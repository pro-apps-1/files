<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class Domains extends BaseController
{


    public function ajaxList($request, $response, $args)
    {
        $pdata    = $request->getQueryParams();
        $dModel   = new \App\Models\Domains($this);
        $uid      = $request->getAttribute('uid');

        $result   = $dModel->dataTableList($pdata, $uid);
        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxGetAll($request, $response, $args)
    {
        $category = $request->getQueryParam("category");
        $dModel   = new \App\Models\Domains($this);
        $uid      = $request->getAttribute('uid');

        $result   = $dModel->getAllDomains($category);
        if ($result) {
            return $response->withStatus(200)->withJson($result);
        }
        return $response->withStatus(404);
    }

    public function ajaxAdd($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $uid      = $request->getAttribute('uid');
        $result   = \App\Validations\Domains::saveDomains($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $dModel   = new \App\Models\Domains($this);
        $dModel->saveDomains($pdata);
    }

    public function ajaxDelete($request, $response, $args)
    {
        $editId   = $args["id"];
        $uid      = $request->getAttribute('uid');
        $result   = \App\Validations\Domains::hasExist($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $dModel     = new \App\Models\Domains($this);
        $domainInfo = $dModel->getInfo($editId);

        $dModel->deleteDomain($editId, $uid);

        $zoneId     = $domainInfo->zone_id;
        $subdomain  = $domainInfo->subdomain;
        if ($zoneId) {
            $settModel  = new \App\Models\Settings();
            $clToken    = $settModel->getSetting("cloudflare_token");
            $clApi      = new \App\Libraries\CloudflareApi($clToken);

            //$clApi->deleteDNS($zoneId, $subdomain);
        }
    }

    public function ajaxActionDNS($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $domainId   = $args["id"];
        $dModel     = new \App\Models\Domains();
        $domainInfo = $dModel->getInfo($domainId);

        $result     = ["status" => "success"];
        if ($domainInfo) {
            $serverId       = getArrayValue($pdata, "server_id");
            $action         = getArrayValue($pdata, "action");
            $servModel      = new \App\Models\Servers();
            $settModel      = new \App\Models\Settings();
            $clToken        = $settModel->getSetting("cloudflare_token");
            $clTTL          = $settModel->getSetting("cloudflare_ttl");

            if ($clToken) {
                $clApi          = new \App\Libraries\CloudflareApi($clToken, $clTTL);
                $serverInfo     = $servModel->getInfo($serverId);

                if ($serverInfo && $action) {
                    $serverIp   = $serverInfo->ip;
                    $zoneId     = $domainInfo->zone_id;
                    $subdomain  = $domainInfo->subdomain;
                    try {
                        if ($action == "create") {
                            try {
                                $clApi->deleteDNS($zoneId, $subdomain, $serverIp);
                            } catch (\Exception $err) {
                            }
                            $clApi->createDNS($zoneId, $subdomain, $serverIp);
                        } else if ($action == "delete") {
                            $clApi->deleteDNS($zoneId, $subdomain, $serverIp);
                        }
                    } catch (\Exception $err) {
                        $msg = "عملیات در دامنه $subdomain با خطا مواجه شد. ";
                        $msg .= "ممکن است این خطا به دلیل موجود بودن آیپی سرور در کلودفلر باشد";
                        $result = ["status" => "error", "messages" => [$msg]];
                    }
                }
            }
        }

        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }
    }
}
