<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;


class Dashboard extends BaseController
{


    public function index($request, $response, $args)
    {

        $viewData = [];
        $viewData["pageTitle"]      = "داشبورد";
        $viewData["activePage"]     = "dashboard";
        $viewData["viewContent"]    = "dashboard/index.php";

        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));
        enqueueScriptFooter(assets("vendor/chartjs/chartjs.min.js"));

        $subsModel  = new \App\Models\Subscribers();
        $servModel  = new \App\Models\Servers();
        $resModel   = new \App\Models\Resellers();
        $uoModel    = new \App\Models\UsersOnline();
        $rModel     = new \App\Models\Reports();

        $userInfo   = $request->getAttribute('userInfo');
        $uid        = $request->getAttribute('uid');
        $userRole   = $userInfo->role;

        $viewData["subsMonth"] = $rModel->subscribers(30, $userRole, $uid);
        $viewData["totalData"] = [
            "subs" => [
                "all"               => $subsModel->getTotalSubs($userRole, $uid),
                "active"            => $subsModel->getTotalSubs($userRole, $uid, "active"),
                "inActive"          => $subsModel->getTotalSubs($userRole, $uid, "inactive"),
                "online"            => $uoModel->getTotalOnline($userRole, $uid),
            ],
        ];
        if ($userRole == "admin") {

            $viewData["totalData"]["resellers"] = [
                "all"               => $resModel->getTotalResellers(),
                "active"            => $resModel->getTotalResellers("active"),
                "inActive"          => $resModel->getTotalResellers("inactive"),
                "totalCredit"       => $resModel->totalCredit(),
            ];

            $viewData["totalData"]["servers"] = [
                "all"           => $servModel->getTotalServers(),
                "active"        => $servModel->getTotalServers(0),
                "inActive"      => $servModel->getTotalServers(1),
                "onlineSubs"    => $servModel->getAllActive(),
            ];
        }
        $viewData["userTraffic"]    = 0; //$utModel->totalData();

        $this->render($viewData);
    }
}
