<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;


class Subscribers extends BaseController
{

    public function logout($request, $response, $args)
    {
        container()->session->delete('admin_login');
        container()->session->delete('userInfo');

        return $response->withHeader('Location', adminBaseUrl('login'));
    }

    public function index($request, $response, $args)
    {

        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $status         = $request->getQueryParam("status");
        $userInfo       = $request->getAttribute('userInfo');
        $uid            = $request->getAttribute('uid');
        $userRole       = $userInfo->role;

        $uModel         = new \App\Models\Users();
        $uoModel        = new \App\Models\UsersOnline();

        $adminUsers     = $uModel->getAllAdmins();
        $totalOnline    = $uoModel->getTotalOnline($userRole, $uid);

        $viewData   = [];
        $viewData["totalOnline"]    = $totalOnline;
        $viewData["adminUsers"]     = $adminUsers;
        $viewData["activeStatus"]   = $status;

        $viewData["activeTab"]      = "all";
        $viewData["pageTitle"]      = "مدیریت مشترکین";
        $viewData["viewContent"]    = "subscribers/index.php";
        $viewData["activeMenu"]     = "subscribers";
        $viewData["activePage"]     = "subscribers";
        $this->render($viewData);
    }

    public function online($request, $response, $args)
    {

        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $status     = $request->getQueryParam("status");
        $userInfo   = $request->getAttribute('userInfo');
        $uid        = $request->getAttribute('uid');
        $userRole   = $userInfo->role;

        $uoModel        = new \App\Models\UsersOnline();
        $totalOnline    = $uoModel->getTotalOnline($userRole, $uid);


        $viewData   = [];
        $viewData["activeStatus"]   = $status;
        $viewData["totalOnline"]    = $totalOnline;
        $viewData["activeTab"]      = "online";
        $viewData["pageTitle"]      = "مدیریت آنلاین";
        $viewData["viewContent"]    = "subscribers/index.php";
        $viewData["activeMenu"]     = "subscribers";
        $viewData["activePage"]     = "online-users";
        $this->render($viewData);
    }

    public function connLogs($request, $response, $args)
    {

        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $status     = $request->getQueryParam("status");
        $userInfo   = $request->getAttribute('userInfo');
        $uid        = $request->getAttribute('uid');
        $userRole   = $userInfo->role;

        $uoModel        = new \App\Models\UsersOnline();
        $totalOnline    = $uoModel->getTotalOnline($userRole, $uid);

        $viewData   = [];
        $viewData["totalOnline"]    = $totalOnline;
        $viewData["activeStatus"]   = $status;
        $viewData["activeTab"]      = "connLogs";
        $viewData["pageTitle"]      = "لاگ ورود و خروج";
        $viewData["viewContent"]    = "subscribers/index.php";
        $viewData["activeMenu"]     = "subscribers";
        $viewData["activePage"]     = "conn-logs";
        $this->render($viewData);
    }

    public function ajaxViewAdd($request, $response, $args)
    {
        $cModel     = new \App\Models\Categories();

        $uid        = $request->getAttribute('uid');
        $userInfo   = $request->getAttribute('userInfo');
        $userRole   = $userInfo->role;
        $pModel     = new \App\Models\Packages();

        $packages   = $pModel->getUserPackages($uid, $userRole);

        $viewData   = [];
        $viewData['userCredit']     = $userInfo->credit;
        $viewData['viewContent']    = 'subscribers/form.php';
        $viewData['packages']       = $packages;
        $viewData["categories"]     = $cModel->getAll();
        $viewData['isUnlimited']    = $userInfo->unlimited;
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewEdit($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $editId     = $args["id"];
        $viewData   = [];

        $sModel     = new \App\Models\Subscribers();
        $userInfo   = $sModel->getEditInfo($editId);

        if ($userInfo) {
            $pModel     = new \App\Models\Packages();
            $cModel     = new \App\Models\Categories();
            $uInfo      = $request->getAttribute('userInfo');
            $userRole   = $uInfo->role;

            $packages   = $pModel->getUserPackages($uid, $userRole);

            $viewData['packages']       = $packages;
            $viewData['userRole']       = $userRole;
            $viewData['userCredit']     = $uInfo->credit;
            $viewData["categories"]     = $cModel->getAll();
            $viewData['userValues']     = $userInfo;
            $viewData['viewContent']    = 'subscribers/form.php';
            $viewData['refrence']       = $request->getQueryParam("ref");
            $viewData['isUnlimited']    = $userInfo->cunlimited;

            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewDetails($request, $response, $args)
    {
        $editId     = $args["id"];
        $viewData   = [];
        $isJson     = $request->getQueryParam("json");
        $sModel     = new \App\Models\Subscribers();
        $userInfo   = $sModel->getDetails($editId);

        if ($isJson) {
            return $response->withStatus(200)->withJson($userInfo);
        }

        if ($userInfo) {
            $viewData['userValues']    = $userInfo;
            $viewData['viewContent']   = 'subscribers/details.php';

            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewRenewal($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $uInfo      = $request->getAttribute('userInfo');
        $uRole      = $uInfo->role;

        $editId     = $args["id"];
        $viewData   = [];

        $sModel     = new \App\Models\Subscribers();
        $userInfo   = $sModel->getEditInfo($editId);
        if ($userInfo) {

            $pModel     = new \App\Models\Packages();
            $packages   = $pModel->getUserPackages($uid, $uRole);

            $viewData['packages']      = $packages;
            $viewData['userValues']    = $userInfo;
            $viewData['viewContent']   = 'subscribers/renewal.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxAddUser($request, $response, $args)
    {
        $uInfo     = $request->getAttribute('userInfo');
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();

        $result    = \App\Validations\Subscribers::save($pdata, null, $uInfo);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }


        $sModel = new \App\Models\Subscribers();

        $cRole          = $uInfo->role;
        $res            = $sModel->saveUsers($pdata, $uid, $uInfo);
        if ($cRole == "reseller") {
            $userInfo = $sModel->getInfo($uid);
            $res["credit"] = $userInfo->credit;
        }

        return $response->withStatus(200)->withJson($res);
    }


    public function ajaxEditUser($request, $response, $args)
    {
        $uInfo     = $request->getAttribute('userInfo');
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Subscribers::save($pdata, $editId, $uInfo);

        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Subscribers();

        try {
            $res        = $sModel->saveUsers($pdata, $uid, $uInfo, $editId);
            $cRole      = $uInfo->role;
            if ($cRole == "reseller") {
                $userInfo = $sModel->getInfo($uid);
                $res["credit"] = $userInfo->credit;
            }

            return $response->withStatus(200)->withJson($res);
        } catch (\Exception $err) {
            $result["status"] = "error";
            $result["messages"] = "در افزودن کاربر خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxSaveRenewal($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $userInfo  = $request->getAttribute('userInfo');
        $userRole  = $userInfo->role;

        $result    = \App\Validations\Subscribers::renewal($pdata, $editId, $userRole);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Subscribers();
        $result = $sModel->renewalUser($pdata, $editId, $uid);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxDeleteUser($request, $response, $args)
    {
        $id        = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Subscribers::hasExist($id);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Subscribers();
        $sModel->deleteUser($id, $uid);
    }

    public function ajaxDeleteUsers($request, $response, $args)
    {
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Subscribers::deleteBulk($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel     = new \App\Models\Subscribers();
        $userIds    = $pdata["ids"];
        $sModel->deleteBulkUsers($userIds, $uid);
    }

    public function ajaxUsersList($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $uid        = $request->getAttribute('uid');
        $userInfo   = $request->getAttribute('userInfo');
        $userRole   = $userInfo->role;

        $sModel   = new \App\Models\Subscribers($this);

        $result   = $sModel->dataTableList($pdata,  $uid, $userRole);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxToggleUserActive($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Subscribers::toggleActive($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Subscribers();
        $sModel->toggleActive($editId, $uid);
    }

    public function ajaxResetUserTraffic($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Subscribers::hasExist($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $utModel = new \App\Models\UsersTraffics();
        $utModel->resetTraffic($editId, $uid);
    }

    public function ajaxUsersOnlinesList($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $uModel     = new \App\Models\UsersOnline($this);
        $uid        = $request->getAttribute('uid');
        $userInfo   = $request->getAttribute('userInfo');
        $userRole   = $userInfo->role;

        $result   = $uModel->dataTableList($pdata, $uid, $userRole);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxConnLogsList($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $clModel    = new \App\Models\ConnLogs($this);
        $uid        = $request->getAttribute('uid');
        $userInfo   = $request->getAttribute('userInfo');
        $userRole   = $userInfo->role;

        $result     = $clModel->dataTableList($pdata, $uid, $userRole);
        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxKillOnlineUser($request, $response, $args)
    {
        $uid    = $request->getAttribute('uid');
        $id     = $args["id"];
        $uModel = new \App\Models\UsersOnline($this);
        $uModel->killOnlineUser($id, $uid);
        return $response->withStatus(200);
    }

    public function ajaxDeleteLogs($request, $response, $args)
    {
        $userInfo   = $request->getAttribute('userInfo');
        $userRole   = $userInfo->role;

        if ($userRole == "admin") {
            $conModel  = new \App\Models\ConnLogs($this);
            $conModel->deleteAll();
            return $response->withStatus(200);
        }
    }

    public function ajaxViewConfigs($request, $response, $args)
    {
        $editId     = $args["id"];
        $viewData   = [];

        $sModel     = new \App\Models\Subscribers();
        $userInfo   = $request->getAttribute('userInfo');
        $userRole   = $userInfo->role;

        $userInfo   = $sModel->getConfigure($editId, $userRole);

        if ($userInfo) {
            $viewData['userValues']    = $userInfo;
            $viewData['viewContent']   = 'subscribers/configs.php';

            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }
}
