<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

use \App\Libraries\Mysqldump as IMysqldump;

class Settings extends BaseController
{

    public function index($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $sModel     = new \App\Models\Settings($this);
        $settings   = $sModel->getSettings();

        $viewData = [];
        $viewData["pageTitle"]      = "تنظیمات اصلی";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "main";
        $viewData["activePage"]     = "settings";
        $viewData["activeMenu"]     = "settings";
        $viewData["settings"]       = $settings;
        $this->render($viewData);
    }

    public function servers($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $sModel     = new \App\Models\Settings($this);
        $settings   = $sModel->getSettings();

        $viewData = [];
        $viewData["pageTitle"]      = "تنظیمات سرور";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "servers";
        $viewData["activePage"]     = "settings";
        $viewData["activeMenu"]     = "settings";
        $viewData["settings"]       = $settings;
        $this->render($viewData);
    }

    public function domains($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $sModel     = new \App\Models\Settings($this);
        $cModel     = new \App\Models\Categories($this);
        $clToken    = $sModel->getSetting("cloudflare_token");
        $clTtl      = $sModel->getSetting("cloudflare_ttl");

        $viewData = [];
        $viewData["pageTitle"]      = "تنظیمات دامین ها";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "domains";
        $viewData["activePage"]     = "domains";
        $viewData["activeMenu"]     = "settings";
        $viewData["clToken"]        = $clToken;
        $viewData["clTtl"]          = $clTtl;
        $viewData["categories"]     = $cModel->getAll();
        $this->render($viewData);
    }

    public function messages($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $sModel     = new \App\Models\Settings($this);
        $settings   = $sModel->getSettings();

        $viewData = [];
        $viewData["pageTitle"]      = "تنظیمات پیامک ها";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "messages";
        $viewData["activePage"]     = "messages";
        $viewData["activeMenu"]     = "settings";
        $viewData["settings"]       = $settings;
        $this->render($viewData);
    }

    public function backup($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $uModel         = new \App\Models\Users();
        $bModel         = new \App\Models\Backup($this);
        $sModel         = new \App\Models\Settings($this);
        $adminUsers     = $uModel->getAllAdmins();


        $backupFiles    = $bModel->getUserBackups();

        $viewData = [];
        $viewData["pageTitle"]      = "پشتیبان گیری";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "backup";
        $viewData["activePage"]     = "backup";
        $viewData["activeMenu"]     = "settings";
        $viewData["adminUsers"]     = $adminUsers;
        $viewData["autoBackup"]     = $sModel->getSetting("auto_backup");
        $viewData["backupFiles"]    = $backupFiles;
        $this->render($viewData);
    }

    public function license($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $setModel       = new \App\Models\Settings();
        $licenseData    =  $setModel->getLicenseData();

        $viewData = [];
        $viewData["pageTitle"]      = "لایسنس";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "license";
        $viewData["activePage"]     = "license";
        $viewData["activeMenu"]     = "settings";
        $viewData["licenseData"]    = $licenseData;
        $this->render($viewData);
    }



    public function usersPanel($request, $response, $args)
    {

        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $sModel     = new \App\Models\Settings($this);
        $settings   = $sModel->getSetting("users_panel");
        if (empty($settings)) {
            $settings = [];
        }

        $viewData = [];
        $viewData["pageTitle"]      = "تنظیمات پنل کاربران";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "users_panel";
        $viewData["activePage"]     = "users_panel";
        $viewData["activeMenu"]     = "settings";
        $viewData["settings"]       = $settings;
        $this->render($viewData);
    }

    public function cloudflare($request, $response, $args)
    {

        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $sModel     = new \App\Models\Settings($this);
        $viewData = [];
        $viewData["pageTitle"]      = "تنظیمات کلودفلر";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "cloudflare";
        $viewData["activePage"]     = "cloudflare";
        $viewData["activeMenu"]     = "settings";
        $this->render($viewData);
    }

    public function telegramBot($request, $response, $args)
    {

        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $sModel     = new \App\Models\Settings($this);
        $adminBot   = $sModel->getSetting("admin_telegram_bot");;

        $viewData   = [];
        $viewData["pageTitle"]      = "تنظیمات ربات تلگرام";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "telegram-bot";
        $viewData["activePage"]     = "telegram-bot";
        $viewData["activeMenu"]     = "settings";
        $viewData["adminBot"]       = $adminBot;
        $this->render($viewData);
    }

    public function ajaxSaveMainSettings($request, $response, $args)
    {
        $uid            = $request->getAttribute('uid');
        $pdata          = $request->getParsedBody();
        $sModel         = new \App\Models\Settings($this);
        $sModel         = new \App\Models\Settings($this);
        $licenseData    = $sModel->getLicenseData();


        $upFiles        = $request->getUploadedFiles();
        $pdata["logo"]  = null;
        if (!empty($upFiles["logo"])) {
            if ($upFiles["logo"]->getClientFilename()) {
                $pdata["logo"]  = $upFiles["logo"];
            }
        }
        $licensePlan = $licenseData["plan_name"];

        $sModel->saveMainSettings($pdata, $licensePlan, $uid);

        $redirectUrl = "";
        if (!empty($pdata["admin_prefix_url"])) {
            $baseUrl     = $pdata["admin_prefix_url"];
        }else{
            $baseUrl     = "admin";
        }
        $redirectUrl = adminBaseUrl("settings", $baseUrl);

        return $response->withStatus(200)->withJson(["next_url" => $redirectUrl]);
    }

    public function ajaxSaveServersSettings($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $validator  = new  \App\Validations\Settings();

        $uid        = $request->getAttribute('uid');
        // $validate   = $validator->saveServersSettings($pdata);
        // if ($validate["status"] == "error") {
        //     return $response->withStatus(400)->withJson($validate);
        // }

        $sModel = new \App\Models\Settings($this);
        $sModel->saveServersSettings($pdata, $uid);

        return $response->withStatus(200);
    }

    public function ajaxSaveUsersPanel($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $pdata      = $request->getParsedBody();

        $sModel = new \App\Models\Settings($this);
        $sModel->saveUsersPanel($pdata, $uid);
        return $response->withStatus(200);
    }

    public function ajaxSaveSmsSetting($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $pdata      = $request->getParsedBody();

        $sModel = new \App\Models\Settings($this);
        $sModel->saveSmsSettings($pdata, $uid);
    }

    public function ajaxSaveDomains($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $pdata      = $request->getParsedBody();

        $sModel = new \App\Models\Settings($this);
        $sModel->saveDomains($pdata, $uid);
    }

    public function ajaxSaveCloudflare($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $pdata      = $request->getParsedBody();

        $sModel     = new \App\Models\Settings($this);
        $token      = !empty($pdata["token"]) ? $pdata["token"] : "";
        $clApi      = new \App\Libraries\CloudflareApi($token);

        try {
            $clApi->checkToken();
            $sModel->saveCloudflareData($pdata, $uid);
        } catch (\Exception $err) {
            return $response->withStatus(400)->withJson(["messages" => "توکن ارسالی صحیح نمی باشد"]);
        }
    }

    public function ajaxLicenseDetails($request, $response, $args)
    {
        $checker    =  new \App\Libraries\RocketApi();
        $result     = $checker->getLicenseDetails();
        if (!$result) {
            return $response->withStatus(400)->withJson(["messages" => ["لایسنس شما فعال نیست. با پشتیبانی تماس بگیرید"]]);
        }
        
        $sModel = new \App\Models\Settings($this);
        $sModel->saveLicenseData($result);

        $viewData['viewContent']   = 'settings/license-info.php';
        $viewData['licenseData']   = $sModel->getLicenseData();

        return $this->renderAjxView($viewData);
    }


    public function ajaxRenwalLicense($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $monthCount = !empty($pdata["month"]) ? $pdata["month"] : "";

        $rapi       =  new \App\Libraries\RocketApi();
        $result     = $rapi->renwalPayment($monthCount);
        if ($result) {
            return $response->withStatus(200)->withJson(["pay_url" => $result["pay_url"]]);
        }

        return $response->withStatus(400)->withJson(["messages" => ["خطایی رخ داد. دوباره تلاش کنید"]]);
    }

    public function ajaxSaveBannerSettings($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $pdata      = $request->getParsedBody();

        $sModel = new \App\Models\Settings($this);
        $sModel->saveBannerText($pdata, $uid);
    }

    public function ajaxImportBackup($request, $response, $args)
    {
        $uid            = $request->getAttribute('uid');
        $validator      = new  \App\Validations\Settings();
        $pdata          = $request->getParsedBody();

        $upFiles        = $request->getUploadedFiles();
        $pdata["file"]  = null;
        if (!empty($upFiles["sql_file"])) {
            $pdata["file"]  = $upFiles["sql_file"];
        }

        $validate   = $validator->importBackup($pdata);
        if ($validate["status"] == "error") {
            return $response->withStatus(400)->withJson($validate);
        }

        $sqlContent = $pdata["file"]->getStream()->getContents();
        $importFrom = $pdata["import_from"];

        $bkModel    = new \App\Models\Backup();
        $parser     = new \App\Libraries\MySQLExportParser($sqlContent);
        $creator    = $uid;
        if (!empty($pdata["creator"])) {
            $creator    = $pdata["creator"];
        }

        if ($importFrom == "rokcet_single_server") {
            try {

                $parser         = new \App\Libraries\MySQLExportParser($sqlContent);
                $values         = $parser->getTablesData(["cp_users", "cp_traffics"]);

                $totalInsert    = $bkModel->importOldRocket($values, $creator);

                return $response->withStatus(200)->withJson(["total_insert" => $totalInsert]);
            } catch (\Exception $err) {
                return $response->withStatus(400)->withJson([
                    "messages" => "خطایی رخ داد لطفا دوباره تلاش کنید"
                ]);
            }
        } else if ($importFrom == "current") {
            $values      = $parser->getTablesData(["cp_users", "cp_traffics"]);
            $totalInsert =  $bkModel->importSelfBackup($sqlContent, $values);
            return $response->withStatus(200)->withJson(["total_insert" => $totalInsert]);
        }
    }

    public function ajaxCreateBackup($request, $response, $args)
    {
        $appName        = "Rocket-Pro";
        $date           = jdate()->format("Y-m-d");
        $backupName     = "$appName-$date";

        $backupPath     = PATH_ASSETS . DS . "backup";
        $backupFilePath = $backupPath . DS . "$backupName.sql";


        $dbConf = getConfig("db");

        try {
            $conf = "mysql:host=" . $dbConf["host"] . ";dbname=" . $dbConf["database"];
            $dump = new IMysqldump($conf, $dbConf["username"], $dbConf["password"]);
            $dump->start($backupFilePath);
        } catch (\Exception $e) {
            echo 'mysqldump-php error: ' . $e->getMessage();
        }
    }

    public function ajaxDownloadBackup($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        if (!empty($pdata["filename"])) {
            $filename = $pdata["filename"];
            $filePath = PATH_ASSETS . DS . "backup" . DS . $filename;

            $fileContent = file_get_contents($filePath);
            // Set the appropriate headers for an SQL file download
            $response = $response->withHeader('Content-Type', 'application/sql')
                ->withHeader('Content-Disposition', 'attachment; filename=' . basename($filePath));

            // Output the file content
            $response->getBody()->write($fileContent);
            return $response;
        } else {
            // File not found
            return $response->withStatus(404)->write('File not found');
        }
    }

    public function ajaxDeleteExportFile($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        if (!empty($pdata["filename"])) {

            $filename = $pdata["filename"];

            $filePath = PATH_ASSETS . DS . "backup" . DS . $filename;
            if (file_exists($filePath)) {
                @unlink($filePath);
            }
        }
    }

    public function ajaxSaveAutoBackup($request, $response, $args)
    {
        $pdata  = $request->getParsedBody();

        if ($pdata["sending_every_hours"] > 24) {
            $pdata["sending_every_hours"] = 24;
        }

        $sModel = new \App\Models\Settings($this);
        $sModel->saveSettings("auto_backup", json_encode($pdata));
    }

    public function ajaxSaveAdminBot($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();

        $validator  = new  \App\Validations\Settings();
        $validate   = $validator->checkTelegramBot($pdata);
        if ($validate["status"] == "error") {
            return $response->withStatus(400)->withJson($validate);
        }

        $sModel = new \App\Models\Settings($this);
        $sModel->saveSettings("admin_telegram_bot", json_encode($pdata));
    }
}
