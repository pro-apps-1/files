<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class Categories extends BaseController
{

    public function index($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $viewData = [];
        $viewData["pageTitle"]      = "دسته بندی ها";
        $viewData["viewContent"]    = "settings/index.php";
        $viewData["activeTab"]      = "categories";
        $viewData["activePage"]     = "categories";
        $viewData["activeMenu"]     = "settings";
        $this->render($viewData);
    }

    public function ajaxList($request, $response, $args)
    {
        $pdata    = $request->getQueryParams();
        $cModel   = new \App\Models\Categories($this);
        $uid      = $request->getAttribute('uid');

        $result   = $cModel->dataTableList($pdata, $uid);
        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxGetAll($request, $response, $args)
    {
        $cModel   = new \App\Models\Categories($this);
        $uid      = $request->getAttribute('uid');

        $result   = $cModel->getAllCategory();
        if ($result) {
            return $response->withStatus(200)->withJson($result);
        }
        return $response->withStatus(404);
    }

    public function ajaxAdd($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $uid      = $request->getAttribute('uid');
        $result   = \App\Validations\Categories::saveCategory($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $cModel   = new \App\Models\Categories($this);
        $cModel->saveCategory($pdata, null, $uid);
    }

    public function ajaxEdit($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $editId   = $args["id"];
        $uid      = $request->getAttribute('uid');
        $result   = \App\Validations\Categories::saveCategory($pdata, $editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $cModel   = new \App\Models\Categories($this);
        $cModel->saveCategory($pdata, $editId, $uid);
    }

    public function ajaxDelete($request, $response, $args)
    {
        $editId   = $args["id"];
        $uid      = $request->getAttribute('uid');
        $result   = \App\Validations\Categories::hasExist($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $cModel = new \App\Models\Categories($this);
        $cModel->deleteCategory($editId, $uid);
    }
}
