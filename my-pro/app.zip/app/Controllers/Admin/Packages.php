<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class Packages extends BaseController
{
    public function index($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $viewData = [];
        $viewData["pageTitle"]      = "مدیریت پکیج ها";
        $viewData["viewContent"]    = "packages/index.php";
        $viewData["activeMenu"]     = "packages";
        $viewData["activePage"]     = "packages";
        $this->render($viewData);
    }

    public function ajaxViewAdd($request, $response, $args)
    {
        $viewData = [];
        $viewData['viewContent']   = 'packages/form.php';
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewEdit($request, $response, $args)
    {
        $editId         = $args["id"];

        $viewData       = [];

        $aModel         = new \App\Models\Packages();
        $packageInfo    = $aModel->getInfo($editId);

        if ($packageInfo) {
            $viewData['formValues']    = $packageInfo;
            $viewData['viewContent']   = 'packages/form.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxAddPackage($request, $response, $args)
    {
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Packages::save($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $pModel = new \App\Models\Packages();
        $pModel->savePackages($pdata);
    }

    public function ajaxEditPackage($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Packages::save($pdata, $editId, $uid);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $pModel = new \App\Models\Packages();
        $pModel->savePackages($pdata, $editId);
    }

    public function ajaxDeletePackage($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Packages::hasExist($editId, $uid);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $pModel = new \App\Models\Packages();
        $pModel->deletePackage($editId, $uid);
    }

    public function ajaxPackagesList($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $pModel   = new \App\Models\Packages($this);
        $uid      = $request->getAttribute('uid');

        $result   = $pModel->dataTableList($pdata, $uid);
        return $response->withStatus(200)->withJson($result);
    }
}
