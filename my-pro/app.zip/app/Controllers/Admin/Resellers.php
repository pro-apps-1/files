<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class Resellers extends BaseController
{

    public function index($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datepicker/datepicker.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));

        enqueueStyleHeader(assets("vendor/datepicker/datepicker.min.css"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $viewData = [];
        $viewData["pageTitle"]      = "کاربران نماینده";
        $viewData["viewContent"]    = "resellers/index.php";
        $viewData["activeMenu"]     = "resellers";
        $viewData["activePage"]     = "resellers";
        $this->render($viewData);
    }

    public function ajaxViewAdd($request, $response, $args)
    {
        $viewData = [];
        $viewData['viewContent']   = 'resellers/form.php';
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewEdit($request, $response, $args)
    {
        $editId     = $args["id"];
        $viewData   = [];

        $aModel     = new \App\Models\Resellers();
        $userInfo   = $aModel->getInfo($editId);
        
        if ($userInfo) {
            $viewData['userValues']    = $userInfo;
            $viewData['viewContent']   = 'resellers/form.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxAddUser($request, $response, $args)
    {
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Resellers::save($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $aModel = new \App\Models\Resellers();
        try {
            $aModel->saveUsers($pdata, null, $uid);
        } catch (\Exception $err) {
          
            $result["status"] = "error";
            $result["messages"] = "در افزودن کاربر خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxEditUser($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Resellers::save($pdata, $editId, $uid);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $aModel = new \App\Models\Resellers();
        try {
            $aModel->saveUsers($pdata, $editId, $uid);
        } catch (\Exception $err) {
            echo $err->getMessage();
            $result["status"] = "error";
            $result["messages"] = "در افزودن کاربر خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxDeleteUser($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Resellers::delete($editId, $uid);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $aModel = new \App\Models\Resellers();
        $aModel->deleteUser($editId, $uid);
    }

    public function ajaxUsersList($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $aModel   = new \App\Models\Resellers($this);
        $uid      = $request->getAttribute('uid');

        $result   = $aModel->dataTableList($pdata, $uid);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxViewSettings($request, $response, $args)
    {
        $editId     = $args["id"];
        $viewData   = [];

        $aModel     = new \App\Models\Resellers();
        $userInfo   = $aModel->getInfo($editId);
        $activeTab  = $request->getQueryParam('tab');

        if ($userInfo) {
            $activeTab  = $activeTab ?  $activeTab : "details";

            if ($activeTab == "packages") {
                $pModel                   = new \App\Models\Packages();
                $packages                 = $pModel->getAllActive();
                $viewData['packages']     = $packages;
            }

            $viewData['activeTab']     = $activeTab;
            $viewData['userValues']    = $userInfo;
            $viewData['viewContent']   = 'resellers/settings/index.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }



    /** Packages */

    public function ajaxPackagesList($request, $response, $args)
    {
        $editId   = $args["id"];
        $pdata    = $request->getParsedBody();
        $upModel  = new \App\Models\UsersPackages();
        $uid      = $request->getAttribute('uid');

        $result   = $upModel->dataTableList($pdata, $editId);
        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxDeletePackages($request, $response, $args)
    {
        $userId    = $args["id"];
        $packageId = $args["pkg_id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Resellers::hasExist($userId, $uid);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $apModel    = new \App\Models\UsersPackages();
        $apModel->deleteUserAccess($userId, $packageId, $uid);
    }

    public function ajaxAddPackage($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $userId     = $args["id"];

        $result     = \App\Validations\Resellers::addPackage($pdata, $userId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uid        = $request->getAttribute('uid');
        $upModel    = new \App\Models\UsersPackages();
        $upModel->addPackage($pdata, $userId, $uid);
    }


    /** Credits */
    public function ajaxCreditsList($request, $response, $args)
    {
        $userId   = $args["id"];
        $pdata    = $request->getParsedBody();
        $cModel   = new \App\Models\Credits();

        $result   = $cModel->dataTableList($pdata, "reseller", $userId);
        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxDeleteCredits($request, $response, $args)
    {
        $userId    = $args["id"];
        $packageId = $args["pkg_id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Resellers::hasExist($userId, $uid);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $apModel    = new \App\Models\UsersPackages();
        $apModel->deleteUserAccess($userId, $packageId, $uid);
    }

    public function ajaxAddCredit($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $userId     = $args["id"];

        $result     = \App\Validations\Resellers::addCredit($pdata, $userId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uid        = $request->getAttribute('uid');
        $upModel    = new \App\Models\Credits();
        $upModel->addCredit($pdata, $userId, $uid);
    }
}
