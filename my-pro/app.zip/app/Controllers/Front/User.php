<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Front;

class User extends BaseController
{

    public function index($request, $response, $args)
    {
        $this->templateName = "Front/layouts/user-layout.php";
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $userId     = $request->getAttribute('user_id');

        $subsModel  = new \App\Models\Subscribers();
        $doModel    = new \App\Models\Domains();
        $userInfo   = $subsModel->getDetails($userId);
        $configure  = $subsModel->getConfigure($userId);
        $domains    = $doModel->groupDomainsByCat();
    

        $viewData = [];
        $viewData["domains"]        = $domains;
        $viewData["userInfo"]       = $userInfo;
        $viewData["configs"]        = $configure->configs;
        $viewData["pageTitle"]      = "پروفایل کاربری";
        $viewData["viewContent"]    = "user/profile.php";
        $viewData["activePage"]     = "user-profile";
        $this->render($viewData);
    }

    public function login($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $this->templateName = "Front/layouts/login-layout.php";
        $viewData = [];
        $viewData["pageTitle"]      = "ورود کاربر";
        $viewData["viewContent"]    = "user/login.php";
        $viewData["activePage"]     = "user-login";
        $this->render($viewData);
    }

    public function ajaxLogin($request, $response, $args)
    {

        $pdata      = $request->getParsedBody();
        $validate   = \App\Validations\Users::login($pdata);
        if ($validate["status"] == "error") {
            return $response->withStatus(400)->withJson($validate);
        }

        $aModel   = new \App\Models\Users($this);
        $result   = $aModel->checkLogin($pdata , "subscriber");
        if ($result) {
            return $response->withStatus(200)->withJson(["next_url" => baseUrl("user/$result")]);
        }

        return $response->withStatus(404);
    }
}
