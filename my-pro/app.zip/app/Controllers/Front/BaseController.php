<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Front;

class BaseController
{
    public $cont;
    public $templateName = "Front/layouts/front-layout.php";

    public $data = array(
        'pageTitle'         => '',
        'viewContent'       => '',
        'activePage'        => '',
        'activeTheme'       => 'light',
        'showUpNotice'      => false,
        'siteTitle'         => "",
    );

    function __construct($cont = null)
    {
        $this->cont = $cont;
        loadHelpers("front");

        $sModel         = new \App\Models\Settings();
        $siteTitle      = $sModel->getSetting("site_title");
        
        $this->data["siteLogo"]     = siteLogo();
        $this->data["siteTitle"]    = $siteTitle ? $siteTitle : "Rocket SSH";
    }


    public function __get($var)
    {
        return container()->{$var};
    }

    protected function initRoute($req, $res)
    {
        $this->request = $req;
        $this->response = $res;
    }

    public function setRequest($request)
    {
        $this->request = $request;
    }

    public function setResponse($response)
    {
        $this->response = $response;
    }

    public function render($data)
    {
        $sModel     = new \App\Models\Settings();
        $settings   = $sModel->getSetting("users_panel");
        if ($settings) {
            $this->data["activeTheme"]  = $settings['theme'];
            $this->data["settings"]     = $settings;
        }
        

        $prefixPageTitle    = $this->data["siteTitle"];
        $this->data         = array_merge($this->data, $data);
        $pageTitle          = $this->data["pageTitle"] . " | " . $prefixPageTitle;

        $this->data["pageTitle"] = $pageTitle;

        return $this->cont->view->render($this->response, $this->templateName, $this->data);
    }


    public function renderAjxView($data)
    {
        $html = $this->fetch($data);
        return $this->response->withStatus(200)->withJson(["html" => $html]);
    }

    public function fetch($data)
    {
        $this->templateName = 'Front/layouts/ajax-layout.php';
        $this->data         = array_merge($this->data, $data);

        return $this->cont->view->fetch($this->templateName, $this->data);
    }
}
