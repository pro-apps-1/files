<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+zYZhXFxdA/5hGRcqiE1wnEsGVImrG/Tzrfnw0/0hJa4TG1qgT9WqcvzXKWrAdnvX1mpvph
JEfA51tzkUbpo1Dc/6ymZ3Qo3QwukMKWpCEcLTZFIDoCph/3xp0XNUsgDmoE/IxuxtVMoaqtgHwt
LKzfAYzM0NkI12AnT5DMDNxTkUIhXKuh+EDavX69NJRKS7B/o1enZldEsaMuchdIOBOIWOTr6Hyc
SaOl2NlgW2eS/t48V4hSAMKRVQa3YfVrEooXb33ZmUmbimo8G62q62zKbydIQAcg691cHXhu9Pln
mQnyK/zFFOjtm7FmjT9zUPCerA/T4MrC5LpJ8GIYVQTWsIH9TiBFCs8ovq4M0cTeokbp3OjUVNVJ
no5jjf8aaVZHkzB1Yy0ACIQO3WkT8nZxg1UVS9W/k9mCDv0Lf/3MsOUvxcDT0zh/RYv5gsQljrMa
YiUIMC4fVGeNS9hqh5rrkYfE9li6r8dxy1CbzNyXWScFzacVmadBt7PSUxhWtOkboSb+gILOzzWo
B6Sj/Rwk4fKr3CjDYl05aAL75y260ITtBHykqP+AR3ucVXVwyB37RXSbMTskaErEZQbZAvurxOrS
dOhQLyIkI791X+DixvWzdUlAaAdGfiV0MLGlpWUL1mbe/trYNlsiZSGxtLEhexttJkGRe+6mA0Jd
tqMw+60mpvTMhSbEADvtKiRpndH3UsRtJX5q3PNYcf56wAw+WVBxn7ociSqBESRmr3VC7rVNHVuJ
BRpqltweqncu6/S2397KKZUxV11ToGDe2AHVAMLBhrUX/UApkHzl2EyU/fS5KmUI2LRqB+3Zwd+z
bsNdUebnQdrfC0DLZ7JNk0Cl1HYNFaP/HpRAw/UHDhaJClmChpgN9JAcpcA1CG01d4pQ6HD1vd9E
8Q7ZSuAA7rQNDf2lPTVvBJ3cRYegj6bTNJbkz70aRhfKYTbHXA+A7tcBnLklLPTmirzspNuN3XOB
8mHVztcS+VGWUNo1ffk7TGy35bvRz29anskJaGCctSTAkZbi3S/pR8xywdmKkPvieo92cbrRjdMK
rDssvs8zaslhIKz42Y0Zp0/dRRT08+IojRKCwd948nVp7uTH+418OvOZksbj8HSbA9G/unm89cN2
7JOLOXu1OzLdu1Rx2+ATXQGiCRxdQXTQq/ibvfoIS7DKFgT9S5KQsXBFiyhm5iWVcPvmOkdfHjAl
MVgfuJEP+rEhfm88J0Yd4hrGvhIMwb0p+2ZPMvyXw/0muYYWsYaX+MbnMQOHr7D86DhJO85Y6dvw
bpP9t17B4pzZpvKOB1vMBAfiT4r7UGx6Gn9xHnb3mY54sIkWVUpEp49P1I7rtcrMSCaEDai9lMHX
fu8CZFkiRqk4TxtD+Lr53/befws4uvIZNPcYkmXPKTnJI+4tuSYGNfyJVNKKQ2rrFHXLfdWjyKLv
AIOtx980QsGQm4Nwdamh5EpKAD5K2acmXA0UJ/9vi6ffTHoBZNxAAQaHW1j+UW4AuNpAiLCqCwjn
e1avsO4de+R8/JZMxUbtmuA3CQcj8W5oU0/r8kbqGPAPuq9mhNuzaCYQFnjxBhqblOdxxOtE5KmY
UFt72ObFXNUB9bEyaMgoKPrn+hr8wXkXUVadmLoK1F+3q/eK8Te5vvdDOX/Ugvt5QHBRJYNA9JZK
Ilbl8T11EkYx/LuE/nMHfZiroxShVwdf+oZ1cAfKix4QUMMq3IFJdWRwc6a5zlDIUaigYp4j/DMA
1+SJl84Y/SjvojEit5neswEteSFGtj05t8PhibziJ8qoJW/foXgy0QbHg0b+YZl/WrIdUnlZf3Us
5OxKv7xcDg/+6u6i4btlFqxjIKVWx6s1mW/44zhdzUYuaxpfV4kTlr7v5nZ1WgMe1glkUQeVUxNt
scZOJHZz5VF/wa9l+Gp4EeFM0ebN+CwHRm60rmmtJShPSFegKPktQ9d5z0N7TO2p9y0OkGNOjguG
nTH/JsgosPWu49L+4Uoc3a71Xz04ln8syd5reU+0q1Mea8Fhtfb9ScgG9r7o7BTD6/EFUMGizLh6
rUlwjvyUdWoSOBM5nQDjQOygd4v+dPNqCYYO66387Rqk5Pwwv7DoxJh+oUdQOxi5ytYl655tUzCv
drl18njWmC7aCNLWL5+B32OIYdzqzyCBOHeP1jwuz6aNqU/f97Elq7C8MP6tazRSiSUep35bX9nZ
BfSguQAcuIWI1nqMHCiGYffRKMihui8PWPvuKrldPYHz9Nc1AfRqpQtArgTiroVLFnsK8fAxvtQX
b8n7NQ5vkO4+6J0xCwEu9hXZ42WwHdzQMRh5cSEjXD7yYU75woTGgS9o9flS1GNNoluQFOM2E1Rv
IQhzixo8xmUfQd4lWoFqDIsG2Kp6CuCGOlbhG4ftjpqIGF5SKBT5pDDn1zC5wtVP3WjGmIkW5pAC
Qm6v/J4ejN1c1rVkOAfi+6kCmUbEe81GB+NibKrGxQ/tbjpTwxi2lvc0iOx0hiPgjaJQndO7425W
9KkRIPK2fa2oZaPQ5EA+YDI2iZuYbpPREo/Y6I+nRavt6Wnz9lTBafDfUK7W9EJn1eC+V92tLuuj
W49FAfwMs0OjUdN+ift0L83jNZE99tN70H1ph93cVB3ybQ1i0JNxQz2qUSJUD19h6cTPS9doGGke
3mL6cw3hEJVH2e5PBosv2AXRuo8LCDF1/WFAahHoWQwpqib1vLAg0kmKuyV6lgLa6zo2EFU3EjLv
R8PkHEhKp6pLl7y89lPxG/ctnjzpaTnM7nKr5nyPX/vTwqtR2EdlX40rwc70kRQv1+Zr/HgE0bHn
mihgS+XnoSj1EkEWzd+NZk98kjiwBQ57uB19H8LY2F9Of4KQWuDSTDC+rgu/SJcURifvAVgOddye
mPGo4FIetkbA9614Hf1dCj2dWINL0mrN+Q4ZVlO5oHampui2VcOkI3AjT7mY8vrSxAr6tIN7u2gs
5+I6RJUFRnKoIFPh2d+chUbBJFBlWB3w/zI5mikUDXPpZ3IIin27lWn2GdktWBw7P4Ro8zI6uzvS
MJjR9BZ7kity5Y44ljwEP5O6PKkytLIvNCU230M5YCsyDq5ZTLY421LBaOqU9o5jOfowUr3yjHyR
nlJWNLeaJGxtiLNAC+XEFNl4o6pUJ+jBpq2+tm95ZTPjlJIUVUUCQ1zHdv5acWSRudX5uNFS+zyf
jyg7sD399FCWkKsh1QQJjntt9zpvWSOQRMI1aOmDS08HKsUTZ0tSHKz7RikIk/RgZdy7qkOvYmCD
cOv4EpcqujGDTmr0iMr7Kyb+ysyoxSUNZvE8Duni/VI1CaiTfy/GKzg5slESLhxyUoNabjazvt93
j+Y5920Oq+Ry4EpNvNqn0BTEnNgQEcGjticYUkPzqSH2hUelXzlLUrfpbywNttA7Zc8UjEDG1j2/
YLOW6wuS4nG2LEZL07IN94yOeznr0aqpoBh/jQwzcZCd1Qa+T94GZy9ElddiHYJ2roJUqLONB/3a
gB1qv1ldCB8A+y0JBBXjy9Km1pxnkKOFeF/+H+EE0Ws3V6FWXqVXeFO5VdGZsnHIcfYPuUoJdvbm
IRevldHSJ7tqv/0R8a7P8O3ZCug9zdMDtUt5rqH7HN+N9+ABBy0MpWq8y/oI1WWSicJ36tM+eQPN
hhZ+1Lnes4ITCglwPxvRKW0gf2Gmfd0UH9phfNfSM3GszeP/fmzgXCNi+a5D87Qtg67Lm96AK+WH
//pCxai/h6Z2Z5e9J5mYjcfNseCzugEqrvWQu03Y8v3lXNdzNldo8n8VW+0Z8TwsXAwo44w3avUi
BHIrCpxjGOzfoY5h8TpYuDb7GGvUkuE+N6+0ie7CcYZS3IR61PL5rxpxiIRyJmwfa4M/RsXBxTZH
ugQsXz04tooaRVDyLdJtiJcx6Csb4oeITUqSB4u28HWniXoJZ3g2V2759e3JkmbRC7gjoqp7k8bG
cOIeb4AbWmoPvvAa0AQcWWdu6+rkcekSFGXjvvJuECXMKJD0UFcvHn0VgiBI5Jj5SUQoJ9yWjaJ6
TFqH1Jh+9/UQAtQpKTylZ6qo314jcXMNmPhjwdnSt1ux/eZ+eBNNkjwkbCbU9kHmcerkCNcFBSAd
8yI8lk7o0wiTgYJBMI/UcJtpHShMc5bKsVSw9x0bIgyZzPx6TAT6dQXQXbY9FgNJ+k/OugKOG9O/
kc2GifXsa59d2DEzo7pUDrrNEmZVdparHalegOM2pWshQyxWxXmUNuEu/bKeMD4XeYc4cTjrO22j
NyLi5ZFLUrs6itriaFzi9U4h5KOS10Vg1YW3JV32M826GhNaJ9nmUKmmRqYBAlhPcTCJFUaemYA7
mVKOUY8WS6mCjVMSDndxYF3OWQBKorW7Digv1wjFh3feCtD0qfKgJabfmQ9aP6Xs4+4wseZWH0md
6WHi868qNM2evb3L1vQpQOJ14nTGn4ktHgcxCgT1wME7AqAXz5h1iqFwLoKNiRGBLYYwL8qYbpSC
5Tp2NxzS5JRyw6d3Ezke0uK+SB+YbSwiHxK1MWjPRaTDKKV+DLk7ljkdmc8+odO6spkbL8ymtEGB
SZiSZKNLSWa5rzyKqUl/DbdPg+5ZT3TP3DSvFzYtAdsjC/yRDr5U6BcryqCAInBQBUmZLw16iUQx
GHbky/ZejY/1Jc/Yc55cCR+a3b1I1GOToXBqBNy1CdiUV91MTayDGXrbIsO94FmUBbyNw/5wlPdA
cm7cdjPUbesbGCYRFlgl5jpxbY9uIsUnEpEOsOWjqJfILSWzhp7K2Y1TTIbNITr6rfu1bO5x8Wwn
1fgbVteunSH1Ji5bJ+6WBI+0U09hoezdHpWIsW96zPGG/yWroCAqISrpNR4JAa9XqGvlBRVsj7Cs
j6EEOtn0WGYDltQzvt8nJRk6R6CWVU9SuAcGnMscsbM9AGE54QYfmR/HKNKhterwVc7fpWOMfBlq
aEhLfDkzpbnr5V4l7eE3hhnD7h96vCOQBPrvLm45Me6WrhxgSvZQ2QeeDco2J62apmHP/6O2FjjK
4JtAit13Q6vbCYeRZZQ9jKhmOB00LrdlA+0ButYocrcDzaDFRWYUzXYJNpX0YY3VSjJXnk4MbXO6
jVifmTxePFWANJW1Tj3fQUr9f/pxe0E71yz5ild2CDebQBfMUSpyewpk2Rvy55Ukf6PdLkq4B4me
kNJal6bcamPLSKOaPq3LDS5VRGCxaev02CxId+W03WTrZguj/jVSfwpmxfbHdaiqf69agHmVoyGn
2UvGYnTDjkHy5aNfEarPCnZ+VVIOGskMwfSgW5PZ9wwntp9ETKViwZEoaGMWdHzAqCyVYJOIc9vi
c/0oQwlId9+UQfpHyGmceAsMiKNQ5V91mgSr6THoJ+8ZTFknduOfvoGJgk/8dkGP3IKQuyEXFJTK
h5ZFdmCe3umo7FwvhOQQMJI9gewTwgQUc4iOR0PQdLBuMrd4v25rTNceY2jXYGfQlXeDqFP+3gjr
1MJQo8C0O9DtADFxGAwXpZRMZGIvToulOFz+LCKEh+8PdV6sTMITDNAQ3i0ruVuxD8VEfkm+xGBb
1e6nZYzIpNkZspCJUxbJRX+HVeL6x/QGwzMbikqvletBrduDTaseMSoEGAqONeSSaSyFmHu1+Sk/
2Td6+i8It+Je9L8ZHi9/URJdmHJUuZ0qeD30M0u=