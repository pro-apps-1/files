<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyBf3BeeP/MzDIkPcHFWv+3extwgfnRsCfgup7ZQgh2q2VtXdnxZxvL7yEIBJJTWhMREK/pq
LMeGdTfM3mfpGklms+rgbb5+yP29V9pFb6JIiqiEBi2rTfloDD8FUUrdnQPgbx86WN0UPwrvG6lh
MHWV60/luoqjIYYpejPVggN94ndHjCBvSIYnybwr6VG8zOBf6WmVdblCPGCEpLqNQ8QLl2s2/4SH
deQYgNG48U+WuB6tt6MgR2oVq3zpLIzWYHwKCEF1x2Mp38X0OBGOBrINoV9i22+u3urUt0NaD/51
hNmXj8y0NtfjBxUjHTr1aAeMBeOl9hgvT0zlEa8odJ521TKsvYzlWqdvf2HaATXvMUkneTc3KeJC
mxK+BzAC366/yFyk8S5oynmm6K7DuHLNk91BxThr8Kw4j42Q0F7/i6o77uuEj4h2Ed/lzCGsA0Zn
SQ+jBsXZswb41ogxV3EQSUAYMrhqBKRLBlvGYEzg9RYTSh83PpUFAwJEr1GjHH5RE1Vlp/dxtKQj
OXo4narJwNGglZJixu7ELKhSo8dmCjlLbVJxLTkjv6uitW8+ZShN4hFcjF+aO8FervZI/OtRJ8LO
dpiIRjW27SbzpQwiIu6a68HwQ17TLEn3KqBzMnA665LNg5J/BC4A8XJ6m6fV32pNZmoesAziXcvy
58LgSxauNE0sBLchJzoiRliDbo5lVstvWFOQM3J+Y3fUszz7wivBA59mUSNYk4G4HTDhM143Jelg
+xk2ZDYmR+wg7ssWrr4Mu4T2joR+ybUa8qJQbrn4gyBMUeA9k8hP9c/PxDVcHWrEXMW5seLrcGNm
KeWf9+3MemT800HxHQ4n0AMiRJJ6sDOf/xR9HwKwHSmQVXmm2Irsc1kC9ub7kDsNnOssJwK5ynnF
hHbSMne4ejDgVs+IGaYDqzYIssOgyet9jQUT7d1DOIsme9REs1A1dZWJzAksCZgqrTLeaYwNP8dR
5chB3r1XDF+FLIpUsWeXMwlLrPWRqkbJwMq5XUsUuuwxXZBrNDRqZ924sRur3P5V28EdyXWgACOO
O1ask4Z7Qytg8CVMqSexPIbZHYtNyS7HRJUKBkv3/0BuIDTLZl55C1kMJfNtMcSlAWrtBJQ3ityK
Gafo/GCdrVMTqqWFzsiYK+GQ3L5vddOj4e0pqqpg234P/Mx49XHvXY/V22l1BLD+j+IIm5Mnf730
k44lAoT+7LHPDHt00R/t/CGSAmHd6ilGGvUmJcgSPUFj3cnFj0u0K6yA4V0A5mNKT1NVw/Q0NKP0
vRgGJqVaUbjTPkefyBrvEakUdSxjeXmkmAqCPiy3RD0Zq38MfejPV60kZIR0ysIv+Up0LrLG36PP
WHGXxH5F0I7GMMG1VJiNqUyT/79iSvtKICBsW+JHuYm5KPizC5J6dwuWhi0bWc1eJlqklqDeE2kI
urHWuQ62vxfkcpGQw6F+8Izqga3GFQxuC+0WRDsiw/Rm9MxyC4dWEGXitwo/ES9FsnmovLjAJ7jM
IFnBQs1dnhNM6Nzg7xmqxBfwPcMKgOIC95+1Ei4L7++fhCmjqG==