<?php

function frontViewContents($viewFile)
{
    return PATH_APP . DS . "Views" . DS . "Front" . DS . $viewFile;
}

function frontLoadViewSection($path)
{
    $fullPath = PATH_APP . DS . "Views" . DS . $path;
    if (file_exists($fullPath)) {
        include $fullPath;
    }
}
