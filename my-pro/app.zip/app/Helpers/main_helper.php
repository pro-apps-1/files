<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */
$toEnqueueArr = array();

function container()
{
    global $app;
    return $app->getContainer();
}

function db($table = null)
{

    $db = container()->db;
    if (!empty($table)) {
        return $db->table($table);
    }
    return $db;
}

function validator()
{
    return container()->validator;
}


function session()
{
    return container()->session;
}


function baseUrl($uri = '', $protocol = NULL)
{
    $base_url = slashItem('url');
    if (isset($protocol)) {
        if ($protocol === '') {
            $base_url = substr($base_url, strpos($base_url, '//'));
        } else {
            $base_url = $protocol . substr($base_url, strpos($base_url, '://'));
        }
    }
    return $base_url . uriString($uri);
}

function assets($path = '')
{
    $path = trim($path, "/");
    return baseUrl("assets/$path");
}

function adminBaseUrl($seg = "", $adminPrefix = "")
{
    if (!$adminPrefix) {
        $adminPrefix = getAdminPrefixUrl();
    }
    return baseUrl("$adminPrefix/$seg");
}

function getAdminPrefixUrl()
{
    $container      = container();
    $adminPrefix    = "admin";

    if (!empty($container["admin_prefix_url"])) {
        $adminPrefix  = $container["admin_prefix_url"];
    }
    return $adminPrefix;
}

function getMainAppEnqueue()
{
    $manifestPath = PATH_ASSETS . DS . "mix-manifest.json";
    $manifestFile = file_get_contents($manifestPath);
    $manifestData = json_decode($manifestFile, true);


    return [
        "admin_js_url"      => assets($manifestData["/js/admin.js"]),
        "front_js_url"      => assets($manifestData["/js/front.js"]),
        "app_css_url"       => assets($manifestData["/css/app.css"]),
        "preset_css_url"    => assets($manifestData["/css/preset.css"]),

    ];
}

function enqueueStyle($fileAddr, $inFooter = false)
{
    if (!empty($fileAddr)) {
        global $toEnqueueArr;
        if ($inFooter) {
            $toEnqueueArr['styles']['footer'][] = trim($fileAddr);
        } else {
            $toEnqueueArr['styles']['header'][] = trim($fileAddr);
        }
    }
}



function enqueueStyleHeader($fileAddr)
{
    enqueueStyle($fileAddr, false);
}

function enqueueStyleFooter($fileAddr)
{
    enqueueStyle($fileAddr, true);
}

function enqueueScript($fileAddr, $inFooter = false)
{
    if (!empty($fileAddr)) {
        global $toEnqueueArr;
        if ($inFooter) {
            $toEnqueueArr['scripts']['footer'][] = trim($fileAddr);
        } else {
            $toEnqueueArr['scripts']['header'][] = trim($fileAddr);
        }
    }
}

function enqueueScriptHeader($fileAddr)
{
    enqueueScript($fileAddr, false);
}

function enqueueScriptFooter($fileAddr)
{
    enqueueScript($fileAddr, true);
}

function printStyleTag($fileAddr)
{
    if (!empty($fileAddr)) {
        echo '<link rel="stylesheet" href="' . trim($fileAddr) . '" type="text/css" />' . "\n";
    }
}

function printScriptTag($fileAddr)
{
    if (!empty($fileAddr)) {
        echo '<script type="text/javascript" src="' . trim($fileAddr) . '"></script>' . "\n";
    }
}

function headerFiles()
{
    global $toEnqueueArr;
    if (!empty($toEnqueueArr['styles']['header'])) {
        foreach ($toEnqueueArr['styles']['header'] as $styleFile) {
            printStyleTag($styleFile);
        }
    }
    if (!empty($toEnqueueArr['scripts']['header'])) {
        foreach ($toEnqueueArr['scripts']['header'] as $scriptFile) {
            printScriptTag($scriptFile);
        }
    }
}

function footerFiles()
{
    global $toEnqueueArr;
    if (!empty($toEnqueueArr['styles']['footer'])) {
        foreach ($toEnqueueArr['styles']['footer'] as $styleFile) {
            printStyleTag($styleFile);
        }
    }
    if (!empty($toEnqueueArr['scripts']['footer'])) {
        foreach ($toEnqueueArr['scripts']['footer'] as $scriptFile) {
            printScriptTag($scriptFile);
        }
    }
}

function slashItem($item)
{
    $configValue = getConfig($item);
    if (!$configValue) {
        return NULL;
    } elseif (trim($configValue) === '') {
        return '';
    }

    return rtrim($configValue, '/') . '/';
}

function uriString($uri)
{

    if (is_array($uri)) {
        return http_build_query($uri);
    }

    is_array($uri) && $uri = implode('/', $uri);
    return ltrim($uri, '/');
}


function getArrayValue($array, $key, $defaultVal = "")
{

    if (is_object($array)) {
        $array = (array)$array;
    }
    if (!empty($array) && is_array($array)) {
        if (isset($array[$key])) {
            return $array[$key];
        }
    }
    return $defaultVal;
}

function trimArrayValues($array)
{
    foreach ($array as $key => $value) {
        if (!is_array($value) && !is_object($value)) {
            $$value = trim($value);
        }
        $array[$key] = $value;
    }
    return $array;
}

function trafficToGB($traffic)
{
    return round($traffic / 1024, 3);
}

function userIPAddress()
{
    $ip = "";
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function getServerIp()
{
    return !empty($_SERVER["SERVER_ADDR"]) ? $_SERVER["SERVER_ADDR"] : "";
}

function convertToPrettyUnit($value, $unit = "")
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    $base = 1024;
    $index = 0;

    // Find the appropriate unit to use
    while ($value >= $base && $index < count($units) - 1) {
        $value /= $base;
        $index++;
    }

    // Construct the pretty unit format
    if (empty($unit)) {
        $prettyUnit = $units[$index];
    } else {
        $prettyUnit = $unit . ' ' . $units[$index];
    }

    // Return the formatted value with the appropriate unit
    return number_format($value, 2) . ' ' . $prettyUnit;
}

function getUsageBgColor($usagePercent)
{
    // Convert the percentage to a numeric value without the percentage sign
    $usageValue = floatval(str_replace('%', '', $usagePercent));

    // Define color ranges and their corresponding usage percentage
    $colorRanges = array(
        10 => '#00FF00',   // Green - Less than 10% usage
        30 => '#FFFF00',   // Yellow - Less than 30% usage
        70 => '#FFA500',   // Orange - Less than 70% usage
        100 => '#FF0000',  // Red - 100% usage or more
    );

    // Find the appropriate color for the usage percentage
    foreach ($colorRanges as $range => $color) {
        if ($usageValue <= $range) {
            return $color;
        }
    }

    // Return the last color if the usage percentage is higher than the highest range
    return end($colorRanges);
}

function getBgTextColor($hexcolor)
{
    list($red, $green, $blue) = sscanf($hexcolor, "#%02x%02x%02x");
    $luma = ($red + $green + $blue) / 3;

    if ($luma < 128) {
        $textcolour = "white";
    } else {
        $textcolour = "black";
    }
    return $textcolour;
}

function truncateStr($string, $maxLength = 20)
{
    if (strlen($string) <= $maxLength) {
        return $string;
    } else {
        return substr($string, 0, $maxLength) . '...';
    }
}

function getSessionUser()
{
    if (session()->get("userInfo")) {
        return  (array) session()->get('userInfo');
    }

    return false;
}


function inlineIcon($iconName, $customClass = "")
{
    $html = "<i class='far fa-$iconName icon $customClass'></i>";
    return  $html;
}

function getAdminRole()
{
    return  container()->userInfo->role;
}

function getAdminUsername()
{
    return  container()->userInfo->username;
}

function getCurrentDate()
{
    return  jdate()->format("d F Y");
}

function genSshQrcode($username, $password, $domain, $sshPort)
{
    $str = "ssh://$username:$password@$domain:$sshPort";
    $str = base64_encode($str);
    $url = baseUrl("qrcode?text=$str&time=" . time());
    return $url;
}

function genV2VmessQrcode($username, $uuid, $domain, $port)
{
    $arrConfigs = [
        "v"     => "2",
        "ps"    => "$username-rocket-ssh",
        "add"   => $domain,
        "port"  => $port,
        "id"    => $uuid,
        "net"   => "tcp",
        "type"  => "none",
        "tls"   => "none",
    ];
    $str = "vmess://" . base64_encode(json_encode($arrConfigs));
    $str =   base64_encode($str);
    $url = baseUrl("qrcode?text=$str&time=" . time());
    return $url;
}

function genV2rayQrcode($type, $userInfo, $domain, $v2Settings, $onlyStr = false)
{
    $vlessTcpPort   = getArrayValue($v2Settings, "vless_tcp_port", "");
    $vmessTcpPort   = getArrayValue($v2Settings, "vmess_tcp_port", "");
    $configsSuffix  = getArrayValue($v2Settings, "configs_suffix", "");

    $username       = $userInfo->username;
    $uuid           = $userInfo->uuid;
    $username       .= "-$type";
    $configsSuffix  = !empty($configsSuffix) ? "-$configsSuffix" : "-rocket-ssh";
    $host           = "divarcdn.com";
    $username       = $username . $configsSuffix;

    $vmessConfigs   = [
        "v"     => "2",
        "ps"    => $username,
        "add"   => $domain,
        "port"  => $vmessTcpPort,
        "id"    => $uuid,
        "net"   => "tcp",
        "type"  => "http",
        "tls"   => "none",
        "host"  => $host,
    ];
    $strVmess   = "vmess://" . base64_encode(json_encode($vmessConfigs));
    $strVless   = "vless://$uuid@$domain:$vlessTcpPort?host=$host&headerType=http&type=tcp&security=none#";
    $str        = "";

    if ($type == "vmess") {
        $str  = $strVmess;
    } else if ($type == "vless") {
        $str  = $strVless . $username;
    } elseif ($type == "subs_link") {
        $str  = baseUrl("v2ray-sub/$uuid");
    } else {
        $username       = $userInfo->username;
        $remDays        = $userInfo->remaining_days;
        $remTraffic     = $userInfo->remaining_traffic;
        $vmessConfigs["ps"] = $username . "-vmess" . $configsSuffix;
        $vmess          = "vmess://" . base64_encode(json_encode($vmessConfigs));
        $vless          = $strVless . $username . "-vless" . $configsSuffix;;
        $vlessTraffic   = $strVless . "زمان باقی مانده: $remDays";
        $vlessDays      = $strVless . "ترافیک باقی مانده: $remTraffic";
        $strConfig      = "$vlessTraffic\n$vlessDays";
        return $strConfig;
    }
    if ($onlyStr) {
        return $str;
    }

    $str      = base64_encode($str);
    $url      = baseUrl("qrcode?text=$str&time=" . time());
    return $url;
}

function genV2VlessQrcode($username, $uuid, $domain, $port)
{
    $username .= "-rocket-ssh";
    $str   = "vless://$uuid@$domain:$port?type=tcp&security=none#$username";
    $str    = base64_encode($str);
    $url    = baseUrl("qrcode?text=$str&time=" . time());
    return $url;
}

function convertToEnNum($string)
{
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

    $num = range(0, 9);
    $convertedPersianNums = str_replace($persian, $num, $string);
    $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);

    return $englishNumbersOnly;
}


function formatTraffice($traffic, $lang = "en")
{
    $mb =  $lang == "en" ? "MB" : "مگابایت";
    $gb =  $lang == "en" ? "GB" : "گیگابایت";
    if ($traffic < 1024) {
        return number_format(round($traffic, 2)) . " $mb";
    }

    return number_format(round($traffic / 1024, 2)) . " $gb";
}

function calcDifferenceDate($startDate, $endDate)
{
    $startDate  = new DateTime(date("Y-m-d", $startDate));
    $endDate    = new DateTime(date("Y-m-d", $endDate));

    $interval   = $startDate->diff($endDate);
    $diffDyas   = $interval->days;

    $result     = "";

    if ($diffDyas >= 365) {
        $year       = floor($diffDyas / 365);
        $diffDyas   = floor($diffDyas % 365);
        $result .= $year . ($diffDyas > 0 ? " سال و " : " ساله ");
    }

    if ($diffDyas >= 29) {
        $month = 30;
        if ($diffDyas == 29) {
            $month = 29;
        } else if ($diffDyas == 30) {
            $month = 30;
        } else if ($diffDyas == 31) {
            $month = 31;
        }
        $_month     = floor($diffDyas / $month);
        $diffDyas   = ($diffDyas % $month);
        $result     .= $_month . ($diffDyas ? " ماه و " : " ماهه ");
    }

    if ($diffDyas && $diffDyas < 29) {
        $result .= $diffDyas . (!empty($result) ? " روزه" : " روزه");
    }
    return  $result;
}

function getLicenseData()
{
    $container = container();
    if (!empty($container["licenseData"])) {
        $licenseData    = $container["licenseData"];
        return $licenseData;
    }
    return false;
}

function hasActionInPlan($action = "")
{
    $container = container();
    if (!empty($container["licenseData"])) {
        $licenseData    = $container["licenseData"];
        $currentPlan    = $licenseData["plan_name"];

        if ($action == "new-server") {
            $serverModel        = new \app\Models\Servers();
            $totalServer        = $serverModel->getTotalServers();
            $totalPlanServer    = getPlanNumAction($currentPlan, "servers");
            if ($totalPlanServer) {
                if ($totalServer < $totalPlanServer) {
                    return true;
                }
            } else {
                return true;
            }
        } else if ($action == "new-subscriber") {
            $subsModel          = new \app\Models\Subscribers();
            $totalsubs          = $subsModel->getTotalActiveSubs();
            $totalPlansubs      = getPlanNumAction($currentPlan, "subscribers");
            if ($totalPlansubs) {
                if ($totalsubs < $totalPlansubs) {
                    return true;
                }
            } else {
                return true;
            }
        } else if ($action == "new-admin") {
            $adminModel         = new \app\Models\Admins();
            $totaladmins        = $adminModel->getTotalAdmins();
            $totalPlanAdmins    = getPlanNumAction($currentPlan, "admins");
            if ($totalPlanAdmins) {
                if ($totaladmins < $totalPlanAdmins) {
                    return true;
                }
            } else {
                return true;
            }
        } else if ($action == "new-reseller") {
            $resModel           = new \app\Models\Resellers();
            $totalRess          = $resModel->getTotalResellers();
            $totalPlanRess      = getPlanNumAction($currentPlan, "resellers");
            if ($totalPlanRess) {
                if ($totalRess < $totalPlanRess) {
                    return true;
                }
            } else {
                return true;
            }
        }
    }

    return false;
}

function getTotalRowsInPlan($action)
{
    $container = container();

    if (!empty($container["licenseData"])) {
        $licenseData    = $container["licenseData"];
        $currentPlan    = $licenseData["plan_name"];
        return getPlanNumAction($currentPlan, $action);
    }

    return false;
}

function getPlanNumAction($planName, $action)
{
    $result = 0;
    if ($planName == "bronze" || $planName == "free") {
        if ($action == "servers") {
            $result = 4;
        }
        if ($action == "subscribers") {
            $result = 150;
        }
        if ($action == "admins") {
            $result = 3;
        }
        if ($action == "resellers") {
            $result = 3;
        }
    } else if ($planName == "silver") {
        if ($action == "servers") {
            $result = 8;
        }
        if ($action == "subscribers") {
            $result = 320;
        }
        if ($action == "admins") {
            $result = 7;
        }
        if ($action == "resellers") {
            $result = 7;
        }
    } else if ($planName == "gold") {
        if ($action == "servers") {
            $result = 12;
        }
        if ($action == "subscribers") {
            $result = 550;
        }
        if ($action == "admins") {
            $result = 10;
        }
        if ($action == "resellers") {
            $result = 10;
        }
    } else if ($planName == "brillant") {
        $result = 0;
    }
    return $result;
}

function includeWithVariables($filePath, $variables = array(), $print = true)
{
    // Extract the variables to a local namespace
    extract($variables);

    // Start output buffering
    ob_start();

    // Include the template file
    include $filePath;

    // End buffering and return its contents
    $output = ob_get_clean();
    if (!$print) {
        return $output;
    }
    echo $output;
}

function translateDiffTime($time)
{
    $now        = time();
    $second     = $time - $now;
    $prefixText = "دیگر";
    if ($second < 0) {
        $prefixText = "گذشته";
        $second = abs($second);
    }

    $result = "";
    if ($second == 0) {
        $result = 'همین الان';
    } elseif ($second > 0 && $second < 500) {
        $result = "لحظاتی  $prefixText";
    } elseif ($second > 500 && $second < 900) {
        $result = "دقایقی $prefixText";
    } elseif ($second >= 900 && $second < 1800) {
        $result = "یک ربع $prefixText";
    } elseif ($second >= 1800 && $second < 3600) {
        $result = "نیم ساعت $prefixText";
    } elseif ($second >= 3600 && $second < 86400) {
        $hours = floor($second / 3600);
        $result = "$hours ساعت $prefixText";
    } elseif ($second >= 86400 && $second < 2592000) {
        $day = floor($second / 86400);
        $result = "$day روز $prefixText";
    } elseif ($second >= 2592000 && $second < 31536000) {
        $mounth = floor($second / 2592000);
        $result = "$mounth ماه $prefixText";
    } elseif ($second >= 31536000) {
        $year = floor($second / 31536000);
        $result = "$year سال $prefixText";
    }

    return $result;
}

function getEndOfDate($date)
{
    if (!is_numeric($date)) {
        $date = strtotime($date);
    }
    $date = strtotime("today", $date);
    return strtotime("tomorrow", $date) - 1;
}

function  getStartOfDate($date)
{
    if (!is_numeric($date)) {
        $date = strtotime($date);
    }
    return  strtotime("today", $date);
}


function userStatusLabel($status)
{
    $arrayStats = [
        "active"            => "فعال",
        "inactive"         => "غیر فعال",
    ];

    if (!empty($arrayStats[$status])) {
        return $arrayStats[$status];
    }

    return $status;
}


function githubLastVersion()
{
    $url = "https://raw.githubusercontent.com/pro-apps-1/files/main/pro-files/version.txt";
    if ($url) {
        $context = stream_context_create(
            array(
                "http" => array(
                    "header" => "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36"
                )
            )
        );
        $urlContent = @file_get_contents($url, false, $context);
        return  $urlContent;
    }
    return 1.0;
}


function getServerName()
{
    return  !empty($_SERVER["SERVER_NAME"]) ? $_SERVER["SERVER_NAME"] : getServerIp();
}


function getLocalOnlienUsers()
{
    $onlinePath = PATH_STORAGE . DS . "online.json";

    if (file_exists($onlinePath)) {
        $content =  file_get_contents($onlinePath);
        if (!empty($content)) {
            try {
                return json_decode($content, true);
            } catch (\Exception $err) {
            }
        }
    }

    return [];
}


function adjustDateTime($dateTimeString)
{
    // Create a DateTime object from the given date and time string
    $dateTime = new DateTime($dateTimeString);

    // Get the year from the DateTime object
    $year = (int)$dateTime->format("Y");

    if ($year > 2025) {
        // Change the year to 2025
        $dateTime->setDate(2025, $dateTime->format("m"), $dateTime->format("d"));
        return $dateTime->format("Y-m-d");
    } else {
        return $dateTime->format("Y-m-d");
    }
}

function generateRandomPassword($length, $type)
{
    $characters = '';

    if ($type == 'number') {
        $characters = '0123456789';
    } elseif ($type == 'letter') {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    } elseif ($type == 'number_letter') {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    }

    $password = '';
    $charactersLength = strlen($characters);

    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, $charactersLength - 1)];
    }

    return $password;
}

function isDevMode()
{
    $serverName = $_SERVER['SERVER_NAME'];

    if ($serverName === 'localhost' || $serverName === '127.0.0.1') {
        return true;
    }
    return false;
}

function makeCurlRequest($url, $method = 'GET', $headers = [], $data = [], $sleeptime = 0)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    if ($method === 'POST' || $method === 'PUT') {
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    }

    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    if ($sleeptime) {
        sleep($sleeptime);
    }

    $response = curl_exec($ch);
    if ($response === false) {
        return false;
    }

    curl_close($ch); // Close cURL session

    return $response;
}

function getFilteringData()
{
    $requestId = getCheckHostReqId();
    if (!empty($requestId)) {
        $result = getCheckHostTcp($requestId);
        if (!empty($result)) {
            return  $result;
        }
    }
    return  false;
}

function getCheckHostReqId()
{
    $serverip   = getServerName();
    $port       = getenv("PORT_SSH");
    $host       = "$serverip:$port";
    $host       = preg_replace('/\s+/', '', $host);
    $url        = "https://check-host.net/check-tcp?host=$host&max_nodes=50";
    $headers    = [
        "Accept: application/json",
        "Cache-Control: no-cache"
    ];

    $response = makeCurlRequest($url, "POST", $headers, [], 4);
    if (!empty($response)) {
        $response = json_decode($response, true);
        if (!empty($response["request_id"])) {
            $reqId = $response["request_id"];
            return $reqId;
        }
    }
    return false;
}

function convertFlagName($name)
{
    $countries = [
        "ir" => "ایران",
        "us" => "آمریکا",
        "fr" => "فرانسه",
        "de" => "آلمان"
    ];
    return !empty($countries[$name]) ? $countries[$name] : "";
}

function getCheckHostTcp($reqId)
{

    $url        = "https://check-host.net/check-result/$reqId";

    $headers    = [
        "Accept: application/json",
        "Cache-Control: no-cache"
    ];

    $response = makeCurlRequest($url, "POST", $headers, [], 4);
    if (!empty($response)) {
        $response = json_decode($response, true);
        if (!empty($response)) {
            $result = [];

            $countries = ["ir", "us", "fr", "de"];
            foreach ($response as $key => $value) {

                $flag = str_replace(".node.check-host.net", "", $key);
                $flag = preg_replace("/[0-9]+/", "", $flag);

                if (in_array($flag, $countries)) {
                    if (isset($value[0]["time"])) {
                        $status = "online";
                    } else {
                        $status = "filter";
                    }

                    $result[] = [
                        "flag"      => $flag,
                        "flag_img"  => assets("images/flags/$flag.png"),
                        "status"    => $status,
                        "name"      => convertFlagName($flag)
                    ];
                }
            }
            return  $result;
        }
    }
    return false;
}

function generateUserToken($user_id, $length = 6)
{
    $timestamp = time(); // Current timestamp

    // Combine user ID and timestamp
    $dataToHash = $user_id . $timestamp . random_bytes($length);

    $hashedData = hash('sha256', $dataToHash); // Hash the combined data

    return substr($hashedData, 0, $length); // Return a substring of the hash 
}

function removeCommaStr($input)
{
    // Remove commas
    $output = preg_replace('/,/', '', $input);

    return $output;
}


function getCountries()
{
    $countriesFile = PATH_ASSETS . DS . "countries.json";
    $countries = file_get_contents($countriesFile);
    if (!empty($countries)) {
        $_countries = json_decode($countries, true);
        $countries  = [];
        foreach ($_countries as $code => $name) {
            $code = strtolower($code);
            $countries[$code] = $name;
        }
        asort($countries);
        return  $countries;
    }
    return [];
}

function getCountryName($code, $countries = [])
{
    $countries = !empty($countries) ?  $countries : getCountries();

    if (!empty($code) && !empty($countries[$code])) {
        return $countries[$code];
    }
    return $code;
}

function translateUserRole($role)
{
    $roles = [
        "admin"      => "مدیر",
        "reseller"   => "نماینده",
        "subscriber" => "مشترک",
    ];

    if (isset($roles[$role])) {
        return $roles[$role];
    }

    return $role;
}

function transUserStatusDesc($status)
{
    $items = [
        "time_expiration"     => "انقضای زمان",
        "traffic_expiration"  => "انقضای ترافیک",
    ];

    if (isset($items[$status])) {
        return $items[$status];
    }

    return $status;
}

function countryFlagUrl($flag)
{
    return assets("images/flags/$flag.png");
}


function genUnicodeProgressBar($progress, $maxChars = 20)
{
    $completed = round($progress * $maxChars / 100);
    $remaining = $maxChars - $completed;

    $progressBar = '<span style="color: #138923;">' . str_repeat("▓", $completed) . '</span>';
    $progressBar .= '<span style="color:#dbffdf;">' . str_repeat("░", $remaining) . '</span>';

    return $progressBar;
}

function siteLogo()
{
    $model      = new \App\Models\Settings();
    $logoUrl    = $model->getSetting("logo_url");
    $logoPath   = PATH_ASSETS . DS . $logoUrl;

    if ($logoUrl && file_exists($logoPath)) {
        $logoUrl = "assets/$logoUrl";
    } else {
        $logoUrl = "assets/images/logo.png";
    }
    $logoUrl = baseUrl($logoUrl);
    return $logoUrl;
}

function isValidSubdomain($subdomain, $domain)
{

    $escapedDomain = preg_quote($domain, '/');
    $pattern = '/^[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]\.' . $escapedDomain . '$/';
    return preg_match($pattern, $subdomain);
}

function isJson($string)
{
    json_decode($string);
    return (json_last_error() == JSON_ERROR_NONE);
}

function createUuidV4Secure()
{
    $data       = random_bytes(16);
    $data[6]    = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8]    = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function parseUrl($url)
{
    $urlArr = parse_url($url);
    parse_str($urlArr["query"], $params);
    return $params;
}
