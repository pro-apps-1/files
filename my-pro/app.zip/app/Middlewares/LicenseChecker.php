<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Middlewares;

class LicenseChecker
{

    private $cont;
    private $excludeListStatic = array();
    private $excludeListPattern = array();

    function __construct($cont)
    {
        $this->cont = $cont;
        $adminPrefixUrl = $cont["admin_prefix_url"];
        $this->excludeListPattern = [
            "$adminPrefixUrl/login",
            "$adminPrefixUrl/logout",
            "$adminPrefixUrl/ajax/login",
            "$adminPrefixUrl/settings/license",
            "$adminPrefixUrl/ajax/settings/license",
        ];
    }

    private function excludeCheck($uri)
    {

        if (in_array($uri, $this->excludeListStatic)) {
            return true;
        }

        foreach ($this->excludeListPattern as $pattern) {
            if (preg_match("|^" . $pattern . "|is", $uri)) {
                return true;
            }
        }
        return false;
    }

    public function __invoke($request, $response, $next)
    {
        $uri = $request->getUri()->getPath();
        $uri = ltrim($uri, '/');

        $pass = false;
        if ($this->excludeCheck($uri)) {
            $pass = true;
        } else {
            $userId = session()->get("admin_login");
            if ($userId) {
                $setModel   = new \App\Models\Settings();
                $result     = $setModel->getLicenseData();
         
                $isActive   = $result["is_active"];
                $isExpired  = $result["is_expired"];
                $request    = $request->withAttribute('licenseData', $result);
                
                $this->cont["licenseData"] = $result;

                if ($isActive && !$isExpired) {
                    $pass = true;
                } else {
                    $pass = false;
                }
            }
        }
        if ($pass) {
            $response = $next($request, $response);
            return $response;
        }
        return $response->withStatus(302)->withHeader("location", adminBaseUrl("settings/license"));
    }
}
