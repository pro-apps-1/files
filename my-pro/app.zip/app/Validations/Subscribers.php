<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

use Morilog\Jalali\Jalalian;

class Subscribers
{

    public static function login($pdata)
    {
        $result = array("status" => "success", "messages" => []);

        $validatorRules = [
            'username'        => ['required'],
            'password'        => ['required'],
        ];

        $validatorMsg = [
            'username.required' => 'نام کاربری را وارد کنید',
            'password.required' => 'رمز عبور را وارد کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function save($pdata, $editId = null, $creatorInfo)
    {
        $result     = array("status" => "success", "messages" => []);
        $sModel     = new \App\Models\Subscribers();
        $pModel     = new \App\Models\Packages();
        $upModel    = new \App\Models\UsersPackages();
        $servModel  = new \App\Models\Servers();

        $userInfo    = null;
        $validatePkg = false;

        if (!$servModel->checkHasActiveServers()) {
            $result["status"] = "error";
            $result["messages"][] = "متاسفانه هیچ سرور فعالی یافت نشد، ابتدا نسبت به افزودن سرور اقدام کنید";
            return $result;
        }

        if ($editId) {
            $userInfo =  $sModel->getEditInfo($editId);
            if (!$userInfo) {
                $result["status"] = "error";
                $result["messages"][] = "اطلاعات کاربر یافت نشد";
                return $result;
            }
        } else {
            $hasCreate = hasActionInPlan("new-subscriber");
            if (!$hasCreate) {
                $result["status"] = "error";
                $result["messages"][] = "شما مجاز به افزودن مشترک جدید نمی باشید";
                return $result;
            }
        }

        $validatorRules = [
            'subs_settings_by'   => ['required', 'in:manual,package'],
            'password'          => ['required'],
            'mobile'            => ['nullable'],
            'desc'              => ['nullable'],
            'category'          => [function ($attribute, $value,  $fail) {
                if ($value) {
                    $cModel = new \App\Models\Categories();
                    $res = $cModel->checkExist($value);
                    if (!$res) {
                        $fail("اطلاعات دسته بندی یافت نشد");
                    }
                }
            }],
        ];

        $validatorMsg = [
            'username.required'             => 'نام کاربری را وارد کنید',
            'password.required'             => 'رمز عبور را وارد کنید',
            'package_id.required'           => 'پکیج را انتخاب کنید',
        ];

        if (!empty($pdata["subs_settings_by"])) {
            $subsSettingBy = $pdata["subs_settings_by"];
            if ($subsSettingBy == "manual") {

                $cRole          = $creatorInfo->role;
                $isUnlimited    = $creatorInfo->unlimited;
                $maxLimit       = 100;
                if ($cRole == "reseller") {
                    if ($isUnlimited) {
                        $maxLimit  = 10;
                    }
                }

                $validatorMsg["limit_users.max"]    = "لطفا تعداد کاربران را به صورت صحیح وارد کنید";

                $validatePkg = false;
                $validatorRules["limit_users"]      = ['required', 'numeric', 'min:1', "max:$maxLimit"];
                $validatorRules["traffic"]          = ['required', 'numeric', 'min:0'];
                $validatorRules["validity_days"]    = ['required', 'numeric', 'min:0'];


                if (empty($userInfo) || (!empty($userInfo) && !$userInfo->start_time)) {
                    $validatorRules["start_time_type"]  = ['required', 'in:first-conn,create-user'];
                }
            } else {

                $validatePkg = true;
            }
        }

        if (!$editId) {
            $validatorRules['username'] = [
                'required',
                function ($attribute, $value,  $fail) use ($sModel, $editId) {
                    if ($value) {
                        if ($sModel->isExistUsername($value, $editId)) {
                            $fail("لطفا از نام کاربری دیگری استفاده کنید");
                        }
                    }
                },
            ];
        } else {
            $cRole     = $creatorInfo->role;
            if ($cRole != "admin") {
                if (!empty($pdata["subs_settings_by"])) {
                    $subsSettingBy = $pdata["subs_settings_by"];
                    if ($subsSettingBy == "package") {
                        $validatePkg = !$editId ? true : false;
                    }
                }
            }
        }


        if ($validatePkg) {
            $validatorRules['package_id'] = [
                'required',
                function ($attribute, $value,  $fail) use ($pModel, $upModel, $creatorInfo) {
                    if ($value) {
                        $cRole          = $creatorInfo->role;
                        $cCredit        = $creatorInfo->credit;
                        $cUid           = $creatorInfo->id;
                        $cStatus        = $creatorInfo->status;
                        $unlimited      = $creatorInfo->unlimited;
                        $packageInfo    = $pModel->getInfo($value);

                        if (!$packageInfo) {
                            $fail("پکیج انتخابی در دسترس نمی باشد");
                        } else {
                            $packagePrice  = $packageInfo->price;

                            if ($cRole != "admin") {
                                if (!$upModel->checkUserAccess($cUid, $value)) {
                                    $fail("پکیج انتخابی در دسترس نمی باشد");
                                } else {
                                    if ($cStatus == "active") {
                                        if (!$unlimited) {
                                            if ($cCredit < $packagePrice) {
                                                $fail("موجودی شما جهت استفاده از این پکیج کافی نیست");
                                            }
                                        }
                                    } else {
                                        $fail("حساب کاربری شما غیر فعال است");
                                    }
                                }
                            }
                        }
                    }
                },
            ];
        }




        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function renewal($pdata, $editId, $userRole)
    {
        $result     = array("status" => "success", "messages" => []);
        $uModel     = new \App\Models\Subscribers();

        $userInfo =  $uModel->getEditInfo($editId);

        if (!$userInfo) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات کاربر یافت نشد";
            return $result;
        }

        $crole = $userInfo->crole;

        $validatorRules = [
            'renewal_date'      => ['required', 'in:yes,no'],
            'renewal_traffic'   => ['required', 'in:yes,no'],
        ];

        if (!empty($pdata["package_id"])) {

            $pModel     = new \App\Models\Packages();
            $creatorInfo = $uModel->getInfo($userInfo->cid);

            $validatorRules['package_id'] = [
                'required',
                function ($attribute, $value,  $fail) use ($pModel, $creatorInfo, $userRole) {
                    if ($value) {
                        $cRole          = $creatorInfo->role;
                        $cCredit        = $creatorInfo->credit;
                        $unlimited      = $creatorInfo->unlimited;
                        $packageInfo    = $pModel->getInfo($value);
                        $packagePrice  = $packageInfo->price;
                        if ($cRole != "admin") {
                            if (!$unlimited) {
                                if ($cCredit < $packagePrice) {
                                    if ($userRole == "admin") {
                                        $fail("موجودی نماینده جهت تمدید از این پکیج کافی نیست");
                                    } else {
                                        $fail("موجودی شما جهت تمدید از این پکیج کافی نیست");
                                    }
                                }
                            }
                        }
                    }
                },
            ];
        } else {
            $validatorRules["renewal_days"] = ['required', 'numeric', 'min:1'];
        }

        $validatorMsg = [
            'renewal_days.required'         => 'روزهای تمدید را وارد کنید',
            'renewal_days.required'         => 'روزهای تمدید را به صورت صحیح وارد کنید',
            'renewal_days.email'            => 'روزهای تمدید را به صورت صحیح وارد کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function toggleActive($userId)
    {
        $result = array("status" => "success", "messages" => []);

        $sModel     = new \App\Models\Subscribers();
        $userInfo   = $sModel->getEditInfo($userId);

        if (!$userInfo) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات کاربر یافت نشد";
        } else {
            $status = $userInfo->status_desc;
            if ($status == "time_expiration" || $status == "traffic_expiration") {
                $result["status"] = "error";
                $result["messages"][] = "امکان فعال کردن کاربر منقضی وجود ندارد";
            }
        }
        return $result;
    }

    public static function hasExist($userId)
    {
        $result = array("status" => "success", "messages" => []);

        $uModel = new \App\Models\Users();
        $hasExist = $uModel->checkExist($userId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات کاربر یافت نشد";
        }
        return $result;
    }

    public static function delete($manId, $uid)
    {
        $result = array("status" => "success", "messages" => []);

        $uModel = new \App\Models\Users();
        $hasExist = $uModel->checkExist($manId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات کاربر یافت نشد";
        } else {
            if ($manId  == $uid) {
                $result["status"] = "error";
                $result["messages"][] = "کاربر انتخابی قابل حذف نیست";
            }
        }

        return $result;
    }

    public static function deleteBulk($pdata)
    {
        $result     = array("status" => "success", "messages" => []);
        $sModel     = new \App\Models\Subscribers();

        $validatorRules = [
            'ids'          => ['required', 'array'],
            'ids.*'        => [function ($attribute, $value,  $fail) use ($sModel) {
                if ($value) {
                    if (!$sModel->checkExist($value)) {
                        $fail("کاربر با شناسه $value یافت نشد");
                    }
                }
            }]
        ];

        $validatorMsg = [
            'ids.required'    => 'شناسه کاربران را ارسال کنید',
            'ids.array'       => 'شناسه کاربران را به صورت آرایه ارسال کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $result["messages"]    = array_reverse($messages);
            $result["status"]      = "error";
        }

        return $result;
    }
}
