<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

class Categories
{

    public static function saveCategory($pdata, $editId = null)
    {
        $result     = array("status" => "success", "messages" => []);

        if ($editId) {
            $result = self::hasExist($editId);
            if ($result["status"] == "eroor") {
                return $result;
            }
        }

        $validatorRules = [
            'name'    => ['required'],
        ];

        $validatorMsg = [
            'username.required' => 'نام دسته بندی را را وارد کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function hasExist($id)
    {
        $result = array("status" => "success", "messages" => []);

        $cModel = new \App\Models\Categories();
        $hasExist = $cModel->checkExist($id);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات دسته بندی یافت نشد";
        }
        return $result;
    }

    public static function delete($manId, $uid)
    {
        $result     = array("status" => "success", "messages" => []);

        $cModel     = new \App\Models\Categories();
        $hasExist   = $cModel->checkExist($manId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات دسته بندی یافت نشد";
        }

        return $result;
    }
}
