<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

class Resellers
{

    public static function save($pdata, $editId = null, $uid = null)
    {
        $result     = array("status" => "success", "messages" => []);
        $rModel     = new \App\Models\Resellers();

        $userInfo  = null;
        if ($editId) {
            $userInfo =  $rModel->getInfo($editId);
            if (!$userInfo) {
                $result["status"] = "error";
                $result["messages"][] = "اطلاعات کاربر یافت نشد";
                return $result;
            }
        } else {
            $hasCreate = hasActionInPlan("new-reseller");
            if (!$hasCreate) {
                $result["status"] = "error";
                $result["messages"][] = "شما مجاز به افزودن نماینده جدید نمی باشید";
                return $result;
            }
        }

        $validatorRules = [
            'full_name'         => ['required'],
            'status'            => [
                'required', 'in:active,inactive',
                function ($attribute, $value,  $fail) use ($userInfo) {
                    if ($userInfo) {
                        if ($userInfo->id == 1 || $userInfo->username == "admin") {
                            if ($value == "inactive") {
                                $fail("این کاربر قابلیت غیر فعال شدن ندارد");
                            }
                        }
                    }
                }
            ],
            'username' => [
                'required',
                function ($attribute, $value,  $fail) use ($rModel, $editId) {
                    if ($value) {
                        if ($rModel->isExistUsername($value, $editId)) {
                            $fail("نام کاربری از قبل وجود دارد");
                        }
                    }
                }
            ],
        ];

        $passValidations =  ['regex:|[0-9]|', 'regex:|[a-zA-Z]|', 'min:8'];

        if (!$editId) {
            $validatorRules['password'] = $passValidations;
        } else {
            if (!empty($pdata["password"])) {
                $validatorRules['password'] = $passValidations;
            }
        }

        $validatorMsg = [
            'username.required'             => 'نام کاربری را وارد کنید',
            'password.required'             => 'رمز عبور را وارد کنید',
            'full_name.required'            => 'نام کامل را وارد کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function hasExist($userId)
    {
        $result = array("status" => "success", "messages" => []);

        $rModel = new \App\Models\Resellers();
        $hasExist = $rModel->checkExist($userId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات کاربر یافت نشد";
        }
        return $result;
    }

    public static function delete($manId, $uid)
    {
        $result = array("status" => "success", "messages" => []);

        $rModel = new \App\Models\Resellers();
        $hasExist = $rModel->checkExist($manId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات کاربر یافت نشد";
        } else {
            if ($manId == $uid) {
                $result["status"] = "error";
                $result["messages"][] = "کاربر انتخابی قابل حذف نیست";
            }
        }

        return $result;
    }

    public static function addPackage($pdata, $userId)
    {
        $result     = self::hasExist($userId);
        if ($result["status"] == "error") {
            return $result;
        }

        $pModel  = new \App\Models\Packages();
        $validatorRules = [
            'package_id'   => [
                'required',
                function ($attribute, $value,  $fail) use ($pModel) {
                    if ($value) {
                        if (!$pModel->checkExist($value)) {
                            $fail("پکیج انتخابی وجود ندارد");
                        }
                    }
                }
            ],

        ];

        $validatorMsg = [
            'package_id.required'   => 'انتخاب پکیج الزامی است',

        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function addCredit($pdata, $userId)
    {

        $result     = self::hasExist($userId);
        if ($result["status"] == "error") {
            return $result;
        }
        $rModel     = new \App\Models\Resellers();
        $userInfo   = $rModel->getInfo($userId);
        $ucredit    = $userInfo->credit;

        $validatorRules = [

            'operation'     => ['required', 'in:inc,dec'],
            'desc'          => ['required'],
            'amount'        => ['required', function ($attribute, $value,  $fail) use ($pdata, $ucredit) {
                if ($value) {
                    $opr    = !empty($pdata["operation"]) ? $pdata["operation"] : "";
                    $value  = removeCommaStr($value);
                    if ($opr == "dec" && $ucredit < $value) {
                        $fail("اعتبار حساب جهت کسر موجودی کافی نمی باشد");
                    }
                }
            }],
        ];

        $validatorMsg = [
            'amount.required'       => 'مبلغ تراکنش را وارد کنید',
            'operation.required'    => 'نوع تراکنش را انتخاب کنید',
            'desc.required'         => 'توضیحات تراکنش را وارد کنید',

        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }
}
