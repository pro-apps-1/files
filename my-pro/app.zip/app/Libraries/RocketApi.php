<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Libraries;

if (!defined('PATH')) die();

class RocketApi
{
    private $apiUrl     = "https://rc.parsnet.xyz/api";
    private $apiToken   = "qV1h08MEGYtjZqt9AvssiXWSNVI4cA";

    public function __construct()
    {
    }

    public function getLicenseDetails()
    {
        $url        = "license/details";
        $response   = $this->sendRequest("post", $url);
        return $response;
    }

    public function renwalPayment($month = 1)
    {
        $data = [
            "month_count"   => $month,
            "callback_url"  => baseUrl("rpay-callback"),
        ];
        $url        = "license/paymants";
        $response   = $this->sendRequest("post", $url, $data);

        return $response;
    }

    public function verifyRenwalPayment($transId)
    {
        $data       = ["trans_id" => $transId];
        $url        = "license/paymants/verify";
        $response   = $this->sendRequest("post", $url, $data);

        return $response;
    }

    public function verifyPayment()
    {
    }

    private function sendRequest($method, $url, $pdata = [])
    {
        $siteUrl    = trim(baseUrl(), "/");
        $apiUrl     = $this->apiUrl;
        $xAuth      = $this->apiToken;
        $sendUrl    = "$apiUrl/$url";
        $method     = strtoupper($method);

        $root       = (isset($_SERVER['HTTPS']) ? "https://" : "http://") . $_SERVER['HTTP_HOST'];
        $actualLink =  $root  .$_SERVER['REQUEST_URI'];
        $referrer   = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : $actualLink;
        $curl       = curl_init();
        $options    = [
            CURLOPT_URL             => $sendUrl,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_SSL_VERIFYPEER  => false,
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_CONNECTTIMEOUT  => 15,
            CURLOPT_REFERER         => $referrer,
            CURLOPT_CUSTOMREQUEST   => $method,
            CURLOPT_HTTPHEADER      => [
                "x-auth: $xAuth",
                "x-site-url: $siteUrl",
                'Content-Type: application/json'
            ],
        ];

        if (!empty($pdata)) {
            $options[CURLOPT_POST]          = 1;
            $options[CURLOPT_POSTFIELDS]    = json_encode($pdata);
        }

        curl_setopt_array($curl, $options);

        $response = curl_exec($curl);

        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if (curl_errno($curl)) {
            return false;
        }

        curl_close($curl);

        if ($httpcode == 200 && !empty($response)) {
            $response   = json_decode($response, true);
            return $response;
        }

        return false;
    }
}
