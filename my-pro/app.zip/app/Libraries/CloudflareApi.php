<?php

namespace App\Libraries;

class CloudflareApi
{

    private $token  = "";
    private $TTL    = 1;
    private $apiUrl = "https://api.cloudflare.com/client/v4/zones";

    public function __construct($token, $TTL = 1)
    {
        $this->token    = $token;
        $this->TTL      = $TTL ? $TTL : 1;
    }

    public function checkToken()
    {
        return $this->rquest("");
    }

    public function checkZoneId($id)
    {
        return $this->rquest("/$id");
    }

    public function createDNS($zoneId, $subdomain, $ip)
    {
        $pdata = [
            "content"   => $ip,
            "name"      => $subdomain,
            "proxied"   => false,
            "type"      => "A",
            "ttl"       => $this->TTL ? intval($this->TTL) : 1
        ];
        $endpoint = "/$zoneId/dns_records";

        return $this->rquest($endpoint, "POST", $pdata);
    }

    public function deleteDNS($zoneId, $subdomain, $serverIp)
    {
        $endpoint = "/$zoneId/dns_records";
        try {
            $response   = $this->rquest($endpoint, "GET");
            $result     = $response["result"];

            $dnsId      = null;
            if (!empty($result)) {
                foreach ($result  as $data) {
                    $name       = $data["name"];
                    $content    = $data["content"];
                    if ($name == $subdomain && $serverIp == $content) {
                        $dnsId =  $data["id"];
                        break;
                    }
                }
            }

            if ($dnsId) {
                $endpoint = "/$zoneId/dns_records/$dnsId";
                $this->rquest($endpoint, "DELETE");
            }
        } catch (\Exception $err) {
            throw  $err;
        }
    }

    public function rquest($endpoint, $method = "GET", $pdata = [])
    {
        $curl       = curl_init();

        $endpoint   = trim($endpoint, "/");
        $url        = $this->apiUrl . "/" . $endpoint;

        $options    = [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_ENCODING        => '',
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST   => $method,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                "Authorization: Bearer $this->token",
            ),
        ];

        if (!empty($pdata)) {
            $options[CURLOPT_POSTFIELDS] = json_encode($pdata);
        }
        curl_setopt_array($curl, $options);

        $response = curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);


        if (curl_errno($curl)) {
            throw new \Exception("curl_error");
        }

        curl_close($curl);

        if ($httpcode == 200) {
            if (!empty($response)) {
                return json_decode($response, true);
            }
        } else {
            throw new \Exception("Error");
        }
    }
}
