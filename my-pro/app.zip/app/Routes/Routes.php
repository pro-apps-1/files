<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

if (!defined('PATH')) die();

loadHelpers("main");

$appVendorPath = PATH_APP . DS . "vendor" . DS . "autoload.php";
if (file_exists($appVendorPath)) {
	require $appVendorPath;
}

$app->add(new \App\Middlewares\OptionsMethodCheck);

$pController = new \App\Controllers\Admin\Pages($container);
$container['notFoundHandler']   = function ($container) use ($pController) {
	return function ($request, $response) use ($pController) {
		return $pController->notFoundPage($request, $response);
	};
};

$container['notAllowedHandler']   = function ($container) use ($pController) {
	return function ($request, $response) use ($pController) {
		return $pController->notFoundPage($request, $response);
	};
};

$container['errorHandler'] = function ($container) {
	return new \App\Handlers\Error($container['logger']);
};

$container['phpErrorHandler'] = function ($container) {
	return new \App\Handlers\PhpError($container['logger']);
};

require_once "admin.php";
require_once "front.php";
require_once "sapi.php";

$migrationRoutesPath = PATH_APP . DS . "Migration" . DS . "Routes.php";
if (file_exists($migrationRoutesPath)) {
	require_once PATH_APP . DS . "Migration" . DS . "Routes.php";
}
