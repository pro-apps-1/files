<?php


$susers = $app->group('/sapi', function () use ($app) {
    $app->get('/settings',          'App\Controllers\ServerApi:getSettings');

    $app->group('/ssh', function () use ($app) {
        $app->get('/ulogin',       'App\Controllers\ServerApi:sshUlogin');
        $app->get('/ulogout',      'App\Controllers\ServerApi:sshUlogout');
        $app->post('/ubanner',      'App\Controllers\ServerApi:sshUserBanner');
        $app->post('/utraffic',     'App\Controllers\ServerApi:sshTraffics');
        $app->post('/uactivities',  'App\Controllers\ServerApi:sshUserActivities');
    });

    $app->group('/ovpn', function () use ($app) {
        $app->post('/ulogin',       'App\Controllers\ServerApi:ovpnULogin');
        $app->post('/uconnect',     'App\Controllers\ServerApi:ovpnUConnect');
        $app->post('/udisconnect',  'App\Controllers\ServerApi:ovpnUDisconnect');
        $app->post('/utraffic',     'App\Controllers\ServerApi:ovpnUtraffic');
    });

    $app->group('/v2ray', function () use ($app) {
        $app->post('/utraffic',     'App\Controllers\ServerApi:v2rayTraffic');
    });

    $app->get('/confirm-installed', 'App\Controllers\ServerApi:confirmInstalled');
});

$susers->add(new \App\Middlewares\ServerApiAuth($container));
