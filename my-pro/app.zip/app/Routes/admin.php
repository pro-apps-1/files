<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */
$sModel         = new \app\Models\Settings();
$adminPrefixUrl = $sModel->getSetting("admin_prefix_url");
$adminPrefixUrl = $adminPrefixUrl ? $adminPrefixUrl : "admin";

$container["admin_prefix_url"] = $adminPrefixUrl;

$app->get('/cron/master',       'App\Controllers\Cronjob:master');

$app->group("/$adminPrefixUrl", function () use ($app, $container, $adminPrefixUrl) {

    $app->get('/login',                             'App\Controllers\Admin\Login:index');
    $app->post('/ajax/login',                       'App\Controllers\Admin\Login:ajaxLogin');

    $adminPanel = $app->group('', function () use ($app) {

        $app->get('/[dashboard]',                   'App\Controllers\Admin\Dashboard:index');
        $app->get('/admins',                        'App\Controllers\Admin\Admins:index');

        $app->get('/packages',                      'App\Controllers\Admin\Packages:index');
        $app->get('/logout',                        'App\Controllers\Admin\Subscribers:logout');


        $app->group('/subscribers', function () use ($app) {
            $app->get('[/]',                        'App\Controllers\Admin\Subscribers:index');
            $app->get('/online',                    'App\Controllers\Admin\Subscribers:online');
            $app->get('/conn-logs',                 'App\Controllers\Admin\Subscribers:connLogs');
        });

        $app->group('/resellers', function () use ($app) {
            $app->get('[/]',                        'App\Controllers\Admin\Resellers:index');
        });

        $app->group('/servers', function () use ($app) {
            $app->get('[/]',                        'App\Controllers\Admin\Servers:index');
            $app->get('/resources',                 'App\Controllers\Admin\Servers:resources');
            $app->get('/{id}/settings',             'App\Controllers\Admin\Servers:settings');
        });

        $app->group('/settings', function () use ($app) {
            $app->get('[/]',                        'App\Controllers\Admin\Settings:index');
            $app->get('/backup',                    'App\Controllers\Admin\Settings:backup');
            $app->get('/api',                       'App\Controllers\Admin\Settings:api');
            $app->get('/users-panel',               'App\Controllers\Admin\Settings:usersPanel');
            $app->get('/domains',                   'App\Controllers\Admin\Settings:domains');
            $app->get('/messages',                  'App\Controllers\Admin\Settings:messages');
            $app->get('/license',                   'App\Controllers\Admin\Settings:license');
            $app->get('/servers',                   'App\Controllers\Admin\Settings:servers');
            $app->get('/cloudflare',                'App\Controllers\Admin\Settings:cloudflare');
            $app->get('/telegram-bot',              'App\Controllers\Admin\Settings:telegramBot');
            $app->get('/categories',                'App\Controllers\Admin\Categories:index');
            
        });

        $app->group('/pages', function () use ($app) {
            $app->get('/filtering',                  'App\Controllers\Admin\Pages:filtering');
        });

        $app->group('/reports', function () use ($app) {
            $app->get('[/]',                        'App\Controllers\Admin\Reports:index');
            $app->get('/credits',                   'App\Controllers\Admin\Reports:credits');
            $app->get('/logs',                      'App\Controllers\Admin\Reports:logs');
        });


        //Ajax routes
        $app->group('/ajax', function () use ($app) {

            $app->post('/check-host',               'App\Controllers\Admin\Pages:ajaxCheckHost');

            $app->group('/subscribers', function () use ($app) {
                $app->post('',                      'App\Controllers\Admin\Subscribers:ajaxAddUser');
                $app->post('/list',                 'App\Controllers\Admin\Subscribers:ajaxUsersList');
                $app->post('/delete',               'App\Controllers\Admin\Subscribers:ajaxDeleteUsers');

                $app->group('/online', function () use ($app) {
                    $app->post('/list',             'App\Controllers\Admin\Subscribers:ajaxUsersOnlinesList');

                    $app->group('/{id}', function () use ($app) {
                        $app->get('/kill',          'App\Controllers\Admin\Subscribers:ajaxKillOnlineUser');
                    });
                });

                $app->group('/conn-logs', function () use ($app) {
                    $app->post('/list',             'App\Controllers\Admin\Subscribers:ajaxConnLogsList');
                    $app->delete('[/]',             'App\Controllers\Admin\Subscribers:ajaxDeleteLogs');
                });

                $app->group('/bulk', function () use ($app) {
                    $app->post('/create',            'App\Controllers\Admin\Subscribers:ajaxAddBulkUsers');
                    $app->post('/delete',            'App\Controllers\Admin\Subscribers:ajaxDeleteBulkUsers');
                });

                $app->group('/{id}', function () use ($app) {
                    $app->put('[/]',                'App\Controllers\Admin\Subscribers:ajaxEditUser');
                    $app->delete('[/]',             'App\Controllers\Admin\Subscribers:ajaxDeleteUser');
                    $app->put('/toggle-active',     'App\Controllers\Admin\Subscribers:ajaxToggleUserActive');
                    $app->put('/reset-traffic',     'App\Controllers\Admin\Subscribers:ajaxResetUserTraffic');
                    $app->put('/renewal',           'App\Controllers\Admin\Subscribers:ajaxSaveRenewal');
                });
            });

            $app->group('/admins', function () use ($app) {
                $app->post('',                      'App\Controllers\Admin\Admins:ajaxAddUser');
                $app->post('/list',                 'App\Controllers\Admin\Admins:ajaxUsersList');

                $app->group('/{id}', function () use ($app) {
                    $app->put('[/]',                'App\Controllers\Admin\Admins:ajaxEditUser');
                    $app->delete('[/]',            'App\Controllers\Admin\Admins:ajaxDeleteUser');
                });
            });

            $app->group('/resellers', function () use ($app) {
                $app->post('',                      'App\Controllers\Admin\Resellers:ajaxAddUser');
                $app->post('/list',                 'App\Controllers\Admin\Resellers:ajaxUsersList');

                $app->group('/{id}', function () use ($app) {
                    $app->put('[/]',                'App\Controllers\Admin\Resellers:ajaxEditUser');
                    $app->delete('[/]',            'App\Controllers\Admin\Resellers:ajaxDeleteUser');

                    $app->group('/packages', function () use ($app) {
                        $app->post('[/]',            'App\Controllers\Admin\Resellers:ajaxAddPackage');
                        $app->post('/list',          'App\Controllers\Admin\Resellers:ajaxPackagesList');
                        $app->delete('/{pkg_id}',    'App\Controllers\Admin\Resellers:ajaxDeletePackages');
                    });

                    $app->group('/credits', function () use ($app) {
                        $app->post('[/]',            'App\Controllers\Admin\Resellers:ajaxAddCredit');
                        $app->post('/list',          'App\Controllers\Admin\Resellers:ajaxCreditsList');
                        $app->delete('/{cid}',       'App\Controllers\Admin\Resellers:ajaxDeleteCredits');
                    });
                });
            });

            $app->group('/domains', function () use ($app) {
                $app->post('[/]',                   'App\Controllers\Admin\Domains:ajaxAdd');
                $app->get('[/]',                    'App\Controllers\Admin\Domains:ajaxList');
                $app->get('/all',                   'App\Controllers\Admin\Domains:ajaxGetAll');

                $app->group('/{id}', function () use ($app) {
                    $app->delete('[/]',              'App\Controllers\Admin\Domains:ajaxDelete');
                    $app->post('/action-dns',         'App\Controllers\Admin\Domains:ajaxActionDNS');
                });
            });

            $app->group('/categories', function () use ($app) {
                $app->post('[/]',                   'App\Controllers\Admin\Categories:ajaxAdd');
                $app->get('[/]',                    'App\Controllers\Admin\Categories:ajaxList');
                $app->get('/all',                   'App\Controllers\Admin\Categories:ajaxGetAll');

                $app->group('/{id}', function () use ($app) {
                    $app->put('[/]',                'App\Controllers\Admin\Categories:ajaxEdit');
                    $app->delete('[/]',             'App\Controllers\Admin\Categories:ajaxDelete');
                });
            });

            $app->group('/packages', function () use ($app) {
                $app->post('',                      'App\Controllers\Admin\Packages:ajaxAddPackage');
                $app->post('/list',                 'App\Controllers\Admin\Packages:ajaxPackagesList');
                $app->put('/{id}',                  'App\Controllers\Admin\Packages:ajaxEditPackage');
                $app->delete('/{id}',               'App\Controllers\Admin\Packages:ajaxDeletePackage');
            });

            $app->group('/reports', function () use ($app) {
                $app->get('/credits',               'App\Controllers\Admin\Reports:ajaxCreditsList');
                $app->get('/logs',                   'App\Controllers\Admin\Reports:ajaxLogsList');
            });

            $app->group('/servers', function () use ($app) {
                $app->post('',                       'App\Controllers\Admin\Servers:ajaxAddServer');
                $app->post('/list',                  'App\Controllers\Admin\Servers:ajaxServersList');
                $app->get('/all-active',             'App\Controllers\Admin\Servers:ajaxGetAllActive');

                $app->group('/{id}', function () use ($app) {
                    $app->put('[/]',                 'App\Controllers\Admin\Servers:ajaxEditServer');
                    $app->delete('[/]',              'App\Controllers\Admin\Servers:ajaxDeleteServer');
                    $app->post('/configure',         'App\Controllers\Admin\Servers:ajaxConfigure');
                    $app->put('/toggle-active',      'App\Controllers\Admin\Servers:ajaxToggleServerActive');
                    $app->post('/sync-users',        'App\Controllers\Admin\Servers:ajaxSyncUsers');
                    $app->get('/sys-data',           'App\Controllers\Admin\Servers:ajaxSysData');
                    $app->get('/kill-online',         'App\Controllers\Admin\Servers:ajxKillOnlienUsers');
                    $app->get('/resources-html',     'App\Controllers\Admin\Servers:ajaxResourcesHtml');
                    $app->post('/action-users',      'App\Controllers\Admin\Servers:ajaxActionUsers');
                    $app->post('/run-cmd',           'App\Controllers\Admin\Servers:ajaxRunCommand');
                    $app->get('/categories',         'App\Controllers\Admin\Servers:ajaxGetCategories');
                    $app->post('/reset-services',    'App\Controllers\Admin\Servers:ajaxResetServices');
                    $app->group('/protocols', function () use ($app) {
                        $app->post('/install',       'App\Controllers\Admin\Servers:ajaxInstallProtocols');
                        $app->post('/install-logs',  'App\Controllers\Admin\Servers:ajaxInstallLogProtocols');
                        $app->group('/openvpn', function () use ($app) {
                            $app->get('/certs',       'App\Controllers\Admin\Servers:ajaxDlOvpnCerts');
                            $app->post('/certs',      'App\Controllers\Admin\Servers:ajaxUpOvpnCerts');
                        });
                    });
                });
            });

            $app->group('/pages', function () use ($app) {
                $app->get('/filtering',              'App\Controllers\Admin\Pages:ajaxFilteringDate');
            });

            $app->group('/settings', function () use ($app) {

                $app->post('/main',                 'App\Controllers\Admin\Settings:ajaxSaveMainSettings');
                $app->post('/users-panel',          'App\Controllers\Admin\Settings:ajaxSaveUsersPanel');
                $app->post('/cloudflare',           'App\Controllers\Admin\Settings:ajaxSaveCloudflare');
                $app->post('/servers',              'App\Controllers\Admin\Settings:ajaxSaveServersSettings');

                $app->group('/license', function () use ($app) {
                    $app->get('[/]',                'App\Controllers\Admin\Settings:ajaxLicenseDetails');
                    $app->post('/renewal',          'App\Controllers\Admin\Settings:ajaxRenwalLicense');
                });


                $app->group('/backup', function () use ($app) {
                    $app->post('/import',           'App\Controllers\Admin\Settings:ajaxImportBackup');
                    $app->post('/export',           'App\Controllers\Admin\Settings:ajaxCreateBackup');
                    $app->post('/auto',             'App\Controllers\Admin\Settings:ajaxSaveAutoBackup');
                    $app->post('/download',         'App\Controllers\Admin\Settings:ajaxDownloadBackup');
                    $app->delete('/export',         'App\Controllers\Admin\Settings:ajaxDeleteExportFile');
                });

                $app->group('/messages', function () use ($app) {
                    $app->post('/sms',              'App\Controllers\Admin\Settings:ajaxSaveSmsSetting');
                    $app->post('/banner-text',      'App\Controllers\Admin\Settings:ajaxSaveBannerSettings');
                });
                $app->group('/telegram-bot', function () use ($app) {
                    $app->post('/admin',             'App\Controllers\Admin\Settings:ajaxSaveAdminBot');
                });
            });
        });

        $app->group('/ajax-views', function () use ($app) {

            $app->group('/subscribers', function () use ($app) {
                $app->get('/add',                       'App\Controllers\Admin\Subscribers:ajaxViewAdd');
                $app->get('/{id}/edit',                 'App\Controllers\Admin\Subscribers:ajaxViewEdit');
                $app->get('/{id}/info',                 'App\Controllers\Admin\Subscribers:ajaxViewDetails');
                $app->get('/{id}/renewal',              'App\Controllers\Admin\Subscribers:ajaxViewRenewal');
                $app->get('/{id}/configs',              'App\Controllers\Admin\Subscribers:ajaxViewConfigs');
            });

            $app->group('/admins', function () use ($app) {
                $app->get('/add',                       'App\Controllers\Admin\Admins:ajaxViewAdd');
                $app->get('/{id}/edit',                 'App\Controllers\Admin\Admins:ajaxViewEdit');
            });

            $app->group('/resellers', function () use ($app) {
                $app->get('/add',                       'App\Controllers\Admin\Resellers:ajaxViewAdd');
                $app->get('/{id}/edit',                 'App\Controllers\Admin\Resellers:ajaxViewEdit');
                $app->get('/{id}/settings',             'App\Controllers\Admin\Resellers:ajaxViewSettings');
            });

            $app->group('/packages', function () use ($app) {
                $app->get('/add',                       'App\Controllers\Admin\Packages:ajaxViewAdd');
                $app->get('/{id}/edit',                 'App\Controllers\Admin\Packages:ajaxViewEdit');
            });

            $app->group('/servers', function () use ($app) {
                $app->get('/add',                       'App\Controllers\Admin\Servers:ajaxViewAdd');
                $app->get('/{id}/edit',                 'App\Controllers\Admin\Servers:ajaxViewEdit');
                $app->get('/{id}/settings',             'App\Controllers\Admin\Servers:ajaxViewSettings');
                $app->get('/{id}/filtering',            'App\Controllers\Admin\Servers:ajaxViewFiltering');
            });
        });
    });

    $adminPanel
        ->add(new \App\Middlewares\LicenseChecker($container))
        ->add(new \App\Middlewares\PanelPerms($container))
        ->add(new \App\Middlewares\PanelAuth($container));
});
