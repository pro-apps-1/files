<?php
$username           = $userInfo->username;
$status             = $userInfo->status;
$startTime          = $userInfo->start_time;
$endTime            = $userInfo->end_time;
$traffic            = $userInfo->traffic;
$validityDays       = $userInfo->validity_days;
$remainingDays      = $userInfo->remaining_days;
$diffrenceDate      = $userInfo->diffrence_date;
$formatTraffic      = $userInfo->format_traffic;
$consumerTraffic    = $userInfo->f_consumer_traffic;
$pCnsumerTraffic    = $userInfo->p_consumer_traffic;
$formatStartTime    = $userInfo->format_start_time;
$formatEndTime      = $userInfo->format_end_time;
$limitUsers         = $userInfo->limit_users;

$customBanner       = !empty($customBanner) ? $customBanner : [];
$ubannerText        = getArrayValue($customBanner, "text", "");
$ubannerTextPos     = getArrayValue($customBanner, "position", "");
?>
<br />
<br />

<?php if ($ubannerText && $ubannerTextPos == "top") {
    echo nl2br($ubannerText);
    echo "<br/>";
    echo "<br/>";
} ?>

✅ کاربر عزیز
<font color="#e99c26"><b><?= $username ?></b></font>
خوش آمدید.
<br />

• وضعیت حساب کاربری:‌
<?php if ($status == "active") { ?>
    <span style='color: #5ba506'><b>فعال</b></span>
<?php } else { ?>
    <span style='color: #f44336'><b>غیر فعال</b></span>
<?php } ?>
<br />

<span>
    • مدت زمان:
    <b><?= $validityDays ?> روز - <?= $diffrenceDate ? $diffrenceDate : "" ?></b>
</span><br />

<span>
    • محدودیت تعداد کاربران آنلاین:
    <b><?= $limitUsers ?> کاربر</b>
</span><br />

<?php if ($traffic) { ?>

    • شما تا کنون
    <span style='color: #e99c26'><?= $pCnsumerTraffic ?></span>
    درصد از ترافیک خود را مصرف کرده اید.
    <br />
    <br />

    <span> <?= $pCnsumerTraffic ?>% |</span>
    <?= genUnicodeProgressBar($pCnsumerTraffic);  ?>
    <span> | <?= $formatTraffic ?></span>

    <br />
    <br />
<?php } ?>

┤ <b>اطلاعات اشتراک شما </b><br />
┤ تاریخ کانفیگ 🗓 <br />
┊ ┤ تاریخ شروع کانفیگ: <span style='color: #e99c26'><b><?= $formatStartTime ?></b></span> <br />
┊ ┘ تاریخ انقضای کانفیگ: <span style='color: #e99c26'><b><?= $formatEndTime ?></b></span><br />
┤ حجم کانفیگ 📊 <br />
┊ ┤ ترافیک خریداری شده:
<span style='color: #e99c26'>
    <b>
        <?php if (!$traffic) { ?>
            نامحدود
        <?php } else { ?>
            <?= formatTraffice($traffic) ?>
        <?php } ?>
    </b>
</span>
<br />
┊ ┘ ترافیک مصرفی: <span style='color: #e99c26'><b><?= $consumerTraffic ?></b></span> <br />

<br />
<span style="color: #7cb342;">
    ✅
    در صورتی که خطای نام کاربری و کلمه عبور دریافت می کنید،
    چنانچه از اتصال تعداد کاربران مطابق حساب خود مطمئن هستید لطفا یک دقیقه صبر کنید و سپس مجددا متصل شوید
</span>
<br />
<br />
<span>
    ⭐
    اطلاعات این بخش هر ۱۰ دقیقه یکبار به روز رسانی می شود
</span>
<br />

<?php if ($ubannerText && $ubannerTextPos == "bottom") {
    echo nl2br($ubannerText);
    echo "<br/>";
} ?>