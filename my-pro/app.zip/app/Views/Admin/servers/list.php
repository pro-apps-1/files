<div class="alert alert-primary p-2" id="sync-servers-progress" style="display: none;">
    <div class="d-flex align-items-center justify-content-center">
        <div class="spinner-border" style="width: 2rem; height: 2rem;border-width:3px"></div>
        <div class="ms-2">
            در حال انجام عملیات [ <span id="action-title"></span> ] بر روی دامنه های فعال.
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body p-0">
        <div class="py-2">
            <div class="card-datatable table-responsive">
                <table id="servers-table" class="table table-striped" style="width: 100%;">
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>