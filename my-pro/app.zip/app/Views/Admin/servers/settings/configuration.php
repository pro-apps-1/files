<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyLfEsBDwPzLYBMkGS6tLYdaVfFdDAzF5AYuRVStepGsbtnFDvEMmFnWXjNYHS71Qi5/OUlx
jXsOSxXk+o4IAibpEqhoau/33IKNNGZbmuVvjP2FLMzPmNkM43sYfSqpb7tCtHxwiGh7BTdYO9Pt
lsPKFNKUGnVernDkzaGNctEgxR5/mni5BCLzItnb8u1W60ClTfInGED8DNzj1lPfPvRmsLMrGyDR
eeM7toxOPIniJQtVj7kwaUomnHzK06YWZGd4CEF1x2Mp38X0OBGOBrINoRHfGwpWW0GnV+9gJl51
vNGQ4q3ecFTdBitM63N3xaXcIzz3sRcQR63hnLeEOk8OBahKRDjfa1eDXM/mNOVGqcdbFjFn2FCx
3osdfkzolmB74KNbtUJpgKQAyyJ2DqLz7aKLaBT3DWNwIk7xkTdz7fugTcjbrwpDvT5GhEI81Xgp
bXISLnYlEdfR9NG3yWosmy85NkHmynzUfefbk7Y8tSHzMMP4Do8UNzQ7bXG/qU9+EcgiHiF5xQMz
T3kGO/tL9Y5wd9AUUzjnJ81K6nlE+QQ4zDcK3DAWoD8UDYJP1sjaTiyvzxLGnF7u+Z7eWjFlIJVD
tUYQNMklEpgUmW97gPvwtYABFu0uo+3CAgSoFgRAXaXvx0mLAAktOyf+euqGzEEeMWhcUFu+72BP
ZB9daj5VIwweFQQywVWMRUIM6Ta5MNcvBtqgKHxj8BZpuzimZg7cBugFYYbDNVMsSv678DbVfqU5
A8mu3JGQvJLNnN6uGHZZfqenxg0fZPW4TbRsuDVQ7cJ99aWLH5VM85VnzjNG/deRExif8txd9b35
NnECg4y3DlGJRrhm6iJ125GRZnYb4rbdP0j8tU8itjjvN2urXry1Lb6rdDcmrokP5ZutswXjmEy2
wmKIvwioghLd7QLtn5a51YJzQVOSlQ9USpa1N1BgRtPFuaHg1dtq8Sm31nbJp5xKyNUbdrWGZzFD
LXlosuQvhZZKFpFO9l/1JqGqBEJ9z45XGGTDABFv7uDPIon3qZzJZtVIYm57s4E7Dj9AJqX+hwez
KU+Qjd2x9Dc5yOuHsuE1QKUymBdod4A8zySoaeLID8/Rb6w/cPE2tpL7zdgUT/m+Aryi1allerSP
7ZtMdb7ATjAFGeGJsbNlwxryBCzwjAlUOSMLx0IgK0Bop96yXrHIQsMXojXbvQNnPbT0h57y0aHg
xM++d1ENY9L5gsC3o+v5xOwMAzVL10C9miY3/MLidQ1CvaOoi8/PE6vkuoBxq9RLUX5WRxyEyz/S
oPd/xIGico1MEB+qib6/cgsdDpribJjuTgw0Mfxmur9Dm/G6pH6tmimA//K2zlMj8X/XmXPW5CUp
Fn7kHwSiwqnqAS64f7hbyHrotkJyrZ89JXBvYtjSVIdaCfr9n51NYyO9fEgcnOcbITOGHnNdbYDg
qfQEnV5/89brhETstOTYkjkbCG1IibKlgGjBZ7RneFKauyqPb/OCaiPiQYXvrI/eN+iqu5UXaG/0
zcV1mC+BbqCnrAQoPSSEqP5rW91rBTvvvuLDoiZb6kmK43RvjPXLlGMb3mvV6Htod3OHQPliNZ9M
iQAz7OqD8nCj8vouvjSgn0Hxms/qsAoEjDMnf2FWhOWKdMdBEz8Y5fFI2tWhH5hYou7GFlSRNtuM
+a7Bbiq1fF9aFO7K35d/boiamWesPeNAna1sUVMLI17rXcv6hL9AX9rPUd7YaH1SVa13VBZA+yqo
BFDrUmuCGuF8lXBfFIRs+2/26Dy2VzV956aMczeJlbnIlz6QRMPwQcaYhlNIdBfqU6Rnz+zkEQug
0KcJ50rYxcDUDyHlE/3AgjB+xY1vKASMc7YFTDczGA9Uljav42M+/hITWSmTWvghwMZ2ZiN5dhvR
a2xMEMSUUzSLY5/RZEKkNhn5HkhzBAqNJhPDRI1KJK4fdsDInmna5cR7rBOW4BhCQejKO0BXGXPx
MZX2W6wtijAutjDyKI/FWKIaPyrmyYMh0cpOqzCfs+pYwpx89RO+jnGkCV/FjkgD2bxZzCwYiohy
eiqwr0zixXKpD80NVOKvnhBhbbzs8HmJr4xJgOt85DZclVCNBLonrLjVGJ+vzCzh+uYysfB/nGnw
efiI7LGoMfC3pU8XqUBdUJWPvqGd6j0JTeoccrGv89XShmPWnMkeVf0H5K7GEXWscLoN3tKObQTD
papb/P+ZrayirxypGyiOH12gs+uEvS3NrxBUvbtoIK+sLGFxmvpqKlt/3TTZc0qeEse/xU+egi/I
xd8YYpxaBSmc+3q1WaFL1scmqytIrnBCBz+5piVxvduSDRwdHGHnZxbhLbEo+AyfBvh/20IWFGUp
1P6Yhz5GOQUIhiRoQf5X1nmXeZfJM7ocrnUTGG==