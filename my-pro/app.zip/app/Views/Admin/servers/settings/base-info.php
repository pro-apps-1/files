<?php

$serverName     = getArrayValue($serverInfo, "name");
$serverId       = getArrayValue($serverInfo, "id");
$serverIp       = getArrayValue($serverInfo, "ip");
$sshUser        = getArrayValue($serverInfo, "ssh_user");
$sshPass        = getArrayValue($serverInfo, "ssh_pass");
$sshPort        = getArrayValue($serverInfo, "ssh_port");
$isDisabled     = getArrayValue($serverInfo, "is_disabled");
$isConfigured   = getArrayValue($serverInfo, "is_configured");
$countryName    = getArrayValue($serverInfo, "country_name");
$countryFlag    = getArrayValue($serverInfo, "country_flag");
$categoryId     = getArrayValue($serverInfo, "category_id");
$ctime          = getArrayValue($serverInfo, "ctime");

$values = [
    [
        "label" => "نام سرور",
        "value" => $serverName,
    ],
    [
        "label" => "آی پی سرور",
        "value" => $serverIp,
    ],
    [
        "label" => "کشور",
        "value" => "<div><img width='30px' class='me-2' src='$countryFlag' /> $countryName</div>",
    ],
];

$editViewUrl = "servers/$serverId/edit";
?>

<div class="card  mb-3">
    <div class="card-body p-2 px-3">
        <div class="row align-items-center justify-content-between">
            <div class="col-lg-2">
                <div class="d-flex align-items-center mb-2">
                    <img width='40px' class='me-2' src='<?= $countryFlag ?>' />
                    <h4 class="fw-bold mb-0"><?= $serverName ?></h4>
                </div>
                <div class="text-muted"><?= $serverIp ?></div>
            </div>
            <div class="col-lg-2" style="font-size: 15px;">
                <p class="mb-0">
                    <span class='dir-ltr unicode-bidi-plain'>نام کاربری SSH</span>:
                    <b><?= $sshUser ?></b>
                </p>
                <p class="mb-0">
                    <span class='dir-ltr unicode-bidi-plain'>رمز عبور SSH</span>:
                    <span class='cursor-pointer fw-bold' data-copy='true' data-text='<?= $sshPass ?>' data-bs-toggle='tooltip' title='کپی'><?= $sshPass ?></span>

                </p>
                <p class="mb-0">
                    <span class='dir-ltr unicode-bidi-plain'>پورت SSH</span>:
                    <b><?= $sshPort ?></b>
                </p>
            </div>
            <div class="col-lg-3">
                <div class="text-center">
                    <h6 class="border-bottom mb-2 pb-2">نرم افزار سرور</h6>
                    <h6 class="fw-bold">وضعیت: </h6>
                    <div class="mt-1" id="rocketproc-status"></div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="row g-1">
                    <div class="col-lg-6">
                        <button class="btn btn-primary btn-ajax-views w-100 mb-1" data-url="<?= $editViewUrl ?>">
                            <?= inlineIcon("edit") ?>
                            ویرایش
                        </button>
                        <button id="btn-reset-server" class="btn btn-danger text-white w-100" data-url="<?= $editViewUrl ?>">
                            <?= inlineIcon("power-off") ?>
                            ریست سرور
                        </button>
                    </div>
                    <div class="col-lg-6">
                        <button class="btn-chng-active mb-1 w-100 btn btn-<?= !$isDisabled ? "warning" : "success" ?>" data-category="<?= $categoryId ?>" data-active="<?= !$isDisabled ? 1 : 0 ?>" data-id="<?= $serverId ?>">
                            <?= inlineIcon(!$isDisabled ? "pause" : "play") ?>
                            <?= !$isDisabled ? "غیر فعال کردن" : "فعال کردن" ?>
                        </button>
                        <button class="btn btn-dark text-white w-100" id="btn-sycn-users">
                            <?= inlineIcon("refresh") ?>
                            سینک کاربران
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>