<?php
$protocols              = getArrayValue($serverInfo, "protocols", []);
$isInstalledSsh         = getArrayValue($serverInfo, "installed_ssh", false);
$isInstalledV2ray       = getArrayValue($serverInfo, "installed_v2ray", false);
$isInstalledOpenvpn     = getArrayValue($serverInfo, "installed_openvpn", false);
?>
<div class="custome-breadcrumb">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("dashboard") ?>">داشبورد</a></li>
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("servers") ?>">سرورها</a></li>
            <li class="breadcrumb-item active"><?= $serverInfo->name ?> <small>(<?= $serverInfo->ip ?>)</small></li>
        </ol>
    </nav>
</div>

<div class="alert alert-primary p-2" id="sync-servers-progress" style="display: none;">
    <div class="d-flex align-items-center justify-content-center">
        <div class="spinner-border" style="width: 2rem; height: 2rem;border-width:3px"></div>
        <div class="ms-2">
            در حال انجام عملیات [ <span id="action-title"></span> ] بر روی دامنه های فعال.
        </div>
    </div>
</div>
<?php include "base-info.php" ?>
<div class="row">
    <div class="col-lg-9">
        <div class="row">
            <?php if (in_array("ssh", $protocols) ) { ?>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <span>پروتکل SSH</span>
                            <img src="<?= assets("images/protocol/ssh.png") ?>" height="25px" />
                        </div>
                        <div class="card-body" id="ssh-protocol-body">

                        </div>
                    </div>
                </div>
            <?php } ?>
            <?php if (in_array("openvpn", $protocols)) { ?>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <span>پروتکل OPENVPN</span>
                            <img src="<?= assets("images/protocol/openvpn.png") ?>" height="24px" />
                        </div>
                        <div class="card-body" id="openvpn-protocol-body">

                        </div>
                    </div>
                </div>
            <?php } ?>
            <?php if (in_array("v2ray", $protocols)) { ?>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <span>پروتکل V2RAY</span>
                            <img src="<?= assets("images/protocol/v2ray.png") ?>" height="20px" />
                        </div>
                        <div class="card-body" id="v2ray-protocol-body">

                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <div class="col-lg-3 h-100">
        <div class="card">
            <div class="card-header">منابع مصرفی
                <span id="loading-resources"></span>
            </div>
            <div class="card-body">
                <?php include "resources.php" ?>
            </div>
        </div>
    </div>
</div>


<div class="modal" id="configure-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">نصب و کانفیگ پرتکل ها</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6>در حال نصب و راه اندازی سرور لطفا منتظر بمانید...</h6>
                <style>
                    .configure-console {
                        border: 2px solid var(--bs-modal-header-border-color);
                        padding: 10px;
                        overflow-y: scroll;
                        max-height: 400px;
                        width: 100%;
                        direction: ltr;
                        background: #030722;
                        color: #80deea;
                        border-radius: 7px;
                    }

                    .configure-console pre {
                        margin: 0;
                        white-space: pre-wrap;
                        overflow-wrap: break-word;
                        font-family: monospace;
                    }
                </style>
                <div class="configure-console">
                    <pre id="log-body"></pre>
                </div>
            </div>
        </div>
    </div>
</div>
<input type="file" id="ovpn-file-input" accept=".zip" style="display: none;">

<script>
    var serverId = <?= $serverId ?>;
    var serverProtocols = <?= json_encode($protocols) ?>;
    var installed_protocols = {
        server_ssh: <?= $isInstalledSsh ? 1 : 0 ?>,
        server_v2ray: <?= $isInstalledV2ray ? 1 : 0 ?>,
        server_openvpn: <?= $isInstalledOpenvpn ? 1 : 0 ?>,
    }
    var formMode = "edit";
</script>