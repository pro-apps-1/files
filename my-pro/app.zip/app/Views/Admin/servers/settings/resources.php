<div class="mb-2 pb-2 border-bottom">
    <h6 class="widget-title mb-1">اطلاعات RAM</h6>
    <div class="mt-1">
        <div class="d-flex justify-content-between">
            <div class="unicode-bidi-plain small"> <b>کل: </b> <span id="ram-size"></span></div>
            <div class="unicode-bidi-plain small">استفاده شده: <span id="ram-used"></span></div>
        </div>
        <div class="progress" style="height: 10px;">
            <div class="progress-bar" id="ram-progress">
            </div>
        </div>
    </div>
</div>

<div class="mb-2 pb-2 border-bottom">
    <h6 class="widget-title mb-1">اطلاعات CPU</h6>
    <div class="mt-1">
        <div class="d-flex justify-content-between">
            <div class="unicode-bidi-plain small"> <b>تعداد هسته: </b> <span id="cpu-cores"></span></div>
            <div class="unicode-bidi-plain small">استفاده شده: <span id="cpu-load-avg"></span></div>
        </div>

        <div class="progress" style="height: 10px;">
            <div class="progress-bar" id="cpu-progress"></div>
        </div>
    </div>
</div>
<div class="mb-2 pb-2 border-bottom">
    <h6 class="widget-title mb-1">اطلاعات هارد</h6>
    <div class="mt-1">
        <div class="d-flex justify-content-between">
            <div class="unicode-bidi-plain small"> <b>کل: </b> <span id="hdd-size"></span></div>
            <div class="unicode-bidi-plain small">استفاده شده: <span id="hdd-used"></span></div>
        </div>

        <div class="progress" style="height: 10px;">
            <div class="progress-bar" id="hdd-progress"></div>
        </div>
    </div>
</div>

<div class="mb-0">
    <h6 class="widget-title mb-1">ترافیک سرور <span id="total-traffic"></span></h6>
    <div class="mt-1">
        <div class="d-flex justify-content-between">
            <div title="دانلود" class="me-2">
                دانلود: <?= inlineIcon("download") ?> <span id="total-download"></span>
            </div>
            <div title="آپلود">
                آپلود: <?= inlineIcon("upload") ?> <span id="total-upload"></span>
            </div>
        </div>
    </div>
</div>
