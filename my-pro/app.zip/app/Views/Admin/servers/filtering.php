<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx7hiBy9P0cmr2ebd9AwMCzZJp6ITKQbZUY5EdhSLxvbnz5Tat+ljywhErSpRiI6Sn5LlkZC
fvDoxSjn92Q9QPBPjxxoiCqGob2dsKmj2vw1zz+JKWxVaAW+gp2Mlo96gGZB2jYBf8dPw/X23wmJ
wWK3aa8cMf96EY7GRSCFeK+eCr05B6WpOXpckVdUAKTYTQbzTzulYBg2JRdkC6JvPAKoDKb6wZLf
O9OFDbUaZEYeC/meiW2ThYfP8an1rL76J7+W5p3ZmUmbimo8G62q62zKbyaXPvXazPXgHi39P+pn
mUHqNs2gwQhFQxOCnWL3fxJw5A9dZnpm7opHuMR4GRhoZRv3EBFF+l1o9Q9CS7U005fdZ/E5j57a
lURhds2R1airVtHkWfRBnnzqL2C0gFGQLGdwLmRS4ID7hj5AUkKWWJrwcUgVj7bb7Tz4nRxbCWOX
eQcYEmNeZaDmSfTxbft3mxzjzj0Dlz7w2VO5j4yoXSI5WsFUcxgcVJxVHDJTfEqfdKIejoKxbC6R
hEYaS14ibRQD560S3HUbyiJ46WqFUtJylHfK6yXA3ltEANsPGcmusOlqsG2J8HTNdZLFOqpUrZyd
ha1rNUOVqlc66Cyi0erMmHo11T+D4EkSyFrOGDYNzXDTP/3fXlf838gk9jD2f2GCuEQQJ8W2G4Yg
TnxwuqXkNolyOq+YdhRMmxWuDgEsSzgnQRuYMaHQ0o/StYyeFT6JMpKBMkIGu32MrzPrtL4rImQH
glI3umGYOLg1sthZnD60n566VFnQYbVj4y3Fuc6mYMd8P4E+nvyMZ7egrPjlVgurmlJ26ToBOJhv
APA0UyEfhQot2RyoKm/5LvRH1DzKp/aPI+zYrLRUE3wiu9KPfzq7FY5cyBJzuUKIDXmYnOLvakGl
fKLJGNcNegLOqN78kw9X9K71KY5Dl53iJhNXi4iHNBkC6Hivn5+HrNqY3yFFLgRLzwOntSDuipHj
6+eAt33h3fMIa8QbgU1sQ9JRXbR/j1Ta3JHdJNKOmTfX8a+AoATz4xTz1cHjZELuh4uP0X0tMGrs
hcK2YE2Xziw2kmk8yyI4Axn6oyjNzBRpoYQpkcW6iDXX3lmxURqz+HR+OyaVHUadPg8rM0qK1lO7
teCdc2SAtt9r+zQAnPvJ6T5pi+25buj1gPiaL560oxAu6C5xVTBwOssNpwlhPGEccMiJl77EbFVL
p+ezhle0IFrnqa/aqWiP6T5zznhHQrdKdaRyCH55alKdo81mneZ0iZVBIh0GNP+CZVZV7GmCCr7Z
gSLOofSWKpjEnQ6IeGf6Zr3/ZbQpfQwCyqNdmTmPzKDebyoXE10jAAW7JbqntEI3PokEBcR+D1YD
/N0SJWfXhb1sBqxV6QVzHelHix7KPpPuTm2/Q/QBm3lkmMYQk8Ab4B8=