<div class="custome-breadcrumb has-actions">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("dashboard") ?>">داشبورد</a></li>
            <li class="breadcrumb-item active">سرورها</li>
        </ol>
    </nav>
    <?php if ($activeTab == "list") { ?>
        <div class="actions">
            <button class="btn btn-primary btn-ajax-views btn-float-icon" data-url="servers/add">
                <?= inlineIcon("add", "icon") ?>
                افزودن سرور
            </button>
        </div>
    <?php } ?>
</div>



<ul class="nav nav-tabs mb-3">
    <li class="nav-item" role="presentation">
        <a class="nav-link <?= $activeTab == "list" ? "active" : "" ?>" href="<?= adminBaseUrl("servers") ?>">
            <?= inlineIcon("list") ?> لیست سرورها
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeTab == "resources" ? "active" : "" ?>" href="<?= adminBaseUrl("servers/resources") ?>">
            <?= inlineIcon("list") ?> مصرف منابع
        </a>
    </li>
</ul>

<div class="modal" id="table-action-modal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-6" id="exampleModalLabel">منوی سرور <span id="sub-menu-uname"></span></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">

            </div>
        </div>
    </div>
</div>

<div class="modal" id="configure-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">کانفیگ اولیه سرور</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6>در حال نصب و راه اندازی سرور لطفا منتظر بمانید...</h6>
                <style>
                    .configure-console {
                        border: 2px solid var(--bs-modal-header-border-color);
                        padding: 10px;
                        overflow-y: scroll;
                        max-height: 400px;
                        width: 100%;
                        direction: ltr;
                        background: #030722;
                        color: #80deea;
                        border-radius: 7px;
                    }

                    .configure-console pre {
                        margin: 0;
                        white-space: pre-wrap;
                        overflow-wrap: break-word;
                        font-family: monospace;
                    }
                </style>
                <div class="configure-console">
                    <pre id="log-body"></pre>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
if (file_exists(__DIR__ . DS . "$activeTab.php")) {
    require_once "$activeTab.php";
}
?>

<script>
    var activeTab = "<?= $activeTab ?>";
</script>