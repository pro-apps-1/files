<style>
    .custom-card {
        display: flex;
        flex-direction: column;
        justify-content: space-around;
    }

    .card {
        position: relative;
    }

    .widget-title {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 15px;
    }

    .widget-icon {
        line-height: 15px;
    }
</style>
<?php if ($userRole == "admin") { ?>
    <div class="row mt-2 mb-2 g-2">
        <div class="col-lg-6 mb-2">
            <?php include "subs.php" ?>
            <?php if ($userRole == "admin") { ?>
                <?php include "resellers.php" ?>
                <?php include "servers.php" ?>
            <?php } ?>

        </div>
        <div class="col-lg-6">
            <div class="card mb-2">
                <div class="card-header border-0 text-muted">
                    <div class="d-flex align-items-center">
                        <?= inlineIcon("users fs-5 me-2") ?>
                        <h6 class="mb-0 fw-bold"> مشترکین ثبت شده ۳۰ روز گذشته</h6>
                    </div>
                </div>
                <div class="card-body">

                    <canvas id="subs-chart" style="width:100%;height: 280px;"></canvas>
                </div>
            </div>
            <?php if ($userRole == "admin") { ?>
                <div class="card">
                    <div class="card-header border-0 text-muted">
                        <div class="d-flex justify-content-between align-items-center ">
                            <h6 class="mb-0 fw-bold">لیست مشترکین منقضی شونده</h6>
                            <select style="width:120px" id="expiry_type" class="form-select form-select-sm">
                                <option value="today">امروز</option>
                                <option value="3_days">سه روز آینده</option>
                                <option value="this_week">این هفته</option>
                            </select>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <table id="subs-table" class="table" style="width: 100%;">
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
<?php } else { ?>
    <div class="row mt-2 mb-2 g-2">
        <div class="col-lg-12 mb-2">
            <?php include "subs.php" ?>
        </div>
        <div class="col-lg-6">
            <div class="card mb-2">
                <div class="card-header border-0">
                    مشترکین ثبت شده ۳۰ روز گذشته
                </div>
                <div class="card-body">
                    <canvas id="subs-chart" style="width:100%;height: 290px;"></canvas>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center ">
                        <div>لیست مشترکین منقضی شونده</div>
                        <select style="width:120px" id="expiry_type" class="form-select form-select-sm">
                            <option value="today">امروز</option>
                            <option value="3_days">سه روز آینده</option>
                            <option value="this_week">این هفته</option>
                        </select>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table id="subs-table" class="table" style="width: 100%;">
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<script>
    var subsMonth = <?= json_encode($subsMonth) ?>;
</script>