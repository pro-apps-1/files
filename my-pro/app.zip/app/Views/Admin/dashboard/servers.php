<div class="card">
    <div class="card-header border-0 text-muted">
        <div class=" d-flex align-items-center">
            <?= inlineIcon("server fs-5 me-2") ?>
            <h6 class="mb-0 fw-bold">سرورها</h6>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <div class="text-center mb-1">
                    <a href="<?= adminBaseUrl("servers") ?>" class="card">
                        <div class="card-body">
                            <h6 class="widget-title mb-3">کل سرورها</h6>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="fw-bold mb-0 text-primary"><?= $totalData["servers"]["all"] ?></h5>
                                <span class="widget-icon fs-3 text-primary">
                                    <?= inlineIcon("server") ?>
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="text-center mb-1">
                    <a href="<?= adminBaseUrl("servers") ?>" class="card">
                        <div class="card-body">
                            <h6 class="widget-title mb-3">سرورهای فعال</h6>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="fw-bold mb-0 text-success"><?= $totalData["servers"]["active"] ?></h5>
                                <span class="widget-icon fs-3 text-success">
                                    <?= inlineIcon("server") ?>
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="text-center mb-2 mb-lg-0 ">
                    <a href="<?= adminBaseUrl("servers") ?>" class="card">
                        <div class="card-body">
                            <h6 class="widget-title mb-3">سرورهای غیر فعال</h6>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="fw-bold mb-0 text-danger"><?= $totalData["servers"]["inActive"] ?></h5>
                                <span class="widget-icon fs-3 text-danger">
                                    <?= inlineIcon("ban") ?>
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-lg-8 col-sm-8">
                <div style="overflow-x: auto;gap: 5px;height:283px;padding-left:12px;padding-right:12px">
                    <div class="row">
                        <?php
                        $onlineSubs = $totalData["servers"]["onlineSubs"];
                        if ($onlineSubs) {
                            foreach ($onlineSubs as $server) {
                        ?>
                                <div class="col-lg-6 mb-2">
                                    <div class="card">
                                        <div class="card-header">
                                            <div class="d-flex justify-content-between align-items-center ">
                                                <div> سرور: <?= $server->name ?></div>
                                                <a data-bs-toggle="tooltip" href="<?= adminBaseUrl("servers/$server->id/settings") ?>" aria-label="اطلاعات بیشتر">
                                                    <i class="far fa-square-arrow-up-right icon"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="small text-muted">تعداد مشترکین آنلاین</div>
                                                <h6 class="mb-0 badge bg-primary"> <?= $server->total_online ?> مشترک</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>