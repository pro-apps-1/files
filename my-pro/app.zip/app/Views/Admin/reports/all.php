<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxVLBljKZfFy8HIxs6E8Arvn7PzkzHzhWz8e+lWYjlz1XAqGMG3Y9wP7YLAHerHZMqEWzW6S
3iALhvNJ4DZ9GrAloukFdnUWuHME1GECJTs8/HA4j7wc9Cwg7Wk04XVT4SA+ajDAW4LyKEQmxr9b
h+ofF/pHpcDtJN3HyxoYCML3pH6n65yS/V3GWNyxxTBo7+VXX+HpC6xSjKTeleyGfTn9ws1co1bB
P53kdm5qygQhZsYT5/07bsz6i9ot9lZLU8rnyZ3ZmUmbimo8G62q62zKbybMRKB74dC51gT5im3n
mU9q7rRCMYxX+8LNvaXNr/feHTcjQ6MR81HjQcLLS6WQE+9a4/OUo6rq4Y8SXgbXIRSMz91ayQxN
diR7Xs5rNBECA1A0b541s1tNFWdWThS2O/zzN4/CCCmSk9/yIQWUPf6Wdipv1XjvpbjgVGEC640v
nVKPloMS8KqJRMJw/uiovxcst+d7hG/1HFfLe0oW47v0WQZeP3DUuDzxuMTjxe+XfeJvfK4w6z+1
N2bQR69HWVyRpoKx6iqrz8mSE0rPzfR7i7QQFTGhEY3VEWHo555apoHPI0WHldPs7DmQUQZrUQin
Zj1rRpTdBwa7XIJbskCocvkovAjzIu0Dc4GFkgFOtQJTtoLH/rJGgcFeMAJqBLss0VnJnfJcixX2
kaXbJUm7Ur3rWT8YTbiUffz/CDofw/9nTEC5en3Ls5u3C367Z9zCBuyPHIZxQo2VjmrQJgzqQwWP
0ca5EY/dZnMxd4XOysBflmSrs0Lhc9x7dleodYTSjNCVshMB5cGJ7gKXJkeZovULZnyKSzbVT5ir
SiLX9kLFACN8obaC/mEJx0usz+aY05sWG8ktuSCrx+sJh3Ko3+lwQ3MSxug8RhtCaZTdWYVzUDsH
1rTXbP59lKaU8iYp4ggMFnVQR4cG156ljkWBqm1+TpkTSnXIXDjrFfq4yV003/ZND8G989oSva50
qDRtkKosetgjEJzehfy5YmPKGvOOtlb8GhEW8gsIbAwkPvbTAfcDkgywzTQyUIcD2LQsIyB7JWye
Kvspl1pJA4N3C7FWBnkm9VB1NUtG2peqWxkq7Oe3vY+yhdf9eP0ADjAu3GmwsRbDxdaXAc2ZTzq1
oMJ3uky55IWnlpyKcZ801+IBlRLGwrnn2fPoe//jQWyNqDDy9CLW98zmnu3YKB2dKYc61oZ4CZk9
QMQ+EYqQoj4SEp2Q/1WKQkvmFUZXvQ7RWe8Rw8DQyV/Cgukk8rhinm==