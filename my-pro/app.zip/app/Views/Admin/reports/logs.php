<div class="card">
    <div class="card-body p-0 pt-3">
        <div class="card-datatable table-responsive">
            <table id="logs-table" class="table table-striped" style="width: 100%;">
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>