</style>
<div class="custome-breadcrumb">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("dashboard") ?>">داشبورد</a></li>
            <li class="breadcrumb-item">گزارشات</li>
            <li class="breadcrumb-item active">گزارشات کلی</li>
        </ol>
    </nav>

</div>

<ul class="nav nav-tabs mb-3">
    <li class="nav-item">
        <a class="nav-link <?= $activeTab == "all" ? "active" : "" ?>" href="<?= adminBaseUrl("reports") ?>">
            <?= inlineIcon("chart-pie-simple") ?>
            گزارش کلی
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeTab == "credits" ? "active" : "" ?>" href="<?= adminBaseUrl("reports/credits") ?>">
            <?= inlineIcon("credit-card") ?>
            تراکنش های مالی
        </a>
    </li>
    <?php if ($userRole == "admin") { ?>
        <li class="nav-item">
            <a class="nav-link <?= $activeTab == "logs" ? "active" : "" ?>" href="<?= adminBaseUrl("reports/logs") ?>">
                <?= inlineIcon("list-check") ?>
                لاگ های کاربران
            </a>
        </li>
    <?php } ?>
</ul>


<?php
if (file_exists(__DIR__ . DS . "$activeTab.php")) {
    require_once "$activeTab.php";
}
?>