<?php
$mainAppEnqueue = getMainAppEnqueue();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" data-bs-preset="<?= $activeColor ?>" data-bs-theme="<?= $activeTheme ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <title><?= $pageTitle ?></title>
    <!-- Icons -->
    <link rel="icon" type="image/x-icon" href="<?= $siteLogo ?>">
    <link rel="stylesheet" href="<?= assets("fonts/fontawsome.css") ?>" />
    <link rel="stylesheet" href="<?= assets("fonts/webfont.css") ?>" />
    <?= headerFiles() ?>
    <link rel="stylesheet" href="<?= assets("css/sweetalert2.css") ?>">
    <link rel="stylesheet" href="<?= $mainAppEnqueue["app_css_url"] ?>">
    <link rel="stylesheet" href="<?= $mainAppEnqueue["preset_css_url"] ?>">

    <script src="<?= assets("vendor/jquery/jquery.js") ?>"></script>
    <script>
        var base_url = "<?= baseUrl() ?>";
        var admin_base_url = "<?= adminBaseUrl() ?>";
        var user_role = "<?= !empty($userRole)      ? $userRole : "" ?>";
        var user_credit = <?= !empty($userCredit)      ? $userCredit : 0 ?>;
        var activePage = "<?= !empty($activePage)    ? $activePage : "" ?>";
        var activeTheme = "<?= $activeTheme ?>";


        var adminBaseUrl = function(seg = "") {
            return admin_base_url + seg;
        };

        var baseUrl = function(seg = "") {
            return base_url + seg;
        };

        var assets = function(seg = "") {
            return baseUrl("assets/" + seg);
        };
    </script>
    <?php if (!empty($licenseData)) { ?>
        <script>
            var licensePlan = "<?= $licenseData["plan_name"] ?>";
            var licenseData = <?= json_encode($licenseData) ?>;
        </script>
    <?php } ?>
</head>

<body class="d-flex flex-column h-100">