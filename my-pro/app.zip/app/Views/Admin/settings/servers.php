<?php
$serversToken           = getArrayValue($settings, "servers_token", "");
$calcTraffic            = getArrayValue($settings, "servers_calc_traffic", "");
$onlineLimit            = getArrayValue($settings, "servers_online_limit", "");
$deleteSubsLog          = getArrayValue($settings, "servers_delete_subs_logs_minute", "");

$checkFiltering         = getArrayValue($settings, "servers_check_filtering", []);
$filteringEnabled       = getArrayValue($checkFiltering, "enabled", "");
$filteringHours         = getArrayValue($checkFiltering, "hours", "");

$checkAvailability      = getArrayValue($settings, "servers_check_availability", []);
$availabilityEnabled    = getArrayValue($checkAvailability, "enabled", "");
$availabilityHours      = getArrayValue($checkAvailability, "hours", "");

$serversSSH             = getArrayValue($settings, "servers_ssh", []);
$sshPort                = getArrayValue($serversSSH, "port", "");
$ssghUdpPort            = getArrayValue($serversSSH, "udp_port", "");
$sshBanner              = getArrayValue($serversSSH, "banner", "");
$sshTrafficCoefficient  = getArrayValue($serversSSH, "traffic_coefficient", 1);

$serversV2ray           = getArrayValue($settings, "servers_v2ray", []);
$vlessTcpPort           = getArrayValue($serversV2ray, "vless_tcp_port", "");
$vmessTcpPort           = getArrayValue($serversV2ray, "vmess_tcp_port", "");
$V2TrafficCoefficient   = getArrayValue($serversV2ray, "traffic_coefficient", 1);
$v2ConfigsSuffix        = getArrayValue($serversV2ray, "configs_suffix", "");

$serversOpenvpn         = getArrayValue($settings, "servers_openvpn", []);
$serversOvpnPort        = getArrayValue($serversOpenvpn, "port", "");
if (empty($serversToken)) {
    $serversToken = generatePassword(30);
}
?>

<style>
    .msg-box {
        position: relative;
    }

    .msg-box textarea {
        padding-bottom: 22px;
        scroll-padding: 22px;
    }

    .msg-box .btn-vars {
        position: absolute;
        bottom: 2px;
        right: 5px;
    }

    .msg-box button {
        font-size: 11px;
        border: 0;
    }
</style>

<form id="settings-form" method="post" action="<?= adminBaseUrl("ajax/settings/servers") ?>">
    <div class="row g-2">
        <div class="col-lg-8">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card mb-2">
                        <div class="card-header">
                            تنظیمات عمومی
                        </div>
                        <div class="card-body">
                            <div class="form-group mb-2">
                                <label for="password" class="form-label">توکن سرورها</label>
                                <input type="text" readonly value="<?= $serversToken ?>" id="servers-token" name="servers[token]" minlength="30" class="form-control" placeholder="توکن سرورها را وارد کنید" required>
                            </div>
                            <div class="form-group mb-2">
                                <label class="form-label">محسابه ترافیک سرورها</label>
                                <select name="servers[calc_traffic]" class="form-select" required>
                                    <option value="">انتخاب کنید</option>
                                    <option value="1" <?= $calcTraffic == "1" ? "selected" : "" ?>>بلی</option>
                                    <option value="0" <?= $calcTraffic == "0" ? "selected" : "" ?>>خیر</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <?php if (in_array("v2ray", $licenseData["active_protocols"])) { ?>
                        <div class="card">
                            <div class="card-header">
                                تنظیمات <img src="<?= assets("images/protocol/v2ray.png") ?>" width="20" />
                            </div>
                            <div class="card-body">

                                <div class="form-group mb-2">
                                    <label class="form-label">vlss tcp port</label>
                                    <div class="input-group">
                                        <input value="<?= $vlessTcpPort ?>" type="number" minlength="2" name="servers[v2ray][vless_tcp_port]" class="form-control" placeholder="vlss tcp port" required />
                                        <button class="btn btn-primary btn-generate-port" data-protocol="v2ray" type="button">
                                            <?= inlineIcon("key") ?>
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <label class="form-label">vmess tcp port</label>
                                    <div class="input-group">
                                        <input value="<?= $vmessTcpPort ?>" type="number" minlength="2" name="servers[v2ray][vmess_tcp_port]" class="form-control" placeholder="vmess tcp port" required />
                                        <button class="btn btn-primary btn-generate-port" data-protocol="v2ray" type="button">
                                            <?= inlineIcon("key") ?>
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <label class="form-label">ضریب محاسبه ترافیک</label>
                                    <input value="<?= $V2TrafficCoefficient ?>" type="number" name="servers[v2ray][traffic_coefficient]" min="0.1" class="form-control" placeholder="ضریب محاسبه ترافیک" required />
                                </div>
                                <div class="form-group mb-1">
                                    <label class="form-label">پسوند کانفیگ ها</label>
                                    <input value="<?= $v2ConfigsSuffix ?>" type="text" name="servers[v2ray][configs_suffix]" class="form-control" placeholder="پسوند کانفیگ ها را وارد کنید" required />
                                </div>
                                <div class="text-body-tertiary mb-1">
                                    <i class="far fa-info-circle icon "></i>
                                    <small>
                                        متنی که پس از نام کاربری نمایش داده میشود. مثلا
                                        example-vless-[rocket-ssh]
                                    </small>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="col-lg-6">
                    <div class="card mb-2">
                        <div class="card-header">
                            تنظیمات <img src="<?= assets("images/protocol/ssh.png") ?>" width="50" />
                        </div>
                        <div class="card-body">
                            <div class="form-group mb-1">
                                <label class="form-label">پورت SSH</label>
                                <input value="<?= $sshPort ?>" type="number" minlength="2" name="servers[ssh][port]" class="form-control" placeholder="پورت ssh" required />
                            </div>
                            <div class="form-group mb-1">
                                <label class="form-label">پورت UDP (تماس)</label>
                                <input value="<?= $ssghUdpPort ?>" type="number" minlength="4" name="servers[ssh][udp_port]" class="form-control" placeholder="پورت udp" required />
                            </div>
                            <div class="form-group mb-2">
                                <label class="form-label">ضریب محاسبه ترافیک</label>
                                <input value="<?= $sshTrafficCoefficient ?>" type="number" name="servers[ssh][traffic_coefficient]" min="0.1" class="form-control" placeholder="ضریب محاسبه ترافیک" required />
                            </div>
                            <div class="form-group">
                                <label class="form-label">ایجاد بنر کاربران</label>
                                <select name="servers[ssh][banner]" class="form-select" required>
                                    <option value="">انتخاب کنید</option>
                                    <option value="1" <?= $sshBanner == "1" ? "selected" : "" ?>>بلی</option>
                                    <option value="0" <?= $sshBanner == "0" ? "selected" : "" ?>>خیر</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <?php if (in_array("openvpn", $licenseData["active_protocols"])) { ?>
                        <div class="card">
                            <div class="card-header">
                                تنظیمات <img src="<?= assets("images/protocol/openvpn.png") ?>" width="80" />
                            </div>
                            <div class="card-body">
                                <div class="form-group mb-2">
                                    <label class="form-label">پورت OPENVPN</label>
                                    <input value="<?= $serversOvpnPort ?>" type="number" minlength="2" name="servers[openvpn][port]" class="form-control" placeholder="پورت openvpn" required />
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border mb-2">
                <div class="card-body">
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" <?= $filteringEnabled ? "checked" : "" ?> name="servers[check_filtering][enabled]" value="1" type="checkbox" role="switch">
                        <label class="form-check-label">چک کردن وضعیت فیلترینگ (check-host.net)</label>
                    </div>
                    <div class="form-group">
                        <label>چک کردن هر</label>
                        <div class="input-group mb-3">
                            <input type="number" value="<?= $filteringHours ?>" name="servers[check_filtering][hours]" min="1" max="24" class="form-control" placeholder="یک عدد بین ۱ تا ۲۴ وارد کنید" required />
                            <span class="input-group-text" id="basic-addon1">ساعت یکبار</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card border mb-2">
                <div class="card-body">
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" <?= $availabilityEnabled ? "checked" : "" ?> name="servers[check_availability][enabled]" value="1" type="checkbox" role="switch">
                        <label class="form-check-label">چک کردن در دسترس بودن سرورها</label>
                    </div>
                    <div class="form-group">
                        <label>چک کردن هر</label>
                        <div class="input-group mb-3">
                            <input type="number" value="<?= $availabilityHours ?>" name="servers[check_availability][hours]" min="0.50" max="24" class="form-control" placeholder="یک عدد بین ۱ تا ۲۴ وارد کنید" required />
                            <span class="input-group-text">ساعت یکبار</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card border mb-2">
                <div class="card-body">
                    <div class="form-group">
                        <label>حذف لاگ ورود و خروج از</label>
                        <div class="input-group mb-3">
                            <input type="number" value="<?= $deleteSubsLog ?>" name="servers[delete_subs_logs_minute]" min="1" class="form-control" placeholder="یک عدد بین بزرگتر از ۱ وارد کنید" required />
                            <span class="input-group-text">دقیقه قبل</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card border mb-2">
                <div class="card-body">
                    <div class="form-check form-switch">
                        <input class="form-check-input" <?= $onlineLimit ? "checked" : "" ?> name="servers[online_limit]" value="1" type="checkbox" role="switch">
                        <label class="form-check-label">اعمال محدودیت کاربران آنلاین سرورها</label>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body text-center">
                    <button type="submit" class="btn btn-primary btn-float-icon">
                        <i class="far fa-save icon "></i> ذخیره
                    </button>
                </div>
            </div>
        </div>
    </div>

</form>