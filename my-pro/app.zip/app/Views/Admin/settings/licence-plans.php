<div class="row srow-cols-1 row-cols-md-5 mb-3 text-center">
    <div class="col h-100">
        <div class="card h-100 rounded-3 shadow-sm">
            <div class="card-header py-3">
                <h4 class="my-0 fw-normal">رایگان</h4>
            </div>
            <div class="card-body">
                <h1 class="card-title pricing-card-title">رایگان</h1>
                <ul class="list-unstyled mt-3 mb-4">
                    <li>تعداد سرور: 4</li>
                    <li>تعداد مشترک: 150</li>
                    <li>تعداد مدیر: 3</li>
                    <li>تعداد نماینده: 3</li>
                </ul>
                <button type="button" class="w-100 btn btn-lg btn-outline-primary">
                    مدت اعتبار 5 روز
                </button>
            </div>
        </div>
    </div>
    <div class="col h-100">
        <div class="card h-100 rounded-3 shadow-sm" style="border-color: #CD7F32;">
            <div class="card-header py-3" style="background-color: #CD7F32;color: #fff;">
                <h4 class="my-0 fw-normal">برنزی</h4>
            </div>
            <div class="card-body">
                <h1 class="card-title pricing-card-title">30<small class="text-body-secondary fw-light"> دلار</small></h1>
                <ul class="list-unstyled mt-3 mb-4">
                    <li>تعداد سرور: 4</li>
                    <li>تعداد مشترک: 150</li>
                    <li>تعداد مدیر: 3</li>
                    <li>تعداد نماینده: 3</li>
                </ul>
                <button type="button" class="w-100 btn btn-lg btn-outline-primary">
                    مدت اعتبار نامحدود
                </button>
            </div>
        </div>
    </div>

    <div class="col h-100">
        <div class="card h-100 rounded-3 shadow-sm" style="border-color: #C0C0C0;">
            <div class="card-header py-3" style="background-color: #C0C0C0;color: #fff;">
                <h4 class="my-0 fw-normal">نقره ای</h4>
            </div>
            <div class="card-body">
                <h1 class="card-title pricing-card-title">50<small class="text-body-secondary fw-light"> دلار</small></h1>
                <ul class="list-unstyled mt-3 mb-4">
                    <li>تعداد سرور: 8</li>
                    <li>تعداد مشترک: 320</li>
                    <li>تعداد مدیر: 7</li>
                    <li>تعداد نماینده: 7</li>
                </ul>
                <button type="button" class="w-100 btn btn-lg btn-outline-primary">
                    مدت اعتبار نامحدود
                </button>
            </div>
        </div>
    </div>
    <div class="col h-100">
        <div class="card h-100 rounded-3 shadow-sm" style="border-color: #FFD700;">
            <div class="card-header py-3" style="background-color: #FFD700;color: #000;">
                <h4 class="my-0 fw-normal">طلایی</h4>
            </div>
            <div class="card-body">
                <h1 class="card-title pricing-card-title">75<small class="text-body-secondary fw-light"> دلار</small></h1>
                <ul class="list-unstyled mt-3 mb-4">
                    <li>تعداد سرور: 12</li>
                    <li>تعداد مشترک: 550</li>
                    <li>تعداد مدیر: 10</li>
                    <li>تعداد نماینده: 10</li>
                </ul>
                <button type="button" class="w-100 btn btn-lg btn-outline-primary">
                    مدت اعتبار نامحدود
                </button>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="card h-100 rounded-3 shadow-sm" >
            <div class="card-header py-3">
                <h4 class="my-0 fw-normal">برلیان</h4>
            </div>
            <div class="card-body">
                <h2 class="card-title mb-0 pricing-card-title">120<small class="text-body-secondary fw-light"> دلار</small></h2>
                <ul class="list-unstyled mt-3 mb-4">
                    <li>تعداد سرور: نامحدود</li>
                    <li>تعداد مشترک: نامحدود</li>
                    <li>تعداد مدیر: نامحدود</li>
                    <li>تعداد نماینده: نامحدود</li>
                    <li>اپ اندروید</li>
                    <li>ربات تلگرام</li>
                    <li>به زودی ...</li>
                </ul>
                
            </div>
        </div>
    </div>

</div>