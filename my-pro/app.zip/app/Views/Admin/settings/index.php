<div class="custome-breadcrumb">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("dashboard") ?>">داشبورد</a></li>
            <li class="breadcrumb-item active">تنظیمات</li>
        </ol>
    </nav>
</div>

<div class="row">

    <div class="col-lg-10">
        <?php
        if (file_exists(__DIR__ . DS . "$activeTab.php")) {
            require_once "$activeTab.php";
        }
        ?>
    </div>
    <div class="col-lg-2">
        <div class="card">
            <div class="card-body">
                <ul class="nav nav-pills flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "license" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/license") ?>">
                            <?= inlineIcon("key") ?>
                            لایسنس
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "main" ? "active" : "" ?>" href="<?= adminBaseUrl("settings") ?>">
                            <?= inlineIcon("cog") ?>
                            تنظیمات اصلی
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "servers" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/servers") ?>">
                            <?= inlineIcon("server") ?>
                            تنظیمات سرور
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "categories" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/categories") ?>">
                            <?= inlineIcon("layer-group") ?>
                            دسته بندی ها
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "domains" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/domains") ?>">
                            <?= inlineIcon("globe") ?>
                            تنظیمات دامنه ها
                        </a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "messages" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/messages") ?>">
                            <?= inlineIcon("message") ?>
                            پیامها
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "telegram-bot" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/telegram-bot") ?>">
                            <?= inlineIcon("message-bot") ?>
                            ربات تلگرام
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "backup" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/backup") ?>">
                            <?= inlineIcon("database") ?>
                            پشتیبان گیری
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeTab == "users_panel" ? "active" : "" ?>" href="<?= adminBaseUrl("settings/users-panel") ?>">
                            <?= inlineIcon("users") ?>
                            پنل کاربران
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" target="_blank" href="https://nowpayments.io/donation/rocketpanel">
                            <?= inlineIcon("donate") ?>
                            هدیه به توسعه دهنده
                        </a>
                    </li>

                </ul>
            </div>
        </div>

    </div>
</div>
<script>
    var activeTab = "<?= $activeTab ?>"
</script>