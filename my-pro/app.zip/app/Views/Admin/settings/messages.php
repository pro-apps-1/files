<?php
$smsToken               = getArrayValue($settings, "sms_token", "");
$subsRegister           = getArrayValue($settings, "subs_register_sms", []);
$subsExpiration         = getArrayValue($settings, "subs_expiration_sms", []);

$subsRegisterEnabled    = getArrayValue($subsRegister, "enabled", 0);
$subsRegisterText       = getArrayValue($subsRegister, "text", "");

$subsExpirationEnabled  = getArrayValue($subsExpiration, "enabled", 0);
$subsExpirationText     = getArrayValue($subsExpiration, "text", "");

$subsRegisterVars = [
    "تاریخ ثبت نام" => "[reg-date]",
    "اطلاعات کانفیگ" => "[config-values]",
];

$subsExpiryVars = [
    "نام کاربری"    => "[username]",
    "مانده اعتبار"  => "[]",
];

$bannerTextArr  = getArrayValue($settings, "banner_text", []);
$bannerText     = getArrayValue($bannerTextArr, "text", "");
$bannerTextPos  = getArrayValue($bannerTextArr, "position", "top");
?>

<style>
    .msg-box {
        position: relative;
    }

    .msg-box textarea {
        padding-bottom: 22px;
        scroll-padding: 22px;
    }

    .msg-box .btn-vars {
        position: absolute;
        bottom: 2px;
        right: 5px;
    }

    .msg-box button {
        font-size: 11px;
        border: 0;
    }
</style>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                ارسال پیامک به کابران
            </div>
            <div class="card-body">
                <form id="sms-form" method="post" action="<?= adminBaseUrl("ajax/settings/messages/sms") ?>">
                    <div class="form-group">
                        <label>توکن سرویس دهنده</label>
                        <input type="text" value="<?= $smsToken ?>" class="form-control" name="sms_token" placeholder="توکن سرویس دهنده ارسال پیام را وارد کنید" required />
                    </div>


                    <div class="form-group">
                        <div class="form-check">
                            <input class="form-check-input" name="subs_register_sms[enabled]" type="checkbox" value="1" <?= $subsRegisterEnabled ? "checked" : "" ?>>
                            <label class="form-check-label">
                                ارسال پیامک ثبت نام به مشترکین
                            </label>
                        </div>
                        <div class="msg-box">
                            <textarea class="form-control" rows="3" name="subs_register_sms[text]" placeholder="متن پیامک..."><?= $subsRegisterText ?></textarea>
                            <div class="btn-vars">
                                <?php foreach ($subsRegisterVars as $name => $value) { ?>
                                    <button class="btn-variable" data-key="<?= $value ?>"><?= $name ?></button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-check">
                            <input class="form-check-input" name="subs_expiration_sms[enabled]" type="checkbox" value="1" <?= $subsExpirationEnabled ? "checked" : "" ?>>
                            <label class="form-check-label">
                                ارسال پیامک منقضی شدن به مشترکین
                            </label>
                        </div>
                        <div class="msg-box">
                            <textarea class="form-control" rows="3" name="subs_expiration_sms[text]" placeholder="متن پیامک..."><?= $subsExpirationText ?></textarea>
                            <div class="btn-vars">
                                <?php foreach ($subsExpiryVars as $name => $value) { ?>
                                    <button class="btn-variable" data-key="<?= $value ?>"><?= $name ?></button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-float-icon">
                            <?= inlineIcon("save") ?>
                            ذخیره
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if ($licenseData["plan_name"] == "brillant") { ?>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    متن اختصاصی بنر مشترکین (لاگ نت مود)
                </div>
                <div class="card-body">
                    <form id="banner-text-form" method="post" action="<?= adminBaseUrl("ajax/settings/messages/banner-text") ?>">
                        <div class="form-group">
                            <label>متن بنر</label>
                            <textarea class="form-control" name="text" rows="4" placeholder="متن بنر را وارد کنید..."><?= $bannerText ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>جایگاه بنر</label>
                            <select class="form-select" name="position">
                                <option value="top" <?= $bannerTextPos == "top" ? "selected" : "" ?>>بالای متن اصلی</option>
                                <option value="bottom" <?= $bannerTextPos == "bottom" ? "selected" : "" ?>>پایین متن اصلی</option>
                            </select>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-float-icon">
                                <?= inlineIcon("save") ?>
                                ذخیره
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php } ?>
</div>