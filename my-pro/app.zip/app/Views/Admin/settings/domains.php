<div class="card mb-3">
    <div class="card-header">
        <h6>تنظیمات کلودفلر</h6>
    </div>
    <div class="card-body">
        <form id="cloud-form" method="post" action="<?= adminBaseUrl("ajax/settings/cloudflare") ?>">
            <div class="row">
                <div class="col-lg-5">
                    <div class="form-group mb-0">
                        <label>توکن کلود فلر </label>
                        <input type="text" required name="token" value="<?= $clToken ?>" minlength="20" class="form-control text-end dir-ltr" placeholder="توکن کلودفلر را وارد کنید..." required>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="form-group mb-0">
                        <label> زمان Time To Live (TTL)</label>
                        <select class="form-select" name="ttl" required>
                            <option value="1"       <?= $clTtl == "1" ? "selected" : "" ?>>اتوماتیک</option>
                            <option value="60"      <?= $clTtl == "60" ? "selected" : "" ?>>1 دقیقه</option>
                            <option value="120"     <?= $clTtl == "120" ? "selected" : "" ?>>2 دقیقه</option>
                            <option value="300"     <?= $clTtl == "300" ? "selected" : "" ?>>5 دقیقه</option>
                            <option value="600"     <?= $clTtl == "600" ? "selected" : "" ?>>10 دقیقه</option>
                            <option value="900"     <?= $clTtl == "900" ? "selected" : "" ?>>15 دقیقه</option>
                            <option value="1800"    <?= $clTtl == "1800" ? "selected" : "" ?>>30 دقیقه</option>
                        </select>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary btn-float-icon">
                            <?= inlineIcon("save") ?>
                            ذخیره
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="row">

    <div class="col-lg-4">

        <div class="card">
            <div class="card-header">
                <h6>فرم افزودن ساب دامنه</h6>
            </div>
            <div class="card-body">

                <form id="domains-form" method="post" action="<?= adminBaseUrl("ajax/domains") ?>">
                    <div class="form-group">
                        <label>آدرس ساب دامنه</label>
                        <input type="text" name="subdomain" class="form-control text-end dir-ltr" placeholder="e.g. ssh.example.com" required>
                    </div>
                    <div class="form-group">
                        <label>Zone ID کلودفلر</label>
                        <input type="text" name="zone_id" class="form-control text-end dir-ltr" placeholder="e.g. baa602s3ac5c16s152a2d91f3274dcdb" <?= $clToken ? "required" : "" ?>>
                    </div>
                    <div class="form-group">
                        <label>انتخاب دسته بندی</label>
                        <select class="form-select" name="category" required>
                            <?php
                            if ($categories) {
                                foreach ($categories as $category) {
                            ?>
                                    <option value="<?= $category->id ?>"><?= $category->name ?></option>
                            <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="text-body-tertiary mb-1">
                        <?= inlineIcon("info-circle") ?>
                        <small>
                            در صورتی که میخواهید به صورت خودکار آیپی سرورها در سامانه کلودفلر ثبت یا حذف شود وارد کردن این قسمت الزامی است.
                        </small>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary btn-float-icon">
                            <?= inlineIcon("save") ?>
                            افزودن
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h6>لیست ساب دامنه ها</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="domains-table" class="table table-striped" style="width: 100%;">
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>