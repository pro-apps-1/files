<?php
$currentPlan        = $licenseData["plan_name"];
$expiredTime        = $licenseData["expire_time"];
$isActive           = $licenseData["is_active"];
$isExpired          = $licenseData["is_expired"];
$licenseType        = $licenseData["license_type"];
$activeProtocols    = $licenseData["active_protocols"];
$price              = $licenseData["price"];

?>

<?php if (!empty($licenseType)) { ?>
    <table class="table table-striped text-center">
        <tr>
            <td colspan="2">
                <div class="text-center my-2">
                    <h4 class="fw-bold mb-0 text-gray">
                        پلن فعلی شما
                        <span class="text-<?= $currentPlan ?>"><?= translateLicense($currentPlan) ?></span>
                        است
                    </h4>
                </div>
            </td>
        </tr>
        <tr>
            <td width="40%">نوع لایسنس</td>
            <td><?= $licenseType == "lifetime" ? "لایف تایم" : "ماهیانه" ?></td>
        </tr>
        <tr>
            <td>وضعیت لایسنس</td>
            <td><?= $isActive ? "<span class='badge bg-success'>فعال</span>" : "<span class='badge bg-danger'>غیر فعال</span>" ?></td>
        </tr>
        <?php if ($licenseType == "monthly") { ?>
            <tr>
                <td>زمان انقضاء</td>
                <td>
                    <?php
                    echo $licenseData['expire_date'];
                    if ($isExpired==1) {
                        echo "<small class='ms-2 badge bg-warning'>منقضی شده</small>";
                    } else {
                        echo " <small>( " . translateDiffTime($expiredTime) . " )</small>";
                    }
                    ?>
                </td>
            </tr>
        <?php } ?>
        <tr>
            <td>پروتکل SSH</td>
            <td>
                <?= inlineIcon("check", "text-success fw-bold fs-4") ?>
            </td>
        </tr>
        <tr>
            <td>پروتکل OPENVPN</td>
            <td>
                <?=
                in_array("openvpn", $activeProtocols) ?
                    inlineIcon("check", "text-success fw-bold fs-4") :
                    inlineIcon("close", "text-danger fw-bold fs-4")
                ?>
            </td>
        </tr>
        <tr>
            <td>پروتکل V2RAY</td>
            <td>
                <?=
                in_array("v2ray", $activeProtocols) ?
                    inlineIcon("check", "text-success fw-bold fs-4") :
                    inlineIcon("close", "text-danger fw-bold fs-4")
                ?>
            </td>
        </tr>
        <tr>
            <td>ربات فروش تلگرام</td>
            <td>
                <?= inlineIcon("close", "text-danger fw-bold fs-4") ?>
            </td>
        </tr>
        <?php if ($licenseType == "monthly") { ?>
            <tr>
                <td>هزینه تمدید برای یک ماه</td>
                <td><?= $licenseData["price"] ?> تتر</td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="small my-3 d-block">
                        <span><?= inlineIcon("star", "text-danger") ?></span>
                        جهت تغییر پلن لایسنس خود با پشتیبانی تماس بگیرید
                        <span><?= inlineIcon("star", "text-danger") ?></span>
                    </div>
                    <!-- <div class="input-group">
                        <select class="form-select" id="month_count">
                            <?php
                            for ($i = 1; $i <= 12; $i++) {
                            ?>
                                <option value="<?= $i ?>"><?= $i ?> ماه (<?= $price * $i ?> تتر)</option>
                            <?php
                            }
                            ?>
                        </select>
                        <button id="btn-renewal" class="btn btn-primary btn-float-icon" id="">
                            <?= inlineIcon("credit-card") ?>
                            تمدید لایسنس
                        </button>
                    </div> -->
                </td>
            </tr>
        <?php } ?>
    </table>
<?php } else { ?>
    <div class="text-danger mt-2">
        هیچ لایسنس فعالی بر روی دامنه شما ثبت نشده است. جهت دریافت لایسنس با پشتیبانی تماس بگیرید
    </div>
<?php } ?>

