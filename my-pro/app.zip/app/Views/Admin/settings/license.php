

<div class="card">
    <div class="card-body">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <br />
                <p>
                    لایسنس شما روی آدرس سایت شما ذخیره شده است . برای مشاهده اطلاعات لایسنس درخواست دهید.
                </p>
                <div class="text-center mb-3">
                    <button id="btn-req-license-details" class="btn btn-success btn-float-icon">
                        <?= inlineIcon("save") ?>
                        درخواست اطلاعات لایسنس
                    </button>
                </div>
                <div id="license-info-cont" class="text-center mt-3 d-block">
                    <?php include "license-info.php" ?>
                </div>
               
            </div>
        </div>
    </div>
</div>