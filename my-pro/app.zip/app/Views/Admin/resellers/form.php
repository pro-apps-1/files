<?php
$userValues         = isset($userValues) ? $userValues : null;
$userId             = getArrayValue($userValues, "id");
$username           = getArrayValue($userValues, "username");
$fullname           = getArrayValue($userValues, "full_name");
$status             = getArrayValue($userValues, "status");
$unlimited          = getArrayValue($userValues, "unlimited", 0);
$protocols          = getArrayValue($userValues, "access_protocols", []);

$formMethod         = $userId ? "put" : "post";
$formAction         = $userId ? adminBaseUrl("ajax/resellers/$userId") : adminBaseUrl("ajax/resellers");
?>

<div class="modal-dialog modal-md">
    <div class="modal-content">
        <form id="user-form" method="<?= $formMethod ?>" action="<?= $formAction ?>">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?= $userId  ? "ویرایش نماینده" : "افزودن نماینده" ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="form-group mb-2">
                    <label for="username" class="form-label">نام کاربری (فقط حروف انگلیسی و اعداد)</label>
                    <input type="text" value="<?= $username ?>" name="username" class="form-control" placeholder="نام کاربری را وارد کنید" required>
                </div>

                <div class="form-group mb-2">
                    <label for="password" class="form-label">رمز عبور</label>
                    <div class="input-group">
                        <input type="text" value="" name="password" class="form-control" placeholder="رمز عبور را وارد کنید" <?= !$userId ? "required" : "" ?>>
                        <button class="btn btn-outline-primary" type="button" id="btn-generate-pass">
                            <?= inlineIcon("key") ?>
                        </button>
                    </div>
                </div>

                <div class="form-group ">
                    <label for="username" class="form-label">نام کامل</label>
                    <input type="text" value="<?= $fullname ?>" name="full_name" class="form-control" placeholder="نام کامل را وارد کنید" required>
                </div>
                <div class="form-group ">
                    <label for="username" class="form-label">دسترسی پروتکل (خالی برای همه)</label>
                    <select class="form-select" name="access_protocols[]" multiple>
                        <option value="ssh" <?= in_array("ssh", $protocols) ? "selected" : "" ?>>پروتکل SSH</option>
                        <option value="openvpn" <?= in_array("openvpn", $protocols) ? "selected" : "" ?> >پروتکل OPENVPN</option>
                        <option value="v2ray" <?= in_array("v2ray", $protocols) ? "selected" : "" ?>>پروتکل V2RAY</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="is_active" class="form-label">وضعیت</label>
                    <select class="form-select" name="status" required>
                        <option value="">انتخاب کنید</option>
                        <option value="active" <?= $status == "active" ? "selected" : "" ?>>فعال</option>
                        <option value="inactive" <?= $status == "inactive"  ? "selected" : "" ?>>غیر فعال</option>
                    </select>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="unlimited" value="" id="unlimited" <?= $unlimited ? "checked" : "" ?>>
                    <label class="form-check-label" for="unlimited">
                        نماینده نامحدود
                    </label>
                </div>
                <div class="text-body-tertiary mb-1">
                    <?= inlineIcon("info-circle") ?>
                    <small>
                        در صورتی که نماینده نامحدود تعریف شود . هیچ تراکنشی برای این نماینده ثبت نمی شود و می تواند مشترکین را به صورت دستی نیز اضافه کند.
                    </small>
                </div>

            </div>
            <div class=" modal-footer">
                <button class="btn btn-primary btn-float-icon" type="submit">
                    <?= inlineIcon("save") ?>
                    <?= $userId ? " ویرایش کاربر" : " افزودن کاربر" ?>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    var formMode = "<?= !$userId ? "add" : "edit" ?>";
    window.initResellerForm(formMode);
</script>