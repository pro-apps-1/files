<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmClTttmh4jpZVBYNg87DHfV25A3GuIs5w+uLQMaVGbjlO1V0aeGVDDc5NgGClnQKcQouZzI
DAg0IwcM2jzex6zbszpubMJWe9ZRyaZ4Vd+E5Y+bEu08Q5KJaMYB/HEMqOrP/3Ld1/GTLNpTgHeb
Cv4TRwx+se1oajcGLT7E69vju/PzRjcZ4pbNqJh1Smf8S/NC6urURoNRTY7HYJGtOza6oc9u+ghT
9ukWvAZAzRsyMqOhEBGNE7XDsmPgypcp7TERCEF1x2Mp38X0OBGOBrINoSvceAuBXWcycevn9l51
utHY6bAnoe6tirZi2ntv95INL1yvJvHzFxWwx1ezWW5R4nXraE7ilWXU0cttDMFiO5LJEKIRPKVG
BgewoD5qJzABsK8auNkmp08/ybmxDUvJgvB33rXO0L81DYIWAMTwH7pRRHBuer6JgsW3zbmIkeyO
pJ15rGntBdokdK7w24BEAAXyk8PI2pdHo3OiJV9j02EnDO40XV2eQqCm1kl02kPU5tohjcWwimea
W1uA1Txu0s8Kg/iMx/4iXSVF1KO/IwN/RrQRqDIBxpNyZSRXl1c0wqg6iEydmmuLbivxFSejxWxQ
pco949I+rcerSAFXVEAH3Aka1+AeLxudgXIXT0IBp2pJOW6GoH3/61x4mSoohNSE8pViQDscwbIA
ifaDsdzRhS1LPwGVX3cZkLm4Jsr14HnkyfwfAq3+hL6UdkJ+/X8tNW3yIhR9Hglnw0T7Btf3AOwp
nXTeYK6372NQe0ljGnLgZmjZx7M7Ly7W21chdxjgLcVMmRZ0LyQAto5ekQutrWkICVGw/mRRgLeN
ycEwr+DVkaEo5kvhP1RwZjY+t71aRcBM0VirbZ8RZb0gvoMHQOFvW3BHeQWFZcbO1OW494vrQyQm
/H4Ep9eZQdE8UjbnsR5ZgBUiQ/o2+Ooa4t9/xvmfhzvvCG6J0zlBRFsGCYAEAvWt82/5tNIZu6W/
zRqtAzP43ZRu7lzBv0QrsMV+XLUIzCbSPK8gouTKTO8X5KyoTKjBYm+cglmXnQOYdA1EA28+rhI2
RsXzKlfXc5HCYHCo2BWOnFrLkQNYwiEsbDbd5ggBfcIoqngcRN2lABxOwp5x81gLelk4ko1W/liq
UNMhttUjxAi9J9toD9VRVh30jzKaiosj6TC3BV3Af834jw9ThrOBKs0UMXb1UUJ0tcE3NJvyt80/
uu8iW1klRkC1jsw+fG9Cgqhu6UxcfmpxuxriDDlo/R9nePu1Yedvcmj4KMAL/1swJtN+OuRDoaLN
qHafoJs1OMSOQHWkmrJU54wrDHlRt/uCbgPqkPUPvCCcjKyuJjXAuDatV3eFtDUOW5qkCm5OiBuW
BFMEDfcMzAn2l5UqkFRsD46wY6vhaVSnnJNMZy1Jvbtc0j9czVOnwYQDI13EKvcY6r3mHQq6rpc8
KZRwD2Qa/r/WFSNBQTHTskDckva5wfDXkCoingzQQQmTRwIEjr+iciGoB7Gea5GTm8ePRKK/4lSD
4YAbroJJLsCob+xpdKbrmg0ZhK/n/CCaqoTNi5V13Vf6HGWZS+MiXpUnWofulEVaijhBAgoekPJi
jvIwHwnIPS6e18+ES3fNliwTG3F/7pi0kDIAJCJX9TX1dZ1wYkaL7XXUPDyQkt6I66xQ0qb7bzlA
A/5a3s/EMiCWnhnfJGN/LrlNfHMVXl3aTVRIXYJfNkJAHNDVJErXrLmOw/NZTtALgikJA36Ft09a
rV/UfVEkZUYd+hIBvajlXTC2v+WE9Jq1KEXrl80t1jtXd8rYPzy7JNDPDhwyiFhyyUqLLe1DMNt6
yocB8hbON/WF4QKUZGsPslWUqtxo6fJ5AVEtjLhprR1Bc4m5bYyUWl+vfqOMOujT2hCHOMZzWxcR
bxOAz3yg6NyogtgFbN62r7iXzYQuZ4qNgFxwcxLMy66TurRenalUPLxrKRR2VEarBKmButf/XKUS
K8FqHgavf/2TCIWc5DPnQ++OU/C6C86BhX+aM+A/zNz18O1XBLYwsGc/MIvIbVglCnei2XCfztPi
scJruZXxq2mKNXT/DNi+puwieBrxLrG0q8ZPS0O2EvG2cTyeq7PfSCCnkoMCXsl2g+/s3iv9zmia
7waTRPTM8cnzxP41Eb+QyU1ZFtmWnWoUDF84TApVCc7wAIczPqgf9Fv8EC3PNU/kGhyH4ErFo1P4
B2wgPrcJRCmYfWVoYChBUxKv0hxBg5ukABCXELeGZI5cWVim7cTBBUQcvQxQG0KC6MIgsWOhB/EW
zicxE8hj8zwjTOKtG1BT5ZfyXPHW1uRcms9kcimGH7EiWWlA38ftBDOiKuC67DdEKWxRZWKepxJ0
7EAqfzdwRKMUzIm5NAJe+dCrE+DyODb7Mr3gdiMm2szNt/D4fE57L96zEFLSKJP0jvkUjQ4TmXMQ
gFegZK+dzxhPSP94IHdnql+23sZaV04pdCrY8AQdmRUtPdWhJCx7YwoXrhwipzm1I4G8cXHQtXCE
QfKtWhTKMqh9ik3rabv5BIbpuoWw85PxcUW/Jn5qKaiC1TDRdHW87ZakGsiLfryjM9jGiArHo5NH
pZCw+vPEqCfjC64ea9Ohuz/a0WXtqhQ47VSHKHYXFdP/7pwlfAkp+sIyJs6LC0==