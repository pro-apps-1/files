<form id="pkg-form" method="post" action="<?= adminBaseUrl("ajax/resellers/$userId/packages") ?>">
    <div class="input-group mb-3">
        <select class="form-control" name="package_id" id="sel-packages" required>
            <option value="">انتخاب کنید</option>
            <?php
            if (!empty($packages)) {
                foreach ($packages as $package) {
                    $trafficTitle =  $package->traffic ?  $package->traffic . " گیگابایت" : "نامحدود";
                    $packageData = base64_encode(json_encode($package));
            ?>
                    <option data-values="<?= $packageData ?>" value="<?= $package->id ?>"><?= $package->name ?> - <?= $trafficTitle ?> - <?= $package->price ?> تومان</option>
            <?php
                }
            }
            ?>
        </select>
        <button class="btn btn-secondary" type="submit">
            <?= inlineIcon('add') ?>
            افزودن
        </button>
    </div>
</form>
<div class="my-2" id="sel-package-info" style="display: none;">

</div>

<table id="packages-table" class="table table-striped" style="width: 100%;">
    <tbody>

    </tbody>
</table>