<?php
$userCredit = getArrayValue($userValues, "credit");
?>

<div class="accordion mb-2" id="accordionExample">
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true">
                فرم افزودن یا کاهش
            </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
            <div class="accordion-body">
                <div class="text-center">
                    <h6 class="fw-bold">اعتبار فعلی: <?= number_format($userCredit) ?> تومان</h6>
                    <hr class="my-2"/>
                </div>
                <form id="credit-form" method="post" action="<?= adminBaseUrl("ajax/resellers/$userId/credits") ?>">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group ">
                                <label for="username" class="form-label">مبلغ تراکنش (تومان)</label>
                                <input type="text" value="" name="amount" data-separator="true" class="form-control" placeholder="مبلغ تراکنش را وارد کنید" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group ">
                                <label for="username" class="form-label">نوع تراکنش</label>
                                <select class="form-select" name="operation" required>
                                    <option value="">انتخاب کنید</option>
                                    <option value="inc">افزایش موجودی</option>
                                    <option value="dec">کاهش موجودی</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group ">
                                <label for="username" class="form-label">توضیحات</label>
                                <textarea class="form-control" rows="2" name="desc" placeholder="توضیحات تراکنش را وارد کنید. مثلا بابت شارژ پنل" required></textarea>
                            </div>
                        </div>
                        <div class="col-lg-12 text-end">
                            <button class="btn btn-primary btn-float-icon" type="submit">
                                <?= inlineIcon("save") ?>
                                ذخیره
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<table id="credits-table" class="table table-striped" style="width: 100%;">
    <tbody>

    </tbody>
</table>