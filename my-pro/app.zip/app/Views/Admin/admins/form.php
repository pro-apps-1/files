<?php
$userValues         = isset($userValues) ? $userValues : null;
$userId             = getArrayValue($userValues, "id");
$username           = getArrayValue($userValues, "username");
$fullname           = getArrayValue($userValues, "full_name");
$status             = getArrayValue($userValues, "status");
$mobile             = getArrayValue($userValues, "mobile");
$formMethod = $userId ? "put" : "post";
$formAction = $userId ? adminBaseUrl("ajax/admins/$userId") : adminBaseUrl("ajax/admins");
?>

<div class="modal-dialog modal-md">
    <div class="modal-content">
        <form id="user-form" method="<?= $formMethod ?>" action="<?= $formAction ?>">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?= $userId  ? "ویرایش مدیر" : "افزودن مدیر" ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="form-group mb-2">
                    <label for="username" class="form-label">نام کاربری (فقط حروف انگلیسی و اعداد)</label>
                    <input type="text" value="<?= $username ?>" name="username" class="form-control" placeholder="نام کاربری را وارد کنید" required>
                </div>

                <div class="form-group mb-2">
                    <label for="password" class="form-label">رمز عبور</label>
                    <div class="input-group">
                        <input type="text" value="" name="password" class="form-control" placeholder="رمز عبور را وارد کنید" <?= !$userId ? "required" : "" ?>>
                        <button class="btn btn-outline-primary" type="button" id="btn-generate-pass">
                            <?= inlineIcon("key") ?>
                        </button>
                    </div>
                </div>

                <div class="form-group ">
                    <label for="username" class="form-label">نام کامل</label>
                    <input type="text" value="<?= $fullname ?>" name="full_name" class="form-control" placeholder="نام کامل را وارد کنید" required>
                </div>

                <div class="form-group ">
                    <label for="username" class="form-label">شماره موبایل</label>
                    <input type="text" value="<?= $mobile ?>" name="mobile" class="form-control" placeholder="شماره موبایل مدیر را وارد کنید">
                </div>

                <div class="form-group">
                    <label for="is_active" class="form-label">وضعیت</label>
                    <select class="form-select" name="status" required>
                        <option value="">انتخاب کنید</option>
                        <option value="active" <?= $status == "active" ? "selected" : "" ?>>فعال</option>
                        <option value="inactive" <?= $status == "inactive"  ? "selected" : "" ?>>غیر فعال</option>
                    </select>
                </div>
            </div>
            <div class=" modal-footer">
                <button class="btn btn-primary btn-float-icon" type="submit">
                    <?= inlineIcon("save") ?>
                    <?= $userId ? " ویرایش کاربر" : " افزودن کاربر" ?>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    var formMode = "<?= !$userId ? "add" : "edit" ?>";
    window.initAdminForm(formMode);
</script>