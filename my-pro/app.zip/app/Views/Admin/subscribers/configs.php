<?php
$configs = getArrayValue($userValues, "configs", []);
?>

<div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">اطلاعات کانفیگ کاربر</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row g-1">
                <?php
                foreach ($configs  as $protocol => $_configs) {
                ?>
                    <div class="col-lg-4 col-sm-6 col-12">
                        <?= genProtocol($protocol, $_configs) ?>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php
function genProtocol($protocol, $configs)
{
?>
    <div class="card">
        <div class="card-header">
            پروتکل <?= $protocol ?>
        </div>
        <div class="card-body p-1 scroll-bar config-box" style="overflow-y:auto">
            <?php
            if ($protocol == "openvpn") {
                foreach ($configs as $config) {
                    $serverName = $config["server_name"];
                    $serverId   = $config["server_id"];
                    $serverFlag = $config["server_flag"];
            ?>
                    <div class="mb-2 pb-2 d-flex align-items-center justify-content-between border-bottom">
                        <div>
                            <img class="rounded-circle" src="<?= $serverFlag ?>" width="25" height="25" />
                            <small> سرور <?= $serverName ?></small>
                        </div>
                        <a href="<?= baseUrl("ovpn-config/$serverId") ?>" class="btn btn-sm btn-warning btn-icon" target="_blank" download="">
                            <?= inlineIcon("download") ?>
                        </a>
                    </div>
                    <?php
                }
            } else {
                foreach ($configs as $domain => $aconfigs) {
                    echo "<div class='mb-1 text-center'><small>دامنه: $domain</small></div>";
                    foreach ($aconfigs as $p => $values) {
                        $url = $values;
                        if ($protocol == "ssh") {
                            $url = $values["qrcode"];
                        }
                        $urlParams = parseUrl($url);
                        $text      = getArrayValue($urlParams, "text");
                    ?>
                        <div class="mb-2 text-center">
                            <?php if ($protocol == "v2ray") {  ?>
                                <button class="btn btn-info btn-sm img-configs mb-1" data-protocol="<?= $protocol ?>" data-text="<?= $text ?>">
                                    <?= inlineIcon("copy") ?>
                                    کپی کانفیگ <?=$p?>
                                </button>
                            <?php } else { ?>
                                <button class="btn btn-info btn-sm btn-copy-config mb-1" data-config="<?= base64_encode(json_encode($values)) ?>">
                                    <?= inlineIcon("copy") ?>
                                    کپی کانفیگ
                                </button>
                            <?php } ?>
                            <img class="cursor-pointer img-configs img-fluid" data-protocol="<?= $protocol ?>" src="<?= $url ?>" data-text="<?= $text ?>" />
                            <?php if (count($configs) > 1) { ?>
                                <hr class="my-2" />
                            <?php } ?>
                        </div>
            <?php
                    }
                }
            }
            ?>
        </div>
    </div>
<?php
}
?>