<div class="card-datatable table-responsive mt-3">
    <table id="online-table" class="table table-striped" style="width: 100%;">

    </table>
</div>