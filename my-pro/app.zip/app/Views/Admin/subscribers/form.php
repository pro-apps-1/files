<?php
$userValues         = isset($userValues) ? $userValues : null;
$userId             = getArrayValue($userValues, "user_id");
$username           = getArrayValue($userValues, "username");
$password           = getArrayValue($userValues, "password");
$mobile             = getArrayValue($userValues, "mobile");
$desc               = getArrayValue($userValues, "desc");
$packageId          = getArrayValue($userValues, "package_id");
$startTime          = getArrayValue($userValues, "start_time");
$endTime            = getArrayValue($userValues, "end_time");
$limitUsers         = getArrayValue($userValues, "limit_users");
$traffic            = getArrayValue($userValues, "traffic");
$status             = getArrayValue($userValues, "status");
$statusDesc         = getArrayValue($userValues, "status_desc");
$fullName           = getArrayValue($userValues, "full_name");
$validityDays       = getArrayValue($userValues, "validity_days");
$categoryId         = getArrayValue($userValues, "category_id", 0);
$crole              = getArrayValue($userValues, "crole", "");

$formMethod         = $userId ? "put" : "post";
$formAction         = $userId ? adminBaseUrl("ajax/subscribers/$userId") : adminBaseUrl("ajax/subscribers");
$detailsUrl         = "subscribers/$userId/info";

$disabledPkg        = "";
$disabledManual     = false;
$maxLimit           = 100;

if ($userRole == "reseller") {
    if (!$isUnlimited) {
        if ($startTime) {
            $disabledPkg = "disabled";
        }
        $disabledManual = true;
    }
    if ($isUnlimited) {
        $maxLimit  = 10;
    }
}

$subsSettingsBy     =  "package";
if ($userId && ($userRole == "admin" || $isUnlimited)) {
    $subsSettingsBy =  $packageId ? "package" : "manual";
}

if ($traffic) {
    $traffic  = trafficToGB($traffic);
}
?>
<form id="subscribers-form" method="<?= $formMethod ?>" action="<?= $formAction ?>">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?php if (!empty($refrence)) { ?>
                        <?php if ($refrence == "details") { ?>
                            <button type="button" class="btn btn-secondary rounded-circle btn-icon btn-ajax-views" data-url="<?= $detailsUrl ?>">
                                <?= inlineIcon("arrow-right") ?>
                            </button>
                        <?php } ?>
                    <?php } ?>
                    <?= $userId  ? "ویرایش کاربر" : "افزودن کاربر" ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group mb-2">
                            <label for="username" class="form-label">نام کاربری (فقط حروف انگلیسی و اعداد)</label>
                            <input type="text" <?= $userId ? "disabled" : "" ?> value="<?= $username ?>" name="username" class="form-control" placeholder="نام کاربری را وارد کنید" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mb-2">
                            <label for="password" class="form-label">رمز عبور</label>
                            <div class="input-group">
                                <input type="text" value="<?= $password ?>" name="password" class="form-control" placeholder="رمز عبور را وارد کنید" required>
                                <button class="btn btn-outline-primary" type="button" id="btn-generate-pass">
                                    <?= inlineIcon("key") ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-lg-12">
                        <div class="form-group mb-3">
                            <label for="" class="form-label">تنظیمات حجم و زمان</label>
                            <div class="form-control">
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="radio" name="subs_settings_by" value="package" required <?= $subsSettingsBy == "package" ? "checked" : "" ?>>
                                    <label class="form-check-label  mb-0">بر اساس پکیج</label>
                                </div>
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="radio" name="subs_settings_by" value="<?= $disabledManual ? "" : "manual" ?>" required <?= $disabledManual ? "disabled" : "" ?> <?= $subsSettingsBy == "manual" ? "checked" : "" ?>>
                                    <label class="form-check-label  mb-0">بصورت دستی</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div id="subs-setting-by-package" style="display: <?= $subsSettingsBy == "package" ? "block" : "none" ?>;">
                            <div class="card">
                                <div class="card-header">تنظیم حجم و زمان با پکیج</div>
                                <div class="card-body">
                                    <div class="form-group mb-2">
                                        <label for="" class="form-label">انتخاب پکیج</label>
                                        <select class="form-select" name="package_id" required <?= $disabledPkg ?>>
                                            <option value="">انتخاب کنید</option>
                                            <?php
                                            if (!empty($packages)) {
                                                foreach ($packages as $package) {
                                                    $trafficTitle =  $package->traffic ?  $package->traffic . " گیگابایت" : "نامحدود";
                                                    $packageData = base64_encode(json_encode($package));
                                                    $selected = $packageId == $package->id ? "selected" : "";
                                            ?>
                                                    <option <?= $selected ?> data-values="<?= $packageData ?>" value="<?= $package->id ?>"><?= $package->name ?> - <?= $trafficTitle ?> - <?= $package->price ?> تومان</option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="my-2" id="sel-package-info" style="display: none;">

                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if ($userRole == "admin" || $isUnlimited) { ?>
                            <div id="subs-setting-manual" style="display: <?= $subsSettingsBy == "manual" ? "block" : "none" ?>;">
                                <div class="card">
                                    <div class="card-header">تنظیم دستی حجم و زمان</div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group mb-2">
                                                    <label for="limit_users" class="form-label">تعداد کاربران همزمان</label>
                                                    <input type="number" min="1" max="<?= $maxLimit ?>" name="limit_users" value="<?= $limitUsers ?>" class="form-control" placeholder="تعداد کاربر را وارد کنید" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group mb-2">
                                                    <label class="form-label">مقدار ترافیک (0 نامحدود)</label>
                                                    <div class="input-group">
                                                        <input type="number" name="traffic" min="0" value="<?= $traffic ?>" class="form-control" placeholder="مقدار ترافیک قابل مصرف را وارد کنید" required>
                                                        <span class="input-group-text">گیگابایت</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group mb-2">
                                                    <label for="validity_days" class="form-label">مدت اعتبار <span class="fw-normal text-muted">(صفر به معنای نامحدود)</span></label>
                                                    <div class="input-group">
                                                        <input type="number" min="0" name="validity_days" value="<?= $validityDays ?>" class="form-control" placeholder="تعداد روزهای فعالی را وارد کنید" required> <span class="input-group-text">روز</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php if (!$userId || !$startTime) { ?>
                                                <div class="col-lg-6">
                                                    <div class="form-group mb-3">
                                                        <label for="expiry_type" class="form-label">زمان شروع با</label>
                                                        <div class="form-control">
                                                            <div class="form-check form-check-inline mb-0">
                                                                <input class="form-check-input" type="radio" name="start_time_type" value="first-conn" required <?= !$startTime ? "checked" : "" ?>>
                                                                <label class="form-check-label  mb-0">اولین اتصال</label>
                                                            </div>
                                                            <div class="form-check form-check-inline mb-0">
                                                                <input class="form-check-input" type="radio" name="start_time_type" value="create-user" required <?= $startTime ? "checked" : "" ?>>
                                                                <label class="form-check-label  mb-0">همین الان</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group mb-2">
                            <label for="mobile" class="form-label">شماره تلفن</label>
                            <input type="text" value="<?= $mobile ?>" name="mobile" class="form-control" placeholder="شماره تلفن کاربر را وارد کنید">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-label"> نام مشترک (اختیاری)</label>
                            <input type="text" class="form-control" value="<?= $fullName ?>" name="full_name" placeholder="نام و نام خانوادگی را وارد کنید..." />
                        </div>
                    </div>
                </div>

                <div class="form-group mb-2">
                    <label class="form-label">توضیحات</label>
                    <textarea name="desc" class="form-control" placeholder="متن توضیحات را وارد کنید"><?= $desc ?></textarea>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-primary btn-float-icon" type="submit" id="btn-submit-user">
                    <?= inlineIcon("save") ?>
                    <?= $userId ? " ویرایش کاربر" : " افزودن کاربر" ?>
                </button>
            </div>
        </div>
    </div>
</form>
<script>
    user_credit = <?= $userCredit ?>;
    var isUnlimited = <?= $isUnlimited ?>;
    var formMode = "<?= !$userId ? "add" : "edit" ?>";
    window.initSubsForm(formMode);
</script>