<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs/CnSpBVpxZaYDGxuLM53y6v6R7E2QC+U4Jumj1vnbalhG04k+hjSDJUtq0bDW7cG1DvzPP
d9wSE6Pb6BsRAi6G79/eWgX1pUKsTxCApt7svTOGDQxxPWc+JT0gebfwdgPIRYOwnfoX3I8/eh1H
R093ws4+h2fH4NDaMz8fqMaF7kp0Nwhr9eIsEz1/EI2e5w2aubvt1cKbrbqbcNPcL8Qanjb9iNQE
W/Z60kMsIZ8ktlV+IGTICMiM5cC0HAFvXEcpLu8muy7i9RCCY41Wj1WlL9V936Oe4rq/MHvkyKz7
yS4+YnE8JpPIxDfPETQzX3vtwVmW/iRFRFJarNfdCYl6OTkoeI0EVRxmxZl2gdJcH5CR82sS9GaE
6RFCwjYC1T3miWtslPK8pbigiRw4yA87MwirbN1gUaCINBUkXBK6XKDH/SziHgwNCUG/Ey0cCqjx
OO1cbQrCf78x3Pl4JX4FlN8b+1Yv0rcmQJG6FfC2GNRUucOvyU5Bqmf/3JMD6bIA335/QBaqkUk5
tjG9B866RJU87iYbSKAxjmgQOVMDHLJIKe4oepg/Pgv4T5bZ/WdHQF9QUOEYnlj7/Sqz+4AwIEan
P6/HtPuVZfajEjT/jjQ9QssESPgMxa5HHiNnh/BLQOxO30uF2w1K2YcxawT3j8oNVHV1mGX4fmMR
3A2l+lDfdXkWJ23E+OzLLCx9fj0iCRmYjHYfMBNEnW45EJIJMtMn1pv8W5x6n4kvUUFTQMr3htb9
VW9FcuyTPnwjYBiYcJqGVBscK4oeyFXR0IbLXQPc+WKekwAK8kuSfe0pVWD+0YnuEFknG6xbRrLz
5eMtb41wqr++GAfcY5SRMY3nipsYMWFP88ocYqWBBGJ1Cq2uGc4tzci02sORyntrMdkKsFXzHzBA
b7zxQu5t7C43KEORZHcY9s49s8lE5p2yKf5EX0LE36LrMu6aIRJSC7hFeXu55N3ifmc4VuaoOcKz
vu/LqoNV72rHgZQY4+DZ/+6V8uD6YnPJz1FSa8AmD0wy350TW3yJyfWeJ9zchAJ+8R7Xr5uwqtUY
99aoi/LTN8HDL0Uxv2B8yTeVhBxp4MJn8w3Jg+25GtrZxXrPDP8g1hh6MSECwunVjgbWzOVgezXg
3NZndy88eMYyt06IX3C1b9cPMsZOqlHPDkuI6G8ZhtZ/vwpz6PE/7eR9N80gWz+8V1AyM7GtodKq
WqGoGYSbkrJ545lZD9IlaDdtvFBQ33vkbCW6yiB+sAVMcw9mciEyoYEruL0LbC9YFUbZyq3eM4j6
Z48n8cWNrwECuCeGPiK5JpQqP5KUw59LsimpeLB1/Mlt2/Debu/BLU10C4coCZGA0XU58V2AetNb
W4WxCOQ188ouiuaEuzTsvv4OR0CPyniCgKDsnEAbuLSOnG5EiUCl+rY9dJCDHOMZICJhUvI8AlEu
cDESmPlIEsnPERn4Nn1Pm/2NZ076EFlz78jNIm/nnECJiHc3nLC6Nq1IB++85Na+QDK9ZgO45e9K
eUbCR5Y03/H5B6UQ+RwIsCB0z8TKoQEXHdB2sZtKsscgTAbMB2xRyCqJAchME450QdMKJOcv3Kp3
k/C3T9R4Dtl0NblI0iqFkeA6HY8tBMYwf1kdaRKazXNF4SdKyDcgm/RJ3nd85MFSjpGmgie9s3in
OCVXH506iL8qoq1rWb0tQfGv4evLM2mpEhAr7b9uO6XaafBRoHq1Cx/nslLJRLY48a/1377s8Xg3
8cY+63vcYEWKPzBe+0Qf7iNHl8QDflYa9Wy6reho3FqS5QVige56xnmUa7c1h9y5NhpAI/hMsSJ8
L/xQJQo6UgYULGKo1uNZ26pubUg2pqY31uoIpDo4VL6PusDANgv66/evt7T3hNmjahTIS3Hu7Jld
XHDLB3Tbb7NkHuXogzXvADxzw2q9IjgsUETEdf3cupY6gwBWhOtSs30JLMqgKPQ4Ouvs17ovo9Ry
jM3I7YBvAOoj4o1xeDCbni+TaurlZw2D2mFUNJLcclsKvddwUMOA++qo5R49O8sopkGw3psCLlaq
DYQmTPnRYMoPwfh22qomfUTlLzGSh8FH2Yzy5CHwZ/dOOa29gId81cljmUdf2bICcb63AX9FCTP1
1VlROO+9UH9P/nIOL9LZ0b0B5rFzhxNL7ZJ9tjJQTqDjYwyleijUJyyTXKP9kMPRg2F9phm1NeAZ
gP4tQDwaiG5EpB2UddgejeYL3sXrItVzIvuwoeOC+ooZIJuAOrFDgGBKSqOPNcmMtP8304Q6H1pN
Dp/NlNkI89XLKRb27Mfi+HCwdeRGY1b5Gao1KMwspDwjL9u+O72hbva+Bb9U4QMoCa3WzLtKk+s5
8clIGUL6oX37m1nw22dExcfKGhhdyVtYW946Cp//+ciOk9FeqHLyjM7EmEHFU0dDaAzBdCzYQQ11
Adhrp2Uiaxzzftx0HMOSZH00vTiZkasRy61uRfoaRJ5l8Q5LK+VClEKJhYzNMbimP/IqtE0Uz/Uf
EV+hzaQnC+JJhmrxeZ4RxHU92VJJllTgvY2rj2wlPvWPw7QN7wAOfDdy/TqtYE8kA5UINcEiYLxz
dm0EiRX9wtZXvrYaG0bgMtCvr0KC2vuPABTJRRoTyz+N8E7Ucy0MnQW5AZLFhr1cnM1A81QSYmpM
C3OEN96PGpWzqW4BTLpohP1FpHWBKpR/3XgkZDpaU7ny5QS/UlxS+rjp11p7PZ92zpHPTAwQDykI
9V+SnXa63LNcitEbUSYQ2+XVsA9+9rxkzk2bA+xaydcNTRs/lsbX8jS5woTOEe7LiaAH1PtcKZI/
ai1o0bM+qoYSWc9kByuCYyQN0TgrIp0H/dSzWFWn03BRZw9tWQtjaYn3eS4ikzn6ogfuaBDOgoBS
1h8QqrEoDUfFyAP7N4xUO3/ak1+uooeHBQy2davse8rvAeQnkL6X5F6iY+HjsB8X37sXiwFD+P3y
x7o6JnAEdiysYKuGHO0lapLabz9fHZcMvljQW7Ezvy8Tz1moIhXd3sKT0maccziXUiw9cin0Bxbg
sPP8fZOPxQRG6INXySH5meRqPMq429AzTNeqsRGVnVG1ZkrniP5bXHSZlhc2GhlNaIbdiiGs3DQs
U8QflPHLGrCt+IqW8Twx3UiHacBsgnreM02lDmDhNErtCa9+qujK+26E8iPFPxGwGy/IqDyWSLPw
qDvjCp465ReVVTEzzhIzG9e8AyPkxEnR0EhEqBdvlJKwK14WBbrt4u0BfGxBeF+wollSCyCB4+53
wmpJQczqlmG55DI0T1MmrWtH2F0zuwvyOJPS+V9lorkd9ZGnrMFzqLHK89nRlmDmqPkv378YvXDg
dy4B43RhMnhNX18iCjZHX3Rb5WwB9XqeDSEmAnkDId4xpC/wE4wGHDO14T60tRIZbRF06Ok6EKp9
38ZnydO/2bMbnpKqzFgdSVL4e1UwD5qeP7woLYWf6/fonVl6ACBovY3fXbZKRzvZEnB//oVxATOz
0nJepjwdZreTiP/uM9Tgd7E0fqnkjFo0NTQGny70hz7uhmnM/2WBDB/hZQFjmypbGrKB+UiOEJ3h
AM6ThF9zzAWNQsauW2oYXqWzEAxCKskwxabXTl70aygdUaCGpZSlmlfIxuAzv5SuXbhQ1c7Ylztj
5sQ0bLSeMGKiFii4ZI3Fdu2hHIZvABupOa+ZlI6Xyb4fxAXfekjxGjP+hwrE68Bth+rnMWt4clkc
Fe6XFQv5aHHwJOH6CX3GdNV1NCU6cD5buPaFpOMsxpT+gHIyiMT+8lz8kUNgEQVsbcQX9HFG0lqJ
uL0XJFua9LWzzw8acF9HseHAvGdTavyA0Ybs9tLBhlvNDwW5LwKqXzzCS+VW0nFDrS3YmqEVDUXH
zYDJK8JoZuYs1Zxwx6e0KFPlYFPD/9Y6G2IRLyjLsU+fujYYZ1gh6stVTgBX5Hx30S0ouJRYrISo
ApYPmtuJitZQa3O0Bd2/OGMkIhcqAglvkj+EkCTiDrxJtrn/D3Zu5wzuLrohxF8XbIApUgbYHx+L
Y8V2gNCo8myT1ZAwH7uLbicrmq8DhQmUP2EAM0rol1UKN+Q+3m/2QChbrMJUV354npu1s11/qhE+
DLncet+NYmy5Tfmz/+1BFQZd82fR8ez6D5KbeWhpWUiDHM5yl/0i2OYixGpOPrkogtVUh+Vikt0B
cnywup5fE3FANiLbzNWvmNcwRmlp5JC8YCqVsX1E+gKeUENpBXQljSna/7dBqCMpP9Ru49yBrp2F
6Bkta7ECTAosa0Vcx3RNNaP0qtMEUoj5t/7JiBBp8b3cX/2ALK7SLUaqw+35IHq9I2/zxRp8q2y8
rWHZ6iF2rREV/faG7HkECDpjIdjV6i9KdYKBo/r/olfIjTazVX6WmUmY/+DvPxvq6QIE4yHecKFS
0De5XIRmawuJwH8tJsEfryfADS2dqAI1Cmn9zORDgYvnjrjyfAS3ZtR/ka2XZtOhSS57JhmVB8bQ
UGlV8FeUdwnkCt3A7Euq2uz8edaV9tMPmGIbvEwrVJV64wUlgQz+xa1z4u6GLgGVneHBurTlepvg
MPQtO9VFmSkqSPwUgEmVtBWv8rBUsa7dIS06FSWI1GHXjj+yMb8zoE8rxq5aLf/MSQFtnAXMEbJY
a8j+OgWDiQyufUxnRFsIg3OvdIs/R/+zbR2AEi4IfQtK4BdOjzuaFIFsR6bx+BAQUkTYck92SHJf
qC0eCDhGoPbkEJV9GBIXszt7O/F++v4CE5eCAFNbax+ToQwv7QZCzLNTw0Z/n0Q8kYhJhvhu0l4r
f28w2DOWLEddyBcZVWWc590+MWNgGfu/RowF/nFJ3B5pql0xvb2aqIGNOHei9G+UsyuZHmI0JVcK
iMy2dT449y6K0XeclcQTZuq+nu1vRScxzlu8mfkQ5sphPwjMWBeZJZFv84ECPimFO5vGmOUUFNVs
Gq9ZrIG/1g54t5k1IzS8DeatE8V1r7NoCewtZjM4qW47AfU0f2TboOlhXcuLzUuz8VenGm5L7VFz
v8WNNEmEezzIv53e4pO1aZuvk405DXHllvvIrmbaEP/900lpclyVurWcDv0bfdPrY30KUdZ18Mnq
FWx2d7uMiA9XdpCTJFyT8UDGg3HZZsZa6NS1/39rtXlNYxjzkTg1SuGCbFOEwmuFJlyQjCd+UypZ
it2zXyW4XKY9T09ASeQ4K172jb4vd+jOETUx/w74BXe5bYcYmnkJAdychCi4zPy7dsLliHddlt36
IyusQInbnIm4q2PJz8yT0wHCedJf3SCxTeJyYRGMboXLA4YLDxpHrsUfFZ4NplaLvxtYyspoVoun
sxPhR+pCq+swcAmKudmzNfkZuNgliyNq4ITPHd6QMyjdkB3MyoxakNfeOLnFT9OicLOKi+3y60f3
qOuhtAbNRvQkuUT5vcp2uSh+gjtwnw1fUpqW9705ujY4LENc+bngV1++usOtZu0N/KkULGDf4DOt
t3gXUnNzREkDRuE2Hmlt7VDNGofIQo7SUHRmrfOZvD+24s0edowGhIWtPdYpoicIhAm4i76BnUIo
hGxM8MadKJAMAYBSA/iKcKZp1Ya1yKxpZrOsQmJZPuoIywaTQDs9yn3JuVHf+/eW38PGT0v+XPfb
vAjbGFz8jSVSWCe9f3d/1jdUHyeqptD44HW5o3g0qQpxBnxJw/8SIkYctFC4xLgmnNou4sP5mxr/
gvrXZzlzBvgXGhEDIUYFucm+OqJMHNAvKkzXq0Twk2NEN2mYrxoc5vyUG4jUsz2cNohWBwDkJC02
q2KpzB3NAJqlvO4+Y6GhhF+b3i5Je3cf317cIlY6D0DJcTb/j9O2blX33eCm/rhpbVdg+iIjBDbm
9/z4HjWltHSKSRuV7oOACkDRiwapSo6nnUGhTCp6Q0VHkmf3k0M//+VGMQfjisBhPuYx4Kxrt/Vp
pO3J7EH8XHEBzz3CfT2ssvtPd5Or3P5kUdsKx/bOFU4PMzRB21+9UrBvyyvBlx9Q16/v6ZVMmudj
jLvuyJXfqEHAeLntXNouMiVOyEdMlBYpVnC/tY4Nvi3LuXQSJtaC9tH2icoLv76DX9p+GRU7rUbq
D24jA8Di4N/OpN+vdRTX2kGwCkx1w8b9bfo5pWs+lwSaJZR0XFhOMqb3JX/Cs6t6sRhG5AFCd7wz
HQoKh2owzim3XEc35LzOXyaSIC+9kM8g49EbwrbzzATlypjjqwxdpAs9dRNjSVSsEgpBtE+NhgIG
T7xMZrf6Oc1G+2vTK7MSPspQuxgQwgXlfA99DMY+D6BfsMrqTLvKwoIBImKJ6ZPVxd7SzoLzj8jQ
/W1fOO5qSpNgL00HOxY2cqyhFUAaeHeiyjQBrMsVww24sEpZmmlIHx3imNMjNvbypflyvDsORRiZ
2BU4QydXBcPhBZlOX1ufXJMgf/Q/3sMBkPgjMZstz4a8PvzakD2YLN4DFbRzyeoXtLAIY80XFQAi
pSvdcARXfw5BdVSii5Z1uMTIowO5xqgArUHA1t4GQDr/jMV5uGRKYOQ60YOipVUTxH0AV28PhEWK
xdNIP3aQoHgQd/oy1muOgAe7Im84D0WrnATUT86FJEcPL17aZtVxtzSpNI0ZgP5bBkQeDwnfwyUh
VSyjmawR7IJRuuiKAQQhv1XWluPpgdcO8vexZmiETDbV/3MgRVvuVHadXW7daoEmoFpjMXFVy3Sf
5zg7x//3xR3LUSIXhfL62asG+mebiRsWzeOHkGAUhx/Nrnlb2gh0bBGZJWQUd7wdoKhpn1eRshLG
Wos66zklpx8Uas23hont+TqThqwjf1NqXXju4GMnLRxqvnuZs2BFZcXjwkJFzJ89oKN0rc9fFMSW
G0jgltR4qE1bnB3XC31VKnbzrYZUxNjvsO9mZorilAAW3J8kAF/QiVBWTFgEeQv55AJWsSFTavd7
DBEKJ17JcDZeMKPsLc+o0LxqPF+HgQj5NGO2CeVnypkiRtVCf9tJ9krxyqeaB+sM9MhGL29zq0bF
K5eLSh8K4qFW/Dc0mkv/P6JDFk1mBjcbwohc+iwGp8KVDNW41GAfZJz4OQQSSpUngcWPXkpwMT7Q
5Y4qHmf2R0HccbvTVUV3wd3s6SDPYT4LEzzIx5EahzOOrDgjn3OXZM2gAYEOgOhhu6T1M9lmj6wN
RfnAG2rHpImp+vReV3NpoUjjpPp8RhIpgkIG0hkh0LfKz6q3qvBya2B5ceFshlIvKuvU1DmtVJXF
9vjaEx2zkvu75oMbEnD2MWQjLs0WgVflXtJFFIEhf0UgXyLjC0Rv8DQAIQjzW8T8tceou4XV+7xf
Fq9AuMtw1CVd/I/3ntNrkGK1KAE4m81QXmFDu8qg9RRVKY9TCbHuCOtoJuxYfhkNc34E/NczovM2
msLm1FMzlEAYTdoK4aLYiYkr2/So+5CHRvfuS0FVoEE2Ia9djK14H0dx8jfIsRioqGKU3dO5Wc+t
TCaxbi9i6gIBNcLHgXTyNdRJAjfGNTcwOuxI/UDRIrFxhkkvTEQki8CDo6yhchuuBeD1PoEymevq
n+ps6uYL8dQrVA7H/5LTT1thSFdUblUp2XDTk5Dk7vjXm+sJ4Km9nlELAoGwbWHWDLY9zbmu4klL
AiT0dTWSi+PEWEgqeLhRiNl7yPKlQTKcy9CcB4TVTodRnicikmADlAOJtDzO6OJ7QyGGhJDhK7mF
1K2aLj8iZMZREEivQ67TuprNTX6tqdQl8gQC2+97VuYvBKcOULmcJ/YLIyHJit/w3r9YcWsYipUO
5lD9DbJt1T1h1lNp3cgUIXTinZcwIX8IrR8TIOFL5CPTq9YktfildHqm4f1OJxCNmlXQPMCK3acW
mmsnmNqXlh/9BawFv0xx9US/vRh/3vDUcvIqjweTFfYA/3lagOcIXtBx1sPuP4cISztCv6kCPnXl
KBgzAHk3z+gh0Du0TOxC68jcPuoVyw9AA9eUiVko8kHhSdJlEkKcwAL5rJHn+yMi9bCdma2Usq2h
sg1eNSXSI9D503I0RnvyUtyVzqatLDW8IH+jTpRH9PgXT69KDFfEbt9g/4wgUazmrMhLwIbfVzB7
6dJhLfrSSAV1CX8T7un6wCfApMI4kqjNykoT5KkEy4izPfD0j09f9ivwKB9GVOS2Ht9nB4RcG+wB
GSpZbfLqNXcz1+xhDEMe5RN/HN0uyHMCq7OEsHPOs1VT84iWGyJQWenwg0b9/acbLrgW/Y74o5sL
vHZwVj1NgrzTnI6WH9vLLTIVNk75LBxDGyitesUqnoeZCPhHRxbZtYCYy4ylgmW+AMz5/xUATw7t
LqGaK40vD1rLRteFhnBpw1Y88Ehih5awCwCnuYYn3svsxLHfwhfW0i0e6mkT8iOKCmVXdoJSq4T9
864Sd+Wh9K5yD/NAtN+tmDK4cHMfzNPeoO4Vq5CEjY5iCkGFzr0eJu94H9vfhZ3j8ky8cI+vUuMV
hVXG0EAh15VhPzOUbRiiYzU48d1BTBNwNFGsXDjdyS64z/D/0q0ZZ48A60HsI2n2dutY2oj3atHm
ZqpObqJOoZc98nTc/hs/yk0LT4AoD2nRhkOSTEbYcw4hmrJF0twQcOmJ12mwKInpU45HWkSz4s9a
KTnLidYuCKXRWZF3WVHTVaUrcMUzgc5DhwKRtPkES2zsrPtWqpQ918VZTZPLdSf2a2Z+a1jy3frG
7GwzifcZSth7sSiN4sAHtR6bGGFxf3cEmTt6/OBKPefvU+V7R5wpWR/eqXgXZLJmjm==