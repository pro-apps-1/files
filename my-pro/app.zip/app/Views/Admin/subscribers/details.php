<?php
$userValues         = isset($userValues) ? $userValues : null;
$userId             = getArrayValue($userValues, "id");
$username           = getArrayValue($userValues, "username");
$password           = getArrayValue($userValues, "password");
$email              = getArrayValue($userValues, "email");
$mobile             = getArrayValue($userValues, "mobile");
$traffic            = getArrayValue($userValues, "ftraffic");
$startDate          = getArrayValue($userValues, "start_date");
$endDate            = getArrayValue($userValues, "end_date");
$expiryType         = getArrayValue($userValues, "expiry_type");
$concurrentUsers    = getArrayValue($userValues, "limit_users");
$consumerTraffic    = getArrayValue($userValues, "fconsumer_traffic");
$endDateJD          = getArrayValue($userValues, "end_time_jd"); //jalali date
$startJD            = getArrayValue($userValues, "start_time_jd"); //jalali date
$remainingDays      = getArrayValue($userValues, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userValues, "netmod_qr_url", "");
$status             = getArrayValue($userValues, "status", "");
$creatorName        = getArrayValue($userValues, "creator_name", "");
$editorName         = getArrayValue($userValues, "editor_name", "");
$desc               = getArrayValue($userValues, "desc", "");
$arrayConfig        = getArrayValue($userValues, "array_config", []);
$diffrenceDate      = getArrayValue($userValues, "diffrence_date", "");
$publicLink         = getArrayValue($userValues, "public_link", "");
$utime              = getArrayValue($userValues, "utime", "");
$ctime              = getArrayValue($userValues, "ctime", "");
$fullName           = getArrayValue($userValues, "full_name", "");
$categoryName       = getArrayValue($userValues, "category_name", "");


$remainingText  = "$remainingDays";
$isPassDays     = strpos($remainingDays, "گذشته");
if ($isPassDays) {
    $remainingText = "<span class='text-warning'>$remainingDays</span>";
}

$editViewUrl = "subscribers/$userId/edit?ref=details";

$values1 = [
    [
        "label" => "نام کاربری",
        "value" => $username,
    ],
    [
        "label" => "رمز عبور",
        "value" => "<span class='cursor-pointer' data-copy='true' data-text='$password' data-bs-toggle='tooltip' title='کپی'>$password</span>",
    ],
    [
        "label" =>  "ترافیک",
        "value" => $traffic,
    ],
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" =>  "تاریخ شروع",
        "value" => $startJD,
    ],
    [
        "label" => "تاریخ پایان",
        "value" => $endDateJD,
    ],
    [
        "label" =>  "مدت زمان",
        "value" => $diffrenceDate,
    ],
    [
        "label" =>  "زمان باقی مانده",
        "value" => $remainingText,
    ],

    [
        "label" =>  "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
    [
        "label" => "توضیحات",
        "value" => $desc,
    ],

];
$values2 = [
    [
        "label" => "موبایل",
        "value" => $mobile,
    ],
    [
        "label" => "نام مشترک",
        "value" => $fullName,
    ],
    [
        "label" => "لینک کاربر",
        "value" => "<a target='_blank' href='$publicLink'>$publicLink</a>",
    ],
    [
        "label" => "ثبت کننده",
        "value" => $creatorName . " $ctime",
    ],
    [
        "label" => "ویرایش کننده",
        "value" => $utime ? $editorName . " " . $utime : "-",
    ],
    
];

?>

<div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">اطلاعات کاربر</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row g-3">
                <div class="col-lg-6 border-end">
                    <?php
                    foreach ($values1 as  $k => $item) {
                        $label = $item["label"];
                        $value = $item["value"];

                    ?>
                        <div class="custom-list">
                            <span class="title text-muted"><?= $label ?></span>
                            <span class="content fw-bold"><?= $value ? $value : "-" ?></span>
                        </div>
                    <?php
                    }
                    ?>
                </div>
                <div class="col-lg-6">
                    <?php
                    foreach ($values2 as $k => $item) {
                        $label = $item["label"];
                        $value = $item["value"];

                    ?>
                        <div class="d-flex flex-row align-items-center justify-content-between border-bottom  py-2 px-1">
                            <span class="text-muted"><?= $label ?></span>
                            <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                        </div>
                    <?php
                    }
                    ?>
                    <div class="row mt-4">
                        <div class="col-lg-12">
                            <button class="btn btn-primary w-100 mb-2 btn-float-icon btn-ajax-views" data-url="<?= $editViewUrl ?>">
                                <?= inlineIcon("edit") ?>
                                ویرایش
                            </button>
                            <button class="btn-chng-active btn mb-2 btn-<?= $status == "active" ? "warning" : "success" ?> w-100 mb-2 btn-float-icon" data-active="<?= $status == "active" ? 1 : 0 ?>" data-id="<?= $userId ?>">
                                <?= inlineIcon($status == "active" ? "pause" : "play") ?>
                                <?= $status == "active" ? "غیر فعال کردن" : "فعال کردن" ?>
                            </button>
                        </div>
                        <div class="col-lg-12">
                            <?php if ($userRole == "admin") { ?>
                                <button class="btn-reset-traffic btn btn-danger w-100 mb-2 btn-float-icon " data-id="<?= $userId ?>">
                                    <?= inlineIcon("rotate-left") ?>
                                    ریست ترافیک
                                </button>
                            <?php } ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>