<style>
    .btn-items .btn-icon {
        width: 32px !important;
        height: 32px !important;
    }

    .btn-items .btn-icon .icon {
        font-size: 14px !important;
    }
</style>
<div class="custome-breadcrumb has-actions">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("dashboard") ?>">داشبورد</a></li>
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("subscribers") ?>">مشترکین</a></li>
            <?php if ($activeTab == "all") { ?>
                <li class="breadcrumb-item active">لیست همه</li>
            <?php } ?>
            <?php if ($activeTab == "online") { ?>
                <li class="breadcrumb-item active">لیست آنلاین ها</li>
            <?php } ?>
            <?php if ($activeTab == "connLogs") { ?>
                <li class="breadcrumb-item active">لیست لاگ ها</li>
            <?php } ?>
        </ol>
    </nav>
    <?php if ($activeTab == "all") { ?>
        <div class="actions">

            <button id="btn-add-user" class="btn btn-primary btn-ajax-views btn-float-icon" data-url="subscribers/add">
                <?= inlineIcon("add", "icon") ?>
                افزودن
            </button>
            <?php if ($userRole === "admisa") { ?>
                <button id="btn-sync-users" class="btn btn-success btn-float-icon" data-url="subscribers/add">
                    <?= inlineIcon("refresh", "icon") ?>
                    سینک همه
                </button>
            <?php } ?>
            <button class="btn btn-danger btn-float-icon" style="display: none;" id="btn-bulk-delete">
                <?= inlineIcon("trash", "icon") ?>
                حذف گروهی
            </button>
        </div>
    <?php } ?>
    <?php if ($activeTab == "connLogs" && $userRole == "admin") { ?>
        <div class="actions">
            <button class="btn btn-danger btn-float-icon" id="btn-delete-logs">
                <?= inlineIcon("trash", "icon") ?>
                حذف لاگ ها
            </button>
        </div>
    <?php } ?>
</div>


<div class="modal" id="progress-modal" data-bs-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class="p-2 text-center text-primary">
                    <div class="spinner-border mb-3" style="width: 2.5rem; height: 2.5rem;border-width:3px"></div>
                    <div>
                        در حال انجام عملیات [ <span id="action-title"></span> ] بر روی سرورهای فعال.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<ul class="nav nav-tabs mb-3">
    <li class="nav-item">
        <a class="nav-link <?= $activeTab == "all" ? "active" : "" ?>" href="<?= adminBaseUrl("subscribers") ?>">
            <?= inlineIcon("users") ?>
            همه مشترکین
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeTab == "online" ? "active" : "" ?>" href="<?= adminBaseUrl("subscribers/online") ?>">
            <?= inlineIcon("globe") ?>
            مشترکین آنلاین
            <span class="badge text-bg-primary text-white"><?= $totalOnline ?></span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeTab == "connLogs" ? "active" : "" ?>" href="<?= adminBaseUrl("subscribers/conn-logs") ?>">
            <?= inlineIcon("list-check") ?>
            لاگ ورود و خروج
        </a>
    </li>
</ul>
<div class="card">


    <?php
    if (file_exists(__DIR__ . DS . "$activeTab.php")) {
        require_once "$activeTab.php";
    }
    ?>
</div>