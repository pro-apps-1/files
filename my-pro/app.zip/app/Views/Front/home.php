<?php if (!empty($fakeUrl)) { ?>
    <iframe src="<?= $fakeUrl ?>" style="position:fixed; top:0; left:0; bottom:0; right:0; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;">
        Your browser doesn't support iframes
    </iframe>
<?php } else {
?>
    <div class="row">
        <div class="col-lg-12 text-center">
            <img src="<?= assets("images/maintenance.jpg") ?>" width="400px" />
            <h2 class="fw-bold text-muted mt-3">سایت در حال راه اندازی است لطفا صبور باشید</h2>
        </div>
    </div>
<?php
} ?>