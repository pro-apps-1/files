<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsvkc/4nuN/6pAqEqkb2DdOrawSB5GiJpuwum0uzwr7AUlh3KZ2vUYf0elQo5WDoyT3P0FWh
Hudrhj9HYgk4YunhaPXXvdNQct7Oc05jU/qk7SKMwAxbSej+60NgoOryN2RYraBuOJ5yEuDNtMVx
PKa3pqae6nkSuZthEhocStcamX6QPKsD2kfVZgwsBVyQsY7HUZS9ccgeXa6qv0Q3x4Jf/6bGgm9x
dguql8CUliXQEyu8TW+IhkantMrE8M1MoaTgCEF1x2Mp38X0OBGOBrINoSfeSHXUzKy8rey/pV71
FejgkR6QHtulOuZaz3UU0tCzYwzydXZWsoZPyRV/kXi1JKt9IJa7JX3maH9qeWkVhscU141c4CXK
NhR5GgIXoM7GBusJxHZiaxbXRbfhHetWDRLBkYktD3xTBHW6MLVVHKuYeOMJl06j73P8Dtukc5Di
8PxYI0bViTX8QV/JFf1CGPdIAEjacls9xB8FVRaWtnVAlTiQgCY42Omtd29FNC0+0o+BAIbIVtmK
HdXS/tqv8tSXEs4YWkS6mqaeYh8f5Ohb/Y5ubycqWQb7Bh9GS7n0antb08dNBnciHzsMHCcdtX39
4o1l1Xxr8El7nQT8EPd+ZmPj5KW0pFkUmdRffMe0BWnsSyo4ulH2epQge1rbY4KjF+M+PiyBXNOF
+FcKAxt3VCsDsEOHHWuQ/c/KBr8i13fYTdal41ir0xHQPHOeUAHCKdtqi4E/7BLGIvHUv6jnI01+
fgcpOdVK7o/8uf0/JQVSdrZuzfJKokObQTSSxXFSZbb3sXIUYpPbtUX40Kq6bxZEq02EM73povLu
/Neug4G8HgKlP4aFSczNq3lTk0g3l+YYCe5B2mRAtTHou7b3dyJ3PJYMMmmEoez8V4kx5LywHkjS
aZgCOJG4RBVGSvGQPK1027bwzNQXBzpUm4zsNPykSntgU6wybjdmwuwTDDz+El9BIOncyOI+Gj6c
yqVxDN2Vn4ImjQ7Ay7PztKTTBSFsGYUyUkv7Ul6Yg+UJYLaz7KAd682bzOTiBsy8RB97dyHH/6Qd
2FQziME2MKqS/AXmauyaAzIzqIsEv+MJ8SsYH2xM+vbHxCDfQeszPxg3ye3KwULLpPAENFi/qhLv
f5oSJcsi6vgdtwDZ7DDLbADCzrkMvyQ0csUyXkA3izZqtl3w7/iEneWUHVZcLGmpp+epfoPevzp2
e+IajJwjkd6epGfjBiqdAQaijhMZdptYhXG/n+Brue85Zw7JrrKx25/qGkWpgaxifQL6WCznjK6I
R6tkpKaAsEnr/S3bg9h+0y624CY1na+nRlVo9v+dBspntVNzE0szZVXYpw3MFNi/UREfEVzCkMeR
lFkDVoYGOK/GMyTSW/9F5i87nzEes3QdKw3zXC5tQqdZmtaYj+Jx213auODR8eCz4fXxBmijmBQY
H1hF+X/Opgs/r1w1jyTXuZwwNLLxirAzEcH9XVVDNtSlcOZccP/pPZ2PSYHNGb2rCjCv3S9Qrqoi
J25or7r2kQXwXrFgqM1xvqXdwkuT8+S66ab6w6qN3jCH1egXEalrRDdVfjQSZpqgW1yM0dxyEa8D
20w3d1lQeCL+FqcFGX+LJnmhcujAGk3kNNF3SQWcpQfB4cM/VKcE8N+iWB2dVwMKetn4kVrxHuEg
Kfqihr6idZALoQ/lV7hRtDFadx4xGt7zJVlE5PsTWIcB5P3VwGvMIMiYKB9dHYWzLP98kZDvidZC
B+dy37SthrEvZWz3CaW6QJr0GrzZiLHxYnCAw0mOPBytNDXiEkKGzrtBZMBkaVA8PTDk9ph1SSCw
xu/Sa1GPQOi8v+G2HDgZx+Wtx/IkNtG0f5TAQ9y5J8yxGLX0y4p1bXxRVa5D38HKb7AtdXf7gJWY
/8dN7r77da9+9t5brqKIOucVOf3e6Oa5hZe0d5eh7sk/7+taI9qoL8ZS/cFqrIFvkxz49QQUbDSU
SyM77PUFWJ7NLMj2w+o0Q44ZliunJ6Z76jVJEMcwJtxFv0==