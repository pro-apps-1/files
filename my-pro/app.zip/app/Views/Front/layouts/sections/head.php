<?php
$mainAppEnqueue = getMainAppEnqueue();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" data-bs-theme="<?= $activeTheme ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <title><?= $pageTitle ?></title>
    <!-- Icons -->
    <link rel="icon" type="image/x-icon" href="<?= $siteLogo ?>">
    <link rel="stylesheet" href="<?= assets("fonts/fontawsome.css") ?>" />
    <link rel="stylesheet" href="<?= assets("fonts/webfont.css") ?>" />
    <?= headerFiles() ?>
    <link rel="stylesheet" href="<?= assets("css/sweetalert2.css") ?>">
    <link rel="stylesheet" href="<?= $mainAppEnqueue["app_css_url"] ?>">
    <link rel="stylesheet" href="<?= $mainAppEnqueue["preset_css_url"] ?>">
    <script src="<?= assets("vendor/jquery/jquery.js") ?>"></script>
    <script>
        var activePage = "<?= $activePage ?>";
        var base_url = "<?= baseUrl() ?>";

        var baseUrl = function(seg = "") {
            return base_url + seg;
        };

        var assets = function(seg = "") {
            return baseUrl("assets/" + seg);
        };
    </script>
</head>

<body class="d-flex justify-content-center align-items-center h-100">