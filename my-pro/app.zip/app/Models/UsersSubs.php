<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class UsersSubs extends \App\Models\Users
{
    protected $table = 'users_subs';
    protected $primaryKey = 'id';

    protected $fillable = [
        'user_id',
        'package_id',
        'start_time',
        'end_time',
        'token',
        'limit_users',
        'validity_days',
        'traffic',
        'category_id',
    ];

    public function setEndTime($userId, $startDate, $endDate)
    {
        $startDate  = strtotime($startDate);
        $endDate    = strtotime($endDate);

        $this->where("user_id", $userId)
            ->update(["start_time" => $startDate, "end_time" => $endDate]);
    }


    public function getSubInfo($userId)
    {
        $userInfo = $this->where("user_id", $userId)
            ->first();
        if ($userInfo) {
            return $userInfo ;
        }
        return false;
    }

    public function checkUserToken($token)
    {
        $userInfo = $this->where("token", $token)
            ->first();
        if ($userInfo) {
            return $userInfo ;
        }
        return false;
    }


}
