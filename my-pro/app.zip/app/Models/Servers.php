<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;


class Servers extends \App\Models\BaseModel
{

    protected $table = 'servers';
    protected $primaryKey = 'id';

    protected $fillable = [
        'name',
        'title',
        'ip',
        'ssh_user',
        'ssh_pass',
        'ssh_port',
        'is_disabled',
        'is_configured',
        'country_code',
        'category_id',
        'limit_online_users',
        'ctime',
    ];

    public function saveServer($pdata, $uid, $editId = null)
    {
        $pdata          = trimArrayValues($pdata);

        $columnsArr["name"]                 = $pdata["name"];
        $columnsArr["ip"]                   = $pdata["ip"];
        $columnsArr["ssh_user"]             = $pdata["ssh_user"];
        $columnsArr["ssh_pass"]             = $pdata["ssh_pass"];
        $columnsArr["ssh_port"]             = $pdata["ssh_port"];
        $columnsArr["country_code"]         = $pdata["country_code"];
        $columnsArr["category_id"]          = getArrayValue($pdata, "category", 0);
        $columnsArr["limit_online_users"]   = getArrayValue($pdata, "limit_online_users", 0);

        if (!$editId) {
            $columnsArr["ctime"]            = time();
            $columnsArr["is_disabled"]      = 1;
            $columnsArr["is_configured"]    = 0;
            $serverId =  db($this->table)->insertGetId($columnsArr);
        } else {
            $this->updateOrCreate(['id' => $editId], $columnsArr);
            $serverId = $editId;
        }

        $metaColumns = [];

        if ($editId) {
            if (!empty($pdata["protocols"])) {
                $metaColumns["protocols"] = json_encode($pdata['protocols']);
            }
        } else {
            $metaColumns["protocols"] = json_encode($pdata['protocols']);
        }

        if (!empty($pdata["ovpn_subdomain"])) {
            $metaColumns["ovpn_subdomain"] = $pdata["ovpn_subdomain"];
        }

        if (!empty($pdata["ssh_category"])) {
            $metaColumns["ssh_category"] = $pdata["ssh_category"];
        }

        if (!empty($pdata["openvpn_category"])) {
            $metaColumns["openvpn_category"] = $pdata["openvpn_category"];
        }

        if (!empty($pdata["v2ray_category"])) {
            $metaColumns["v2ray_category"] = $pdata["v2ray_category"];
        }

        $this->saveMeta($serverId, $metaColumns);

        return $serverId;
    }

    public function saveMeta($serverId, $columnsArr)
    {
        foreach ($columnsArr as $name => $value) {
            $where = ["meta_name" => $name, "server_id" => $serverId];
            $isExist = db("servers_meta")
                ->where($where)
                ->count();
            if ($isExist) {
                db("servers_meta")->where($where)->update(["meta_value" => $value]);
            } else {
                $values["meta_name"] = $name;
                $values["meta_value"] = $value;
                $values["ctime"] = time();
                $values["server_id"] = $serverId;
                db("servers_meta")->insert($values);
            }
        }
    }

    public function getMetas($serverId, $name = "")
    {
        $jsonMeta = ["protocols"];
        $query =  db("servers_meta")->where("server_id", $serverId);
        if ($name) {
            $query->where("meta_name", $name);
        }
        $query = $query->get();
        if ($query->count()) {
            if ($name) {
                return  $query->first();
            }
            $rows = $query->toArray();
            $result = [];
            foreach ($rows as $row) {
                $metaName   = $row->meta_name;
                $metaValue  =  $row->meta_value;
                if (in_array($metaName, $jsonMeta)) {
                    $metaValue = json_decode($metaValue, true);
                }

                $result[$metaName] = $metaValue;
            }
            return $result;
        }
        return false;
    }

    public function dataTableList($pdata, $licensePlan, $uid)
    {

        $select     = [
            "servers.*",
            "categories.name as category",
            "servers_meta.meta_value as installed_openvpn",
            db()::raw("COUNT(user_id) as total_online")
        ];

        $query = db($this->table)->select($select)
            ->leftJoin("users_online", "users_online.server_id", "=", "servers.id")
            ->leftJoin("categories", "categories.id", "=", "servers.category_id")
            ->leftJoin("servers_meta", function ($query) {
                $query->on("servers_meta.server_id", "=", "servers.id")
                    ->where("servers_meta.meta_name", "=", "installed_openvpn");
            })
            ->groupBy("servers.id");


        if (!empty($pdata["search"]["value"])) {
            $search = $pdata["search"]["value"];
            $search = trim($search);
            if (!empty($search)) {
                $query->where(function ($q) use ($search) {
                    $q->where("servers.name",  "LIKE", "%$search%")
                        ->orWhere("servers.ip",  "=",   "$search");
                });
            }
            $pdata["search"]["value"] = "";
        }

        $limitShow  = getTotalRowsInPlan("servers");
        if ($limitShow) {
            $subquery = db($this->table)->select("id")->limit($limitShow);
            $query->joinSub($subquery, 'subquery', 'subquery.id', '=', 'servers.id');
        }

        if (!empty($pdata["status"])) {
            $query->where("server.status", $pdata["status"]);
        }

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $servers        = $DataTable->query()->toArray();

        $resServers     = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;
        $countries      = getCountries();

        foreach ($servers as $server) {
            $server = (array) $server;
            $num = $num + 1;
            $row = array();

            $createTime    = Jalalian::forge($server["ctime"]);
            $countryCode   = $server["country_code"];

            $row['id']              = $server["id"];
            $row['name']            = $server["name"];
            $row['category']        = $server["category"];
            $row['category_id']     = $server["category_id"];
            $row['installed_openvpn']     = $server["installed_openvpn"];
            $row['total_online']    = $server["total_online"];
            $row['limit_online_users']    = $server["limit_online_users"];
            $row['country_code']    = $countryCode;
            $row['country_name']    = getCountryName($countryCode, $countries);
            $row['ip']              = $server["ip"];
            $row['is_disabled']     = intval($server["is_disabled"]);
            $row['is_configured']   = intval($server["is_configured"]);
            $row['create_date']     = $createTime->format('Y/m/d');
            $row['create_time']     = $createTime->format('H:i:s');
            $row['country_flag']    = countryFlagUrl($countryCode);
            $row['license_plan']    = $licensePlan;
            $row['idx']             = $num;

            $resServers[] = $row;
        }

        $result = $DataTable->make($resServers);
        return $result;
    }

    public function isExistIp($value, $uid = null)
    {
        $query = $this->where("ip", $value);
        if ($uid != null) {
            $query->where('id', '!=', $uid);
        }
        return $query->count();
    }

    public function getServerByIp($ip)
    {
        $select = ["servers.id"];

        $query = db($this->table)->select($select)
            ->where("ip", $ip)
            ->get();

        if ($query->count()) {
            $row    = $query->first();
            $id     = $row->id;
            return $this->getInfo($id);
        }
        return false;
    }

    public function getInfo($serverId)
    {
        $select = ["servers.*"];

        $serverInfo = $this->select($select)
            ->where("id", $serverId)
            ->first();

        if ($serverInfo) {
            $serverInfo  = (object) $serverInfo->getAttributes();
            $countryCode = $serverInfo->country_code;

            $serverInfo->country_name = getCountryName($countryCode);
            $serverInfo->country_flag = countryFlagUrl($countryCode);

            $serverInfo->ssh_domain     = "";
            $serverInfo->openvpn_domain = "";
            $serverInfo->v2ray_domain   = "";

            $sMeta = $this->getMetas($serverInfo->id);
            if ($sMeta) {
                foreach ($sMeta  as $metaKey => $metaValue) {
                    $serverInfo->$metaKey = $metaValue;
                }
                $dModel = new \App\Models\Domains();
                if (!empty($serverInfo->ssh_category)) {
                    $sshDomain = $dModel->getSubdomainByCategory($serverInfo->ssh_category);
                    if ($sshDomain) {
                        $serverInfo->ssh_domain = $sshDomain;
                    }
                }

                if (!empty($serverInfo->openvpn_category)) {
                    $ovpnDomain = $dModel->getSubdomainByCategory($serverInfo->openvpn_category);
                    if ($ovpnDomain) {
                        $serverInfo->openvpn_domain = $ovpnDomain;
                    }
                }

                if (!empty($serverInfo->v2ray_category)) {
                    $v2rayDomain = $dModel->getSubdomainByCategory($serverInfo->v2ray_category);
                    if ($v2rayDomain) {
                        $serverInfo->v2ray_domain = $v2rayDomain;
                    }
                }
            }

            return  $serverInfo;
        }
        return false;
    }

    public function getAllActive()
    {
        $select = [
            "servers.*",
            "onlineSubs.total_online"
        ];

        $onlineSubquery = db('users_online')
            ->select("server_id", db()::raw("COUNT(user_id) as total_online"))
            ->groupBy("server_id");

        $query = db($this->table)->select($select)
            ->leftJoinSub($onlineSubquery, 'onlineSubs', function ($join) {
                $join->on('onlineSubs.server_id', '=', 'servers.id');
            })
            ->where("servers.is_disabled", 0)
            ->where("servers.is_configured", 1)
            ->orderBy("onlineSubs.total_online", "DESC")
            ->get();

        if ($query->count()) {
            $rows   = $query->toArray();

            return  $rows;
        }
        return false;
    }

    public function getActiveForFiltering()
    {
        $select = [
            "servers.id",
            "servers.ip",
            "servers_meta.meta_value"
        ];
        $query = db($this->table)->select($select)
            ->where("servers.is_disabled", 0)
            ->where("servers.is_configured", 1)
            ->leftJoin("servers_meta", function ($join) {
                $join->on("servers_meta.server_id", "=", "servers.id")
                    ->where("meta_name", "check_filtering");
            })
            ->get();

        if ($query->count()) {
            $rows   = $query->toArray();
            return  $rows;
        }
        return false;
    }

    public function checkHasActiveServers()
    {
        return $this->where("is_disabled", 0)
            ->where("is_configured", 1)
            ->count();
    }

    public function deleteServer($id)
    {
        $this->where("id", $id)->delete();
    }

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }

    public function doConfiguration($id)
    {
        $this->where("id", $id)->update(["is_configured" => 1]);
    }

    public function getConfiguredCount()
    {
        return $this->where("is_configured", 1)
            ->where("is_disabled", 0)
            ->count();
    }

    public function toggleActive($sid, $uid)
    {
        $serverInfo = $this->getInfo($sid);
        if ($serverInfo) {
            $isDisabled   = $serverInfo->is_disabled;

            if ($isDisabled) {
                $this->where("id", $sid)->update(["is_disabled" => 0]);
            } else {
                $this->where("id", $sid)->update(["is_disabled" => 1]);
            }
        }
    }

    public function checkLogin($serverId)
    {
        $serverInfo = $this->getInfo($serverId);

        $serverNet = new  \App\Libraries\ServerNet();

        $ip        = $serverInfo->ip;
        $sshUser   = $serverInfo->ssh_user;
        $sshPass   = $serverInfo->ssh_pass;
        $sshPort   = $serverInfo->ssh_port;

        try {
            $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
            $serverNet->login();
            $serverNet->disconnect();
        } catch (\Exception $err) {
            throw $err;
        }
    }



    public function syncUsers($serverId, $lastUid = 0)
    {

        $serverInfo = $this->getInfo($serverId);

        $sModel     = new \App\Models\Subscribers();
        $users      = $sModel->getSyncUsers($lastUid);
        $ip         = $serverInfo->ip;
        if ($users) {
            try {
                $lastUid    = 0;
                $serverApi  = new \App\Libraries\ServerApi($ip);
                $susers = [];
                foreach ($users as $user) {
                    $username   = $user->username;
                    $password   = $user->password;
                    $uuid       = $user->uuid;
                    $lastUid    = $user->id;

                    $susers[]   = [
                        "username"  => $username,
                        "password"  => $password,
                        "uuid"      => $uuid
                    ];
                }
                $serverApi->createUsers($susers);
                return  $lastUid;
            } catch (\Exception $err) {
                throw $err;
            }
        }
        return false;
    }


    public function getFirstForCheckFiltering()
    {
        $subQuery = db("servers_meta")
            ->select("server_id")
            ->where("meta_name", "checkhost_reqid");

        $query = db($this->table)
            ->whereNotIn("servers.id", $subQuery)
            ->orderBy("id", "ASC")
            ->where("is_configured", 1)
            ->where("is_disabled", 0)
            ->limit(1)
            ->get();
        if ($query->count()) {
            return $query->first();
        }

        return false;
    }

    public function getFirstForCheckAvail($lastId = 0)
    {

        $query = db($this->table)
            ->where("servers.id", ">", $lastId)
            ->orderBy("id", "ASC")
            ->where("is_configured", 1)
            ->where("is_disabled", 0)
            ->limit(1)
            ->get();
        if ($query->count()) {
            return $query->first();
        }

        return false;
    }

    public function getFirstCheckhostId()
    {
        $time = time() - (10 * 60);

        $select = ["servers_meta.*", "servers.name", "servers.ip"];
        $query = db("servers_meta")
            ->select($select)
            ->join("servers", "servers.id", "=", "servers_meta.server_id")
            ->where("servers_meta.meta_name", "checkhost_reqid")
            ->where("servers_meta.ctime", "<", $time)
            ->orderBy("servers_meta.id", "ASC")
            ->limit(1)
            ->get();
        if ($query->count()) {
            return $query->first();
        }

        return false;
    }

    public function getTotalServers($isDisabled = null)
    {
        $query = $this->where("id", ">", 0);
        if ($isDisabled != null) {
            if ($isDisabled) {
                $query->where("is_disabled", 1);
            } else {
                $query->where("is_disabled", 0);
            }
        }

        return  $query->count();
    }

    public function setMeta($serverId, $metaName, $metaValue)
    {
        $where = [
            "server_id" => $serverId,
            "meta_name" => $metaName,
        ];
        $query = db("servers_meta")->where($where)->get();

        if ($query->count()) {
            db("servers_meta")->where($where)->update(["meta_value" => $metaValue]);
        } else {

            db("servers_meta")->insert([
                "server_id"     => $serverId,
                "meta_value"    => $metaValue,
                "meta_name"     => $metaName,
                "ctime"         => time()
            ]);
        }
    }

    public function deleteMeta($metaId)
    {
        db("servers_meta")->where("id", $metaId)->delete();
    }

    public function getResources($serverId)
    {
        $serverInfo = $this->getInfo($serverId);
        if ($serverInfo) {
            $ip        = $serverInfo->ip;

            try {
                $serverApi = new \App\Libraries\ServerApi($ip);
                $result = $serverApi->getResources();

                if ($result) {
                    $cpu            = $result["cpu"];
                    $memeory        = $result["memeory"];
                    $traffic        = $result["traffic"];
                    $hdd            = $result["hdd"];

                    //cpu data
                    $totalCores     = $cpu["cores"];
                    $totalCores     = $totalCores ? $totalCores : 1;

                    $loadAvg        = $cpu["loadavg"][0];
                    $cpuLoadAvg     = ($loadAvg / ($totalCores + 1)) * 100;
                    $cpuLoadAvg     = round($cpuLoadAvg, 2);

                    $useBgColor     = getUsageBgColor($cpuLoadAvg);
                    $useTextColor   = getBgTextColor($useBgColor);

                    $cpu["load_avg"]        = $cpuLoadAvg;
                    $cpu["load_avg_bg"]     = $useBgColor;
                    $cpu["load_avg_color"]  = $useTextColor;


                    //memory data
                    $totalMem       = $memeory["total"];
                    $freeMem        = $memeory["free"];
                    $usedMem        = $memeory["used"];
                    $usagePercent   = round(($usedMem / $totalMem) * 100);
                    $useBgColor     = getUsageBgColor($usagePercent);
                    $useTextColor   = getBgTextColor($useBgColor);

                    $memeory["total"]            = convertToPrettyUnit($totalMem);
                    $memeory["used"]             = convertToPrettyUnit($usedMem);
                    $memeory["free"]             = convertToPrettyUnit($freeMem);
                    $memeory["use_percent"]      = $usagePercent;
                    $memeory["use_bg"]           = $useBgColor;
                    $memeory["use_color"]        = $useTextColor;


                    //hdd data
                    $precentHdd     = preg_replace('/[^0-9]/', '', $hdd["free"]);;
                    $useBgColor     = getUsageBgColor($precentHdd);
                    $useTextColor   = getBgTextColor($useBgColor);

                    $hdd["use_bg"]       = $useBgColor;
                    $hdd["use_color"]    = $useTextColor;

                    $result["cpu"]      = $cpu;
                    $result["memeory"]  = $memeory;
                    $result["hdd"]      = $hdd;
                    return  $result;
                }
            } catch (\Exception $err) {
                throw $err;
            }
        }
    }

    public function actionUsersInServers($action, $users)
    {
        $servers    = $this->getAllActive();

        if ($servers) {

            foreach ($users as $user) {
                $username       = $user["username"];
                $password       = !empty($user["password"]) ? $user["password"] : "";
                $uuid           = !empty($user["uuid"]) ? $user["uuid"] : "";
                $actionUsers[]  = [
                    "username" => $username,
                    "password" => $password,
                    "uuid"     => $uuid
                ];
            }

            foreach ($servers as $server) {
                $ip        = $server->ip;
                try {
                    $serverApi      = new \App\Libraries\ServerApi($ip);

                    if ($action == "create") {
                        $serverApi->createUsers($actionUsers);
                    } else if ($action == "update") {
                        $serverApi->updateUsers($actionUsers);
                    } else if ($action == "delete") {
                        $serverApi->removeUsers($actionUsers);
                    } else if ($action == "activate") {
                        $serverApi->createUsers($actionUsers);
                    } else if ($action == "deactivate") {
                        $serverApi->removeUsers($actionUsers);
                    } else if ($action == "kill") {
                        $serverApi->killUsers($actionUsers);
                    }
                } catch (\Exception $err) {
                    throw $err;
                }
            }
        }
    }

    public function setupServer($serverId, $mainSetup = true)
    {
        $stModel    = new \App\Models\Settings();
        $serverInfo = $this->getInfo($serverId);

        $result     = [
            "status"        => "success",
            "messages"      => "",
            "status_text"   => "",
            "log_body"      => "",
            "is_finished"   => false
        ];

        if ($serverInfo) {
            $serverNet = new  \App\Libraries\ServerNet();

            $ip                 = $serverInfo->ip;
            $sshUser            = $serverInfo->ssh_user;
            $sshPass            = $serverInfo->ssh_pass;
            $sshPort            = $serverInfo->ssh_port;
            $protocols          = $serverInfo->protocols;
            $isConfig           = $serverInfo->is_configured;

            $enableSsh          = in_array("ssh", $protocols);
            $enabledOvpn        = in_array("openvpn", $protocols);
            $enabledV2ray       = in_array("v2ray", $protocols);

            $settings           = $stModel->getSettings();
            $serversToken       = getArrayValue($settings, "servers_token", "");
            $serversSSH         = getArrayValue($settings, "servers_ssh", []);
            $serversV2ray       = getArrayValue($settings, "servers_v2ray", []);
            $serversOpenvpn     = getArrayValue($settings, "servers_openvpn", []);

            $v2rayDomain        = $serverInfo->v2ray_domain;
            $openvpnDomain      = $serverInfo->openvpn_domain;
            $sshDomain          = $serverInfo->ssh_domain;

            $configsArr  = [
                "api_token"     => $serversToken,
                "api_url"       => baseUrl("sapi"),
            ];

            if ($enableSsh) {
                $serversSSH["domain"] = $sshDomain;
                $configsArr["servers_ssh"] = $serversSSH;
            }

            if ($enabledOvpn) {
                $serversOpenvpn["domain"]       = $openvpnDomain;
                $configsArr["servers_openvpn"]  = $serversOpenvpn;
            }

            if ($enabledV2ray) {
                $serversV2ray["domain"]         = $v2rayDomain;
                $configsArr["servers_v2ray"]    = $serversV2ray;
            }

            try {
                $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
                $serverNet->login();

                if ($mainSetup) {
                    $installStatus          = $serverNet->getConfigurationStatus();
                    $installLog             = $serverNet->getConfigurationLog();
                    $result["status_text"]  = $installStatus;
                    $result["log_body"]     = $installLog;

                    if (empty($installStatus)) {
                        $serverNet->startConfiguration($configsArr);
                    } else {
                        if ($isConfig) {
                            $result["status"] = "success";
                            $result["is_finished"] = true;
                        } else {
                            $result["status"] = "success";
                            $result["is_finished"] = false;
                        }
                    }
                } else {
                    $serverNet->setupConfigFile($configsArr);
                }
            } catch (\Exception $err) {
                $result["messages"] = $err->getMessage();
                $result["status"]   = "error";
            }
        } else {
            $result["messages"] = "اطلاعات سرور در دسترس نیست";
            $result["status"] = "error";
        }

        return $result;
    }

    public function getServersProtocol($protocol)
    {
        $metaName = "installed_$protocol";

        $query =  db("servers_meta")->where("meta_name", $metaName)
            ->select("servers.*")
            ->join("servers", "servers.id", "=", "servers_meta.server_id")
            ->where("servers.is_configured", 1)
            ->where("servers.is_disabled", 0)
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            if ($protocol == "openvpn") {
                foreach ($rows as $key => $row) {
                    $ovpnCategory = $this->getMetas($row->id, "openvpn_category");
                    $row->openvpn_category = 0;
                    if ($ovpnCategory) {
                        $row->openvpn_category = $ovpnCategory->meta_value;
                    }
                    $rows[$key] = $row;
                }
            }
            return $rows;
        }

        return false;
    }
}
