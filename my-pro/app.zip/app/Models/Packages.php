<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;


class Packages extends \App\Models\BaseModel
{

    protected $table = 'packages';
    protected $primaryKey = 'id';
    protected $fillable = [
        'name',
        'validity_days',
        'limit_users',
        'start_time_type',
        'price',
        'traffic',
        'is_disabled'
    ];


    public function getInfo($id)
    {
        $query = db($this->table)->where("id", $id)
            ->get();
        if ($query->count()) {
            $row        = $query->first();
            $row->price = $row->price;
            $row->fprice = number_format($row->price);
            return  $row;
        }
        return false;
    }

    public function getAllActive()
    {
        //
        $query = db($this->table)->where("is_disabled", 0)
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            foreach ($rows as $key => $row) {
                $row->price = number_format($row->price);
                $rows[$key] = $row;
            }

            return  $rows;
        }
        return false;
    }

    public function getUserPackages($uid = 0, $userRole = "admin")
    {

        $query = db($this->table)->select("packages.*")->where("is_disabled", 0);

        if ($userRole != "admin" && $uid) {
            $query->join("users_packages", "users_packages.package_id", "=", "packages.id")
                ->where("users_packages.user_id", $uid);
        }

        $query = $query->get();

        if ($query->count()) {
            $rows = $query->toArray();

            foreach ($rows as $key => $row) {
                $row->price = number_format($row->price);
                $rows[$key] = $row;
            }

            return  $rows;
        }
        return false;
    }

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }


    public function savePackages($pdata, $editId = null)
    {
        $columnsArr     = [];
        $pdata          = trimArrayValues($pdata);

        $columnsArr["name"]             = $pdata["name"];
        $columnsArr["validity_days"]    = $pdata["validity_days"];
        $columnsArr["limit_users"]      = $pdata["limit_users"];
        $columnsArr["start_time_type"]  = $pdata["start_time_type"];
        $columnsArr["traffic"]          = $pdata["traffic"];
        $columnsArr["price"]            = removeCommaStr($pdata["price"]);
        $columnsArr["is_disabled"]      = $pdata["is_disabled"];

        $this->updateOrCreate(['id' => $editId], $columnsArr);
    }


    public function deletePackage($pid, $uid)
    {
        $this->where("id", $pid)->delete();
    }

    public function dataTableList($pdata, $uid)
    {
        $select = ["*"];

        $query          = $this->select($select);
        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $packages       = $DataTable->query()->toArray();

        $resPackages       = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($packages as $package) {
            $num = $num + 1;
            $row = array();

            $row['id']                  = $package["id"];
            $row['idx']                 = $num;
            $row['name']                = $package["name"];
            $row['validity_days']       = $package["validity_days"];
            $row['traffic']             = $package["traffic"];
            $row['limit_users']         = $package["limit_users"];
            $row['start_time_type']     = $package["start_time_type"];
            $row['price']               = number_format($package["price"]);
            $row['is_disabled']         = $package["is_disabled"];

            $resPackages[] = $row;
        }

        $result = $DataTable->make($resPackages);
        return $result;
    }
}
