<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class Subscribers extends \App\Models\Users
{

    public function dataTableList($pdata, $uid, $urole)
    {
        $select = [
            "users.id",
            "users.username",
            "users.password",
            "users.role",
            "users.status",
            "users.status_desc",
            "users.full_name",
            "users.utime",
            "users.ctime",
            "users.mobile",
            "users_subs.limit_users",
            "users_subs.traffic",
            "users_subs.start_time",
            "users_subs.end_time",
            "users_subs.token",
            "users_subs.price",
            "users_subs.validity_days",
            "users_traffics.total as consumer_traffic",
            "online_users.total_online",
            "creator.full_name as creator_name",
            "creator.unlimited as creator_unlimited",
        ];

        $onlineQuery = db("users_online")
            ->select("user_id", db()::Raw("COUNT(id) AS total_online"))
            ->groupBy("user_id");

        $query = $this->select($select)
            ->join('users_subs', 'users_subs.user_id', '=', 'users.id')
            ->leftJoin('users as creator', 'creator.id', '=', 'users.cid')
            ->join('users_traffics', 'users_traffics.user_id', '=', 'users.id')
            ->leftJoinSub($onlineQuery, 'online_users', function ($join) {
                $join->on('online_users.user_id', '=', 'users.id');
            })
            ->where("users.role", "subscriber");

        if (!empty($pdata["main_search"])) {
            $search = $pdata["main_search"];
            $search = trim($search);
            if (!empty($search)) {
                $query->where(function ($q) use ($search) {
                    $q->where("users.username",         "LIKE",     "%$search%")
                        ->orWhere("users.mobile",       $search)
                        ->orWhere("users.desc",         "LIKE",     "%$search%")
                        ->orWhere("users.full_name",    "LIKE",     "%$search%")
                        ->orWhere("creator.full_name",  "LIKE",     "%$search%");
                });
            }
            $pdata["search"]["value"] = "";
        }

        if (!empty($pdata["order"])) {
            $order          = $pdata["order"];
            $columns        = $pdata["columns"];

            $orderColumn    = $order[0]["column"];
            $orderDir       = $order[0]["dir"];
            $columnKey      = $columns[$orderColumn]["data"];

            $validKeys      = ["id", "username", "limit_users", "start_time", "ctime", "total_online", "full_name"];

            if (in_array($columnKey, $validKeys)) {
                $query->orderBy($columnKey, $orderDir);
            } else {
                if ($columnKey == "traffic") {
                    $query->orderBy("consumer_traffic", $orderDir);
                } else if ($columnKey == "remaining_days") {
                    $query->orderBy("end_time", $orderDir);
                }
            }
            $pdata["order"] = "";
        }

        if (!empty($pdata["status"])) {
            $query->where("users.status", $pdata["status"]);
        }

        if (!empty($pdata["creator"])) {
            $query->where("users.cid", $pdata["creator"]);
        }

        if (!empty($pdata["expiry_type"])) {
            $expiryType = $pdata["expiry_type"];

            if ($expiryType == "today") {
                $startTime = strtotime("today", time());
                $endTime   = strtotime("tomorrow", $startTime) - 1;
            } else if ($expiryType == "this_week") {
                $startTime  = strtotime("this Saturday");
                $endTime    = strtotime("+6 days",  $startTime);
            } else {
                $startTime = strtotime("today", time());
                $endTime   =  $startTime + (3 * 86400);
            }

            $query->where("users_subs.start_time", ">", 0)
                ->where(function ($query) use ($startTime, $endTime) {
                    $query->where("users_subs.end_time", ">=", $startTime)
                        ->where("users_subs.end_time", "<", $endTime);
                });
        }


        if (!empty($pdata["limit_users"])) {
            $limitUsers = $pdata["limit_users"];
            if ($limitUsers == "single") {
                $query->where("users_subs.limit_users", 1);
            } else {
                $query->where("users_subs.limit_users", ">", 1);
            }
        }

        if (!empty($pdata["conn_type"])) {
            $connType = $pdata["conn_type"];
            if ($connType == "online") {
                $query->join("users_online", "users_online.user_id", "=", "users.id");
            }
        }

        if ($urole != "admin") {
            $query->where("users.cid", $uid);
        }

        $limitShow  = getTotalRowsInPlan("subscribers");
        if ($limitShow) {
            $sub        = clone $query;
            $subquery   = $sub->limit($limitShow);
            $query->joinSub($subquery, 'subquery', 'subquery.id', '=', 'users.id');
        }

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $users          = $DataTable->query()->toArray();

        $resUsers       = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($users as $user) {
            $user = (array) $user;

            $utime          = 0;
            $startTime      = 0;
            $endTime        = 0;
            $remainingDays  = 0;


            $uStartTime      = $user["start_time"];
            $uEndTime        = $user["end_time"];
            $username        = $user["username"];
            $validityDays    = $user["validity_days"];

            $diffrenceDate   = "";

            if ($user["utime"]) {
                $utime = Jalalian::forge($user["ctime"])->format('Y/m/d');
            }

            if ($uStartTime) {
                $startTime = Jalalian::forge($uStartTime)->format('Y/m/d');
            }

            if ($uEndTime) {
                $endTime = Jalalian::forge($uEndTime)->format('Y/m/d');
            }

            if ($uEndTime && $uStartTime && $validityDays) {
                $remainingDays  = translateDiffTime($uEndTime);
                $uStartTime     = getStartOfDate($uStartTime);
                $uEndTime       = getEndOfDate($uEndTime);
                $diffrenceDate  = calcDifferenceDate($uStartTime, $uEndTime);
            }

            $totalOnline = $user["total_online"];
            $totalOnline = $totalOnline ? $totalOnline : 0;

            $num = $num + 1;
            $row = array();

            $row['id']                      = $user["id"];
            $row['idx']                     = $num;
            $row['username']                = $username;
            $row['price']                   = number_format($user["price"]);
            $row['creator_name']            = $user["creator_name"] ? $user["creator_name"] : "";
            $row['creator_unlimited']       = $user["creator_unlimited"];
            $row['password']                = $user["password"];
            $row['full_name']               = $user["full_name"];
            $row['limit_users']             = $user["limit_users"];
            $row['mobile']                  = $user["mobile"];
            $row['status']                  = $user["status"];
            $row['status_desc']             = $user["status_desc"];
            $row['status_desc_label']       = transUserStatusDesc($user["status_desc"]);
            $row['status_label']            = userStatusLabel($user["status"]);
            $row['start_time']              = $startTime;
            $row['end_time']                = $endTime;
            $row['remaining_time']          = $user["end_time"] - time();
            $row['ctime']                   = Jalalian::forge($user["ctime"])->format('Y/m/d');
            $row['utime']                   = $utime;
            $row['traffic']                 = $user["traffic"];
            $row['consumer_traffic']        = $user["consumer_traffic"];
            $row['traffic_format']          = $user["traffic"] ? formatTraffice($user["traffic"]) : "نامحدود";
            $row['consumer_traffic_format'] = formatTraffice($user["consumer_traffic"]);
            $row['diffrence_date']          = $diffrenceDate;
            $row['validity_days']           = $validityDays;
            $row['remaining_days']          = $remainingDays;
            $row['total_online']            = $totalOnline;

            $resUsers[] = $row;
        }
        $result = $DataTable->make($resUsers);
        return $result;
    }

    public function saveUsers($pdata, $uid, $ucInfo, $editId = null)
    {
        $cRole          = $ucInfo->role;
        $cUnlimited     = $ucInfo->unlimited;

        $pcModel        = new \App\Models\Packages();

        $pdata          = trimArrayValues($pdata);
        $userInfo       = $editId   ? $this->getEditInfo($editId) : null;
        $startTime      = $userInfo ? $userInfo->start_time : 0;
        $endTime        = $userInfo ? $userInfo->end_time : 0;

        $subsSettingsBy = getArrayValue($pdata, "subs_settings_by", "");
        $packageId      = getArrayValue($pdata, "package_id", 0);
        $packageInfo    = null;
        $startTimeType  = "";
        $validityDays   = 0;
        $limitUsers     = 0;
        $traffic        = 0;
        $packagePrice   = 0;

        if ($subsSettingsBy == "package") {
            if ($editId && !$packageId) {
                $packageId = $userInfo->package_id;
            }
            $packageInfo    = $pcModel->getInfo($packageId);

            $validityDays   = $packageInfo->validity_days;
            $startTimeType  = $packageInfo->start_time_type;
            $limitUsers     = $packageInfo->limit_users;
            $traffic        = $packageInfo->traffic;
            $packagePrice   = $packageInfo->price;
        } else if ($subsSettingsBy == "manual") {
            $packageId      = 0;
            $limitUsers     = getArrayValue($pdata, "limit_users", 0);
            $traffic        = getArrayValue($pdata, "traffic", 0);
            $validityDays   = getArrayValue($pdata, "validity_days", 0);
            $startTimeType  = getArrayValue($pdata, "start_time_type", "");
        }

        if ($startTimeType == 'create-user') {
            if (!$startTime) {
                $startTime  = time();
                $endTime    = time() + ($validityDays * 86400);
            }
        } else {
            if ($startTime) {
                $endTime  = $startTime + ($validityDays * 86400);
            }
        }

        $userColumns     = [];
        $subsColumns     = [];

        $setSubsData    = false;
        //for create 
        if (!$editId) {
            $nextUid    = $this->getNextUserId();
            $userColumns["username"]         = $pdata["username"];
            $userColumns["cid"]              = $uid;
            $userColumns["ctime"]            = time();
            $userColumns["uid"]              = 0;
            $userColumns["utime"]            = 0;
            $userColumns["credit"]           = 0;
            $userColumns["unlimited"]        = 0;
            $userColumns["status"]           = "active";
            $userColumns["status_desc"]      = "";

            $subsColumns["token"]            = generateUserToken($nextUid);
            $subsColumns["uuid"]             = createUuidV4Secure();
            $setSubsData = true;
        } else {
            $userColumns["utime"]            = time();
            $userColumns["uid"]              = $uid;
            if ($cRole == "admin" || $cUnlimited) {
                $setSubsData = true;
            }
        }
        if ($cUnlimited) {
            $packagePrice = 0;
        }

        if ($userInfo && !$userInfo->uuid) {
            $subsColumns["uuid"]             = createUuidV4Secure();
        }

        if ($setSubsData) {
            $subsColumns["start_time"]       = $startTime;
            $subsColumns["end_time"]         = $endTime;
            $subsColumns["limit_users"]      = $limitUsers;
            $subsColumns["traffic"]          = $traffic * 1024;
            $subsColumns["validity_days"]    = $validityDays;
            $subsColumns["package_id"]       = $packageId;
            $subsColumns["price"]            = $packagePrice;
        }

        $userColumns["role"]             = "subscriber";
        $userColumns["full_name"]        = getArrayValue($pdata, "full_name");
        $userColumns["password"]         = $pdata["password"];
        $userColumns["mobile"]           = getArrayValue($pdata, "mobile");
        $userColumns["desc"]             = getArrayValue($pdata, "desc");

        $subsColumns["category_id"]      = getArrayValue($pdata, "category", 0);


        $trafficCols["user_id"]     = 0;
        $trafficCols["download"]    = 0;
        $trafficCols["upload"]      = 0;
        $trafficCols["total"]       = 0;
        $trafficCols["ctime"]       = time();
        $trafficCols["utime"]       = 0;

        $tValues = [
            "userColumns"   => $userColumns,
            "subsColumns"   => $subsColumns,
            "userInfo"      => $userInfo,
            "cRole"         => $cRole, //create user role
            "editId"        => $editId,
            "uid"           => $uid,
            "packageInfo"   => $packageInfo,
            "trafficCols"   => $trafficCols,
            "cUnlimited"   => $cUnlimited,
        ];

        try {
            $result =  db()::transaction(function () use ($tValues) {

                $editId         = $tValues["editId"];
                $userColumns    = $tValues["userColumns"];
                $subsColumns    = $tValues["subsColumns"];
                $userInfo       = $tValues["userInfo"];
                $packageInfo    = $tValues["packageInfo"];
                $trafficCols    = $tValues["trafficCols"];
                $uid            = $tValues["uid"];
                $cRole          = $tValues["cRole"];
                $cUnlimited     = $tValues["cUnlimited"];

                $result         = [];

                if ($editId) {
                    $userId = $editId;

                    db($this->table)->where("id", $userId)->update($userColumns);

                    if (!empty($subsColumns)) {
                        db("users_subs")->where("user_id", $userId)->update($subsColumns);
                    }
                } else {
                    $userId  = db("users")->insertGetId($userColumns);

                    $subsColumns["user_id"] = $userId;
                    db("users_subs")->insert($subsColumns);

                    $trafficCols["user_id"] = $userId;
                    db("users_traffics")->insert($trafficCols);
                }

                $result["id"] = $userId;

                $username = $userInfo ? $userInfo->username : $userColumns["username"];

                if (!$editId && $cRole != "admin" && !$cUnlimited) {
                    $creditModel = new \App\Models\Credits();
                    $creditData = [
                        "operation" => "dec",
                        "amount"    => $packageInfo->price,
                        "desc"      => "کسر موجودی بابت ساخت کاربر $username",
                    ];

                    $creditModel->addCredit($creditData, $uid, $uid);
                }

                $result["sync_action"] = false;
                if (!$userInfo) {
                    $result["sync_action"] = "create";
                    $result["username"] =  $username;
                } else {
                    $oldPass  = $userInfo->password;
                    $username = $userInfo->username;
                    $newPasss = $userColumns["password"];

                    if ($oldPass != $newPasss) {
                        $result["username"] =  $username;
                        $result["sync_action"] = "create";
                    }
                }

                return $result;
            });

            if (!$editId) {
                $username = $pdata["username"];
                $desc = "افزودن مشترک $username";
                addSysLog("add_subscriber", $desc, $uid);
            } else {
                $desc = "ویرایش مشترک $userInfo->username";
                addSysLog("edit_subscriber", $desc, $uid);
            }

            return $result;
        } catch (\Exception $err) {
            db()::rollback();
            throw $err;
        }
    }

    public function getNextUserId()
    {
        $prefix     = getConfig("db")["prefix"];
        $table      = $prefix . "users";
        $nextId     = db()::selectOne("SHOW TABLE STATUS LIKE '$table'")->Auto_increment;
        return $nextId;
    }

    public function getEditInfo($userId)
    {
        //crole creator role
        $select = [
            "users.*",
            "users_subs.*",
            "cusers.role            as crole",
            "cusers.full_name       as cname",
            "cusers.credit          as ccredit",
            "cusers.unlimited       as cunlimited",
            "users_traffics.total   as consumer_traffic",
        ];

        $info = $this->where("users.id", $userId)
            ->select($select)
            ->join("users_subs", "users.id", "=", "users_subs.user_id")
            ->join("users as cusers", "cusers.id", "=", "users.cid")
            ->join('users_traffics', 'users_traffics.user_id', '=', 'users.id')
            ->first();
        if (!empty($info)) {
            $info   = (object) $info->getAttributes();
            return  $info;
        }
        return false;
    }

    public function getDetailsByToken($token)
    {
        $query = db("users_subs")->select('user_id')
            ->where("token", $token)
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return $this->getDetails($row->user_id);
        }
        return false;
    }

    public function getLoginToken($username, $pasword)
    {
        $query = db("users")->select('users_subs.token')
            ->join("users_subs", "users_subs.user_id", "=", "users.id")
            ->where("username", $username)
            ->where("password", $pasword)
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return $row->token;
        }
        return false;
    }

    public function getDetails($userId)
    {
        $select = [
            "users.*",
            "users_subs.*",
            "users.id as id",
            "users_traffics.total   as consumer_traffic",
            "creator.full_name      as creator_name",
            "editor.full_name       as editor_name",
            "categories.name as category_name",
            "domains.subdomain",
        ];

        $info = $this->select($select)->where("users.id", $userId)
            ->join("users_subs", "users.id", "=", "users_subs.user_id")
            ->join('users_traffics', 'users_traffics.user_id', '=', 'users.id')
            ->join('users as creator', 'creator.id', '=', 'users.cid')
            ->leftJoin('users as editor', 'editor.id', '=', 'users.uid')
            ->leftJoin('categories', 'categories.id', '=', 'users_subs.category_id')
            ->leftJoin('domains', 'domains.category_id', '=', 'categories.id')
            ->first();
        if (!empty($info)) {
            $info               = (object) $info->getAttributes();

            $endtime            = $info->end_time;
            $startTime          = $info->start_time;
            $validityDays       = $info->validity_days;

            $remainingDays      = 0;
            $remainingTraffic   = 0;
            $diffrenceDate      = !$validityDays ? "نامحدود" : "";
            $ftraffic           = $info->traffic ? formatTraffice($info->traffic) : "نامحدود";

            $info->ftraffic             = $ftraffic;
            $info->fconsumer_traffic    = formatTraffice($info->consumer_traffic);

            if ($info->end_time) {
                $info->end_time_jd      = Jalalian::forge($info->end_time)->format('Y/m/d - H:i');
            }

            if ($info->start_time) {
                $info->start_time_jd    = Jalalian::forge($info->start_time)->format('Y/m/d - H:i');
            }

            $info->ctime                = Jalalian::forge($info->ctime)->format('Y/m/d - H:i');

            if (!empty($info->utime)) {
                $info->utime            = Jalalian::forge($info->utime)->format('Y/m/d - H:i');
            }

            if ($endtime && $startTime && $validityDays) {
                $remainingDays  = translateDiffTime($endtime);
                $uStartTime     = getStartOfDate($startTime);
                $uEndTime       = getEndOfDate($endtime);
                $diffrenceDate  = calcDifferenceDate($uStartTime, $uEndTime);
            }
            if ($info->traffic) {
                $remainingTraffic = $info->traffic - $info->consumer_traffic;
                $remainingTraffic = formatTraffice($remainingTraffic, "fa");
            } else {
                $remainingTraffic = "نامحدود";
            }

            $info->diffrence_date    = $diffrenceDate;
            $info->remaining_days    = $remainingDays ? $remainingDays : "نامحدود";
            $info->remaining_traffic = $remainingTraffic;
            $info->public_link       = baseUrl("user/$info->token");

            return  $info;
        }
        return false;
    }

    public function getConfigure($userId, $userRole = "admin")
    {
        $info = $this->getDetails($userId);

        if (!empty($info)) {

            $settingsModel  = new \App\Models\Settings();
            $domainModel    = new \App\Models\Domains();
            $serverModel    = new \App\Models\Servers();
            $resModel       = new \App\Models\Resellers();

            $settings       = $settingsModel->getSettings();
            $username       = $info->username;
            $password       = $info->password;
            $uuid           = $info->uuid;
            $cid            = $info->cid;
            $configs        = [];

            $sshServers    = $serverModel->getServersProtocol("ssh");
            $ovpnServers   = $serverModel->getServersProtocol("openvpn");
            $v2rayServers  = $serverModel->getServersProtocol("v2ray");

            $domains        = $domainModel->getAllProtocloDomain();
            $serversSSH     = getArrayValue($settings, "servers_ssh", []);
            $sshPort        = getArrayValue($serversSSH, "port", "");
            $sshUdp         = getArrayValue($serversSSH, "udp_port", "");
            $serversV2ray   = getArrayValue($settings, "servers_v2ray", []);

            $licenseData    = $settingsModel->getLicenseData();
            $activeProto    = getArrayValue($licenseData, "active_protocols", []);

            if ($userRole != "admin") {
                $resellerInfo    =  $resModel->getInfo($cid, "reseller");
                if ($resellerInfo) {
                    if (!empty($resellerInfo->access_protocols)) {
                        $activeProto = $resellerInfo->access_protocols;
                    }
                }
            }


            if ($domains) {
                foreach ($domains as $protocol => $_domains) {
                    foreach ($_domains as $domainValues) {
                        $domain     = $domainValues["domain"];
                        $categoryId = $domainValues["category"];
                        $domainId   = $domainValues["id"];
                        if ($protocol == "ssh") {
                            $configs[$protocol][$domain][] = [
                                "qrcode"        => genSshQrcode($username, $password, $domain, $sshPort),
                                "ssh_port"      => $sshPort,
                                "ssh_host"      => $domain,
                                "ssh_password"  => $password,
                                "ssh_username"  => $username,
                                "ssh_udp_port"  => $sshUdp,
                            ];
                        } else if ($protocol == "v2ray" && in_array("v2ray", $activeProto)) {
                            $configs[$protocol][$domain]["subscription"]    = genV2rayQrcode("subs_link", $info, $domain, $serversV2ray);
                            $configs[$protocol][$domain]["vmess"]           = genV2rayQrcode("vmess", $info, $domain, $serversV2ray);
                            $configs[$protocol][$domain]["vless"]           = genV2rayQrcode("vless", $info, $domain, $serversV2ray);
                        } else if ($protocol == "openvpn" && $ovpnServers && in_array("openvpn", $activeProto)) {
                            foreach ($ovpnServers as $ovpnServer) {
                                if ($ovpnServer->openvpn_category == $categoryId) {
                                    $countryFlag = countryFlagUrl($ovpnServer->country_code);
                                    $configs[$protocol][$domain] = [
                                        "server_name"   => $ovpnServer->name,
                                        "server_ip"     => $ovpnServer->ip,
                                        "server_id"     => $ovpnServer->id,
                                        "server_flag"   => $countryFlag
                                    ];
                                }
                            }
                        }
                    }
                }
            }

            ksort($configs);
            $info->configs = array_reverse($configs);
            return  $info;
        }

        return false;
    }

    public function renewalUser($pdata, $userId, $uid)
    {

        $pcModel        = new \App\Models\Packages();

        $renewalDays    = getArrayValue($pdata, "renewal_days", 0);
        $packageId      = getArrayValue($pdata, "package_id", 0);
        $renewalDate    = $pdata["renewal_date"];
        $renewalTraffic = $pdata["renewal_traffic"];

        $userInfo       = $this->getEditInfo($userId);
        $limitUsers     = $userInfo->limit_users;
        $traffic        = $userInfo->traffic;
        $packagePrice   = $userInfo->price;
        $startTime      = $userInfo->start_time;
        $endTime        = $userInfo->end_time;
        $crole          = $userInfo->crole;
        $cid            = $userInfo->cid;
        $username       = $userInfo->username;
        $cunlimited     = $userInfo->cunlimited;
        $validityDays   = $userInfo->validity_days;

        if ($packageId) {
            $packageInfo    = $pcModel->getInfo($packageId);
            $renewalDays    = $packageInfo->validity_days;
            $limitUsers     = $packageInfo->limit_users;
            $packagePrice   = $packageInfo->price;
            $traffic        = $packageInfo->traffic * 1024;
        } else {
            $packageId      = 0;
        }

        if ($renewalDate == "yes") {
            $startTime      = time();
            $endTime        = $startTime + ($renewalDays * 86400);
        } else {
            $endTime        = $userInfo->end_time + ($renewalDays * 86400);
            $renewalDays    = $renewalDays + $validityDays;
        }

        // update user
        $this->where('id', $userId)->update([
            'status'        => 'active',
            'status_desc'   => '',
        ]);

        $updateSubs = [
            "start_time"    => $startTime,
            "end_time"      => $endTime,
            "limit_users"   => $limitUsers,
            "price"         => $packagePrice,
            "validity_days" => $renewalDays,
            "package_id"    => $packageId,
            "traffic"       => $traffic,
        ];

        db("users_subs")->where("user_id", $userId)->update($updateSubs);

        if ($crole == "reseller" && !$cunlimited) {
            $creditModel = new \App\Models\Credits();
            $creditData = [
                "operation" => "dec",
                "amount"    => $packagePrice,
                "desc"      => "کسر موجودی بابت تمدید کاربر $username",
            ];
            $creditModel->addCredit($creditData, $cid, $uid);
        }

        if ($renewalTraffic  == 'yes') {
            $utModel = new \App\Models\UsersTraffics();
            $utModel->resetTraffic($userId, $uid);
        }

        $result["sync_action"] = false;

        if ($userInfo->status != "active") {
            $result["sync_action"]  = "create";
            $result["id"]           = $userId;
        }

        //renewal
        $desc = "تمدید مشترک $userInfo->username";
        addSysLog("renewal_subscriber", $desc, $uid);

        return $result;
    }

    public function toggleActive($userId, $uid)
    {
        $userInfo = $this->getEditInfo($userId);

        if ($userInfo) {
            $status   = $userInfo->status;
            if ($status == "active") {
                $this->updateStatus($userId, "inactive", $uid);

                $desc = "غیرفعال کردن مشترک $userInfo->username";
                addSysLog("inactive_subscriber", $desc, $uid);
            } else {
                $this->updateStatus($userId, "active", $uid);

                $desc = "فعال کردن مشترک $userInfo->username";
                addSysLog("active_subscriber", $desc, $uid);
            }
        }
    }

    public function updateStatus($userId, $status, $uid, $desc = "")
    {
        $columns = ["status" => $status, "utime" => time(), "uid" => $uid];
        if (!empty($desc)) {
            $columns["status_desc"] = $desc;
        }

        $this->where("id", $userId)
            ->update($columns);
    }

    public function getTotalSubs($userRole, $uid = null, $status = null)
    {
        $query = $this->where("role", "subscriber");
        if ($status) {
            $query->where("status", $status);
        }

        if ($userRole != "admin") {
            $query->where("cid", $uid);
        }

        return  $query->count();
    }

    public function getTotalActiveSubs()
    {
        return $this->where("role", "subscriber")
            ->count();
    }

    public function deleteUser($userId, $uid)
    {
        $userInfo = $this->getEditInfo($userId);
        $this->where("id", $userId)->delete();

        if ($userInfo) {
            $startTime      = $userInfo->start_time;
            $price          = $userInfo->price;
            $creatorRole    = $userInfo->crole;
            $creatorId      = $userInfo->cid;
            $isUnlimited    = $userInfo->cunlimited;

            if (!$startTime && $price && $creatorRole == "reseller") {

                if (!$isUnlimited) {
                    $cModel = new \App\Models\Credits();

                    $desc = "افزایش اعتبار به دلیل حذف مشترک " . $userInfo->username;
                    $pdata = [
                        "operation" => "inc",
                        "amount"    => $price,
                        "desc"      => $desc,
                    ];
                    $cModel->addCredit($pdata, $creatorId, $uid);
                }
            }
        }

        $desc = "حذف مشترک $userInfo->username";
        addSysLog("delete_subscriber", $desc, $uid);
    }

    public function deleteBulkUsers($userIds, $uid)
    {
        $cModel = new \App\Models\Credits();

        foreach ($userIds as $userId) {
            $userInfo = $this->getEditInfo($userId);

            if ($userInfo) {
                $creatorRole    = $userInfo->crole;
                $startTime      = $userInfo->start_time;
                $price          = $userInfo->price;
                $creatorId      = $userInfo->cid;
                $isUnlimited    = $userInfo->cunlimited;
                if (!$startTime && $price && $creatorRole == "reseller") {
                    if (!$isUnlimited) {
                        $desc = "افزایش اعتبار به دلیل حذف مشترک " . $userInfo->username;
                        $pdata = [
                            "operation" => "inc",
                            "amount"    => $price,
                            "desc"      => $desc,
                        ];
                        $cModel->addCredit($pdata, $creatorId, $uid);
                    }
                }
            }

            $desc = "حذف مشترک $userInfo->username";
            addSysLog("delete_subscriber", $desc, $uid);
        }

        db($this->table)->whereIn("id", $userIds)->delete();
    }

    public function getByUsername($username)
    {

        $prefix     = getConfig("db")["prefix"];
        $onlineTbl  =  $prefix . "users_online";
        $select = [
            "users.username",
            "users.status",
            "users.status_desc",
            "users_subs.user_id",
            "users_subs.start_time",
            "users_subs.end_time",
            "users_subs.limit_users",
            "users_subs.validity_days",
            "users_subs.traffic",
            "users_traffics.total as consumer_traffic",
            db()::Raw("COUNT($onlineTbl.id) AS total_online"),
        ];

        $query = db($this->table)->select($select)
            ->join('users_subs', 'users_subs.user_id', '=', 'users.id')
            ->join('users_traffics', 'users_traffics.user_id', '=', 'users.id')
            ->leftJoin('users_online', 'users_online.user_id', '=', 'users.id')
            ->where("users.username", $username)
            ->where("users.role", "subscriber")
            ->groupBy("users.id")
            ->get();
        if ($query->count()) {
            $row  = $query->first();
            $remainingDays = "";
            $diffrenceDate = "";

            $startTime          = $row->start_time;
            $endTime            = $row->end_time;
            $traffic            = $row->traffic;
            $consumerTraffic    = $row->consumer_traffic;

            if ($startTime && $endTime) {
                $remainingDays  = translateDiffTime($endTime);
                $uStartTime     = getStartOfDate($startTime);
                $uEndTime       = getEndOfDate($endTime);
                $diffrenceDate  = calcDifferenceDate($uStartTime, $uEndTime);
            }

            $row->format_start_time = "";
            $row->format_end_time = "";

            if ($startTime) {
                $row->format_start_time = Jalalian::forge($startTime)->format('d F Y');
            }
            if ($endTime) {
                $row->format_end_time   = Jalalian::forge($endTime)->format('d F Y');
            }

            $row->remaining_days        = $remainingDays;
            $row->diffrence_date        = $diffrenceDate;
            $row->format_traffic        = formatTraffice($row->traffic);
            $row->f_consumer_traffic    = formatTraffice($consumerTraffic);

            $row->p_consumer_traffic = 0;

            if ($traffic) {
                $row->p_consumer_traffic = (($consumerTraffic / $traffic) * 100);
                $row->p_consumer_traffic = number_format($row->p_consumer_traffic, 1);
            }

            return $row;
        }
        return false;
    }

    public function getActiveUsers()
    {
        $select = [
            "users_subs.*",
            "users.username",
            "users.password",
            "users_traffics.total as consumer_traffic",
        ];

        $query = db($this->table)->select($select)
            ->join("users_subs", "users_subs.user_id", "=", "users.id")
            ->join('users_traffics', 'users_traffics.user_id', '=', 'users.id')
            ->where("users.status", "active")
            ->where("role", "subscriber")
            ->get();
        if ($query->count()) {
            return $query->toArray();
        }

        return false;
    }

    public function getSyncUsers($lastId = null, $limit = 50)
    {

        $select = [
            "users.id",
            "users.username",
            "users.password",
            "users_subs.uuid",
        ];

        $query = db($this->table)->select($select)
            ->join("users_subs", "users_subs.user_id", "=", "users.id")
            ->where("users.role", "subscriber")
            ->where("users.status", "active");

        if ($lastId !== null && $limit) {
            $query->where("users.id", ">", $lastId)
                ->limit($limit);
        }
        $query =  $query->get();

        if ($query->count()) {
            $rows = $query->toArray();
            foreach ($rows as $k => $row) {
                if (!$row->uuid) {
                    $userId = $row->id;
                    $uuid   = createUuidV4Secure();
                    db("users_subs")->where("user_id", $userId)->update([
                        "uuid" => createUuidV4Secure()
                    ]);
                    $row->uuid = $uuid;
                }
                $rows[$k] = $row;
            }
            return $rows;
        }
        return false;
    }

    public function getUserPassByIds($userIds)
    {
        $select = [
            "users.id",
            "users.username",
            "users.password",
            "users_subs.uuid",
        ];

        $query = db($this->table)->select($select)
            ->join("users_subs", "users_subs.user_id", "=", "users.id")
            ->where("users.role", "subscriber")
            ->whereIn("users.id", $userIds)
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            return  $rows;
        }
        return false;
    }

    public function genUserBanner($username)
    {
        $details = $this->getByUsername($username);
        $html    = "";

        if ($details) {
            $bannerPath = PATH_APP . DS . "Views" . DS . "user-banner.php";
            $vars   = ["userInfo" => $details];
            $html   = includeWithVariables($bannerPath, $vars, false);
        }

        return $html;
    }

    public function getUserServerLogin($username)
    {
        $prefix     = getConfig("db")["prefix"];
        $onlineTbl  = $prefix . "users_online";
        $select = [
            "users.username",
            "users.status",
            "users_subs.user_id",
            "users_subs.start_time",
            "users_subs.end_time",
            "users_subs.limit_users",
            "users_subs.validity_days",
            db()::Raw("COUNT($onlineTbl.id) AS total_online"),
        ];

        $query = db($this->table)->select($select)
            ->join('users_subs',        'users_subs.user_id',   '=', 'users.id')
            ->leftJoin('users_online',  'users_online.user_id', '=', 'users.id')
            ->where("users.username", $username)
            ->where("users.role", "subscriber")
            ->where("users.status", "active")
            ->groupBy("users.id")
            ->get();
        if ($query->count()) {
            $row  = $query->first();

            return $row;
        }
        return false;
    }

    public function checkV2rayOnline($userId)
    {
        $query = db("users_online")->select("id")
            ->where("users_online.user_id", $userId)
            ->where("vpn_protocol", "v2ray")
            ->get();
        return $query->count();
    }


    public function getByUUID($uuid)
    {
        $query  = db($this->table)->select("users.id")
            ->join('users_subs', 'users_subs.user_id', '=', 'users.id')
            ->where("users_subs.uuid", $uuid)
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return $row->id;
        }
        return false;
    }
}
