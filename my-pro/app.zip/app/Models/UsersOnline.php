<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class UsersOnline extends \App\Models\Users
{
    protected $table = 'users_online';
    protected $primaryKey = 'id';

    protected $fillable = [
        'server_id',
        'user_id',
        'user_ip',
        'session_key',
        'ctime',
        'last_activity',
    ];


    public function addOnlineUser($userId, $serverId, $userIp, $sessionKey, $pid, $vpnProtocol = "ssh")
    {
        $columnsArr = [
            "user_id"       => $userId,
            "server_id"     => $serverId,
            "session_key"   => $sessionKey,
            "user_ip"       => $userIp,
            "pid"           => $pid,
            "vpn_protocol"  => $vpnProtocol,
            "ctime"         => time(),
            "last_activity" => time(),
        ];

        $this->insert($columnsArr);
    }

    public function removeOnlineUser($userId, $serverId, $sessionKey)
    {
        $columnsArr = [
            "user_id"       => $userId,
            "server_id"     => $serverId,
            "session_key"   => $sessionKey,
        ];
        $this->where($columnsArr)->delete();
    }

    public function dataTableList($pdata, $uid, $userRole)
    {
        $select = [
            "users_online.*",
            "users.username",
            "servers.ip as server_ip",
            "servers.name as server_name",
        ];

        $query = db($this->table)->select($select)
            ->join('users', 'users.id', '=', 'users_online.user_id')
            ->join('servers', 'servers.id', '=', 'users_online.server_id')
            ->orderBy("users_online.id", "DESC");

        if ($userRole != "admin") {
            $query->where("users.cid", $uid);
        }

        if (!empty($pdata["search"]["value"])) {
            $search = $pdata["search"]["value"];
            $search = trim($search);

            if (!empty($search)) {
                $query->where(function ($q) use ($search) {
                    $q->where("users.username",     "LIKE", "%$search%")
                        ->orWhere("users.mobile",   $search)
                        ->orWhere("servers.ip",     $search)
                        ->orWhere("servers.name",   "LIKE",  "%$search%")
                        ->orWhere("users.desc",     "LIKE",  "%$search%");
                });
            }
            $pdata["search"]["value"] = "";
        }

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $users          = $DataTable->query()->toArray();

        $resUsers   = array();
        $num        = (!empty($pdata['start'])) ? $pdata['start'] : 0;
        foreach ($users as $user) {
            $user       = (array) $user;
            $num        = $num + 1;
            $row        = array();

            $vpnProtocol = $user["vpn_protocol"];

            $row['id']                      = $user["id"];
            $row['idx']                     = $num;
            $row['username']                = $user["username"];
            $row['server_name']             = $user["server_name"];
            $row['server_ip']               = $user["server_ip"];
            $row['user_ip']                 = $user["user_ip"];
            $row['vpn_protocol']            = $vpnProtocol;
            $row['protocol_img']            = assets("images/protocol/$vpnProtocol.png");
            $row['ctime']                   = $user["ctime"];
            $row['session_key']             = $user["session_key"];
            $row['login_date']              = Jalalian::forge($user["ctime"])->format('Y/m/d');
            $row['login_time']              = Jalalian::forge($user["ctime"])->format('H:i:s');

            $resUsers[] = $row;
        }
        $result = $DataTable->make($resUsers);
        return $result;
    }

    public function getTotalOnline($userRole, $uid = null)
    {
        $query = $this->where("users_online.id", ">", 0)
            ->join('users', 'users.id', '=', 'users_online.user_id');

        if ($userRole != "admin") {
            $query->where("users.cid", $uid);
        }

        return  $query->count();
    }

    public function getOnlieInfo($onlineId)
    {
        $select = [
            "users_online.*",
            "users.username",
            "servers.id as server_id",
        ];

        $query = db("users_online")->select($select)
            ->join('servers', 'servers.id', '=', 'users_online.server_id')
            ->join('users', 'users.id', '=', 'users_online.user_id')
            ->where("users_online.id", $onlineId)
            ->get();
        if ($query->count()) {
            return $query->first();
        }

        return false;
    }

    public function killOnlineUser($onlineId, $uid)
    {
        $onlineInfo = $this->getOnlieInfo($onlineId);

        if ($onlineInfo) {
            $serverId   = $onlineInfo->server_id;
            $servModel  = new \App\Models\Servers($this);
            $conLogModel  = new \App\Models\ConnLogs($this);

            $serverInfo = $servModel->getInfo($serverId);
            if ($serverInfo) {
                $pid        = $onlineInfo->pid;
                $userIp     = $onlineInfo->user_ip;
                $protocol   = $onlineInfo->vpn_protocol;
                $userId     = $onlineInfo->user_id;
                $ip         = $serverInfo->ip;
                $username   = $onlineInfo->username;
                try {
                    $sApi  = new  \App\Libraries\ServerApi($ip);
                    $sApi->killUserByPid($protocol, $userIp, $pid);
                } catch (\Exception $err) {
                }

                //conn log logout
                $conlogInfo = $conLogModel->getUserLastConnLog($userId);
                if ($conlogInfo && !$conlogInfo->logout_time) {
                    $conLogModel->addLogoutTime($userId, $serverId, $pid);
                }
            }

            $desc = "اخراج مشترک $username";
            addSysLog("kill_subscriber", $desc, $uid);

            $this->where("id", $onlineId)->delete();
        }
    }

    public function updateLastActivity($onlineId)
    {
        $this->where("id", $onlineId)->update(["last_activity" => time()]);
    }


    public function getOnlineUserInfo($username, $sessionKey)
    {
        $query = db("users_online")
            ->select("users.*")
            ->join("users", "users.id", "=", "users_online.user_id")
            ->where("users.username", $username)
            ->where("users_online.pid", $sessionKey)
            ->get();
        if ($query->count()) {
            return $query->first();
        }

        return false;
    }

    public function checkV2rayOnline($userId)
    {
        $query = db("users_online")->select("id")
            ->where("users_online.user_id", $userId)
            ->where("vpn_protocol", "v2ray")
            ->get();
        return $query->count();
    }

    public function getServerUsers($serverId)
    {
        $query = db("users_online")->select("users.username")
            ->join("users", "users.id", "=", "users_online.user_id")
            ->where("users_online.server_id", $serverId)
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            return $rows;
        }
        return false;
    }

    public function deleteServerUsers($serverId)
    {
        db("users_online")->where("server_id", $serverId)->delete();
        
        $whereArr = [
            'server_id'     => $serverId,
            'logout_time'   => 0,
        ];
        db("conn_logs")->where($whereArr)->update([
            'logout_time'   => time(),
        ]);
    }
}
