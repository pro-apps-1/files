<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;


class SysLogs extends \App\Models\BaseModel
{

    protected $table        = 'sys_logs';
    protected $primaryKey   = 'id';
    protected $fillable = [
        'log_type',
        'log_desc',
        'cid',
        'ctime'
    ];


    public function addLog($logType, $logDesc, $cid)
    {
        $columnsArr = [];
        
        $columnsArr["cid"]          = $cid;
        $columnsArr["log_type"]     = $logType;
        $columnsArr["log_desc"]     = $logDesc;
        $columnsArr["ctime"]        = time();

        $this->insert($columnsArr);
    }

    public function dataTableList($pdata, $userRole, $uid)
    {
        $select = [
            "sys_logs.*",
            "creator.full_name as creator_name"
        ];

        $query = $this->select($select)
            ->join("users as creator", "creator.id", "=", "sys_logs.cid")
            ->orderBy("sys_logs.id", "DESC");
 

        if (!empty($pdata["search"]["value"])) {
            $search = $pdata["search"]["value"];
            $search = trim($search);
            if (!empty($search)) {
                // $query->where(function ($q) use ($search) {
                //     $q->where("users.full_name", "LIKE", "%$search%")
                //         ->orWhere("credits.desc",  "LIKE",  "%$search%");
                // });
            }
            $pdata["search"]["value"] = "";
        }


        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $result         = $DataTable->query()->toArray();

        $resData = array();
        $num = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($result as $item) {
            $num = $num + 1;
            $row = array();

            $createTime    = Jalalian::forge($item["ctime"]);

            $row['id']                  = $item["id"];
            $row['idx']                 = $num;
            $row['log_type']            = translateSysLog($item["log_type"]);
            $row['log_desc']            = $item["log_desc"];
            $row['creator_name']        = $item["creator_name"];
            $row['cdate']               = $createTime->format('Y/m/d');
            $row['ctime']               = $createTime->format('H:i');

            $resData[] = $row;
        }

        $result = $DataTable->make($resData);
        return $result;
    }
}
