<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class UsersMeta extends \App\Models\Users
{

    protected $table = 'users_meta';
    protected $primaryKey = 'id';

    protected $fillable = [
        'user_id',
        'meta_key',
        'meta_value',
    ];
}
