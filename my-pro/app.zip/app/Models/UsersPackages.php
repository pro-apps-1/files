<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;


class UsersPackages extends \App\Models\Users
{

    protected $table = 'users_packages';
    protected $primaryKey = 'id';
    protected $fillable = [
        'user_id',
        'package_id',
        'ctime',
        'cid'
    ];


    public function addPackage($pdata, $userId, $uid)
    {

        $columnsArr    = [];
        $pdata          = trimArrayValues($pdata);

        $columnsArr["user_id"]          = $userId;
        $columnsArr["package_id"]       = $pdata["package_id"];
        $columnsArr["cid"]              = $uid;
        $columnsArr["ctime"]            = time();

        $this->updateOrCreate([
            'user_id'      => $userId,
            'package_id'   => $pdata["package_id"]
        ], $columnsArr);
    }

    public function deleteUserAccess($userId, $rowId, $uid)
    {
        $this->where("user_id", $userId)->where("id", $rowId)->delete();
    }

    public function dataTableList($pdata, $userId)
    {
        $select = [
            "packages.*",
            "users_packages.id as row_id",
            "users_packages.ctime as row_ctime"
        ];

        $query = $this->select($select)
            ->join("packages", "users_packages.package_id", "=", "packages.id")
            ->where("users_packages.user_id", $userId)
            ->orderBy("users_packages.id", "DESC");

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $result         = $DataTable->query()->toArray();

        $resData = array();
        $num = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($result as $item) {
            $num = $num + 1;
            $row = array();

            $row['id']                  = $item["row_id"];
            $row['idx']                 = $num;
            $row['name']                = $item["name"];
            $row['validity_days']       = $item["validity_days"];
            $row['traffic']             = $item["traffic"];
            $row['limit_users']         = $item["limit_users"];
            $row['start_time_type']     = $item["start_time_type"];
            $row['price']               = number_format($item["price"]);
            $row['ctime']               = Jalalian::forge($item["row_ctime"])->format('Y/m/d');

            $resData[] = $row;
        }

        $result = $DataTable->make($resData);
        return $result;
    }

    public function checkUserAccess($userId, $packageId)
    {
      
        return $this->where("user_id", $userId)
            ->where("package_id", $packageId)
            ->count();
    }
}
