<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class UsersLogs extends \App\Models\BaseModel
{
    protected $table        = 'users_logs';
    protected $primaryKey   = 'id';

    protected $fillable = [
        'user_id',
        'log_type',
        'log_desc',
        'cid',
        'ctime',
    ];



    public function addLog($userId, $logType, $logDesc = "", $uid = 0)
    {
        $this->insert([
            'user_id' => $userId,
            'log_type' => $logType,
            'log_desc' => $logDesc,
            'cid' => $uid,
            'ctime' => time(),
        ]);
    }
}
