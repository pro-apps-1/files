<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class Resellers extends \App\Models\Users
{

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }

    public function saveUsers($pdata, $editId = null, $uid)
    {
        $columnsArr    = [];
        $pdata         = trimArrayValues($pdata);

        if (!empty($pdata["password"])) {
            $columnsArr["password"]     = password_hash($pdata["password"], PASSWORD_BCRYPT);
        }

        $columnsArr["full_name"]        = $pdata["full_name"];
        $columnsArr["role"]             = "reseller";
        $columnsArr["username"]         = $pdata["username"];
        $columnsArr["status"]           = $pdata["status"];
        $columnsArr["status_desc"]      = "";
        $columnsArr["mobile"]           = "";
        $columnsArr["desc"]             = "";
        $columnsArr["unlimited"]        = isset($pdata["unlimited"]) ? 1 : 0;

        if (!$editId) {
            $columnsArr["credit"]           = 0;
            $columnsArr["ctime"]            = time();
            $columnsArr["utime"]            = 0;
            $columnsArr["cid"]              = $uid;
            $columnsArr["uid"]              = 0;
        } else {
            $columnsArr["uid"]              = time();
            $columnsArr["utime"]            = $uid;
        }

        $object = $this->updateOrCreate(['id' => $editId], $columnsArr);
        $userId = $object->id;

        $accessProtocols = getArrayValue($pdata, "access_protocols", []);
        $accessProtocols = !empty($accessProtocols) ? json_encode($accessProtocols) : "";

        $columnsArr = [
            "access_protocols" => $accessProtocols,
        ];

        $this->saveMeta($userId, $columnsArr);
    }



    public function deleteUser($userId, $uid)
    {
        $this->where("id", $userId)->delete();
    }

    public function dataTableList($pdata, $uid)
    {
        $totalSubs = db("users")
            ->select("cid", db()::Raw("COUNT(id) AS total_subs"))
            ->where("role", "subscriber")
            ->where("status", "active")
            ->groupBy("cid");

        $totalTraffics = db("users_traffics")
            ->select(db()::Raw("SUM(total) AS total_traffics"), "users.cid")
            ->join("users", "users.id", "=", "users_traffics.user_id")
            ->groupBy("users.cid");

        $limitShow      = getTotalRowsInPlan("resellers");
        $select         = ["users.*", "users_meta.meta_value as ac_protocols", "subs.total_subs", "traffics.total_traffics"];
        $query          = $this->select($select)->where("users.role", "reseller");

        $query->leftJoin("users_meta", function ($j) {
            $j->on("users_meta.user_id",  "=", "users.id")
                ->where("users_meta.meta_key", "access_protocols");
        });

        $query->leftJoinSub($totalSubs, 'subs', function ($join) {
            $join->on('subs.cid', '=', 'users.id');
        });

        $query->leftJoinSub($totalTraffics, 'traffics', function ($join) {
            $join->on('traffics.cid', '=', 'users.id');
        });

        if ($limitShow) {
            $sub        = clone $query;
            $subquery   = $sub->limit($limitShow);
            $query->joinSub($subquery, 'subquery', 'subquery.id', '=', 'users.id');
        }

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $users          = $DataTable->query()->toArray();

        $resUsers       = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($users as $user) {
            $num = $num + 1;
            $row = array();

            $acProtocols   = $user["ac_protocols"];
            $createTime    = Jalalian::forge($user["ctime"]);
            if (!empty($acProtocols)) {
                $acProtocols = json_decode($acProtocols, true);
            }

            $row['id']                  = $user["id"];
            $row['idx']                 = $num;
            $row['username']            = $user["username"];
            $row['total_traffics']      = formatTraffice($user["total_traffics"]);
            $row['total_subs']          = $user["total_subs"] ? $user["total_subs"] : 0;
            $row['status']              = $user["status"];
            $row['full_name']           = $user["full_name"];
            $row['ac_protocols']        = $acProtocols;
            $row['unlimited']           = intval($user["unlimited"]);
            $row['credit']              = number_format($user["credit"]);
            $row['ctime']               = $createTime->format('Y/m/d');
            $resUsers[] = $row;
        }

        $result = $DataTable->make($resUsers);
        return $result;
    }

    public function getTotalResellers($status = "")
    {
        $query = $this->where("role", "reseller");
        if ($status) {
            $query->where("status", $status);
        }

        return  $query->count();
    }


    public function getAllResellers()
    {
        $query = db($this->table)->where("role", "reseller")
            ->select("id", "username", "full_name")
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            return $rows;
        }

        return false;
    }

    public function totalCredit()
    {
        $query = db($this->table)->where("role", "reseller")
            ->selectRaw(db()::raw("SUM(credit) as total_credit"))
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return number_format($row->total_credit);
        }

        return 0;
    }

    public function getUserMeta($userId, $metaKey = "")
    {

        $jsonMeta   = ["access_protocols"];
        $query      = db("users_meta")->where("user_id", $userId);
        if ($metaKey) {
            $query->where("meta_key", $metaKey);
        }
        $query = $query->get();
        if ($query->count()) {
            if ($metaKey) {
                return  $query->first();
            }

            $rows = $query->toArray();
            $result = [];
            foreach ($rows as $row) {
                $metaKey   = $row->meta_key;
                $metaValue  =  $row->meta_value;
                if (in_array($metaKey, $jsonMeta)) {
                    $metaValue = json_decode($metaValue, true);
                }

                $result[$metaKey] = $metaValue;
            }
            return $result;
        }
        return false;
    }


    public function saveMeta($userId, $columnsArr)
    {
        foreach ($columnsArr as $name => $value) {
            $where = ["meta_key" => $name, "user_id" => $userId];
            $isExist = db("users_meta")
                ->where($where)
                ->count();
            if ($isExist) {
                db("users_meta")->where($where)->update(["meta_value" => $value]);
            } else {
                $values["meta_key"] = $name;
                $values["meta_value"] = $value;
                $values["user_id"] = $userId;
                db("users_meta")->insert($values);
            }
        }
    }
}
