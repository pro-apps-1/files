<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

class Users extends \App\Models\BaseModel
{

    protected $table = 'users';
    protected $primaryKey = 'id';

    protected $fillable = [
        'username',
        'password',
        'mobile',
        'desc',
        'full_name',
        'role',
        'credit',
        'status',
        'status_desc',
        'unlimited',
        'ctime',
        'cid',
        'uid',
        'utime',
    ];


    public function checkLogin($pdata, $role = "")
    {
        $username = $pdata["username"];
        $password = $pdata["password"];


        $query = db($this->table)->where("username", $username);
        if ($role) {
            $query->where("role", $role);
        } else {
            $query->where(function ($query) {
                $query->where("role", "admin")
                    ->orWhere("role", "reseller");
            });
        }
        $query = $query->get();
        if ($query->count()) {
            $userInfo   = $query->first();
            $role       = $userInfo->role;
            $upass      = $userInfo->password;
            $status     = $userInfo->status;
            $userId     = $userInfo->id;

            if ($role == "admin" || $role == "reseller") {
                if ($status == "active") {
                    if (password_verify($password, $upass)) {
                        return $userInfo;
                    }
                }
            } else {
                if ($upass == $password) {
                    $subModel = new \App\Models\UsersSubs();
                    $subInfo  = $subModel->getSubInfo($userId);
                    return $subInfo->token;
                }
            }
        }
        return false;
    }


    public function getInfo($userId, $role = "")
    {
        $userInfo = $this->where("id", $userId)
            ->first();
        if (!empty($userInfo)) {
            $userInfo   = (object) $userInfo->getAttributes();

            $role       = $userInfo->role;
            $role       = $userInfo->role;
            if ($role == "subscriber") {
                // $subModel = new \App\Models\UsersSubs();
                // $subInfo  = $subModel->getSubInfo($userId);
                // if (!$subInfo) {
                //     return false;
                // }
            } else if ($role == "reseller") {
                $resModel = new \App\Models\Resellers();
                $userMeta = $resModel->getUserMeta($userId);
                if ($userMeta) {
                    foreach ($userMeta as $metaKey => $metaValue) {
                        $userInfo->$metaKey = $metaValue;
                    }
                }
            }

            $userInfo->role_name = translateUserRole($role);
            return  $userInfo;
        }
        return false;
    }


    public function isExistUsername($value, $uid = null)
    {
        $query = $this->where("username", $value);
        if ($uid != null) {
            $query->where('id', '!=', $uid);
        }
        return $query->count();
    }

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }

    public function totalUsers($userRole, $uid = null, $status = null)
    {
        $query = $this->where("id", ">", 0);
        if ($status) {
            $query->where("status", $status);
        }

        if ($userRole != "admin") {
            $query->where("cid", $uid);
        }
        return  $query->count();
    }

    public function getIdByUsername($username)
    {
        $row = $this->select("id")->where("username", $username)->first();

        if (!empty($row->id)) {
            return $row->id;
        }

        return false;
    }

    public function getAllUsernames()
    {
        $query =  db($this->table)->select("username")
            ->where("role", "subscriber")
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            $result = [];
            foreach ($rows as $row) {
                $result[] = $row->username;
            }
            return  $result;
        }
        return false;
    }

    public function getAllAdmins()
    {
        $query =  db($this->table)->select("id", "username", "full_name", "role")
            ->where("role", "!=", "subscriber")
            ->where("status", "active")
            ->orderBy("full_name", "ASC")
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            foreach ($rows as $key => $row) {
                $row->role_name = translateUserRole($row->role);
                $rows[$key] = $row;
            }

            $adminUsers = [];
            $resUsers   = [];
            foreach ($rows as $key => $row) {
                if ($row->role == "admin") {
                    $adminUsers[] = $row;
                } else {
                    $resUsers[] = $row;
                }
            }

            return array_merge($adminUsers, $resUsers);
        }
        return false;
    }
}
