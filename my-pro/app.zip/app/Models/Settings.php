<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

class Settings extends \App\Models\BaseModel
{

    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'value'];

    private $jsonKeys = [
        "domains",
        "servers_ban_sms",
        "subs_register_sms",
        "subs_expiration_sms",
        "banner_text",
        "users_panel",
        "auto_backup",
        "admin_telegram_bot",
        "servers_check_filtering",
        "servers_check_availability",
        "servers_v2ray",
        "servers_ssh",
        "servers_openvpn",
    ];

    public function saveMainSettings($pdata, $licensePlan, $uid)
    {
        $validKeys = [
            "admin_prefix_url",
            "fake_url",
            "site_title",
        ];

        if ($licensePlan == "brillant" ||  $licensePlan == "gold") {
            $logoUrl = $this->getSetting("logo_url");
            if (!empty($pdata["logo"])) {
                $filePath  = PATH_ASSETS . DS . "uploads";
                if (!file_exists($filePath)) {
                    mkdir($filePath, 0777, true);
                }
                if ($logoUrl) {
                    $logoPath = PATH_ASSETS . DS . $logoUrl;
                    if (file_exists($logoPath)) {
                        @unlink($logoPath);
                    }
                }

                $oldPath = PATH_ASSETS . DS . $logoUrl;
                if (file_exists($oldPath)) {
                    @unlink($oldPath);
                }
                $fileName = moveUploadedFile($filePath, $pdata["logo"]);
                $logoUrl  = "uploads/$fileName";
            }
            $validKeys[] = "footer_text";
            if ($logoUrl) {
                $validKeys[]        = "logo_url";
                $pdata["logo_url"]  = $logoUrl;
            }
        }


        if (is_array($pdata)) {
            foreach ($pdata as $key => $value) {
                if ($key == "admin_prefix_url") {
                    $value = trim($value, "/");
                }
                if (in_array($key, $validKeys)) {
                    $this->updateOrCreate(
                        ['name' => $key],
                        ["name" => $key, "value" => $value]
                    );
                }
            }
        }
    }

    public function setSettings($name, $value)
    {
        $value = is_array($value) ? json_encode($value) : $value;
        $this->updateOrCreate(
            ['name' => $name],
            ["name" => $name, "value" => $value]
        );
    }


    public function saveCloudflareData($pdata, $uid)
    {

        $token  = !empty($pdata["token"]) ? $pdata["token"] : "";
        $ttl    = !empty($pdata["ttl"]) ? $pdata["ttl"] : "";

        $this->updateOrCreate(
            ['name' => "cloudflare_token"],
            ["name" => "cloudflare_token", "value" => $token]
        );

        $this->updateOrCreate(
            ['name' => "cloudflare_ttl"],
            ["name" => "cloudflare_ttl", "value" => $ttl]
        );
    }

    public function saveSettings($name, $value)
    {
        $this->updateOrCreate(
            ['name' => $name],
            ["name" => $name, "value" => $value]
        );
    }


    public function saveServersSettings($pdata, $uid)
    {
        $validKeys = [
            "servers_token",
            "servers_calc_traffic",
            "servers_v2ray",
            "servers_ssh",
            "servers_openvpn",
            "servers_check_filtering",
            "servers_check_availability",
            "servers_online_limit",
            "servers_delete_subs_logs_minute",
        ];

        if (is_array($pdata["servers"])) {
            $servers = $pdata["servers"];

            if (isset($servers["check_filtering"]["enabled"])) {
                $servers["check_filtering"]["enabled"] = 1;
            } else {
                $servers["check_filtering"]["enabled"] = 0;
            }

            if (isset($servers["check_availability"]["enabled"])) {
                $servers["check_availability"]["enabled"] = 1;
            } else {
                $servers["check_availability"]["enabled"] = 0;
            }

            if (isset($servers["online_limit"])) {
                $servers["online_limit"] = 1;
            } else {
                $servers["online_limit"] = 0;
            }

            foreach ($servers as $key => $value) {
                $name = "servers_$key";
                if (in_array($name, $validKeys)) {
                    if (is_array($value)) {
                        $value = json_encode($value);
                    }

                    $this->updateOrCreate(
                        ['name' => $name],
                        ["name" => $name, "value" => $value]
                    );
                }
            }
        }
    }

    public function saveDomains($pdata, $uid)
    {
        if (!empty($pdata["domains"])) {
            $domains = array_values($pdata["domains"]);
            $domains = array_unique($domains);
            $domains = json_encode($domains);
            $this->updateOrCreate(['name' => "domains"], ["name" => "domains", "value" => $domains]);
        }
    }

    public function saveBannerText($pdata, $uid)
    {
        if (!empty($pdata)) {
            $values = json_encode($pdata);
            $this->updateOrCreate(['name' => "banner_text"], ["name" => "banner_text", "value" => $values]);
        }
    }

    public function saveUsersPanel($pdata, $uid)
    {
        $validKeys = [
            "support_url",
            "theme",
            "welecom_text",
        ];

        if (is_array($pdata)) {

            $saveData = [];
            foreach ($pdata as $key => $value) {
                if (in_array($key, $validKeys)) {
                    $saveData[$key] = $value;
                }
            }
            $this->updateOrCreate(
                ['name' => "users_panel"],
                [
                    'name' => "users_panel", "value" => json_encode($saveData)
                ]
            );
        }
    }

    public function saveSmsSettings($pdata)
    {
        if (!empty($pdata)) {
            foreach ($pdata as $key => $value) {
                $value = is_array($value) ? json_encode($value) : $value;
                $this->updateOrCreate(['name' => $key], ["name" => $key, "value" => $value]);
            }
        }
    }

    public function getSettings()
    {
        $result = [];

        $query = db($this->table)->get();
        if ($query->count()) {
            $rows       = $query->toArray();
            $jsonKeys   = $this->jsonKeys;
            foreach ($rows as $row) {
                $name   = $row->name;
                $value  = $row->value;
                if (in_array($name, $jsonKeys)) {
                    $value = json_decode($value, true);
                }
                $result[$name] = $value;
            }
        }

        return $result;
    }

    public function getSetting($name)
    {
        $query = db("settings")->where("name", $name)->get();
        if ($query->count()) {
            $row = $query->first();
            $value  = $row->value;
            $jsonKeys = $this->jsonKeys;
            if (in_array($name, $jsonKeys)) {
                $value = json_decode($value, true);
            }

            return $value;
        }

        return false;
    }

    public function saveLicenseData($data)
    {
        $crypto         = new \App\Libraries\CustomCryptoAES();
        $sysData = $crypto->encrypt(json_encode($data));
        $this->updateOrCreate(['name' => "sys_data"], ["name" => "sys_data", "value" => $sysData]);
    }


    public function getLicenseData($reset = false)
    {
        $crypto         = new \App\Libraries\CustomCryptoAES();
        $sysData        = $this->getSetting("sys_data");

        $result   = [
            "plan_name"         => "free",
            "license_type"      => "",
            "expire_time"       => time() + (5 * 86400),
            "options"           => [],
            "active_protocols"  => ["ssh"],
            "is_active"         => 1,
            "is_expired"        => 0,
            "price"             => 0,
        ];

        $insertData     = false;
        $secretFilePath = PATH_LOGS . DS . "log.txt";

        if (!empty($sysData)) {
            $sysData = $crypto->decrypt($sysData);

            try {
                $result                = json_decode($sysData, true);
                $planName              = $result["plan_name"];
                $activeProtocols       = ["ssh"];

                if ($planName != "free") {

                    if (!empty($result["options"])) {
                        $options        = $result["options"];
                        $activeV2ray    = isset($options["active_v2ray"]) ? 1 : 0;
                        $activeOvpn     = isset($options["active_openvpn"]) ? 1 : 0;

                        $activeProtocols[] = "ssh";
                        if ($activeV2ray) {
                            $activeProtocols[] = "v2ray";
                        }
                        if ($activeOvpn) {
                            $activeProtocols[] = "openvpn";
                        }
                    }
                }

                if (!empty($result["expire_time"])) {
                    $expireTime = $result["expire_time"];

                    if ($expireTime && $expireTime > 0) {
                        if (time() > $expireTime) {
                            $result["is_expired"]   = 1;
                        } else {
                            $result["is_expired"]   = 0;
                        }
                    }
                    $result["expire_time"]      = $expireTime;
                } else {
                    $result["expire_time"]      = 0;
                    $result["is_expired"]       = 0;
                }

                $result["active_protocols"]     = $activeProtocols;
            } catch (\Exception $e) {
                $insertData = true;
            }
        } else {
            $insertData = true;
        }

        if ($reset) {
            $result["expire_time"]  = 0;
            $result["is_active"]    = 0;
            $result["is_expired"]   = 1;
            $sysData   = $crypto->encrypt(json_encode($result));
            $this->updateOrCreate(["name" => "sys_data"], ["name" => "sys_data", "value" => $sysData]);
        } else if ($insertData) {

            $result["plan_name"]    = "free";
            $result["expire_time"]  = time() + (1 * 86400);

            if (file_exists($secretFilePath)) {
                $result["expire_time"] = time() + (2 * 3600);
            } else {
                @file_put_contents($secretFilePath, "php");
            }

            $sysData   = $crypto->encrypt(json_encode($result));
            $this->updateOrCreate(["name" => "sys_data"], ["name" => "sys_data", "value" => $sysData]);
        }

        $result["expire_date"] = jdate($result["expire_time"])->format("Y/m/d - H:i");

        return $result;
    }
}
