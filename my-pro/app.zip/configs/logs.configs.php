<?php 
/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

if (!defined('PATH')) die();


$configs['logger']['enabled'] = true;
$configs['logger']['name'] = '';
$configs['logger']['addr'] = '';
?>
