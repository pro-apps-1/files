<?php

/**
 * By MahmoudAp
 * Github: https://github.com/mahmoud-ap
 */

define('PATH', __DIR__);

ini_set('memory_limit', '256M');
ini_set('max_execution_time', '1000');

require_once 'vendor/autoload.php';

require_once 'bootstrap/bootstrap.php';
