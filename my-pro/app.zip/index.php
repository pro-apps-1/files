<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('PATH', __DIR__);

ini_set('memory_limit', '256M');
ini_set('max_execution_time', '1000');

require_once 'vendor/autoload.php';

require_once 'bootstrap/bootstrap.php';
