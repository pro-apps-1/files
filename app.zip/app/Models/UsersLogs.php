<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtQofdTn8Xju370pL3Okh4XweU/9VE6gYQguhkB2t+CAq8E+oW3xghcd53gZm3GTKZPNW6c4
VS3pG9Aqj86KHUzrADwcpAPYrmlgpPSKv34hSBhzG82EJs3YAmfBfivsAzwH7a+LTvPzO64cuT4B
7PlXzASE1wQwnnlGm/ie/QH/0IHQ3PKSYfgDjT1xhqA5KO4xfMIfvfnYqj9A6+7P81XX5eX7AnuG
MnvmkZ8DMnVj6V2r4cs3quSeFK6wLbCb7a/rlg30UZr/oXUPysMTD8bFfAvcnxbDgByF/eYXmeKY
EYfP7yvratzdpzBJMn40T0R3AKb2XkYaSlvXSTA9ZW8+uXsP8d7VNzdbYXm1fTFqdhGIP34HKcc5
I54cWe+g6eWpKru6BxjN8QjrJVAxnRW9ELo9fkutlXW2N5soclk2lCcqk+u/Qp9BPe/tmK7iq6mC
j16uAxUnMaMu9vrRt4KncyyTKnc2Ug6Lv/uOdoHu/N05bcrbHY+rrYPbXdl43EUTly91yJ5RZRzE
jPm4OcvZUpUegcGtYX4dGcQ9EhYwir2cybU1st1d+ilddQHnUh3wK/JmUJMCy4FdVQNjhhZGe2/3
28xtvDjWIKbLG2174ulsxj8mn/1JlOFhWVN1bqQ5kg6xTM41MO5Q2FqHhcO03z4Fwjw7BKz1u6Tb
zGSEXH226k9fAK8xtSMrEZCi3HQ3m6QbsyMrRBObgwj/FITMNWCpGjRhwzuh7oDRud03Sad+H0Sz
WwXYIJ8dm4Apee+qCrrdgXMYA8EUZjSlTIwzm2UpPqN/anvdiWnW/f37piwmHrUO1OTfZfgWhQqL
83WBQsPIglonUnfwUsWFWFXLHjklgP9hXRqROldPyxUDfrg4XxCaJB8tWkUBAvQnQcfoLIL7J6jU
qO9dkPbClitCIEWDqCXoKCxyvk2jBh81Ut94VdwcFLo2NcfVO1h9PgbtOxu9IWyZwsQRhUfo2TBf
WK6cRFXyH+HuKc6c1etZfl4Q1p0o+KaIvE89Cgh90eXdXj23scZ92s2mue3+9LrvxAk9YrtiPML0
aG57E6HbCwi+h4ajsuNhz8tth2Z1AKFzWYjMSMZFWdtvdkWYg/VFVbz1jgwhjGkbbC27aaj7dJBA
YpXdklasdH3dHtgWPvWSJZMbptX32QC/aSr+1BKBvFTxm0lIjfTpiD5d/nxq0IlQqI0Ns4zykae9
puxiPDdc3VZ05jtxHIHpTMm+MA1pP50ulXe8Fn7K4fwrKzLU8ub4J6lch1RZP82gfotaQvmMAlEH
anyW9ayoPIg/JOvGeaYqHe8+EFQC24teOwIlfF0VTfut1PHgsySeTnfZVP04DrlQ1rW+HPKEoGN4
xpgA/NetdwxTyBR0i+XppVX+tD0ai2r2+JVIt717uY6JWt6xVYPWN15w+g91LjRcmN3AIlB6Sw6e
/n50euJDK+E4RvaptR9L0YxNuJqavwBBhfLcLQnafDJhb1ce9dcqBlsh5R2uGiNy6nrsNWWMWyir
896dS9g4Cy4FaAdiTGc8/U/mtiNWYXnuDk5esEIbl4xvbSXAO3UdfbnOWyMDoBNOyGMT+daC2zWP
ZinYBkXKhCLYs6t7oIMTBKfNGnimfVYnmOp/4/0ITu9M2Hte3g1YyRoOM8lZM6lpukDypSKhQKvc
b9pOuy7AlwS2jbSglZ8vPAz/654KAco2SW4i3IcrA8Lym6kIXlsFzakWDnHdoG==