<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtWtD8CYgOoqE/MXe5JC9dj+6IUBbum6uRAuKNMeMUz4QYgh29goWYjmo3eqUFgcMtam5Iqe
MvhwG5cF3hYv2wPc9mSMvlnSNJQKbEnH4evONu1OjkV5FaasWlNgIf/IIYAfLmOo17uVUwZu3SXS
uDgTmCGQUB4jENlhYjrss5/Itjo08qDmQ9DFfsoXAj8iUBmjeZA1sqbTXIXNW2hLkTjfDzvYdVAW
0Ut2eH3ZMVw5EldbHe0sXYnf65kcm8gZJlevIdpduDuQEICruOA6s+HRjG1dVlpkiibTuNMnyC6j
oBqF/wuNaOmLf9N1W2vdc2ce2Fv+2zRS6/2eb7zdBgjUW6QjLagcSN6p3t36XS4O1hMl/isIzne0
22bt7q1uv6mo9oDFoCR/G6PWosTy8OwHCHIe7bQbje/aXAGeyWMjSmDqkHuCTrUQ5HNWeVewLtyi
ozjJRHEt2saTKnrnl8sOHZON7yAoJ4rKXwzhKrT8jPgijI6dFVCAD3SSDwHYNJQ23orubCi9908W
fHDBWpSpfl5QAmXbfxTxUTGNn4GsejTO0VPnf5EhY+HtTtJ6lGkmCUSiq9OGRwdt5ruDmkocWEk7
tQ6sZP6Bn0U+XJs3fWP0wmZutHAi7pbKN/bhHC7TAMOCk2Kb+VRp171dHb3uXjO+pRPzFveRkWMt
P7fMwsZVSB9lBmQCvUsgTdCNZ+EpaloUAkhhsaviKtK//mfcFsK+5cqnPKGsYn87qNl1Evt1h1bm
RP3wHqMa5KNpvTcHJ8xdLtEeieQyMBRTWJt59/Dc7yKqbZMRcfjQDln2/nCHb82pLMaXEOYER6bi
72KVyGn2NaZj7Ws8cIyY5Zi6msFiaMljglLImvyJyI1ZGd+vywdJ+SjUHELwAme8rNRUEhOE6RGe
OuE6AtcN6jNydZhs/m7DdX0gpTERh9ciebEU4dOa3iqngTZTdYUja0/gXOp48VV7BOmn7Mi7A8FU
QoJgupEXEI+S1FzHnvhN5EwJZ/O1XHeIiifLDIXf0lMQDwAeqHaldOmr9/qOGUhad+emxw50hgj1
8el/3t6UuJ7mQicG4pYsEv2hud1++/Mqek6ILdEurz7nqHd3/9QVIXPnOrBPmjSRZFHX3DlkBUXA
P61trl6IRu337RC4wvc0vz1Ve8BHl8UQ/7P4G0do1Wcf7s4ONfz2huRefY/5Q7a1Ve3WzuDlucv7
xh/CZbG4xWz+PEMMW78uUiewk6z5RmCzxp5KDUgtEEl0oXASAigHyfVmtXhmOeThpCeE9Z+mOzTg
NBKqKFAeyfl0p8l5b2DSAuU5GoHvywPXmQLV0JKr/fYQsylty9O+ow5CycbGh/0DlrFg5dDus/Qy
KRA3yMpbiqVJfteejR+ELHJLftgVYib5OrtkUzFwGuk0QWXz48PbNhKuikFNOfmsdQ3xVvLP9DFJ
Rl9WIot2VwN2h5IUv7UvX187ayAooC+SacPfBnF0qeslO0mOchlkBrM/L7v/4usSa7Q7u0ond89F
zgPDZMtCdNctHBRYFdkw1WiXgWNc5aW8p3srxzNb2dTnRuNqxSra17X7mVDx1LnXKdF7X3ZXKGyg
y/E0vMG4f4SDQUdVvU54dkjI8ga6xXKn31KDlumHKOLcZRVXw/DWkNaoJ7D5A27EXFdJ+u+IeMGG
/lCh6m7KhhTOljHRVMIqKnWGjhejux7IPjut7GT83J6HVgdV3Jjr