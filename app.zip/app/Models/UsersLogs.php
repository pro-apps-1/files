<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqa41gD3sFgK6iQJW9f3rnRB2h5H2LsqiuwuDy3P0ounhErx8KJWk4vll0mSIw+PFz7Mom72
uSVeuV0LVbSwJwZBNlssoB8eV13h5PK95fDK9MNnBoCHuqFVtygATnyKKUHMGN4StGfi6o2n+C/k
WgTVS+tf70XJH5isJlzYXB7+64VtsI8IIAIN4BrCvrgcKEsE5U2LAnKY4Uy499TkU3wjU49SYmIf
b9f8NxAabGcD+622YBrb7S+veJ6IAZ3hIsdh9+6KJ9tsl3a8lfHDjYU7lkfaKg5f8S6VR9pGY8xp
pzD1/GOLb7Y29YOcqxi7EYrMUFpI77ujKFjNvz52O2u0b4cBs58tCINiEnvkOijI/qeqyT5MG6h/
pKlkM1FfqRHnsrTJQEdBcu+sMN1gUrGjWp4aXzaelweIitG2mbzOWdYYOlZUtQtboY8xpWwY1j/Q
M+k2Qc6AjSC5RUEuW0bQCw0WIQxL3cLWyJFLkBOe/0O0KTWSiXE+e/b0qGWiz8zvKYuEt9bLDNWS
gxEFGi5Ih/clGfx2wWQTJ4WlQ/f7awSvRYlzuKAWNEknLEHJ8yYXxtatTW6gBHg9KS62SkrwnGdp
oVBdQNhjskHayRvli5zk9D86ljV5iKnzEo1Otuw1cWK1GsPAe6MkdtplLW2Lev+gjF5cv7CTSvy5
HfJFXYZE1RMRbgxkOttSk7fy6lYlEAAyj29s5Rca3bB/tTIzyoxlSFpw1LqFHD12VGCRwjo6Io2q
TJZv5w/V4yoToQAQM+6YQbtIf3lpZ7V2yczV92V9VDkxumaaftTCoA+cWwG8Y3fepj40UyLx22g3
3P9EajqZpL2C0WcwgIwWeFGTUBct1oPPakdJVAojR0r+awUbxiLyZGC41AMRy5Lj1sZXBwB485BY
bfJKoZzB/t5WwMKC3SQViOTvnsAXZaUUg9lQ/2/OtFy3+JGf2CmOx61W3EzdxZwAQqXf8D1XPp6X
NH3r33eeP+8gTlz+zrQZ3W2UuR8QT/qodXCANqylT+z8hfGdZqnRruzcg1UNcQ0LZW6+ApiwWz3i
qV7eBvyqQIkTDXdPWjk8MMnD9W4Q/276xPvH3JR1RTR6W2QBZwgtHpL7i7QsyCYN9aa1qvGZ3478
3GlI4r128Daka10+Zo5YZ2FtexLIWj2E9WM/61tML0HsZ5u2XRKoLfZVhREQW4/xYeq2C7vdzI6q
/zWgLAj/UIKI+7hvXb1xrsqPlC3HOoNyRPb6vpw2g5pvAdo33WS80bQmNXnrJUzaRuqhwq4BbNoe
CzPh+XcE1eSCNqRmibdqOA+M90KNTr95+rXPuBmKOSkwfi6CvRmW/wOfiNc0GBo1Jr0q6FJadvpa
rxBSSGBqkyC63OnGcTdXa4h1zSLQfWvQA138YX9RuOtamUWqiVc9AStZvRRd5knFA5U6EeNwuNR5
3WmCprpkvzDYyqrP5xQDo9Q9I2JsPynzYb5LeqXCrjWnEL5u27ZhVMimtFsOAGnsyvvsNsiwhLW8
wourEMM99VAdog4hfqJSBvzEsWuZyZXI6Z7SRmysiArcZiJRITBRtg4fJChm6ZudZ5PRMej01JXd
/Wx1BlJYi/Jap/wmmfAUu35kt5kWS7/Smrjf8KQqX6lKGzOx8qRtgmJkNpck6cdEHJaYZPURFzOt
N0Q7vVkvk2gyoay6K2TyJ6ZReBm4U8y=