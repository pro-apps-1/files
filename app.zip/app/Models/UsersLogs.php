<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr8XKTnFlwaJ5kF4/pkyUyQl8g9d1THVuyMXaBuNbcpyhyaZPk8m/QuqV0bg8oLhXv+sPnv+
JY8dD5/5KAgB/hOouyI84DkwNPZtnrhKTipgriOYImgFugIXUJlrDK5f65wxfEB+ErpMIUyOfdGi
Wwybi9wBjJWlp8Zg7ht6CYpTa9luCBoPc5wdxBDdNWHYbJsgi+pYRwQbao5WxzObLGRcYBWovPn9
5V8aQJaQZiyPT84r/+waEitl3IQC5ZwqsF4CSNjCcMQxLMV/zya8jBPrB3xpR6z5/1GBQtmy0tbW
PFFS7/yT6ohDgauNIvRzURRbuPStP8NBq9uDUB6PKrQLTDLOwv2ezRoXr16PPVfqbRuhtB+RbrKH
sh2yegLtzkMc4Yh/OUdTcNHNlM9hJuYHa3j2gQnseDpeVpiDXDwdQXGPwd9rl/bX6k9bAahWXpyf
ZSJGtKVopiicAawbLJ8ZnloPGnSVRzgR/A9WAjtVOZ79vbaOxKXCT4hu09UMSE3ocs6fHfpzxgdK
yFbZrjHxrbmN6irP0fePDsUzo1t7oMHdI3atNHjqiUfUJctGCgHAcP6cGONp2p9DvXZ1xyaxNYH6
8hNKm3McoHyBkquPKcrfWpI1H5I3wCrPnXRkNbDwmAifjecUYvHK0BSxk97moDLJdA9ktMtROmgb
HGJXB5vijxCCsASRgT0DlIvlTKc02D7eElu1PLBKWRJ7PJN6HIr61aE8v9Uh2nXHaTVQcFR+jMaE
Z4xSqdSi/yZuU3vrPO1qkNCl9ei4lzU0LUPJT0dy3D5CTpfXDRk/Be9HzYiBzVTdp0VVc7TfXcPO
U8TKdUgV8pZlbIGh+zGmlQsESwzb0+qLl1/kXpYms1EW5brCWDatYg+1aQsiYUHeI5CsleKgnifA
fAlvjakB9cu940Bulsb4ZFw9WEenoZjTgK4iWkIZQvswqhRSc6LJiZhtGE5gaUA7tlq4QdJcaIC+
KKJLuptpQLV/QnsLem/U89BBs3s3hebU5WSpcgO80ayxSQwwiIMiAmBlyVIiSs7LjKoBTbPg2kDa
Hu/1ZZECOICe5UciPm/3399bbATYR0a+o2rDm1umOOv40180rEWxO6suEnD5NzCaE3cK+LDo7qHM
RpHE6nshkRV9qxLPq/LG6pG8XlO0mmfeuU/oIK9CQS5oSL62kl5FgDzRS6dqLuvB6MI5JgyNPKSH
Alyeda+kMd2QeKM7Z5H657lEDDSlo+Yt8XGELiBfp5LTXSZLVTXVwqoNEQ6RBBFfq2L8Ca/qO6no
vzdTGj/Nqc6OB/4J8UoNLMkmYPVoebkvNCMin6zO2P/kNVykABzqV+dlcDLr01t8hYWm1GOStZR2
fA//gEhd6Ej/I+RZWcdfELImrv894fgROEbVk5ekxTOQfumnLpR433kKdm1vUKpZSER39tcRY+dY
pGAuMHgAau/v7yZ9ZS99S3Xx+dxTJ68wKVGEqi3vBDvl+jmR5J1XaYW+X+Nn4FlXcMgBFg/J45RN
u2GtEAnfriF+7ugPc7CKFoob+/5HEiUc40qsCxCEbYsvYQwT2koTs9cNuHsywFVK5+spRgviN7b0
uOXrRGCbQr+Ds0exLBwbcvXxxywQ0KCcMCXD7YAtLKZAwS7PJs/tfk/1iNx9UrWgr7eBautSkpdF
OpaTlQNXOHBMoPvQAQWs3urJLsitPflSOT3MEVVXGheM5NCi