<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmhl55wCOEsHIIs1VToO6LWX1LkgkKRTYQ2uQeGBXsgfXrrOHzL7QWMhJFA8WKO+Nwd9fZ6Q
CgWNwkRCjKu6rRlaoNtOzNXiEanBZYtCTdcIPYqnszyWgK+eeUYRc6tZbha4RHsyRVDWQMmxkMfE
BctGrOt9gvKIKl4Fowkfc0ByPEd+0pDQ1KFFe8kMnZ1mBFzDDWEMbK65OuHCKVYgTtA/Oo+L2xLp
M4d0XQPIvUTsqH8hiSuYhFshBabYtLsoH077cGvBj2YX+IbYrpdhsNBPbUje6QfwFLhRQaRQf/dZ
hunl/+U8AagkCPvJw7/pjmRqixBocOuxHsQ25G8TsHVld25DnwZW9rptck6lpCV1jkx++ZwWHcJI
GKAzsx42eHVKj+AaSFJ4D81u8sW2QrZWDtF58fLbUhVe6YI43P+yACoI/jE4mx2d+8nyrPEvvnyo
qw+K78rzYEL551WBxHzqxt/drTMuJH271iKDKwnoJsKMEReex3Zz2CZhFYcVTIn/vlweAfthdnwi
E+etEVlXtTk4jSW+3UqWttDTLDPVzy8ZSvRVMDPsQ+gl9wathFurFg1Tgi9fuBEihDhmmPo5H57M
5AZEjy6qpvhVGoM3LU221Szri0tWIkAloYdwcyWW9NZ/WS+/etjXtADgnU1Yd23ZTsOsaO7N1s11
pxWeLKqUPrncJA/bKIzqCL47NsDx4O1bEH6ckSYXl6O3ZnqNhNTesR4FoFc2h9rtPUMGRGAFXviN
6HAA+UkeQPUL93gLGgx7MNFKSueVJp/GJADVEBJhJ/lU2ALIJkB9RKVE0NO1rcmGR2PaErBnxfMc
hbEMxwBuro1RUrl/GjK4tFJczMNaUewsqTMI0sVBazT70oNsmQPJNP2pqeb9Y1Wv7IKW2Qc7kMC+
BMuVGl6roR45dUCuTOTuu3/gGYOJw2DexuvouH3eVjCnSF36My7wtaCJYg+kVsGi/W+4K31+LDs6
rJFL4F+meiANT49vckFIRg4tObDIsbHfi7NWJrtsOncb1a/SfskfICGYPoLLKvcvy4YDaLa24rD+
Bgk//uPL1K8mC7HDIEj/yO6mUve91F1mvvWiIF2xVkwA0wzJdvbrZ1kMKd3+7USqKrjycVNJuGac
jX1KrixkA1MZ1pE7Iqu3pOTGfUPwf8b49G9HI7Sz4Y94gteLCJe3uMdESJjKtYK/eSui1WeNq0fQ
vKKPz7DvMAbkelnGjeQQgleXHBFlJFAEfymsrUCmpVFQgEDFHZqHGMbooI6HPpLZGWdDOtwX/XBP
517OZkQSPmmWaCes5+dIu5EJYWvommIEwG9E5apLOkLh/mWrnMjMx88inz7IXLSwIaUHbvcq2Usq
+UBZ+vWurcWAZ7bhI/iA3UBd0mRRlXZAq1Rt7EBYYDgISyJxRk+e1P85VFY/uQoRm1N5qr0qJ1Pe
1DK9D6gggdcuQL6Tjwdf4/SATFosGN7Hl+I5gviuLqJVShQ4xxxLCm4WR4K0Oxc1IKHhnosZ8oMr
qA5wBMlSeLkarZ3iEuY9sggVNwkR4FvmeEpJXhELh53FmBEaSv1SuUr3s6z2KWTCKEFfaEbFxFHK
g2tX5iznE8Fp0cGnrbfKRAVKgW8gpNiuuGQ8wFJfm7oEQ5L1hyy2VtE6fO83bEC09RXoIAQiwMyE
v5p+BpGSwNhdwOHKM/s0Rke0X/k235rJkybchIjWD29/mg4e7IRQ