<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyZNBLt/5ecMaeOLk7wjkluI7/dTu/YMIfgur4ir11erMibx8b/uHU9Ov4X8QcE+0BTmHHPJ
hCXKg7phbawPg3k9EnqnpPKv2KyYpvpuJQPuicbpKGDx+WWZbA58qwjQPYQSQsyHlRPvcsRkijPs
k6/ZJmTwaGjJEIQJR5QNNCvaaxXYx2SSUOfougmqXJNzyfTMrDVHqq3T+2JHMEBv6fwJQHg4xtTJ
gWZFyOZCzURYQu693vX/GWZlbxJagzk0DoUsGv2yD9MuVnh1EjhBxNnaxCvi7uhZ8I7zPimmP8gs
VxjA/p03+0WfMIeB5agldvBd09LYEIlITnBU1ibp36NH1YjhNKi0Duwvl/etlQ7ht+mhI5X9grQ8
nPgKp5e+sM0VJBlVR3Zbsz8gHTMUVLhgWznQSAJaf7t3eNgsxTi+HGsnpbVhridsXJ0H2NEvUNHO
O5F8i4RQLiABi5IO7McpPAJ+CJqTNkMGSk/oLjw4FeKz0XahPt74m0OpMP9Itpluw5zAXmiQjP40
nai6VQHvaiKfwqAEYNYIYibBgn2oAFnJFI0Zs077yCkF2Q/xUp2we+dQw9rt+tB3xP4pi8LQmxNy
m5dMybN8x7KwqWLcXPTjFiuAR/BaGNx9X8QearrPVs3//43LgTfm5zzolBZ4J/h78Chj9Cf3CND3
6/E5Hq9ezj8+4DlxtSHPRFo7vnd/vm6omfq1Vr8IGXuP2hOYjKSPEV2lJvunaBA56UdYEEaTLpkQ
VCBCYfkh6ukumbys+kD/3VbcKiVyN5hSH8/be9lSycwiWbduvVpsV3aoMnYgVy2p3WqlgWpSnS+Y
usMdOeiEMVfM6BUAVZd11SaJDmZu9h5NjDuXez4/BRgmRmFo9p/FR9YfS7uNJElvXq+m2Pc+Aopm
HV3bERvyRgjqJbzi828TcTbNCW0FERs/fEp1fJ9mAPK5NtBuUNmLJsi2gwV7kdkAqnyTMUqVpHCU
G8upGV+fuXaDvX5h7u/Q+X42tWMhVD+7RpJMVLlG0B170NyrwyYJnI++wu2H334QSGIzm74gT8Sr
aHtYnee/ntlXZJ1oNkI85GdXofif4bgp1RkTuZUehg9Hy6OUkwUOoNV42c7h5ZTYAutBXHTUjsG4
Qikpxt7LLOxqrf+gruA0wdnsQwTK/Otw8KO/oadT4PC8TSWCJi7B6yQNoo6KzaUDZCNqzSopgd1r
/F74Me1jVdHXNe0ezX5TvDHrNfi3W+mffiYuYmx27z4gYab/VTstz9OQDxX/W9T1uQ7JonzWG3aN
BRtjiqUMEnWbx52gzaSo5i7nfmSJSTNiXQ0756eVLuOe1TYxx0izYEHV+MlC2eqvRDqjagEYHmaM
MenYWLXRaobZppd0AMIzfXTNsSnmjZCAEy23x8OR4XQKUG4tf+0AZvZTK3vbhrIGzLF7YzAlvnem
eqD0o2gpxhSc3Id/kSRE4V4T2uMclHuS0kuu0OzAT2ExW8QV3GgVMAYGBS4f5Q4ApoeTIld3ow99
5NVQCHI/1sfFt39CETpvciT8uwygHIXdbRRjong7wfMD+8MhkKPxvwKd9sWi1pSWIfyRpJ3+LYVN
q7FZo+vEZ0auAh090c2gyrSjjDEwe60F7OmlfsfI7yk5q9bbn2DB+7mgJ6oEDRb1SbhBVRc+jlWj
IPvrQOnU+KiCp/Me2Od41YrMhOABe4q6WhS=