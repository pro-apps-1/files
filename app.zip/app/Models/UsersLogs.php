<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzVx9uN2LPogcpcofiMVrSjpet7Lc3TF6vUu/5TMtW4q+feR9QMmvrkDsI2VW4B1bWxkAuHS
MR+ZZIKRu04rSw3D5Mg656NqmE7Rxp8iK9+GxKFsxhbVE4RpertHxIWMAXgQnKyacZbHlrRi/WtH
ALPinCgCGtIYlpYzfrk6kmoFiatK/YgqXYIy+l+hA9z+SAmEB47pbF7Tqsba8+1QhH+06tvSpi9n
22IIfTvU4e4I1iPJYtHbyQAU0gXIJ6DuGJxrAWetD6Fa59t1nE8I/Q3Fmpjh6I3LR59ENuKgG+RI
Zeeo/qK5fTSILh+JJZOvS0Bx/ovW32yup06XS0gEnjNaIxCxTwWVt2gQBXYQKLJkCXlAD7tqwLJa
kDNRqbAyJ6iZyJiiSkwgU+CDHvyUkd5u7co/wAeTcfPGUqLlV+vkaLs9S60RZb0FPPYdYjla11/s
kSB4LR+SGm/zQFhtYudI3DLAl+XpSIsrZznZiGvtCTgee2PeWPyzRaipd9DmppF0ziNoU3SdvA73
0PxZzzmlw7qw7OXEPp/1ivuLM6Mmlaw1VMyF5r168bJhlsPhG97250KXhSSdCbehp1C8fhCQhmk7
fYDHx+UNgRfqbp6ajLUuqWpZIk6WXmSGOt7phtTA1IEZuLiUMWfgr0Hnu86Kl1PtFPu8JKetlnSt
gxEusdU1ifH+Qvow0vEryHfQy2tRn5zZMkHXQvCZW+3yXcP+oIuDdIXxOcHgKNbv27ZdjyAsOm7N
YficbBEm0nHa0zBSP8C4oh+P2I+aGkBRtt7VkVUhkXTaXUUKLfznHUhuHPNNLXFahq6vT66ErMOQ
oFZGDn1Pvjls030skPpuFdnOmfv8ns2sAuEo9rkTzAy0ckIyPdfwFocoybRna5VosC8kxTzB6skH
xtNqIyFZle8TENdoH9YZ5xP+ssLHXfgxpEz92w5L3tSiOUmU+BgPTcneakOKfl7nzE7xd+wxxpFB
QWgRcZRtLVyOco9hL7Jp7zz0tJrWheinzzrS3tL8fTaE3AStkCmnNMXhYa/iMleAzzSfO2/xAH/P
8b1ZGS0RepQXuiYlcOaHL4WFLZSsJfoq/P3cRMRnAj3y9Zji7dPZmwKN/OrsK0dZwv2j8ptEfqEt
YmeXKL0mwS7ISp5vgWtFoXUGSF7ErJQL0SOWIyCvheWu3QWM4TK3ZJPPOOt4osToQ0cVuF0BCWRN
YcRI2yA47uoxGtz2i5MKwCAxT6p/HWZca+l+oJOzNAsoptXMTqwrznfKET6HClkqyLOIClkta7BB
q8f8YAIVsFetb9zR6cuOtVvf+VcEDjSXcMVyY/X4n/8kwo5K/zS9iOKHSd1hKi0RI4+0SJNf/v0O
cExWuyOFhU8NHXfNtkCTrg/BqBS9meRc9ABgNUjywVdxFw1E+0w/4toi8byLxjqidDwYyPn49vLV
7yJGK0znVeHrCprPXUdP38JuzBNrs1janvp5pNu5x4LIHxFRh55CWIGQxKbTdfckT6F9uzcLDbYv
A/5LglF3A9wqprsrUiRN5bI+NYkTyMgXx1p+yNf66Stg5tPb4xukMiotDIR/WhJ/GPSEMQUGkeoy
vmqnEWmxDuoYv7MciCnNV2artk5hSkUjsL9YQuSpsML9Z294OV5UDnwu2Mv4/O4YdFrRq1Ao8wXX
Ku1+hTrHLW8E5ZxzILvfvhDkRY2PVc2c61HgN0==