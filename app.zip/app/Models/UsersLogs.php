<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxPnTqOUxqjgvxFYPVuzyo8xLQChc1EdDhkuZ5fEipNd/dhZDN8+XvinmvJ/908DU8Gvfoao
mAOUxcEYtc44g5qtSqUQM6MMlqTEhQMVPt59qpLECi7tf2Lx8oS+owVgtq2T8+GNq2eHO2nPW/0q
2pzR4gSq8ZCkGCewyYCbYZ3f9c8FsmsmNw6ANkSooRyL2Y6XgkxSdDenlX7vrt4/j+MQINTs/kvU
wIiucnXLiYlAecg6iohUvU4SZQpcxfZ9mvRkCHcsHeRqKnR6xUgE+EdiLRTelLc6xDryTTquX4c2
bNW1zbr1faNKPUmrbFQXFY3HcT+RMUS0rGHHe8TDM5IywxP3F/HL0Yf7HMmlN5WzL49CQWA/D6ij
mTd9hOUHLbGV71ZpzOpu8FfrxsgdXH7hmg0KXySZqyHlksei0ubB+YoXHMjPBR4tx+OvrFon9+gR
HU8X2AhvzpA8Eg2dsxYgbIeZnGkOT0wxvR3u+DXdkJwC5E3sygaE+BN3JVadJPzv7XDSpi2En9Cj
Eq0p+T+rRx2nGnLWXxqr4bLJFlQRsvS/ZiDb3XlA7VcXCPb3OsMJ1lgPwPbKGFR3KaqMDU47fea+
rXGxp386cGdGzLqxbZFhKoMCqKSzsu7EI0Z7AeEu3c2Izrp/4VTqFKU5wx9FoZ8Q27RBEy8zi+do
6+nMEcIqKJqurOT7IfeZP/wY3SD9vAE0vyyQaNzEMaZQtExHBG2oyCNbv7KRihxvm+YRsbgkL0VD
qgQib8M6l7jhwqKMIiYDigVRFUCQhRImRpPZGdGoujPPsFC0374CodSn4PgKt6hQ3ML7zNDF32rk
R/84UVVEN86mo13vNEG++ES7wXy+ugI7y/4o6BximKHDQEG+GFIWBN4qIg4SIlSDroAoM57Bu9+1
z0+B3lrwV6jyBME9n7eoHHZ1w2VHDChgZn057FFhs0h3u15618F5wXBrTUdnZPgve7waRTQba3dS
/6VedpdGRGCxVm6DO6rELQjnqsTAUmj/eqU/EHfqjS4CSwLIM4Gs2VmXSq9XMp9H07glOAOD9mxS
YD4I8JvJKcaI5Ztnwoeci5ed0Chhcdj+MP6bM3UlPadl5kAnZMDZhEUHw5nb9KG7hKA7VlSIfNsw
p9G6SUMy5b7WOo7S/o9UHB6RNxpA0eUKYNKbeneShn535UQQuqrQLJKEfx4NffbelkC+dsoS7q/L
sd15EdfzvCtyBZRXm3WXTHEOefRx8u2hBCW+4XY8dUGZ4KdukK1wLeCXGhuZQubv5hGaoXriD6ql
x+kubwIEn3ujtwNBwhQ2gb5t6HZNtAuSCLSkTHZmqO+qYJrbmIAqGR875jImhg4uuFm3d827o0Zs
+SmxD+R3CTg7hnle4Cw08luUdH7khNhhXrQKWS2qAbUhvnyCYa/SNXhXjNhymVlbCRTx42t5sjJH
r2I3nUBxcgejRupZ1GB4mcL+5d/4IP5guNtSa3rnSfuLCfcqjdzY/+dEy8Po6waFcb5XsmJR5TO9
zMj8RjtkaPjYdTGh/CQc5MhXsPoBOLBwMQgyCMiJFnFKBG7LS0ibFYET8aOXMPEx38bc4F2X/EH4
GzFrMpqvamxEC/zusT00J8X8oRiOXZPVhaPNARHsP33kSQhQw50fDwkO5l8ZFlp8XgBWKrium7uu
KLPTRZAg2KTf8WExnSC9JHG2Rn6gQmJAtm==