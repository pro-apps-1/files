<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpD/q36oq2W6Ixr54Zg95coACPzQBpVkXxYucEpG7AkwyzZHjeh5co849M8K3sxHLygYsPtR
3Az90f44qQbjHP4g3M2UOu/QIWQrj+pfsHL9y0/O9eDDiNrJgdJx5r8szGaGlKYVNVo4fvbbGnx0
ts4e2QbZoI3lETq0GvI/31+TYoZBQokkKBPoK73L75RBC26pncNXdMLADo9dB703/d7qUXbvJmxp
cwXsHeb6WPY4jyydXnnywSY0QLcB1s5jvZCEfnDjqKeZJQJYb92MQiv9H7vYWzozhcgn6B3c2d4j
wAes6rSNF/Spjb38tC7UnSJTbzpPwUWW0AN3K7ddq9QqJ4Gpp1gJECTDFa4b6GhBQckMl16ksLyf
CUP8/TejYXP6gSYq6sBcnpSXJKRsFKGudxHCY2KvNlK8zxrLQXf4KkoDgeSwheptO2K6T0pGbhO/
BRq8HDUHGl77hzPs/ofseJdP7qEEG+H0Zq1+6LUEW44HUF2EIaLjR5awVnI2kGRsNGZ0kiDhGbLG
AI6fwNK42Dh0HuO2uw+hOusPkvd659nrjyPTi8YWcHWDuKRa+iqZ3B8jhatUKzw80OUDkfhDzxps
B+FsangcYgPIIA8gJysIzPYDMPuH/b3Jz4186rrmzdDvW/lVeoGSJbN/v86jnwNx8uIxknbS2fpW
Gm5SeJzTq9GAc20hRNo3SX63r4n1IbrU7Zgrc6xlU1rW9lqkT11vXvKF8cUEQ3k5hmckW9jWfuf+
gahxPY3Gjh3QKlvPL3dgDe/prAfhQvMbSYMQergJqS+x4mgz0QbV/5DZWCgM8MbWs9P8vsUr9CrW
8GxoZHg6gAiQWzeqEUI6+IpovAjSPuCe3QEPb2Gd6usA7I2g/i+Em/+oG9R64UL1GIS4GmFvFd/E
hOUABldbyDgQjIBIcrFFf72T6aJ5EefJZqynSQHWpcJRrWpwOeKpECwYGQnSAayfeGp6yuKCAgTS
MZ7HtcX7xwhRc3I3N0/FWdRsRnmJ91bzoGVhvT+SFm6TdlwvCX/7IIbpeiLEDyDjyUXQRG9yncoS
LRmYZhRP9noJp/f/4WaFbLcjjoduSf7lrpVlR6iQC9xj+e8JrglJwR+HcrbG3eZtXX+rFVM6iwFI
ekePQMe5B5MVm8yT3y6Sl0t+d/LfmZFl+DGGg3DT5rNYF+UXiXPsz2IDxoOAHjKIrE3O6CAFaOIN
3yYwr/83QHpUe5QnTblZ8rrC5O4l14MQgd6pE9T2YrMXjN5le3P8nPABVKhcR4O1llUig+TQ450A
x27ZZ+MB9rAH6FMbEbKlc5JxmVqb3MjPgR8Mhf5c+UihL5M45WiBKfai+A5vSgxfPDH2/vfOqMeB
zwUJexGkk+WRcHO506kOd+KEaFfdXAiBBUGKMsgD4gWq8/qIdBv06rvzGeYSCwPmrpkdkoD1ROas
S/RmTXhLuQ4uFnM8bih3Scb2BRCpxc7wqqueZipVR8QMV2mwgDgOYtr1Xqn+76VmLsU/InOlOsSR
yW5MxuRmO6Hd9aDXX9d8LycvNnk8XBrFuTc7ohOcetty6TpqEEhMpXUa3sj0p/axbW+waWqSzPL9
nP8c6WMie34EaZL12QBChKC7lRNLAAviZRoLTGRXpoqjeRRynVbcbkFLLLLZ4t12nHM5kz156L3x
cLMkCKzvuwLaEdZlLkJWWis56Osa15WJGEHDC26uWq9NCwgjCbLi446XTxvC3Hsa