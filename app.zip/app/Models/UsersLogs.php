<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn3Qvqo0TTnZNHXoRv1g5z8t8W3UyqlRI8AumEm/8+raXKG4zs8B9eEJFNQITNTX9AbT4fuD
dyuDohm0DxsvC+MgwkvGYPT50ElboF28b+R+ascmwYPjSlY9kwnA+s27KDlTYl6WA11pIQE2QD6r
9xQwpuGCpPfcBLxyA/AJ9qTPdmLzBK+03LzVlUu/qcRXBQ7Mq/JZHaMIOaH6vIexd6/pHzRGT1C7
WClAzFgmGfxdxKwNa8Nxe4tz0AoS25q2juC38Rv5Gtg/oOGMaUIvJ7aVDbLhpFeVFfpQvnqn6i69
qRW/GY62pNTTn4OrkjeZN5nUiN7ZMGWSZ3XsTLdjXN0GASq4dJZt/Wowix5FN3PMTuwleRJoiKGQ
wO6VKt3LHHeG5byFWvySVBonzV1PHnR6Zn0m+01U2K23PKGOivEk6z2pb2n7lEzgIB+zc4UyB2uE
MtlreeWBvld8OHZcADoa3oNJ60dlga055i4uMzJUsHTVsGbFIOC5EX8VWtDcCwoMC3iIOsQjtDc4
bVudWu7YoyJSkZARvwKEw9aAlMYuz/bc/GYtcToFmqt3Wr1l3tSHgq5nqjVDzfqEzKFReRnlq6c6
X8qCvzKktyjWXy+p9EmDtSvo3YGZhp8JQcfBtbZrOwDVZKPhO0LQRekH7PteJYtxDOk0OOl0caek
WYLLb78bnY9BM55yhGTfjJEJ9oamZuHgl7PfwXUM2HUBxhNAX2fkG4DvCdiUyL84Z8fJ//evdylu
GVVQTanviET8fMk6ovZdM9rvMnH0H+HEJlMaBIs69n2JOMwL0GJcUm+iRPO+uSEn+/5pj9ea3Za1
YkcBnxIVA/s8wfEXQ3inXKySCl3UlxS9EfdnHYgZVX1xyLXEWBkH6AKoW/Y/xxqGsIOkueBmsmwY
+h82/Ur0b5sGM6jyTOU/6WFSz0pkybDGOs1Ry1XBkkp3h6M5/EGgy2KigFqB6jZbqqefk44ldvwW
oQxsvkVN+1601l/ZZ/YIFK+XrdxH4eZk2UjX3tGl1jHikyNL4IUy3xJZNv7HyFshFkhFYDwY7QFh
K1hXpY+v0kDHnP16o/xe2+Tec2kTi5Jqz/7c7pd8bvI6aXrL6Orzz9U4owjHaMl9HtrRYAAs1qkE
x1SNf3EZw27+kg5VHUOJ2NGUh1BuLpDR97b8+/7liLoRJWMIKXjNvLhXunwgHegQwQo/0wJ8hhhs
tK1JQhAqWa8LvTvg7WFwVijVPwvCAOO/en5aRMyH6T906K42/kbjHT30n9e1NP3Lr7AQq18Jiw1E
erG91c0GTXYoC3UkxK5pCT34cN4YfWX+xawrKv6C5LmJvZtG5Fat/u2JfHL7apw5QN6UM/89lkVT
WLCEMyAwGlUwojzLGT6uTOUH2zZBenZkgowEHY/VyFb6v3i+8NAxXyGFxLYOSSUHzYmlZnqGcqoi
CaMHJ6om5qj35Gbc7TuWI7mHAlPSiPZNlpeQns+fpCiNrvwcOO1D3+rDUl0+oNAypgQ79LzEFccO
fbr9A8+kNq6+BUcbJ2cHL6PJmtIwbFgq6OPag7Ki+Ig9dKvj0Lo5KIIluGKWal8NTIWT5FxcL33T
AYMTvk0AOWHJBUkJ7l/fQ29Yfyn0vTKn/+nlu8wiz1qVSxj9aPvE1YbFSwH6MY/3qO2+CI2ZyKIP
XDfjwh5D5G6Yo70C3SJmrel03WgmTgZnhGW7Rg4=