<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqlifwGgO1oBCouoXoFo5PT91PufUl1wZlcKEtji80sdjJAMCoe1I2knXYhcAnO8xlVrXy8C
MCbG23r32/JZiqFInpg/aOxUOSKJCWA60vqtqFQ5K5SddtdbwW1AecLy/6pRLXnmb7NBPfHlwepV
Opx8AfXopXuLV5aqI7PI2DQV9KMe1ZKdxdNR9+QNSg1TXzrOK9a/U2ftg7C4e1hWfRgYG9WL3UwV
7UgOHC0bfxGZhUHKNRJjttgwATgY/dh3MPNwciPY0ghcZFD7ml34C3RvuA0EPmmL0sRcK7WalvgG
t6nCSPh/ElOlGBANuvVlvNh52DGBpIxyhx0gPxcJ2e/tcjRU2MSsEGdsf1FxrE27abIU7YBUW7xj
e1sZ/yqacNdkNbKmMNhhbgkfmnjbyDXvDmU4YW79/OQJ5FzQlPHArwltpB4HC9nhqJvESWNBo4Yx
PTWJde6c2k6kOJ3ijWoIEPhq2PcH3UESsfek6d4+5/pYxfU48BbYssGbCL25aVOnP3IFA0dy1+5o
OEaqW+zbfjRO1os34sh3m05eRLiFpS9MYwC/QQjfBU0GYoabUX1951u/pJqSR+ATYMSCUKyBg4+L
SLlZg1xxFoB1Ei1ARlTkW5rXwDTeVf9z+drW9pNcT6am5Wz//yNqOQNYUFZqQKVfQP1w35Gu0vto
bbu9oAjw6gu3anCiFo2ZsBXG7jpcNurqBftWrrx/y83jCWSCB2UhfFZvp0z6OO9D4+Ezt78Krgbf
t8SVMt5SUyubCpIlabvGd6qVfQHBz9qtkbcWyATWhh06sfIEmtwYQSiXLoUl6dT7UG0rkAdZFdEp
R0S8+ByKj5L80eJcK3W+6HBwr/WYQLwUEKqFvU4/BtWdphyQmQcsC/32Qkvmiz+2cGwI63W/0Etj
Ratfl9N918hwzxTlbPoJL2YvCr6krevOHcwtZMHg6vH7sqzehmhJG/AuNJi4y3rkRLuDKcOIqEqv
5DFeQLcd4bVkSj9d2W09ewlZch9HIg/nZ84x2pEVPOLGHC2URpXusdCKwmxrBO6Vc0+ivsj6uYs6
7SBXT+QQj7DFv9E/DgPvRaEBjJeiaTWnz1KzxdgQX2PtdkjUQDOh2I5XRl0uxK4hsdxXv5hQXkTV
5oenc6QvBvgbhBSSerCCY1ATAarqwRhs0wZRv69vXqOpDFbhBJH8qqcQPPhGlHlze3HDNcPO5Jbg
+nbhCF2CuWs3TOfjT+61K4Zl98Nyziq3ZCTbqisHZRSpP1IAv4fk394ZCSdBfx74CR7Sz4LMFsHl
6d4G+QYZ79Us/+mbpJJv9vnoSfTDR100/towylwa+HJJ3tp/wvKfHV+DTmhqV2O8ATjv/zdQPrNL
bt54T+TiJeBgSMb2Y1VM/pS0Ev/fv3Qx+aVPqq0WDImEKyGVm4cQD8RMA4Aod2iziXyVvDzICelh
VbSk2PwZzgo72EX3r/3mVrtyNu/rjFEghKWMDRWtB+nKN4xD7nd5KDFlnaZEWp9R/fq6kXMXJpeY
L0ozZsraVI2Na3FOreadjc+gZQZuJPryvWyUSOYsE9uMUmp+1+Oo8491pvFI14bVLP2wKJfrfJ8u
AZFKvRjPZHLirwINzDHT47CMWBo1jzlXW+QPB8HWovXye6SM3aZ4r8t59D3XbsU3WI/ETCVa4Y0b
JHd1lA//Fe2a6jmm7jQj2Mn1pG2Hfep+Na1ubVJr6Y++4ukNr/YVTXFk0gtK4CnU