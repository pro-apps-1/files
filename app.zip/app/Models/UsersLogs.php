<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpVvI+XzLx3FU3lUor+v2Dydguz5Jd0fWjACkm1Om+cnr2IW9AjOig11L6/jXpPFvc93CEBj
fg+h+pe9Uj6iOHYNw7ZiJc253IbLKaaVj9acpGSzFl/FAJ0Nbt0oPdFuRLuTYW36rFlBvhqdD3Zm
FsFqDzfuW+Pn4GLHAxx1YbnMoAhCHsFlq0YQX7jsGT2SRkGvik3J8A6VsR0x/7uEmSTRLc4VMv2n
A+13VJI7dF/X2lJuFZ/f35vyDHIHPk7ODZc6gl5UV3HNAgEvKMn0WDbY3c8aQPy10WSr201KMGpj
W+uxVVyEXgeP/HMQqRqJSNg8GOYzVFht7xHex2yhVU1scsxp15EKpX/40C1Deo7vRKmUBXV3pCXy
so7NwMaQjfh2aHhx8ZIGYRhMPZTblaXDXgNg5OEVt1njyjVzr78t0KR1Eqsjuob0kDFauU1/TBFw
NyM/Bb9JbrLFpSkGRSi6ItVkzUa9WRtKoHuZOdMsYVEiO/J+m6U6RmjKiMWfTOK3QWSMaiKWnZEy
puskO0LVS/aM/DNkI0bEPdxLZK8rpHDmdsRaCFwz9q8gp30gw7mZU69cLVYs5NEpeawJ1hgtdrT+
sU/mIIKNfdehl0fJ4VhlfU2ObQGjN32GBo12OPKj2Qmj/ofnJ/1mgWyi99CIrggkCwpGJGbVsSMy
7iGup+UwLvFQ3J4hyCIY1do3/Q4u6N5ixqXB1XbNcD5OWBrwDii6+yOssaQZJE4c/OSarhomNqiC
75cwq9IZG7L+1HUVX/2HKF5qLYWLN9yUsSjtafuTWxBqiu6wIhHGXHnE0eOH8jxDSn6S6PoRjjyI
4Udaf5qWflUXjh73unMyCHcgMw3JmxsrVzOWQVV57qoa+dFud85opCAySmCHcEmr2StA7+wR3Xu+
pIwFPhOaeKLaiTf2JoulMIQuqnt4WD7xzz3lq/02otF7sarPQeUxtZNhfAyWRUMQFwbUmev6nc7y
f72waMt/uhrlM3sgwtTo2aQVSVHTh95owbPmGWTK0UTGHKrSGY2Evs5CXK3mrsBrCHmd464dIgMw
nyxIU5fGCv3WcNhvzli/M4TgEB8RZPNxsTSPHcuqh7fcaZVpYluVNtdvL8/Eg1jId433/OFm+DlI
PuwW2hfTfdV5jVSDxwy8eUUTjmw5JEBLbmkGwhHBCr4YqU6qseAwzsVMCvW1+EO+V5cusL/7DUlu
hiOcZy9Zs7KP+OUd0f12FN/J/OMrRPdW2D/yrUggsv8BDJ+oiC2TmJ3VwJf8I9yppkSDHFz9upFx
qCGCVyVlsYLS0j8GwPKx/glmeVpcgCoD6B9zH70e7/njCCUWFzBDb3Lxs74UkaqQe8IpOesJMB4l
+gmSxTQbUuioVON9LPWZTY0/znPzgVP8XKPNvCzHuwMg5BP8xWf8SxD9TfIzeNa71f06xyCrmrjC
W5nzgbQSEQep/yld4IwGqPsC7g2Y9uRelXsQ05gnUy7GqP7o+ZOhP45eNrDr9H78bVWoJTQlq8vm
tCm5GWlhtDyIvqy/puyoL3XnbhChp5wfTOUKXCxz6XVAgGA5exsM3HQ61dALp/54JLGe5pPfkeSw
37KgdaNKaBO6DwUNYGixSl8oOUMt3Y1hyBU9qj9Hx/JSbBklsZdygvyX4lF5lLVYxzBqKn5rQ0GW
dXZP3lZq2gm635pmU8lrupUhLNmTUwdu6c8M