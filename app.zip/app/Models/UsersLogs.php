<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzWkjyt3fWlYckmYxeUacQ0OpKgl4f+nfQEuTzklSxqMYDpkJSVxfHiU6lAeB2OQgi6DBqTO
RJ0qt0j4ADZwbuTpujBGlXuoPL2iinUFlP9ojsT8ZCY5B4eOUF1zaTI56xzEg4amAGUi8TFSyAAr
Y8nVn2xBXMoeCJPTdi6EcQageYzNHeSEVMKkNnsHUPzt+fS2vDg1Vi2GfhDr7ErI/95OTJtTkOdp
coSsVKQsZ1KNRbsp8vWX+p6NH7pgfqwCtc6XwNsmmIHe1LU3zR5LSrpbjG5h7ArbWUEdd7ExM0Vw
oTKg/rgSN93zPcnvHQ807dTQ/iA+/H3rvRK9mHppBnh9nOxAnAQ3ahv0SIDsWKYaNUJ3k5Euyv+U
tRkWb9x8lkdO3umKn/E1SrlisSe1SCpLD22rvldhgW9nCHlcgPYLLaiPllFAPH2P47OStrETNdH8
cQXO31Lz0gZSNVoMpQgGJhCsD3C52TYx77M3oCtFEz+FW2RaE9Hn9wEhHpjTx2FYVnfXyAniDh2Q
AvVe4PWRNb2DnFNXKXKUdlx6zZ8vK9ozjmGJq5RUYjJZTCXK2jViMoHMCiwaSQ9Q8stGvhgnjEIW
LLc1HRjPysBn/DYy7mvHZc/EL3Xt1trztUtEESbnZov1SKjaV4SkXVhvBHccJ5ZMf3etO+QRqjiu
kLdzpmhW/tSWY/irQ8tUKH7I4v55GGrH4sHyhF5i6ylSoQkUPU/vjlUEacSAOadkiiMrHCJbjOTA
Qh9yIVhq60H1FURVRZDwHhVv64NRo2PLg1OudGQ3JrIzd5SIM2HcKDeXG7jpl8j0/IyRdnTcKxAe
HKGwdBTqK7gSJjbUvN15VV8EFYlVoXGsYztSTPKEEePf8zMu92t2U7PPgaIeLirByUlbQbk1FLT5
pLo6rV5P0Rs1kZ/9cxfn1EO08u17q9/qmldA7hAOddBMsvbtgbTlFI/bB9pkkB+rBLq3vLMogtPD
tR7Z18t3Paen0l+IZPfMWwDRUbqjdddih+5S5tCNU1bnA54BUlAV8OYAA48dtnvEdLjjQ6ne6dlZ
t+0XLDuT1Nkm2i3xuijHPcH02UJtAlWgmhFLmTuku1+/iDhSdPlCMo9+CSenHGV09XrAW+EKPZEJ
H+rKkJMUnGyHMTp5pakldygYqjJPQNwDPO2dZjNXSY4G2pFRCxoq18k62IK1+BcjNoA7Efjhrdtx
WufZre31yO5yIbXFXbk6bnlICIBK7MYMd6rmUO4JZ+3W1Mo2qmAqiq/FqOKBRq0Wg6Xc1O4vcMLm
EQ1brjmJFjxKOeabywd6oI9wNjTF/HW3qJAYOuXHZC+MiYI6GbCc/+D7T2EWk0F/OnSJy/8QrobC
lVxzBitDnhkjsR5WKST1W2Ss1gEfu0MwWgXtcACELQ1qRgsEwXZeeEr7iVkq2Zuc2HIo+mXBV5rX
lIv9jP/xwm032nwq4LbL+YIWDr9VKWoXa4ITh5C3XCQNktXUkEJZvNOj/uO61F2J0r9imyOftAS6
0gfcrFPeL6q42NxYD83Wvn4ISGgo0xH1bir0vGL7C66d4k7p3uSKpIu0mETubqddFct3cotSWMVr
w/3u6oV3XjEqNNmHZQ4WDnM1dQcrPWtux2hvaxraEt+zg7ah5Yxnu5FuTZ98kflVHdAYWPug8kEt
AYGXbkbPdIhcvaKLFiYr4TW2geAN5MMeAqo5vVdY1sBXjkSH2WS=