<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu4x0tqvbVTonFcMNXTwXuMbamIJtFz/DvMuRx/i6aNp7913DLBzaUDsqoGo1Qss7S5vc8E5
FicTfp8ejqpg4tjlCwwdBIxyKt0rBt4aYlTp2ZQL0S2/2aLoWf3+FKzlUBOlHhLMdCDJGPvpjQEQ
RrNtcFKO3GQ31RM8g22ecTmutD9yaxWPPfqYSE09RnsF8hNb2uDXZFKQkDb/mH0RD/SRdXdMpmPq
deubah5L19RKgdYiNa22dadt4rRZg0fUmjXVt4A2h9bI+Gfx+6/Lx3YILWLcaB48bBOkvLpz+Lk8
IJqIJwGUZ6oZNhggaFmZA+sA3ZPohpjaKSTJ5miVze5nuxzn9j2d+ia17qkVGZNyR0ErGmUdFfhr
V0fIeELoj3L3pKnWgKUl/cS9cfx+YXFaFW2I5IklLLmmyMBEMh6JFNDH5JcBO79WUlUBscroEMuA
XcFmrZ0s6KgPMekzNUF5tEzeeO23W/PSH9z4QXYUmYYwOR3+CbKOmhh5cSPwc1RfWPDiMNtRSeZH
OhgSePSloFRsWORp2Dl8Cw2rtb/0kFh8nW0q9ruaBr8BRGUdtD6qZ23pNTsTEk/lq57knp4BIi/5
neFGtBiAxhKATiwyUrRqPy1AnaIYwglvRbZLsEZvfZTGCr7/7FjNBH1BVF6+RM5Uz2eJWcHZRqwn
06os8MOLFhaxTjV8XHp0ABXLe+PIbDyjQAFICvGjRrNoB+EGzI0nZeXh51LeTMaQMuVxEL8a6XXm
h4cT9cGCLScykEEFLr2CZWyryk+2vg6IJG0qQnxbEDAGMFxC8CZnTqt+sfm35PXt+r94qT5FgkTm
lexQU6wyn1C4moEC20BC3rETorhg+PyUaeIdy+PEOgnZ8BIaDZZnvrIFTr//LwzPs/8XS+Y4HmH8
wiVELSZi27bNPZUNfZjy5wgftx+xyjOqg66iTRO2aBdWBI/bajodpqEyFZ01S+ULtHjKrfTq8ItY
oYLppai0GqmojnfsRdT9RujFdVjC4tNfpDvm6Sic62LLo4+ipNX8O0qZt8IwflCrfd3beq2bzQus
md4MCHDVzUFBHrebHqg61397sSYKwPj0ZZHxWvDCieoSxzEgCA5sfHsOiHvcLuiJW9XX5bMemBpE
JQuA6PW5DRyOlwxop8CQ/NPhNaXzBzsGKzJc+GbmNKtmb2KSELTBzOQ734cl02nwqg8XNo1wUwH5
cWTTsnhZqOPT0Xa2+59opr+S7kIyIDSJv62r/fmRBX7C+RFTH33AYzGMhJNc6Ql/d1iVV5XhbtUT
Tgom3onyPRPa4i3fMlfvF+qQOMJNfrH8fVxuY2G5Svpw9Kn9uLbPb1byozYC5LVuO6ELuW9V7AOp
AR4WFnRiId+JUejQMWF8E1KXR4GfgMnHDLQ6q09MbMXBTNtrfEt7G0e6AQsAilhfKWQoJXNR0Rp0
UrFHL2ohPZECDPqotYjmE6aIODYRkCpOICtg11CKjuMJRRVP4nCKbF81kT5tIzVUuRk4Ozo5hkgY
ukfz8/XfK8yfoVROGtuVok2PYrLg8g5mNFGD1939wTjit+S0W8xPuy7F6Puk4lM8A0/KRMDSv7uo
px2T4jMxwnK/Eck9n0EMrEw70AQKjysrc94mdzdyvbnxSxwNn7FnxFj/LzSbxpcZ1gqNt3YqDNe+
U++MfbPmth/ELRKAWcSHc4TXscJIvjR4JGA/q4r4mPgapX2lw0==