<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmoAjawpHGjXIaWZRScR55ez+r0mZwTaOFiY2EX2csnQOUFy3byY0nlQT2jfgOjg6uZZy6Mk
kgFb2t394+TCQy7sFqCjVz9rfQpuk9rmfjVaB4eIGnYgoYLZ36v6Nz8C2pqNu0feRg1E0x03GXXO
EkfoyJXhKzOUmFVbb8oi914IgJe9xTSa8EL+6hf8sn1XlJKETnlnkmFBQVDXaa7SXGKxPKudRHs6
MufThrmcYcjIKK1OHwRAX6I6mORMLuK7t6woH5kuA3bInUyPaqOsaIkOiCNlvbyUeUKWqtAwrhOj
mhY6c4zLoqVhCQHjSLisfa+iyecD8qQNiC5eH4nMt8yg3RRfNrAf/zqbEj5iSGtidEkUoEeEl9gU
9QZmXouuYw612jN9unFu2iOzesSp2KDGflp1SaNX7MhLb8/cVMPdezGmtWlsJUBmEnmbKyW90R3R
x5gotEI1CWoGYjgb4RBX/gGLvYyIACcrUh0CdN6ZVwEbzc31Nb7NX+wfJiiv8WM4UI0SwMRMEGUF
q1tl9/ee+kmPwVsseUl1ZqgwZaQ1K6g5JdUTjXH23txTgEPQM6Ma1dAWqegTYaUT6QYD+6h6Lrng
3kYi/G82jCRQG8oC1Y9M3LyuXa6mKkOLO3eK+OpaqHlbsWgTYlK4VAuO43gzt9xtcSRBBTGpL4UR
S57S/MxL8DAzhvdsXRjwOdWY82p3rwOleBQIw+8TPV3pMLSIwi8VsLZ0oo+eZCtGzlgbxNb5R5b3
kVAO5KBIQQqfp2QJd6Hng0hHoIpKJH5dtYuYajpSCnbrjkDVNlk3Y9gC4zC61LkpEcsjv2K96RB0
IC1CUop7UfZflRzg29+sZuj1/TX+Y3W/GNNzJO3nKh/MNqHSBs9V5+Lbm52St4DG/Lo0svH+H8rS
Qa6NHJGglQmRqzZEtYcWmSQroP7aNmDfQDRpAbtkVynGbFUIY1vwAMU6YGb3yzAuE8YMNm+B4FjC
gIqLqdhw5KeSZT+8huPS/rmalGHXXbW/UxBstfPaK/PYTLySCZYmnPCBTgBWGR8rfKXBnBVdY4gV
lwn8aDpp/SdazcLVlRnZ0E08NHrEI3NmN4cQqKIV+CO2hd3mkALen1/hW8nuD/n1BkWmgPtLL+ai
aO7lyr4WTh4mj8WOzighRejDSjudtThczfMsM/83Ov5eCjTEvnktAPV5MeT79c7AHEgJMxTgbitM
hDWR/r5vskOLHKB9pMXHfwmtg3935mXR1qHYtsQ+vAhlBy0DAxosVs53JlUg3NX3Zt4Cy94CaYPw
e/lKGPwpm2q4lhP7oDih/w5vERZShom6gEUVKKCY7rNRLIHXzJeorStai3Z/ssdhDsu3GXrHgm23
DEbFCQ85BUaY6eGKcPfEBQg0sFdCdCSePMIUok5B02AnnjQO1d/sNHvvl8m5NpN6V0TT+nkKHgPN
oNw1lr5uuwxK09W5pPCENBnz8mvWgBPjznt3yiy1p65gu1sXVJUj8tBllQJCxLlICuTGOuKzJ3AJ
xaGYlAnrZLB529bY2eBQH3Z0GXPyruz3M8r5AT6ruE6yV6GMaGgXhS6rwQjMu9696GrFSMG+spsI
hjjW3zPerKjr+hQlI8/FvzmpO5v2/AxVPxZkkQoBKCQt4Z2iZvGdhmYoXohh/FC3/0mT9RJwxK66
zFSahHP5hseB1b97fEe2UmmUG3c6SIa8AejaIbUv4HRWy0==