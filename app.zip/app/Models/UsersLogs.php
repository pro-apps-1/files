<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmfLFUo+2eR3HvUepzECW4u/l1W6uc+JS86uS3gnk7G+i2htzoeXOEG+W9apl+KKa9BLYaMb
ugonMgjCv8/2/o3xY26w7VblZ8upDU5cy+c9bp8RxeWd2aAY2zENUhl9Ne4V+DpBppH1P8dMN43D
gpyP/2Bo4goMAPVOX5lIIVYL63qivZHrMFx/jSnn2xqf1qqlgm6ypnjXVAE2WjN5c0SC6Z6wSfma
2BTkMxS4BLcH0ufEeI5e3xGCMKo1XZa6g2FOXGmX8x4qZZJMw1YKFlZa7VjamRE8WkXTRcFb3qLh
jemk/yWNia8TybX7p7Eg6DVWOl55/8vZZYwondi9x7pelimupeF6UdWdcNDqj1k5jFR9sY58NBoK
5ZNas+liQtNb6XPOwlLfobZLeZvsdB4hnPIR8JlTFKwd7jmT60c62Bwl45BgyAFfCBeQBrjCu8DZ
uQkraV1KkdZ4GpzQWFco3jYGygVpOd0ljXolD/QTknkZV9X6jftkmfRY7CF6mztEWdRxKyye/ZPM
LN1qNPImnQcP8s8SgW6csnbw9euoinO+MREf96kI6LJnPTFmPPyC0pAjLXAa1SSeepr4Lg1/4MIQ
Nhq7n0cVGcSHgbTvVd2HkWsSwnv1ib0vI+TpcDEdSJ0MhmxZvcnvZ/FwA+rs6CRV+PHFTbqjyP3S
GkZS6IZg/iKE2efHoZfN8qBHXmoiHpEfWF1d5+UqLG5z6aVz2jT85ei1vXlEmQfJplEdfIywBQmR
UuXfNRqm4v8f0BBHA+kL+FM8gZyz+Txgl/WHYcuP+Mb5ZRa04I7coX4OlilQ7AvFXKnAnq+dJlSh
HZXza5CxqKN+fDBZn7al1gmE2j/2SpBdpP2EDTaQhzxu+gai+ud0yJNJwGcpgUUrk7UIVxzS6K6J
zXG1lBYBJ5HWOS8UWXa2XKXMmleYTPjNJDzD7OLFePvoKzR4zVk9AbWGc+ZrMCXCfHJJ4mmGvFjR
MTlWouUgUF+7CkEpuUdW7NN7vISRJySiQMlRAjcv4ZDiLO/m0NqFplJkxK182WEgrmE3SfmLB+9t
fm81St3QraqTOTVb7jEiM4t+nWS2nayHdB/znbHAdv8XSkQ+3+LuExOnw7FJ9G90iq5eGznIJz1J
635MSkGxNlOJZfHCPorl8yumgp3J5gJwFVKYbLSpNfYMkW21ECdxIdT/ik5+OwONLux7twATew/H
L29NoefrXbpjFM3IHr3SWKyf4F5pgV8rQy6d658N29E9KQVrOMTgSfE0gw6LiRJvUrGZdanUPynV
+6Awnanpf8QsMUuWa1Mx4ll0vXRpLCI2xNazvxEo4dYeZLzbGSGxSAjz99ahmOJiz/5TjHYLh3Yz
d94xBzX698wbCVH2BOOFKHCJMo/BpTE+fHh/ySVKAX3dStcflt15xa6jzMyZXMH32jQbN+J3kctj
1+23yaAovzhyD7ONjZWMlX4blZhiowYeQQ+QEM4dc4BOZkJecSWPGnUD9zBYrpfUzhXRNhrujX8n
A46vKo7tKHmRlR3zVv0TFttoPgNQQfBRZ9QJDYYP5MOEvW2syAr76HlI1464LGpvLahcVpAaFpS2
ts61urwoHXJ/GNlj5i2EEKs1FTO7MPDHFRlwToQqigK0AJv7Pwt7GCRdWeh2T5iIDJIeHT0NpJhx
D6IfRIzetLDVIYJ1vsW9dAqG/XFK8g/GeBWDo4m=