<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPovcOloR+LRqOgJttq1Uk6aGXqRuYEvQMS1xtDwPcRob+ek4cF0Jc21IESOoyk3K9+nm4gwB
L7pS0dufiwdvKpUlmjp1SjNry41E4qLMSDtSLQ3lYC1o9/9bJ3COUoducPfLQ01qWolfmUUueQuA
x4lAD9M71a8H5gwFV8pGaHRHLgZhpPsyjDsq0uHI8pk2q2PcaQdygpkk/3fJ9Y+6LmSA4uhEQXcB
7uZkjg2nlYNR1AlhfVFxnbXUShMmbkppJ4NMgIpoY3b7mRaD5DgPUrjRXgm11UnlaI2KEpfDskcO
f1xtkPW8/tvVVEy6R1AxfESKLtmYHl2bxU9PqT9hzuBCLCPntGecEgsMxtl3SRjOmj28O0WnQkdG
iChaRZrKANav343g+4sarH/tKH8t0s58BtcKKBzf5FO7vW7nGLh3c1mrI5/p4fDERXBQRq+IFwYR
/o7c70b+OJ9IGHpoYNRMFu26Tt5dp/WgACGQjTx7u/C9/PDwejtA8Xu83EtLBTOItX7pqUybG3r7
2U+lR1sTUiSJ8ZAt8zfjpL9Wls1UMKdKjpyo5T+zmkq4vCgVnvuHrNWwd5pKvo9jnv7QbI8RdqO4
9L0tmMZ2ZZMgcGAgZYkNajgVLvra21pB2vT9m59UiIZfpWF/SyPmD4Gxd5LzKdV2GlfrsluD5LOm
8UlRKXjXqvHx1236gQvxSvzrg09DnkANaQicOtt/TUsD5yKXya2jHji397V5L1F7OmJclnFFW+8I
eEvgarA6t9gB+gpcJyyC7Z31j7oVkDXo+/+8XdTyXP8oVI0acXzl24aMM19U/zF/hcgrcmhwybos
w3/49x/eqd3o6xVbQ8ejL+jC3Bqaiy3ebaRqdt+O5IDrnmZr8L3101ukcKFNMj9pYxjzAyQAeYoZ
TsAmgVrohxwRchCsp67CrB7o19kkeITuZkljdvOP6dR95mvOz64Q4fC9NyxLU0HS1mcaz0vEtUj+
wwjyP13RMuhYJTfK9+tqlqTHcwRl4mCMKd/csOSNlE93PkhnGmgYA8hBjKKA9Lo97+qgIOKzdBcs
wSl22sgnU0WGcxZjZKfj+JI0aF+VZRe0Q7y6PLWfjjsn4WYBOzV2cSjel7zT0GVjjVCU58YzLsWB
8/AEn8DA4MrXi7Zz83Br1h2OwqgAAq56/FB+bcTsaTYR6rbq4CCztQxs7pYHLgkNsz/9wYV3DAb1
HMH0TKpqhxzPA1MKpgXleXCTuz5Xdmr9nLsMsMOX4PHETAzuOjb+4+PGVR5CqBRkN0aiUbD58vhN
0kePXHmj1olfqT4GoPdJ9AfQVhXmBXE30rAfc1FcV6qhaeYXV+DHVeuPAmb3Nnkr9+Kll1zI/skI
1AKY9Ui3tzWRaz6BGbZV1d8TxhtwIt58Jt5QapDPKCbBS/0wwrwq64jYNeIXmwU6NpTYx9QpL6sU
zdPjpmCJH2JA7/7yv+pwzpvTDpv3HrguRUVyrO5sl8OHBgpQn07y4kRj/kypdbnaw3J8gf4l8O2e
tqe1qniGhWvcjCzIqUYzPr0AxM+kmm01gDmQ1wz6ZMyp81RX5oPZsBtWb+EdvyIz2EcU+bOU+R1z
vGVRViIhP1rryg31IcaottZN3dCpVzDVk/a/x4FzrwdOpukZMNfTShQCOUdFx63ye4zv/nxPtyxT
44r+ZHRS4Dcpjt1/JaS8KoiLXRBc6FEkCWeIm0==