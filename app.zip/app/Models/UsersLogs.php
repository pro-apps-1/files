<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnjAPM+P1Lv1P8ZmJ3/Ly0YU/ToOCJG13Ocupxla8JLHh2qXrhLMRfgFEsFiLS7jlC2TQRvT
JOUSG9u60Et7KDvXgz1uFwjPpBAWdDcKW3sS5eIZIr1B+0aVMsPQIhLwxGVCShwmHAija+4O1idw
5KKuf9Zk/ccYA+ZE2B8kyRkP7ITjricikpMh+Oj831b3jrFYNElbCFOB9yF4vDRmDzr2V0MvljKj
X97D+hfRyrx80z6n0D6wFtIHVifiUyYqNQd01wkSve3f/SmM5W9QCEVAiaDjD8JFSwPYvb9DVKfF
hHf03cSIpQsa7m/ScmP0J4piW5KngHUf2xVxm30eUbcBswsxVxPBy/UBBLCDm0ejHY6jb9RbjCIb
NYmVrPJSmaQZY4oSRUE6ggR++ZBhA5ruw0boRAQjGfzEoGLR7x/KBkzMBOmlLe8DHtg5OQCFdk8Q
ivjOMNBDTq02P9QMTqD/wBLFBuH9OQZ1C4m3mDMjxbzUxgTrpFb6iOBQ1ybNPhiX2k8dkEiD/d9q
VoRuJ3kKSOmHwAsB6wSjv6tKds2Hv5z6r+WAvUYmwU010hqnD6RitjUDTgJAwwRwlPKvTE2L55N8
SL1t4VfhRv687BFNK3jPhJImCDDBH1bFbXeb3PIYbSSqqeCGc47/FmFU3Xph0S6Jij2GWOzRDQXi
KX3A+7F8PQ+39tKY2lSwEMY9PRtmWTYh1ewfMD0oRQclRb6X1hPpu+8+ytOdsg3evgP9BolE++Pz
TNLJkiZLUY//0BOYvLYDuvd5wU/Y75XcaRanYrtZv9QyWHixzqDrQLjW4I7jW9waLd3h2oWlcOff
Lsa1GUEvVS1Amvyj3rJunijfR3q4CFiNnUwcEHLezwdq1fDqRtlajx5OeWMU8RvKVe8u9Y/lpUbU
75x3L2/rNTgde+V6mTUMJXpEN9FmgwJGcEgsNRvZtIWchknakl2Dbmg2rj3wsg5d36RW31x6LCxN
y8a2zmCDzrFzAj/9Uzaa8lfIWbVI4fDAKYIwCLLqkJziPlW5AcyxuaJOAwn7E7jL/R9FzIv6Ebuh
YCI/NtfS3e49wcXUdeLE6HeprR/yPNMOD0xRkCPs8L46DvttR/jwWPNUbwZ6cF45HNLaD5sXt0Qp
/mebeDN4BJl9kp8qtd5gHqUUNLPFAXA7FxGQ0mKACGs1yHXdFUDSg9wn7vijkFudIONaDv+HZ74b
qxm0eqKJcP5ffbXGUe/Xv3IpxRhiOewGN1hJjZ6VNChg7QZMw2XrcHtHZWEWaTdQ0WGnPFU8OsOE
LeKgc1KNYeWC7oaDx69M6tbQPP4d3Tr/Cj/D68bKvIwkK6T/UHBJNfuqf7ecyhxuunixTLkL+GAf
j6+atcDFp8o2f9/BR7ldDwwfBTmQNG8z5+RpmMtsHO6zAM+cdwpjxhWgBVbg7aZSI0Br+dlH+tto
WOw8j76GjkzeoIqrNJvqfN6kYSsHc4LZSeigPZ/xvLlI3f3S7TweTijzJnKelfypvOKHpoaIn99l
0UCHc4LMZabbCp2WamtxmBf9mTW0pSVU96R1mZ8eqiPxK00Zb6Cb2kJIImiJ9f/QrDA5CrTFILhS
6pCclVjISjM6fBCc8Y1XCvNXUFHxqPIQnb4r/4TIiZ8J7/LKaED4aRCYf2Lt37GKZUi8yiY5qlAW
FT4wQ0bCOzzfzvmlXKOsJsUqsMyHVGUWCvisrdwr+lpe4unNrD+sh0zMfW==