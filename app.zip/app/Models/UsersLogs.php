<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs0xzAPNbSo9BlbXXRwTxy8MuhVzhN82LgEugq2ywCQXB3w20iyGdBMeVU93s8JreH3TiMxF
S0e6W6JwFqXpkkSgLAwOiJQ2HcOVE3gtR/HwbaTY66SjbNZtUxsOtWsO4CooM66jNkDKbm+9Abgz
ZdkjJ2iu7mPIYyU/0FQWiuwJsST3RvHK5clOtdaS6jrbAoj6vUbUnIQiKUOvpaWY6rtCDIi4nZuM
KvdflSOtIZDNLhHm76FSJRIj6nhueLe95Li5CEF1x2Mp38X0OBGOBrINoGHbpTjDsbh+bN2FFV71
hdmweiIVmdk4wsTZcKGNKHGfDqu/lYDgledCtr96TBS5JWPv98KH1A5+7jZCPkZIgRARsvoNRiiJ
CE76f5MFY1rpLI+qVi6kIGG4Uln/cPakJUtYvkRc2I8JidFZNPoNxP/LJ2EtwAJGMCIqW72eP9of
o6Id4GPXjKXMo0eQ32rEQG9YXwptfJ10HFvOodgLc6sN6OHyIG3mB5X/IIRSN8sjRHdK3vgxFbmb
UmtVrn5JktWE2fQffjzNOKwR3la50p/wnodb3UV79pTtRSSuMWSDrzHMp0XWXtdFRwV1Ju0ULt7J
NpwSLJ3kJRanZjM11FUTIYgoJ1Ki2/7c5Gnvswsc7C4oort/TkTfeAtqmiXghTr2NWRb9610g1wS
8uAKf6idXEGEK9LhOtZGyNYpshqIw7ERTzjndfKxlx8RVUuG85/Tf84e32tLrkXk+u3cl+/bPSl9
LpLHExmaHZKcWn5xApslUwBuw8AERL/xwc1TUCxtMfnl8S2UOyM+0sWkm+61Ek7fU1UVJGWcitXA
FbtDeAcqVtdzvXRa/fSmMzhN5quL8Jx0i9TAsnRpf00tOZSx0ifQmc2YgmKPaxb5HaGFSYjBGuIv
37B38gbZh0gwFpyU3wM000OhIwaF8lBMSFbGCcdjkbZC0KrO6VATHNMnmXzPXPz7ab9Rimi0rZv7
nUpqdwVdQ//nUdai04OxkGeemyaeQ6a32aMf07p7Y27ZJZH5+Ng8l/llzBFpmQYnfSyJaLJR6qPF
iwnU3YeaOpUws41+bL9kWl//M0nLLYffDnZ8PHIVSvVth7MycHCDVlSblEr5EtbTG/fTyRnxMDI6
QLdCSC3uL82EjuRkU/UxSu0oz52lIlwf3bvPbQvx7AlmovH41tr7pBd1wjmfUo8oKTiulBtSKuh0
c4n/xA4omQgbYgs8hLSF0mlF03zN6PQ0I35FBsXbySB2oHedoGJvGKwpqy5rnZjgANLoyxvceQO7
SsCB9uBU9HyK0HJhMjMgNMDNq5ppGhgbzUU1wsJf6/UTVwuB/oMrtodMzsnUBLGDCOJ/cPb8ev+v
o+sab4FMz/jT7YFuYstvDFOT8aQ73EqGo+NTQc3gZPtSogKrplL07Tuucvn6HIvyVbl7j01X9BJm
Y+VCz2QufUu/j9VqTtHhMplPvxasJMnPahD/kWt2YqMyN3sKWTntwPyqsjgplqcLhHQhNiVXMnMj
KjcB6pYI34SdIg7LuwA6kJzBfJijydV8GgRn9v4w2hgTKdJ44fWUFNrWNxaZJIZVJd9EcO3/JFK/
paiX2CzQxzb+z6BLhdEBPYxrbCvLIzlRQ3YEICMx+0g7X9VrkbPu7ItTnLKvY5R2vrwChkTGq9bN
kYTWOHTB0K4CUKNFnvok1a8RmiLWh005PF0=