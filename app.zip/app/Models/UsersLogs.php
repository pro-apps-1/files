<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzp/njGMsP0iMQJ+GJNfumITp9Ayg4jDTOkum/cODMPknWdVnbgdQlsuf5HTk7ByCaRhilus
hMDJotnXW+NBrHBm4dmxacd2lLv2SoOZNAbDm93VDNr7rbf68MFsCUIna1VFmvsENZyF3FtPYCD6
Y2Nc8uMyFutafbcQoGcN6PcqJVPf8xdoB5CtS0jrbYx4JyOo3xdIbKfvb0qWnF7esqwl0DVqpHJ2
c7XmogEm9AVW5VszBGHcmTkPP50MXHe8ZKwmfBZeLxUYiG0Ruwqfsmxzaw9jS5xkaHrb7/QQi1Z+
5XCiIskp2dHNE5mfp7itweie5mDmUIDPTZYAIobDvu9NrAs9j2YsamkV4h3Rkcf+gQvh70TLtQ3J
U1nDGivW5hK+zAThWkp283A4g8sgUepu425KgaxnxyKkxMaabTvpJM9jFeYUr1mzIUQ460bl73UE
96wG0NcHFG2esp8UogwnG1BxNT4U0YyeJ/Eb91qdY5/fc9IR7phZcWlUjwI107ixpQpGJC/vJbIZ
8TTxVL0piP6TruvRH6WaLK9dZdcNcB4a190VXpVsyiaZY62wQir3XSwBtoo9dJJDiVtmvGdcDs7f
9E4VLijcwIaYv00Hwnzz+34Z4eadyH5siooxE89H8s8BzoziXoQMciZ4JJX1Bk86oLeCxCSgnKaJ
BGJlm1pYtMdiP2pbGZZZIomeyvwlNdc9md7Yucxq6/Davb1hMhJ5n6F+PI37sifRcfegxTtsw+tw
G613SQl3UnEwoMwqpyrcW5BkZNscFRjhOcGGOwY1NwjyPQbbTCfo83bb/xlbmePEAgxKwDow3PFA
89iK2sFEpzAbV+8e4qE4oBnFXZqjMZco3ZN4xgCp+eVE9rk3x2camIoIjafHMlYMfyAiBQQurjV1
sUkrpnOFq3UTPfLhQXj5id8qzLEOvdOepbPtknpXf8XDQ8qVL3JMikkdm574OSfsQ3QlDFa9sutj
6WsRVuF8/GhqwdmUMprVNgPmyWdHgeuhltX178PhOVfABPqomdK8KPpPuNc8to0z7I7cGqePzEp4
kJzFIcG7Jq3QbM1nQ8693ZrkDkzoLBNEwkyn2wkaR/2q0pv1+ELCfuPNRFRg6x9Ye0oNNFq3fF00
lC/z1xZ0RpQ8JpAk37NzdBd5YaX2mT+iE+xqjedMw/J0PsQhBT8mibZAGjBi4Dm8yn7z3805rhqX
FQw3z058rsBhwfSJdgPPMCdqUOqt4oRXfhlpucuVWbnIFuIs3t8sNxBT/d4GyG+NyASobAfPsPG/
veC9tv4fYLFTfIQyB9C4jJ5BVwOnxEt3Wc2IHmifbna05Xm/esT0sY6TmxqGMTGKVsKwmr/XDfS7
vRwR1V2iL8s9KwLXmmgdr4K9UXn5OUcWtqrzIKKAoSTDmRDsjpB7YZsOpVoM3QeMhztgGpkrqcbB
aaHptZfkMeLSeAe2NpAAoFpc/IC/GVY/goMgxipDHdEbqI8Dmy4XlTSrYBSSa2g4+Rl6qHBut124
NLS41MAKtKD/2Ber7cfDRpD07v8wyLahhZh9T8PC7utONUIqAKqSVldJq9D7rVLqQT3vjDKXFdOB
VK+bmAvhaZB6aQjyEzA2MYERR/Hol6P7H/ZZh3UcNO5lH+1bw7Gpw9Vz44B3lsjhvanZTch/Yycf
j5AL0IAABgFuwulhHOC/Ceo74rA+tYWJsL1oECdmfsoZtCVGQ3/znbKA2wan5bxm