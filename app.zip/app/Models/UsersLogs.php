<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmMJyHXbJSfVS55aEwD/iU0UYkhS0NvQiOsuzZr3Ae6w0d3b/AoVXFMr4oB5JtP0drlCIQXB
xPrLN0/JDvpTWFCbcT9a96jprdlv0EA3Q/btE4R8FthK2x7tn6oWDFqt73G8TVcGme7d9GkBkPM5
LYV9vAjEyYoFIc4xbpX84L/84c9+DpSQ8/DbQepnP6tCkVOsBys9Uj98h566coccS/wzni+10Z38
NG4Ynu7NEy+BAIBBVmAn13BJmbKpA5t8//cpSkkF2qtch+LXWRBBi0u7Rized4nt6fGbvHtJ8FGV
J6WCbjD5OkicW36NByB/lpi26YUy9ZIDk7X+BhAT9Mdng+XxIeWSyTYBtWaxQhndwVZCMaZfbAEh
i05QjnDgPGTNhEqSrljoj2RVhzKC5759zfEX0Y7VZ2wnao3czXogoQYxUZe/Ub+vlGxFQ1yMLoBx
qLseMFH+vqip/965D2AG0tiIfVvEch4IlDASn5N2VSuEn5MSn+01BemENcX9QSAXWtKeN7PUXeCp
yz/2e3uP+MkXnxz3OfQvhs8ETiDeWPx7mALEEJ6NSmyHD2Ru0QdARZdfn8PhmOrhBeLRQuBXj9+u
YuDpKEVkedJwhu58HMVc7HoGTwbdQgtuU8ByPwMmvUbVDHK9yq0qNPs2JhWUbKvD2eUzzPg58Tyr
GDMDh3fyxgsUcilpoXxTxUVduHpHMO7N7yeb0CKBFXDyYzwm0kiahWzlS3RQrSkZkvYJpgCWKkPE
8todmwGE25Xc1jj9yJyprJAVDug8pntWp6TeEWPTLE56MDmMEpV4yTEKEydo4xJWDNFqep95jwVx
lD9FgU0HK/0UKJ5RSd2+T9hr86qrayI3cFiT+wA15bx7KlMfOP+/TVhD5kBMj6BI/q6tN0D5WXlA
R7KT4NoRi0qVOiE4/WNlqsmnCOZMwdgsrTxOHcnBmCFB/ICuDTESQfcmc10LI6amPyyOYR0OL/Ao
WxN7kGeQ6c+TgmX+JYkUG2W6SlxhzlOGp/jKlOM/+8EN2EuoUOKCrdmtnPj4ZUzS3TQXMWm8iieV
WCeNrZ6g/B46peI9ydDV14xNgR04mthvqVt8sjEOsvZ01TknD1QemwhvgE7ydh7dYITS83qb+Npz
rXRyrIuwSxzKWH07/gRznXJTbgthBgZH4HVmlV5Cj/eP4+SVAxQQjzJqwi3W0f31FYdRaYrY4xm+
2vtRM92VKj2PmUQguMVK3o3Drv9RBOHPCqp7PnuhOOhsR1TbBbg6L2Dl8NExlwyPU6vN2JtvswPQ
spUwBIILePyUm3Tv3fiuvbr74oVQY/tj+xTjx893sfmU2fVdB8kgCatkOtkUBYCjVGn0wTMa88rL
ApgZWNY52O7tkOGBL7WzEf3P2pkhmlA6M7qxIeUPMfVT0P+k5paQ6Uh7vdxw+wpmYrGx/aD26Ra9
aUgmSlN/lpLUSMBd0fS8Fs2fgKzOoSKB8aTKfy554WLYlcD9PSpDEWPvzgjoRK5WH63UrSrw9pL7
Cu/LZH5pWPFfq6TnhaFaRdElYDXUNJ+jmk0U1PDuRpewh8Scay8hTOSm0MvpDn2Lk2VksOsYphOS
H8bPcqanuDjL+zzOZoxZMTn+DbmK9FxZ4XZldODaZHeCb4/+x8/lUeo8n8i0jYsJEJsID4M+TCDW
3vclfgUKk9fNbmeDYbP4DNJSiPemGGeO8JwHPUl9Xfcc1QEkPGceSWSk5WoPybfOiOiP0hG=