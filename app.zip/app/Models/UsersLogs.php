<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwgnWFmNBtdpxdCLtus7njTBRFjciBi9fgIusVHMy9csao6sgG8xKEnS2Cif7SaqWxsX+QLA
CEQMWJLk1SD4h1BFIeYgCR5MBbjDNW4fMwBH+9xw5Uw7SEiMbsX6ukjTOsn6ISxHi4zGqxuwTz26
oHz1p/acTLmYh812wdeMfg4rJQhlNqWdk5W9vsW2TCxP1TGN1CeFDgqFFg+tzPR4oP2Zff80ayxZ
kiSYk7GvIEdkH8IfDp0+Syg2rXegmhAlq06TRjHLK0sFFSqLpROcz/6WCljg6yFtmhazXVbj8e82
CZWd/wFDJEc5kQX3i2mFcrnYU8/MWCMZVS+lNnlmNy121YiJKKrDsXbtQMkAbIr2BuYjvKW9smcw
2RjZoMm7Lv6/6SrMwYep4giKMqPXLhFWyRJZN5ajyJWl8kJ3c2hOSGrLCit1H2gI1cMWPqAuQ/Sx
dIFniry/vBOQfHTOHMlMix3+Wqkv+PxZkqCAFf6NA7/oL2A5QAa+hGzjmAgg9FEC1BzSZ6eOK6Xr
1EY97I8qEmICsbZjLBoyYbWMZb1r2mIpdTdVatfWXgbh6UxuHlZ7E+/AxH7JljOhZFANKIk6lRdD
UR3uVuG+HS3t5xbYMDgpbAD89bycqXEa4F6lwZGU56NAy21AxWD78F5/OKAgRHGtfs27j89OMoY2
pghs2Hl5sAVvWlNNsEPhuHMbhQrKIMs0wCJHWLMVRTlidjmttqFPCWn6U7lddCvK4XF8GxbIWOoD
92ONHYf+DUAQBYHP/rHhsONV5sVp3/3ZOSB6hJf6HuNbruW91D2OCo2SfHKMc/tZjov9u+48ANji
dMgYJdN+W/1VCpF5c9Z1OZ/E7KQJS0x6esN691O0x0uv9LX0wrLAIA/AhnZU7SPlRw0LJ/XGuNom
teCwpKaTleL0DoCCpYoocSVQMdOlINi0tWLsvseemCzmcKZ4q87Hprkz71N/HfVNKX12EDAIiToy
Efd0EoWjLFr/Hnr0DEZpVLYemoZxljoicZMsj6odJy84dI/HUHCst8TUL+6CDz5uFjxfQWHpEfIe
3uBGmOI5KscZHS0xaRq+PDQjSLzjIf5TjgtXPklVgOqQPV981jHcGwYCv1q3c5qN+DRykhmF+4ig
baodOy5D/jDRFjx9VK2PaZezI9fKG0odiLJNuxSJcsLCO47T6qUURK/MDDBFtIbUlx1I6A8wyApw
cwPUC1qx6NjAxMqxXLU8rePPXy+rQmvOR2rl0jpxjAnNmSGGLAGz6Pw5UCUxtVmojD2HMJNlpO+w
o1qn6+KMleuHDCDHEkEq2FWO8mzaiuQs0JHGOrpUvZr+2Mloc4WfoKcHv5Wo2m/0zBZAQIVNsUvk
wv9xBS8BWUlTYN4JQ6CnA5I/aY5tyC7953CgaGihZjp25XLh/t6OX4T/zm6DxX58DWb9y9EeIsbg
OXDwM2cC29b/b7GAACwdomKZToJ1RrzZJYyvA9jQWwtxS6i8lCBWLBZiTYnyALDF1UyLrwqFdlp5
0NHOPP/ZuLmxbPoV7gPkXc2nxyRgIQMtAcyQaGW8p124zxrhTUfrXc4oIov7tIK49FmZBn1OuOV5
I4jJfDG6NiTYknLDB1YUi/Z6E2HTa5L1h34GE+64NyttffbXOhIuCJcdDdqPNeNOqAh9MyUyxOzV
5Ac/kxH1Q042Th8+PUWWXryszRuU2KyVz4E2eFjgTQVJ0MXE