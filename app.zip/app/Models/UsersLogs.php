<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrBh57zBPUrm4Yc1N26RFnqTrfyIL7GsjDfoUfl5O+kLKdRQ2OZVZGLtfiQrrAg7rn3kqjyc
SAMQD4UdBAypOez9hMmdEmDrbpte3h0nvl0kCbs5g0rxFpYoJwuvr2KgGLEGjqbXBFbrRGd1MPto
R4RYP7pcpry4g7Rgl1gRjFGn9BsP4QfqBwRDgKWcbqM3g/BMK7jHQW13q4uDKa1Cuunw1c+CBTau
LxVfnMPvA/suq52ZzX5wxArMnFAyz1ZAXTQ3flHX9+XPhbv11mcj6MAwaFisPzs98Zz1Q+DafGQo
0RYAOJKxTyHTJJ4vCBS6AkoXBJjYgfgRHlzTU+U537c1rbrby1arbd/+sDQXZGqlxp8oyWnx9WkZ
We41KBUqhWzNhpJyyhEdfqBPBe2HK1FqeyvneZwHGhJAEjvFwxx72P3CrIJ0iWFYqvGflkjIYZlW
OpPgbMDqJE2l9NGcTZH6YjJSPE6Z9guOQOCkJR+ZeJPKDixRUkvyO3KCzSdY1uC3BonSRXb+y/Oq
m4jRua7pJUq3f7rnlxu3zRrvslSMf9Qytbm6wlBwvjGmUdO/0Kg9jG0DclBT1IRR7SWz5vpSEo/k
veO+sdgz/nJpMDYRhAXOkmYGFHOHXqDfTlddgZuzdhQMOkvJcfSiIezvIZq7qkDO8B/uaLe5U7Dv
jjBbil+kwnEVUxScKo+QVo85fcdqJ/1OZgPCyKFpNrA46pl2SlsecmF0n7GmJuUzmqxipcFNLpfh
ZFLGj5j8IEygL5W9YMqajRzW5xn8Yo8IizLE5sK2NXmEtpJ10NRWYpeiQHT8AT/SWgWYqwzS5hmE
JrNnxzC8tAVhtFqgJ+0XFlCbb7pz5CBfgYP7uoF9R3vweN0Bpf+85lVacQ3qloRP1EfMzLha5sJt
TaglRN2cljQInv8mgcc0ylMf9NRMKuk1tKgl0BgryRp3iHIb1mNXc6cD+sZdw4LKJsoeJyEvH/o8
1xhjJaRLFTSI4VTNqXS3kJfGb/K8+v/OMCFKWilkiIvUDjfpXi68pfacT3l7dr/vTB7Tr2pKAAGY
iQ+NMiyjMr4CGgOkp2IUb1D3qqM1Z5SSCN/nkOqD0gH71SJp0vVlLIZp0q2EgeUtT/GBM7v+5jtJ
QWRM5Pe+Zla7nuYgSlOjwPecKuuP0ltdYn5PsjAqR38ddN51D2NeoUlXbFwjttpsrRldlLOlr/OL
+v7mo/iMZy3fLp7bO4KD1SAkt9Yw09YecfD9VD9Vt3rdImk8RDb59ywGghy/WsR71QfEcxk6PoDy
mQAXHIM8Ft1yKCNHdgHBdyTBcXhnzTqdOBtevjQz8fVVrmLafj+Qm4pm0XRyJoQfSV59+HAgREAr
sNUPNwak95oOXTn1xldfAKnLk5P3VDn2i/Yo2OydSDZgYdG751cnMUGcWRAYYf0feUpnB6FjzokG
75ZB0HMhep/3ZvzCAFRHtdTIATf+uy7lmuOeIlnEVn23CLFqTjSPbj4AtOyO6HdeftP7Bmx7EQRV
usRplcbxRjJGht57ZgqoTlXfSXz4MiU3SY/oW5VIRTRkJZ7cjVuF2DS7uS0t2a2xMD5yphYeC1qv
1Y6sDxq40NmHprvH8exiwDQ7Nz3Yt2/0g5cDnS/Mpw1qTHhq5/ldHXjPeqnjpuqUqUJHL/jVLu2n
3vrxrqcfEflmIQJ+oRap48AwZE1j3VJKCSUGwJDgAUXQExI/V23H2m==