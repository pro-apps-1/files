<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpgopBQHBJMvR71PbK7sDTFldP1lCIb+f/0BCF6nZafYuAp+Eucdh2SvSEHQ/TrWPKgAmXq9
d6fWCFSvw3XplFE0t3dOa9uM+82b8OfLAs7rvP6tNgxEaOHzuKd+SWSHB9GmtUMzzqUhZDLmURYY
V0fYFc0ZYz1zVUYQhUGDFrNMHnohTZGUT8iX3yZK8/0HzfJBOgfo3qTdV/7evm/AgbZ8OpbqDXZw
N4AM7jIFauLNnnxxoYrlMuj+d6GO8otXmu4LfbRsZL3HKx83E6zV6oB3Cgh+QTurEWYAA+mrE8v1
cJOp2pH6VWpfM/qkHH8Op0icQr4TT+Ikcw4HLVAPubZOv4urtiNsocERTRh9q/b1byZutjPSB41G
YwX6oW2vM5EjhL1O30qKJEe1FGmD1kqkNFSOxsmsYsQLUPAsXnDbPc8elC4Lk+ZzVpWY0ved6/07
wDJr58ZGam+gzaKD9B8woUNSuvhtaUK6EmlD3qSMUsdinl9JFd/f41tM6qw/V5gsjMLK+mHCS/Yo
CVtEA25N56AN9BgGd++41hbjAMd5MmSfUasJa4qJKBfGOFQNLQZ/gSO9HM4Ok2zZasm1DDiVQFLp
O2xUXz4M57G4UkAGYyVxf7ghxdB28ePKcLHTCO2CCA/QTdLq/yexSD9Sut03hLX+9BooPxd4reGS
hjZxsRjh+evU7N7RC8Hw9eI2xC4QFsszp4eGcqnS7fdc3Vbq9mMz5TYTraFhSzADKB4wsYFbXzgN
MhCnQa6Uuzc6xxyUM4Sx280Rf2m0d60xReN/TRP5gboxACG6Rrf6p6KaaaI1FMq72b7qybDw5Mge
qYPDwkO3JliP/sbs3x9dpnPVHL20OMds269U+0Tj6Onq7oPXIMMUOcMI1cylyAsIoEIL1MqHYEnS
I9z21BjZRIG4U26DAwzUGKcJMtWfV4BxTIvfL2ZmOPgJTy7U1a+kJ66eUJVPWOfIaCY+hv5PEwQb
8z1v6cTceYd/GY3HbVF4QQU8HUFGG4+3ISsbY03zj+22/kJWzj0hATBgMRLzFpDqHedrErWBUYwX
7VeLKON/bHifu0Bxodn5LjBuKQktiUIUxK4ugawfs5hCbdWigDIxMH+xlYJ2Z6AyZL5u+XHyKQlK
2P+7401570xDVELrwwzD1NfmjLIg3L7xKSKvtzPrO3vLkO5ptTp7V1ri8eWwiI1iXKigHy2JGMrW
A1zB0uxnMCUrFOpiay7GqJ6xIUQf8RZ8GGvoKIKbA3S1jJVOzTLPsiZGSh3WG0Pg/Bbreb4oPKho
SR9mqddK5qpoi8aZ8LTYGJdQ5BhGMDDDh+iUX4NmsQQS7fWrCF+EBWJd6nepsI9XpAPAyv3TXPBd
7Y4g74VR23uspUtQnRJ5saGUUPtMN8Jei995cSRcwLC45wReG7lqZUoAyllo8hBN8UF8QWrApmAi
vy4ocx9+6/Y0nLgyFirbVnSxM92VYG9M4byN4odCfbNriRpfQA4kLYKpXOMjBe5mEjx9wIgOXq79
hj3YUAxNi8IXZ8kgr53j7Rc/QzAQfvbhv6qZ5qdtk8MF5CMB7RseCrNn6RkcS6tbV1qUcDPZ/e5M
1lNIdIZzM26dOAhVVm23tEJ0Z8e7wp0ZEoeeXIG9e0Ixxqgh/BSz4bLqo2dnrQd0Gkxq5Wm6fY6E
jzdeiKn+2/PV0n6lDgc1/bsv