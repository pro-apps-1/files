<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmQUbqQoCMnfIrm2PRILxpw0sgMK9xteyisNG/BPG4did425Kw9Vgfntj4gAZlzIgKUPw4f0
3jyuvnGjjgj6r4LH9CivTRFdBglu4kbPZluNnoRap8t9H5BDzk6NMiK/6LSNKpI1/RbRU3yuh8Se
V8NGjHr1mN/wgaw0LP/3nNn7PyueN6JFvDgsL5i0cmsXVgRisOPAeF0QH+DVV5DZ5fgqjObMaBZu
1dQlhoMwOxGrjAyWz9C6zIQRd6w01AsFzDoOwDrKlb1g6Cjv1nFo8DJn1qxsRDycf9Z6RwtZAhkX
YcDOIL21Qc1vLiu+Irkv4lXud1w5yrf9bq88fbDMx7zRLsmWmXPcihEtywggb/KFMNLs+Y/75ec4
p+iogPaFTikfki3h5cs2wwYJuZIhcCjyd9OzReaGEgw+z++mg4LOvYcVlMfhYqKe78qRVfFRyOYy
T88kWl6WS5I4bA+a4W0MwPvFoACXUC71Fc+sQrYV5JPgTOBIEuOASp0vIopLJuXrCCMUIMIe1PhI
a7d+9nFxzwhdxgLSzkesSK00jVkToOMwp40FEPquElaJssXRyrSj3joHZi5+eJX+xAeq/AyCjTZR
iLo7y0nmp3Kpl41quLTKlW9IBY66+rJ8nHFUdbLqyBngnvDGv3U/g6UNVJvGLCr9n9+8GmkUaU+L
JKkJb5ibNdO/XU0GP0ra7M+uiRpeVYEc0pDsuRVtvLGbDiOWl6YtLgciXuFJhdW3TPkFYFjlStdQ
hNJS4NNRFVTb1/Nn1TOCOEfay2dMgej6JVwNiaekyGETJNPjjyLB8HXi83Ya/hCvfLawaFGRRu7L
YL8oKezZcrguINq69kSoWumonoO1ERrB20RLea8uKy89lpRLUyoECSMwJtM8Iqfb/5/2ys+gBvy7
7nOhDBJEJbF1PNrP6paLYpHF4Wec88ss7SQiPpCC4bpnbo4JV90h3nfQiVGRCxAnkjdFHl/h1I6o
Qa6IcuUGwVVDaHx/Y6h7BN9Gmm6MaaadZXiUj2AkGTtaqTist7FqSzBICuSIhnLiD4kbjb/or1TV
0KDKfadIiFa3CErevyO+NMDA/ycWWEVMJkGvk1PfMRAU+HZa4q8G6E7Ty96xNex/jevkoB6yJJX+
Kwo3jWQo3M4E2/q9wdznNpTb2jESH3cL6L7FvNbp94pGKY7y798npku3ZFgtT3+vxH1hfjf4tFSc
yDDRmtnKFuzKZ7Cgz+q9ms6lJoegkV86BViPY1Myqbm3PIY3UskerQXDYvVeWDYxSb2opFUODiQ4
PFJWNw/1fsdo7JNVJcM+OZJLtUeJ/KhBMCPBr+mDVO2J3gCRB10Z5//zY2sIkN6GN2fTEtYGfOog
8oni0y1/MjQrO9KYK0K4LriC273T1q5EsxZI9gKWCY0UHkmwkWgS00zhae2qMHDtyqfe/LaL9SMM
LPvtlu6gxOqmFWgYQwkcA8Y+QuOBKu6m4qM9HWvzlfS37O8iCw3yOfH9xtVy/M7htlXDBkHmh1Hn
QUaUJ/7EAbVtROef73F7G8j9WDVifH7IhBbEedBUC3ihwfLUSknuTEHKd2WXZsi9K5/Lxns/rhTj
+q71EP1rzCwKdClZIcHpys6ocL5gZp2jSxk9kDKljnaKHQO/a/1OmXHWSZ7+PGh665sFDvt8GG4l
242yGeA+wCLAhYOu2cl1G0MFZeW9Kx+i8/z3Sza=