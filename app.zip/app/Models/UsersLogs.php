<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmg8k4gqHm5jGKejQHyK4PpbUO7vvH2dxeUu2iHIVO6t2s1GxGeIEHgBvhPRqmbGzJPFfxE7
e8RyGgzIhq7UGGwwY+X3u4YKmuG2vEskDsCUQsWF2G3feOOHXYaiREmGJyv8YHfyGYXJ5f0k7jtg
dEgoy3PzQUxwczuNFS+XdAMQLPdwzasbJ488pnBG9yWoKbApf5Fo8M7aI+9uTFKwq/nV/K4Y+SUA
JsxXNyBjwx3wh3QjHkQQr6YX5uLFuys5Wn5Pyh6F55dCubCN2OI5/+0cyfvf9JfsK9OFuAsNGaNt
st9H/wRA7N1v78T4iQISQXuu9ZjuzVIspQ99dY4jklVO2QVxUDFpPbusvSMuAmbJ8WEcITw045B8
sz8xsPh54jbfkmvsh2ghpYb2htmHnHFwfA2BR+2UKybOOE47lWCeH/PKsrAXZdpP26emnA5Ntd4s
TWosUr7inrVFnN0/a5zSRfqbOPLwGaNk+wb+U3bQnMCU5wA80p7clU1b17CazFbtbTz9vcOV9cfj
mZzQGNAa+LJ+buqGv7DD3RBFiUP22X5RlfwSlQB0N3ytLc7NfH7CbGA0NuPvYyLNd52wS3TreL0Y
esdzbXG0FwtpHGmO/btX/vfoiulEnM43q9fTpZ1/EnO/vESMQJ9bPSTkaNMpBe33Ug3Ni6YutaIA
pPrbMgoaxVyaHfvrUOtnWX1Yd9eBHcn+ItJjOirJVLfmPMktkswDbYCslqcbHhMJbe/PKkqldGDy
2hPoOEr/95BF3zECLD5yK6D/VoCzdGxgGsrrTIHGkYEvy7SUblscfJgDe2uafplvpFhmCVZPmWJx
iXlVXkgMTh49Z+zuaRSpIe70diOP1W29AP/ocIeLWbple34RWgNwTQrpLuE8KjYqIBoOi5mb7Iug
T8KAjqVJFKT2aaOcN+pCAs3rVvUO5+tEjXVlWkPl/7BjRz2LGyvs5dUrdVJqFHTRr/wSAJDV1yl5
+CEv1Dr9I/zi5Kv+uYPRLj9W17vLWzRz2Qpf4hAf//SEwdN78KbJw+lWDWbs+CkQr9DXTZqwIG0V
/9jxjsCpygzmr/pjVErR4wn/5yW818UFycDiTcE++CBV8vt5qCBCPcfhwNQZ4EKZQ5Cxwa0vElL/
QaXP5H+i4IzFfQql14Kjj5l4oxUeO0yqf0hFWh4aC4WWXxA66w+JybIKfjdJ7Zd+qP1YIXKdWpxe
3jbGSkeYjbix17O/BB70mETON0Uls6s3z03R/WGihU2v1ocZBIfwGWvopeR/z/0Y43ZTu02VPNgc
ILJUmRGJ0IW50JxjOKn7OLqW4Pka3/oe6YbQ6eV/oWUvLMmaqtodexOutMFsDMFCAGifFSdFHNrE
4lZh69BTIt1xIfprh9HOTR8fb+Zh+mfANCAvoB5rFQvcIAYgLyHBgCaF4uJXaVtz297a2HaQ1z0v
wBFn1EP9+wOsp6d6tm4H1ikZtdJA29fVnC4cunt08K370UUvBXnz4Olv+FXBoSZ3NONrbOQ/2k3y
QKSErOFvnrngNLSYC2QeRDX5ZInPsaDgeQXm9+sL+ut3Rc3Kg/I8fR23ni3fzl7FmSc6Ary8gnRl
ICI2VHSAmkw9lu+EAgvlinY2hwQ4K2CEcZQ4nZD5Z1sOiqY+ioY3IcSS0BiHHuIuchs+tgUmgXj2
DPVMEgRWTe03nFIWr2iB8DhO9mDrRE08I0sqimoqjm==