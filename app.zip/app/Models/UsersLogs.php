<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsuieJ13e1a76kuq4szzz7xwAM4LudKGg/QAjakqbs0LSIauOqdfpxYaCH+zYsuWJnG6i24z
9wyj8zAeY6Rc2g+28VpG2im1wmVjv5YmUS5maFJHBfbel1Qm8zNafkxTLOV28uDEcRm0HOdN/sj1
UZZ+QNFr3957CJlim0CeFhm5QcRMy1l0xxRWHx1gAwU8Ti+bhT1p3Q991zodri2e2fF+CVskdYr7
Atjru9VEyCygqT1tYi9t03k9a6+y0ahIzfjAO1+MgeT25D+EjpKkAQLjijMrQ2hZKfocquYnTq7k
3gZe4l/q7RNv6UnAf/bqoyl0EgF6Ap9tj2E1VxZy7YmeOCmzasB6xnlclqymfvtF4xO4Y7qPJ/mW
uclNmZJDvIy9TyFKfDpqvPDFd8iA1InKTCTQT3GMpcoaFMXeB3UvsYY2VhT6sX9uvD5eNDgCbD9V
UHVvGigXx7brwLyXbF9IwsdB7/xFDZ7tACJjRN8MvCiBX50vQcf+r34s3l2nPuY2speAAT2SqG+h
/Rjn1HGKec5YpcXxEemgvE+oFhgOp5HESb19MYyjCn74pa7G+KmTovrme/PNaJCMoRa4NxOrwpH1
TiY9w6G4M++Tp+rGXR5vFdbNkPLsrwva6ub0eziHGAfi/nsCxg/3kbgqNNyiV0Lt7OdifYYyLc0b
maOQWlV6pyPJUuCoto85HVm/+sZstG3VGxYE/ZGl4gFHACssfePVl2O98R6RxKeZLI+R9oSViOEr
vI2RgTOpfSO1W7qq2gWUUbuBrENm83ZtMdT7KXcRFs3Z0YOVufLltiihCoFMA8IntPLFmqqUA4W0
wOEpwD+DaGIBi8Dk05XpvWxBWPtzyC5Gd8IlKNhTengSuCMXQqwYtJktoJUd4d9iLWj3VD5apfdZ
Mmi5BoKZgiorc3utoE9Jldf3UnA5Fjb7Z4TBmeIgS9A13AkwL+QcRtmxkKijXE/GXm341s+gYhX0
pZxfrodOFrA44OUQh6nYISjwToZR1aw1MxdM+7jvSZc9riRI80iXQdbEAVr4AKyHmYPdHsMdzRRl
vpwcdtqoAcOE/sRhy25dmhURhyvMYk1iWlSODSe/fLKA/OmUn8yuh82U8blKBNIgExpz/5l0tkIy
mPCdEmrIWDCo8Erj6DcIUkybKYUg2XmQ0kDeLf04Ositr/Qr+itLBocwbpOBQsm/FzRCXjD1RbpT
mPRlywkMEM/dQhgsqkAkcr05916POAN7uk2/ZUZVa5DY+p+WeAu7zZWm/+abAiq7k9i9YIuX33qU
x9xB+mN1iY869851LndXKeG+2bm52s9p8RpdoCIu/2BUkS+zvXJ+VD3z92YGH0N1C/jcsqRdtclr
Rqs5X5sPUsvBm8agy68n4Sx6T3B6IRaE+m6clf6RMaNj1c8j8sm4jAkCn3BMJqV7nHOoSgi/sKcU
/BXMs5HeQLaY0BKLgS5x1qfw/rTaA+aAiutaCYh/sW6QGVuTr4NrvKbPzarw6QHM4vleFrlcDu/V
5qjXvUGBFnZFr6lMrkIMOv4bBgnCLMMJylsnAI5k3cMm3FySs7mYa9hA0qhPLgKvmaeEN1u0+U6g
6qBs3RS8FyHunZOUGPgePZBO+a/Xd2bV0sO0H9yoKYgWNU0s+s3nRHbTp3UCnAW0airvXnmpBf1A
eFxVIIO5Y/qU+lwGBQAXcvTN763DHjzDBo3+MG4WGWP9GWZ53D2bRsLl38Hl3OIm20r6tG==