<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/szEYEW4vyKlN+l09PfJe6x7FXz+Dmn1BwumV1tX7H0bs2MMv913f4hWgRvNZW8LO7qGwfj
K08ZBaDEuXZ5QNFqWP5JzRWO3tPLUWP5DC/tkfyuUUaF4tpORUOiaZcO3fn4YvwlJdsXBB/Mf2+i
jLsF4uw01Ptxbvl/PEuuJ0Na8FzDrLhgSSnJkrmiM0JTsN7LXzavgZ5nQa3GotVCj96VCWoRGGPT
7zq1NoVQ6OwUkZ4GlJhkZls3iODLOyq+B05pWFm/shcxgvYq+RWdSfyMUujcPgjCZPDh0ZoTN2lB
qhXREtTkfB5EtMSStOI7jP2Ff/nhT9xBXQhAiGD0i10CS13jcHFw+JSCnHvzskKXCaEqLjZJmGlC
TJuSguiY8m4AWnyW7UFORsqznbzot9XpQJIjh6ieyIONWzymWfm29sXPWArMFho5kaofraOxDA3U
KJwWqC3p0oEZrKv8/OibZhP6TfCnbKrjiFfZQLQdrMbnez8PXSq/l1L7J1/mXPDDo3ZjbkbhPU1l
OZ5vcnd62z3/0Re2Q8d4L2+xk7+wzuww0FURlr5khhWB+sbg/2+XheI9UrIXk7HsgHZEwF+Be7nG
llrQDW1AW27J60f6N7nt5wF+0PV+XyCzwXdx4OXf+p3tdqcOrO9hvyZbNtVQ59E+aFt9ArpdKi74
hWL0cs36B8GsALKThdvqZVT5R2Wko/voT1QcicOYAKsROfKUMFrZBdxtkwDteKgiy/Ad8XaNAv+R
+Or0erkbEy5MBa1k2jPuiZYT+S/emM7N+1PDNMhAWaeW8F6HMlD0+3YIA8SX9LyGcf+DHuSsXnX6
PnscriHpyZcRf++khQIp4kNkQ5FfTcPfIGyxFkIIif3m/LrK3m0ZZS0KY4PokL3GqWqzHtQZb+hU
kVZwCk+FA4P14RxU31a5pQecP2/ZQZkQa4jjXiPDaxoTYiHbCEmcW76P1hpo+WXOnD865uUfMGVV
ahPNSSlW6zhRDgXck62TxSyeGT7eM8H/4CQgeYGXoytZpADqZyB7SJINoVDRPBJR2QazX7sH4Za3
1Nei+2jOljqj8h/UhxUTxBn2A7MflXTjMqhRY2aUlHm6yn5Vw0eoMsytJHWAHLirbneo/x+NWZKe
3Wj9+GjiVOI6hufc1DNlv5Y/xKQHlWd5BliLhlpe73OMgr4GA+uKKbl9VDj7p5z3bakdiKn2Nfo0
vaeWMeCAz/+LMEJ49e57dB3PGZ0nuVE+N2TOobq/dLa346wsKar6UWRoxtncab6VWkgikMP/jNGe
t9T89AKx7Cc01b3dQHFXy/nCOBDkVboR1lwjTbQzL5vQaTA5q1UJmSQTNtEnzbqkAaI0YsDaVVxz
9BmDrRINlI9xGPLidA7/43YKuVrS1pabgrP9ZItQEUfrNktmGby464pVyvmXVMu8Nln7NH8ex4ux
Nf0sypS/y7YM8rQpfJ0jVJV3AStL+dYqXl2uD4IfmwzmlEggwcMlzhNRS+HBPkVHddQDN2e7QjAw
/W5Q4Bm0QcU4QN5+OK9i4O7FsgZ7JYPf8m774Xdh16/ZeguptH9T/joZ9yjzaYw1ZQO9ISksFHKZ
ErlTnGN4Oc2a0RkZOI+Dpe8CyDhnhArz+oiv4qx7hxWGdisaQKUliHi0xSSDRGT7Mx0cSJuJZNAX
WcchDa43iqH0D8fxvwUs7adihf1VaRUQ1Wd5eBBu5DiXoTcWOGdGem==