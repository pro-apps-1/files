<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmJcczswUM0IGoGE/cefx6URt2maqr4U+uouwuxBUl5qDjYIwqWCYhgdG8Kla+Nw2ZMmZmhn
80ZMzfnyjGlvPx3ZUuUxU8+VpckcUh8paxCfwJMw1VexDdnDTHbu/0PBETFmRO+0fecy8p6pyX5M
x5T4QXRD6pEPh3Rg9uh+ddTLNsXk48b98p96IfSxw15JWw3P+sk3PC7OptRWgvYiiZv5yyAPjurB
7zhDrXlbas57HA1o934gqLu+BeXjSgmRznRx7nWRo2Rxs85Hakb8U5GQAtDeK/wQ203C9mxAPSAz
LtyQCDM16Gv+FJjvwBXztgZBeTS+OLsGxC+ididzNbqYl4zCd00TE8DGrl+wAnh+hIJtXPhDUSx/
v65G+LqFN/blKFlgj1ktfu4Ao5xR0fb9fpB8GMlsa8JbY/THFKiA6mGSEcd+dUGrK5tRQaU59A7N
yPa9VEiHokp3kBwotFLXrRRBz6WrAB5LjBoDWy3fk7f593DHuNVqhBW5hFL/tXv2NQgLwCw88eLh
fBetaj624E+AsFxAsYepmIm6y4vqub15TqbKoPgpO3V0tC+dPdY2Z5mtXYOGfCcPgEyFXm/sdcSo
bHwiod+LI/tXdFWfOHYQcqI+r8p2t6gPQDm4DtYYNCW241Q0qMEECIptvXd5/R64woaL33w5CMtR
LpT4tWiSDLhAtQ7b8dUgsmSE5iEqKF1U83us3qW0JqTcaD2253im9vj9eJ9mcwltxtHUKAe5Qap6
EqB1eaFCaILNc8a9EdmLFHKZwEaRpM4XCabjrn6s+30CZX01ARfW8GKT9Aw4HOdOuQcMf45+wV46
qjxDAqB0SrHYwVeiPr9jR1nMyHnbluNLObeKGe2iJbmXCt5xJLlxBuEhvuV4UH8OrShVaqF/1v6s
WTM20jXBUO6jj6J3mZBp1y19MDwDzItWrIP1ljWoB6FxN71gVhh65tmhRNiL3O+lYKxHbCmJJbPq
A5OiePfL3kn0G/yraNoyU/vUZfzh8uMnkhRfIn2+gruL2u553s2Bi4wlCopEyqu8Jfnm/90gBPbZ
iZY4G3rVz3D2aAzfvrSYM8VMYpiLGmJLP91tRsX1HNY5nNSk+buktE970wAc0BTohE0ASX55etD1
DpBFZDxl6M83S+5a+aDsqFWYipZqC6QNGArLwatPoudPJS4fELAM4WNP+rFTWdnZAjqCbDq4o/sL
Ls8LlgbjynnteeNSwu666IIAYGR+uCl5BHqlUdJcHs5xiyKIQLsPerb1UdH+XL4f6WlfLD+sL03i
ZPfJPD1FJ58HqjxePJZhwOez8emt4lX0/LU/zztM3uQoMnfID2nGPOOpHhYRVRhMv4sn0erGMSlN
Y3alTn/6CxpqmWtu6oJicqLKs1Wl8dQ2VN3chONAobZF/tLTu//3bg+4VMOJyoyn14j2KC0G4gyO
KSmLRvZ23FVds0NxuQ7lR+MmRO1hudxxLc0oaC4ecPCLaKufmtn/HYRQZ9I/IdhwUyAvhcYVP/h1
kBVsjtJeyec77JbZQxxaliKO3ipQw/LVl1CJPboLK9RwwDZwPfKpODi8T3u/o01+Isp5fkm9LEs2
yHls6DXK/HSV1IGa02HR3nb9m3OJMez1RP9Axcva0lArZvW308qWrEySW+XXnlp/rIPUUwflNC5o
8Ll+HNFE76BBc0gNZ1aFOcdr7A+FJqg7P3A6KK8tkH06e+m=