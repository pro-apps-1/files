<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoxjHPsEOhxILo/GlbW79ncnwMCnxS7m9xEubacTjHZQNJreL9gmYxiY2DuSjISsiseORxcN
T6qBANmJE6OXsNfrXfkrdtvugODk+6M5IYa9czi3/x2L9Nzh3cZbGaa3aMs85qoHk9AxbtXdDP4U
eHJ4XRi24rS3pGSgCbCzCLnoj40hIlEX9j9x+ljP1G9g2FrzAsw7j/4XA+qu3lGm8xcCf7ADjYY/
el0Gsvo6qqImKuXkucbAb7CP31oVDs9uhorGgTMs0bR9yaI/G9MPSJsk0XTWBTeMFwGD2R2rAbu+
rvDjGzKkc62L8yUCT4jBSxRBtwQMO5k2MQIfErkzxI/5NXsxI4Y6LE9mht+ZLn2BN3H5Tv4tG6Bs
O/7XR9k9M537rs9T/7YDrNuAzLFcuTmLjPz/bvuWKWXRVAI00QqUc993RNkudLGR6vWbCK4Bf+dG
H1ijGz6IpLxkejbF17lfQg6d3NJUo8lRIg0bebGtZAUnlgcabJGIKY7cmCOFd4OBXNuGawzjBB6z
Xe4tFt1qfdrPmdv2fjTiZ4Y04kbrWrG/VcjzAA+iq4c0QlL6UBnIWNlfwJQYEZZMKlxxCrYDgJWU
e+dhSEgN45QIei3zGQNZplaLrYYh7nVhg9z/N9Cjc7GB3BJDz6fK67dGWilZppDjc1dK5bIhuKYT
Ka0FamdXna1xsNnT8SZKI1UFjky7K+Ph7wgvxZUaUj+xm8sZ1RHbD7jQUTW77JV5msXysUqwvY/I
LiZd4q4I26T92AuI5/T29Am12RJLPo+NmqKrqVY0FVF1DeiTsg1gOXA+pfF3JYugrhTXXIcqCrrP
3mVvaqf35Ha00hJ2Em9LsRtkT5c2akdIiZizefX7G0aRZirOZYSf12k8T0s95JbTP/upYZMkXi40
aVyi3C7P2zWUquVPPh6Xu+w/n2qHhwrpRbAxKhGHyAto1jGEIycwKxDsBag4TORrU94k27j2DndN
Sx7qyGWHnwz1PvtAQZap21E0xnO2qHrgOJIP0Y4b3SZtqJcBiBC2nb3KgmdSVu6ai3MaZdh+TKc6
xx/m2r22hqKCC3vPJT3Qi0Wm+uuiXRa/qDdYwT/+f4bcbnHDoAkJnsq6gXC6HY6bY9tP8Ddzp1si
TyqsFGch6JyE/ftsPB/r5UlFD/KUESXY35zMmwcL9zaZ3HQbxd73whqCpKO8ItcU04Euqsk34zWi
H+4klD577DtRipciTNWioJAoT6xiH1DcWWdMjN41zzL76IeCVjoInbIqYMiCpr7Ay8aFDsM3O1Tt
KlZSjeGYG8e89UckrrT1rLHpT2WxG+xjo5YDSP1MTd1YNmwYBPu6jjO+nbDdwDGt/V9NuqcRIdV/
IlvUgkbT/oUXHqAOacZ4qNCCGqoXBJlhXBM61bEb49ks8yQ3atVFyrgNnwQnnrsKDlE7DIjRqxRk
JGLj7mStROe9a3Dl6y16iIFFAOU3gOO5BKm5hPD0sFjRECsGhUSb+UsuY7w5xwmBklOHX4yA0Ugs
Oq5wY75oDAYNHRC+l8oaXbRl5rOhROxPtSXch396sXi21YCBricIzRTaVJikDs2m3eYy1OS2ygNn
zXLrPgjR9IYgin8zUY+dCLoaXUObrQwkkDtnVwEn/xLhIUU1xHdXi89GR5KduDwybmqmtDje6Dzp
UTixrdQzT7Bg0MteBv2UCeqvpg1Z0u48mE8zdfSLLX1jebG8r8/PkkWTq5IeH0c5Im==