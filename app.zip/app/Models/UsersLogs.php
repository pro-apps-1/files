<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrD7xWbE6TCk5uLxAZ13QlnzO4y7C5rCKyT5oUMkcXXC82OURj4sCY4cT3EBU/TFNa8OogzD
tuHah61hBjXuM5xTCyprOwvZ0Utp6XoAUH7ej/TcjaMxwIKN4I4KWLWDn4Kff2o5l1Y42IzbrBU+
YrLjsfIb8eHtVAHjsRj3KXKajwmXB+cTUiAoxWFKdLJVd9T96R0Vr0ht+kNV8Lf+7FJ45szF6mQ/
BE6/vO6BXf3Ta5dw3ErypEy76OYQGB+HeI1ZMAb0+uVch2gfj1sWzQ18q+ImZMKPQ3lG9kxEjqAv
/T9iS62fsK/NJj2jEFwHHVVeZElO33kgl+Pv07jgK++A8ACTCk4ECvyNK53KGmOMeYFEv2lIxRwO
INOVYScBn7kdWUaD5/D3ceGbvFra3TsyNrREfSTiaP1xUdFLh7JrYUYbB71j68CNC5A7iCaNg8CL
94Rw3cHTyj+J1eBslpMUsQiD17Xq+3SLgH3lQNRbfOxQieoCeu27rO2x9B9kaoLJzMCvs/Eez3wH
fWkvr81eNLMuEEYZkMoqNCu9KPOU8fYn9JZcgJbfABu+sVj85vhqiG3OpB2Wj3Y/d+Q5on0Az+lH
LFST6/OlU0qhcIyBiIGznS122KRAmSddcLEt3ANDWWkNpqjqRVyfvACZJVBdPwBnqZYjpGbp5vZY
2XFZZn3t0CKMhmbf54aP9a9Qbe/bIriOkPkkj29gYkkJpM3lhRwgGXhDtHYwWHf8EDfDrrWgescg
4G5U8LuNIv0Lss5pvHjYHhsjltEhaUlq5/oAdKEylSNQ6mPPHBVtB9A/eAz2nNP2ik/l/qHoe/BH
3L670VXlaKLSjtdCXY9ld0AcR4Yju1XA/Qp59s7Or3DF1VZ0mb1nncPFCZjqS8CImqoimLQ4jIfq
ZIPZoHbRqanRZASTkHJSfW7LuB7tbRw1JqEknu1n3CA/+LawKMvnMrh/9ObU/oHlDSpz9Atx/Eni
xgjf5KaLS1uq/+YNpSMUpqurQyrYi7CWBvXiAnpLbFQteWrpcIJjpNvcDZ4xg+L/K0VEwtgwV3db
s5Ml2DL0fh5YIBCUO4qxSv1Slwyn9kdP4y9sV3Qc34SsdyNzQDcBpoiTPiuQQQ20DB6jOAxfx7+D
rmTFsjiiuTHmQlMSTi9aYDbeu5r45MUR+YeHxigf13SeX2s10ulMvYrttLakMy90Y5j1AZtJoPHZ
ovbugfk/WDSnDf0MsaRBLdzgkw3tCZzCJyoN1SyuAE4graYWIhxD1np+ojN+yPFFn1uecQD2Itdo
U8lkOv+qE6TU81+P2c/u4QpTxSjZm3Crwus1PTvB3O1YxYdSosAGYFM+7J/anGHXlD2T/+5CGUis
qk+1y5bmHPA6yT/CiEUE55s/OvZUXq9JxBf0N5yQBmWHA6lIVClKP07Ew1oOySJgLp9wkg2lq2sT
ZsZXCq8SKnd46TicBd2Bf6SkaQT5idKo8qF/o6WzqUbnnADUU7fWY9AJJgqf0WlCO1jOAyk0mb8C
hmlJpIte6qnK/PHLWk8HRaQlKGO24obhBpXkPHwMghdppvEF0BqStXO8k7rXcPa6EotO0/ZaerxG
VgD+/dbUJdc+iocmZ5d/9+nERqzMbtxRrjlRZfcVo38/cRVAn1q2Ege7TdZNEhfeojHtB/pRI9so
1t0CtXIg7x5jJ5o8315T6hIsMYrz6WRx+MgGcNjB+wA84Yew