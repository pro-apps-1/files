<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsHcaUVwrcd8Wxm4n8M9k/xDCgVjUjaY0eIu0mpZSczlKtXqW8TfaBBfzikbEfpYk0t6HLhy
LzgRDQ3FMKdOPITMb40YDDoHYOHooNX9ubSB8/ikJZ3UhxWZThbNpB4iC7PoKnaz2X/t0FS/sQwn
rC8kc3uHcnEunZimYFr1Axv07nBjODpiTJRvDmyzYMX0kSBcARo6Iv6UuM5EiFOSqcHfd5V5uz9o
m1PMUpjYRkAVK0eV+H5OqI8Y6t/cPaF1jFgRGFk7vgmggRGTeFMWIDFai3zhwso6s2o4GUcS8VtI
Rt0RmzHPCWgpJc0C91SfH7okJiB65M7Y+kFLWUJ8B6SHGuuCTaYBtxlAmEGfpajAKvITTSEplHKk
PSAK7MW8kkBTuncIbkfdDMC5fPqBzXKCMboHJyeJxV9mw0jUEkLCZC4rQQnSc0TY2VGbg+GrGdsd
bedVTgUMftCeHUlG6LM6JIzR94cG0O+vhorj089HoAxW8BiUb0YpYiYRk/26IHWPDqBDFjeB2i6X
9ss4IXyKFL+P6+K8lHoGhnd80F8kdkRyjT+xNviP7IbA8JMM8Os72E8IsjrxgeAI+4b7t0M5vXph
HG/S5ThrZVtcWWbIxC/1Y9t27H54N5OcurubzRAyQRsaE8aZzoaJdHtZt5rmK2Xf+Oe/DnWIzU/f
YOds0nQwkizeeBeIgvvzNhPkdStmYCDMGo17WsSs4nSPDtvsyLysZ2RV4F5epKwc6gEMmY30GFGt
5TLTSdvec0vVhb+P0jAf9VWDgva2PIegCBnp3SI73Bl55fPepuyHSXThD5oAEh/7zRJ1kfDELal7
GfTByyWF5vkwwsmR8wJpWoResDHsWAyR2p8Hd1OwLO/vX2eDOYxi3d1evUTcY/PAGFsEzQQKbffh
V6rfpazrgpxe5H5dERH1+hcNvmxcQW2NsyjQSNRmnPP/y9/xjcQWvQtQurRntkjvGe0XnCg3tQiF
WD/CqNxZymf4rFcAE9Kfu1rSM/zv+ysKr8eRNsfOYLcFALVsZZyxuPBWDnzmhbQIML/34CTUAEv+
hgYKpQ9UzkpLX7UMPZ9+faP6LDlLoUkpoGyKvNhRywKIV+oUGOtD2GxznRpjuCeVV1DwmauGpGCK
0fC5JjNjXgjnyJ7fjKZqHn9nAB0wHxvT68QK2+WYX9oAcqZy6Bao12MMVfyxZozeypFknvcynJ+0
NB579KrbBaz7XlL52eJ7GG/RWh0UyNxO6RiuXVkm1kFFI5ZERW2c4qPGDC2v7zMQYFSJ45BykkuE
JZiUcW/lHEYQ3RbmhSeQaLXosEOIOALIzNhv2D7a16xBlm1EW6SVKl3QhGKvg4HtCcw+JcNcVKeo
24NplCcItjVbOq8DXzSI4slHivUPkoUFv5N8z0oSY7DnuTYlsJDZhZ3pboXJp3Edprve6iIZ4QgA
yFw9I2FkPDp8YuSt5TUAQKiJ1+yzX3u54l7C8d5tK5559nCJRoC1RBwoGb8gKdtyOx8aU/JiMbyF
s1R2D5eYhZKD/CUhCErmOfN5b0CVGylmMM513NyTUi144B5d1FEKlJV3YX7HC1FNvZJSL30XzJPs
/MQaOpNLZom3DI5E4dl9NMIVwi24dCR4VwR+A7t03j0ORgnAMMby2EoWNzeH3jpkh4oP0t+NOgds
6vd9oeFvKM/M62qk1myLFJfaxJspIXKiwJ83vBtFWlFoBj4wC1DuacEOHFNi4WmkQqFyK1A/suyL
RHAxfHUBEi3yFg6LLLBIIIqVC2f24ha0kKKFiNdxksrLGotcyK1NYnO47rSMg1UolffVrFkxsOBu
o8XJq+YktWJeZVzVxA9y0iOISHRklD91OR6gd6+bMwcrhmTJlqevlWNqjYYkQ8WtoUP2o8NuyqaU
omvtxIJveynnKjk92HwetmVuFl9UMV4BEDmpNGYkege37t+QPZwfiP1nBO8FBLQqPMlUNsSREvmZ
Xg3LzpiNTmNJ8JR6dQQWnFNiZFtase2tYyPuV6clf5cY4GBmDozSGub4/WV4q0Dffe5lOa4T1tt4
qRa2siRr3u2Z7JRKno7MVp9BttRADAziPbYzbHd5rqRfX/2ezVBpCsyBnr286qDYq3/7LuAxY5Y/
y7aWyxEskFoWLQkkoFpCgG0HPx7GhAnpyX81XQWskCHzjos7RQGs7TgphiA0LsTqzUR6++ILMeSG
UH7+zLoqbREcXOTEUu6iIOgdwjQOU9WiQAmY9ZBgksIlJT/tnvGxjwgaRQC8zkXKtR3HLKnZDHZf
AT5Jbhi+mY3ufaC9YdXV9QjDCqe3iNZ2y/7Y+A+RKvDfIzi4wFot7RwJJRVIbaUGGMCd0ENkOrpd
np8WwbzGeulg8/vUsDrg21Z1n5+HOLUsGbsB03KNFwBCswJWVMrLRKgd6XvXQFDtotUcws+adOux
NXvPvTtWR+4E++MDGus4aMFO1Gz2GdGzc+Au6v5M/uwM6ObjlPUkBhy5WvAKlAgDd+6zQ0rZNZuw
JXc6M9HKLgBd8xLoSQul3VujzEbOZ9CAcgj6W7pmC0hNVGlNRQnQSXIXwuA5Xns1y+yP59LwxxYK
+zhudayIlne/v/mj76wdZiDB0NwHaD33rmpVUFj1c5iRjJZPyIDN27lza5H8yIRgDGlBOm0NA+R6
rWK/juwsfyB2Lk8UDsLJw+VX/6Xmx4H5TeGo+Q4HKf6iKQIuIVH6AQfThG1YxSVHaJCGiqA6M+ar
oHI+S4x/Tw/4QiWqT8Vt0ScwSG/ryBL+uR9NIi8INS8swYK0Ptspa/epp1Kvcm9CsJK+eFRi/EQF
w0N7YgnoKvjwWzjDdWf2NvQ72k4xVEhGHy3EeCP9/ymwlq8dm7LYwIx9JONXu7JDrHj8Fk3HnYo3
Zzpl6ILD4LfvoRcKZkI3gNdTo/BRlqame21Tm4f1BoB0FRPitUlcWhWMHOAylj6Kqx47AxnPYyLp
Z4gKzhFqhdjuLvApJiUbqBw2znAS0ARiCAmjQKcBMWyPfL6Tp/4fitFNmHahmlV6AnRxTMLjBc7w
CFznYkgnFsWFQZSk+Vtt/vYP133Mxv51nbXq5w/t58zySma49FgQKLYxcjcJ9HKfzZfgz3b8Wqqv
QD9juZvDHN93V0C/lBzKv0ue23NNg+xpOCHV14FwuTILRqZBoReg+vWET/y5vRnw0VW0RwnS6lDu
PLnwU2XhQAga7fgjhHdxIL6GRnV3uRCSl8ZxoBpEKtg9V7P9YLSD9FXjqdblffmoGl5zaD9TzMol
My6nqOEkgMdQ8JIuX3t4/Mn89+bXiQZKvod9YhEoVX37kj4RRT02C6M3D+tysYRHVyQcILdvMP2G
e/eUJfQ3WRLrmXt7RD2O+ERAYfrUjMzIchYOgsUugM65jshL3mF543cWIN7leJdvHgilYf4W4c5Y
X55CfipirDaJut0DSOGnQdnFHf/fWZLcmstPzeIOptc3c2rxyo70LhkFxtNpP5zm5KQHwrGEa+E6
J2jnMHNNLdT7/awsWjCC2YG82gOmdWNRGdiWTTTpdNU+EwzqKUCUu3Te6/JQIXJR2dSB2q52mJPk
y/yQY9tBuZEv8O+TZTy+N0nD8sIjbZqJGY+jrWae5dP2m7MEylylXdbNOSodGWomR/kEKzUJHn4r
d4QBdHrt9XdhSN7eisLKhJitqdByv/jW+XGPLcSB31TDX+7JDAudTB/WrSBcNGASrDL0di4HC1a1
a8PAS3utEaLUipNlav5oHbUvTA7uNwtlxv2WYPn8XlagGrJhMOdPH0cKQfAeatOuQbyoVXiAnRCF
nD8kaFgDH5Y0rPqrBCOUHcMLSGeS519ideRSj3N+ojw6bmcm47rv3DNE9xC7fYsMTGkMjG2dvUMh
wI+t2plycUDjotpWjjH8tQYjNnw4YJ7Q5rzSw/tyfo/3alKQ0jsYtadeMNLYHTI98b/Sj6LjHEkj
kn5u9+NgXJ2FNtQONSTbgocQl9x65BR61w6ApRMI81ntLndwwBsSAT2CkQU+ShuN+bEqr48u8ueb
emmm9TJv2D0Apl8ZIbPpw3vlQkBVkSf6egx1YEZFY+GdBtTynuYBOehULwclq5Ym97GTmCauwy+f
pTwAjMy5Zm8bnFwwjXbG0gJf+w4V8Go5QeFOJ9/gkpyER2slMgT6j8p+cKRIQ7GREsttAYEe7Vmr
CepIR4jwURl8162SLkbm47v6dI2ugYBditnfPoVSN95pmooWPeP53FMa7DZqxD5guOShFi13EA+l
fdzCpmsjwyd6pChcI4/4lMw3uPMLGcMrS0jYmwvTTPeo2ZIhOzXkk8DMxATUv/+g2G==