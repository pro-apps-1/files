<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwCvkec3onwkMjOlga3akIn02vfiOUJz3u6uGcOeE/ZQzbN0NjZisjikOr7/c24D3yHbQ+os
3rJojsYtqrcTCLtjeEgsjceQToL/eAMoq5ua9AnZ8Yp6HiD9+ilLuNM1X/AFz/6QGg56eN3b1fN2
veap+q91RR+XOa2WCkzNEA/jycrollshweehh7OWIRW0a+Bo7GrbuAClq4P+S8UiE+xeP2hGGGsU
DkyfskiUQTbGetFGW0tn3C84jleg19SPfystfBZeLxUYiG0Ruwqfsmxzax5lKXuOxhD2O35UR1X+
61CTaNRywoByD4zmY6z+QKlq6KSSKk8D0Y+yrzgopY18DtzNGV3YtoC4TUGu8Z9x0JT/xFl4FQH2
LVbO+oTanLnad276DDVJQahAjYM46Vl8wZZ92tuzZuRLnIhuHMJ5J0L2nOowmnPfNGLEf/dWipTa
gnBGscT1eoHXCq54I7s2c8/O/56+UtHei+WAr6fL38BtD4UTkIql+/YNA4KnrBxLqfBPFn1c7Nc+
xFPtiNCCpM+9cg0tTLTZIDIybdnSlD1NJFp/EEUD+sugoKVoGaDhHTCY8E1jETQRtq+uTuQDd+X4
dXm1AWRXwfCQU2/ui6UR79bEZcWo4b/FQtj4WJr0X+GcfEspXDvBKaEeN1Oupr8BASDuukfbkYHy
KVxzu0EX8+/gqjeU9V8dKzzXlFjaFQPQh1sWpdIioCD2Olmk1Y7GkVttSX1mHwhMgVq6DPnOYP97
y2GE1RYTH4JeTn1bstRDj55E7KHJ8F+Eb19N0sSsdFG7/fidok66dfchAHaOiRqPJjqpAHB4+qRD
/hKh42Sb2OumvNCSYc3NVk85gnInqKYhKEjhIzgxHNzmn5r8eDy+WqLdLbkeemH9vArvACirhnrq
MdFAPhxuXMEnAGG6Uli47XiddcHC9FP+neFhfLOeq9kpCjEPXAyubR5HlScJPuFc5CURNpPiAtdN
mQPLGBoCxZVzcvxY6g/8MlzUUIpNxF4/6H52azrm/obBmFLkzbTn7GGQTM3S+BWri9xtmoHx+9dz
rCf79nz1ifyfKHkBKjLQPz2OLvqMUxiQ9Yplh9ZZaFwo3aevKV+xGmY7yyaUNsVk4bs9XWC1GaZy
vy2GCxqvylVa3V/7TXvU+k/p622KQkI0/3kgsVe3sa7c4fG5ImLVN7STMxa67pu3iPQDBnt0aKqq
DZu3YraLPedNBSekrfeoCGgmYQ82+71gZQT5KnoArqtD3i11P3AXSLlTn+Tt6vSIi0mKpAFGui07
WO9tS6f3YkJIv7DwBbWCRRx0zGMzI92kog0VqT9wnEmvicg70Ts2f7DszLCL8WNkSs4TImOqGaSA
To0u+0S3ky/CHLMS6ODQuJCvNBh8mZYLaKiSBoschPfDXJqQswyJ2zeMg//rfSYIXy9kABS/uuk9
BxzSmOCmU+aFBLCmUCj4lWZSc0BF9LVnHDf1n6IOSxMJKI10V7AY0gAbGT1fRS9oV9LLyZ06jHis
o+JyqA5bT727+n3edgsCWI1isXZYebipGcf7CP5wO86sju+fURe912samB4qyZ0M76bc96kI/BX9
SQ3JF+1DM1PojDkVKHR6MkKsjgxkDeJD31V0yDUqCXxMivxQ0YtcxMfN+zfussFZ7BDjMtY9Xhte
8Wm/iUClI/iVLNUQW3/+JUEl4fiIaqR/tEaQtxtXS6sZlL/kM7wlV49K1fNfcTG9vUainMbIZobx
qVZA7M+qLyihx2Xq/fBIhrA0Y+C/QUr4rI65S9qAFKHoQNpd0VDfw/sqizgmIMjC1s6oRvwjxepM
nQ+54lIfTOmMk74r6IryUS1hD9PnDR6+OeOXLWAXMddqMaBSS71YHYSDCM5bSWue/J88/wAWfcSU
eIrWmBzW4SyJQxvfZurS5cse5Kw79dyqHo9CgerGmfwIYqxYxiXGcgV9G+260DvnoU8DOJ+Hj18o
LLrVrXcCg7LlGITvylJg+zB2dwv5hl50/iddNzJFdHnUsbTqAt1U6Imhcav4iyH5Xrm5Gzt2dSXj
OX6r83hmnO56/k6IyCuYEF10u4MXzgEZueMZZ4Frc0E7Nu5yky6WN1jnnC5iKDhM3lr7SvEaPCe8
D487X8mqFIYjozkT/pqjTw2hamo53MdXbReWYBY5tnzIxHi6dlQgRnGoZnUTZ0I5dllIo47VM06e
GO0MGOMIFx5xUCNLBwFIwqmljS9B6Q+6sBphrb3/Hqate/vzcb6CQ4VWsWFnV42ERe9p3kTYWu0+
1BYplf7m21M70O+jQvihqmRkCl2IgBj8gkoIuwIs34k/z8w6qEzlCf4WZJ8hL8EJ8o5CVsKhSZva
njkZz91uvJAyM+6s5VjmvmezUKlC3fO5mf4G6vi2LZUkPOxVBcrtluzjVfdAgBZTz6xN3kEh2f3m
2kE6EscF8r8Jo4gbNkaGq8xYW9c088/HoPNUgt5Kqzjm+P4xcg18++d7jvpQiK0ZgTIfi4KYfBhr
ZVn21g6wfLQELRipP62rg0I+vBkEAYGZgK5VtC2nbbQRRrJam4c1tgRDKivUIGPOoWzt4Ptl61EN
pjRW6DbDt/dW30YrXZ8IjSsUvS11fWiuuxMmlYDBRwmfJT2X1NMddSkxQrAXKhgqTjHW8tNN0XYU
7fwWuzcjWPjeuTpq0/qn2BRVj60ez7Xf89nSr13zgyoB8eyfeZ8/fIWrD2ss0RCJIl86Lc+liWQ3
1cB/MtjTuE1bYJzQyddb2Fl26Ii5LEv6Q4sq7X+TbAN06XHPOZM3DvJ2ntGSL/+8RbHbBbquh+Ca
BqjmUAFJhJFfIu4k/MTc6PznfYBF34eV0iO3Ozqv6silB+uhpSeCAPx0NI9/IOx+uxU49JUn5Mcj
EOeYSgrTR00gsexwE+fA7fG2XMhQMXMnuvb6JI7VHqnscY4Lh51XHInEkXhP5as4XH0rTCYKVF/H
xZLGsOx3mYwzBOtZ7fvN+TGAbLOoVGwwUnc0Czvd8KwQSDy2hkbM2NBPqSAhk5E+pyoy77Dhu61K
EvV/u5RSvAoZhI5MrbO2FjiexOWi7MPXHBslOiE+BfCM2POmc8smNtjUqOb1/WIqJ5xv8bUmeBlx
X+Y4m6tnZXTCUB2J8tg0EwWFQ4Tkm0Som/WZVMm4FJIUVBdV/S4h4L1gQh0+jRFJTfDj6xLwqr8Z
43SWfl6rAKRJR8dwSNJBla/V9JHxORUGo0v7JPZpTXLrdEuJNwl0Tys9kLHPi2vYOa0b/sSSzCrZ
RKkcxSvz7zIEBL4vH8Ri7wzSfrzTefdnH7rAf7UovC7Acc81ue3z+Be2F+UY2VR0dhotWt7Wah11
U4FDFhZ4X3DS54SbaSS6CHV0N2SXK2lJ7tbJMQr6P2pLRePW8DsUlRZn3f6g9wcBA0O09IivXLJK
l/V9Qgr9aDXELDwu9Bw49OdAcRQrfCHGWyf0tmrNeavgIJgClBs/ngIthI4uBSeF2wwPavPGl51q
8m8+n7rPaLXLCO2rbvy0rjcru250BcR+vKsdGf78X4PekD9nwOxwBQgUOqWs5/PgPYgPl0SK/2yW
SsQhmORJzKqUx0qoQ3M/yviKcPXgVKXUmLy49uQOqwYizD3FceUqcl4px1Lb3613mnr3VBcEJRdf
snqHFcBEY5c1FjDnsXUs83W6maQ/eSxSKGki0q4TxgGm+xDjJhl8XrCGUtwGUSv5oic+KEqeKaRo
p2xaBjkNcLq/BSHgFW5QutEelwJdW/I3K9vmtWI6XS2C149mMJFyZNh1+rtCMCMam/YfjTnDId1R
TQKrV6STa2wkYiBxHsZgN0+eoKVN6CHgJts6WXwNUKkltydWq6fIFROUWNiGawHZznCUyUIezQ8w
dXlS07eiU/4XmLwkQnKUBZI+Xpxwj02u4TDVwzUwpsa8HRPvaWu0URdqIw9xbTNSz4JZbVt/jkpU
yq8rZiLX7zMPmGuQfVGIUEbh0rRV8ZVefKZnykbT1r7FWe7v5QVgAbkojAarAcboBRMq1N5Uyg1X
p+wNLfd0kvhIM3s8hqV5dks+Kwf84cGnTGaZIPQ+SuRbMS+eyFSgvCU9CEIZrkRBJV7FINFJUBvz
/cb05KrCweBISl7uoxVs1RaNOizaYytUtfOlcFaMdsabNvfnjbiRERj+qwDfRMIDraHGG2IyCmo8
stsvS2Stopl7CBgz9GVqGS5AIeD1Qe+GYcwyLZdH/VnIdkt4bjl7bzg9eXLA6UJAZKK6tE3wVW62
WvcRvJd/bdKkcAEGrDJ/lu1NtwTx3xxRYHjQqmlftvghaKl4fLNdzQh1uGvmxhrhA06U9HGN1g8R
KxhrOZ9fJy2qfKF+LcVidt2ND/8b6F6F/F2nNiXAaOM7TmqWmv8DTZ55xlsu6Op5byjJDucd9QY8
sWC84tHygz1IEYcISo3iqKh3UxbMQQO4Gh47Ts2fMua0XAKCT0toJNJIFHG6fOEwVHGqbQHEVr0O
RH7p3xUHoBLtRJ5Gz4DGbq1oVUJdX1otUwP0u47l4wSFlinoIQqouMrPK4Zai5W+74j5TSntvE+Q
ZLxM0gFQ9xDrbmsX17ldjfofjOiJ0TAjVAP+6kO9YdP5QX55WqNTWXDBODeW+AR+V2y0y6RV64xv
jg7Sp3SCYiiJUE3afYUzoNDExKhQkvPyKAyRto2Mb5PgQTJV89CzgM/DbQKBj6vBL5GNbqb1g0pl
8EAtw+4seL3J88sWV786Q4vQnReFEYlEFRV2R8IeZM5JHLHbzyvRZDNFWbeS8h+wsyxrcGrL/N8t
8Yqk5Gncqdt+uK0hWVhLl6IusrxNCaua94qhA6NCUlc6v8hucdahOhGF3s0eYxgv47TX8CwkGZSm
UjBJ8YctezFzRqbd98tvCTFtZNu0sxxouV/mp6JSfdJOcgxS9SDAxM6QjOlGe588aknLwbLj2Bv4
/iqvl0sgYN8umDClbLwYppP4kin1kDW0XDcUn9i63Ai3e0EimYwo6faHWE/LOF9qfUucFMFrcdRZ
Qd88wAsATB2uMMwBcTUFBy73Rx5qkCVIOMhIsirC/kui3GgAun9a+B/5OTemHNc1tnxbDZuKEGLM
SkxozLRPQHPijsPJfE6qYJiv9zeh+VFb5SrvB5I0y6EdzT3wLLS0X3k65TSKlltDsyfBsbURvdxH
EVynVIsaIZqleYsAsmPI9sv7jnDbRhYycy+dvFO0MCjzusutUsrKMb81Oh7hGx2I6PvtOFMsGthg
0TxtUBfN9vdRkdhKsdLA/qnSiPO7maWmXCxt86yfJ2Iy9I4RR8j+D6Xb7zaqnQ2dNh4HkPn+taJ/
Kz1osHrdVH9PLZFbGN2qpIJYp+BUIxs/B78O1M48nAXb0cV12smXMPj9j+SkFNh9nlfFApezxXA2
dYjOHgoU9vg41mC6zve55r4hLqu7dYVfmBhqCBAGzqiVRyiTutiW4n0blFQ1MXK/IlkdE+o7ZY7v
Lk9icHPjpNlCX4ltxkaAAPnMFGRhedoSjmeV1pvLISbysGMhZBnjp2TZgvyoekF3bEGS6tiz/orS
1fQJPd17BD/WYy2A3OKN1vcGzQtmEwRxmV/CCY5SOXd+VV8/y/94PsOKOd3gpUMLRY2r612odir2
PaDH8EzklsU0Bf2V915Gv7522V7swEh0YWYu3jTcrWmuSj2f1IuOxbJdiZMzDvANXK5TvCFqtde6
mC3j8qX6zKBvEo6p1NJsrZcXpRuNk/QdaNn/9wdtzAvXNFC1t45SNvrSOe02IAH24kZP6WvPhNC8
hTx/W+6n4x7UdVIM1RK22cE9efxO6f9SK6BjPu6cmlQSlk/1ix02S4JoONBoYpCLlyfqCCCxrfo1
4Kz9rbZ/GQ7EfSJOtC+NeiqjnH7IJfmsRdmWYGnc6zMXrll/T35IToQEGF9Z78bvOTF/V1Yaeuws
McNJzamffhdic/yMOgCqJ1LWMLlXwHfAmRYYYcQyWEdmRKONxI3yusOReKVTIsFNBNQUHtz24Pfu
xWj7EcwVxArY6+SrNkDmvyClwKPB0gO9vyZYAqIeD+82LXa4eAQsXjk1gzFuGQSenCS7XKqEbLdM
gD3FUOdwo6o5CfqvVMuIB9JnNUq/UUD5qCx/VEAHUWOUtk3DNoht9wVOYX0i3BSb4aJonjvD8cjj
nwSUy9CLbRMr1LkE3krH0v6vY4YUZVPOGRdMYVveqhIRH6cnCpglHXAVMUz+t5RW3/Or6iSNv1eL
PNjMz0WQ8sGfAUikxuyCit/Hozxa2zcBepZPyhRUjM1C/m95EPu2QUSgBFMv9SM6yzr9KYGpR4no
zp+svhzL/B+OtvjarqiY6bXo45ks2e8PJ5k4tqaDLDiu1tDZ7y7ehV0JUedeGuSdC+KsncQ+03UW
qYAEvrnDrwXken+ND23tY48xyvM6uEXkwZkrww0nJhIZoLBACO2HGLhEakJbEUkc5w3iQ2WDnzCV
6Xl1ezIBIX/jhn4goqw1wzQbiGHwNXPByV9Id4771Smqq9mRB2+9HYL9i5ezgwcU0wAYk0oqPUYN
wmEegj3y5eIW55DZ/ojpCBJmQskrHnDEvdn0srGlRJ2mpTijQrUYY83JItPKpkRW1r/8yAQ9FmFl
etSRwA4sGFTkxTBEpIIsitdQ1w5Up/bJY9pTcHBx+F/EobOW6P6ao7sHz4XU8m+9VfwQwzBzRv+U
WLHQ1/rtqNDc1vgNJn+3bZ7P0blcdxsiIHSu+uxfEgShJ77ML8vMz9RcRkg5elYVAJiZmod2x3Nn
/UAFMwQfvdvGZ815ycg4LjPBcqWO7LMs+l9i4b/gNX4NRMrm56rqcrM05fg9bWMaVUDtc2FQZoJp
tOPVtSS+ljzxpulieDOmmDG39CpEjAI5zVe8NMlsdscWcMZceeadUaXCXCl/f5ebhRl+qjSoU45v
E+uDNpgLl9fbzuHiXhI4VElDU+wiArGne/S2uJ5YbOCZIHxXbOxoMh2YQVkgHNS1YvsIcGmejHaL
gXudhuZJR4k45A4tY3iQEh2b4mjyV2KbpBVN5G1+SHdOflp9VAhvvqp8r9OtlFmFK8jPex58WNU4
OCOXIcKMQIAyDa6X6oSG+eAuH80FruxXDcUCbdiZyHXmkRaATVOeY4WI/6aDhU+iykLw2tpEiDOf
3iMl7cx9MfQRdXSvEA9IK+yk47D1SFUHnIbyItWBl2ExBHZ0MxKay7WfHvz9P1I+INCS/k3jtq5s
PeG52p59PO+oX8YEbxbC29+TiJFjJinSK//tce+euvsdrdBs5YjStKODhhasKgnjPvOfPRl2hzZd
v31csEMjOw0Q+XleEOxpVNt70fC4IL6IYUv5NKa54m8zsn+Kfdh0PRuKL+F24h3Fua0ABdusxK83
3Q3379AWeyy7fOOxmsId/7laeeBw56NjJYNWNI7ZyVHbBZPjoRFeOdkg6a7Jii41Oe6VjxeZr2rZ
4zADX0pra3DKzZ0m5/lHKy07rdYTKCT1ROFJy2C0bw3Kqa+U3RVLGwR3PlzQjyly4Pz4rjrcKOuk
xN9Nu+3quTFiPyIOwnGIMuqvbn62jpAn+mzU94QnV4vlM1xxWRW872cYm0NxPBEQ20HeHYeW2YGQ
iD6lm++4Uqk02qvIgvipqmtwsLBgfSCDIeLIaf2zpX2hIfpsFnfL7VDDaCCSmeW29HdvN9QDTBwT
Iw92b/j1+/wGJC0/GQSU5Ihh4Y2n9/SD1h/SxyQ8x//Q8S3iRexmHbpgrd00Sp//IKdrNSHnwUIW
u7D4o9cssKpDaaUbgTM5+Og3ISFbXD7Bo6jgre3l0fV/lhQt6KGIgZFaPlySu1P0YY6d+jpF4U48
SIc6dsVjPeMHGgyqLXo6TbLJ+ORx5YOz3nSx5ATHTaNHWAVmceq+Wazn4KjrPTznRgS2QctNFOrF
Xf02dfP3AXqZ3sUUJRMLsUp1IokM4U7o02Sw7rjFdrJctbqilsOAeMvAwMH7Hb9yMCPx4/JzBWCM
vjLMJ1kshRNXujj4IXqHRWkVYzuf0k5I6cur0lcjMzmUa2Y1x8sj1U9WPDkOPZ4WQ9N5/Ngm9zbA
X/Mhb7Uzxz7FReXRwsa3AWxqOVXH+uyh6z+VaXYWGRczYBfr0cYc7FaoKkHcwH6/hOl2tX/2IBlU
14MRLLxCR8+EKYGMwTISYDFqGKUMjzIIQvQ6V1vrFiNxHsdZCwsBJeRuOgr6ThgzI+okvm4lKasW
HHIghaNm+jcaSCvDZteAWsGnyw6MHrUVKhnOOMB92l4NsJ2nuxoBFPY/uHo8u3Z2L/RUQVi0442C
0USoDwxl4lh2oqtc9rc5sK9RY43cBRy8oW5FLvRNMAf9gF3JXJu7Iu0H61h0QXYz1eBI6l5CdkK1
R0KNh9nzCDHtRew7+Y7iuqM/Y9YQyTs0qymWOxKw2CW3N6JKlW60pUO+RdMdNuVxJrafi3yE79go
lnmYSXjwKYEmnIYA3LnWyNdAviAVQoezcm0PDz4CzGLYDDs09tBjIGIPt4v5nZaS5neB192O1EUS
G0XdPLqCWdeIs59dPl3IWVQhZMqUiWeWWO+ZM4lAjN9oburv98ncFjUr1T6rMyvN+WRUKvab3QrG
3rauULhXPPxuROco5Cdoi5YLe99waRDA5Q6v1OczNk0GLPwRC6J6aAEu7/++EF1MDXTV9vV/VtB2
c6ouPOD9b8swL/jcIvsQLXy/UDtbTnS6/pLmrGjBJuALUaT52q/y5VjAymh56POFeh5O8Wq=