<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrHToA8xx32Lmh9TWHSA60n0HRqBFVnO1CXcl3OaM7ya594eW6ryOO59Z5i4jXWKutgp1I7Q
8HRetBBe4UWZxfB5LAesSbN8UrNpec6J67wejTX8Vo+3nJT5f1PdOAQYUPyh6LcaqKHJVXTvkK+f
xQkzuvRc5Awknzvl4FR96PFeXb6kgPFB5jTLmO4cInCYzKKNqkBCqfuhJAtfHlGwooxRbgi6rL5S
dUqJNzmTAWI+ykB40MSZP1Sxrh9zNl4eIYv7ycxKLL0DZptD5Sss9lVne3AAPSIRCUwekg66afU2
WYquO/zQMStXoa50nY38FyZQjotpqmf8CV7bPQEAO0yhWPZ3kxEl4JhrtG8J3MrsSe+swSbyqTXk
cZaP5/eGBV1b4W3bOHG6i/zlqc469JRX9DC8xglJprgAoTSZg6BTcv1Ebg0hy2GEG9+J8WoqIiIG
57N3JiSgIrAoIHXrw+BHjsIdYGTUCc4nADfll315Nr4WUHZK1cuGCU1eKooJMyD2NGyU/ka/Oc3Q
RzWh2kGhw14FEO4wbXTDg+1mHykP2y0VNx3HXTFos5YQYIMEVtJtHwSiL0rtWSbPclq2C7cfrg50
0JLPqaRch/ZdstTw1Wito1bQdp6atxhG4FNM3oqXE2vQ/rvo9EG06HCIFKsj2yHF6YUV/2smo8nX
72xHnP7SepufXWmVajDAR6BJ94T+eBBE3YQ71YCavSmscwg1o5ParkeL9GfSpLOZkda9rGNbBb8j
gjbqgLFrpgCZDgzIYa5tQbiEV/vbCEkZohG9t7+AGPUzDtHRBNTyZgBkQPFTFTzhLjtmDH3MZ/uB
+2KPgUZEP7cB8URaT+n0h0Yv5lL9Nmvb20V/GR8fVSZL1u7xT+GZREzi3n+/DXyak1tAUJFgESSx
lc9F3u84Hdr9/U9I6hItXui/hg76zJ/8VuqB3he1FrJ+Xflnz/jOKPbMS0HeoueqKRBk3uxT3niT
RyIMkm30XjG/L7W5qF0a8J7PZ8usz+6iechsLteYzOoD881wZK+cP04P0NxMBZxm1VFpwarr9SOQ
jHd4r3xy5HUmCQEEq4Ipcl8IKOliVMuOrkBfLcxldTlvEGLFywTOJ5QDLfgvEaJgbpS1ejJe0F/i
YEs3LL0nRxpJ4tNP/Bop0GdRKiXEfEEfyADk2ctGUNw2RMs/ynbnmzYgb8kRzIuqAR42tE7Xv/qG
QoGkAyMmLfS77Q2jobpBqNzUJvAXhr0o8BhEW8H8Fk4wL2yKRn5MqDe+crsYdQW398mjjMbDKwP8
4bihwE/TB+ZiLNkiV0GIqMwLNFN+I+dUqZ1/xtu1Vt94YRyhDvRD5kDZ7buG0kYqBSosBhu7ZnfK
847bjCM5N/jymYZ8HbA69PtiPBHuSDkqgA9tOopnsTMm7836CgIpXiWvvX2oHrX/XsXPTW20FY91
/Xg01RfOSgxh61Mp1oWdI0UnxtkefM8wgg+nKkFDTCANOVL11aewWKzRJK013LnYzrW/0fqJlzq+
H+PFiO/xQUeLo9xQi+x0CKwNbJWhBWBTktH2610bdoDDlpQ/GEBlMIoESX4fBVTDl6fLQjvJ+vDZ
gEhRrNlZNfY72oAHQuslBIf8mBYo0UHtJpuUJ49n4YvlzcMJOpaFxQ0p+ntVYnjj6IADnr91GW6A
UgqmNkPUaL6zJB5yBCnZdwfmSsY0gbYTavdEeO+VIOAFD1A8yzudJefYdAoyUvhAuhhqno+R7gfH
JsN6AYRc9TxaB1fg14SUXByuI+xXyWi2MX6QGJk1hKAQcgyADu55q0D5NPOkis5iMlBQKBWHI17g
6So3kjoOXCCSUQSc9Qz+1pyvGZYG3XoBMipTW0QtgVQjMiOCj6nDH+6I0ttgo2eg4sbQjhOKGd3D
P5iUDpJyg+FHl3OEID63ETjU78B1taFDMgANhDG9gUymCO4DKp0Q19hsypzfnWeUx5H+U5xGSD7Q
JEhohM1UMFkgBRmvxJVoog5c0NB3mS5AoTK/o0AQQtOxEn5hilF7krjpKWaJ5QKagaZNS2aDUQhS
UNPnKde9TKQHzja44HCLP/NbKbjkZ0iM+N/QRuYh6G2MHdkxMbiEQwTEpV3zjDRcw2ZowNBgNgOB
Q4AjgrCWBQTQcJXnycmsb/ZYW6twIDr9s886f86gZk3QAPfQ1bTACrwQtqbVmW17PGZDnGObYSij
PycxTP38NrIxi7k9n8KKiOY1u4YNWjGGzmm/8jGHGMneGfXMnxMrLsr6sBKOou3R1IVWdOADAnDU
4Ab1CEP6Ii6NTljG6nLra1k6vfib7/eOy+v4LLmbNVSMFte0l/g8jYud5hqtObX4dFJoTu8YOrFr
2K6X5HlaZ92XMkVGMZrXJbzgD42mLwnrFORsUpsgWBjOZZYOBtLSD2N/HXAG/bDBLm5LwkI2+BpC
IeMrrZx27yLFiFFz42wVRrigFNPAK41uDuINGHTLEZRjLg++dE0ooDcci9qHX9ZmtojeuHBjwYs8
vKl9bsXy6X7ZadS/mS3WR60gAD5gSl933O/GsFtiZ3kLgYnyHMPIMVoHJvXDiPqp4tYBjeJS0Dk3
uDNr02rByEgPw632TkMP9R9NtL24NwCX7dEjOd3ky+a6hJlZzzei/n9Ehbd485eu8Soe0NuAl44P
/DxToeFkyjjNB0xlLH3bUnFim6Xz0KVWV73R0mydXtl42v9UZClUDyFoy3NAVX6jDZzlz+zablX2
/zAKBLlhAS9ET99iKvkLqDsp7GZGszFGSmarW5jae0S97tLV9QKQMltCnbLaoMt6GbxyNObqnSs+
aSpd9GjfRKB2rnfmP8sp7XT0oM+4kgKNzdsl8U1icLtlbjOlG6H6Tynse73AqKDTBHLP4XBw6X62
SpHdQMllqbZrauQmlAiRFHZpDbCgob2ZYwk+Wb2QRpkpt5TaxKjf5fKi7m9MsEYdbUZ+L8zEY2P2
yY6H79kAdsMV31s2kEWLEDL3tcwY3Hf+Hm0D/lMAlPcsPMFyIYj6kGEuYp0A05yO/CuxEi3z3iob
im0kOx+kN4oBlYz5b82DDTI0t+/MfaBJfLqq/ehE4lxBK5AeW3UMHwVRS2DTmAhr3tPF/TZwlWaj
YELkJHBGFfLQeMkiQSmugCJ6k4xtyFyGnr+vGzwGFpsJHKNUHUlkS8OvaTlLaSNFrweR/ZNBivpD
3VJ++ueTrxD6o1MFKyuLyUgn1BmiZ70kJtSHuYOBbSCcbLTrDpy+WUbytuotRxdThSf61g1WSLUD
Mucvz1YPYlYjEV3NtTYHEP5oNXTUIafauI0u/3QWpyLjYe85NMZvp5qV9qo+GCydRbS6zOYjUD2x
XRhHoqk1Ji8Oe19O5zii90UD7Kb5FuNzzir03R6mGiDvatcAmv3wJlYLFYKMNf+5IYfNu/jGHE6O
u7tT1SRt0C6b1GVitOig5sVAc4Bg/GLld0C1fP3qPXKOqr3m13AdEQfcWlzlzSSlnyutBoi0roPh
sihUb02BlpbwNxnd2ACwOQbPJYj+AjlZgd+KoEZhHVfZYXY+XbHs02BFBdPeFXGWFV5DDUm4cI6r
nLC+NNcgvXxlswTMw5w+SW5aI7Mp+lixpzrOJiGqJa5vEkXioe4mo8kWIqoyX6uObqt/XlzWJ+27
YmbuDAQ3GR5ZPSArIscbdiVxe16z1UZIVQZJ4ujes9TsdpSPrWyQSBukjVVsBMZUHvsWWY6TznOX
4eFBWqD5PNQbnaE/O3exVFoPjOzhO2K4mDtPqcpHslWY4VyIsjSOpKSS0ZZefN1kABYpwFncSweR
CH9y6tsucWLuizfv04CB97H1CroCwMwyb04/xPPV2+6KCE+Ddt5J1EDMC04qiY3ER7cqXDxIAW/Q
Mo1dVvIO+xEOVuibifpJmwcDMLB6RsljP9WA9FY0uDeDLePi5xaZQTo+ZnV/ywjxBYrp6uSdVM82
uo8j0aluL6LELz+mn3qqJAh3rS6gOzDF+nQjojhrth6yilVv0GWKDQyjnb+GqT64x4mxmHtk1Rd+
h3sYAyQUr50GLWOUTv9O3Qs5PpTF+H5CfIMzouNFmY9H8LntZ1uYc6mheZuT9LiDu+0viljDrXpB
gSADvlXR/uaKBta7Cq3jKWYtbBNKuopYijuBuVacC9HiaEn8yPagbD52A5aawtW6nfSXuWvILKZA
WCW2R47HMhMBnSLNuFzVEuz/hw9KnpAFs71eKcuIcvtSb9CS14JERJ9Cdr4lqYvQ6dFcM378CIeP
47hjLvdFrGTlj2wk4994obxzOSOW7EyCH6TMCGnzd4Sc0J+XsO75WevZSw8bqOA+0Pv9bi7P3B/Q
/Cp9WAlRuOnmKuvBx8RvuSupPF3MusUarXQRufcDLGQeWI1a9kaD54QulC1k7YmUcKh6GeE2G14s
3mRSa6TZOQwDUuMMVJI4J4ZioIcUOqsC94kU0JLmE/al9MNn5cfwFgYKlaf01c34WXS8L/3k4vUh
GvSG2BQGlbjB630tiv2DvykxMtxu5opDaRQFTj6fVG9UflVkOY60dTcGCugfCLXpuGycbVFAy+cE
T7fMjGubL9RYaBsh3dZ7zvxI6xU6z25QTL/M/lMgLmKne4f5k03w6/Yjmf30gI+tNO6YWH1qxy6K
M77jY7oCmtVgOaN9gPHhgYRiU5hmb9LEmFXbS/RMXMZ17aDKUZXTwoGf6k4JXyqVdZeZWil5MPhP
zSU8zYpOvERIB/7IPY50EnNHubX2aNl1p2IsLaYw8zSu1kKWTipB4qRZ/tWoKPn4VOMrFGslxhCx
nUtDIp1+zdLZEWKql1My69fzSp3FMBlZBPYRDhA75Rp05Aq1OeMwSZOoriHSEUvWC9lJd0vKpJtC
e47uS+qYQ4ZIkVIJ3JZ8uYfyQHTrkPgIak3G9AlclbKTzo+P7TPrh9/G6Uxqtz+Aj+nct0rO9njG
78t3pF5eDrB4uHzI6xe6BQ44oNJwYKR7oPDR11ltjIJ4SEQw9PKo0fn3RYrR7DLwKm7bw8OS11nP
GJG0FGKZGWslP9dMA8YZw2Jry1S+p1G1G4YFNbuFKeps3WlFgpXXwoSnjz35TsYQjJQ6dUSa9xp6
mRQqXakFO2BpTmlGTy7qqZyqBOztAmiuhaxLD8YmMHCI4RBuemq74fmpMN5d//jGhu2fgLFtVda4
oc/oPtvOap7o6SW7GDoRMk+c21RzPFnpKwL8S811gohcbuwoetUjO4+0/B0v9J238LUoz2AQFXsO
y6EKLtHgq/fwI6FPH893rUJQGxJH8byFMc6y/j+DuYXv8TqGRwsleN92AN+hLz7Dz0H3afTBuFuu
eZDQvDa+2Onq9YVjc4LJG1cGp6i4NRFWs/HujBMAD5z6dHy4rRdgKCSursU0s+B02lM/r2be7IWX
SY3/Awc/9ZKlEVRGGfhLbPwnAJLn0P+7ft+6jac4vybj40y6knlcbbUP44V0Dl4Cn38E3rXp2SML
CtlwZzGCM6RcfiFfUNytgZIb+fzyoBDXIRlk6I/QY8RmGf8nvXv9x3emVISA9l7r0vgppOFLDt3+
U4PKhlx6LqIgofugPhy8qK+kwrZJEWJCX9bwkfl6gAz6OJhauY4qiSgvGnfChGedSNWUfJg3kwfB
87gfnmQ7SkPGNX3wcRMq4XQuW1wRUc6arJt4lzIMEBqS8jE14rt0lEBXjlPobSH8Uc+OExzowFSu
CKC43tVDUZtc81Wab4rBMUnExLP9+A2fdSK9qYfb2BjrIcjlCyA/ugKYyHsszkB7iJGj6TMgj/M/
weKRm0DeOu90B+hh9Iei/yRuLcfdcm9AaPbSat7P9mieZ5McHx6BJq2TGePnQ3ZJLBONQAG/T3dd
N23r+fq5/gKtqsW22/V0unAunOlAj6TCVbcwMjow9UjeX0PkOM0h7JsS9eRQrLByei+ZPFx1vM2B
eMBu1r3vjuisADoNVoXmjsBdtUIjsTBbUragg8IJdE25yd+HDe1PIEzGwB89Dno/yFXqIutKxXKi
IwouCHkJizcQdzg7QW+G0xeDWkxtbkJuXYaYQlYpQZM9d1f8fG/3yUmvameJs/oNoGpWFo0EpdW4
2AfoUfHeMKWfEcGB2pO0AsmqYwUOrlElznxbMyUtzFmo4cxBG+yCId9pTrlaEwZFOHpMZ4O0IQ4B
TpC+XR2WmCWwOJP/PZhEkLxYTkDw6sn1gbBjljXUBl3F5aoheTNmxxGTnXF+pwPiMG1VIXpdrgfK
9d3k5kdsOWEF0I3RfcdqTbYbQlXRPC7KlOUm52gLsq7jQ4+5/00p01Z0gLTIJZvlQuhgkOKYIDbi
iIyElVRImn7ULVRrUWqB1AaW/vyjzwHlQ4yHAKp7qBWz1q6X0ibbXnlbXzs8NfpumXX+oQB6r4DS
lr4x9hJ+EB44+d7+YDqHjF1ImdT9aVUEWMTWL97qgjvdFuzBPjdNbqZrAV+t03c44klNEeliBSHp
ZGU8gg3kqZbTKhHogM4SBgyeTMENEr2vovcxnFik777LLrdXz7BON2YcDZqf6q762pHJ6sU3Qnh/
1NzreQKP3pkruoClTr6QZcbejP3RBc25YrNRY7VcIO+pQeubPEgwQoAd+gxwuYLKRRlsxz2mmzPg
k6D+nsbhX/BaP8m63aXbZUX1PXRNCr3UiX9qlGHOykgg6p6s1w5azIqtYchtZSxLTbZnwl4GP14S
idU35rAsq3Ih7T1Sqa1W542v53tP3GWFZKFA+p8wMBNN9oixNBCxJVvg88kcaXX25Flc4UiiSKyY
SUOD3d714vwXFa3Xlm12coC1OX5wmRoda4mCqqp+EeRiafF6O/LqBO3IgJhIZ1s5/eWm6K5AtbVD
e0cySi68V0FdKaeDxmB+OIzTkd2htlAOwXUXQl+ZSs1C5UcWLNQ7h/YpAXkqguUT+9LgBOpBEqtn
EtiXeMPSx0EfZq6bfzqkdtXmi1w/LE2K6ivZWkXnBz+bXEaTLkNS/KKp90kbw6EPi8WIFhdhblfG
XtiFqBhy05PizbrRtDxVVWElEpypx0Y/Vsy0E7lpPcfo9G5eEnNXEoO54kvzrdliiBiliWqdP0vy
1Bf1sIlOsz9VA8q91RxciVMlqgkJzybNJ1PafPS2dEFmxBt8T9s9fIInLeb3N5y6Vqcvio4S0Uii
oedsTls3zR8rhxpdljld4I+HWIVxy3kEBMrykGb0XEtFc6wotz8Dd3hAHFnCHPr4PJ7Ia4bvqC9B
oHkUlEPBDto4vxHJzR4+7PJeEm0KbEe+ObJ2MAd4+feGMchigG8W88y0TQXGcmUpA7V/EnWGaD7n
Gdv946fSHmBGiUb3Q02cthB2pYn0YPlQocyqScUApgHxkDOXjFoBwG4fxzmm7kEJUR/NduYt3vYF
mw+RmbgrTg0AnhwTyZZCCwUFnrqO2QUME/KmpUJE2FCOUzAtJwdNwyEUhIQUTCJ46KqUT6lnI4K+
hOlWR48arkOx06yDDZO4nuF8xLFAiwPQscH/3gUjb8lIN3MjkPBW8Wnls9urS3j9zGiRe2jSefur
oxpAXtA44nDSteIdg2l7NfluS/Rk6Pt03BqUbN1AArh6C2Ts6Qe/ZIIV0UVur3uPwf7nx5RuoOhw
fVS8eVagquZfCGW593yanaPeeMS6Xwd0VczrCG1NwX0bx/sOYfRr9uD3gtltZTtdRfyZ71OPh8Rp
XpduhLdP9B5IfDPgNpbtPvTSOAtq5Y5s0FopWMf1V+DT7dhDWWVMQn7owGiQMK/y+XNM8J1zFdi2
lRtt42QnoQiCzjEhjcAX8AqQ2IvyTLFmT4BzI9Sm1u9RMdq3TEp0BbelUar6fRumu/WbRBCMMfzu
e1CqcYKKE8nJGxCRejxOqHfKEUAV50EAUUbRjBA2It0YOY94tDfEDIchneaDFfLeULGHrQHA8qrW
UOjyrdvm8OLqYu6tqKnV/9Xkw6g6qx8BJjgZFVAik83D22pdf/emtOQZx3XLNfyJ9gyZnLAFAdUE
uyXW5xqmiKy87tZrGgmV/c+7Lv13te3TFfJXG9pNjMAk0YU1qoww/MeIUx9rGM13BbfCupRr36eT
RQCHhB9exdQLTp42mxBB9LbIX9CtZ0CAVBkBWRmo8ifMwq4O0ysAhmD+2+Fe3GUirxUWM7kZxlUj
Y2gcM/LsOAYIL4eFVOcUisvT+5UgLldytUztYkTb34gzlehWvrR/Qy0h/8Mv4GNo14SBcf5kGntF
AgYxPBXmdWLc8Btjv9vFtze2RveNgzoyPF5roOFTEnNXiAe2qMzx5J5IjNPFBBXBSfE4kw4m3/nz
AS6UkiAfCmF2vMLBKP0SJ3UNQP67EQoJlx9/XlgLnLrE9+WPXuStATt8qRqhbCf5RQ8Mb/eiQv67
OsJ6D5GDPem2MVO03jgLZ2r1CgjQ/xcC7iTZloRFmisxpEbt+RV9WHiu9Mv+DLspX6q2BpWDZf8O
+D+yZmKOb2ZtG1sqWRXYPoDgHG8xZJifi5mnBvvfFj4AflASrSwywFlGq0lXKhcbH9yNtkUS4yHO
LXtNBORZjYV4nfphpH0/zTXk7zGmH9ftNS1oH2JunYNR0XQvERtGejH1BX3ENsji7CTBiftFYZyD
QIpEDQQ2Wc0SzhZY/6dBgSs0B7Kior2uqrIDyUwxQpc8xLj646zZE6K+rlJXZizuA5KwZbEiXZb3
y1Iwjd/Jk1UvSvFx2O3PbVNH2/xkahAF1tTKhK9ObnWFj/gisNZKBWAH2/kHTmd9twSwnIbTiobB
DyfDCLAQa+ikEvSTwrj4HINLGCMYhFIegoGzLdC=