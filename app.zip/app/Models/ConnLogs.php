<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmknU7mUCq5qvr/jNoXRxAv0afgLopN3+gIuLVJFy7IQm/ZEgBEud+J8JCzoquZvmaOURxJp
3fvZahou1OHF+UqtDJl9eMXOA7vY5WYkkvfthohQI+neuMw92OL7RHPzqTKdMyZVEGApbxgcYFOv
nL5ojFdurZkWA/A8i80R4265a1Fewb5+aXtHYqhb9LB7eQFVtHe6p6DXGcySX8edR3AWsb4EeO+W
ZE85gLQrHLB+CKePcnFS+pGlNy6QNWzc9P63lg30UZr/oXUPysMTD8bFf09izJNZrGMuRaXfw8MY
DYew5mwjSNZQ6jmr/SMmioRkchbGy/wdccQRcf0EvxjUGrxfuo4qPHx4w4r3et0kDCjCruN5r7oa
Mx0VRYN5DfBxoWhUsg2EH4qkkR1Qk/3IDZfcfBwBkMktePOmobs77HxvU2q1PN5npkRkDNwRT9pK
4cPQMmi8CE356cazdwJLPLmCoLYAt4002atcnaEenoYXIS/L1OGouCIx888Lxcinw83t50HYChHn
uS7yJnkIgiiNBtckbQtVVf2LltkqfoDTDm09/I/pBZXobADLeXTWDdVu/AJr57/9eFsOsUgoJ5Im
sfQKbWB3/6xXGcOaLyiFWvCvNpX66D0cdPe7ula9DCMshIx/VqMevIfT3hUVYzD6/cJ5XrkbZeQH
vmestP04wOub1ZhndCPgMW1MVwdjOULmzQPgC576gfvxqwDvYDlUXL66NuCoxVla6TIikGfcDLJL
tJP5BJ1G28zSW6Po4Er6Ef6q/zxdeV1FKjrqqXwPtw4GWoYTyUAv/gud5LKEapH8bhlPvNuC59La
Dr1eiMFBl58Ek3G8sYJtZUmTcJzDvDPr8MHCrdhZ8Sxc/ZAgPlmPaY+lHSEabfWgvmo6+DkexLd/
O01Kx5A3QtLqPuXiU4HpfzpNfk3Po/VBEEw+/uM+rS71v9KV2zVDC52IttkcHhiS0RA8//12qYaT
6VevKqof9Gq7wDlKYh8WQHdtzZImXLOoyM7cpKRRtZP6rg8DfsX0XoYXEQXWxMdwJJDVxG6T8c18
ktYD/6WOoO7FpXAQmgQaGYfK2ZN3c4Z1uTyj+w8GE/w1Xhf+7oC7nAnzZUf7YZ8nSXNdPiWKAq5L
0z0Gx+grvlIL0JYXaz8QJ8K9GomhjsPkYtsR8x1DrY7aGbCqBO6SHmfgiSYLlWlM1YDj3e1Uo5CX
QM1ALpwA9tku5uzvvdMg2OltbGqroqNXc1RdaqI4wkI7VjXBMMozZfybK9UQC4S4nTqSZCvEkCeU
eOocnXGu8Sm7eytyzWCkophB3Qq5eo+okctTHribUfK1NQRxXT59/og91+y1IbEAz9cx/2KSc0ve
Q+8gNBGz0+NTLfyk+tXdWeOoOCEclDIlPkaEGsi/2GbuefmI4J0SYSaZnclDZ+AlUaXwMRIAOaaQ
cGTzvnJOW+8DWkO60XeIvw3dL+qStbD+z/sNnTTjoMqh1AIm3jVlmiRK27YHG1izuiTKqK0Jmrs9
UCLOs+99AFGbSqT66gMppTABpygsJsJJ9ko85vPXA+51CKvCEVhUvG09puZFYwApVagXvQ98jtcm
999S5zkymeJUehQHxqFQCO6InPAXQjBS7ngPocekBaS30X894moYDON0bi6oaXvlp7QxuG2xjBs4
wrWPG42gNB+kwXZ/1U9H8JPe71F8vPTWOGRhdR2ZFqgopyWZ+TV3VPsYK40w8rW3lU1v45F3lNLy
oKRKEKWmI42v2+QS8xA1HTx+bkQYiTfRf2tmRG7G37YDN9BMTGUaTM+bdE6lqfAeRDRamiWKU+fu
LUscl4vf92YAoYithGp7iciLsJboqZkxgA7y59dDvqEi2MbbpRWgz3uo6Msev2MafnuQXqH1fHwh
kuY+0k/V7VRby+B8uiaMXxI5lh4mWy6kLSzG2IglXWXGwRFdQu6qfIZhYWJ2mnW2bZhVwzoWcpXE
/Cg/ZAEX0akAg7HHZE0BUwWX27tuG6ha3QkdE3HPaN3mL+2XvLuxPFzLUQ3Nn1cLNF2CGwJiMN93
1TXUst9zO0p0nI7TtvHoV9sFM7u7zdQKVDAMfv2Evh2ZzruEHPotpolG5NFdtPjfuyMcBPKmB9q9
OdZIKAgCmZuqEf/ylAREXnkBg3ZTTzTba7oJGbxQOhJWaLtn4sFaqTinTUtlzqXEPXY9ZDbd+qMk
PeXKx7/7AnIe8ZVL4mi/j2+eSdSVMnFtoFFfzPMQ1U7jwWY9OqLRnuCbW7OOzqu6qRUH4FYyOrKv
Q9e2Ui/FuiiEffDK7j9amyNct8FHbfmV4m4+kNdEM+O2jPhUnBTpEo1waYvFeY/qSk1+A+4RbC72
3ZlG8LDGwEc1+MbdQnqCvmC/PUAV1LHXDObZ6gp3KV0bf8J9N73vjQtcrhNq+3QM6d81VvP/PRRt
zay9GEMJ0SpHoeKnmr4AVsyVHV0DYTfrwfwoiJkxpJvEInk8GwdjQWHRD6BWTH58ZOYVmKX7pWGN
m6yLAl9rXmvsaxyLKYAzI7tsembPgq7Yt336zWpbXXdUXtXagjcVc+4/LVRzGvMJ5t3A2Ke81GeC
PxBcaPYNuTNrXUX5YLEcW0yY7RnZ1vpzRVw3jz/gJkjyRgFCYEMczTuNaeUut8feYFIFfmsbWWo5
MytaKom+p1BROuUbpHJ62KWUrkXlUBZbTDOChwpQ6RiPv277ndsdrcUYv1h/0hiwHBqaEBgze09c
rdpOFZYFSa04ZqvjSeUtuAzyIhUyjiTfG2pZdWNqcVKxt3cB2KzuHCwFJzD8w4NLglv8qPNtm3N7
Fmq0P8M4lMBzXHVsFb4f25jm5nW8mJ5DGgaU3X3SlUKm7J94Y74D/sEsbRWcQz3jZm7uoZUS7qhz
NcNIzuYeRkJ5u96YCdivrFGbTJhzNhj7X6L6pXu8OU7EVUyfMpkvUwuVns3tL+3KKmjmYQPBFx+F
5l5G8O30pcmJYoXp8bn/v4KWbJxnxZZHJ2yvEY1PY9aDtuo+KBdEA3bcgx6pzFXbs41CI6Z3sTxX
LOkwbPeNxfzids18qorkOviw7jSttF44Awwn8Kp0+8ugUXAhW+g79w9vgM+mZykJKqbv7RT9GkGP
k6ooUcxD9WIN945HO4bayXZDHgPKfODtBP63fGAK8tpcyzyi+qELZpAJX2ojTBmJu4Tv2uGntUNg
+B3wuBEw5UsebPoqda0UNtUtdVc/KJfOqW6vlu3PzUjCTKst55D8qwx1ptCOuKamvI5mxhudq/AX
zOE3UMC3n5KoErJA8SNZMScIvfANZzE0HVXQOGtORzvOtJZZhFphYrIioCN7qHSFEDw6Do2pvzdF
bABQKBK3qkqouis/kFe/heoLzizwPcY+C69FG73rTJNwgLd/QgWTW45LzD12G7yZ//BbX7/k0cWh
9zDGsblw6qd1S4JhPjNiaMcGVxcfr1wR4F3Ro34EMhM5qWzQPD0clXsc69rNQLzF3hxCHkRuhWYv
SjV97uN0CJ1SQ2RaAGRRHgo0GwRy0opaOAUnSihSVjdCR/YPj93cLqsdERuFdYqmMK6oQodFroBi
vxyoHv6CFG1vOyjHSerEUN8qz3i2Z9n4DytzqY9U/XhxNStjbar+VXZyxheNkCBdnHNEVfXMgoH3
T80hFh17mnsMCQGDWjJpu5X+LuXsvqNa4M7LVjKJbCOMQIf2VdJc4zGuS9U+VpupDiD2jRzKk4+F
YZzKf1DQXsmZ3+18rAPGZ0hTVrF/1CbwD77CHT56NI/tQMVtWzNQB1jTfH6CnCStVOX28bXZksWt
LTG2H2Xe7sX7vSXeggDDU711vmTZ0+H05AJt3X093u3J5McK6PBz2OsTk7o6Kq+in20f38COQtOP
LvJE6GyNkdf30HSo8sehqlUURy1wVqM/IlJP99Y9/6gHXmoquMbvBNTGY5h/P6HsGmH/BMzqTOiJ
/wxBEgyJQXJ6TNxrqw80i+IaelI5QVilefFTsNS8WXF1q8+a8rLT0KqfkEwZglirRVyIIYsFHqlH
eWnGEJSVqAGzyiV5MzU9Ei2TAi9eBP0aFi3ispk+oCEs+3xyS+kettXSVK4ZIgyoIF+SvsXnETav
K2eT6Aa1ITxUCLl/IO8lZnVVWWJCiqtN6t9ix02X9Fq57qJcKLzRzYIZDcSceTxGYmeHvs4eQVZK
YK3n5E6NOUyz8dW2R0FymKQt1RQO8D6VX4VN57EnNuZGskwOqF0jlL3lz8Z3lu8hrSSbrr0sHsz9
jCqH31DxV75/BzgcgEMDS2Vc9HyciizLLMllbTnclbGKeizmA5UMJvxX2i03JCmJd+SPh2TGFNEO
mHk076qR0hSKEzwvRhsewquDSaMk9mRm3WMa1frEGcVPSXBAml5UbYxlz5dDBt0Xw7ItODj4RjMi
1o4aS4pDyDLjXK4+zFva4+p22C0XcBR/w/UwOji66yM0FIRPQ4wUNXiAYbqc1sYD0YukYAp1sAlK
9iz+zkuXpGR5bft7Mi/T3QZpvq5axnEvTwJwU/5RDUpYiZFUURZOjH9nZJezIv0XbRf5+nXTSZWi
ds+4BFly53gRLvjEX8VfAGKgEKS11PqQ+bdtWeRyPmcvepFNbFD2M+ua3vNL46JvdbS+oAPo9klP
Y+mLWOSHPekiO26APqp7oNAWJo0KRWrAqLnG6fxnWb9BTWHaUiks33R8P2FDskmn93Ukbn+TrvEi
3R58mA/iMghYnZimUbn9Cjmq3PTJtUCzJ9FPedzVU4tmGK+QXU9c496NgpLq87k7eFhFAWV/0Dfg
wKkpGtk+o5l3eAPQNYUNc9ysRGjHp26KepEl3c7R0zqsl9BdLrBEY1GVlAvPwqW3LBjo/+W24Yte
RdeNXgu0mTa4apY87rJ5So0h8K2cXUJ/iOU9BcCiFR9DAHgjs26OJW/tmjDWKhgueo7IIK+5DWGC
1wTr/g87MwwwsuXsgb7Gt/5SDsSiVWB1M+zRYkAkJwfDL3ancROIavXmi6LL3e4jPlBKRso/xled
5uFPdTBhQBaIyRHQoNyEcEu22wqexkeNWxOdUMz7jEzX3HdnivFLBQ5BXoYkS/eQRTe8WaUqYkY9
4YkQmUKJXBw73pIq5eEClobBSiUxhYZr0l/x5Qo1Lz1FaYOJ9fiXD3bhvUsEDkpmbr1sv0WlD2OC
cwIqqQZOk2br6mMaojIwpAmxe+Gv/CBCygCcop8mMYMyT7jIKonGVJD72F2JxaFOfW2Z/7pWQXWi
E47kuOjV6jcRy0RN2QZhXhNs8JhovuKSKskRFhwbn/7g5Q1HQXiAnMLjjm25iBGn+j+UIBmJsX3/
7x4uLpTnk/7CXKkmlf927wA87qT9EI8/Lvqn4XuWAuCN50hkEdOzJYogzxuIqw5YXCh1GXOqGCD2
mw7tO5yxiGCOlNzQv8G/TiS3urs+K3cBmU7fJL3JOWLrgki6n/Ty/vwN3YeU8NVemXwglbWb/tCS
nafphRFnw1+H6sn19rAECxLwQj/3nI4ZLWV3Ezgmcl0m7eowULWWWkcW3OXONZgbrn6H5O6WIMWV
ghFwKKjfn6pVlPIDGEisJ8OHxGfVu1eWvRYbfkKhlRMjQuZMZQbiMMRPyDN3Sk44JUrWJobz/Zix
i7Qta9VnHzIyJcdwsokbCie82FLcHnCUL3ZTqmfry6b2QpQjGKzx0QAZVkdWaVRJmcxjHS+N1idx
8FGQeTalH+DIlqlJFPXxKkI252z77y7bSFk4uDFU+y95M8+z+U1nxpyh/ZHumddBo++wDTlMZZ+h
416NlQf5CFptNhqKmsksOPfvyGxXzk7c7Xh/WF5BrjmIsrdn3AF4NZagEq63qOspNXV0eJzT/OW1
okB7Y3u2dOeq/bKNvsBZMxNj4qpyXS7fzaqMfg2RL9BHZxEf1dQSYNXTqYJRrK6EWGaYy/HYgqJG
/gtalzDAY23ZnlarMZca4oDo1vfnc84FjEmZrsHcz+Ku+V6GKYfhL0QBqQid5jqkPlp3zeGBvsUk
+zgL2ZZvmrGLm4u4i9xAq/S3rx+zH2ZMZak8apwyuDFLADMoAQP3vbHGmVOPxXbKVj3Xj0zNysCw
S/DQIc3/QovR6OISMDghU8wSfbo0rjDaHxc6AIgVkOe6FvnOFKYHZELMvOXd3Y/Owhi2QEyz4Qv5
hJxKs86bs07caLHC2ENQCrt1Va4SE/iqli2vW+NNS59doXonD9g588MrVorxdapypJTAf2/C01QR
f7u0HjXmjYll8HJznAbYFdZAsWMa/Y4tCxbrU1bwT/9tznCWZZJMmDkXJ9Vy6/zdoWhJM6tgacvA
NXDl89rxLFOkzUG0yiLZdHYJetxhcUNKu1twEupPBtaVKEeBHihvVVPSfRNB6bIuOZk7m7ow5TLC
nk6Hy25G38DEmDR0ThVMVWqIhFBU0nbtMqqeT2PJ4Qa26YYTmRRXdCasGTTDNnM+7JrRbfUua/Ot
UjlkL5sUzkixc96MpNLIr0sc40XcBc6yR3uYJqywVZVGgsul+4EvrNPLHTNndbpKw+YolxlmcQ1Y
V0Rj9RFI/KPK7qoqjyw90YwehqMtMOCaPBi8r3QLo80SV4+B3RvW8HT2X6/PibZsNAdBWUiU2Hi7
ZRG4w8+bRtEJ9sJLd2GBjTA8tK9/KsbNZscxFHcC6mhoaNtTYgEMnmiA9PfIEu2wBOAvYS32iMfR
fnFOsf4aNfJDQ7zLYF+IImxHGGCG/Dxrn+GN1hrgNOgLv2p6nAJKo1D2y/HwSo7vu0pYILPjt3Ol
1Lo7TZjsqX7xnyjjhY/E4HgLKyq7OPqaXHsA1oRpMOc36mSw0CocHyJmXwiWIOPPyFqV8g1oAoOG
keUAE3Cb08p8PKsOzvwjH8AqpRK6BclV+Nigte1RDNudLQg1mls3sqoGRPFvQTaCNnKPKhLByV1m
KBhwMTkPK8ENF/6X8qMDoEd5x3zVjg4MYy5udtdXfRuqvUIvuWnRn1VmTc3a/EhJNRML6kc01HRd
JSKd1EMLY9u5J4ee0eDPHucTt01nmVMdAOnGGDpUBSfD+nhen4pKV8buy1D2D+w5GbS8EuvOXq1q
CubaLBeRgyS+XjRyBjNYJd41tjLBLPOZW8s09TGFSo1xanLLlTtooWmXqnWHs0sujLXCETbA781r
51xIKraJeVgMNyxEzWe4xwd+2K5bxGH57S9uwwOOWlIFq/m0U/+YQfDJ1o8CNDrq/HE/CWkuABeu
6SqVpYCAsQmOXSC0dj4mlJb+uqaqBGgGK1eZP2FoNFXDvUdwGLwdvTZDBlUKkz/ULzqDo8WCOKM1
KVOECrg6vNtbnf6WGcB76if6qefAt9MIagHoRikHbahMV24DktTDHeaPlKXa7osnUKCdf1KzSHdE
AsPbWcGqF+5m9ZRLrXP0tc8VghzvCRdYMdEEOPxuv5W1O2K2fN/1x/2pVsxoucQO5TMPwhSuDLfv
L+AdytnW4wCp/O26dMrdVRmLzuZpAPwTCIltY9kG9X39vW2LmgMew6DjsgJE1lW35AsQamLJI+yR
OuoybIUyh58SGoabqLI6gjYMUlGw3HAbRWoagGgHJfNOCveXY8w5Fuvd3cmSocabtQ8QP7rx1Iks
l1PfaOv9HTLGZ5RUvSd3mOHsXcwSJLWzISmHV2+kmTjmftXQY+seFz9eZUlhmgs1QqyZvKsYkZsB
u167NeyO3wJG0ycmvliTeC3tgMEEQ28u0gKbFPYuFNtY4uABw+NSSkSgJP0dqzL2Y3uSmu2gDHKT
e6GAu5PN6PKqxBntWU/fzWB87GR0nD7VXCAerUxcwdkKd7ZVy+fqKdSeYwvcebM9sKHeasDoR92h
PyQglEoTg4Wgf0ZbvuklVZOg6HTvcPAsnKYXYp91pcCtklMJh47Bd1mMX3//BRbZyelZbj9Gt8EW
a2eNwlmZrxAn9YxMA2C5UUF+I28fhkyj64DnXH9ystx5WD3Nq3hsJNowzmtw/DJ+V+OZugkN9ZjI
/JWtd8gO0CKdAPTYQaWvLbdUJpSX79OnZhEWXFQ9BIFvUuxGeqBT3c/Ov3JOzh7a8VUnVa7kibuw
y28NoT+EuQcn9LkaVvOL7BzP5FfIlvNA1gU1na/grtz9nmxhXxMt8M/qV1W8zY9hHPKkdYGJBM8t
DgvsXC2TSWpr1T+jPj5JsxSm6/7kQEpCUwupGvKxwMgeGmPaWAqX2l7nLEZiktpZ6mlZ5A8CRUwM
Sw6p4mzNeLNY77KLLRSKMe11gubPdtKA/roGfNFv5cL28Il1gzbIpuby+wYaJq/HuIeuo6nwdylB
EAok12FUY7MQ56UZfT/wSvYDqVohwRzLsToK0uUDtRUgJ7BlMQtCofZjZF6cjFfybYVOPs4URDC8
mFrQTprgwy3P9fuEaNL4W4Q5L/PDm8S7rSIdWTuA/wS2yTas