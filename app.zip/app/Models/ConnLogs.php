<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo3GdA0SKsMNsJy9W/24AJVo0v8ay15UbDQEoB1jLrUUnG9G1PUUUTdSAmRXTRkXRyEZHzzF
plB81Z73d67ZyxZsNRQJA6yiE4/CYl1tC9lyQCougMiNMjX+97eZkz4R9GCqkkL22OgtV/mo1zY4
bcknU1X1WbIiu3b9Qp8V3EJ5D2IIAw49H3RAl8MpTqcKPRPqnQjL+M3DLm0Dfi2M1L74xm966AGR
eRaf24NYNT7LsCMmnR8eiW646JHe+pD8bw9R1J4PjaQ6z5CMnktgZlZfx5LpPq/WT5jZEd/Wzkn9
0fDu7l+4kdsHwraL6lQwt6Me3zDGV8ELdKktUOW5BvutCAE4VpTuPp8kEt98v7smZcQkYLftp+g3
dRTsMisz0EZJXvnvLv+pYK/FRJKg7G/8ObFfB1/kZsUwVWgnlG09fqrZVY/50rPbVBbhLz9+I/wD
DCWlrWoAK7ATFT0CcrSfqh2v4LLH3TMPY6DcL6LcnvxHZwLBIZtnWfM4N6rfv6HJe7HSr4xuBzHQ
kEmdwQQLqveqaCFjb2fHsh3hk2WQigZhW9sJrFl6dzU9AG8zbbZNWBGaIJSaSMz2x2g0MYt4zFI7
o4sgwFzOvqA/zXqCaAdfsa8ROOTdQKSnrWbKzIwXRlGwRSEyVuc1X6+ho6LCSrCdfwliC/ruvnZG
oosx7KwesCzjyyw/goWrAB5ORErJH4691Pi2FrsJUIWBz8Utp+nbTCLSnxy+DidHL+GmI/+nqAsk
+bKFHnniCe/AGAeaQewWipleGe2c39o+3V/YLM6Q03IHH8uhYmA59L66iS9EfyQ+QMhi3qVbVDeq
jMC8M0PSEgABBGrBkvgnXYo5jBGhA6lnCNIbemDOxErTw4zuNxGoBDtHRzsBd5PK19xS9rosLpeZ
3LQ5Tt6ws4TYyd2gLCPthO0Ze0p6+/NyA3I1YyUaqI/GCvh7o6SHAz/m/hJ9zkNRzl5rj3ZhtL/r
koHHH2AZoGB/nBKAMDoiGBQyCUrwieyaAsk3+YZSnS01opwQ9ZN8gefpDZP9mKpBB0Vz4E53ncdf
boaumTeJXEWYiO6966UpnS1YkMiZHcYX9Ocfn5tT2yMo5VjSKMbsOMPnn/bjDTdk2TrtNKsc6rNg
BUGw2TmdrcPwDiXNNeKdLI43W2XGRCNA6yWh05KEuJJ3+huk8ABl2JvtPPlqttrJ8pxhBeGEQHwe
zaHhcn1v3n0KUY9usgsQWht5fodwkF2AftUpabPDZ9nBILDSAqtd2Dq0zrXAVH1j+aK6oBKspz/m
+oQP2aWi/Cq8Bgmo89FuplK+OOs6vnmFqGix05kBGwxKRUAg9Vy4ivdOrHuY3GCwI5jywyKMW94S
fedItU2cnUsDonzHRYHYlpkNjf49KJsTyiCVqdaWfPaf0/nWlpJBMMIGBm/ZzoeCG3kD7+Em3qW+
H8BMmCjX7MLHXtDoODVcwoyJSEKAPUgEJRwuRZxfJE+Xx/DErL+TWOGfmIJiS3X82U25+DhfUBxt
c6BCgYgUE8cL7NFpVwqaGlziwAi+JOTjGuBYqfosPJAFZnTaiiwxtbGdE+E1RNzed7s8cSrDCqo6
vfaHJmn74O7G3pViOBxaJH+77/uTiht0Z4Pc7nJrKgUt2X5inty78EQlMbXmV7k/u7CkD6t+jIJ6
Jt2aCTg5URLMABFjpbNEV3LHQEwyMXJ2clBI+42dfi6SLXCwFoF1RED85TCG7gyoJfsM23jdBGJn
Aq+7wpatTYGQHx+fkA7i2LPmfX0IqigxKEgAsrhVL5PmXGbkDoV3ZxjWMgHytVFOXfqOnR38YQ5O
68Z0qDEZQl/gasPUBOHxv6Ped/JeW/5DthCDa3vEwn5MIKJXrb5wMONTX9jOGHiut0dUOCoy10s/
lPb8pttV6yQZ068QMA1pNos1qMXFGfxcNbPT2MtR6vvWd6ARSzJLvCnsf6haO3/vUQzLkYE/OFs7
BJN8LaWxXKHwebVRg3xPXs6VyYFrien74I7MVa3rLLGag/3uNLahEOSuH8X+EGBeinpqrGnviQ1E
aKVf01yJVwchFK6nfQ5x5TCPMWHKNwbzAtl9h2fZztTHlIgwFkQ7tpKEWnFa2NGBvuU8a+/QFb7W
q9QZCRyX6wGQWm9pfLNmW2NdNCc8DsfgX0k3Lv60Am/sGMKcub16/I4BxsWnUkAQWpTTWHxbV+gK
JkN2tYOPIrRdT9eIbiXMHeoede7uivglZfUXiC4QX+x5lT0pZFUmD2NxJqVfH+6FbFo2Bo8Lcbj4
PXpBhypjotYZcG0N+11cwzBWynhjhK91uXTRnk7weGCD0V7pvm0R4EmIM+sFDOila06R7iVhdzL7
BVSO02L46vDPnPnINmhTa7VmTg0Ev0AYIDFMXVHQFyFotajrhMIyV8oHIimJ+TtTaDXhSr2iFTgH
zjr416ZpAHWvbdF1GZeAjq6GRTJrNc0icVYKiPd3ZXRdE4+nltXS3lMO1xsCZCuwnjxGPzuWkO0V
ESzsTa/wMvNRjI3iTc/kg+VWUR6DFskuOlWWb7veu9EgA0KoJMoBKRn3mc5chnS9XuVwNjgpaRS/
1+vfPmL6cKOQitbwKwqW1YkKy8mzFqVC6omezvl5EgbgWGVksq1nSt/m/5+eTT6YTmO0+8crHkCC
maD05WPNNz2BY8bpAy5i1z2a3P0u5CRgznk9NqWafebCs4COrh2UPVjRXCSX56f/A8dUr1cE/g1v
ILZ5LKgQk3tpJYQxBHdUVQ7z8ijSqBT7IEzW9pfd5xIFzFHtEumAjDz1PPlDENXn8TszqECtcTOr
RVycMDykr8wxQ4Sme4R5IAEP7nQL846oBfMUPsq9C3EsbWUmZO7lZlauTeRZtek/TEQwizHfXfYj
SIdVM6/jacge3QrnCgitUsucofjJEUzFMkMUSabZhgwVq1kwpcWnbx0MkVRtjBNvKm8kUqc/hc2y
AcgvotBV4naZhY//bQ62lbT/Vrl9fTDEyDe8oy53E/un+iUqha+PXNfmZ1ZEhO5QzPZHVH9/saMM
XYeVuQvLsPkVusxf7fUthCm2GBHIHLU4Obr/6M23ctbERqb2Caccq1RqP2vqr67yz45git/eSt8h
kJDRNd/yQucRk4PydmPlcsZwLP+N78BYy1qrQklv5nVikmgKVIfKrK9Pj6WUYH8J2VPLndE3NhaZ
FfEjFs/2uc3lcErIiqHsvU3z06iGJckBomZulWUDMR7PPD6TvvZ11KYp1H+Ve75muyIVLyzlJnrs
VdF+Yb0qp6iBt4yL3WKBp6qHeEPv6QfMTyrZAmKtGYTsuBxmAPZJPnFN2QGnHUKlKMeLwjEiXAA+
3oEVMnKtrkUTrvEndZ/rRwFdgKg9b9WM544xObnCkwcgOtsJuDb6EJ5ycHAd9niIySDUer60hmGa
rhecrfNm30eHYdjMbs/Iv4ZxHV/QcXZ5EsX5IkoH+NiM+fqDEzPF1VUeZP1HE/yD6n7LLKqkwtj3
y12culo7DL9a0nunwGS4uHEMx0XEo+vXLebJ5JUPHz+YqgjC7qiNT4SfOvpCP6qzYkGmSjNX0ez2
eNwMZrakfzbaiisdXb5biJL94Uc4vvSWqFVn/WDFi5DP88zEvh3dA2DOnI+a28qWchN0erh+1O3H
ou2vNN+CLxeVjS4r7c5QS8ydHDdt+85M+eEPnAUvQ3Kmvc6/nbigNXtEHY/1ncXBFmYXZVj5Uffd
PlzvCGlFwboqR3yTbKiuXLif56WaXIuE9OESq0QtMrmQEZALL+KLemrcSUef5WK6Em4GvTgy565d
XVcOvQrZu72Gm0bPXcZtJtqI2ysAXivmbJ5nebbX5Hd3vjiljeRUq5NE2sy8hIgkbvFBXXPQm/oN
UahNA6+vUiCarHmqX31DERiFqUu2Knu9qGnsY344vkjZk7nVvoOK3hcQcv8xyQsvjGen9eE/GKnT
g6yBqQs2V/cNlu7aRzuzvAI0V8RiXQ99LdPUjvKaDwRE+SdbOGQDWDcvk/zg4KeDfdhggLW7hz/U
Ek+KeH/kOgilEVbiINyCG/7IJiS6krRoAN3a2oqY86nXJDLh5OP+XeRhbIcDYgM3v9ZETet6xe/a
O5XKyvbnVVIivGS64jNL2mvA2QR/GMiVSVZCrWGPXKX065943uFRD5cfawsuRfHmn0nhs4GYfuip
J1ABI/cdIh5lFvncEBV0QtEiazUCS60oHNYkal5fUljlDdmIt5ks7ByJoxaIBTL9aNQEKkqc0bmd
14FUg+iv586mJwe/v/6ZIBo0VLKbGab6vvbVHtpdJzX2FwyEAzl0t8pE7PuqLE3JLV9eOCC/XjTV
H9LkLb7KmJ4BiEgeMmHQnHhPRqYh2oLNR+0WdPkXoxS3NnmrrO90aXyNJ1BrnJyspJwJvCTLsCz3
LgfI3y7++qc8fw/nRqV9MLS/I0Rojsxa38clnzQMAZqXC0+82VfuJrITImN5x6PzgjgJYPBN/Fw0
OWBeOvziVAhjUmZI9LTW7zmLlflmDIe0TVDTWTnI9VS1Hf9ah7kkcUUJXg6x/AkeB63KQ9mg2dTp
XwlXJFJHhboLopYtRoh6NrEsZ29AYQMBpr445mXF0QKG89/xJZeOfx5PTDI/dHhD6ONEcotletlH
S+te2+j577C5bq+EJ39gMWewWbKxbuatbcfkvYnmCPg3n1ya50rvmCXVH2HtAjF7O5ZDyC7KiYeH
qei1dHpMVERcgVuGxPcKQYYj9etz26mNz3OmSmPktkzcBHgMWJa8r6PaMwxP+PeY1FVty7DZzNYq
EtupbWEdIUy/mNjDW81veAisGNwespVPcBHs4ypWhcBhvMsmpUwLEwGe07tfKIaG0gq9a5fWC0m4
9jWl9qcqj7HaTVX3oz85YOHut7xkWyUexWMoa1lpa2q/+xYq2GVqRnuPYtzZQO2BKSjmKAkQK9AY
vYgb0X4GKW2rg42INNGsyu00NmS8JBuuXwb3TaP2+//Ff/8UEgt86h3thmAsFaYQ+IlYIgFJ3tPn
IC2GNWH59jV5/FgehDR1mNhW9NPZ022b3dmG9WW5xnlvzLkoJKan084C9fe7dxtuYlJAVele+Tb4
he2bdb+GEg+tTK0P8kIoIN+mEXB3Xy8KmLJgtfBFbESz99+/MxMe7PUx4lf36L30cGbwCuPo/i9k
KOFkIljSdVK4CjBIqGtaSVZLGF5Y/xC+72/GqT/LpGcY9KKPLphvZpfblvpaqqOT2/vjwI69QSEx
7XBEAjwpy3MCaIjpfuzlmy1kpk6yWITsjJeNewRFhYhKirE92Oq6NeBou9sJ7FnTekCDM2xDeTkI
vhe7Hgt5qBKhvVld7dqjg/W9eoZjeg7uOOfKEwEVXW14HJR8vVrpFxnd8XUkBcLrbA0VxvoWKXzT
f/IJIyV45jTHzvGI6a0HMerDQltMb2jzctEvHQgHtuDkp61yBgGgEP9639k9LmxYA/HghRvD1Hch
aCjAXwSIlO+YDox3nROeuR1rw2ujZqeQ4ZxiE2FA2YwnRhY8AiPZx3VClND+OPd6l9VO7ucVVkyh
AWlG/GKCVAePd33J2ufcFlCtWDrzm215BBM+tCDvChUnqwC4oh6GtF1v6iS8ASKerj8GWOJ6b0ox
R/6YdCZq9dKz8ARpFH8VEhyRMivF7oQOrw+k4rqZgLYo32iuc+IVCEZkG1UkftNAqOvF/uqrXW+m
hJ45GJue9yHpFW0Vfq2Dxu9wYf/oykzbO11GA/KawI16k7RWY+RJ2sFldw5Dzcx+TilKZwPjBqsu
NJ2QtHFg+B8YTsVlTpNQck77q0QVe+shPcJU+tw//p1DjgT0rYOnyxBNnxnS3uT1H4P8KJf7aitd
KPG/EF7V8n30MKe1OAZnLfkEY3QFc4WEgWW46hWpQpC8/q68Zz8NwrtWHKnoR3+WKxnO/srRW8GJ
Aon5QIcHuKRISo7ETfJdqc7MO9n+cRaNdzMsABgM4GOYIlLzVsnsCoRfiOIad88/s3WMtWtRym7w
hBcD2g3o8HYIk88oqiMj11xikp+nSq6SCgXSY0BAjQkqopL4dfJkiSG1g047HEnK2y22ReI7aiXS
U/e4KtvV+uTmMe5B75LTLWutHXpTV6cnxp4075pqxbEYqkN1X2uso+mCiqxHNnx9JqRrQ7mdTpFi
GQmf6THuDwlfL2nLAq6zf9WLe4R9w9nI90HvBGSIKKHcL8xNBZWH1keRqAYDG0ak6NZpVGWN9zml
p7c69X9NphnWm9AgPDDs1nhp2wtRoi/l+ZR9AFFgF/OJc7A9MyXz8hKgx6SPrNWcuQj9xnSr3Ldb
z+Ac1wzoP14L5mquMcsUyUAQ2ZT7oBH2B8MpyULW9ENYDUGCadWBAksDZIGMyitDX1n2yq0vERu/
b+o0wwh/sMZehDAoUWoD48xGpBN3KswJFOjyBtoYXtMP4ivJpieLeR7rC9iLo9YuSEN4TBMyxXK6
c6aTFTS0mmPGizpfxY9k/PiQjQ46dmeeHAgbdUaOWF89m2IuCRP2gS4vma7/oyhaMZJ+/3XJrRlj
n3xi5mHMRpd5PxDdcBpMwC93n5WMp+PmhH0o4xEvAzCY6XXxWnQt6lztmHsHn5cL4PjpMU/MSPM5
ZV+AAtrGGo2I6UpufsxftgArWwubXy7opy1XaWfEK7vTCJO3Im26MtO7IdLRyBmQSBLSWzbi8r2P
j46OBzdi7SamRC43Ad9nqWhm98x+kR0h8q8LQTy/5d3FXS94OZWCm7xKR3DslJ8Hw6mZvlBPAqm0
BvrQkqL01cJkG28lyC3rk8EKdbRTMdNQ+p+nHtnHMLXWKrHrCE+UIZ7NY5lpp4onDa8iHh8+sCar
Dg3JAjzdvTajJIVFKJxY79Geim18VY44/r/LLOS96trOwp8inm+1LZzoXazMyEGP6K1YIYvYdLeN
5WhXNWOg3JitI5rE/mkMFr+q1oS/J2AgsnbwTK2o9XgnKM4nPjqM9yzvuKhH2QqQaREwqhTdrlh9
vEamq+JlcruE/1kDgqMWnz84H6TJxMzck4h+Kg+11w5Tal/tFHJvrIV874+qjQR9kXdqcnEUCpat
UzntKPEyXQdtg6IT+RdN+hCrFO8gykospECPZD/vQW38pgNAq1nJu7P7Wa+MFyFxIzsJfMYeTxdK
UA4kWGi+utD8PodOAGP/sRHQC8pRHiYWTtUw0FaHG+kJW5YeuttuzPnBO+wPvA0o5m8T03ir3EFD
QaeaIuqBBDVrwsSGdwc/zCQjKDuD6Nd+WMHBa2ZVqBOhZjLPrWqV50+sW7BwwVxuG8XcygL/EwyE
ZMpTxHLQc/FZ6exNT0q/6HH+9T2VtBGBm1it+az169s66gCQh2L0hAPXYUvhhfK80eaWGriL0zpS
Q2CLEX6sXfJghNectEGzY+gPc/d3222H4gl54xlqg9x0SJLHX3+xoKPAOkUGmHu5VSGexE1qNfye
g9K/eUnH01S8ea/TtULKB3cH2YevHTDqAbMHrw/1oIKrls9f5WqpB8lG6xpN3BHrkREonPkF0aH8
fSMao4JL9y+uHxLTqwGftd7IWcKklSoHkPANwjorXv4rsjsE1NyRMNX/DZqXmNBjgd9hQWN1IzND
zKkIzOs2nkeG3z+/yBQrFKlgMTWCDF14aQdGNFMCXo9QQu7NXCMi6O17m2HZI/fXw4T2L8HSzFTF
/G3TP4aOAG1t9pZ45eqNL2SD5hW+SSvqt5bWBDiScIILYbYTz6opC/3JJubPhftcr8e3lvuxyBp0
cXjL2Z3cGxKJwf1PEA36dR/TDOx59sS9pxH8P98N6ytqvZ81hW0+KWx7nX2ZqlrR7yEfxoGxeIBO
PjS+PK84zlFY2m9n4/FKaxAQbtDwu/qAFWjs7uBoeddQ58ITLun1sQGdOoVgOtMFK2DGBFQfbjuA
JLegJzLAFH+ZHcrZ0Z6lgbebkbRWyKgaHxSJRrVoc2Sv6bp58AeYK4/Xt/G4WbGS/+jTwTdNv5QE
dXXGALujDpuBBnUSRmVsdsNn2B7RNa5Q4VAMarOKYcbToB+b/zXgftL5Rgr44UV6sFqkK3VyqOrY
L/yriKpd1oRYRMOA1A1LknndLxmDhdmzxorGN+MLtzpxSyPCV2WzrGnJVnUxKg2i5PRs8c6EnMGj
KXcSMc9zy9hOhVvIjT6HwDtFbAJQWDdazJrDlUQK8dj/dVszRANRo85Jb+HhF/g1zcJvp1Lka/x6
FTsf4EhlQ0sebI9ke3qlIbcAXIdfAZvpwQGIb66RHJR1QaZyrPi5KS/nAyzVlAsbji5HrSm/Wnai
yV+aKhLLCl9G443VU/IDaTCX5Wos1EOt7346ze//frl4y4loFLhy5RtnHC/ZZ0hhGCt7HAj1XX/s
h6gVAawKXdqKqfHNjMuL96XmmemSXTzi9otOJjtWFdLeJgz7J3SVTss6ifAIT6XKBkWQJsfEMU8t
uRXR8atNVY0NXjedxsNIa5SA0eIfZ7kryX5bekUqhqG7n4Q8HCYtfZlNRzZb5WUeR6YTcjejbJNX
8PUcuqCUDeKcH/8sZE7oN7i1mxjPMYUUi/jaGEslaFsCbW18Jp99wiKEYXETLPuh7gcGlZPnE14R
dVJAbwv/i2U1f84OZccLwfGQLO6WolriUBvi7MEIMeb/h0LxuwfgsguDujzXvpiPabCAGZI9Nxj1
o7YzJUxfCodWkrA5WYCPdQISPfuF9klkZQmkJL4Jfumfb7zMJgpP8Xofd4C+DsB6ipakiTa=