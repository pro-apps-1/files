<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyDz9nHQ39nR8vAoD+fuuimFz2kE8RYyBSIB44oT1exNDjUWhU6K6qqtHWfaeLrruZQn5hte
4WtlfgxQeWlZYTw+mFaZYZ8qh1+9WbPN5QnS5rK4CBQ+nwn4+eH+tTQ6K65/QV/X81Cf7/a75B2C
Hd1gLYEr0BzZKCUt1Tcuv+lXqZs0ImT42N2/WbJ7rNpa/faj5kTxnZhQ3RQzmLu2ziRihxIBrAui
PDPLJc5NnAj5zj+Rq0gVSSdP7DPCPKIUuyOwjzn2WgoPKlaAU/XlrUmuabQKQpMvGkPJ0i3uv9LR
27GgNV/GZMBVvQbB509CHuVW26uIUkMQBPUMyq9nme2myh48mrICLHuFyBwGiFEKnap2V5MeWua3
VCmBC3I9OwVutUqSJAYdY3OiT5QegVE0EWdW2H4a2OKCyEygPe7G2EmdUAGXNuFNlNrNylijg9gn
m9cQzrCgaG5m/C18iym7pL86xatuKrKRmkI5XmHMEZwYRM74p3+140mBw5ScZl/k7RZrh7jAqtDS
pynOfaaakrX40yxyVDZHbmpgsbZ4WYYdCeCegkgmRVIM46HJYaRuQXoEUWDJV54KyPvbQHJywRuu
0z5k8GtA+fnXE798YsUdRU87Q8xdyGsMJUp3ADHHFXzs5HD5wv4NXfMBjTU7BLEjWdF5KWfwpvQn
Q967xdIo6PKAVKNwGlVRT9qHemwOK7+VzjXVqHQY2r98LXKzXFBFPGO8/lxHiY3XR/HrzDOHuCA1
oRpNgGqcpeAYySkd5fzPyYOllVl0M6H7wFs7Zu7/3ENWx8MkpnupZbY8uQtce/8NQQh6n7cHrl2J
W1RkUl/WIvh93f887dbF2yPihLoLjEtQp3lXiq7NqVy1Y3f3FrFtKsjB18Ze+Ge8B05zcIAGT6+0
5r0+ruzZOqtaEhQ8GkJIAx0YmA+SDxtMA5wGQhWdbKkymfGOUCxtruR07OEYGXSdE1kUW2ajhFvQ
gKZtTBKk5mXGl/tYWsN/uxwi3gOAqORxqPWZb2hee+9efokIjftXuVimwhwBI7EAGdG6CUJodpUv
PCQKq4ILDiIUGjE41Bm84M5yhSoU5Vy6J1awFpLcC+6/wVT89h6pu6o2Vgnma6rkXDlYhE1xRpaq
hw3I2ggPpzz+Wr1AY0f6D20EHGHmzQkDu2NEt8PX9iw7rV6lxuGbdBtTv6yKGht7aCCoEWHV/8Qk
W6LGGdDIh9gvj5vclhQqK5BzBxc9M1G8HDbMIf7qA3vbHLDz/Hp2P/iW2fpKv9KruNVio2YYLHAH
hIqlGzZrZVbeX9clFJIS6CAyHMwv3s5iKtklXfFDgOtDE4zMwTv1dt7ZJ9zHCE6gVmKv6dDWqw49
PoXra/uP5dJAN6SQlEfFWorzcvlFiRq99P/WQ2xVSABZUKlcZC5AliEU8fB+ogy6DPYr/IOIvLBw
zgIMHQL9UlR/8HMbmXUHxkvgoTnDeg9F9auDoUtdScvHE4e5cddwkCmzGMIHdIa0epFQjpCRN/ra
zdPqXm0nbXhhAaW1z5ZkwO2dol/1AZB5+iQnvEWLQCUChYiJxpW9u0ozc9fzUMZU7fDkUy2qkujV
Q4jbe4DUCwhuij+5UOEg9NV4G9Yv/4dA77V+jKNdrOuBuJOqs8fxREVp8IlOpxKYUofE8PzI7Rqb
U8B/COqJzLZCMJv0PxSOqF/s7nPOLE0BL0rSnJEvY5oJnQvK3IaRZoTX3zjcvmFnV4frGpygtYjH
DkcTJB5pUgWtqfCkVgPUvKkJ6Q13FvfDsnCpojFbONWlzzZRvRuvJzjdqZ6JMPWYKPYx3wfTwsOU
GiJF4QjYj7rJYk7LIR/DYavwmzeEveri4oVd/GmI6wUKcN31uT0iWaeO3uDnt4n2IktAFKMZ8vn2
ATK5FTM+gNybvSc2oWXdYip+4kXU0tAxsN69jo/ZMEn4SPkIKIKMQP/P69zernp3yp+9xM/J8/pR
4SsP3Q0VKYdnLf+6poabuOmcUhbOmXmvX6ADgFbCO4YsKZjYidizP0fHJ1KYqsID7QcTYqZjp8YP
JZibGsMDHIwCnvePL18jji5IQL2XRU7HPIYiHGcxV6tE/OYPsl8l+GygfSfQuPglgmx7epyZoBJ8
6XkPykJV2ht9vJNWDf+OrLF3vBpt3gSqq7kdoNk/IluRFyeP3JTnWnnxvqPzhWgFxMX9FII1Yw/q
wKGFlmDk+Jkzf1iBJPJuR5ulmEVgTycODeFDw/7eKJ4nw8a2I3Gzw0DIWhFtX9HaNTXUKJwJu7In
9j55sVTkGKfvgi4WWC8F3wy4Zu17ordmTkVXGaVARwsDvIrPxZ6mxerwuiusLD1pvZRZYsMunseb
kbzYbYZgYF0A4OLtb5u0/dmczfWo+SDT/1hVNo1cwkpQcosf+9qOc8B5M96NNZtw/6KWzXB5rcJ2
fmA0/v+zPmjtXSSJChyg84+RTeUDSD9EAWhcKE9HwNs2pMRQXUojQIdwhZa7zU7pErSV95nRy3BE
GfTC0hVOfRtrKI5XgdKseVKhqF7DM5WsBPi0ZMoMJbiXC4wGsg72LE4SuOk44M9jHNUPssGAVzte
zzsZ6Ec/uRnkwrEPM5/8y51HOJJIhwRT/q4nUN9PaFTP0dRVimWY6EBu2cURUPtk5YcS1bRvgMEE
uLX5exogaZZ2sgARLi5sIHu24MFNhFx00qxiWQf5HZTFh3CdsASFXdMG8/JiFnsz5AeVtSzHH4kC
PK9A/vPb/xlWi6Aw84jKE6oWnXVPnm6XFkIQSU5SZujjqc/GX/SOyjDdUNMIkTLVqJqMnfqQoNfB
he2zkaCnUKxnQuKZVnky4QmIDsNm6XNyqTKJSeV97OdZD+eYhsjP7Cx43j6sLp/+QGjkCkRpOC/O
Vn7AmVpqRZZ22i8Y9wS1t4bu1e/p1SxV2IkHaDjdLqbqa18rc+JOe6RC1lcjuq3Jyt3DEI8jrx7E
WKJUEez6DNWA7wt+Zh7Hyzw9bWRzTa85jKD5ftU+m9D3+4wtt0BvpbaIO/Y67DnbX4yKxgZiRepL
BfSINMlMG4xStLhpLXnz8a4JYxG97EnHggO6MX3duxp99aMgJX7sJLkvGTk+yL6/OunqV4x6vGan
ZD8gEm31oMr8JV1LDaulQUpnqcRBuw6tMRWx2vUENVCYmGhGwGDS7V6boH8dJtzP2acTnlKxQwFG
SH62KuaeIumvuDHiSIbaTcKcs7g9e4LD/k0VQWryIyA5+A4n3ll1f/On6WAPMcYhEiRswnRYBx9a
9eqaVwv7fKRPaDUzsZxirX9yGrBE+94xIM7gbXFBAR3qfY+5Tm8Hmeg76CRKqOQ8ZHMCVCQe+Os2
yKv2N9ySa510i/KbIZP7/KyeSF9gZTEPxVeba/TzGFehO8E7RzczFx9bAbn7MJElm5ZinawKnG3+
JbuL9bimwP/cxa30CLK/vcOMJ0hzBm6T8XY3guO8w06rUC0JISICHcomW8dFLfJf3/QMfWD6OMhF
qzh88V8uz2Hy8dVwAK1AtNIvTLt7J/zHg60QAF6xw7vzPubC16MJl+OmaQvjgVdVCufyi2fZsCRL
NMsS65E3pZi2aQlK8L5uK+0Ac03dqEYxTpt7mOvlGcyHy1UCksyuQM+4DDISoarOnmuTTIEGvXx1
gBvxEWfPOcmD1ZW8x0PJk0csoB0i3dU4BFIioMdX2cwm5+z6FNLZLqtFbaP+qr9cxy1UCSgBAcJ6
dsAFTxOp9ZbHaRoXukVrJPUM82JC/etp5mAyIeByKDAuX0qHCNVs82O1dpGr2odaz3YM0m7XRi2j
bMrHymZAXQXgPJHVMK+TNFgE3DYZ6T5AtiE7lBvJjVQM4nsC1HbEtC8f8DiR1IRwUtNrZkSgwzNt
2n8FXuEnTgI9PQgSeanwQIjk2yK5Pw4agch/OOXFZdnm/C7MY9xlNbrUR2AV32KcjIq2uaQsMc2D
/liffPWdyzgN3TnkFSM+dVAlQnAJ3MeA3b3E3HZGKhtd3Hzff6d2XzN/+DlDHvyCDiaHpadNpBME
am/LUDLR3V/fvhyhYo+4e2ARoZq8O6YK9Mt02V7xcnZOakPSO6Cpo/YFigleT3lcuskmcpq1JKwp
YvO2tm0rlzqFa+tYHGsWh4S7XplGV4My9XnqoNmr5DiXt/uA/kwpjA6CD21ASDD30RyllbrS+zDm
0SBcU4uldQ9aHryLEQkxqMiLCpDlXbR6c/SNloUfHUI/9S9dvzkL4plYRYycFoM+TRksd/ljg3gf
DHdplN9mRpXRdBoOzC/o3J1qiw67LTrmjPk4BWhtbpsrCXY4Se5DMrK0i/xkRcC5Q7Z2EiR00ZKj
cGnNpbhF8EEUvRA6Bh1orL9mSFz6OyZDy+eMzpie3nH1+9NBIEDJEnUi0c4DPcEar76MVmSm0TZy
79jzKX59hGtqSBvFg4fuQYUIFTck99AW3XmSllLwoE0n8kQYwv4eUmADaQyX+tu5KWVfrgCNR/+I
hT2XKMOqdGNVY8TQBX70geos5uPzIx2sYaBQ8WuJHjYZCgiuzfgFEnpaegrrshcrQYHLvL5kuOJ3
iDLV0Vqlk7L/Q39cMtdZ50t94rU3X9BbYVnaytIEV2jCUaA7bnXvnjjSWBLiwNznhxwhD+EOh/Cp
tOF4tMO5N9YSaSJ3Z3RoNzBBTzB2Ms1iXXxCYnq2EwAzxKrbllamDyPbwpC7QNfHAwYaaucDNVIT
d21yAvzeqPd9ih87vvvp+SlTqv2m/Yl3TUC3yl5bK3hUko0Vag8dQ/pbX5yRUE81IdlYagEyUHED
/LaMAwCIRg8ei/IU9AVh18u+U4yCn1ZOjSDO4jlPbT6yGDyZ6Y/RBFyFIA+MnfX60UmOrNLfxC9R
yCwCITitrOcKcriVUWoaQR1kz5R4v/hdA7CvgpfGeCHFJxzbGbxj0qHxBMJ97dqNZl8e6PW8RrvE
lUrN8G0NPXDeDs6JxJbBSEykFrxUwHk2pdEo3Ht3/qYqBTPXNnu8wjDkUkzB+/QOKbR3OAAnUJPS
KJ83Z5MUM/q62c3f2rfyzm8rkQtPyHWbXL6s3pAapLy5JPIBnBqZiUMzB1NhvnDdNQ62Y182v54W
Juh9yJuCEOuF6wytQPPcumT71PSENb9gEDtNeGiUJzOl36N+tKB8D8qBYQftcEBatyTzalnNBCWY
/0tmRStvVnCDL4Y0Tc5WJ+NjfC4Ax6X5LBQ7OhK7ShPnbLm8IeuFk8i4Jw95AvwEzrtvercn2pHr
SKg0ebMBlV5G3QaAnInMU6/xSejEmQksFk2no4T/Pk+GZ0F/GAZLiX6kDeQyQVQndN1KsTL9m7kH
/DxosWkf3N1W/4BK7k/ZHh8rAuNOFuDxkQTa8afrWLg1UbMZfXRDslXSEAj98GYEwkotufyZ3J2Q
unYwvcYTvTk+t2glZoha1/BXo8sUGoTxQ8H5iO2VSV3ylsm2JWCMC1OrzskDDPe9kbSSudjSrUrS
R4gax+WkIQelV9cENjphZSK33it13XjCNnGG2mUrcOgxGb4CaOupV8SgT+GYu02Ogf/Gj/dBby4u
aje/P4dSHNVVBe2a2nYRlAWYCXFasKsgfx2kcBO4Q7UVbSzrcLrJR1wXwokDTvKV3+/iqseaPqmP
Bjk2amgjQj3tyILcHfDl14CaGpVIUrl/j03H/zZ4G5Bp1goy0iwez79BoGEI2yiRrKmzvQDg2o2W
HATMkwJkLq3pUguBVugQT2202DBfmn5owdLRmHs+AjcSYT9oTP67SbSheSt2UOkPR5Dfs58fLTBx
Avcw4IHNYq231QiWWCAHspEgtrHHwXfQBtrs7PkSmwRk9Jj6L9WAUtvbBELHrRuBdKjceBLtPp/Z
wXbYsvevKj19/vGCJBd6Hmdp7lT77MKsdeVH5AYOQ7Jy38nZ33aNyRLcTGjcTuJUK+8cD7zQGX0g
Imv4J2mthdye6TUDNmahMJTdporX8K5var1G+cqxaDE6w/84DoAU9r1h5R/vqpDf+WSf14ZbwtrY
MGy6f28uaKSECbg0h2GppFeNK+iNjFJJXfUeuW+pN+kZ++i3JHHcRfM2b2kUH7Ril5Qr1mpgP5tb
pOqn9z6boZKB2rdFA7HTqcsj/1McYbEm1E2MbdrDMZfQPMPv9bz45fuIQzALqQtF8wRR7HM2jbKg
b/LYjw23q/lgACOpPkUPuyh9j3wcpJMI/1RhYp2vL1h5WCtNZM0+bBmS8g6zZYiPHus9Y8wIikv0
0bKkSRhoT5ljlVWtCHCQaYKYbJ704lXWUqdnO1qNXduf3s1MpFAH73TGr3Y0D7J0SGj2gqtwR+uD
3KqKz/eGPAMs9deZ6NfU2gjGupcWBAUGp6TRauYKGIdv3cqo1Du32CrSqT6yzQk+ES9w4PnQdr8P
dr5vfSPbORmBbvk3pDXc1jGfumKGH2vudZqcxyaGWbKCe2LEspPPbBjppervXwtJLo2A+rjePc2+
3zBjOaIzA3RBt4Y0nW1g71R8wVHgme4V1IrUYyXR6N/7/L/QpAZ1ZlNN9e2TR0QMMnbU463Fy3aI
UaYU1zS4Pgg/YgBY0NyIUL5x7YN7WXYYbGYUWJO3a+I3jCxuLBbPo97bpz8rVawme8GtNM98X6Ys
rTTRAJMWxblJq0O7BAj7MFar4uX193x4Idjcxfn9WTeFLPCVSFZvjPwEj0kOvmHKzQY5TGd2WzlZ
4tBDHAttkOeBvjTjzdcD97g5yZuNUXvYdh2iWPaTVs03h92hxY7Zcezf5YhiRWtr81YOly9nSM9E
mabCf31omSOalzj2+LgS+X9WZK2zd1Aq5YZeRCmhpqziXFi7pumEszC+TzeC66pHdmRjBfH0sbvo
cgroFX1lTN1eNGso5CpyvRdSt72IqP9IW4VhSJZYQJVHuGaB5OiauoHkdtXmI4Dd3Ve+kMK40eje
KuITuUAdJShy7WhJ0VlVTHy+lGEKK4d9vDEtAfGbYrM705iis2KDRm7yq+8SogvEiFfRY9zHwvQn
oOYdxv3lVJOlQ07gPQteKdlKHs6Pu2n935ijsuhjQkF0x64YevMS3ve3z+g0Y+PVdQvsZ6Rqu+OK
NSqWj8gTVWn/5LGSSt5eY51HWlHBPGi+SH9ytONHwqc+9jA0Gr5QlLNF2NalhVa9Yra2EDjJJ8tq
mU05P8amUnm79vXHl12IMo3bzJ3423So4mSVr3U8RBOMKEO1wJlW5HyelT7MIsjUzs9Pc809ax3R
TFL3kp2I7u92J9LLyPutlRmCmSWRXpBf2/lscxVDIpr7E6yoqt/oAVONMKf2cBYvyeFvfB0dzlO7
5B3OopQSsIpPl9IbjWzD86wbFcr4Apwz5kdrFz33aTR5tVOj83kfEGweUgCG3KdlOm0IDlbruxng
3x36es3gxK01WmRIAcsAs5d2IJ2/WGSYWgggqE4qRzOnInCTEhF3gM1HNHa97FlijnYJ/Dbc6Mo9
EbS7M8dMielQWimd+1xlgo51l/ZpUybecvx756ddykOFCquD0HXdRw1rIB3WLMG0+QiuKV1sIrFB
Y4H7oOmSHW0uuaNYpeyXJYytCk0SFOI9f4hiNzoIpZOL9AjiNNMTomhopbJSWIsC14skSoCq0U1D
OSHTbf2Bn8bX05OHgBe93Prt9nrfkZeWg2qpcEKbhiCwrhJe9N9Hq402j2Cpk0nyeCLhMkdvQMUD
QRphQBxKXcL0/p7rhx2QO97TnHpG8zqGiHK1rEdQCHAsCWuZVC5Nf476Bh9Q+CbFlSvHvAvk394n
dJC6arxFqOBsirVePt1Jj39O+5xfBxZL1J9LcmF/uwr4PvRXaHPB4dWpGW0Pnlsr2K3tijJm2Iik
FGQQ3Q+2GSvM9wrKqotEwa/IotiFOiVLby3/hfWP8WI//3aLihOMEUt9N5sAo92DgD2wT86wE1w/
ZLnh6YG5L/nOuvAXPFdUc3jVrKQ23dMnCASMTeThDDgVrNOr8X/MxxlBqeEniyoNYds2o2O+l80K
YQX91sDKteb6LKsh6Tk0AXSEKEhcmAA0i/ABetNAlagC2HT2iYYvLCuJUgybnpbao9K9xIPfxB0D
msrwBObmptHEuRZGxp6IrMk6BcJlKkbQt5hs7s9FvpRchbauRWdsYCczBC7nKWQLoP9AArN/eLfn
JKNmfT1yW336vRWd6hbQ7d99MrKPKMpDnmlCafDGy+88huSz1KOzJGzkiLjOrVBPRbyLE6ECS+ei
ivnWv4FU8MbShvWUSsdyBY5H1qp1v+ilB974jzrTfcDbGjMVtrlFwchlOnnk+flyug777RFBPrv4
fZgjBId/dTu0l9OYS62MyQVyG5hAMJfQWcO0/af02CcmFKYc3Ae1wDfCIXfeAh3y/utBoQOvHn0E
+6LBCCxeobXOCnc/TKT2TKW9fXV3d6s4I1Qm5izeyBBupW5NxAX4dFXSihbEQwVm7QZevLHFlTND
r4mI50L+Psrq1n/ZDgHeN+/Zj4dEuR11lAwSZn3fWBBHZhXU813xiViGbjAPdHBeFmU+KtwczTM/
WtqkJ2K3NPgaPAeB3fcNxWmSdxKdW6VwvO2s9BvkFyYdLDyBP9JhW3uKFiXXFy5Fmpy1JFUm/zPP
oYMfWECty0EN2rlAUz0zQ8rQXx3kgGWVd4g/XFt+xVLSBbtrUoHPY5GlBfgcoZ7Cuy5sjOSZZLUC
YpiHAFxMA1FgtBcn61ho2GR88o32s1PzmWLziyz01Fw2FmZbJ3IUnFble10vw5V9UfbyjFjvf7Mp
IL1Q53ew7SzwjDGZhOY/y4Selm==