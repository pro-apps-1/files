<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrS7rsJLkYjBeEX2HmtkOoq9nnRExKyU1SWYEgiH8pvKgjMXyQ0YM1Gbvl5E7R7es9zPRj3v
7ehG7v+mHBoLdDcARFE+BjrV8ZLz48VrLdoL0nWwUMZroSv5SA/v1zfmTob7Vz/9+TBcIS9zKMH2
EUMgtiJ/e5TpC///INvElvLKu+jLc7t/r/nHcYcu+hsnoYCz570eLBF1nkMMKOK0ji0P52OGHVLg
H2a5i3K+QPSWXTC5sCD+olprwAUJh7yegKdDmafyv+3U6ZaZDU62XjlaMxMAROiUrl0q2Ww01tN1
BVEgPFyLx6NlLiCcUA+wlR3DWUGucVCP27l5GcqPi10tQntqAO/K26937kFcrXmr2mWNFx0Ji2y2
9KG3PFwpNNyZ6qfiATDRzY/34iuCVXmPxvVp/6RHCnsOTxq9EcwLZO3ZaMPb106secsJvelBnZ73
PeC3kgD8YYZurr0EA0DP6wv3ZSASEgxVVfeKADMkdmrRnK+tBulNUqtDkdakAXeIdHH5lG8eINvl
aHtMFurmKN4Tb3hqUPVM0XX1Nx6C8b5vcZZaEEHoIyb036rDrmxmYbkf+zR2SVu9uiqkQlsAmvud
4bjcuSrB3mpVVwr/vEw+vDNZ+EWCo8r1DKG4v3JmT+aI/noPA7cXNRCDJYnTas5roI6MCeGtKL6i
UWsD7EglhL4hAv58CQj4jFuUMvXEXBvWgDqpSDBTdpyuP+JY2iUJ5ROIo75P3yrrmrzq57a7h3z3
awSIUM1B9HpmYp486b45JjB1vKeBtezPs9sMuOlbrQwBKkCbrI0xkoH1BvHFuQHh8sKZ9zxsmmKS
IGmlkxDtTUr6z54Dy3Kd5P1NRIsjpKU8VEDFumNgAhwUGmFAXahaw2Q+7ZtKfjovAuSEurJw4zlX
I6vosDFx/kqZe0e1Arz2f2aTkSChfITL+vBKTSzJY8Ht4bLQtBRZa7vJxK7eZA6dVKTN07emZlgh
AZfIcNwCQtDP7lYE1Y/wAqXth9t94D/C8+9wfg5yphP5+tpkKLUlefsECy0fInDrIBHufVqggz83
X1eiirJTyjAr/qZI/6oBXNwLh/P1HqNiD4TBM/FMqY7CoFA/Kp+Gkucfx+E6VNsrgMyCYG6/uZCR
+wN0XJ71+5QBXYEQsiRxBSGxp2N7fiXe6P+1pxVXkH2UIMy9MaJ2oOqAZf0FZz8lIU27QfS21s+U
KRP1SdU5QUpogxkYzDs7azD2qw3s2PLoMryvG+DwNSLhJ2bssfdRD/yQ9uai9M1AKF/yNTDqgyCC
g+bQix3E6x+FJKWG8Pi9Ni2wthe+zc8T68RrjuYUEmrCkQPFiHTe5Xic0cE/S/za0SYtrCLqBVwD
LD/9f9hAed7fEsIuY9rODx8a7dBYgFjSyoNWFbRRHPwooQ1R2oHi4MFbkYF9hpD7jBT0NdTukxjL
zGh47iH9kC0BjslJUzwZUDvuK9otIzL1jRJqZ4U0oStbXgFDkHK056bDjC+NEG8ZZQb7YfMsLLg1
QHg9T3waYgerbtybZhw8kpbZpaVWc817zye/TpJ8fxN6P8yMozBIkeMESedMZh1g82uU79/hkw4c
pnEGPONEi21kHhLACs3dk8kFuOCs8jSquER9iiW1O+SZNpa2eUO+HARMlCo6XziTs6/tMHi9zp15
MIoqhGe/VhIdLjCkqc0XYv07Ik3zcYyQ4CTE9Yh9bsahniX+VUjRfRko6nsXvF94vhHKAWTaoWwq
O0hz8/YLpOqT1qoi1Rljopb3yv48O2P5xwryR9uJrz2IHRMHXnvOjDuGYiMW7ag422oWnJ85V9mb
F+mj7uxkUubws+4bCTB/X0IQmlO1q7MQ+dZ3Ngf1uwiYpECY+n41DmiXhylzUE/AfN5qlHe8AhZn
Za8/1/ZV7B+9h5RBWo467lpZZs/mz6o5EWoxmdrDJAr96lSTr1rBXZD5I7yYn3SAKgVAJItfPOnS
FwB2MsYsz3u9eX+TiXrmNiOrEMxpuam9sZ+sETeTg4Akew56Kcfgr7v6JykTDQFgFop1kS/+CBmN
sZ1KobcEJwJAV943Qt8lqqpwzqF2FHvRFgkbEU/jhs8hxGu6OYl6dPWBFwY5hUYXRwLVwV90OAR5
9tlCGPQpZuLcJ/l4SrQYmDGOUyLQ6PCX4ghoSkQ0MhEKaF+Y3j2LnxS/iPQOGo/7WuCNtW8WEjRU
OpVIHD2joncE72f0uYEzLwJIqHY06q5zxe2t0/kRzpQJ8MPK7wSr8fdtCnfh4N0D1dQKX9Itl58G
WEK0jTIZQCc0/a3kd/+6p8nfCpre/UzyvBz+daK28UmRl6b9WdtNOJJM53/6W13ks6Hic/ehAvcd
e36YmLW9Zed/ZOjj8tzw/G1o8vKSvJDTL//Bly2NGtEcAoZkVAxi73ASrkoOrDqDvBJommRTC4EK
VnEqrPoXMI5YLdy4+wWLOAp290BrtPPGZVLk+n0bR2aOE4gnPajIEcf/HeEBlqUThlH58ZDTnXxW
PMfN8quJTRSIeYD90ArJacf3wqElgkWQ9b6p4lvNH/RcXJMdx8CU8s6S9yBFAIf870lUCP/EpiKO
bDa02WF63F+3kRfz7ojS7s77QSwxc6LKEv+NDi9J/s91r6N1fJP0G81VJzyVSVVczi70u7wfj+m0
XXrK9aRZPWSbRMk7EPPh/WaU463YQf+4SNySTfw6f73OGUZ/HUfxDHu26ye2jShqNKj/gvDfYFLv
dAZX7XJSvdpZa0+rAj4P8aFKBqX2lEW8vi3GrmHkjqiINe4DrhKh+BkUT6CSc/oqN/o88mk8Rpkw
GQEnLJ2wog9+XSNRrsSeIxEJyYE9p0BgfIr3mGTHjnRt5f6mN/zc6LCRcfiq0JxCZWI/OZCQTVXp
cxcagNCJoAYhxkKcoZbdjzoMsu+9MHXs9cfB9c4jnnV+uE/3kADRNsrcOBpgTtT/4E5n3a/WieEc
ezhAxkihDrW3R2SWaG7l8AzQwmisi51Jj730ujBk1CsoEIH25Bp6h49n/ENx7YQIwqrJYUoQfpYc
oKkIgTaa05Qo/oVaPGK3vrwzwLwDxGtu/APUhW2ZZ4EbtAIXp+lqkMkP9f5Tu1aYcWYtg2u40zyH
0xyqGeOJcoBolzEBV0xEkwbFK5PgXL/qkVXdn6Qxp1Z1uUHTY8Sf36uDQogq56PhxRU3s9jo2KFa
9ImdeUUjZizHw/T5UxcexhgntNu+0pTEFcfVm8SS8t+PanaIjXEjazvVoH+TYFyans26i/k3+iPf
uRilQrSMm2kyr8TgMlby/5yNjS6mGO24T5iAkXoM5vIjv3yr28IxuRdzjDM47h8bubXplXMRMwke
yehlhBvhGhF7y3TbCZsQkRQZsHCt6KKsaTp3w87xObzceMCsvl5EnoghTUWH1DA2pgk2Tq1b+wv7
6P51DxgNFbNPDmI2J90bJUFuZMRFoo5E21RTO6S4PEYUpt4KrT6GcExvnfOxYW8i2IxKXkXQOuHO
PMPs1nDCb2+q7JNO7knwZSeXlJ3RrJ0BPYXhjCwiB4UImxRGY+PdT2+3VHyGU944YGkJUBuXHpAG
RP10yRTYUl4NLO4dZbBYJOAxfEYQp34irr46otxe8uc54yvYwi/qk0DAPR1W4zt3ZShb/Kjs+YaQ
un3vg34P6bwa7HpQ5UBwGb5Z0MQNns14kvFmIpIUFsIL/0s0VMydsSeEVvsWyIDhr9+DB86lUPu4
iH9NIJITPyOqsQ9TxkC1A6LMlg29FRFM6SDSatNsc4woOpzzOOGOvSMXYwCuC1oJWQcyPP0wLHr0
aYnrJzD949ly7Y68xg9bW0r4y0eRbd8YHKEvhj9dSsfIGBLZMWkbYfQAWXIXNJ5OE9NOxRQhv1L7
WGK8yd1K4zdL/0CIOjekcZN+zZsTL0oTfuXYORBfwoDK/+JWcyepQP4qSzP4LExuNf1QGKFMJjoy
0OoSBJdcv4BHqVV2WmlkLZDC4KOStqU17dWXOJz/iVqRTqqWQi4GQD7mqEWFTSCis5PlrsCV8JjH
bi+WvXeW7E2GiQ02EodByiT8lNWSr3f/57qb+Xb++ZKMuS1qveTdQB4Ta4oUCQuFtIz0PT/Qot7H
f1IO27cNCDUbWbEhzDMXyCUu0tIXuvqVXAEZN3yNNF42Si34Dt3VP6gGrVO7+8eiYIDkdgEFvDS2
9mlZaHjl4fN7uOikGZXT7xby1UlZsiRGFsSTvsAjuWsNTqDkff9wuVG1tcGJ1k68ObmH9Op8kuaA
0M6Zj0EtK1f/FeSonNERvp1dvQz5Xfp9xe6Sr/PvwETQzJy+ssosn+fH1sTzEmV7//9y2Ojhrj5w
D0hyXwRBzMS62C3eav4lKxDw3A0v7OVXgPP2dljophgJkiecdfCTdAeJgAvhGBIGxfLb7t3g4UGY
Tz3RepYB6NnRKWg9Hv/8eEwryyc4IriipfKS9PIYOEeNnrHyuU2pnjdOVHx56M/y4QZzBkmvixxF
+R9oiUMXOch/7mIu1wi/Bx6TL3ZWj1V9N9LtbUPvnniUD3f8djbSSdGYacTbjyWREPQgvf1Uo791
ea9OCypo8K1PTmbc5I3CTJSmSecIiJ8ujX/2UcmxhTiDpB0EG5vzq30/N/xh+tvtwEv70rDl3X8w
iQIUj36/BCxupmy5Br0JnvnYT7S1/YoTvNfKf2E4dS5m4MRLhlyoWLaK9CJfWdxo9prnV4b9Trso
+YCkIm8o+mrpkpwDxE4S9930+Rbihp66GM37UueVgHUWheaV7srrliNxy65z9PNJTgmJzUuIJf4X
AwZat+twNsYRgp05VYZKi5vmQTbUOJ4c4mjfXGiRUY3uLZsLrg9IIJeBLegF+21TJtbQO8bzy8pA
vIBWFmu3kqQpgKQAi19RraQSFKPxWH8Qng5rDJuLIc9D878LhFGDGM9H+JxNiqLZYNrj+AWODEZS
d6ANuMqdrqTra9126LjLivuugCXNo6pKA++iINZR8elLrogFsqG2EKZEXoft3JKoLfX4XvQtbSl6
/4R5IEnLGcua0gDf1SxL9kWSfRDjnAN2dRlexS+fElyIOcsHQKRGBGzZQqrIhFk3cK9sEUbyjAzg
lf4zQSjJZQa3tr7Y1YBpvVsX3dlqCS4CXgd4VBvg8MdQmPlarZsvDWY8ft6YsMKmXAALntd/zNXb
l2aMLa2eNyi52V1Ae5KG73jwy3CelAKUv9sC9JHdeOmVJXQI8stFXZ3MTjh0eHejikTjpxY/1kVX
9oQZZfkmNFwnckHfyphzBO8YiKDnEZ/OeWHTdl14Kr4ByooWcxC526dz3DGLisVtNVRtu9CwATJJ
GQtzl1Zl1eR+x8OoIdg80v2HywvWOxT+8Qp+rsm9SDaNVyw/mNmvUdfarAAMCpgS4qDU/UIFpryF
ugkmCfZyKeHDu8drDjaMzWig+2UDocgh8HSOMqjvcZuB1jfVo5M6nuIXTUov1o1Xt12Y72u48ae7
hxnuRi6KYnFq3cFF6zdUs+V+KZQnwoa0PFyQZ+xhzFEzT1uNxaLZLiAL+h89LswSmaxNwH10OG8n
lFFSlnTlQRHpNJHjZVIlhrUzHZtaIeTxGXOCnDkucO+pHcoH84I0aYojXIvHiNQUIo44lRGKMFWK
gTejDT/Lu37Z35gjng4F6HgxGazZnWLLFidnkMmDsL0zenMsXbVdiCqRDH8cZe0iGSyVQTV/KUe3
27kwuoP3IPcTZeTi3TO6/pA7I6GPkWCfMFYOQEbS11vQQqPNI4DUEy4k7Qac5/4pUct1VqD+VeJd
Iphm4Zb5PG9w7G9DQuT9QESD7tnFvSTYQb6zHYc+tsT0rDoO0eIeHCW5eoWH4AkSexOJ0SWquxRt
5F58fXZEFdFeJqTiR3zJDkxjyHEOii1LjKCAFtZIKfRYnCo8rsd97m8ThCUjyuQ8MkmKFncUpEE9
v/tAiedD/BIRIQ//cjBNFuBti5ksFxY5zt7dnYrNG/TS6kG4rEpioHXgEF6uiujE3zJ68v8h+Dh/
/uwxq8Ezz429oOnGOt8a6BlgNWjVRnTV5GojYNcKUv0lEIcTOamb19brSPkVJI0FIBgmz3L/kr/d
Y2F+dPLGFR044hCSf6cciqzQse1XwUZyWpD5Hh1hj/m3mA6Em9EWHk1XDNeT+Mix3qt4DI7QbCOc
6nurj5xnh7+7jv83IuAu05EaMi9N9dbtwaO54t0c96U0YPH4SDUW7G7qYYmMnJ/s8VHwXwv6WYjK
qHviLj50SaepzaQGtH8gzmzkHsLKhGPjcOZlq+nNDs3xqShU2vUmYv6jMQ4i2tR3QhwWdVeLPtwL
ahDS2spBYS33N7arWQs6d58+eTrwMLKdvQ12BKyHArC9mUN5jO0mQ3gkhNVSedKYAo2v8SNjUCTN
qyEgJxfnZfpPAHG8aIG6/dcQyF3085+G2TDAnfawdSoMMLDlbS1sjE3ewH5nwCtQf4KXDOT86FRg
q31XyvqR/2cRtikrEbKE5OiWxtruWJi0Li8FIdyt06kCw5+44BRjC2q5xD1Ytd+As168z9r2oniN
zPAmG2nsiG8MDVz9OFe/P8xox05TYhBQ2g1q/A1ltokQ+PTbLYkT1L77FJq3rMyP8F/LGE6HOguz
fm5vdPla9qaqqBZVsEH2sUaj6DOYJjVkM7dJgEgxfVjLyqBY46LvK6Q4aOhc717NaTh45Ww6jcJT
Kin4ywx7zJ6URHuvM95eybrvUATQBIwGNcAldRnjFhJ5W1xcsYObddKbGH2MSRe7BjierDkQyyon
BVJMeFsgU14YcXXQiiTc729DALQ5/T6c3tS85GoRhtBdIJPfZko+PW9rQO2TcQXE07Q9V+ZWrGdl
J93uV9hUu3fy5ZKElAcYQf+grCec3qRcNshtqCp0G/pZXjvEeErz//xw+Jg+qKTKrSf5ZhoPUxnw
jS8WRw2OD441H9AHkDyxIWvtRSUd2fO0HQBGVrtZx/ghHOb/CAKh5ddxwWhKLVd9gyVATnQ5UrVX
QIxGYFu4hfLAtIhABHz3PgdRp3LI7b9YuVYquFC0hXIQGKOaUPyJdl1aASMBuk9cA5WYAe5oE9zA
3lPBgesgXQ0weG8J5SFJbPFYD1BwlW5uLO3+tZHn8Vq0lrExw1s42cuDNVN4aQ2apSEJyBjE0tT+
3Jd9PY3Q6iQB/roC0uoJtEPgpMan5k4xfGJQTkY8Wq56oCLeJUS5V8uWLE/6/7t65Tv23c7eS/QZ
MCRqru6Gn2yRVnLTsoomFdwl7PMqH4TeLX188hHy5OWJotRZ/6NaT8vD3q2Uc38lxb0a+2ZtOYki
dQY6n5R5JvUFFOBlDhv7nTgVul/OJZVb1LESBMlagq6//bnaOjnF39c6raK/P5u2bTSPeHVOX+vg
0xYRbtSIEDbjzogygTtzNTOvSeCOmLKEMhdYP5nLoyVRvQbO7bgSLGR9I9+hNoYUi6qwdn1CRXRI
eKC8rxWZd26XBTHAbc9gvGsbuQZxUnZagTw6uFDOU0SLeiIJ/iOLBzc7KrzUkHW2Oa3f4p8R2APe
Rzg7+Xz7KZiuGdlnCKrP34Zyz3Ce8f6ZJfl7gqdJrWlR4Vai1EzXKgQQ7a94568x/bvhFvQLw4LG
lmojYkp7j04p0zrD9mJc4zzz87R/KyWmvuTFTIBUdjs2cYr/5Y99GnkdPXrOtM8wVQdIeCkUAduU
Dt7DrgoX74jrBieGWNn5P1TxJx6LfU62WtHJHBhRdebOdMV6DEmjcaZ/ZvEDmdNZZSgybruHk4Q1
DPKFB22SHzjtRny0yj6X1ngSC1qhLTkJXg9bKQrPpp8rA92RTDJfoFDP+L3OTri9uj8XkixaNpZo
hoEjKBuuWUkg6eiDkXcCLcZjGZUWuWKc4HjDM6xwldfDqsTpuHAhyyo2ssR9Jz1wgU05qICzfRU5
Wo8xv/LNZ4QZ2Ymd8mQNmoAh+B4cL2fVj5Fmp1qNNsHgHCiw3/ruTzsfC24EjHU9MwEdPUqrkLgJ
KxXe2R503KzB6fD+ksF9fItI/CLpTB1GnfPeDNB6VbsbTIeWeZhmO642hQC2MD1umeQJRgfW8mYa
c4132FTiq1Y1mCMz87U4517ejZbvfaK1Y6FFC3tZOncABy4utuG9dYLvUXmmgigOPKwtcn0JD4NM
tk+0HHfy16e9a19Dc2AVqzUrUwjSoE9Oh6a+6LexvFehdJq2ddy9Hlwm3kghyaVPrqcbfvGt2Hpt
SZ63Cpur+0zoIX+KUFkB92s7ICPpInZKdJ1UyxogLaWDC2JTPBPpfvk4cm4UGSs8qmmLcGf237mW
1aQWmAJW/UCSAKruT/+DI5o1XckH+i485HRTOEZKU2XkaEB83DjBN0g0zO9cjBt/B6wtrh956s32
OGzAOIaSYZLGl6Xw9/ck3fqFNxg+ty2mevazxMDRVZZsGwP4HxRL7Sul4VI70iX2PZ6Mfmykn8ZF
U8yZx1UcxVh0l8hxb4Gq/V8vgCUPdoBKufB5S4KgqTqmSBPugo9f27yqjp1eCT8/2otDUNuvkZFN
/RHSlP3Rp8kotOHT2/fXTNVXqa4x5jqFdVTtL6qFSlB7LT4Qxk+nlQ0BpK8N6DJqEq5CKpNQlRnh
qnVKMRtx/8v8GGmHNRloEUtw/+aEr8Xy7T3TFWiS4N0vKk7PCCp8+fu45p/09nvtraxFaR6g9xco
dejFOp2eC3YCIlGGJN+UgM+xvctuGoQnQCYlhcbMn4aA+zlVgkP/nW7Vo5Um9Mp4eKoueYog0W==