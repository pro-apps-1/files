<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPua2NiIueABhHUtBvvY/4tN8bGN6NIrfZkzzR1bahIl6uBYhyx5J1b5kO/MEsMzuWgT6WIxJ
k7ThUzt7E4wV7c9qZBHxoC7tZfMUi1v1Z8l3bL8aefB7v2Qr1InaFq9bKRHODHUBKlIQiQdNkXwN
/i6RQTzcVPJl05swp5ZHfTtEcKDRhvcWTr9UZTHXIaizphbjVaJkyJIREZSGGu67uV2pS4SsKjaT
l49VnnId0EH5PlWu+0hsoqkRisylmERa0wQrJYpoY3b7mRaD5DgPUrjRXWKeRPSgC/xTM9NTOo0U
TxUOD1xSoghl+8dytYlse5VSHaq0MjSYd1tozaziIImbHnUK967WcL2MAPjiQVriuHpRwJSv4lRX
x1K0jfQaju3i/lKQRMslVqiDru2t9haRpAwdsCVPZJ5+Ey/Tsxcs2fu8mGtwAk40TPozeIn9YqnQ
UF3CctMJ9rfvVPDYxZQ+uRmazSYhN/Blubf6HTFHwnUeYU5i+JzrlhrYMq/IccVutty1SN76dQyK
rI8fTOfRB4I9KgXJ9gd1gSq88FNrJR9RVRgfdwqGVQ/bEsTFuZ1RuKOTFR1DG7O/cX1PRn8i6Z28
8DsfOwDQrchdkdpjeN/j1oBlwP1YHBtvZCgsPsFNqQ79q0yewgRRwh6xRB3X/rTFfvfu3i3Xd5CJ
a7IJhs6tkKCISOzrpApoc75XglY3GrIqT7ejzP6xSbIiELpdabeTY+KpRH2cwRQE54yWOMJjFxIN
YKzdtX8lrT7HXY5RTO3x7j5RvIM7nlXDvWSEaMx7POxt+KygU39jThIwvHPLpNbfafj18Rl8uK67
FLd6Xkup2CjmG11QpehETJYao4Q0l6oC8a06qca0Gna+leICFoTgiE8nHyg5lYMtQBRL7p/to30E
hUNouZPXTA5iS3endNiXa4EsUfBfaiyPOgSsPDW7HeigboArPMIvs2vg0eXr21Gw7dmhRwBVPcdO
3LRpqQB38xXuN2t/4r1dsufo93MqsdN9bu7LgnUKR3tSmU2qfEC+mQBisczVygvN+3Oc9QTBYRHm
4xC77Z7KTOZRpc61CC3/lKLE849Hsug9yv0+Fj6hJO4IdmhUKpJVuFaRtneJITeFH+PnabWLblw2
fy5/Vtes7jX07+3raG+JyYRda00QpEQZGw88po1uQxujx8cWUts8BEBqWrLd2o0xgLgQpPpYMUK3
a5kQyZd5ldvxY+VEZZ7vY2a9s/NxdRU0BfVwX8MJQHo7x+DoFGZlfgGHPqG3vM48wx5ICsO16+ks
VRJPWDlS9FzYWt4tgFpuGDsnsz6RbOdyMC5OB/0TMB6EzqbQqRLXRptDVntyczhwY2iVe1JbqWvz
iUxeltWl6S0gemmsnzz6jH2gDdD5V0SAzl6GEfWH5NnbOclRftKiy5jwFSIcZx9DmQVYhlbGDSJb
XQcgkrHLDtif/oDqyLrdTanUSRwqhbqBXninHdLpbsb1t+axfkXg8cz9Uj9lBAUsB6kWKuLkur8N
xg+P/0lmG26BMkL1nZ6xpYOWUtHtY8C2r2XWNUwMOgHGRlLYEYytHZRbTF/GpeXnwFhpV0tYPFat
6qGsiph81w24zUxFJCTJ4epHpoa2M2a1z7VUFeFXaSHGgfYdshpfOpYMEwJIkqXf9SimwqcV8wcJ
BhMB8wRcK4CEe1GoI4fI/+3zn56BhD2knk/I1uk12ls/Y8sVv9VwDXKtY/DlO3SbOs5m4hn+y7s9
rouDZLp2VfC/nTnxjrNcUsvcAY7WGF4JFvia9IKsUP0PHrpVpFKcaldgPGhdT+tT4JJQUKuQZsQj
wYRTPuO4Jj4LlJkvzuPmkFfKbzGUK674LPtErqMVYmf/fMNzKBEd+Z/CIFmRJs0rMiXEUdzAK2+v
BP24KQZVb0JUjlwo1tfB6+GDU+itvSoffN+RuY3/UOpzFLk+fBS0orHGGojZeteFmFq1FcCiJaWS
uz6lDyVUXa2WfdBTcoc4JekMKfPdqjue0SMamrPDE/0CJ3lfkO05Xiut9Mxw/ivofRSIc+4ssBM/
jgQ24SKp9v/ZX9n9LQYEkR9PS1XwYbL/rXsxVBhvk8qOpr9JDgJvVDjAomTINhmny2LUkZgdb+EP
2p9l+pYOOCL/wuuDgxPV2I8Ayfl/zkMFPbecTrw6dtYCNnhKOsenYdbSs91av9lWpVGj0W4fKuZr
Qjt516cAsAhLi+CmexqTQxog2StciZfQt1hA1Qz4dn3wbUtv1OFwGGEeUs2G3Cp4m2m42PO19lS6
YImOwlLEnx/O9+MVcd8JnJHvmjoL8vJ5fig2TnClfKAPkaG2CIUU82AAGf3CScIG/HdK5mtwrETf
dhuXZvvlc797n8vc7GGByCOCEV/Szj6gUB9j6a3m2hTNsvNWOu/P5SGBfoZ4olfTz0C2M9Lk7VSn
vLY0VGoT2tPpNYU3Fnp92gPjcpXCr2DBoAj649b9GRHGLNrrRfb3yuCfUncErezpTYvFjEULWNyR
zzixrQwelnPpp6wtIXmDe8HxWG1r4eQNHzg62OfmkA9R/7hQpxhTUtStE71ByNpe/CpHCp4n3dmE
mQb1FrAtAAcfABTYzkrRYjPxOTrSI5DjYUNXoomBtvpECxq26IEcqSpXzumW+JZ2QZlkxQb2oAom
xneu4pToAj7q4Q2UzJu8nu9mIWtLHoGmFSSMaIeWw/87Zv9tou/kmX7Qh8RPXcLi/qMjb9lDp2uw
OmcQqLI2joiTl7tm7Dvqk8tvyo6doE+QOpjoX5NribUVsECJ+/j8DaDpoy4nCDxzAHyZuYidzT+m
hAjoT3A9/9Klx9LAKYEGBfROIVmib7Yf2vECZBmhu6VAncnVB/+QRrQzXdmg0qw4kUEteLbDVPu2
CMl1ATYRi3f26Yf5hiktSNEJDWgspJT87JJP2WuBUUSlS+z5DpN50ElajifA8DizoNfC4p0xF+uf
AstUca+uG+d0E2nBqYwkNwiZzmTZ1F88hqNyNksjpzXBTALDKevvVn/wR66lxuWbGaNp+nSov2TK
aQ5/Kba16eQ/5ixxmYI/RhfhArLGyF9K5RZjvf4uQ+4StMW3Kg0lZV9GUwaEL/c3mHA28q37SnRC
mWT5AZRihJQ2JGYO/i9KBBf5+9H0SnF0H8dfmGLiuB36f3+kRfTuUBplsUELLMqDHJzwrR/pqKMY
Eemx8OtrU0uP4v+89C/jBZ+/KujTb9YJ8JvECJICp4UPS8pQ23+cuLuCjggtvLrDbLvcFvtvZLJg
bsqjcQ6FI2wyTx8iJXQqtgMRi3CrbbR9mb42RApwHe5eKK3TDEsWdfBmKMPgZknVPR/PLcOS8w44
3Pgh4+0vJ36EBNTwyA9Q6FRfLgmdcfHyDt6FfZXiGanx4QLwON2JtpAmaH084KroF/0zKtvVYMSq
uXsAIdnwEl+hKXYf1/BVC43GV2eAXtOcR0kiZfhV+HMF4MvOo7XrU2YsDjxYNU0qKB1+93x99gpS
LvR2y+LxO48hLumcrK6jOUfc/QnhooULa22HkQfBgP0f7zdQAVvt/CIaSFlDHkrwgooQRoobHCBA
4x3GzCzdVmDD62WmOjXLfm9k1dPGKmBdkCw9PhaJQPunoGDLjmb5Xuu5S2Ua15/H8Up+BkVvIffK
gPPu6cM1M1zu2heOLbuPbuCLj0Ow7DMk4qchvz8gDdE4WeS2a8HLlArgDE8viEIxba8G22zT/2iQ
jPH0gvLOggkdUNFfk/SgHAgNi4vaZg8ZhXGCvm6OwEjl0UiN/uCtPKo+OhLxO9HL3t9wp3VZzNTM
qsKfmthCWwRvPOxDEBy1ROZao43Cd+vTFLJWOaIN3r7cne8N16tCOE4MmOtDmOOHB9xtbXd9Kffy
nLVF8mPKqckthbXjwjyAblK0hcXA2Mv5YBl7QyEWzjfXIYB0K5teO0FyoKS/yFTJtaFJLNKscWcT
sKLelgd7XKTp59Bgn33KXXAl8Cfw+pflIGrOFsZuiI59eXoVH3zgWjIDZAYyTVlKIKIj6xTlQgqf
K+FsR7Bw90WbrOUkXXPGtgNyjJVOBRAw4k5akfA/gNBiuMeR4Fx6njG6xnvlhvmFgVUGYTh9yuN4
yofU7507Hp3/t1iAOoeTc91M7Qtrw9kxxCUQZDm4R3YI/944FTm5TENFlKChd3KdK9OsXMksq9A8
S2MnE442nxIoAjwG/DcZ73bkmLazNzPBd83CWfhHPQNr27uNko1bTixOwAd0dln0uY/aWY/bCyp2
wbvirWx4DJ4jeZT/r3OVgcnS0Z9AukOm2dp7Kb6cV4LWat6yrP777rokwa3pmvbFauwinpKUmdPt
phAqRuGeY+tfiJfZGJijuZsg8gwPKtq3BgFEXtia+ZjbYOPm/L5sQmnfuIJpdNSVb0k8C5H/neep
3BTsI+tnjBr3zY8LGD3/J9AoGcFczUO7R7MRFNje02g9gQp7KlzLKW8x1acqYV0JLbG7vOnB1DjK
Jag5v4KpSqHD3oYnRFNcxuqVD9z8cwoZrjsA4UIrRXBnloslYC5rvtGEdbV9BdvJ+AZUeU4RIaGr
+M5dWGNQd6qdLOjS+7DNPyS3UBZPywuLyzfiXCh3coJ9tNNFTTSeGt6+dUhQtLAX5pfoH7DmsGsr
L98l5vrCFeoOp8bAHfPxIVDWMG0uAxzPhBnHrL5lvA4YhcBARrIJI3ANUgx8/rDRoqbG8DQS1jeX
t0CItFnilqDdPUvCkAeixRi/HNHw/2kRNHacIkNj4rCV9w4fAPAbI75WtsywE2EiDLvfLTEx4SyD
dxJYJN3/lPG1/p69UbM38IHxjtOZH5XBwrwl5x13zLeuRb/rtKKWS3ZM0+vyneh3idT9TAjkw/8q
yUjt55CHu00Lst6RRNusMRht8Ui9CR8ZOmDGrLOwqAm6pG/lDTnhc6VxXrvlzDLNL/fQsK3LwzHw
nEzCpDuc9T0kIC6VPSgLUPlu8RrKeGeUs7I2Q71GPZhO5SLFuDtnM4B7Dndjh8vvRyvG4S5eiapY
Nk7Gd+wPsdqNpmK46OtFRjIyHZxBlJZRG21IwZluU4tX0ge6WEh4MVWkEw6ELftWgNDFX5mLDsBo
Kj4OZdr2C2x//ysF3ObKVw/AdywdVHxZOEY/YRr0XozHGzqmXMd/zik+JxPdTeKCNHF6sscnPOuF
0yw2OAMpasw5nJyXsJ8t3bNqtZf+KNlYW5kLtS+OlMggnrdLmX/8k+ZiG0pWGA9Fbo8OGkT7ydvA
SxbEr868H+31h/nKeixTjLAD+yMnUFBouIolT3jNm8XyU0cpVESHpOSJzhhjKnT6NkNGG8/bSK/W
88gBQGBZxqZ9weSwD/jogNzn8+3+5+LEd1UunQOIE6Fh98PhydkUJrvbuyk8FxVFG0kRM44u0rN9
bft4oSICBQCPyz98SkD2DNjVKvsta97Aial+LtHfKozbT3ti4e75ElAWgfZMv5vrp4x9uIVyHIkJ
ful/AX1fuR/ZJgCQc0cPvZ+cyfFwWCrx/c3rDTkGlPuPSJfW1xHOpRj2zFlN0BGbWn6zcqvjoCdB
QRHqrh8tDro5u6rgSN0XN66rfTDqDWCvocHNT4Vpx+onfKwi/ImVSLC5hA0u1s3bSvOu/7sftisj
Ui5jmeQLjX1uF+LDcja2JKHI2IANccLtv2+I00z9LwgJ9KQyowIA3DFBG5mqAcKkQPMlcebIXjav
796sZcGzMrz6wdi/DfbixykGVB3nDiWHlLjYnRtQecVenm7nKLqZCF1W5yCcczLVK62W8+2q6GMy
Smz731d5faUjikaV9T3O+c2yd6qGxfvRVhAyDiFmR0MS9V1RIcQXInOeCpP9i5sr8IvNGCo18T22
4SxZyfhI1FPkNCxz7PahRpjZITqANVu6n7rh+9gzo8JQP+Ne8eZdGJix++5FfOqLYCt6UE3FztD/
dP73ki4ovzG+2F484SycbQYl+GWFvkNaETL+EI90NZMIQaJxMKgXAO/8ke59Upx+JUFH/LYxMgP6
pk5CfMbBkzFuPzL9+cp8DeNVPlAEfiaKYrgx9oKnh3/Fuu0FHSRL1U5H2gBqEsoSfA8wQfkD5r1d
3TmLdgSbm9tqYiSk12mHEgMgGa7VS6N6vUUYWC9X/4DqfZVuWOhzU5MP2pSfXS213kgZ80rsIQnN
vDj6REst2hMLProPlv3pc10Ayv2dvsF/k7SKOESlh1/RdDtQNzzSHwRZhX+0SIJai127Z5Z1U4T3
VW0M30wLM4tsi6Fsn102vlY5VXmPyZXZbBmzjpee7CCCbMriYB/ZN27xTml/dqD9exec1PB6rM4O
iR14IPnyvhUwszI5zpTTl/ZrDd+U4kK+gTgdYRqwrnswO7fOsROjUJvADB8b50noxB2paEMex0vy
P2zgKCJtCfUu1uST/ijzDTgKZkPovRv3e9nDPavFn97qHYTsXR3lIvdArbcsTnit8XA6qWJeW0F/
dWk2iE4n/CRwuUdg0g0rK5FQQioXNeyRlMS46+SpDEEm15Pq9ATnWd6/x4Aup/nnMRF/Ug7v6/BO
dmO4JxeA/2tmrdEDcSi/bA5Pe06HLSCOOopbZ6A/+VejVlD28j0rxcBA8WUSWZJVo16x/Es+1BQu
ngbNWf0MhPVTrNe0q51/T7to6BR3G86wD0QzrcGjz+gAXkSXTbjUSRPVN5O60kBQ3EnModfGWOta
i6wI1MIJtTBGAzKre5dX7OLWme/K1b6mRQjofALrMZDrx1yn0Q7/IlhKdfguIrqLXawpjnTJFI9m
cW9g27emWRMLdoZCE2N+4TWZaRdR1bNqH2bKgQzrZNA/ISgXI1UAPGNn2lLwX5pJLtm2yLtn1+zO
BZqQzO0+pD13YP6hEjziEqRjoJDz8UpbyxHqCjFkxuqUWtohzKAc5eMlG6M/FzW+X2O35vFd05du
oP2/xO89/dHnz65ciLGkZO6eYZ5ZbDa8E2fBV7FMo4PZRfqWlmuRpr5eH6lULLuS6nJcCu7ZMVzp
Ku5pLelbzkQRacZZROyFei15IGeTarY6Y85jam8BGD6BGJVv2sL3kPRSqs68u0yKxKM1+bmzBGcQ
KAFw2N0YphKiL6lRarK+eQKsFivM/DXzwF4gtF2dWLLzwZ7w1jzZ6y9BB6r+6PBrZwrp42FWA0Uj
8m+uKG2lYJSzYZ9O4Wk+EZ2H5MEZRH9BWkpC17jO9IJQGv53VKZavh1JPjvyT6uGHWq/n6MivA2a
NWghQIV/qo64HgUW53FC8jv4uf7lwH6UfBAbq55M0pWrUjxgrgVdPqyzyJGHzuLgFWxcsQm/yig7
2KrQqT31aCtNTCHVrhs5ZCaAxNpFU6fsxwW9dn7yAGM5DUEenvvDQlyl6Vo4AqmAZ8R6iSwzZBDb
L0nQKgEh0/3EqNjGuJj8M9/4rO8/t7yIXHb1QxcqZb0pbPAYWkqXnJMo5KNF5JfB2SwJmmX9AufJ
RkhCb2LccAh8zz6xhzXeBpOzQNfhAMKgW14io8rg/YvthZCbjCUopXOShrMRWYioPbKwgdvbzGCS
Oij7yoHVGR/jkclteUIa5bIKU2PDHmxgVduktFWX+7wMOVyGER4D4KctzTa8hZCccc0JcAiI6Kz8
rYHYnz2HJTbbq0krfQYpawTJ+C5I3bZJ2YBlfPvQ95MuzQ+mxJPVSV3iP1z7WoAbRV5W2Rfhf0Bl
CeFRE6V1vA61viy0ucFTn7aq9BBsZBlAreZ1Wtrp5GDE1xAIJmZTxrWFAW6s3fwr/Ex0QDC9vXvs
th2xlxpx0Tfr5MM+UCSV+zWUe8SiJE77n5qj1kvB6o+F415P0dP86BdfdGo1Lech+y5JoGkDJW2c
jm4gfKm5/yemuF7hf2IvaYKVskm2S1QRb2DWiRWraOwaCEorzWs0fGtXHjhRErbtk75YGjR8W/Lj
1IWXoAq5/xlg0UjcQIHoJet8yYKzZQOvYdfYzQN4b9CxU1Py8ziLqKeW7eGmlCbCEBHh2OPN0jw3
XL9IKnu5kjM+Z+nS3YZx/rynmT803z4kiBPlNZ29IjCil2Y2D74gyXn+5cUzHz/76/IDpL/AfHNO
TklmYdWdNv13l9S+VkDr5ByQc7VzpPjvRDAmpTiS77LXP2rzmCbFAB5VS1chcfLnPK6MH3uKmL82
5jnPBLw4MzfyleQaAcYmfyhsSe9vhyFh2ds3VKcngoUh/BmQ4/h3OjijoPKEUSmLDjlbiwFkYjc+
K/kq2+lC9axpHvkzKsos7LcY/+ISrUjt/WjrxN3IAJh2GYF/Mq3dVE0XkMujVvgQ9Wmz59c/IyMB
WCHO27n9oFq5cgRA8SLgJ3k+oa2VimAvSH3zmGrZ6ectzDrNGGWdDOYIV9vhBdng31TbbyoZskHa
CYaQCvzUmSWn6Hdhqovtyps2AteZWuvJgkRBbm5htz4pxj7LpfCbvuGJHHSYOKz3/4Z2ET9jt5oh
6XwMOn24tzZR91uqiX1z/xlzslHBvO5xszuTMOkFjThohK917EovTe3PXOQgAi8PBDt5T81vieDZ
Gtag8GN7xonZbYh2KQ6AV2IkhbD1Klmr3t014EjncveHEru6gjNoHXRH1hm4JvgF7LuXNANA++JM
1/HxkMhIC2juo/ImVfapXXW0qFmu3WjfmwgCmnLnhYzmJYk7pUXWaM7uXxAKWyu4Xu//a4nu7KMG
RY8B6yEZLVj2J2exjSpKMdeVCiDl3d4bSXc3iDvK0ne=