<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/jcHle76hlzteZJsREJovUR7UlfjLB1skOkut6AoltUm4H94y5tzomd37SRYNLup3TU6XY4
wZVCHO/xQf1MhZqV03dRUvxqd+v637+mH88wkn0quhiBGt8SsOUxN1RZsvqz++L5w7IXjRsoFs95
8LOSb7SzfvegA6TRPol36JxlgjjQEgUe04z3wBuxn9Xs2x12xNV6tGLTRFGu6OlDXCfLSCqGqwC8
hI476/8DBjFVAAfrXHbIc5LPC8b7OsWgwhZASD36JK2L8pzAnBL7csR7QRo3Asc+TCiFFcrYxpRY
N9YzitLyzAqwvDPGzZ7moZcFzLyN8ahI+b0mKGkm1A+eJC65SrZ5Yl2NxWZqG3jax9jwAAhhEReT
9Vyorh6V9JvAbRoHidCvxtF9G4ozLgJzpA7DVes7qvYnkKB6J7ceOmC/pmMlbT/Ydhw5MZ+TResY
KV0WNVfGDp1+gDznJ8go1vKV8qY30n1TJjdbQ+fF91NUT9cFFvxImoVRY1mdJr+HP22BWpZjegRG
jD2yy9OHS11aoKPf+Yx/bNAb3LGo9YmBqtPAfRqY119Ncmk3JYOCDDAx5YeTIHrlW/LRXbzvBDbn
yA4qVZ3J/w+/yn2P84i9gNdgCfSd3KxeOJ4q2UlV89QlmEc6clMo0LQVDFzJPvOMQnIyBdjHVGmm
mOO169YEDwxBRMKhjnYveGOOZjjo5mnefZKvxWG/8qkpUpt8I+Twq/rQmd49h7TsAMLFY8cHdvpQ
/rpXg2K9lLZ2SnO25nC0LgQkZOGhd6PojzR76CE5z+QhUXSzvIUBaaMVkBNIf6/aPd5JTgY4s4Sl
+mc3uvPbE79hziy/zkbE0n0LG/JZ2iTdttMVUl+lyfbCjeAf/pCCoabyvE5hs2RGts8q6YtOihsM
djSOxTH0AhOP45YtYXAmngQKXkyTrZD2nMR+IMCFM814G3MXy5OSblU9BbCVVGWG/SalWLKlRumg
zzxWsYNDXe9ani/DGgbe/w3TUlLPcLbCwM3XegO1m2RdjuHgokTZPm+4G3Ct1Evuf7IBxGk9q4Ke
jASzN23Uml11ZYRnq02mFTeWP0QirKKpAQjqH8Ny4e4NV5WelFcCAf107XhL5YGTuyCuyLgetZMk
D6jj4BYhlmeWm2U8ss2V0iaDaWvVVP7TldcnpA/ZLS8+s2nqGu13OostakGuLjL2j+y0wO1tRxaz
CkNHiJOUp+VjGevc3y2tTWOPPeVHWBHGw1jjZETzUJCTeiiHB0z76pLSwABx21pN3Z4Zox1qsdFV
I//5HEyYFgXnBsDoYiFTXQV4SkXGgFy1OL1rnelhl8Tx6inBKPn5VXPsDLB/SsospFPI4qjGZMUn
JxOv1p9t4RZ9ura2q0G0My7gVpJWXvDc7ev++aiwHInj/Uy+z0XVpmQuR9uvQ6wR6I4ZU6Ykr1Gd
e3zAFWpnSC98hzqv8YHqTxN+ARiOPDV6jwMt8NcPQHv/ZbcQWagetQrPyt+knl+1Nzv2ne3SES9j
NXxeCi7CGL8BQcZQ4d3jyqDJMw9tBCUYUNDOUoQoggFoRj481gO6ULjdpbqmKsdQFaKoQxNoLtZL
fGretUtj18RoXhzVQbJ7WT6bC2IbPFNqFbTKC7071LKlEmHiMaq0/OtJa6VdHAWQ3vPwvL8eMZLn
gf4EKskJtPaE5vgeNipONZHft7jfAqN84DYW/xEU4HWwML4clTUJekEg4T52X0FUYY1ydHVBTbbc
V5HnP91QAdFlR9vndkjuodfNEIT0n/rS9OAqpF7IoVS3i5muxnjFRamB+ywJyDhtgcvhh37R53+B
0mB6nrDBCSoCXPxzAQf0D3XCtN9cXe6tTKYSs35cQyxd2ScYYqFMX457FgS41YkHsYKWRy9iOUN3
VlTeShAoKA4qwCqC79wsG0ao0H0rPiSWMsmN/eB8/md7yd2n4ZNMoLzdlPLcFnkIWe55eJikwhEl
Ixy8Ehr7iZKFFURBt7vamkfI6dkIMou7hR9wMorQv98p6xECSCdjsyVM+x/W38aRaVarVhNRIbwx
3c/9zb12laRYLKqamkzbwfe0MfSAaj/GkHIAvTN93QJGnwwF2pS39mcDMuuSWg9JZ4qL2Yus9whs
T9qgHX+9aHGAsK9P8Ovy33YpjuO9gmORqjlTD8HXgAY32/lSWva9kx9lc+fMTDv0OkCYgVZYXL7s
ToQDn2kYHxK0hFsJ0Oq44/M6D+9njHoRk7zj5wYKcY/XCFpjEd1LKvfwaxs049tkljlpdCQcP2EY
zfOTsBsAH8K5lmHrZXpjQe0NoKjMlUteCTkqrRv1XXG9n7p39eVafK1TUP6AkoiO3ZCSY0xvTP++
bcCz4nbIWvlmVFxqlYb1Ku0r00rnEptrIVhpmszVFXJJR13EkFW1dMn7rCC1mi0G4IJtDgKMJTis
NcyCT1u7wB794K/WCRtrhB1xdye2WccTxSjgxD73uvt15/WCPRmOZp4eZUUxfzi1W/u7/3PeZvoC
Hc/9OO3rMU3O/tP92APl0iFUMsW+IdwWrvn0uzUrjOIBpE2d7dlJwdTWPHaJcgKC4fpFgm5le/A1
dbSVACWSlsTO7AApd0sezX9yUdZB/dmRcMUW79ss1WFmUlZEAgSsDw8Q8ApfRLf/Rke3Khz3MkFE
l2neRGYqxhSCCykM8YfhTpy5GHv14RTQBasSJ/mpXRCd8V0PqfJxXAIT62q9QYbOv0m6i6lqMF+G
ompLu+G1geKUisGwi2xp9w50U8CQLPfqO7D1V+PRlZNRzDWLh606M6kii+S3fxILQmxVM54aVJQ4
j9/FpBPtya3BSmrTus+Iqum/bIZWhXGN49+8NGNLSxDJOb+wOesABieHPj7p5RMancf/zAPC/3gu
yDoB6/lp5CQVXwPfR0VSww5fVFeYkj6JdXlNIRliWmgOwsg9lqlKXtfdNnq6xk85mOKHmwf9qAuY
mZIAAth2NsO9NE2ndcvRZ8snrGP9bjq6b26LiCfS7iPsdhhkOW+jXi6yRxgVRHgLfbvu+0aNg9Oj
bR/g5eUECBCtsryrAKjOCavx3mf+UE2GeOyXNwLLxasa7XjkXUVbQek/HU8QKL10ypWtOu92eW12
W/Mxs3wjUcEk4bZ3xmm0jhTorLnMHTjARi7RszOK0peo4U3O/pXpP4dxuyLtEgVtcWt28qfFMRt1
8zirulvHDZTfWPKTI8OtgXiJI9ke0KVQHV1cwk7IJFQLl/zvH3/mrirJRlAdSys+CkGf3x65XmN9
UmnwmZjHbapVlzS1DZiT5PVfP9lf7eyHptIVm9sM7pr2vn0njyLh2KbIn1Ui9lMe22P2EyD3yie5
41nu76nR5mAwjwP5XsUtcKpi3DDJILtxm1REOs6NaBoBrK+qdwPr65yXvZcGcL0KLu0f6yEd5/pm
7Mf7Lf9i4WDJAs8TJnafndyagZWvc1MvTtoUr9Q0KH2gQVRrBgEJMmL26PkZska3DTPboqDPeZrv
SYkg5eTOuCB7bQq0d8TEK/2rT/d1ZbKixLFBTrt9ikjewo23eHIh+Gcr6YpW+o9rYYp9zFHaBuTp
kMN4+35YJrW0hMMrmd3dwkYj4kyDl+3a/2BvrNWY2ozaisU/cxbfcdoYseA2Q4+a8XtyxTM29SuC
FSF/nVCWuHYRk2dsW1fcsajuwu3HsE3FkXv2oB4zbd0uvJBV/6isZsVhg3Rpg9avSnwyFMiPujs1
oQymWUceWX0UJzp5Q7+pstNLCe+wM0HQ2QJVRs+LpxYRz8GsMrG2Cvgmg4u+dDNHzCJZEJ9ax+Xm
vA2URqP9y6TjcOxYLo27qW0HEcQwXdMK3B6Yiht287NvauPAq2fxNnUUn5KxJEFR0V2a02DYrJNP
3VSZFrwkHO0KYqv2GM4KSMvIGHzhUrEGHBPF+d1MXQB+FMh0jEwwQeSzBQMtjeNezaFTCVUNBWmA
jlcPdMmUHx0ME/gIUlsS41X3KATCBUNHaurJPCLy3gdBIqCsh9bwBeRIQ/Hdy+qJBSAuwka5p6BO
CXYchBGedWDV1WkjXfwJvjti2KU2QtThrVU5K2XGZev85p+ClOJlCa1OZ6TDrfyUAGh8g2erEYEU
V4gKIyRrOz8XB3SpxyqvUEEvmKfyfQO9qPOzzxdlQ00SLqp1f1p89LNK3faoNAakUeqzbx0VPT0Z
tqktUocBLXzgeBZXjfA7RKxcXSW6cZV0d7cNkdxjv6d9q/+d+J7AedRqpMZCsqSZpbxRrKMESxEy
WYZ51Nqq3z5TIREaP5kUPjUWajZz1Pd6SuPhAC5TjSdcwo/v9Uz/pT3zCdxk3GeDdpE2B8BpwuKJ
VOHdB19E81hZZrX/7LJ4g7f0xMwM7Cmes9wKw6BLe7fTM1ux/s9AORV24LM2G6CAnM3/jtcICEpz
oCiJZLB8NR6xn+MSCdB67FQ3ISISOll1fKe2qicjExKNVi0PN9elY93wRQ6STKet+T5oPaIg0441
kekV4KS88FKDAltZW4wbZDSxiOy3omvAZ3dnGjaVoim0apDHQ8z9QoHLlpIcyOhlUrNp41Czq0yl
kiqGiRi0idvCc+WBXPqSswJu6sZpT453J7ILmiFsMgekGVU7Jt/QPQ1xrCOrTxUmLLpwbRX0peNy
zq3YfQEWrJAkC8iPNytt0RIjgBthc+m7SHyAaLVRZ8cIViSFa/x8A7jRUJJX4fh6uZx+ej9GOFvg
Wac0ww4o/LGtVHJiDb3qQmSsvzJMHAdWiaSjsVlGq9ko5FE09o4H5xNQZM4lLNhTxqlZiIrRBpvh
XyfmYmObFZVxxPOuxeckLFrjApxm4NTxUEW2Wg5zvX4lI/hr3a8zfpd1ePkGyfZURY4DeoEJsSD1
rh906pYTYOEK7Wla4StDDXVck6Sla95C0nbd55PoslnZtYbWZDE5Ngxg5uXxLNybvv8QDoWE3rny
ErhjxJvhnAKQPZZQrScjQ998E5MZ1OCtoyaQz6YXuP02XhX3d/Is8MkLWWzarLkuCQVQUF6eEzFM
LC8l+wxvLLiH+u9g4ZBEw29YZdUik3OzlQUBMFBnbzS+/jjmmMyoqPg06AMa4kGidjO2KXglgBbT
/Fs7PKAlZYDqPUhGGNpPItcMOQZukvcYFq13k3GdcBj95gMm9PHhLWVZCRZbTactcIUr7NhygHnz
0iECdILD/7At/zh375k1CWTCGiftEgf9Syw+qmtiNbACmNH/CJ0DZz/Hb270c7m0Vu/t7B4kd2k8
zWtSZYWucNraTtTOU1clM60PW3t7GOXMmXOCoeLJ7c8hJYTYdivUhr1auMWL6wfcmmuZbUS22jln
YB8OnznSEe1kVnPHkQ9RXK6bfoEiL5wz50F7Q/wg5qDm+WWHgyBfZAXSm0TE/0sAKxENcbaM9c3g
erbhmDUE1sUhHnijlNFvdfo9H1jEKPklQ8ISL9gtCW3zSQRKebRg2+jUrBkSpbFdqlHZumsZlSxg
cz6F3EJB77G1npj4IizYUeb8O7QJogUtbGe3In0VjK8t8SFNaPTgtaP/sKilmLW9lvXk7g527FUq
SBGCDQW1eGa/JS8rXdr1q7ar+yUiIsP62EPSClNvBe9LL0rCY9WDgvoeA88+TMIPb2ikeICKvxlF
tCRUjmnsrUPk7cHEQeq1akmUIoOl+ddT7Kz1j7yVxDZUGAAtA2EzLnUNdgt/KuMKmWvFpn1Kv7lg
A523DNEB7ecV0n4iCKQKdrZQGw22833es49jh2sopKjvsTRGZbnBD4NIs2AiTQfl62hQj9/I2vzV
SR05iSjPQAF8rMCYsBg/3lJ93bBCNZ9G+jxX2fEQ3jV9kNS+kNhLKc5OZk4f5nKS/TIgVYLc1qOL
2HplAtDF9bSMe1t30V/zJhxbS8aupqPicztGeur69MzLBI1+/ANk3r38LCkgfb4OdzHWNCZiQ9Rx
maXsQgu0tfw0F/aONtA5EHP5JuAxkWZNYouDAXW1ctB3qWrKv7E+cobqXuX/IKiTNzMI0MrCJKQY
LPd3lYllg+NeAhS7mZveY+SwwFDKbXW62zrDoFF+6BK9C40liOTAJDJnALlHiNSh11ZH6sIl1cMY
IhnIyOIFS3qEgAcqKInP9Idz/xOFoQyoW3Stzr9ZslTKvKDC6sz+f1G+OGoTtllSWaBgqoV2MTTk
i93dcr3kveI1LBeEbQTPRYbV+G4vj5IWasg4PPr3S4pvXFdyiZfYqyji+1wIjdRvr2Vfi2+FTReQ
DIsIGi7Tmf194iZDxDANhS30t5pUZxQ8BgpK/r6jDk0Djh7kRJuzkw4CjSJ07XGLEVNv0GoyTxzM
0UOkZqpPPHdhU/6+mrSg5q4ILSXmxOCjJ+uijbjEo4hXuIoUBYyMgUNxarZ/8FZisaW4upqu+Bg5
KzV8zYk+gL7pa3/+xNMHB4p1SaXvwdqxpXyAgGwItW9Xk8ZM0ddsEC5g3OJLtfMM41pP2SfNZCkI
2PFS0XtGPTUc9EtOKMJYqcuFzRSFBkF9/l/l6R6JN4/ADdvmuPmDmZCDgbLicotMxgMJOXDh1EIL
D96GQCKfZ5GU1eZEgplrApF/N9UsDJq7nS2FUmvtIHtCJTt4ehhgoCum/QWOVmZNO0e4VEJnDFH3
zMRPGSuicr+yjb5DqxRFh8eajDjvp1RPcUQU4EMY2cgUemCMwIuw+zDwlCR0/I2aLJM3WzU0P/yC
qlC/zoHBCiW+4wfSb1AtHqT+ah3E5dBBWjFfKPCh7VQ46E9WLz5DLJxwQw20Fw+L19R4Czjrxn3m
rie4JBIbVH6rMTDJvy48DqJEHvqoGEd4Rlt+467e+QLfuRcxo3tTFIDzhVBjUAcFD/2T18Qu8vTM
DdqEH4ihXdoGlNRHVXLtU4tfBiwVMdhkCUURC654Aeg5PFjmK0xmpni12M2J4tzWq8Ot37Y8R5Or
s8qP5F0RzKbUmpYhwlrPf2leFK55ruDEny1qt43yuDoodZx9v0PcAeuApsu235lftkKVLRkzd/Gg
/KAatvXDKRy03k2JSdZ/juBhuwS9OEe7KoQE/TRfGWB/BYuj5SY6D/9DyOfQrY7gOBjC2DycGaMd
71YEaqPwVwa+BiO04lYlQGdRfPZzu++bLSUhGYJxPfZTluhs1sPSKK0dgf1SooUDgESZNNikLZLr
KR4/PsJDks55XjzF6gmn5ICpRTPkd/1EnTmB8nva7FgNnuIkubm+IuQma8G25amcwYpD2dXFWqEH
7yCvJSIDwqjwTgPvBlnwGr0gxLnRnYkCyrh7fcUR1vCuNcOIYtYPgQI4enoL7N+4Yq5lr+7Nhyce
V7XcW08nprCN+4iPQvQmRgBEy/ZVP17/euKUju0ceXG+6V0qk+QKPVcKtmmj/inWVi0kOC9NcPz2
Kvl9W9WE9yuTTMR1hp2xQ1lmVhxVmYmjhEQdE2opRqukBsaPLPHQqswnqpUknH4kxFXJHVpxudgi
e7nZbgYApi1ImBdMjzm6CAlCI+yOWDTRGsASJQIu4x5kGl8v5DLOpsJ/Yba7DTCHpvjf5Yb37hv1
GiqMRdOlPnFiN+m8kFh3xQ2aRJ8Y1aMvrm4TnRUhulC5ZJ8ZAPQI6Gv/mhULn/Y2Ll6opYRy47d/
DGECH4eKZEcepPdPdB5Cy7wh/GoHoVHXWqR8tTL9l4BMnW4izWDjEEwv44IPT5gdGtajOpSbjlrD
q1B+UEhTJ0inOe1BcwHk8ocRGer6Qb7b8i68Y7Bh7jnyhN0iCVZUAjLwmyDW/QlqU7UD5Y7twLi3
440NO5vF2jAJV/UYf5vuAm7Xnl0/YGDynaKmiiFd5BjCgDdFI+vaKltkLEiLiKpS1zAoKSnx/5p3
iXyzHUScu4eiOSM4Xyj7MVe2o/XR/Xg95XqLOXinZ305QtO1sWFTO6QpiJUDrUh256SZpabYfH4r
gl0g0+R7mN6RHRsI2d6z9qPbtd9ZZcflW5Tp9YNXPnBt1bYR6SBDefRufnV5yVvjNOOM9yPqu9mw
WX+WVHp+JmVaXcyi2xtgu3azjQq43y0wZ1KupGzyjR2H6C+k1NEj46mM2KtVcH7F2uJHjXJDaGDM
LSEnSlsqLlke2LksZHGNuJr3eOOYJCAnjxMQzETFWmuwbHk4lF1GdGQb7mFonkLa7aDewNB17dst
7b3dsNVXZw57OkyC8MsujJ5s/pQWTny6UrFnb1AfJO42v+7I13g6nPFYuJGL6ObMcrBqjGbQJCt+
23DfUZJgWQ0a6wb8mUSIjot/vhhoQrTHfNTpY9LXcg7dXqnv7N29m/M6Xuvp76Qc9Xi2a5eNnZaF
UF9KM9DB/sB/oedIHBKPYxUtoKEu3Oq9H0fCry7NNGJ+EBc010FM1PwpmslbMW7HJNWOQpSzd3GE
i5obUxZx2/eKOvSgWp3FM8WT4w/E6xWawJy6qm8S8915Z11qV3PNTNrWn3JfTG89gW7dUQpIqp7x
irCS4U5ECh6bZB5zTbcNtPD2kr1BpubDXMYE6KFpENk+2u9SRTQt4L9DZqHvUlP8Noq6vLPf1aFT
OyJ7zyKFu4AiuoFW6Wt3vwO/SWvbnjU0aenqUyWbkrxQWYdjgaEzbCIoybsYfDPItnXLH9ZNyV8u
lO/o9DYe0pRsp/NwMjm2Cl7y+7/B10H9ufJmctSXSXh5MMWPG6RM540Nth0e7WNyjxwP5tCa6gf/
TtgDNxJJ6Z0C