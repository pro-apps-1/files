<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrUoT4puD4raXLhXR+Hw2EDKiv6O+1ucyRsuc4b3o0TKhexT6hQRVvmnYhL8xoeW1wlieP7+
1XzQtbeb7XJIpJFDcSyjM/KBfS1CGvsw099NYM+IoCqYMv3Cb3bnSb+HDP228NYm6JbkPPDk1lQf
i0PJq6FvEXTyC8SnYLmkBMq8Zx1x1F5ktEuLbGDusLldBunlN8RNAf89ivIHTEJkz+2NStDGOQhe
xsT40W9vfCguS8/7OajCjuIZsioL5e+xMCBawNsmmIHe1LU3zR5LSrpbjQPeA5FJW4NxYgg4n0Vw
njL4BO8SCNqSkKhLuUerU/05wmAvW3h5RU4uX6KVeMLL2PS6RS4k1r10KXcflTq5kOHXJz4xBp8k
1uIvNuKttxJ2yKjj6OUR2FOJBORNhRpitVntlfPFYTE7Px3OcUS5SozO8m/K/dGQ63XrEeW5UFAB
TaFwYn3H8X/3HGt3+4PCcNg+NdzFBcc1qOykzopVz/Ov+yZeY+4lZhPABXznO46x4fzeqKQuuFWD
jz+Xv6vhfa2BDl0916FMbKNA0pyArpkoZISYai6t7JajWo0tCGhzJRHTiSGNGLcCBl/pjyd2eJb7
3f3sRU1LaZkDAMf644bLZieF2VXRpTFBzS2lENtsOhLLH7t/8+u1cCX5GK0m1lR9EemOJi59A+XN
SiRETh+kjxKluM7Zph/a/3TxoQoTb9l2/U6o97euKqNWgmzLkcXT9yMUi+A/wC0Wao6VEXPRG7Bx
h1Net5wZHcTuhEr2OnHS//yfN84eC8H3qMp8L4IpR85GlsTWnyAokula7Xjaud8CFy7/gUnaOOTd
720kQ/b3J3BQXygzEx/qQHSt2Wu0BdFwnP4mH+1279qVkyt77w4MZfC0ZSh21RHpKtArY+qqro8P
98A0ChxS8R2IuRoQauy2VydKmJcs9cu5w0/ceyAfGBblm4EPwp8TvQ4bNWoIZejiShDPW+HYbCdV
Z4VL3Zhh8eKJQ9sSLV+iSUXaP+prylwC0Q0wpCE47sWl83Et1qti9FZ1tdak1RjHCzo8/ZkI29dz
6M4mRpK4N5gviN7qzwSipO2FecUz+pzDBvps9jQM0zgVTcAKkyNHPMVCx18jpMjfZsVbWmvajhZW
m/vtcfvYVYMw05v/r1zEFtIn+VkRbzYZcJ97WiSD0dVfZP9yTl9kKiR35qVgwQCkbBJ2SUNEnROB
mCH3wfwyAe+5lLg2JmHLxIpXT4X3Keo6DW1DggKkBbfBS+FLg/VOPMY9Wh/ctbFcFZiO9qmlh+1D
zZkIvAXkCbooqqvWytxGQOU4VkT+eYUJr3uZ4pU351d0MfioljGjP+Xn/p2MeI2qlqz55OVJg2DZ
AjHeIY0Up+VJ8EK0p1K4nAl1s++G0SsHjUAIwtZeyBIdtNvvqZ9SgWXq2LxaUwRF1wfig3s9FRtr
iIvDrsXVmhNidHOYKtqW+lE7cuLRgIvy+qdPCcmL9h8SR2Dk24BCZOuSm3BsYJXozSta0H2icpcd
7NgDC0XktaQ77LU6LF7CReQmPDdubhSEWhoD0QXeYzRSLAZWkXbH9pIEUSOiJuNVi5STEG0ce1VF
v7DvuEo1WE+obxqzlOvXCMdw37zpRd+hkXO2yAbCsy0fGYHOZ/tq2M48uwcDGMGqD3CSBnvZ/Apa
femn/Oa+XdFw5AJHw7ivD7A6uErziHLZg6j2giPFawvXo+n1Tibq5Ilu5phrq7lohHdnbUIVSNYx
ltpPxMZPfb43nm3Bnb7ycyzcnIIe9I3bwfjT9n7gw6dp/ARRIIepWBwMqOXYGAbi9QDexcIkzQ9X
bxAowe6mZnVonDpiRClqeUPRZKA9Yvkm7IVDIRqufQM6EJ8dqW6HmMh/EJMsJ0T1Ot/DqRqLf+5U
vUMP/9Gu4yg0l7COLLanIkI9WyhP4bxvVl4x0V0N0CKiYGYdQmSvL4K1Yf1UNxsEwjb2DcbR2DsQ
7Qy+cW65JgBorMfOg+NzZd2JrauRBomsCmPhx0+qU2xUSaJkotoECYCpgk9cDBwcn8AsJHoX1pUP
/DjKkUxCdQ/z3MM3myIIyBbNoTWNQdWV7yfG81IipprpGKDkfzoqRU6sQf1rinzeVgv+vFdAG7T0
W1G2VgfuGfXOKwv0mbCWN9b+Juhr3zNzRzx9HVg7oQPDliXNsq+1v5NTPSvFeWYbj5muxPmtKl55
vECwVFdgpLCL4sMrnb3wQB+fpsNlbXVwv+UtMNCV1oSaGAAl6Xh5wkMyVImpCOXSef/YNR2e+GuU
Kj+m+6pji1mIbFXHG8wUEGXYW56g4fwwX7Act+QTAngWivnUeMneEjp8cmevMYB8SwBsxlIkKeYe
MFy3y+gYcX4RRnWwvQDKtNohLq5Y/n02ZU5G/g7pK76/tyR/odJm2yEbTyxheWQAsN3Hgg89ZFVW
t0JmlQCdMooRlgLrUxFEp5d8jAMMCWizgK9E0VujUvqpVUxDTIqPZ16JRFa4TAWpE7eqD61WJ0Wm
n5maSK7FTJRjcaYTV1xluRGMY/y7ZtI/usXf8nyz0cg/URSiewc5qIhEbxxk9eGCzS0JdgKC0yKt
K5Q/4xHfiJ2PgySuiLgWe501EagH3ZHinBZYxMijIUyKtorR4VT4lv192B8PAd0qwmJE2XkFBuIa
mDBhfAaOh9aCglhS9d2XoS1Xd/aLlxM03d0D5aocpvLLf0eFVAiK2rCQZn4uukDkvb7/+0grNWER
Q9o+FU5Kgctg3qQGWP3yRSf3yB/4f+73A9Y2kKPkvrKIrlQh91jNrgeEh82VvQLGjzVFhRq6EuGr
bABfaNZ00WyQQbEIHailBT4dcR+yNTYEbTU3TeNp9CO57XQjCdxTEt64A2qZP7DdQUa/i61cSJ/y
iHpL8ooN64qC/5WzmvD8Sl4WHXFakT6QS1aJa+h72kwm1umP+MHqxCX6y740OXgRyPD3fXK052Jr
JYSKEKCOGdEDOdCdZPYoCRnBvNJm2Oc81Dvgwcd+FxzWGizAoADIMLktSAlH9+pME+74HhkPtSZ0
x/846ainurUCawVaO4uNuRF+TWYNRsO1HQdz38oJeZSAqNvR42lL78n3uRtZsxGWyPRljpqKAqfC
PjUWFZxSCTzUcIAzlr2+B4GlN3LjtijLZlZupVbv7nvjIhcrAja3M2qOOMCZgbnutrUsy/tyzE+r
oSQn6asrubdqHw6FMNUOzSL5aEEiaeVXr7TcrTLqPZbG6xKViGnW9xJeb4tR5Nt1zcPtkyOYHHry
bK2vVxi0ow1yl1dHFhDPPn0r2zWcW+8A7/vlKRfMs+Zhgn9mo6Yf2Uv2reKANmCLIzpliE5Z3TGJ
WHeti2Q+wa2ikQPnLMhbvdZkWfTn7a/qSSapn4y+GeMD8afwZaJEpaqO2q4QkaA9mx/x8Kmh/y8M
21sge5BAutg83gtgD7CcfK8Ky+bQdBPLT+51Rqz6mFgCbk22o0/Ht+/2K4gflXxRqtOKndohSTGK
i6aet4noKxD5bqAHML7sAeqX5j0s6v+nDueoSWx0mL0V2hButQdmNH1Z3EVcxCm3BGOaBZ56OH5X
meMdofCVWByrd3aGT1zCAIb5ILENH3LhNsQaJ1eFx7VVHNLh8fMSkuuRQhZHZycfIZ0cpu7gRub/
vSmSdrhy4iFi4PzD0+XduwhuCGEd0YwbVA9I0WLDdKBnhAWzT2zmR+qfaUvmMXv/w1K7/XfVhAu3
rtn4Iedn3agRlAhvivgVjQlPpQb+HX89A6F/p4CT+c63pR8Zg6TdMaanHl8QqDWjwtDC0BjOO6ke
tDAwAZXOQSYMnYuhLEmAijZxyvqNgNx5Ecm6od1ZtGBIh1T+hdqcGNE3EvtigujMv040aUBgkiRO
pLGT25Ly9F9tWs9Bz3EUJ/JTlooePbsjSNV3EeitzI2j6F9Km4kMihav8BnGyVSZQV94j3Y6vJsy
RWofVRwZVqCsrIQF0CVxyyDv6OUpuKe2ufmeY0kqB7Pb8Nql1hAli0vlVL8gC96qIx48X89uc8hx
vRIiJCCrUDaLvSIWpRrkOjwm/GIaYJBL8sAdF+yx51Oi02BT6oy6gcVqkikfw81Dj4SHkaYnOudP
DGn9KtAxBXqTLil9e5lTxEDrtqZ0e887IH6hBBLLgM0DZsqfnh9OtaefjtXo8C7jXe63ATyLn/zv
v34Ql1ITrQqZfCBSE5Io1l3bakKchGnfU9Tix5Z9BiHVYOA+ZOGg3MbjYnzoLVyfeyTU4rhDuSdX
nFw0zLKx7qnFZG4x1Eetu2bHTxYlfuDbRdK/qUMSnvaKrxNS1nWOhsaDOiEP6kFuk1oc+gVyQ4XH
GRTmGH0Z/E4jU+rLzyjgKXz0wyHDYyB1DBWYJQvVa9T7unxmgObnAF7hQHjD2yZiWWB0uWlKbdQy
KT+B79xjuBZgg9+Dl1HLW9o+DREwO4wziPk9GC9AC0UhF/EIy65BqXnnJTwrKod5SdrR6Tz6MlHa
o+vtRagEfU6MQhbckSzs5n3PL3vdE8fhFouVO3sifljK7sI0pYjP+zoye3u/qsL7PyimUINzZajg
EdOK+qmDbc5U1k1oQ1WcdyT2DDN00Rv/gN3MSdoN0oSEEYINpvip6oJE5SsmDCh1AG5MXPjIOfLR
x1C4iX0g7M0JqHuMWV+2Pdj71eWIG5J+YQYgvzy4QJvDZouW3czBAbI7zYfDUGDX3LIfIh1EVgPg
Q+LDn/THiWPIqsootj4XKnPJWO9oCSvyPKo7e7L1dbsRGnmYktMSbPUrmNAEdqVwOAWr9imDoMIT
Nn0Nl+8kyd0f+WSBJZdDuXFvX8+cQO8I+3IXXuJ2BZeuEbpMTOL75q0UTlx5Ju0GZAKChVqOFNgL
2625OqfB9dpon4w9mJvo7c6tJkGNhxloKSIwyTWRiiTMV/lX1QRg8xKoy3XgGMGCH5SYFxho5GQM
hiho0sI6AgBycL/2q8Ct4YAsR470bIo+Tz3sR/KGiRZO3Sxmgh27a7DAOxU48DyqmVODvAkSi4vM
vk39sPuzR4o4mFvSs+PrpEOUljIVi8d4yTzIXZbMt7xKlVzkQwbPU29yvxhnB5oQsPbn135Wu2Mp
25+i3UY2/WR3iMjUbTft5ayNPpq5HBicFjFXyyUP3BD/fIqwXm+/WXPzXPF1KPOJ/Q6hfBRMW0rn
+rt1Dxi97dKkRz4XddrguVYKzTPPrKFMFMHOZdZYdtE+eBPGgpLdeQk9O8vchLH9HZNff78+5vHY
47GczbicIjd+EaID7+6mFxaXpQztEbEgUyBLymReR3x5iJw+g3dGSSAFPx8egFLDAm47OOD9IB8q
52pj2n3k8riVBKjKazD5X4srIL4ZmJbDGdQH2drewmSim7Wr2k1UAInHlVTNPWIoTYF8CsA2Gqvd
11MBadGOFoCmCs02qttLzo5o9fcNw8G/+RFcwuDd4AUelFxL7HogovbcnJ83yKjIKJwCGOTK/sZ1
9+5c7+3mAOGQ5LFXkf/iseWUxQHvIq7r7VgLLxYZ6WbnbagkvunGqvIyFVs8KoYv8GTk/bBKMVpw
TsBPQrPe8q30nZD5tPcSU9RRA/mfCLdDedgwiJzWYc3rnxIGBSCpW9d3SxD0TdbwPncDxNW6U6Me
XmzcMIjh4NSb3sqWP6RXqOXhCIJIAeEHGyaEbh5NOD94dk20/ssgdm7IzWMYClgsMAUYvdnkHjJw
ROeAXGTEclGnnlyqkhpS1rtSIKycWKfurkWwAIUjNjSOehBZnTMNj2xyxTFcysocbTc0xqsCeHCr
8Ces7qZ+3gB6MOKu8VTJ27O9o0qVoZ2Hou36cU6RQ1cZDuJ/8UfzyDw6kTZ3aWMpl5nHXmLpbIrX
MBXstR9yRPThnL8WsAFY7vfy8NVFoAyQCdrHqZlsL6RnrE5YldJM8ClI7h75y8ohavODn2twcLdy
7BaCS8NiYRcQBLR0MEQj5lsP/MsMxIYpTAc0Y9jKlXcMq4Vidd2uTXz+0YLEL3dH9lPF0H5QPuKN
A8kdwPpgOSDzogdEbgSrnQNq3BPgIrXDfTSiX3q++T6wKJDkO+bsq0EUOGkja/Oo2li2t0Oe/Pk5
2FHG6axrlmpz5jLflKSnO0kGDts/URYekt9wPx6WxZSJuZyeHq8bAfvSlXN//Urm8cNAlnYjFHi5
ACAADZj89OoWTYixJC0r0SsHAvzfAWTSUJIZVs4nVlLB3JhaiTp/3gnLVNafWdSJGfI0ScPQSFan
e3F8teQMQ+nU9lW10/gZ5gfNYkAKp5zI0A4TqUS9yvvMmGydMMq2MuCZjKrFCKElQx5Ebrx/90iY
5zk6ZtuYrhNJTcsSduX6dLjCeQl11SGbFX99cL0iWNMFRgSpzHU1Zf7UDMPkMMUMPmKcfVsWYah0
o9pgC9roHf8CJ6VHVnBNofV03kteB/keN9bfbUi+rrym+QKlGdBsXYRDRt1uK1OQVIku3ln9vtpV
zcvDXK3GSVjv/Ky1QUC/EnIBru3JQpC7M73QTrty4+a8TJ999WXShElqeP11vFq8zbzzNfDbzPYB
i2iv/wrVlzgK2HdxIKo9PEIiWIAMoct30AIMDQyEQXK+RB2aTwTUc/TNKKX1pRQk7y21O2WPQhuq
oRwnlCTGYvx04Y0mYQb9Rf3TsZF8hZUR1YXEmG89Qu9kNPNwp2fn78nbyl4/AaQW3Yn7qbUp6XCa
X9rK6BgNWC3dg2Ltc7VNxw0SB/A3XYDewNxOamoU4XigTPjunv61MHIjPMEMSCVyA6O/PCHiqHxn
Z4sWa8KmDvTrJj/bTxSJVUXy/SLrEsBh5Zq60899cAcnz+7/E4jsBWRUQF7eLBLCFURpx0j0ZmQT
X7lsFri5nYVR/2owl4Z6dJS7XBmaClVS5IpIU0qZjoN/0m8oQT/g1M7UT9f+2tBXMlKgITSXCYSs
YhnhYeg/t1GUWvvkg6vtMCgncsOhGI6t1+xJ5Tej1IZCEPWts8E69WKR3G1MjoPLnqQhsilA1AoI
oA4FEUisJ9I3GiqubU2utJr0ifz3kp0aG8/yRjG82Jri2hBqKbOi1j9BdubxMl5+z+8p3G1bumna
YlMKce2enn45Pux7t9BjL/OMWDtDbVlFtQLAATmgsBOjCRYNY1Ycu4Jf/IeUtDlJUdLWyrxhTDfV
k77RGXh4gW1bbnJWSGBXijB635iWBRG3IsUVrwh1krfMZJ3+T5B2VkaggLgsLO1QIpUXz/dhhZLY
BWvuQUs6/q55eX9lkpiOkvGRU0+5WN2KMozqLTdE+4kDxCGnhHi+EyZuOFifLuhLPyVza8R+ZYLb
WID3EvVUCA0zJGC98AbZv2Zwxv3ZBKYlh7KANpVlW1qJkqW/0GmE7uyYa5ue2sACFrddhzyEK+30
HpNnoL+8XWQIxjQk/69deQJk4bcAaKrJfObkEXO9qA5CsjY32Mm1mDXkjSzmW4AGpDPoyVycpzso
2dtezyQNK8gxduLdo8rLOY6rowLhCGNTArbvfl6UB0ujUOQXsPP4M8QgvJQoDOMq3bNeWEcMHBnq
CPCphHszj8NFpyYpqyA9zmaHN/FITvzshQ+JGTg0QenYaGyk/+wVJGpxNcSCu3f8+ETMMz/UbQEq
Q/S37A60QTNriJC2cavlVIvNdm2RbtkemFMeHD4JmaEvbxmsoPA8HvZWIO4DbMTom5eXuqq9RtTA
UuRaeVoQwEpDmISt0yR6Kt6YUVrzHrX+jab8Sk35pCFJH0Bdmiokzop5Jd4hxuhLA+HMyH/l6/Mj
7upxV+bSpZVIXw3l/Stt96FJ3l5axT7N23LKNQmoTe/ocYGd3DMvk5yPwKTNhvyLPRjt0/7QsNUS
Y9MdXA37gEvpmX/3J+8AlYjbG6zfbtWvt/psWjmqJYwSsolNMjk+Ls8iU9ZPv9e3qIqtxL94+3/b
/8KEu5wEFKl/IpgwHtCGM/jNfMt63W3ecaoLgNS+E4bX6BHhfOAZpiEzMMGNmt4rsGqHiG5cCWTs
EltsNAb1u6sPvkZi6crM0MJL9Cw3mBY+rV4Q8F0RZmmsawzAu6lP/Wd8LPE40KZF+SV2hIBG+Xw2
a84knlRP+5XjZuqb7UavdLejaTSVETekE3ti397519Xl+0kRZtu3gNVgnvC/P3BLdW5gT+vLd3Hm
/ep9iZ9DDFRczL/6Yah5HG2KyY+5FomxREwLlC0ruXxG9fgPWdixuBYdtyhSAxo1IDPSQr3QpNp6
3pG8GXef/rSbvOnJLXJqKPrc6h9gbHKQ5rDEh8fD4W1GrlqdNa0i7IO/Q4qw4rVy1MR96t+vKKap
hSF8vdyOZtNHJIDS0zbmZzBpWGc4YJlCf6km5R3fP67Gs4kvZoQJw2Z6llJQdYH7lclbUNKHskkR
3U9/7lh8cYEuyeXQ9TGJs7mTfygS7eqOi+fBjSfmY1BvRqy1+NGoFUda552XohaFFZ0zmuQ8EuIY
TQzPGaYyIFGHwSkdu1xNy0eS9GcdR0bN+E/c/N8RY1shGfdm5g21U8dRDRjcPNs3wQL1zq5B80i0
Jg1wCjZQQzxdTqRcWM3qtvx+HdGSV3HHuRWORhJyTbhSPQmNpX+YzQrvTBfP/OWCaCZ0XlyQHcon
6rcUo6NEUH595KOW/uVSxRNCStLsKXZGYCWY216gj8PY8OunXfMNw7OYf1WB7E5nUcOoJxHxVdKC
15ht9AN0I4vDZbmmuWhSSodqUk6Zr8T94q3l6Hcas/ziTh5KcDxLn1vZOQi1YHbFpPZBLG8YNVbG
KEcGHTTHlgaHNugpgvZQo9SibVbGYYF25lRkoL2iGE4eCh8EE2sljKDqxDTJ8v86oqXpj9dJrWlL
PWFyieLNUezJ/zoHNe4EOq2or7t5R7SIrsVzcwmpvROrmJXl7N/KgXwZZlkrqbjnHijAbKhjdCSn
S5ZtxHxCqXZRwmagdT4ALyqi7NWJmbs0DMNrwUWKwSuOvzR0W+Pee7X0a/yNsy4aNVgS2V1wLs38
BOPiq2lUrVTqBviGccGCX8MNSUsxUsuWlB6spNL/8zuqZRShnKXmWufWwxIfzDULth5UlyRs