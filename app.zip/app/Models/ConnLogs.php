<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsAxz2khJyqCibDX20MyW4NOMlwMOPjvzA6uQCFiUzEqE283vEmuL0GJ2QBl92126zKrm22f
hhSYJ0KsixvMw3wEM2dDfraHo/eZ2pucV+aBaVAXHnSOBgO1k4P4W4LQammPoGs2kqpnbcP8hhZu
gP8p/bp38Yy3WVo9hPivCED/BbhK96snHKor0gtKDbEXTmggEamzHgJ4GnXIj58TWKexwowzphAl
aHqYweiM6hKADrb20MTR/EmMRjVje5DjXyFTUqoPPhjLP//toGYqjdKiFanXZ++66j4POOquCc1a
yDnlR7eKr6wUyexktHAAczKSGOZsgvWePyPQAikRPMD18v/mWSeAcO/kW8fLyXJpwtwtuVS8f7i0
1QxVDq4wdVVGoDeh6qIBERJSx777d3+kK5J+XUadBKx7fSPBVBW3NK3ertyLEr2j6Suj2xzcTe/c
7f94jX+HHeyLIJM4pBNZMMnpalVQIyrUMukd0919xnhsPGr1gleTChKkthVF3X8fSQkHTolDJVlj
O+PquiSavO5KVjpNEHP4hZrQL5tQ7BOjHDs5z9bWGBuQbji45MxCvJL5Yrfp6mqkWjqulUrzVd8S
2TQ9/nRCDO1fEG332d6XjDdMgkaclRnUaD0H4ocU4Jr3M5d/jyjv5EZPiTeYcaZwvZ9EcEph588k
rg/NFxKvLpgp3DGfx76HHAIiNah90/ynE83cCTWMQqKiI704uXUCq6sx+XXF/QcspUKV62S3HNrQ
lD+cPSdVS/8jLI4XByi27bDoUBB/8s4O7METQkky02kHsTr1HzCsVmINszU6nRWkto45OBNikqXh
6v4cogmJfZYnqHWMGgzfdz6TTQ012SSUMN78Weo9Vj6PUiLQMqpyc6Vu2Nrp7e2WQFOOqAumQQTf
xhL9XAiYiKMDKG5erjlEzuWrHWJzQmH1chfuCGM3Pdt4rrrbsOQvINkYpy4Fl0Rr1Nkg9NLY4pLk
UPjiygwyNlzoizA/D1woSYBvjFQPOVnxA8RxbNVdr5nWyZbU8Ti/XMYDgEuai/B6+c5ns/gY8i7N
WjGsV2W6o/Cw9OUIZdJaBY2lE63yPoeoPl2svdHYxd2hpkxl0I3eBJW7C7Vpyl1ATPVQQjrLq8Jv
UsX1YQdZ1bsKZ3M7K0spJmZqyACCiRd/fv4CZhQ7nmU4ov/bsp2Rc1IP04B8i0Cwhz7fRZzok1ec
V3T1vL+l2k2TtBlqt3L/BaZEs9C/qe3J4ng/Lj9Ot9MkQ1cKNwXRpH7DB1LxUVy3yvxn1vSKhGu2
GXYEV4PmMMKdPaBkfmRnSm6eRy37BtprR4vpz3xGJUySq999bqUfWjYOBlAzB6AdydA/gK8jg/FG
Oo4pC+VmM/RVsZS1SGPS4Abn724V8yRMGWtL/qusfP4Q9ePMEwLjYALKwZb0RmEWa58NdqN8Zg9A
Izj1nFRJaFGR6RmHkZ3VyRmC5YVAS3ZY/olVc7iiV5q9Bln/DfTqQuJRgbIJnYeqmoltfcRlgD3V
xy7+C8vJdD/gUHMi8UE1jQI9+Y9ddQUe+HFrenONkQiOopSFOBradg1jG72bsJQwUEq2Ut0fxumR
HKBwSxR8axROzzgYwuL5DxaPVPNzQJHpgut7NlRtlIyWkHasLOQdXP6sWbibT+d3RXmsspQ+dtKT
qY7RqcOxNEziCbNbGT3PwZzNCZ3kv8442hOqcjYl8mPmmjcWXoMsjwzX3eCigdnBLdS/xaoiGq/i
pUkjG+6ZdXfRaNf1okUg8rknKz45YmHqu2htHsWo6Siaw7Wj+BvRobWUDb9rltoDvV0hmu4s18HF
KsP8I0c1Vz+Qu8Ajr6Gn8M+1/B6tQcJAwP1n9R8tIRO2Ixq4jCjPrJKZinIhsTfy73CJWYwUgGHl
WkRdthot71VIXntO8hhevlk3bmUtUjYFyFL0SX8FR0lULwkWt8bPei5UoyfcLH1xiMubCccSujqe
Vf1yeU0rPO2+JfiLQfNCIXcTvLBTNYw/pbDeLi58jb4+INxDQW8K70jMKF+0e9dRYCAMNL93rwy0
5z/3EUAOZLWGKrPE5QgrLdGHo21qAwlSTzim5H33cttsMQmZu/r5xoY+e4StSn5qPjBTv+P+WItL
nIEj6OELaB0jJ5jxcajjfmHw+4e3wn1zTrgtdVNmqS7yXEE+O6/ssDETFreZYQoMVpIeOyUkyOZ4
ho9NHE6MDJJ4xU0ZM5XGUFK64T+9l/Yfe9opCaw9HJTXwxjeZDROB11vyQSQ8JxZuYVJiVj5bMaU
oDJwB85Y+Ds36T6WuaK9sLBI8uXVUDvEebcwoUC8fipDy0mUp2aACUqIHXKq7lxJ08Zmaoqqz1Gv
z6dZ4kCJFaIhCrt2Cfj3/qLOZNpaFpATus7ncXC5QqvAAr682YgEgA/52WSUU15WJlQMBTGGn8SL
xQxnVabcVXyvMBh1Z79tdQWdff0K/1LBHLhR35C6kfR0X4p+J9Sgl+Nbo/vPPae4erGGktntSbXh
XqHKJMGESSgvLpRY6xknF+y7bnSULJ5rPAP0uGwqV9JhyBk8aPFG8zxko6c9y0blQJjgsuAHbqZ5
Qvcvz2r53NAdYLTbatdNzPgx+y7glNJrUN0xMAWAz0mI2oZAMclUimobZiiRm8GY4SVOrL1Z7i5K
Xqv/KR5JORh4bklCKRn/lWSsYVieG4IWeDEA8Sdo9UcavzlJMpctv2d8ur28u1N8qkQS6T4gtqEC
VJcv8cRXnat6niT4U0zihcSrVRDKlZWhFSHk9iDKWEXx3fWW8ntKmMlnn8JDD3yj/RSjCzXKrFpo
aIExW6tSL4PG093NECiHrvVqzVfCS+ap41w30jC7ZFjebIEvEa4NmC3Z1IDV891XEQlRkShyTrbi
dWDaXzvCQpE+Qv308NA+FTBtG3g04tmOVl5GSutCLYZqTSyZWJ2bfs4JI/LoxrVx+S3JZGzFrwqd
QcepJF1ZVD/OTrbtzzDI0jIalHKxZwlOWU8Z2nJgJvVEHvOujGlyXJtTazFracwVCau9xU3Xen/j
t5aXOrSoRMkBKVIGPos1Dc83AimaGVOXPgc2fu9TL2kdkjfu6X2oeiBDX0E3duYSEEMHyBpAiRg6
bwDiwhZVhxNgzegSJ7723qy1zHZQ5OCUuRpYeKKV5jPRdwdMQccHVy0nkevvrEw4jr1cRIjMv7CU
qDD7clViMjWeaCYk6uZjHitwf75XgGLJfMKZfIUlW+/0u8vBctEg0ry3gNpw7FzN7oxGatbn44Ye
Yr/voPyDaz6m5iWWCF/VqE3khitGI2vTzZH524wtxFD4druCwrlCDaHgvRCmY/npo5rh4oxBxlSq
qa+0JKBoZY/nmX47ZnnNjYqEDMnf62e7eUhKNRdhiaxdHhTenLRPRT+1UdW8/w1hPkakLi5q/oFU
KQOA3TScNy0kXD9E+8e3jc6QjeoeKm8zxQVliAUVKuDTYs2sT/FjUXCm/5Ox7IOSZLlev3gMKuZK
urF6TNUsZ86LoiAy02627VdXuSygi1pNZ/1KYOh8Ca0VcpSjGYGWJo6bwcm0MGSC+hoiAv9Nzed6
4ja0wZKVjoSrHi4rf5K/JEc9l/UnOpeT89imncjUYKn4VCzuQ+ZhiwQaSfLxJIaAVBmMSwlBGuwh
yg3j5cb+kHGz6ee92NPnGXYaodS2FLsaUHO05g2+e3lRaZUAH+VRlLyBhO5mkep2oOEre3aiG0Js
hxmEO90UrHkQkEBrzZWRwnskXeTrhqA0tml/9VuSrEi6ch+Wfm6v0BlmZxiqpiJ4ZwwHmp3GpgQY
OiknZPoBUG+C9V1RpOdH05va/Fnz3Ulj5tb+5Go3oJY1xMxcx5oXk8e5MI3alFLbI4aufGm3DeI3
ekAjKjG7xAiCx/j6hXkajDcYV/vmsAyK6zE9RTVJ21NLOf6KXbI3Lz1qYeLW4iZS3xJAwdnC7LVC
8FGKsSqJz2LgZvXY3JEDjP3+2SUC1KLsp1tpyswia22NPUShI82/d2WXGpec5qnONSgQxuwVcdgy
2tY9A6ciKSSDJ+Gfl4XJ0laoSjwvdOP5lduSfie/wyckchydwLO8cRxj+xmqlM9GBEEJQVlnL/yA
x+DpGHjLrrzfPU3maLwQzOGj9MgQD3980ClJO/i0f8QWCEIiBr/T9i/eMZwJjgWCaE1Xl04Hf+YV
91Aisp/nvnQkZivkqaba9xuE1R79a8H8zvnFm0DOeIT6qDRiV/yFyOwq8K/eW7DgeX3IQINsL6qC
3w8qNluX8uk889IdamTc3lxfcLnSbR1Ut0a/3o+TudsmktZ4iAKsvWd6lvx6Hn2B81k9BLAX9hCv
7/uEKtiZ/j1h6sao09pCZvmYvsdrzgBwxJfllYTvztLZmEgDEF9wXniRCWQWarrA4zgrP/yfiOZ+
MTekbY2D06H74IdOY9HHwSuPaVKGwizEvp8CYbeeh8CFhjbodY6OgX0f4xiFqAwXYBE1sG20PKRK
+EZy7k0tDTXO10ZjkzzNAi0Wl06nAUmEJ0N6FbsKe1SVWSnnwIYvOVKMmY/esxukBxq/VvVMZdO0
RvZamewgDuQd+WhcbhFCU7peL5B7VRKLtFrAKaLFY0eMllZTkMNOd6Ax/t56Guh51kM6J8nGT7Gc
dXKlUoO6B1rDEf645J6Ahp3yHYAjNX7lo+uHSG33fE0pQMACSAVZFrlkEe9Iw9yLf0dc3VNpaonH
Yj52CEfAIhplQnHJih88RCyPNMfw1DdhoP7EmTEYOTLtlI3xJOvlIjqkZVCM39tm00DxcKtbeG2i
rnugOiB6Qqz0LVW4zVR6j3ldgz4+QwJWQwA1lzVR4T18N/opv8C90E8ppi9YdZWFQGdBYG+2RuSK
gP9929VwOvDHzEDEDPX4G/l3zjPCDi1DaOZd6/vRY40RbZ1r0MBxq5yV140FILLc/ypkJaCuqhpt
VfoqtGG36d1OfsvgImPENo5DwNUvwnlnqLa9K/uCKO3PLfUNRAMGc8yB86gsDVYH6RwoUTar4w5J
HI7OyMrx5S48tbOIeJdmq2M3WMnVvzLcpOHWXmbzUZimDXzr5CUkfJRPDQi74XXTmGV72F/muI83
z1ae5/IOJ1vjCQ0B/5LHEnuuIq621D+uMzZ1O4I0e4bFGsX7FtChApJHa2GbjWxaMI8Vw4wNvyvc
CADf6goUkHF6dXQbK9SnSLZQexgHQblPWKFGIQhNci3tOJhPECdInIGKevcNaLFhLJH0CpYew/W3
1ugcbs1FzDsyrV2i0FRIz5yedJaX0aZzGkXLiXKF8liAMeyVyvqtdx9q8pG8lB9ltAS/CWP4Kft3
upexigPRo22Ox20BRbzXg9PnMsseb8LxP/V/fK7/1HrvgDL0QsskDeXXmVIGZUv/xmbvGY73WhIo
Cy170D4Hg5R3jZOgxSn1eC0cGepTJ4ALM0ZgbAt4zTpAbt2dlA2swf2PbLdpny+ETn1sPDsqJf4L
XPiVwcjwPHlcNMGUB6CiASKA0BnwZNoyi0OKAI+ftUigHxqb0ByYCZ5WPykZh3APMEwDIPBMzPlv
ZEnxrUBjIyfb2ehzytgmJxZC4fWV40WRZH/pg1wibvmSQ+kuzWF56QXs15On0cwX3vFthTKAlXZY
a2dbVRAVPuZbIZK/WSTxum6PKsrqFdfjcQPzG5Alt234LwBKnUibAGUyG0ZXxbvFWJ31XYL+GKbM
+EQf4zfoTD282L1+JlDZwvn2PfbiqH5Y/cs6KUK4FrqgCztdJX0VqUxbVo2d6nS+WbKS6loAJL0A
DvmoKJQJpQ4HwqU0/002XcuDcx+pXBpFSQbtYVqkcFU8BoNyVIlamRBxdRX5g1YfEeiKM+oHZkZr
+U+kBlYPKMo/83r42gQFbVdkAnPVAXpjAjBTwryIQorsdOGnc7hvleUoYXkW+ghJZvL452RtucVK
J0DN9AcTadysP/C9GAc+aq42SEA208+SDmxTbyVxMC3NG2gsRpL93pZZDzzCXtO3zTd7IxSqfIAY
mrvNKp1aiL9iz99WB3aSgI6ACkTK5wSAOxxs3q5fq0VcACjPviN8fYBLAzi54fXx7rL1ZPqHR5k/
HxkOcrLWlBuY90XMew+x57y1we/UAbT4iZqE6/uMOcGD0k9F6jjTm/fihSb0UjF72d6icUyvSTcb
YojKNrt8XdAFK8WfHPdpf6JY/MQwH437QkkhJv50FI9CIhsYIK3fpCUhLuX7fibYjHiqkWC/NOT2
w/PMSPMDeZchBUtKkzUkwl4bclDBSm5DAcTzs18xXDqI2RpKSPrp+G5ZJvAY3RIZe7DnX6UQ6gGA
ye3RUNkuKL9hnEQMt2AHDEfxVWXGP4pp6aiL4OijudmtLnP34SVd3Zf+65YY5MG27vToUeeHxrag
t1tZHWP3hD9Ti4t6aCzQYesDwm539hoQn3KSbl8vD7g9B9P4VI/MVWjZHiVUozgthQEIDjm9btQQ
zI5koaXdxFHLAiLu2i4lIoYYpK6uCh5pCMa/kWyGqHcBzdRTg6oXlPzFyhIZjNNJT0C0++4RfAXS
r7mXaTSpjw/CsXDx9Dkudr9Qg8k3UeVMR8haVScCFGziHGvzBbOvow9l4T9lypXKWyYg8jpZq6tT
RE6voa0qP2Y621pAh5x+ZbpzDpFI7+M9jdYp4tRZMqFgfqxL0COQOIoUgkMIVcqEB9h149AbfrYi
qhZvD10Ys67dmC42oGIl2mRq8t2oKQiZPWAWzdUztQohseAQmGxXTsNpIjdC6WG6xBPdiCqXhKDS
tifNDa3RfhSkXLHrQ/bgUhYL52py2Mhfinrd9vHpsAFG/e5njXLcRL73dBy1AhH8QZZK4ckZw6A2
tu0BM04L6ksDt+iAadQkCc2zQv/GtDasjcRCXpT2lZd/LTrB8//UYpaPpdkur79AeWoB6TJEWjYj
3Siq3Z7ORGeJ415QhAy9KPjx6z/zb//GDbrPX9Zzu1Oko8TObhcn1Sk9w76mExtJKunHfBKmvqqP
Mo345H7VciCMbx1nnmXexou+a3w3T8JFG7R0zp4ZMstHSJa82Mvc7nlBLFBInBvHEmjBBM2ttlZU
U/2hw8+L6aoypCfToxxcAM//GW1iev5qYAjjSD8iNAUVrjfCIM7jOz8MEgfO/l2fCOtTy/ru+f1R
/C9r58pybUrwv3kqGRdoVvaQWNu/febsmgYuESoCp7Myx8XNRxx0Tjm4QbPVq4XffBQ8wzt2gYXJ
OEhSA9oqIzTCXqaQdbEDs5kxqyjs1pApWuxpnAbRZWYXx9tq7cfio539p16EtHVhC+tOeVMyMnbx
pvjHvmHrn025Bx6nQeOhHNvEZYeregN5GAK1w3SGNu/y4kaXgtC7rOUg+3j5+W2sdFC0lzS4ZTQb
qPNUB+FlKtRgAMywQcnbYYyZyrANn/vnbU0bwj+S/zChtaaLhoRPX9bxEBHkUTg8Uaa/Alx4EDtP
jXnmXRMHtQripj+UWFLiaRR0gt6bsan08ALXtn/6hn4r/qw1W05FQHeKNLq8aMMooxXaKDoJezhx
YPjQ2rqSdc6jERPCxB8JcbaO5lPKdxBatP/6SELhI241tbNOCjG7qWfY/zh5XytjclLdxSAeI7vV
2R1u7LRu1KFzmRiNaDccJydomGFSoAovkzjIg0/lnwoBFrTW8mmulW+/kWgb7d/BSsTEZeLPKwac
oVYeFmzpyDTfZnjiWhszKDVKZ3iDNteaUIn2oUeiFOgvEa+EIzu23LvXEO+x6Hjp4brxzcLWCa6t
cX7g0QlGqHsOFxrr0s1OTVJMsR1TzZr4ecwur1pqh6KZwmq5r3SVeSCzdJ3RFk2ABvXEuPKPTecJ
shcbvhk0s9o3Ls0xh+/QRTKbmMH0qeoceWsG8uz1wNaOV5h5HbQYXqQfK8IMDnnm020BnSIkSqn+
TELwsEq7DcUUvW1cvuMHOVvxkpOA4lHQQWUGEvqFGw7ZgkKQR/jD74ZA0xzC7xieu7X6ghWGbAZ9
tNiUvdHASXlrjk4npKuYf8Ksp/prB9MkTtu1ibfaH2UhcXnJK/i6JkE27z4DbcA2VElfSFRWKN8Y
Ip3KcwgGCCPbq+pNuJBOUjdGrRaVLVpYjUKR3TuX0nX6QimZrsgjIJQmwCE2uupBsZsc0v6he12f
x5TWzxOnP321KxqxTBRJasUsDIvbQLa8Jrihc++h0HkV8HiLWQvpXG+yzmUDMJyZ6k7yx6EtrASv
D/NAUM+4RCys4YBnA5SZrRn/QwtwvWBcA6VXQ1vxf6pJoVo8VO2qN+gS/3h/6EBIbMzFLVoNBui0
tGgC5eVfQqXLdWp8jFDDswEaTUEtYGYPg9s+3DQh2LvrjTvBnKeB1JHBGe4Sr/1DE/5nKEOZ4qrF
SjUxFhYrzbCTas3/lg8iPjq27DNEzZZIzlecaf1eOlY83yGrmXvx/51/v8gH74oYvxYCJyE5IIhu
uVzMgnDkL7OWBo042otnwF4BHUbvRWKGd92mE0onOCkr2EAKvKwI6W2wOtPSVERRLTnmtRuD8vYv
sbxa+UJSwmkrpPIRU9WG8tLaBQYajJtumrPEr1PPcnOKEBcZaB3AEfZF06QiCqVvKXvjSLDuMivr
URwvwmRw7RraFn3i2c9MC5WaSZRC4fSYRbfisx9ywwAoQjqsCYAeWqFwE1tp48wJrx5rdEJDt8Sj
jHRbjX3atN25yqZL2FjElaZN88XdkQPPfeue9nAaX58ILZ/OTc9a4A1DKFnJDQWHa8OxM5txUN9u
uLVmxMPicnKDpuhp4HpVcStMon/mrdDwlqTYfby9kMALUf1F4kQeVBGmggUJvFoSAdnoer8TIlvP
60kqsROhmlTdu0RzKno4Jjm/rv7BxkAVqHgR/7rD6n9HJn/VQfr4mGkmFql2Ec2XXp6MRXYooCH8
BrQTUv0EUo+8Sxgd4glyBgFVmcNKENFYKafkxm8oLShSv83+tmQ01UsOMHeJbG3cZQboE00W9pqM
D6BOEvSjPu9uLHwNQCh+C/sgTngUXgEhfOet9jJC7VQfIsguQLlbHqPhFGE9aJVC6OPhesdAvO0=