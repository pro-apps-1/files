<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrTsFnmxzODJmfcgFmgpOUUR2uxw5bMx8+PsaBZVyk58PT7i0beGrRzm2hteBbqmu+JOIF7o
q9SWbuE6oDr5b81wWSH3ESGlpp80YGMuD5SxdFmQy+08u2RwDmvtQh0zQDMRJBgAHUZGwOGmsgoq
8JBKVyFjHAdH6M6DRmRhUno2lNlC8coFwsySBmbsSVB+5gz1A3X5GyAF+fH3KMSeGg6HhAhYL9EC
0VwZOBE5zr1EjghTR1KN4lIUicR0b4b7QNdPptOKAnTu21puFx0CpmxcZiijQcU/EFIBQHviZCty
uT5AVWx7JGdRkLP9TSJfpfO0S9uXIF2T2Z4LyIIv+GWUpOheRq5OulEDBsfgJkQxmN3IVoJRBAff
X4QWwrkdhPMCvOjmj2SRd9MfK5u48SWXfzpHpe1ybSTAwzxotnuuS7mHhUw75Zs8Mehusqqa/Y4a
M2m9DRjKR/9vUb5QcjG2t0mattzhqchD1t4BQYLkQK3QvAZ5ghJIawjtb6pWNREmmdk6eU48gOIW
RncKE6O4IByVwX+XB+qkrlybjj8xZWbpTF71c65p9xJfUSz5AerjtnVpXOe9z7YKh+Zi7ViDX4rD
+dO41+v9BfKe9K5gOSWgkljfhzAkwv8xH1ERui0VjpPuBWOk1KiIsNHXZjeb9J2u1eV3wwRhOMAo
dtJTIWhF6xaFyXLa47qY72ci4v+5IzQnsME5CctJr8ymuPgXYhJVgU3Edg9DIi4GkqP3aPPlFZwj
p0nctCUMFocwFSPrN8IOs8fLjrkLIkrMy/Z9V22fluKXv5DeYRU+ugd2wdR4TNy3tJa+O5t2ECx0
vw2E1FjzhM5XQ7Y7PcCZHoAjELaXCeaIDkMIvKXzxYDKJALY+3vk92QPXhx2TD3Urv1XvfProAUc
c3cbTImAsKsX4ewgxczq6YgfOZYk0s4KMErNbOOe67CAkVAu1zF5zcw30Lgi8wOeewSCfMOg9RLZ
/+MRcX5LvuAERM+A2cV/dXC1RF9gqff8AIH+dOFtv+G4nvLBfmxih8+yd7VUViN0WoN3YxzdVm6s
tY+d0n+LJ6ajaQyFonoHKWzCX2SOsKtOroVOrR1Mq0d5twft56fqqgskLAIkAAoJTdIAoeuLDAsp
0eTHLey8omNgcuQm+FNQDiVkyl2eR8SiEd1hrJ/84QePf++/i4imUmTVqTUfrVsEkb06B/PCqDIa
MVbHWIa1sOGS0pqoqOQdIumOg5hZ8aypC+LxtoWUy/yXkCvw2W9rqKi9klfNmotemTPXZAth7cVp
W8Tb8Xjlv2e2GAepg4RFOEZiG62wnYbN+eoFESQNfm48/7lDTVUArGD5K7mSyi7Zlg5FhBHasv8P
89q5o371lZ200/MG3butrP/moFmj7SP6gf1MUmyGt7AROcgxRtEBKVgisfXV2l9W8ERgCe0wMrca
XezhANkmZZ5b3w+C0sw4kBN5+1Iu4mMO+xYf44q5iOiLmrhzoyPKyerqeNpLSu3DDBMDuFWiaFLz
MjE9ruugc766idKhT/zMCDJm1x+R5PMWtdtAKEgtT6zrik+liCoFQAZXSfsmdqOf0KSPYp2Wi91Z
zqsnLPgg8QJZvySLScZiZKOD96oF57qY7uvU7uncoTh01ftsMXeejX1xyxjdeUsEzjcONbTgG2QX
rld9Lv3GZfgvQ0pCJYZKXpuGSnfakjCM//BARPBw46dHFgcGg4lGcO5GZnhdDjkR4nZ4YbDJpCPe
lcHufvi0vM3QM6IU9b3ixOIwVymXCAZPONz7drteapwd0VtDTg52ISWAvp8o0uUivPtX5aNfEV14
4m5gaAAmc1zJQN/Vj5sRwo8PbZGG/oY3lxZmWi6tQv4c/I1yq+m/8a6LuJFcrG0OOf+60+Un7+RI
MjpSYFa/5gN+32w+2839UblcZEWHYpyCRYHqvwS3lSboSZLdct1tToHvkULG/1wHPR+qnLjafGNx
5BzWHjbCbD9suiG2qnn6IiU4R/LvebZ1/w4fpryJGogVpTrcx2lGi40zn5JjCExl24+pctR/4rYu
sckg3BMPVPRaFS6D7juCR46opOO5K37DQ0DeXT2gpY+ohx3oVDkv5oKcLYmYCe6B0c3HLxw2/lth
Nc3H0AwQ7eD5kOgmyCHOlrxcPm/B1ITt+RUPVmXeTD9sUf5ixswqlKwX0Xx1nui6fGFBnPoTq+yk
0b2vBbOLixQ2J11XPLydLztCXFo3u/Hxi2vzBczcrdTaChx3NS6xHnaorTOk3OZzg+nPbZ2PY/FJ
h7ATMK8Zy88OFzl2iGwzuWdXYxrD8lvzJEMwYqzOieLrhVMAtR1tgCoXIL5uTeM1sMpXoZaSMPUl
1qBzUxHXKrqUPttEVyUVrdPYweeVkIRN8/zfwAMt+h4tsTdrjnm25onFXUn3rxWa6pEzidBUfK0O
J3iYaTIwHjZDN+v51/wHwSKxf0+WsoIu/1NrdFRAVgUVTA2FKc/hwiIrgFGZJ1SU3d4Bw1Li6ouL
Nsgho6PN6B6f55YjIaQUWllmy6K48XRHP/juMbADtOvuLdoe2pLFO51VQFrDI4aQNeIhzWnqJX16
qVhU+7Ir+opUfHyZh0IKZI8aMKiVVXZenr2mKmKH6B0Y4bigADOGAcFrWqH+OOlCOBT6f8BDW8Xl
zLsensS9WNbQ57eu07qbWpuke0vBf8NS2290CB8pQxyDBBOfGU9WOND9qXz1lsvVbafSoS4qOQCH
6KTisXVZ7M9hB9CXoDw6Hss3XJ1CpE7m3wN2eooXvBeCIef07xPt0BjngrCRAbksLcl9rM0ZAr1s
RwB+YbCtirY4Uiuce6sj9j1NrMdNmKqpFzxLqfOwqCoToxTMcUoKhNsT/PP/rSzRGpxZPlRG0oxp
71zwtNjiG3Fu/3qsj1ZYBRSc/k1nuKC4mB0W2nVDPA86BsgRbquth9jhJ0d1Y4ruZ7/qfBCHyxd9
axgX8HOgXv4uVxMmIf9bEpQnLz2jBEzL8s7p4WCaBzl7vyVFcBk0lZ5WkLVnNNzho0TP+Ypz6UDD
CnMARVgUTa8o3wLRvSAfDAKOR3iUkk3bp4Rm7XbfzQ+2xykJvxc6I6DPrupqnyt1lhSztQydV0wT
hODgOWeNc7nnxU2MxyfsfdnL4wdMC0N7Mx/BRo66+Rf1xQOFM9Dyj6ZaTzECOxamh4X3JCElt1ad
Hnm9rJE5kgSoIXwJ6d6Gl87ihfqWcVmBbOzmjbzyeSp2lxsBlPiaCbtBNMRoDYLBGxD1ZyEITPcu
uKH6ulKGhNmrXh/FyJ/cPBBX9jZxxN7wb5nhrMAPceAABbID+iEKER1P2XyxtJyPsjfs/QWDttYD
TkcprxXpPoqQnW08jXWuc8S2zUbuqEGnKsra8SmJJ4ICFZYVA8ZPjNPqvqom/tXEOJZcj1lC8PuX
AilJDsJhvG0P8Ml/PZO77YZ46kq0IHCjBYfFV+ulfgUhmsdj/qZVVa0fNDiL1b0YfCSLWo8QAdFq
m+qV7X4YyhmrguuUX6p2qraGy20t6VD7+PV+QtuAIsfdc0dzMCJEXY31GQkscd28b+OpSOS7troR
SdxSIU7PVjuYwerzHxq9DuZRq858qYMn2n7j0BKxBxyz6FMh/KAdxgIcc3CSIsFh7FKV+R1i530D
1TFqduFFjw13sTIsqPqk6sCiS2WGPJKuTkgyjOC49aisxeN3niSPQIoHxG7DbDF37uP6amDv96v0
9oHk8H6jDgN8LmLCa4PvgD+6G7X0aVGVYh5fq2lgW3VjAvdVMmECB3jA/uwhBThOlUSoj2iqiDO2
UBhDUXjXa924Sjheniw5zSpYZ1Tujf2oejV5Zf721CA2yHxGhXY8qhOz/PFSyep7ItrdkumfFg/d
HZ2QtQGvRhRZ8vJU4eLnYfgaNBC8i3KZjgPR6uq9oZkecoXDL3xrU/g5VW5wSqepfU9c4VXu3GR4
HhZMrjbKURhgcAlgUwR093OmXUg+unEYomq9KJCiIqKmHrR/27WAVDo2pRslFQt2svBRXvCnZOu8
XmzIBs3tN7UkvdxRz9787FSiX4+F4DJJl1yBmVx1E+pajAqGz8tsaPrOAbVdrGe0a61XWBtzY9g1
sXg5ie8mGnWtOPFAFaHvv9gHU0LNEFT/feWDN4Kqg5tZRSsn/+IWxuXJCVaKCSHLiEdXPAUA9/ql
o+lMkBQbHjO/6SYKfJGXlJ9wmlURDm3T7mzXLiuZIZX46Wz7XGnx3U9EVEx8yageq+vBW1RmQzOm
he2Nwkg66XLvWA+yYv7RcqlmvNEHz8IjGGyXFw6A0iRkjRq+jwrK2uw1t3vrxW4SixUY0ivGkfb4
u7OM6NKdsSZIEApFOMjxEeWKSBowiylaf4xG9RlVhY0vCQDX4Fq8ZPex9Z3f5ixAoI1enHr+KpHh
nbZN5W3IxhfBut+GWgMhKx3ek6ExORVVqUZTrR4T8FvLvzA+b+tVdEfcAjdHLnLZ55qjyYrDp+Ta
BkmL0q0OxbabgswPZO1PUSszMMHd5PMoEO5iwM0ZhPGc4orJs4cakt1W9/qp1TbzdrCNCoL1lhXJ
dnHkFleptyN+h0gYAq4/du7ubWCtbbovOYQxozIKR5AXml3/dpblkNzJG0C6XLGr+Kcg4nZ6Rjy/
5gCuNgTMK7vpLEKs9MNeOrTrupX7aIhfw05dI/pGmDsoyY3aTV0RZ7RiP5YO3Mq8jbuogMsRLU0S
hUzPEVarHwlTkCihCq+dQOrVYCLMIqITXNRkOhL3YDOzfjN25Q4z629D/tguS07CyYkPC8nKpap/
KKjofe+DZpb1iqH3wYM/g5koAVrfhLKZDlWViLMCq88bZE7aKll7ZZ0jTMSeuz6nrg5xq6/aOVXr
o6deSKLinYCdLQkw92U3j+M/UUY1ceEdQ4/D3sysIH/zbvLotQRpddXKl0hlG/UGzQPqE1z4qtfn
gFPkyxBBTpJNh3OFVXdWOsGallVtOEQ/JEq0+JtZUFoKNd6XrqPjDYP/jgkb86g2Y9epJHhw+mom
+iUq7t9b4YCEFTXPdBh//m/+/tU51aKX49TvxPEZjDjlf5qna38WBMsybcjMIB85BYWHFzvQJJvH
60yZsm4ohf3WZbnEaVFcamiMAc96z2qzKdDuJSgK6pVp1AjYex9PtDxVcmnttF7qNuY68F+nilSV
yMMSFb7/Oofo59wgGy9IX+78BNzhKtqqmr76Xmp3ivGE3zMDG/dbQesREiP5CSG8WpwToayf7c8A
GFr3pQ1oZb/2OwIobL/q/ntJJFU938j9cjv/KF08BZKY/I0Euwf2y90bYYgrPPdklGxSHZMa9Cpi
h8sxJkhuXGNzrOkEtEyN67wqHGnKpnew9nl1loXRl3Rv09XXhTbdzo+xSsqDH7d/FgWEANIz8+PS
yJ2Y337Tqt87JuRpVnKleOdAteW4JaPi95ZEi3sTeR7Qwq5D/6gt7rStwPMvCvst0W20PFacOH7R
kgqQbT5u6jQssqN9hfGoBNzSV4JBukZwmV4xnOtvdGUs0l/UZEBFQJ5kE8blBBKUC3lvjdcywibQ
DA92Bh88EHtrcyq4g9gucPZfk9J2yWUs6vMJsPPh/hm0KGe115Eo7CAHk1yqFt7P+c4Sy1x8XXSA
9OKJbR59cjk3Y/mWfaT3qzuL6ydhe+Wkay03jsDZpQjXXUwN2TwdR4+mh1h9IdJakNMPNYYWWEwn
CvpfS5gg7I71BczWV1ZSk7zVpZ84qE+CQG2IQS/LpntQ/T3PnN+YYOjHaE+ZykXkxFvR9qonX1Xt
ZOsPM0jgi136dpipKaJ63dVOoI5uPYsva7agPvLNi2j6vr9DxSVeyMX6SbeXxCSmLDCM/Va9dgZm
wCinPmStVnFtaYY/kUSmPMIBv2ZZ8frjgfrhvfU4QkLkXXYEEOq7IU63MwNfNdmd3tv97zSm10sw
dZVzkmJsrh27Zm1VjAC8dvf5ZQkIkvazEheZ8q3LM5kwhq8rqNj2nrcU/RsmB+aNxksblyvXcoOr
JMu4bbzSatnOtgkg9xjnmVY69gsNqav/8tV7sVxuicut8FjxRdbzNhgQjkPeRTM+vvR0+CKagVfq
4fxRTjZxExhw6w/A2jqWKWKSNrhW6g9Ap3VNB9QQvCZYY8TYXWqwn3ZiRseT1hGaRAhnpCsjJ5WY
SLLogrJTxLUv7jirwgDGBSHlPzkT3bPphu3t6YOnn0elBddgdYVQPi2NMIBhlvRUmcMwvMHztUue
BNYY6yOKyzK6hP9Na9LTcc3W9A9kbnnlHRNbMXb+XTC4cMkGr6nUo2JTciapHzbil9rRlIY6/P/z
R8LtX2HLvFY27He3y6Q0SWr2GMDdc65OudIfvCARhC5pMBmggyHeASROKb3ratfI6t6vQ5UZ9876
CN2BAFez0HXY36MJnBFeo4Oxp7vV97/sReXrb0ubGOl/iTKVUZE7L4khkMnUh/t6/sXbkmnG9xM/
AhDXViXXhqWgVuPCM3DUXOyOvecy/hYRo0OR5I27qryaVqsvHPCcXyUp50Y1AWcgDevmI9PJ+uiP
Gx4bD/wFllAkQs3W9lyUUyYrv5d+Aku5vF0038msgIT7706OXxwCwDYhpzmLeJUz6JU+jdtm9fyJ
oQzFewbwIlsff3TbSPyb6seGueZ/3ui/gZNUbrPK+DPnX9xj7anqLucb17ASYOb1ATWWgccBdVY5
838NYPDwCbtQUhLovy0rfy4hzP67hk5eEt2gGp2Hoz8z4GQVgPiQakDcKNPMZKyUKllZ63KtqZDT
6SYeIyuMuyBKrY6Xfs7iMiyj4kYz5/tHCeE7DT9a9bNZlpKFP/nSf1QwsxCxBR1qTrYyeJl0BR8P
KLQyquiUarlmMxR7oJcVLEatj0CenUL6I2X1+V1rIJsXIJs4UcWaDubRyfT7hMfZW71z7xC/kjsy
m61sV54oAInxqZbsAerDlK0PdIqm39tRSeJ34hlBbopLHOEdGL5doQTEoWcDI/tIA2uLKRbJY5ad
w/76rznmcIif0uqRP2Y5fuRjbP5pDfli7AQ8yVOMQQmXISjyMBuwYPh+0sCiXVioQleEiJM62Ovs
WoIA5QzIYX6bkcoQZ8YPjpxlTDC+FhU6KraB+KZ2XLlK80CSIEBPegA59vQL5qc6etUcZIP/Q04I
stFYZ/aPO/7CipHFJxnZl62Dj1NFe6cjJxLak7cXUotvwEipb9hBHgduMz4XQCA3eT2DdRF6u55k
c/jI35oFqwmM6muEpr6UNZFABPq7R+Z5QWvQvGuOHB0EblmXftA+bQ1ag8+UrqEMVMbxb1vmrcEg
K5nkluS4kUHuJ4FTmd/0oXZEdmzGd8qLepMxx2qwcxR30z8lclkTox9cU/TMfR0id24XeH1YMnEK
lKXTju2zBn6d4Eg8HeXfIxd9Kw9t3B1HRCnBJ5uNvqbFZemO7r68nBDNgWQRGX5ba+8CukzElH3L
Uo5UzRVDjEjbZaRhoglZd2CD3mgU3UfSci8EQrFj/xj4CuZlgo1LWkr9AmDnbwRuyvFk20wtSCK4
7P+5ydEegD/+D8ZGTn+o7gzrapLqVbYnAHixZJAUwNANCvCqsb0xk0+HMQSsbyvX1M+tJ0KxD/yU
SU1Ope99TR1kr8SB/Zkf0htwTmGWTTmLs5jZ4tX8/FB5sKuh78dehpvcWO1eHx6TT0C0dtEEyo4R
Odl+Ozj+f3EqmjhzoJwabVzNX8x4jq5QNyXn4zxxRo90dSbLnUXtr8UhfpA3GMCMwPdFN5QClebi
1hMA0uKqER2MRx664gIrhaiTBsHkMGEPsMapyu8PqfiD3cD7sbVbmR9spXfDTcZIb67ijze700ZW
Dan/18CqFq0BwACLiP+9g6NV+dVWMreeCO62LF981mvgVNPxzGNgWm25sgrMEm+v9qOGyQSz5WrN
7aGUIkYXziwZwDlDJwI8KRLxyzOi8hzDJrTnWsuX5uw8lF0GatbaPnbCoNkt3kj+mi1ePFqOTrAO
wfaWlNBGyPK/RjnVoG4p+Mk+rcFGdRLKDGy0qzROG3ybenudj6gCtbutK5MKqTXPggikw7TzJeEU
zJEi5/mpxh8fPSgg4De5tc/chW2Uu1WtyqDH4lsgiR7Ior61NHy4s53N/BqCaJG/Blz1WRSJpc84
DbkjLztRzJzwVUBnetrc6RTngYaQxymPI5FGdWTlJCLTCTqlnmgVlJPCcsvo/yH5BE/aCVC21HIp
PYq/wo6rntwjlwQfTt4gbg5o6j/+NwlscRxtkgvRV6LjoDukcyJ9g/DQnpgRNhpyOyWEHbnOvEav
oInloYX8u0tlM06WluFBl+NZk04LLKRFs3bUX+jFHHPC1NlZseIRJADpl7V5O9TadYXhckJR0SgW
xLd+qZOb6wE7W8TP4HalvfkwbdGfY95KgljonZhKZ74u0AD74CiNq5pySutOkSp+qpghxTBs8lad
tId6nf7HiCuG7AOBaP8qZMGhKVTJMa164J1WeKcTeqRmY+9JRW1Vq2/0sDTmb4ocIcHKJ/IbC1JI
xS48niwAyIab56v6UDlkq3TfqZTR7hcQb+NEl2nk1tBDvCo58+pgEDXdXUfBWWwdBjOHGibCaX6J
S+TOps/sMQSiGJRjeqOhKNGoMf4vNlE2b5vM2/oZ+EjYNLPVLLwHV6JyjVpy8oNcU0townky1cRu
FxKSfRjjqJ2EIyX8EWoxehPCwrm3o5xVUYuPwTUP5YFCJ79bEnvWKrBlnDE5QzP3DRzpi8lpKi2p
aI5s3Pktl1B8B+cBNwQ8AtqtovH4OFpFByjafVflshi=