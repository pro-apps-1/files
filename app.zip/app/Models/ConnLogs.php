<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtzqj7lezmnyzPiXM4qDh2h8refh8X3NiAEuVfbpm7RkTClqjcRJD+ggn1CbNqeuxOOTYdvh
01hSN1hzu3Al30r/Q/9AaRubUMc78cwtn6HDjXToaBNzPon61GgGiBBx1WovGZRgAuNyI0z6eVgO
K8LDLxJ4v0GAveJFpp0PcK7GlREqHK8VULR8SMtjTb4hI4ZI6bIDnlrA5Q4bGP8V1pWiLPtayF/7
brzRMSNRsJVctOpE8MRBzmK1CysdO0wvm38pyLvyD5SgexbHR420sM8EOjrb9BdCtY9Vm9DFLks3
MIfourVzzIlRCBVdFUH13Vg7nohBWjbnB3OGbzL2uAfjUjeQSvrZeoJcSX7amJgBiVS+sAq+tvXc
xVR6zTkPG8Peb5czZgSkgGBDzQKiX+ahLNa9FeCrS/F2JoHs+kQ26EEOfQIZJxsGUsIy/k+sNaDP
WAA9l+HUaTL76ug+kbwCKVAd/Qe9it7WiqOYvpZTRc3qx9wRvnRg4mzLN6e4LBZ+nmnfM6Qbpp18
XI3CNoD9vLjWiQ+A/IKLCknXCYuwKzWFYMk0MtqNIBOeO1RRMV9iaMSJYN2YR/XuK9LjEBxz7C+D
A08faavb1ZJfWHVHoeLjTHIrMLoeo4djIqLvmhU86BCKPEVe+oTu28WW1hpO4+6V5ONwgh/Ej/Uz
Dvi1AcXMs46q21rc0UDikeCYcqlCkPjcg+rL5DSrWy/Gsfn0jTCqymEBgHoIQPWNkKdSbp8W4+Wk
9/ON5+4RUD5Bp4CLC8szkI2XekLUXRUjvEGSeXJEy8ZARP5yGrIKcV1dgGlWX/HgAauKY3IF87mv
k8FkgkYcri5sQsL5xWCSPy84S6QC6k02ydKldPySQHJXyOggBbl4p4bwLYBxKPuiBaNZRkf5+JPD
ojL/GkLmVzk4GSe5yC4SL98oQsjR5Jc6W46+hTpBWYd8tbqvI7oMARa0OKjxwUykqk5npjvlY6JO
tJ341h1fXofGk7lW26rAHt/by1WveebCoLpyO+w//+CrjguiacgTy16jh/uIos40FubMpLYczU18
ftO3/oJ6EzSBOAunlrFJBB4nrH55BZ7/D+x9f3Qv3LnNAV/7GuzSoU1y6CeeWQRK8936s6UKuJxH
acyVzi1Yj8CWyWVfrdLIUOh3f22gFIUf8zluaI2fXyP16MXiqe0CHiYedMJE4iGHpqY2N8SLijLg
BL+1bGPM7sD2K4omgixZYuJlgVZm1C6MasWR5pIlP9/s8rnf4/p+trjG7T2KLtMKujMCpuBhRLDO
d+0KU4xBnwjHNZAh0kf9EaKugeu0V1ZMpqj+s9dYuhDPWbQ67JOE2hyvbe6LXradDEkomta64YiV
SDhHtWtbDCcuua7xvt2A68RYU0ELGdYOuNheZUJ1EmBGFOCrNws9rtpjpzeNZoVOSekwobFp/B3X
PJGuqjLDe4Wlnh/90BLAHby1Xik2NUaYPggUo3dvcKBoUs/9opGSqtTkHIxH7B2S3wlI7n2PIfDu
+/d/z/LPWT93nAVXBzaeiRGTFV8F4bu/DWT3D5ZViOatRDue6D2vuB/D72t/qoY1oOkXmXkLFaQO
EHP/sA872EVY92JYDNnCkumgmK+LFhDLoIkrbnR6f6hUqfZ5DJITgq/YMzBZXfk3IKQuMU4j+Siz
/dyLh3h3B5zBasP813PnYp7rql6PVpk+jmWIy+SfCM9LifpdFURs++vw3/DUuVOKTbQFlbjQjCok
x+MVExqq1KcEB7GUvWYm1QKrTg/Dl4/GX9v+6FUzncesDMnsJhHJTldo7zsgBB7Xn2qOu1m086Tw
8sp/Bu8J9AcWODY/Q0XmMd1C4En08POWp+GVKGnnrDwjFxf+n0DxQayFCL23FfH/wNUFNvUXa2lJ
+G102p92xgLZLD+5DMP46/VYIBBIorEd0jmhSlLMHkyPvshmwo+kTjWYn1glkpaQhEQUAwZmevgr
VW6hee2tjmJt00SvL9GOTZlHa7XkFRVuGH5DNIhy62YUJf6cGpxrKbAdHw4BHmDUYnw5ApvnbFVS
poIhhIQNVnpSGo+HUHRlquSUMwinHRh0do+0CPnwkFxKzUGgd+P97pCm+aqwm15hVOMprVvTXJx6
APMzAjO5vaiPfkzLxZI9JYl2vE+ARKUy23rT0zokHu2DXMCUntylg2I314/0pxO65tXdi8nOJu+K
2pb4raWjPGEYOEly3FR1on4547u9ypPBs9JT++8x7xihTZrC1zOH+Y/5VimNxdPNqaZnn5fTQ+We
Sm89YIoevF183SFQS/EpFay3ggPeXzr80oDEOejpLEMR1IPq/QQpxKfecDwl5yfT5CrCkdicHs8K
r6M7oaL8mkoMrTfREJk0i0PWUqHbdKy2hWarB5bhTxi/DoWwJUTnzPembxq9lQqDjWrlTwNFH+HV
abtzzOI4tYUg26Ch/fAkrTKFiY/TMHkO1JzmX8lhIJdz+vVGrAcIe3hXPd7K2i+86vC19oRzYUMe
epshUvIFjN2bcvkVsW18SdFJc/fuMP9OW7AQhg2TfjnyUn9Ygw9F+orbO8QxVYP3UdUCOWdRFtX9
AK+uyV6e5r7zqNqq3vXMytBXBiRZ8ZgGFaPdiUJbfzQOodK2ZRe95uRqScCDjo39ulNpGLSOg0SF
H+ZejJaHH3WLa2wAbs6ggNYfQZlBr4W0QLB55T0zSALl69xSDlLDTIXGlF0Zh/ZlOipz5xqTheO1
N9JISPkDE1U+jnc0xcyTeM/ExyNTzV0Wc5oQwCrZRGce1VPyYaG4Linp5+BMz6CeevUPdhENXfxn
vx8rkE2JjkZlpF11oPWLwf7dY4Bq/4yItPBHMxl1n9BRP8kVjUgmGhcIP7KSTmvPepXjc13sb8/p
NAXhaSceMApaqxFBkl2tL8T0lAEUHzwkMAbWzbodEFXlOTT/xbcMyTsj+3B2zCLU3S1/zOAeRukV
5IDwTOmbD7zd1sEgaHm1syvX1h177CaJaQq5YEXdbnS/GJv1nTupYWW/RnQmflkyPqF0oCUFytem
qXB+JOJcP8vO0UeJbIkPACyJYY48kEwX2wSvJUEFMclQodA8A7In33L60td1gQ+H3++1FetUQ5cN
t4uw9pLpLhsySYKmB/OjFWO1JuyafUycAc8W+XiB88cfR7nL0R27yxwZ/VUUnFU5RYhpij/VvywL
u/0Gia8q6QMtwWCMbCvaFm7TtziotOZMavtuPtF8gAXmCSH4F/h0GzeYx9AVy6qUi4hvQ93TI5ZE
V7urbjwjSOzGQu8hCqut7sksuxo9QVrzEXSVZlF5qMWLvZXaITg81DqRADxBR5/r2Shl2oivBvQu
z7rTaz4Uff9Fo2coqHs60Q2vY9ANkwGxDE+j1A0bz80/cDu6G0eUJfxREbc/pNgt68LluL+zchuu
Em8rKu+XUmzWijbHbuCJFi1AxTn9iDXO/vRMIWCmWieHwkNLr/QdgofilWewqo0qP+u7sL6PxCU6
tMmbSEDfJqhBYiQfOZGSOtC4WpR1YnVQs57bNQ4mzP90h5jhPAX2+eegbKBDsvMnVdXc9pNTnN/b
efBeT3+syh3h/i/mxj8ga0tbGklvmmkkvkkMthPhI2MVL5C2v0Q1jElKRPPyXGxOicXzwQw8UK10
+DJImid7py+ijwLhhUDTerhYe/4dhnL0VQK+mkYW5fp9ngvhBEKMuBwa0kePbUE7pXti52tVAQwi
rM3FEVblRnWMz4/iBsge75p0JL4oKbBMytJwBrL4IYqGkKwC4OxPnTPbbc5sKX9uiErsCdCMfPAy
Eb4qDTz1ybSwd3KUeICJcg/Q3vCVRHePnGA+mSjZUL/N27gYy8XXeJTdEO6sDlp3CetYFtwfTJvs
ooZuPrJWUIUg+plQLNde2h2idVxdJdsaymlA25LwaoKkNGqXq/ikz24t8iZEzHQ6gM0joLFl0ju1
S2dGou2x1f5/3KJm8PSlQokrAsOP8L4U1I2fUt8+eeKcPdowKQjRtQjDCgX7uoiVQ1lflLD+MBqd
5mlCUwSLPaoV5dDEmuidB9aLDEXwQcsS6XiUo2tP7y4Nf5+aQ37WDHoqm9cr2deAYpz4urKMpdRS
EYJPanlRWDThKBjXy2XWJDFQ3INv1WaUem4cWVRykmX2UV+oE6dkigGiIYPSy1Q48WWe3VZhZuaN
NPnHpXoVB34uIs7QWMTW02weeWZ1hH06EgSC78yMJGWmh5rC3adcZouYUK7/mBL4JFhAEahEHWpO
feqI+QEo8q9HSnMsssFhjW8F8KOYdLC/A5FI9Cviwjm0gXAZOyET0OLT9NeSnDYlMDuEC5UvybEW
30DKwPcZAhH/QfT57B9jUtoJkEitJ2V5wUDHX6KagBgh/5mw2szOzi4FkuWmvsOci4iXs2VqXqHo
vDzNaPgRUY/2c5jZJw9S8bP9gKkOpG2xrJUt3k6EHII+ajkYi2aEODw+pTalsSBWs87DJ9bMjpwY
gP2D85GY/z1iX9Aq2y3xGme3ony8c/mgMAPBjl31hLv0u3dve3eTmC/cBdj1XCfAYUtfzDPxEGqC
QPo1SChbAMXMa1qeY3HOc6w/HQqtsDWjuRoB3ihJJI6mldQbNxiMODAW4tyijrf/tXsvd55WB+ek
7R6K17cm963217FdEK18E8zfxWDIre8LuBb60OGloB9Wv7UI6mutIPWrUZlXByLFz2cWxuIjgZUJ
rIcKBm2Rp/bP2aVbXUJCB6yu8PvKOjH75eUxnlYPo6gITVdHwFzJtd9vEB+SmjXxzK+4dHnad/f6
qy7V1lg1D2mRaayrYc3yAjzGn80cdLAENQWcTMGl4kK5l48Jxxoq1fZwGHSbLjWH//TKEqBjtu86
8Y0sgsJIMImA83rC5xPLjBMIDDh0nkGHH+NWB6onJUKImO8rUSf5dDYa5G9tVKuibORWKR4nkyxM
jIY1i35yQ3anjsWgMQnTQhNVEtjBkLzggXQdL0mJXiS2OEZygHWJPqyUO+yWMKo7hEUzx+ag8viz
CBqK3vb5rhit65PUIv9x91eaiJYTIuuLIkSDAacKjAzVqgHdW0fD6KwsbiLvi7kRzl/FkQ0hiTBx
iQZJRXBEJxBkBI3Oy0ktLRyU97wR4gfkendrzAlehwEHj4n5PJExcgMHw1us99UwIHEaqyJCRa/9
6MLPwbW4+fK0gtoqSY8SotaR4GYoeDj1OzB1T3MkbmmVQGxVqa0OaGZadZ99LInZaeq7bnpEmP1f
nj0T4t2gLTcAhb5S2iMuiRfXQw+keXhBlnRSG7cuoJFBK0+5PUATdpsJgMd3M+vh5YiwDCCcYJvg
krZr6Z6Z04BldRnrXutuFb8eGZC9zumSd8/iK27oZFCdnTcoTWS+K8tvVdhWQUeHPFcMM7wN2NmM
TEFFQRLwB0T/ZlIPDynVZAI/SVxMa2R+ww1pUZzrL9E7QN14gnp2XevLUWVT76r/Vx0FcEHF8ZOi
Mq1455oJ2WDz2HT9NhiPrSKeWFcHRLHGNZ+SHc7wPhSGj4+q7E2sO7EVZdkABgKxXgp6kw6p1oRo
X1FMS5ZwmCCDYw1rHrh0NQVI++hP4nk/83e+c8E8NPM1XGFV2gS/viyOqaHAahxPhv60MhSavFtx
rZOFAEF+VRGZ9sdornFTA6UVONCfycI4MHcGWMzi+VQSUWm99fGn7dBF9pU8omyp2eiF2Lmb0B9P
jUTAoaS9w/rU4nrzcuSpU4GRsxRMzH2Yd3Qu3blp9/f/8akZUDXm9bO9S3O6TxM30aQmVrcW7CI0
+/SNns7Mf2fUoffp7TXLXxJHghW8N+iWmkCQmMPOETSiq6Ji8jxJxxCIKSGP05pDXfZLK0+rGo7E
GrmfWLU2xjEXV1S2JIe+G+kN3VX4aMB/O8VuQYUwYTZ22i6Xtmz5k/dhHn+JRfPIIQFf7jZyDPC8
WEZo/021FqlnFnBcqrArM89hYpL6exFe2aIONjFtvzPHIeqlKA2xfoSHPpR0TJqNkDObBV0t6wff
CQM3+iE0IwnQVBCtNr9GnijUo5jmYBD8dFQ5ImdEjWhATZVl3XATH0Kbx7SivvzbQMYn0pcdAue8
sU7g2UVRGUDhHdrNRcuh3LUmZ43+uLP/wnACO3XyFWpG2YkfcQ03dG1EK6+0MuCGIkY8tB+WpIcv
tdxK5zpVYrvREvofsf9kYf4fMtkFvPoSf488AqMdYd7plTfRVf9ZSHJ0VucQONMRy6xXVarw48AP
66qCjZDy7IsV2Em2sviQnoHiTUHzkSXF6fG4rhJC0kLhcMZo8yTlaX5Rly6kANUUy+thvEKD1Ps/
SygpWlphUUsa5tW+Fjnh79u3Ox4Y5chIQ+fmClaoZkYGkQ9sLYCgUGCtUxUsL0jRhgQCcLpPpv/L
/GkuqE0+zP8aq+bQLQF3EvgTCucL6pN+U/MsczfgnQ0nIe7pgkEmUR3TID50EBxgRt+At61gUY63
2ysp7RHqQiP4iXMdLWiQtCfETqHL7ON7GLK5+d4KHCp84Tx+ctCzKRkkk9fRvLvoAQrc2msxpXOW
UFYXr/cudEO2qSlntZTvx3y/SQAZrZZbgwvt0PkNCJNPtMgCgrXZ9XBAlBS5MYzGnKy4uZLigv+J
Iq4ia8Rz6sizyxldThR9AW4gy1oMl8AHT5AHKdcZtU8Jf8rDwoDG1VYQLOUB7/CWS+q2WP9PrOSa
OYr0gNNjHkgsGWND5OcwwCvtE6N4ivrN/CF8nCC/3hr22gFgBWye3x/xUhOtmdgrL5LMdOOQYDRz
4Nfju9UWblDZBY1fuCBLR0uDggV+YX6k666H1aTNmQ5u5ca7DCk9CK7CyA5WhDUYBDFcqHXgLcBX
/PDFugPaASI4RuEo+G7BKj4c5ew8W9Mz62Df7dqUcSSlj6QpnWXZE8LTPgmjEgSmWW0ucX9FtMBH
51eOuL3/zD4odQGKbHmTeCrLayyWWv1pmo/3jOL2myTipM1O0kuSPjigyyB7LtAbftdydBbGlA7O
gJcFUL7aqgQhNAyv0Vr95y6+FglPdg0gH2sjzEbPWiMRG0rZ7HpKL1eUXlCOpyNkXX3fuNgjJ9Kl
uqtdfreWoQ8zVydXUw2wK5EOlwkG6wV1fl57Uyb83R53twVvjjh5KoFc9uVc65cOBQOHFrMGbOkP
cVusJ0DNA5unkLHtjcotLT/iLGwmO/zZRAh6E/PE+Cn+H3cw8YeMNnjbxtteNbwmIGP4xcUoiqnt
4fvtpTlFdnw61LZubrHwtI3or3Pi9yxdNbqZCCU40nCz3pyt8LyrqRI69yRhwKMoAbNYmBR0vs5+
f3LKci64qljMR1keRCRJfYirCF3AY6kBIFARabipu61cQuLwPGn5jHEFqavg7chclpcP0PjSfmYs
EtDgTJCCgnh+Sg1dNzaT2DXg/W4wAohCjeIdFZDlFW7A9Dg9TT+Gpf/ZYP9iDoiHZeWhlYFC1W8s
fCGUByYYiRNtAeVqlq44tra5opWcA5wk62e8K6fjP1F+fyG+1uv1O5JLPChIz6usx6qu9Z/+4IeR
p1A5kWAlyMqlhtIB9F+/2KfWtEKnGzykJiElQ1IHthAGCzA7lxjm4YxmENEYUIoiLz4K44HroXvG
lbfMBwMMHF5lLlTm/u+u+OSm1hQ9KRyP6EPQwDtLeNamWyvfM/k6SoVUhhVtOgZ/rOj/ZSxyY1mY
41ICfhfseTB+zXuH3KCqxWwMeOVxjGqJiePniQ4ReibsAcbOoOBcWCYNsCi87aTbd8hV8c0D61us
0IylaXtCO8vRlgfx5ghu5DctKnB/e0B7YMVyW2MBXCnUhzRGHFBfbHvXNyTfzK380SdM3db0ZGQ8
R8QS9e3KmVZRzZBoEstPAWateGu1z1cY7JE2TXYWUnVDxIryHxqgh59hVVBDGyh+vSOJaT7v3Bn9
PODIw6EnIxvgLN5kTqHabVh7/UnPS1IHuwWW1k2MjaEEKv5Unm0jQKZ/hud4/PivoI/zan3k+6c1
P6luXxyb+6zwdOpbzv58ExsS81c4tjQ/Aib0v6eHnwM9R2jToF5jrTdQylq5Ui+udtC3UFbQTkmz
Ae+QdVwFRJRKndrkJPJ2B7n8YCE3dAHKhFmlXtH3hTr9bIrOwCoq6m394oLsjmif3Vsi1tNiKmbF
AonhAxyup1w+NeQRDMvE7N1OeYVsYU9cWiVAU+NgH2Y/f3Kk8ccLGXl86RUMwoUFFX9luzoWHcpA
PjMbXNzPNIjD3yrtXQZEYTNyB01AT87dyrJqi7zvADzgCQWc/cBIttPU3M9gDU9I5ClC57SbZnyh
dAmbDJqYcxlvIG3tNl/BJ/IW4VqXgNh+PQdRjY7RohJZ+aYCmBka8jf5pnONWYr78aJtBOKouVdZ
4x6g+nC6cEZqnqP1LQNf9jzP/uLMqBy1OR+cIxKEL5aBaF6wvnLIowjM6v2pQbLQuoBDHIzvwP36
svtLC7geL73swAyWQ2Ow5Tn4oRR/wauskRF25f6LhVj8gaJoyuCPZeJyumN+AxF4DLegrLP5ua2H
4eG1vee39zx3f+/Fdfc77FJPbonEoN+NlqaTmuHkniueOgkJr985o6S6wTV2bMiLXtK6/p4n7X4m
yPMpYM2X5iqI5O5XfUTZdf1zwcFERSuzQ03v0o/OvAJfk0CJNiNuwEa6KLpNcpTdWfkVIX9T16Ae
omyLL5WI9RB4tD1l5xzOFXuu7hpe/KBGfpNWUttlC6nh3XGSfQsjdNG9NOgj6bapVp9C8rLBMmfb
PbaLBFin/9iUXeP/3maLtvGmJkk9GsMFtYS9qJHX48ZimngniR9JqyG=