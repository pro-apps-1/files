<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtSjIJzctx4mVyFS7AlRfyLLDj7h8tjsWiL+QRPfey3I3aDMgJwmPdh5tTX58nt53p0VAC9W
/SK2YFMqP096gspuDWvTEXgWAXpBdR3GdV8a25sx1+rrucyIiqbmITbgK17jX8vOIdaQ06Je6NG0
KMzlQKaVB57iTBVgzi0p9kvFcc/Jz6c1mFwYOqI/SiAvsBMGGmbbx7EmYZbabm/x4de0YcofYcNH
0U9Y+ChfI3sqmEEJ1YiAWQAK3DCZdhR9kZ7yd1yO6yWc+zY1KPBfI7XK6YlXPio1DZ53b9HT0Qp2
lODg7dkMt2fsiYEp3ibogvwY6PUUXXgFXLj7m+BMtAEkaSA2WD1eYnyZ0z4BcpY5+ch1VSvAnG0N
aHrhKjDiw3kLgeSiZWUFY3Fg+3f7u/FFkz81PJeDCrO27j0zYgrlf6gnCQI6HgPG+wDvHSJTfOSX
Nux/uAI2VNJ5WpMqN4wUMcU3hJyRrylAUPKF5NeN0qeoqEIZ3n0cH5pgFVH7MrywcGzfr2eCCQ3n
TOhhFrIi76b2nyY5NEhOUYA8dioAhtY9w9jhapEznWX6fINijVBnG9sw0LoKmtyn6wjBlLcSjv7g
7qNk3NWYUa9r/AlGvTjCLE3f1N6zQlRXOCzOD5Gc2fotImCV/t8eIw0VqW0j63AE/DzbVTJ4tpxv
ikMP1Dhi+1rr0sLx/tpx67I62QGrI3yOKyDliMxHGjFvca4i4TyU981fuoQNSsKiZhaBB0nIjkm6
JtIqlNaIpS26y6OwxNtYJ29P0LRWkmcgZHH+KQQ3upsur0lBzF+GVVg392q4K6SYMtHp+MEeV2rU
R8qnl2WTyQ9sWUbJGg6rBYXXuFBTsm4KsLVdVFy7popqwbriDH9PyVFACBCevkJVm/LLcnqnMxMV
wYyjUZY9xV9/wKbkjjFDfUEJLY5b7QAQYYLOe/IK9fcuU/+JhmFkfxtpcI8rfnrwIvr4hlOfyFsb
MXy3kY9e6GV/sP4/L/Ut1ax+EkMrX8SL377f/uKGLX4lQpS1DTNoaXKqhWvMq7d2HNTR8gqNflFL
vlk72O6K7DhAwlqRapxMx+NokTEqK39DsRrKNLUFjKIY4gLzwiJ5O3cS5y1rZVR1tzJTHhDMVNsV
Gly2h7dxm7YJ8GwvRN+Hr5hb5qGJZv5f2yHgL1DfUtAux6baMdUXdFMUsFIyk/XOnV3NHnHYjRTa
1W+VSmdLbX5g64lLiW/lT12j41VWYp1qQZI6lBmS4BHgHnIOdvR16s+Aznccemh8XepSK+BCVQ/9
W34CRsgpbvWJZS8emfzfdxY1aONDCYP7WJwdu+Qr9uRJFcNsOFzr9c3YhVH4rmB3lE2W3KRUn4Xc
pS/iKmym9rt1GHFN2vqeKIh2/5o4RNNjzmbCRctrXabHv4+1r6DOg4VmNC412bknRxqde/6ViRxG
NzxIsigPHf5jbYVTTt7qjQDXtPczTr4z/hGxdYskbWI7KuzddDg/6oPA+M1zN9ty4vEFK5FhaRjY
Id9dwUvoD3Ia8FyxIJt3qdJVDHq4Z1EIxRQ47EdVdmlL0POHzUh92JOqQ2XQxwDWUDejMBHd3hZz
1p7yiokQ862zyvcgsmjm7F9eB98sxfiizZqzMd9F0T9dJ4uRuX/hGh1LAVcCp4HDM0LzINM6y60s
uC0C0xkZOcSf/u6dpPQyMCGdbE6E5mCDmmChVDWMMXgcfdgJMyjvppWIlPX5hIWfWwF1GYFLmfSf
/yTX7kqKPICzPStXiVrlHlQOwKdh3fVhnUuvjBXwx5INzeJZqL3ntYegXyyf9RA7KJkhzDP0no4C
1FQWX6490lUBkhrQIug6LWfEe6vghd1pgYYVlHMCCIt9DYYN4xMKbBFuSvLQNJFlkcvbKR1LHCOz
ZcGbhzSwkKoE6Cz1d6OOsbUesBTXZUL6BHvzJDnqy7tcTET2vyOMf4o0P7hWjk04K3X/NMo15+YQ
VVXPGy2M1BO8b2+Gpp/3w0jkwsw9E9gSkor1T9jJDcYb1rh5E6l/LeqRda7SWXUVxYUD/cDZqFhX
0xiR8OCE4+05PKP7xWxCTWrhqpTJaHqQPaO01qSt3C75aH+TgzN0oHwvrUb81wDE2mF6VWElbqlM
tU6BrstkmA0Vn//iH5pmf/wOy1qK+EC9/OUDIF5DnFvd/r4V67/PmTUHDe2jiOuCb5wNzq0JuoAM
JjHeI25QpDmSYJhLWCNUGwXDOB+KBQc42jEcoTMtlXlqdnrPuxbggy3O/tvNLqKa9GIa06makgZs
0tIkhH/74YFRHCn/TdhitWtbT1z2KaxAxVBuWOaxnz7gscJh78kc+MEOiUmMdtG9t7vYTflwqSM8
sHjObRJh/NXYJFyTAmyAPpTAyQz/banpO2IAylyTG8ebkKBpJdG/hGBzH5O7yIHYjxnkVZqltSLB
EFibp0G6byj9bCH4X3hNeGfEIknYbfh0/XT4NqODyQrXv0YFe6mQTZgCkH47RzCmuhf6p5E5Slh2
QjDtSEtNHhF6/DxA3QhkrIpoeXXJqctd8nSVEu3lK5gA7mTf4LZj0PfrjGQaxIMCEROADHZsKjDo
kSJH9hGd9ofINAUzb7nRjYkMcxp4P341AMmAl0cJYkA5/EavGfKRiW2BlJyf7zboO/4YuMbKhAyV
ZsZ73L0698ldKBU0AWaaBOb5hKGBX9B3jef1RjhX4UIO0owWAt4f/qnxO3xEnaY4cvuZbDb201nV
CMdpGOBYzM4T7K0Cb0Cig0VVwoJOGw8wzAE7rJWGyd6kh+bVPE5Iu9WHPjelLwNiMvHePz0A90Xr
K1j9tVQrI97sKlCDXjsolijVzyr058A7e5n4g95nQ7NcukvhuU/8wM2nGgXUXtWvKAYGcbgObRCz
0p9By0Atg/F/4a9bfU3bsj2q6pI0NfzdubChOV3qOMQ2zNigPevzVp3W78+8vR48fhYQ9X1GFSrF
rct5b8FJe03wef2sK8B3VpXCMYRX/VkaCcW54m7pjBHP7ICMnuOvK6JoA6SpnzuzhWVpvJRwJvc7
Lcx/W10ahevLQ1Q19fI7Nw0q0RGtRQA3ajQFYxb9P4KgC0lVTPAt9I8WMzx9MwqWSuf8t/zrnhg8
8NK4Hv11MpYx8lGPOe1ZlJ+BQBNj39m+mGdmUwwXEEJp3dRcGQQlKhJPkV+4ipjMpd3FG2TQ3CrT
IX9v/Z6LoRZ+KMV6d6VetYCm3EDHsmSiW9/qbkDUVUvYV353y3yq96kq1qMrKg5TunWvG4QRipjs
sDBTtPVAQHBwblmklH0Xud+/nSGKd4BsKupcVfHAGWO6Q86eXRLT1Lk5xDtfuSNIWr4biCWqX3XS
EisCclrOeTigk2k7sHRJ8Q94Hw9UraDMOxwrO8OTnXA6Lg0rPHCgvrzf8PMwhJbcc9yVzTPIwt/F
uoNOsaCCB81ogOMwB7HbMWzhEMCLfuFnBU9I3xq0lzEEl8tRx3Abry2O7v62mqyjQklKwvkoQMsw
7PTjoml5L5FNwMSiA+dt6k6bNPJGmIuc8DZZlGandCK7iabbzFejzz6JMLBSNQjhpCd1tDauoTEy
ekwh3qYZzGIsQVAKrfZDWx8mRS/jbu4H5Md0KHLUFx8cJ42RzAa5N7lm+sfac97BBMFmz1zyPVSk
ijNP6qiZ8lM5Z2W673YX1FwdpyZKdjT4CGOvjmKVf3eh/G14o/NjVyxiqtJgATwSd89TYrqXbEDn
jdU3eI2m/bHjpQZVc+08XVS8yOPNohB5+0aBvNk+x2dK0CpKCi6mqNFktYivuGdM24/0lOocm969
gEJkjMmZQCT0hzbsAHUNO1qIxUj7CsuKltW6T/ZQ1m+2HwAvbwrjNkUrgMznTra2WUJty2i5hrc+
L9uYRvMFfe4IbZLgQiOgFhDofWi5pHrE2v3Xev+ReTvsbUDtSqSJD/N6dFF3tie7brxz0ilP5B55
ZoSj0M49dBES23S2vWYlo9qXIe32s0o4uoxBLjEPhYdTUDHQRTqUPqvggye13lp5hptc3qxO1wQV
ZDyXXEAsgrfwcPamw+rP99FfkIU5YEqd8npIgNmXO3c8FHaDRTPT+u/xwIe9a/eva4IMQcq/1laA
rLpkE1ic1C4ENN3juvc5ZTnPVj9jahY3HwGv3IfNEhyfCBoDxwfY02q9vbG7/t/Y3OEFXfeOiwHv
JDC7xs7crxdGMR45Lf3n+2R5cPA9J3dwcxreQOMvDg4qTCw10aKjvX12hbNglZjAN2BOYoqjxkuV
xMu3sO0Ys6K+xXafExOaWhdUdqaw0BGs88UBKdJYX19/QFpzW+NGAlHRstxghSYC3JqH7BfdnHTI
eXfJiex5NyRla/wy8l+cKZX10Zy+vIfHYf6UlWHXhapVQmkMfyq+MK0YefCZikuECH504FQAQULz
TxdB2DcKffrH85oPim5+404VRFuo6U8PP9BMV6hfDy6KKcHfcuXm2CsBCv/5/cdZjqP6rXmiXCEu
vUb9t9RU27TsabQGaMqaOi5cYViqpwcSSVpFv1ew9JvrR92gsUy1Pb+AQcvSw4RBn1U2orhnJaak
GuX8Vw4qcY31M3YYYsvFOxsjzqJqxkMvwu9tHxqwHZvx2dfe2rzCJnN6IAQf+UexYZ0ombbkjl9z
ZuHANsme5edke4qIeX7GqPJIMmZqyySzTB/BX3i5xY7/+O64nPvZzO45lFJvep3/93btQqoz1RNR
E2tJi7G68syDVDQicRX4sA6bImH6SPQqYOaObtd0EOuAjmjUjo2OGnrFE+YA5OZKsh0ho+EzOu8L
6J8px4Jp7dB2gNo5qsd7B5Lu4UPWNHbwulcLp37P7FT20K67gnFZaqdiklS5LAVQ3j0nToR0eSlk
bkUEobB9n/o++iRlW0RhhdqLwzML1vQbieJxhuXaRz+jJA+DWhDhpQhHZOhecD1c71P+ofaoqiHG
Pc5PYmwQgRAOsNaE7fyQOtnViN3smnjeFqWr8dLskwcbEXN067Cg80x1CS8fyaJe3qPRpcR8rkuF
DN5+D8NcXerEBgSK8QtWCGQiU5Y2OGSNgqzCnkLMv+WCtD3vW2XMxeQxkXqlAtPzeVsdkrAw1KQB
SqAEWgtUFZ3Lva2LmQ+/2oqwQf4sOWiVz3ICeSYvHntqdIrXROGvA4p03Mj29EtK457xaupO9RrT
9NQpu4gdM/6VJcMhtp2p6FhfTik5POtqvvGDQkVOoAj9Ex1UOUBx9fyIFUlNi7rgzRquRbXK0fB5
ktMYreBOjY9LScXlqEc4UnkSN8qCLvqO+lPOahCwaWRZBCeSH2g0h2Nbd5k7jfkmyvVIyqJ2dF+8
9uYzBQFAqKa4viJkKwZemfqv5WtyeWJBM7gRsnoawn6kbAZ/8v3ukNbU+qCOcGouQJCgaXW3yQl4
TJV4FIo/iRajz6VGAsHGbCEjc6sY3CHorRffMkUS+aZ8B2EPI7x2wkX8xTQsYHhtaqLwAZE/7HoF
1BStEOkIu4E/E/+24B3x9EXwfGY3m7bZdXeTBDBrDaISJwF9uS30YEtOuejBhOfJ5o78HzZd9tA7
vRhIrwasaOlkhvXcaWAt1Iq/u77sbV9vaLQdcjWTAIAeBliCO+Rw/25TwKV4SQhZt2u++mUBGHtm
WYYXa9DMBxbe5A5P5tSAYlvRseyKZLHrTUrBAZbAQSXSMuMIUPAp8UZiAuwJUTViLOwgKx+NAQdr
a0mqSloTaniOkOnEeGLicw8tJ2XJ2mImdmP0IsudUh+aZhNP9VNRxAZOR27n1q73A+vLg6AY4qJp
XGReY2CusMuQ6RvGjMvylCUKh32yTf6hLbY1QYGIaghmK11iWwrl/sBgQ5s+0SBwgIVWWmtIHhkz
EtikVzlQX9keVp9fPuwq7+kAnsYnTQctlUR2uOj4V3Ykq1rkIGrZgxz5Nue/kwnNPNTRovjyBy1R
KazdGxw4/ZcvDBV9avZMSRlBeskjs22OGhFuS7Ez4ANmWdFW3stzW1eKWGJfJRvU6cBLA+BHg2dY
fh/6mnbZMeW2aA55vcY1gR7ZeKvDt/Z0/7zs8ipmF+u4SPkpEW8tMhDK0hSFpVNgelP9lqgONJGl
aaHMr7rbmqxELYFKKOGCWl7w7X+mU9odlyEMpLkS8A9ilu3FBSaAd+2dvBz9XcBori/iSFh39bgl
TsI6aKXCjPtFbaWiX8GawVoZ0DN/+qKG7IwLnPEqOCx2326Z3lERZEZJSUROkLfRbGTi+AG9glU8
OKtE5ax3YriirbEiWFtxTkMZFp8vXoFz9QLOEwSPrdguSAU5gcKLpZTs2wwgZqPKsPkR34W8J277
h3bya3PbNYhdbtjcDQ27bp4Eg2ncO+Ce/JNCyArM17IKLaruELB1ADVGA37n7H29ld43bkN0aX+/
DjYByxzL9M8uQc89kdXOpECr8JkyVzD/Wg6q184LPRpGwLWxJlfog5/r1fQMfKaXBWYl32cBjzUB
7R3dVLPgvPvavGDfbPj3t/2KuuW+oos8kM9IBaj1qiKk3dXF762D2Y83IrV63Vzw7cGcgdJPklw5
+7Zynp6S8U1jtarR5w0f++QbhkLq+I7hgNGC91tNQgZXrBqMfiQbGWKNkIKoFJG1Y7mvQEg5Mt5Y
OolKw7bDSvWIUXI517l2Nx3iJGKDnUNmgIUDPab7843qfGvshOQK9YEGkB707dnQWW/i6Pc0HIch
k2C8j4UDD6QapwZzeNkqZJD47seNNlsI1FYWKYa0CPEH64PrLM1sG9aQKR+bkkwA48BhhOsp706u
3XkbIVeK24XZxRUSL9FGeWGqon/+yCDP7UZIQrlBOI8eAy75EJqUNzULcisugNN2f+M7FYg4wdnQ
500wnIlH6R6dBxSCnrjlIziq23jcK4qDnA75bBnlzePwXzNsLHf2RVo8M+Z5I7Q4vCwjykZxG3DG
G2gNj1C4+WE+n2KwHqz4K0V+iUFh08PtWkgK58QQQp5xf8wiZY8g/+qUy/VyzfaSGNIZK1iET+7p
GBDb4JigoXQyyge3yDmltR3iIVqgtRr3KoaojsKp1AErdUQARHbzS4w+2SiXyzkIQtnbCBulKx54
vV4hB1aL4Ma/lebHXrth3h2vxWs49WjMVijDbzQD09EFFMr+t7GzebiQZOHI+zwWZRZdsiCYpJ3x
wL8KkSZMDmAAcWd8gUmuUR8euQimJbxMMZlmMvNY/ew5V9lbVPHmphAz6DpXMu5sbIHavEuVjcHI
Dhy3+jqzSqm80foANcbPoMZV+XyvEaQqG3C8k9pQzoO+id84MSuisuRDSVv8l3eORehrjRk8u9kL
vb9kd9d8awRSNy8gg0JxSO/ddDBdFeCPyHrydc6y5dId/6UHhuIFRPel8iIR777zJr4eEcuB9CLg
tN5QgoSp7p2vZt8FiMFC/iXrpl6gburUGFQfJIe5nEO+WWImcTVvBqhH55jHw7HOm0rCkyzB0i7+
09kXUWYgWZTun3XfNH84jYlbeE2Uob4bgd8l4pXA0RSD6KvP+BzzWq0oqiaAnrHqntAsUsa0aJ+A
0pEkx6J5SwIAEV76ozCRrGQJn0T6tV2n6Vyu9TH1D9n1KT971IKrJMrel6KAf9Q0hpDFdXR+j7mR
2cTCKerU7YPtpzpfuD/fAzWEK3WPe42/VUpZgJtmFMLc4zawTRGVAiSc41DRkfeNrMO3xOxz8HLl
FJisbRNPvPDKWdc8GC0ocQVNAz9a+R1Px8bxTycHv8C/2mar4hqJs+JLSWO6/G8SnO9AiTpGqlFm
CmDZePAMVOT5z229vTcqvLmda9DEA400aYvovdL1nF4R7YVRlKVNnbZsDPjJzdoesplsRIqOsgfQ
zWitDr1/qPL+1WyXRb8+LcztBP7Vmj28zsORWPu2ZdHhJyfmEVuj+y2tCMoT2nF5j+SzT/1VrVTp
/b4aYg+61v25GpXdtytUBdilVdrYSY/QQDrEKeMFWhl+S1XpRWUBqByLJnRtrXvbYoCb7w/tGUvM
G2cZMLSDSc+AlSR2/MSf5wOUpMwzRDmgbKDy9qQ0oYAwin+hbiD0ydJ/E1rXnlOAtBrYLEvwTEhX
0CFNSE/4tQJELtlBpDTC5EzKN0UiSB48Xmk1nQrxJ/UIOgO2bv7QQo2HH02N1uxeCVSJ30IQPXm5
RQr/HWUa5t6F2c1i5s1crz67jliQBKgJTcCaNKIxLrj1J/dNLJXfDvzlTodJSr14aG6oFYd/gKKF
UlF0SPlPijThAuH24c0WPjKlL2L0jNHr3VC5hcnsAynxnVBxziJq0x3Xqktmkz/UUzrCozMA1H/N
5jOt4Uu70ADcHdfmgs7Tq7QVAKwlXcsRGCmQ4HY1U1Vg0Z0roq5kjyepsW4x4wnsWcLGm2OL269F
nDZrihwCBdBZ3yly015QzvhumbrAnT3GmD4G0lfd94O1P8oGJYzbzKjrbUof8cz2AnzrjrPOtb52
xRPYSms1LBSfoHcUtASOlSY/HSSclQlmTuDZOevzA5XzrRJ7pEmizjF61s9MMR4GcQtc/J1ZTK2b
smCRPmDGTFa6JzSjSJZM6H/xyVGBVsP2sKdcqE1MCO1tTWRjNPpXPPC0pzm/pIfK5eLrLnMI1Apc
roUOVN52Nn2XlyXY5j+4wUpZ/NY02lcqlgOgxiO=