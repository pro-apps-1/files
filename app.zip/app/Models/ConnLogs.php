<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+b0mMyaupb0CQzKJE5/FxgW3hHHdUdQnBIuPAlJXw/ZhLZOje+JaAU6grVajnOGhrwq1W2B
k7GB/vQDX44pPADSZtU6QPS9tf6OS6G86nbDTGJBbAzG4qrrgyQK1GW14vAQqCDidsulriYq5CNp
6vmu5k0F1RM6LFuVO8dAa+k4cHVztXmt75UKfW64387cHUcNyI8LzUqSU5MMLgZ4/02rUob5EdvN
euSZi3i8YkT7rBlE5GWLuqEsU4CDvz/k2Isa7xeLASVpR/ki6MzQ9EJRHSnbci1F4IH9LZ21L+mZ
F5Cx/uZFJ+QuQ2DM/2lrhRDa+aMwJHrS5+71b+niubkzjGvFqCXNA19DbP1Sx1NfkxsEG3FkmcyF
8yEWTzAvrNP/vSalZcn+/9LbliTMgI/YLgIjM7HHXKS7WStywlEXGZzKzOZwSy5/cs6rvL3foBEc
pMU2VSyF3Ospi8UsL5iA1iJg5MQ1d7oDc0e3tc3RldLj2dwj6NxskCocsAvbojB6gEPEvrmeuT2q
B2NSZP0nB25Uoea0yli1XXmNH6Xi3zSDNQzYDknzxRcAnbjVc+iddVe7BFvWZGiBSjYkuyk6dX0o
nMAZ6pu7tpx8TywhPbGLA5eC5TkyteTJz3bIn69XIo8nTzYaA+Q6+7cwbHZNKglf/d3D06iLTmXX
sDzbOrN8ImNBQMG0caQMhwI5X5rJ/54wZuB2QyqPz4dbMt5v0J3bUrWUtNm7Bq54VwGUhSPUdZfR
gcT/UELVj9YAfktGCPXoeBeBTyanM1LuE8o9oXUqQ3gnISXftP9Rqr1OD+qIV67OaV+O695lAu7V
/IZ3el/HrvTOW1zl3d3eoW015SIGQjXmdhSxNK+lBg+yL0hqTZ+Mu/zJxbaignEKgSQARg0fh9bz
E/kuOp3IPl4/t+2C4q4pLytw9rBAVRJmXnTdDHmuYisZq0BV9XQXUjx+Meo12TUidGpznui7nTZ8
Z/qmyqfiIFzEK9EATrehaJwz+K8sPHO4w9QqJT4tCG6hxbX9ULxoKcYG4Uu9zyPxVi/dfTFSGX6R
Tc/FTn2r0wC2I/14rXmuAO6k2p07wKznh3TTu/mo4b0P1CZRlrh5Erh8DjzRdHQ+8xKP5m/+y60D
S6W44CDWCm9inXF/0X/S8SN+kH0tEplFUGuZwb06ilxzAVrRtt7+nUOAUrQCx/oM4SwDOnw4lcrw
zvwiyix1yGiPPFet+r7UazHxSsSjxRk7a11KBBkHRQcrPxFv0uIGLsu0ixY1fg9GmFbr0CMcLXrt
h4+Itqmv8jXohKXieGHclgp1p1x+SC9iea68dL4VirQPH0413vS41MI4bWHNKEW4Q3qlaO7+EaOH
gwvjd525v5p+QHyYcb+5pLtvQd/4CsJdyJrT9NBfEf+UBRybntzNLXoue3JKApbBoNP+ArvagEj/
fU5dwwy0g9GQZ2LWcdHAg8QS8aAiMkDMOSH8ooFfposG5xULwMC/sBnepVPWBHHL3OLZq11CGaWW
2glDg5xRvAQo8Wjw/cvZ9xjEEbeaflRqQT1VttNw7n+AOqFrcWILgTelD89rNAzFgLpLwwGtsb9T
AjnE+p8Td7/XJK9xq6I9mP77mTyDSG9Xe9w+uRiDfjZPuiEgnj46yCjC+s7JN8PNhYTnrmS2//70
I76oIFyFC7ZBMee2nYZ/MPDV04jI0U9Gi0HqwZwfWW19qnnhHELaFRJUMiwK8cS5aGnaviqiz0N0
T5gPUb/RvPhmZW233grgENkKJodsTpMPSgWNmYqmU3+yvkKY5OVdbZCgJaAvKNn/ikABCjYp72W/
htnP08aPs+WP1OHAxYsj5WLxF+XYgCdKCHpb0tpgwGQVS2F41vsGpIU/2OHMvCHL96fHi6/Ac8/f
6Z5O6/e4DVswRqKz5p1kceDHIyGX/gmV9bBYshMrDiFzE11uJnV8G153r5kAoKZKw0RUVPhBveAD
BSWhi9dx2veimAc2nv9Yj80/wBPwi9m29boEo60Oyj1V1+IYZ4z+UfXyHJxHNCIkiu7D38a9hBHv
uriEpPeGAhUxc4JEC2EkLgjQ7sktiU+Gm7ViFyZL+dgirveFTRaK5EYBQ4GGCnbnAuN2UC372o/v
ffXV1jkXjQXZsLzli58K1xo3KtjCa6emOf9uvYVOTdVlEhxpWcKgOztJQAJVK3Zevlqzd8pmMVTJ
bYfIEnbF4celvpS2sMhq3fBqG52WBkWE6v+jgcp1aGZk14pZFIU3liXnKPLxYfIErRu9sSBRDjNX
mR6hhgWgr9ACuenWTAW9As2bKcxcmdnOXAf3+hG4jkqNWgDR19/GQ3uCyKcr3G1CQ7vmoIbyx7Ay
aMPAAY10JvR+p0VOFTO1RqvL//sQo0iwtLy8m7t9q3vo/VA4uzJrj57d9FU+g6QFsGglcj2/444O
RAtn2dSjz/7s1MCthFtidZeKHvIqWU3TSQxYmVIBp+z8zasDxz5/zkiXub4TaqRUIZ0bSibIeof0
62A6N18l4uOWYBCZ3bu8FuqhhBEpIomhXAwbsfzTIABdyp21iHFqqKWKKgAviDk4AytA7VJ3G5It
hE1alAjMtyeibwKWFvJCOBnkhySwncsafjNTw/b9FZ61NYdNifjwmvYCWISeC5PfloOA2oo6EiKX
9q1moPdsMhQLR6mPe1jj55kw5Z/FK7eQ3Z6/j4CzI7lcBqbQNwi7k0BELlX2x1w411n78WreIYoZ
EBJaYBLvWWN5CqU2PHeHD1mxPUIbe/djs/m/R4ytA6RlYycz4D76rAVVVsd0lJSppIaMzJhFQS5I
Uwy4liQx3GJpmUyo9NvqhF/MBsYw8m7qlIdbn0SkZGUpimnHeedINxMkucAP9669I5lKp9ue5BFR
dgoTGLhGEgXpdhjqUZLlOXLtMz+29nqviLt7RN/d0wPBaV9V1etPcrljx2IWs9oqSlw8Ydp1fxZe
AizkmsaRHSsx6x3YiqnX6MwacvugRm72VyAVP8iX2M3rs6ZFV46zycTWFGzVcWNOVE+T5wLDW2d7
ujPhI48d5TWnuU7DbeVoJF2X5dAmG06gW6WJ/U8BzZC0nmnwcN7u3Ifq7GoFZbHlD4wgCEqku6QH
Sc572Rx2HxWmVUbVT7iPDBimiUP10g9saugJJLC1qBcgrVxKpw84fwEYQ1BNp3ZiMilw5X8hOgHX
YNRODSgiLcIdf4tBJJNwVzveRRWGYWuaLKufV0PJtfMynxkUR3egT3HhAsHsISNJKRF8lTc6idgU
2LHotpyjJt1NSrJU0CQ/hACXKLFyuQV1f02pEPbY8/YA/GPsRxvfrnzj0z1IrMUkH0vlZs7RqMU5
OJ9weFI/CX96j8keKcIBGKgJCBq3qwxykMitxpQfAF+mEAmzFN37piNqQyFDezTHpZyBZpuY2jWg
Uq4GJ22szKc2ipfhAAlm17qx1SqdvIF5Y00OuqLTdsWU5q7mB3zVC23jv8WK7f5xKsOmC3Qo78zY
VmFOTGftYYytyqsL85rGoMIWTAU7cu112I2hYkU+8WQuBJ+jtaPvdIU8aqoseIOPhdXbvEseU+rX
K+e7oc6QScLFxC7nKv0sI6Qhz1AAwNbwitzfQQAd/9UaqvTc9yQoaXDwJ9ZVbCcHyny4b2CeFxi/
m7I5aGCdDiu9Ha3fcXOvoVvh123RAnhmm/aaw5/8IeKL33WOeongSAtTHorNiMusy97GKnUrsaeR
Ebz3fPe7Jl3yYAVRhT1htOL5hqnW01/jKEAQCMz7g42eL6h/V40l8XS+rcybFwZRbndi7LmvoDMX
2U9U9b3/X1KQRM7ijeDcuCo5k+qvvMwquqfVo/uHtGsM33Ax7K8MjqLfI3LgxqGdHduYT49xSb+q
UZlOEhEdY5VpgGeCHXXEdjvmXGxGlAjznMsh/KpZXNbSjxMysuu45ypZW8fpNH/rlIs1NDkdv5i9
7hUbTgUuu1VFr8RQ1tNVylwMwCCO0OngsmrQ0N7woYSb3CI7oummNjqYHQhtJAND/DYRnfF31Aij
IrPnDtQAVUU+o5qV79izxfJ4nC2idLbMLhYDZ3laO4F9HuKToiRQjbQk4XT1ByJkzdbfoSlBC3tx
LdwzFzADLFz/x+UQXlRrz5LYI6Tk2Bnsf3gRODLDLFrG6KCejYXpzbm8G6nTb5t1tmtc+YnPuq/3
KDpCQF9JDVHs8Mq5P3ZCykQSBENgEJ5yyTpE44wiixJVvMM+leLwgg7JLjKd5VF9344PlSqxJhzM
+B7hSIcSCwmmhiUsYj5j1PwM8XkSTBv1V3uOFGdZByAlvyAtsPl4FLNFzhSKgETqv52yANRi+v+B
NVIqqrooMxXQrRyZoifHZC7R58P7xUvmeOInuSYq4ViHnsjqmss0EvvFrRdofhy/gxQhcE8prnKG
q6JnRhepak20pQQluHwgJYbgwJfey9RSy0++tVEGx9WAROqx1Z62kXOTUPj1QCtUd2pbxdxBsQJo
FnNcl/W9vWhOTKFRuqWr3X7sQBKPq0//zmTKDnPJYzG2S/U1qyQ0N0HV78xe7xa6NGlmmQ/NGgX5
KW7nfbb6vZeIzrT3ziBbNJcs3zyD/b+iwQQAo5+FcB8iG9R8mr28uPC0TZEi2xKuN3dxKxCZLHoY
xs4U1kqYMTHFGwP9cmAkE/GG/rnaT+DQ/ha2HNxPRRPm5ZXXgz7ZFw3Mj5xChoei4fJOfX/JKY2/
UZq7+C8bYmPWAAiFbt0hjI7PJhWYghOxY1ajAb5sPdJEICGuaW3mHYEvjResgvnb12OICKGCP8UK
MEzclHcL/1/nPZAbUsY8qxF9oiaZrg4WbW5nzjhC8DUUoHJTYF+BKSnEv8U9ZdSddX1mckMAqS7p
HpWgm4tavfJGu7G4mH9dhexoh6XbKM7qzilMvcAmYTkeZbf3iYTMwT0Uw83WSjJQ2Ip+fPYeiOKU
DjUEOAu4chGiXLmAKrdP+Tqdke4bTSV14bVo60F9JH4EvoLmHeZ9IdQ+JeovsgKDC/MvmhEDAzYL
Q7dS3SUT9HMmDc08BhUPFvZq9LVu6hJpyCEzNZdDc4QD5y2Pq5mbTawaqX0GGvNL8RDN1AJLqCSq
gymskxaZ8fY6BR+UNTRxrhpsqC4Lf4Id/4i1TtV18J4vPstIYvOTctyTSJMM7VyAoLy77NXG3qmo
zav0RqdfwArkXpSNacfR3vMeVCM74ZSf0J06phOKFapuBOdhojVhZowp3MEpIQFHfPnYrE104xDy
K79pek3lLVpyPN0IadgdzJZszBClpJCB7M+bkvGdJ/AybSiznAPvXvo3K99umluQmqQHZFyd7NaB
aBpZF+G5YtActM+SZdnB7YQJpwkbC0FPmehtqqiVQG8XfS+TopYFPgR6iBQvytlYWzYCtY1NKhit
VxnHMQQ4cqWqXyGuAWQJ1v2y2oujizzOEwF6X89NHus63DT4P5hUBmSRCNvm8vFWHA+cLcfnkJ9h
Zo+vhL9CHkxvGOIs/oknrpy5kXkyTXX3kPD8G/NMVx90Pr3h4MDVIwqxei6Nlt49UEyEnu7neVbu
6lmmZKJWioSQfOrPNqlyG9i2nx47ZeTs+3qL0U2sJcPCvAflPzQ6X4rraFYoEOgwtc+rBhUO3aUB
6V/H5jdh3l7lrjMMDxzsYagGy6eHXyhre0m2Y97LJHL0206lYhQy27w6rorPqCv7SvCLiDfQeU8F
N/Vsqo1RJ/BG+6lItaWNuVYSvC/4WTHx9UER4nkrEKliOuMv6KG0UNUwKj48L0QNJem9FuvjSZsr
5x8MFRrtTlC5TiE4IZ7ktOmU5X6UtdCAE4zTXxS3xjIJmc7UROnCPV87z70g3bEiqrTc1npebGS9
xAJrocrIj88He5+dqhUdHok+YnbXT4HsFM3m3XEPvDZY7VSr9EkbGm9kxSFo4FygYQjSNuXld1rt
mXZZ8iMr/Bb2o/hsGRJj/GBl47N7ReGob7FKJcrANEWxOs/wvnq5b+iO6mRrVDKqIZ7GH0u1/VHF
B2no1A4QmgARuWzWS9Wh27pB55c/oeCS23ZUhutGr0iHgMNQfpJcD5HbuU5lhsVV1iBNXYLG370F
P038TB8Ev1nFpW76PWcrVj0NDQea4qMDoKPb861P8vLWWOWLMBPmr5GQxytUlfWFhU3u5pHyR5tH
9rMlSmuwcUmdz/9QW+P0mDiCT/fuUbkrKvqzSVzhejTcYyrlQn30WZC748WTEADL85+m5AKevmT5
LhXLqHVgD13Ba+OsuXSrcNtn6j9uzmUoIpioBFoo4SHUJItwFZU0yeRfmE5SOoe/mbhOUXEiWKEW
PsgMK6jDwxdB4HfjdJPOuQq2FzSeAvpVrCmJFdJ4CKzTWFtJ+hfO6tbHLBrEYTkDW8ei5eCmjIWf
homESqV7bon5kW1nHINrk+v653yiQi5wNIgaXbPMpAEI0hArpYEyST03rG8z1u8gbnhWmzIDxa45
Cp6rOtE1RsSVSit4HGK2DkeW9EZNHZ+E3N4IJ1FhXIvFi3HaDhLx+Z6Kiaq2jiPglcfOKheCrjXV
GElJsyhJjJ55kM4bdrSPslKJvdN0TrOUqvj220JC4hBwImVwwsVZTn7UuTbZeyEQhPARb2Zd7SAu
gA3EWd2bK3wV8Lc+TOX3r8JBm5QOqznye/7cDxDnNC8/QQqx9CohOX1mVn6m8yY/2xoGLpQlFbTA
ntbQAiq8Y6Zpb3jk70rDJpTl4eBTsIl9j9eQiLiaDZ1kd5wgXo/s0cUKw4yMtCc6AYRcG3lhzM0z
VtteRWWo+J2108d20BNtSlrQ+rMx3Y+R3pG7sLCfwbRkh3DAnaML5UkW8N9WnS6h5YgAWEvroPN1
mg0gAVNACRVn2XwtGi/l+7jAj11J6iJZpgDlE5II4nheznkMmBX3Ff0iuF5Cyu5yvhCNB6YC/xYj
TV8IQ7UkAXMIMEDJnfmH6DUxzi5PhiufqJAzmEzfn/IBJY5ftuinGjT7PpRA1oDAZHAvRoTSBJlr
LXVeUwkb5jl1+hAgx7k3NT2rn4cTX+jcWfTtaLFAO78m9V21k0ChdyFZEQUi2PTC6Wcdq4OSsUQ+
mzxV8FMYHUVSPqXHipVg0e5hx7f75l9aujEubWeb3Y6R6g04wEQ4iKQ18O/O5Gm0zdFwPP+9ePI3
UCl4xz01RbGji4QmpmAUcJW/xNa6+Ty88HZf9s28AMmRSTGM9velIHO5xdF1io1wDXmv0y9pV1Bn
3h5QppjqS9nyHFU9ipEvazVWOucV8/O4vIdEM+64LhioupQAzM9Q8H/MJ/QA6ixAp1aP3vJV5Jcx
XTMeMYe4l1M+Hmbki66wRFOIi6rewO2c51TJu+vKfWGUaishR4Or/pTnJI41yJZbO008jjnt+Wfs
WgBeCD092YVDEPE5epMiTHmA7MkqnC5GCc0eWW0MGH9Ix761IwDQgC8U8nkSxA+vJ0sGbKLYOq4j
wGWCssINzC1u9QBmujp20me51rP9b7rxW0qAD124mnkh26GjkAyjI5ZRYqpVjyntg/nFIZGl3MyV
E2mL8dypo6p3lzR2vJTXyCJYGihwtTYGQfT0B/PDhGBgwmc7968MQKprcXjEsGFhLkii1BNYWACs
WFgZw/Ww5J7pVKBE3YX+McFMoewGaMUb3WB1TeI3NZJBhU6TqPoLonom5GpeRDicWDmISQaK6A3L
uodYXpdTRYJz1zCTRkd0J2RIx7wSxXme4Y42ABohf9Q37f9lIOZNVkP2jy9ri9aNX3yCrUHbVi1m
RRPtcWCn6il21G/PeFdTdbKf7n9B0gko3WpZi1UjfB577VDuxQ9Z0Z0w4NP7lkKoQ0nW0beF2x9p
E39yFgMyfFIUyGWlrFvOKsYrSbXqzm2cOV3wy2iM5zxMKyW9Sa7zQSrxxalEEPA+SmClR/Ar5qy2
hcW0oZF3souYzfxHL0ALPYx/XKQIq8CUrsAJ3aSxQ8y3mNWRebSdajt0vtmBy9fnvNtzA8/S8G8x
u6RghIfEMSaZBdvkjpKXOKoeWU9wgkg8DUQbmUQOLVNYWXzctWcTIKU56lhzNSfuq+Aa0KilCEU1
Lfs1R1+8rD/+WZSP/hrcmZyBMAOb6al9KqMlpx6VeaNXXN9kur7aMt1R1AW22T7IG5YNNPAAEO3I
kDblIpgem7PsetsVPKVe/Ow31nTi3ZARW+Hvm0RZ4P/1rJF5MckTpWMmgWV5s5LHjao5ZxLYeTqb
v6u6Lf/h7Iari1tsel3pVn8Dk55tWJU/ezQ3OZfLEVm8cdduCDv79gqNGQiY2oxwdH8eXnytMFha
hhcgcB6nAzMIRX2rpMoYDJ7vV8nMU5LOcJhSAAdpssqQvCvqYzb7q3e/l+zLCY8+4rEIX8CdvOQm
5ShZTcXfYa2APLxijF1wQg/W2vbL+PBXoN/9KF643N5qDSKgj0AjBo0IIhL3I8x/+xipRU285isR
58b7AJyMVtVaucdVa1urk2yB1AWJ6plGGN145yiWGxqHf4jJYzgGEaGasJ8nwyb9N0e9BK1kDKID
A2zYLRVKEMJU6h7cJlmPtKX7gzsA6t9ZTmCqTXnPYsk9K39RZUV23ZHnvtCXtw+NxrAR+vNr4cQw
YLhmwDMafa5HuT6K6QK1/e/J1eSZCczCzib2h5dZcqi/O4HVJxbmSzUA/vcGOLQNYUyMytq1OMrX
VP0uX+wopIK41V+BOcgFiBGSGqO=