<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtKkC3t5s8WoaCQb7W1cOlbFUDIe7AZ9UAYuX9xCwMhnh3WUrx+kJBeSUED9lK8JWn6o5kiG
6mfK7YLhal1hClfLbP0b4JiSvX9+eYKdK1LJD0528ZdblO+rrQuC/SnIpM1Ky02Jy0R8jAvaHZ9X
jyoQMXlxX5hoFGsXOHz+KH56P8k6ycJ6FGDJrRzQHLKb3YAaRr6ZFLXQ3CdEagfnaRrYxmDMyv2v
rtrudCPghn/j52nJ/9jRanbi1aN+ly71ZovmSkkF2qtch+LXWRBBi0u7RYTZNL+++fMNEYui4/GV
HcWw//07fMYv+uBqjqxGFXH/LW/z0GurhsLXrvAUukdDAgdA8nIfGgBfUVRxER+zSryZPDPhvRCS
V6nqpFOUCnUmaZC+UsbgDov/p6oElPiBPFn0t4AJUCPS5n4Wd6MhrzdUs5fkqv4PyUj2OBnp1Uvc
Df4W/iyvzMp2lASE8THTU7vjgz9NwCmnrw+M1N0CCzyEpEu9ZNLOC9HYQGPK8mTCfjFpKb6SxzMG
y8rLlyO3pEz6xIGik2RUULrWB5d6Ocy/aVHbCeY8e6cahhK9A+1FLAkmvhZCWDyt+7s2jf8rPteq
duKvSLrj90Z/QBUal0sJlwzQIPjzYplI7ywmAt0fGnh/YyXSB3tNSxPsxvX6o9RsLfT6FSvC25Ko
a/GtcCVJoYCNSPMMNihMsafrc5J1soD5Z/lkTddWqTUkRtXNwSybCz4BBNYNzU7eE+yfSJgx724V
nijusZQkI0WCNTjOqtAj6pA/AO+pVoqGpIE5sUi7NzO/o01N0NwUZe1B1mpoFhZMmivSIJ1DEeEQ
Tuh1BrZMkU1bOed3/4aI5QJVJHairpkBZo+0uJPRNcN0CYrI6Q7LWw6NgbhSrOrb5inlyGESN/bU
U1qKAW3jvU+AP1so3MRvCHrguLlSfGVIvERb+jyKQt8G5FCnzBbTAYX0jFb/mRXRi7YRdo5rfsuf
GTDaJ/zPyMtrv5QEXOPf/G64uh3UunQw34KJVQ/OmDbtG2jT0ERXaAZ1h30pkDbJI07W2brVrcKz
AjsCWLrhl0fno+obIBZBhES6WQ1nmPaqCPmWU0lWcQk7UF9sCRX6rga8ZzH5MBzYK16KEun5XXWe
5mJjVHzce5VhVzZNZ1Sm9w/VJ8e+mqijXRmJ6zTHhcZS6WLXy+f5P1wfvi3T1qTR9boJuA/7fRD2
x2DryH6AR2Qa7CP28SNI6k8E+bNBU45IquXgR1tucpO44cpr+3zMhptNwNIykWNr9UxyGQOO17XR
L4MO50wR2wJD5dB0DSohqkTPrgKgoMQT4Js8j0m4zt0z/+5kYyEs+MRNqawW+sDIuDARSh9uTluw
dx4ojhxHwlb6Vco+BOBmXIV5up9nr7Fw5qiFRB3KeWvdP02HbCv5ADx3lSvlGrnha8th98cmIBcH
LTYk/URjqNiR/qe9pxYaMxpIwVInqYR9NTJdzCqMAt//HDeZCAOtXFugTj5ECT2/rHHC4j6xz9DZ
sm54eRVU3OCEkgiJd072pG6rBqVnB3PFVF0YhAfKwIjHzRk2pj27DGS/iWWArjq7ZJhOQOeIvI7C
2uH2A1m3Qog8GaqJOMuRLZIeVmNaviQ4VP9XF/U6nawLniAnhc++bmYf9xgBwX19fFNw0xB7rlY0
ePkfZYd/lAQNiGyvZh/5guk+DKXK+OiqBzcr9ODQWa18W5ECRwQ5Z4sv0iopxWGubBLtFb85kTMF
BNUcCSHbEVHcm9DImrKN9cXOUbotL3kcnuvRx0UY28ie6+xuk5do0tc0qyHZkWmSzD8sEmZ0z0vI
ljmnAKVb0fIr8HfaIZOsQCoTZzA6eutbNaELOmTIghR4Lyua3pz/vEeHk+hfEDX/01nKkwe5xdgZ
mEPwj4OKcTNAe/+3dlosplwA1XvFQlz5redyCqQvE0lfrPgTfRU5HOCi9dA71Toq9uZkgI92XWjE
Y0e3V8G+7EN9YDnDcLIpZLkO8owO3YEfnkjRuitHGXG7HoImdInRGN8T0+STY9yoPma/XGb9xJjR
NzSXc4m7PEBsNQ6pFjg7qrBQo9ZIn/l6w2Y1n98zWOlmKSzBzAyLoDBYk2rvqXNQBYt7pKNdXspe
mbPDsN0HoutxTn2UcBAbxfJYsA8gz4QWah1WlAnTP0vhhulD2aUemdhZy8JOIUYx5Wjk5H/jTNEo
Sgun8cOfLJ/PQ0f9wQemtRGV2gu+RNMo52a4TiE1cp0beVm+P3JK6j9ILfLaIXD+I6bYWBTcUPjL
l11IgLL3QENjTQkzmYhyCfnfRKABmJjA61zv8Hk1y3uzYMke7BVQ8+8WzH/5OtTDVoD9MjtxT0YY
vYfjxKh9sqegFUclrOsXmINlQwx3iMynCci9ZS/2VeNQor14mwvTilJ1WwPAQEZQ43wzkz6QpKH2
50WPwfWfKEXckoVekwgApoT1/rdIfuLpIdnQPPz0orDBjObgzIWXR1rZwkhOyEXnbNyIfSNTo/G5
GK3Hu/xX5uVmgzQntepz17iVNLO/5ips7dM7dq1/lfMuUVvFWp4ml97G15X/BKDRDcaRtEegf1C+
u1I0QuWheBq2mddbk4ooD9nlGW1epXAh/XI+0d8lgsR1pQhvy62en7LYossUKR4dkf6MGiLJXiju
ivg7/bZjkPjZT0H1iWTathNHQk3B4d6jQfuJOM0gqz/+Yz7mx4YpZs8/AorTwmZSC9Lj31IoUm+i
KBPwK11//r49neDR0Mxl3YSgTy7jaz7ZbP93YkkWg6kLdawqzXH9SXOisHj3yKAO5Skwh/LpkEYj
buZP5oma9r6gbzJK1BmE5MJD4hCNWDycZMKLeVUAAslnMsFgyUwipnvyIvPDfvEmiG6LkV75qQlr
2Cl7GYsW/mHaOLNjXJ4KOQq8Gcl+BKlnqF+nGxHFzu/zjvOlANLkANXjqjIvrQ+6ntV+axXFj/gp
wi8YSRSSmZEyJ9mgw2c9JlVLiiYFHcgwUOX63wrc4XRZ5kHQYOTUL6S+dVR2HtSwg54iPzhUyG6R
vP/0NF3EgF2uHRDZlpIU2XliEpIviWZ8PQMhEphx5sTgk1iqK0Qo54V1L8K1QClVcsCqeakCFV4N
7vJEjHX0d2b3g5Th5UDOc/9/XzjFHLhVq/mhWiEulKGawHx9Rr6vFKmC6jkU3jvRH4wuD4wz8es3
ZxwFjSFGldBgReuucAXyFeO8YbufVW8kLj5zl3X7E0F/SJUlk4QfDPHemF4rgBZ4d7HIxx+E7ThT
J71lE3+PuitJYFWAT2gan9trQr7YL+7sljcEe/yWQUwTOC3xUXvUIPz81q8nmnpUH9Gcfg17ir6f
kAegPslUor1dJoMNaW/0hrLKUXQpx3zyJmu9Bxw3dzti/BzmKK7DQXf5h6GzjOhfRl1Iv4PgEXO8
IP+PGk6l2aHgU1/yPVFaYhq1E+tOxUT77w95Ap66AH8Hr1z8WuraxFRq1rWUggNXxuJIlZL6IZgA
XKDQ6wzLjZZPJ+jGriJ+JkpjQ0RD1bNxlmVBlPNqz2h7hHXnRZCjZ1TQnMX44ONMWE9HYKTvA9OH
nBJXCyF6r5qWFrMaxZVW5MKEsLOViTmjtO0r7WcVOsjNBLheWqOPQR/8v+dMoF28gHDGlPFjAvH0
oYHZgIm6bRqv2FNjE5n0hnTQEF2eCsALv4pp5P4ToYMm7YcX9n7dwAkn/ammuTrAbmV6XOk3z2GU
UsaliAeZk4gSH3l6agj9ghOJ23d9Rgp3NOFGqOzWILFwM8R9U8UJnZawjHhwxn0myvF/UwhVFMvH
tCDLPL2seCEDVNPZjZV7t6Oz7qMPp4brQw7y6X8a+lYCNKdjRIVE8EaVDCwL5n2EbL72E5hvUfDe
Dkc9uNp7GQx8C4JiTnywsYlJb1nxHXm2h800Fb1SXRbwtsPlPuexI8GzBi4Lo4V3fFMZV3v5f4bq
0Pbjq67V30ZRWHypBhyrsPyM/+oQj6uaYYAfbq89SlT4i+l8gK6Y5buRSx8i3m3nSdGg9Cr7DHWY
cKJCt5fFyjLTr/T5YubGQjEhlmKPwTGq5iOLb2bhVOkSPn+kjTMImS3CPis7Gmn+OoTZm51wEvFd
9WJnmQ1L1ZxPdhiqLuWJ4T0rd9XMUWGVQ+dkqW1Ku6Kk1X+JHbaDNC/KXNBSt1CApfE/HnIM6IkB
1CMYFXKsLi8pUnfGOuO5IbnGrC/sSlhPKpEan4iC5zfSxEWlEqDZ2vZ2msBnCj13XjT1eyUcxopu
Qu7lJbIaTtX7pOvgy3w/4gcnj1YaG1AVuk0+j8WRpPY+cG9sS1L7f7tMEIBcMasIZm6DZ8gJJsCj
FGIkwWBuRV987kiQVW5M1ml+prSXc5cnRxbEx+ZDgu9E3Tq7T+iCU5jKx9cA7pYt0Ss48PapfE1g
oKMNSfPGah3/KecgXYuvGsUNE4PJgpdl+6rd6MO9TTPMLQ0S4XCxmnWdVbVqWVcM/6HmOsFX9JaL
VRGljmgcW18cqO5UfT8NohED1TLq1oO4j6arrUe8NyvX0tiSe2CLkrOF5g2RirPIhrJkFYZ7PtRR
fol33cXrnY6kB149eRNvVSYrTjZkDMFQUjJI16wDO6MTUSETm/tznTfagSv3pI3v0INM49RSg8TE
Mu0F2Lx79l4cf4jIjiwe+9H5lJ8cqBTf0Xr2NOJrhBd1CGegRlR0Zi5ti76jrgy38KPU+luCW58i
7Icd/qxd9wWFtNFpOcEyvT9vGAgndVQPrkmtG/ANTsKU7XLcNtT3QHRJYgoX9eBUWgnra8/UOffy
HAniiYG7WLWG82H0ZXKY5sZ/K+327s9meThd+kj8j6uksiwKuSAI54TLi8uqkq4u1oDnpkQpqPOn
Z0NBg2/3NYsQbav6QvREQo9BHNdKBGqHSmsfNB2sIXPl8SiOvi/scvuAZ3Bs8f/zC0zT9hdRj4Dn
q7rWU9qW9MMftp6K3CuvM2vautqorRy5a71T8CGYjZ3qOyYIXbo5wJGYkvanv3SheffqZsvxdfX4
d8TV5ZHQnwPad+D1USDcXFMVSxcnqXiUmCEV/Ip2W0lPDmPP0LlWdG/q+iG5n8m+Cxxh5+j+b0vm
yS4xSb8LP0heV9EWWO7UZrnTNFGds/14kFo3xXyfP902i6/AE064l2jhIDqoPGBo3uKiA2XJ5pcs
IfWa5gkmfJ9ae5woH3dXSqwigR3nEXGgjnmcJCe6X8MMkNXnY2jRqyF7M4h5IRBjYsuYZSOXsG3N
IsNrHKQYZSsqMcAMZB4A3zvRlH3JExNlzYkQNW+JJ7bKpG5/4dZJNcx2vracb1NoJ7AYcrWv0+Zy
+nnw8h1/nypGcgWGdSytiSMGpnXaUk2cy4jfJneqmmoiYcL2udI74yhzZgJYVLuuteJf2zXpmuhI
ffzNVleYm4FgDjhmKIAWAU/Ix8jKRXdZXLzN9vBY3lDgutF3CIqg1/hMo0p22ksaAB8Jwnma0c2q
NQVdz+Z2+rQGrLvR75qKDbnJyUn/au88/oY8CewSAJCbRBLQMLiZoI89O/HBKl49aWe8T0RPUqnO
3ji2f2sgrk41k+gTOLtkMZ21QcVTRUv+O4+0fdvddbcEZ0vJ5cH/ypFjDnnmGvwT395NfAgNaf6K
DIvkTSYpCH12BXKGE662J2LS/Fs/TfrKmDmR+8aJjMpA89AQkmvJzu6eq2tx452cDcSOnCUhsfE9
mK0nPXR++DASxgBF+tqgo4BsIGJSL2rESzo3fkwHSvWDOecvnJ51jajYIc6Z0uGQxHKmsw+b98F5
bEji2ZFVvB4QM+pT535AbE/pPdsZmoXg6D04SAY6DLO6zMZHvP9P3pDJbqGziAKMTVR65JC1EfCe
3ls8OHyPdk5RflrS+7eVws0L7vb1ZQUV3RPS38xAzQwkdb1pLzYI/n25dOAf0mLtputTYZPpR8p+
L+ldcdIVLtCsOaUL+P9zSggmGFomTJz/hYLLez3V8cQ2VgkTuc97G0BzSGBbZYrmnAYgYpsOIyZn
rGaiSfCv+4UpJksm4nYzFjb0JuAKGX2xkorwybV7jXqGJV/UgBO/gQYRDUwS3lyKyF2PwrEPWMZ0
lF42eIDGvEAdJ+TpSrvlgED6VOzh9L6+Qck1SrOFr8yoVjPOTdmMg6fnXvIzA9gyKPMRk92AcwsJ
h0trUqMuw9jlB6ZPl1zi1P/5EIRK2SVMKGDQ2/yISxo/wVHYoi58UJzKWPMCqHWAgC9mqMNxLexE
wtTZv6x0/2Ptjh64mK5DarAA1F8MUXzHzB+livlzLMhmuiXmllaebQzOL/edJDA/fziaBBlRVuEy
hqoWRyrLlrOvUEVIjv9JQalrQZBhVg50ByS/sndCDhykbpejL1w+LiMBExwoPiXoA8FquBAjElpQ
a9xknqYi3swhuBQFDkDpC9IEzCEFU9XEBDPIPZ0x+dxjzr4n/J3tK17+ffluuA169fHhG7/ZuR2v
yS7nd1jmrjjZMDrDHEwDE84SUPS6I+J21bJIDGc1IgNSgcxTUaDH7Xg2vvYrxn2VnPLcSd5XTbHg
CgaasYx7k0rYwvkCY2XPdNVzu0BlCTsqGkXSYvPR7PB7iWrCYFuMkjwzrp0nT3LAwET7YhvKp0Da
U4c03kzgHoV/5rTfyFB702xiG8jiFHNLEfHOwKg1bKuVPTacM39jQj9ToWCBZ5R0MX4BHsVYOPYc
fL8wJvjv5QIR2AafXkTP+Ar9et1ggGNBJ6NJbOraiRLS0+QxAfqMwr6l3sEzGrNVYVpicRYvdjcH
wWDgQokk2IPUydu7ueIKhfUczZZ//n1IbiykXHK2jDkrJ93csZrzCNQRcj5XLHoOlDo69C48+rkv
LDhBV6as3jgnFx8xf4tVrUU8eHAo8O3OL/wX73aTBrqlZzpULSIxMsLJLoctC6SEungG5/85nrZ4
za1M/ddmvl7RWzIED+rLdWEEb0epkC6Tst/FE+O6dGR0NSdv1BOQR4k1seiDIP40psFD8DCJH4sn
Jn9w5rAEldaaxi31g8T6RbJjK6mnvrmXQ1mojRzJL+xPoigQsSjSjtFpr8S7/ulKY4J200euzCnM
RLI+jIhouf/wUdLptSdU42BusUZtmN1UCzQKAh1RVy1MUn8//W0TBiCvHlbHCYvurNo1zwsT7Sua
AB1ZXNP3CB0DzoVDvoklfM8tAT+7NNG7Kdnl9+E/TVKIDcdCdZ9CFgYglmZWdEUDb+Yvl8Yj7Vs9
kUhGiIgONXwH1wtXMay5J7rAI6g/1UuvTHr2V4a4WX+OdrIsoksUxrj/jMB0AFzll4xUEhM+0gXs
Dxs25pw/5hpqd3uDIwgFXu8MnVqWQPJjixCbKkyUHIlg8C3CHLIJqsTCQhGXUNEisnsU3b/mDuFs
am7VYI9/tukv2ICOl5DxADEX+s+QzNE4fLpJIECGiyGIKMKRU8ag/0J7Zqt2FVodjBISiWb9NfiM
GplmBVc0DtXV2EoP5ZtFKRNzjUhegd/z/BLl1LptPCDBrpzPCHHX43NJsMbQA3IB4tkHwgam5GR1
Xu3ByeDJ8YJZMwDUPmidP6GI/CWXR074pDzPbU9L8ImiS1M/VS6U33l6QK8TXTGHnE3kVZslhTkD
x5aW0hbniqh+UyDZEeTJGVE14QefpcQKvT/9hFmPvSVKOn4QtGmftVYxL/rh06LjPKbqwzE7Prau
Fkh7peFTiMEhiHM92FyT0DqQc3TcjIF2DrooTtamD647LhGW5uflYTkwRIgEiu2HGhMH3IeQFrbh
NqTN/YSVgXUTn7DvLo7Ezoef/4BIDPIDcKo3y3GfYhakroTdcXSO92ygdEe6/h/x004IxLsOBMzP
LOKTauqnM1xB1hGeW+1EZyCI/xcYR8g0uVPCulgagzEGPbWdmOs222zDTTHiWulZf8t3VO6yxyXQ
dfsdevFaGpbfmi+Nxoov2xB8Hn6zn/sD2/S+W+/hh/qvQBNVYIfQ+M5IytLzmjYIlOkCgEBm6K89
4naJgKYb+apb6htawVsVZJQ79hbuniehwDNT0IEHYt+98mDoSPNbDlN6m2jo7eoBCySa6g8XngVj
KBgjDto+GMqeHIBl2zRTGBX4TugBZZz4FOy1K9k/VxCcaNsoXcm/YwuLkf7Amsh48r5IcEhw3ETs
A4ru+sHFdkfTrQjojcZVT8NCItuLQGpTvN8CQM+zs428FPFIjSu9aP5ZGMtGEZ00alDlBdo8cWkP
oJ4Phr7uW3xmBWYbbqWuZyhwrbOPz/a72w4aVVKa4ZxQtqURWCYiKVysOrL85geG2ipLMy3mxUUY
kbKRH9b1kuMYK9VHqjnv03Ea+qXrqS7O8yeBQKT/IhQkvyrbBWVZ4REjHGaDkJiElm582aWRv2XC
EFS33/dp8mnC2isC9D9esH7wmsaI2hmLcb/E6S/Eljt18AtaD5WekZdeyrVS5TdDhHyPFqe/2b+a
LVCqjzQ0WkaOaG8JvVgXVDncZHZveo18krTiInT3hgR69W/D3zCLimrYME1apy8BuTYdD3MfqP3I
H7fcE6OZvOtyh6dNg4BmVgQR16CBNId1Ikts2o18nYE31m0ovBTq+ICjR6U3WBXwRvaKNAtai0gE
EFajKtn6BzVc1EFVSka6mJIzyFiuTyZsFucUxSjTDH/KTNbY4Pzr6eAZbENeC1vaCZqQwQD4wnYO
WIMDXiA8xNHwtO/gP5ZhUgTOibJk0wZos9BzdIPR7U4A1Pa4rWwe0hZfydbuhb0SU32cqRIrFMDE
jMfbcm07gqiv+nXcpuRj7VDikJTATfrvq3yszP47PsV8wvqsa87N0YlqJNTzDY2vdtXVuOrlA/Cu
zpNpSMiIiRYe66ITD/Lzv6laiKWbTvkROloX9XutwApRKrQHtWF1NwKe5/PRiMIsUQCTClxGAa9q
U8MwqRMLyMc+dlK9YWatLH84sd9wWoQPXjFCy60JENB1TQRHNpXU/9tAb3kU+KxA4P0RME5OyyJU
sdq75mWC219Na6geIMg/kXmTnsMfecdEwZd2SZR1kc9aIKZjz1hfP+ScjMHYOFjEYaHoYojCSVJ/
/c6RUExeHbtPjksXEQbdXWoty4HccrCJWEqXlTb1oeIuTVUzrZ8nh9VNRKq=