<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxaNGFp7bRZpdldLt+Jfwe2NQhoZ9/VuGucuLgsFfOPJ7YiCse8OhtrAt8kL47QSsKOojUG0
d8fYAb0kOHCZncmm0llpWI9yShufYrkcbf9Iuz5lhSn4J5qIJgdEEVQkN6OEY+ZNOCZFb5AbldJC
sS6ojktmcUFGPOCDnpasKy7lzqzxzfk0rvaqlmW6ALL4XRift/MSjx//vFuc+QMUcKXHwM+v4Kl4
BJFL9Cly/pOgW9NTtSxkobet/NppB/mlxl18DDLlWsO5PxOd80HtjBOotyboBta0MV3kkrgxxzKr
hueA//YL2e5u0Li0/7iTq4f3HjM0imHXN4ojRHsQdKJwKA57kw0D4rnFJv2mbz5DY3HS8sZrN5OX
qf8/u0X+2eVqE3Navcil/0wcrn8lL1OGETesv26EBKS4g7USQcbUgkppaxYGoTBVgEjeJylqZrEG
3fx6kdA+RWGknrfDd/EwXkVrRBuKFYT5giFZu9gQwY2rPfM7JHNNbON1RTFxmKIY8HAQ+t/KMvqp
9w6OoO5FKG43AbrpUujldyVqlnW1uBIeXhzC7B0ErHm0y7T2X41OQZgUUtl/p4y+PL3k0F7cgQLJ
jqUu2f0xVcPQVWNLvOU0S47dvs0jkUU95InufiHJfaJ/DtPi4moGR1Y3QjP2oxbJgTK5zLaPTcTg
JhVuai5+uVpcs9lwi6FhWkeAfvp0E+VKNVDe1vk8ZcPQ6H5Nuvhh5FTeDyfHZ3SrtfkN5ivTro4m
fWJDvAF1wJy88vU9AWNhk90+zeq7tnwdcS93fZvJBQlW5nQ+3NmjnYmA/4Q8EHyWCDfIvN6ZrBqH
5lw3RmK5jP3jNmGXZTn2oxpLY63YMzErtyQr3crfodyjxMxlillfSwKVAXP/H+SxYCst+D7iz5HM
1s95cueZcj1r2DVI+nhQgwygHFmLgdh8p9Zmv4AX5HB2xoAS479nmj2/DlyblY6W0KC+8ZTAkE4Z
kZtF0VycLbSQsU+ZCDmH/rxMGKhX3EfDP1L07Uxrw5BAbfbQxYDfiOcZzArRggM1mxjdKtU46JwS
Gg5Svo+ppFGYZoDv1ytNAtikr1JrqNQd7uh787SkVVcr8lV/cw/xrAbz9n7S+Pb6jFLG/EBTr/LT
wuQQFnY7GcG5C9O1DR6l1fc7X92nT9MyUBWlEM6r+0/kxYD9LK2ZEvhdFrKWe37SltGtj/Q0P4/M
z/nIJgtIKnkBFih/dB50jnTrGnbAwqSq7+jWzv8aJf41JmkVNu0iaNe0svY5A++blHLqLKLdveez
KsuYYA1BYYQvNTiojxfhTENRrYerhn0GqEcL0wSr/+W8HA/GHtLZyEoSqzzdpgrAgyi0gHIJJkbc
roXRP8H9+26L4A3txtQMjyBuzvP+fE77Ci1/Ih6OjDC4K6MmhoO7/g7SMX9zYDyQkdtvrfwWQ2pR
s6kPyuxNShKMKaXvyihADMOSOlHDkMF/i4gJnkx5Gs0kBprshDZtzpzwXOhETD6ukXUPji+ygcdT
q+FTPfRinuDQ+Hz1X+BPHhvnv0fkhwJi+ed9v1n+EuNNqyBWWr0+EN1YRoSQgJtBQ6T4qN7frONs
Rvumx6pGrS7+tvrWokRqnhNq3Ho4dhEBBXht8WRrg0PPthE99jb2wJFTKaThWjRnf6OvN1bNPHWz
tO2AeurChJR/T4jHJ0dtYPRBzk0FCw+/LMqQlfarXQSaj3NT8EisIN6ghStfQ6QlCAEPVaQ0RUiN
S46ZJ/Pcj3uXhXTwWpyF4NrLSLor7cCJxDvYBwzy5GyksKR6G2l/CgYxvObL0dxd9fUd5471clnw
bYG69udzX1c7DLHxMkvsPlEnJnK0nrHVxJb0Gtfy9RAsuIUkHCZs0u86eIz9D75gXbVGrtQo5rVg
aLbS8ufuBeV5ohf19/de5zy/CduYuMikkfMBa+yzGIgbredkJjwO0H/Cqfsa+t5yxQK9tXK3qeBf
ILi5tkO2MvXCcg/NbnYsgeX9sJ+RdxrvkO45fabyjcsHQOAnDHH1uS6m8yrDnfxflzAGYQcajS1t
89NQ9jDYqnogdKBuAI+j3AkQoIrbRDi2ooyKSt37f6HXZUNMoJqlqfWg1c7Rh1QEq2GDQsXbMKeD
bFmp9YC4rZSq5nZGqC30sjkrJXFoje6jYHU4R45HdOTcYE5yYm/a0bPDu39Ypynoch/hcnaggrKD
qc2pvOvHMbrDCa0j/aahMx7KtqmUxwSMGjwDWnZiKmm7+jx+qLTYxpSAzNT0XmLEgrbfL56C9VMS
LM3NdBpP7XIOdihlIfyznQinEcrk4KmmRBi/wVY0wu96oyvX6yc5jMdtDyh2XiqA5YQDJGYUUKMH
yVAJjssD3MkJRfmQMgX1Mil9Q3q8HX1vmkT4pslAzYWUNSlebH7CGPWd2LJEkkcgpHAPgI1+o16T
1uJeXZYAyYe7E7FzDuQsjL0hh90GBDKIov9+KLpi+jYpXc5HcGdAf82TnlUSaaCxNe7W5tyt5u0a
s/QVMSWApfLElCcm4GasYIcDCudSsQbQfc1eRwlb4P3AA/NekiacbRhZHl8CxnyfLg2AFGChoiZz
tOqVMtyWVPtw4Uvq+eGiOR2uxmqKaBxrJu2D8/DbnJ9jdGdxQOJhyWD/Kt17dAJfAZlfaIDy4fvo
J+30fEwlzIW5brGD91n/g4Z3zX5D7vPJB4j7cUh1Ocp7oNYKR4Au0KhJf4RWZuyfXLXhy7bxqLBA
tzVgYhaRYca+FwIcmE6t5nNWsYGXqANrosgCgbMPIfNO2doJptkmzTh7hDnNJN+QyjcScFP1tsqP
C4dDGTEmpQ0xDFahob28MVBfwSO4LZJgXT5cBTYY8e+og9Iqf3V/IisTiEsOeNAJLHBHLhQ3Lz86
9g+P6DuPzJYcMXA25ltgm93ijp3q7vNQ3kD9fS8SuBr0YcuHd36YJ9STDDpUQ5XK0lSQXk4twqzJ
s3QvgYra5f8H0pN7WMXLwqPfYQWwea5pp4t9csktcbgmnC+u6upaO7RTfD7etP4DGv2JBOqLiyrm
h/twfnaD/l0EV9inzF1o1R6gtrZCuQtS5rYuliXDjOF5hZ2VnpryGrXIlra7OyUa5O5/pjSx/DvX
0hLj1zz6n6Y3yVzfy0Ik7wK8DOy7vTNNjhv814PnTj7UZAhWeRt/DOY4GttagF7MZKraydYrJcv+
boXEAa1Unpt3G/8fjPbqxvjbp7Ga+ZzrXUmfqTx/9CwyME+6Az4B43cw8VxKcOvP5Ni2QSYK6Li+
v+OOcjrThDaMhB6fWvhZCqInv1qnhzkg7p4rczEDdvQ0/IhI0brPsA+g8utVYNtBOPekR2PbZWO5
INRe8rOXuJE2jFusTGr0t9NNXZqGTSF8xQi6MBp9hxLViIjuzdSFrCj1pArrw/z4K5kxcYfJmn9T
CKGm/upb3WRNEmtqBtYx5OufPNNQeC+7/eU/zfEjRLwCjD1WIjmz59PqhaezmdM9/2FR5WbZ8f9y
ETFAvBjVZH4ge9uLHyrjPyUP4HOgK16FU6K4JcpIy6ICZaw0kz+fz4dxNAsoByB3w/6XisgddyOh
k10tagdGZKvgZ6iLa+p6T+q4Irc1b3rxl01U/8G+UWqeZxI8/3qMfivQppVYbDYHj5C9uT8sJV2g
48XasrFIiUi7x4UYuQSOc1wh1ixT57de+Xg5f9GWTeZKBWYmJtp1uoRcpnLnsvfgW6ReCYSmzZOJ
Aee4yt7k7rtLr1159YHv/adAvXiE1NCVtxKcG0A3zojaczT3xL9ZA04K1igOeYkzdtnnVL/XRTkd
nr1+wpWd8pHqn4IWQwOd0XvfqnTjZeiPHXFCIeEfUSQ56HLohRLCacuJnylrbHADITD8z3Gtjm65
mJ04gzKegG4gAfbbGGARw4eH1eiFGNCI2ZI8/w5htf7jbmM1kgMwDYn4iApihjJAnaXjqIwDEl8V
2XFGSwHu7urJs0LLlSMBKgyVpBTijXC6JUF2ydpZhedRsSqq7QfnzURI4v5JRIQBEDO/ocrlvcWk
FWb0Wq7U8FxTAjNwLnt7GXJoWMv1rNNPWGGn9b56shOQh66PzPI7LZHOrulWnFyDPp/gSjZoFkmU
vPk2SbytBqF+EjocSfzVqAwPclqWKsnRbfAEzYHT96w1ZQR7p4cJFUGbcICN/h1+rN6bD8kV7EFj
F/i9We5CNcqrL505C/zPii9LTeA0w1tIJOJNNejjMCnN5DX/nc3gh1eexAoVvePNpGABxH2EIYqn
QMnT7U5fCX40Q6a8/Ft2xD+9BpjCNsGYbk4n5Q56/vGI8FtWYXN9u44tpTa4Nr2VevkL5WooOWN5
0MhrL/+kv5R/wp6XFqnILU7p2n2WQqaM/S5O9pWFNrS40Pm7Yt6cabyIeanfreqjyQBDuF+ZCbwR
B8voceTk8YCvFL4ec52tRAdC85LIXiamoX5Cj9MmTDT2x/9litFc1myMdovjTaupqcq28YB/ul3e
YTB7csmbOuQb3I4ktz1n7Shn1TohyhoPg0VEgAWSQsxbGomaeWXn6JwJFmmYO8za7wIJ9xQXlGAc
HZP7CpBjTcp4sZlPau0v5rpKRhFbzIQbOVz4wBavO2YFLyhHvwWsV1huLn3RUNHmhxBBq0Ottxp6
UPuVdo0lOHy4OGpoCPolFcQLpZyKaCWTcq910iYKfvPIQbytekwXlcmNeF+Au30BSkUq4EMipodl
MkzNNNRO/c/bcPyZl3cpCrIKQEP+LZaBU9wu3Rzdta1u2PMMD+9VVcsG8Nhb0oxP5WT5ARo8auWV
tguAN2xrAmhDkwNDIrM20HTGLqsxJdQJUiuadUTaQ6nYMw119QGW6gPv3otxdrx8kqqJ4x0l7yHh
QZIAteUaWeuXieD7nQHkOeyXhPpkgqHD5aZQAqD1tRGiHcV+XMI9ECINb2y4Nb3tFO+y9Inz/Mvi
rI7luqind2/1joXOjYsVsnT5ArqiS7tBc5W2zCeR90LNr+LDhPaU1uK2V7n6IOtgH4IxexVXJTPD
aN6Az7hXRlMAcaQrc9esbU1//TLYRsd59/t/nUrakapfxYv3cjaF9YuuABVVawORJT8O4GgEGj44
7+C2yHvG2Xo4NNMWCKNjJZRhMP1d1I6i8F8tqWKBYABYwX39tAdKGAkwiESwHBVD40CJBhhADl/o
du7nePv/y4YAXpDFrmYs+661sPb+8OQejmn2wzpa68+a9EdV8X3XRmEakB78gu919OTxTxxTKPnx
WDWWYaX+Yv1wjwOWKwJWxRXPQjJr1tgRKbXpzFKKeMOcvj/scMz/tCQBzDBENx5VpjpbNqLNWK8E
drqYbg+9xcR01GzRBGAmSCUyHI97zdFhhaFcjn0IpFbxKwJHRwUZhMnhUfPSd3VxIHf/mExi55mW
tL9uBlPB7NCn0MfqehptvixHwP5BYqzbi3A0EgJcE6KU8Y168d+oHIkpa6fkJLnYWW1BQ74Of1bs
GVVu9Zu67eXQvuYSlvssb5Efo3fpMAkMAViGGAqUWedE5R0xFtl9U5pTNWXVLt4OPwrZ+I/NJePV
1lo4ZWvD7CoTKSag3ucmyqyQ4NBZJ9D8FN1iPhgiGEhjVNgGlsk+dFNmmFWh2By+YKtkYG6isxu0
Sv1ULoJePGl4lhryK9lSQ8cOiskTg0mM4s15Zs2fssmqPRu6toEEmcErGg/6NBIrET6BpIW0Yash
h9L+xd3RJ8zTGS+oNsCJCMFb+BiO4Ha/VNMTK++MBLKuMqph0mJTj1zEtbeFC1L5efi3uMmJGCT2
eBSe4aGdvoOvmwgmi7yFSZvwEbwzvkUZW26G89CUy8IFeo26GgSl7fUmAp6GStgH6fFGMX0OLhvb
GWbTolJXEEt3wJSk3TVKji2Tmk2RRkrTqtF8+QnOcSV2LNE++n330qtz6QQqZpAxJBl+r/lty1iH
9fFMq1dAqM3AcdyKLsLZ4s6flEivLg30kRECPzV5TKjy9mSgsQZnYJXbGOvM26/pDtbRXG+BMAuQ
SljtLvK55+hKoUX8f6WrQ6JwBvzpv9HpcKN/3LNZbs5jYqnHNJTfZX7evkES5o1jf6OHXSKPNuxV
d513+iL8ZTW7dFrK8w9o3NamlJu0eMLmuAwhGN6k7lmG7DiQheHOROY8tVNqLP77E0vrQn6UKy45
ak5GQqEwlzDlznbSHZYMh3XJnlZxakS29ReszL//GanP7IHb4ciFGz88blHLsaTRSBcjeX7nzZvd
jnKP7oD+e2IMVwzWHPcUDiJgPH/uEwWQvM0YfPauoCVa6xMCua3u5W38QCLGahWICUL5pISBbC86
v0E/V8PgEXBelS7g6ENaOTLWEpZrRz7A/RtA4l0Zqf8x9PCF+W9vql43jb15QmMOM3HIuTs33HFA
3XDEEO79eWYgZK2TTXCzuuGAScfWDTT3jRKtBYub3Rj/tXErsPThwz/Zn/YDdOuGSiT5uwvL6DkS
qQEU8yCvr518HATtEz+/mnkeTVOY9CSR8um2J+LNw9F7YFsYKGqPmAbgJLl7Zo478wY86E482ckA
zhZ5CaIwY5/kYJ91NPDuO+xFni7GK3d7Ttt5GAO/9n/4sPbF2xdvAntnFwfSPqpj8j/Iyh+SNFYC
ae8s9b4o7bF1oM28RXGwfAxj//mmR/tPqqzIiYR1JKgoZgJ41lekNnnZ+GyBlotc/86LHw6YysuF
6kt6UbAwyGe+Qd55k1NogDFi5CjWzL/ny0Epl7S6e63kRkmF5N5/VwolIzZMbc+qtUufbkxFwiuV
V/SvSqxjX60SsCUqvX77p4Yc82qVI135owMJgaSTfIZb0y1XKx6/2/cCs3I/BgNAyadKOPH9HXUM
k7i6UpciXnjk6z7N7R5FoJ4J+XIoQSP8hMwrRer0PPAdBWs5v7d87yznM6hprZi4aKtSASvushtj
Wvnm/4lCAPyIrDzZXoU3zheqR3bpVvaXZHOQWb0RPmzt+WcvP4IHxShHkSUfzKLfx69Gy70NGSrJ
fx/O/1kxPCgncSqatyMMi+Ff1r4Y1i2ATgOSFRTLGBxsi9cRpKIBRnMCk5bpwB7VMH+WlDnwThis
VtbVF/late/sherReg857b+Q6KqWjdopFPM/bYRdChHF/cFrUVPS+jzWXzqpc5mwpKnjsDm7oHYk
QBkWNApoxiRDyDQXyCTwgEdFv+XBUa67Xu4/1m3J6Py4UvVn7TptSAXcP6hjR9YN0rsLs1fNwNiG
BkvQYhem2u55/Cuo5Nwhj9Z2RZ7QkTYdJBkQKKuY8M5q76GzlOdIosnVCAZg+osf9jLI3S/So0V3
JbwTavMue1lU5fYcZh1O7As9A08Yc62KKvIAlMatcKN86mVg50er2BUAysQOSaSCeSw1/fYrOCQv
zUPvXzS/ezV4Sz7u1szGpYTtw4csbRASURsHiWvMLEM73VWmU4y9R4WxtGWaBAkSUCc9zzot8YP9
VvOSsqp7c+AQ+Z30mUxoTCJ4xmJZchNCVwe8pp1DZulZrSFk0bIRgU22d+TRkcheOKrVObe0Jdmf
/qrm3k/+QiWqj7XxRx80mBYV/6mB9NtxGOpmxyJqHWZOD1/XrJZx7FIcB5Xu1iJbw4Y1zcQGUX9Y
R0JtL9ZSndclAxIU+jeCUoxZ03EMNkhCcsv+sN7sHNwKhx5PIi9Gshz9O40NN7edMVYatCa23m1k
mQyeRyahpAguoGRHAnyGZoquIBv+wqE8REvptL8An87PnHC2NgrX/N5yc0F4GR+xDGGxzO9aFvA9
SAw1+vVID/vFEuQnOjPu5DhWrHWaa+UqObCeU0CSA1WaD3ToQBYndZJsbybvVZFDHQBBrvJS97Rf
Tg7cH+GV7RrtzC6Zp+hRh7uac+Udk5DJVNlj5yRXuasInSrkg7FLrEJ48WZKd+n8nVtBwld/bOvb
U+ZmgQm5gbbwY5KDFsLKDLbvlDks8ZIeBKcgR4iifWJX+hBanu2WK4PaB5HuqTqfpClq7BFPFf1G
sx96kq9csoTy33jHI7CA+6dwQCDnmrJUdDdO1vwlwFZqubGMOZC1yG4amRnHSakl16elCtEUNsdE
yBwtT7TYhCUp/n1yZyzGndlr6CalvcC93tvU0EuECOfPXQ3LuKpz57NlmMBjtcjy9l9qaZvM0W6m
9SGr4hF5x4jW6VIvbv0u+Gmxjmg0sq5Hy6SHCXW++N4xYtOsRw11JAcZZwd0a3Ac07xs/Nso7uMy
PGARiHq9kaja2N8ArliRdznYOIk1ARVjohYAL4PFX1bo7Su1aaXJrzYtlhha7QaV1YgA/eEThBBd
yjIJmRa3UL/TfUT3mKAeqaN0RBgPIcZN3KINJcWETQojo1YDcGVR9Qea/L3MYkA2kS0KwtgsT69n
wJR7ILUmxJrwXNdhsG5xRMTxL8nQN3AiddqkAbdKSa/rkoqH51AxnRNKHjVW+fdx6OnHxLekqF/8
e/icdfySmZV9cceJgVoMvC48yMfyW4VjP04V/Lb3Ub/JKh/1ZnThIgMFOUHyheE9rEEgEujIlBVF
aesl8EEosiK95LYKTVzyGEFzpeUrPA2Rg5Qg4sRQuZwFMN+WUtWbkJFLlJMAD0WDYNAi7ZFPLb4t
vSfh69fuZInr0+nxa4CF2z1HV9aL7nBisRCDyzBgmRQ4CvgBKb/FvsKS48oGAQzEFwP4Yc+TNnTL
T2wt8LQDC0==