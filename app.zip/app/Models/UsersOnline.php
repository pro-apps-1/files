<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx7mhLKATnQQqniuTlhyfIxrSJQEKifcrAguXS05ktEOIK+bLAFlm0eUbk8GeSnaxuH5x2AM
E5A29DsOHHRSjcRBO07aoEKFXKeYCB/L/pWMDlzOz4/yQdkhRzw9V59409Pp9KER+hVgig0/zgPa
U79bfbcc1mJBPUPopm1ozGhp9vvQ9sd2niolEgcykb411argnlQG797AohsLqdqiUcX5wXjQ6iKX
M7n8CdHQJvP+TUQbcdGQmrG8BqEF4d5wpBdcq6Wd/76Lpb7MaO8rknKwRpXfR3M6Yw4Ir8xs4z1Q
GpqlN2rmj2s0PztcWnPaPhbcZBi5oG8GG/jTh92QULnutUl3q9cv93qwN4RrAWAJydfnBTkgr8k7
EBUH/166w4zbWQKekIFyXDFSHXo7/7a0vt5o83sMKsdHwgDGSX2QZtCjeYaco26wG3VmY5nwha3v
x4eYNC6AbTP5PPErFMB+6FtQM8rdFmupwUr3+5bHdy7WOclKtN7c7QlIKk+Dg7ASqOVotfHshSz6
oLLJddrBQsNqWkfAEck2vIY4s7MMb3cRJ41U/m3YWa590II4Nzgtxm1VFV7Ns1UzL/jQ821Wso7a
75rJ4dKCOxR68OqrkUUMgMtB4B3rNNQ4vb+SoZj1ZAd/7JXXtaSwxTwzLwWqlWU6Ifwm8aDhJCrk
0Xiq0h6o1eIFso5mGCHcOEa6331hUmyXRVkXRIFx0YASPVCHuNYhLuszWSgdlPZcW1NI5E/BPWtn
tABw9FTpHbz87uAklq5bZMd/lfXNN9tJsAzZp3KNy37ZO28AAh3Ih8/i8kWj+GFBijPyKksP63B0
PWcO1cLjTaPv4AVW4aY1V4d/HPCf7yGiXCHI1d0E8V5+RZTnWxNmCdY81dkyZG+kRj2WsS8fbdW5
5m2t5IMPcPqI/a9PDbDagjQBwjRq3nPgdztmpsYxDJvBdsOIW9nFo/JuB2ossCYWEpYrSA1qHgyQ
G+/nbihrRpS+HVvdxRcdGbjGdWpyERxOm+YOxQlErfjaGWJGVMn5IYLJTiHRPfgs0xNl7cOHEjSN
Vk5HhIl9j+zhwzonUTG5nbogjCiCiBBuaPJ/7DPeWIVDJkzS5pBTpszrtPjoNcdqxSHqD8/HUv3v
shFcvTjney52wASEwTQry9L4yzzIHX/JO7Kaxd7Ro8cNJiHTqjRaflNG5Pb9ZI+xTJq812PCHHWM
c72/GtQUoqfwa4rks4tgIdIHs1sD1i+p+l37DjWNd/U5TLdOzCfjaq2wTu/kTpHejSMh7+lUyjrz
L5QX2I6JP/qnUNH877bPcbA72m/O6l/pP0MNDg3yOXlpjZUKCeN85F+8XCca4EIPKB+ldOQS7y9w
epMTzHTPSiHlfc7/H1bAq1ziDVtIEWlJVizfUOzMp6RaE3sOQWxMvltREV0+jaZSYrexCGy2vcsb
bHd1HvZ6QYRMGT+jtRgj9/6HMpYUUAxwC5YmtVg4O/wp6aPRn0WwURAAhfzm/jZJAeIVUdGPi4/9
P39dW63FoDKdum5ght3FZ9fDHxBPEiB/kGLSeUwPUGjCJKQWDc9aIYk+j76NM6I8yBNG7y4n4Eq0
u5RtB/NGQs7VvV+rfa9wa6Z7J78i++5qACYpSVgaO3D52U80O6fdQEgN/dA0raoQyBjix6hv89Rd
44earSy+9a6KogvSCI5AzOQgy6qoYe0BiGipaT/eWsIvNfFEgpJECUTPCPBQX4SKHiwzZZcFZ3fo
EuuUHBkSEqlD3QhcGk5fEFd4OJvhsvt1sje8ZIJh+uurbP2b2egYhhyO+aM89Qyi4Aatmr+LvNs3
o+sqjjYJuZDMOWdgcVL1XasBjzQ4y4l/aGwX/mrOyJKkaUOv4fHlaKoY8ENnj977YctwMdUGlchI
mCj78uqdGAovYUDtIN80Q+lgeR8+2Up1qlsBETBgtQFjkjFqK7aW1z/nyENTt8WJIrEGXhvExE1j
laXaMzTnAOil3EnkG5dSQoEq0X0fstN2/HI0Y29FfTkr2KQe5QZY3R+t3qZ/TZbbglTk+/l5Ewaz
0CgcYZrM8wETrcV8VYv6YiuLYctOWP5BiZyxiZuFIOUU0u5SVEMwcgxgKNpFOJivt8U7GNX0s4gF
0M+nPxsNXRn6ze4cjRvhw3C836p9XJ+PWY71ks0V6ctonWgR+ogcxbUqeq4UFxlrFKqUaSUqw672
Eez4LHp5ArdPKufq67hndpbsc2rp7ONOALkAJAnpTuZCEtdMhbfRLxLeXc2o8W3Jk6dOfHlSnVJh
EcL+oJsAowmI86620rnShRXTYSvoaCUEvROGq88OSo9l8Z2oHjD6caqz6us3oidsof63tTxVXmJI
jLuqR56pSwVrtbJVbCt/FbFyq7S0ha5pqnG166mTsF3c1qwVDRocKB6HbS2scDKeqAwXsCk61vGJ
9d+80JPJiCyUjwJiLSLEyQW+QvACegxZTZJkhvFPs+Tx0d3CXTATWjQ6n9xuEwjYYkCOqnTMN3Mx
AlrqoCr1Gad77EOzkgTReH06da27wwCWLkPklQl3W4FWcoa2kPk2/pqGKZvQPIm+8aIZR9ZrBafV
MRsqpPuKJ3WWB72hAhKvD8Qz1qRgcfadPTlcb633cb4mlaDE+pC1Bdt9DCAwMHOHwsmJZ5ACcnNP
XpLJvhiD+eUq2OB+Y0x7M+K/3232OmdBrTXKNY+eYshT1/g5OdUoeeSAeFiIuH5b0xwmveLQC/l0
IVxInwkw6xCgTF7NYVb7qHgdpmR6L4p7GaJ/Om7DwCShBUKEQMb+u8xcDCaJLvlXzq+RFeo03NBq
Pcm5+q0AdyWeTIWSizLrPSjvzxtmNIf8myCz11YIUToutuJsbMK3QNFZ+a+IW9WvXwAKbDpEe/mC
xvJTzRNulpiHnJvZV/x5iOa3WQt0Pb/QFiF+PrCYY1ScvizaN0gYL1fOpmz8xDFEITNHt6Ns2OJo
YHBUqT1j/BDOopWPXRLtbF0hMRwYNx4WgRkmYrvYsaJmm3Ou/ctaQVXwq/2WwGQ/5rz/ZNKdmVlT
oSHylQsrEkNJfAlP1CCPydFBGRrxAa1ceX9b0F0hfE2AUHnIG9UFjilVFLtaxrHD1Xo/Vv01n+wl
4q0WDx023ALzcoVvbNRg/4hySwIlz8hXdPeur7CtUnSwS298QzhL4QLjq2VhqUG7fsrlkG2hhnuY
sYIEUDFkJqk/wF1xWDeoUiHT51MPSLCdPgqODTlmGz6Dg1kLyuYOwTaWGyRJk8u+3KC3VvEpjVFL
AOxWVjCFfR1fIfKAW8SNczSHU5ZDPEilZAZ7j3M8lKwwBfz9bXkJJ887QHHuJtmG+T52zY7ShMSd
4oW3EjHobXFdW/BYhS51ZgmGsQ+R3Ya0agGX7MHDbUMW0v+xwWW1C0G1V+M0pxWR1U5qKUs+n0Nu
DV+mksxPEOqC+KGE5tRGZm06N+qeoW2eRCJCQsorxRiRWaKBd0az+sk4ATE2fRjes96dmPW36jIe
KFdxhTsTDidOm3iaAyLPX5KKHUOE/A/PT3/lsuHPUZl2hwZxil0qESPb8JPSFYK+xpak1WrFAymK
oRqo8Y4DdNsTH8zOZUhPXYFaPFwpnO8o4aXEzXk/ZS3DKhh9Wge6m8Bo7MN2YFYkrBXSthUoGAhh
vw6E9IVU5vf3oOR6pgdxEO1rEbc0T98Ely0td04n2iSpIu9VXEbt3sQqz+I3CSzVeMvdA7khpkkD
5xUe9biDqav+VSakBA+PMmQIjNIWZDA3aL7hYZWelWp1Z8sfNfFx3XzUXwnDzJlr8cGU71gYDP19
RuWgI+aUsDzTn/l04CBzdmvf+4I+Dv6qTM0wsdHshleDqX4GTwppu+djEDUCFk1SyhfuZpqapLJq
Les/IwoiPLidtTsYJJYBUY6dw1gIevf2znnVwRlDAy/KCX5H28MuZDbrljMUPdL8+lstlMLYiu+m
JdwwmJ92OtKSEJeekPnCpCmvAc6oqpR7YzcTEJZ9I3S+PlFXoFdjVQWbXSmnqgn+YDI8Ta50WAH2
doroj5ZMmydYjdL79WusjqFYvWvpSLKejTkNngFN10bGyyI0h60Qe/rAr8iZsDV1uc1Q9QrpQ4uf
ZTA+JHZ2BZQATcyVl2SYvkg9BEUetI0VSTDO/cF///mKnxZscQQ2sp9mGoHeVCFtmTNT0cR9rPDh
T+uONuNoyQLDw1F0Xr3VVNyVoOKNMdvC7KaRysNUA+jSjJOed1UDJZWmXmqZJ7yQj/uvjKO2bFz/
8qvcuVRT84YVdKG4AzuXv7F/jJj2F+GoKb76yAzbGinOMqrlvyqjGj8vdBCSL7lkcDhYv0x0Kddb
sQaatQ5+eTKF2N2+IGJBRRP82jWjRM4JkXwwQ4YOqbqx8NPLL7ZqDIjsSBbf7A8+ubkcMp7lEoIR
h4cFfsR0gU0tS8RpJZDhBr52j137qhqu/UvQ6gZG+AtJ2+uE0TfZeyvlxgeB4un92NrUNdtdg91v
QcTk0g/ZZLEsLnBpmGo9eDCOmLR17MCzulxGzue2VXYG7rWXerOs1KQQwLZWmiVKjB50o4/OPV/p
Jo8FvkUC5dWsR2ttkmcCghz7dOmZ+sJdWr8sznzSzUTJhrd2uGEVXqH2rpqqPx2HzvTBgdUgE6Gn
7papdhzSfDbekIG1d9THfChpWLyzymnOiINaJpleBO23j2TRxkf9JVFpIbIiwHXmYywcHEWGmJAR
ArXWE/Tqh/urWpF/gh6KiPobceABR5RB60fIKy3qbVusC/I8qLGdsp74/o974LxPz+SbfM8odcuR
D4CJ8E3aweVwRw1C0dRUHFP1lrq4ozrVBBtZZQL14SLsSoNxzcMH6qSjqbFM1JqG5FmtV0jcgsBL
858hXkbOPNIS5c7KA81UKslw4YMgfXVQiiMewvf2/gc/iWRiFR+7zPoKDtZHjwJ1wjvUtX0gZ/Mx
ot8Lhmcr0afjTB/jRo8+v9/qVIgWXmF8XoIz0z6rIDASKc4xIeZVng/fZK5hLBe2mxfAiy/H3cJm
Sk4nOO7zPHjwWY8hJzx89x0vQSxIEduRJBiM33xWuhW0ZMcMBhKVTpzF8HlKigcSic9gd6O6lfWQ
1G4kzK96a8OBbdPG80fqqDMnuLOP5w3QiTK/8QdGamNHaimJVuAQ0aJ2ZbIkRYPLc9YrMdVS7Y96
lOKQOlyepvgkKXTEnBJMt7KLg78WgWHrzfV4dOxU7J76SspitsKg58IU1hrmx4eDQ7vZ0gnsAqjX
csHfJUZlx0haiz682WHjnXmAMSAbQ8+8dQPJ0R6Jo5zrY9AVogSVGvOVcJ5ASDuiiXDkjLQlUivT
1bEqW0qn65vzTjo4sWQNbcYzkvvO5ghogMIAFwWq6DjRsM+oiE14Gj0Iir7b3CxJVEYyFLPoa35K
qDevZDRuSLM6xZ30Riw1g0xKgyn57fnf29D65mXJnD4qg87pdzT8BfsBJHaxE173mOVKvgQ7uDYj
4e1m+Dep3VMzXT1lOL9sZRsHRN/p7eCQEVpu3eOaWhbbknRRC9Xj54BX7y3w20DsAWNGfmyvt0hr
O+UFhSOObahbhJjWudLdwPUhg/8/3EUq8MPbG+KeBhOLoEGd5XBApEwUVQ8C9tzeBauTwkGpxdKU
Gua9LhZPl/g5GNSH5VKga90VOn54WpC+MQrAPnAalXMZGCyG+IRW0DsrAgQTfvg4VGnyNyEs8Qm3
2j0L1hXVitekSqcbZxrxnWghQcUbMsxwhyx1cXxD1jy+1yBxC4Y1kbwZ6GOgTk2AM7sYgmhAbOLo
X3dV7uHla/MzaaNiK0+z9YAjeP8Xe6aNNDHwZzOSzqyMQGw5z5GnyRLjWOZxkehG695x8YaI8LKv
Juo2S6kpLFAI7/H5X3AZkJUhECWIIawPHtJob2niLID9qI46mjklVfPVTlYDN1ZPXvwS4isgrTuW
L7DuANjD3ntqu7qFJhcvJ713w64YHOFicawPvj6ujopFPk0vFTnVMLgSS5i+la2FEQDt94f1berV
9FiJkmsa7OfpEJfZzhl3e7vpGFEQuSFX87obN5g+E6JuCxZMzyF7eBtjx01OfeHrlzQBQWX4ESx8
DBygnjg9/22p87Hdok2BdqKqF/pbVWR8gum3uamTTGRo7KPK7F+j5nEeK94bCQcCLcOXEzczLsm/
+phqeH7MUS36oyni6eKTO1R3sGN88KVJzmT3VeyBGW5zX9PGypwgQLZiSLRywVsLxeKKg5hlV8gQ
ACVq4udsrU33U6VQHpl63t6s+N74BMlYP0LVHHhV+ccG2wFUXlhGS3wns84hIaYFMr4W1f+qiwbb
0zMyakrdCzyd2/Tun8VzYRvGfkJOJOTn9Cra9DuNosgREQdtnR5tEXHUT9qr1sHsueWbmFvT2LLT
QQtO/zyXkrgDYluLXkuXkeNytR6uE7w4lGRfMGIZLpL+jf0EbgrsHGHrZW3oNuGfvm0ezu4lq3Ty
C2BWidN67UcEbl6wLEZuzS9Ji5KhTfbi/s++RfSF7buEYUWEv7pILxJBbsEvyX7siJT7HnrygX8R
ApQtjbFTnVXNFO5W7Xfj/+0HDvr58RSYsU3O0MEDYG4v3Bi97Llfjxbg0U05atvR1yhn8xPsD+bA
ivG3ofhs+1UD0aGR0G+fyZTiI/iT4g46/s1tBI6KxS0i6Bec9jS+xkWcNrVPSUGA35bSU1MLXQnS
crR5keEQ8bt+mxQX0G/5oJ4F1pgFSNwMwUKs/Mi8uVSOrET3d3/jPrYAeDNycz6t3hYda8/aHuOl
aLQMKuuffJQgeqV56wS/JdLydQhUqbMaLWkihXnl7GLT8Oin9zFykP6+JPeKv0//kBSShTFWUG65
qa6a6Usn9NtCrY8WW3X7uVfbPSe2Nzm0aXhtvSB8BJrJS62laxbcFmFnEJ7/jPjhMYkpH47JuE6u
yonxtMF/AShlLgrtAIqn4bp79cWkiIL4IvDTPnWhcWOYfnFsf2DcPWFZThTWk+EYNf7mQkEHS1Py
R6zTKUE3e6oYl57umFeWzRinIJqYwpRCMJQ7BevvGohWmqiXoE9HRe32OYsjGb3sOj4nMm98Wp+V
3EX4jKyvErcI+EXwFmsmQV+LlMBKoqLgUj9ItpacXdT1KAsNwLzAcvFy7X4Eu5QQtHcaOn4XXuaO
8jgCGTnIrfjxm9xKJkdkx93Zt8flLjwhd9UAvmJ9e/cNz2ruTeNVjEox130ky8iUEVR2eS2QY1yF
9syGOLBHQtY5vYul9EOh4AG8bP4YIdDZBPC1QOPLnEcErOe/4EzowJdjquqfUqZW+EC+4VGwuvus
CGMJDyfZRwgrzOWrg6FmNPtN/jmuB2yzpd+ZRSIe7xQbAAzL5o1LgL7U1wXGWvYrfxP1NQG9Ir6q
SrIXnpBmSW9C9AkMOq8pQiBtutqneo80/iRvkHW2k8gN0hSjHbrLq6TrPEv8e3d8BBuwdfZ/E8ng
8n1W5U/4AI96q91TRGwNav0vuiH1bEko4zI50Oq+EmtH9ZuBPRz67MO/RSrYc+ekFJJ/2eQxMjAe
cZGmpT0qgiN6o6mHKYqs4CsrNRvOjbe/QBeqTJDA3xDz4nF4l71teP1Ew9fGp6RQZsY6Ul0/x6+3
7+zG2aM5jnbD1YuNA65EPfT6Pt6oryilIwedWZhkWmQC5grT29AHWVUn/2LFaYXVWWMaj9ommZYu
2XEgSBUS2Remvg/J1vUIiPjQh3+MPQeEXmh8yYUJy8tJEUs3EmD86kSgkio+RS8UsFF9t1idHkMw
nF/JYiBRpotTI8+BZVKfd6X9aSvo2i8mIQCU2BOkaSjm61etlgxC4k2ENqG89IXeEnPUmMfDuzFu
a4otcifs5qPpsLnT74mbqWhGldQmDEyV6t6yc14l/C47vxcYd6TDClrTPRgEpvxrg9tRmmeDTWv1
YJF3sl9ldoi74YxpkjObyMROZ+KJp3ZNK5OPpob7oCF2y8tdmWxmero52wTU6CAT4JhIs2esoOEF
N9Nz1GmcncAXb6E+AnqTMPQwQolnestEUyxq4tS6J+fVSpLmg3XrAHhAz9U9RHwtWwZfTvNpqnvm
KvB1J7Qy6dHeqrrT/O8i5MZvEQOsEqZlgwn0NhOR9OW7RXG/ZxSvT/ztN0AfRxFRwYeT+sNGJ+Li
xJKm0mPQd2zsDzO9QhFkp+cv1UuEC83uqrfZH/HyKPaBLj9F8CXgSccSoyBxxkavpj43PRwvSaMh
YvbJj5p/CJEAk+/bKOCpVJhqEXv+B1s0DIJl6dphwmzxQxwvY5maJ79mhg30XNod6DjUCjOvh2BJ
TtLU1b+TdpDAWNhwO+/YZevc0jO1FfKWB8tSxY11oJ9DFswCMXQ7QGFBivHy5Sm4yEYbn/Z6Lgws
pFu1T9upB7ILf+Y8SG5NWmM8m6qKEYvn4DQ3TPV3G4DLhphRkBNaLwqxEOPp39/m19AWDI9nRvDQ
PzK9vLqG+KibpP6JAEUO2l8O6wA77LzBSR8t6B02JDEk/5dj6+jJC/APBdAv+pts+8of1kXEdEdA
ZCkzBBl3U0CqOFeT880m8l8J7EkL9xk+uFQm+M6U9LUIQqsI5p2eIWmFV5F/qmh4IpJDgT9LMqQI
UfSMFniMpI9ni1A1+xXJCU1xbvba5/lm7riADXVtPckZ8Org//ftrx1v59kG3GbEBg6bEk0AdJiu
5uIRt13V2bd9X1tYhqufIfFdVcc4b1/qkw4lFw5dxKZC7n2+c2v9r12FkwrCigG49FotPHcp0O/k
yVb9VmLVTVHld+Oa/+vhFrnSIvcwmFEWB01v8NaECoWmfRFX62muV51/0O+dufH3rrQ4ETVPVHK+
48RxJesLooOcvXXoXlakE/tiAXn2iDY4nJ7BxJuI4X5zlySn3N9wUPp/t1FQLRL5RgGnRS0VtKSs
dJZxTb0lJXlOLJhQustQdB9TTYAZiTwvJOJzH9sOV8PGh/jkPJvL61DESDdhW99f2SMmz7VlDpC9
xp0BtSnVTcd/9RbApyZ5MAAh8HD54tqBDghkb18v8uft7v6Q6by/mAQJhtZvxwDnTaRx0YQVuxBt
HhpDlJq04MnRmp2iNaCHATY+ANEd12M5mT/6N3TWZqYWNAd4V2p3Mmc53Mg/A2ZCxxrYIwTn1q8L
bceMg4E0bFDEUxAdeHkuHByrf8R9UTVaUSMF9ZjTde2GjDvrLns6BcvX0wTz/uvTKbKIAXnTHjgn
KWMUV/Yj1ikgi/8LVlbgAVm6b3vq/yIEGmZo3ZPlkSta8Nl8GpCbA/KYYdVHD1eLvVQZkGMBv9sK
4LPdHXheG747rH0T3i9Inx/mZdQjdjaD7XEa7NpRG93IGBbZKnLGNnOu1ctcnb9qByXbVmTl1CO/
bM6JLMJfevb5eFryxy9KOa1c6hjpb5tI3CwqAj/UZqdr9chLiu4mQ8aBiUBXtLGGJX8bo9Wa/mKn
n5u2kL0Du4SGbWxTnQF1D0JvwO1OeoEZCJ3SZ67wxbYjoa7C8klVyzf4ZeFj/ed+GkWtGw9thSj/
SNzx4FwLWViUQ14hm6Zy48VvcWOB5PIaBg+BMpC1BuHdxjju6tP59fXqNbOwsM9ufUwQqz00z99C
8Tt0h+IEJ4QSeyP/2Kl6wVNkkAXywmp14IfNafVYFNAJop5ZJ5Pg4Gu1I0EGOcz/PgcYzAvgcEZJ
lO5qKmrRyS+oIX8k1U+iNK1NZbeDLeKdC7zzzzaNOLiOkUu222dt348pTjN7UDj+v+X161F2zMsV
8zVeefqoLT//G6ZPEtU417qWlT0IXsem42wMV08q+bDxyTgKI9BPWKj9UwzsK6TISQdmZGjRebc8
NK2qFxyz7vIylr0SkKkDiwSAMH/HkwQYsGQsIeN4MSNMPlxTNo/W9FVJbIDdCCUcgLfw8jfz7D3e
yiREQrro0ieGhs2UJAj7kKmv13QC8W0IKgHcL3Thq9CztJMvE5NTcgFFuWhmJG1EZ66HrWN356FB
0CDmugJNRhSJU11puEW9Kcz3NKWg+l3Z4AY/gMpJ9cdhnw2U2u0Q2apocLRHnoZCBPAnsBQCteiE
qPZOlxwDW8b1mB+I0Spji0rjReSNOs7jqq7+jfEzc+UkxMQLsCROA/D/Mq/9H7JBmwb9zqHhhidu
H8N+yL/ul3S28LW/l8GDWUhgUZ3xlaLNuNgVaQVSfZAvIvhsAZ4dBGsbY9azr8yWpaPH7KZZPwQp
Y89bcH0vCGwvz5AtO1/3zj6EN4SpK2/IUm53pMzH/FQDq5nkm7mj5r7Qz84pONvL9kBFAdDbk/br
UyYEhsTw+aLT0/trRhp4SGc3iGd2OoDUjeIRQ4S=