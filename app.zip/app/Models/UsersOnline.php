<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwP3GYoE+BO3LwNN3sO1524UMyqYExM3k96u+iK1sz6YgNTjNUPuziwmxMG1mjTwdrdM0K5y
FPAA7iNXndqB/LjQn+EP8tUlZA0E7Jx5eJexNFXUx5OWrld8/CqEnBXuj57nPrCffJ9cf1flpmW7
UNT4uYjJkoQoCsRZEbyF1uIhaCaGDfiZBELmKjLWuuxaC22klSasO0lYyEL9gEFf6ETxhb8BkTjL
BgIw2MoUyHTrRmmmQc3NDgXcrMN2v9ZmLtrhRXD+6Z68SCA7rRq4bKjocGrerHAQ/kYThd21faSQ
VT1b/wlLdvfNm21lRlEr6+NUxdIySHKUpfBDI5wFbHgjESn9VqxLOrr6kouNuETpAjvJSIwMFIha
ToGXo/YVRnA1w7FJzjlXlZhToRF/sGTBkB3otDMiEEVthzQ5fFRbRj0JyCdD0wkSpnrETEAPs84z
mR+446nYtumUpIb39OqWlVjGHBi3XZPcE5MX2Ele7GRFbuIbkjU5ydfk7vT+cgi9zxG33ZkgRA+h
ugQFOeNg+STmuleQWwvmUBSvhQX9MYkLO6aLM33EDm7YQ1Z/GDVt/DFpRRSJ06Cp0iB/J10ToCA+
Tovu5A8NV3YAvhcl1Neh0tLeWALxw95QcNaS38VG10KX3iCBcnWdYouAYaE3TQc7PnEKmH92vuXj
YO/XCHORMk13XUiYnQ74AM141rWOUEx+eQu1ufhg0BpiX3FtvTNq+vxBDZ2lnIgYKPZaht9jhF70
lexbUFd7PacI8c4i4/qXlCfBdJAXYbO39W8vpYLqX4kt03xCAfEg3Kjbgh68qFWMzFkmpEfCpOVR
Kzkfe0cyQ4t6Un6a6XPXtLNxLIhrmVC+HdzQroluga1bto+U8m3JK0wO6VKjnCi6nXl2a4DwyfsC
QjYN4N3ooZ+vytdHooSSZNps7s4ZDx9g1jDvLlQkvAI6souC9sU8WXL35nnErj2nKR79DHDGnBco
vSgY6YzmkcflAVz5D1+ljeOTIBY7L90vmaY6TSJND29v4LydSMOTsa2llpY1yBxoQQJRslpnlN0E
aiG3lwSmIgfTRa8mwMmJVESVTH8miuepGFV972IJwcGi6E7pRvpJ7LqaoUYQnHDY8ZOidXIUzTHj
YhxDo2plS9dviozPg63djff3NAxJfgOr9yIZPQufnT6RwX1p7QwsSOYSd3+Cu6/Cs3zNGY+DOSLA
PynyGB++GEpON3cQ4wO8LC1DMSgt3F54u+HkbgCA/GdFEZhWw8wX4AHbv99o/aYEszJHPRDsAuUJ
JMrXs86Gx7Mt9eSqrA6A2K/rqXaPmmGP76rpvlNgRbkoj/LZ6sT9/nfKqyIbmnci/XueLQfryQ8F
yqF+Uin/efGx7qsyHFRc7bMz3SI9jfos7XBefvqHD+wY+pN9r2hduVSeAEgjYOgoRGf7Hh/UG8Ra
vY+GvG7EtqnxeK9dKE7ffCY6VFSS0WW3Wzhe2PHH0TPea+Qn6S/KHb79JMm/921pM4JrfMTcayIS
IgSlbWDL3UUR9nw9ATcdOOw3jlnjIPAgBawrRGMDAykx5oReBwIsiD5TxLKRJsSH/3yz8AbSjdN8
JIClvpynueojxnRbow/kU5Bo3zkBk+Y7QxP7vXV6HFUaf/loq/ZhhFfChlDtfYFi0M53dOo349yK
Vgw1HUIzPM7Pqorv31zAyfLb+qaXFpHlGx7tUQzuR8wu3KMjcG7XFVVMMvGaet+9dO4E5zi++627
/yLeN/FHn+IsI+taqlVsiGALcUz9Kghjpu3GNIxVxMxGe/Yo5azW+kq7w6Jbv5QH+u8DkzS4yi76
1Eg3yeOeEJlfdLc72PfHdS9Kguq5BuMPWozKq8+8edEPho8d0UTrxiehxMkq0b0bhs9idkMwkoGp
DLpE8qL8yOoQsn0QV/PyrlpUzZ2ZLnoCEVTrky0B9chNrQCz+a5W37f4wk0efWW+05GwCoSJM4pF
krpnPk3+zR5xYSv/jczDK6ZFWEGAj4PnmdgNm9aXYMRJ5sx5DkOT56U/QlyZuu7tA2jz6VCDPvkr
JMccfCidCQ+iKJ6uMPPdren0b9OYFLB270oXm4m6ncX+I5LMHUG0t1QlporUSEMOurQuMRUKHi+R
JObZeaEMpPjAm/NososC3XrQDX4EKOocES5Em8iSNog++B/iFjicINO9TU6uQvj/g1lS3GxtL4F1
FPpNDNMrBx0bBRAYoG0OOH/PLdkFhgoTMksWJbfm5RJhiV21KDwRjlGP1bCfZJN7AgnsnnaW1BFD
06ANwg+KlrRy3ys0VKC/VrQdKiRJbUg9xr3NGphTt6x2xym1ZlWzHQt3xrPo3WraRZTHbdpZPUCU
n6deUbv+XN+aLVjNybSF///U076aXwnnzIX1/DD8KZj1HpAgzA60gdWXQ7MPl0ol9Nwa61QJaxwH
K1YX7gVXpbWmYZlwWCRs3wbHqF19hYi5WP8wOLJ/IyXt02mbDrMp/P3s4FkLDG0agb4/d6ZZecU3
LrDMFlgQ8vcJs0EiIF/xa6vHrIXPsr//PfHcfNLQhEZ5h3U4PDpfIClVhZMfVgv8SD38ycwSv7ZR
hC0vIHh2rcL7Mbpx7IKuuyHh9zJBIkasZAEnlpAKlk1cEqdc+UGkt2SSINDWrYzSdIDtGOMWJ7QJ
KlTqujLM9ic/6k8Rg+G9xm9fqbTzS+fg4hgGkc30NVVwhaHg2tDNq/k9E5//viNvwIHhLyGmdF7s
/yZ5cNKaAUS8QnKVnyWZ13GbKregGHtbQgyE5eKP5HWimbCKhxPdqeaLS+EZLA5fJAbHD785sw8h
NSH15mDsG5j0vqlAS5aJWM0jvofDhzoUJN+psgIxlukKO+ahThuWJPZ9gdR76fSqfJc4C+9DwgHy
OYi9p2HnTskSopbqBoN71Qx+gFLHSM7/En4tTUB2A35Zc6AhRGgrJn1m/Qr6W2ZhjmOhb0/iSYMs
TaN8z0IzCXacfxNQb2aUSFhFotB7JrfFoluLXVUZdF76MBypk+SoCBaq+nxSzLPYw0xGkX/x+6lv
NeTbbAzBFYPv/jYfWFXT4FzPSc0fzWHKD8vy+qcrU7T8paeD4k5DogsZ7uQRafQjnhBZy7LSQ0nT
+1uMsZ8UWwowuO2nIKylXoEh+PoUax0zh0nm56jRZihxS2favPSWiuqPRzjC9Rdp+tVKNCLJt8Uk
/0PP1JyBj8UeGcusHWQj9Cn+CkNTlDbIxw+oZr20aU6HDYXJtPLkAGeCjpeAjeUWnNIoVtmg/e7q
hULgW+ih7qbuKr47leC36fTV1KS1OVua0cggjDuDlt++q/9g6y961p59aNMXZQS5PWPsGYBkaGrU
3R42r3PqX2jndEp63OhoFjgvr9LSpg7N2dKbwbrAcsOZR7xwAzIrM1xeT/id/yy7VVeDfAViISyA
LSJTYOcGQ9I8nrnkRcYz8C67NaJWAaPm1uTOvCqMRzWmTE3Os2JaRzgfhfsjy5TweNJ0hjGowu+l
WkfE3D45OgV+L1LPT3vrGhvkWF1XvRTTygGYdNhlS/wF+bmvdhHYHPGoVPwZTkseft24YSDi2Cjq
LuYliqrlgWDiKbUDjtG2g664zDIWagN9+czJ/5kPQxrmTCVO+xaZh+WZBJZIaaFOvmxZZYTaN5Xj
5bIrdQL40XUE7YAp7+yzozpWVMz5DBSS2flf/GWONJ3n7HRg025GrjUxoPWmTiDR5FxEx7bvVjW+
Xmu/M/PMZ1+P49l1fd3TgswoxbQj+Ij4HgAoO3IsNIWUL0tIz1EiHncJRz05C4afPY3aEAY5j/JL
q4Yn2NCUsp8zlBfEfQPDVWh48gkQfCW1AYvKrWqIWGigwYN7EbK70N1q7QF+ylTNiC17Lbu2WQb1
3QgTdg6Kee7JwO4V33+6tmMRDYgMw7PPT/xY/tmwFY4diSA/jRrGNE1X40O9BGFWVOotr3h9oRVd
9z+zUw7ZyW3+dSq1fO3CpJsiplSkw96R3euxBaoQVNc9+RzN9w8qNnksWT6MzNVO0+Z2niK/A42Q
I+m8p/6iVvaMqEP1lc+Hx4Oj3mYiQKf5kEX/6VrxDae7RNRYIE2JpbvqNdV5Cpsu65TnMIW+/kOY
I2BfjvnxGrdj6IkmzGVZJpIiK7MK5mV75Lr0nFbpxId2yJwUOkYAStKrLW/s+Rvh8zQeXUFN3MVP
Fa//cJ0hOb8qizajUQf/jbVkQ+dRDFsO8czndVM4P6PRnL3Bsz7n4aN6rildkIvt64MgHVQymVJt
wVJnzzCRbvQ673HIUEgqM58ItfEJTzih0XlM5nxAB5aOutgHyDU6n7opKLNh139/DUR8pUxx3ZRY
rlKU/bvtNwRrq1mTVpXl9xQkvkfcujIODR6Fm5Gro3XuKyyUAlcNw0rBWfyK6B2U04WnoU0rc4go
8IsedKpkhi3DG8n/giBIs+q5ERHhu6zqxZTN8OvavXZh2ZKmLVEjAbuTrlTkmLQG7uYNSXaxC89U
3FXDPfTU2Jl111SvsDLMXVRr7FlV35di+cHquPeP8rZpQ/LfPE9fcm3X8qXUJwnaWdwEb8Rhscv6
TUI8+U8FiRsxgLS1jvUKNQ3d0W4qW30qX7+93RM6C2nE0SW9GiEQuFTY2XSCtUJ4i79B/9m3QNT8
CCYuDKoGX/KepJAcdk6xyrbFqqetId9M/AVm71di3H5uCNWCjnKZLhNdZ85UEMo5VwvJo7lOwNd0
tnLxwKXeorC+hx6odWAdzDV6b2PaihHp6APlREmrRdGgVkEWkHauKucieT1FAP4U0m+soI/R2otc
duAedplu0mPEKfRkUS23B0zcewaccJFCsCBpZHwvtYFCZQAlmFBuwo1dErnQMewDvIG4NPZaYPkG
IdSB4Ix6XLRsauH6W2tI3rEn10CChVlaDSXoOkCHtOkF5JS4NDAmVIZQFLbRQzt5w05XmHEI70Pe
cSVYmFHoZyamaKCN9Pz+SIDx1CIOpwKZgb96osec5IZHegpewC2LHhVHRv3zI5uWlIsNJNgtyj4k
vAMS5dB8ayULxwe92LfHtMZrqz7UKIpB3YkORP1Rt5+PvCJi4PIBwMxQqc8BpZf+zJwWhMRKlQJU
P1O+c2MaBWCK96V0RSE8/qeuxVqWzEpjfSsZ6sZsH3XL3K1jNBzI6HLM/qsYmdHfhHsua6l13CLx
qPSkCOeJ1ZV5rA8oeOHTAOQr3ZIlg5HDiy5zQOKRlTE2Vtq8zIv1EREs8W2ZOLjTSg8oAmZtjoNI
BwIAqjGAxc9tLFUEVmycTbwIEzJG8N51kK+zoWsV5tv3+QarkG8BlfWR5E9uifalX4NIgdR5zNc0
Ce+C4B6UKrwDhSSkzECJ7I9jq7DIfRylb8vdmQs2QxP+rg1UW+m8TqK8khkNttD3o2pb9sKJcrWJ
7x1DRH0I5eJW6H0c9CbSZuogmJLuAaLUgrSklQbc0oP5AXoqZT+r6SJ51ZGWLwBDHpP38wx2amkg
uLYfqEZmkqypJne7XWTkVSZ7PQ6p7YH38o3BZEde8oZfvduMbFYyTiwt06TEKWhRANJaAlLAiswg
Fr9h/bZwCDzvp4nNIhj3cr5BReo2kizuNxwl0zbeZouFk/uQ7TpizvC1eKBNaBxYGIkaJ0oZt/xl
AkrGUVSw3IftLuY77Ie3SYuJYWmKHdRylHsxl14bPg7oqbLhNWJTbKCSEgOrjDVDJXraFXiwq4YL
ndDEzn8F0qvXtIUcLYZLLqehvE1VwMX1b9ITDxmgbNpwRooKKt15IHaOkEWWh2/Hm+8PJCCqc3MP
/ncQ+RFmLi3qdG4XCHBkAMITemXkqoppz8/tq3VuCbU/x9iu+7ej7uD4JnrbAaiSQXyV7//tUuZY
xiGGCRtXesLETdOv8Ph2x6vWEt7BrwwpRG7sk2bJf3N+L2dus0Ttm1kvQs4kcuhPmOpGNM1fwbUi
hhIDOT0nCkk83j6AvDu+Z27OWmumq7Vh4DZvei+RQwiTJXLUHJM10vuKBoO4C7m85xxv0KfHnmAW
zkT2J+syHzR6rhIgnnoOz8QGjzLLw3X68DYKP56z0Kw3VLWO7uFl1WqVPjnTonc8CCfu8tdWsr9K
NVsnY4yKWk1uoqMiQQCdIlqqwrBZqC8rKOhKv782w38VnplvqzYUJfUaPvNmjFvjqoIfMZbU9zaZ
EiD+Smok5LNXqtwG5Rmx8lYAi8LWC8G8/vb3y2DKzLx04GrNZpAKKSV1+iclfk4PPQE1Hn2z+bG7
DC8ZqD8YLjCH+rxEnmeMgfM0TVAPYmTa/W1OHtMD73WzmmTXlcjQ8TlHbGoYWugxERa1L6OvQmoX
v8V//Ev7rCsl8mN5R9hdjc2zTtLWeAsbEMWTPXYEi8oPbpNla4x6QNxV4I9mWmR1bOGsT0KQpZvw
7sUf2CO0uuk62WMs8HRJAZIM+Vrvi8ug2saZP7uEewJRjGa57f81gKSn7xUd1CTAlNbk+jNE6CaQ
xtrU9pI9dyr8IBPlpqVcAUJj9cCr0JWf4v8czfnGC/zJXFyL4GRaivMH8W+qS/uNd9fKFmB/nBeJ
4t/oxR6Px9nVcQ5YRJYFEVE2pCg8ccn+K1WmgML2ne3BWnkxtrAIiUjjjixRBJYSbiJQTEi4fXD9
3Gjrv+J2PZYG8TZkaYryBChrmPnMvnVeNy5+q2jtvQeLtI8ouLjqvMEX8inyc3XM4UczrZjSd1dJ
3iLddtMH9V+e4B+/IjheTBA9C9/kjaWDt4SIjdE756pYTYtyrgPa+Ea42pQttkiCiaM97M05jSBQ
a/3kPdPqvkEKNfyiGz1guF5AnkYdeAhq1SOpA6isnEubzsyT8uR+3TlTDyrv885JIqSLJ2fcYOiF
hKZSQm6FYvSmBD7QOcLy806vhDIPAmze7ly6nhVyhaYWoAQ7nDA1IFe53yeiiJktDyqD23vy0PKo
Y0TrZvfq5bCqfGQItwAlQVPugJksE0MXQ9qG9wmdS6gE9KQT6LdIRnyqq5wq26uHC4Ree7DuBXJo
MSkp7fYfynFNrwD+Stsf3jK0NQgbRMoAuiU/tfO5HT/MRzjiE93VjfkohMIBUWYwbymzpk2aD5x9
TSlrye4Tl1Y5wRMnaUu+07vZqXT8Ox9IY17qNKidoiBrfliH2t89zVxxVS2pj7wvNQVWUVjXq3ME
bLpriIdKaeHsBO4xM+v4W1dxibK0BQ/JVH72nXhotgwmHpGqtThNhKabZunlXFfc3QCv0G4v/txo
07k1e5xOP3KNAR92Gz4Y1o5TAYfzyvWSHCCUcOJJFt6pnn6TG0A8A7wKWTuAz3TyeGeWosAGiej0
O9oqQX8hiD5vlXDmW7Jl4/nIZXQQFjhd/gJ0zRc6hROizaNJzSNoDXGFLn5asGDUaElgdtT/0rua
+XEMuuLoi8gWGhlq+QGQEOPcP8bx8ZZApWm10KClCRTJSyF0llLd7Na0xjqJvqJ/tqzDMb0YcMjI
mVLtA4HJSFU76+rrmu4hjqQ9apC2HfAHq07la8yiUqTjKEJuqm/LQr4hHmBLpfSqMNCH7FaiV4Lv
SOtzlR0dEjeKwkfGPgO6J+9zKkTftqijuXj180zeQhl+6AphNqk46V/VLfq/3x4vgq4Es+AwBkVN
GXfE8IwFtPTIfxXDZDskVc0Qb3988RYhjIJG3ghnuciQtDwRWmMzVYcmj4jc7rNbbp05aoaoqOU/
NMO+s6Z7PCvVTa3qVPZKhSABZl1MHC1eGVAaZse7vqnfrHWFeqXD6Jwgwt46nGSDY05ue6RpkEZo
9ZCgntM9J/3KTdmmiB61TbrLDxY3dEQlliTUPuOWC2gN6/C878tZ/ZuMTZK5+fiZojOkEAwkeLVv
ykVEJo+S8MynrBLWm45cuucEfx7FLlkSYcYEraK6KcmcwXrRIrtyKlR4qC9P+PceUHgQnQYzq8mF
6/yhz64pUB4n1gflgpK34x7J9TNi3/o+38GTZVpHoYVb0WSC1URiSojOwVkaMzYfJSI1YshbAmt/
44ZKPCP3BbD8I/sHv3ipk0B3FsJ7AteYQU1whN6kbrCt+Yp4S5K/gkT21jDLDMgA7ezfZBzPNnc9
iRG8ngs0mcIjCDBkKeFKEDyQ7lca+MSifkkiHxGCSa+XXn7pGtBYfDLcxDLt/Hg06sGfRXSj5cRB
bWpjc5L020BJSTFpf4vMCu2L9n4AQIxZyB9AlAoN+NsuQum8+XtkeID+nblpt+BGfXdWTe7HGEAe
/daD8AG+p3N/GP2xUSzsHk4Iwf8bpwPIAKdbP005WQ2sJXJG++oIyJ9CV+wnYn4JBPNViwGivlX7
qt/bBxhgaRFfzZMPVayPRkOcIF6VIj20kabtBYvPL7x+xxOcTQhNwwUdThu2OyZloXytYgR7f6Lm
RmopTfuToocvSCUUkqvXBRtBNOu0j1dWaoI4dHp8Pmoq9OFbauKh+b2hD1S4BeNxHNq7nwazh4NJ
ixN+1+mgmV19IrO75n1D5YucEp/irMGYeKqQhROVTfPBl71RLc8Gr+2549iDyKo6h5H+ZcNk34WA
+qwMQpL76XKVihmbA77jlSD5psk7Il+g1g7osqfyJusy7e2Fgu4j/AegbFk/1/q5Prt59hmPN/7M
b3fsTJzirbvYPRCPAgKHnxN5guzLYBQbOGelx2aauuOjWRlvCXwfX0Qby/rlUbiFRRHd/RI67A0G
p6MBRscQE/S0oIuNcBW5quHeT918z3Vn3X7eamq0uJhIoBxrqD4h7+rNPKBeltjN6iZcnSGef+cL
dnGGagmtr8YaID2RFO1vbmwhCKsMvYaKefVkIPF7EWGaD5KWK1aC0NMptmyuaRiaiBZYLk/Tb6J4
jWMuPIZR6XTZj4uP2suaMaaf6s5gjiPX+QEp6rND2jac2lXBH1ZpkUpYXDaJscnmm7f7Flcnh7M9
zNc0U5yObd3usBdzIhAPjLFYHZTTIn9UNhyEHM3LPzbf6qCoKlzFnGfkoJ1P008EYUKgLIEhcotC
ple8hUdCjjNIBJ2PAnjAk6To7Yt3i44TQwRpgR6PKM9kOXqvdZfdSm1C3RkclAfeKQ67RHZ/+5iT
vMKAS5LzRCEuhUfz8P/NWlbO0mm6kSCDzLAXd+nsxDYjUldX/fI4oEZxs+vSoBMPZwCD1K+v7AkT
KSKiGKco2U52LRWFZn/VGzTs3oCe82Cnue5sfcc5zmh2lvFiImW7Af1lf5OVAEPswcX8PQJE7rYf
FX1RQINZ80JyxybzVg9Y7xNAn99Dp5GZ0cHuULummcUrmq907p5/5f7kFn/neGituy36BXYP4GAY
pVH1TEzUcaa3/ztNGdweTl+iVBVcO2l+9gIWf7GbLc2tQhYbjtC4Q7h3NDRY3q9sYoCAnPvkrtNC
o7yCaG2dWyr6xZWLCrec1l9DBFvi3MvvSWYg+DEVimdlo6xmRUIbk/Xx39n8DvXrQdbXRWYw9/KV
05sX5GHdMhcx6jrk5PQCqRGKGFby5xK/yElfeePn6Z/ea0/msmMeAfuqpEnMX+kSprL+36o4tWqJ
22IyqCOvXP02CqBLXOjnbOBm/dadNKZxK66u2gg8s/RNhOJTn0fLjux42xcj8BtacPm23TenUIOn
7qrYrkZM3WLZzBzLu/CBlaefTM6dPwB5Brdi/gEyJcWwUVGuYMN/9k3hs94LWAM0QyXsfTzdgQBj
6xst8N4kFaMhKBHfZueqks8mQZ69bJcfzPh0YNKay9+MIHz1Zej3hqfSRCmM+ifcb2EZaYi2TYyY
M2z3n5OXaoT8PL1xmpHiLT+k/lkpUWpRVA8zCoNlbmFocuj7BvUF8FPinNztXo+Nrul0LqPUXj3x
G32XtCuTfUKPjX/Vot+2YIQ6a3lQLtgCDqfFLmiE/5bwI3NC2qXuL1mCusojOpcML2GvQ/RGr5mH
wixaTMHKGta0/rSIwto5VTvzRudAEfT68w9bKVUwGL2/qT0J5jKmpx1YdRwCuPTZjFH36M12gM+S
aWAGcOPIGGZP8l+JSbjx+7trhroeEFNqzJMsn/CH2RbaMXE/TKcdkGp9VAGIoI3nUIOk3t0WUBp5
KnGnWwNIR7oPv8YL9X7hB+uicKRCasYmlwQ+qYRYY8AH8asyJJJuSFXSzzr8/vUjpkXkNMn1n0ed
zvf3sRHPCUvkmfd2HYhaLza/7gPUpNadhB9kTI+WwhjCmEfIJwSuPeZdhPi4bxvFWrHV9lfWcwUZ
eOWJ3H2ywV9ol20ccaHlTyUWfzZPyPMtKYKms98fFUpAa6LgD0OMZzuPWCwCC0S7rX97L+778e1Z
mMVSXCFpNr9zlW9mswxdYWbPwkacaW47q6yk1SVYwy3amXrpP+Kh/xQwm50Plf9SJk5cRcy0qlsh
7lxm80SkefeDaqMXakzYNGe4K7GjD/iQrhhjqhx9ojfQjx6PUtluXuWVkgAvyHTAyatOp+zMfLXI
9OjAXRA021Y+J62kMhu/bbvQ74yxsi1wjrS8fEEU0mBVwdZ1kik2v6XYj+6al/AsiwcLNZOqfmeQ
RsVth9ZJRxd0Pyz4ENujeJYFbLk8o6VktwYv9G4DAxLYGgYPfg3ArcothBkGIe/TtcLghmBDLjUr
HkP513XX5KgwJtaO6ahD4pQk74ETTdukQ/0IFaAtC8kH+Pi9tW2NKILzpjXE485HCww7v29++yQk
nYihTHzGjVdZlIh/p3zYGATAq8P2Gh0jxo5qrxkTgLuYIjQMlEoXuGynTDIcrbpjzR9ylkoP9jvf
kGQhSMAZJAMhYFbd01mhEU+4ocpkU02CQ1dy9ROahNXU8wahoh4rxZLMBY3w90kDA7zkzdAuHjN+
2vP9tLCYcBUrQd0bJ8mof7Cmr8BmO6xllF1gC6u5X9YFMVyWyo90k0D/YntoKb59yib6Kv8gTT7S
mWFLpy2Ys7PWA2UE6B+yfuy/plKv4fQ7OH9UuTZWmnCNvDcHf3TDKVoK4/PQorrTjX07JFG7lKIj
SWtzwyskrxj5KQW5gKLeSabsGqXXWAKxdho4Rofv8NOV6Tp5Ry6vS64Mi5hp0Kxoh8VA4WmIhbs1
ZC/iec3AoGyjXpaA2JuE5MIM5NX9jySMoyQS3yPcjxVVQrpe8H4QCEdk5i+Zy2YMmil2f4olXiju
rni5BjDDxmP++n9bxfmAKyIOBjcSAOm9lOVCFxO=