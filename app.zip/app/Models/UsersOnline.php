<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPySkhxKfsXEwDCWwbjsoWKL3HaGfg4QJf8wuNUouQu5AsHfpcwNAqGxi2e3eFc+UneAbo/LD
Q7GJmlhnGzgsNYg3rR8w9im83TNv9HpwIJzt5OSJ3gCXnF6wrRNl3NCoyt4OCESh9Kgt/hw1r0aq
TaOWZUKtOrcLEc63uXLDa9M1WEGRtQXhO4kYSzjMx7Lk+xbFJPJqOl96b9Pwk2DOkscQvzBeQHUC
lMuPQgJ0lkgDNrjN1UO32SK2uwj2Fgou/Fkyyh6F55dCubCN2OI5/+0cyZXifFy4Xau98HJLw4Lt
uN94/ylClwyV2F7cakWAmx3uQJk88+k+Obh7koSbeX48FaGYTI+8qkNCtNdXT17VZEoKVMhrHlMi
6FtmF+miTGz0N7thk+N2FIQD5SZNeR3YywcAg4dPOJc+POImP41RuYbPKmy4IFxoWZZnk4Fxi1ed
frcKf0oRwt/ZkIRAkoeaQsDp6Qt7nRXAi2ZS+/++rbBGssshtkiPw9kDrD/LatKgbn9dzYazR7In
bEX3DVAppsovYAJiHNWBOzAou4FavuID3qN6+Cqtru/0z9ewjVdqeceJmUfEf1JUr1yelt9V2ygz
KJErXv1L01mf+F8gqMDTC2MluF3Q1zzZ9lQfYRA7YYfDqD8txrFt3Tg75gK0xoIKiw1RymHj4WMV
rAJAkWeud0sj4qqHjFDRuCrT9rbp2Fo2ZtipJ0ZX9n1MsNYkcE5EiDe4nFOZRu1uzUDp8LYA21In
XH9L6cXlPL4Nb3Vz0ceX053q85iDKwD9iobprjQxdog2s7aYIwx1dlqXWyhhugh3yGwhkL52SFAU
zybRcFE+jurXeghiZhChFMISWcJ0TkorauGeHVWOAWtC8AcV9dGu1soTJQGCGl1VUjdlkpAIrlos
nLQ7RW6WNL3ZjQLsmhR6+BkNNqvCyubOMuCwg0HPLz3L3zg0/xQr/L6d03+HNXnX2Jf8deepS5f9
rMP9dX85EF+0MJbuHlV9v6nukyK/qQXbrwjHlVcqUb3Yc3PCwUMPZZf2B9cPJNYXWz7Opi+lgKe6
Vr7vc/4nmKaDOw02p0wRsGRllZXquMxFv+Z7WahBffQHAcuDNKJYCtPKQDUm0p43OKd6QqqhtjMv
Ijt8OqEdD/F2Ld3Z6lUmwL/5HRYZjSeApUJKy5QfLVk9EvXQnKsCdJxx4QAmvTBRuNVZ4yioV4jH
xVVP0+YJZTgtuGQUOv7e95sBhipzS63N1Gzk9ZhR7RXPmjnzhjf/eH62epIrwmodG+c4U1Mt+BSm
AZCzNn6KVDMYnyQf6h6NMxrir/1m15ITYJksBjTieQpWMJP5/rJ2oruGf9hyxTBw1SRe/I7uJoO8
SiKbGRysauIE1HzOE+PQ7DzQ7S4EemZ+d4vrlQz0c3qkSpIA8cUGrbPjDcl6C50uPtisd7MKhw/Q
Q7ChnlSKVNNaS6yB6BBLSuFj7NYWCER3lWqJ+W7uLJQO33PB9vYE50xXODJ9+hfVTF2WW+siREeU
Xv0BViXZTG0BminTJesc7JSxw6WgkLUOMjzxhX8PtypqBQrOQ6tB/EtL3zr1IoA+BOyOxhkztkwn
9M+uRREaZFBk0uBehsYEdUllbHxl7qnOoQnRwVtFko9Ve0PwthzTdIcgOCMumbIBYyA8108l9qsn
Pqr+1oHmjnwO32bxWYPWtNKNgljz3kChpOYIcZSz410T03G89S2u8b4UqKLCArurFmBnBxLvCHO1
SxGMz6d/UKgB2B0w5M6FKT0WuWmUV8xTxVSYzgu1BLYgQaXEFNzLL5z94DqM5Kwa3Q2YBCg2EZeL
IdmA1DeIT+WXqLqXdVpyH/uhEeMQPwANp1UziiKtAjcCMXrCkA7aFRM6ZCxFsv2Ueb9celY7LPrQ
TsQDZ6S5JhffGcFo7wZJfM9rEDE0l0YsZF5wAkOYPAOeX3E45hjsXhthPNFrG7D/16PNw3hOBYKc
Ko5IGePEdDlkMiLXe4JILJ/ctcOXkMHZCtoMRXVPAy0uenxSHiBl60EgR2MO2bFxzCEUsukBwP8J
d0dS9X0ncSJEvUOCqBKzM0ND0gX+ggvvEixg9RoAxwxcQTHQZG4ml4FiHNA6S2gHYi8dEqEkpH/1
CmIoaBNQKmoR18B2k1bSs1/LR1GKDSZL77bB4qD7uL8ZYnk7pfFTYf2fYSbucOhtG61BJ5mSvHU3
GLLM2Ws69yWJvqMQ4E883urQyPOpzk1MBUOzvqypeGFkh2+AmFiEy5q530T3TmxSvBK2HPnNWIiG
076pV6+2AO5rAu7IPqA7ROLA/WzEPu9dmiUhfPymRSLAdKlWBkwZdWkwM+LiGa65ufhNdDCnwpg5
v4pOd7d58o28zmsIO+iY7/urFHPU5V/rB9Y53D+MS0ZmyUMocUHnk2ysjvPmvp+2t3yL0sPtQ9eb
sVBm8qpbPpSi7nMDvqiedx9scEQDLBmo8zxfA+WxXWYaQpITBgMiVDxWz99NgOgEcdE4sRMSI9cx
E5C4i6hjLgXplCAwQBonRgu/7jnmQ0QsslnAXNg1r1NjmSzAcphyocQbz/1iUrudftX6W/X4evJT
esgr5Obhjeg2c/CEwlkQzaEYlb/O9FhhRyVA3D5oeVOxisMbABHdhaND6QzvVVzZ6zzSS81Zick4
bauXCAKu6NUrFwQM7T2J1rrtvblRnXavPYvjYliMbE0g7M/C243Si/RBsC3KwwEO15j5T4r9jsqH
JAeTzMZjJdSx69Fr+kR+N76Xa/NcCWOtgwVlYL/tLmiRHNuxm14WdCR4Z/I78v6LMdE0VRfInNhy
nsyUsRA8Yz7gFH3iEetUDHCQjneeofgu91dqt2QwRcZT1jlrbI1FEDUSBuYX4SN9al91MXDCJps8
K2NVT8pqARmBXDBTf41AvDG6bPw/5e/0M+VrRd1TAT39e7Z8zmnrZpv59mUo4YGQTAFjToOKeoCg
Mv24GxUPUy0kzvIkx6vJX7yc1pQCLf4bzOM6RK1SvxmYoh6qP1RTYrWQCuFm7m6GO1sfzNq3KhCc
6k11t2Ng1s+MN3EQtKOv29hJ1gKt4lseuoBololkb/oTJ3ByPlyO3mJEjLUqEZyTm1k2rb6Wlm76
/GY0BU22qEzm0vr7k6d/P/l2UQ3xotdM7X9c3AkSj+/hLb4YqkJAkdQfyeBH3Cvuzl+FktXPZASp
CzZ8W0K8uZFwuFMfiTEaklbFLG6F1iMc5ztYDBm+bY6sKbkzFdWuxHNqmSGruuo5fwq4AV+KV2GR
3a/MbHJW0OacHOMzXDgDt0ys5BDmbV/8NMu1kRSYlP9P2PLAcXyE5f+zFOwz/B/q0JEUChB01R+r
HagEmq/VZ4jik1fbTfZhcfCHa4blBgBElatGhZKcEgvbiO3/FfBN58Oa26vbqMxeowJI960ZtXn7
uLrMnJymo/jREnbUI4V1ajpmNtbCyuB61GU0EEPxv1BSkAiO4+/vw06EBHpw70O97JwZDipD+VDQ
yEF/TNydmKhdA55jc/OpmrfrCUMNuwfKZ6DYupbagEy06dyKXDxuMMGM+hbkaDHbtyfoiYGUBhO6
NzpBBd5VppIle2Ztbct2nrHbs58x2054Gjw6lJYWqWeWKCz7HbtMOASsi+FPE2Jnj9I2b3zkO90R
Es/2NbN+TVDLf/TGPjphET49YjkpLyMXJYGO5vGM4mpX+IjoHya71TKYo3PnNQuvDQ5Bo0Frj21X
qDTa+hYq5aGve/yr8zFwwrlrpqzObqj+GG2e9lSAC9im69o20CojYN2v249B3BwcH2I84nSZ8M0P
qg27ALKB/D4qYH2SP3cQIGvnc+B++63ojQJLXOMGJIq6V3gWzbVXkQNX7iNGdcThgu0RX07Qo2Nn
kRYmZidgjAIfnb23OYxbh3saPoKayWwesyBC7gY1PyDynDdmdWrpNDwqzWq0TOLN/jtahKOt8+fv
HY5QJNED6vNgIQ2ZtP+DhZ6l0cz1ImJdd87xba4TCx4pEqVAHtb0XZqO3jsNAiAuE9K4KQ51hJUG
opP5A4NUY7HMaWB/P76lkVsOjD36WW0icSqd0YAT56WUxwwQKq8PBD3SOws3LdLTUs82em62QX9m
Vwh3cAI0eKGJmA9E48abLP91YbPXnsB0yTuvXvU3G8+McJIoLss+fGP9TxAfqZz5qhAITJvKzcfB
UFZiT8aEifK0ilPEf3qm6gISii17Y8m+VHznDhtCP1L37LfpX4uKJBwJjlrKfNmW7STDdLO89oyD
e2HIv0nw8busGC/Ej1EK8zNEkmjQ5+eAo2egufZNGLSxIH3Fw2fPC6Dq3kS/TBABX9L29cph6JjZ
4nSjC48RlZgbIX16NFTHQLHZyYh1ejIny/7uWjYqTOhw7JrIMyASnBlHbBpwi2XfZWEliP+Vuiqk
X7fxjgCGQtYljyTSUDwdPnBzOP6ziMgeiQFwRxvaF+QhJmXIMO9ZwQyTeOjC7oCq2gIWXefVjBws
IeAKqo+Z8Y0L6LlQUeErB0tA4/F57VrTv6n0Yp4KodJE0cSq2BjsjhtjM7g4vJsBwBYFQaNZXGq0
hLUXAmMAORmndt3RWO++GG/p+GbO2QLdjzerIZ7o7meprSoWIYVvfW5j+XRdnfi54faecl4z7sgV
Vf04L0NHQMx4g2ob1M4vxXymFcnA5EDUCjHtuEjnSTyidSXNhPD29nyE9ZNeMotvvPZ+kQGQMO+j
BL3prdopNsj61fu/ALVGxnm+JDGntGmTPH0E/drvEEfE9mFloDtI/v7pWPFHrhjLtCgq89gZ/8vR
yJAgmrri1wJgxZYcPRz46FjVG7OFMUL3XKvGHFxQVVGeVL3gtihRCgwQtMTKVC4PvSnumAIyflAG
KixhgG/VtFDFGy15pI+69LoDrnt3fUjmx542ejB4vb6pQl1wEIWdn/yVkGm+Dmd6j5AEJK1cbr9S
cZk0UXgp+PgyS3/K+8KhH5YkPmvCe44PhUX8+0OT3ndr/PLVc/sp+jQzLTjGBNiFgb4uUudXEwkE
VYGXLEcnBW0BHNIo6mG3tJMjFoypDWA64oY75rfLQTjNNlXq/05bs7AgWE55HyEiXZ8t8koS6JZW
PmO9/x+G8NNQ5Tx8vMPnjoYy9RbQDMDX21FC1Q9zO+GMG8iUEqLHg8/TqHOYzazCCsbHlNpDi/i8
BgoxI//ffWeXI9T5PVlLYT2hKZ2ywAYl3vTRjnyodoQGxysHBY5hMnPdHVVXoHG+Rtc7Vr3iKRXp
EicxaujqXpCuXYIp9+ferjxKlhn4bf5ciish1GsRqSHOHFzyDlxfm19cDabc4j8kzG6Nh8rgZo5w
/5U14AvUJBMHOsap8uAdmQ1FQOqFJmWqn+OhoIB+FK/PJ7w1OrCbrI7KZlXZiksEuDnR02YcB+G/
XS7tNgMvZ59hAzYza6GDG44O0sTnhaFB7/Gg5njyHysZoAsWZDA52aZl1Fx5FesncPgOf9eAzQPn
mkg9w7DLhL1GpJQEN1iopy0X85GIJH5sna41aSOQ+1DBl117rtq61oZ0sdlYr3NnfDyPXQWTFS01
qs+zemNTkvCP0BfBfdg3lda9QBUyqKf1LgPGsoJQfx3mnh50gVzacH6Pjr4RqoadVvTi6OmI5nAd
ni8a0XdcmugIcHYtB99j3hktYxJRS9NXLmo3gXWjcDU+kkHSoLSMwDfxd24zfShTPQcDKqwOg1H3
UaDQJ4xAOHlsr+989RbSaQVRWiw/i1OV8zvF2jTl7/dNlQdGCjEhfsCoSAXFePy9QXRJYxbEGjn/
lcsVEykHZii7A4yJo4bkQRICT/16hrCYpynEvq48tm7iSZrJA0SztFNbWuGs0z2MX7BlQJggjMT2
ZLkAcRsDeNYtKhU5nkhym8JlcxdNiXTrdev4JjZyWlM9EuqTNMopeVP3+ZKWQtdDDy0juRgSqeIm
vuP5JUtIk0Cg/bCuMwyjWBzK32t5zR8A9g0nWRBZhI80kuVGqC6BP0Rl9KvtPlEMLfOrLwJGvVBG
BbpTmgWc44Zd7RvBI6WN3px8na0xZkclkdgGKbwVCpsx83tns8d/HW8megQh9cwvkLiMoybvf0wi
wk2M4zwqKtGJBrCXHekH0GVkdVNhc4qDHxzkfKw3riwrdyffZVfQN/BuhhaU+17mrP9DXVIDS5nJ
9IzOHI1QUAbzy7PHNOXlvbaKnYT4uAUcvKS+CZGU5UDW/sQY9nFU7lzeB6dQUJXzXrWXyVJwzyTu
uSfJMaKSqSoIrFwNb8ZKS23M7AozpeE8P2j6XQ1RIwg6nr/tVms5r4W2t17eGsmtzLVKUy1sdMt8
yeq1wK6Hjs6YvqpaCSk8HAQlTTAAtTJz7Gop0rJ8+E2M+XmBZ9cnBq3IJkFw2nZI1XQGXI80KvkM
evuqTCpsHDuzeIFC23iwCGXhxFI823hC6vZn5P1PwY5Z6Yo8cGsO5vyARrQU6ly3HZlDKNz8pK8G
UroNrrSwnvJjkGQJku8n05ujkrBK6aET/ZZjdK+77YHjHYfVCXhKWvHxdDAO66A5D1BSDaQVhYD8
Rx5dxdzz/NX110ue/tgPC6VhGU4l5jiqbYTKG1f+sOkSXN54lkW2afEYBCr56SuGhQGYWn2Soy6f
zaHpqxe3lILS9epZy7w0X9HiUt1pGmIIhyTTrPT9zbwezgeHTxRo9DlgmdW7mKfqV+hGJr75yCh2
qZxQo4q6JSWQg4ZLVeirYenQfldAR8ZqyZePGeTgJPNCCDhgil4NG6eeLmHxRKSFaKvgwWlJOCJT
MEYozPj/RJ41ghMTBCXJ1vzlitNqx/iENaNcnJYPKAJ1GebJbmpavwnKMgs2IprhRypQMisD312n
qb87teZ9v/0psclzkGHYCM/kKIlOW2FC8aNCWL6uqSP0srLDzDsyf1p/fu/hDcDgpyTLdlfONzQa
8LsbMi0a59CfdPI2nOIPSRkvq88lomTQrRJ29Sh759WWxTYdBGX4T3JD1Hlo1ry9d6l9gbvgHyGd
XXm4G1ty/mRUo0VmVBWNRKXvhxY8WKs2MnuamkU5OZRoM7AXVG5OhK5rT5gp0YyXKrS7bmUrCGY5
bdbVYaI9qXXCmBJ43i+mv2Z2CMs1C8MaZSM/tIGEiBHcQ/S+frIMCjXlxDSaNxCGPuHg19JWn3Ph
FqKjlcgFJujCo8nJjHJeLI250ocIo3/RWbTOHwn5fp9XlPVG7/l1S8fUBpIT6LEVFwNQ2y4qrWkR
vrW9jZHiMYlisNVLJGCKrL6D34txE/3FSPQ5jEkm3vUwrqTuKp2ctgczRxb16vI4xFT0WyGkAWfa
rK1UJPiU3Kwkf87ppCw0U1czS70jHY3TXeKnMcQLIxMJuWeWOKNDsBUZw+c8gNgw7Bb0n21sWGty
+qqoMYiiNqB7B8q6zUyftjBM+BhgfO11CprrKW5mgCLBv7FQi8lY+H7aOIacGiIHSbnGESIT/G6d
gufxw9mBAymrgTZJEqBL7oof3SfI+BmPBHL7RTvFOntizCj1s4QEyOzvbWdsUqj7LINL5Or4LQg9
urU9CoRkUv4w6YBFD4ccP+aKYaqeVscROdIEoYAx2sWZ+fdr4A7Pyamcd89DRuU8Fa7xIVlcdBxm
Qb/IX7kdJKKHmjzqZrX4L+C3hYh0pkOxeQknjRVGOyqC9FIi/ZGkLk/Dkx0AxpbzxH8HE4rAItHE
ahRBgwPZmnl8qIvl7GAk+m1nW0JoWU98bML3qj0Rmzce6/YiQWagLrLJg8ry48+yVI4MrvcllB6w
n+iDnMXWxNJjnVZyS0EOIdQVvVXVyx0N9BEc39slzvp+F/IgXYS6ccR2zI8XNh9BMJG7O3ZnZngs
jLmxdUBV7Ct+3IxaedE3PYg7sElkijj5MaYRe7af/jFt9URHfKJOU5M7E7qRx67gUbeYzc6dB1e4
wSpsscDdJInBKumd8f20DvoKTdzLISmQOQ1njZ9IOu47OVzGbja5A6Ea6LAZSfBlixK7Zt2Rkg7O
PVPsGNRd1nhCEvQUrk0/5PnIwoygEowsap3k3ctkz3y0ghGJGvmG3hK8ufxzejz00f+oV4zK8pLY
BeDLb9kBOOJDuYT2iItcPkaXZN/vLRdEVsu5fUl0f+mk1P9nCW1b03PXatGaCazWMf4Rr5EzJkT0
g8eEV0gazUqXAI2p1YEiscf/d1C3Lb9Eg9/D0sLEfqLhsXOL/dytkud/Y4XjDCiiLbGPy7N5ulj2
bunzRQEva7h+C9mZBE0AmDKkw6nJ4nC1UivNgzoXMtmAfS3z1hEZBIa/gtwCgK89bnjRW/Oh0h7I
KFzpGQHc6i8W34jNos/0BxEJKgTr7yu2n27aiVSE3sRgfa2FA65k5svaZwmeZNN4xCUgYF+WvSdx
DL3ZOGvo8wu1Qbclvz2X7XPQQ7MsCI+XYzvnR2dlMdYLvFQldIwWsRmrGV8HlTJkQ7XyGTdERAgR
diRr6ID3t4O2FzjZs17i/1mcVwgd3ZfrYKzHIr0Fcj1wkyICJS5t1md9xQC4fSO3RrfiZ10YMlwN
X4y7nzr2JZXbbnW2HLfMUEW5fCZxcR+8qjXhk2KOILd8OWZre6XMaaGFDAAj1g7ts1B5nXvswYVA
v/0NzW9oa3i/vodOFum2oMEt/+UAodkJOrHa/2Hf/phpIIlK9ylg3OOvLWyiydWw5Vt4Jtrnp5Zh
v95wJ7/3ISnHh+tGye7Ot8+ENqoe0zx9i4aHunwrrY75ep8gjNk+qGW4ToWvki45/nJLX40YrrL9
n7ZRJ5G7502vOmR1gsr5EMiT5pty9B3DLRRFELF2k606sg14DHHY3jCpZceQr+dIiZDAq4DNnjrF
JRLDD+mvQkbL3er/HK70xr0EbR0scAr8DxGa0aspGmBUn69YV4FXmQE/kqn4fmJ7RUsru1/rRlSk
t+EaLfmf7pF3I+CzTUK0IvZWp5ocXSDMKYCwxzDItt+qlq9GcT/tuwSw3/7MaWl/S5zYTlCbE0CZ
46SN1msuMk1iLO1BccT5t3IfSkieB4YoTLc7vsV15kKRObomKrPu/RAetzYjmymJPn/xfgcqTrCi
FNcb2B46dcb3hUvE8PxQIAuOXQLUOEk6BKF9+jf9kzxteRnANfxQ0fj0COvvPSz2Ve5DCMlpSXvY
Gd/2r4wjK3LSlwz8ec67kfNvNQoxz7oKvtKBNoIy6TRV1pESa9oI5NsSPY2Uz3Np/mIvufcwXIW6
fJT2jGIvq/rZrOyiZQnLTaqgpCYhh82C0mRD3c9cOblK2di9k4r22/gm+fSe8/ZCbvc7LOUSJYM8
stbZOFsG9TQufMrAbI0RSiq5OmL/ySwqeSa6mmDUEXMO91pn2M5PJ6KJzSN6H9Px/l4llSqqYOe4
lbzqVVQ7Z1nqtdI1opzDA7cZlql1JwvSg7ehDn+pjl4X5HagEBRdsu9CktFvMBdlq0R7It3dyMD5
gfxPtEUFT0GfrhUG1lQMX02aNAw2YHjvdHERLpfUdA+nlKyYLZUcIGOWsqKDJN0kN8o+O84OjhPr
mjFWptrI+3Ji2ImPWKnfzPOt2dlmb+NoO1QPzvH2JZHxQl3svRS+eG5FPbgQp5qPdydsscRpsX5v
QgsQzL4he81w+dOCFmtw6TQ+zgNEXSmokV7zTWlw3NZpOTXoiiv9gCyJgdo5khQDTm5YCu1/AaqY
HiOjrmkb9Ezz9HLUTnKlV7+145VADmcUuptoQW/6JChOULAMU90FH6Xclbj9FOrEkmgGImfFBhwe
+GfoSTWb9q2X5ZE4NO9y1niabf0dQjRvdCIVpvlgFJE2MesDWfDrKgNADsehhLvFWdYX4xTJ+YN4
4tnLfvkThK5YnLCJ218+LOLOddKGXm/HznC2FSA1Z3ksQbXM4wgDZz3KcYuLtiWL9tVrXxktx+4R
EpGi2lOoKNNpkJSaUFVZj76ZK50dwiN7zyXWJTLB81mx2TMkTQIYS3EQ3GrhT5RXesbEXMHsCSpG
3QyVhY+NiONR5RDSeOgl2I/5MPwbN764UI4am4EXPDG6dtMfED0JkjsWk2//J5GEutCSDQ7wb+5b
QjOt9fQQEw2K8v7ln8EDOTl2ppWOCCHC21fAzQq8Rol7iXCZaDQ1dPJ4tCzMIcxjROyw3c6MCyXj
5etYVpJnUrAzvKWO5PoUh5xE+ZUqVWceOfHqQBPAZi4tp80A1eHUc6DDWNisJj2iq4/SAvbMUBID
DTUmUEMgCqewnQluuKAQ7aPsSca3ClEcdzqqxKDkLJx9X9iBNiDT0bgAtPIAFfqoE/kErkDpnMgm
wf3M+OPMWwnz+mvA6jp7gn+cmaQD+TAZgcep11eUjkr32pkbifwqKXC6cyl7rvMQ0Stxv3Bv+wNh
WhyHAjTgym8KBE2uRMavExvDl5klEb8U9n4INohO1W3SJw61WgO4NjeXpM7w8Fu9NzDLpN67Zlur
wjfEXu4tR1F8QTHqvGY/XG4KVpj4Wf0UpN0J+MQT+2qSqLzMpduiDS9HlyzWdfqXisjWHgEluiVU
higt16D781aQfv4U48p09QAOVOw9ok1vXTQnGtbWHOz+WRkYZh9N+FKXAlShWaepZOqknTYKH+BH
Sd4FGjloS+GEjA8U2cLXr5r71J/pdklhdoSdvzFnF/dfbolacnLLG5E+rUutdfOsSUlepl+ZPbO/
ucm5/nJwIqf7rQtIltjJcnOVlcjmWcs7eBXWBL5yy0wiDvXbBuQsCnasAmWqIHe//nAtrPMwR1kA
uJitvm45t57dm2+c/YLlAik2r6SEtqm2lYpUum13pSRex3z4Ijlhrb0lHZ09kSUWqDqpYjTX+bbk
EV1MRwWbakjzu+dk1Hr38goAyu0KFir63YJXiNerMikKcMHYLuXC16soKiVWHI7iNCoVdniaZ3qf
nW2mtEj1+o3430qJPYIaVjFY91OgNCAi2tR6vQ/px6WR8/gvhh9u1/0id/HQuQk3ZE+2GIy+0Rup
37qtWw4eq0iGd+j9geadd8UNLQblsbQkzgXMEI/VgeExcaWs+4+Gk7sPYBBYrXQesyCOgAQu0gc5
TNO1tgcBTmDeHGABiDg1MbTPYtGwdaaP/xOOhhphhG5pvhDq/KKo7KeI2dXTokUWVgIO3XkNML3l
4KQxN4e8kakLhwqJ2u45xiUsYAXR8A5phLEJ