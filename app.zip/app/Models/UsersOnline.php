<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpOW36gTnlHDMCkPIL9tKer2C8CdWanEwA6utzSgeURaFR3zx46aieJkuEU7OZV02kSAZ0Cd
f3AjKx9V8cicLfuur0W/8rHUJbRkISyJaXaFQofFGqB6kXYmFL+RmVsG2qqwN/CiRXMYosOLcrSp
Prq5Z7zvG40lrmjC82DJvBEC/CuWKeStSXdPAMTavCU4wHm0lpbDUNCaXDBTT9aCCy3+DGAS0hZc
Vbv+/yoj3jWD82CDZI4FBCu6SMtF/lWZ5TKcRjHLK0sFFSqLpROcz/6WCaTVNPuZDZvrjEEoOeA2
CpXN/zyjuTracGLdO4jR6tRmXdh3H+fxelO0+MeP7YoZCn48T9ZyAfU4k1UtYEkd0X28xNTkAsuq
36IyEVEM4KMmJ7M5fbgb+OIL0S+Dzqq5f45tjQog5VTe1Un2NdSQEluKXySWrM3BLWq/xiK18a13
goiQXvExkCeEqHnHxNdzsuFEth8MY2E3CVHhKtvCzfw+T1GX7Op0vuLq4xgs86P9oRE7KwODI54o
M2uJEx7dGVMAWPbWzubFvtpq2gOwfbU5aETdsK0QSMeZqH/fXh+lqo/8pvs+jteH0QBqsynquNZU
LlKg1km+XzDFIUg3JROUDKSgR8m0ZfyNuAazBFHeC1yAhBe0f48cgzlJYP+iOaKSS6EQYMFVd5sQ
J/PB4ps/iRYS651Q2bgO/I7JncwlrCBMTsZ+h6a0bW6NxzW78kZS7ns5Q5pVaQoM0fD98P2/4m+p
jiI2xGAkRCQjXKRgA2sumoZ92iwqdDK3g+X9/PZdZ7u/zIwoHpDUGAg9zIQLXdL/zHpRQzdPffnA
JV2Gu9e6CqXj8PxjTl2r5UyDDwrskkBSicelacdSSKDkfTGIWKlbYnN57r5bRn+yKP9tvuK8NURA
eRF6EELlvkbjXy4LoIenRwXWpZWU0BkBu5+oQ3CSxDt8/nrnFMjge4gwqApO0cjLDS8DzB6ULAFV
LTRa92e5qX8P49nmM+RYiJcZuMg3ASBfsN6ZQIUmaxmi0H49zz34tMGv5vYrbivKO9t12xuJ4qUr
aDEnexuVyttIChMxrVY3iLJIJZXoqK+X2hsErBpCRyYI/QU99hvp3iiP4PzrFZWSMTpPi9DAYgTT
yqMcaGyLSHPtyNHSYlfgbm/9ta8q2Nrfm6vbQM1IxcocXWT/Rawo0FsdoqySKwcgNr2EUgQGQNzY
r3NVrx8QMbT8GdYZzX62PadJwkDxi+voSOLwhwh/Y5auprcGbuHvWiWO1hp1sIa2WWjqJY28+A93
grLeUfDSm1dGCF2VBVErq6CGpEobMHmPNvShSo+CFYT4ef/PgJMjy6z2SJWzun9e0KvWXMFDtDHy
tf+v4ul2pDpfUYt0q13YZtnrQHl2LYr31r9j4vRLfSM/Dm3RAG7wEJBH6FsaLKgSLGetGVCOZ12g
aaw7eUrX3THDRk0r6RnnTsDsdiZK3RBm20Ke6mUvQYkuk+d527MLjdtlWhbfZMkCIOxzSQLBKceI
EzeDUOWlYuNccurQt3H0ryFkWaANgp6aJf5v6k+0Xm5mgPrBUfrTHYNE9NsouqfkoF2gYa0rHbu2
2gRfo770uL8nQgvO6q/9KxbpXmI9p4N/SbqjaBVrn7bi/QwUa4n+bv8pLRDq3gIwjaD4h397/iib
rW2P2L6CP9BAXERYb6KVxbt/pTF+eG5UK1VmrMm+L66d1pqWt3Zl2QWMRZQ82LosD16MtKmWdDNr
P3FEL8VMdPskomn3Wy9hFNICrR/4rywJrGINgIj4N6FQP1V8tSOmq0LGpBdxsDgJ3CdYohmIpHFN
ZvoftOyNBCdd9lrY8sC9EyC5VXhPnggH4utm8C6OhOTaIgwBf/ScMqC4aUzC/+GlCXszGNUsGJDl
lv+WbkHt+05nZbr8K95fETbXn5vOIHPEoE2zz7A6wfJT9UXSrlnJ7Tfa2RPVjlsBaQqROFpuT9bW
SHZBDGAtTb5dZ8MMfkElIhxsL6lHIDNarqmTIPIC1zMcWo7bWQno42BvO1ANUudPAtbT9QuYM1xM
GsAW0iSHUf5jogsTTvCMddxPo0VJP/KHOv/tGkbPI99MvP0VYdhDcoHeY8adb3HXZzkuycGTjpDl
ciFqAgCIjY0XQMljISxFP15kRT02AKJbaB5wSWV7AgNoI2/MBcWa1SVCtJL3QoqJqceXU0ho/o2W
NRi2zhI8jBKTyQ7iJPkYO7KYasarskzyIhyYlIe7YO26YHP9yMMURSoWblnFiDSkLC5DjYahc9hR
5NdB47hC5rjYrbsUKcaPMySXBXg0OlK76q38jCT0C2ycTgR48dFu8KmDo6ijfI8veJUmR1UXvvD0
p7mp86zwzoIOf8dmts8HgwcUxbmeapzaPTcuDk0NiahM6JgsL5+YmziA5Zr26a0J1G8nksbjVRZ5
/Gn2SIZvTfEDNbs1GUFVxsXeqPOd2aCrQJJBbFLlsixJBXF1gx65qw+obJuCsWhjA5qQytVXK2Pq
t1Y48qRxQmg5x+CJiFh1fqquf/M1hE74N/w2rh19s+tEz2j2coz+nstHGt3/aFeOIDBLRQpsE8Wr
Lsifx4Z2riOEcvYT0SVftv4WtIbeGYdL28EGbXZNey2CI8MfeyQp0hnb3UI8kfWrQMDLs1JG/XmW
Kqh8kIq3rdKaTPk5VtORmk1aWPbJ+qpvAjq7q8p7A0fFjQ4zATxc9dnBE9wtkKbi3oslVK6vW8+I
pQScNNips2edwrrMw5gXQdvDiWhKyXGX1gqIWNCVntG70lduEHLQUfrcgZR0xcgkLgo85OMWKENK
9ToX4vvfsQSm72ZKHpP9gCqg6KpqPVFh0RtkAGwJ6URW6DAka+mNQtcZKYGKMfwGuK/wEfxMBVoR
erR56S4sfJA1xnNwGmsQ/9E36U8OboSBwdhzDci10bL2QmFhlOelHrgivb/rbBpbuul8jSfk7Q4i
09f8ZyZuIhjVito1itP5q5qkwBn54D9awyi0habo+cr3WysRU8nIBTJaCLcVMShbeC81zdJpI+Jp
l71wUH6Zfg001hVXAO+SGzdz0nV7qQTn2ph39VybRQjoNTUFM/CE7EjNPEDBMp+vxFsDojE93iGA
9XI8wNvLc1l3PE7woDR0jqdTIJ53Gfz19/6l5fKH8UMmjrOL0IaCyewi736zmzw3b5MEnEeGHYrf
+JHvuWIGeT6K1RIC/b79FqorOMOdbGr6HCsDge7/g7/+tkiDL1yXsW6Po082yQoAJi2SVT7pG7O5
ehyARe6Ftl5/YK34glOicUi3dCCdqiRvM2bjnNIUIvD99VbxeYw+jW1SS/3jYVXCr0ZkXLJhXx3/
YVef+6VrJ1v7Cv7AhOMuGwF6Zqw0ZQMis3NkudxbJAxbeZUDMcV/pZ00j3SiEsZj4+0VcFJ46EfC
/mrD5zCo7/Xobs6clnGsjKEgUlMz1SG846ByU4KO6KgtZlfDQkw5wM56+ZSaDDh0yKTU9yMcoSwk
D96kw7UllkQaPIw98psxLdWT992gY45qu589PveurdqBiQumDuNY8tYGxhWizqx14K+f8ngO9mUZ
LN5/MIPJWwvUKboZ6tiDJIx6ZR7hBFJeTuqPZ4JLOyFz9ti57klkNkZedssGf+hjejxbDADf+05L
9h6GUA6b3lRHDgS1G1MUxPc2vJyuHoP1KX+H+zdcj78h+Q0c/qrXev9Hwqmwwnp7bJMwGMxB8ZMN
rpriYVhcx4qdB26ZxNUVTZw8K9Sm24MQm03/3mtJ4eVLupKVm9CVOqAoeIAiCYbSNoOxGn/n3TbV
nYiYhQ8WkFV3nrDczAiQD1GgnZ4UWyRICF8dWUMRXEm1Ljy9yeCZeKaUuRziNA6NHnLD6u6ckoOC
WTLDvH3XLGNk/HR2HUJ/AHnAvDMv9UtVUw6nbpVVLQfT2vuBCsWAT+P8tT8PxofIvA5OtJVOdBrd
RboVPnFT/XLzHmUe82NKxe2HrsZIRmaQG2pu4CGHk2g6E0BWp0LBgSbuUciI7sjegVkwbM3sBx4R
SKFibfEQugBmISviUOqZ12ibImWvn6AmhGHWWtjARlb7YsBRRjPbv4Au5qhWfEcRxxPdKQ2pfWhL
5nkF9tBhCfJPQFnw0PdOPFTJHh013o7Q5mTroceSMi6AxAFW7x+uYi6W0E6wTWofNXDMB1rixmtb
cBG4IcHGGTNxTvPBW4NP6bs8BanjiW+ZIBh98PIIQBopKY5IQnUa8BCQbDnDEhArLJOGMWTARE3j
URC38eQ72bsCywhhBAH/lDixX4Gryi9BxhVhjCwrVwCdEpJXYif4jWfUx6IS5MxydGwpcnByX9MT
sssZOcfv9LS0e50NGE9FX6t71ECLg/O+vMA9ouZcZN1EBtA9t6cwLza7X1VfEiaQPw69XETRnAn0
JwFs6k4XnOiTLHzNGANIdQfUuw5znhF8EzOvFgTxWDQMjzfDuh4si0/t7hEp1jL7EzIX6wvRMhKq
AmcftHOnx2GmeCr52wVX75F6r2yvzrkUx9jlpfmQqkNoxhzh8Xy6zWm3zzf+ycNE5y2HXq7DILEd
28AGsGv5rBrPqbGeZzS1vsrMcO6qqesLVaKY8vbAzNW4pvWvVVircOkh1pQQnNIPnWtA8GcOwxfW
gSjbGK1KUEJZ7C2c93vukk0R7+KRfHFQ/roGploYI8Bx7fM8+thBxZz4qikmL7qf0wr6j0ykbH8Z
i7+33Cd64vS2X3Ys1VxV1feQ/vq6NabnKcLIFRzZBrRrJIgD6GySpATziGjJWAEbES4SDD8wHEY8
J89E4QAvVMsKtYKGpCZSJSDWmzXZBeBMEPTm+8KiL22t8Eiu17gsOEQ+UqcN2Ksgo0iq+5PldhE1
RTxC03uUlvIDSitQPv/AnUjq/wcmFV/plwjt9TKckeUXGUq78kkdS6Q4O7FIwuG04s5WObs3IxeB
Uk2O89BuI4mmwscG0I7ATjdgw31ce29CMiDOPapDXnESMfB0zwY1JOa/xX2sSzZFDSvSkIULQEnG
Ik2yVzXW/V+lA0aoiYr67/PwuNoH++smKSU498GIOOMGXmIAAI5RAFn73EX4v0Rzvotn3MUz2ktw
15pfDXlXlL9G8BO/0LVkU6LMVwt4EiTRIlir2kzEMZhzEqnSuS50Ehige1nt1F/Wsg15Vdf0uQbZ
Yr8S3AMu/T06ep+QWVCnRGMLh6pWGSnbfv4gBXm05BYHyWcorMOUq05BYruwP360/bIpAG1Jem67
sSAsOxAVtGFS3JRvAdpNbwz/ZmCHW2SV7fV0NTo/vO+CMxp5Gms7D5Prb8dgUIJvExmHtZzbR6NV
8RzfMxnltnSFJBo+uUn8qIYZTw9yQQrBIGeheT1gRY0j+TsNCVZXiiPlGFCYL6x+hXSQ/vXVdH2f
guMAs9Kc77lcbpJic2kBYliARUGJ0ocQM0DD+L6QLjz9e5FmrsK4+SIKjhqvMGrMUCxgO1mCc5v/
tTd4Ty7r/Lj87H830I2IfsCp74hHly1+s12Va49+//Ek/P8aFo1tUJOn6dWCoFEJGLAoXTHCczpg
rWhozIlbG1BhMgKNN3KL3cMOAmG2e+5PKur87u6o2Ge5sdIFkjSXLegRl91xqaqVeyeHK4CN+oQZ
9jRDQhUGbLVG7mRwKOYmPNKmmS+/rH35lAsO04Ybiv01m2q/YdBG2iG91O1RPXOjfMi3QSHDo2ew
kFW6yfxSGIrgB4+piWhPMtYXfTWUm9KpJqBgI4bUefSmzgp98GVcDrthniTaAN2bNDjh1VMzvSqJ
wP9UAIyFkzbgStw1otaFAMunsRRKl3e4Cc9xzkm5Dby3Q6+waSQJAHaIZsm1IZ9tzLX/grZg6RYF
dgKCLjSBwgSFbd2b9vIWZx3L3JU7/BNR/Qsl5ZZvh1JD9QUaV0G4GYMmj4slj1/rKqIxyNya40wl
zc6StTfVYUwjLgfldc0VM5iziEiZ5bSPZzv1qiSeN7Fp8wL1l6ZiEhK7cyRmhzzOk3tkjEYXqtgw
UET/pfPTGyKqQu6rtwBM10JgpfY5OB8TQCc+n3LH+kvXfMHHq5FczHxlx5cbi7/77yKQ972j9Dau
eJFJyvklS4mlc+pWiO3ppi+8RmWz8uhn3PdVAMFZhAUsuVWBroXJWgvqULA6QJvINL0urDkehe35
Dx2xcFyJ5BljCg2/JzZhcF1tPJ912RqakTDCBsUuRCdSHoE5rMD9EC64EFCMTH1WbYHs2sQF2ECh
pMtYE0VLCXDUD9XhiaWRlP/SCPgn1zJ4bcrLqKBLM3FG8VsU3pllR4bZp3J+f1G+NpeRglHFmfcA
L7Qj1rXJGXXmPNlvfli1w9WeZrnuKGsPQnDFoHjD3h106Ds13vDyogugRUOMBuS/zBl5RrbreBnv
o2YFbHiICW8Z2TyEklj9UVR64lQxaAVxcNKOCCVPfwP9wUqbwSbQbi3ieEVSJPZFNIphNaW/C8l+
BEnpKC8JZdAItyHhO0aUrz3grlHJnuXQcDIkin1r12bjSc+hq9sM1nJg7jqdD9/2uoaWjz+dNvSL
hI2UoeT99mCtgJzu7WbxE9fLXjpNeExMRs3YcpifwUMPVLLjpRPrruwbT9ZT7E28RnZBoa2E/1Tu
vDM9Fgg7sZWVslSZLx86uOmhJ4IxtCC3pXD9Jx335+je5aFRyac6zy56dpD5xoLYJFQRdpPvnuhn
yFpsytWYfsSz9dcayBCZqh/n7lpoTot0avdbpirGg6uCb+eDK8/QelVFeMpvBnk9TXzpgIQifb8a
YvL18NpjN/XkgSNNQ+0ZAlNCgCPwPJixXkY7epYjdvQMADJlDfXUSvN6hw9Dz6+bCcWiEKDggTSv
ar5M7jmvliWdgZr4t0z6JDY/Zgw32EQ0n7NKSiE0sTaeajyacswkjfVxtMpP6kQC/W6s5Dy52tOs
b9U9Lj9nO1t9NCD9EDlwWNzJfLPehGbfwkspWU1Od+ZidJlx8uMLJ0K+7l1g9lHduH/Okwhc5KvW
myfmwzwuKwCN1yq1XEohnUF5pqkWqE30ZPJBYCdZSfwtZRXr89OfwtxVcQ5Tt3IjruGep6QYUY6n
0qVTBpqZb5RB5NYh0leO0hz29/CIJfyArAPpOVurywW2gkoXBLBZyJ2x17qWmgFAKDsc2DC4Hf20
ipuCTgSe5K+G3kGFLVfTYB6ipVYYPUNzjdV2H2e1jVN+/8nyRYNiCnRD0kdQDjO9VSOTGiHyLsZe
Ce0qSlWWK6m8vysRWY6XvvW7BlzYnvr1iNHUHK9KffX2oO4uEMln2PhEw/N43+juJTFLMgtUssDg
VnjIXb0wO6OxO09OoxfHZBUOO0ICli57TqJaufKGFSfG7nmOjCDhlWN00Tt7vU+20G0viI3HoTkS
jXFNxJPX5JOC5e2D1BG6rsMyesvfMKHGfJvDa4avSErBArYYJcxGB0Xw+OKZSP2CA46SKNMr/Nfc
SETMhIvKiUN1vrgrhbTbZpDuz3bqno3x9LXF9J8glk9MzUXWFwSMYGI5m8ByKi43jnaBRCQUDIw8
WJOPglTFnjQNdbFB2D74cwOmha0hgHUlEkp9i3FP7LC/AQ6I3iGtSaNrlaiRc6fpEHYHGo5Bz3q5
SpDKzfE6BN0W2Ee7mipZUG2ri5pWYFIKcGCmJ+wkm9Z7RfPS5GpK97lyH0cZkNSgPPCCBhlOSa7D
bNjvLpuzQb9XkjOwMq6RP7R2mUfNGaO2y+PzxRxAAW+tFt8f+PaWUiPktQVncbLuBQLL84LBT1z2
B82QgDKNZABYhMw6uooTip5Xy5QqTWAtOZVkBNlmvIS48loYdBiFh83pcV+RUYYdH0Nm9hWuD9LS
ZAeBdpeIJDf/tfcCI9VvKvHkW7Ygi99RFrVoaF+NHW/eEg9NPIP5kTDeMvwBFbvIxD0w1KrSAiiY
/fXZ+UYDu0rWV9R6ZYiP2PCb0J+JCy/hXWXeR0honWW4h6EFl1a8uuAPlDGPA69y7BjbzIPF/M2M
SKBm1kRwuc/AfGgb0u0TJBB5Q1ncVeU6nZ1DnMFzIuVv2FhKNMTaXg0eq9W81y7lfAkyyFIk4Csa
Q2g+0TpQWgT95n7p+g1Vvew8ud2MxIVL8S462DI+LyndnXu6KXw6m0vCdp6rA+kQPhgt4R7iBZIj
Nt06uzDiOwmnoiC9tyAURczvgO9ODj6ZrNxwgm+D/wZdScWaNzodjekD/ZQ4l4Egfpezeehzz7Wk
kapfB2EqoBB2sbbw6zcCCRGwHsMHpm044YGmguZ4fnDmt9dVeMk+WNKtxqy9khtu2+8fnw4gBHbK
5/ynJCVYJCfP0Neb2hFqExsM/Wh913bfxpC+T8KT/DrtLyqfcpFXxg3ig9oSYZ8maGG9oG/+NNpZ
Z0vHfvyhboucRs/IaKujmknR/Jy8zqUvJe9PWQbWzEvHybr5Yk6yYd5dxhYKq+8+P/0are9VZf29
scofUrIvLaANXTmSG9OWkJgh2GSc0yGQa3Z1N9nVB0VOZjri2h2QHF7oQmagCEBoKsIKIUFJNuY+
A/ULCRceu+K+Xi30eqspj5tw68DJR2ysn3hFMPmNC7q9Jl+Yxz8TniEozOmXZuu0/WeAawwz7z1t
kaV4O9QAzB+KSwtR9DLuJ4RaWAwbnyypqXBghK8A//2cNYR945ekh7rdUslrgg/If/K3yLwKrVRh
enWhvCdt7sGfQqgYQ52XdeW+8PJyWoFUO8Eb3OgZ1PbAybiz7uM5TwMzJOF8YR3BOnJVJUamt2nh
ixctzp5FDuxhJCP+9td03QR30Tx0LjQpIkm22sZn5srUG1Pb16mML1Q7HnRaESCRGvYHzApzMPsY
dVDW4APgz6KdlyhQE2rBOvxcYB2L8EjtcAtAD+ilc6bszFoFfaX+cSefdgCJeQvqPpIsDFlcmbtz
v4H3FamkG2yCpXOgWhHF6ZvdIKJ4e5W3rAkmLA9+PSZeOc+MgSb69teJR5Fpp5dldAD5zXPtuvQx
JbQwbD8jUteHK8DuCo7YbNdh1+FCGURzmTnEOcBpAKUB8ZYx1ujfpZLPVw42HxHb6yTH6AsQVw7h
/OhZnYk38QfNmpeXoTfvKHbOWomtSHFjK+cKxafojPAH4jvxuRuJ4CRSUUoUikm44lFNmCJW0A/A
HAcXQmRBc7uH3pXxN0zTqZvmaPrpCoobirvBYthjd8qfLmvCrPzYGcn0n14l47sQ7O/bW0mjU53V
6/A6uVpNA+I287xLiPoQKcXfbY9yH6er631etfeuqUEKZZLUspjRoSvm03yp3ok1d1THqw8c2Oy0
OteiMwviXrjQNBLL3xz0e7mtaHIe+1moEe19w4NZ4sk560oQxksSaTCME3lqoIgOl5HtBzHVDqP7
Dzgug/Pz0hSa+LMsvmWiZyLLX9pEIjDIxN5vUY1G3Bi8n2L1ufRAPBGNIPGMQxLtHK+ZjtCvZFf/
PNLqwm8UbDa39/GM0p91kGcWAH1L7shtIB5ipsdK2MMkP1L4gRHN2CCDbTqS/+8MozIa/oL8YPQK
+4Twcz9nBQhaPaBT9nsNzWCiaUbjie9LiKOuJ6CSP9ZoSzo6uhgsBu8bffig9QdG/7q9T2SZJFHJ
Jn6tI63/WVzDFJzUfZ47KomskEIT1bET5jM+UWj2qUEWM/JKU9M8OarBSEeofAdTtDHPpJE4V/Sg
fRgvRoHgQfXfKYWNqv7usqkauq3N8EWtIGEOnGzXeTWKZmZK2etJ+i0Zm77AeIvnK0Z0MwsYFqeV
zA+ifsCwOogW54jwX4/UvUxxH3dujEd/keb4LPocefRtMac5UDWXCJcJMvCuBcdcvuFt9YusqHc3
7JxBr7bwOzCD7q3i3PHu/8L9j28GjLTgf0VoLyBgOAgUrwKOiQXswqBKIgtUyzQ3Iy2X5EiPQ8Si
b2op+ZDfGaV4T4+pUCR53T7yUXhEL2Mec9zbedwx+5qo5wRljyGJFeguVuBoD9e/Y37CuIkN+oeh
Eg5njcmhdFIohYR4lfNtVtIFcG2daqbsgd8pcad2y7E5THNuz7kRRIkxMo8dBSAM43ERJAA+19xO
iH0zcJ4Gd0GJ2HeQiKnunIIjS210fHsdxVE2Wf0u9co9Gi4KONIuYSD9TQNLlC/6HZWOoFRiaCFP
IHF6L1Co9wMeM2+Wc0OBNaMdENO7/ufXMlNX5GkOxAM4FMVIQ59hgswbMo6MOxAyWPNtajsUqje+
UthoZU+lN18CffSPis6m2nH/ClIrl6I4v+6q/wTr9DB6IKkSgrKqmG0NA48Ww5aoZELWtWUBKnSC
DOrmoyyJnk+541VyhNE3QJy=