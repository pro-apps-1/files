<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx6oycOCICT9oLPdHG1KqhFT/PFvJTv6BDSFiF42zQ+EDA1TtxGuojsniwY3+Z0JH2mLB+aK
CwzoQequqKFP4vydsFz86A4lnbPYd950OTBShzepxhxSJYU8RhDggP0PvlPX9gu0YncMUW82asbC
oFAjevbnEscRBRobUIbaZO+yAGxnCbD5Bsla91LmarO9MLSgDw5+v6z7unaB2PZVV2djsT4K25W1
hONFLQZnWAGsFSV9Sl4rkkFumkB+DCydkBq56lPx4aPphoX2ab64hzVSx7iVQSwzI4P+2ZHQimP8
TYiOPAzKEb/SJ/rTBKSf1xPFerM+I6xcsOiDDFpBfUTPzWBiP8befZr7hvbmtStLA8wKaoeXUmE6
sKdty8mm9wf6kc7Z5Ge9WmsT0z/UFhqE4lJIO4mpWYUrrDF5t71JjIFadxpDRyYe2IlkyoBgfNDA
u8yFqckLXEIlAw5AXnNL55ArkeIf/+x/4jsB3+l1myx8OscL7pZAZF+TQBNq5PJ2p1YAvXq1iSeo
CUthi78dmL9UX5qsGHNniyprsvP0mFf9tsQmq4pkc1Tf6MF6S6JZ9l/RuRK0XlWqGtW7Mo42P932
iQdAfrEBzyOmyoBHA/kvb1dDG4R8bXa73HSx3nPmjoSaJ8x61oqB/mUGdqocp2txov12G5e06Qcu
YsSks+FMD6fao9pBxThnm4lUvFXj3TN9QaSwqOaRNI6FhYD6viPTKZxeO1DG0r/0GsIqkd2vgjFn
JGxKBaPV1xxGGGIRpfu/II91200kPBrQu6EQp/sEvBUj4zwni6++5mJjxGgt665MM/nLdXBItBOI
B1vf25u/ju90UN553uDh0myMWuSrLlTr1pcxFcKjVFFxNRTToUac/KdhTwd3V8Dra5tGmb6wsMPu
KsrIrCKtIgbcwznYjA34tJlRHp2CJq9QHyJhvIyApEbW9Pif2wwelFqUmMW38IgsNmzxbllD58NS
wxfBBa0nmrRKIJsaCHcXzO/GFa18pKdj7Nnk3M/MOcivOXBI0OZ/52SuuybIUQgVLDEFnI9AWT62
4mbBXeF8z7G0Nj7JudNFxNBY7zk8VuYNiIeZzKt103MxhkfkHJFDu4jMzyfVJ6Cheg4+Lke9RNoD
MZHR7u9SvZ0qsuW0HFLVeq1s2L/n9zbvzwJUOIwzRpjX3jZ2I2mKo8tbE4duQsu2gWBj0Zssq+WL
2o7XWt6TOGjQnUHb3Pq4W8Hcus4LzujTpLPp0JC0N5BksTx0lPA+RwKioY9uUFgxmow7aYCGo4cg
RnstONkJ6pNnJqWzhqBYjjmX+JJABKEaIiBB9qF1PfLL0FY7UhAACFM3UlznPxvs8dfoGcel7heP
OQN4CBuWdNxTCQt1QU78gvAWweYBb1zFu483FOKTZ5raunCO2dVtWECm8lO/O9jF62oIRtNYWXzN
B7LGzHbcdlHWaKM7m5GZAJgvLu8S4iiOwJ3q6296orVAnSxMpnaBB+LifmCGVh0bpwj90kxIrzMA
Dsa3XPl5aOKQs1LW/u0lygb/YPS1iRKhD8FFRbO2hTn6jdAEGOe81JALttdZYyh5qZN5bIiOoTsP
rZInKKFeBv/Ddgt4lqctXG6pDAHpGrA0Y+HMvs5AoqFtEf0VGo2+9xri60ra1urai8Q27eVHHbfn
CmeQZQ8Y8pURPI2eBu0a/sUJsGAiYs2fs//KFpBHVHzpK1oR8t7OzVmwIqvxwaT++GVvE/lqlEta
4S50hIQAy5vTZ28JTYIlNpfTI9Wx+/Q7psKYzzor1WYbgl//r9+VfH2cleSYHKrKBFo4I9j3AYe0
PLn7pt0A//N7ilNCddnN82zlbIeBPdVewAL6GHUxNirofvTfuvheucWJSnqkC7jflvZjDhOUzpMm
WazeiGcMOt+CNUXcY0TikjdfG05sn1CVRLz8GKeeA8ZqpAzHQrxVKKU9Sne/75zbfmCgBSY/62sD
RRdfPtt1vq0whNrAa7V5mRwf/i4B6tVOMEkf/FbhdOweQbitGAh7nk2By1N/AnpBreQ4jLHiMOn4
p9RxosFDhATCUGaIL+1BNJM/dHuK/ccBaR4tQQLtSNKYKSTg04yCESPelwHLzaMpnfaz5oGdeecU
kEoioNOxh03KhhDo+Mjfp0bdVfnK50sYufpR6Ro5jcpJpMaRpO9rgeB/fVVFxfETWo6e3pInLrPa
QxOBXN+t3UYSDryO225Plg716D/MUa/BoRudS9LfvMdLa0HBy+JgFMwdcA2LMMCQOmxUnADPAqfj
2BrUxelVIuwKat5s9hi5iqYzXh7qL8bs0i10dAxLfmgnGQkZCZZmMHHzvqaokG/hpCvsW8xAxgdP
z31MGWuvUbndxvl03OgX1l+ZGb4l5qOnxucdu5n4O0W1m8jnLzIdos5PoznbZR2+Y62d7OhH996r
opwvvju/5TCfIdAnOBwZ6mZZMMOaF+/SIQMxMi5XnWzyj2EkG7WXzzEYUmTLudg1vmO7KoAo5UEQ
1rhA0w0IyWZLSRLGi44Ojq6E47LhhSwnLoGZ4XDqwMPooCHAE9mdhF92h8t0xIRIW9qGS86iM+vy
BnPfGKW3/12gCGXJE7B341eORaKz28HQvipHXyi18Ix51Yx64xsl549ddb/Fkf0wJBTTvwlE4oZx
lEQPaLsjZGySP/Kfk0BpAMrtdnZScQs0bgQjqGv1NC/aSbTMIVWrPoDsZ0WJclpf1FqiYSGX4iTo
fh5DDyepdRiJFXO9lgQfKETX/rxI1J6JRhbNn/PCOwXdr8egyaQaYCSrmJReI2RfC8ClDHOecVyn
OIO6PHg4nvGrH0DBaW2zpTSCsBbbQIWHC038bps0a1Ww511a/OenCXN/LLfs5KsAY5VDzjxXgIv3
4eHAfJCdi3zR+jc49i5cTl3Es6VwAgz9umof8KgJAqras3cMXUtE7/ieZwJbr8bxf0fDs+gg+Lxi
vjef7/TjW//K+aoHlTedE0i5WXOm+9UyvqpzUPMDBDRwD/wyGrovw1ZunisXepDQG4/tHPRCFWjX
pWCv4SxiUe63R+xE+sYLhmmUOH2Pr65SW5NuD2xLZ/XtLgMP+rA6Q8xYRi9Oos1aPb2MosJohqZB
Jqkh9OJxNrxDpXH8tV+MmfuIzUXTV/+HnyKlfdc0pyTlezlH6Tt2ds6bB6/L14LnMxBLiHCKkHol
yaKi3Z2iMKgxJw86EG/AEmHqK3DEEADAMm01s1M7UkU6ZO+OTGg6m2GJY6niFSE4djPQnNKleEyg
x5rWa3176CYk3mvkOQ3BKkpyu384qSbQ73WOAje2tuSdMqoX9wrtqVMgX+ONDW2HCJJsnsrMi2fn
MOxa8V8tGFeSEvyzGc+l8Bm1sW6M4kzSbPtDPv3BZd980X1ktsAZBho04mIQjoshSgTWM7fBRV/U
C+zTKZUhyfjzr6R8Cds3SJUqC12xXZ85+gCK98baavSmMFwUI8vwpAmEmRRQOaRZLK/TwRZ1PIUq
VA+J8rsCBNq7+Gn7bAOevhTg+WRWbOpGRmhSq8BaTxL9oErNBufL0xcusA7vH5bLDw5b+KWhIL9r
0b8WKU+/coLgQj1zihEBpjOWUjRV3RbWx2fltzcKZj4ZHMxdWN+TBurP2zj2KcfbNwrrJs1DQvgw
cHNnWna5Xd1MBmCexmewQC95K2Pw9wUXrxYzyk6rjxhQM+e05KHuYS5VEo93SP1R23gZ/jXFWgmG
W+ls1Ho2RMG/Rm7k00nfAHtAtTXPymw8fijpM6fDnpQPysWAjr/HLrathr85o0oXyttqhGe4Et9x
ePGaaI/FyYgq73NqIEPMDflNVhAFWJG3YJWHVqKZoI35i8vAEk2euoed0Y1moy82RmQkBEqd7vQ0
HbQJEoccg2wCyB5XCJ81XMQbKjRFWj39YcpXDdk466roPAcDo7bHr4aRtf4ASXaplNPQ1396S8LO
9L8Bm+hPwtOmbYcp0nWl56H54dRfe+C8nVaTRWGp0acoO1nz1skyCFHPWE3i067JPUvoKkAqXgao
q8gaOC9JIthSJ4g6kmA8Ns9SykB12X6XWkjFiYsiH4YI19lmLdRxk/LvS6bGKcXwl5KUJB0ovW+t
/Mt/USZIKqjPSQAAAVScO0227SKO82oiITh5Rssoq5CKoMPdLBAK8aMiJPVZCjjkoCaizXPSutjx
BbhdfBrfXmC0xAkGUvWF9LsqPBvDvT+2W2LXcvhy0X+QY/WwgJEz93THp4HL1Z7t2DaA3AUqDQbL
PvfToVVT96rEmtKaYCz9hxN7VBYkS0Kz/Nv+QwQFHKr12vtB+Ku1hykpLpsH6cvBjjClrncnXUwz
pv0z/PvTVHE6zEzhOKoK/eKboYqakHumIEza7KqDjMp1XOtbTfb3fY7CfTKLrV2dFaX6Ozs3NaOx
GrddoZyx9dRz6zxU8+P9Hmfv82pCRXb/xAIrlx3l6lz32lqzg0R5niZH05M7jigKZcgqiBOkh3hR
0tTpH8f8EBUozLZ/Nos5zMPfw2pNeUefZDpymBxzDdsne0SoCI4l6zo2ZgyEGz/CSKxf8aQIamj6
Co3t3MsreoHXqaX6plig60SzSmF/3GZdBzBdLPKcCvhN/uM9AiUcGIwJ9DzL958u9kBujRatdY0K
ghmhTE4Zhk7aZtVxb07mDJGgruI1PmSNzSLSDgsZKbN5nqdZVdPAZdDQHjSKQdBomXHsKMlUOEMJ
m4CwejP/SKv7DlzItzMlIkfEsr0YYB6XuOnRGlYxax8IcnWSoa53GI+x3m+uzZaJDx7oN4BxysD+
lqWxHf1JqjlfPlTwSgMAMCAMKS5izoloDCIZnSVxwEY4eh3DRBnRKhH9ZVF8p2FgP8hW3G14MgGU
dSuKlwHU2HQZLN9r/QOIWQIR1J1GAhccb5XtPFfGSTEO83hgnzSQUJQpUUY8WI9i39KHFyC34czu
L69JaFU28OCnbkCBNBiYfaEm3qDRGxUMht6yKPq4ESicIjHiH6p8YQVWyhkGN0vdo4e5IrgNPlMs
SPa+sTe1EL2PVRY0E57EUH81D2JOTVAo1vAEjvwocTcHDnQvY3/Rs95dQTnFNKUm6ENXxMJkQFCU
uqKrUj9UGCh01P5+EtbimtZyroUJD73sg3cJ9vJJSu0K+fJ4Ss/FP62bkALg501FNI0dFVafxXv+
OIVlsJR+X9wlC+XYK3HjzjjCCIXvGRT3XbUr0CLDA1vADGe22y0I3XQHGej6rGPyMRzbYwtWhoWY
l9v+Me4a2rPus+CZBXkEk4hOqxDrFVKArKQT8arG+/VMcqwyCRr5EUSNaOPjHetZEQoSDcjlPfnL
uZP83WDa9zuMdjK11uo44NJayF8K11lnlkQRQxyOQgQqg+1OmuRGorXFFZ6Pdasjjpbfi0N7W4+c
CcXXeMUhSc8IVbpskOevNx3cZmqH0gLuaTm+BCk542Zmg3jsGI6rRIAglvD4uyU6vT+9Q1KIX9rG
7PJOiERaaqc9n9N26E34Klz6Dll/wQzzSAi4Mo/rbeJa14TIQVoVoLAYRF6tLDmv6IFRmZKi1SXo
A3xmETwp2jcJCBrIDWUWthuxzHbrKoC00zh8TGPL4MGjtyrBhySYQJYpv+9nBMAhcWoQFcpBBgHA
37lPYRV0FrVYvcSSWB9R+qxAglWIS5xzIhj9XBodRljp3LxuedVgCFFAYmfJXYFcbGhKnuLsVfSl
6yref4Y7rBj3HLOQaxy5gUlXLL1cEAJB02EfYGO09gav3+iuD0y8PUNtzHF+mPGm6ZuTuGOwepDa
ziG51GtwEyRA7EXYE52WlNjE6izUwYn7QJWX+lna3tmm499b7yiuW/M7EH0FutXp8lLgkf8NOiVl
d5cd2wsaQxIGzrf07X1zjE7c43WE16y/VF1iOyETdFbP4oOnNk0337lkEfOZKId9a1cHbIr4LdRS
8JkiuV8ZGM5mHkqfkWYQokJPxVfsn+x/0YPCfPA+iP2QzUsfQUyvWtYwm1kyUAaA7urcQoWRvnFr
klnULvOMroQ9sKbSKE6sFWNVDEaBlzGaQPJfKvoNlCF9tAqD1vjcECoyQv0wH1DdJxOCPQ1lYA0b
yjDX3wVa4T/IJ8mdKVqOy0vujIolMV2PiUBJKpqOTz+gRLeLmNlaq6rsDWaxZvjl6tUFWmeNO81Z
xhAsD0CWOcxK60/NwJhcHZkLhIh/Z6Ay92ruNnVPxow7ahNvtvQMPcvTZ/UxMlDEBf0HOn2ACkkQ
Hxp/3Q4+YGF1B+Cp+WtNY0/vo2Y+i71ajz+kyaQgll7Zdr5tqTfs+zNWBX/AylVaiM5hl01Fk6Cr
LpHZOTwFRUHzOKnTi9w8qtM+JI71CTOHkVjUI1s7q/H2C09VTfi3/v6wFXX9jd0G69hUZdVdHChe
GIVldAVP9ey1XnAtDVZvuvl+EeHSGYm0Y1CM8iPfFgAFxyBFy5jYpWirOFeHj/qR01+jI2DEoHb+
7GAAihxxtN+PayXPu08kZiOGYE2e19AxIjqpuHFh7BkJtCJEZ4CS9AbiKIUjgvI9N3WYcZg/Izda
IVvhaWSZn3UmssEeqDM2FLEni6vlaanMdSLVt9x3jjb7Wi7IuSwiQTvNdURhLophTfmYCiPJUsV7
j2ZgO+MN3FO0OJECbqhRobpmzJ4BYUXNtTwXUK5O3xQvWi9Sd2vAQWZrAxCSj1Em04AhM/HuTlor
GQTcPZbGyG9n+D/75DEjvnz89vokewR2XjLVKo23OBL+lNfvgs1eNAMdApeaAtmtXFJj/Wmhvvru
7CibzrrOX4K9MJDJweBc4Tl/t2owiMRAxKmV/vA6KhkKlDsTkg53oCXU3o/zPaJIoJXEiZ+cWToh
vPSxBr1dH3Z93huwVy0wawWC9de19S8ZAA3f1Oc92Vg2nl570XMR+JSP31/GO03ffDOhk6dtmF37
RL9I8gMFU2w3xdBMN1KBAIqUi3dV3mzu2iaZkzjEplTF5VIOH3Y4uNY64cqtcwYAbN9RO5B5H2X5
AB2YMc2AAa5sMNpj07Ci8NzZJdADDhg8QOluTFvN96S65VXMXMkHW/uUwweFT0k163tVZ5R3UL0r
a9EFQGHvFusYcT4birXXxNclijZRgRPrBzjuOuUiY5fy8lqJR2cv15YpJkIkm6p3KLtoAcy6FoRJ
eXWvVaBMbp6wJ04A3t8lPdA7CholOjS1Shpsjp3/zkZGZ3/0dTS7oOIVwVrNhbF9xrmVl5+YUsgp
AL2UJFbPlshYqHINml/AYvFKOA9vxUax7vUDypUU/gbi5mV8Fnd07g1wuiHjsps/0+3FdVxTEuyn
lLulUoSvHccQfHaNQCH1qHGPR8sayXrYMGC+XCKrhZ6iLGWYZzpC4WqjTqLwFHT0qM6cBYlo6znB
E4IdflWK6XCwiQ3cSgJLytE/CCYySrNDEYVqv/MVQK1V0dM0xkTyCkEmHWF9ZeO6y4dcAHbamftN
SlkGTxpttc6AssvB3L7df2799FlZE5bP+z+RvTvNe1dinhmY1ep7e/zWZU22iJ0QbkeoEHaIPpWR
3ti9eNYi1JYYi1kxZapW3R9ZMsjBbXZhWqdse0XV2V/rKRQDlNPwmRXxn92arRwJzXwUJKlJMOWq
IhBmHXHE60vDJzv1W/szsTmhypAfyUtdXh4XB3PWT+nTZ74sdMpti+cpjbATjGjhm0oC4A3yR1ef
CKKWiHZPzsWXWvrLYRqmLrt79DzTvf/MocWOiIdFKopYTgAwz39hREMAO3hofP15u5Li75JpGxw4
kFWdNb4fXJM0pgq3zd+RBV5MmRk4CCnNlh3bIFNsHMFxapkW07QSaBWJfHNmcb1Z5mCBiUBvFGcd
OagSi7nsgKLfYZ33LGXbeI7Jlz1Mpbpar+GmOdvSAT12h2oxIbB7asnHUARf/upTwlQ5rVfoYYgV
BBj6i4nRn7fZeM0j7OL8YTKWifB11FypjzE4L1lqg31Kz6vnV8cTYINLYkt/5gGfa0ADLqPVdDOU
xZYQsLQnQ5DDMOKQw/XIfJcLV/8/TIM1FmGd3JFcrLI/yGKzrkU3KGC6BbWYZrNaS41nL75u9e2v
LXk0VgsB5sh0SSgKcsMowdAtgFaKxhHG/72zVU5738eVNX/XvTUdSnoDp7VHFM7hlAZ8uBoUBSkT
sdZppv+C0nryXXiDAYe691uMsIoaeTXmu91W3roPRGRYw1Gs8T9T3cDzV6Zr5XCZNptLOHfzkes/
RIDtqVeBYIjfT2qvnu0Q36KI6cju0F2Y8AGqT6IKlVzAr65v77GGYmx0K7l/Lz5k2Bm1QuqnP9JS
NgNFqoVKHjhSATZEo2TuixnGpUWjMhkSpHC6xC1vy5zXMc7JiUonsnPB1n9s1nTfr5ggIdtavX5s
C//raY7Zis539murrEgcDj3rEWyidsTJjktic4lNpHRNxicanpUG91mDhxrxVoFvEFi6Gm3zE/wC
VfVE5Sgho3GtUzeYrGU4dn6Uc5EX1schqW2MxWkeBrsE3Tg9igr3NH/BBvUi6/1grdLfOuYULrP8
+yCubmD4T8uLUxy9/9llW/XVTax33gYCbD2zlhxH1h2GRZsfpx7b6T3ibF+bQ7MCxZAKGLUfGVcN
vopNqpiXavjoDty9NIFDBjAUydF/CJh1eoXxPXyULiEtzhhn+WkR/vocuFaerYPkde/fWQsBL18G
4NFrY3YN5fXWcquvRDRi39JY7PuQ1TNbakoX2u9miMlKSWSj3caBBE1VVH94IXnB429fVijlRQNl
cJPN7n3orDyelZ0U9hxwHX16tFbrVs9n3Ptspbok2yrIzazs4KMXd+4FGJxQKyhLOkSxHiIwiH0S
n5UYY+QDAxpHq4icrd6cj+FB+daVDZI6hcNRiTv+pqrqyZS35rqoQ0giEmooESiZgz5J0LhZPJ+E
2JKipboSR7gvcecjmIsLtZBuytDh2FYqrya31Ud3ejuzEmCCQ61hQ2ChcHQupn0z/wR7DqatRmpz
dEGSHM6mpeNgfndZWypLARUnRJCextGjedaVL42iM6DpeUbHLsht2aOgcgxCGk7CkeADwzMSG5yg
d8nxnQBoMnbM+eMotFiW+FZzwPfY/dwgFfUf8ffXz+PWCvc4R5MlqfRl3tDdiztX042dpoOX1ljP
MlVomJgXsBxPa3j007sME8oAskhJwrcj+RuppXEmmqNM58a5w3D58byiKi7WPlFYpCGzLWp+bu/C
q/0dsjLKwrGUkPP8upQ5/85zGNPt86RAygLdbMmWC+AQt5QnDE57/NiT6ZcKoJRGb4RUcAbN8Vgf
iNrhnL8my2bm9esyWaPxHeEssMc83oqqtA2kEUF0nRnCXjj9hyUMuvQs2UIsa1eDsWPblDV6Xa5X
o2FBKEu1NBbGdJC50KEyT5BUEPEFSJQtKteCXzcC67KCTbvPlv91CGF9a2zfPKM5sA4/HVdH+3gJ
e5Z+t4RmZXN9hx6myxd1rJbfzY8cRpabdO18ybJOaOz5ek5ML4kwClAWCecC6KqA/9/Lxijjf4xq
DTdW/o8uz79GeHhz0Iu1LVPBZr2sOz4aQDqJNWHRvXhVtmcYB82SBrH57Mipf0koJuh1bygrTUJV
VJ0ECdbeFZCH+PdbC2ZyKNmLGuAYL6IOcipPnaeF7vs/b/aLdHPhM5tprAQdbEuflbf7luWv3KIB
IvTIlWS+bHJ1ArRE9BegqAmZVfl0ovWRuTj/mcvS0jM8S9aKAO2yF/8Ei2lc1wKqAKIGFcAduvcL
YWTAiHDclxVMTOqa8RfLOJwojPLOL0Z6OTYKseAhcQRdI3aAhs+yG3fA17JMkazFkENRqic5sIBV
gYMx1p1Z9wmJzTmVRxBux4jCNiuUNGobkqJ1RQ4DHjRfbt4E6coaWFGYDrIgGDhnlDfDjfxP+i/e
GouImHZyh9B0pPxxLJQnf1iVCx3PkxKpS2H0005TFs/O3dnde0McAd+AFc0WMxqm1FJd5pJuPu3V
nsXdP1Aj3rjYaFoXNdZWS3kqpCLf5Mx5fHTSL5zfR62xPEHCQpHgxN20+Hc6PYgGDkZtj/csen8d
IioZOS9oQWUykDP2bS7oZLPyJW5RivTY7RGflzMF58oL52a4nY7Y8d2PrN7CxwJBkDsNqrbGKNr5
3n+TK6Le8eicFgdo5tiEgdNOTgBtoTDFBOddKPBb8Y74zfVOohNZuojPSfnZ2HIxNEHUvnyUH8qg
0nrzyLiPk3z2GDMx5TdZXOk5huAw/82nImHBOFhOP7PXcAkCQqLv5lnoktT+eybVGNKD1J1ZwDJc
80CMuf5NSCH3pP7pBE1mhKhtImHtzkh9n8vxKOZJcc0IqGuhWBk6UCIeMyN2oBVF4/Co74nMr3fh
0BlTGMwP3+xhrUNWNd+EQxql/sQQ8iBGPo7H3msKIRKZFVuhJFIubSLMHURO2iWZYmt75TdmOp8Y
iGLZ0p1zkfb4CicWXmdW8ChVP6GWddftVSDRVnRtriffL76n2GbHIsYWVoSMKMqzJsUP9wIKUqFH
0Nm/U625i7Cwpob2arW/KfgCTa2cL59jrDNB8pyXvmXb5iIDBukO8bOx+peBZlbh9aodoHP16uFm
D8kye2zCafvghmCOhfs1g1W0Sl0W9yhzDYJMbmGhgFJIStK=