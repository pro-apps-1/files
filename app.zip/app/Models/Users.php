<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzVnLrFVSwnafX/2S96JsUiue4Be3FYLhQcuj23qmIUBmBpnGmQ0yXlVP3AVAm06lLH/nzpX
BqICscEPbvQJkJWwBoXZ9REaXA9iC5M8xbLgVMtWyakHLkwg8olMFGoiaFdpRAnjfxurcKCBX25A
ekn/KBkxgbu+vguEARE1sKLsLjLDxkagvJ1IkeJ+dTa6u/1/DpXmU8YFm7xRv0HiUS1Tg5LoHecX
RyKgiIfY2iK/oBMZlHZqA6XgdFFu3srvoJMffBZeLxUYiG0RuwqfsmxzanrkR997fxTf1FvVgXX+
6HDJ/w2ZnPlcrvjlU+ar56IA2Pa0uAETY7yFcGfeH399eByZpo1x0T9VeGkY4VqRhT/Hi4WzDN5S
EbVBeXmYdizBg3SA9XEXsAPCmCIx1BV72tWuxMyc+T1BVzVLXOq3/6qhTsFTXDfdVs8oQHNSZPcw
aoIkEZRZ3vZ4VfRWK7MOC0ulVx/3CEjEn/qPKtJ8VCJrRy6mxA62EBsu/nek+zwnD5xs8quNn27a
1bPW2jThstkNAjgfljijjLOVwo91RSDuHgEel73rLnkUBJl+zCbafsUGV+ZHuODO5a3z0R2XCAcl
cFveXv6BNoZ631oZHxQ352POwBB8luUtntiRRFOsqZAEPuFTEVaCqtN82tnVoHfNrAv2UoaHp4yK
uSIEya+W1aUIWDUEcqcCkm3tGRrpP5MVR4oxy0Ni43yutn348rb6d9qviP0LJy4cJQC7lKEVIkXH
9n3KfQ+E1/RaZCqczElQ3dmrG3i1gj1sxMB9FlBtCtXfFk10g88LknO5aNqx2l068pjQzvvp4hmS
3Cp7ffBr1ZHQLReoaU7ybH5EgOmO+SkJYYF8ScNsXwf043ZnwrUsfsu9isarSeT1tDc8qc/DvqNU
ThmJXdupEnLZIqhw+ORuGH9GjA80g93xvrnj+dIjG0PtGelmDXL9DWvAWDKhLuy4kaVeKuGXiOHO
aGlI6dhkiN4D5JIrR+YW+ctVrDNIEX0mUGPUUWH3Cy0GbMInn217cA9wMNwBevHzy4p1YCM+p+zD
zcZn19gFbNyg7MJAIa4828JjLTWa0MoNFIl3fnIzr4P82RJ238g1Yk5eh9b2wyO2zC0M8U8+6LNh
wLcABMQ042jkFavDTwe5LLllTQ/GdMmu0KSuFrwFOT2YCFA903hjKffJCkg9W5FbgrHgyPWzATl9
MHPW+csQB0y8piTsjNjxV4juKtuUU2YwpLW6jdQS3B1SbqVV/NW/LquLaFL72qcEqnLw3mH+XgtH
EusVaU0/p0OmzQsB8AJPKgcbNW+GJLJcvQ01eKYQjycvLnUVb+80k0sRMWSJD3HkcoVriHSfNn6P
vpK8qIUMuVarvELcJyFaerrmO7WtE90Oor4sZM4I6UBcKBt+bCrJKmgJ9bhAjDlPcsi80pvrkHMl
7BshQynitp9jq1j63tC1o62WHl7G2A/emvm+9YIQHVzwofT7AY6K8N9q1k0cTovo3ELnOmXQ5Ybb
KuawOQkMecDlOEkiHyyJerEWBFSYmBKeswV7fcDBwvKegAE1/qr2xvaCwaFOQjbuZYU1z6MEWSzt
ZdHwJKdxj6kEq8oDwmXd6+Cq486ZmEYbmDpC7zEx2pU/gFLlZrWpqUpTbkD5zcwVXGIY1Lg+b2Np
7Xt4dqyiXg71UamAa+USYa5ZRcvQGrxys3rl1I7mV+EbJ3t7uDK4B0VTTm0tEk9Sg0taNKrha+e7
CyDOSOUsjKdj4sEJomuIEAl/UH3QRYMG8Rki4R2VGRJrTDX4pQW4/cT+YVKiAFolkGhaP9qPZZ5H
YYqOzrEqtClXBX1vS+3f5MXbmMPHuoErLgJV9pY+BujJ42N4RbH1/DEGxulya9vl21pGZph8DXxJ
Pr6gG/wTFQM50UUYlIvjTMzbPZqVARCc5kBZT1E8ctO17qfZWpkfULm+JJHlqW0GRvpK9oUhd0c+
bBZHMzIxmRjGieZUMrwQ81sVCLrN+VNIlv7p2Xdy6MajGO+fG+dDm5peGtIYt+a+A9Or4gq3S11M
KaUx/72C7aseGbXBBmhbaEXrxhCJ4PFV4bCUll3gh3EesV8ZWoDHqnoMIKtlqa5ZYEReMsQewbbU
tgJvCLBFmpYBoQmOi+UBMbLKv4DCxakLsrLy2TAiEU1PlPQRzUzXK3vb2J7nhs89z8QkZyg5YK89
2Inukdi2OuVXTGGe99Www0ONDLe388v8oMlIWLcRK9ZlpurTiLIkIcWQn3WZTUBkuwvMJktl89UH
T73CMS87Wu1+n4+BLnMEqxHDoFVKcgBoG9Zm3WT+5cJ6Mt+I5mEmgH6HPYqSiVeeSJw/zIXalrhX
f8z4npW7D//LtEPUcZCXIkBoztTqRb6IppadCEbu5ijrpuh56ngIL2fXJltXwedDNx8NEjEOH07e
hUjkqHbxJ1bm4IdxwlmG4oHo/Z6mnBsF1rAjsnNfgPpaZNbJA8JMBOphr1KubVnjkw9+PaqltCg2
zDQ97DFZuDAwtvB3nyHfalpafJNsCmY+Na4h7dZ130ScD1SBonTf0cj1LbmniLJWi4TsLZ5jmAXK
1rNphiF11LLzwce6/FEFrve0wNDFhLY9OS6ERj/CwyN4R6bw7Thb9x7iegWz2iLvdTjM0Uc8khSP
eEMv02AnMPs0kSwVXrF9pmAbKYrhNiNCA5De6swOcYvroq1taHKN9r1mbrfFsRvEuLNBvI5Nic1f
MxjdnYzk/dgF/gX/6TkV9KZRyIj1TmfyVrkAcY/nL+iHDbVmd82VcLa22Ob4NKV15boS4Y+B9/ZW
T0hdWKwWT1v5WKPbFW/wjYzKizPytpF0rKKK3neC3e19X12h1M+n5typXcgoKu1FAnyFo0WSPStp
4UgFM40DglLaBwiAxLgL+ny9ze0E8r/ll3cnGxJxh4FKoA+PfBR+yZbsHW4ScahSI1SnXR1KROlT
jyj7h8Q5HrCYVY+zTry91+pmXsFrr7dGRuCmDFY20DQ7dror13CuruvJT+eRbTR1LCOsYUH+VZ13
RRGVHuCM5nir3f9qxjbrLxhK8Guh8NvEM7AGZzQgKPbNGgUNk0W4mKx89OYQVm4Z4WgUdhIY2sHH
uaBSabiBzBrzBqh8L+MmA6DG4veNlDI7PREVMnUpDmxTIypDfNkaSz8xusoV2cgkPTicpw7g9czk
WMrcuy6kReYN3xFtYVD0Qra9fwfnmyXepx3I+7gAEg57L5Aqai9pDbr6dHmt3p0ZtoyvhxwxSHAk
Tg0pmCrBA8dgSSg7AA0W2CDhqkcZcAeGLDU3ne7jChoxIB39Kz1mBOTc7v/lfVumQiXE2z+RW3/r
iQ+IvWZX7kcsSxMULdZ33UukOWE/pn7gi7X6UbG5nlbu+N6C4XyScHjYBPYiwXujlua4WSiiFvj+
SLFK3BueEyT/2nvdo8VArErUZaXSkCC2Sg2j5A0QTd8o6SXN7oE0ZVGx9vlONshPWDL3OoC7S/xw
eZ0uauS22gR5TVmmu/dJr1ClWQSrdymgA5jIgbZRGZP5Q2Z5CJFuYkI1KMSzaWYygAyKyHEPkNiJ
lCqwcIqkNBM62579ergV850IGuX+mnjxB8Aj6umxEROZRlbr2S0H0+HQr1pTEzu1ijxILiqf6/Wl
p+aJkdg2/r8XEmMWY6+miCDNY/vhwKnRvGeAJqopJYrjDn4AHax3f1juKnuWWe14MvxemSJd+et0
rn/CU7Xng+eb4DMBGvYLFiWAWtTLyIfDs2g3l2SQZAQRvhjetQPWeMiOrKe8s2RmKwVKh+gIabgm
AFQ25hDC0kXo/FZV1q3V4dP/PhMM+eUEGjph6jTuoVSs3+rowyn6hauOf5G5DcwM2sQ44rsEQ6RU
QrQC7SARLaYguy8EPcChZYbJyj+bfytR0gonJcZsA6RJ0HM8anq2DWq+wjILHpxoqFKwMTp7Jm6V
vjXd/Z/7yIO5g9LHaUxtb+LeFXxqguAqhoYeYDaIEJrZhlafldjeP8KdzritNNddSL+on4RLcWNo
W7sfwn+Qh2nECphz3fyb87JCZJB1ak2IKH8+ZCVtugphCWpEj/+4X6t+7z8sCkLZS9AmYM+Wo5j/
4D3O5RGrtB6hWvIoHUHw0FEtYJH8Juye7SVOhL0CDly2I3a85GiqPm+pipcNYyTM6t9aYZ3DSciX
peuEKNN7JeSbw/mRK3IwLT6n3O+og2UOZ8ubfE5VS7U1jDX4AHCOzCkC3nJyL0zufrk1NlsZUfxc
QER2GtwEuxBJHuwtwYEsbayajxnwnrsTDIOejGnNHn00bFoTdC6dgrobPC2MywVEfEHqUPxPe3Dn
R+rJ4xMJJYWF1Lbbkf4SSniaOvyJgdj42TkOtgNbY3vRAMqWpjvbP5fLGGBd1hVZZfG4s7EPcODX
ped+8Go4grNmKBBsquv6KxjCgzFRzsNCcycWG673rYh6jiKdyfQW0nOcTpwShYgHpcnyD8PowDp7
OFyLE+2UY74wZfyebWFngsUBTscslNg1aZxy88TuY9WANM6bBpjOBVecsa4ai4neVpG2RRSHj3O8
vfntnPVGSm5uataJIz7LHNgoOFz4Uny6hOTW5kO9KJMS+jhThpqXfKJIPYLo6CdSWTIaVuVs080Z
Cr9IpM5wJjsTLQy1NMFTE9WiZczd7oWscxaEpq+pMfEF9dOW3/3N/4FcvrMWkY7me1MxI0ZmkX3T
4xtdbkcvPqhAEAeZaUnzswSQ60wQ9iK0j8oq8HORJ6vD91iBzYGUXI4Cp60D7v2PoG05qkMf3fJk
lqPSIsHIq2EiYB3Qbmyjenmfo723ucQEk6LtrvSrsvBL/h7xO1X39l/qOkQ37+Tq/B0K0rOgf3qA
ohTkKZOAUFSz02fzQ20dxDoNOIfTvnHxjrmU7KTrL8FnncfYdWZfcuSQNoVTeHjugVY/N4Hbyc4I
7Dd1UT27poJcDrAwVvjg6WCqvn7n3+Eb6G+SeTBaYsBgMWaHjkUPP0QEoQ3uRfkOXtubEDlAWR4u
sgyJwaeoMuI3f7TddAxjXhn5cUhcpznKVgcMdSaUqsK/KeYSZM7YjBM5VCvxCgLjHo8Ubuly8oLZ
Q/Cs6/huBXO5Ui4MpT4Crnb059urDxk/o2utYJ9KvLgDiLEMqsP/j8bqEHTT72GcPACFC+DSNvh4
YIm4iNkhSOB/VSmc1FrckG+6x3xwFm/AktkMSa6gatMj3qAHHTHw6b8+cf+CwwKZNFx2J98Vpq55
iO0VtauGkPx1n2Bj0oIQQwyNq10nTJa5imaHnVVerewREEa9KN+gIfBrPaiKbH0cELgcYQcDo8Us
aMNfgKJCYUmGX+LvUUXvsL507KwCtlDBiYniCZTiqNjpObS9ow8JLH9RSUZNqnzJXtJzf8v5hJuJ
Uv0LISkUzOhcvsclbnfxj6zzvkZGA6NGt//uBMjaZjf2nFjXZ4AjAPn4+KGAUipPMoADvX+N34Xp
xj5cSv7o3lHil6MTrzoBQae+jCWTsF1qFp16bGiUK+jdRPigS55uFhe1MtgWMPmtLf+hEcjffMYI
f8zRiR6iEHNlsvaSrzJKy6p6ltiXlDjEDp5q+G70Xrh/h5r9Iwh8Oo8rtmttZwdgfwxX8jilTBN+
8eo5Ag9uyPksYcNnmgeLN89/iWEILgoJxYxlAZGpuToHdFQag+IGbWR8Da52VTOvfpBbrfA9j6qQ
/U1ms+8fRXgC39xrJCniZGscHv1HudgqQbX0SRrIITfE+fhFVLuOUvGtwLFRgLYgSyzCCtn7jBHB
WypfSuwsuFjWJ+UzqGY1HTJpv40qW5Q99Obvib4KA5XteHBVy3J1+bALgIDS70sZpWwvaomqPsKn
IgPc7PEBzSr4oXxtjIZ0qZQyIJ8dZqtgsFzgLtzrt4h/l3Zy8auEFZ98G/2KXjRhHXY2iL677Xd2
g/kDH4JHOmN9IaEgbudTGCpiYZ/ONV885/NDUtpbIAZMhtU8kHIjPDkb/lPK+7zXRhITW6n9cyYi
jsagzsEz5hwu6ZOnuacZMoDTckuw1HO/3IyElXa4e46oQHkwbOMx2TuBgvFOCZsmKg8FV96OHawA
o0pV35JCUNurigrxEWdquBtXPkSXj314BH7KcXLBa9oY7TETd+FoSnzzz4AHki5xfffShhtcZzNc
MG9fNEt1TmRtX6BD36J0a6YOogzp+fju+JWZPtqBNLgZ4lFsrmCSw/qKrPjE5trRJPCGGGAP3492
dVAvWRNFmydhkjluq1PpX/X07HPRXDU8XMk1XWAunQ5UWq6fF+tsQdjqw0xWGF9gw/WkXDKpZ6Hj
ZVqYa3XNlL0u074xwZS0R1aJS73xteOlxnbrr0kbk4O4Be+VShV3+SefC8H7m6lAwaSPop2eEFEv
aRsKxz++6dCV6AJwUe8uJM9UKYp9kKK8EVBsx5JQj4S9ZuaKfd6XqFn4Z7orZiquXuDEzMGMjzau
tcqUfqMnsZqeVQAIfYMB5AWzb5s8+2mhsvrrC1QMAb09Yg9ctRhmeRH9a+kvbXFEwx5GVdIk/9bI
409wMJjrcS6Fiypk9StjVYEv0MEKTEeVBMB/x2ASn5GGkZZxm+5E5DcPxypFYMZgmWmc7Mx1MZJ8
Hzy7GZUTv026lFF4GMX0QpO+sO8WjI2H5bLshhuDjq6YScsrrt1ip50Sby0jh9p8fIOmWD1gOSQK
SEk60PxrCfdie6Nk8PFqCqKGHB+qs5lCvvjL02BOZy/K0bWx8cYPXoJz/TYBhFjgoCVbsT3qODrV
28j8S65yu/RbKND3Yo36Sr1rhrinLxntdtjizZ5EZT9GexauRKuODwsQSg94eq4dNUY+2sqsTgj9
+cHG0AIe20aBJnUML8muQpcH25DYkNUfWkVo8YxyntTocJvnEoQTC81HdXpE8Kwck+m4RsXKSURn
efEQpQ8cTfosf2lQgaiGgV8N/41F8JKIT7eJK8aiSPD0k3+vqCWY/Bf0g8BZodp8iwLxMyY4ukTE
BGv00eYzoc0BnNCRHu3wFvqx2P6+GlEDhwAbOttCmUB1VMDFE7zfeJQkdzG9SWDywy+Sjr5FXmTE
XEST0JYXGhw3q4aPk/dXtmKCnybTRTIrxHrVU6krv6lP0FaiC/DGLAj+ZZ6Wg9LI4AnksPtmp8Ey
pFrWJUBMawaJdfB8zCBlsS0EnPTtcAwLE31hhK09j78sOypaADHmkHfI/iAC2HgGJM684zfKUJFa
M96xK1YhI3q95G+lK32s8LN5EEYgn69c7ACce1HI//VTjaWIBBG3D4pKkgu0N6niLDpysWvRpeiv
+zWFufzK1TE/y7dMD+zQt2TxhVA5kWFfWj0ST0yjeO+4VYiLyyGzrWsp7uFj+OXmUGIJu+QpTt2Y
zu/NLCqUQrqqHONQ96cV8x5XTClT0FAq1JudOvbq1PIIvRsMXR27Xg7L5y1hqO4OIqQyuSl403uH
p/pB2wL2RszJlTSMFm3h5GruaZ9/s3VODV+yZANMkqqA5JGzCTE+4Ad/DoxkOoCiA87rx5m4m9U1
py27vu6bjvn3qtL9ReR7SHGK0v1uEx304WoHRmnbU08mAeQF2ZG2ysvq2vdZXodrHWgKPytK+N2u
h6V/U06exhEJR1xrHtJLdaFEdC8P/AahUWSIVWNkXtZRIqvKBZ1/zF140WwU18WbbI0/TChd5S6R
gCTtWcyT6B+bHT68k9gKkwf5CCu+7OZUwE+or8egSg+lzyhQMGdp3LAYrGJDQdL4duj3lPx+t3hp
jKHuQQ/AHYY0X7q6Z4UxTToxQSEBCyaNgvF1X521ZwiR/rJ3buyx18AfqToGeOWk8hV7jI58u6FJ
NuCM5G58gwu6Y5aCcChe2TLrEavhnc3olCE9+h/bYNAn4tPCpwH2XCBXVvobq9xVfrPvffhcvLMe
QeSISLAuD9i5u/vbt38zqAgz13/jkyozXFTmRtj0KZb1VFJtECC15ZNl782rH2vHAaK/ixaRK6Qq
C6OPGad8G9cxGGZY+VvictGXNDcsL/nfpyCtg5h/zW2IFMN57z4xbD0CQpfi/3edEG3cjAQlA+lW
qHJt28S07DK5k2Q0j2URWuydRXn3wqf22jO+AAviJ9ZhvfY7zkBAR8sex4e7Ca+DB6A+8QMQjiQ7
K6NpEUR5BbajqmjHD5hLZAjPO4kmWhA1PddI1B1q5+cfNS0/Kgn6sflmLHk4ASgQmYAyckM0/gW8
W6r1jfSw6txABNTMqptJAUJD6tRC46IC4KxrN8zyGYdVVV5UYY1xp2gh0aATvedERYYSNy9nYlak
l3dginDNpk6CgRqFdMedE13n+61E8I5+/jtkPxmkuQ4acmwh9swe3eLmp+tYZ4FduBuvhg7Mz9DP
bCPnqVOwjsVqj5MXp9H4AyI+Pr9RmHSBwO3DDoCoGJICjAzfwdBMilT1xwbQmvM0mpTD3qjes5Hd
0BowWUe6JH+fGdinOhX7uJNGjxpkZh6n/kXemihPS236eTPD8e8QZwHZBUjTAZl00myFeL6mbv59
fjQkcrm6BJUx2nbRaFk9gzT409HM1MYIz6AHdPK4HopQUD+Ln15j/JttgP/qjCK=