<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+EQ2oXIBl0FAtIU2w8Knmgu40jMT26yOif9G0OshpNNwLTsJdm9szodD3TU9lXSrTqCZlzy
MEcLkTOva/xXM8pq7fE59O09GBazDo0R6HHS/SKbGgsqXkU5l/OTA0ncmka9LgTkUnMcxVV8g4jR
1yZlxnfvoxLKVNfc8bpVonh2LoVGIiwfmctAhZ6LhOS3qmBCXwT4ob8wgWCtXvJyDV/pGFt2sfTG
cuB61ZqI0sXRDdYogqL/XNRpkJYcd3V4+0ExoeMbi2AXEY+NIVLnj/1LIwfpPt11CXmPr/1e13bS
JEHgKPVFs7rufORP3zEzU0CZgoF6tPAdWz+26Vkaxr5tiP+3mhfceGYptQccqVT1+HB5GNJlm6ef
pVKel3WJDe7nRAHTkEuxc7Y0wDbZjpHwUaNQWC32maaCxgT++OXcsAlSkJYDFQJ6obPzcPz7uobc
xyzluQFDuvICdgKbWEA/7LZv4dZvJ0LSgh1WWFlIkSqGz34CJiryIUJgaLa0PmTXvLy5LXGYSi+w
92RGlYkcOMKN4ZEAj7YfHU9F/1oxTUo21vW8b197/odPjNn2NapyVsJ/FP6/Vq6hCoqRkjNZ77sS
oDtz0pHeLsJeVjCe9GzgsUwXh8agnTZ5uYiYuBY3mYEwubPr6VUK2Z33u1wtsuEA2qwPI0NepkX3
TdUwY1cLeNpXatRMtT9tb7X4obU/0TpAlzrevYuZGNKHjn3e4JXi7FuzCRsm2f6isn6yrC6muHPg
BxJcVFoRS4SpbfSlLFhvrdmSJ4SlCZwYWF4Vpo5epfzinWwMK6ekIthYHkJ8xgKg3G8aYkmnJ9lg
Bn9c5TgAlAhtiXsGMCYfqU0AC9v1AFyHn9d5grLuivPALrx1TODj7t01bMr67dXpLha+IXXnvKVI
Eo63tDNGIzTdS5ead6d2zZ0HdEbM5EoTD6PFtb2FFtrczMzQFPzEBIdAa3cUFexgTHvNG5oZAYY+
d632QfuFd7qO0rUk/4x/8IiszYxDHnJGlP2VSIYKp0EtDdRsMvpoXywM9bWMnyUhQ64Xy6lHa2SG
1RC8FgVPo5qwHTGFwQI4VTRS4DsmLOrpXDyA2AUCmnrwFf0iTNRs1xcnd02SJLAbJL7v8t5kk1Cz
7Hlc0iIL50cLJ7+8S9C3tI0hBqCvvHcQia2XPXqHaEkrVPwAZSvv+0t4zfbwrfTc0gSKwDRrfSFE
FIe0eGff5GGnVX6dNTtjRLOOhCxSTDYFL8b8Iil+kDXC4IGDnM2SC62GWp26GX3VSqtxgOzXbEVI
twImEc/ZZxy+yi/gBw1BV0c5kmfLCZLFZi3N58YdvMHOV6c7ohaC8Gof1V/v9//urRGA0ptFQKuH
qQa34HRn083gx0QhsNclvo3s7foQzEQF3eCaiK71W1wogXWQqS5lYAt3c0AIgwVKK17yRKNmko4N
w0Vu7XSQ5QQ+3FHl+KdU0Lvg0KPmCrHHsu6OE0UZL+ANih/VItNw5LJLT/ZivduONJfobkoOPA0t
+6faOWlIJf0C0tyFr4yl2wcfyk6HPazXuTdaB081jED8iMxIjUtsVhftsM7HAvgqoMEGoy4v5QSR
bc33zgJLpaoWSFxMXFrDXAKQkYmFIOWVROoonSiNMITTEvDgtyPL73cSgZ5BPmIjbbbi5tPbgh+k
KTzrPtF+EUERe2tBlAKImMW33SHCeAr1KHm4VWuPNT9RKSq1oIwJfbgEDxyb5J+WHNIxgPsb6w+Q
Lnsxe/MhAJjtv2tN/HjFeOs+JjqMfaEjdV76jZTTaloJh21I++evwg236274eqaeH9tsZp/QqGhC
kbQtQPNFibkJf78/HuKYJfswh9ZNzyinPPKof6PakAOxbv9m3ekII5eKUeN6G/OGunkm0QxdUlVR
hS4SqUISTN1qU9+KdlkfoJlpqa8hCw3zEECzpXnnxGbOUm/2HvcInXuzmzAizQmO0iDLtcF4+kXe
xem1WCLU/NUfKqPdJpvYEP2y+vVfBMUZwtMounpYOXYzrFYG7bix9GEFY1fGhXV/0LCYz8B0kG6W
EpaEmdGsUAWY8K3VQ+uDq/uIKbST3K2mW+uKmaUcskN9Ynptj6WOr7Uq4mFaRlV5T6T3E4Z4oxl7
2UnRP+kYHgd5P1Y2edM+ijOZqSk37Im3dD6ul68qE0+ADALG1gdvaFvwn1x2PZYrXZwuQD9kEQW7
4Oe8P1hu3r81C8EIJ+flNCW5/s3iQQMENMXJu1Hmu1S61FikvW9ib04FDiWVUWOFR/rEuxm0SlmE
PKc2fc7ik92oFxKteiCZJJFKqvo/Rx5WxsE2JSHAzalw6MclbASYk3K1SyBZqJAvBNcDZSy/xsZY
aTGii9I/2y489OY+LvnZbxSqVyHJS2ifRBVH1f/5C9FgpHkf1d+BWshpR8tMeAC5sm6GBQrsyVUc
C9L0TElSd3cgqnhT9ZEgss4nEcuvSjfxwKk7ojvM6AXV0vPRgTgpitXRY5DRSjqT+Cj2EBo6eOJh
Rlpch/sTC5wSPBoiElHBbYMzZSPGoyV9IKZrWc9EYlx3KmkVJpG8IYX0b8bf+URvGL6o30yJpjXv
hyiV6WcNtxAg24bS1TH3xLjXBdGSjRlEz7xJ7mtOzwBZAoDVXJyJ0TFMyqoGdqauEYIx/zaK8Wev
JWHayE4k8nR1jDx0nUjMRCoY7bdrpLwCA03FZDMDBqYt+MtOo6W3sTjnq5Gb4os7omCD3ycAuJhv
Yat/oBb/r65Haer67PTT6w3rKOKotiiPNlw15GKdv55T0g4b24YXQkmtgSmKsZImpkt7UkaoRU4M
iIbQbeKSpD/aPRgZJOxsjbmf5lhja0QnoZiTQE+k4shn9eib4mAQeg1YsBNhxvY0aw2+fGTHWAu3
4Xnp7pM7wT+Z2krCLp1qvAnzuDCvMCeGsWprUEJTaNXTpgvzsQEDI5S9fsBbhqJCOb4xdQTCLwGm
mKZNRTBGMHspdkcJmH/t/M3EDRUITkCb+aZkg+6DRjiwsVZTVpx2cxnsqcAK2y638hEE+Ertj5K8
DyBjoPoazCClyGaW8rOFEIiNTVyG0N0mr2xXProDqhyJzCb9ghO3FeGJIayCP1O047J1nX5xGHmt
mkKPXdP0yL2R5BqWfz8+8REEvi4B0KWX+6ithX+iXjM8bZwXQAPYirC0vbzDLLWmH01MNd2uZfWv
IqtYspXdURYgbt4Y11plXx9Gu07iqeHbO3eMmxRxLQJcwMXdxsKobdloM7ezT5B/YWraGgMs3UTs
d155STRb8FYq1BI3SrbkAbVEIg53wT7I8at3odapw7XTmDJ8LUNenPfttsqFWcxkvBaBWHRJpnM1
UCQNa/YwOkI3mOCjfs1ntkpPK1aL0TZxYPxDU0/Jb38PgGBZHwlC/HKVHZxPorp2JpPfT3GI31hu
M3Vm7/z3+m/q7D9MTYH5j3rSGxaxLogr7K7YRf65bS9obvuCv8JVkj9GsritTMQARPxMM4HuddiU
xHVCPwVrZKrhl8RSXUQK8ouKMhH66efE3eL2disWRNvKqfRYukPFkGa6pe9f0edkatb/mKKLkTpM
PovgEloKrNhM9XkUwGarka5ovC6P1Vqk5hAYMR/Rsnvjk6Ow38tQ6efHpt72vsIAENniwjMG++/E
vFsc/BG6U7rnfqGn2DCDshniyCG9T4bxXLni3cm76aQUeWs3QsfcQZ26Z1LBPzFS1kUfH2QreVdd
UxjmSQOOnIqb0TKGiRwQ1mR/4vBctT3kyUTa9W+hTnnC2BE1Sm3rLc/SZ8bjzbFwpJtRWrtGoAj4
Bk62WiEyLkQRjHnHjPNuRjAogK9nKoOWb+A3Yq8Q+oWzTS8mMfyTQ0G9aq5/9bxMjBCvY97RRiAp
6MkM7ixugJFA4CbQ2XTmj1FgiLiOmUqKdIXcwZqCjWuSbcrXe3BTLwSazHx/yBWUPtGai88pjGTO
sgpecBYbWwL1vYwQpVls8OBvj6ZghIaYUz1Hylr7yce5dMGbQgwVpOvYuJ4FPC7OF/iSvVOmCiHE
7cnlbVuB9Xj7K8zP3d6dI+BaZwxcnY15kdLxRNw6jE8HNyzt9JRwoM9g6jhDuB10N8yJQsJBMKwA
+ZYqoHHVucZ/SbzaNCLq7JyfGw/I6I8SWx1S1lrO+N6yKmH9JW/+ZRT1ILGADn2bb4nD2yQYOd9d
8g4iA5Tpey2TDE+Dym2jWsCU3CEbOjX+hlmO4vNZG8A3EriPLMy7Om+sfk6hvTYcF+4BL1euJReo
iZEAYXp6OhN07816qeWYo3x4BnHF8Adhw7UMEGtRmsWusf/JVrLcuelVjmjr4+NJvOAbzZbXA8yk
fMmJB+vv3ME8Kaef4wVZggRHAn9VWU4NTYxrlw9VSW1rgJ1abXnKmm31RvdNpk9iSfOP/vAZiTYY
VgHi25gUuSuIPeQ46STzG4XlQTvdS4aKhqoBo7fcH6bMOvsLMPaW5Jy48mtVKc7D8a0xbK7tsO7e
EFunM/NbSkeu9bfMVIe1DcBELbLBFH42G5IVG9UfN6u0+KJOD7EC83sbc1qYfCT2a3vkPiljf1v2
d7lglLA85VpJw46f3YUIcedkQblF1mRwPigFoTp4GyTfqjP0DKtDqkJUVifurzMBZjcz2ZNPBtlO
O6XM7ehKZUpl13f/l6Lf26sIsOQPut1bJEAD2XBvzoy+ZnO9s5XLfhLaYvrzKy1/UaOUZrhplq00
8ntbQZAq0qsXA4WqpGKpy2GhIVTtGRObV6fsccMDnC6ExPFxTCpKsLX/R17aB8XEtuOZZszVyAdf
HShQAfCXgA4IurHV/rDTafa5HnthptImCVU2M4NxsJuUMylqOo0W7qGhIc2bn4XPc/R3tpGJs6oF
UOvS08mmELeEiAK2rzPN0DjUSbWUhyo5Dk6iRKSQA55cBIY0GFs92TzIeKB87jRFhFhFyHgYIs7H
RIG8DIa5IXfYKOchahdG7Xo6iT0T77apkM22D4LbXbtC0zcjwiJ8I0rStQe67oRLQJ9LYA5gGxRS
WrQLWOxGP2bqatsUoZxpo1a5Rr0fUkAJ9dmNMZb+ri0ecuFionsXK2bZqjXTplfUxFTz0rVNXpy9
wBMT1asldgy5JObtZttssHL+I6n+74pFmtBSqc5t4tUxU/z0NSqGymT6U+vzeGjLOVVkEBy0OlDV
ZNKkxvvh3r9g249GXzgLGdU2qZy56qyGE0yD62wM88HcNraSVv55DLp/PYWOTDn0vJQrkOw8u8Vp
LQuJND2kfnKjsl+C0gBLN2FPMljcR+ULh0Bb6r4OtzI+DdDnH03ruGKdsrEFsDXdR1SP8+AMsbki
Qso/3LCKc5cuMtFHW6C9cUffycLLyDfcEuwd6MqRScvid2USiTpV7dpu5WvN1YqukF1Tuog4rBKU
1gBYY/paNl3xfLcW7E10C6eHMrRnf87CN6C6Ur3I/1Djp29lSeElAuOnFmUHwzckgMMRDuHTpFpP
fN1ws4+LC2a9GTHz2fSx4wgjL9n5pemkt/6BjSQ9vBp8Db1E0bUobg3oRls0kryhAUZTpAXvwxum
n40GXYOx9DSwUgla9fmJZ6xbE/tuKXdO3O0hIIUh0ndH4wUNIcKr4pBjKNhnlcoqX5hToaC1kb6w
rc2VBObEnKLr9iYSlNDLcAVx0LroVtCi56s17wPsQHoMrpYOPujUbMWN6OvRtRWId6DufvCdMRt3
mlwjv8YKyKnYcOm1z05YEiQnuRMKhH+1GXEa48Y2AimRDKVyyx4pvEhjcOBIn36myh4kHqMRpCGr
kWZRX4C/H8T3MeAxG/hM6BNzPCuQmbqmakCXzOebKHhNqNy646rdDKpI+FDA3jUlAsLZzypAg8sB
7+2znMANIYzMP5TE6nc7E+zAUdCEQmqrf8golcqnWpKoXhYkG1LSjj1WMrn+/EHk0ypJN1/QYCbN
NtX5t3QXxo9oOAt96SvorvVQ7El4wZj/33Gf5rmMdnI9JmckrCKzkXNsOrLeVFOXUqsZCxp3/Y5J
Y9IYUNRsEtW4U7aqNgJIfO5ITL/RZsyTB4Ow8QDldlKXg7h2bW8TWo6rqST4/uKFCKKp3leDHNwa
UUzPC9BciVGirwIl3LEDYUD+hgi03WkRW5m/nv5HBqyn1snkh1TzmCRD+MXykXlXjYlqoU5PdMhj
/6pOLu5oP9wSCKy66ac3MaO7zs91Mzm43NoEbXn1SIWDBDz8FJKR7gOXUIBWUiAZSdBsgBwK5u8M
7305vB8qJHGxi0Tiu2IKg7hvqCmCQWyEzX9ZpemtGhbxTqTTvG2wIIDh6GniOS6buxFcuzV+t2uh
XTZAyBh+xCW921/2usYX/OLCdIEmGVjzmW50LqOGPJvq2wvRhkGgZrI2R5F0ewotMyGw/zuf19nY
Pt3+qLocrbniTqqJvRQw1aLMLXJ1T16RtMrfKb4UgznSPwmzxlWgLsEiGh2yNbr74yDa/AkoAe8a
Tf/TkvBYcV+uWSehCUcuF+i4lCGYnKfRqBRRusnYOP1VTnPAOhja8ZXOsqs1BkBcLTBlFpYwUE9N
NHiqGAREHJDfkFAZXCZvp2slZKaHP/q2VZ4AU4UTualMjIQ6cuH+gaLB7wC6j3AYiRrcH8axO84b
XGfbrnMIi0kp4BqzDrfKCadfiwjmQsWC21CEeHpMd7jsxfsb0ZTAqnq8JGIGVe0tD5QB7+adf/nW
cSqpETnAK0PG9Dmr2JffTptX3U//Q/6VgLt68iUXQyzHIn+GUbsFMsPV+XnPbOe4vxWrhxk4f1ud
6kp9PGCUJDglWg/6TlnxUqhs0IvilqASJT8hsvFGzUXGZb3F/It4DQNwhEa8Hf56p/WrHgAPnx9A
arctBOEPsN0uy0gbYpuR2I8mqukHJmnGn4N68n6OiaYyr05YImR06vOHvroyzCpejETTiNp8fb8H
4aKCuQ+5VnqXoJTlfMJm5SvJ0euMreWBDLIL6Mhd9UEE1Aw3lG3irFTAtAawfe9VCsjdZ1yVBO9k
GZbH8X3Bgmh9YLxLHL5mhEbtpprC6MmXS1pE1vxYLWkUD32A9hh2pet8b+QZKOytkDoUqZLIa+9t
xa62RYyL332UIUgnBr4SJbpb/Bpb46wUVX1wZwPzO+rU1aLhAoyjcKpv8RGZC90KwkEFa/fVAyG2
T2KJjn/Mq7YJt4nzZd3pUMBKOn9fTJ8kzB2NT8La8w3eVXrVDaXr5cRrXt1FtBs2CuZCTx74IXVz
Qojd+rcs5yfYr3BXhMCTh73/pjf1B1TibwXtGrs+jzxNyU/riMcXMznv/6obArTUuxEpe8sFgQHY
nJd5b9rmwd06Wc59EltwzA94DLpc680kTohMrI3XrE9Ju1gMtPIHMeUpLhqb5UK9ZbfMBaqdL0W/
wiGpZkvGKI5Cx/EAjEKWnksz5xSNfIcBvszkczDzcI0XfIbkd/Akmp6exiUgQWmMkF/QeJqcKMhp
YRs7rMzV+BDuoGzZuctIuiU5Xu1I9u2eDPaYn+h3tGBD6dVCIL6h9mWTkSwi/GMAiFtnxisizdqi
wEXmgO5g5Qa+FpiQ3RnMCQ31Wd8e4kfHIS5tBK1OKBGNlchbLH2YZqve7rkA6EqOsW/KmgLfHx+2
LgPYoyp65u7sWc6dvD866GzD3DgX9xRk029TEd+Ll2pWUGgfOOFeP+YPboJvVEb2Bok3d7gK75Xd
kM2LUkQJXLoXUCDYMEdwfz+CLFuYZytxibcLmrIi053R/5U8RsVUnokl240ki00gIDe/a4Nj8aax
JwsnCCuUsHAlP/sfoaqxWnv0/vNTmiU1tzoqAdmG21xDfR7flnKp+/J4QboUzANpdPsjh7Tx92Wr
rhw0xQgvNYJIzdX+PVAFedcRQWOhOrjPgKK/VTI0K9E4tM021znusghqvVSfguy01UxOI4F3KnwO
vYiHMc81A5WAtM0gtfnEpBEkudfdMpVAZnojL9K86kcEIMTOIejQVC0xT1RmP78u5jAwEDAfTv59
f1XwqYs2zpVSO82nCe2+V5HmtbQXMXo8U9zcvd/IcJIQhiHQhS0T7IkPnR7Jc3hNzupFEQrByUM7
NaYZKt8IRaoHEWBuwvaIw0GhpDWOIZChZpJcWDA7b6TJ+U5oKKiEz4ENd12pTUXAuf4ObXyiB9w0
5wWYeZCX4kzGptm0vL+0Af0dsdrxSPod04DS/B0saR/Kd+0Sld6sBT/Aq65yW4w+tQ8YIc8iGCyJ
FJPzV3kMcgc7x0HscAh1ung1RRQ3axthgK2WORCCVd/qIlE+tatj8e7Hc2IebBMYWGL/Kdm/stxV
IwlwQPopwAYnvC1cUw655ACTCeMW6zMhQzqtS0/dm7N2Z8853HG7k81cDvygKZ/Ng6DyZGkesiE/
hwAClSoaSvC=