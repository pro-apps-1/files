<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxo8T5bZE4sVUcRXUjtcg6xttzM5qMT+2SA6ifBczIfKCD7mqHtj181dl0kfchknXcjUAtMj
XTudqbgPnQDbVZ5dmu9SawLReZgSxm6u2GBOjIlRBz9pE4vQ/nPs7ImG3vX7avMYs15Ti2Ryew6s
1qbESe0udDwQ+xUMk/J28G3gDy5C8BHey7sZ/8q8PnIDse+ZI/BMfxR19eBHLPbz0XkuCS4F13Tv
MZbB2Ap9yPHwFNZYrQvHarq870coMudY23HuMV5UV3HNAgEvKMn0WDbY3c9VQ1WawbTAC/wRjQNj
Wreg3zaL8/8u6gmGH3ycw7KXj6kYZpddUOtmTO0Dm2Ccow6QtLrvXvMT+lrEGLfAnLlzw8NNkAUy
iV6laUcn5gop4Cjt2hAIZBcMf4WQgyAdBpU0VFPxIz0a/Ppm79k0rLvmwzMxv9WPruvZQO47XSUJ
P3uloRj7o2N8NyqRrdCrOYRIpG33e/y5eVYYN6h01O5zIbWMaF/EaBQl4IxzN4lEpzgDIb/F+hJu
yJkyUL0G2wm73vR5Nn552ZQiPjnJhInqlydHwSTbC0UfRUjWYaTrzcB8tdqX6Wig3V5wZsva4HlQ
vs9EZHlWPls7IJP5YJgaX1y54s5XN/50QwqdOmOWtDNH+ueMVraIM2gjuB0kG5PG0h4tQsu+Rv36
Err+zD3CahV/cYMrTXdSyW5DuOjSp528iOIvIHYD9YxuCRZc5rNpnUcsqkYh6Suw5IF7qt0JtkBO
DYoF1aUMIEQCGVWwarYIuIKEVgPEttDQ48CFx1QD2Ew5fMYN0KcD9N0qtjgiw2wURI5WLpqPbpfV
stx7Ujs6DaCcmiKC7m4LxLYIXEU5VWjCg92Sob2mTESJG/98yQG5RZl0Gg732zVoc6zs42NbOy9Q
StL1iFLCiLv1xV7QB6N1s697rmGUNQ2mzdlIUylt5kRE4d2bmPOjmqQwiAgf9XBQs9HWAXRg5HeQ
80BIhr+KkGRpmhC8OlCipW8qWSEaiXNWaE9+/1kHbvP3qrMtwxXZGCNGLOk2ogHD6kQzIYA303dJ
PH56QYzps9qPPJLXP88x64LFl7LeupYqV3xGoGPe4QlLGjJ8C3u9VKCLVBtB7oPtP6RMGD+hgcli
DC4x74lLxko/dQhjYZWmyJ+PHVCQZdQIErX4YK2On5w42yVFLwE7szUG9PRKXRf8nHw1M74xeEEx
22QKVqxzYDSGVzeWIrGi4/XKSUyQiV6u4Pz0hq/CdnlUAsL6QiLiFNFROyHAGAlLnJHTSWGrX/Mj
fy0UcAr//GtYv1/nd8di4B7D6aX/QiwlV6c+7cmT5f2ROMZi/Ivx9drwNzRpCwjU3knm3y0qOyTY
GdnfR1EgRWLDqZwWBvlb0PC6DYsvrWHqOqfEAIQtqSl5J86pRirjYJkR9eHkQUETR7j6frKSxbtP
2Kq+VouunIaJ3LYu6WesNQ8VMWeX3saf/TcdNe3QUXzj4UvvcLU4r8/95hZDiegg8/5GYew/TnN2
jN2n2fWLh8VKbT83kijs2jqbTpHfGcil0N1u69X1Sc12lVT0rFKgJu5GDfbWJzd0m7mKiJ8Qc253
96o85NBxrl+vAU0RhHUVLaMFxGW+pvKWwFwCfIMPClgQ3VenU+pOWXNsLwU85Furie/qncZjxTb3
bhSueLdiLLqfp+755zU2tE/hiXKFjez7RrS8/oGfFarkViVc0x/puoe82YzH1KkGhblNVgFXxAjR
RaJY1oTEg/4B+YnbUDIDXO60xXn7Gxl0kOYiPLLpG0K/b3bt/aK3swgOASh/VF4AhQqHgdpg/udE
WWoRPM6cQsnDBeLsaCjBFduH4Wb62vCSDtehOdiRrpa7Fnis8jgqAaawAi8+zlOmUBpp43YOiJEA
2LllQXj3KZ6nO2aYwdpaY6GCFUU5IaP5PXpmWUbPlleVDDPlbpbnJMGBJw/i8dAVJd2zH+fJjG7R
4GtX/EakHwQDY8YEW+sEPGK+nSsKvt6oq/YktKNveyb9RWo1BHHbMVpVkNna7aI4sx/4yJCdo2F/
iGSzkrlYCmOKOXgt/dqtc32LCUuty5a/JiIFxJbi5Axag4mfqEPg/GHIDhNAvH9cmwPvBZE025oc
xHt6MhkyJQAFOBwRZMJWzpfmtuV3r8FqtZ2jDRbIcBKtmXEdSYUn+ZIxGn8BiJbvmWYFNYn4fvgE
j+lxsVVCRihAPJqItu6DoOJDvStBJfNFyDQD+nyaltOXj4Wbj6QOKKlw7W1KG3/Kb7hPrryJRCCO
fRNSJKykEaVsv61uIiu6SISng2pZpYzodWyvtYyRCSqx//t3D6Gg5eecYCSCsRtlDHA7jgv7pNw8
Lw6aqR2yWOlI33Sp7V5+jSDE7k7jdLBjFg9KOjjX27Ttef93Pmp5mDklidVOtuddZtkA2/Jb9IjH
G/puClbajZjQGCbvne1LSBMHRuA8wkJ3tivL38AvAXVw+SCkrISI/8V8DbJn1ihzJnyUnEgJuX5H
k+qD+74htcl3PTQVarTyfAx/WRfqOoHwTTz6Q8Xnywca6RWoKqBkxgchHsEAQ6y46HIn/EvYCPbG
cTgrbe+tYw/lEB1uNC+jnlYjki6Fy6fxGnUagUt/Kp00jDHDX3E9lr4aWHnr1M3Vm8SCgwSxzLWp
t7zpl/OJ70JhgV5VQzaL/+3zO3Y2oLeZYhQxu4V+DdxdATf6HLGA0Q/YoQNSNMQDp9lEqBEYmHL7
ptnW/uso96whU3w3QYInEhquSHJOWjRo5rDvdrycJYe5ZjJKKPVS4wZx8P3gcuZL+g3fPnegrd7g
trWFB6NmfCkR6g2xzoe0u0ASmjHwrb61/EEV6a5W6BHwsrNA3eDn2qdP7TEfSqgomlTax2XlaZE1
jglHsH8xCxg6arjB/GthV75ckqulHLQ3Jm7Zk4mJJO53iwr/+hkaL7dqdI0c3MLlvNPwfszWN28a
oP3T7S3axtcY7Os6goKwMdAvqRgDXVOXrOtCyxj5NxqM2NMQpiwS1jV5bMxe33F7Y5UKc2Va9PJQ
vJ6sN9BLs+V8Uf1j/19dZwjTKD9PXGVBENiXDPKk6Yp/1m0+JlHVl7LbcAGgMK0PRT6QZqZHY6T8
fxp6AH1GAxjwgP30ZeW6I7aeRK4ee7faoGBcl0GLeVoUEF092dNzgroL+yjgjJSh2Gmwc7Z4v+W2
lhrCP11adIOtiVpX/syfG5FEL3/087DQ9DZU9Rv7nZAv7EQCnhRkWIufMwfuh9zR23sXLCxlguys
TcU7tRH+9wMCCWTWZ20guHMFMNEkVhMMHvrRkNomZdeM1g18UFyowVz5jGX/ALgzJMLlTiyqLUiA
Edp4FdQLgMcg11lHjzu+I6V9dn1lcSky8SIipACMEeQIcz7DFi/lWk6SHKLCAvQYg5dcOsJ0ZvPH
gOx/6V/JpSktwP773v/8vUIGVGRqaH5vDDYkIn5pCYlgun+RBD6TqDeD9F7ww3UyfnN5EDkOXw+L
07pHBmVbyBo56nMS+ZHrQE207cmMqDrwhlpFhw4K0VRo3TzkfV6NyVZuoBhv8yx8r0LPn9Rf/jaA
ck2X8f6ZV9XnsJv73eawVrRmMSIBH6T+CUVtDmfmhV5vhIxMTEPfddxmMRxis/eoU6lGTMOTjOX5
u6gU2EANR1s1kCvE7b6jar3c5ayTEB7ysxaLEX6VxC0CO2zNbtz4BE0uU15+0t0H25hGJ36Ut5Ad
1ZCSPUsoa4ReryEx5VAFFqgBn8ZTC904nr4GbSTt3tz6/wjeQxVNnAW7N6ieDAVBUq6w8NgRWpKx
Mu8RFkQZGfj6x6bx/A/omrsSk/yTfLwWGXzOyneSzgOZBjcsmBBsL6i82XQTDcDuPC4BxleMyV2L
Fb+3ch1wLvpYz9v3XLt/yqmTZmuoH7nFIPsmmkWbsG1a6RLHRHVhdGhJXdtkdxg3WpUkRq72s/El
Egj5RZS0RLhwOD1Zv5pt+eT3svu7uDWdYTqK3aVcCYItgCSw++51jE9RXwLS/M3h0Fr/bduo0trL
wGURymQ/8B3WsB2mPiiDnQmB7YpNWda9bkwc2u7PKUpjoheNiOGRgbK9JtiwORkdwuuiaxgEerA5
8mJxEqmOH3ZptyMSMGB7ZPm1P3jYumu6UbZIdGnPZ0H4EP71nE8dCdAf2eel+4OJC+diFcJujn7c
OPjDYKYFgYmC7fi8M3ZRVz5efLZ5TNM+PIEGGs77vOeFq8Ih1gmntw6K2VrajPiH+THLbphJ4KYp
vFiw7CzBDtcIVZ5dPxUW+dptuRnwMiPRRh+NySbzv6Mrw33Nhs/G5dCJ2Ea4vmXQF/oG5u8944CP
heuC+TwtFPEWWkvOz02Q5D6rVrMespNIrQ/uX+xgt+RoVt/alnqCS81bQNeW+YlnnqJ7Kry5Pr0l
JrFnGFRSfhrMeDjv28x1hZA2WwCCG/BD81RXCZMFl9O7gTvZtdTtKtGvKp0D1C1js0E8pBgHvGcd
+B6wVeZN+QY2IyJqQwIwG2kRHWyJGiDoRhA5nSYNxaZS7hlFVxpXacabLNC/56+qIGZDPODpkUsQ
LyMS76BLsJRW+jSuN8QrpnJrpyI7QFDqXKzPDNK/W28kNvXZeaAIuu2Ge9Fq5Oe6yq7VqT94GzHl
fHgF2a1G+Wz74x4m/LxaFaeryWwRlP8Kdy6sNhhuYv1At2b1MjkSlPlKeegIpiE6WcWAhYo4AK2M
eGKzw1Hz97tY3Ni5hpSxyWRU+k0guW1EaLIej4JkOyARRRXjMCPGJp+Vf0a9HkcmkiQrubj7dm3d
KumnUJGtni/xWf+WIu91/SEFOqK26Ut3MlwYpaVjJ8Osg3OGDkMAJxq6rEhLQ9I+yEa8Edeo41DI
ezClW4DWqoiDyMkhSxAtBhnvQTQdcz33RDcYJSFfvpbdkol3KFKlPh9cn23XTc20PU8ECPxNPEOR
nRZ8/7E0+4xMNfvobU+LsCi/cC2F0U+U+Wbxl3JGR6vY8PJY+5NFf17miBq4UkXu96kZJgJGNtfV
4wwH2gahaLm3pNUcCoMQGfNuaMd7gL1o5JuDIK7sHRJU5BRCLpTZnVXBlZji2YylC/0BZP2BTByo
JTgY07iGhbH4bBpF/A1u3pculiz+D5ZLk863rJkcf2mbzNC7ZfpxqTQ1rYi1amSSVUNuLlgdfs6S
iUyl/w0Nv2oOHL962pIqwijUZeVAKff0xSjykgNF5BxJkkAJOS0eln4EPiV0F+hQrILuGHpYbCdx
vG12bPTXTIOaHVMc/qxZo/hjlUXtlVcUa+GoZspgt0kuhY/fk/RohNGEXY/OZBWpKc7ggFxpH6eC
MX1GVRwZJ2sVhJ8hSRuiOyQLeMWrNiEXdikPPUB62k3ocB+UEBkyZ6y/VK5c0C0mE9PV4cjrzQQy
gtVyq/jMaXfiHp58ItPYmIlWZp64JdXbBf6l5hNfVB3H9ynDkzXj85xJpnnhjPrqDfmDd7v6kyEp
Y9u5wjIVLub4sM7SeGp8vEFEwsPH7Yj9E//0n32jk30kSr5jQHJx5BP2YZJkIVpPYKDP3ujMPaE8
SA2+TM1sSQu1fwjLCA4QI74m0+0/hmqnPJac8cUDrfxZVn4Dc9bBJfsBPkyewI0QeKsa/y1oSbyu
NHX0OePY8FdVvbd5VAERjFZw7JBqqTfflP1vNrS9lpG39RKQn0ty5ZH0M5Jz60a8MhXlt+qwJ55F
ckfJe0/92+64ZmiFYjOLygy2WfrfwG4Hsdz8HzqbBLusUhlGohq04Dth2jnGK1iPSAWR5Oe8ooCz
Nc8kKypR2GqHecyVc5kGvMFd1awTUcuGUcNVrCmpQtuAJWBbFZa50x2kuS5VeDfAtrwsYabu/sXI
l4OanssLtuWqwHNS9zymj0EpTRtgB3fSe24WPyiLVRV+On41GgReC9JHRsCPkta3hXGXd6KZONad
X8YMn0NRfTvMbKtUagWO453yRIEg7MvKeLiflZJt7A0t3inxBJPNtaqi6AqfnAEsfoxn6avjIFZ7
qESTdItJBgEBksXIrxHoQxlna/t5jtttKBMiMAtyfRmptJ0ELX4cyDsihd+nKxEVMzAWKd1p4yII
+H1y0xU21mBpQjmT9zEwx7v1e5ALGIfJfOURxwunJmiKnzsPC99Xo9BEKRDiz5Dt9f+J0gWtrlau
k7ShDOjEK6q7wW+eHC9yMsJhcUZoW6yNpZuG8c1+Rs9jOAN5oCDTt5hmK9w+Skwd7OSjbaidgRBs
bPH9PXsO9eRaUC7ufYrCCSFyFiM/fZD5lRGGhhSHkWjj9lD+QBDKg3Q9uJbgPxlHlXSJK6xHDN3F
lecZgwz5TjxCspl6BXFAdV39aBwP/dc2NZvG6TZ/KEe6GlOOitmq8uAkGMOIKkMjKu++BDqj7vtQ
Y2WzSuH28b2E74XkvfdlO8wu6o595aNxlEl9cJBN3CWJcXCgDWEtD5t4Z07+QB6xT5qbwvqeJrPU
yxCI4zS5Ig4nZgFlVZKnuHyDlPXdGTTr8lF8G6g+i3xQkvqPnHhPbNnEBD7pPb3PeaVjNWE8PcWA
RV/1LfTMKOUgT0SfzJT8oYZ950qsIyXY+BOeCTAhwjmembPDLzBOU2uz8egM6whMzATq2Mh3kbAN
NvgvQqTXoktMgmLEmOxAWV4bbzzX7cQZ+KIkLVWL3k0YPgN2o8e3zAdJKwPA68caybuhaTe7R2wF
dgKP5pHdNgnSo3yKf1E2m8xqLA8fFqk71n+PcEoYGSB+al6O0Vd9KlfdPlChPN7ZrjWVtBFYq4te
zF+okpkixsFBsj1WtlnrBN7boXuirsoezhHF5hkqxXWRWncDPjj6ec2xjk8sL6EBo8BzSlA92Li6
hAOI9joK+xmW0FtmZLHXwF+SlwKqfIG2nSl63zOeA5Ngii6PKOKhuusqlvVp99zwTse+8DoCB7RZ
t2AnS8woCQVaGv//zho8iJjuT+2wFIIRslzs2E54TJjEd9xfshiqbqlXasqDR5qDMj0PdPeqISPc
BeExUa+xVOQBgdInUN6Z3jdJgPGG68YtLdyQJlotgzJw8RNINRydn0WUMJSVED/dxrTwSH342LUz
lnkbyoNMHE+cDHil4mEcbpUdYAvcSNBvcrWwNTsqZhAF4beECf8K4lydi9xOaU7E9zAp6lv4CKgt
7cpV1kkil0WcDbwe1xU7GbJPJ2BZwXNzz5K7QdKBHonZ9R1zBXPu6Zf2qIgmn6iXlVz8eYV7/y6L
GHB/CQP6b0mwO/knUYVCvw1jWTp4A7U8N2bG0wElTa7JjfkSsztC8eyU37W/iYyZH1OGmJ9iBqXh
8K6VkoctzuKrhem8JSIC7qZM+kv6/nSUSeJjMIZ9JUxn8V4PESNnNTJw46X7o4FImmAOLKOs6HfV
J1t04/d/uGWYnpYMzuAGPSBZzkCJA0fyodR+Dx2ZuPnmT67mLCV5ti40xdp7c/Mo1dFZERacmnwL
onRPD+ucGW2Vb0NYw7H2zDKc0QXIwkjA/bwSLzcacPe3xv9e/EHwS1BNQQXLpK2BfCnAzx8h5cjy
fz1rUTEC0RtgY1mhdgMGn8p0YHzLdjwXBLF/DpUiJlveM1AeSZZdClznR+JXcNvPi8+o1BAr2bUq
cN94zUtJudL+WQxqTxzQotq0U/bU9kt0UNJJYVBwb2dZGasBVlox3PgGMaHDyRvG2lqoBoxvWYxu
p9iK/+Dg/iNREitTeMPHC6dYisCx3Y3rcZJDpBXFgChpdvvMSU330DU7atWhryyh/GvTDXfJz8xH
kupF5RSKHgGDdwP8Br2FppgDd0czCgh/IM7qq5w/wFO/m7mbIDM8gRj7Bx0Mg4LMTBP/1EEJUQ+Z
lnBW3dW4sUoR/vhOsR56CxE6RNdn7MuHm94dVCwEC5Urs+A5FIpOLN/0ZD91pox+vzrLoPLl79oG
lXZjqwjYcebLgWbe/t1sEYc7po6pWSuj74EE3nZyyYXLa8+GuzKEK5Q/8U7xMmyzHeOaU3UBZF3a
nX7W92Q8uddIqnSOvQBbrlSDnmooRbADz8eveaEUIVci9FibbsR+kckOgFy8DwrgKfqYy4zbB+QG
N5cd8fP+kuDb4qIpeY7oEzZTOuxbe6KY55TR+xL372VuIal8f7uoicufCIsIbPSPw5eTXbJzjvzD
1RFcqmO2oEz/IYTtth0mL2V0CGYM2zTHSJTsL3ePQQlSsfBrhI9e3yTua0os7pN10eGKmwpqmSxE
UDm916CANuev+PYXojdzpyue35EyYPG7GTYDT3OWclEJJPS/CMkyCaDDsevgvCx0UI3mvmQnYBE7
K83mMAmVJ2SrFI6fNZaCR/EyurxjLCBvFMxgqg/RkwH3CWWVDHUfZeG7BRyABQiOUk7REtLlrGKS
/NMoR3YfwTsLdm==