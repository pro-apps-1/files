<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnBnpJthSpOoyXzO7ltp+DXefCveGJ+TAvkuNe6aShYIr3ZuUwphLFJGq1wBwpYyS63Rr5N5
NEIEln5tLUJ3VNdkVQLtsBA12W16nWolUh+f3yIaWbwqLCSXxwgMUm3gssH5Svf6w2GOH1C7QSGR
tblGmn4qCBV85mie8TaCz1utTxQFabCbLAwgQKLPXkihU0xFnlbsJWWAVC7/fJZvMRkmXXyPs+qS
wqB6Z6Sa0mKGlFdW9YClkqYrbPp6m0+0G0vyq6Wd/76Lpb7MaO8rknKwRmnfcnvJtgzd/Hdqvj1Q
H3qZil9wmhT8nUyZyRXtSUzGo6293u2XARzmW01Z00es26LCxlbpI/V3w50IjV6e/CNYfxugTzYe
Uc0bvhHw0skjH3VpFqU7GTx7p4ZdBowAOI1lZS4oSwotezQ9jH1WSm7TfRevFIrhq3w7VXfa/9p4
nWqFbE/3wiXI/TW43HHWgRlxeDQRfNmLlCPneU0dMvF1q07tAJDiHJadl6wywYtcKUZde00cWSQU
UniCnmGiEpdOuM63U7eh5jKkPGQWKTiKpRVVTNf5bvbuPqMtWLa8y/xPqJle2c3q9HYBEVxfdNju
dDfxG22PJTxMVctC1KRLgXjAWqcyGnAWvrJZDzIpgBb3O1pNG0iaxglUNpGd5t+J8m/fZf698cNm
nRrxZdZEFq40z0fSTAPxGYV2Yuy5sWti9FKx3vAM9jB1VIFsgvV5D7f3KfwT1WBAiVEhKLEm6XmU
cfeJ25HNcXFEZYl5Wu4BY/szu4lRZjoRwfH7VVOYjmGiR5Mhrim+rulXs0pjY+xTkYYR9C0zDwC2
t2mtGWaqu29Bqbze+4iYtJvvDvPkYJs/fQ3oDWvxqECib3wwGfmAIEZZOJJAgyVZ9QwgesV56Wcw
AaooqyDhqQRLI3ANk+XbVhymtkVrTjgvwI9Pfv2qU2IzMyr/8KeLbpOYAgSw7LM/VUzMP4IoT+4v
/dWF2JW6CYGFEf9I2Kyz6EmrxvlOdWnxOnYoCwqUc75z5Y6sabOXgtHPsZiBOUYcYwJHz744h6/8
MYwRSgqXYpfsxIx3YHBixa63gKd31MWHF+juMARu/3vhZgNNYNKcO4eAI/nxOGxOx6HZXwmEhgEi
XNxXC69I7KHvvkhTyY5iMUReU85kyJIAKO51/l3NduHts4QN1RiVN7K7W3ye3MrxnI6nq+bUptR5
Can9iF6/ynS4iF83eNdNtZ1Id/gXNuR894udxtEMVjO0HhpnDWq1x/G/uJX/CGGrszI+XrydqZ+i
9jSYKUOjiYNhwqbO0LtJ56aY9zNjDMhMxj1pbzg/220lVazfeJh2t/hMiGYe1aS2/tVEWOBGDiMc
KPYgHwxSLr0Ofp+i/z/FiasFumhootE+g1rbhKHo9OoytYR1vlBGvtIB2sBTo1Zj1Vi+9aA0ruf0
vb6BFwDlEQUAn15FZRz33tfIEuL0zA7C8Y9l03GrFPtmSS9Ht5TT8YSUi8ESNgchPcYUIGCs6XAo
2cYf7gEZi4H35jf7AX7E6Dij5WU5P8z/gQ4X7+N5oEPheVTc8kzUIv/9ZMOO8vfPqhWSJxCANsZA
c8tMMzTWTpcpTKWNLHdZXNBGP04iSuZhj4d+o4sVqxVXuF+toISBD3YWNKzq5hqsPIpAbSPOP1mv
R/ybXl4gRS00VFMfz4c5YcIKTdR/j+W1+HuT4ry7XrDx/V5iVCz99vl+spUZoeipSmnvm5zImQbo
pXNPXBBhevfgcFeCsg/4Pdd52WCB1x/tXEOrElh55MV+R085WeJY0TKm+0oY7sFI6R3AJLsOq64O
Xra/r/mlOL6I+0D2QHfTcqJnX7dtI+ye5gtB5b1Xy9l9ZRuU2HxeFQDeJOd+QHGtrl35BBiastxW
+7/aYg14vYSunvcTKAZIE6u0Kpkfo5ZVQ8OqiGSGqz9OOYgLs9fY7AMKAVCHhXOfshVztvu4z6XV
kfDX+qoVCiTzTL+j7isnyTBGhJgiMWKvB5PYqkH54HEqOu3seZxX6U7To6bRoSd1SFy76nSOqhJh
TLJxfJEWlwjdFJ2qiXMH3Dgf1p66kEtSDqgBvP6JniFYWbEwMyIybHxF6IUMDgRQcSDjicmrkrCw
5F3PUkvSyYdbh07GvuHs+fozU05aQOYJcUkcDNALADp/UHHZww9UpIG58CgQO1KeTnOCIX8ovwJ+
k4zIqIogIdEBKFPP2oN/PxgnNnxblGTQPO8udDcftJfKQ4RuanoQ5xUXn46rxB+r7H+iZYwGw2tG
QQbxsFUlxP+HEbLC96JKUx41sbgkuLddZg+fxToCOafcub3uWp6GkPVnaSfbmsuYa3uft0jP+nhF
BvP5+WJRqe/5XF0bJhJJemdz3UGC/rf6RUe+XMnH6KYIHRE2iEzm3Qk8nbSPVMcqcPNvWzgtUei+
MOIW1mTB/GZd9BA5t8FghPew/SkS4/HvZePg2rkbYlYwhG8YHKq9XUfsXHi/hkaleGPxxOHkoM/H
N1GilN14fxIQqUW6XhbHCehWpFVNElTiftroEAUqvHLbPoUuODfg2JRALLzZPOTRCZ/NrtMf+b9U
akKl1TDTRVAiijYXijMDIQYyTjreRTkBGUHiATddZ7+k1Bf3iK2v8WWv+DOx2oqpHKxC271dAv93
GxWGicy+LoTzUCsvZw23FIWHdbnaWiH6500Bew01elt6dgVuEluwHseYXOesz4OE0rF/3RhcvTML
77oGJRhMIpLHt/FRlxid2m9OvOHf+zlk0zhPgWJxmwUhAevYxCkUvhJL6hNG3Co25LLb61znVHbx
vGCwo665PAaM7nLB5VvV9cuemjVIV3795lr8rjVqi6Vq1HqY52a6UA7jmOqj8YFuKHBq7fjlP57X
YzxxP/fm7o/mOVP/pp9q6zao9bJEkloEqbVtsKTbE3qedV3QeRJHZ2lxiLlOB1jFo/uS2cfPbMdd
pZ3yFrPDuPDKXZ8CAu5uyEYFe5HiEiboIKLU1E+FLnfKJf0QSSxm490+TI+Hs0KRkbtNhPu/Vm+w
85IFABoPXrHWqsUe17AKlpQLP14YEH3aAW7tO+XsDdmMYCvp6hhmcO5PnqQKiZbkGlEHMQHchPQ2
iC91/JvJmzgi6sPQo94DYFfYq5YVQ5PuXB9GdGYGIGSUpWTvp+2BHzvjXu+KVhJlAtcQnlLh33ru
jOD2gGjAhjDZ/v3iWjwLmGROW80/xf5oviDngVqS3YdD81GmBUYzlZkhZ/kv1KsOhVdeTjcXgx+J
xsw+0gOrnhx4hIZHUVszSbxzIgBa8OaSCi+N+1SAp2wYIKJl8HcpDOVcbnok46xGGUJT4aNfoYX0
IHnOBn8RgE8rteSLprgPkaCc0IfZ7pWjdpR4dAeMIoWsXuTGTgsjLBDz3rVY7qnnyCzGtRfIdWbc
/pbVfeVSNr0bBnmnxLIdgx4e7bNfyhofqeFcEdZsrZ0tb39ICeQq6P3S8NJAtUO6piJfkEolZb/b
NF33/TEPsM4AIiRTLu/kfRUQyIxegbqRXJP+YoCr07kKGWHcDgV+9CM//NeT8NS9tepaLiUTtRBi
ZcLbHG4Bm8NXJ6JoSQstCfPPVB5aXEZQmMW3N4rIs283CIoJwOXf5Wu+k70oHyTFoxcBnFB7KFv6
TLrAgWXi2Ib9m2c+grcngGgukxmwMcPGPRe1WssSWF6NxzPw8AAGW0Ag0QS6Al8IEYcRWQVwni3s
TmMj1D0DqlGWniLwXN1bUkSWN350ksN4PVrCc1g335B2RhSIC1hL19vXz/W1Fd8EZ0RZM9je0f2C
mZ7kq4gv6jw3chL0RO6n4OX2Wur7E5zxLZBAMhyP55uBPjmFpg7K/nsesGi81XrKzAjrp07DHOUC
0/s5DD5EhbXBADgBxaPq2T5Ub10GnPJskb2BA6YQ88Ax1FEG6ukDORK3hR5Q8LIQAGToFrbjFz+3
wJXzohjuBR2KQ8sAll5WJ1yZh1gFZdqnAusXOtvRLZGNz5ZA7qf/Hgdd0qINd4aza+t99ENs5JIm
5JvWYLAi8iGRyAzO5bL4GFPa+KgXOUGmg9J76doOI/5rrla+NpLFeQJoiPNQPXb9aOpdXv1W2A8w
QyV1YVs3MrQaK8SabGNXV7ub3YcxQDzVP7wMyT1WG4XE8+m146D8IggdftiCYyl4I4o+OmHdlIrb
hqLHDHmql7xqx/LOtKUNagBYeGdxGrfb5LyCUkPEpNS2OXs72vkwQtodHNlN894/A0fgW+IdazZo
G133yYpILuiqZp3WSpucvUdwigUV1sHD3N+NlPDdMCi0vkYFktA4JSSzI8Y+8Ti7XBjYPwmivjBW
Tg5qIhqnTKpVdSsrSAU4U7ib+uZwZw4jF+jB0iurJ2DFy6bJP7yD33dCceUy1gY3drsyYzaRAw2A
opJaapPtALvqYBM6j+qlWoUCzlXLcyy6Nws7ufZH71gsKChZrG/bR8yY/m5PnGrgS5nlWSfpvYcr
u6NPr4GrjhogfhMHTnaMyOD/QbEEzdx/Sw84HNS0LYKOftEwf27h7PToX5DvsfbYzmx79/gKClJ9
pKccEw2HERBhETlvmtmtYOv+f9hATmp+cRNwToBfnhxGmvtqiK49syuu52er7pW2NglxGqVFNcsm
qC5ZN52xZ2nm/67ohC+12SCYRSZdm7wt7TImPb7ORcfkRAXa9reXbr4mfaD22TV06cb4HsWLIJYt
oDRCzrx16ztRcZl4EUUiRbQfR2h3/leA90wDDMdS3cqdd8Aub8F4AearOaQzlWU5zIGDH0XDh80N
YhwAZ2twd0SEwBqlMqN7EXW84twisQzNto28sCzrA4jqr9m7yyHTvIgsxmysBOVFS20xvgtyaxVQ
hst75HXAueKL9bjfjcFhEAuofj17mI+r2ITV25K9TOv0tC7YOF0VYs/XH+hlankzEufKH37zcsCv
WaZ4NlDGDdMVWbhOPDoFGvzzzZUgMLdESLciotMwciMKcrpvx3x3RBJ5QTHwyvV3Edk5i1rs1nE/
h/1HkTlgp+/30d/TtKPolr8gFqxZd+fGR9FzoP+M1WRmKV2kFrnYL0AmQuMHG3UQZuE3NGar07/4
yyEXlcVSy+kV3I3Px42JKxaMl+WXs9JW4Flm/CVxwVH3dFiaWSODT1DKgdgMHp/Dnkxku489qTKJ
eOtFypG4wBkSTte4ZlWh92XbbsTMMOsyAdr02kT1rjaJZ04igise50JkoI6sZO//VSnWwA+730bm
hTejWqYachXryoQSck9H/KRTWVSMZpJc0I2zbiQ25shIxPqdN0sWyXcxhWumTsFG+0qOwumJUh3v
YOSIu1dg9bIKEy5xUKtMKOvuWv2jWxD1Vck1IofUJd5KWkIi4ko0t2stFnSeVICCYb6ZMCjR3udj
4Yi1rwkT16AqLZUi0wJylLkGjsORWSajbD8TOck7AV9Pg+yDJu4mzsIe6sKcaivv8iy5mTfknyTh
LUMIpbHBxZ01WyQBJBC7rqRPp9zB+Gd55w4i/+NBEm8vZxXrGytZ7+UX2VBtUPiFjk8n5xSc6XtI
fs4ol3yDXYROoly20erk32FbYPzI3AKhEZcPC2gBTo/9VbsxWQbla5syaAgG51Zukr6oZbVQZqOc
ujGo8gxVHfvKO48dGQrm2Qc49e+ygjyQUwpzeuy2Ya7jqt3WNFq3l6J+JLbTOav4jHnDmARdYtHB
Ku3DBJfO/BTJsOLQXBifBWhqY4NMU2psnjg1/kZ2w7dY9eHJ939RDpW7BC/mpUEHpug84XtNencB
Dp95uNj8zN6klDuXAkp8zfIbceIRv5KZEdVrcuQP6Kcd9/fNatBS79FSMbgcH9tmskCW/tVnJrkq
t7Y/YJ2YWNR5Nc7fSrkbwE4HPODDM9Ascz+72cAW/9Zc5nGo4qjNTP3PI5/dI2K6yLbS1xM+EYzF
oVevMiN8zuyc0lvZ201xaAVp6+o4xvPJv3Vj4y5hoSWDhJxqT82orD8qA11BW6dMhifQV/g7el0p
ph5FaRCkXsLAHyM5esYC63DsOktQnsApvL75edLFa7CwmUqU0oT7TCc63DjR+RwMOTnvveREt0kA
y5UXde6uiHoicurGIkDYtpVxS4/R5uWfJJZuZRI9K0nZPseEIAnFfNkLfPeoYCswNfEerYfK0uBA
KciU0ZBGXvCMszmS6dsuHdkpHBYlg7O9a7T+CUV01lz+Xf4K4bhKCLS8nOu7Rdq6E66GLTAgXgMy
RPTmnVoI/y3en6PYYxRLUI6YXfRwTqFI6YX/nVgsYa6YKYnWhJDVo2h/JZ8A9zXXSkAjFhgBPV7p
2A+gWAbExNOzD/3XzomSUlhGszNV9g5/0a+E2Xq82KH48FSW1uSCo2qIab+WnYS4RqM7SUNwkW2T
76Tv6rfHkYpKXrHbo27XmM27yQHqENlvuAct1kIaiW9oLgZCAGmhKxyQcd3/Pmt1bKCArIPAlpcO
6Ntw89ikiAtJWF2W5viJ+PUZVhnAoGL4H2L/5kpLpMRVdJXIBgq6rcVkAgoiOP/7P6JWzMlAgJwr
C6Dd5bdrVOHFRcFF2z04KLuHOVsy/tRqfMc75aVeLCXtZkLxH2GFwRKDIS2XYjzBlREAukde1vPu
hPhMoi7c+Iej5CUAmFNS9zB19aylP/ZjNP2wxQfoLC+VfrbOpAx2QlBywv9uEwLo8mUzk41Jtd2+
G+yjXjrUxeO3ZbSilCqXRe65pD3cfczWkSYIMIazIjRWtVJuC2KGkyRACMSmQJqOtVxuy0NUU0VM
rd6YNWP9VgxxqP1rUeuqjGoVS6WYSux1ljQ5o/8xzhB9BSz7bE5xd1Yr1t6QMCt3a7GhIFLPIJJH
hM/Dx5BJUAVmPVfiMmMWo4Qv0NLvQ+NLIlc/NMfT0INm0YyWXS284W2Oj4MsoDI9th/vGiio8JY9
WnxzOPq9zokrirAFNKnix8q/K++6ZcAJZb8JFvGtE/kKHemwd5pGHRPlNEx+pNkN8pYpUbiGQuU3
sCFpqk3lCdP4sM2EaRtQ9lxtzGAXTbxZ9AqfsDQWJH/hR5mfJDY6UHYr1qstQOZw78qCL0aCCizP
gRsZ0lLDHtwaZ24vPMnwXOPLfcc8hqXDD32nxGvemHck2e0bpjohlpsuSnQEVxbEl7dSbDAM+6oC
V9vJBZU+NKr3rUlAlnTEEdTKhCRXGb6RIW4QQmCgJ+XB3BNlBdO44uNroI/TyN8FbUnwvnTbH7/K
cOS+2myiBOEjMHzHGBLCRt7uk7NFz4qzZ67KfvDmRQGXFks5sirv2dXJBrOg8roDjaYd1LfLiWW0
egxplTt/xnwPtz+/gKgGWRewz6itoarR/LT9htRBHniJX/JA1+UVr05qUzebX5rhdeC4zZSLwo1x
SIIxO/2hRtksipxSh2uDTOzZBNqQOSfqinQ268gSwTMcT+3fjiDkCovQMcUQRmYFvPT7gRJPfeuG
dEP2CkXXVtImsJfW6HJIC1za7HNkcOBVQ6+1e1766oeZRXii0LKdpxaH5q3Z5QSuV9DfzwOOySYg
5xrNWs7cBEZNrcvCkRNWuai7sICMxB++IBgwqJfd2erlI0zBOgfo2egjXpexyUy2MMWWNcHetZLa
4KhrDeoVa7DpJAJIAXpJ33O8w7uPhJT6KEj5vdNmxFhc78h9SIdSO3XzgDoXyU83bdI/VrJzYGCK
e4mmwcHC0sfMHEkayFB9igq7Wgkr7TIu3Tv3ObN/S/60x7fvv1XrfVkg2xvUcKe6HzzpePf1CKEK
k6qzE6wwEsQgKqQ9WVqDfVhTRgXGFyvdkssCsM9N8fzSI4HWXcNTYviC3vzeZ4e9XgRAa5/z2FR1
t8WAivI7fnmng6RMHbO6OtOc7H3NqP1wx02RysK6NU1VcbgNuCMuJoLa9fhH8YR3SuCq4hexlKNB
24LBWIJZ42ySwrNRFpNZXHbO4drG6oSOuOZ24dd/Je/woEezmP5pbWuzu/+69P/UDDK4slIt2fI4
tRHW6bm1+uEVo45O0NlwYkCApyCn9Ye/f2sFgnyELj9evJKu3kxlBHu5lDWzuuvgBWfJBY09JZle
mzmF7QHk7j7MHBzTJk4C7PnLl9hvUR93DgMQogo4maDVlqtbH2zWZQJut9FeD8eAYhhB1kmIz7k1
3ujIBFQ6q5dlPbMkNil7fYnHUN1LvzEEqQHMKbRpcRocIgRI2BjyD2IedbcJ4vIjHEAP/RIF6I27
WpJ7Uq2V70WGjtTTwiWmBci3mgdv7F8Em+O94qltxlqwsLoKUi8Sh49cj4eOy6utg5Ijh2rSWk/m
06AGyHgkjq+/m3U36rn0yqBPORPV3CnhV00HkVOPdZ3WvwQO8xuaTtMqOh1lMOMOHtKF988M7Aiq
aq7pVMQYgmAgJ2AnoEkCDqvRc5WXZn1oDDNoO9V6vOwamxblAjTeril0jwL2r7YE