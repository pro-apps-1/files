<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo2Sz0PwByqf0tDX9LBwLdUyCPQIEPSXyEeNgJe6L+tUweUjW0GtnRRGK/0ahcaRi0+Xe4IR
Gl/mK7AgLf9czF5ThqJ6NT/Os+YVnFVwPFAA9f795hXNCHBuiLLmpVMJ0taEoOKAlpzazNRWaFVz
iff55ymH6y3xSDJFg6rkFhEerj1VySpOlvZEFGk8a/pYrZqb4kXqnXJUd8oS5l7djLzRA4oXZ1Pe
XQhSIjNDhYDxpXtYlmtH2d4ZZbGzYL4/CSPZsn+MgeT25D+EjpKkAQLjijKjRp0Z/V6bGME2gV7k
ZgxeCmBQ4fCBRwP3bL9T9jtaGiJHmXd/9MctNDJCyxyFKJWB7Arby28ZSzJc2JjRroRK+ZxJYUya
KedY1t16YcNKOP0gear8bXn2pNPaRlFe8lJK1n4pznng4PcOZ8n1chDoAc3XE1ExM+YYYlMigUcb
ng11HiPz30mpByhYi+Q/5j/zVWbWjmztqfLMM/Qw6jmoGHClrN1pVHwOv134b97rOxGflAslZLCR
qClpGgzuZzynLTRmdZFaKge+0nKLVvgr3iqxsYlhOhFFB5wUnEkIR/yPVBi5wPsligdC56mkpzyL
7e2hNN4/nfVxOG2giD5mBHaMW5wvFYMrvWz/YH2i3v1cO+zy1rjZ/ulqoRcfEGd1tMitBT/jlx6y
y303CqoPgDrRuwZ9bvHdMVpC9Rco+TxLVTeH0fBBzbNRxKUkaCluazFfPHRGmZ8PqxB3zWPZy9g6
sxvnq89v3e7CvZX0FajtotPNm+eVf4zzPerVv7rRT0ucR54uEMMtUR1yTJr+GewOhBA5WsaeBT8h
5fyDuiBFmsCly3KoQxOww5D8wPBM2q+IGR70MKQDsPKokht6c3EJ4ROYw4m5zIPSy/FgkiKxXKSb
1UBKaUIDjVtBTD5VtM7IGy1st9PrzZxvgt7uje6HIdolb+wKlvQ4R88MQv/E5dLFynQ10C8pXtjk
+ZZBg4M72qcYQ4SiRzco3h5lk/5GrkpKp7nh0gkzj6PXHtoSJL2AqWtClPDl+RZtbt6YWeTnicU7
p5CqbQHC4jN0gJqDkmpOVZb5/TRIpOMQCO4mMEfQcWJL96sflFH4ij4mzcQ/3cYcBNHAzignkfEb
U2nQyoZjjsw68O78V8xMnGNj3RbB51D2Lx13syMqVZfYaf1oNz9im/4JJjiuCvXLIJAz15yzkqou
C0iQfINlK9sMS6p4R5pg1dI3IOdPy5RQodeYq2bMBQ4T/N+2G2iz8HdUNedWH28tFluITcEx22yr
ASyuhuuabnrS0koLPDqe/EC7/8sByF7RXBmc6kNz37S0RMbS5uC0aQ7AwF4rZNsbB7iKnY0w1vZe
lrgJoXHfwtOndd/yoO4mMMeKjAX5GAedFgVIvlKLmLLZdWtkLGrcaP2NVjqNitvJzZXTJGHxzXej
vC6rUYKSfdEif1ppQ6bvg0ejR0qAl0O1XarJBsSrPZT7t+B3ZHf4gdv1r58xKT34+wIDNK+xuoWb
2HLn5ySmRRYWeOQ+1hqv+0N/h6AIVti9NKnZFMFdVXypm/5nxOSBCsOOOSOJQgPlD1mKsacBheN7
E5rTdMW8si+qKg1kBQ3l6lfuqx8IDRCQfE3gGYrRXo1uFJAQT5yzdVoFvXks/xSnPNFBQMejjVvD
x1RX+/kkvofh2cFRCdnahhnzclqRCFjiH1taOSy4//sFaoIOx5XSzE/pVRY5QD2jLZkdwcMldVTW
juD6uDYvEu0bBCRZcomJh4cx8v/56VsyD3qzlu8cYx1yR51zkjK/3amMJDzH760Om0nIcPIPe7dN
Wf5f2jiGH1BdPX/EyFOs0ZKDHB6nJBiTo5w78oONul/FarAc4X8CBG5S/nCtnNxDC98JPAnnojo2
UPgH3rTBGx88ggVfBNqbWrvKRuuwcWLWYUV2hPRymte3wn7GzcP72LjGEGXORCgqvkVksWO0zf0V
Wj8UahmR4uXBjNYLTOncDbaR5IJ2JdOQp1U1svLXYxA4z0U5e7XGBBIKGDjImOsrqDKX9bQKvrPP
CLMDXz7vS4vBUyOqy+zyMIzgdamkAuA+aOBd75fXxttrRAF6U8s0N2RWAYf78rv4r9Eno1xLMKIj
udlvbm7g7PIE3a608keCDEDocu8YNAnEEfWZ8+nIz5Ic31OSUzzmMnIoE4K2W0bvFPfEB5JwryVZ
wbitmBIVbOtO/f8xl/Jh7TDhzaIs4jjt4nLmCeZxbPHG0xh6nf3d76s9txkyVGqw5CV4NS4HlFP/
z/8LrFapfkECRplqyQtRs/unr6CsrtJjM3yqtKz6w5LBZdphWJ7HS8UAl2NhY6PrOyxTlz0lejZ2
zCW6TMkD94Kui3q3FxDXOllFHFnovfPVXNNVLH3m8/56j14UH41t8tx0sA9zbCEyMQ6ZLsQV5PrS
BhEY6gDpC8AEp9N3qhtdZPES/A8wtuBCfZiPdQMjrNZ9prB+gZS2joQI3noYXCmNlfYETdcyRSha
kVvKUPozkj+r7lkfNIBZBGeq30Ax/xlSO7tMYKz3xyBvMzv7e+ABS1pG2P+7LfT3aNKDZzp9RyB+
vSuBsKsw+Ts+eeWX8Y97aA0DyNyZIk3KpsiZjmUONkwOY7qAoAuMvyFZrUzHt4uCakJVST3MUyLK
H3BpYo1HERd/l3LMrplXhHH1PGWSOgkZLnVbh7QweZ2wT0PWBB0oHCMW4Up+ykjnp2hjyj1LtuxS
MimEHC73PdCqaavl55q3UKdNZdCUYFVFub81Sydz3vuNZ+9ZuRY52Tyv0/rJxk2v4XsVVjBjzWk0
gBjyI2nV2pk0G/QrBLPazx5jdUHLt8ER4Kz3bl5/nlqf+mDnjQ1SUUEiriYoLiq4OWrgUbUOevBY
ExKL5C4E321yemdIZtblLzwtv0g17ht/GzjavbMMIDqr9EhERMBxApzDoDTvp5WYH0gPcOF/h5nT
4WTmk8PwUs07HGrZPcslfC572Tro2hnfiNQXiNGKNqPAtM/mBkF7UU36cYmmr2xbKRH7TcM/vPlw
JcvtnMPyCITCg9l5fid09LVJ2n/9C31MXwASlyl4497O08CiDGWpPzPGf3vYaH1St6DvNbqx+AAf
9/7kOm/dqxGYm3tnMPhDBVo4/Hz2SgTID0zf0MjawVHx3SzV2T1y0cqZxFmGfbFPTaGr2mfGXpwJ
1NZANRIzVpFADXFl4Da2RDgqDJEP7/L4xmoGipwYIaCs0g1z0hWgWd8a/M8df6Eyx0jtYhVWoeXV
DrWMnwm0zQuTwDPZbU0wKx6RSqcgWraRhbFJVuhuG9A0HSF6djp8ZVD/sp9uHS3LHmso/auMWTO6
XN6pqmxjRqcFcO54/qv6nlRh+b7zCRlkwDFX+h0/urxGnmRrszuPf5F/RZFOwKOBXLu5Tx72stQl
KmxbB7AG8zBUeYVnw2gebKpwQ6A4SY4X0h0RYKTFZNnbDTGAIxzFIup5heVLzzPs4kJKitbQu4AI
4oXmlfrbbwPPoP84B6ioYmIxDZl4UtR04tP6VGspTByUPrhtZrKxwhzinsAeauVWvWYN1ETGRfIL
KJf7+KOcdZEMppJp84VWBtb4vr1sjpt189JAn/IhR6T+/mo+fWrW8SGgfarkiz928DkHB9X28TGs
m8W9PMmVYJfajChkoFlgHRUi07Szjh0+S30thdBx84/+YyhKURJof9jDPMeJdRt1xpToBkuuXn2I
XUvYzYVkkzFWxHhNdNtzpd5X15X7edYsjuVzait7wY5lVPqXky8uBHHDO6Vrg0C8JlwxjvFaXM4j
/xevEeQsv44hD+zCAUJ7viFLU2rlPu4rUbquUdV3RI+sO46wqmjMNAzo8+Q4YWh/b3iAyuh8WfCN
Yi2DKba49jYXIYZnlmcPBf+icdn70pWlzZTrCiNSwAntRiHMAkIHkAhutaOIBJFyIsO08RM4H55g
JLSKNR5ZMS+FB4Tj0e+UEi15wIiHR3qMu5Xf/zASCDBBAfzxYDYGSjt7E18vTuYZqC09LR6w5NIZ
AOIa/rVnDKAHanLUo1G+Jltxh3sv8Vxmr+6yBJdBEZ25Z+EDvYYrJSIGu3FuGH+/ZTn9QSK+YeFT
EgWuQugWaNn77PJwFbakcGEu741B94jSQKcUJtwB6dfBcwDMtpX7ZrurdXi6IAmxfaFplxG7ucfW
UpAR8fJj2Ur9SM/Z5gNv+wLjPjZs9/GVWTrDKUudKyjjvBGzdf0pKnHCIWDS2LB5xD08aHVoyhDe
w5WKLdP498g5QI1VXHlr2Apg8O/cNCdwi6tlXPWq5YTEGnxAQgnb00em9qWU4SGwU1SDYwTA0PuN
5dFr5f2o8FYpkyVDOyKwjqnJ2cOrBy4lWtJIoytw0qIesoDYYQZtWeHXSU0NLm8IuVsoTeB8AkMy
Rgz/kmPPVOOMgKKKA6YWwpL+3j3FgKiEXDkT7QWx6JtWZQ/jFI+vKDyvYJe2Av1ciAfzAImdsCoj
mK9WJZjtZzi5SGr6rVD6AnANpQ65oikTTYEzxcsq+VLubvjFS3GRdIBoko3ojKImalgrFsmTnvLp
u3wSsUd8ouve6v0NWP+vLPnWlw9xOgnkVzbPaYYXNhY2QpVeWvTBhLbHOhIhD7i3KlCeqHsc02Jv
3PaNXDKaI2lkH5Wi9E2vo7HX9IrJPhCNt8d0tfWE0vwzErm1MrskMn+d8NRnNr2MsmDC1u4C1j2V
AS02YElh3n5vknEi/6vvU46uF/9LhPKp+hLx6+qez0ZIbLjvejXrw5YRaNGo41gpxUfabUr5obPm
M6jN5rf3UgsG7yZd4s2LnxiCfvxhPVnYSUaeaxmiKNPRV66kS84s/z9WdmFlZEhHOjV9T0NfNwrJ
Gj7jNHvrwQpdw6cutqlaNreaBR+YxRaCEwB/Xq4ForOO9cIjtBV+S9jfELcC7ozRJGYoiHNQoYXw
2k2wc7zmTxHMYVnmDJbj+Gh+4ijNx/IplfUYUWKvVh1kXK5hR+ouFio4R86OZkYZQ2vvIR0psNW/
+LKkrrcBpzKq6eSr61mClcfXYzz+BKFl4mgmZCaNdDhVELDZYgSGyRU31/tEyL6agV3zGfBVYpeW
VjePiYUxSfHDDDDij/Fh4/5nshl49bnVNtkEtVINdDm+nKgB6F6+yzHQmZM3vWqKpFtYpAHwRzt0
B7qxm/2zARqNX4yAHQ69Qtn7ylRRae/60CUBsMtzEQbiPjyRWieC+0Xb38i3ENgTdG76UjNdDKcb
L3DSDUQ3f3kt5bOTOfvIjVfRbaR1KgXuAaZgUgos/YM6Z2hfa49dN9HYqOL2tQIDKM13hDWYkvuP
usJvg9SAOi6ib4tBAp1hhSBIH9Pqg1IZvNADTGxRh4nj3pemokH9KKnZQAXq6frTJWmMtw8pkXKb
KvBnSGmDQhFF4J42UIf6frXL/5FRZcdpMpLxEdoEr5R/5/vPJRhUo4HDTjt9YY0vwqnfOjdYW60B
B4VmxvnF5zUB0HtYbQp4UMMmxoVV5alI0gnVxiwYXjbQzLnZT9f6dziA2jD1JVz+TjA+F/nFhV//
vjFVbYS/1DdAQj5KmvkZ2OGWlhJjMttv/OZ7PDbn37ChaWZbzT+KAIuXkk00lEtpt7pWihsV+DKf
7XLSu3v+eEE7larH4hF0x9/LkDb1l+GccP1N74YkSHxDT/0ME4tDORfDWxdTq6rNKpf7hHnNDWlX
9148T4kw9UIaY4PJiJJTsbcF9GDwvufR/msUKaRMQwtGBKSkNq8HdnvVDQAS7Dw5E2SDzMJE3M9n
cYyTXEIgdpcJehgnaLdG8KyIcNuQ6T4Jsw4bkfeq0mW/aXWi8OwCooDsmERImn2tX36RQHAeiLgF
57ISRJUSpBrMlDBIRTwgfYie/qKmjHNBbq/8NXd7xFIHOX1fSLGh5cgDqCQ+1/y7XBo2ofj81xbv
sK3TDfPuRdhn/zM/U3+AeFsgXl2BNFNqxE5sTXCrILJIBUYEsemR7g5l8hNs0JwKYn+uLrWMK8iY
h/2mmPu1CZW0uBSdQ1xipQW2LNlTbsX0ZAUiNwzGE2KUh8nODDIWGXWO19T+B0qp+L5UC4jGtECx
3NX/s+jPnhTgxSEfuKG2t4UCCDEzcZetntOdWpsbSBQHle8YRjrY3olobw6p7QQan4BZopv8YOMi
68bosfQVNrodbiabEfwtc4u07EsyUCU8zwkLBMEOJuIj831R8qsyHQCcygQ2b1CDZ4KngrjLBnr8
Em2xZfFXDF5f+Sf8B+kk8hN6CtIsqxyVTleBrGOzDsErG/UzMd9Pt6shAIDki1+PBxP9K0mK3GA7
yo2+Jl9vHWT05r67JNec27lcx9qgXmmvZOAlKbAGUTEYqSl93DCs5gtQZKE4MbhJZhN5YpYkRlIh
tARZ+8M7Sb7HN1MPWmZ1Y6AMzF3uslsp6sotDHlM1dYy5G/B/shxfFwRomGxUZUNGL2UPet3aZUc
6UEABnF1ZdmCWiPYi73PC8rnXFP0SVQFmvABw1G+yjKP8jZXlljtUq2cGQ6Z6vI6FHQcK7TsxPzn
uKwh/FNM0OWrfT2CgO0fKT8jHxO7RO9mexxhDsGrtAHb341uM3WgvG/s3L2awHjukf0tn6GqwgoY
G1puWrDneH3syhxu4ltrtuijzC3qsqHYgaNyki829MCrIePTKCOR9FvXAJBjTUbcm04KgP65YrVj
78e6HuZZv3YSGVACEsEhaH/LBuHMMcAerxYr+riUl7WBIgOLOax3ZQfKV7pUprAUGXDo4lAPfl8X
VSH08ax5PdC2EPuPtzLgs7Wlx0setwyStKffL0xw6lNhniatNodsMpgu1/9nO7Ti3OFL32AeptCJ
Aar+2C7V/jB+ILEzKSArOcFcrQofllen3JKRMZ91UC+RNRPZuT3CLJuYGN2oge5zU2b8BeTV/uUb
BD80evSO1IKcIVifAZaXdO/CsZ1MC88EaU+kzPoO16lbZilBXM/l9B4Pd/DTVmuEhe/ZJK0SjSUW
PlQZcbm51UjwcwbYqNBFolJAjFrqjl2nvllomKSgSiSa45vFvXTIsn3IK0XyMh8HyTml+fAlk8ki
8SKUazz8pX0e4BA7EkxMSwwqqIhZRqgMd7+A1xFkZ+ufi1RLPRWJbv6w3YcAnLtZNGpZYVeQBFwN
O27a2AJ5xqSt9gT9m4M+Sr6YX8q3LMpWI26r6S7klWyvoH3LMbbzS+xJohU7wtJyRsS/fxRDjaBH
JEsCUznNWlSVBfVZm1SN9+nrAUmeDfKV3L5zRtaahBNa335DWHntSlLyw+lQGeh+OPnhrqz1OYfx
lJC1ASvhg0TigWaU+MR9ZWxtUhTib7LlvwYdEs0uhmAVhpgAKj/PXLqKU1NVHsAxdfhO/zJ6YeeJ
nB1ZSiJ2AG7zMka95qdXMUHuoWaBn7t0YXp+ZB7DTIq7wlXZVWIHuNM1tKox+tGCa6biNpCudm8B
zVWoc+/855RqlWTCtAbLYdp1YgnHbPF8yDjhONvpvhvz9aYNIGZjT6l0H3E4hjRO46FuHgLwO9p+
cgTUTlqMSD6WsJIFpA8nJTqEi5XEu8jBHvzjBAXtyNJscTXZRD3tNmhhbUKJHIaxqmJFEUOYpUc1
B//vUltqZS1mY5s8hxMj0KRD28han7ifJOVixAr8Lnqh59dDJna0z/5334OIpkmrwLmkRBR8pZEr
szSYPrWzx7zKL5K8PSsOpwwCc7S4ZDDqLM28xRefKcuQGMtft1+epN1RB7QZqdkdZB5OJiwkZffS
WxMGngbsVaIjitoUeklOdBGBCHjtR5KgqftYc8443QrBdEOiPdlT+nxX0BtzjDXkAYAPh5EOT6gO
vDRUr0nVjmCxugN0J1Tit7L31SGcQWwfG++ymzmtTQYt/2uI4YYEn15Z3/v7XuHYwlTU0bkonArg
Wo21yWraD0GQYu8ElLt36Rrh6sCbuUSz/BUZUIipl6F3gIa/HqlHGeA2Kk5iTt4mpzIPTSed7dTN
5R0nMX3COHcJ/xkQbLurrq08QhRz63i6vIojc6G+Dus7krzJB7dTNf1NDIBoBxomaHdNV704Xd4a
RYX6v4VUdVyq/sjbH7xsUcRvMtNii6dL1DknP0QPSg6JYxiDxywpdMVfp68ev1UwLzHrVT7vIAdZ
9QlB6ARhrSevYIQt9tN9amQ5i79Qr+AR5B+sXgVa03IFjgwX5qO2t4gvJld+6O1satSzBkE62y+w
XLZQaCIfgKU+xw0QIpu9ze966fY8TQS0sxJOl7CGkh6kqA4D3UmuLlMTT7iJV1GouFnPpG5MqJ4t
l9vr1G7NoIHOYTT27rvhrRVJIIxzfZHmH5vwbSxC8Jk455W6lhX8d+y2zBtJpbtY1WVb2KjwnxjF
rMtrnd+BvgMcTY/rtEnLOhU0iI3J39rfX8uqiRtknSlmdnYdYC8LD8JGUIo2sW6t1K3xkeVE3DHF
nbapxUTb/71y8fDEopAUZDMPFlp0KNpC2uPXXft05Dbx87barIIsFvYr+1P//euNftbNCYlV3c2F
rpJ/OuTaHBNeH37KgUVZL5XWkAXGscn627IlWJQDkXiu5xlFYmSEO+HogQIjQfRSReKcNRFrimPg
TxH7BKKvoXaalMfkhNBq1KL15WzA+eNH3hbA07ub8/0AtCe7fvYdRFvE7K18qKJe3Xv8vYnY/RCa
BdJ5SxFHI44/rA/WKCQBxK6QmbuGvZLh8P+FBOP9IIFuv3Eq46W1gvjah8K8KKNJVk4QdIr4PatP
ZiO7iFBTF+8aKGJUC3UdYdeTkuqXKsVdAFCr7/jG1M7HTr5HeIBhUNquIK1k2y15cLX8upMdSsZN
0niOT1b5+CrtVZ/Bz8EkjxlSngTr3enIk/YAFI6ooi/RTHHwJp0kkFwqTeGk1aL8TfcQajl22GKY
NItaKs1vbsl8/VkIjwXGL0wUK/UzRIgyoT6y0eqVB8GwGYjuMYVsummvaCk82xIgQ/YkRN8AEix5
SFQ6FIiH6IL2sqEuWY091n5rX8uA9tSj2FGAVGDNXDhcjSMx/sfQ