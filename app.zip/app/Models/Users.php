<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy/w613VZk4dfXIDCnXoCOnwUR8Z7EUJDBouvlU/+AOLcPxzx9KTlR8xtwFw0uF/r5/FavHZ
fEixRDFafKPbOJ2tfz+zAlRX9tYj/TM9O8L4sUTKV4IQnGg48AeLiuF2kmcHN9//eQvQC4Us0HHL
lnq4y0xs0Y7tljrJvN/UVfefciuFFvULB0liruS3DGVYajYJJVQNzUB9MoIlQ4wjt9nbQdAAeBxT
leFer+iRIkJ28gcaYnK1lCzdfBwrxE0wv5X2nar0bIC/IiIrHvjcnscyWnPnbTKd5nI59fcJqLmO
mhDn/vyqfBCRuOpO9VPTzXArtHsszbtQCOepMNX/VTJWqLFdr3XCmYjeI29aNev/LWMmh7XbJO82
vjdtK4jZ2jRrT7FIHXW8T3c1RAjN0eQ48wX1/tudZQS4c5hSLUjHjoTH9nJxVb0UDiSe20a1Bm1M
I3HDBpGfIsG7K3dteiqM982oaoNm64v+P0LvUfhxbmVkeoqBqd5TsXZOpzlZDCc/0T3F/RRDAl9L
E4H/DS4VBpMuK/47mArrcq6IJpbR1GwNTRcfc72ivNvVjQStBfc4/4SrEedX9uJuCcx/UuEBhPQ/
LgpUf05HvhjDceHP66iVEMwLB+LSifMjglxn3JhK6p3/KeVCaFVqqDJgbajOTJZ//sLtLIdoy5yP
I+LJIdIUhsbDsjjS00Hw7JlpqaM8kVzi2NA2bcHQKqlAfB/2L2+lV9biVyGd+E4g6jlg1HD86sC0
ajsTqYQ3LgZYkxe3jDWFPE/bX320CV1Q5fMAD71A584VLU4XyoUGYJeI92tU78iCpIFNzurKnX7M
9Cvr2AzfKSoqAh4OwDJlIzZutFj45dIC+bnSsJEQDcVZmvqSlCmYd1oKaTkiymCNwKmT2r0/mild
MJkeLwYPsSqImE6Kf6F2YtzsoG+TNlr3NxtaM1KWWwtjkFaBdL7b6Vdyu05Z8PJNhMmECPXFEYf8
xPVlGu1IPk6Jxe3Wcq8p1irUv2ssYakNCRUALsbFCXgOuC+onCpKiSCKq6z+6AfefPC929vU8T8A
W6C8is8if434t5o1MdncjGwGfELsZ/S2023bDlkJUDzqGbFACBfPLlDT7AuaXjy7gBK1zBLsvAzD
Gx4QHU7IziJ585S8HV0vhwY+FeFy47uBLSCfIjRiXXar4QzdGk7mWg3yDeHvJC+1T03hkuD59d3w
aaNa7jq77lEgpEBJutvjapSTfe/GY2FXf16YYV8MOkXUAkS3uD/qZf3ELJcRu7Fgn2iG9sfsbBO+
N8QFxIm9/5pFPQRtYxDDD3hSAsh4a+5aM3cUJTiLR6XCY8PTOJy0lTK7t3H7KanEWyLHebTEZWq0
AekDyqIxHUrv4qPfYBoBNXU5huV0hlDzkPL995PIkXASxgK9NNIICQmoRsz+PT2evrIKhI8EXxwZ
lzlEPrd8aUPd1RcpGQgds+la3FUT5YcTSb9IYAyE4KVfA8TpHZiMqqL+4CZyTLKXEKw1cr/wgIWT
Vhzsa6/xs61rmfKm9DYXpqyi9eP/Ke6PafL7gIySFfYyGP5bEJ9ULlUfa7xLalwI+uViRl3aDNaC
GsuWfb4QJLEFJu6fr3xKaqfAJsjV0nQCJwKR52Luj4lJukV6ndUmJ9+uLC1xPjjUfdndmaz6n+L5
G/cAmzisEhYoD4SsgP2sd1GZ8I8rYfNHLl2MLL4lY3guQYAqHnAc37zzGyENuPPB/cibTmsmxGxq
t2PdYHW2i94xXv5ZJ4CIMrSZrXnfj3IRYpxtCuBqhDj5eu4M1yuVNdEO8J2zUtQIQz88Wr+T+sDr
HkFOxC9dPhEi9vjNblIcwc7uKkjIJw2G9Z7i3N5EWLY361zxBpY96RLcXhvuVnsH0RLp/dOwaPiv
/h2xvV/5LcDI//0aJJRq52P3wVDa8jYNvlNQ8zATNrbgcmQ2E+2ptSAYT3cAipUGSE4ltmpRUmD5
VXoqKBycwv2F2CT8TJhhWP5jxM/prLQCDuUpQsUYLU8iXyu4NNBZYHV7czW/92XHTwhRTbJZy+m2
PY+PWfbsCTY7Ye3m1LBp7U3XfQDCee8/ekZFmjx4XFanrWDr8lrvNBDOf1rpmEkbCHb4Ejq1N9UI
tbQVyCnnyjiHJ2puL2VYXi9wxJSPD7q7Bjbtfr9vJIIgU/wCxKPEl9aq6ASXn22YbAS173lnjiPU
abubHCNTbIPeoBkqS5YMODtGifikNrZ87S79rT1mxTbuffnJ4ew2Uu4oxQHga4Ll6hgQQakH4vwu
n/PRzjf/Me7ZOa5eqtGrRAlSGcai+J/Z61bMwZAv4aNms3hNxg3UNU7fOBLYmuAecWw/LuWp4ZyI
0QgGN2OqMFOHGZSbH2wLQRkxA2a7AZ0YzCf8K3EY6HwVo8IBJRwurU1DFzpcjSxDSJujJogMcUGW
AZgdnkZNSOULTghSptMiJs7Z6XkYItetAAoT0AOL6c+gqqDKrtwNZUZUgDdiAsojxd7ltzsP2WaS
GiNBegBjluJPjMXyUCDnewRFrj0izqVku+Iv5v2oPJNO0c2bJ9/9RnTYTST6CXWwGoobGoBhN8un
GtefIibwOTRpSJBSPaLQHJY8nW+WcyvMxpqAxat+kTTHmAYVMN7cI/JqMkAloLVIz2wn/T3pBmMT
rPUvRJRHucuDYPRhI27ZdUNo2dFbBBtXRFCM2FuzabbKgr0ugtqKpCO74N7TSlY8aH47LIjIogZS
IGPNrxGmp+B4mXb5Xu7mTFY92mkDHhE/PVLVhu/3wDsSbaKtEdWQvVFUcQbUPHEZV79einHHEgYR
e9iWA7Zs8pbiv/n3/D74ZDGv7SBM3fh4Z3Ejlk5qMHZbXYydfm7h2iD0JvXpLc/ICI1NHQBETgu0
o0ajJqu9jwvbzotRGkjwDKo+SUsaYqoyXs0/lDPKKIzVDLVlFuf4OkjOI2j0/9X6Ixa0bvDgyir3
WuiiW0XI4LleKr03kWmXDxprxKgAoko58iTL6+woqZITpUM6Fyf3KryMo/NOAHIIZz77gOy83rED
a5Ch/pOo0FxEcehjTyU3Imx4939VqpiWOqfg7Z95YOkU9p0kudwg9GhakJDDbVS+Lx6UI3tUu0VO
btH6RusujBn0G+FdVr8AhXgsSsCj2lzUUeU7rcNEP18PJ1O+AbegqoKR4lg+DH7rIeRAvhEk1ioV
GSK3RfxaJQxUSl9LRki2emYmNHX0Gji66cECAM5xsHmmJXArt8mgvwSUemNa3ztcrATZjGudq2iv
wzB+Ki3dSs3XgWR0M39YNXaeGT4lz/dKRTpQK20DLYhiLke65O9mfUP6b4N/voJ7PghqMap00tsZ
Z5Zn4/gJHwBmJQS88lkPetuKN5z41kvse2lUQy31nCy/ByeYfYVnOtwfQf/252khgfoa0YFJcfA5
Le4k64ELAJHI/v0xo7N+N0tJg82VXfz3YvkD18CxBSvS5ofWRy+oMGIGCUVMRh3UdQ7y/orKOaQG
pIUK7eDrBSGKeWrjhra11G7XheQd6DYw8h1ODJsJACZgX+Lk/BZ4jZK8Xe0KL7HLT6Vy393yqArT
wZ3mk2HlHb8QvP8/AubfnmrUNvFFPfdtZ4EH+YfEBI++X7ePRDWhklRaC+YtWpSjj58ieQi3K+ut
Dii+KmRZtU53AQq190xjI/DcAtIu+oF6G1MxEGS0WZN0uj+KysLgQ3WsUuSrOqkwSUDifLAhG/YP
JILEyS//i11tQivCK5cDdLUxohmxa1Fwc/uI2L5/Ov7NUSnaDYRwm6V+H8E8hJTcoVf7ZQVm1Klv
Fh6q0fOPrxbAUpLDU11ZHw9N6VwwkE/RBRZ95f0aw159agV2hhPug//pbHE6zRq4letgpW38gAeV
Vng2jbnTETTK21wLbU3EvNmjw2WPspzy5edss95TeHYhKDK2A6d2yIsWrjqvKtnz2kiOV+BtucMI
Z+t824+epCzlqRgSIvoQTbZCpgm+s2Xqs4jfEFHqxvWhjOaLWmaKWvqC0VEgdfkle8XyFkcjLSlt
bz4wFXQTG6b/8bHlVFvDtDwGV/H75FjXPgr6aumoxjUoP9Ty+on9DfWtLrCzhDNTX7J/hm8+LEkL
1cJe+eRqL0I+aBoEOHjFaowJeVi0r2GzsTWwo+aYRBqYoEmu1pB03EU1OMBZzujAnEmc25j+5cvE
Jkrsk7Zg1MQVVBGUXOkoGmIDZR0/iMna4tmuYFbhfvzQcHxLC14iGMjgcT2SIQikZfyYVjWCvcVP
9mdzPX4CscHUX3LLI8KT/evnUUifWktrCZ4Ty0YCalw70e4dlgFzaR3yW5jrHgRsMilop/tU0qXJ
bGZTasmzrpHivnD+TGzx0oqdTRQUjcpa5lfn3Dt+EC+zApl4CAzxm5cDXTAR7h2Y07N3PnjejY25
u1uAXdgF6ajfOGyXqSUTx5udumV+VeOURbMqsXXXAs68ybcYgkBpycx9ZYuP//1DJIXjPxO1Sles
a7lyFoXVFfnk8syVMIpSqv7qNtD4BCOpnfIDFUwfy42ZR7Rq6VbBittDb+ydNfzng00cmdfiT3wP
/AyP9rnaearCU0wg8HpEjYSqutWE3pxq3KxoL9wOn6U9qOnzrYM4qu3rg243mbFErbW7y4EK/yKt
1alUQVlIFZEN/ZPha7yrtJ+TQ6WnTXQjAf+H4jrCikT9lxouHG1uOMsUGqRU4+fNEJjbhenX0BOB
CLBWtx4mDe3ysyB81mkh64bP7gKxw3VazwAWvsqS73dTzPlcbYTvTtK6pmAr4FNdNU8Yb5IBv9TY
Z60541q0NY7AWyfTMsxVjXjAtoK9ZWO2oRsQ1CGVAq7DXl2F4j0/3saps+LTTzQ5HsiosW1XLEfx
vfz/wUZJM2LV4qUZwdaff/+Sg6KYQsHsEQulpYKCozgjNaER3sIq6SF53zbsj4uO64zbJPqII2oR
Rtq/3QUa1GOsm4IQdV8QxC99E1Fox4V2k6fm1/YkvTwY/I1qEoIqqOYrA+oanv/bGNhn4xuqPdtt
lKpHQpwmUjnWS41hOpNMc7VKRD9wYqfE2M4zlUa2Ju1/Co9r58v1kHNDGtKfnafoHmGhTZ9dcH0r
N9H3inUk5CVE0V4JnI0GiB1JMreFyFKOoJqz3/43AOKzNMmiZ5vWht5oNX2k90elTT78fD8lKIlW
oiN4XexBQHHSe4z5zTnr62cav+OUUrBS42GXZkk8Rhn/R8RmwiezidMSGCW8J5IrMQwkatwPEYI9
KVH8hOTRBLLluPsiuLcqCq/WXKsb24UWzr1ovDxrX0CjWYexBik++5QEf54OUAxRvfi4BDY6Y8Hs
lQJEuEZrqqmOd1YRVW32ZiSBaIAxSqeGGO2Ey4NRANaYds3h3pJOr1sRWlae5I6Wpwyc0JtQ/uI7
Wi2Zrwz5jYFSumYb2/+q7sGt93WJ8pGrxAF8XyUvrPM7JoqF2rbg3FVBU6Nngu+dOfxwjodqmx7K
VAFFosevsMCGdQD17rHHUV0XUD7BHQuuN1FKnfUN87XHgT0sDedG/QApuGoNoWeB3Yu4AICULX0s
KL77PiE+lVTzVKdSdggzFHgXoaEsWjGUYDcfdcygq29pK1LcoG0Tb6zhpCkWNtjJKVrrBzbqQDIJ
aSvac7PxeeMsnPAjv3XiWT1DBp28F+I8qFDKfWG4Xr9Og/n+VaBA7TBav1YGtqGHeEe44K0GK4Vp
LS8Re43fcief9sBZ6sbE6l0VDQVwx/SKHZ544iqdWX/nwFNAzZ0DXYZWR0LPGq3HQEwooBa2RbKH
lAYOWydqUuNyh1i0BBTCthRzH+cnOZY/k274CcxIrE3OVe2UfomoDjADCAgiVoPLAvjHTfpDp2mj
D5vsx4e3RGQ7BhKBvu+a8CQjg/9ow3847/+n3+wkVLjBwhJUori6fDxX0OkoZ0u8QYRuvob4PlHE
Lk5t/cwIYufTDToOgPvtaEIKEpPWnTOsGEPSUfZ0iIXC0H1Y0m23Ez1RCkbvc9QLNKUTgPl0U9gw
H4y27BA9ruxKSmwBIfr2mAnYmS4L3lhMItZKlVE98/CNqdwqyK/l/nQ84Nnctm8wkm0sXF6I+sZd
O59Q3O2cbASiKulC1yZDFYJAz58RK+tKOkobHjYxlhD9JGQdEr/zG0tKq3FEvmxldpKSAQV4nXSr
qOu2HjkhIJVyNwUI+RJr+HJfPI4RdHdu32N1wnouVfvuBopxWUmXox4sNLHsZwifQ9/wKTXxzwth
4Z9xWYXMcwkN9NP5jlViVHYACSv968+RGT93n/1NixOoBoZrjfJHLu0Uofh13S2fe+fdSLOtYRr2
1Y5HqdvEOb01DWxTDDlBFWQnsX4RU2/mVBdGTI23qwbeMr0oDmNAuNBNoxLgSxaTfFSmeTO8jEsq
DLIj9UnyjJjAX65PJFDaClILOpwaOwzZr36WOLzXzSSxPGluyflfqQo4fLIBjYFUNg7QiaZOEWTS
DTBLZsPxTfzqtn9rn80NFl+nrIb7xU+MWazUjXnKKJUMD8WcslbzB0omvsceSPszXeduhLhUkFG7
RZlAJPf73oP8/scUJ4RfogMQs5LhynqFevqTs8vZ7R7DPRbOUc8c/uejMIU6j2FryS2UXQ0+FjBy
zzqbPtr6Ox1gqGgUdZKu8nUKJToW6AQvV5t56KVcZNZj2NvPUaxgiAwmre9EA0mCT9dCOwdnFxMl
TnkTazn+GYGH9SWEHKFr/dJ/ZRIcPuRNYRBYQgUZrjkCxgR2hm8rlJFV50IjOk1jCD+YDFdLKOxC
n8OFt3uO7JwkPkkUZOt5n7xe77f9xq3gq7mHnr2EaKaS3mj7ep/eG4Lw2EVqMf6ZZJ5i410ViBlo
sf4xhUdrFmBHs1X+dIvYV4WmO/VOlarYkSlRCJdAAnfWUK8pXo+1Ol/z04EmpEaBylQU+sJTB2WZ
MSBUADLJgiMNFJxvOZUGzoh/lBxiBJXY+Q76TodKKmn9xR025cQ/HuCSy+X8HND8B2dUaj23reDM
PnefWOh3ye2cvg1KG5v8LXw5pOVf8E553fdzmWQfQmkHrZx0sZ0eLYkebYOMHlcKJWaIivVVZpWO
MelvSXUtGauDvjuS+qOPGCu1scReBgwDdMsMZOtXaK0RMU1AOtryaK3NUPgm3tk3I2HMzKl4xDmo
SkqLLPPKVqe7CwLSdHfflQr0U8WL7iuilZMCuNbbUjutovWg329vg9esqyvkG7WpcyiGIp/wlERQ
qBYsIfufSu2r58Osknkl3lzrLUGgh61soUKV5zRL/8fv770u3uCZMpSG4c+Eq7t93zSgs8fihBs5
tBRXVm9JyyRIuNFrMbBUhR8xLz2IHALFLxgZn0A0kxB1OtIr276kE7EUlfM5qMV8WWUg6BI9yg1k
z3BBoULOfljO66y9PBheZuPstBwdmtSDjKsNNoyzEdOVQXGtZhXRbC2UUxE02gweBvotDqFQ40My
V7pwQultGL1IdIgoJKi2BnnxLotxVUnxVug/GEratUjQOOIIWTEwa7+4R5sztinzSZ63/slNWO1E
An28zpMDadW7eygYv2JE6vL/wgQnVxRfxO7FPYnygE3meLAQmEwowG/wVMSRCTMUXj7yWazo6gC7
7y0Hfj2DZGJMYISbpahhL7s986tA7uE9gnjjakKOzSKNEl1cjXQRCJuxw5QjesNLc9OKaw9LgYls
pww7MyzasEhnTRJ+2QHdEfR2aGlpA6ZPqY5ypUvMO6mH2o/kwMAixrjHfwEUTLYHfjTnJJe7WUwq
JYf3YpzJurkAwN6AeKidNnbTjGuDpngAE5yFHBLpWKNTOF2S/7woXSwoSYKp5DVb8FeK5jdh//KA
BANfr1WrmRpR9YJMsPDw6jx8PGP2SRNxLJJCdMdVdqR6tX5GXOTFHcBDp0lwrUIKGosy3fdk33fU
OZLkXcgph3+Qy5QCdRGG+/SwbvpvhtxJRYKNkbUuaibsEuKb5erfJc0izSd9Ir5gWnRkuelQSECG
D8VE/UfSph2bxM0fdvhTjm9XOwzGQAKQACoICGLx0/6eHiMk5wrzH4at1dQZuPB1TvqdOHy+BoMs
eo3iPLJ7IN984jovjkk0v3EPcLiGaPPfB6tqw12Zco9oDhMgBkQS6WUpfzBq9wouKK5ZPqY3HCH6
Jku8wCS9zgm+J7P/Pwx1K5RLX4JqwUNQRSjzccbKEZk2vkYGeKqlNmwA9y6Aq/hTbxsqaanzqoSh
5pSED1nE/fuZOWBgZ8BnCXoQTgbB1/lEZiq1m8Z+uSs9INVA1dxyi/Iz5Y6gaZLP2p9heOG/He/P
Scp5QDWaPDQCw/rQhYAwT/4QkURCvgOVh74U/T/ELjscxojMCmFngOV4dVaUikH/pjlQR0BGoFtv
ZbdyX0DETVgHNWIzEbN8LPN0BKKdT19ghzJZiDKdsICL/0JCy6wwOKPfBVD3tRWuEQc2gtsqaJVc
X/wb8LZe6q8bUiBqaPrRYlZHXytU2YzR+PrxjCQENjPOOxOvVc38vWUy5WnIlFEUTgq+Bklt3zHC
MdL5U96Y4HaRci7jYdYPULHBUSCIV8njKZV36QeMmFmGQkEM1a4FKdFqwQiQKsvXbPUYNH1vym==