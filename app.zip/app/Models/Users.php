<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtC12ZfCeuuz2U+V6QPAoVX7YPkWu5UBmh+uTB8N8iaFHff1bktZABHRYQbEiGVvLahJQN37
9SV3ZzVrkUmIeRiUiopyW8Gz0tj4oUp/H2YrzUTWR/fiwKNR7TTn56DWJAIK3H2D9QZHInounS+O
1Y/1NCEraH4wHfhOuVzkQy7eqOE/5SRcYVFj7ELt7IFhuXjhFknjti7roM8+RKaINNkeH5RcFkCb
yyADD4uPrNDbhbIpH9HXCiFqn890cK+tiwIrLlQDKD5JiWCuRryR8iCogfvi/hTSvgNGG0+aIK4P
EJDP/o4G0Zsq/NjUVsm7Maj86zvfnwihP7EemrOxZKqUAqdl4eNm8a0vfd1++rxwIb+u07/riry/
fmKFLUGLLKgle13EbTREuQZ2qWB/sG8N/Oggu9pxNGvBtE3p8UaJkteSE4ONE8Me5V4YUImP5HNV
Do20TpTyzqyLHyorxrKb0KcIiK5PsvQPqEcNBQEmLUItl6H8b4qlQW4nhhT+SgfX/mzEhImFPdZt
Q1TCPmp4d+LtgmKDtUTecJGihWkNPJUhZfhuYH9sx79NzC0qCBjHmWY0uWxa6AiXAaDXKkMMpf8Y
DTrf8Jlq6MJpwyQPLsqb5chtHwARKfTpdUS+ikB34YvsT6+NAlIZTwbSIYiIvwocUgPrh4HBeJaS
iG5hjBOJX/3Pw9Y2OFE4UQMPL6yJDovlzvI9G7y42tmTNTRJUjfaKvNAv2DLWkrqFQ00MIXDEMUQ
zmH/GX0MVa5wP+bNMiu3lBqkT+qPdOdRd2utY2/zEz2VfElxeewKLOZ+iAiig9vQUO2+iXo9n3I9
jv6RtJjQswTdlmLiGLzC4kgRW5v4CX/C9N+74/ygqfqIa0iLfH40nu6tA+SHQvvgl7t+8klQV4z2
LtZklgUeCfrTvWlXd/eQtvNd6//18cU9a2qCrn63WyUAO3jI0WAez23d2NexBPrXoWpMu4CaS3aG
mu7pN1/SLl/pHPrjHHmt4D7BMus1NOwdIkyRYPDkPANJdY7oeMJEomjSI2tInxHjAhzTnxW/PfFZ
6aZtG7Ua3JxUE0UEOLElP63ewcxvkI08xPip8dR2iZXKXLrqxUJBZSbxr1yz1YIvHNzOZ4PzTJwi
s1EUiPuSqGlO0u0fhIpvrEZS2duohoUbYesGzGsN6b/tiyFKfkYqGi/5y0ZPvi75Qo1S6h4TRuNw
4IEKcFpPr/kLoJGaB6xO7XFaxjUDXd6Cxjy3GPlSNsJnOpwfxNACu/gCiESwjc9vZpDZQ1BwG8mB
IYI1ncHdOUwWyNDE4PyCgZvu8iA9JFI0kUlI1kauvJaU3rax9XxtAVPKWAxIjKFqMNZy3vGK4Nu0
VEfkPHmCBi+kvhhu8U0uxEyFcrPAVcAR9mW+ywnsBLzTH4vwi8LYEyUTRMGX+Y//D93gtMK9Dq2s
2X4ruwCGpgYA0lXwXXocaHsWrgLlpFGdINC/G7ZqUcu6h4yTJokiBLV9JdAvH+2Jc/A8wM8qQME8
qb3JmogBHJk2eXYXzQV8TpCpmYWTm2vkreCtg7DflYyPx8fjNLajuHZVTFVj1sMyuBNfH1+ojaV1
xVO9zSl8AtgOYc/lgAzMExEgQmkMhw64RunGo2Ke6+12KCZNqkC9Z4A+XHdiarcVLkcvCECefyHx
GLEUpuDc1T1LzmxoKKdEO+3qpwccHnT5QGu8Js21HqLLrX0UTIUzKvCv8IMVoMsjE5rR6F64Mqdz
bQM94wfw5aZRAA64VVRqKkjmO8FpvB8bnLdORL77gtu6qId25XBNUVlXvt6hoRpjmSRpejuwJmYb
Gx0wSbUL7b6T+zGAQahZbsn5GKcbNwUS38RpxoCTWFHxO8kW/+jM4rMWVVo3BGQOXxLNWYk6X1e9
uktv/HktHsn0ugNsVMLAlKjwBYHqUtHywSXjnoQekl9c9GRxtipTGEZc7SmjQf51LNA94q83u/kG
Wh5+95Dc0scdSTXuG8tLXNQ1nf8b8P6uo8mRCW4EZbZzXvBxh+H9IvwfAWVnQXd8v+n56LLEOjt6
4uloOgwWp90NLalZGtprIpLinEOktHV7h8ldx83g58YsFLRgDmOL5G7R6tYDg8EkocQCaQM+xQVv
U/5rJehwq3+4XOXU1zckXucP5ti7fMObcSfRgHaDhs3jSPPYx07C0K/wsWLsQ99KAl8P6zyFNPOu
Krfp/eH2CW1ubxm4njowagIW1ssdB1QndnkKLdOAwHorqC0EEDRD+C2Bt30hZiC5cUrd+BX8YJ0/
xgGS2mCCsRXk9deD2mllwaiRyldCrcrK7w+OGK/G8HxF+tHOZLL3iqsLa3izRfTqhHnMQ6PR5JkH
ngWbG29ntW2GHUl2AwIjCbNyVPTQDKF4kGH//skYJQDhLTCur9KhzKOadeoWU96zY5kHq1ibidR7
aIjtZFAcr5x1qIBBAOCwKAeXAqfnf82OTP5gsTquQZOYsMmKD5AxzLcM5b0Pk++c8OfmQpiFYop8
U7omgAGWw1WdvF/EMid4tscgdSVXnwc5893j2cY+iwVbjEe0qS1bFGmx3TDV88eXGZMAi7XV8VmK
tFUo1Ri8DMuL6cCxwctHWGk7vO+KoPRxiqxaJYV+rA67E4DGSf4j/oUbbKEnmTYrCQzuFX+TKDao
pbZW7ZKvwW95iDUi78ERHzpcHgI786cWwDtPEHGrquCLUnQm/0M5kDi+Yuv0CHSq6RYLQsxR9q2s
ufTtBaZS4vNPt4UKBtTnaTUpbDiRMvluXzz1yjQVQ3r8pW8Nep8BjUQtzePk8hK+HE8Y8RV1C0or
DJfcdWk15psEpon4xypGBMlNtXVOBoJhrbCfXXcX5KnsGfJP7JIg7z/Oq1vorHasBG3oSZQIZcrk
qGRu3PfSAFHvjQtlf9SQnohHiizOR3MGSQL+mfhRjMHxLSTKcQqdZD9rj5MZDGRAsUvYX47BTnX1
qv0R8DtAIJavVFY0+qX8x5JF4Uwl8qM8gCpnS6Me6U7F5hmblkbf8kD/pSulXf+Rc/bYSepU0dgR
IHGrM7w0h2ABlCVXwKDuURklfdmSJx740U/zbnBGI/+yZiGl8abJbc9ZCqC8gHyk+A1YsKKJ66ia
AgJ81WR2KTBUlu/qwWxusl4xa0YH9g9sIQF5X+ch6gqcub1kAKr+kYueMSGlgUB0UeD4WAtmbJvW
+wlItCKTgwthbEnNn+n2OivYUP3bIO+zNHDLa1v7fw2ZcfpiibSPZZNFu6/nvHcaYKH2Fhwe33X8
u4emFT5RhwPHUUjMpItvjZGVxFX4esfyiRy54JcWOpKPf2U0ZwyNe/QXpsatlAxAQ2xzLiRu3D7N
ly/CkNz4fmq6BDADAbxl02WRy0BHDAwiYvk8n5sthfm+tsWXm5dj9dVftUeJ80Njmwq0zmHQO2F2
9UWa/u7Hq4z7eryAdc9KbzFtDx1CzRvowWUOYV7GLEYYUg2+B0xjnYBpKQH9EyGQfd/R4XMJo9iW
bufN4dTiuVWg2B1oSaaqmJvZmO20wF4XAbaPAwjU+SpRrirw/sNzFRF+KoxS9Drx3FZT9U8+JWSa
tRd6Ji3sS6646BdmSsS67qmi2C8M9u3KRY5JLM7mlDUlw+wiKE2jtLbu0Ggb5GwG+piA+1QDRrcb
RC+VSeqsOWu/mxQBAVSGmHDThXwgpxiu8jJorA+0J2nup3clgYbv1Fr+5uJWrUBMhdjQv6/CRbEF
5gvWOVzrICk3zLTnvYzkbTwToKVlBHaPXZQ9NxX2VtE/atA2GmEpEPJIdHAVGnyHQpJQn8x62CTX
wN1WpUdyOgpQzrKzmbtRXieFNEsooL6Q33b26khPMkHePQ7mDvyBxvBO4MONw00XLLF1I6nu6eYQ
/4NVjAYnDhNHDL5fyjFn6cSzx7sEPmkF1+9Tzei2UgoCRIBdaSgfbdgdxjnZQ6BHohQKqGPy7o9M
+bEyfdG/V+h8XHpFRZjZnweaYcWvh3OA6ka8R2GH2C8gWrbDBPYOHL7xjz87GsftP2Rt1LEJSa0/
+HE4q4Xtd5wOpCYa3tVCq0vkXkxKB3viW0MQK98X9+QF/4+w2YCk2q4np0evtGTAUGZSKHgy2SmE
TXzMNlvfTWfPQZ8JVlMlTC5ubhqHzByC2benYsl4pCzdRYtI4uQOVTu+Xg1UPgJ9ORldbbWWTnb7
SEUyzSbVDTardwmdcnvuTZNEXqOH9jh7quqeyq+Xece486mDmVaYW+oWfBelFdA003R46U0Av6Jh
bdSSrRDzDYmYsv2ajyBhyFTsSgq3l2ivq2Ups7sUCGGWw2qjSa164tAx7v6N7FTwAX27w+t8d3Wl
sl9nwHfJue73ZU3PMxypianIcmvg6rus4NjP+FNEtWVZ8k2NZ3ffeqWhIShQQClEZB2+A9qOoigV
IiPx3MFVu2mUZ/tfHq1f1/OK2qDv8vZsPq69I3MkP69qiapWsnuTzi+jrvaBpvVOAczvIL4Dmekx
O4d1SKmKUxoctHbCijamySNvAkbL90QAd0Zq5uhPNRn6qR4FBAphw6rxpE+SKj/a44EjvHs1qU++
lAysgF52da4wPIwMOh/TekCPR/e1jOnuYWHH8moAUVnU7kJfVItbxV2q6zp7TNKBGqXyE3Zx446/
2X/pZDoTl98AMFm50x2s8SIyk8sjQj9O6EAk/rP2UbkGGR5Sxh7vgDeRTSw6q0iBWUrIW2Mm+1n4
QGf+UDZcXcaGP+SFvm8lp/JzRDsQAEdwGV2FyvuV6sDFY3a00UwJJVOgqVsVZse02Ye8JihsSy5U
XPsFO0WqOuksqgC/p2R/feIlNnCVzuChpANhjhdwOjT0iqQe5/R4jVRVXYmDXGiKScoPdtUP88QH
9Af7HlC3BCrJw8C8+77RQStO6ybQcEXOjCI5ujXFyfNCC++AzD9goNcgSZOXWZqT/qr19xBAsq6p
M8QKzvGcHxjL8cKEk2e+Qu5fjx/GXOZOS/SAbPWQjbSf+5XOgZl+wKhjgKIsGL6psvS09nNIFMH/
hqvbTDw5t0HyIkcMaYzKH59Fa4Cr1NRuusOjk4vOXFPgYJ+MA7D85QQ0Kk4+VDPTBHnyaOA2olpE
M+hQANdW//KFsTvWkZHb2T4+slvvq3+mJmE1cQTh+ME9ZqbpFx6OE9PmTl56DzC9rITAhr4scuTk
+3FpaHS7zeBvOF6SmRdVTd1CIHFqxAjNMMzBTF9eecrrIFOZbguJd3SPtlJ80m85zynuZi0zC1lq
9RHi0LwvkTmsrcUKXn4ZBHFMl1ZBbcjT6eMXy7zA6hn/vMCWW759oJGRzJqQ42d5SVn2CSXaKoPy
0UuHQkbiSIwvyrwPi62n+dM/aug3alsu0CmosVkAIkaj1SFAOk9cOehlV5fVMaVXnWVIo99bowQ6
jvCIexxkK+AWQVtLn/XEcsZDkUtxN75nxZP0fyuFsi4iUAHM8U4vq+1ws3T1Z4tSTB4Wr4rTb2Vu
bgzY3TQBN0jLI1x3PlkSTnP9HgJ4J4IoSgn/uwGerGv2ZvLu6BlhAaVMEfCxCSVRwvDnKfuFgLfW
rFeLtCHnyG1K44r5jL9aUSBQCcsRtkGlQVv9ofcrLRM9aqgu+ry4iSpQVMs+VufSlBmpSlNq7Qny
a+gIhmltHqgwu9ZtsijnWN2ShO1oJ765WmOaOeJ7JAuVtis46I8svTlc/Du0+D3YgTThcBci1KuH
6ceXNDJoq1Lo7RrRtkeWyB6nsIcJRngdAPYJyi7a69GxCygbZP2BY8Ux3zHf0rS2op/MirlnEdTv
Y1b2x9KSwFHgTmvegchzk0v2TjviSi1YiSX4NfWKnE1JoEQx7adpZPygLom97zcafZSsGn0WeDJ9
IFil2ywY9S938tW4XflsUN7241PtdghyLa4f+47CNnA6TlrdNpR5GZ0tIc54iZwubsfNfXLW0Me5
iAzMKMFylqxahDOEneYnmKLJxDVQtRYDnRupRmxFrmF3RDtMRlB6+TXf/bX+OtQMrGX58ebraoqB
PYYx3gOFx/2YJ8COjiVcngynKiXdhqIKNx7KPPoH/5+vOs2PXGPXgMpVSC2LXTK02NG/SqUm/7nI
LFYsJWia9l+MKVznw27RTFB9bKK4MpDdLOZLCEi4DQVneoIenYcFo2YMzBPs+9UNmoGXCidrI7/i
hnn/Zck6ginECv+0jA+k7XHIJdRM9PwOLS3HOlyG80pGSthVe/qFt827rQsVUfUUbJ1+kaAokzIO
Kt4QVVQ+xQR+9Nlv3WYI9QobT5kb3FmIUpblDnb/2fd5Bp7DA4/JPC7WmS5fmMtpxkufOEaW5C60
cgVNv4xS47G7zpu0FezBalGU9p0g1e0m0Om0EIsfTtKXZxjyrpt3D1nhWqqAfdqndSyT8+Y95TkB
PEVTcHCLbvQsvsVeQX19YcUV5E/pRBWmNoL5PUAT9U4dhfoNPUu/ht2hVUOYcQyjBxrKWFwxe//+
Lt7zL7sxrgRGom1jDEstMOnt5R66hBCdZIwMBRfogwqG/c9bVFnxUiYw9KOmZ2dUUj5YLQ+ZDTjQ
QFRhkMv9jfJcZSPBNzBaBuabNenLJU5KME1lFTd4VwQNVCGtfyHrvhiA/3A0LVKGKsXTsxEB6Dg6
/AMLPLzvIbYv2CkXtTS8pKKzmoUyxddn+aPJpomBj6TbtpllxURupBsyBM2fMb7ecW9JDBJy0GPZ
Ydy7Qlwfm2R2ANXb7nfGurgZ4uf9TxnIwJEDljzS7wSROtO8fJgprPjg9S1QHRUJaHK1evK59bzF
sY4SM7O4vD5ChYmWXNUiltWYOKdgBaTOgsZaLeYQglFXPctRVM7kzAwCzrNZoEr9v1pTfRsswkzo
7UsA5g/P7t85FKQdmtCoZzAadu5Gek5bV+7WkIoK7Ak3OIx9f0l/9i6gzIO4Lsyqn7lFK8wb1lEp
+TUW/k3osCJ/VAU7WZ0emG+n+n7RKKSPWw5C4Ixmtjm8uY4kn43csH2VnDHmJ47uubgPa4gXxKKV
kURbftkIkwy7yi5cmv+YU0T8B9ECTp95RduR+iwAmm/SX5Eb+9u4uuRLtKAzLSumkDylLy/MVTBx
8B7vibp8OpTtRi7JlNDAA5stj8JY1QOmtuuhW7veyXW/b6K4kzLTNt9x7aMC/qIRd+3IWPwVkoKt
dPK1jyVRDQ2QN9HRu/cHgEI8OXNbAQA/FQHv4RGBsrFuclXyPLgRx0LZ2Rd6+/LjX4r1yxqcROCE
j8nnGMbd8V9HRq+WNIfR0L0vjryUGFNijuSHzKq2JheV6xTFA+YDPzEuUOYQ9m1AGg95JbCg/AmX
ghog9lmPANToouZ5yc8eVZQwUuWi61UtNPsHqaa+VBnQZ+Llh+EPCOb456dBmMDjkFEI2BVhMe1F
o33txqpRyQzPnvm25dkgWbvpxP9bpBOqA+v10n5JCJD85g7EoZEFwBFTL902J+zk67YsQKpzDOyx
LK5H0GnZQcramR7WoPx5H5CFAeFNc6JaMcyIv6H3ZpWcBJ0mm9P00gIbOqSmMgBx7uhiDu4TI52E
ZYLoML/PuKoKxgCQQvOOVX/J2YpD0fkDSw0oXDWzc2gRCMP1cHRc/zeniyc/4JT4WA0O6XV9MhUf
d9hrFPH8wj1DPlj/hHYrRfHRfeUakeSxQ80nJ9qEMyI1P+jBtmQ04/WoZ2FW04PWs+aCPqYIFGrB
Dghueup/+oeARpTEN2lZ7zx6VYylwMckvB7W+rhu6khpVuLSdck3f/+Ij3qw1dhecON23BJz1x7D
cLHqv8VoMVeORCa5yQO+WhOcwwvDRRkoqd6z7UUXd+3qblrwHxKCAn1hJkyav0wYOdeTaSkKop1A
wAimSQiJTr8N8Pn1qXk/Osa65tP1gb642J5WXGu+buWMvlL3aUNIk0gxKXKNUdoOoZHbbIJ1cpzM
4w5xp6jNaP2xaet1m7h+HxLr/nO3/NzrPT03qr6mWNvjYleG6wawyMWQuRXJWhSrdRB/e8EfAsTN
vlpkNEeLbzg77yySPQQfxmFndV9DHr6NEuRV/F/PPLn9VnT08b61vKSIji/gvJwn+NwUC6uAmB7Q
dmnijzIS/ApGMxxaCQaurbkLoYkD0WzrZDfFRm3L55EnmtQztyraoH2JfdypjGkqtrYdGYvCFfJt
dw7++DOaWiUyznN9ahSew9EXczyZDWkyFji8Eq6O3Q/DYEoSV9m6jnaWU+XySmUFqoWoO5Smsqhv
e99rURJLaO0zzdjdu8ZMnTh/EnhE61C//rT12I9l/2Th95RG+gRxK+qAdG+eoslJVrL473FaC4d2
Gzst3jSq73AWuFnhV61jCdp6ioWSEowsTY872BZHOD5D/owMYjw/91PCeqbSPg/oxp0EVI2f63rR
igCK/8cVGfCVGQJTA8R4VnoL+DY3yfCsuAEGRtp70HPMP6o3ib10c45kzVf0E3LHIUgJVacdpHZW
t/28pTIFpMUS40VCXlJK50ttQT4vLyfkSi/NQ6kt4dyTDenE8ZGL8QAt0APLGEX+nm+2v572AaCd
SPWu4VO/1VOTyehAsEUpJR92oEx/d+EzQL5cNfoNdgpU7izk