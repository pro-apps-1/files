<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmT7z939vSodbAbXixfywPB0IJBoyd8Qc8AuzfP9CbDQ6MCYnP2K8XjkLzKJ2dTjtkpC/goN
j2JlbNs75w/6nVtq2CO6C5g0/hD62cG+GTW8ychdWm3J2LRzc9jqJUBfhnD1iuLELG4ttgyC/EpW
NmPUb4nPK3DcI9pjgY32di1jeKuRZMGWDZlka6aDW9Kf9gkNkv/zw6FEZsKfGSnY41Jd2SPycsx5
3sE86oSnP5Eu/gZY8lvU4zeEDSpM6YcjGQGRlg30UZr/oXUPysMTD8bFf4PeQq5wS7IFUM4C48KY
EIfF9Xg9sE52AjZRNFc18Y+/3PDnwkftLVCUQkMX5NtZGIYccZDubR/7Zw5DcpXLx30Ed3/WFquv
LS+Krxjw0tgHEBqYIMBok/1bK9d+xbRC1e2Ik5Uai/GMokFKSHaX/t7q1JaSsCgfruIa7jkb631y
qDJwhLmUcEAldRSTmRJ7M2+GvQigk3x1ntbvhqk9/3WHZMlsdaeiOtrWLhb3+VqfRmhduCFsK3aC
VA53p62ay44tB3zRpfUkbfFO1eueo78rmOPS+lmvZJzOEwEhtsi8oho2bG9mQ+wpHsFb1h+9OUQx
nKcAuTOsW4ZDMx4s85fwRZQIYH3WEJjv3wWmoVpSO+dCSAkASW5q4hJFixh39uavPksgKo83yT3M
dJcBc36/HGwzaSGNrtoOjEFJIIMmSHxkyhDBZUQ0riWWhHyI7Z4iX52gzpEsd2FaQZLwGGLNKUp9
zOER+N3ffPaSKnRCtf7SkfTk2hqwtaNnQUoB9yRIjgfh2ITc3LT4l2cyj6OiSUS7ehkAVqlVLCiD
Zyz8VPIHHA82Bu5HvICeXAG4+nWrD9xO9iF+QUotXSbjYpcSuURmN5sU9sQmBkjiJ9YI0XnAxnIo
jmHqenpjPbw8J1zJQNsSrCtCqXy1KuzOfT3aKEtlZs+X1s5THnXRaxV8r/XRGWE7hJ6J3uRVibZR
cm2drzewNM5HVbohIxqd8AZClTgJHAjC/BT/qyMzVD6cpGZDItPHp8Z/6g+il2pkXvXg2rqiZtAl
b3FddNk/YciI38eNt1QqnJHzgo6DbfBHOfMfbI8a3tArvss7rBwNxOPSmcusgNpCpo2Chn8deH91
9f7OT6lk/ARj5Zc6gQxX+fwzsx+AWuWbzuaXDRw2hBr/uwfubltMrB94Wpd6RdgZNIxTtG77iN0w
g9CYi+ygb8eZEBj4CtnBy2rqkLeYub9ojFpCu3xk6pwnOACpK22/vML6JwzxokxcRj4g2o62G96m
3lxsJ8BxJYy5xples0ACs1Ye9o2+UfaPUn+VUZ5thUUXD84Ef0//TwGKEtoZG3dCgL+6gOA9iol/
3CgXNhrGHqnpiRXyC9bgfvWoFqUjZ6N+76zTeWxBn50ikwDdXOrw4xEJWYl/C5wdoXGuc6GRCOz9
+F4mcke4fHwiyq/zGlXipLoxzM1CsZvyUPJLMstVIeU4CB/4KuFv7PTkUp2NuAvdBiFy+tO2GYU1
A1AdmcNYt7OIUuU4eMaVzGZqClpGvMZ6R06dXoCSX6XfKuyVnwYlLra+9IniKNO5/dSC4Cm4B5SB
JaKi3u+8xMOQQBVUGOmhJvdyjZ8oPjtXjLevq34G72NQL5K8wnJaP5oml8Ac5qx+oU+M4UQru6gi
6022fs3WpwI1XrJSnvzGU4xlcQIqoPCISK9RKi/dt672KPHY7T3JDm74DoLXzN1CeqdyFiw3JfuR
/FadOEi7jjC9gZI+8WBlBpDnpJDBZlTaBa0fBMHebdP0d1Cwot2a4vDDlD2romqite7PxdNECksd
w0ipCHcqqc3VHqp5nFAVb4YrSV4+KdrmTRQFdzSYInv3OcIlmhWluR1xlLTAPS2Q4NvN6TtJTYm2
7trY4aHudQVFzEd1pWYk21M9N1pzLZuWLrgnb3iJIWIbW/Q+2Nr2ReFIXb+CwerDIh8jMZrOlVRj
spPORdWVkioIgculdmeBrqprrRq5XL9ESJtFWOCO1RShbT+JZm9qbYYgzY4pw72RnYiz0K6nfvp9
c4Kt0rrzyfTlMPnVWOWUC30ADaV3WDrAx6orL+cRghIVFcb+nRYm0wDg8gk5xfZ5dfq9wLKr9yGi
4l/SO8+4z5usROTCS5tsFmc69GrIKTTTHVNzmKTZOSt47S/eLFhAUTdnOVE8rNSNb5Hdp9QbiEiD
w8sW2BP9EIruh5RruwjOxvjPsVgkZOAf9Ki8w8YMoL7ejueGRDsrvnj0IweQZ5JUy8Oq4OcPxGfU
V3DmfoASczlCi9bGyLTwfHCs2Wcq1wAQ/C432/bvBOInVu736tJdhcmp7QFbdBXQvGsp/+P4uWE9
74wXd+ZiBRPq1I4PEQW/hchQ4U40XPWwrIA/G2T/pLeKakolbNF/1G+w3+dO2LzskyqMwOeRARjo
FiqrImkMWADbAnOXRAZaO8LHO5UdeqmimOi9Q3/zgnkb09u5KErl6Lt4AUqg9I4WI4Fk6wQgYVL6
PWdq8HZBy99nEqmiGfutYDyGp7p/Irf+sCKVnxLVYAOw52yYXCUdVGZ5hZQjSYjdU0kwVnsfOzUE
I+yV8qQsVu8IBr14jZdOC1wY1ipaSnpeMbYFNkzzchbygHXj/a0QrKAXR+IGG8HsLv56O4DyG45v
X1rqepVXJOax2GXBTdn3VS+iH9+WlnBfTMcFAYM/FuynuSWkrD8zWfm0EnFkWIx8WGruO7/tM80X
aY+ooEJhTAbzVV/iu4caactFLz3uW3WI3UkA2ZqV1JtzmcyYOB/et0nbjWw/Hq+P7JT5au9f8E/m
WmqBPaWKE3iY5jTa+hXnH1HoPv/zhiTQo1T2ajEdviU50GnIRDFe461D6cyDAm1I+vKBILkCWYM7
0DOfoOt3h9NA31T73fq47ax7JBpvrDm8fqaBRIsROYG10MbL7MDkkos1ddRuwX3ba4q/2PkHebT+
01a8v1h0zzaNykzsazWUWgV457C89zntMkxejpUO0d9etXFe1nSZ/9Cz/k74e7tNFQaiUr7t0zw7
MKziEPaj17koFwrkaflo0ZsXrsQdR95QCRNMPv/VoaYJskD18pK9a6iay0Mlxmfd5fmgCF2ZVQ1b
qeotmsrz5FL4ouNbNdoySWX41y11qiLQqGctoFY+CH/9CF4TdTMRRhDODZvWbIyiBOuALZXHPZgt
wCr6S4Evrz03bLyDwMx06nqmuKbNXc5DySGDFXISDaw7IVDpQ0/wXcU/QONFzFgqWRHnCf7TfknW
oCHIhH/RQFJ4YeysV8b23cuAx1PUDAnv1TSg53OPlQ8RzTkJqiSsGiMGEzoISfpTQdlkQp0HyD5V
FmWnDaJIFe+L1NnW8xmHJlTk9C7/BmIOk9WAZ5U7c6LTdBjN5vazLL2ecXy4xrI+sGiUNtHmyWHT
ntOM8nMoQJyb8cFNJq9V8xnAsZYczpinejfPYw78DtLDA95CbnxS+/+d5de3be3gPHkMspK/dG1R
0/2sUPAZJfHlGJC+bkKNSDyt2aOtinruKFLmW+shm+Z0d8t03ymLawxfdx7yuv6gmD4mVnc2vMaN
AvFMpz5EOhm5krmgEoptXQl+WISjWvE9YJ25xSj2Wth0+Y/h46IYI0UNwcZNFgMsP7WuU/3O9vuq
6Hu6B0wJlJJc3w6BrwVvOR9vOFznJkmMxeFrKDAifjl1zy/BK09pBj63KhLUKedB6aFRCmOwwxAs
SzBkIrbzYJk/Ehd0+FTPjCmENZ15b+9wkLGrjT5bYRWvryfcPgQKqTJWYNXoz91HKm6DSNo9T569
2yCuqjes6/tqf2MPw8M+OVpr9OmvX2Mf57MbxC5ScAQeXInZ5B4Al4FXfC0EMGeqnl9ughaBauQa
XIVJ6ljgfyazktLN+IfP2G08Gr51jmvbirx3edOdCgquxv1WfdaY6lSVa6jD3MysrVL88MqkrEIv
4UgCIjACaHKrWihi3oC9uvaM6O4vLyA7VoR9hxWLNyKUPH0NeeStl7zOwcd/qIyLAVBe9Y0h9T4K
xsNBD/tO+GSXOsZevq6za1TYwRdzmeUvxNibKpTFHvHcTe/SohooeQDuP3LVyAqVLgoPAeRgQON9
ubTOPUJVtw0swNPmMrOFui8UXxwZSm/PlzTXBv/uOoG7YiKx3clsa9KWo6foTqxx4+H2qJR6vtaj
Pv+GW4j/YGNlkzW7rBXkAYZdWOqWpuur52EqsaumbTqsFg1LwYPtr7IUsKJYKDGMDn/NXfCqJD4m
Fh+/MbiC26pQwHXkgy+0D5EFB17twezJ+3eTwBCrlRUhgGIxQnFNfDUSB3CbUcpQx6S7lkQLcmLi
XVPpF+JZYcbaSM3FPZ6KxSSA9UMhINm2Tf5IzTu44d75n3v+JUREydUvBU2cwvtyCwxMxgFX0czX
qPqZUIX5fW10qSjbsNdREf+VD6+yw1gZZ3LXeArrZyx96Ut+6tBZVUn5dsUm5oHAtnOphRRMQZ9E
SWqxYtUZRrc4JGivqF6/n63drR/8XzmaP5g8Hh8umt2qfBtT19mYppa/u05U09RmjRX9z9ePlCsV
NBEagwjE0Q2EoYGgzdJj6fqr8VE1rYFmojVdv+DXsxrQgzkGkO8bpF+7vRPiDuutB+vj5zIZX1bk
bzsHK42bOAuhXmfv4nP+hp5KW8qQ3mIQ5IM/wiMsdXwhX9jVDfM+ummRBAsSUFUnTL0Mh4/QiKvt
bw+PyDo8rimSHBPWf9rtXU7vpIRnV31NYbaOMmlnbh0lNRngIvZK4H4Mp2r+39hKxGH13JfV79T0
pv3zXbXCBFGc76W+ypi24wpvQLMyLQwJzRrgYbIBDZyVTGLI6dHTLGHtNNZSUkZr/CFCkVagNQ5w
UASfZSXpRh60hvwrruhWpdogiOJ8HlhtUHUmJBH5vhp0jz7pBc+2L9RPfIv5mtE2EsyaNybCowbE
SwGq1ltBUnfU+YQTB1CI41SS387HwegSZEbREzP6ibXNanabbha6wedDbcE6M/E2m8F3MHTY9wtG
OV7u1FvBKifVfVYDDpxWLQFX+6hj3Jkd1whqYgBox+zcPOflxw6tiifNd6W43RnJ+evTogn5QnGJ
V9/XT7+G52f57OQyVURDmh1EQhK25EVd6q3PRdCf82yg8JR1bb85d198w7N41Oi7jz41HCI1XgHD
t2h5/NRmTHuEvP52TtyXuGtUNCR350slG3GtKRSiFeRR28WO/Kc2Z/mal5RaHfFepWYqlHojkYVO
wE/BnP1ComPlGA0lD/B61KuVopGmNHdwdk2zrV0i6CG1GuLJj/v6ALK2mT6tKcZ9eygnMSj5PkXI
+gMqA0NnDUXGfTY4thoSs17vK6lAGIHA6haitTfjxgvynkoYE0i1PRiv/r73YubVBOiBtP3aUTwD
ZfX2Rr6e07Sm09lPWXBxtifSAN2XS9wLeQwsWZdN86YbuR16q7GSmgp+fx73hbKxxvZwrjnxNMXz
nmboTu99AldvzY4IZPam8FLiam6He3POPbxMfr3eE39AI0AwA7Q+ThjBcb04Ko0w75nQUSW4UOHc
l0SGBXKB5NQNbEZa8rGEuU3CwpI/v0ZtdXIVLzzbVth09xL3I0juqYe8N5gT87Hv0JR1yhOx6FOH
uedzh4cD/prpLcvYm9lZeZfZzCS9j1qrVBrMT9mGQv0pDiYJz3fuQTPHUpU6Vc9LBQpoWJGnzRp2
SvhTJ+dHtVUS6BwDGDH73br9Z0hS89c8vdTvccuZMgIJPwOWOa6uifkj+3QYjfcIoQyfrKTdlAn7
YzwISqd5nLe5rkccdIharXS2KRDv8s33MihF0nAoD2MPwuqwn0sxTOYja+i++e2Acx2WCe4dkzuG
Hxq6fhABGZSHl9Pv9oNxBIdpIqj6OrkmZvDY0en9WfmBNWZCe+dEB+TkqTSdVhZfEOZGvr8GJFxK
vw62AIRKBDaItxtEM8rDVnrPW2ptw6BlopIO7GCGKgdKTf1+4HzS7Ay/JcYnOzHqsi2nIcWtzJuz
UrWNJ7WtumEMExJ1LGwB2dfgw0+aGCbuXmUUCmyPi9tPePgVRDjUaATa7YHnhiHDK9ma8cdPrrCX
W3+I9K4VqDnhzbocg2GmQyzTn6265Snc0hVwVIbWBZetKX+mdpBUgBoVxABQoqgSF+ImWsSSv3Kb
ZPFZyxFf+mYmyffv7395SI1MYvcKoTt8dW2railGdfWMgMGvNMoQr6E4PMCMdlSBhAX8mHK7Lj08
gOckzDgM0pt/yUGte5wOvpS/5fY+sIgIBNcbvgopU4F/T3H131JRAJ0gz1tJZqP0QNOFnwQcvicv
gMGPPzZAu8+H1C7FfSdLkJfWcoeDLCncTDwrsbt3K2aHrs3iKqSAlgz8JkxbhGjKrboKB8m+JHGi
CmSExcT5CebaenNhsEGYM9Af6BPd6Hg72RrA+KsPyu2wibv166Vdxe8IaVzlJxxt8a9NZ4JnFcJK
+Z4YLBZ2zViLTsDvuXwfaZxReD7mJvi5nXN2sf3oAEaWTvaGmcI8ygTqMM4CNskD9ktq7e3NRzPO
583yV3K2NFWHCtZyDhhdeuHCqWpGgqg65heuwlFDjzFAKWw/G/+eGyAlYIvKXpVPmkEE5Xb85HuY
b6UeJOK9dIzrJ4T7kU3v5G5RN8Bv1F6NuhrMh14SgFjTtmb0CRzpMAPeUJTk2CKzL717i73b2S+M
ZNYrOUSqcvceUhrp7GJ2smvprFmtzBZ4t1dfJ73awp0pIaC7CLiMbsI1dNNTvnw865EFZvxlnbWY
SOySaqInx1RmS7B1ivi+YI/vOSL4/FrALMe1sdepVFotQ7ffGKZkiL0LfgsDYgxCmNRrgRLlC32e
dakYQzlkFhoo3mE6IUzChf7rOMkiKr5c4WS1ddhoz2JwXhVNtxDjzvUfjlkUBBTTpfmafXKTEX2X
rSun7C5UGrLeobQ7FTI+FKXCesv268uQWYS1nrEqm+oiXeSjFsTUMkQxz0ymu2mleTE15e7fszr6
js3x6QHjXtWW4DTfkBwTT8QXK1CqHOFKN5K1VDMbUeYGGDKc2HqllhMCvU45dQUe8Wa13K6xb64F
UVtfrz/phjoxYcWoeEglPiH9YtL5Z6O0VElLJne/uWrhOr/ORkGUpBo3Yp4qOCNuQB4U5tAK9wDa
jP+bWRJ3oMCFgekY61ZfmOCAtF5e4P93wZglVHH5euPhNUnKnf4T17689MmqwaumvUUmk1X0cQTe
tPC4bQ/6bWhzeAwtEidss8Oz509RhpWN5S+NgmROzFYZ2vqOyCvIZLCYrC81PmYkkz/69MwWBZKd
+5JFNASQmEwbw45yGNpJZUZvN9CC1C33YJeeQtVIW0SAFj3rx1gep20JnlLNFJfcRmpfxclwIjIc
NQR0/ic9R39N8hiKQohop18OYb+iQcUcpRqFLAjikOOUY9ekgjD6yytSMhkYKJEhCLh0sO5y8/p6
mnS2uuRKD2kTKDocQ9GPGGlwkOIGLKL6IKCNh5JI5Mk6q4J0M2iOHf1MjPexYQSIpVQHFZ5aUn9x
MEfoUtRifIOuULLjlPE7ngtyH0vBrk/czkkR6vRbezS8Q/+1ckkkO9yINIE4Or4RyaW85tnoRtKs
tPqNT+vXQouJ1Lrd32jOjDpLVl/u8280Hp01rgS5lk3Y3fRRqpe3fb98G35Pj9ACKuULsTMjAY1z
Zd91QTnYju3wTIz6PzQpkFSgXaCDPGDBcOWOAS+GKZcfrSA9f0WUyC5P6beSesNSftnVbKJWFddV
Iurj4E2gWn2MLzYzkXZwYOIqBT3fceC543RE8Bw5AFqcPtbl/wfHJIgAX7XcHFDBsVhis2STx3RE
oqp63gieU2r3WzI2l8H8NQHzk2kCpgv/IUk+uDsNNZgVyEn5lbwLZ4nRlIT7JqRVwIsvvsijql5s
YE2Y27n3f/i0wcANCWUHg1TK9OG1j2s8+VAUDlc5YYpWR7zUqCpAIzxeIQ/ckzfB/svuGsYXcmpU
UGn7weK/ti7yrVSqmv/FLqVlI0x4ye54SY88ZLqpq+KLu+z4U9URooLxWO2MBV8+eCdLYZkbjk+/
Vjr/G9iECHoWluhapjjrflRESPVzN9GUB8dD6qGfCxEof4SOgQMCJUVNQ2q0RS2Hg9Ox4RQfLjER
T8SLP53n7ASNEo788+Hrn4pYI+YOyxVDG7Enn1+wRNvvYkPBHaHLTcJIRc3pUWuXCZVGMGxUgQ7s
gQ1J2iZeqjqS2ChOXl7QIAEVx6RHCz3ngA1daTJbaG3eTmzSVIQ/9QsfyDPhOp26U6nWQw1Isk8m
C/Aus0+v/Z8Teq5REWJPNwxqpKPUxC5w3HJA/Tm1zwPyZ9lvDB9JAjKHZwIpIwANq98VueNaTk4h
u8zz5WvRaiCT00458WpFW6NOgMym+uM05LQTgOL0xK17+QUiiziYf8SuX07iD2QjEf6tOwwjUVHq
GB8ZrxMm