<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyC5N3jNfwJ/j2xhoHXdeCyCK3RWPK7wtEX2nroDq2zmEPTwt14fOKpj+OmM6eHldrADNReI
ilNn0u+dlpeRjFCfRjg0ZsREVbJcMbtKsWMkKUgxng4U/hpIwE0TlNLfV7O6rzqPnBKFJh2YI4Jz
NP3wIeTmNUgFhdzYmUN1gh/e2aNPkcg+rSL1eFYR3iH81jfempGSxOXxvjDiyuLXH6MEYEeFvr6C
KmuQllQzg1WumZhQSiTEo92XgTDMorRnxgiomtdcw3OBYl06iL2goSIbkba2S++dNUgn0EuIItMS
gxHg3CgwNphPL4QzLj4rVja93wTOid7P+kHo1QGcfAcAYsitI9xyJYo1Jfqxvzcy1qJDQOYiadbG
aubQ2dnHOLsND2HXwcYKR7nakRbSXhv1++wh4xzAf5lL/NYqXIf+HJV8rGKVuiL69TzRTOfGWNOF
H/C7n3TjwZscuGAAMsiB3tEF0DqGnkzrahwCFgeHlb5lpUniQtprfv5D9RuWYN/RDqedyLSKfSqT
f2dKs5rQ2ZKDKdOQ5KnKoYMY85k+T7SALCzDVzxf5YItqNynZDKK2sroK/VASvBKEdRbb8aAA87i
nIsKMHGG4Uu+KYA89VBSBZf9FtCQ1cf8yyetj0qgMIZNmcqi+aXQ/xHMx55seB5M0Dq9xxTg0G5V
xV/SLOBuV3YZFXpwI77OO2RAi4H3foxK50DI0XCoPVHkdEi7urjgFmRcQiSsmuoII4okiI9TNUM0
q9cjIiUpQvrPUWny1SIkXDZa9ojOQ/jZHuX/CSwY+tqJ+j0mOHeJ7R+J4XBEhmNzqvUZBj3WLlBI
BN4kLtxMUaV0CAefv/rEOGXgeuQQPUtRhlDyk9ag0+PFff1jd859AKvUj4HqYoTGvpPehkT4Swpn
tvL/J0NwdTcLEWS43gfBkDs0Ly22WmqDKUzzFqzToqsZCLAKmdw4nRA8tp0IbRr1NESGnSZVg48f
zbUk0Esc0DBfVNebJiSaSZIMTrVI7Qk2Zjl4gNPvIpGYqvpXhp4GOUbASI0SeRAdwvgEFPShLy+C
OE9KWGLLe5sZxkPeTDEuC+kbneqY9owEqLb+Ew4uOaY/DBqzNRRGX6Wa7xJOBLaoKsatQXRr7BBK
3kVs2sLTEboojFqXWnBLDFiJMRD4ySHDLg4JbTSC0LZGdzC8phqQkPQD4Iq0+aNbWg3QHKm/L6Hg
0S3/OHl5+PdZywV8IsNllgWSrzrowWXgl+GVD1jq130VdUPnGT1JdG1Juq90KUWVTconA3PL4SME
M4PINzXP/MIsS7HwY78vdSEMkoqXSgJdqon/W5q7AWe8uX99QS269o9iTVZZPOrtVihH3z1w9MMi
VqU7N1vC5R6LxX07UgP0Prq+t3+WFWfA3Nn3YPGl3PawdAbkWfeDU2yjhzkk9jW1Sa/CzQRHXAxD
0ayfhaRLqjbxvNU2rg+1wHLZtDazEXXpG1+YBDRh7jkvjbMcD0jrCrr8FdIyU03+mI+7IJvfSBEl
X+wgMvMUkE/CMLmUNc8/K4E5IJqtvDfrXTFHvKRP2jePTOYzzelVoUkjEKF88SGbGqJGL+jQzvPr
j4whBfX+mmEkTVlc4mYqMXOqf9t2JpdXdcA27oS54UohJ5vJh2NceVMMmn13Bxc4TIHOQhUW3UmT
FcBiZKbWfRo15QFS8FZgI+EcKycXmVPzRstVZC0eBxNTrc/FgcVF0lYGFNZLDEWnyu50oapsR7Pw
/YZjjUWPAqRF7zLXK5uGkxumDaapm/74ZcvxlaAHfmnaZ6wWkUsnsPlENVtN7FUGHGvUpAd8mqZ2
0+aEh6nUi+NlTBRSyS9K0TYWEAaeovshRO/3wDtx9XXN/DEbnghw8O004QtLiS9q6nXenuccSRPG
TZXuY0mcXos6n0xhTbzRwPtHlmdlm6+vjdAAt47pgygKQzjoH8avzmCL7+kR4mFuhRhog3ufr33Z
LSSwso8sZ1Egkc/iT6ejDz1ebd8AdMpJLGkp+cA8NJeUbxfviis8nafZjwcJjulqG7gFJdMicrza
dCQkZvKWfKnF87iITVXbshCawKe9jJCfwomssIvSdwbwTlUVnj5D9EwW8Q7B9T2X7r6P2b4+XHbm
9o45cBZC4AhxvzA98GMMZ4ZOgFfXGJxWBPbbb45N8cBgBFl66a5fjHCjrvyuHYz/8C3gGfDlv2P4
kxXYOiy2nMalG1PApZ8aot2MtTEqYfXEkngHZi6TGq+68jA93uQRIMeDrOQqCrwEMuRbG8jCY3Lp
JkGkqqUxnoZrgjdQi842qsC+gWy4tp1MOFRxO8pHvfWeoHzfYW6QfNu28bh7DKhw3bdIy8MNb/Ff
VuOb2B1HqCkIG7PAZnS1xa1CYFAlD+xcAIDo8jvZshfa98vcIMmI+DdBzRRYVICEMVOw8yyDuWZl
mKxtKvlng7DXDVaOZsJaocTJxIqm9sDRCMSxjOovd4UnSOiSm88m3i9RoIPlcH0d+M+NvvHpWyfp
UllsJc5xh/2Vww2sv/UDaUdkORFAbYQgBidz6yQ8o5SQ7aX0PkYnIV7mGEeMzG534pGNALikrEWz
dPXK7NXVX5G6InMDpvGmouOrjluL3GvIPI4PcNY82GwS84LwVnApfTFu9mkdvji0h/N9QNAhxLuh
DMjBLdogYtHdU58WsH+hHO+gO4tKmsaYfordo8OPPIIqakdlOjh5UUPVhZBETeEkqOK6Ye02iHNX
eol3RtMeIdo6GtPXr4Rm9+SSyGe1t/s6YbduexuAAV9npp2LJG8YncP1PBmHjtlqOSRk1oj1rB/j
DZqb3G3DJ+3Zgq9ZrL8tGUrMhEmDu71uJsiuPd3IQBGdkMQZsaBpi2CClQmopn57/57mRuhibWTl
Cd6VsskEayZkBvzYeebQjW0Aoo901AulN8F7dzN1pUupd3q7D+e1mQcDd1OUf1bwLV+sFkSUQ/Hn
CEgcEGODyN5x77+s1vbNQqmQIzkZGvdEoUqBfnRmTEydntnwjIH/jmtWRbVyCs1nvviflBCXWTuK
AfGU2kZP+MCWEvlX0L9NU86xc+iFNK6R5s+wSST8tg0aTfxMyNXUm5C/sYv1T+9T1cDCkK8rmoOt
5qRYtpZipmjfuDmt4ULUx/hlex8lW/iCcmh7ILXSwy200uJNlbOItpZnIy4gjU7KFLgPqkwEks2z
3sbILU7YZ4IEWeJMvDINllksjFtd3pk0GqdI3Bmj+R79zip43JcORFldWNShe66GbjNwb74iIeHD
PWCxSv8lLLPZ+RepseOmmFWSKjgwNf8KfpUmIYm7MyS1AXRVpIsUN+eqWVBAdHOBaD1Poh1x1Yq8
lGHYkDZVaXfjYRVRA75pH8yMmlLOuKEgJgRWIimaKcE2hXk+p/j2mhYkL/1/sODic8tSB7ZB8ZLf
YDHtST9uYz0UW8hl80aDpSzCFjhEGOwvqpxSjL0TqrCN0mHeGDDulKHm3ICtzbX3fkfeUh/3JLTy
1YqCi7BTgKRwSY7zlJHF5/RthaE2L91by5mG/m34pzhe1nVSmyISTeXQ+wjFRHy1ZZdHn/gq4jaJ
Pyu5vTAvBofqWbUWVV99Z5SX2Lhm29JidLQFmpXiYI2k6Zy7PHURXDiMhPmWjEwAFOWktaO22q+E
dhhfKeoWMCjrZu2Npl7QlYwPP3eqW6PnULhlfHEGSUDY0G5F1LHgGKTjumifs2jzuhbGpHt/4s/W
pLubA5tj6ktH2fw12nzzpwzu1wwFG/J7Si2/iLF9IlVZeZSfMA+mVn+0kYJVYxvg16tK8gLN/nvX
uG3J3Wet/EXXueRFmRvT6UWLsCFjdoG7HgPSyko5lRMBTvfOSvBjkUO9Kf3rS0OZC9O9hlg6bRRN
dinGlwbyQxN8yvgKzPM8wiszf5n091F/3y1UpxlZ40hywVprIR6viQQjUFhpGPPUWcfuqnHDskhB
2qBUG2FCpt4Ao2Ydc1A3tPiI+bFZlS23iBC1OuC/nk8XClS+vTzPiEz8rahjN8FY7hskku2Je1j+
+pE7ubQzoMKi/ecN3JUSkRxVjx3gM8MAlSjT5w+cHRVW3YOSxinSJvgIWBR5HTLbddZH997JcHZy
tLxibp73eivnDvKkPk4Hc/HuhExLJVD1THyYQQ7iG8IzkrjDKxVQSmQgT13/PyhTYQyD93H9pleh
1C+Qn9/gUDpc2G7zPdHT0WdzCj7Z6JK+YffRPlpXBUeeTKn9VabxdggsluOvkqbr1wmXO3UW7Vm8
jvBa43T+LI0YaL4U7ACfmtPbTBd/+l4P5DzH2Cm/QJDHVk5JxVaP8UKUfjRcYtnATQT3ykBAMUcE
xiWNso0GaqP6eiI5J0XY026P/fyUc2ILvwsqgsTfbdV5qb1NXN9Mgp4pNJKaydjrkfKC6t8RURe/
553wcvGELQeIihljRCDAVZLbawbnuz8cSERFJI8Wlz41sqzgYaGtx9rYyDhy1ue6VyonFTNII8wR
E8E5TBKxWos2FLwjhIQuvfixaUzbRsOKvqr1IeK8PFVIKIm3cV0xWpMv+yOrzTsG6CiB9pctTrBp
iUPTbt31Kq65xsWn2J4g4DUjjHjvvGtcwZBdyCdMD0uwjK6T0Kw4B0Dx0IzPOeLJeiBaTNifXHiN
0mHcAVKOut7IZQMcIAEbURfdhfYVVtlCux3cfJIeaFLjmJcEuxmgT19HsXwTZrwrcC/lLHUHGco/
GeIHnrVxdGwqrUC8yGz6FWDXVu+rqKelOdDmmPxekztQxeJ7PhVtb6xJBN7M2bo5G07abYxYz8DD
pnLe78N56QA7MOMdoMFFzT0EkH8URqPEJ9BgoSn2rujv/p/S6v+VnIBsHl0lnc+bM35CWvAoLVwg
I9kfqpIHK+u9ekvNSekROO9cRPdbCvth4eYQGO636C9PeQzGcx5H97OwY5KE9WMf0Ppw2VeEHEAj
brZWNLcSjSPA88Vt9mIgxUZqZYkiVRYpKE7zAAEPKa2xKSHZPbR+CQdzvQwhr/q2WJMNjeQhMjrO
/aJGgaFp0sny9BeQDsGetPPEGzwaQOOGW4RYIBzze0UJDxeZ976+LQS7vuDCMTBoI4xjAmh4XbgB
EoqS9Ewo5EgCqKmaWZvT5TKlzUzfcB4vt36+hiaPHWLCRFEmLIRyz7LPdPG6EDznoFM6gODjf7yF
2L2GtG6jyzqRJCMzRSoRpxOC/fEzyyS74d1EZVFgqzE8Yz89pCrnFkue3pIJUL2YsHMXCsjKfIZ+
P4gFC6sWErNGMnVh9VVb3Y+8+0TfPI3eRhMI8l7BtPx6DIhX3UrQ7MweKUvfdNnficQeR7Lcle3/
RxfQL/Yx77y4FU/epABRC6xtBNnhH5+G0AXj8RudD97d83755VmmG1NL/2QLPfUx+Z1TFlZUYExv
+WPYd8XjvvA1+2nHegunFfQJJ+usg/D0UEfcco2va9rHllU7TQtb3JqcjmmihfHxCzrZkVJXh8Ny
D5hCHyD52HSJDG+c2TLYP0IszgIzAtFlBhUlrfk9ZM2m38VaPhk+rAfql6ES+U2ZYo2p20IKrcgo
toGwxZhdIrIStanbIbmJrTVFgCgi+BfE+Zy7N5EHPBS2bGbXzMHqJgm/aoLAyER/Y70fp7X2aIFB
m+cYQMQP/e+/3ANgPASLRe9OdCIh52uC2CZgd3tMg47+pFvm1LFQBbERkFhBvW4VL7KbOcsFgxcI
K2Qxjp/qQRGpvf3Jq2+hKuCg1esJLHBfopEw2jx3uo8aNDLuNmFt3jL6D8UUpvhLbCca2X3MXaHr
Fqp3iKJGBfQ48b9Vl1kXBJsICofrYYi97RWfwAghoZkOTxhAH2LguXTTuuYQs1kDsXhhzGTxNCgG
MPXsx8kbgfLZMGE39ivj/rShyqXW1sBddhr0pwhbzEqb1MK2gJ2G2bWaNv5R1E8X7io4qU/fxCOd
lisgRfmsJjO7IiJzqRIoXAn6lBqFEMv7ebfqSftrLkc12JE7v8XlaJfMN1U1HXBlo3Wnyc4uJMQn
ziviHUom7R1fUaqnwShQPmEky5PLALTJPnl7Xb2tQABdiToiSpYvgmBfOtmAKp44IOkR4a/bhlUN
GPlMYYsgxLr9noYQ0GIDGjaHlGw/c0z5O4Go94RZ9hGbhyuR7uhVJn+eBXzQTMVIj1Cw9x3Bb4M4
1qrX242vPwjs+6WOSxhG7RzGi28oOk+gsuXfpbnu18Eg62x7yRFJycIiiqu/VnhoOObbzIdDRbjF
TP6S0YeBEWQkwAF7+zk/fbtsYWV2gkAm2x3C9CHdPAD6W8dO6kDI0dgdlnYrfCiDpHNaZheULM2F
XW31+BFzItsXpFJ/msmK33+iCvXFHAy+CvpEU4xn7qljLbOj2MrUbW6B1rrH2B+yDbKl/p0SW+dj
faLMj1qNoYxJ79vQZfVgJTEv5BliuV5SUOEU4W1fBQyHK+tulQjtAblqxIWbvIpkSNbn2NYZNXtx
2FlyDAFdNXb8enaTdDiqG+U4UbUHoes3pvrVTEMioH6LSmRpcHbEJa5bqLvxqlo0KubkVwVWqzbc
VTpm7VoHBg5busxwN61AFdJzvnoV4e5XZgKsJFQ396kOREHXWAtwsLxPXKwSYDX5Yu0pSv5E0NHI
dIzYPQe1EpaVdDAB1WLu35FpInJskjU4s6unkR6BKHgiR3vENjSApQ0GdNEv7GddA6KMawCnwOff
ZTgTje4GQuYmB5EAEsJ+Hb2ihRw08di3jD4KXnrpvFQfRLbbyjsIysiNu6Cqc3AELKlUlZq1cyAs
ssnVoQ3EazkBqdPbKVOb46QiOCLldqrNyg9S/icEWAawWkxLo/iGP35MePDmU/jQMfh2hTloElMF
FG/wxo/q8GxN0m98zF6sPoC0DcCVj9oaNs2gaOAZRlJ7r58TxI2y0sgdmbvmA9dHboht7BxMey5E
ZoSHFWbQV5VsWss1BGRub40wvGs21mOVSYBIwomuoRX4R+wZJ4/8Soyb051QJYoERZRZHdD7zl0o
suZLeJvWgwV0xoVtTvB7VmwMpn7IyS1AHnBhrrrCpVfYyY9M4hEagAIcVY27/ypqMJQVvmmprjXv
pkaKHyurV9rcRQIXMSqJJbHqZc8tLeVb1Gq/AYVCZhutMurpvtf0sJYD85iMuKtaVM6+8GUMLSOR
KRMQiGIjQZw+wR4JjAqm0/AkrVMuSbfjvJH2JuOijyjCOCt8jfmojgtPv97JscUVN/hSR+2j00DI
nhD4PZSxOdaH6LMNN5WJhdR4ihsi5Fsxr6EpYtYijbEqyJ/Mqh3n2G5Eas+1niPT6kbBL6OEt5mi
2M8xqz1yfelc1hTc3gl+ZNg0+FSuKdlyCQE2623QpXqflxpEsHCagf+Dc8mKwdxrA4ELwYIhMgO0
Ay8LA+QAN37ZzhlWPk6CInhIHZrEiqN0BPWSbokc8OLYvlSZb7pJM2yYGYVSHtVUbfLao+Mtek7l
l8u5UgW/cVO/x/HaQOyFsCHiUDVJLAeDs9qYOCz9Q9F9JWDBMPz88cmUSSea2Xp8FSN9v0VSJWO+
y5QpzLL7mDUKTlpR+6AQ1HW/Kr2Vo9zkPIZ+Pc3kgO3Gpje/falbCb0lXh7x1PpEKUxmprLjM/m/
A32HmLlD5zX0R/yxeMaibs1lp54FbyTiqSep4z55GOCDh+SMjM6TZqTRq9oB9+T9PZZihIwdnvgu
Do0KS4ivhzz6FMKpudsIdrwpf+3FD7IKLaGqnd7tuDv/o8tNeBRdYMwdpqGO1yXXTwtD/1Mrqi8f
7syENWCDSsGho5Shud6uoLt7gN1dIiLpYQw+ME+Rw2kI+Z++kdxifX8OGVWcjXTV1N1QDxsVR920
JRDBjeXGKjC1/DeoPhwxuwwpbobvVW+kRfOhREVrwvMR1VAGj6i4YlL8j4MhWGUuMnk2yyypMlUe
a9pX/Qeu5RF4YzgzwSar05ZtgtWMSkn4i7cnhBr0DuTFGHT3yoqp/z5FEvyA7PRo9Rx8C3IzzGO9
DaJFnIibGMN0a11nClSoJWS1M1er3PnpIBecElgeXdVW0ZDZ1NeaTrj7V9Xwz5WxUgAR1G59ipSY
889lBByBmqexoQjJwOIEgGlktFGumFx6FXGl/6Hs1NaWlLmkoY8TJwNTBFUpoSHt4TDwzw1aantr
LqkMCpRuVAcW8DeS4CXrkhsm/pGTDu4rsyEr7/EbdyBXVBHbR8Q8W6jteRPAsZk3CFCiC7IlgLLl
OIikvM0GKk11K/qkuP+Rh0R9ohFctiuLbvKSKkbnLqN+mu1lmBNkdHXkMz5X2BdF1TCJAXgH3V30
L+eMQsy6yhG2UHvDcPSWx1O7hUkzfHnQbdNFkFZQbtFHQ6D8rnv0c4B/oR1idf5fWxxvCp2AbUH4
71PHOezqHx6bPrUGkC8AciaXUfHvIgjJkBEITI75aeMuvTUbEG==