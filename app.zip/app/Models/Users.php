<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx6LK4L45wbg4Nl5PWNeE8jQbvq4gRPfHDqOOop9pNv1LT5uSaXU+FNFw9B/sr1rW6yrsOmV
ApztH4zylMJIBDO3GeGpyf2AFRW43vW59UO8ZhUdqwqcz7cFI1SEjqVL7oEyvk+nIBlkSjKPluUQ
PrJGJy19sKfdr6SOV96IkoK4lJ4z5vAntZg7XpefCzeo+eZA9pUZNaF+eFGTi3VfEjHKjN8TyICb
hdoiP7W+r5sQriHwJaoLmH0dzSX4D2Xc/x4IIowP3akqAA7vAMBNEUlPSjcL2cUBR9pQ9tUdM4Ms
+UEqZ2h/45rOJF5hnaDI37AVIlQ13D4/PhY6Mom0R0FK170/sVaddfpFzQeTxes2lDKYv/FGnZPi
igBBBtH/R0/GzGpbzHNMwEpDmObzfqcqhwnZh62AW70BUE9Sy2rHqbMtsUCRyvUIArhJ3OW1DMKE
ZQXKDUsMdqwXbKZ6mu0AyOssCGfNYtVXnPH/kamamrl8DZ4jfpXICuMCvGRfcaSxCfZtOnVUYdbl
0DBmLz/vEWH/Wn2CyrEu0gYqpG6WKmPliEuMfZE7n4jYpqsKhZhZe8QDAzKiI4UoOKmg/1xJv9ip
UUOlu5qDwG9K5cvuN8ZOMCbSbBQ/YVVUeS3L1YbVsXAW4F/2Jgc6lv6zp3aLYtgbQsFNHcIulTGq
xiWZsxPTYN7T2E+mFc2xn2feXZG54FFavdTBKPyZB220A6ZUwNsUbRmgL90mFbifRNBCkxd5BDLA
dMAHSmNlBlkug0A/KB1jMoxMusJsKODZziZiqbuA2LB1SfO7G6iSCy8CmD4Q4jHD+8Goydzgg/ST
nb/kAnPrquvl9aLDdh5Ixsz11BGnYbGXDyrjRBMBMEPELEeq8/MUp80D5I/GrgQPAh0WPBFaPCgr
q/PYFlQ4tV2/kF/4ma4Pw2lLUUwVCX0koJZHKySTRvwTlGpa6RTW5/Nfofbeyiu1uqVfyTgctb+c
x+6gzZCBY/pBFHIgKCPF5a/mVdLHlqFxQZUfAyzJoqWXfjVL9e4+MeW0WZqwmMDYyux8SGWxl5FM
byHVNx1mM4hKPtHS4a0vwU/sVzfsXtJ9IqNNuk41qn96s6lhUJup1nNh6rr4ZiaUYRe080MrwZMN
rx/XJ1aQ/E/hXzBNb1ELLfEuNJhMStqSRVhyK+Mdbh6BLG8vdfmY3atA+ymAnxTQMaspmduD9csM
QfoQEPdrhWzdKSLtee+wVAcWsDiG/MvauUyw8esQj2vU/RCwWcypEO4t6O9uVLw8JVNbHeo8dzKU
WRTU4rbUL1cY8kv/6YjOrwnVZG8EMPFmcdvEpSlzyv2rpGm9s3wCBZe1hvgtNp2FWqQuBE0E6Obp
0RDNsE7+KZGzJGFrvE8BZ+cKidwY9aBd4WGe3pB7cAPm7c7cxd2V4qeYJQGX62sxnWSibPFgnkiY
dJF9yF9gH34+qMCsRJ/LvzH3Aef0UH0Lvm+LMSUEsH0TFSjyMvS6cViec7rZSTkS4Sf7djZCjK3a
JyjGJdSmDVAS/7EPcoUO2mFT9TtpjHEzGmIZG7naks/bQGZKb5lRCsJMiNVeRzeN5G/PHc/1utTX
0gaf8tHbvZ6WM2zmgYaTAXR5MuRwxxTE/Bxw14kFFoYnOplX6fZzNrl9z05dQ6EY1FJLqpNM23d8
rrwp23rP0zxNlPnO9HCH+hNM+vPINM3rOlzi3dv1y+e7YW2yYzi+lCWfRyWkH0Tvm6y2TU4nb+7f
/2FgFQWeHFJXVcCsb6KBKBFdAig9L1V7F+sYJbSzOt5y/QeAdq39GC1LOn4LIFNNee9CSO35dhS9
tnX83LSNFM4wTXTdixdlxHVdojqH1rKkSiUgPUvQYZMVaHLP6QRtgXqzH1Bao8Okrti3J2BYCSy9
nxq+omfGvCSWwv64khtTRwebLzCTWVL7tlt6sbd73N/d+aX6FKz4muo1OYTYP5kU4BQaMdVM09IJ
/GBmGxn9lYwn2uxWgPCUrkl7w0Gt62g/uLdnBLkyxJh/tQaJW3th8g87KhLH6lzFdidurBLSZF5Q
UBplwyHiA/OwAfRB2ApamLc/cp0WUCNqG5i9/9goaSSCkLYycUgftw6XVFhhNulvffRIL8NUMWY7
MVUbbjplcbabHmY1Cy5RNuz6VT5qqDLqV9LhvPvZw2tlL77ozVympcEK64H1l8SqaFlfJ6wOypXR
6vRIJI3zcpxp9QhtTeSS0EY1XKS52aLPdCb0Sjp93ghmSlAMi8kxVYiH/2jB61L9IqwtOlm5g0vJ
hJSfbnjkrXQY8OpdG5/Rz8BQaUcJGXB10MpMjN3VF/m3w4ctGlFscS3qzthV+YBp2hMv4nyO30F7
1CNlLw+Geg0SO+1WdQTVsSbLEUOVQh2dO6Xr3dJ/Q/pIia5J+Zcc4NFqJQnBrzViKXAcdXPjK/+p
FdN0Ehomz8ewyN9V4piDsxOhKfp6pDyowQYVnjjjlw3+VFwj+qgnLnhuvdQBbYpJMiFRAUXKHkRo
h5/WvzY6tE18W2k5b/yXrdS18GuJZhkjnKtuVjutYlq+ktUEuyDHn+jKowEWPEaD5Laxh9Vz5viz
fiAGgFbQQUa2a5lHe2oACtt7dMs77jT4CjGImrTI5EEQeX0GrebyLLYXySttrfIG6eWcfKQMnQOR
rDDtCthEl/DF2UPj2vQ+RzP0LIAvl+R97VKZbcBm1fd1/fujaGsTPuT1xXmuMk+tUzH0uA8smKk3
Cd5gjU+4wvT7qDpsTKIk3NLwQDn28pcR8It06HdgjuqJGa4Macxp/9ThgbPyTbzlXZSYavzBqkgF
rs18M6QtECcJtbx8x59tLvs+meWiqSskM7KRR79SHj7V7YEI0InbpJh4j3CKBYLA/BjY2fjr1fAV
mPAsTesGtDG3iVWk6tNjgYNLJCY18VW99XBMhoPqBPttcrpsVBTXXH9oMXWfC/quy8k3fY4unCGQ
Y8vUHOFZbjXuCK/L4C8AzQbMh5swJOUBEbFhT3BmncRmJCtnghmf99CuYkVME0xmxPc3nWpOpbOo
XxnnMnRK0FeRbv1/X1dqe6KZkIQ9Ypaiy32XWFFS1WiZmzAd7cIguonsh1hq8ijpelRJ9M03JHLk
WqaEV6MWiNABp/zD5A7PlEme5PiadnN7NR/DQLWSFi/TgiHy9s9CvsTwRI5p4XSwtuI5mQTGozP8
bBfvbesOGZqpkGZ+u1UyRCR+B/9DLVXhtqLfHIC1VpwwMYiUWV5ZQLeSbocUc5hKTYvAkT9gc115
Bb1/eVGSEaqrVUrtw9oVx2cReslFWHZxl75sGcDOVbCWNt19Z9h4N9P2MF6jKdBtyLOs92GZIFS3
KeEmG3jRJgbrUsvelgM5NkHS3AarooC7xMEk7MAMEBZj8r2IZWlaPZuULb+wPErZAkRJmgBsYm3M
0JNu8MTLdKd/PZGDBti4JjOsa25bEc0dUt3Bj6xwiaq5GIQV95q6pizD16PmXYkdt5EaUMPjFKH4
q4TmmUpT3PBUR7hF7kE+/JU8FuFyn/nk7oIi7DqYc9R5pRQxEcNTNdm19fEYI/cUrUsvGvEjLo+2
CUgsyu8QRZuAtEJqDdkgYCASORRlnDhDnQQlb5I1b40jP/iSJu5z41i4EyBZmmAb9OwOKU9OdIWN
cGN5Q4q42IHuQ8XNhTbV+purpiOARyS9Lw6ITZuERxSDituQcR/hJ6bcj9/2sJQzuqQed/Dt+ORU
uczTclloV3wfORvkIGiJQMHIRnr8NWLTYm1pJA0a/Llq9rcGMsUJYhafAc5m695cYXIcE52hI+3w
PE7cc52EvebbY0KpR1H/vUK+7Z2UwzHGlcP4Lol6X+CE3+zaexvkrTiAgzFnxzYGMTzQSUf7hCtC
qcBQ+UB62vwB00qDS5jKIW657T8L3LjZQJl1c+zTPqRL4ZQZcIfNSyFUXtSD9GujsKk1IfVpQn+t
tEuLRJHBVnkzRSmb5dVyx/BF05P4Uw/GLD0bvDk/+bGE25yiKcePjXfgYo4/dlcSsrM7IrItBT84
+19lqONp3Si1HavplhI6JR96HJ6TpL8l4HuRxF7G+4/xhanp7kNXiaiXBZai6ivDn9OWzIxVH0oS
tc5arDAGXQdc+jhr3S1EMVddaD3rzfabJG/u5XZh/+I1ByF8HzJLdU+b+sE1M4y9rhIKVPHw/KK3
ArNWpr0eRIrTJwJnK68OlSR9S9KCsKgvlTrPd2jfeobbWYvc1NP7Kl/w/38fX07YZX9x6zaTIxjS
nUHQs++5giDywWXT4g0i2fR1+mjrAfjsJedS9nm+WNfR6dU0MeuTvJ+z9yUrg3lkwS4KUhMHTdBO
lS2SIup0o+VREAsaMLerrvFIu2HBJ//ZKB6VJ4UIzW3IsgAv9bNR2ESUoJFJhsAF+FvN2hbmIE3R
6gOY1hoQWitdCymZmD8/Wm+iKBSzbrvJTmJ/ETvwTbwfzHr64xhAhVd2uiEE1y1Jb3F/OeleVtDj
NT4OZ7M8DSLydeNXTvUT49YKqSU3r03whkXCc5Hy8I0pAFnSvZCwTyd8oCDAYsFkO4emevlNyFNu
ZjDL8UtqbtGzbrlFe3O5uVSNJ9LrEYalqBra4Gq57INj+TSH0PPOWCm7ntPHftBR+nF2vl+3eh4I
N4keuTc6f7xL0XXbU+jtymyHsWGQUk6cOpVtav2zobrdDGo8S/5CukITwOB5LluTCf2hXkb9G2gD
riGiQo8n8VprEod39ULgLuPzRcqNORlaoeEfp4oDPmWax8MapSKbFYkhsZ8OAgiJw5BuMVXFzN1w
xZuaXpBdytUK5WbGnrVGTzTrRXk9OV+4SRYgV19yoylmBWLGxJtGDdtvssuddIuB4XBUZy9xgh3a
r+EFuM4+9XckdPzPbnI9+X10IGl5qrke88IHGKrG2cyKZY6Uc0Zb9QANdPHasyLF29EO4lmAz0DK
KV0UsjUTt3TBywJn5CGKA9Kuo/EVT30inoFtJUADg1hjjOHWyCBViT9b3hpZSumuK0cOiRYRRa96
JzGFgOoBKDVW2kiS8ahuQLiZFYKvRce8esh7RSwVXd3e1zN4clqbPMA63QdPUQ2zzg5cQFFz054r
9s0rPcJygs65ANyol0r1kPEJsq3lMwet+X+1037XO++zUBvbM453ooFK0Pj/4WcBfwKn9qS6h0k/
8u2Z8hc+lLC0lBElZ881LwUCdgjNoSxnMYEinA31kRBl6f6qIDT6yq0qm7PFhiDtJ0cU/xRy+gvW
9KDXLY7+5KL0+WkdsXUbk4UlEWevnPYdK9UhTB27ySGJr0RuHXtC+XQDMPFwsQbaDUmRXCRcQ9Gi
Mtf1ATPzjPtKuvSQ319BTsMOdbUBbu8q6EWC/SCk3suGoxiZL0ZUfcMXv5nZI0axje/Y3FVftJZf
XapFjGuT5blta9Q/WOyosGKEGkNnPrITXIPmTgTW27sNRoIBiATYS0BJsPa6PHS6d/VG4Fzxe4ig
Tvk4KVvCVHnQsnQVNqgmaCRj1Y5SQz5iyZ3/ko+fuTesZU5eM4LKI6/6LPWKbNKTvrHrgko0Kfzk
dIlPUwszxEvjCjvd+w9U4zK5/nEjeQOs6kMCCagejC4CZEp6kxH1BC028ocYFGkVlMvUrhfHaP5Y
6tJVnog6SZZ6OHKrEKp2C5lXMN6NKPGYNEnm0UeHV04GFpXgkj1IBl6WSAp533HS0nq/EcTe+ms6
ANHUk/xNxC3jkYCskQFSkcqdVyKhxYfL/gOOMH1bjVi2hKtZ7myEjIB/vvLTHbuNahb6bTu7Ru5h
kG8cydau40/ye/CYN26uiNGijTKiYSs4PT9mVLEiXK7TdCpjPywqd7TvHlOzZYlbhvY6yV8z62MF
O0decMMe5bo/YhcBzUJCQWNIY4y1D0nHYwqrMDA7LM6g0mq0cAuVsKyao0rZ0FJSDkaBp0iG+WG5
nlg60ftwjmlH9arQVcli6isiW+3ZHBLxOUAX2uNNzH+gl/q6pUQIrUIxIa/c2uGQCQ3/JUmeJe+O
iVYRru0EMn65yZsKM6E56VkZLiEiSiZLcjxHTCW+5PvcyjYYMCvGYeGGS7kMhaoEBGXBoFY57cre
27iowCDhn6NH+SEXzHMBwSCppQXSss9WACLH5Tm5EOIycyyzPMw9ZMbElB2RQInzpsxavoP8eI+U
pfxZO/sLuFgrMQ8IHQLm5u7sAhmb/0UB+bDxep8A/+u/gQq1CNCoMyy84o0JJTqeVEbLUI5sJ2xg
SbSQKw6S9t12SeiBhiLsUqGHXyH6+UspFiy85Pf5Yftf1aLFffXkIn8MGPEHfGG+XerPNFgN+Fit
EoUW6tVew8eO3NcaYLhl3WXsS0UPnhLqRRNLMl/6o5o7dRmK1QgwjeraTu1tuFsjMiMjPyESKJKm
ZWTfZHiXWekmgPx/FlLrfqJgKPAtXO5LlE3qcqfnAsPxcTgmfOoF5k6N89taryT9ZkU7z+wPNyPz
MYMNJLAh82MEuHYCoz6roauOvpQTF/yNhbYkbxsmlAkwYQwakDWhSrRcx+ks5S0zD7lqsRnZxMks
25R/XlA6+WSWJ+T4P8zVhz/QsIm0u/0fktmj5vD/HMN/NYS7CMT1vAS4dOSYQzEAqUgi2VVo4ICv
udE+/lGDo70MX9XxFnI6LzIxhXhkjOjKnDwT0ZX788pvjqd0MWIXs4PNczTOZGixmtrIR8ttln2f
5+RBr7zYt88sCYnmmPDPE65Oeb9EwNNgnFYqjBOt5sN4iChYpvR1BK7YpUXM2IURQwSWCRwqhghd
yebrQvs9bza+rImG5nZdbfJ8e2tbREFCvXOCfYbFaFc8HtOENPV8V5KuHAlbcfMkWlWjiQUOfkpp
2qG4ZMu16L0a8/7Oib0P+LSWVJ3mH6zbFIYtPS+oPlzU6J8U0nJj7faPM05CJh/mNWXonURsHBKi
Mx4dQdiJVfXA8B1FzfYXuLtd2kfek/AgrwbEFb/pC2zhX/9d/w7b/hICXAwxYA5iJVXPmSt4yK59
G+rNcUKvyLDDWyFMUVXmOFkxs4TJjjfuCr46E/nWASSFPwFcyKAezhHAmYE3AkYpP1EThgiD2x2k
38wxUKLfIwafNNn85cUi4mulHBxpgffjpjVvRlIngFNr2Xb5pe9spfdkiiCLoC6zgSeqIFO0Z2mm
bbWOvxS53KMopfLUMFQTJWmKc3566962SGSwYBSTl6Rkpzt+3rRi9WZqhojNc7zoO9NHvcrBdGGT
SiCGxniT7+sMLrAnaBRyOkfXWNIe/yqXPje3H+ASDqGACjx3B71axxCf3MoGneEmcg4fbDvUrDpz
f2EuBIrrfniKZqt0DX/5xbbB6DnWmVSNBd7ru4E4Z2q8LDbH8nS95brz0hWXWJQqo7oJORhz5sji
tsHoXnEyhAWjW2uk2CdyuREeus4drzcI8nDiYEhM9102CtexyGmAyM7V4kqPB5dORCjjORWR3xxI
fw5x1uTCic5NcG+JRMFmjwSq7Bdvw0mLCytZdrSnwRibMmoE51zthLF4LRMxSxEEXF3kImHZbQGj
JK4K7cTvxkJLydJEqeuQa8fZ3yqs7vKTGVjTIbCWCzWABcd/PxPiRfYayHaV29/eA0Zzb6VU8yJG
pUFy+ne0z4rB2Jd+WO5fRPUCpu9PrvjSWs/58/sCXodyL2a5/JXmBoCFf7D5zzic/JIuTP9LgxIT
g7zQSksTd1Xo6qtrrpAKChiz7jTbZkmSdALD347GzTY17n19SN1JWCh1lUgN5dNviznt38LcgA85
/OsOCvmuSCU/CFwSbnyxLldxzpfeOVi8sCLxwrKSLr9mZHuVqjQwv3SaPsapNaGmqGmUe3+IUUJ+
BCrSj+5VnRsAjtnTrIPUyfGPAImE7leBAcIjQVshCeidna1gsouEzmSVUwBi0YT6JsEEMm6iCsfw
3oK09RMJF//fA8IV2XL1G4GltfkyL8IPlJlajXi76WXA7E7iUTkjuzgBSMcIMpj2cpuuBXu9zWEr
bocOSEXSfS084Gs3J+hfXXiKAs76Tb8mm02WsGgkt6U8HfOWWHkx3+gpHHFfTlHRX4HRcYt2/5fd
8InHGH8ivHndfx+sNRIqjrpihQ9xQ4H4crTajnEmJKZrzOx7y3wG9Q3GbswoJyGRwMp/ryWrG1Qc
TuE2G0K9GYxFQnNTJiVKfu6u1zcmXzpmyO3/fITUOn/opneYyU0vlxcGwj9zvG0/U6pfxwzDSRc+
HA7KR39IbE724ZlnUVq6BuehflFYldQuVKZKvyRhXWmhdaHkBrbkhobnpdWoaEuhpQa8YBX2ASE4
YB1e3wxkcT48yZ3B8W7j2eNUIujqrAKZ9H3jZarjAaancuDOm3SlM7udDm+kRpODE+f8c8C2cV5Z
uxHQ4FtGUCFONyeHyKNscese1LUwSStnNcxfIqsfvg2gbWmeZT6tNERXKdsvqOZK/pvFG9/MJJwD
WAF3noPnA8kShGwN5TF1xVGl8ib4PVDfUkQO10p5x5xqojIT9X+7XN7Wi804thexXTEaIWZJX0==