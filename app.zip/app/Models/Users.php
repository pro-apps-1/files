<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+4en2FpsF/N58h6KG0BBcsxYFPu8vjRUzevKTXN9viMCV4iuCOJ/aUtY6ov5QvdJRkX2HUQ
0X3iL0A+1cHsmf2TDOKAdbMMOtjTikbIYHTUs2GngNvbgNXElHYSoYQce6hwpVoFR4YKateMRbM6
3HwK0kLSV2EKtbbVOpk/WICW9ToD/XhKz2cEOsBmyspn28boTFuj/eSjZ/q+SFIZ886lwEp2sqx8
xOoDtCWInquf9JADDqsqASUnufpEH20N+Pgb3Dfc3gKi+VXMPDuvxUuHG9FnQ4LS5YCWqTPtttoa
aL5J5//d0BEB6li1LQ76wpApDXRMpmP4x75wT++pZZ+AGqLHNRKvoyKSELQAoVXljX6FnrvmqZh0
Ryvvu9mQD2CGQ+OAvG3s+bOaMSh5ODDUfRpVuyB33gjhvL50e+WY/E6X62y7zZ93/m6D5tu1J6hg
xayOcwMmX+jesAIdeH3CTeZXA8GNpTveGjVmPU7n8wDcQu9MXIN7QCqQgc6i55tfdybtPhMRCOfb
hGKi/WMRC65aYToiUMlcu53J34t1R50z+VBnLCoG3eziP4kK4xlkZfh7gHZJOJxKBYQ/UDQJWO3K
Fdsgeo2F+bY5NiOBErMKqYSsejsGeLfIPL3sFnUZRnmJ2zCq2W0T6vCX7VcnaoLJX5P6ZeeaADpi
kwOelt3pPW9BQJi0W5rXqiquz3yNTTZFHxF9ezJGu5DSAnImjJlSc7Ie5oaL9c0AjQa6s4mc9cZU
8AIIvL6rxp9tKv3usD5l8CISv6ZnKOQOhpXLklT5C6SHSctB7wkJ3c5rlRg9J8xQU65FzeMtz3xz
GXFnrbOYEjUj3PEGM6wQqx3WeHVuyXVgUUz4Rq3l1Y2TClWbBZB10H7Nlq7xGlLVlB9FPThE5a17
vTLAh9DXXkWDS/oDC9ee6gRD8MULoEyMO/UwkQYiUwaUm/Bfp+jlWQuwPOUbpum/hWhdlfTSgH1l
45NzhhkODMq74rJ/hX3+grTtw/FrrEH1pKLmphNqSYXgP5ceOWD+rPJmR8euB1wOowTuDaHM/KUe
Z4OY686kC/YBRGmKo5dlWAiHARTw6Nj+/UklzreWxjNocksKNK6vWgYwsUSZMixIkc/7TgJrtXE1
wzsM29gkLrIJAMNq6FE0VNreKz1+HR7YnVoRobUVQ/hqGdnoee+e1j5MmCxkMcJxMS8EWmbELS0w
urfJqusqLOHlxZP7WtYJgvAcepkO6HYkubjELsURUVul2ahj+wKakFRGEJTrTiHIS8ID7uoy/fP+
qTTKfo4j4/e4x71pgx9DVnOUehAPCJ0eZoBTTr3PPZ4VtMDMxvKG1hni5F7dERYpr6+OAMzFIXgN
0j3ToKQJt6skd2bWKBUqHFjID+exP2QEMJSwDJwPjLbtIs+0SpGIcLfhOKU0RWib/Poz08oFkyCV
SuLrxIlu6z0TlPIk6OJ759KkdZYXMkrqpWaCYvS3WU0VXuXOnJB5GAEHAGCWu8JhBuHXNFiHDQDU
N9BDR8VJPLdbeF4EaP1L22MB/1r+9jETSfUOj4ePuYRoDuazMlKxzrRUXycvVi/SjesvGdXTRXOY
9eQPH480SXDwBgVhdICiNW0XXowLydwYfu5GUAJvpWlrCOosCYna1h7bEGg42dQJkaTzxd25MGdw
9xpwuRWXpLfQ7CwqgSiY3MA+2zlEAaiRuMkFleo2VJxno46h8tVsAKwRiUy+0ieVp6yqpFDjsz1a
JzZmNf0Nd0I3k4m90BjRYU4p0QZAuRMy0Lcm/EhzOztzqxEmZaVYU1zaajmaefgrOFHeK+Fht+6b
y97gXUAxtR1PjIftgOVJdFy39CspVYEo9nYDthQfByT4e1CpJWK8hi6vS53UgirZnzP0WcPgTpf5
KGy6fzvXzesvzjj+kbvbwYuVrCH84snGZXLrVcDMs/K12p/1Hp5Lc8MR9jutxgRL5WFus5rCUYNo
neQOTXmINIKFRbR6llLP1NzCvYnSBLcbE3keM9XkoY6MdFmUcCLXJyJMvXHl3HZOt8hbc6C2rOCn
b4B4GU12D/7k1+NahNRFhqV3rROX23IPKfoSzptL95BL9vZ1thXwSdqaTk77BbZphA0rkOK6FNYg
cRLZ7qaqbvyRVaztHOc3GZbvhMMfm363c0MZ4gpMrW2zVYYcOabB4DiXmo/4pkfA2LgO0ZNIDNCM
OXnFr018GnhH0XQbhIh/tcWNU3IkgYrPHoOgEfHxhFF2PzWNw8/M6QQDrOKgGTwzTpuZL4YOJOlr
ufG5z8bJ5BwgSLom/QzV1UEsEi/fE2R5+U7Nu3biWfcrCwoLc7Ho9dWp9hObNC6Y/cK+7PD3UWwb
E5omox34Hr+6Yl4rTWQ4mlGs4MqpPhsFR5ZxEul1Qu8F57O/sLm42qHoLDlM/qb0W2CgZxB9Uttd
IxOZtzM8GotiIc4eNi3BowMn+MwF6WCqRfTZaML8IKUB3wiWvHqX7Llp4USv8ixsvBl9EtFCcHMi
nxCnCszRPZ8cpXafFMAjFyRB7WmvWI4bcoS3l4EMtV3+Q4ofx3UqUcHfeu8o7F5WAgvlXuP9UtHq
S1py2j1vrx7nZAfSazG0RXgkEBeWxlzca1EsmFablqCnQYIAulbl2dw6Y1r1YpHt9M3ranN64fPP
5uhfzriXqcwoaulnyewBN39Iczvf0IdBgNg0C1yuqtBROAW9xCvcjIMCwkuavHNrb0eb83P2/mNP
FcUvTn0IZ+SEkmrBX2mxgdoQ2sSIW5QyK/BpO50pNnov3H0tnQqRTlS3GlcBG0L48UdgHsF51Ij2
ltTxZNM0S4xhCx1ETspmOvMKPCqaxSWoE26JYBaeMa0UmFNmEVm4qSSGJuJbcwsPFrcdgHD1RVM8
ZP/XtO7cBSrfj88lnHvUbaxq6Eb3hs5JKrms8DjdDhQ7UKKFpIghVgyTj948q3jmh+4VKL5mTR1M
sRh0ToQldaOF0TAhRDu+SwmqAsLx/K+DtlbY9HTO08cefCM+m6elNdjHS79OHyMhwmBg9u+W0Eue
ehU9nmm/PovliHT4e71SIrVgcPpSvPgAbLx/kuS0pkbLWUnr0RtoRLo889PEjCSWe4Zu/7ec24pV
06O2mCIl1hc1dmp4PgHP3IwSzwQy4KaPZ0m+TgeIAEOUjasfujWddeGIfBIrX2rJJp/riWKLU8GA
rPcmtFheZDpbOaGqJd0wye6iX8g2BVlMT4JAlNOA1EDKCK5ikU/hgFetpSMlx26ScHRs1sngxK/z
gWiUnwtaTMcu7dsmlmub17nsf72jDQG7gce7zrxdigBY9LUmRyAYTET5UA3n2NYAD+3I2V7zsMWr
wwJnpTyIgKwwk+q0kLX5cxQquopLyVTMYwzg/m8d0Tvo7zy/D+Gq2AMoSLRKEdptgosA5geOAJ7v
THIq8nNP01O3zFiS0MEhVrnmr3TBCNm5SXJsMNGqdeqEoa8FEjZzYQc6l3kPgLDfYIeTFhtgmTn7
fgEygEWaWDJTRroEZ2a8TUlEaWC2OQJ7HldjztnBUUbL6JJchqcYLweVAyKHtvB91pGmNE5rW/JZ
dGjeZc8bW4QHijYuWo1BcGvN+VKQg3UnTQSJVFK3YUM1jEDiEs4bu7wHruQWD1ROAw5KZ/iM86lL
ipANcyaVttqBy6YVK8NeLmzwPFWNOJ+aN6vi5HdJjwKIWuBmAKJD6A7IUq9WluZoPwRyNuQeoD5s
a4M+7iHwV6jbzIjnGONUHEsEuV4i6qzlLrPO1m5pfGu2/wcnj7359MRuoNMs7OiZT4iEvqpIrGou
mvSDQYFT5hk75xBYlu+/4MdmAfWbonb6W4Zt9HoPeIrIHy9OKOtJ8IE5mLnofCskwivKx89qECK8
Xg5Bq540LeAQdilSLrgBqp+2ObRlDGU7gwyIx4HJRz9d6iw0e8a/Ds1hqEsQ8XUrQ+u/umx2ztl/
seTXc3DH0FGwaiD1xPMR9hxtCEaTOLsGLh3NG8JzYS9mbO3ESFMa3BtxrO/Y2B/mZkCpraaGPfIF
GkaER+WmN7zMEN/vmTe+kQakCTdDtQh7da7I/mpFD38Z8cTHRQoWIVMCdSwm7n7R0G6rAXVItMtG
cBdCQ34K1tQx50Q7rVpDRpS+8Bl6605Z14QHro/gfaAE9tWhzBdXMAJyDU1iLGe7uXwwH/GOrorD
Q2hVAoQtm7TgAkWs3sbCOtwv3zbZWxDjvX0ibE+FgIwCEJ4IG8sJPSekpWWaVfwVLQTxHZ6+0FEe
pzzpGXbT3zUQdOUhUPwMH4IkC6AnpC3Pt9qeORkuqIVt98XLycO2sshTM11WKh+6hBJ71PaLiE89
FMmLNuYHT5lb/JCCi+vOD79ftPhX+yY/ZXPFWW69dq2/BbYPFzQlGO9bIZ343VOhREVzMGtu/hO7
cHqBLgpEkbhR85fczYsC+PrKGyABmu2HzpEttuG7pfKlD0ZDLVyChZrDtGB1mEWtd6wlT0xp3xaE
kEuWbTCjJMrVuzDY2LhgZ93DVyUctXklg9FspFx3U33pTN0RI6yjIzmF7HsD0HrkYgdXD4pEohZK
8iUu+KKp07x89jToVwKbDtUzHsuzxgtxTpW/2Pw+Hc1pwIWRSam3Glj4tgomKcATusY0B+uTFPbk
QUeVMN1hxFHT2zqZDXHGSabXQkMtyiRKnT4DQaVyExyJSSf76LT+aiuabnWjFk5QdThs4SlRSAVn
PCfj05WseTcMRrzIVjzA4XBSDSYfdAiwknpYT0/h7qWQiR3E4U5fEmikobbZ0gxyzBPTwPE0r2ST
TNiKyg6gOn5H/xEGI2+EzZwramWFnNmTSsCnIt7KQsz4EpkC147wtKGdV4XkrrNQKDgEZrKzaeOY
7qZiFcp79H1jLc8jJc1QoRM5bg24Zouekvhya5cUmHjMJy1A3ePUOc7d6AlVDGrWBvl3X+Lpksr6
gWLs9hXRsR7l7LEBgpYW80huOnQy/FFL2c24SU6AyELmAN15AMpKyVBgrHLvuZ5V8ASG5+LHKX0/
mYmIsaj4MjhSRwxTMaEFfVo0vQ/UMplQJEj7SbN7IW4YMyubAwLy0DU0uZHflC8bHC4/OYBlBw1W
XRfJloras2e01yhi0Aeus3H7nHtsxk6ihf6HIzcShYrcLbL60nGS4LrdOl9p2tpYvcxxr2rNetjr
yNxxFJ5KteXWHPJRO5whVhXshGVFfVxLBKhW6woyYAEeRsUO3tft9/v8+FlNO11L+82my6reTk15
bJRXajFcui1uhml4ozEeGYY9yqhLEj8vB5BUZR1eSSWcrkkyJskN7w0m+0dJq59wuUjgW3H2PsDb
PpkLNtBupOU3QtT7W5psqt2ZzWqDWTitJGLTc7XiwRUH8QLYQZBkZib6IAMYM558q+RlP0ycUWS1
eruWsH4S9xARACuPc+FpqRbZtko2zGtD15fgH78p/ROENLrT4/KF9dUCQHM2CJ0RSPPswY8hch52
cBfsv4u+NggQoPZ68ILs80eW6/+b8cRo/Bz+xxWpq8mqktXxcTcprR3tKb0Co0aTje94sG3QgIWJ
2scDWBgHhXEDtEtEkrceI5niYG7kVmveWs36bDvzYI3tE1YMEiGr75QGGIjRVIpsHuCVYofi9fF8
pcgMTPhDA5YM4LgA1tT7VuSMHdWCi22GxYPkRl2pgFOR8Y+VUN3Mx0DTqsafHzygyB0nYxIePM9R
SAOdl+uIAj2I8nM4ye25eeXeecOccLCl0FqNQ946ct5h5IrmwcirID8M2424fqxHgZXGtlIUDQH0
yUXxo9v8nwNImZsvf+M1Z4aWa/YUhB3yi54UD9gzHKiPDYxOghN7GQfFPWWAyEbmsjWl3a2b0CyR
0wvzfXpqC9En4bEaBoPbQAKl5+Ixh3yiJZ/jQFTetDdHwZXySjw5VnmCEplCvuyTn5tJ/5m7iVMp
13ICxuJeaYypss0fv07nnlBpKBvierXsADfFcyfJ7qy3e7F467NLuFJC5uJS8vk1DPdbcXd/1cIs
bsHjAbxtvgvQjIg32Tdi9l+VtkVyjALBtQR6P7DTYeIzlICX9BYtmr5fkRlQM9UfgGuCxmP04wTj
71JCmyvma48OvG5csc/4uqR/OYqD5yTs9VorAwSJ7iiNqHnyKaQOa2Kn9AXfsPTXSIqJm6fBFW2A
34YTvJafwInxrmE10GkY/lNiasWw14N/3XIwMizGw1lAYY5cI9c947RDKxS/7o8Q9Lb13MT1BP60
n8W/2TF6hCzmHCW6fzVjtUGJa7mgIx6Yv8lBdx906nIyV0HFtL7TPURb+KVHbxKSjOLRJ7hxWYbN
IJNq7uFBcXTq5Pxpg5vvGXeVubXwB8MWwL1/Lfb6ZE5qIno7PGCsT3FCcUzo1W2gwfbdnQ0uOW+r
8rX6RLsTZid2HfHZuRRbleONxRaZfNDPZcsN5O8QvLiHLRARgfdXTGJQff7eN/DvdqpZgV/j6hS8
yxIDh+i99PQJjl/+qInQVhNDCvs+5qn1GIW3y0fmxiIXqSnjcirpYnGHAQU7uR0AnYBVBVzV7qh9
UCOcdmbajpANceSqGT/RS8YvVyaA/FzW8j6lZMx2BKEurGgWn7Mkj/IfeZeMW/PkFGCjfcGhNyw2
riGBoAZ0HM/rPGCuQEa7inlthszIBPabrHxI+Jzw/Xd856vtzEpjP+MUASX5V1dlX9AlJeeONhI0
MuTs/o+YBuqHWNo3jeU+YUsDQIyZ78iKQypXV9XxhXlJyhtIQRX7gKe4ZeY9ckQcJU22YlVOUala
WTh09FC5xpNAW+P6OQ/23BWHNxSM1vPoUW7vUJWlbXJajqxmJb/obpxz7qCozwUlZHqMUhrOlpAr
ZHBpjHycupbJzflo3hanO4EJgFRVdorKvfCYtVAOHY2sYNvSkbki3TIK3ubjiVuxEPe1cX1aBe3r
pAJLAfp2jOH5MjcHeNBY2CeGwPoY09L5Oril0Xwc5smAWZ9v1dVrDxcTWPauLSlZ1AEL2CVPqhFu
aA339l7XQEfKif7Om3+nPinP4BpecgNaWNFBZvsJyXFljwRVCp9q6Yu8J233lEWBjjgu1aLx56c9
28r0TJ/YnQ+wzdcHCIAjYx8fqO+ejV8d9ZcR7+qWkSx5s6dVI8aCThqli0sT1qPjaYbSWEg82AiM
BJWfcBvwqw5GhNjtG9VVwernEJWqpXPqjX6+b3966Bwr+giA4O9KJdROEYVz2oJUNnfHdqGfj7pd
6COJUzj90k/6mM+kHuf+ZuYYICVyeRSWOAfcbcVpJC265RwEjGmvZgGn7ZXZ0NSidIHjxAYYepX4
96qSVw7ecgc5pNlYS/TeRggLDGD32Gmo/v9CnfQzJdQ66N3IDdLT/NUvFcxPE9HzjwiGkuRWCHTE
vsSLyeefqStvRYA9Od8XzavAJvIso37AYtgw0ZrrvJyXw7obcV2fa/a5meZB3aRc9kItuBHPuhs0
9LSv5BtlfTRbev1GEOWANUUtQVVOhjFL0jf+w1odRS5w9f6bswk8oOoc0t5cLqZf7fDisyEMzz2V
pjOkdFTR5o52jgZuJ4tckpFksS6FIMzKQgIVUQ4xOpQkB+AhjJbGKLx4gINa4M0jyaN/C0A9NSKL
dR9yomoUQWNcHj98mrrgpHn3vUs+XMhs3cYwKAU3V238zNKgMgpI4uoArlUkKni9Z+JGyUkhksS5
YD9UAZCJkPYhZh98L0H4AEo5V0cN/4bk25SBKoK+l+Lwl2vezEAzhGxzqsmZSyDiaDSXxk2V/L4V
WcvrNSXtNWxxs+lHcQ1iwQJv9cL56ohkKZIrxBDg1igNltD5eKoQW78jeJqcCIZTz/LUWKUkI61l
XKTDjEpJ04MeO+X55lORG0lp5oE0C2MZKjOkYgjJrMRhHbZE3HNJRgvC5/J8CLRevUYXfQgU9blE
o3PGp1S7P7hLUmSJk0+GGCOBExQsTloyCmyn7HYrnj1jdipu0xri7sJQLh1kA+TLWTXW+FQq9uT5
49Stq1pKB3UMxR37M7P/JUkNCLkPRN159IjjV8miiXerPcOBWcK/qS9p6ym1xtwBCoE7jNUQSsSC
c1OTjH/lUxc1uthMegwjRkVakJKImi42NaBaoIzzZifKvz1LjKA+Qghoz5vIKb1q2EoxCeTAyn7B
rWZe+kl2aQ59hV6+Ib0L8qoUqyW/ZXxnzGzU3s2OZn4WIAgXRWSLQHrdl11cMEs8+2FKNAfdBziZ
LdAe18BCd7jkSr6VRtruzNMkfVI8+kxCxaRZGBk9MAGKaoDBKISp5RXj7zfD1ilW18b/vc3y/jno
1nHgJlBSUXTcegTAa1JeJCQ+E4kPTgVUotaZFzyfytfdXz5DjfKdXrffYVlkaJEHg+DTaJVP+dOb
kuVOKQv9PehNnj7wU9FIZSuTi7TknmgKbLBcnhiIu0yLxKjahrPyyCT6bdOny2FmLyKHPOOQ6UCb
UM5uL5XV2goJoZ2NUiu1/H0Qk44x7WKr6feH28HxZptIsjGb34yKCtA4UJZ68AGai9klUlMm+MA8
uaPGsfHbFcQTSDvsGq9eZ7NzjwHlU2dd+9YcUQMnloEFzySUOfbFnVFf2aLUPqJ4f4u2mAm=