<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPua/5Zq6pUeotz637b9FP6X7Ov6NMJtf3/ClzwNE8IJZlxyeYk+jR1vR5EwZ0tQdK4N6r5l6
i6PtkoLq5DaHrNeThZKzYVawvuVkOZAzrKRtiGBiL2PoARnjh3b/9ycmH864n0yBEl3jWQd/XApn
4hc1JCLkpoLeX7S8wiaNLqSgwjG0EzaGMIZJDaJ4fjjSv2eV7AmOZjyhURov/1XrXkRHHGwUslLJ
1UJdea3HYYMRw8flVnbMVbsUV6QHMQidqOFs65Gi8NSPCilXjyMnfmuGuqO3lMV6CJG/NV6JSWA1
hkb7FWt/7TNZ4vooB5s4OAx3GsqgAgtGRoqgbHkaEpVXTmiafI+8jJvvxw1QNU7rr7avHSFogoP6
94pi1DJhP2Nqa+dh48X5LSQ0pDtsbNi8k/o64mcozxFbvJ1ExDGAZhq1VQXrKJf4TQA9z4T23r4m
HFa2nXLL3tU3ItT7ekeax++PQl7aYP6xnPYjqxTdu9JiD0ojjHgAVcWLAx3LyX/2sI84aXIaYE6b
YmBz4OpUpB/cgaOfYysAOC/GRYrF5LMX3+OrUuTd1IJyhi3kZtadJUrVyMP9BzF7tQltg8Pmq8Ah
KJC3sAIGIwVQVqXH8N0lsMToFOaJv0zXQWmPd8CvGZ0R9CUMyaJSpENJ7KOCKbJVURWrCComB/zd
EhJZnKSJtKrW1Ps0qyyPBwaXcDZClUHjHcD65cN2eWCf5kxOwNHm2Qe5DQeVzorL4fwX65C4MyXt
DEJA0Hw8M6rNAfCto9fN958XAk9u21TyBwcHGxZtD7XVqB3KcWSR0Gv9seycmSGqmfVE0lVQz7TS
utXyaSmMZFKUlIRACWlSsupgltoJ8xwXwhxLABvu9rihoszZSjtqy7SGCq+MSIWHGHyg3C0CcJdF
EQAhuHQJXD88D+X5QJ/6a28ZvHxG8iMGd/FOEN4NZkYDldLKZzO/h7ReXcItGuTsDc5GgWtmwJsz
Cn+wWKm8VlPc/xsbv0I7eWW4SSNUY0NHk2fD/pLbK9OhPwa0KZcfmBthgKMG6PYUT8tHBnKITDK1
ctv7j48WXyTrZ9qRJIThdVnI81Pl+SEtRqOTU7L0h9vp6MOfPnLUoA7B6scpxGgu38SOVDOUX1ue
RmTKacT6QkrZfYp9wu6YlVw1X1LVaUjO+wpbV16iaB8uce2OkU8BhkbGN61A/PmVdQu8nksMJ1Vb
8t6Qvv38aI0Sh9gGSyGk+UG0aGvi5/CpJ67iMzvYRJLQACb3OoW5lVbYk2dE4bTtkKEKXEmb24hI
0ouKA2L2JZtp0e1eqag+NHq5U9SlsamJqh786njXTuEhnRKEm63/v3+zbJrkZWTQWq1qjmHSJH3M
j1urwJIoofx26N5TMVCpxNON4LhPtUViRRcXCH9lsxhZhE6h6N6jWnVTtri5l0JYRwvOPxZpRFKI
SEsOCzVKRw+MhiAMV3ipgE2QCdHYLq8jLprQMFWu9BQi9JSF9uKxo/++iFkgzTg8jSKl3HmEwCLB
HZSbTv8kHcsPfotqtn0A5bgm5o4S2TF8Ox0tFK4JztWSkpqxNRL9N4cogV+F1F5qE8STDnxRksuC
tfE/Ph6NUKVevzMrUUxmr0jC0B8HP/8Ub1rcgtWuhpbJ0I8xr4xOQgsNQgqBfTrHP0ExhB/cJFEL
W+PNG6HN99b4Hlj8wbOn7xvrms8kEZFcGeztqpkpaBfkjIBZLnTFaMJ2nZ5bbKKU123HrEa0FivE
9yLth22IiBzTU6LRvPVjbsLsfxQj1hlyQuQO/6fpxm7gPqZhisLoey5unqttjFd1oMnvWu9xma6z
se1cy8q1dVsaw1EqKaHc60JKLXJuj7TsSXFwyRVU90P5a6obf4TEImgrdIou2wtxvCzSJ6JTATFJ
pPklBfUw1BsWoujFU6G/XcIY9XfyGIrpyR0BXkLnuQLfgswZGyACQna2WNvzwTvvwUqY27yaGKkm
iOhC1qV/7r3g1LvP5qxtdHrAiUG+lYGtUQYg0bVJIdXNXeRsVmFLyuTyA+SNdXYbIWrBKqLP8EUL
w8hWrh6X61Mz/w+xYEF+e3XBmsU53g/ntl5FXQkSoWefYCC2Qc4B1RB6zh47eQ+We7k9mfc2mpHG
Sf/tqvNU72nr4LDwFpv9vM2AbYbxtI0YzVervbUZDMhY50BAA+lvwAbkzHX4bcR5B2cYRoNOo16z
jqsGMU3DS1xjtSCLyyuEe+GtnztJUqsq1srezjc1bi4f2dnLqJSUmoq32/6ZTVs5Sq2kNqlG08Qm
CfVCX2ysqHerqFK1p1A04XIzgnLE8zOgsUx6bDsCYMPSBL1gHO2BEFmCSsqt+zfw5V0g4xxU0LRQ
wyA8vyTfRg/lBKhfRiyZlZQhNoQCD4ul3ngRt7QZN6YKPCeUZCJdfer4DW+hm2UrbMJZb0R9BBwD
ym8wFnCWazgFu/1+DA2E9GBFEvIwM5qq5llo07DuaNABRIKFNkbqNEOjU0gVJU5kQVBCli5+2Und
EObJTr1dwRwn2X4nqfKLD65EUK14UfiPN9omks1gpOwQA2onWMZTLqwWiprJ8Y3ayAVUkVAeFvOP
cYCwq9M31zdOEnwYa0UaZ6mHeJIF08ox4NMXklvKMumfEI2JJ+dqWhW68CXUjZ8B4qk78jEIH5/w
AOLYQMjGxMPH6YASMWFWEQil0aErbpSXMEOsgfINv4Pfo+Gra9zShoH6kz2lM7buA7WZe5ra7/+o
8EwkysHbRHVh22dH9UpOL5b7b4ASxn8aEzkr08YuYUG+mgOA/1PVBkK5e9CBH7pFOuCS+HJbbAD0
iqnrgvL8jvhKWViMa/geKhKlqwDFZzz9lLumoNzcldMlD0Hper+JVLErw0B/QJujp3VX0qQoUtRC
V5oY0PvFvmDsGaYFZzhToNMAWJkYqVsX/A7eoD0FR3QCLUw2hE+XZ2R3GJCtvgXjpyVw38U9Ny+L
AhyvheSZUUfhHAjL0Ly6qBFcwwHp+Q1nboYFDKqoM51yTdLD+kUjAdjyVMsGDlA3R/4Ft1NGOJLo
7VBvUnxqHcaZj10xcVmjj/7yfnPjjS6zI2zx/mhH+KuF0BXH9Pv2DqV1Yr72N5qGzSHM6e4mhfB/
HV6nGl7/8e6AFGbuuiz4btIO1+aoGULv+yQ+Yt92Pec6+8QMGi9DvIyMx4wOvcynwhEEcDLQFxVh
hDgEWUzk+TIC8G4x6C2QLrGnVt0L6X31d3gUGnZZWdoiTr14UNKmgBnbvOhcvaknzI7tFoqL8DVM
1O2up8Pj91S4NkR8m2+ArIcf+LDS5YZVHGYpekVuK9/+gZx7BWbXHR+Tuoe/E0SL+0K+G5LbHOUq
OY4kyoUAGZMI51RcVzRta1Q+E8Khr0EAkT1UmvIEiFdldUAPof6Riu5ggAF07vcEn+swd2dLfGN/
z3Y6PFn4Gih+jFv0agvRAj399Gegu6d1EyHu3zyDvOeTMQebXL5oq7Z+oBbb0x+GUusXPH7vsjyD
N+/N7N25qVOwYPCZqVLYCv+/1PzYk4ejcPB5sptQwCgNtE3As4hRRwqx0Z2SBBLEaj/6QvbYBX8A
HTLiUdLNw5fKqOGmz9tWTsnHEEpvQ7QSLHr/qTZeSrApsYbuVQnJJm5F1nGMA9CGn8OCvm7jYtZO
47tZqF3FceHxfTrYTOdjZHErdfIVObVyiJO5lmTuRLIQg2WZVYckBqiA1GI6T84mnruTBbrcSv0e
kCmUIciSImYEDNUaKXapGL2T6dZUwQVzOCLzIl9N2zvItHRfxTMXthxDZVOvawkrBTJNBwPNeU+j
JA/KB/qdcuZHwfhhNWlwqcud7bDOS9XSbMtOqBDvYrBzKRiwK8UjUISjHvdxCYqxnfvHGwYGjgSG
Fv5X0yEdZ9aa6hhBkl7qp8kp4huiT2KcaXXP+wrYKpg8KgEUfHHa1XX6JSxHJm0JqKrT/40Pvz8j
QC7BicSSOPlUQl8mfx8E6yzTICoWQChnI0F1adnpHt4R22Cin4zsYjTYb0ZSdy/dXF2zf0hZR8YE
b5hIirmpRBP9iNq9NgdaAigRTIiOj6bBvTO0yZJpnWPXHcRZhYGPEjRmkufkImpcSXr9ybiBs41l
WKPW/qaHWL39j3X+56uS0ALabc1gchke49Sh6zMMj6LnqMg/bLl+OerplDkQFbyH8nqiMYaVbYX3
vTDVEyjeNcbCrTS8/iNWeQUCAQGEi4bnnPz8Bh+ezIXMCGjzAuidiS3csxRSDniKBx5AWVcboqv/
7h4RGTBSPwms/L9WYAHIv3CndfR7cM7TPOAUfUC74UCbHfPbia7tofhH8n4moMyGK/2YbM09P42V
0gz1P4Sv04MenaP6vXNl//CPZts0fwE0ab6W36Ddcgb/SrkVSrdSR1lWw4ndfDYenZP4pyU6X+F9
EY3SfSeTs4N48IUFsk2BBo94cz0EvT3vmLlTVn0kTat/PC2Le7mOrAU3BBhKCvDsE3i+b6k77O4X
5q6gRr9NOpFCagKfw6TDEmLqhDYC1yzyrXTyBSbLgEAXNKoXm3ZfFgNPxn3PAHAsDkf2YP9HRGjx
HfzFTP+F9Ez5QeBq5HMtaPhgawPwvCTDtIFe+fhSOfiLeGAlL3O/2eWEIpNEfVJ5HvWBhjUskfYN
W3RCeOTfgbPZ19vM3W3/G2iA9shW8KUyzpvxwVJ3VMpSebV/I02n2W+iYTPYn8SrQ9eLZe7wUqjV
0F7Ytas6gfaIb1OhofP5mVdFTz/hJ6JYHvTdutdW8K3A68jfN57/757wRZIPB4dUdaCdo/PXsj+A
rAT4GKTvQFR+P+B6MGTz6hQrejTwGHN1X0btacThv2wOyWJdCeK+JAW+7ZE4QbfwjLVRI8Lq44Mt
GhLG98SC56OgL5xgu6gT3okjRO5NRBU452bG2GRcGdlZnS/bU1Ek67tn7zDt+TW5R98BsgQUUG88
RQ4RN58AyOd2ngUblAhr6uer1YeVctge96IZlsLVdfeZCCyQDA9sO/3HJ7rW9yOjavQer5yazPnM
IZZEyRRshCHg0D8SjM5jrcbyuWQ+H/GigJl0m4wJF+F+LYENq0p4rZ0A1Nj85qOr82f+mjqVWq55
vDwHHzMVGe/a+qkIKgElMobAdrTyTv/w5wctI2j1FKk/mITumY03Ahw6kdBjBU6ATf0fIau7w7E8
sZ7iuyNIgHoEWaDqJCdeY6ziIjI3RNXgQh81DGJ0p2zPvD6QeWNWIUnwmSeHel/2Q+0qLqmRq3AV
jkTIUEQDegqt8Lyqmgpghu8KmGBWw5iEDxkewawMa7cGeaxBfJzDBU1WFqQG6gTPjmuQYXivPoZP
+lXL+iJ5fgBbL47to1qwLYba6H0+wmr7+SHXC0F4hZka12Eu0aExkxvrC/jXLUR0OHUifA5cgV4b
+K3+c0vOEn16G0kdKoyGBvmo67OKoCNcqnK6rVpyT428JGhjTEwMCbO7SmWWvhT+EID6+g5nkKa7
HnMkyPn9FX2h6G4CCF/8435twRg/WdOaTNw0KwA9UPoE0V80GInQrvgUgOP/tEhLMXlPzzeemU6j
lsbWGLSHjRlfwX3YdrKz/hBdKmwHlY00WkUugohFAR28BpfS8sxh24zwTLvF2K+SHYl0mV8wYakO
UhtzeIYWmZzpsKQop11Paj9+qTMRPy1CZGCF1O+IPMw+DOIEgguMMjSa5mL/v+E8I/eXpDLbtbgU
OAgIAd3RzAw16VpVOxQWiIZ4QZTw/rhXbO4QMAZGuqXRsBUGHeH/MrXu+jOkjNkQhudwmdXzw5xH
NX0YV37T8CmJWhTDjxzrNve2PHuErKPePrFfwP8XsXrRJ9wM8KvXEUXC/uV73SV+q6ug6pPo75VH
rSzusejW8qFIu+RmNcQrGAaKZ65PogdUPv2FohaMCOWOg0JmP5ALGof8bZ0c7dOe7pTINfIUSh/Z
/s/D999v0hOI9QA+W+nIDYqP9GcYbdE5c+NcI7nB77dJPlyl8aH3Dnot6q4g+ojw+J/3sYKjZJbB
5ZFzYSO7jRphdsCH5AWkg1kaeijXAE6Vn0FoMXx8ts6veauHH+0MDQapIAuByM/VmYxJV+5SEIYO
UYQKvjFm10kPCHDScYO9tmOJgW4DofFjXGAg/NHuXK8alSiaSBJk/ESCc7YOqBeuoAxMfYYR4dcQ
8nCFA43GRdpCzghy+N6a0o1XUlSJ76KISxbX4OqXl4XdxRwqd2QG+s5bCwOtPRu2ukKl4F1c7BLn
wOGsJkRJbAKj2Z8Pc6ch6g+d6OyRU5LncDi+zSWP2zLw/o078NT2yG9wcq8kDT12GTvyqFwllzO4
jhEp71VWogMDNHOPDtog1nL8BLUEPpxDSzhISFs0tvqWfnr4OEnE+1E/ziABSR6fBz7rXqvYJH7q
u/Dr3jI1p9sH47fQB+5ZzYSheaoetYXxbtGr2ymWvRAy8ACJYwX5tn9Cbwgd94xS3r21qJMDCxry
T6rtiL7bYDSegeBMOPmh6bBhkyBB9cGhKfz610FVmIOQ/YbJXgalENSGBaxO0l+Vjqq+XYOZ5viZ
fvOkDiFAht8XRA13V7MIKqb+DcW9xWFIyDFHslgBNQlnQjrd01O571UPN2Hi2BQlem7S5ahRzY8E
FRiAqT+2Mjv0QdkyZjUh8SASSt/kjiQxGWb4+BrMbBohK6XBtdVMoRR8ddKjjNeN7O0w1xC6xIJP
GWiR8BnQhlRlsOKWcujmMiP/bnqGRQcQ882zThHyS1eYfVsq6bS/w/JbvETiC226RmaIHxMBP59K
zUF3+BExg+rN0AVWnhERQQZnrmBuULbyOSwrrwvcQVcA0qiL4VSBqGXCW6wd4iL58VFn/CXPMxAX
grwPjSqdI1gOmX7eRoC9k+fUm/atwwYrFbz8FLfKBKp8giATCpt2fja8Sqz2I31FI8aDG1Mpzr64
rPfkA4VqvEfLnIV/2WedcLrpgyH00JaNDEzpPKhtcPRkHuJzpMkFHQrb0s5cDh6LyPV6Hfgluc0S
N1NqCwFe8StDzWEZs652A7sNBgbnpfVhcCYeyKF1LzgULso1TIA14tAhBXU0luiWOJY3nnuRQmbt
85Wo7ybrPwsRu1MHUUCLWQiZ4JfLN8mKv+Jxb/7mDahjoMfH+qm51QZT7PxNEpjQ8iIXUqX91ek0
vnoQ0BVEncZE5Nbvq0MyAWExqM0dkme8JtCfOUgNwU/xZMVZTEEUXvIincMBAzXATbd/ndAvsfw0
4T+gVTDpy1ZCdhJpxCdH+hWlgBvz824Q8oAsqdyQo6YNrmNgGNpcLEAqPFV7XKfgLL9BDjtDAOEY
CYtNYd9AiBc/LHkn0oHN42dPAxIxBKJVzzhHEZl3lT3RC51fX/v+29zGmb3DaBfXQixu7gRUa9OJ
0rM9mNzRlbRqjmjC5fN6YixmtzUoglr9svH/aV93EL/kIWgvQNy9kyi8dy8vGCjLV4aVUoU/hNwz
wuIgyoKbuSFdsR6xerHkJVedXUuDGgOgXC54TxtlWSlDuMV+AkXOhOoT6oFk3h5aHZqDsWuQ8rXB
ptMVQyWHcrSLWYNByIpUB025FnN9O/+rhZ4iUc4bMxK92xgSHTjFsFXM2i9UIUTJTXCcQkTYCmDb
B+PE3GCR2rYaB1QIs4TN0hVV+RpFPOUSPXfcs+e7nXYG9VRvw09TVyOsgK2hkINt2+en8pLHNWYl
sDAh+w5NLaaTtBn+Sc0e6E+3a7VmjAxYSAzXjsScqOYqeJdRNvMhlN+Yjzazgr7Jo6T5sTXmhN7b
3cSkBNZXSv9f+wNiPz9Xu4+Cf2ynN5/E6JwpEshXhydPr83CxuENYgDo8BYOqtxDcgcxqe5Ccblh
xb41Y3CN4LdQMCni2iIRDsUGgNfQsh/1miMsLcwrDgSg7YAkwgTJz0tMxSVYZeI3S0aP/o0RZ3Bs
Cl9ZVzQlla/t/zg2+Og9A+TzBE4Dxdx5fNXImnSRgl7hq2lVXmXjN0s+KG9+sDbz8CMBSmSva2Z3
CSBmes830T3MVnHsrtxemqbhhkzskDC8p9JI1RppQ/7B9OVvVDWv2wVb93w8l3CEYGcnQnn3doBy
SWVjtqsvmiQxd3+rLXqU5DOTZGQFCUwvtdgjP5izk7E/sqE89RoPBDx5UdBy2k4ucLL5UcbgAR5Z
E5pTXqA4Dru9QxVmeOtMZG3oKPhBtZQVBXDKbJl+ctJauVfXphszNX1UuA+KNNnNLlpZxYyl1ADL
39thOfiwk01AHV42qwOxaXVJha9oK48j+ek0zXzAb0xuLSXQ8a/IcNPS1yae5pdLs3l61v3dzsZw
11OTGFfRX8lTL2PSWWWmU9++IEI8B8aUHZdojod7lWsD5v+9yScdImeMvCDRLYVTdTWbFPJ/4jEr
HICqAtV/ZnMApVnzk27+1g8EupYmiWgZWvKoo/RTk4uxWc8Lz4e7zjTXEsMgJthAyWFMmO5sNnk4
LL9hmVV/6AdSZYXRU+PvH8+9ljTqGf3C82BRektbx1ZAKen1XiGnx/RaSIGiTB2ReotAy/x4ZcmQ
wOvChpRTOTu=