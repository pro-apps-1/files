<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpcoj83hDWstybmXewxJbcA2O+EQv8xuRjbGiAxyNGq3FVP/UJMHW8JIXg3Tzxvk51AcOZrl
PecgXgSTIhxXR0sD3+aiEoIECYgikEsiS0SONV8ZtEcy9dRhPic1lZM22B/SpvoJt2qNoKgJP/Wv
AL+otfUg9SwRCXBZPg+IEg6V0qCFow5PLXyi0KYhdjKCMlAX8p03uHpxO59rrFXplRZT+6C9cRrn
Kpc/KYdn8mKzpK/8wvgpNREDlZ2DHN9uabGnmlPx4aPphoX2ab64hzVSx7jIQewISAxqomDWFBz8
TYmO0PhEfswMsh65ApQuMdFxjGROrBMlCSfSeXLH1O+JNGVfkudPV4PS/XRR5gjbPrtc2xJ8w+BX
BpNP59wSpSpW7izhS59R3B9V4/sAkLTLUc3awRTudAgohM2ZMWC2hb2KsXCx5mvXFl3U3vx2HsDQ
U9Zmnx+Aqztxv5GihLua2LY+OlbefvGbLs2CTAUqiVPIcCE8GKQnzkAn2vrYWSK9PCKF+/Mk6S86
uLIr1+L/LiiXduGxqhANtPttYY6R7Rq7HxxC/58mVH/ygqpJdj+iDuod/yI6NVpzSDy7MMBBfLFQ
iGBT1XoSfODgi4sHQ7MdHid+BOt9NsTHpJPkEoaYOe5C7IrR/phjtRM7pQ8QFgOb7xzaoViKiEVt
D2Yz+hKHiv61M75lLSXNS2e6160KDyxmx6DBMMkJdY+N2tOo2FwfgUWHirMBzt1aBnqc70897Pn1
L/Ea1lWlq4FDVn8MIa4iUaHpAC77XHCS9Vnpq4RNY5m6hQq+BZNOCK6+i5Rx8feQ15GZhMHV1eF5
mijYr7pjuMvi9a+S2c7MzIgG3ceLMx8jEzYUjCSHu04W2xQUcrN8rWz5/EQgruc1UYqDux0i6953
cNa3fbpiZvt32Lo3K+XdnFHIqxALBabhCFTJi9MJrErLMuNY05Dm6ksm7a87S84YkN068DXTj1Mp
y158tMLEWJd/PqIgnJFjeAOH2GsJ7liAuKxFjPDPQ9CV5C4F9tLoNwEpw1zDKkwu6NCaevkgDEtH
e3im6ts/hqg8Of8Jg+wzoMnoeoHulri6dU2BUXld1ibq+uKhDOv3t94WUz6MSyWKNoQ7WnNxEqXt
XJYPTV0qzDqOl9yVHg8aOyB0bN0c7hbRORFMM6cNmaTWFXBpzra+C2VfTq8BOj/FZpGCVVPdEZ9L
Dfdts3Z6a/iUrkfiTjeEQ0Scb1cyQrfg0bSq/TCv6WOdLT0ZBQjuHFutDJwb3Y3lb9kOUx7W03Eg
OKDzxOTgulxIY31UH1KVsaRlcnANmhTncY8NlC6mZvAdWj9EHpjCDnSnwP9XjWYfCMuDBMw03BMf
fMejORbEYFJY+MFw32s1HB8of29+5xVAiSRj3Lfmy07QPziuOBIyzNm1gfp8VSBmg9vZoLkarC3x
iMb5A7iJv5sFi6dRPGmFmH6Q0VmZwqESwuEybT8AKU1BtZM06Il44RT75d+8pP5TsF+LZjLLTj3u
dlcddVFDYSx1I4U+TvDY2hRMErtr39+AEwbWdB6hlF4oNev2WX6GDfHB3021tSeQ7VaBB8v6B5Zd
t4kAAYAfFVab6UiENG4XoWu/AOHEePWag1Cdl3T5y3WQqlAWccFRy69BPSoLRm+zeRpz5VNji7Ki
gdoyFW/us4ZhZAQjkKrpgjTQr3d03N6aIa6jRXmYBhzw5dj2nGESVZTci5txdG0nTq5QPI8m9p/I
8E/LBm1NQrsKdv4GnJ4g6CFq5+7MMCY9D0nFLQTyw1cqAK+Me9BjBe46tht8RwBT7GvRcgHLvQcM
HWEvyhMdZrJ7cjn/tw2tA8tq7r7RJ37qinQJJ/EaXRCsSwKZnjWbew4qy+RC5hhCvjaiYUipgjaK
9GuTQxnw8cVO/Pf3dFDDV1v+AjmcgM4aec1u9+l7fhjCtkPGLr1dBtQ8WVMV2Y0v9NRYcgvb40to
inLVzRJQ6ZGNbl4/JEX9tB/WtOy1OU/VPPF/CrMeTFObRFExOY0n1ZtijRcIksaNAF+SoRttrnM9
KZxbleAP72Mlz/QFcIzJZ/HyA/mG5xdTSUU+c4cNxPJPEs9kD/g87KyA+tu0kTIEiu5d3gNQyZW6
q3BCIyypFruO++duP3Ckg3zJ+V+TiP9aI0z7n+9/cPcJ38Qo5X6ERczrcXOvjgKiUSAF/OkE+ZvA
cEpGqKWRnz/7Ge5cwM9wAOejtyVZJdKb3k1u3VqIEx9NO+tUHZEBvMcRgKabr9AWB763QjGSuCEM
o9S0kQKSg96U0daWre/75QLmhp5f2taCbIzEfjegt3OjgEXukkVqbO7QHWU1NxPsAT+GzztAsy7n
dzCUw1uColN93ZldHkuw3EH9wve/0T+VbYZz3xnAlsbtBZJRP85pe6XXX1crLwrTIH9m/kd/LOi5
N/hvI2IZ8hSV+jvZd/b3lya5qU31ie4NV6AhCBvBSAIVSNrl8f5rNSkKZzIBjZcPA8yBhUAlFfsZ
JmxdkvkxNYOsgd1u0Ulj61P8k3SE8EP7PTd1NmuTQN+uL7E7VsOWQfmoFqxVKozk7Jg9J3qYGjpq
fWK6acSNV6Fb7ma//2cIKFfVxn/jnWOR9dlzPmxiw2V3iea+v+uTJe5EAq33BPjrZpLix9NMrwEJ
YYxuuXMR6nEm4bq9R7JwTTBIfK884b8Xa4xUAb8SH5AGb2aLXK/+gyMw3fzx9ufDpUosBsN/NX6I
If9jIToudrF8zj6Qyl9wQ3cFtwhrIWPObDGrMX25Hdo0TuLUYn6EGRRxe96GTiXQhYCYW1tkENUh
cYHu2Uxe4DoiFsYNLsg2Ff+9gHKaRr9wO7tZqCFae3EoKtqA30315YoyFj3bPz1dxmW4yeLGPapN
keI6S5cvUtGIV7cjKfzj8SLCclhheJxG06TJuzWUapvuXu4BvPypGR5kfe6v848S5UHXM+wkoUko
t6uTsPxPIZEsov2F4YYW6cBD1aB4Zv2ED+Iq+3WJZS/FdN4vUInr0cRc0rNNYe6yXoTfhxwv4UDs
nDUgbZr9uQRfOgL33zG1oN3WQG3ec+Gl2FymqoubLd8XS7xeWMq/+GmchX+N5djkfUpldiGUUR8K
xizvLJ2iHiG8n9NUsH1eo78qQgio3hLcoaiuhp7AWdZMDPlwKc/aMHoh/z3pm/maAPTbasNHDud8
3vPDlnpaSMKHvuWpQfokVOJQFtOkit82I/pR4M4w0CJM9wMAiyULo9uNU23CZUFUMq9i7hXjTLVy
2HjhpqUtMDY9Zkjd2NeXFxuiHJOp4/2Fi6MI+N9MfCmczDbkXZN9e9lnEXx6bCXH0M5nX6/ijJPh
dqvv0NAff8YFjTGJvoe955oDfwc70ag4IIVkmboYLExC7H6X3kjzZ+61du90s76NIbDAXU1Y/txn
t1+eDtVbGta3AbqLgpIR9wzF2OJ2R8Gp3Am/dyKP0+IEMZgt9DfCvziMXwIV5cJu5X7U3KEz14GW
XvS1IkuDisb/wMYx9vu93syYG6eTxaTsf+6zPVWC2jUbN5xiYrC1MGI37FBzb6IbQHttS1URLuJM
E8o9wqoqax1xaBEsoZzWHnf8BffS0vqaFq9coVtgqVXFgV8x7IbDSvJWI+5hDlU3bTUIqrVtGmB9
L4xpT16YWdN8xCbhChkVZCIAciz14dV3XElmSK2m1LHte+f0sNWAABNNlOXSGgqzRErsP1eBryXt
Mh3P60F610vIjG8xNJKfEL4lUMPSHgdL/n0qKecnIVPpP0QTa5VPHkEIAdgzbzVbr+EbnnYYOZVw
02c591kQTXSsIbc39uu8KAO2h9lxf901GCeNeozv6vDR34TzugtHEgdagbodxDGCDLPBR008ES/p
nrI1ALH9kojajdeOYLWT7RAns4kwm8lTAKMf/1tLjTnv2Go3NQJCArp8uvlh3Z1me8uFTHiCbZAW
igc0Fhg/NrdzRz9jid+vOZ/qAE6plg3EqBOYI/ybNHRRXSDdTzHkXKodmh9Schy63/1s8zMYVQJc
/yYmEG7tHBk2DU2n3grOhlNItr6Uv2oyjJIXQEja3OlH/Y1kZr85gmc3ZzEKN75aNLuUbAZ+pfgm
VqVr/XHgh3sVu7ithIAnvBHSwUPy0nzFtKh+bAd07VCMa7U44xf2dYyZr3aTji1u2HgzTQ/dUDej
LUutdTJK9h3i4NKaWlrVaP/yFhVVxAS+DWAK+tN1zV5VLaUYnDkvWnmVns/azbsejqbrguhX0wVt
R6lUuJrbIy41ltLWUwc9u9FPmeSnzle4Oy8g1d1T47YsgOwvBtM5HwTVqVpSpzW+g0hwkmfyqdYI
mqtsQ0r3ojzF/raevUfL9AY4k6w9T92UOXwbhQjyBwaDt28AhAU4A1DeeFRhVAE7yTH5/cAmFHu2
ANx0ntfGf69weilQf1s+fBa6DOmNuxTQdoXszzPgwHzPIWRPD8xUjMEgfy58RsDGGWZzqkE/rV0k
qHMVDna3sB/NRSkIULPpr8L2mJGfCSzUCPBKpqVPnBblk3NgwGsb/3OHaLP59EtStAUucNS3jBtV
ShfGIO7Q6lMtMMHv8uj997yhXta+UBAjaKDZ6a/RBB4jpu5k+BCbSJ34/FlpYoPmCsaLrXzJ2/cZ
SG/yULuX3EJbmc0ZbqNxFiavsRkyZhEUZb2dCkxodoyqPpkcRIfsvwk9FZze7cSZY+fHiN5X14PI
iJzlzXfpBhrNtCfp7mgKREbCBgtUDmjQJGpEWNKcwb4iOvbB5nBU4fm9vajJERtLqcAOJqIm8DfB
k1waQoOENX/SB38xZAdC5xwS20kzbjpqW/8hCx6ibKzfgIw+R2eiqOIfWD5PhC5mOnH6hJsBczmQ
n4FsXwwUvEcduxj4yubjIXkB8k4kdF4wwTlljIH4sEq0NzvWB4KuZ1awzpY5FVZ3SAekhtjbYWib
WqvhLGM0J127bYneG8GBjSXvSae6sXdLkgUuiVNUVKefh2SznxeNn5zWxkosqnzdP/BkXLzEg0zo
8BGe+U9apqvmrdC8BuPEulV7OoV4LeqOTxnovpSW7gyRHW9rRiIAABakqNz3lfSpfHFwgf8sonqx
1P/gO28qxR5vxMuRFNsUJNO6JEV95RR/n+iKVw5jJWhIqRjTUag2ICHrjAN3kzQpaLQ6CPezIR+/
3KZmBL5wjpfXmgkCd36AEBNnp5dzDcmhXdRAg3JyKtMfIiLRD4KzgmIvksPCKVdsYh1b43HdjNlH
RgtMTH+ywmZ8L8T9ABLct9qChfuzQwl4arT3i7EXf91KnRMzsDk9DnL9GmH68DkXmUrTHyYJowsI
MJOZBXwp/Soeww8ZLhewe97xC5fEydwOaz3uXcxv1axTi7W3GRSaGNxKAjozt44RRt1eDVkVAtLF
MB81U3qxyM0gYDjPEkNleS5PhG0+CAOVUWHRsC2oefpmUW3MSy+3DsiW0Y5W+MLFomIBYauVfD8o
0I4RgacVuLEZ5FHDGs47/wVULiDcR8VELMaFcli8gcOjT0rNXFG75i1WjvunT+p1NVwmxI1b1ohh
WIo9oKL69ceM8kczS5ifcmBqJmMpSB2FrmOUXvy2A4Lf2fJ2eWpQoilFN+MX7O7/vEC/payvLYup
1yPfedjl2WX1G9vE+hqiAczLj6jh0SEKcxLEYRDBs6RiVOK7iQI+vU48bVMsjP+xd48EyrNaB7eN
OF1NnqS7oKH+6xE0RWCUNCNlIamBcQw0ETDtRLLFAjcKeN7a/uFQMO5V7Elxs8AjrpKC+IMhIsGs
pE0uEWuNK1hj6iauDQozyl7D1o/mLBaNoqkI4ujU2BDVXLOw3FnwWlKTenVmZkEVGY6dbeIq+w+r
hz+Sv0aCDry0KsuVhfZW8ZgP3J/mi1vpxE63WcMaaWh0m+0WGeM4S3JMGeaIRr8ih10wgvVHJNXs
zQGTRO/hwruXc7unPRcwnQoKkOeidWsQ++18DS0gicmlQ7uf0ozCfpzCZNSQ1rpFyDrz2MShWsXd
9P7hLFUMWdTT4bFHXxCsd7p11iOKLENbpdrMVbjKGnePAKPv3dHjU8wCFRa0VmrP/MW4/AwNpIPF
AFSqkjWf8Mlm0oIeF+FmZ23CLg94SBytx3SvcVxblc15efgNCnGa+HdmJz1nXwWDaQICqQdt5uJu
bmL23jiIf+sriVrbUT6pYdPVCoutulOEUnbN6CYpVsRlLgoLW0TT8x/LpNhMUpAO3jEn0e1tVPzh
BSLXQ35Kxx23aqrjdDGcfE4V8an6GL3qitsToEfPLTpI+8yTlLWjVnZsKaMJQiNB/qylfBVph1Jt
yfL/pgnuhrAgmSEY1I3ugty938M4BylMlZrcED2J1NcS6ZKBxc7dyOWdFc4Qnq4fYOjzsHV/iBJA
+hqIpd0lwoy+kICcj3e4es4+DdE9rXjex/h+tIKsbt5+rbq7f9Zbetnp1rwCKUatIDqxRe8gTesz
ApCC8nXKbY/sXUnGKZ+fHzOxiVgaNW/A6McPAR+oBILg5GVO/rlM/DHRI/QpLJqEWBpfW7bf/mns
FedmsaTyN/IPeOAk+FylphQi+L3TbfgYI03rFfundASeJgV/kVPPJrIXmyCgnF8tm8G/1CwdU3fr
5Q19zITyteDqSz47dQZthGjYV3CsmBTYdOct9WwYhqBz3xYVYbY2qLAIi/Vx3OyH6g5OqhNE7j7I
qMpOwb1i4ZPrYvgTLB+qunhbbLXwSRCMO0DkOXVOx6SCNKzGbrLza7OUhEUfXvq4di0aQ/m96GOn
BNqBYhB2WguQ6NSj4DGxEUWrtzy8PoBR8T5TsuUWneuYG9HirSc4/OrK+G//QqxQsqJqtxn9pjPw
tkoRWXNqlK+9NId/akCSTONV7fttjQG2eaiuFoI5vEooBpA0M3RnvkrmmTAdUNHPWBpGgzn6kHMt
r80pZ0+dgOOngy1Ynznj0/r5Fd8UFaty5yIBsKvivEk2Vy+vYtEOfnW9u0IHxz59cqDFC9sJW6Ui
NtFyGLfws4xO8AAvK65zz5qOs/0g/iUv/EEYExpMFwFEikvbHjEKfemcjhjB2FcBqsyM1DqKghxD
/D1UpaHtodOJZXBVLmhfqwgbTYv7wyVYZXqKMVNUdYj/1Lj/TCm43j9eAFwQVO+e8UwH8BSOmZUp
+NIt3ZQ9V/ECfZVajWxGT8ik20DC80Er5d1uWCyZGRbhN6yD/o2y4GeixZKhEDrv/R6+s+pTkcxe
Y5vyIFymT5paIYiCZwix0tGM9PngxKxHRk55MqlYD8h2HYrG3cxwYHzxFVeJykWjQzv+YDUfqVPa
HR81e6fiTb1S+UAzzvOC7/CHyBRzV8qkMep02Q5vuVC4nicn5bu6Q+m7SJ1VovShHEuReW0xTMN0
5raPxjwGgsbLJdcBgxT0msAAD0zrVmNuUeGVUAibza4iMtrPipcMFr5aiClVwAAzSQiM3OzAsbS9
GWMcMi3hsIx2MCq5ScBuXV0jK9wQMqfjYON/dZkhW8gHxGqCSPq7RDembzqh5mXwTbSK8qEWrQZq
+J6hqbImXjB44T39wz2HhqknEw+LZL4RkuQgvJdpqTS98A7WIxMrPDRWSUlhw9gFgHRk59N5DmtZ
vU2z3qPozcZOYUKctaqZrKAm8A9AIe+2r+FkOArdXAzyvkWIypRiFN7T31P9O6l5UlSrav5xog9c
JjSPCkg4BAZonIGWjbOwrcRd4Jc/AeSq79Hfneov8/gP1VDBcXfj9YBzgiSCO+74B2IK95TwuKcU
tjV3DbqINu9EvfpY1UNslqsZ/VCjaOn/f4/PRmi2ZIRHoab1lk0pavnqYFG3VzbG1qBPPtfUUVK2
+cASaIhyl5xUIuqp2tFW0tiPT4hJWycmU5MYzvUvk/3Hkov5Ks9gC5f21ciPCPpNHqCx8FrMVHPu
M5HOZtrTBJ6JobvNbc1z8J2XRy0MaYK/d8v3QhjjtDR5UUuntC5TyT4mpgdrkb4m/Xuo6KBEUhIb
HKzxljtwSVYwurueES4SQ332p5dmMr/jopjuqSskmmmM2Gx4IzEmtXopSumrQql0jpZNakfqHLFG
2JKLHBznuUcq+9PEpls9evmWizm4lakqMHBgy4dSUpxzjc2Y0lQAyPXeaO8qQvJDD/fp9b2WMreV
LQK5T6XqhniC0jQBHpPRyUBqo56Ey9500akEWPV9MLGXourfnSYgJ1uiI1Xr9xntLQIehPtEPFDe
QHeSoT7zWGYQcZSq6ayKGn8fTYcxq+ouSOIAQsJXGKdZm91D9LtBVKl6DfHZsBLHK47Hwj7/BAXT
/cLhbWXL93CEv8JPfTp1m/U6ynaKcGcX0BEmA2n663a9uxDy8tnCg9MN8r4WwghA4hr8k0bfsNkA
y12yWhNQZG==