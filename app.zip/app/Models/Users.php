<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPym9FyCAkuFqq+Ugu2Q4tbDx9kTksDkK2+jcN2TlA7VATaguCL6Ym4szuxHQqNG8C17vmxMn
rckql1i25JWxc51CPcn2swUJGj5qadPtmREWj2tkGK0vUe2xw8ZYDIA1a6WbsfPszXrILPCGCDT1
UCLuW+UOIGTYk21Hn8IY728rZL5OtJ3Ptvi1NZI+ZLSga36qXGFHQo+lNsWVVuZb0JigxldMcpSJ
AoG4s3MxGJWzO/66fByNMvHv4+LKIjs2VKUnJH+w5Id7ys/xh1blMYJasqKbPKyZgK4Dh9YV3kli
eq1J40hvWFxFplgeAGLmaE4dvkj6iLTEMMFHN2H+FP/2vsY2GFl0+iCKMRxutfKcHE6zShddubAi
UVO9Ck/E7/kFvq3+qbsPsOklzAzKQOArgFyEdUNLqux/DflFS1VUA9c1NYH9nZZ+wUOs0JwhLAVn
qYxdllUG0d3heVHL0XMx+RlsVAs+SoMI87i67D5xrpuHcgTEaBiZIW4QL7LYR9RlGyKV2RsvD8xz
iIySKGazMWqn6rT9KPvhJb2tCARd0dFQw4MGS64Kojc1dY0xFLRLIGG8dUsS2EejW88MnRMK1+a4
QXEfdy3TITcyecCLHNQQFMet6OueXqrP3RSixYwpStxF/ysVh+5k/z3sy/fDW2ppvYLcxP8IMpqn
6Y55mb7pB2vJNZZTCH5OIGxu0iY/SaLpCXOjMnKlYcKiZJQ6j6k6Ay2H44QwCC0JSxLjidU5D5o2
sQnqLkBk9nQj0Gu61qBEMMMZaou2X6jntGmVJANe3F2Cf+1xTXq6jSsz8ylRh7bMON5zPVUpE7EX
apSLPjFPvqpZD/bl7NuhMok6BnIrVRoELSZv9wykClYyAwALSUe5MlysA710LB5c0un5re5lkDc+
5KqS61pHIxvR/Sw28+CY0RpJykif3wBvFoJ0Qk9HohVA5PuAZ8lSdy5RanqwYxkjY1AYFZJrfrD/
vYRtLiM/EJXM3mh/LJ40jX1I9Lxp+XCbUYca+3ESkTL/1xtjAqLJprBAw5lFVQPhHDh0mBCoRfuh
Jo/ZzCm9laWeFRIFtPJwnSBvSndPfrlyZuWP67BOrhPgilHF3Tu2iajlAQBUPiDxJ8whfu2ottnV
8v+6fuGI9IG2qxJHaCUJGLg/sssi9SYy8B9bWEwED1W31xpSIjxB01ytXQO7LqaiUVN/b8fniiZT
/ClOdnA6rE51AS+qq3N1kKT8ZFJF4Zaf2wrkTGFaA5xKG6Kl5mAotH8Z1/aeslMPH6aNCKEYcIPo
HyameRyR+hZu8Fsbyecp4ha8ZLJzEbbdasGRzBeT90Vh/TJryQZeGl+YlYcZA54lUw6xEoEtHoxF
itrwfn+8UWPuAxshIxlT+rXqy7BGbyJv4nlL5S6Z3dsSBJDf4j2BNttCIbJLLnlPZe4zCsc67n84
MXIEQlSvqNiEeUaOhFf0WQoHHmkzp1VUBs7JmHVII94tJxBazct05p3CnTilolkOB0fCYHHEOxke
cEpLxcIynOuOQe625hMbXvAcsCVGPMn9ArS4x8q8P8agPWAubCvAZGHulSCVXaqUKYlCgVqYC6Vb
N5xYnCgVzFOpQvWa8gSe78oO7eDMfTZj86/fxi5goWwu7v4nTYAj8nJGIX9XYOZTG/mkRYTSqycX
dkZGmU1DNl4ZJYOj/vees5TMYVn9Oa31fCOIwcVT/5eLJCV33qIszD+YA+wmY8iEa6buRXOMfQBq
DM8cpcwWHAftjke0jGMh+oPeAdfbPAbkB+XkwH6UAnLH7Kn8rNhuN2yN6avviyJGkOrmpoh4wYbg
9TRD+4jDfOikQPeuBdfp2Yy5ZXD0/EzsecuxxJivc0IPaNz8BRVJuvcI9QZi6J1F9N5FRYi+ApYD
U3WE+qm7g5RMn0+/c5f0U9Xig3QpgoymS4pfTx8EKLWt1SPB8z9kgeOcz1f8lrEHZFz2aupK50Jf
2KVsJ/gCjvyHNd2WlBCn24oxaRhvB5V00Hd0vPKgynpn7PP89vCsj3+ZU7rhsG4lu1yr8eGZL2mj
O1h0KeHyYhqJSfpetiqRFxutl0pJx+ktIxzja3HEhvZ2QdLTp+nQuf15R/TVWH2lLX0Xyg8f2lkY
dMC3m+FMrpwzRhffOysHbaRZ5H9d6RyGCCbph1NEMBFyX4QKDwEfOnwQNXxXM0Lfvfq7zjXOTcnX
M7jneAuVkaTKKJZ+Ms0TRqyW1/Pjowj9CLg3cHsxcS3r6vzBV5hyKhBye69KwKZJqeOW030OeiEJ
Kntcr54+t1kNaiimqDBPTuyOv0dE4acB+b0kGTrNAkbbCVMDQkFCILpfKZMDgZq41O3W/D2inWLH
B/9Ru7lNE7J1fD6vflwSQsZ5HIRhAHuRPSWjPGxJLYn9KRRYZN/jX86zd/+uWQI6MXXWFdMJg6Xw
u4obhhGO1SccfH6mU4LNXpuZM3EPm59jDYy0n/ao1x6UyCW2eDhmCFCqxADDckxiEvdJm8moP5st
MHsv5fCdnv9DzGi12K0qHWggmY1MJcdJt4QBebHzjSi+ByEaRw+kX773wi4U0X7anEyRAOgf5tSb
VflwpdVFMTqDM9maWYdfa+6nG5Ba/l684tFXTR/kV7wGA2ap0THv8QQnbYY8zmqvCLmkGRacFh2G
obfnBedMfZlj3kybo0zpfYAVybITa30BdUK2ijdZph1IwGHR9uQloDFf4MHCBPdjJW+d77iaF+ET
KjGP2TLzB2wEJZNlhLf67qARR0dMZTawvXcLtwoNHRUBgIUDqjHlcid22knWPvX6QQyGf2hcyF2d
YouPtldmqG5eKfXF0zvNP2GrpqPO5hI55l/c21mTboCRbiVpgQ/9XquQTr+3qLvkMqlwYUgh8rWL
rApy4BckK8YH5WJX1+dviSvawT/b+O0oQz8f6IIJDxOGDSen6wV57QK5ci/Q0WgT80sZbStzViSN
un9fpSd7iysyf6MBuF+s1gVolbiqzWIGPCerVBsLNRrdwA53Z/kT312w1K5B/lwsMrc3OGhCgsVt
nwf8b15rdT3o+4qoGJVzrM7w4nXzp+y6/yreAc6yPzFBhMM4S+ujLGNmVRcFpPxClZcLmJ45GIyP
0W+CqGwN5BuSHrdHuUZZbk6ScFxawmV4ts8TX+F0A7z5QgcJchkZAeOksuCm4TqmVdizfUaS8ljg
twybturGEwgAavG8dJJ4Jt02knJB9gqs0iqw5gtdC2lh6gT395M8v5pB9jqXvydpzfr1QTGszD+u
m8VmLPJSjrc8qzZc3wjo87QOr1Hl+gN3Wn4oA3XnRFqOhmyeFrjGJYq2ys+B7fJHIc4I+rsdUTk2
+BOivDjd1T3FeK+DkSBenjRbk7HaIk3Zy4OqhfN7UfVcDGLLppPFnkrVqrNNUW6O9F30Xpd/roYw
4BL9yLnabMxylGZbzM1UIwPm01YUvFYTadnI1jQ3zWO4IiR96PPoAonm+AFNVIG9hTosZwjLXNxR
jhs8p4NGPSdtNTQEM1BPD5eTv6iK31EAs6f3IhvJJ6ySvtKfEMBEL1HD5aLFySprDzp/6dxgCPFY
Q5u0YoogMqX4A4fUAAmQ7JuXr4tlw7KC79T8twgOQ3s4Ekl4v3sPdiruZC1zkK+f3FTYQSe55zDB
YZTQU1I2PeV+74OrcoUCdKdcI/GA5XdWd1TIY1FoD5FhYBikjNzUsjSPSUDpLq6ZdBk6gceTy7+m
BEGsMR4HshI+vdbOMT+EMaYhWhmIDeHwMXIMmF+VkkgDk1CkG0fvKIKYLaOAJvg5PEevzGVNXYym
m+BkK2uV3/l1p02I5k4eb4soigTbnvSxdGrghA84h1pkZGZGSoR8o6Iq7lV7u8U9LPNzKKP3Ll1F
vMtfzsQdFVlvkQvZrrqGSLChjSs1iVa6eZ78MHHb20EiVy2VJmtba6uQneS/K/EJ2x3EaTZCSvNx
Fiwin3Xvw3U0b4z6ThlE8Cbwt9wADau0BC2wZikKlgi+C3aQWyiWUpEFSHsKjlpW6VYNzvVsnmee
g5zuyMVu8qM6JBsd3nmlzKMZGecId/FIS1YTh4s3Ti8oVvdkZELd8zoZZVrsuSuYb2yY7KgIg2fN
/+orjQQGYo/C5DgXWuNbglCWPK5o4dK3PV0HOfki43NYboGKi8y9U3HQMS36MyTLsu7r9UTsnN1D
AR9+ZgvUhzqKuffOg44btN0e2Gn3fWHmICkZSc2FJe14l5d8WGKa0YW0LE2nwofapS5vnQkshLPO
bdv9IemwSBK3V3O6ouFJ2HhrAHUR3TKvMbkgrvx3z1D3yyQJQQEaGjI5G0/MyWjhsMoTR3Ytcohs
qePQ9w3NU3eNhGsnfBQvkZ2BMda/jf/yjzoUPloG6cQFcZZPt1qxryT5674/hSkWFqjKXGPtd3XX
rmJ8z60WHcFSNvtjaowf50FGZtcVBckuL3EY3sp/VOJp2ZULY6U7sB3l9ARtVXiEHdW8sn0xWwFJ
b4uvI/nchH/tM67u9tv1SvFnlFaWVKaKGOBOl/UMcFhxvJRRdq1DU0lhne4tjiOY+WilWpuW/d8Y
S0MxQXOFMte0Dy/ANMmxeb+2s4bnz06JrnmZR0vlpP8k8XatmGrZGih6Lm8hz+CglWzqUKh42SBf
7bUupfpGS0EqgKf/xJad6SNDXc4ep7UHtBitGHSvgrbdyD00OtBTqE80GW/LMLq6s4zGHEFeZN5N
Vm4uy9yPghZsXIZl/zZeNOkihDqKUryfL4xroOQX++WLLVNCIPBL570T0xbJo67KkjOh4Qyd0L2r
Lf4UcROZf4XhvvwjN1ZmI9WVx7w4q5UE0n4/BqdtpNiPw0UWJQjDUmkxnTdOhwQ1Ssn9P7HoLJRa
1LRxIVTaMmkvAZgBSbu7cg/tfMtGzS/dYNvQaOBdp6p7WRMQdK0+Wi/+XQWz2pOtNjGuePnV6jDP
iHYZEc82ZelVuLcmKhksmC505NB6p67bFv/Jxuq3/mlfbiLoRK1atr71UiDy7abj2IjDXpcej50C
OC0JFxpc40qj+bc7Q0CGueajdPYGZ4Hyzw11/yhdDZhFjtor3rw0gcAitnZ/gG/Cj/VOebwgirN5
Pu8DbYR5ffKujqVQm8B/A5ker47gUE2Tr8azB5u87TD4/qLmxkmADiEZSeIicRuLhWb6g6uD51CC
g+8MifWu/x8DHm5ZfVmGY95oviqU+yrDfRanPFY7xlKddmRdiio9Rnz//IZNu0xfgpaT4oXwU6jF
4fmOUH6ry6vaxavC8IZZxnXYyGzd7mhBKAeMWUyRl6a1lZabpAVS2J/uBRCRZGdRuw6L7MC0dS2B
Yx0fqepQAl0QXJ1g7owDcmeKtZtMoPn7Ct49UJE4wGUMDNyOF+rgGp3Kxn+uPMYeuVOmuPr3kpYx
UCaPbf9WrWImgIO6I35cBW7cgbH3ki5hrIK6Mdw1LPFyxaHxvHU/w8cvVzjGJX3k3gvm9M4aJdX2
jZFcz5ik/2oPGzNdQSN2VQbjj5jRCe3cMIaXMPyY0MYM/EcmT1oaVdexKoOKFVyLJGpgyviAPR4g
eaT9zx7T/axS8sjGKAQlMEEQQsyiRcJ80j4eY/QzfhEgJXt4/I24CMnB3MN9uyEcOg4n2lv/oSaI
9JHyPyG5iyAeeiQkJtOR0vcxIOdFCZytq2+wtoXYEDgaQ37jS8AnfU4kzzZlyKYnE8DO3ebGBBKf
Cujr1fIsG/lEUA+iNFL1dAoWc4XjHsUFev+Hdp+KhIzF4z6oOE3DHEprNEqWXloUvq8wNxgMJZRB
R/MZcNU5M0qUN5iZnqSL7Fi1FbNp14bTLJZKU9UcDXUUcIr2CfSTE2rSZc/sIn5Y8yTZeSAhre15
EflVkzFeK+tAR7Uln6MM6Y6Z3fiCrS6ZFG65hBQOVp+bv/95vd8D/vJoD02hWf1IWjpB7qHSyMzR
vnvy3gZltYvcyazEV+Rk2h2nFymppUuCR275o4LPSlzxHwENjNbcsioA4dP5xCbn1fchLZ+Fysq0
5T35EoirPaAptbql9BD/WEpWfcpDS8KlCfTw4cJ3xQS+MVsmrg57InO2bBbL2nd2tunFYX+RW9yJ
akzErjCgUjf6+wqlhU4tLoCsOVOuuYz2Hdsid+eA0ihiYd0sAC2brZBSeXEHoOA56kZ2yRRM8IML
wT/niWaP0sC+bkI807NBhd2XuFOZ/yhHK40O2fjbsUt3gKcM4QufAOkV7jqbtdp5lW+PC/wZpdV9
6F22dyPCxSeNBxIkbRGGe779I02f6YvLuwOnX8gDW/BY6GnKigRaz42/7MSRLW6FQuo2dY6uqX8+
a6x6Axr1LDnzggac0saQ8EUC0F79LrCSBwQ1Mu/VTdJPZAO/WF40oTQQex7LECo1BEB16zmthQ8b
IDu+yGj+etC1XfvDTwd8I0er3xFRr1L1zCT3TBl91TDnNxGiSqiIsy1qYe9mUBRyE86BLPlda5EO
rgsO+7OUq6Pghqrl9EpMTafjl3kWYqHsA//Y8i6M2cYdN73EoFEX5I22t+D4vMKU2cY+nydZb3tB
wktfI/XfgEIXL6TH5VQpxff5/wp3KAlJZxbp/mq+PKh0BtstnQnovSjBvspy10O02fIASkk+V1X8
Jw1BQg+vgzomCVUgbZHCdjEO8P4hr5xS73JcWKGLjvyprVgGvknfbSzXLyNTAQXi4ZSzHizoP6xR
N+t+S48ONnxFHYYHpflQiv3dqqbgZzuC+5+tGDu306Eb+yLYrRtNo+p1SDEtuatUujvTKUmvdaOI
vdJ2dhBsTnAmG7oqJeYaQK3ZhpPV6Y7LI8k2r1K0kvi3bnllazzQHg6wb59yIJqI5d2ceeg0X5Dp
EamkN4Yf7kbD1hdWDR6Lnd4ApU4B/uff06MnxGmIBryPfPe/92OheNuvQSCXJG7hEEwqDfV5Cwfn
lTVMw5BCUeoDU5BJv7PupnMYT2QLA/RZW9jq1Ln1iraBQn+P7C8GyYBpKxGf2JI1ii2g8qWXRGIL
GA8/wZiXxAbRZfQ9W82tNPcgqtxCbuoqWiEvjnZASxBtrPydyHnTwEgZCrNBAzulMNwWLE51OGIx
54tjjr1iKO/MK8YMoPh/vW/0C3NUJxEIIBfLuWEsn+EJVmLKOyO5qZv+Dy5wSlAraZcNvVvkTgVm
Nb7a32ZEORfgOOgay8uhhDjXTp5cUvg55nTpo662W26/DMEz5sV6uOzj6NCLq/l4O27/Q3UqnVnd
F/YZviRe6mwKEJEciG1gmBFidp8819wPi7UxP5FgdQJCulse3xzMwDv2//DcfJjScOml4eojOTtt
obtdrVa5dOVcLx+6FuymbL//R7U7Wctbpbs715zwk5ffxofTlqtGSWxwYVx0nIrvrmKm9SN3Wxwd
N7GqCFZZS6sZs6WBQZUyExe25DNvIlwin2sHCm4dEBdpP6fWJX1jZ0S1Pqgjux1np4QjWN+22ONC
CE+asyq2CQhatIie4356OIwpXiUpDa2ODboK2evfxwBMSWgbp+JXeyg0L4jUIrMXZj4G5e2uuXod
fxlVZViv1N5zUVDFszs2CWXP5Q85aK9/XYiv8StyI7OqTcHUDnICNFb4VJzYh0nHCny+EFgbXwnM
kFeA5kNZTAbKw7ruR0sHa/dYXcFZudJMoQULHfQj4yhqhxE6ovUCg5NIT/GXxjCHrzLDw28RPz7B
0QSKkAsqOSrxu44DXYSV3O6IfPVSKTNbVazKKteJm2zmZyZC0RSC7To8dQKnkIgbPoeeGdpyyXjY
9NiY2RLISH+02avcOse2ihVQK35+vrAn31EufKZ3+VQJCJFm7W3YQvsQ8AJ31wvkhkR3BH0TNEuY
HwpDwf17hMcGQ1OKQlriRypzfkMe5VAX/53vYywUJ0m19Y02gOa89kG8QSV04b1LVOTTGh4F2kNM
NxQtjlycSVyENhL87JDAI2jjlOz2VteNSkwjhEbE68sCsn/pxC2VCmo6+Vw0MYSrI3q3OOwrVFAN
bOsiL4Pu8lKR/dpCehnd0zVQt9vcB/9XRAkHkl+4V3SlCK+MRGml9iJCeOxBquHCwqQejPCSMHTt
RVc6fsDtOmRn4UfXZ1ZI0P1Umz9dlfIKGl7NFI/r90bvOOhKdkKZBkCUTkKeIhXE3F9KFxfUrTCs
3jMwiVGTzMgmnRXRgqjCvYfkbzjFVg+a8q8QAzscR6EynPtzt3FV9dnF1yzJHxsx1LI5WLBReeSG
e6T5SIrjSV2k/cIxRnbisTHIwtwmhRwLXxUaDbEYrFEQ9Subpr/UDkatJ7K1oS4GWK15J0PEsJ3D
J/22hpDjllmLwFhqo+kVVYD/r0EGdR4FWym6HkG25oOf+Mt7bmTvNzUX77bmgjHA9AgwMOI+QwCZ
6Iy4gUCIC9GOhxuHQlo1gYAia/Z/w+Y796Pm4FOwq2JdSA7V4sBHjhlYxW0olQ99IbLyrVLgcjxQ
3CZwWYlR2xzi28iFNBDL7lmL3HgCCZ0tuBuhXnjY5wnateCtLT6mvrt959xAoXhmR9vfY4IDCf8E
l6jh5MOT9UzlWo2HJHlH1eL86oZ0kaQs1b7c0kISyGd6eyREY/0FTTiz7vQYxJ3cZMzRjvtlB9FS
thMnhLqHKoi=