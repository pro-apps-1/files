<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo7opGqQTZOYunnOBbZ8tWG42BAH7emPpVeqkGlzi1GHjVISfrzDdX5T60BAYm0Dp9xC2A2E
Ng+2qYJWoJ3gbxXS/9DLTyjQlFuQAku1HCHSkRAzTe2AeDGUqo29BNIncCmxQadLdPcru5qsRS++
L0M6VlL8rPjuSfQhyvIxyXWcgBFinUbHtHYtT4JKzvjyiKB4BmDJItYe/ZFZK9Hc44mnhyqsQfE/
8JtLFTI49j9qthIOzO6fPSUKfDAaZjjvz2Qzw1o0/3/QkRkhcBJvk2TodnPxg6wTfREz2tZcal7W
AylFk6Hq9H3NCb3W1XTlMQAJ1RbQ5tGmzsU5Igi2k2M6xjwkLEOl+DYNSqqHk2n9BUoE5TZU2P/6
l7MO1GDx76nbzbJDfCmS17xGec7S4nRUsWFbMCh43YN0t90IVElpmHmEhsDx9L1lgeq0LwB5h9d5
mZCXVjgVJC240XIAFcPWMl968n3Uxyq7IR7C//OYbPBjOB4ZI5P9aJGOAZ5ELlgQdEIjULZyktin
vvpzXeRt2Z1B7J/U5Eel7CkIt8mVWOiwN4a3okNSMntQAtlBD4JgyIK139/snDj7o3wfR0Mz4CnV
IOl9OoDasmaaIxSMImcAdlCqzuC2GGfhP37mf4wNtZS+Azs+E4dug6w/v8AnKYO5pxSF8bl/6shC
7TR63kNyXVLGOgX21b7RiaLTAnoHALddllGSPNF/jktMGrtSdnnJRx9Bb3NBuljtQB1bbELmcBL8
1aTTKHrcJOZNEgxBXMz3xlhGKSQxTjyvL6NZ0XjdzCdzfNoSrV1t02aHSK1Ebmi9O5fHomK4pmat
w3Zvr372jqZXA94rNpkISNdEV2hPDCqFaQCZrMrNXxuioU8aZ7Y+h6cp27DCqNeHkJtrJ5NSreTh
+avRgdB9U0stUJUPlrpMyGvtGeSaRfV1ctnud33abHglf3AkaIyjB06dtI2GyH3tGIx2o14DkdFF
Dj+BEeG3R5dyNAjXNGaR/q8COnH+E3Z5YzElGWbXEKkHXuhgxPMShZP8yVk9l+8tyhz43CRrj5dS
m7Bf64knPayisVzBkPhHYiKG78tQ9vbTz1lziZaw33ajhoMEH+AlVJkfToMMr/h5umXI7g2Cup+r
g4ScDFGfCbDlwujEox7UqGFCa9zKLnWAuYqpfUPL9aa/CCs2l0Sl5mJymqkVpY5imBYcHc9PlRlK
zqlbomW69Lr1Jdj8PNU62XnBZH7ycKxhkPKW0+csKs4vzuWhTF9FzrgeDB9Qv6dkSfJc/0HMC7Qh
mrcO+htnJCGpMHtuOoYDAgQGBWffIQ9Z6WmZNSklPyr1EAquUdHUodjpCKxM9JPzzNC5QlNKoxYo
p2ENbxMm9KYWov++8QYLidLeaTuWVyidiQzFNnCcNt6IJOecZzDSi8oqvQbTxhH7bs8kRMQ5qj60
j0DJ/yKv4N5sn9VOTm1tjKF7sfNM5eDroS3Dy8Qu9djRkXb6VXWSM1TZS4GEUILCI5grkqTuJiPV
rBonFeUf9gIlEFVUyA6z7Mp53GiM5KpCnjPff2POOegUNxfGvI8XVFFis4ESncdfpHSzRI/Xu0Jh
C7LRbwAqBA9JP4Cm2Qtm1zhd0uHuZfuC3bJMTc3oUOvqCoXcXjt83M2RlOwfOVYDoEZgkn5xQfVb
YeCWqTGoPy5NotCUS1mstCar4WqEZl7iO/E+3VEFXXDEaineV7UULvTP2xoIUaHNEe5vLbldnj65
itDFpaWFzzn+8SoXoe7za1QX0jaEYY8unwElOF86HcWd6IanUp/C3SgO/PoLFbSG/tRh9AnhX2dT
SRZHLmIIncY3abq+kKNaEXm6jum+o4kdd4xOFdfiAlvQtYg5CGwuhKNfsp27lGk85brquC9DEklx
ZoSM7qABuGyrAj4ZG+8Qgq/L6+8qNa5HhAslJ8eKydSoKO7pg/Ln0qB2bFiQ0XrEYTr1SgQxOkFt
NrgcZ4+QcYTlrmjPfYNmkaodGy4hnq6BP/WqE9FVOD5R1kIU5InEUtX9QjsCbeFATDbr410S/uly
qk89nBlIvxKlW4GOXvs4mU9CXMpoBOKD/sRoZqehNsY7WzJcBuHHqlSR5kj0Njwm9fSgP7JY4T0V
SnjcIiZWnM1R+QooMya3PC/+JtMECK+aZyxAj+agNfIZRAWYMqsBYWJUOBPBe0ofSk99xkFpbKSU
6ZhTC0oc7caJg0D+/TUTBmoH2u+iOUYpy4CqcZdJWWOHsAAPWZrGKoV8zIpTecp4dr27AGWusyF3
45wVbWxLLOcYID2GWWQZnLPvxb2VE0hRanGS4DC4TD0C4rnZhvGZ4nJaVpKTwzc5Sfb3uEnYITqc
miHePZjZbawbl7aKPhmW4afxwaDhhdRKt6mPxDJBrT45I4S/R8HXT++4beXsq9ozibKRUOoRJ574
Smn8pf3iag2pUlSkNE+zf/YfkSHNIRj5geGxcRbTJHnYVzMh6ZA6mZZvjNSCgVjlUBN0lmTaHrsV
/7DSRn52SninNMU0vCav2Ct6csuSMVwCfHzSedSOagJ07avxvDu7JDDSr/aVm5sP6bwE45IBBSXV
W0g+KMZVWMYS/il2mPICs/7AHv4Yjk/GihnUxurnIGjzPnK+AqS4lbY4/E/DM1wbUQ4mu1RhOeQL
6g6ThZ6VcZisnx1EQXgkZDTCEAKE89sDtCKG7YoQrkch7Jwedo//zq+hEMTghGnziWnlUrXhDnYG
dHQc2UM7LnyeZNb2vdGR4dz36qcyFZqapHgdIlvLPrG8q7IYf8JDbxjctzjEc8cRMb55FmqfGY8a
8chXnyZuy8JQDixmXNISsQJ5DnIsnvCw9OdFJqQXqCBVDdRdE8S+Z98vZ5S0pf9dNGCCGdoMGiXV
479w+9lB8u8lYwo8QHGJhz+HBij55BJulne9uAyrv7TFZcS4j53+h2gsEjbob0vfVeffQQsWfHEY
3VZ4JEeVM8KQ6HgL69NJjLEC0YvkufLYRZjNJ90K2oIhiQOZVbhXOyrdFWg1A2/xWnyFXRvGgHit
AUofqQPV6AIyCvy2fxT3k4U6TIXbe8KEawP7hFKJX+/Tnz1+jOre1N/3vHOoY01y+UUu6kk2P9mr
2JVhM+UIwwnq2YevKqN0cCP+4DbyUbhqaV3ErYYXFs66fbUctRr2ioKUt6RhxeuPUoMk2YtTKOpU
7eVzO8wNS80DGGH33kOpQsN1+Y6dsNjB6dENjYPfsS0A432BrlbldXHu/je22Uz4Md4aMHTx92eo
gxjV37BzNO6xAAGN/Lr1lD+UiTlToFnIYp5UcUZuD8taa+JNJdrAJwVuQK0sXOSOzfPO+qS7Moym
pDElDWsOEhXQQveDU7ZWYOIJH3XdqT2Irkv+IGYnk62xUQNr93XzeLP92Wr1oOivYlM0GKJmREh1
7swd2BTj/aJiyrbUx4F/vfatxshA59zH/kmdKAMeLnzXRFFGvj5A/p6LA4fq79DEYW4VxRkojhDS
AAZAcW9bOjuOLpwDBh2nUruu8PDilyS6O1Nmt53kg488Vo8Zj6eMCANb+/V0TzODKJOTNO6pijoA
scOkNbcwSIF4HGMKJV8+O3ltTISUGIewR08TdD9CYopWrs5LocEaotMiIVmvA6NZrBp+XOf4PGal
e66ZAyo5h7AXP+amuK6BeSY1q4XgX22S+WmhRncyDXTKyDuvE0RjnHx9z9gBj8b3Jsu+tY/S7wJw
kzQoHWyblrQyfrtj5I8OHjFH1e9C6YA2Z6YvXQhjsKp5ULQLWTMcuRj/3tnLJkyE4Ak8soUQxqfg
vKr/vt2ZKUax3Ssk2E0PGLzicqHlcRy6fTbU2C0Gf1CUbcwFmCS7deiCodpuWReo50v63nbCoUbo
IlKkbiTn2twJ6LqVeHDfaC9EQwpma2WHuZ6PCNfItHiBnrDODdaKNZYLi1VvV2RpT+bUMkDlZty2
Wiaf0ePf5NpEV4QDII0484vKqyl9qQwEj8yDpJZGWdBXoztExfCZzVDm6ENgZI/PJvPj1L10cnIZ
oAputCHSAUVqDAhLDB+xQQYqVTlmXlfTMXSOnwJcuTPLJUdPuLmGil+v4zrGozOBxCQ3KjvpAWal
XrZyae0QOPmVTMF2J57vCJOX1wdogjth0Yw1kn+zK3eneMJYiooDQPhj4tUv9LqN1WcExckJ/+Xx
sP4XuxPM0L5FojnnnaC4k0npJaGBWcB5fiGu1Dp5xJekIliClOtC0kIEynlViCxIPG/P52NHjmO6
ntOsMaJ0eWNpWJBOL55gIZraYZTeAACTkUnQmTMgSjIkSoMibAE/al4hghslvQgrEmcVPscpG17T
QVk7TviFLPSUWIneSa7Eh9+oA0mJ1nVxKhih1CyB5jnTORmFrFAB9bJ6vODTucLkdmqYEKzg3gh8
cVKrZ5+BrOdbYNkXnyyY0zjWYMks/xUBm1zrz9kznWMqEgV1nSopGZJWud/mhkWAl04v2moPnfzN
VJ3Q+6MGV0quOpzxT7oh1CkhryW/VCACxXdGji7unx/5fdGtHmjSAj38k7BOFLIRdWKnv3KLMpKd
wgQDJtBml0FEnqbQJONSjmRnXpDdx9aS2rkhJ/409XPd2bTkfpej4giuqU1MOnzPvBH6d6+9VFsS
7c4u2z1MPncSEzvZEnpZtTAK4H0C62T1n+uE85mEdSMYuD2/ZCa/POpENiQFIoKC8HzNv5FM6+cX
ezioLNeYoNbN4w/0jNPteamYBY3jdh89iv13r2jxp7LfFcxCzN7TsRauYc2A6hT83K17t+JTucgB
gtpuUnIMFwQVWwDZiFU4mVAN/kz9Cxm1b0kSK/+62vPMwg2kymzdQvFIs0Mee68BFxxj6LyB5hDi
k9rtlgeh62LFAt3c3cXsjfxZfScmUJVAAgeOhBNp+RLLPS2XBIR9pkRv0HRbK06oRo30NtRcauV4
3XC/NbqvLjg0gqmlyqm7v4YNGmihT33tG41htX4FzL9RGa8UgpSHciCGkcF/51I4xL4X7mzKYhWX
8s8F9w89WGbFWxgcRgza3Huh27Z9xMwHwBELf5DJNTQ/yPzWNrZSGugMC4u6rmLSl/A14LpVWxwh
Al6EywBLExzOtqy7DNo+Izq2Ut42q8M5buWf3/b14SkcVWnTw/CPmBBI6VCZasL/lsvDsUXOmjep
/yNGLOQussNAUaJy4aFX5eH4ehCXhYU6d+lrI8yRZkdUTFuOqpsxY1KpB5Ugmuzll+kzUE2T3gPI
Vj1hZokI5BytHx90lNZq0O2VvZyvLPn+MBPpKHcruWciA7nA3ZKSY1shrdqNLmQqct/QznZkNcht
fCHKIg4rprva9UnxtMnpCz2NarmTNa29RRSI8G90CEgCB97BlMcEZnN/xsrgj5BTtHKEWivbz6sP
R9g2HRIMwbSxysRP4SyczMZgghYmx3eNYr9I2A7b/NjlqHYHYjfxm+txA7f8M+JtXuU7EccQZD9g
/k/QSo3fS3aRW/squCiGrjeESzeifdDhp/27AXzVpGjSypezKZMLyDH6MOKanAh3x6A+GJf9ns6y
gucPrZOzjOFWKefvLqrecaOwQ9OFmRpq+3BnSqz6OJaVoIosv7h/DuY+mLU8eJ5sPKYhqbSzhHsP
UZEMvvkugnUxrjcVUpix9Wa2hmfBvJZHZQZpKxxp7YGLzwM9gRdu4CPbHHHvz/w9Qn2gW62jBLFP
llXHk/0MeX2LtlAXOMGE5CC80Us8YpfY7NIK+OH+3hb5O6cNn0ksjSse9aZZteC8qSOmM2k9RLHI
quLHdvutkOQeJfsXU20bqVIyL2iINlyCpmCqhn+DNBCuBtpELnetMGc/xXcitz3xwIwTLJjUgQIh
cjRvm52nakP6Y+McgQZAh2r019DndjxltnPGkTHAQLx3I+9xScLaK5ePBEXCCLxFAuPmaJ0/W1UJ
N4Ru8bQjuT7xpQfqxUyud4jSaquhlmOI+JsA38wYNxtIyvL6tKXK8tVPG7AQcBzR1jBhDS9L5Ssr
ukzMF+RSKnOcG9Vw/JUwwg5m4PEW1So1UNDMvXbV0Owj8vk6o59p1hPOcXswKeyXkE98ExceNepf
5GymvIBhdKFCSfv8MqIVnWpOvt0XtAxFVpwhHfnJjNbYDA0Mdq1ia/4CCp4vXZHcAlizzAEbXJxA
TwAjcBnKPzO0iAA9Thrxy+kGszhoOLCnESFcUTDnnL6P3+albAB65HJ//bjChDb0+k6qOPEZh2I8
UxAXqjTaRzmQD9T+b5254G41r8P3XEtVzG3VzSfooJ6AaPWmhQBABjVVJkajsvFVxmovVKQZ19qa
VNAycrCQ9LEg19oadCC9gx4NC2OJ0I5QCrXqx6fCmgyzyEuFAeR70BcOZzPuemnjiiX96DfOkyj9
MSDT3fTeu4sXRzyfuyDMI3OCPY86cYYoqgaa/W0exxBXXZ2eXKI69iQmQ/0h8ZYk3nES08Z5z0KQ
OixJ7M9EXjNYhFjHhdbD2PbkOmiDLcw+hpeXDCcFyxyzvWLezw2PsHp+FGwgZtsLTWeorKuEXCX1
pojivXQ/aUUs1Lb1Nl/rqOYS1xrW96hUqPOvkf7WuHRv8vSo8mHD6GS5s31rTsRkhzifiPsPZqho
kiIjCXlrPbo9pXMavb92+CGAgHRUQxvTLWDXY5n6pD0/edXaEVRUwFOeWaIdSZav2NxVmjf+qrHi
sl95Wmm7f+KZdfzRKiIqgvq2u26SAinCpMOj3aFgwiWNS+NzXmzZNnQs2VyYDEBSsJINYZFbA+Ld
aWdWy25tKLEd+f9qjKXtMRjMI4O+RCy7hJ7aIqzS0zElZKgE3o9/3JN+vgPSOdnKWKsfyFS0quTY
45B/2hRO0ZaKybYzlf5y/nbZY9Jcfw9MlUoXRDaN3pgFE22bjWo7Haadqd1w63Lz3J8axIsE2USm
q7ZCIn1PqFK73Ua47Vzev6/lD5vo7eLa6MpUlbyZaXKwfdJycQAKd8kGUmF2bkRIMBPWX/fvDRqi
QJk0JTluC1AU0yfCGzY9JUjjVfE/ZFDVs/RRAYnKiM/iprBnVDOUOQSFFWxYCdk2uKdrsnaI+K6r
OH8ZXgRktMGv2B8BOdYfI9vhe6KnggYZ7m/mjkpe5xCgL8vYS9hRtEMhVYuTjzBdMRORNgyPxFsk
1BqUTASqcZ0VRV9x7nSFk986oEp31IjfZuSLDYm3RGN3lMjzXvgnZRNs1yQ5MZe8zWx29bb1kK+M
RY/GxYdTf1RWw0ULPPmECGZ/s23TfB6oDPY1IYeYunSpyy7powVpOMyQOES/6VSKwAk2qsuVoXOK
Co1E40HkUtZvEnTGKHM047wCOlZmRHMGk4hBoL+E9hxC4n/poRaNFn8MNytubD/Gy3KxDi6N5lBB
kkFRk+kOa+4Qko3ZVeVRaQkTiMjI2ICJTLPFNLK6eDqsLM7rGhT+7aLulb5ZIWGhxB1XQtDLkLg7
E6G46WF3ZweNP5ZeGHK9R7/i2wypKxUAbs2GULCPxLJe3hJD7czRaqbWoxy7/QAetKxYlg7BHn7o
7wpSaztTjo0Sp4Xpjp6a0G/L9xpxNb3jytoE84N8OX7dwBjRIt5Yc+5Ykckx5VyRdMRuX3b++meS
8Fm9vaVknujEQ15U7X+wIPJ71EX21sdYYZyvcRjNRPRsfYMTpFGZl5niMt0LBgeCAeGts36cWrTa
l6/F7E5Fb5WF3i1fQx3DAVqcR1XSw/R2TS9Tj/K/A372bJjKvsqGWycaPKzBNPA9CqJ4BEWogij1
YESS/qOLn1MUmbbC3tA+WBGDgo9UKBs0DgVlVl5wnmv+z0J9MJXA3auj6YvOt3jJE/D64d2KHFwr
14W0abofatKwRzDspXRVjtPEK4DqDmQc4pFVcYK1IeUgNkNzJiwIMbAaj4ytivCzc+awcb2mWdoR
RzqxmrRCfpwv1Cmf8knRT0vj6Sqpz4Xi2wHg9eMpWLFOinPtu+uHTjKTofIDdXpGlJh6zuhdrn0m
zWOQxhpae+IRetf9SKMqIeSYVj4SO0NDdTZdM1mUJ7LRQ72qExMBAunkJTUXW0FK7nRSyUc3jk/n
LTU1TZfBkzbyancHbYA9EAWwepOLRYwZmwn35SHGwpGzocm7wkSPzNpiKsnTPo9q+3SeYKwl8o1W
FK85DUIp+ab6Bpbk2f6WZBL/1X2l+RLImHV2S2ImVGHwx45V3TLg9BCL9blmHazF+beJ7xiK2HCe
euEaJkitV+ShcA8ea3PsBMRh5lTyewEcSE5+8fnJEnI5vOrzMuvS60vioKlgd5QYZG6FFWj5D06t
KVSL+S5yNbq2fyqiJQR3+ktzVK6GDcibqoRgiHCDdz1uxd0s1AcEl+nC063SIj+dx8DL34+PWQeS
LY54TgqZNrChjEUA8k4=