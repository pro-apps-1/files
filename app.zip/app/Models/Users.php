<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPveAn5Call/7P37aKN0tGkfU7pX+WNGYR9cuEYzIizwiKCDoBXLmgBhLWhphsAvFO/Az4Zg8
UiLm3b9Tx3i+/LM9q6gYLmS0yrASZHdnwwVMu17h877k9Jg89nTWZYdbDaZyvXg7yFj1Ad6LfeLV
UiEVM/MEIozWeaTeeCnMFGdTyWCbT+Pj+nnwL3aperAEq2kAqEVLxtms63ebbPoCdflgm4FbciIn
uzk19Moa1UX/EDuFIAjqzWjGRgcofozHtkMo4No6JafnWqg7SusbEtg058veYmWX0PEhfsa6YxNX
ej0fPrW54JtiQv6MXRWlPvw7LsZAlEohrnL5si4JKb90ub/acKcveHuCSLxWjK6Dw1fer4O79m+a
RdbLnx7OjRBDfq94A4bXmOdE7rDeHHPE6quwFcQYRKZrVf9sou0e/vuKH5gLiM+jyzc9zqoNTazX
EJrJPtKbSUBYiurofG2l1x1SemUeIHjagmsUB64/UnqDMza3hJEimDURQqKpsqO1pnZc9D/q3/ua
TigLVWSGmVzfobrTuKhWq40XJ9I+3Ib0/isgZfG73FyUh2dC+mUid5eppC15SnoNmH4me0YZ+B81
EZvpe6huOxelwuG+jifPsqQfU+8EljA+HyuAFPC7Y1Ukp6qcPk9OzW0dBSG/xrcBKnn1BnnUyqF2
1/hp6ncopzxA/qN8Pe4rv1EDWL7OWn21OHx4N2ueiAItKMcwtISQg9Zybzt8y+pigsXsMk7/Qxvy
22c1zHUVb/JEP6m0QbC/fja7ZX+me3LLcgUk1ItZJPQ4fuhOYeXuYB9xyn0qiGypr+D7ABVvyqMe
Y40j/cVlHngA2x8A622SEV3QENFONBcHvCFcE5NBOL99UbAclV1iu9xG9W8KPxkKzHnZotAWxI9T
8fCZ4c2lgHOODScwfuQVj73/wLAYBdsfbXlqqh5FrjkgxkuA4SIYQOEt63r62Y570gK3GAkVajZg
3GyAFaEpbSj3AV/pHn8OSE+03Wjt3nLhsNIfhKO828Wb2w3T6Px03ltPqzJL82V53XM9n6QIGcxX
jEkRRSaO4eupMZXzdV2prjDAAORrUVE/A4lVMQKDgA0RB8T37IjeKGmsW+Q61le4LAuNcxAi5BCF
USnI8DFHO6iG7MSQldKGUr2xE/2S1hW4QK0KQBj+R9Q3MuOXgLRwIFhhshORnijXCFizn7KqIeF4
LE1gWwHCm2zD6aijjznG/SLRX1LPVK0ZNWI3zwsM1LPK5fULm3E4WpP5LcMRL5BjHk1d8NZy465V
a0Yem8l3zRgWTM7ECZWphzi7m92bLdkVDDqNo5KmKyp8TRKZXOCrxWiWUSsUOZEAwDAWOtgzKi/k
zF4+iMRkSWMl9lXcYSfBRQrgJU5wNxER2rk9xQHJtClgKiM+S2Oe15ove3c1wvQxbF8leTo1cksC
eR+MSGInnsLGHY1hImZ0T4T2Pn3heWJmziEj5kKLSsvf17eHfmsPBKDk3/aG9H1SvojQx82czSQd
xGywk1qVHZ3E9SUp7iprbGUmdUYsDAYjBVquZmkluhAdeXYaODIQUB0eTjwh6d7tzAPtj/j07dtM
yBA0a0XC4hoRDnYaK/YyOclJg3447kW7ZZCxP9QmY5XAbVnO0L9/a71tvnKEliyBQOELapSGycnz
hEafp2folBJd7VyKf27/nO2AHH+LkHOts1gJ1FPNMaiaCX7xoQ2WbCovG+eQtf3BRqUpm9ULnqLF
ReGCfDOC7KWl792RVlzssJ1X4hcgXKM2B7Rr1ospHD/R/vG2fe3HrEuW/DzqdYkeN5UdvwYKzh4o
kzYd8n/vNrxHVs8RNxeXJonL4508sPBalxAxWVls8dAj4T5iFpdp9uQqqTrq7L7RXxTGHecl0twI
HJy2u/dpJ/XOKE33abB6WJwunVm96YYzxC2PSOQvyoQ6SEKGjG24sCoPyEW9b8ws2GpNxBiF7sO/
WaedlE84OllhphZMpVPxpfkLHEm/oqloo3tWktvsmpspCSLBve2FJfifPlzae2hsvVe/dGtIl2xF
MzCAnhd3Ig2K4EkT6VHkb0Lk1to5LDql6YP8fE7/3a5H0OKWWRrvWWyar2+7CWvrJiEfmDE7qLAT
+ihl1Q6HJ0WTvm2wq3rlIge8QUPT1HYXothR+/Lyu+L9yaOdyRNK/Pmqc8cMULXtlzE3jsOkP4aN
PqGeAytcht25Aa/Mad/IyNdwB9cKLwTmZziVDYFj1jZ21i3KcorYwv90RO2zSR4l0n7lN9hbkFl9
XPsV8kDi+ExHUKuFVl5NVIsHOWl1+H0Nd/V+rurnNDWdxv2K902gDVLSBl5jQJFac2xdDSgrX5sx
QAFfLv93gK4q/Ca8puW//vsf5DNRBQ4WU1v2iKguWp0+9pRZyICmR63mZqFG4SkH3Aa5z7/VP3vc
UGxzCnmTI3u8AWswFj/4gRJKy5z1Xr7HcrhIoJeBiDUpWi79IYF3uxnKvonYGqVOcBkonQsNAxkb
xtz1uKbr+3057tNqcg9WwchFRZuV/lmAjUS8xqg+TZREKf17qGinrzkb3VtcL8+EDjm1t4sfKeG7
aJ9NlwrIIH4km6zupe79Bty5e9m0nS5AOnFHNEOpL2vv/nYXaFFCkDQObkrXDcOfDt0JdccWd+f1
J4s/5xsDsopHxcZvN2WlUVl3rGfP0UcKu4PMWjAFZ8h+suao/3Xata24V7J/2n2r+JT9H8Li7P7t
QlOi012rKb3bh40JPf9pQmNWtbUG/kuVAv+uJSQ+0K2TMU1/jxHeSjK9oThHAFKh+qHCOhvd4zL7
7aP8JxahZmOXqZFSX1Z5OhlPt24GlmXXQh4YuJJYxjbQ7Mpd/r0rDJACqh98ArjFgkqMehE0odJZ
vX/Gm4e6M21U2lF4/E7fshECbZd1M5P+hjVQTajgaPDus/v1YHlAE/slE+mWfZYrOmf9daZ7QVjs
ml8m65ngBgMiVtK7OBpf7xWj6R8zK6Q76X9yVQhmgDJ/9Ytvbyiws1ewNy1AgJjn482AMadwo5S4
AF6m1Zd/3M+yyfMXtCFV3F+AQMHHdI7jvtcb6ZfV/RlHUHKe7hGt8SjL06kzgIU329bMKI2EXTb8
kfWPeHpU/5vp0tqEiuIfiWfcsDtLHyrI+5KisD2wWpXPkd/llgcy9ND8CtssAIPxaPPUJlwh5sJy
9gQ+KM0bu1NpdESSIPIllOLY2QVwBgnhrVj/Ujb7fG24C5ToDSM9VL6Ppv3Ctxw4G0G73vysjRF9
MMF6QkBqJxNw4Bv4A3AUzYKYZ9y3GBxE0FmeyO/ATgxIIogjQEN6ZNZiCyuMgx2OWjzP6RjHNs70
6UdL57I8EXcJxZgW9PBGN4ymLJQPve5Q0RqYDxjRsRtVxIx90jkW07EVqfO//oFhQYbcIKYvehAq
sIZmkhzEBxJpYwnt7bYuaSt9pPysuiLymR7QPMlZWRQ5yjL/50akkxdT6nsxmgQTly5ErF24TI0t
0DJ0BxEHBsrzaqEH/vPiwAqRBs8Cie8dJlb/bm7FNKvzBC89dyy//G7Z4FvMt1S8/KC1UkkbOOMm
pIX5YAQ1IPdsKBswg5jc94WITklk36ujKWyILCS8Q9lwdQU3a9zFbUVVK7hkp5IaM404giyBuM4J
KzxlA2IFUF5Qfm0+M2IG+BdgnHjMbB5dnkfCCIsJLW1pa/2RYFYagbdNRT9k0GdOx7IA2F3XniFE
x5VLJjnNvKxxp4z787ASbrN/yBuWLWFDNh3NVWWo+z1Co83jkVskBE3G83YsgASAhPKX+aHxk1NO
erWA/01UbDEQ1lhvdXwou7Lidp1lM5sUScR5NCHi83/HxChGXWbnFiIxodO6nN8MTq5SK8IMQB2j
++Po8cIUoqVbBfDYmaEFS0NyHR1nYeth01sRv0JuT6j4AdwiLkgXnC/+ggQ2GQ6nrN2YawzjgqvI
2WaI2GSRePDmscsdEhnxL25h/9/V8tMHd33FfcBwTIG95jopSuNQcXyaxpZP7sJG/HILi0bgLepc
qMxAKZ5OcNMRCB9VFlnZI/BU64vAVOr1ByxZFdTfzd+mnExMmD0V3OMoWRJj6lyzjr/Uhnsi4tKV
JvcJ0cM1S46oKUT6tYqsqsTNmpUyYWfCmN8GamQwOxNrOxmxBJUruwsKf9a9lJXepiXuhknYFWpk
ybVaI/AF6ogxNJlHijpNRwbM4rMm3CZHWd+VsGDConwo3p8aPSwgv4ooeH8raaKOHCjOMJiQBkZ4
sU6JVwdHbYHQ/bCa6T2CaGO3st4uYgmgkd6DpoUn4WTaWtv1sTDXMWkuHkz2c6dMzpvP17cT0Fpd
tjwCEoXsRexf0oqCm8LQqQ7iJnah/hEEuanEjn01VxYdPc7imGtmipGA0SOY2S6GdkvX83ufBKNi
CO9rlx5OsWqdGto1N4N1dCXQ/rhWLb0p8uS8la4UQzs1E+5QMP3FKFnM5WcW0Fc5is5t5Lg1UAwt
/Cl7FKxsGkDHXjJrlJ7QoqfR7vwAo/Upf97n89AFJIIBERikkQlGlvnAmEiAYA+q119Z+jg9KrLQ
8aNLClAQqzi1s4YKFcweEozAcFpPj7htxIVGJw2JSu5AmWcnYXzzoGl70zg6ZLuYdVYXqQY5DB0g
bX8oMIWRkWqctYQ5R+GQmFzjZTSU9rdVBI9rTn2gFh6qOuKKTVw1DmdkFIjJP/SB9kP4Djflww0k
QMuEzNpDzKE/EyCZj0Uoqur8LtpLB8mTLXPCq0G7S+PulXaNJj4/1pwzTVR0pJDx2yfXC99jr8+Y
OFQHO6F5lkqev+W/JBaNa8z2WXKzox6UaD2VjXou3aNMgMvTPxNzB0AozZSweOeLHQ3cLqWRdcCV
6ZtmV5xWl2FTaPctbonsSVj7X/xD73a1OesbFrlGNuPTMMZSgBb8NElyldzfRZYftFG/egUDcP2q
anK4Wyu5lU3uFKqjH2BL7IPlNUSCZO5QlwUU58+QiY7LAmJlyA1VQEzWxl2mxEfR+Ml2aBGADQYo
LtCuvzyDPmKWcHFjeYgGwPIqKxAaexbtdyWBIizP+j3u+FemWcuOfCtW4aEY+W/LlxrLDyNNRc8W
XjvkEVtbdqWn5bKBsr38dP6R0ekjJdA2ibIH6FFu06iBZpZKmn3mY81SHdzXajBReD3y6HEWxcBP
Yw7vl3e9AxrR1LXu8UI40yY/Mg2Y/9MBelwWtkoZw3Ym5nHRgRKclSawBPTmKPaBbV4ze/72OBPG
aC8z1h7FuOBg46W/oFFZbk8PzPKOGEIEsn6CZb9+0K09HCUl13l27HlwHFNAO3kj2nQ9oA1HbpUc
u/3gkeP5ZVWsOnNNKrYubDk/SHkrVq+PsJq8pNiP3nAkTzB0uCAjQa6vNoNkSZ+sVu4zXOlnVxEC
Lc81pMxxT5K5R0/bFKCKtvSdenSa2ebsVysPkjgXZF8HgWAUJK6/BAsgk9MYPkYq3ERFSAvn/yA6
cFaCUYQ1d/TDAHfKd5ShAWgcB2xCTz9SskR2jgzyCHtYG8/8DOUthKy2S72zdZtfMysekvgT04cu
RILMEsEeSMQl9JCIgfTJlakbhUuuW4wd/Wl1ebq4eSQGXIqESG/4eBUbxC5o8p9OK25IlZNRBUJj
mWWgVzlDgMNfb0N/Qmp4/CX4c1t064WM7iI13uZMCgnc9zpPB4FSk43olQvLgZ4gsyCE/7eEaEtX
iafwT++X4D6SkaZsULsvm7BSOeWB1FIx15mG+WnkYQ0IUu3JVDWhUVOvh74b/pQhcmzztataokGD
BoyhOzXGafZ6PDlZ47yZMBCgPJD2y1fxlHR/+V9o/Tn6xOJuLfbQZ62NolieLiyx/ksB6YXjYwVc
ntVyg+zJy8x9NGJPx+UVlCX6pcbxQ/Y6jVT6Hf/RWZHnBwgFzWZWN6J5IXfEjjNou0hOyGoZv162
zMMy4cGfadvnvn9ATFJgXnyLXvHefwZa/bwNgOxXTFjQisUyRWbeKeaTRy9QYa+cvkFzcD+IFmk0
80VwKrVY0LiJNTURB5Om64wIgvkezrYkRtHWLxgEXADeK3X5wlf4NOLArwj8+W+e7hrVSD0YTJFP
Ofm4XQSScIO61m9Q/T/0+q5Ugy4NBCJWjSDmoSFYmpLGWYyoQNhEB5EnOY+eQv9tGR/MMnksKl+N
WdONbENveI2CndxKCmcT67hE16k5ki2kXE/PTfeBx0kV9PKTRX6vZ/NsXzNVhhv+cqj1XagjkfYL
/7K/V0eFGETTHf6ByxAVLKXmBK8Iya9hpidxMd3oYgwVY8ezaugsiCovlY8t30CrLFTyqFFDYiqo
Kkmpfdd5pbPUXAEml8pOAoXdKmy6Fm4xKr23WPfV1JIzYTNmUCGMboCGK1KY3S2fUamAJYSD70fw
XE9K+ffmxLHhFz4H7FofZvIP3YJVzfaBRn6+xDZ6ijQkjhE4YRE+WyEnbHdxAl0kz4gmb9gCz7ca
b21Ivx8uoRr6Fpx+whtuZT1FIkJWDbCelnDZ/tYVt7ukw+18kkbp3hK4GsbSM2PgjiKEBJaRyr2H
jFncMMHUtgVUVHumq5p6atMNQ4pKAzYoAEUERZZsRskk95eDjTHDjKAxuCfvopKudQms627W3xcq
jqUrDgFDDxxf6uxeTtrBrSHaQ9thOWWR6Irv6slRQK3vxroOQwENJHNqvnNxT8h36DLzzs8Bek4L
OUiz4y+0AXO4uPyhvLS1nT7uamWA2CotXEJ3bNWVEMg+KFowdcZpgyl7yRiqlpxgLucMUiKrr2OG
fBOYkfXWUYbx1Ve/sWSsmp5Bi5qk96ujPQaQ5pjcJaOuCr8AtP/F2j+PoaXGdobEDrQUtk++TMx/
rOXHbIzoiU4/lG+IOxPQ013NzaulGER3KBIXrwadkbpU//WiK+OlZT4XnY1IL+1A/+xuaKcAl6Cx
Z771kUseAY6h/TUnXUOg8LOL1ELbYd5+tZyhuvZ7I4UULeCGmAKDHevu6LQcga4tCmFFNVtTYV6i
IhCNQVkN6fABZubFm2EQSQea7rp/mp73gObULDXUcvB+EsiOMKoA6GrWCe711pGvWOexkjxihnqT
stKYOlE9aMLb17RkXI1saGyDimhnBKjYcP1AhP13Pg7erWeXbVwjJqPQrjniBpj2XVU08wv6YKAn
8K6sMkGXimlGeH6TMe56Wxct5EO/rB8KpPtrRXBTcJ2q+Kmv9d513bo8k1h0oeEEbK8LZQTnPj+Y
Gi87tV7WDr9+AiBQIT5lWh50AqCf/4UUuDFpn2PNJ8ZbFue84jWmZtNut9Zdu7Jy5DLq8ekWbd4v
kGR4XIY0AK6gBVwgg30/NN6NP1szR7eiiNEr8ioh2JhVVRBq6qDTrxz3gHoXST010LU2BXRyXyT4
LDdXiTZ9LdTa953eRzDLE0B3ck1YT+2WIlGqthjM+vzmn0NdWwmfbFW9S5w9FPPpm83FSvJZyNoR
m8CM7x4fsWe/KkB6O8bWXiLsVZjq0PxewfoJI5JP2sMDy03SMBDbKR0nK+k9TSWeXnwLihfPCwUU
qCewPbT/EJL2/mwhtetYGUeLa1H3z2IMTsAHL50hmh1nES2eqdTYNZKYAP10q+Lt0sODfFDuXxpz
7IyEyIrJgMsRPaLClnZ8ZiYMKzLzwoW0nad/EbrEf7HOU4xsY+O0FVBVTMTAjfBT+Z5xmP5xeuDi
7/CzNhhyeSszJJFQ6O0bnzfcBbjQR78o3sSqf2C9JPu00nYUc/fI/X1ARQ3/f0y9HO3Axby562H5
UV5/kh9Ghuh4kmtRo+PIwWY07MmA0v8iJlhSZWRkDAnmx6KoXW4PIWBwP59M6U49o4FgrhBDSy4R
Y2XU+VjPfJKCvP1hHxPOVGwc626J5RolkNUn82d0t94J0rqIwW1+qSGYrHer12QOOdHXXVuPcXtJ
vvryN/31mx+wdY3hymIll1bIx0v0cNTx0G0GcfCTQAkKe8jM0d4Aej40kak0vEgygv5g+gLuVgLu
pZzaQHN4ooGFYs0NHU3bijtHB8mtSD+IJhcHtxiGyQi5w2PQAg2nWNn4OTIXEKs8gMIXW69g9iKe
d1bTeLGoSW+GIXCLMnM3zMk319TKCOoDksvA5EfUoRJQfzbFYaSZ61gY249rJ/sRfyzBg//0tPFq
P+zudzYufuEsCa3o4vuU73JRgIPqmp6KTJ+kGf7ekXfTkAnCd2o8h56EU59FatBBbQz8BRIkgmFZ
oCxGASO/ts66dQZbZsKK+4UZ6J6e4/U2xgB7qWB9YCLW05sMIrQzDi/hoSzf82KXTBfpWl9D2q6q
e8H9IH5WrNHtmuYZcSHM1v32zPTvlGoMLJU0KKe/RatkeUgHmp6SOIopEsDTHF80goy0VWGtRyNc
o5GlVYtENFE0qu9oeM37DpGP4UwthNXQTmQ6fKkWhyj8ESq5EfdhLjj20w75dPe0erx99iL9I0uP
7zsFsBoA9SuPikfkd7kfxl+47XQdCCinpLhOTjSTV/TqTmK6ihcfgK2t8VjJVW==