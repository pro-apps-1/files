<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzcNw3D25T446tbz4CqrlqdVQikN4nauWlk8sQMspzGmZtnmsBOZxf1X81mBS1nXyBFYAGIM
KOwEFSLqbFJ6oxOlYUklW6+05Jvs5zYjVDqHymQKLdvIV1rEyDhET5UE0sOKpIBZjRj+DmlT4QBi
RxAanQOty+/o95nskGCKdQS/PUExBbGnx3xwnbdIB9eC1nOWEJeBvHUJdU3g+zzGJ85tqBilCKHz
8LDEKfsg+6e1yvzIvQj90BwMJdS9TKVd+67LotAWOfiQetpwyoP6lnyxsQIvQ7apx6pG50rUGUKq
zdQVGzEM1bVKP++FUuircaieEcuaZtIVn3gVMjeKjsF+GVggYdopvKdIofGWZirHrButqjIgkgAW
TrptP4LQYjLzlU7TFg9MhZ9MDalseTrTBJ08LKMtdX8WIxB4n3PVTc/v+tT8VdHMbdHHx/sBg+3c
uZNyO6PlAklBdYf9q1rxw8R4zSNGCI7Unzf3tRXpHouQhPlBQwxf0iwHLkQIiv9F2jhRkh6NH4sW
7HqT+OGd0UrWJGCDuCsH8PZGzEw7HC+GwNrd1LlhCIpqZO9LQD7GCIUKJRYoWq0cAvRFKpVtNRrp
dLpwJD3tiQ7avjOzGNPDB9bQyI3wfOxOCvndSwwHz0FbKOvv8K5CW0QA1FSGMWPspiBPjKC4Os+2
7u15pKbQX/QRzlz94PckDKM/dOW4LZIZ2+XO0AkBRYlr4xHR6zlPEaCtPugUZgodbk/m+E0ZWgo0
n7vizO0cXixeDAJMGU9qKWMKhEdq7bHOTvLfhzwLfb6Nc7GgbURRGrUn3VhHpMqTaLmb07J0y5Ip
GL4s4x6azFl8/bpFUQRLBLjhq9OcN+NQYhUbOnm/Wle0d2htLcrEVa1OoKRjQrR2u+rZxhEC7BlY
lFzoUV1dJoW3aQJIH7jPerswQrWcO0EJ3rtzLgnm6z1zhgvSHstW3gB6/Qjtuk2LoucLCXBt6iUJ
Zkg5sSCUM4f3WIaSQriupnerLNQDmJe/am338avIUxJzzb7jIo4lOXe5D434ennresan4UM10fgD
r4NyGkTgkkADJ3RJdrYR/qd6ZK/asn3zqmh+8ssd+fsGNogGBFZZvCMp0GgNiMCcHA20O5sbHcQ5
e5E5Yt+R4s6pHOTAvVd6jgSeIDAU0HDN1cvB1vjZYkSZPHo0nOl3NicNBYio7X6gd167kVnQwNAY
0tWoJO5taPC4wnwONDtiS9vnpxHBDXqRygGehBClA5e4O/twEXYRZTeNsHguu28WA1DrOhKMzbug
gYk8ZA2yFsri9BTN+/sOoPQuu0VvxZqCXkfFR0r1coh4XYr9UWwuPztvjZk9Uni3EsWMaFsV0TMb
5og+tmc+QvwMoja2FNbYltARPXZZq19a5+xrBXeEXuFtIB5VchHoryFAveGc7+MFT9fk/zgBhojs
4XTRnf38YGRcwJsPw2ipbypGlwWl3WFlwemGHJSnG5tfdV7teS4xE6fHwYI21qWIKzye3B+cVVgB
KmQbXWysM7pCxSwStimsB3y+QlLmhyUSbX4b4zOJ8tsAhGbZAzZezI/X6rviZPa5dqEaL409P88c
Pxybfh9zOeUaH2Rpy5LNUNvmrep/zUI1I5vKuSe24unvyHobBy2DA4k8/z4ECrhqgnUU3+REUoio
3ns2Cuea2WYlbeX4mICitmYc9p1j/mHX3ERD8ttjT1cuYS3SV6LU9TGXOqDghJaH4Bb2qYg69cH2
WGPPH6GwzQ/m73MMKQkkoe7PdJlOX30nKCBGD6WsdKVJIYroKbAfG88AmL6jSy3ZGbxEGr80cIUu
llaecoI0yiQb25sL43JJI1dqEqh2EJr1i7Inn7C+Kye9Dmiq32mRi9Sw2D/AOSCaJkPRFagwWeQR
8Nwq7zcP5FRkEYr+Zy9LPf3JxeqA4ZyDNt1eTME2IWK3oGyIk94xpzym1OwSSTTP0f0ejoEAkPiU
EBNlM2phq+6CZK9Ak46kGsNVlHkT3D65GaqTEz5juqTshbW3KTq193y9nVHdPKav2Nb7A8DUfLu8
mQ+yOW3agXoz5sMmW7Y9kMXI22kkZqbnklfgEVpzkCxYRl0fFl54GTG4iFXooAZhRe2nexVePIqK
eQcaI3ltcY+P8bAtRVp/VfrQQlIPDc0P0vdxCcF6M0fEEbYrmNJkmMsqvQN9peHbq9NICRVCuhpA
LrAzZdgtnDpnbgBmSNGhJXCGKhzY6WX3xx4gHyaddUBfpJJSxi1IsAtdquvDolaX/quI+R0FpY0A
RhlDmB7qOgOVHhE5c3vDG2S/hAu8tjT+P42zpPJCMzRYxftOihiTLm5wSoJhSVR0wMZppVTp13h1
P4/BkxeV4eJgpF15aaW7ipwF/5mXzjWj1xlWQd1trB/xUHTXWRSx7BtOxXk4+to4QbnNyIv5CnsU
UzUIP1nRvOyA6jpo+x9Zjfe0ntwNCtNq18kbd8YxdRlI8ggNJ2iqoKGpgiJuLaCQgrl3DzrkH8Tn
BgAAm0YVFHNDMFasJwRhvizVCnpY3MQ/aQFmgXWzkiumnmvp9ba3cKiE/ygAx20rSySDC64trfMm
LIF+1fCMCBTis/Bct/LelqtFFtKN1dbLQYrSUGhS1cC8jt0Z9gVgdngRXyHkGndo6rY6Koyh3774
1NDTFkcHTLl91dj7J4fqpxalf/l6Sc9g5A95FWaX8fEsE+69mn548rbzK7dxmi19CiTLvA5mHBji
WqAKtQgiIafJM2s/0kUGs4QYI8S6M5kJN0yUk4JY+aYDeqWUm86nj7qQWsVPNg6jNm4utmPay5jE
aFEGwplQ0ZZpNgajef+uQetPfwI5wac/TSMsl/VQNBS2DQWvtsBMiCuRVAE2J9MOyv/QegK+ickf
EF2dqF0FBrCVq2Ne9178wmrqZBfpUsqaCAJzS82lC4kEvvIemPrrbJAIAhPV6j4lVgpZ8sEiaFOb
I6fQa7aDJSvDK7UG1hrpyKbCC+UUQNzXcMfcM/yTl6ok82q+XpknWfkfQP/ot/L04Yx6oTIOn/zw
S1sbAGEpQx04lf5qndO+HOJQgvs4XQix+0diJOE35Mq27fADk2NspJZ923MmWoAN9NJKMadc4cZg
LXr7qQdTxWddNgIw8BdBc+ihp10c9wTw+Hj1b7ACTyS5GVIPNFuo839drIEKL6kwMdescv5CpBFA
Kc9lWIMlvc6zSd7nVj9J0/EagXshHcXHXoll7+2B7qpJrqIM40/yxcBnbp1jdUg8H5LL6ywsKMoN
c4NmxNK0QcZUEEssM7hoIBIlEqBlWwfheF7tCcQEYPM3CMNt2iJ4nnowAudZrsxpbPSq7OTBEdbh
Up9BR1V5EQpsYIKvLU6rCaxSlYMSxzV6NwX0mEwPcOfrksJcxJcxmb1RQYo5LFEZ7H2Z4Cm9T+Zt
XPWI1SSc2Ak3C7sxyMS0cRDBwt7N/f+arq9J9raHOdXS/QoO+KPjY2r1USYgacHzQk3JPPIg9zC8
04ijVy7tLxtSbhY0ApzXIyVWzKSp+gjhJPEaumfrn6b+YPAdGJ8S1/Z3YvdAxEBdo458h+7dNtOS
bK4UgHoYF+PnlZ9aoguYVA8VufPekv1ABNDJyqanbGa166bo41Yc+D6Auct/PssrSnD5aNSn3CtK
uphsZqbhucS9uMFQsT44r4Cjf8YBzP/m+FvVq/THarasnclr0IZFiRvrp7uCRqh/cSSwFoaCqH2U
pYX+R1Qo7SFemgC61BG7iq3jMDwykHETSph/ZVXg3OMuPkwhaCzWSa3ksyel/rPmjQRcNYBFOcs5
rX022KSQzD0Y3+jB1kV/Hcl5thrxhDsEpyA/0+wJChNhwN/Eslg4nRD4CLeVJLm+Gi6L6znJL5fZ
MZtlXJ9QdAIYi7I38u+huXGufyUnKLeiAcnpjCy1ctVaCGCFf4hPAUu6NkbmWUksY0hh/flhPUnQ
2e1qW6BpDKD9c0bwMxaAN0dUFlv0Lps+CufrVTm+76gxGeShiWJgDULzmmygSFExfv6cRRV3/Zhv
6z8xLiXL9rNxQPqppxKaNzvcfXncPMSr5tpzKVkyXx1tWRklvW57s1I5uitpAu1/Euglbmi4LI0p
CeypeQajiCNKhL8KLjdLbrePknJRyGU+A8oKwVPmFWhMU7CuzarpPXvovffJMULgjpWPwEEIYkoP
fmV4N2JWhJXUYOKYSCiVmnzNAAoHBcOTBSwD2CiZsm5XqBbpI03QQcy5u+DNmigg4SeajpOfzYxP
bIGT6jCPOf/6Ax3ZZPhljBxWFy/FxBCs8SoiSeC0p5NJiZJ0t+a5iONywsSKZGJb9NMCdaCxII0z
zjYt6cq2GMAPSdaR/OfSMmc17NZGgW2dvwdP5v+eR/VwaImFK0bjS6wjyNZZ8N2dkeDBxhQIxlp0
5y6EP2acL4iFwxGr9mJpD7Ok/pIFWdAU6ctfX+0fVnq/y6ZqBXNJGVc4Th4XN9TJP/+e5mxAHN5t
uC24F/BeM9hIIIDhzNoIfKf46vt6ggK6/RuPZ7xTDD2jNshNof34/jkuyghaUzP/H8MNTzJDi9ie
/BhHJ6Bq85ER5sa79u1kn3BUI820cfLsw+H730B7Czkt67DKMTJzfodFpLKe4wCWTyr3uiC/o1nk
QTFgdDx7JzUNW8LuVPp4QGuY7l2ck55iJNDkc3HqALmrbAqgS59YxuLPBwLvq0kZliCQfNApFjdG
yDINGMdgRam0PkYOLRHoTIsdPJiFWRlRjf6MmCpXcHsPImb71/kRpltl3lokiB+dcnZMSWrmcXdS
hs1Bp3N86FbkoVu/QE4+cHpKV/vtOngYxvYEAQzhuOuEx7UX72fhiLXPEH8bOapGSoGZBHQq2ZUA
ux6vgFpXqlVarpbOAm65PJBfdNH7Fv71mUZ+bPh9GvtuLQ8NVCMROLZ/pOTSaG6yQBMpsmD3/2ja
VDO11gV9GvTKTvlKqTCd49XWrLEDOyPrs6IrHCkyfMT9WA8e2e4ILN6/WMeOhORNn4Q2MRXGRpxa
yPQ2E6iS1cDXpEB5gvJF+Zdbr7/8lJIywW1ISEKs+xORapkQsk/U8ola0TuTkhd/aBS80Np1psrI
OQncEvQfIDUSuadvxdyiXhF3nsEZLOJTi3gvy1YWeZ9BCeb7USmVKt2Lq5Qq0yaNikr8nrB/gtL9
Ijdsg7jVsBsaWwvhMTP1AHH31Nf9Um4eOZ73awBkY+sbdah1DV9geuj6aXemva6z/RzGz79LbQ96
7W57I2UZQt1wzU/JNHzPmPn2kTNhheY7nxe08XY0VIrePor56oilDjbAJCq6J8r319BddgxDGF6y
vWKC6BuIoLSZ7MqMpT0ddRWG7V4HP3YAxqD5RMH5BDx2yHs3owXi33Gmmu4uRhIdMzkyYX7bfGDs
XsnkH+Ha1lOZO95iJHigj94Z7IoahIoBPjAsPL45lJCR3feprYHbhbAE+aBzNcOCCKkOOQeQT12D
jKetfE3NMqk71S3Zl1gx8i5K7NodHyqmTIMyYpBhHUoqWWCtCOELWoqZZFTxyDpRqrwWE5HwI3KI
82+V71unbL4IYJPPYvLLJrZKIVvP4R7h1pLINBSTmpVaYYYl05VD3ZJNrEo6odC5c6IQmU1QGIHn
jphnGw3c3YIWtNIirjGelCfWjuS0A0xjEZ/B10Z0vz6Z/PtoW/+jOp5pMKZWuYarQ0hnLso6KQk+
jgqj709To+CxiAM/PCl5PRRIxSHgsbv9PWTNOQ1BNULoabe94YXoTihCvjxuoN0Yyd1evkWAI8ab
TJl298HbR08kbkVLlQ047N/GDlqk9JR16NH54w8e/P3/hu4k/tr+KxEKTnsRWjbDe5qjPQeGn4UU
mlsBmqq1BWqUQEoVSTWaJoygdrYyyjIS3XSZd1nN1505YL5uO+6hZUb5u00uoPJPtpd91ZI7qPMf
icGgcVTyx70UThN6WJkJu/kSeJ77rBl9pM6d1gUFhWEdUQDwoAk4QzNfRMXtI2FCEsf7OlKDECZQ
gX5I27UcGpIxlg5Fk3Kx6pHSVZiuURhSceT+9jYf9TPgbQnT6OYvy50IKae3M9s/qk5OCn8tNdPF
Of5RbRmn0kLA2CeH4mHCvpwC3iLCBzCzbO3gHCQerKY7NQNmlJGu5/RuXH67tt8IQBSVtdxVb0Lb
jsJlYOjZliVJB4TG3hnOJyzTkqPRRHYD/H3vHEe8XV0ZOfqh+4eJJlyHEitBVEPzivKb/ERNiT7n
9X8RSqKuKZqp7RvMuJexKgbP+6XK90njwwoN28RTEr/iTH5c94iYOtcwFhWIU+z70k7Yk/Y9w5OV
QAFfkvxxYf9nPqyMEZCLmNhIBZ0MKW6YKs39QUf0Tkpb8BDfj1lCD77CyxFhHh3Awr4A7tGWR4Km
WnRl1L7qRSf7B6he8MgkvmGg+dHC76OglaCFSYU4rD3YfJ5xdtWtEt91zWOr9lATGxznVsstAvd8
orRC6/Xuq8gbJVJ4Lhd8SMtyYg6BAI9zBmP/nA99EeBUH1lt3iTdCqlSY8oAbDmVASV3YVSzP4Ec
Tevnx461n6NP8+X2/mxCbtWdU9IX4lPyVF2S21G15yMMCNJAnoODLsnBvyO7+dNoUUFt+mMQmPTM
PHTlWzr1qAxtAfH+NZ+cubbVTymnUVKgVDGsJGsmGuYaZfMODEmvD0nmq71p0sp4zjf2U4PXJGxM
/CMzjc97bksqB7AwWR5fvVn3rueRi+H0HW9l3RNahJXZvWRXx0Q68dihqafcOxA09wh90WdrhQ7h
sgmX0LFMd0zRMTpDFoUJVUZOa9nRUKjjcYN3VyxxDYU+t93hI4zMege59WdbQO2MSsWwYxLA6iTD
iRDwvuCDuV3Psup+Yr9lcx+6yKk/Ka+kof3Y1nDNXSyQgf5T7wObIHqU1qNfBza5vd5SJZFOyOVG
IPaRP8/WGPd2L9LNany7dUa+Cdt01XmA0sfRMgyBzNRHqUP+taDy1w1tAe3uCzwNR18+w+Ib3aMH
m8W/2aZFJMENpDfUdZiXVTsOBbKKi0/EfHYrLiIlYozR+cqU6eN/oraMu4xSe24I2Sm8Iv522F3c
nfl62vVXG/6nKnw59aiwIrdJYB3px9N+qhQn2u5mAKaueAfFHeRkrmCtHgBFmIvRloZtl4PsPmyx
uBwzw2fFrsKmMYj8avFXVT/H3qcFV38qiU9/WU14BmnjDwE5SCNRWKyXNMSPRo4J1PbisgR8GkaK
giptQBoT1woWWYpRceBFauqKw59m5UJQbq87p1VnHqaTdt5JldFadj/sQvsAIG5FU3xVKWLfDUhS
kqVNyY3t5yV8zKCUZKeIzg4s2MNycNDLukjySwNxWJgIs7CSgIPIhS9orAfhLMb+kyhsJ9vkqnh8
4oRJZxWcRFXhQuEr/T7EmiEbsMl57EXtWOny7Czj3LLhVvphOaakOpcgEriLBwoZ8bCqV5xOLhVo
KTdDrtQBYe7w/oIHMeFRFyd0ozGvNLjNQ8DMEdVutTsMbXPXMSbO4vIJk/gISJ2FSMG4WEOj41H9
JtiA6CJZ8M0J2LwiwluaQKe1vqVdL1QLYMyQE1Xbe2j7B5I97HyAG8JgJNTAUWrVaBkN0Ruf/pLq
1R/hJc3Iwv4CqBFMQhpXdAG3v3PPKkQ0xCNJzBUNMj7KhmEbFqZW2RjSwOSO3jrwvu7LgXSq6Ofw
2oS9Vpur7FdwdxIJOSk1WuxWD+kYbDTN+/5vsoxKmz+v1efv8UVcqgTNEcQnWoewmYDOyTkpqK/s
h4wOznt0zqTLq9ck/8OhTNeWxSTOdXJIy5RSR8d+gAiY1YMqY51qiv8tQCukDiZY8Aav5QixQ8bh
g8WrTjKXcNV9P+/85NaHR2Fdgm1cXhxqRtlzzjC/v/6H1arTZK3ghDrAvbGKjphd/Kd2m+XbUfkX
G2p8z9A9educ/cG4xtf1Vwn++LK10pl5/HZ/pEQtNJsnDBQjayvYJXf1OdBct9sNDB9a/OOesNct
Ge84CReLN1+9eEOs6+4iFPpnBqj6z7IJLx3xh8YriNLR7MU++ymM+gdbjzYQnIZk4nrKrkYokh/I
5ylX5Q9rr8I9I7tKCq1Tw+RgimDbnttuXKhItVvevQZ0GLPpyxjGcnzPZ/eVu6qGhOnslfNlU1sY
QGdkgMv30yaU5BOFGZzmkdCXcCIzYVkJiCWWEf/mSrY6aTSxZR2tlAmCmn/C0bs9cyGMc6kFEJO1
dmR0gkWmMlpSugjKfsGteuM+qmE+gsl1O3cO1uZY/o8S0uh7OmOIXqmGNuzLm3RcR8fy+63mJqDW
gDRR88DKBCZ7ExRPOAjze5lnnBKzvfEP4z9oDixKZvwmTv0kA+lDSM758HhI4psVfh92ETKmivsc
/sGngDrt2UH7iQB9AJy=