<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmAxaHuqIMfHmLK4FNPs/N5X+zWi9E3v0kSRDWIUCVmS3Xea4LZXvB6Pw3+Io7EGV02A62ik
tK9NfNBvO6cla7XiFu3imVzW+rD+zrSblqjbaCM6xLV2kX0vknVP5CKgUKCq8GlH/A/KYybyYoG8
lTKeF/c4/qmsR5NZ1svB0FWpogsiKSTCXIBNfIoNUZscPtTaDOnCjw4guBl6HS/nTXZUqtVp4+ah
UivfYTz4A14Ja4qq2rDrPZyl/awxAe0zo5ImuC7BGv2yD9MuVnh1EjhBxNnaxFTd/aP6cWGpbMOY
EegsVRjX//9Xx+/CA6qUbCqi+5a9Jo1iSbutemUs/zhxpadDxizBioCtlIrRgYPr+Eo42FzLgfrd
cYrgj4eH1fg57J6srF2xd4xUitzWX9V7vQKVpiSv710rCb+5DHEe2TOQS/+H8KP+cilW5D7x29ze
seYLd3WHXnecJYW6PMHT9Cj97DeNur6XvoYfM4vJmXT8fl3Hb8I1lzkkcrj4hIIDYEtDQC+dEwf+
jbRmYwP5UUu3xSTuw+5xVReO62BmZYt6TSMvTjHRH28DXlUFg+A9mOZpS/NjxrJSxCd9IT0Jek5P
MwoFcqRFvrz1iBXVxBs33cXKVX29M86cG+qhQ3CNBhO/itp/JTWRHwZBjjRJlQz+kUKTHR25shqG
8wCmMD/di7IZJegTwX0W99CBmo03J7ISzv8pBuwbCoCp61f14bKpn8zRV5fpIsDY9JfvzLmc0q4K
LTyODI63+gsuO83m2WHuO0XDGeiQNAZ4MIBgpegzlx7IR+5c+wBR41nHXniKR4jHGTvrgsWZYuj9
8z8YfnjiR+p/I7DZWpO+DgWRCiXCRR/KPbnjTeXWvfMTbeH6dEyzNjcGv3XJrD3VGrt52UfOn1uq
xfvGA3a0/1/8//VUZIEZ0cgRMIY+1QraSdXzc8L4gn0OacdYjzN8dnTQEkkDB9OB2d8fO8lB5qQC
182rrq4dFKeRD9toq8S4KRIvD2O4slrSRF/zSApa8ee+QPI6gkl9vIatwt1uWJZGSp3muoElfqMv
Cf2YXqobh1j7orTMjxkDqE/KDEV+JluEBvtRE6nHp8ogJi3NwtyMD3euoxhESUJtDFuPMTK4ytee
99to3oA5rO/lai+uTBro1XeOr11PNR86LLEcQMV79K/qugTve2nQQe81M8Qa9FikGdT8WMc5+bVf
ss4DHk+otLSN/kMKVIyhztfBaXFlyZAOfHb7s3/9kwIYhBdASWdcEbo363T4mFGiKa18ECce7XyH
eh8fc8pl26hiumQVaqYXv0OtjvixQyofWz1vnMMBesAQBr12EMvTvGC3/nlOkhTJcV+5djs1xuwZ
oipqcNwn8vsH5TKBJwLMKEGrJfDDwI1WfYKm5CRVB5BaDEE2IFQt9ieIvF50Fc7AttaoIicm4jIx
kZ3Qj/1LCPb3zPxYYBab4GqEGsyNosO6Ecot/erdpLxOtPXsww9OukIfwfYAgWKagCWUpjUerbKJ
GBNZnRaIFlJoCVrc/4nzArb0UZqjXgDTufGS7GJzR6zKdunSrUsv0EjJ7J+ZI4UDx9oDZUu0KqUS
f1fZFauHEMKaXlkCtfje987jqT9w7GeKHG15rNInoayjr3qdqd4gye2qg4kmMAMgQ/XOFzf00yH0
ntPeunEdB0kcjHMSwdp/NXZLyQyLFXuM3wMikkM1adrHuOEmjfYgXUZcXjjvo7xQe1BElbXF0FDL
n8HsWiyLLryu7VExLZGZuTZvffrxTwQ+SoGEX9eCtcG5jqhZIK5OCBowrAk/6lpjMbigSrLTEeCz
QlHFllyVdk4bdX8/iutpDJUKYY1+wFlJ9YRxmW4xv8OorR0eUMzh09cRdZje6oBxBHOeeROgqgwt
v1BGOy6WOpsCqeTfJosQSIOg+PqOn3k7b2k452jjT4x5s/x66ErTUB70zWj7+1JTyKEMYs27aQPA
zPWZw2D2leC1HYsB7eS8mp/kiiz0vl/M2VyghQfFx+ImX/7rWwoQoZcvSrOmyLOrMPJa/3xNqpBn
qp9pScvvquBwHuxBdAhXLD49YqJiZlUlGYJtsTQ4hJgzAHfRVKYe5OTLZWqlHZEbu37DFgW6c5re
7Gjlj9n9Zr5UGDxRffH25PEs4dH66GURwViLFwdksLQdOEXfKgdJGDIGN74r8P0T83dBAUxmwJqZ
RSBlYKRbzeCxGGVUOPbYA57YThuKqyLPYryV7ttTJdcJNQSWMmHo1HmQigXQAfWXLCvSc8fIL/J2
vc2s3N/OE2e3REKG/QgzuPK0HwYS899yNZFTAbdvd3QDRuf9IHp1NG+0WzfgpwbBCRWE2g6eyKMg
qERCL05iJwVQy/FLwij72U2zuLuRpAxQYWvJrTPNwxI86JRy8a8JFWD49jrCGwXaJAXmvZaSRNid
Ovelsz2UgkE8tveY1bHgJiASrd1wXkT2WhC9Sd50kZTK1jeV1LW0HOFHRa1SCVOhvG48lN7VuAlI
XcUrWPWZxzsH2LEVpKKSmuTcbxvW+OVPPh3N/XHKFxo5hyU/mkrHkg7cKaP7DXTDjqL8klXWjOTV
8ttiYOeLNolcyOGcaAbxGWt/83SoxQlbMOZyL9sW81SePbw7TDRbkpg3zVmuPHm5BKampAut2vjJ
Ep8SNMDtV+nV0Bo8ksSjJUijH6jsf893RLH1DtFkfwwceX0Azu3oFtHGbLMs0tfPQZBHVbB/JJT5
onjH7ZbupbYjXAwjB3NPrMhGEL73lxggwtUX+fffHIGIJBYdkmD3vL8cfU1Tg0zoXxQlrut/b9/P
4coaaTv4oxfCKSPZub9LzcI03X44ey6MjfkUv+TpXH4LssaY5cZ/qcbMxMItjmj4X0Vxnrw+jsnN
OtJbi4/J2kLOCtP16jjTPmQooSrz0nCCNVmhOFLt4R/E4hQJUQKot/L7hWbHEcOca2t4XVxadNHy
hMLOGUvei7yWiUZ971bcxT11/1PfP5qXMYA8jkcZ7pHb/6HxeNm6IiXiICHUsFg4iZYZy0O91Fwo
944dMYWKPJdcFucSI4iK3gq+CpNIkp4F9FygyXUjYKRLeIPnbZuRpslQ2KT31YH+tgLAJqB5myoz
m6wSx66PMUCL3rTmYE3WJIHedoKsIAHc1u+JAt4sm9mh0pXvnajPIljeARZfreu5dZ+Z+h0RgPlI
b8BRjBLaYNB6NSyOQPNWLdlxCm68DQ71gWg0ReCu7JubBl3CIQEAxQwhnmaDDbYbw4acftYIOwN2
cG4Weg6ibxS+0fCRZ7ewEY1ZeifCJC5VO9EwA+VEo9eJRQ4BRJK5xMJbYxkfbL8SCSlW46wTAnwX
3QVgSxpqjbHu8sYd4cYYPnauGpZqd7u7NTlv8AEk8GNP16/Nn097Y5gwAIMYBkRGtNsQ/Gux/t1p
+R6U/9gBY5AG56FvBXFBS06yG4z2VwIQHsA6pHeUpaf4pp3LlIV4/vUb+0XHReLTOZVmKwW2bI6l
FLxt+YQr/NkUMCIqU3S0gowE9BZnmDpKQMr4cjqQlOAk1mpGLZ62BzJ4x5ZG5Z1oohZ2NvYSLYcm
0NBWjDNMYeEXuYwfBdy/AzmdD5ztzpF5pPbLByiF7be8yRMx1igSrWdQstNF4iparn8uAruaB1oy
7aHDFzQQiykzizwQ2y6iq9b/Z1A/WKHkynOtyk6v3SRRk54wx7Y6Zxtt/CjStirVAIzq4Rc1I/uu
AYfYdX3HnsLs1ofhr8CwKc5yIXOD4i2fQpt/Cl5IHKYsfNopXA2BHcCHhk1ErgLxPSA3zVhm/8hb
pVXfE2i3j1rMYFUz9Jc6U3+nCqAP+y9ulc3KKd1m7L5+thAgkTVl4Jx3yd47jOwXRqTRMB+K6MRg
L3Tt6UAXR08LubvtArC453SvOywYRXLwNbHRL+EGRQxPqLWkKlt2RNL06TGtnb0t6lOgliuacj5k
Dze/5Ycm/2mi/SRv/wFzLM1aKon0FKK26kzQPoKS0pBDBbwcmeDo+S27kmuRQXFBUv7T6WouRRVf
AX5nHVGv2yRX19efHFtYIXAt4F/TgnZhM827CQTQLEzVWQPR+QJEmcjiDh3/M3z+8HmYiPBjDIpV
Qm0+DeBGVSsTv2wX9z11rQKw/50PAH5//8he1oHIn/l9NmkYSpIg1GVvPvNg3cNcWfg9amZVluR8
GCCUB4+HClhOs/3puROY4ccxQ1jD9f2y2rsPT/0gRtb26hZNAqdNPAM0jS0/d1RPjzPIrt6fOqet
3oeV1Yh4ZGS7NSXlAAhipQzOJDyumol2bTvpFRueSmoCxOwlL6oejgJucoTHhePT6sMc3APDqwWw
ymelntsFcr75MVQNNsVK/Nj1bjyGaelnhDQ0LUXlnUyS2GV1s6uO5Cqj8ggmhda/3dwPCipKhpdM
mq1s/2Y3mJMlL1RJilnGrDHFUKVbKYZKH3F7MDQ/B71dYLhcQEirZUrAQRbOcOz/3xqWRSCVJKPH
cip/t6EBP3Ku+WW5xtDqAD768wBUPqu3snBXNYCoFIQIHOeVewZ/clYHCov1lygPMNdtI2FLabzq
IlcmG43wcYLNw0RzLAinK+3on6JoPseXINPhVvpQAGZ4bCDXS8Q6jdPDuo+VTacyELydMwoZi+Kt
Xu4nTLfpaTHDRshjbcg49gGMz3c5DDKfh6TAxxjnEvvoKR/6JKzeRSExMks+ovUCO3B44cNDA2Aa
k0ElEe1C50toFPjyXvPTENaQCXfNSqwCUsOOjizPYI0Ji7DUqRnCWJ17Umhcl3zOAb/QyH1P2/YD
4JeCObgwhmkzIRBOQoniRXvMn8SBWVVUPIaMbASYS020OljRQ6YBh+GvgBn7rl/L+NUxA6Cj04zZ
UOCKZ9rmq00QgC51TJxGpANP/OOKI+TzHcbpxHo5xk98zuoc4/UgbWM9hg8Q7GDKOj98DOikih3u
gZK5p4iDUCSifuN3x/+U1DRvK8NxPrIh9Xp7syATL9VHAIWJeYb3kuxH6BqWwe1GW1m6MvMOEc1S
IsISxcf2zpR1f3NGsShuaAaltLlBmg28zX5kYpG0GKGrbYDuhbaXmT5njTyxWoRQpAgHfbGaQOyU
D3SrwXd8Um9NzFNu6vkuZab4H1ZLQdJj7PeqQmBHom9JCaVa4kb18s+IdNTg3BUYv33YJglOt/pt
mqewGPFSU1aekVN6USot/r4dbkxF26MR6PxYdNZkdPaU9bO2PD9iRq1iu1zHSwhbrNcR6ksZtqBH
5mHUjWYHppCGIcZwc2O2MyN82oP4FMOJJrh0faJ5W0MZoxsp5EQ3hdoFTBhE3BTp2SN0SIGvK93Q
jXY4O57mr4GjE0VhxNjcbqunuf5xcKhR5jUUBMYmzoCv1BEe8BIjbPFRkgX2wyB8qIb+rX+qHVIh
iIeE521z1ZVXftkDsr0klRPiATtpXW+Fv8GWFzoJkeTLMqK2reTneJl2STaRAZs3/DM5xavcC5hh
hmqFhyjA4TsaiB5nl5Wb/mfjhWxFvEe7nWW4B7+l3oViCG3k0up4hu2X0WmsmNAhDo6zguf44+yd
eyaHqWnaASDca4HlZ1zseg8u41d+vg2o9tmnvMo50HUoiry8gO/FyWoGQncsERrlJ9CT23jc8qIX
jW3TljL6GKzc4f+5yEQP9cn8/9/IhVJkPyHIijfbESG1EipHw+Til/p9qETleFjY6Z4lb3rBuQUq
u7hcjCO4+AiX18b409Tuq+Un8cso0or86wEntORFcehJYbBaEYiPnY64sJGbYsfCKPCB9K/4Q+7a
TCgPXVIJie0RHooCC7qJHjhvmgi7g/UARTah6AA5mH1/SIYBQpJ9cxyox6l/TWgIyc3wf2qMYKyO
fo6zaFa3WrGNxQM9XdCZCYjxA1PoevSosRD56ecv7dgV8RnOdcnlcow7p+9jQfJY0i0KggqmRbIw
dfKIZ+w5e753VAiVASZBlgHFhbC5D8S+xk+H+2eqgNlcpuwrBAREAg/gHVW+nC24xhtMxBmVvj0w
Cu6+VMnJbFN/tESfX8O5HEf2TTes6P311pzaw79+NXMNoZE1dhnfhmfYOPCadhhTgbi/gG4Zlrvt
8nvpibQGZbm42rkq2CQYbrLMxnSP/6IhOSqdXpcD10kJII7Bvu7e4tYcWITd73kHJu9M/FEMamP/
yd1rN3b3/U21lfcnr6AlRw6VYyYbiwAKDOVw+KhUoM3GRYc9i5Y6WxG+NFVFiHKFXuqFWrmQYdiN
gt1k+rZyBLd3f67TduwvRSgkX4vuh9SQrg0Gw8SxmuWdp0y7r8l65bqbNAGYygA8Oq5PmpSCePFA
EEgmLBwJ3NHXcQLztZblwNhbuLar8nzOiudre9e9eg6JmTKQP0dQhNR2T/tOPoqxxyAFFWgcVqE9
XUBzaB1wbOziCXyP9/Mg3JgrM+HiWebRGUsEB+y2eN0jhxMkK9+FbgrjalXuFQWFVsp6tO7a5B6X
pmU5STqwTZseQoPoXGL+GHewKN7GcWPNnNlnlCW3rscD78Gdf174rbnjbxfpYpNyfHiq8FEEXgKS
kdcHfF/VG5R62Zk5ZzZvRuDFu0C1l1BSFmeYb6DsJNeg9PEOZX47wlMYFyiTrWhBWC13X5SQKQnr
nWqQwsY4dntpS3YEI6DG85zNmU04lczUlw6bTW0pX/DclcexyhlQjW0K3vmeI64T4hyAben2LzbN
TY1UlZsjSqjP45dC+Q1rDiZ0YhQCGdQhDw68q7rmcgR2C5rPTHAc561UEa8NDaPrCzevDZ3BTTQz
23e5W4/zGVhoGUsC2Iqlr+FvAsgPvRkTkcVOUuAUHZZd1qyf6M5Dx7dgCjhD+Y0JhpXreMnui93Q
HnyCNsUBkaJfAgqDHUmXrUj1EesgjfFFioRc+O2gb63/SaYHNU02hjh3bhxdEhNe1Jr+iqjxDFus
LMQNDGA4SThbIuOTbf2SeQKwrwO//DErBvgS29nGuSPkVWhH1SpiGof8BCLtFmctRlEHUUtt2qZA
9NO0HOaCstECd2rdjXkVQp9bdbEvoN/3xWL+rZbRPXlJdQ/CcU6jcwm5VLB73WJscyZ2HSfHSl/q
SXQHPAcnMbbEiQIzNRy7RT/vfI6cC19E/LE77WpRYtnTAzwaRAM4sScDhYmDNW5KH0EOiUdprpBj
3IaUm0yuwQGZWAVNsmKMaaasoSeWYwCefm2fgXHzQwSWMC2AmkOoORKdbbXJTVe6Th0g/NE291Dj
Gw2C3/yO88gD4qlqViO/hkEZbYJ01lbYCeXChkIFZxYnCV8PrIXslktG6ZciGAMKPvvruxylFq9C
VYmwt74AG8RFixFpxjmvFWlheqJBOj6JJKvOgZWh15KaCLGn1dUYhL4h+1uOHFFsS/0QMb1jjC+R
mYr5yL0OaOl4r7cmWyNereVKzIHpBSTcEzLFWu9z172XJRRs6tHLqZa0awuI7KqL6HECYD9Dr5Ap
jV/jvV+aW5zALcW5GTPQOY8DQ3bJQ5vFIEkJNGygV5izPk6Ja/xE/BJwpxb+vPHHKGQE1LtCE47f
WS74DXO3EkN7doqMXex5ZaDt52/S+/wk3YuggL+KpTqa5UPqkRNpkeO1V+jYU+c9alr+31XVeuJB
8EdiO1G9zYTKXmbNwn4/6vsxE4FV+HLnMshc72oXC2SQ69EIoiTtEhYU/efUG7RzINgd5VF7m4Q+
IZPTEFhpas62mw3AoC8zHDXlIzC1z38KpC4ArSL5uphj+kCov/5IK6COlXM1tDtWRsDo5YMOV+Qn
fD4fkPHuKYQbeCwT/Ip/4XrjDJeULysBVif0bhWbz8BECaNlPFgS5EICoqPO3yua0uudCo14v0I2
xPQqZPIENMMvV8IiIz4rprT+ouNZRelU/icC/ePEYTzZxJIkcIS8cwM0wjjEEYOEavqW/sIHbA28
8H1ZMLypapK5kzq9YyELd1eDrRB1ORsJNkNvxJlynveHBUlwn/i4X5mR6afRqfKLBkUKLcQJh2ol
7hm9HOEcSUZVPs1JJCxSHMnHmAuIwbyPWGovJseWQ14JinhJbBlYFnQYHcB5hDnymLcPtakNSCD0
AsZURnvPLCMCN5miGBNwN84smGJzYhY2h1C7bND/n9KrK8Ap9uXSKbLJsq8ZenBkCkl1jMom5ujL
esS1StNypE1VWNFLXdkXN0/EQj6JYBPDEduL6h29xL2hc6brszP3lGkQNCxCzQAn/s3SyzQq8op+
cUwhyLRYKo09OV67gzoe9nnmKggJWfaPmep4k4ficAS2VZkBQFgpxPkmT52JKKbbIwShBDhxs/Hd
ZzYEBKtF/DKtfQXZPqRQmkXp8qY+QNg+IbDXJXGx/+k1MZ3nroI3KgNirZWG5Ip+iGDMn7YBUXY2
bb0siUSAK5twlxQUfRau