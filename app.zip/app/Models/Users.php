<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+0gvvDHtjkaBCHoiAhtd+D7Qs9gP876gkQPduzwWU/dSr+9PZ5k5TYsS4dagxvD407AlTRZ
YiPT0PS4/DpWK/+a87WdI1E8Jw4fK8xreaSmLraYSgOAvkcoAoJUcR43Iq6h6pv6NK/2HvijdEv/
4sgAHRmGevUGWMo4h7e57yn8z9pbkLgnDyGfZCNZPm6VH14eAUFAwP9Ta7FSf6hIOu4G3itNNYQN
5PIHbOSwN3Eth31tf1wLB5/PmsP2tbGJP+Kag48UlJdPArgD9XhjxmGtTds4PrFiOJ6rDykpFJGF
81szJKeKaHvofMnXiuTXB4sI4jaUwrvj7mE2Bsjd7FiWTf9XxO/I2LmjnTmQVT3UpClMLdWagtI0
HHotdV5VG2eqcrHYPw7NlJUpgq6BYurTGBJJoq0XmEEVRvKlLiqUKFWPEeIvUDKngYUzzn/XH5YU
uBcwnZSrhhGUmMxwJFo7CjxsiLuenwA6Ss+anGSZlCnmRsmFsqzwVAXSKvSWHM6DXX32jeYnRxhH
7mIIayUeN2fQDIQhZL4J/UkJtXILPzbu8RdHMSoS1RMLCZqRm8cstUVWmPX1TiddT4eAQL5ZYWxh
RtrlbnWh9n5rUaC7JvbL1PduBUm6p56UnJCUeIZqlZU2xDyK/+8Jr46CLrWe06HqMq/GbgxanXMK
sQIaA0TPoLvPjxufuiF8nKs5uWhBlvTnybFKQcJIXau2S5k2IdMEezIQgZ3A88nol0/7voz8fXb5
0vakFdQJtACpz9KKyXH8/GqhzmvM6hwq6ZW5illZ852f15BrH28Oqz39XsCnI7e2ONaBS1GzU7n4
CFSipEmtKqGjQcsXveRu2LRuAjMMbkFyZ/54W8W1Xp0BtQJOLjg5nyHd1YvaJqw85v1lkFo6DgQL
Cd4k76XAMgi+fMwdioUoXtbeoVYmlbnVj4utw+6+SRWUXKLvOP71MvVU4AHvYSDrLhJFtKKYtZF2
ZzsaFTibTKsDyHiNux52ZUX5MUTzD76fbyzC+h2YWL7lNhZ4lKpN9+PfkCN18eDqu90skaMcoKY3
3/YBUPivE43xeY6g7inwGBra8rZP3hI+IVdMdVUiFzzgboswkKrrvn/DQq97o0pSzCqcWsbRe3Xc
yI64FGIljFUB1LYKd5PWOy8aBP6sjVs3uJuLxjYjB1hnAUINZSG+STqQG34Qs7eqO7qBJXFqxdwf
xMjtAwntwrR3k0td0vWEV1VMvMewHHPoGNapAwBlQfRh5DM8kuKnHaZp0co7JRIozMeYbm8vVvR0
EgxLxpuPKEr2NI5wjZ0kRiIz0o1Icz2tZ+z1yvGwJeXOg0IADR1BLV+Kd2D8SmuvH75Df55Hdmc1
WlT5Qt5B4pfGZe5yFVcAnQWm9wAoLMLuHgJUyd8gYXX28C9p3ZuJLmbjdjcwSAr10hrQJ8xijYeS
6PXSpZ0QxJDQ0Q2kvvK0UjaFFmcnpPzaAUy9hBb/iMdcqD9cf1pcFbaqGF/4+nCuVfAefCXhV5nd
MJaLK0KU7Y03RwobCoaAGQNVEzSvWgQJ/26ekW569EhL+IvGt7yC7DAOgHgyYUFto2FDGvcDVElw
Znms9dZvbW9GUgoeNRiSZjGMjsWv2OXja4wQlAKs0GOo+iFtn4O05iq9wNr3Cf3XpyY1T1XiKEPS
vTXBrnpbj6lllOCQoWQEqSR9OqvJd9P+y0ft18WHMU3mjxaAeCuFmeb1Lweobe3zTB0f6TphbymR
kFsqC4Fred754VJ8QSU5EFRYR+j2FG8kfZdZfmwwJxPd1BrXP0g6D3UUbYjfH6AHuRtCpQXlePc/
luotJp1kb7df6+y0Ue5qFyUxCHPQ7tRai1ysC9QtfVYwoCqnCzF0YFON+zgPAbnou43vRT8f9gB9
0Kn67oq5szPUBgKjyCd2Yjvr8r3POgm5eNTeRenDKN7F3wFZ9S9eTGSGbA+QimOq/GotIZLDUaak
U7rukr0MFYFn2XQxanYD3xfNCdAXsfJsSFSAsHu+rKSkR/ZeA+M7qJism7l/5bxmeV8M/LNq0NiF
XzFiP36OVdCjp98pFHrjRCvPtZx5blk72A3ulmpU13liWXGLR5yxI8+RXJ5aAwhU2lWIU6Zm5a2M
5vu/HEL0qWhQ1YYheCRGmNGuxX92rg66FfUdvkF62ez6dmo6IAhEq1nW1uo6pJVpRW/Lij11cO+L
Ra5/ps/dcNN+NyONS4+4StV3y34neXiL9Fjui4S2+m//w6txQwAvMu15tiTjeQb4dh3HGkJeObOW
oVhyN6aYOd4AAKafPI6L+zwsyZYKO+9kBgTZ9tf+R5v+WbiklEFdlay/+H5ySqlQxlXXCQz0Q8Fr
92NPjR8eqWHwA73e4scuDnbgbQZh4Wqv4Cdl1KsEP4KC0Gw8CvJK9hqNbxvlvJUmH+FmpHQ41XyW
HLz00gAphkxEXXPbYmyZ6MpnYUwU3XhqNh0Ya4lP+EnGH/klgarDQF7AESyYUzgI+2xQ8p3LB2m/
VuIEW5QD7r+MJ1UTR+qSr2XefLT6lEBNi7j6f87Ns0DCuixgyLs685gcWD0JPJTgWytlrv/8MhRf
I2VNd7LFOH0EN9Vt5la1EmqETuNLzK0k2+pToEwILgExqQqdkupeb8U5KmcAVlWnOew+Ixw8drJh
xThGJwhop7epWXOL9ZlEPvfohV2RLBGQVFb0NbYE7HHOyWHuhg/BXwiVUHp6PvLO/xV4Wb3q5h49
eEG0ljLiN7aX+PuZzkjd4lh25EkJGE012XvZ6OuTWdAaIITU/nclMw6oPmNHHnbs/1OYON9KE+Hp
n60V0ZwEzjs6RN/HRgZOUNCAryDcXIYpA5dBFrJVHdiDXU9Z4wXSvLUzQUIzzHZpPtveyprUUa5p
CiNMcViVqoUT2Oh15TXTC/+fFp5skbnncITn7xa4+p3acmjserhuE5WP6rL6yUIs6BsjFQK5BaPB
SpfA8ZMR2/mdGStghp+6DtpJaJbtDyrkmqtcoR6qGXqXcyipxSpkF+Aa6uQZCxDpQ+99of3aabho
Tv/BiFBX0pyDoPNLVjbCZKOe9ZN/L2jttatLlF1eczAw9VLGceEeEDHcSuV9H3KwjsUqM44smYCo
eGZPfAkfGI+gvrpxCYtel1sekKpUsYRCjIbF3uGu2WBV3hs7C3/X9ZWeV1LyxXSZBE77p6Dgxgza
R7gW9as+Gc5iakN+eC6Nckk8PCPwL8bF5aGVMERPGZUErfaZYhHIHZBQZTCEOSvowKNvfHuKVE2c
akDPtqILt/T3oVqWPglLXxWs0+jRjHhaZpJ07cZZR3PbJQ4IXf0ICgBfNCQlC0PXf8KsMl6vB99X
BVlkUVp7BFqCKHKOxhWg8oeE2XMTyhIk/TjOsJO0Pk2Ow3Z/go3tEmSIv7DeJ0aJBlzvwNdIsIP3
9TTJetkJhqHWUwpbtpedK02OExnXGuG4yotdbprbyv87QjcObWm+dBIdnNaeIbQKQdRsGs7E1IlA
YRqbFT1JN531HATb8ViSst6g80wmwi7rG0hFqGZ+ilc8xUqSSdzYIJD+UNRxu9xXMbeFGGQEIJ7P
A/q/un791/4SNn5wIFVZ+mR9kdgk04vyVwyYRMjn+DETSRYP3/lVyGX3WB7jG8eoHZAa2412TOV2
i/hp5EWg81UtA2OGBSAtEsFspdxMnZKHdQWBkrJbVBe6HP9EK9SIiyiXIZM30JqTk/HwoP7R4Ykz
9zJCLm6hb6aij8zmdwvPprfoLEP+S/Vsstd165ZVFh6oQbY9MnBM8zHC2JOI4l9ux3CY0uyzcBGx
bC+1w8GhFeZlyTqlsQxnOysg67ASXkkC2SbpbOduANURSj4My531RqCeoGmar82m1u1cXAbdFsjB
7Isz7usNCjWIO93pjfbivScIvUvXG9IUtM+Bokm1ahYL8Nfnzk+7XxWRwuS2DYW2eiUBUwTAXE4q
paguwVtgKXkcXslNG1Lyvv6tJBML8mbgQrIK43M9C/3JMTDQ00h0YEeHtvOH+Gl3iiRpfVnw2F9u
Y85Z+15cS5bKYaGPK8m742UCQR9W7VYCjn4+tZP2BC/AUhh4X3bZJQqChzWYLNlQXVqJInh/cbqF
+Ldq2jbn2+IrGP6IsBpooSJXmA7KpsCkBuoGIvw99+j/N+NlfEM0icDAfdcR0CecBV0fsc1qHwsX
988s9cNhkWcP/BrRi0dRcsRhCx9snVCjgcWGOJMHE+o0Iq8qMdRUEqgOkRyY1YsAhGu2bGqvqAew
+wFU4jeVs/yt/Z2Nn4Q8z0jA12xF8X64MuUX9Ae1Kr3YSzr3UHKlFNBAyrFDXQoXTVRHrRaz2yLF
/zNvW50UGHG2vIAn0uG2ahvt6sbCV5auu+hBPb4Qoa6irB1K1AC4d8BDEGnU44GlmBGoOC/xxuOG
6oEKuyOqkOc9uZTO+B2PNttQnYzVk+Q1VdjTwnueHrsIphM0a8dW3mZmOIXhSJLb81Bn9719mHvs
Q0EVXV6l3YgzjuYDpZzDKdFKlG/+JUTUMOTE6u/Kb07hvhJfLiWFuWxpDaA1hiqAbMooYDEvbBNF
fhmnR03zdylAE7ErU44oq3zZyRATkqAMcoZfhR55CywC8j2USmk3MdCvlHpZl1WStz103FF/n8jf
iEu2RR0SHg1Eo+XlDdHrUW0d2RWVNCkrb4I+1/Om4Lpni0BTLzKwOlFK0JWVXfKpasNBXKxqRtG5
9g1bb3CluVK+bDHv1sgUsXt4VfWS8v/jEYU/ed9nPyysTfRzNV+IZ0nZwu2zNL5rKmHXRlawSR4I
E649FZN7oYSPu547l5ATjUqRRIewIr2E44MvGxvMDVwuq1ng2xH6b7tyHe1bY/x3hA7b5ba4AFN6
agKVnWJ64PHGo00FgAkJP5n9oDazm9vWE9fKCO2qs0NUTHJthedtQsGO9dwpqd8tbzufdFhAGDBx
ZQOQTtmI2QrHiyYOaQAQD8oPdM8CtPF/hOil9UTTcVKXgH0ziRpUcv8flTzGVWyd/8R5p1dp6Xe0
pPaMvpGnb+tB30XT6TZ9BzAt4avOa9H3rC3Nd/5RHKpRLBxi4gA2PLU095AIH86sByXZcGBI4atN
ezNWvk+OIAQoZYjLfpCvrSs7q0+WEoImFxdvdSf2E3Z/0DfRQu+fDTZuOUb0xD2Zuj5lk0tkM2oL
tH4jY1P281O/YgmNC7GqnafEZJHo/sfVqld0OgC7Wt9/I/dZQ8L15v7yf48rN8zHPrl7vyZ+qVsy
EgcSJcPxut+bQDynx/byFMqevRX2bMnu75B9hJTk1YG8xu2wQiG/gim4V6xc3MZtxmYXiPt3GqZo
PneWZIh7DSPQa4saQ9ohBJ/4bhAaXI3LXBem+Lwl1X2lT/iQyniRZVB0H6zEpeLEWMw/p2gS1asj
JJNxu6aH9aYVCNMwenJJZ9bwLdscONWf2zr5bg91I72URYcgKC5NI5DCh3etb1WMNYPUYKsekQ4E
VTOsOVzWFKpI3rMcK2nnS/Gejv1w0r/PLARHb4N9HxRCcmut0R94VOZg9Gx5iv8sUZT/yJL6cE0k
iFpeC7FfDFbPCwowdpvKOtrefmggQ62Q7e89s6MLq0F96jz6taW4ksQhkAd86ptZF+InN+pkayqR
FfyJT9DaY05miDJc2fqhcFZ+yinZKJJ9Wz4dYevE1sZMc0UtcoKGHQ+nAXc4yajp87NfgRW7cmFr
qXtZfHxVIdplCtgxJfWVcx8ce/PdZ1aq0Sao8IH58Jfy/5LD/pDl8zex+VlQah0XH6pDGoUqPMHq
v1jGv3ARecnZLDXujcVQ4weZD8YoevwNDJROU3RdsO1e//UNnzFOowXExN07BJ6fjujdyIIYX48P
dYpe+NtU/Qpe5npU7VLjQwboBCaEl6wI/x8bIw1zfRajblZ1gltpqB4oKKXZfPXgdxa1ZRmalYCC
nrddc2QELz+7ZlJt1/jlbHwBtOAt2DIkzK9RySx7xIQXmjX6mXN3iS/1M6bDV4VE/sT7Wnxi4qyY
jrswrnK9dkx8NEgYBRTqL8PWDpG4M4Lv0Zkr960wDKOU+3BAyc0AWvAePeG4jdZ0mfCEhWzPIkKA
WGE4CORDh8FH/K9TDFZ5FXapR5Oo0EXsSac3UVTqvIhnvThKGNrTum4gpcB4DTi58zRfTs4zL7/Y
TziDWbPNvAZg0Kl+838UDghO//zvi2HZQfFRPML2iN9bwQnR6Xni1qZ7s3M4qWleIyCDWPPW6UaY
MYwbJuTXH/jGGRQZPsxaK0WSbmVOI6d1PoQ39J3RCz3l/fvgbkjpfy2B0dsjgI36YUKV8BewM/Nd
37lFNC6t4eNbtX55Sn6UWthB/c/LtmC0a+FqwBEgZC9bPbZ/a5r0GYCDVf/noMbE+xjXtQvNymn3
hbClPIbCmdec/RxdJhVHPFJSRVwtODZiOsFPM9iPxgtFCWzOuXCtlVplAT/Dfx5mZIZfUpDC7IDm
vEje/+2hi/ouIhK91Khvh57jK+GEVKyGZm2f76lLHrB9U/s3PEPXxJWjr16k0r56lzNXfeA9fhUN
coKXGqgO/5nixLyY//hEEUoR9SPLkvwnJ91icycA60H+Li+CzbK+xN3LQg+YJZ7oumKa7CJiUd2a
s26xYIBANFHceouwnj/G1FmSXLwclhWvypPUmsBQCjT3DuE8QRCj9NrAeFuzzkHo66SjYcCU2r0V
s4IL0j3pBoxt2fy1GKI0QY/ydlsh9kexEOCs5vl7OENUwlSTBkxs4Mcc6SlqP2ie1JWQMOlQtZ2M
n+oz8CMuTb/pp96p5m//8TJfmlVkGgkw1Pjc1xy7nWZLk8V9zEMf3uGkVXZccaJC7J64zJa2uydw
9j1STerNBayv1zm//uIDZ7plLSjVDytnXa/FjayqNNf/wQ09/zhILTQN5jctP1uolXbX0zrXuVXY
8y7pQ//VSQWx6X8X6GTzhccWNzhld9mwAxuvmQQcX9BGKoqPXy+LJ2vaFyCQLUodkLniRKbfOsJx
rmQcEd6qOMzNSNuuaPP8BPKlTJuN5BmvmDEmoGY2L9NVnB+LBq5vynYasFTQcNPNt8QJgTwnDw02
iPxTqvFKWMjlTby9+jw6xDtoWkrA0m0TidmXwSVc6/pot8LNzztRPokvqIfDO8TEEtN1aIwS/0c7
geCLvxEyAkaFi2H9424mQnf5eY9zbAR+zk0gNGxat0zO/CvJbyTviNF/fALF+a8P4tmVBNTuhRUf
SlypxLAdtU6YGEgA+5xUJTY/OkxMZwXJ62TExi8pjO/9RsC78DQL+VAu1xvhJHoMGaAnUICfm/wr
Ziall1jVn84VBigCYwmHhqimnB6C9ze0DCPPAXQhoz2p0ehKRgtrCH2+oLfqQrF75CVZJg0UYeAY
TK9oLNAkRhhAOepR55Iy4W3V7qu5AkfRQhlolSfjxDwgg5QjsOVq7aeb5nUJq+D6dcXsZmLRl8Ug
vsLmUvNKlEUuyKslcVSxwz0xzwkspOa2DTTu6LZV8ZTMemHHRnAfws4Cpxh2O3zKe8NJsWjzJNsz
PPUDFaNM5x2TJPm/KkA/WDl9+cmCNhpMxm59neiVGgKz5iHbBp4xNHCWfOEaRZU5eBw0PyDBZ7V9
Wa8ujEPBSGMTOjMnJgVMljhks4qg6giZCCtB65SapdrpvuoL4rsO9BlA3S0KvPYYBhkU5DV4QF8l
+05Et5tAtYdjgsRQi0y16Y0IgQ2lgXUktGzWp9lVvKMFzYwGvW0FLkoeZmsICyjZpD1JXn5J69xL
2oqvjiN+vP9lipCO+lh+8G5g0vflWz4K5zAIOoNXbFToek2HdN6F1HjmXp2xTDrv+Vsjilo8+Ab2
shxiA8BPFk5G/JsRaY4G79+jZMhrXzusqAegjVz1pH49C1GMqnn+nS+5gWHV/tr4nWuBRRQe+vO2
rzMzQsjmlSg0ek6ItAIHirGY+XLGbIrntj71aoT6FHFWj7AX1j498Ht6Gj+o0o5vH6VKscOfIr2f
8gD5fPEv52+g07aLKgkT1xeQe3NZE4QF4dLdAGZDQAG8y2el293d8KeZDjJnNsUZeuhXQH4Fn5ZF
gKEFkMxgHivBSlZXdENebnQcGC7UcowZsIWW370q5Ins2aY+MWBKR0GzFc6conABMCnrS15GyAOe
cLaQR6jR8AJIkhgk3rf6mAhB3VQiAbxNOjDbBR/ypCIJnyIc0dUCW60JzzxLLfSP/On8sXGbb12t
Q1bw0m3vsCET6T/aN3bmWdjVvXwKvYnFMmxRhJeQS/QDsuBZ4hmvD93EGvYV6G14quVS7Ayh6Jyn
iefbjq4vNwUOpIRYDvQnX4usEB+zhpLbaotQk1EU0pAK8DHdE2iKo/k7BAqgm0QXHdajh1qz01Q+
fgqZ9W==