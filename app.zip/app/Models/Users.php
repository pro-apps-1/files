<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu0M1afjglfjQFYJQRB59yJgPp9DqHRvqAAuU/JfkK/7nYwFCrAb5bhojL0BPP1ZT8RQAPCU
/O1XyKzU5Moj4Jecj8j8ErEXRozBxEzg/GsrvcJo0YDYnfj/o6BRM2lozB4JjFM37lAORzMvW7w4
uKXwZZU26CVet7cIFxHi30fB/Qv2n0VwxMqYRokSbOo1MLpOUy9cGJwLKGp6v9dPL9AwLblpZ2Ao
hZd0K2i/iHlVM9VphfS/oOKMPToHlFd7Rd1o8Rv5Gtg/oOGMaUIvJ7aVDhrhU8/57fcbMj//ui69
qxXvKqKoDc1BAZ73xC6bogsgi6Isrbj/bcmtBhKmvhyvDMDOilundsowYPugOIPBmc8ciAFwAAaI
w2qanhHM4Hj3yA1d/KYA/Xl7U+DQIUdwmy+XFwXNcR5igokUJudj63bxe5VOzOwkJHvENu0qRRXO
bPOd+QyI3C2M/I4h96ZuegQR1ImosqQpEaMJHLY98ubeRhh1fh3ANCr3ahQVEa5YxjaPJAfDNgt1
hAy/+mqzqoOCwmFcq6p0YSlpzAHxAddKQekVnKPw/tj2oPYU/WJ4I9KzvBIq4gfVW1xEo021tsxi
ro/OrVrGaoaRsBK7odoakFWwXKuFcNu3gD9H6+71juw2n3x1VZVE6N0oc7WBaUD1NbY8OZZkRuLW
+l1voODxyiIkoQM203y4AO7QKQoopU1aNlWnVE+Bff3k5sxASLIZaT2eP97//076QRjcHA812pjY
anpUq6iE1XMKnpt2hG0XujlnFND4s1aklCUhTRa8x4KAQpvS2DLftTCjVOizmNRInW3KPZef/3vV
5B2bz2ELsCjALqC1p/rbGN81dRr7SD14gEQYXwpOjDrrzTkfXo5nNBIZcEfM+kk9Ei/2ZnIVss+I
tfx1I1rHYvIAcMqoIo1v5RHRZt+0nebv0r1haDpOVDWWIuZOU1+NS/Nn5+Wcqdf5+I4HMkoc3t/r
uFBss/6wUxf74XRzH6beQFiUj4vunaymfTiRAEa1+xGNmvWwEqr5ZCBj9Huuz3QCIGwjsLvovfJb
bmWq11MLiv2qsqOgXpMorR7yiVuYi4FAWD5q4OgeTfzb2/YgB0wgmMcBAg59292E5k+mnFb2EbJH
G4QsSUs4Ctk2oBzDZZGobatuUQmKXUD6lY1XdCxbuhYd8rMvRQqZPINlXupou7e5sXbFYMOS5eXt
vSbhvQXifUgu2lsbOMEG4wosh441NsjDxEc7Jc6I4kBtFVLuceOUvl+ZkmWStz7hzZrbmTrtdIJJ
TS4l2XueBufgAlyzMl4zhbpdZto9Ym75XPl0G1AmKiLbFg2lTr/mwLvH48Zg9gON/xJdKc6Mx6Wj
5taTTYlWj7tkrDx6B+JmTeBRPqHjFP6BnUpS7S1Tn6177Kb7jWYBELLiP8I5vb/IffVh9WAQYOeo
4mV095Yy0jFNe+sjjkYngZxvXe2rRk9i0iCnl7L+bjJKHwcxlR8hzeOIIpzbf/JqVA6Xs+fRkz2t
xvYR7bGEIXHkstv9M5C8y7BnYvZ5hO6ob2UpFyxPn55qXyYvF/BfGMX4iG38FlwRVf1jXr+v+AgW
BzEEGhUAmXEz4INsMRacex1YPQUYdGlTn1eY3Do2/RSO/Ttsr6rBP9VA9+MaeAldJt8wSDW/lZvP
BcJWxQXI/1MmwTw7BQlOLtznNtx/q/yesmuqgguYy2+JkXy7W9Twd0I9WFM+A0u/Pqw1dd6auH6r
zhiEP0cWVyxlWVzXoUZ2XFYmMu/eyZhyfy0av2Pq+oGFQcF2HXMZxbcT0Gywglg+2JsvbLjxgNVo
U54bba8IPfPFSGtiupVjP3kB3XdSby9qFX3xaW/swDQ8QyLTgwERujTuAtQSqIu3aPzWj6yC2HQT
x3JS15LQn+bR7OLdEbsc9BCImvSQRLePetvTLbMmaZ+N1xgRV0vgOYG1x60GnQ60jOJF9nhL5OEV
U5KxquMkcf05UpBf5HImYIoVBvK5mT92UsYg4VFHjqKBFQ3JXezQTXgyNVRlpLFTL4AFhv//40pU
dyWeqwpe7D0f4gBoJf0HGoL0RYhbKvVF1fGwG+AN5hOiqR/Ttzf9wbYk1ryo1l/ZzopZ0wAwOcCa
8g+KNoMyzHD5shGcbdzuNfSS87bxbhtjc/h4NgqHU8mIn1k3iRQoHE4hUtXTjM4299v0hf+XXMvB
D5K85erRPIW2U2UxN1IArBR9Tician8qW9w140XXr3DSW8Tbqz6AHSiiJdYM9aRqN5b3vaV7k3Gm
RTrhuJ96ZiGzmU0j3uFtXB06fGhUPa8cJ0VkgnxMaX5Z909Un18T/BukdiRYTCZ7p3Bz6daL6I3E
4rnNbjTGSti7T+jMM+SvKyaLDBS04Bfe/rRENRpAXFZ36Cw2mVfoqUnRFwQlis97Sg+zEb0BueqI
aOcSBG1BekZQJ5dRybukDi8aWxktBoW5PlWdrkHBgsk3VZdYXpFt91PlD/5iO1YGv80rjEFLcIWD
WNtG/w3GoLvtCNrji0rkOBCc+ty11rl5haCOmgEkNQxaa7MgBF6QFafql2K6AaFBj9sZ+e/9tAms
g6AJyaqscR1bcmH8y87PbgMDDA1Gp/lVK08YecHOwKkJKwSxhF86xUqAkYEzyGIHaW6l3N9hZC29
4NOXpA5ropjIbOJRRDBU+s0DCYOPf0yJrrcl8/o3BKaFL8lmj6UnZ7tNZZd+vsN78LHvVW5kZKgH
PgkcyTHC7ZT7UpfkeMXoexanAVvbXrg3oJjIpv+cB7tdlwGJmbX5D76K0KYAxJ9gcobAFTS5g9LG
9/IPeTVNzuhlOmyTQ41b/Y0sfel7tPXAVPpKaVQGEn1sUYWsjimqIZKRl7PKQkFvxWE1cp+GElTv
gz/Nj+rj4qg0rqFbVCzywbCAanY7l/EtgTNJ0+7BD9PhmEyzXjOoZJBbusHNLwVZR4P8rut9gje5
MNs1ocdFRwjzOzrlY9OYzR4xlj0mCNTTUJ346ILH4dtRYFx7HH/mLJbnKiNSZDYYW9RC4uo9nUUS
uHt2eByzPk5k5+wfhzZfyLWVi9BfDHM3vUp0SU2X955R0wBVak68MGmqYhJds2vL4qMS0sZOCXum
Eq673zzjSJBFZNohzMWewAQxFw4jHLBsHk/v61o8LCjphBFkJcx+A62AgStt5mTwIou5UU3vgOGj
oSasKf6rkpak3FVrUEj6N2BRKhP+LGkIbh/wot5Zs4DgFuebXidAMmIW3lpyU6DrtRw0YQFZQdPQ
Uax4ZoqSuWVzhfFJ/NWWGwBx+uosgWfcS8bR6Q8Dl9X8jHgvk0QAmZHl6BNupbP6x0aWDzFbl0re
WEe2vXD3cOwJ12FegCGEA/ZjVZbI0SoMtf5OBHjcrJ46UIfKCFdKXqS42H6NPTbjzlTVtyHkqqgD
qqe2GmrFYmxhy2y+6L+EuOH62rjVj8txXvbeDGjZe0HYAzQzywYDRqwlGgq4TZGs624K1bhqI8sg
YqlyNNW6prt7hRstvZbbKs+Ini2soXEZPN8RbRWXrR+gpH29EkMdpGN0w4IA31t9POtbzcfvksdY
M9WaBSBWJIqna5gUu8sRyz/NSCRKWsufrcLiJ/LfblYFmqzp++ffNPXUwP8ln/U1ZszH8MOhKsvY
1WoAiwzf2ZenvhVP8550ZiHH/rhlmsUuRqWA7dv71FIUwFGMzPk0kYL2STSYr1n4/nOEWuhpsIxg
dzLSXFdHZBdzbQYT2KaSKjs+jG4onTVaEGSTAGyfdzXNOg63+3r5jqgdZX1I54HiA8gxO4o2sclJ
oChXmczzbMd9fv/ZOdPU9UE16tSdy5gbxVdk1Uv5zMeUBEYvFGZ+puDSp7ecWewMYyiOdO5AYhNV
Egh1WXLKHeBuD9mRdNHdSpACnCJ5/2swOraYSMfy1iYL9XapCOiGRoGVai1tqjDI2gBS453grGaS
J23tng0Y7Yj+5xtoWO+4gvDClOB2DAMW5J6Y86ZPWl9nwseRHIEX33J6gGYood5xIdRE/jCVNiNX
4pvDVXte6bHZkqTkzGoG+P04w/DqJee3R2wRmOsOWmwAOOrR/14JfO1Cdj0Cqxx4zzq1PKWXHGlC
n63Czhrdt1h07p4QXwVwQ1EcQvZigPKaLBtQ9iCBzxxmpzutY3CivUdQqBKYN9LBrOs0OsU08ZIr
gur9MJIc99lSwUGnuPq+Vb2JvtU4JT1MCDsdLtcQOBxoT+1mcJYCiTPHQwYeJGVg+vViMxVySPdp
o7bnEKpCP4tRWlViobK7mlw9gVbr0k7TqXW8nmwNEjbAbF7Nq4d57K0bxNgiVo5l4SKXo4ZjNuf6
DAH/fTtOHJcKpeShM8iSVfPdmfWZyE/bGLBjbRH1wLCCeE/YU9xRTEucAoegHAAiPwLqTxCoEbhB
oK958odcOqB4JE0S+ENV9zykfTditVOJR+sFsSZH8tA5bYg+Q8pfkvoClGW50bHJrKWa9399JgHH
wY5g9BZY8GnqUYYSEYy0znRKLYHMRgGSeC9EG+8TduII3jgnGSxFtkRQcRebFVhwwRjcpYwpnEqE
wUdFaesRZHM97gr0PjPBNE6ocLw8cxnnheMJd1qPZ3do8zAYqP4HbzjLhm7tOeofQNUEjr7/dVRj
SlkailhP5E358cx1Ks79OxQ5DIDB+ueP87srN1v3OoVe6T5S9IJbpWYlt9g0wPPnJ2Zx4AsF1Zje
9X4twN+lCbuFiQlxnIWNucjPRoQvFoesFpMlTNQIDnLLVQ494p64vhB0GzgBKvAeNTYlEVhYU84r
GsccxjSsS+FrBEsLhpgp44aIf6nsF/SVm3TJozO7dVUu6e6sCRYcdFWHeHhQvDgJCQigIgPx2PaS
Kuycq1z7tkgEfLI1xcPPmvg7C72hzHInzJ7457WpYgBwVHLnAubcOkBUdn72Sec85glnLp6NwY0n
WtyVqJxUN6EcK1Bk3pYgicVjqpvRjDxXUycJ+p9dX+ss/INeI6fNcyM0nESoQ/ioL81ZBNaIdcmZ
+2gLBwnSn46ZmkxJFkx5t1pIBfhdX8oaxi//IW6jU7HQ8XzexI9CsVhK41DwTngxz/0GBU8W7cUk
qRRCkhR5DABEz5q98c3HXJCm9GqvcmePMjLNCBC3z+jqNDT2m/f/eae5E48pVkeNOp+mFP6uvMOU
1sWfHl/TNExl+sujcvkXC6x8pJxj+7jFXi22dhFHj1m01Z9gjMgjo7D/gbCVGzwfAStzatRID7JK
bKXK1PWHCwfE+Al2pXbhuiF3yZvOM6ImEWCEHPJDuZXKrPT3V/d48hmBd8pgLeXqxvW6AlrjGkm1
sXWRQ91FI+xB/s9OTsMezyeNFJ01iWcXik+0v0rp4wwphouVgZFOdz5/Xw4OhGlrqoJ33RyIyRqT
TGBKcTRGDS0C71w0il5MFbu+xvFKx7lduRvNLjWOBVoITBB8tndx22TZd1y5ppqdRqYiVGOUytEr
aVunioGp6QxESKBUBmmcXf/CU/5eQfMOfGF5jgWtwX0d/teT3b8tCzmpfTM5HhxFwNV0gqvNSn5Y
oKRHT9UqaohbMiI7j4XpP2lg82WEain8J3AeUk5As/C3E0jGi+2vUcLKjhpHYwe/7kfDNjjKnynB
L2Qm0g9MjcVpEgLEiRQMjnzZ6ohGdnTqGPhWsaB8kSi8+5LGZfisvWfl7E+MHUl9GfONkX6uO2zC
3EAIgHsLJcXR7M6gQ9LfxJatCoepKodQyWfpgaBOAzOusyF4xscxrHunzSW9Y6IAYK0YytNkzmEs
bJPpsEk9SEN0Vc3VwXXLqVzsp1jQ7iBF6W20z6ChhME0Y6Dfbrv5t+vg2Neobu1bnMJsajoM0VW7
4MUus7/8y43fYQtTmw4DUEtEj1oK/xEvlOMpVUtfaCjW97ZT5Cnz9ldHASnQ9TKOQEWCnVczgzKA
jAuPNuMw2i4+Y7IigmSfN1J9iI7THfqsgS96Sy9AdumR9gLIBv0En2JEsjHlf0pyCrHEMklxYvIO
CLG9Xt5VKLeDcJV3IQzzwdVmc6hPntgCf1Z9rLPana9gQByIGzipXnXD0Wtpmr5/1P1aALjN7pSh
JWUlah+Ez8/PEAzYBlUG+GL42X/OIRjDl/OiHANZxyv/ppEVNLOsk0yhJxvxmcWADMmJa0R2j77E
3OLnn7kp5qrHvbbqPo59GPBS16lMNsAe1ghUSnctIUeNh5OU4h7it7JgVaTVEzGOYxEcgNpGpHx7
bAgZtVmvH00+QwpEL1b2nXzR9gP2a2V82mk5JMzjCz8fjzh/o/280MNmrI2wf4ZGGGzafTtrxAgb
sVb0StC6WpbuS5cVSTfKtoUt0eQ7C29Llrc7ja4GdXXTHtJlBQjKJjxF2tczVrNnXCJg/Bx0XkWN
aW4XCqc+uurS6xqIu/RqBsfFZc0gOBV8RQoPw1/Uep3K6nG8aW7RB3w/1pkInXrD/skRe9/Gv3Fv
KuM5p9BS2a6kffyZ1m4fawN5+7gdMwSI/ZirAeKzkRT8gVOF3g1n9CqM18fiU0UVwCz/2+wTmQ+s
ULPkA0qxm9b3RsH5/yowZ/gO6HfkfL+t3J00h2hC2Z1RdY+SHK+nVbkIpJxpWUVBimw5EX54AfGp
j0FeoeF5+xn1becR1gcQifFY9DwuSoThDJJscdI0bGxzW/PlUnSfRqU5YNutN37sPsBWIWhjVrt+
Up4aDp2eQMkelBzIgW3f2umfiqyol5f+z0yc35OH+ns0FxjiAS8BZQpwBSpwI8IX/oXiKL2eCYOA
vOtp1VGFpVoIHn+Wg0lDBTQ1Xmn9k3aMxRhf5SyUn0IGQzaljOhgR/ABNDg3riGhnmLgSLvAlWGi
ef0w/QdkErDd65Tl4HOmV0dys2asQ9DzHEKXydIqg5q6AldwHnS3c56aukZord5JcHssas8GB+ca
PIyGPh65af4MVJYbYyByQtaDuM1j7zCTioOzPw3Fy2jn9gumvW6aIPEp1rnsSFq5z28ZcOCrQnfh
gC6LsyGCulpJMqetS4H6BLRzMKr1mobayAOIBY1zZmUT5Wtvafgim5ArANQdE4CimUDQMezKnOCl
KaRTJSr31uv4haNzReBVBolae/yV1IvibjwoOd3BxxeZXh2HcmrQFjaxCJalaAkRSxfI8tiZ+0gr
hyu5h4r9dTNfFPn3AWei/SpdWRCwBKRO+kEKHnNqhU4zeFeRuDdoBvIktPA7/puGhOoX5Zr3ErMK
HcBDWWiafX1dt+eVDjm38lzL4L19yOeUFYbV7XNSjyTXm/ag4mB1UzWd503FPsKPouyIIffTF+Zm
X8ZWppd1py4ZbisORc/2jAHZLcfKGb8c3/rAzFOV3/LncO1ps79uibMc6I2LYT1VCSmEJ5qRYrxX
aQb8X89U+XVolj5qkUxNVCsAbDsq028Gt8DfZdK9dK3jQErGAX5cdKyaG78qI1MmYJbtNq4Qxg3n
6WJTE4j4509uVeoc8SXxwpY4jz6+03LPKcYxB9zbsNuQEoeJxe5F3w1H9XpFgKp0c+yJ4h9OnGOk
6bpw1YzxZPG/uqE3sDmdEoE71iL7zyJTqRssZak6wVdTr9nEfLv8zEh2FGjcIJJcCQ3Fnyc5AomG
EPYcsbuo3Iq3PCMdrgbibaNadlC8oD2tTcH3FukbN6nfpqzPhLoNeId9yKUU4ZLnA3GDXLzeTyRq
0AJYxhs6wXW8bMtCCF/X3XwOtHCQsfwnoplHDUJr9hNsFnsl5nRuE7x/zBoh0DUJHGeY8q7sVLlC
EI0kEnyS2DEN6WEvfTQKcsXPAf8LJrA5Ry90OugdB6uRWxjKs/TCwRhJQx2EBrmBn2wya9ZfoI7i
t9uqP/VOEKbVjCRFYujHzAxRazPiWkt/UUCfNE1m09ndd+/6oIw3oq6OluXbHUlJX+oOQXjT0ktt
3unQEeJAihr19NNLdIklEMkh6XyIOrx7ofSR8450h8Ku0Y62CEF6dBhaaibroDUH2zQgHnJKo/Io
I7HOlasaJicKZL8nEP8qQu8r03JnlROOYbYfdkXilhUGskmNhO6aBhv9jYyjH6Jb+FjSWTje0NU1
OltFyz7JD/WItdETXYRULf0aPeolYq8RvkN6epSol28EwgTYlFzGE7qtu62XLgz7BukL7sH9ODTw
FK58nGWqqMt1RyMdooYmJk5pvRfYk/1SzWAlLpfjojgcquvsYjZok20mEkskzdXW2r11kTSCn13i
EM6Klt5pR0shQxL/L6UbyKgxPHf6yFMdcFdRNgFuUasfIBtIgYN34fBwXc0ju87TGUbkK2DHfpkx
c0RM6bUCvL7kf2ZKS0ORjd7os/l7TYwDtVlKZGlT6SrWycWV3vzB8LVIrWzFDt3W/MNeUMAUhG8a
QqaktR46rMxgIb4V6zyrzyFzLGW+L4gVtSiN0LXGlaKTWdYckE5d8G==