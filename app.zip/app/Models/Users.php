<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/puAoIeY90BjHQ+1snPmASGz48AVwLHqfcu6GNXHeyAEuTkT4tvCrjwwE1CgGunYq+nQYEy
qv2rcJYeqe7IN+s0S6xE1Xx/K95PcWVw9Q+HxItd5MAWFMNixCUAAmnhOo3Qcgw2YkW0J9cAC9nA
MlhRt/V673DwQUgusEGGJGS3dWaj7SDVXdYaoCAjxNb8q476mK8AVgdcr637gD//u6lpR/RXBh1/
5RhQwV6fEGsvCZVlOrLL1mguI/2YTkDdr1txnc82gkQCyqV2yCGmDldWeFTj6ssaqrp2P0M8Uv3S
SKne/mBEjszEnbdAc5ZVvdckrg7XJMfiNl0kTKSXLp0CP7C+xIKR+1XKQSUFPOPlj0KU2h+PZf0Z
H7ljri6ObOYM9vfV1BmJZxC09Pm+nSrcf6pfGb0Z/8XdUwCh4EZURjJ/AIryrKVf+C5pajzYQuAd
jg9d0yhhuepJv2xAG4RWILJXsh7ZkLF6RpS9oR+6jAKCHdVinYvgkScRYnc+D0aoCilFeM2WgsgT
cEem/10sHMs485VESi1dNzrjlDq+AO1BqEC5d+ojPBlOUHtOSQgpPH2VNaeChPkwGwo4ddFsp/c+
fGNzE5yuCak4AOPaayXgFQ4/K+g/Jf5IOeZN/UMyo6VMvbw5268jwiaqIPE4NqKmZEUe8YZeCyrj
JZ6BURVX/170OIVdr3Cm/855aT6dPtygKYOZQ76NM9oHr97PQhLEvMYUqn6n+YBvi9BOSlCnRqg+
VqZDg7BDh73B4QPR0/2N1VULojQ2oM+QsgEY0PrmOGpuHGUzdEPQDyUv9oxvBAdLu1Ho4pPa/wWv
HV+TS9ngLroSwI3+NVL/bRpBARNPvQC7A4H/nBS7g4rvqgRmENoXW/5V1hYKQlNFhddSBBdVlMLT
Bwb6wD3dMizTfHyjSu2J7r+ipOS2ToX5ywlpyuYzgFY2nFj7NpULSPKvDofLiEJW+JCTZr8e9Bcn
x9JeB2If0F/pZ8Df4l+8lrQRI90Q5Uizc8tsk5dX6o2hyl+EhYRcOWQxKIKN8RUMnd3+zqmQ998m
3zJhm/Sa/DuRtlqt82HAkGa3dlrwbgeRhD63bhspNGudq2mckZqS4OV/yFtIpH0xYhV7VRICuWn1
ixBPqiQy0vBkBFNJ6rB1KzsFjRJFCdz0JTwD6C1L3S17u3rLb9/LJrHSvFAsv3fbMOb8iYWbOUK4
LwcpMAQR2/boDqW3t/kPcXNKbKL7aC/L2AWht/OWt/uryxM+Bu7ZUr4kAGD6gJXlxJCgW2Xqsswp
T09miHpFmaQ+lp+NJZtMEjeF+Tv0vDJFGddSAKnnRfGIU+WN9b2E4gGcBU8JQJPU3nWTaNkDymrU
YjX1FViHLCvVdkBzgREVgWxYbqPssCpvzJ7ei9lyn0Dfrq6X2+ssTfjfnWJJgy9Ij8JUNpkQBluX
pTs33U/sKIxNPTIqgg/hB13MBsHeWLoLHkJyyaSBUJ/Ug6silnyxz907/7DJriJA9s3K9p78YAvF
LWNHc4wodlj3H9f/ivl2Nv3Pc8MlIk/9d1orsR6qRP8KSaM0Cy1zWXIW7zhJ4pajm7rwjNtG0MPi
y+bpGfqGBNKM8Byx+UiljRkfOZ93oNboUegcX74Fua4qQXYQumW3srQus/YF/iofU2pllQQTANwO
04ViXhdQDeUYrLQEK5aOmnuUi0tjT7KPLJrtkHkEFsdgMRuuM25IGypIayOQGyEPuM73H6nnlCB0
9TuBfbDGmYxLKqXajwk7LY6he2Z7vbU5G6hQSTTHCdlG1vA4mCZzxi2B7PoGSJULTTempVGHaFpc
42akgkajNJt3wDI8TJeYPOpzgimDgH6cPXbrvR0wxwedM/IJ8CzWpPQ40nt9gs51M8sW0vTIEbTW
v6tnkYf/eO2T66xsfVgA3eFr6KPMdC109y9xxRd1SbJxn+FTorJPpSa+rhn5xGMDGPWqSrePVBDH
JJbA23B0QZee5Z+W6mnq0P7b8YXtb3gxQX7QwMom5T1McJLi2uB4hjzYtY/VsKLyCRlflt60i0Gm
AhoKp2QsGVCoaCsEyaH80w3zAsD8brszWaW5cva0iZ8cXXLkfsHpbjzN5LnnVA12XqOq9BQWiwv8
8xgCj5CYm813yS7CnAP9JjVazwDnDwuxqOA2qMqeBQ02LZVJ31nSs7ZtIiwYP4nsBa7h1tg1Tywr
K695QgyA0o5uBTufgL4zpONwo9iZNjndru2nnyvF0YlrIZjBQoxVNZji+AT/DtCMhM2leRO+/iZb
goLYDd0IxvgEaVviGw7vBI+oqrULsOs+VCin+vNnxFmPfRtvd8lqa9vQcczo2p2BaSs+/1Swd6vP
n1fACQlyXOOCeo/aKvXyI+t4GsyFyjrU/oh3z+e/Xr/RYyOL3pButO1MZHvp6PvaqUpm3v/qB+gt
QiY57wmKmVWZuB4NECMqqhreJgmjoKOEoqi0v34zxbhZnFiYdt2lhS4pxGjwqa8mxh78uhqIbuTa
u0AdDFxmvoV/G8KUS3k0/HPpa9w6Ym1T/HbGhomapUtOtTFeh10WH/qK5EYV/Ybl/nwS2Vn+enGj
WRZM1TmfHHQpP1VLaq9YNPf8u9nak4hLfiIOh0W41xaGEcFj4DXSOJHuql9+xzieLg8oJn7fxGtM
veuZlYOLaXSOkN85fod4bj50rbtMjIDtB2j6tGXtUewzXBNFZkxuRZ8pq8vdLgTRrT+Sso7/Dkrs
21qB19sMO3+J2lsep8eufivecyDD74uRGk6h+WmKLijoo4etRKIlWUTWLaRbUwy72Ymz1Fth7kBj
q7EajEg08v56skK4PPddxZz+ONkYgWMCommvY3bN0IFIKh4hcsafcBe32NA7l+jdIP81etJ/pZK3
f1zQaUq+LwCn2vgqNUZwjcJKnAQYVVzcXSWztUdAlKSTM93LE7OoQoGMYTASlIsTezf4Rds8MMvN
BUaQ3L5bD1jiYz4fu7ZJemkB5oqKsdTZw1pDcUNdquWaU91Iq4hElHmHSWMfPOkcdvP2fmGDCvx4
OI+dUXRnuWBKLUu7C1+WQk7tkxrYzbPjNPXelMAq8w9RvbkgZ6+FFgWRohVh79CqVKFy6uakQi2D
K3gAfOLAx4ISKnEptHDUuFFuOmJ8jfi0r/4z1ZlIsoGea8AlJOH0Kd+UtMY6belwRItKu4ZWdu/9
oljxEq6N5mePz/zycOejHootvKQBMC53ATAmaC0zS6eGJ8KD9QYYVSkUkArM4ZL9WgEN/1gpyhg8
mB+XNhfGcfsqBKcZBlpQj8ullI6J5zXMxZUNGZMrpCN8pXzJbn2jy1JsvzeGSDdh58qO2HLNYwDd
cDDAiS3R9pZn9yaHrE1PPSnSbS7NbY9amaibZU5076+SZxCf2TlJHnZPunxMYeQiXZvzjcV0sRyz
eRLAJNX8gn0NPiLPXoseC8UZerScU/TMR/Jye1ib+NJLUfGUgTmRf8zHZq96LB1ZhXTgAcfJQQ/v
Z4z4YHuibXfFLyJEN9qWdiPoxuBFPsf+YXqhiIL5RwoNDCj8o9RGDFZZSv67EWFFBjCI0QtKvQuD
704WCUAnemF/BRQ67g354T9N3x06q1akoJTA3akTucQDlOimlcksLhGtw5buEelLZJaLz/47R6kq
gVa7K+bzOeBFz90nx36K1mBoM5tBic8pfJ7GrMfTGS+S8/pCSR5B7//dMIEwxdHThje9DTymj/qL
qvzLZ7pJfy19BWqKteQDVJGpd7Sw/EuPR/53jrW9aP8A3aN/7vkw7uoMKKEE9RSQinGY5ZRciZVy
nQuTfH8Hog/vOwF9XeJk10K1bvM1HPIGh97NE0GF3fl9LHeRHa4RQizy0B9dpHB47KbefsZYlgOr
3zcHfUeE1z5syLSSmjd5ijwDzGb/EVu/Ogb4bzIxpvDeOHSKYs3vtT6E+SD+NTk8k8NG3VmheBxA
EewYJaJNKanzM5JeZuIWUxtXtJ9W/9NbNgBEf/a3WLL/gkVfsLAJoIEGlIq8Tof3YOFMN5B37IxU
BNXNmzyCQTPqMd6pfkFSzL/f1daduO79O4aeggjegCXu0l//FZiuzr3Ghw49tthI4U/VC8eKr0g/
G72D0axS1//+RM8pKrJmOSiR8Xz2ZkRHjFX6VL/u9mbWpyiYRWfzrjrsXYXQO1WoPLm4xbAyvfJJ
xI5kuUHXbyvYhz3mUEewmH5qE4F/qok/BCb+C+y9nvigxSzVj5WicvDpkVUq3Nk7e7CQ2STHkBtu
zgiUBGy/9FurLBTnURPs15Qt1RxR6mYu7c3cVw5WwuSoAIvst6llcSOS59jNBxspx2ZugEjWGT79
oi6nGFIf69qWHbPgEI2U1j2RPyJhSV/H2LQQPqn2Oes+8hQMLtRjvPGO5mzbr+XJrtMvHQl8il46
6ahKpwhAixn1N+BRySHiJ+jjLVyxr1iJL6wrntJqtz85k4CG/yzQP7TAQPsJTyRQGKlZIU4d2AIR
/XBU0TbiG1OFve6x0La20Q+FIKPbUPIAmyz7rk/lU0+wmR28thN338Lb62DnMn6mOioQ67KwSm+P
ZxPDhaneMUNx1Xa0TtafOpkH9NjMttX4jd/NiSdPxPF4PwEq+KO0vu5V0/MT0tbOoRaBQiNONI1U
KNOMTcWwfiqYkjChgwiPIzWx/vKlEkW41qVbWuZJs+HViAcIU1deVB4I3fhE8MvzhyvWWpI24/fo
JS9IflpQEc2EAUsZxpHLbJDRwY+BWdQA+gXH6aAkL3rA+tC3uy+xjnvo+2YO5Ezv9fwWgb0kfvfQ
AwL3Cd+dLaV/b4j+SmNYT+iI6hJXZfOJiTOfY7cmNo9aylnIZRFtSDoUQIUzbpiYUfMBAlNT0MhG
jJ4JUSxal/ZMdW3dL3aHdzd5madd/4lkzCRadSfY3EJVZ4bNDi5Ehux0aFUODM20v0d24gFrLHsv
bl8kI3JQ/sznPVtJRMVTISze8rcPGLtVORP4aAP2Exh5P6xGtc1uXjU0hrSiBisWYsaJdx8ktimx
0gYOyenxPnpGLpt9feRUf/fQ4Z331gUrfOWLKWDaMjNEP5aMfLk7tgPtnTOtRSSX+6zRbI+QlYj/
dTBv8qHxKKGkp7hZpKscS7lbM4Ghuzs1ZxvZOrcctvlakOXdPjXpm4h2XCWuVpkJVPbdxqjdqXNd
YieHMM5TSquFp5SULkNwQpS1ItO9SSP18QZvGF0jDKaHR0O+dbIzRYNa5XEUPNkaXfTHQiw1lhGD
h8MNz7+qjK5rj6QBVBL072nWs+n1TkT+WKJaEdv6UYKO9IdBgEYBj9gB3nLS6GKTG35F/gHFtxIC
NLOffn3IcTQzfzXA2b8WI6u4MMltypgzAKEzyebV/0/OQ4gnX+S29H+v1uj/CjPgS3xHkr1Q3IF9
1n3SbI6nQaCvqggTAo9p1CIK1Z+O/qgapJQ6x7icA+Ht1LotRBNyirVnZ6OedMMpo6zRzxvQAyj8
Saxd/a0wiq+Em5qB/ohy6NaohxXPLs9o8MoPA+wgnslRlOps9PGrQA1SxyzSTMUvuq7i+hZB80V6
zRPZLviIYgdr1U0+iTDFJAEsowM7Za4NMUTOd658GQ4F0rdJHB9tsd84kIgtp95Bsz1ula+b+p0Y
af3bt0SFzGthMFTSHfhkZ0YDQUN1POiEDzyx6gDij3+Ov5TLCe/fB4N5wiDzcr4QZpzk0d+3Jg7n
EPajKd2SZiq8l1l+bwEefb1HIUmbvSqX1l0losrkjjVVfDAm/yehXe1y7LhAhS9VsXeP+dffp06E
UXoxbX7QGpIbY4kxzgczcPmKL8EBbh2cyiDsqhnd0aFIurpgCSkzn6Qc9XaRr/1FFnAXvk971y0H
B9h4W1w8QVyxNYHYlVFYSWOdYAChkxzX4y+NIT3yGxJ+vCIBI/FyJCpgU+YlyGFUbtq9xiCAs0HJ
LWxrHbFq2qEvcxpxhgiaYeJq5lpgFKiT3icRwRZfyT4eVj/EPpZsQIOiKiJGSd16ba8R0fuGjcuJ
UbJj3ek5pbqVtCeqNpXZlQJ/nM8UwfmfkFr37j6euS6IPBr5/8PP8piBq9oMS4bqMHkL/wT9q4K8
NeC0VYVmlTfiZtd+d85K/V/UpIzgeUHEJ8xVhamb78sBfu+hjpllmePBd4O1buRzP1iCx7KkzIdV
4vBkzCG8Fz2eDH5n4bmrel/Kh4jk//Sz7UDZmFID06/8UXwBJzxAQjgpHsixAWFv8jERMlcGBxar
gdOWFiARXMbddbXRGtUCzLwYp385cfZV0CbDHyPSPUWn471XykxH7CJ87WUOk5Tfi9siD7+/VnDl
kEzYhv0bXIMs+xWbCmrjekrxdGVbAoi5EILWz42LH/+8haHoyIAPKPhCq7D2XYQxZ+7IYzd9bIxK
334Y9tjungalQ65pMYSdxFZFuKkthHrUiIX65+OxWZblXvxQ+zDlAsdvq0kRAwf2xSmqdNy7j7Ik
bqdqi5zif1k0Gm21JkTzsNqofwc/8z/2GRaCZTftRNf35O4N/V5oWQE4BcCXiuxCqMR8b9n5N5zu
3xCUPYvyPUSZO7PsPfHLN8k2YrIuv8nx/bVCY1P7uLGfCM/35/qKWIa2IZieikx2fvDElWnNYQE5
K5IrLg9V9D2uRxrZ1KmAgE331DSEqLC1hgGBwdZ/ppRa6It7zhwyZNcXvy9rWef6SI7W08SE8t5E
iiWZXM4NbfcgJ//SloZmRhCE3/GfC1nLyHODNgMK+EKVb0gmNnXZ5qjkumds3LOJ4PRBu2egpthj
OJJfMLbS7P1b6TpK/2fRfR6q1I4fTn266rmscpCvPRqAEuMHIT1/f8t/OMecCKDO+MQHddI5Mmaf
WyT8CQ/1W9NH0UNSSV8G6IGixXVXPe5GRpYyUJ2URMZJFyqJC8sV4IHyXrW8xDkys/DRoqtgP2K/
02dgJEj0xrzGlQVUBSm2+fsL2xVj58xgce+1BSPYYBG/U+IFNrRS6NqbQvQz8bTjEA5XFVAfzCZS
9/5Va7eFW+dm5DjU5YExecL0MRUKzLC8OnVAdK59XwohSwV8O1G6IULKWiJFK9I6cOv7JT52zrpV
+uW3Q0Cgz0tHcW4+yFR128BReCZ0fq9LRWE8GTdKuq06xUgfKD40WwR2Xkpc1fIF1BgU/lasvdnR
LZh2niUolKlL8oGEncm5mUtWammToEwuG4VRksLoLRnixVul05yLdZrko8uwOz3dk8S72wn8LPjd
kemKY70Rkr32vw9uRgaVV7YrD6slu4yj9ltAMH0m+onLYhZBhoivRokrvibbwavfKoIzrc7MiFYE
LvEoi85pI29WtwLR+wLHuw2k37W/GsVAfztd+FDXfc3IZDsQwcWvcn5XHAfAGS81B1vrB9Ckn0wo
T+tEhp7wdoRf/wsENQYs7JtfSfLGOAqAr+dI2D2wHG+FsQr0Py7qjoVhyJwxI8ngUoXKWrulPmIx
z/+gVvVFMQC12JMUjpNaDeUtCaGNsWe35lkJCloDMu4jZxLZgYmfklp9xVDfeqZlLxwChDgtJDJA
RDkb6NmBToftce0ZOxaE7JfqMQNVuMqYK/RiUFdKR2UNptR/N6RdMX/ARVG3dZ/nXWaoTFedwYTX
KvTza0JYGorHK/I6oMuUruoblljqG0ZFItcl/YrvdBwb/cOeJbDyKufWJno6V0fbRMjlyIKCoRfU
xPkzTtbOvRzodLneZ6YHmx1pP4zYjHIRN8ZF72Oe3FiQe/aYj1SqFtj89dKw2n2ZoDxfmSt8IYMx
8lk9jdGEupzcrAiF8OTCS5sR5jVanbSAPFJsd//V4nqjf7JRQnWJE52247xNgcsAhHH8sF9FCkgB
ONfNu7OucX0QmhvmKFeqnZPq2qnuclIP6Op8/zWa3XPdYkniX7qY9vosv79NdtysIFFxIEYG+MO9
hH3KU1fUb0JZOM8wqiNFRJhSxpY+58uFci+6jLSW3/s1wjU1DA1auJUbP/vh9WF/577BHy1yxcyw
zTV58yY3kdd30Ja2E826RwDJRibfO5D4we/qvVmBqiTy/mj7+3SqDt4gcBS54zFGyK6TZO752fog
J9dCbH7iD5aHZtxYyRUfMPQ2dw6VZZlz+xx2j/dS3UfzR6lvuKiLJjJ4paMVZ0n60EmXEgvGnnSw
SaxlhGcXb8SC4kOkFk7dkGHbcGc4ideCC9QnTCFeNV+W0W0CWNzv3p0PtCfW/nAjCMWFN/kb1WNB
EgNub+tDYnsN5wHfKwKAw0BC+pt0wP58on1l2ZzXQWJrk9YxIAgSZqXyRWRqvYk4PgXXfQLdcVb5
VHQYkcsCJUQVkvHHsbMduflRbXZijzHRCiPX6osRc1F6rlrvax9lsyY7hVTGMOwuq7B+aystvNeW
8PJypkdBxQ1fdiyZBkNsb+Tns712TAOXzqXf1MlnK1hSykZTRHD0d2mlMJX0A4tIwroiMuuqLqdr
ibeKJCVtFd/LWMg5yfpVVGPkCGgLmshBiq9n1EEB4hfBA79K6CESNgaVsGeFxFTZK1kAVd5iy8Fo
n4EStg7t1Y3CXl8aKDtfg78Sg4mh1hG=