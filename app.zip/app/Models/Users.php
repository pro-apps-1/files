<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv9fMIYU6g8FPuVC2vH8NoL6bFZl/mlRGPguzzHhtLEr/iXbXUtwq40ADHDuiyxoqU77bMRa
abQWKFFXV4NQhKziwQs6Y3PYs9RiFT2Jvaiqwv3wMIUGl/vmmcRNBI5AKWVh8nyG0ds+rZN7HFDH
OsjKolS+Lbw9xJRvVcK1KIeCHGQblAWnrMwz1G7rt2Lr5/pB7oprUZ4/sZ4zhVGaFaaOK+ildhR/
1+GlCiZ8nQyKpXpJRt4xed8TQLTDTUkNS7IVhubOxymazG/Nz8XCYKvD80HhM6poooFsSiMIo/uu
iOeJWAenOndNE1I2HHY7tpBpYtXNwrgbSVKP8G6jruNo4I8FbrdFWGNreVLxXxNQTcG4YQXm6zmE
Lk+cps74XuJJkGNXYZZ1qAUdTfXtIw9ir34Eztjj0mAFFqsN5QJUnJ2IXBnbwPNIgSKf4v2epism
O3PVpbPfkHWV04CqkU2omDMFayST0VoT+aryLMFf70gxi6rY3eDxQskL7Eh8AHBaW5EnVKQTQq6g
Nw1Sj+a0Q7QxCGSAokBtarqH6jwkTsGF5CLnYF/ZxeO0PZ88hO3NQ3/nRNxZoMMY1wdaXbMoK+yK
cLfCHwlr8RMSg6PyAoNXyJKhDI85mDnXIlvANlpdyJHRbQH/tZJ/iXbh4Gftk1+aDtT7qd/WcU9J
0deOAis2TXQNQ1yA2NyuXrePibrMTqnyePVnWKB4e0/xMxETCnQ8t8RqmqmtpK8o43exk26oDBsw
LgmqLfmlBYJkA5PcBDH/rXifaPCFIiKJthfcY9b9A/LXPwjoGsgXhpJ19wVoOCGurg6D3ufcIyKI
9LucJxCsT+fS+8waEuEujBP5cEPZxAz2uSem+p5bfVcpaLIGyJ7GCEDIU6MfSAq0STEujLYi7+nk
DChukKFkkl+fgqGNjyKM+M7iLKJcRvymTxWakeoMnOONvPerbpRSFtPteDYUTubCURCT5Bf79WTI
GU0w2rti/Hhu8Fzh/33u2xCuIkuMtMOoyVYe4N5eFkRZ6SfA55YDfX/+I0cnxHPNr4ahbehCve2M
kwOpL7bnq9jVb33a2/DQ5Fmrxo/kLjFrkzF8VHkM8c5TT8OQMsUBgJITNHUhJyMjT/XQO17lW7iP
M8vNj6NpAdAyaO79DmII5ECS+A2MiBHMLL2QRNMhtL0Fpjy6QXHuWFL69WzUUEkp89vTbvJUX5gF
xTo/iToeM44gR55cg9cs0EBpBLMWyz6Gt3uKdoNwrhi3+C0iyBJcNOntKBcw8kKNv4/zIaj7NGvk
5XXSriHk0zxDj3WJZmLGeau5aUn8VnA/xw6QxkBOQNqsowvFniWc/sguRmWZoQHtL903eoExS9Cs
v9DayvDQdA2w3R/pnuOKS7Z7xi0/8lae/R5xqBCJxc0+biFMlAyS37wc/+S9hXUSbcLUCDL+kr3J
BelxnU/zILmmG9Od0ZLCVu92OjmmpWBT30OZYjsl+EXlc3X3i5ds/6pZ4LrjAew4CFoz/58IcV2U
1LDDxaUDalNQz1IbV3hvSz8Bpv5Z66JwzRtIipB4gKXMKBIHzbwMGXW0nltg5+HwT6KKyBcBo7JZ
+9VshWHff1udSlQ4oWcfWflNWxtD+TK3ZjtLtN/0d6KVBYpBj2r9exfPdQzWeHTopWLPV5Ziqv/X
CEwlvSQh/MDXIbg9LQYgtEJC98PrXWI3AFIauGxUT5B33D7PeYzKK2kBdbKazbvr13YJA3EHa+zb
j+7s9zLIREBGCyHls6qP+aBT4MRC5tkcs0fLtau7rzDaQEDFHL9s2AVb2IB3PQmnX0wy6zCtC4F9
9gIwAuHg8VR1RtYoGHPdVzW6HSV/sh3R1Jje3Crf2X2G49cQN5n6cAnnODgeedAuj8ttoSPToO+P
9NULsxlC2Oa4AEArSiVY4MHCYecI0dcphUKfmR0TUXvovc5abwgNXPV9PcpcDNgfMplKdfo+BYxe
VgEtlDV8C9wvXCGvaOOeGttih8gfq4lgZmQAP+OBZopomvC5OBICMfDN1/w90/yxDj7rO5wtdUGr
iB5Deu/EqIbsPyNfqhgYZg69/fIIKPmRTY0ekkXWTmhJ0EBLQTM5HYK5U0eD8mdD5m+jTQeg4Z4m
FJBHqPIn7L1MPCwaQ33fc6cXr8dOMbeHwEUDKGRsbTbwi2zt40WbSku89w2GWgVMZ/tnxvF95kT1
VOolpSY+fTZBRa85JeM49mChFfWMT/ntO8PbiyOhoVGN6qB8RtgpJKB1VTgW007lmPjJlgFfst3v
vYdX6zWmKrXyaXCACwtpE9ypEeMt6uDKZW7dksoV8Y8iSL20kAhl5L3+8nPFPLMOYiio8R6qprGE
988Th25ZRq1shrSm5GlA42vt//aq8hy44Tty2/dbHBmfu2aQjOpg1oAu0edqLXQl2XBVG9Sg6MWi
ge9MQBQl1F8ibMwzpgFhEvGffO/dHlbiyf3HHxJc6Qk8iT5DlQlditFn3vo5sdMAX1PNu7QtWAYb
jjLBgnMoNEHZEqmKI8lvbdjxvksY3nabRftG41qQUPMzneKtWL4zWOpRWxZZrTDywTL6rpb1Rtah
hzY+PMKv7QZlx+zf98Ar2qT97nSzYeZ9SipICPImKnwhilUmDj28l0+N4JK/n4WOg6JeqPEv650p
xuFfsYXhTnEPmdeVvjnaAkpJV8SP5d9SSF/qFSb8jTB6s6CuqIBa4Hy8YRH2mq3/Dig5poPkn3vg
Di1LnlitHpBC5NDG7Q4EMldLfiJiL6otmV5s9D4K4zppH5n03cV5S+W7dBohVUaayRelAplR5R6x
NQ86hqDjn969wymM1opaW9UoMxm1/MDSAnZlpOG7goJwGyyNCzgnNEZHYs53UM01SkCh36geXM0u
fIvAXVfI5tbxzZ3eGiZMgzlp2R1Y4zXXJcsH+J2Sktn8k7+HTKnr9jLjh+NzTFOw06B7welVJ2jO
lS5O+UlgC15gtHaw4BdhnPriUZ1PIGiiRKQHLU2xsaDwoUcu1g98kWWELQuemZf1u4EeK0NuUu3q
+U8m5bEV6K+Uzjxcety48qzFOVzsX6X/IhrolfB38UdrIa3jou1sj8fJYWX9iWVKMjzDgtLs3oml
qDbmSk7oMPCOV3gybxvazXO4nc1oGoCfTX6oCvN7oSCrNA2QoHuIvDNaXwl7cDuWSWc+qjp/IUTy
8I/6DR81fCaUd19W/dJX+Ds3AwpkEWCcoDgSiRwSNFdwo2P0IG4ml66NMQkrqc/AjAguBCqPG9sm
PNKoDe+4jye0i0POh4IsjeF7xi6k3B/MZFVgE1IQA98EPzhqRFFsEq46WZ/cO4JI7WpDvg7pSOsl
4ZX2rOHSZZtBwcOBnluD6gALmdRHjYQJgq1aSd0XINgSktEOJ73VeA9HFdP8wLuD//niBssFahG5
05t9Y/ksHzAXQjme/JzVJzuzYmAfuxLjmcVXUatO/w/v7vev07zVQ/1UZCHNdnEJOX2n0gIKqKDP
p6PzWz9EjtlMwMavKlTa7b1gKIzEWd+GMnWfl9Hh7I25WqrqcYItjHEBmp6ZbHQI8dfVrDYQWv++
CWuIsKpup1LO1JSGhEbXuD2vFNpHsMCN5CyG1v2JeUN3UkatmRUVOcNYUw0cYYKWwYafQ/nlw/Zt
Kt4KR7L+aHDmkoNauMDXgjbywoFqB4TEyS7lQ7/IyMY8rDvhMb9y19mlcFavLIlD//nanSEN/3LV
uQoogzmEITSRXPznnDbugNjWmat/oYsccPhcpLAeRJZlSiGW5HSq69Z1Iwr3wIpVj++39S3L/aUj
lyi2aLmWUCGRA/RPBkZmeZ0pObWRHC7nTfuaxofAWjV5MY5WIZg1mifuH9fjdrPzUKrvvHt0hdev
qgH4h0P+xsSjr9iGnsXv9EeobwkpPT+uQDyu2eITkv93EMDZw58hXZG3ixIZQbyteb/esTL+Ml10
S++q338VFOCbjZxZGDkV4EQeqr8S2gWXscew7oaG78zWa54AabIvM1FUEMpb6/e52gZJ8mYSdrF6
Hq8neMafkoLgZFkCwdMDexCfbbTF5ob5w5rG+QnhfjslGqpAfhnXYE5ESGbnHDI46/Q8zTGlKnUA
+Y6Ke7G/rXTvC329TIkYBVu+hv1E0Dz0QamsvvnNr9nZH4XAkiNkUycRvl51mpJEi0f2W2k1jjan
8UzCU0/i9uQbLhcfSusxM5A/6k6m/GZmHlu/YNxcB2zCKUEXPD+gZRylIuBpsO0pTQprkEHNlXYr
taX4ZesyzbN4rur1Fe6jqJVO5YFVvaXAlbiF1b3UeMsrPRlICGYaE6aImCKey4OqDQhUq3tMWxlg
NkaV+Ldb4+Uj0FFISy4erQ/y68RkicB0YfQk7rL30Pl0IEuecYdPxLHOPUcVf8X7kDGxyUh7KOKi
AJKqRAzcZyZEoRsRyam8kLlAbLolgo1h/rHb75Pj2B50+CIyqMn0FH5tb590YB520nQ5eUYN/HkQ
+oVlO3Pjb3Vo7gkg2nDx7THfNc1cr20f/BjyPaUqXkWxU+qc4jLa2a5MU4kbJvGDFQHCdJvhlywB
jaFkTe++3L/G73Vq6Yp6miaL7RODo6revI8g6gSpk6brK/+B4MzEdSsldC1P5aswekyv//Me8mJF
M3WZtqKkT8TJW9KcVVxWmVxhxJ81M7qtK4TK9BZ4BUv2jU9AQJMlQn0/RJgm259cGGegrL8KClQK
JsPu06HUv5ew/jdO3+OB16xq3usMDWZQlUTq0iWVblznLuXKVERDQyvF25ECIas+LGXRCoR/gwTv
qVXWyCuXJmfDLIWXrYJboeMZs05wOnjXBhiUeGcP/LwzDj2VkKz0K2QHV85fVaxDCPwl1961V9A9
+10TLBOsvdkLLgW01QpZuiU6qllHLcVCuceBtoTXpAdLyVUhFdm8ih+wHO7cSOiQwtQ7vwPM3CjE
OVCA6a3NFiMPefsEntYCdmT6C2g5nIdirPJYy4Ge0DsYSw+TBV/lLzJGyA/LYz21XZ8jrjK8iOES
egQe6pfJJbWjxwXMj2IKTx1WlcosjRCcAesz7QfIh9eWjOeOhW0M5DDXooP/NPQ0DO0bNaQqd11I
SAs9EJAb0b/V1ROJwtkVkCZfyrjGcZD4H9DxreO3R7BmLkPbB4cs1uru4YWTkk91xxJfXO361suY
d2XmvsYv3nD57mSKBB3mX8oulMFZUgphKFM0MtVSWN0XQvOj62a+YWU6yWqRQyTlCfoFIFN/QXyM
j8sV7hNDQcpQhYc5aOTci+kzX+dqU5UhuY5i3kOfJ+uvupMk1UXiAClLC1SNvzvdzFJcGhBp3LhU
kyk4ubOQE/ourneIJ4LPqtcQ9kKqHsQvtiz4oK6Ak4QMWGe4NEJh8ueW24iXV4NuoiBFbATLUQmn
og97uRTObwJjAZbz3GBNquc36uojIlVdtvFU7YO/IH0QEBAeQKpfALJDl3HLwXsdxKNZc3NQ2Aar
lXyQLUr1ZYNMZnCpM+Q2lUKM7ZhQ33Tp4ZsNrMfyR/iobqoFX/ixHd86RX3yXen7pPlQQN8xuFhr
ryoGO5Mfh82mXDnbqgcnwWQNu5Pl0w5aEcHgOJsXiwnkpA/+UTPg834AxFwNJNMAWA4PkF7aq6/Z
VPNVwW8sJslYsO/eWURVEGh8WlOArXNq5kzzyyyP0edu2Ts19HbmH1k+GItoDR5z421bN6XqkOpH
pJ74ZVhwHwhV+MpCOHBwCcedzCNTWwaD6ue5t9qbpuIBU48B4KnpsDBQ+jFxWTNFmq1t4E0v0uXz
zFCRjMhh/ADp8g60jxuuY9MaW5m1HbcZKB3Ws41nBzD7HMng6L7/EycKu+lcLDwo5vrhInGP225P
SwGLI0K2JMPMZ6o51pxgkbRyAvwyI+q0zKbEy0YHJ5hw39jON2+oX1ejcMa4EaF/WPLB3b28LL2L
1r41DRHFCnV/u4xu8VII1pSUPlak/6rlx1of+trGXTX8wBG8L3vpzUv18ZXFfIaSEub8QBMS48zY
u57cBG1PcuXg+sKLFY/7sxyiGwaA8hOzMo2j2mhA2Rm7Zsvtpwd8mwzi9tRQFkuXGRmjYQQvmKjy
jQ99/SjpAyJ9Kq0NQILXj23wh/jbKumdNDhlvRNsPFNbWTwWpoHRzQzwe4x7X2TTCO1gM3ezepXH
vsKL1eWAUqdOKenGmoGeYharRn9OLZc4spD8OGXESsjt6XL1vaXWMuI8w3fqtCUEskP2b/dtoWW9
ALi/AVCjQA/+Kg1ID9kpwjgNd3rMQPJtKuJqx7j5Ptvz6qeHnzLXBCTXNXBQGLbUoGcZ0N5Y3tgU
uArK1733cpa6yzYAjqi2Bn8DZWo/UW7ZB4afy6tXSVZppct2f9Aq0Whaa1im+nNB0YFKWjS1Pvu/
ZeIgNegmi0Xnba4LncRkcpDuY1Jbnx2J5XdyXQ/FR88iR3RhmYgkDFuK+Km0bKBqGU5oTHa7gArW
Ey56paVLsHL58bQV1t1Gzl2ceSRv7/6jbJlzSiSX6R+JmhnlDWUfn8LwYpjc/wXjl9TIG5QDYNgc
1tnHFy46FwAombYkR8PNR9basfQ0YUo1EyyYPSTvZXHpfCN6BUjsV9qa8LPYxq08gOLbGRNq4f7j
mpBDJMKg0wrvKPlEyUSpxkkI2NrNBeP1089l6b2WLXgLHUczCW0NNsW1xM7li3utXuBahK53J4LQ
ItuqTxXurWOIt3MS5JKie5imLeyTQLajzBwCfrW7rRJAqSTW8s/9uUW97iup9gjf+RKDsQJXrvNB
ZbtQzwTYU92wVbdrM2u4E6IReR/KMU2hlkKsLaBFrG9MiNPXM1sllYOK/12UZQVWLZ5fq0xNiKHI
We9UejCQyldqXCPcoLO+h5F/GVyG7i1j0HxvO+ZboMDrzBIcXbYH3sCInYB6yXkF3r3iPIL8RNcp
wx7OuTwFgAw92U0o501p6GxFJ/PL5vITBlKBopQLo8nAJE1c0xl90mGr66MPLwgYwACpJJqJ3/Lt
CH7ZgjdxLq6YEOo4R9b5oEHcyCeJ7IBP4vpySgwVMC0mqnzECkWtvAiG9qyNQuKa9jHEFmvW8Z6o
LoUnjg81n2AR8dnyEsFPxoQiDE/3y9tpyOdPh9PFSInTYMJ8dXDz05m9tmbIheN1NsoUE0/+A0+q
Jf94RKUw5b7SP03Ow2MMhCzc83s3e9W3AQMAwoDeItm/ASSojmMeUfQCNUa9RYBvYFMKe/Y0i8tb
RGTgEvW385yb3tnTLEdBfEruDZh/74+gZZOwbiajQsU9FokjwoQHQeoZ2XXWFobgFkX+tcveaPdo
EIKWpc12jBTYXn/t3GIORyzVbbRrZPpJ4+Pj49lj0mC4BmVmgTIR4CYoBzSt45yaP3CzR6uPki7s
pe6Ha1tehPVKY8mU+IS5Y8PgpkNwyUU4CZbjgD0a9a4cYpvD9DP0x49meqZoMvnCR58tWcIh9s92
dWHPiuKgNvfn8qM6tXpNard8MVnYH9FwpudzJFveRfLLP1Q9bEQ0q5joi53BkWle6vx+HphF8p+m
MzPqxu7FAtXShZOmbZDORLMONnRwWr89+mHpNZx/L8cjfcqoVGu0S7xAATjDj/jcyEC3kZajTsqZ
NwivLa4WKgd7vlolbUfvECgR6SEFx6bsR9060ky5H26fPD6uGPmos48lUZxQqheIp/Y1sk2VXriw
c5iUii6NQsYV60AfQhZaT72xg1BKHXylmZWrmId+fIiCYz1dl+ygOY3LXq0XlYj3knCpKiF0q3Rx
oIRg4EcZhM8ObyqBhMz16DoncmcJWrunko0v40pcP0Ttnt+W/3kyei99pmCtwPEKvuA2Mn4Cl3t3
LskwOK1xS+jOxuhLUBYS9dyKbAMvXcx13vItWQr/c3eVzl6dsy6GHiMXgfqJGNe+YV6GyN42Fj4D
/prZZmomandVoheY8xBS0aE8lC7wBFs4811vfu7e0ertSB2HxM3jA4VM2SN73zRfmAmsyAX0WARH
YR/TGeFKCLPo+LjQwdbyYadXdD2yO9PjEPgfKxRFVMjuJglGkGLxqy8CtCUD9l1MoVl5ORjUOAjD
DXcNslQyoAJwFPYHhPkmkWvFpkhC7ldSvJc3A2jxX6AZyqUVhm/7dyOvFxCc74uzpBwzSuGeYIaW
7cdsOYpew7dzsaXp5Zbx10h3k+I/9+hY9QQBTGnY02s7AXj4oj/Asx38ODGUqlmCCAlYVBKAVdDX
6ISbCT51Q7V/4MJhZzqSWvnMOgY8dBdNWQzclWDi/hyvCCOuvN9lTda8OlBhAqwdmwRxD8umtIKn
597438jtqeC0Mgap8fM0FxUCNb9e8MJMZMS5iilQaRyWPAlkk6Tm1+aQfMoPVM3lpVGArzXHV0w6
v07dNug5GfXn/m9iNjLbDwpJ+PWXTXsif4/6pjO=