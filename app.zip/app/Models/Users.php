<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyJ93NV/c7lsU3adc5H40W5hoCDurH8UlA6uhtBuuDjpe7iViBFSyYqs2WzXweUXEBXmC4+w
Bpr6ADhBEXX8EaOaldiG28csxY862AReqVWB4S03SVXcWTJLZ2QlPkuYcrtmcuNs+ddrhDQew/ks
xpJts5PTlyybnEIbg1mWefcwVLlra1SLBS0dqoyqulG+kkWx3PpSdiePsucbiA8tGd8gK4/L/Mik
9S9XAAPQ0V626jmB4hw2ug9N3C+V7B0evGgKRjHLK0sFFSqLpROcz/6WCbvgYE/r+ZBpx0k2FO82
BpWH92H/yNTdax+auIFQoP6LYGtvLewJOyFNcll03UoYdQcqUTDW3v6IDjeg0vcs2vFqdsbMBSZy
EbHGILnrFK3x6Q7yKaDGDtD/CzuX7hKxeRN/gq5x5Fv6lu2J4xMHzqbjzkbxnwGtaqTaJSxkBxqx
QhWvlHiJKduSxB6UFNWrr4Pga9mRHx0GTzuOd/ZP5+UrshIrYlsI1fLMcaqkH3O84GqW//vIqB3d
aANtEuHGudu3jsouc9pYzWDNx1/cE11K/4uYo4HAzNiqZSbHscy124ReeA4Hmcm729V80lOnwkBh
SriOlTKFgHycXI+oByqCeyafyQuibs8i3+NeSP9GsgInJ7LETLduB0Dng9A1nWv2UQGchKRHmkax
/3CesjnA6r8zgGXOxENjAGvE6By0iZaLSL70/+NkxsR4/hTr7Qe3T4vOJK46Qn4tDsK3rYC1SYIk
bLSH6vBQLcQWh+c/bM/lsZbTcS/VfkrgFfC8njuXlv5K00ieGUfauX10q/kPjO2H68WxIhjMT5Z5
sobd07lPS01sKCf52onHpp0gPrkjMOueRQmrOioAA1kt1crLMk1AW+LSc92sRw1cJ+OW2SffxolL
TTF3jD6tCXGmHjBgSkHvtWY4veN9zzmzeTxlw5s36gF5TYnI5c/alpTqTCunWVIKt5GH9cKn+0XB
eOqKMuO+lBeYWzeqxT7oEdInWQYi39Ag7sMMzik0AhwfMWhWhFVZLvNxO1jF7JbiSTIHcV5fmTDO
8p3OqnMOllBn/MbytuQAU9bnczA+LxX7KroSrFuonnfVBI42f4f/OEMe7DHYw9Xk5l00UWKPXlpu
js4N9e82pr2FxFnM9/5mI0VsUfgk54eo9TzDCPyjb3wsNxzRtWuFKdFFnsguJS6N+x6GayViT3K2
/PhsdjDj406O2AjhoavmnxemTpX+Lz444VDgCTXoPalYU1wmdvVxa9JbO3A0mn7akhHBTc11ldov
LxtoHMtNMVOZFH5a7rDbgAPCaEMYx2MWl7JHElS+jrvEvAGfWC1xSGnOzwVK6I+tu331RdS6/rVD
aUACPgkA4sXnjt1NB0pIUMpkhkgSmQi8KPuTeDyzP2TAqLmqc40Wg0RKrpJ13L2zDfy8DwTaXU2n
n4M2umet9E9NYD+ZpfCOlzd7hY0C3by3akVx3x0Ru5Eoi7ehP1KwHGbbptBQLLdPsGhUhiu0YUjV
kjiHAhV3j/LmRoDrxzIC7JXYQgl41igsRCCBEx7hiinzv8EGmpDWN/3/ajMORKnWJTNuzTe49i2K
gmULMiTI8LQS1iTKjT5TPVEAkEI771e+dixCuWfho5KkqqME0Ro+/2bc3DflhmjSKyIlK5i9G69Z
/dF5k63tGIYTR5gm0M3xCox3UE9TMt9GFpB/mlZcWVnl8pd9sq08RjSGdoZjIbUiqXrDkfWvrD1g
x4IOfsBtJ9sf/pbyh309wIz5hp9pTRnDVF34ODw+yrqCIO+5jDW4v7nlDoHFRcF6X1WcMPX9PlHR
KaDqmXzxrm5LGO7bw0DG8t2uXdU5gZDpqxHPY+PbS+3MsRoAhXMDSLtG2Uw+Y6yt6ChvOa43KzuG
W+2VBJ5L+U4Op3YUEwtqDt8iTVHMsmILh3Oudv+nSTWs4k/QlrPB4WaItAnVnXNrDXQiSspy/zyf
sm8Uob5JKQ3Jy0ZP8qp1s3RWrtRRjVqzUO0NGeqU3QO83bcUCco1B0B5T7xpCav9LOTWZjNGBoxv
X4FUOAfh0aBJVlmky9dJbVbUBWdtR2vkWErdP14uC0yqMvmOHUr5cMyVv84PZomuTTYByQxxWkGl
td+EWSpgxwsCcDrah0Tw8CWvG6oRaJDUmjb0h4a+kMrpwVLyKybQotE56D+I2YE4Vj2FEumEZdvt
vrXpRUyOxmp3WvoYYv4mWCfTXNcoH/ZTKGoMBJVAkaAqM6q4tTGVJuP6uIM0TfjNKoex8vXS45gC
l444BoWwd1NuYyDEgSf23HyKrbINQQEwYDK/P8AXTi5ySob16Vij5wtWe+/zknyhi9xOt0fw1XNW
BxSBXDKaVS7SSqdbQfMl3V/lTtZBmjviH0pnBo1t87uqBDZGK5tCuYVxnUYXWPPEPqkD5wiaWXrj
49usdurYNIPvAdNLBe3kyRpRmO+jb70fqd6Y1TZJzVCLOiA+pTmJEqIKAh9W75bFs2yHn/3Igl2q
5omqXzrlQWheYIQrkSme69gB2jlZ6VTYLb/amYeWlviOz2XbnvMtvWP73d+GeQH1xEeKesjpyDB2
+2HxhFjnyY6rEvNZXm9RkgFVzhvX1JlYpgA/0qZyN+Ec5ntld5/00ancO4bt7iI20r/FB6vLTzTF
k4mnH/Yvgbs64YVgkNQ+D/SfTPWV+GIWYlkgaiNo0ZZFwT0zJQODSgQAKD6Ap2G19/dsAu+Sbos+
QDtzc5bmvbNfHdk16+654LtGQPKRbzZpwLMlwno6twYH8oW4Ve9R2RwfJqm51y0bDu/nhuSeiE7Y
KG900/4M6oxuGt8T3xHmYz/90ibztqN+Nsj9ixanyUcM1ZffnkITJMN2o8cNFULOj53hY8+KI58e
3YrnOv9qq1w0y9IkJwhqpysxHvswffdV/EdCJ6oFQ19Bm6PrUPri0DzW3tocqAKAoT3BskhP5Fdn
LRwmiMn+HY7LfiFxcDg3zJwUe1nQ1BVaQHmBZsCOKbkrYw2IQY81vPkejtbJrAsL67T5pHFpmTqK
l3anSemWzPYCAm4FWFULJt8LORO1jl5kl8g+/QidDkn0K4Qp37fXPV+OMpVxcxxzE+tdQ5/P9iD2
9lTfzZhL29ZlcttnQVD8q7OhgO6TMPCfCI83GgbZ70NtMNRFJULXw+GB1eTC24XGsJl+3v5mkbjS
0r7us7w/eYUuqWMSxfcdSSRSk6bxYc+ZBjGI4srUNBeJBuV2uvum1A6RXZyHx5tfE+hlWZStUQ61
ghntx7MCfUd99ZEp7zmJ20lz8wc+CvKSL3FjWlqArvi+xBPAabyKnFvs9lB66oHCpt5mq94Ui2hu
W+i8VHtY400Qli18Cbxsv4REY0CUWFn4hkR+/AQ4TXlfheCJ7zRPUX/Sr3QxAI3142rvPuFfkadB
cnvNWdHWeAO+Ytrk/pQ8hzaVCwjFzoUdFz7HlT0cpdQzL0ZtJW96gf3tHyaW5nXXwScCczcQ71YZ
TbLGUycHRuRK65o5kZroZWjjlr5sL57K+uxukvuatcEffBU/QaNCAKUcXc6o8zogpJ5R/6OH6x6c
R0ADceQ1SfJgb/EnUQ/JKY7zJ4Zee8r4f36GkOY0HWu1N2ZFVaOWPKmk4aSv6BxhipDDfxEaLvDI
AqeFugIC/kDH3H9wcg9c4rnQA+GTxTkcIu06pWFNfZyHwh8woBoulKqsAjWFWmG0Z9ylol94WQ7q
iy6nKUCfibWFOGK9//8EptLPgydP00YbWTDLK7BEKURljz0Do7dWdox/BC2rOH2zSwuflTqoFqFV
HX85zXpJah8hxgi4LfvjtPnOwv4C9kP9YW9Fc8kgVSkqYZQTtGYmKHydHYhRx0YavxT2VL6L1Sks
wvNd76ypd7DOpJLzKoQpsIK4cM2C+nT459ddCjXwS3zL+wWWCW3LcNmBfHhhVWke21+qYZdVW6ls
koNhBxAtViqlPwNtyaQRDSDG+YhG9QzuJcZAGLQPv/heOkdf2oRrEgHog9A2pstQjQVdnl+8hxT/
u9VlFoVUpC/D5doz3K3T5orkVfqc+ypdm6EeSe8r6xjARVRZ3XCj3zPxy90qzR/drNkFpAkZUoiq
YliGB/1BQDpHJsnMFhJSM4WOXImov7Tky6Ev1yqvPcl7qk6WyIl+2WY9FzKgD8M24Tx8ceucCwBI
4K6MBH6SBJOe84e85s6nBtobGTkmcPOlKUsPsyGETI53CMf78idrh1pcdiWTbAuKtFxfPxRJHsQ9
xCfjSE61pnrLVDXFmFsgzdDqBOGsPlMk9i/cjcq1RN3vrX5kZSWISjV2XLOwcXnI1WvdImYg44uY
mrukDncs2ydz3lACRgEFFTXH3J9LfggU+N02s26GvMD7i/E52rBis/ezYGXNf3NsMqgNy8peQhcf
CgBsvpFJcPf5J9B7SDYu4J3uz/evaVzWMi9w5sv58quWFOnvhufdzE2lNymCXt9y//KReVtRs2Mz
8wa0NIqEDykkb8jmKfmX50ydIpdAnVxyP4eAd3L4OJXzXe6s1LDKt1PTnomK41sEyHtfGyb1VS5E
qZBelDDP1j/6cQZNLvs8cn8mn6OUBKPMqy5zk041d3wTqkBliGzXY1rcOko1/iHLE+JxxQIBNf7Z
ujzkwDPvTz9WQYIViRmQX8TGpbPjvUoKa4jNb94LVmg3ZHCVmnxMbKjz97sLK1GlW6GSm/zLcTvR
P4FDxrrYi3uqe0ozdeVPBisnWVM7o35IjWcWTrurGNoQGGsXBcaHWpSGkPUux6kxZq0mSoPdHmr2
PSJUJJIP4zT9O7LNaRFw9h/iNbh/vrkQ1xAzEFNNafHnX6BvnmUxcR0H9bC4lXB0oW8SvyXdfy2R
M/+voSg10EOqzBGvSHtfCrZz1wQ9Gaeg/Dx5TduSSIPOyXMhFs+3OFQxJZs+GLb9IVBefuZTAe0a
k1Ek/N9+rNfxqB1i+N2SmuvAoL5puJhnAjWf+08kqo9XfaUWroaKe9Sfv5GN+D7lqC0J4b6+9F3O
J2p1bloEDxalbadoEjh1Xal153uxqFN3DE0qlzgGCNmQhFsT6sukc37GKirC/4nvDM3otuZYs5q0
MWclqdTh6CcyLKt8AuXfWY16YhhxfSjgAcPz8dpTJPhxjzL0XEKv6r4whAojeR624s9v+4NllP+N
POVsyCzdKuPyzx84Mwljfu4cga+EpYA2pDpkvcs/OzeHXLbuFN4n6R1NUOZCgXn402Sd/I59ykZ8
HOgsEO/XMMBLR/iNVOIr0KJD71vntr8FxZTRRj+2Cc2J1fD0K9p0QXc1nosJ/gbg/QCQJkBHPxmj
+IylsouquFus+BN8OY9+Ao50vVw3qevSXzKeX49R/hCeS+ue290h+kipA1KPdTXvjPYIJIrRrkzS
6R7YG2WdUV3Qt7+nJvfBt7D49tq5uDD3UuhLQslN4rNda4M3UyHHwYKprFkMIw86uNhHqtE3/Hco
8A+3/4giBs7YCaEujObhnTRFDFXqa2fc/zc9CL0HNLIPADsCrzhm9MFHjymag2I1XUCb28NP9wSk
7jLAGBWWOMKE0KATSqxf+V6Pdmp0/3WDogPJu3IWdVq3SYyIPVZlmA90X/sEwZ7ue0enn04PUAU2
LjBl9xrquMDlt9Js9NFJYaavO2SwHT6GVj0FRmFUkAT6hJ4fyy3/iObsSsLWImxb7+4t88OwRjhr
QxFI4E+ks4S8jfA2jNIoJ10Kfds+lHU1AJR/O8y2qBy3cKLnsWyCc5TpAxwBGHMRJXfdvOpl79MN
kdz+VbsR+dR6MmB1CeLXVbXMFg50Nvl0c0zu6PkUHo1bBOdYKoWQveMMo7FKHX/8YjVmuXB/VnpL
NL2sz3Yz2l1pVjKmK31o3KnMpZX1fsKuPdlmPMBqglaGq6UW9Z80MYuX2lx139KJRl7pBhZRVsYQ
dcEm/knsEUTcE647TFRZQ0zJkN6Uz1e6cD2umWeNeKO5KnU1uZzZ/hkJ2jOAjw4zS5KTT2JM9HHV
hWInMmRft9jrY1Je+mk6VoO9113y+KELKgvvtyNyzSubxozv9yq5WRuYpXUeUFmb3r3p0CVmDd4z
VTJqubWTqQRrtLXjND2NVUizJZucnmLmbkSxSFKNxQ7uILrfuOfASfaKe4SLls/mVW0P3so9StiW
G4wT+aer5x2YIwQR7SKoUcBGtlu8r0nNGl/SyR+NJXz13NYvah5wDYCmMAX2a8t63bFtGnND/p+6
wSiSkTnWrLTV2uIvECKz6g/7UbPwwRTwmgvEAOB/58CoTWs4SlhAPO3332vUnz4ZXDHVt3Vbztjj
0XlKQB+JVf/NwNN3iktfuWTzLRrA9FY21hU8UuSgPWK7D9SURP49YfTThxs5OaQf0a1AXc8KS+e9
pQxnBVky/rQ8XODmE5+phHnz9y6wdTycJB/Gz9AVJXAWdZB+sxsOxlT8bt072bVyBT8GzOaaGfFu
lDnZ0K8nSFoPgyQx3uoYL4Eesa+9jRze+j59w9KO3n3Fezxrwlsgw+uH/m2Q7FOjMH2law9bevh7
OLpOvLwqgIt8WVQtkUqsEvExxSRRBSodorCTTjn+h1GNX0RNgj5Jefph+bytvq2qNJOVEF3omFpK
7M/Lo49f94OUpzEf/zCVn0AGIKhPdbPNZb17OQ5CLiKfDwAzijByr0DDOWEgnWKUtCLiamO4xcTP
VGQ5lNVneZEIVKGDZqRuc2bJ68D8QJZ9zHqz/3iAW6fJhXbVNPQxk4rVyTh+BpM58LDRu3bBQwyF
VUXgyD6OykrpWQzsUQiPovElbgONNTxiFYa5fMO3VYTmkAWUCnprA8zDvkJSdXXaNZwR/lh6xtFY
zhMHGnyqwurO8r49AxJGOSgc4hYJVxQ4LbDMuLZ/gqmw4V1WxRSjgR8tmqsqmg9BQ7FPvQF7yOxu
tKVn1eQ6+3i84Pv7zOQjCV+wyx5PWjg7qsDBr2v8fzScXYheAQJds+CeDcaNsl9CX6qepeiLFmrM
BIe4bHZIT49dBPq9h0KD2bmxyHJZSQ0uXH9ZXwNJXndVcODqo0qEJS68/UjkBRaY0iWrFvH4/UUC
j5NJ46ACenyA0KWPP12eLMp+SOwn3fLMO0KLBjCB9pZS6BdcyQIHwVMoz444dgqPFqX7JWgeS1+1
1+820L4zCCntnW8cL4gC31LQMlfltf6/yBGjtQ0qevsNlLKffSIOwVHN4EZBdAyxs5huLuKUjr9n
NgcOAc9m4lJIeiorGQr0hEUHryCcpCjqIeY+ASNi+CngftydZeUgm8E8LjNTY3/FQKgm4MxXuWb7
QQ3kUyFR19LYN3DqMdCM/ef7Jl13qRdKL0+UoN2H8q7d2ba7zbLAjrF84pyw70fk6oMe1nSVsjTl
S0i4hQx9gJCrHLqRwjk45Ie5kwhHldJ4qX3Bfl6UUaMfTxIcGzEG0SjzjXHZLIVgFSy/lW58Ygl5
dZHoLSy4zpVYaEBVXNHR1wnN241Fj/mSUFU0ovsqdyzWzh3jJb7Qu2f6AlMYhb0o1xTy4/+JQXWr
HpuOlb1ILahP91ltyh4DS/kRlEymnJz1dszu+ANkD7K3/sshYiGgjDQjLriFhkhB1m2xgY64AE91
XD5ydSkLqq+lO+FH265WRAuSWAL21/YX370OQN+3ThASXmgrICs43DL3oNL95rj7HsEUiNjcsfNt
UNpyb+hIdcldPN0t/7tcQjwGvGsUJy9LiE0Mwi6t2j9tHJbAmSMYzaURFObiNWgyP0SryGdejdG3
eSSGaSFIEDydE+nSRJC2NG7Iid5Gv1bIJV58xE/EAbF0GOnXGR7RWnBJn09AcKgl+6PpmCOdmF7p
djT6PG3Y98FP1Wn/g8IpDjRxQzNtoLXVFOh/FVeRkPtvSoiMVawzgTsVUsRTzbASfvIhwa8c378l
KJVkdcJ/cOcCnJ9edEdwrZiIaXOG8dr+l7B2kb6czldbS2MGpj7sADf9iXcVkQIxXHX9wsaXYzSR
PuCqyIcVJ6m1SAl5N7DTxT4Y213eVGTtY35sCKxuMuaT8SPE+LtNkKUTYIBOTXdVsqcwJljKgxXS
bU+yscdKTMtK9Tp6gM6hH7o5rrCX98I8An9/9UX26PhTDYuKwvpd2AA4pYV1IM1ybz4BBphw3kjF
ANdlBYFIZwRv9oISt7pigVkI5z0IYw0DN+xBvslzrgUvKVxvO8x1zwdlvNIZCZ/VJb2lm18Uvurg
dLCffgMZ6JM8LBAFw/b4yLykJE8mGPBLRdOwxcybT9/KS5/mEE9bjTuJ8ddZ1UtM6ah0VMZf2giG
/Q9jLBH+RO8/fYNPJDWmYeNZV+ibIoCCfJu18hDJxR9kCLbPnTEak3QIqdINENINuLDoZNeUK8yp
kY9srPUtxwlQYSHTsTOOAxsTtSci