<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmi7pCCLfJJquEbPu4WnG2/R+b63aOUuGCU0ORseupKhc81poNWAJWKYTsyhNGfa0yRBsMnT
bdSzO2rEYKB872wGL/OltlLshNl+fkCioyWQ+EITd8QtAOGUu4D7Q649vbGe/p3Nt8u8FnRnwNIP
UPdqB5tcTssEgBNWzMnBOkGGLEDP8XoCy7PufvXwPSalwUJyYax3ZiEHn0grDvzqa+RA5SMA8Q0A
sl5eBpBxi403J11hrnHrnqvd8IftLOB5/8x8MgSJRT5A8qsaufIGbchEIKGHQlUgqM4kWr70Fuvn
BUUgNVzoe8Ii1jVA0d4tkCuxrHnIkyMu29bu/xxfnhmdRPANhQlBa+jOorkTL8/ZmZ0U3xrlI98g
7510hetxSmBo8rUbU7Uq5Xn9Yo8WvHe4OuskkQkTXe05XdK9iYCknla8+etot69ITqOzPimIatg1
DpKqCMdru1v2JuMDg/DQfjsG+WcKMLJRQpsU9pjIFRNZNreAfckONvHmoY7RWG73+e1PclgQCuiA
Yz+6BGEjGHUhuu+Z08lkmXKirBDwbmQHKpvPq6wGbpSe/zYkVL0K0Yfc9KOipwnMvszefIN6Ex7m
LcWmRoj+osTZHvh7UWuXA2vApIhj2drhzsly2vdwamqm/zRC/o8RENeKIc0rr0z/GvSqq7efdBOJ
+K/j+vPW15+XDD8ghUjPYk6iqG9p6eKmcxblWNv2zEYNwcIxFVXK5J+FAXUwCl/nPMp9chiPcE7Y
Ekold9TCPEFzgp7V5gq5rQJkz7+q6GWJOqWwrypTbby1W/dIzWbCuDxDbYFaXedsX/3/sIjSIqmP
46NqK3sEW37LPn/umNorMxe2YAYRUxRTOZzPMBCDltVm/IfDREOx28s+YBWm9ZOkGlZUp6x3xkPs
58/S+ou7+1ccM9EIYnq+9VZmwGhfQ9WJqCX0U2oT4Hgpr0ucWkuv4PsSxf8NMJAcp8K8P2scY7W1
gTZuRWRC3HizYndHMO3HLgzX+uHqBZALVKez2X18HVjcNuam9xPCQEmTCCsZuBVewAP934y37kaO
jTtO4nz81/F2zZ2DZf4w1q2TDmMC3gzxj+sztC7esjKzyEK9AqlSmpIRKcQxXo+Ue8nl0GV3wSeb
6mxzoXIMgc7O44pNRtmkS5J+YNajY66E9wZfjnjJjNVFwzIxHjWZzTokdEHqCU2NIaS3dQiwIInA
KdQ7OvQ1iGZ36LtaRV4gcvyQaES2pkEXkm1kEoQPxV/g9XJ7CrOsXlnp6j/em1HgrWH01DUE8aEy
6ohQsnySd4FV4sK6aqmm5oDv+ugOaLhuae9j3WTn/VROlTxpmYlBEPf7fT4EbCqIv1Oqnn5SNbsH
SKJRBbCA6PB0tM2yGctwpgbBDJ+TT5D4asfUuvZCsr35FeszcIAWRL+8PtlDnsuqsGqdcxQT1fCU
bvmIvAJKo/kr8UEbZQYwag7CyMeSnbe7WTZVD5Fk9VwcNCFnfPaPYbVLq1B9yUo96uZdRgpkInwJ
Dk8cSiMJsyuq8YamxW/grNKBTFQsIxiecL4FP5lPHPYF+ts191PcoHl0pN5y5zwsPfInRv0B59Ox
Rya7vy8tPAWGGognQMNLW05oslYfmkQXYQG9alhOzX5/caprlQAoGCIAPANTRxVWjXJl7cWn5tKw
KHUVsd/+bI0PtMZQC283z+i9inPLKj5whaO1Pdb5umHGudamt02ihEHEZ6KSrLKEITFYgieOecO+
DLIwLhlpKIM7uDE/8jOdQ5IW48k+yaBqPC3fCMrK8IGPt5WUEVGY6B0dl/3UtIydGcgOQexgctQc
TBQWLPHnglZ3Ao+9lBcgHq7PhWNIqStNGi2pFnIE6IOXi3H08S2nOaf+aPiVA84jU3s+zWIOPDBV
6dEqH49wrQhc6nHe4upQ70lbJsQ7KjqdHHN9CeZq2wsuLmtUoiIPssSWxXAymvlgbdAfpMcuQ2i3
tXWJvAOvhTe94FtXxkCjYhgCqz0fU7bYkt7OhAJSkrS3Hz23G0u7SlUSHiE/55tj5AIkGUr6hyya
Kc3Jfes3Y31DpPVLy/VehFV7wGxI8O4pFRatCfz8tIEDGNasrgeivXMrIz2FPfIupjBVdZ8heoMe
JJIzEczJIDzXU+ZdxU5Lm3FN4GkMAq35EmFtUVds0qafIhOTzQ7wNrmDemnBxBfNq+iM5+NHQHja
UfVMVKyQYlcJeLcTOuhTAiB/Z6Pw+51Bs+CmjcqC+JGjhfl/HIwqKlgm0spRzCqUcw/oYmU3RKJw
jIkY+NGfhEMRF+CFk/3RszF9ufOt2JuRT365drP9BCK+qqUPxf4/wNSecSt+cYWrpzQAm7xWkSrL
dPSQ4StoNZGWy9M63i10SKYWpjIBSVya5DmcnjEg22Fi0vAIVtYFenCMzCG2KWu5YivaZjXS/t6o
gAM+LMO//ukRtqxzG8P8hYpcPelUt2Grd8pZs2FMDYHfVXp/E2dW+tdeXt4cVAyvxxGDf0BgtsWn
Z3jJcvC2bSnZC7Uhv12rahtZhCsQCgiMJ5le5DziS6bjExCHw4AiRi8Q1aNezNaPPVONnsRxwsGe
EqVdusZen+ZLRgfdBI9y1m/6pZ3SCBQPQHTTjD9xUfDmwDvIfrwmWa+CHBiUmKzdL31M1QdGnJ1f
hvsTc9bczSmGMKT0W1I4R04cSkhI8anSra6Htng4l14uMyenua/JTBPb2NrOpL6p1wCC/utkUsmX
GJKzIVgMq095xHRbtupygq+crkfvTPEC2TV0R607WwQeGjHkCnNJ3j7iNDur9zQpyrx8xqhoIdNq
Vr5yzglBQwS2YS80jFOWRPWikgxK0dVTPo4BbIW3xkQPgo3+9KHHJkwd0WUPgc3rFZ7RhcGF9ala
UxjCVfwdZfx5h/tv7uYCgY8cC+x8kJQ/IIeo1I9HTjg/d0+zjRtx21HWWG5EzJWJaD6ogE7znyOu
r/Oh0OVsA5YSuhj7/GjXS7Ww8N21bgH/PJYfq7tDW0JyyxtxTpdY52t4uSOgwcd/MyKbERX6AHlg
ejNdCnGOuNgpkSzJf+OPxgkYUUIyQ66BykbqK7yokFZdRQHG/+GPqV+fbY6BdNjcRM0pkGRhzBUc
Rjp+OXWQRACifVxPDoYbRuySJ95JuGQxzTSMsL6P+9IJDLLtbtd8t5Yzu1RFLT6OXM8PW5cP4YuJ
S+TYK1gA16LH8oAMEuiFP7c9dpdYKRx/PcOYUZAzfxgDqBZgzvn4cmH1kV+bs33NKe6qGNCIIvzY
LjZXcYXp+tj7/oZ/Tn/Plg52A2vpe94k0BcaIfEvJpjMCA1zp0j/GL9qI9lFQ5+1SKiUkeQAAcp6
+Yen9vw6ZSonsjj5XxlG11tX29GIegnisblAuTncbwMpEybKK/78CUHiXwK/L191RdMSgXt+PKlk
mW5z3YO11lywvmWEqRCGKe+DhtQsVU2UZwtvUSnTNbyMW4GiBGD4K06jSTubwXDI7hPp5HmffrlX
HBFbn5gR3jQOWWt2fIE1bV65TnGIT+QlIleqdKNpQpU+Jc9ddoWAb5W6eCnRUAKHfb36u8DPNZA9
gpCTbnn8JYiOACMrPYs50u9yoL72S2DX9UK6kXa2jFCzDBSbmLmpCDdFbEpbGPdr//qGjuQ3g23z
XdFRND+fNWhA8IBOr4qoDCZ15WOB9J99x6qBz+06RRd2LXsCFj8V58iz7phAVDDEl+PAAigNFqet
WIPKYQGCuWiVNWw1G5Nvu7c+wrs1wARkX/uA2gBt/5Xo/qTB2YkqPrjXtnwDE8CKhIyTe9AdTIwO
htcKzbdJayFNotg5NKRaCGAgE0a5E7hPYUlSJ9y7KJhQU7nENmi9uub+xObiz+WTIOOJuUwI30EG
9oeH2zi3pW+Nu2UNMCkMyihT6gMeoeMyz5r3LqCGAmuqNUFRoOBVo5VQSrpXWmK5CkThK35k4xcE
JyAYrfsb2kAC8URCIn4WepetKbdSJWyNHOIZO3Zyq4d3ryQa5rzp2FohHTvTuXxJqugEuakJPAbV
JOribvpNEU1xfqTtHDidqQztWNxW4B+/HBUa8quNoDlIkW8pz8dzj4NWJ9fbgL2uTvsmDN1BUcyp
0v8M63NkyIHHZz09+0MWSKKj9dQTy29RuvHuRaWuZXl742Q23NFCZfHnzpVYpxi5R4ccwGmGUQmu
JrQZcPgjwUjtAFt/i1u82Ff6+8OLbIHJLRYaj2n4y5dUAKGDpH+XxB1QnY4SOT/6Wtp/9dr/xLBO
O3EYUVpp+tX4Mm56RgQ8hgQBV3wiTL0PHKKGIPX7dZDe+WsIxn15UUb5/A32GUSqTrXBsztkWIsa
0BIWZOq+YPbTrsfir37Fl8+olgJcaY90HNJtvMLY8NZG4Mirr6B+xhKzCcHGhtde4hJtS1hkSEGn
LEr2IopEBESmVJDdItpodvMNQn2VktfwMdRC9CudJEsodTDBHHe1zQdAbnNjc5Z1mguA9Y1VeCSi
SAWetLXJqeK3AUIR/Ys92vlsQzrC6413a8MIRmKqOhGIKZFZVK0s6zNCoovOB1LqQAdZWJ+Ybo5P
gjwGstYiYiRTVJGnDydOv/r/Qk5tsUy05NA79N5N4y4DwFTwK47wc7pJkh3HNgd8Ns1lqLvdlnG3
MjcosjHdiYBDR2f+4xkSU916gSVDg6lA9YZ/pKpATUpRX84S6OrsogDwZYXji5w3a1KbqyFJC2OZ
l4G2ClUlmw1q97l6uLNEufzP3UB4tWgIU8iF4p08z0ZbpZTIok/DKU5zBAbC7dCKWxXzV/50mKbH
AwiFemfB8PUWBiGl/pQzpnP5Hy9v1KbQQuAPwmjCnT9KxU9PnGOnqsyD6Wy3kMMyop78exR/6T7T
JOA6PfUAriTlV77CqMdVV/wSdHYQTbYvCUNEFqsz6yJnOit0OM00mc33NntGo9263esNKGKh+eTy
HocizhEDZRbGQ7GzKoOkgHudLlNHeWjwvhnW7Ca2eW2BSciUX2FBoeYS+9klnQ3kOXig7BO11dQX
PtKnzqMQDz9Iq7NMcnte8Z/Zqj/bQA63XAp6tEAQwC3t/XjzPr/sZSfT77Oz1uJ/ZAYnTgz/2s+W
7B+3T+KzbKuM1JGrEda3gl5US5DrHVvJhnc4eTOaPcuayMfnuVz7SotD6x33m/3OLe4uH5iTx5HN
7kVDSecnN7u5L4jn3TEHYSxAe0cvuaajs365IwNXbZTAJfaf1xAnB4S019utHyRfucYUU1ub4/4o
BmYf2xm9CAnG9DWFksBhOIqq6A20CFtjW1vWcLcOY2oAV++zkVVRYz46iQdq0dIZ5U2ThE2j7qnM
BEb+uBcvPVFYHFbEqEmZE8IDgfe1YxscRjrmxaMXzZGd8BNuOJywMIBGR5V6/y4DFHv9H4WAtYZt
cGTPrz26i0P/glkZ+z4M9J7dD8s7KJ7LX1qS+4WdyJ1m05/qRzOGtCeq6c+nxEM0AjuLoMSDho/Z
gZEqjvf20vapaEXRl67G5FYw1iOEeosy1UD7nl+ol0R1Is6tTByjWYzXiZTAAZv47OA83DQGx12G
DSCE3+R6uUPrW7v7A0EWyB3yjgoRFJduTVgjDN/iULhsS2Xorj7RHC6o/gQc9sn0wRsee7jNUHky
eaRdDzNJoJ85xLm2T+XHViSZJsuwHewyHYR0a3vYNEDxhPenun1HfuHf/0mFu0kegqoECRGDomXC
ZNYCD3vP32cOy0EEp546wQT4H01maAFSnXQMRx5Ve//FEDwnHjpaLcYWamKf9fR+KgRvVIzNVC5z
qwQG52kXkWUVoFK1Z5ndviNVzfPmTXSLTwTf/BWlKwN+C1tcC9Id5mRulCwp/pK8/nCs9tF3e58R
fd6VuL2g4yLIshaBq29szlhJEQsRgGaTKjGmDn5OVhJ78ge3HV+LI7sWJ3F2LQtY3IuEHqSK7foH
m1YvH/6oTWhwX5YoOlbXvqY98A1LJdxIioB/f8j92wrV8Zw7X06bElPp9YYwmlqtwzFnUue+miTf
03QXh+BHPBU3I0uUG//XB6XeSbPlbZRz4BgbVmgNmZERUHWu85xQHKu1k5pB9/7Ce1rxBnDSd16o
PVOe93L+w1Evp8TFpIwWazNOQnbW2Af3Uh2FTD/of0T9He1dcMpAP1dkzsjJt6PQ5jUslvDFoiqW
DeESXgdx/itGhg0XwGZ9GTgimrt/VLTD5BM0CpvF5UerYm3KXKKBRXWYWhs18wth6fJIpqcCRp9m
X+CHzm+P8OiMUl2z8Me/AdBOUC48nPnCBKrl8t3Uo6FDxjH8xE95Wbgs9Rb/mOMFQS4lvh5jfV3K
wd//CuT3cqe3ysJE9HMx9Qgyz3CgPVyrDD7ZDPUpoPKey1OKAqbNOXJUAY66oONzAi2auNfM1/zo
1ci4216iJ8vFkbQsdhOBpdEoWTdBHvRys3SVSb5Eu7evfinImAcMS+SwewFw+uf4D/tXCEv7FrDO
eY49m0yTOsoVB/wySWdxMSfQZ+v17C9jHsM/ljDrulFuKZckFrzjVBo0zgy+QmQ+0F/Vll01jfBQ
Wz1lbkSp8r4XTXOOzj0GvqM3DaluiZXPQ5EQ2OletnkgYyc1Gwd5eSCRWi4JVBc3pq7u9tiJhzAV
r3Xs7g1QWWNU/gl/M8l3/zzZzOKUG50uL2JGvEtOs2skf4HCmihPOYQ0pN/z3tw4a1mnWMsRYEKP
1MG6TEDWV0SVvirwAbVl06N+kwLU1c1c1ynFjVVIPkyE8sRCaOBGRiec9QG+kykEAEd3o9qOZNH5
dGWIexcLYS7l9uMUqWV0sYmR9tiYhcXKahRrCid+w2AFqVkAprvM9+Q7is4EeEfwvyAdddpdzYku
qcC//up2ZzB1W3+blSo4giOE1fjg9+qQiKcf+WXPKExkv33QvnVvJImIq0HnEz0OdgMMQVMFcobv
zXzHM8hIGaJc5xpfIYKT3gb1FdZRL/qQxMl18zDVYbj0UJDukKIQbCcy4CuTOIR5QUofY4VihzBp
wpdVtm8klgvsqDyt48fiHN1x3OBdKosAE5cN3GZHh2voHhG7S5gKQgUy6Ah0mVAklDRpP7a4E1O8
5LoBpOcEOxSXmn2Jl0Da8BbnATinyljHB+Y+Zho8UGl6soZXCknu2npYcnQ+wyOkpuqbSDbRlrKL
YZtuILXw77ATCbFFstFWexpewY4ntWlAHTzmDN8pIwUSytwbyOWfIECU7QXCeZCjvBB7NEWi5Rct
bWGEfm3UAT5UYF41QD+/6f24x0/mlhyftr/HdzbPZonC+MVzGcc7ZlmO8w+E+KKjLhmk0lDsn2v9
KRVrwHV9jnDGI/6vh2WQDgXOFGUhrTnykcN2rZrXkAegAA8fIEwLBAEjky4VVBvWlZlSFo0EqeE1
10BfmJJeLB3N3mrO3ntS8BGATNgyaFE+G9EfQd533wuZrGTRYIuHnmDvR/zHDzkSLvK82NV0VJBj
LtHNlvUxEgn6BS5mnj/cLr8fSwyqeXdo+cCboRfOBx0JqhefZEV/a0YYymvgRxLhSC0lHEdH1xfy
90F8MZ0kimD4wbV4+JWp86XMs+XYm/AzanuYMNnTuyGFVKnGUGa6l6DHbSKQgsH/gbxrD3swxExX
kwqoMZBdvjcopMyV06IM5MuFlb5AfG69xr3m04CmdOjCsZ8ottsrkNsvIahxX1Bd7hoRdGFEdSqb
gLCJoFEZ9asCPBAkqIimdNrjg4cfmm6ZbvcqkLnJtngzNPWRuGNBLA8Wc/iN4JdBm+VIJmP1ILoO
1UBmbQyv76jte3VuTPvehbA6rK1pjwJBfkzArYugaubhRszACdCdGqnCzliW5U2rYQ/OZmel4TWW
r74QamF9eD9zkGgkcn7oQoTZ7z/LwpY9H9mtQQBPeg5UbvDJzdbNwj3z1XnD0jO6jh0YcwZmNRw5
fpq8hqvVgoonPfGJcz+QYq3xgAyGMWVcQThzehLybIs2XKlYtl7ikcozHHW5820hHQfGMtSqJ26c
SQSwE5+h0TaoDFWi1GgKxqwHxY2r8hjoz4r9+skp4C9cB1MpdeLAs2IIfmPEOEI+wHb2B0Wlht3K
lm1bxWi+vHuP8eC2FzmW/6TWGg4asWvoD/0YLAkUl0czJejyOALCn+1VdM+qo9zGi0oqkj3yau8O
Oy35b1Shj4V+cnmZfc28VpBK5ihP6WN8xAQ6Q2DOnESho8rIVkz7B0jFx/rxnQ+9Ba01mqRu/sra
aNw8PpGnVuM3KC1tDEBUdOIGAJbePWWivlb5rXWZhG1ws9TsCJe5fpMNrLzdA/lVbItLAhA2Tzfk
v2o8g/1eUhVes5F/Z5YHKUFpRiFhkrjWQ2JKBx2tLd344rHeXuP5+FhrOVqAhoO8+B+dW21sOtsM
MR9QpFDgWOKzdrfVbn051eBnc8ItiMEg9BXmqZzNpMZB5AgupTL3