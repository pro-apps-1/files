<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzpXC0BBWuaraW+b8MI8fsUM2xRSB5c9g9ouzQy9wmH5ehpwprwN9+nWvWd4U5NqfxFLhPUu
DFpRXIqQUTEAjd06bNXIfFVT9E2Mw2JUtEiIuMAGahzSOJ+9oFAM+cxb6emhBhUoRD5A3oYhn6Ym
U1lKBqPadpyXIMvp+I2a/Oc5lry4aNI8vZiACQLDZn5UgTs+ITiGy59wBazxQXsfSOKLiWCSemKm
ma+d9PXGC5ilO3xgl5sdXNak8atsR9Qo5Q8iZfHpRblOCEp/A79DslgBtrffnR/X+X8eF5/Kuypg
6UqoUHF0j40XQoTv5pO+kqvsYHU+zfIqi2VaGmuCyN68LYFEt2R7Znu3x5m6I7GVfor5BB4gwmTl
EnfB/bh7XxEQ8HR9pZdLPr97CVeUrNxQ1gFhYAtcQhMovzdW9Ik2fa2BRFEvmZFXUhH5NaEbZTlI
KPof5xQEpO6cK8+IwnSPrZzSta7YHoU5SLewrED1ExTF818RCpLw5PVc5I/SbyCAQC2skQI01Up5
d8XmekiPGurX9CyqV7JqCRyBYk4ovlp6i68+7lj4TH4UvPL7ApjR01E6bbRhRS/Z7P3HPZGwadMy
YmsQN81FGU/V6+04mPZOsgM6tc5VeHruSwZpxczVaBKAONX+pmGQ9bZtGC7TSY+M3K7ow1BwH1k0
HJUkVvouFkER7AUBx0om/ov4QcBQJkqUUEWfEx9QUNaqK+ta2SdEMDuIYAreATAnGNa4FkBKPbhG
fVMZhJDzuth9XJhZGgp5jDMAs8ftywvOPj/vZt+LgfPZwXj+6+Es6PmQXsVdylszw4GKwHbBnSIN
IN7LZ7oJOX+Gia8K2hojxoSZJkZl8fIlFSdGdgPztcL71ZlrFvG5XTJwA1RV7Ne+3ovk/ALmRYmv
RGxtH/RDtnFkbBCTNdsozWSrx3deZUl08gsURA8pyN166wvx4DUWudUnJh+Ym2Yza+7XmGYZRVL8
h4kchPY78WSKFoEDoJ3IEoFJIcWJQ2O2I171B5VNgZEX/xoxPMMpyFHmQGViNlTDFILmJ9jl2zjg
kd4OCDAU1OXmMpYS4/oXwXwK+iMv9340gwSM7aTPCu/WAw7TgaVI+8a3YnFXzWD3MW2qBDCboCng
KnPUvUp+mDQ6aUt2m1hSvSh21BeXiiKV7NfeDh6udWAR1K/LT+riKb7mobAZLsjA5CtzpGwIEYDs
rQD3zgRPQuI6zNVmPIr7o1OHKYYcO9x5yDmVwT8NaXNhNps943SsfNpBOKkex9F29VM5pUcOtX/v
Qv2LEc55N3j1IiweZKhiE2N+evEYeb+pQcPHt6drBg4Dpr5rVE4naYtOgkzndf95jFOFrHp8PBUZ
3IRLe9DknPmXeGfQ7/lptWA8B94oHxJaV/gjkpGewdv3AaClH4xc5EosC0ufBrMymoBMBLnjYkG3
u6hK9ULTOgTaPmCtWSDRYyVvqeipdNuI3DrQzCYbI2feM8tolVfwsT7HUXsboboyrjdvC0vfkwgE
ZSiIijBunaLo5wSArcnFVFXebYgVbqOeppseXLqizMMSWR6Gr7ZJN4+XLy+N+s5ScyYFBUH/L5+6
vuLo6J1uI0H30WEfOPBCtfU8S8VcVR3Po3Ir8/oAkITU8YXYAZluRALomP1Uv0g43aSjNugPRHmP
nluvn4WD0NSpRhWr6xZITSHmzOGgYlrMUH//PHgI95bJ63jeYfyLwiQ1VDNmgD0JRr2B+0ke8I5A
L0ZVhjcf4s3EsUVcQnvo9n9GkUYwVYoyTi0qloGV9iRjiXK1nA5ZyO6vuxaU8KN0U7pA+En/TbVt
ZEJ7BNZQrU27pxKE4RCD4Wcb4b0iaybLjf73iNwZ0NUIYxrnwfcMIlVFL+tEarHPgHptXAOlEPC4
YScv4JMXZOq2w387ScaDCWjMIJcgZHIWN14jBN+hU2kNfaXoakfb1k1iBOu63SdCcS+3cOZ3pV8+
8LR6uumvkj55sBF+8SGS7AmTfd4F6CQAPQ+V+FBAvrul2Prnh1XosLesgpqvXGv/jx07QI2hBl+Q
gN1y6f+BnqAbTEgG7M/1mGezwVbPNkKeVTRyHATnnu8ihrPW1Y8NFoGhrmR2QepLfeVrfWdpDspA
COmfJSrJBWVDbxCUQqoX11CNa6ggQUA5E25HmGQUR8zSWRQtyO8goF/SRUtftlY8wca3Wn1yVjM/
COiByxjf9Qmrc/fobUxGk6S83U+6ib7aCmWznv37/78KKWMqLKpkE0DXmwUK3+vZ+qfhMSexz6y1
h8Ru2bj/ZhIYQ/uxzdMp9SUeKy0MbKGRL8KuEA6f3i7fGWKgniw7oNjuy7XDYz+uA4wz2PgikUSE
nM6mbpLHCf/oc+a1898fTz4x0Qq8GMopscy3/wCZ4Mu6+d4ok8UQWcTCqXrXNLLXGS+vn95EEOOg
h8YMfB34lzO2N/By0UXWf2jia+Ea89OiMlPB2W13PXX+r+5wHca4fsqmIsdnIPBDgukIMdS7lyTB
fgf+hd87/f7t5YKWAvBNyjwMGSB1O6xVss8giGNHrz8R0od2JoisMLr+hFPERUImqQZXQHHgu2cG
atFNV73PfMgjTIjuPqvfj+8fimNyaoA+FxKmhF9VkKXJdZGAqqKBkYPk2Mqt3je0eZAIjUa6g8GB
OpcSHSzGlV4TNj0oLqHu66okU4J4xyIVD34bg1ybqpgG3hZe3lH+uPzltqD+yLhLYCsTW2RkUKmp
4KTLMGzpoUZKYl03KS2SbyPzyGlK05TvGeDS2NFWIPfQPHHZI+u0MfkG/G6RUfs+1n2cZ1GgTz0a
yTYLl8LpP6HwKlVYPwuuvvzgCPe6tAV5IMfCYbOXTdl58DaLUPwGbJjViwRancn+fNxTqZwfOoAE
c7o7JS7pNiYLRMGqGQ7Uc1JT+sIhvY3vKDB1sEbBtc1niFNxEqG91GoAf+3C/yVe1jnI2ukV5sS/
ni7LYb8/KviNZ71FDqu/K4yg+t46RgpUbtHV0FXUAasqNGrVve8Y1dTroUTD/YXVRIpN+FXfB/S1
gkUlqnn02GHl0jded9DpCxmqTtXAjZ+BOCZjO1ml2z1k5FyD+9kKE4XmX5bK1oH3a2sI8w43/g/m
5eTmpqkUMu51ud9tabr25IbSTqqvqYqmVORJs3Cq5mUziGnLw4JS/9fDpV/uw7dsQmSYDimmFRKb
tVMNoCYoU4GLu451isvqvAktnoOuxqaQ2hBIXO5DVdgs/2GKGT355Kzs3fvCVv6tTDuZ0sfzuUsQ
KSGFVKR+1SQz+ecNtwrkKRWT3k4NpjtjKLqjSIN9D7xcwZ1M+05+FjqDowZBeM5JklFoj+loXKt6
EwjeK1gN25XhBlTDsI30PGL82rQCyscGoIz5ga8W5k82yM4p8y08YKVeNoVKSyyNnv6dyADZUd+P
/Zupi8rfD1XW+xjTvGj7wCf3jFIvhSa7YA7m72j16vdVRoovU4ATEmQbPeev5T+wTL7Pys3HkFnX
pGQ9y4Xc/58NIzW2xOD36MNsQf55qrA6JZ5h3LEAn+A1qMqPs9vSoOEmLhHuADd6TZbLN1iuGqyS
HsZ/zABJO1tqgDyt6egyD2vjG8fQmAumXNvRKr3g+HciUulMe77kG74KfYkmdFfPVk6GY2qtOw8m
G3DphOut0JcxvsgSEllt0D9WMfFxvgxBom149bxAQeAVnOosPoz1PgnVbQFY8vJtKS2wPsz8zRRu
cz8FA9m7vbZEKDPxiWFiGfbzcILyB7MlYyNq7IeL4D4/ePmJBzXKMKt/MCZV+ACHywaVIkeA5tS7
woLiq9MY7mbeycveYNUCpPtiuspQNaKtDFzN76Suric4B21WRwB2EEY2zrEqjTyq1eap6eEYYLE4
hxnF3RubUeRCWe/o7vutCO2qbKyQPL0bDcbGmXLbKN1tzqt8d6Bc17BVEG+CYVS4IATkAQqTzzKn
nB2N9ueXMmKn7ITsi5hC/1KrBJygayOxmOhzdHQ4ecJczOtpEY2s7xKZK3H6kE/KDfFasKLx0ZXO
jvLN3L4k5rExszA9n3EWujvsi1eZMtHHJ0lsBmfVCKa666JFkRfsyYHgJv7tA1aML3GlFHkql9xo
nDcQNWvIAAsmOqQJSV/QGD75TS1Vzr0H5yQfLoCIWPD6Oy+2hN3d1bXaCy4mfrzXhkenWDV5gQMc
cge8T+r3vKbH9CYdHRLuhgX2C4J9ZyLaOqwxGQvpwrFCn0+CAuce0SED2je7K9QVPQSqwfz6WtlI
nBycToUgJJai08bNXGKMzXYUP44ER5RPzTgtwKKGOcUf5/WTxuDARwrwxjtTsVpTEpCbuJ7S31mw
dYDOY4dozSENhXOSl8AWdiV8HB5qnaL7bJDMcFJ+zFbeNifg7szinfNuXohZ8ylDmPuwTTwga19K
mXd4bVfDyodjm3UVpEXESHZT7gzqNaLR/Xr+jli7Lj8gmEnWmogdb+4W//PwziAH130cZuD4LXe4
IUqzVVtbhgmFxDHE+c6E5sR4IL2lgC+M2BxR705DbuhdtDYKlVRcYluAppZqoCOL9zuQ9XqMcl9m
yq93PUvhpZwej56FW3vL3r0dj1+CsWU0xgpyZX/B4gmQJxhae0QGzp2+bjPEM9+GvLm5IgQvo2qR
1kqw4DLjK8I/VQxvKZFyfdIarCyhMPkSwWNqsODWy+yMosnmfBPFnthggj4dL9xFbxGO8upmWLzy
eZg1abFKtdXGb5wvCrnGDdUgBmh4WfQPtQp2MCmCdErFivjpJ89sqiw3udTvnCuI7f3WVSKJs4GR
zOGLcyE403VHniT4CG5kXBiIIk4HCevyI34sYQmJX1fOssWa01SlP4O6UIS8ZeO5IYa4Ys56og3s
yKc+DlWlhdrCdGJjGQSerS62VjAi5t1EwB+E9+HaFMhvAA+EbK9S4/9lG6Egm7LaVhEmYFXmszFA
tzQjieyIitkI1gU1V4wGQeiFYFmqDxhfRjsbRCy4IkWC6dpb109PP8X0K45mVw/T116p8ykfO71w
KgdsMquOwtBxaJYKnKI2Wnd2BoKB1PZER4V6Iu0CJnVXiKn5klJ+Ngug0tK4UrtNKiCFe/664bbd
UwrVN0EI1cfOcxVlCb0jU9pQpo3P2n9RxxBjNqBzUVmT1BGLyjoYCfkau1mw1lzHeKrNPHel9Teg
tJ9sc0j6qmkmgCJIB3wKNnNej+1p/D1TcsPtVCZuuHQtaMIJAmQIkt2eC7xPdCBevP6w/MrgTTsx
IYVrTQ2B9ACR9LIUPNBRprsM0qDVuJdzIV6ckGVH6CAJN0Dh//x3Yumx4koXmn9SBKBvWtCQj8X2
lFhnKkctNo94Hb6tOTGsn3WnQKl+EKV1ACa6Mgx52f/OnA7/8CRBV4Wzx6x0V1k9xEZ5eJ9c7aJ2
tia3BmjzzV+rrzNb4lyGd9pIwieh6QZgjhY2WeUHIdrZtLbK1DSu38K6zSasjlPAhClIYbob//RT
6trW7VGEfCZPfiJaESA7DWbrfht8AaTI4di7C4AR05KkfFMFyubxYyYq8nLuroBFqYTjYca7r0nr
JQLUyIqUE4ONYdWLli77IWOc2wp4HysSYORAibNNlC4Inxl0fHjZTWp4RmT3a74z7aSkpGlI3Fu1
OKSnZncyW7i1lpcyObk5QSGeOQip1EUDoBVbI2B1CIK0mK9rCReMkyqNQuuXIb4K9UiLxgQaixhM
FH0AymnzdQEjeef9lfwLkcXOhI7d5IIpgME1ma4OE6MZt/SVf13pytHWGENZkCvjP6rVIG/uxYsU
8KO/C4JEPagSl7Axo2b3l/Dq0zdQkn0LuidutjQHUEaM3a1ejkYgHlgPn0C9SGTGfYuSjah048ui
uiOrNvxHKLAOir0w+n0YNfDHPQDVq8xq4TXQHRN9wWyV16k7LSUDvFLKGTluQi7ISZxyDuTbkdld
jcaLnUcVirJNvDBIDXVsFiZBweBN1eeXL99dgvhVvuRc8pRVI/hK6hXCmASxQvdpLvt84YhnTB/J
9fBi/acYxtK1Pzk0iFH+rk1h/0+o/6i50STidTf1xdb/4Wh4XOrp/cIVRQz+TKdQdOy9gGcamlc/
f3M1BCyJIWPWR33RfFbCYRLuBE/RqVAgo14OCh0lX+3FZFduZtjSrVJIV6IqeVLL3ZwpN/hZXRFm
IWFxoqS3HIWBGp5mK3gHZMG966HpT7PZwD0x2l/HsEliqHdR0zkGoIyv4dZ1h/y5/qYoS9VsmxjJ
R6HSJdhP4hS0KEXdzyqJXXPVOUs83AW3dEcVvKQXYU3GtoJ8ui6D5X+LXHVdKZMkKW8vieEAaKUy
igr72ab27zcezBAFsdng1tB8Su0sJX710UzaJa+xlav3+ncAstpHCKNZ12KOqA27DdkoFSNdAPxt
/RO4L5uOgKpmHMx4DWPz4ngUuaAr1Yeg48dKPvzfvAF6sjdSlq4Ge3RxQgHOnAf4K1H+TtJNSX95
xuecv37CAeYSrpvgWDk+DKgqKUHC/omfciMKUqi8pahHcBN6VHklsow70ZTrd8rc/6LOYX/m5UPY
9Q2nR3F8P178ueCJ4vH0dqY/1AGMc6yVO8uBVl4EwhN/+jVGuJ62YIpP5N164D4kXW6W599rIfj6
f+mcdrVW3i+X3dpQbcM9PnFT8R4rMKmLjND/qw0NTTiaytrjGnZR+gBtzSic96sQoqnCqbV52rm8
VY8Gt70JyMRAQuZ9x5Hto3zdJnMcRXjYYphos7pKPYoOimk72NsLBc1qLPQqrrEiYBucAbQupI27
4NOHROzhOtFd6KV3a2j7FPQM4CpG3SrgbKzzIfWkP3J+ertEXtAO21WRYJjcwq8NLH4Qjx8E7yue
owXV3z3RYT1QjKXL6rQ28I5DWN4LaTO7zr9MGCBPtaN/aUONEj1HQOuKTc64jVv4vkiMTdsHytoB
gsN9uu3m3UeUSyOFfA547iTkXEyaNEeQYT+MOm73jFhzXPNjzpXEnILWTOdtJqRxGZ0SWBpVdCdD
26QEzwgSCD/Ij8vVWn19WU4OXkPaCa7XmR9QcUV3M48jWe4o5qA3Zrb4bYSacclcTTBcAjo3Dy9r
2DdWMEJUl8arUR1GOW8IEfY8QlQfLV+lqnwe93u5VOyZR77QuKo1/LS+vsylGsYI3PWYcUxdAGRW
oXcUMGA2SPjdYEUMjxPiXSWzDvlQSvyiTs9cOzpd88Rj5cc3HKarY5FAP4Qm/Tq43IjcBSFZwFBI
CPC+2eiikrvW9AAazFBwJF0BeZ1XFLFJarLqjHCqLGnQZbLK0GNHEZ1D4DO3a8Ua8+N/AGKK6k3I
dwxVAthuHvhwr/b8jLERo5VhRifFkQhLWHfXLPOAIW/Ck1PgZXzMvmVVSGMftlFxLsIjJtiNkk1w
V2tnPRrQHp7K4x32MCCAj8OLOtjzoFSJQSUsNDp9YgLiSx1Rqf6fW/W0tTpt10Dsif4KddeAclG2
iV06qUk8U5XU2ihhvQrZ0+zN04+dIK2byogHGV8PUM3EhcFDcyuVSkJcHn0jZjuVeSuCpymUFNBu
0Fb+0ol5sc2bcg68jW1HauxkzKibK+P6CipHvNwOLgPUCKbS/xSWQewfDkra3gMR97o5KugF4hTD
TA/HW1y/B2o69ILjlD7IiFEDPaeocDR+Ia3GoSDBfyKekobSQuB1s6fb3BQEvghvxx9aZ1oiiv2g
tIH8YGjW+PHNR4Kvm8azflsShXXuE7KBrqx5FuZVe3LMfw1Koi45hzPL5lz7TwQIPugkH0/1ST0e
SFXcyGUcHPfdhJ2gqp/McsjtrzcJBGk1a5W/tJy7y+UmbnYJkJ6cMmU56Rcr2pz1GOLOPUfln+07
tJvmTTUGYgO4jP/Pg+W5KZJAIn59KD47JE2YV9AH00YLBQ7cy/bkG70A3D2U9e+PJOf3hLkMtZh1
2Diudrnavop/0Xjs13q0irEUGBqYUvTxIIqAG9tfgEFmxc45zK1qttNAd+NEM8hg8RbTVV4/XtnD
FvI70GgMm/eWhVGDwZxgHBs/Swl59Bztt+NP3su4kYxzXbSCugIurxfk6giiCoA7CbmEzIUrCXAz
hdQUPFi+UgHylbiFx6k+UyeVZWdC9Ua7ZNsJfBkddgL4vouCTqwl3zc0GdpHGjpJmXi8OEIb1f9C
TBbqSLk1neIquamhpMUm8s5dBdc+uovtOju58EbLfABS0TkN3QbbmzkkbDc+Un25KhIGf+S66dIP
+ji/e1L0U+0HtaNbm0Q0I0k9L4TJAYVyat6Rn4nu5kJzJYx1TwXEwOJN9nD78Pj7WCsPPFr9WUm1
/iF3um/W7zZkx89Woa7I2VtjxNV6/RNabOC/YArPW6ghI2swhQxXI0cB8a1vpJrwtB0KzrfMGVF4
cHUvJwD7bzv59wxcSU9cJHyRdqVY7UdofYZY1YuDBki7yc4FzFozYIVsImMtrUPRS8YC7cYKNKn7
iyaZ4vxO1P9FinQxK6BtfSHnNhfe4N3fvrkFxjhlAPiiGIgN62iT3isG3+KIwYN67F87gUNJvs0Z
T69JmMpazsiA5FobIVNoUG==