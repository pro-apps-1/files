<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrlvnbKMYpkQxnTJTbacOXCf1Kw8UBeVDPUuvEPK0pa9OXIwFOSNy8GirJKWkn4k377T06H/
/DUSklhzVVXQgzVzXkIt3WvWlqafg2/Ddc+aVkGV2af70MFE3Q6QZPbHeYaJC8uViqQZkGDRKfO7
EJx4izHWdLd7aJq/ocZGbJ2S1q7jl3Kpndq4SVDi6GGnMYHti/iYY9mUl8zDUfb5y6mT9PwxSlLf
JsVaD/jvHsE5jMGqUPTcijAD9qw38xx4Qrpsz64dw5ckNa472QqPOhgG+/1WoIPf2lvtz7S1HR81
juf4yrSmcyX+6lDNraTUOcI5pVtU8NCg/La306OXMkqkC/LjbMCGRYcGPqfjp6dxgIpfXyhRT1kC
bGn54TcZBVoR56PAQU0TKGwMp4Nz8MZ7N0Eo60lec2WiCR1O8iTpmRWJ0Iof9NNDAJ3k2/ZknFDD
l5+Lv0Xw0sY4YmZq3ll/q9GqPEx1LBFqCI6Z9y5iTFOYO+O2/IaoD4v3FIJS2EeQSmVV1YFBVrfs
mjr0j/Dl0l2qN1iMOOiejPfDq9guN7v4grE7QRwF0SBMCTDDjeG+rMmzeWIPoP28pSQMnQRvxqUe
f289YSxGJMEspsjtK5wZNO9pC8GD6WlSlibC4XqqaFRluZHWNdJoIcIVODELiipiE8sybPcZU0y1
+80jxNQeq/G1VUlUeMXJgblrSUROSlaxqgtvUzVoUqk/ycNKbL/3UIDxM8R27GBOo8nFEZ2X/tU8
2TZ5NNgVHzpbrWVzTQvC/U8lb7Kcdh7zay7g4o1/+KXu4bHSHB9i6vuC8JjFUVOXxp/QrDglWadD
1VBD4nkafODIEOUW1kDA5221YdHsK7ot+iAKmSln3kPp75NhunpTn+gbDQZV68s6TNjDOWGdzZfY
fq1jwFbtL+lamnq35q7gSSl3YbbtzZfAMdNx64xM9vT5e09aEV1yztq336wgBsaf+ITE8h7ezmJX
QCtv1zRXcskO4xUqQU1aFvp7wMVcOwoq25iBkslpTNuSFGkpgXjj1gf9pmpwUYLfqVYsfLUDUiXm
MRcrwyGN34m5NifczUf21BV6erw3NMtEUfEWT+avKpRsAOXwkut0KjhORCn0mSbYMGMQVnAYHF8o
glImiDFFUoPXf/HL0EfA3IgdTt4Zc5uW2XNiLCnLYHcOpMljdOwxqapz6ISgRjSDQaz8sFiUp6J+
fQXGcVmP+MRIXrrI4XPEO7wP59xx1AwJSqf7IhWojCFNDnGZb584LN9d1difVaivnvIIuqlKwXWR
Y+K8AUGY0wqleD6mFypmbmi7hmMrsbxjtcFxLVUm4qo46CDXD/AKNzj5ybF2XVFxWZjXGMOG91c7
cWZxv1N90cE7/brgUF5QdOdVEXfr5jk/lgK7ESRGRFbkm59mPltZ74SHsjV3/Q1akd4FVHe/trBV
sk2c3inj3AQ1qt9lT44vUy7WfQfGcMm78jj391dRVSpx1Zd8YQdWlOZpCScZe4uTdo59V5icEOdU
2bMaiow4IjusrCgVyfZj0sn+SV2huW49KuDysQCi0HZEqACH0EZstx59XCLn8u1Myu0m8yE/0915
xp/7J1XgfA5fBexs2g6YbHU8PHMI7TNQoUaXOZNI8XZ2KMSbAKRIoUYboqMpIKYUReZeZbI3Abfl
XUbr3ATr0knWtbOoGC7Tut3/CecaCr/D+syFxRNy+C7UIUy12fJRDy42mcURFRPMBAPWQqalYezV
dMk1/xoyRXt+EseCyHss65we5JGm5mQQfJdUnvogC9b72rrcBWtqJ6zTfs98EE/cCWxN/PkgXVLg
AL6G6uw5KIu+3kQ8DMHMqGQJ69ChdocCg5stFcpwai4nXlEc17q1dJTWBushgc8gJ8M7MFnlTksK
p2Be3bnQy2mcIYtxa+NkDqxwHeU65IygKTju2BR+Uf09wGRKlbwxtn5NqYqJjFkeyjQKVDihkRv5
YRA3/H6GmdItEdCLOWjkdQc+qgBkH2scy29K4M2H+f71Lm07DPiUTUZv/C3fQAfg1zZMn0KYkLU5
K4XqgoaOb/VcUrgXgF2ZJjNyqHX5384AX5uKEjp6PGJ8tG2MZVUfZQe1RMHJltyf09LUEKmFnIwQ
u/r9sGLWTvrqzoynP5u5og7mxyj+nuMfmE0sUa7Qyxu+5AOQNM5LwF94V3uD36uKMazfVezdIc9y
jEm4bDVF+G8F/7y1P615P2YuTPxAx9Y/unEYx61yiRI1YC7uu0hLVWOXZ1ktuuXdQrJZUwgvLalx
r7tZQ1wEnIQzvRF6YFQv8l+grOG3gN7FMh3cuNGxNl/lN+ZwsXQc7jPiUqWBZ0wwG6q8ZTMRTkrE
OR5dwu6ZuDuT2iNUehsFDplKq/fi/wKqBzkZg0d1/MpsSTKoI/fCSNvy4/vNbHoM8yvfglXu1x/q
UwfWWFQ2JlGFRbygU0v521V8UZDWhfvUTwcvyjjllNd1W1Ygru81vrvKq2xjzAiOG+9i9VmfxKxW
oEodq5TQmJ5jzwd++hr3CIRMsABTvZvr053uJGuroA8S5230x3MIaJzTlYpq3QLfObuo+RgTcX+2
c6K5A7Loq2GbjubcPsEpepah3g7VOo9X+KpqMGmlyZWT8DP5KmfKhtUn2pUf2V0djCDj5m7nd7hm
IYzmS4VJ/IFKPI2ErxvdBwWbhiT5bJNylycV/HOvNPoIubtWWJWv0PQtHdskXoCa+6XElxO1Sm9x
k8ljLnpCUh3szUKl6ipMJaHvhJ22gKk9J+KULpu93TOToxFXYO+rdVhcXwrFOZPnox7ickSt5a7p
1sS3Pq6YfcEUBXyNAkbvYB8XMklvv4bQ9BzkAgr8B6a/C9ERE5I2wovhV5xMm8sE8Pkc8JjvqfA+
3aZ+yrUnkRp40Qn495ZMgNFRbgCYn+ybWoBA281Ddymd60FmwnqPJRVJcFcajFcAu+QR485XArMf
jSr+0q5YTi+cwknuC6yP00f6e6vS5bWKqHG5Lde4tT2WIWQgKU5bxQPPFQ9YaO7JeCsqHMwlypyp
muxHdUYFRzc7X+XSYI14zW6nAsjUbpSjE2Uq3cEmX6TlUA4R6cLS7a+baGuVCtvH6Ju/8QlbEzpC
a469Z4ahD67If8L6MQdZjtvIWsUHeaEyqJhvS2bwaxGcNXQr+Mhy97qXDvnV1Yy0bVkr6CJ1fQCF
h5nGonB3vYTopCrrdGIEINE4egabZ+Z4h3lSseCEdOxxfhRoiBNdr6GIS1KbCSB2+TcdPuxm2/F3
8zqIU+KvtyY8VjPSgkW018Naxmf46JiFqMxxJ3JVJEHY9FGu+SPSdWP4N62lkj1c2TuCqNB+3Pj7
7VmjRSLYFciGGru6W8IKuxC5vOp7WF/dokhhO1UxxJfocbBganHW5WOmD7PL84U+C7U2Wp37EhPE
QW+Whan+PV/EqKIAHQcu91km3YLYANTw+o4jt9hAJv1AmjQNZSRje0SE8DeG5kFAxYpk+9S7im3q
/FSFdtiOkFluPWMfdSP1lvNuBLUkhnt5uBCaRXTvG2DmvRL4oPx2micV0U19uAq5HEcDdf8J4sL1
1KrMTJNtdVo4ZvP63g8OFukJSaa69veEqYIGYPvA6+uQBUvTuWH4M0w1/vWGg1uW9Byh3x4i04lo
y8eo71gdP3kAEaw9X70LpV4tkeM4t49s2IiH6wALEPpJPZ8qXbi79Up+ty6vYswP3VOInUTbTaxu
bgxAJb3ALVA7K7aL/rYo2bgnAReSIBvn9eJK9uOYQnJ+gqwYhpgBzNw/47xA2kKhMxXPpbC6fZIh
wbEBaxS43TvSglHWwcWeu9vrmjE4I1KQ66Z13DY/7kS1OLKwpfcMayP0IhcWhxx+ctgLVozypHPz
U/Gg9Oe7rw/uQFqpf2SwxWDQPCrMoNfBVaLH92zDcgpDFjqT6tKI4hrnZ7Z2CCgF9QFRYSxAaE2s
59A5TuLwI6wRFWFQ03kwhK1BJm53sQlJPGTbxbF0AtI6M0595qnTVx6RYEfo1cVU+4zcgyabb3HY
A/FvUY4vqe/D7WFJOV6UHYXE25p836FV0lnLqhc0bf467ia9XNuu69UVYkCsUtpP33dizheJa9AT
7b9EJFKO7/FHnwbwDRO/xq3uCCn1/H9BGrbLpk1+VOZaevgJtCfR5iZ5Pt2Sh3iLwH1BeIaj7lte
A77iZ7M8FOrs0iSDS+xbng/yjnaUpnm45oWYYg2TdvaUOFbx2GlT0OP7kLUu3akyMpSKO6cpHWtM
zyGsllQ54AtZ/4H5W2FR9tfuYLV1SQWgD7TPfNQe41b2r5k/957IhEHSKm+hoVlipGowAAnR/Ju0
yzpfLNWbmOoT4NG8BaurAhe8jVfLKPeOw0gPB9zJiUo663rJJAom+auRjZGrg1tnxCIxYjMDHtRc
vhl61OcDBVsWIt/EFvO/SpRZKqqo/qcDIjy/0b/kTNimaAKP9i02cYusX4D6f7b7RmEi572W2zp3
G73/u2P3wKED4vjcxEqJ6cXYdvZj4mFufY1ZowmWCpzQJpCxn0q0uIF5aobJlAsofhFLNdv+OtHI
/2w/C6ZK3itdEG71/bxWAUzmKUdVttikyfCU3QPsumMdW93jq+sAKUJijCM+8er/9bTlTk/vGGI7
SrgvwuzaHp5J1h0B8BscKN9xj87uWZtXhuoqyivU4EdMjyQm9OFsyUM+roIc4PsWcddN/v+0dqds
wicSl+sCCdboPMIexhTZ8q5Dq111+vvivfAmdaik/MAKGz7ZaKOndcBJ9Dbdr5Kom/u/KT/VzvZS
ScVGBJf/awiq9rn5CptEjUBM42l5Hsgal50GgKgQOViZzGw1EktmE2N2ermKVkOFcLEPOyNhECV+
manvy13E4/Ulnt3QTLwfPTvBSDfgRAfim4c1JcUKe2coQGb9FzW4irUY2zaBUFXlfmc3x2AlkkP8
N3kbQNflpxzZ7NDBtd7qP1N9+5WOK1hZLNxjFpxFH/GvqEjowM3naU30bk/f+98KwoTnbYs1N3cj
CqtJGNR4b5mBj1vmgxeHij2OpxcTfScsvym/QIwABRXRa/aN5QLeTt9OVbpSE+VIuWZXNoFbo+2G
XPUeRq1nJawNTb00+lE9YkdMce6Q5u2o22HfesqgeC/JcNdekN3BbugEzg8FusAfkjwqFRy6E/3s
3riUupkrZBd1sugRZtSo3lqOl3zrnaT2VgPIyEpoTl/B7hAN9LB/zrscXsjyIq5r3Y8dPGgnTId3
rtFRrQ3JRXGLwnjAd38lW9RjcAhn2qPDnpkhTy0/iKD2Y88bgb6CFmlLTikERTGZYEDR7razP4Bq
QYulvZzctgx1+ebZkCdfbgNrRjz7IPfB561j/gmlVwuTmw1fNQ5vLaCBJve7AWCVWZ3qtgJysQju
CeCdFJ92omvEL+L9WvKqbCO6CpVOjCSTKnvaiVg37v3TCOw/de6oP/p38sgHJB0lBOL+Jbs8D9LH
P7DXzNl2HK1ttcsfgaHkwbIyia48oxpZ4JAWHl5gRc89fBGYsqK6vNo/5ebOe3hj83MBpiflzUwP
cavhg2S86Mv3oybKKP5xER/Jz/er3u0gBUCWPMPjcVDrXmPemIBt1Ktab3D6vfSV087jtGxvUE3Z
lhb7wynB6zNXXk1KXbSsHMqSIE8Pt1gRD2334SWBvTXpb5BWLokOwljWUYpYapfYjDI8YeKYpE0h
lyLsnzmIE2qjd8dJva/KzvGs+P8zzpzLgNwIIKN9p/XZBzjL9yxjc6iEJ9OR2Jy1ROw6Ko5TlsPJ
GeieGoPHkg0DuicFt+VFqXj9S+VUoRtFExlYl7TiYyhDrSi1Civ74AX7xeEg4Y/y2GRnObtZjTqK
/VcyiSdHWk6NDWc5u7bavqsVFbzf8dLCndVWCSySyp+OD6DUUsWvTJMwhnjqQ+TAQT9x4c/FhskU
OE7dgIIvZILPdcf2UaGuVOdWgTcIlf/vdgeQkPBnoC5F0M+cSYTNY4WCnHjpLL8c2q58kAwaIDM3
sgdlK9fqfmxWtQ22kqYMBvFASkqTNyrDhPEElp0Rqz0avUSvAMZrasoUMwoWw3RCQXtuIVwDU7JY
bIio8lJcbXLq4jCxA5we8K/E+wlPrs+Km0vAH/oeI4Fw1zRaJN8RfbccAXDZH8j3heKYXAVkg9TL
7RegtytN22+3stpQEblURSGNut3hgdg+B6Hh1HZKsXye1cq/wEGJzdg2qsQq3voX9RqEULvo1Zsz
HdxDzG0qT7vj/6gi7V+CBcG3Kuv9NJZFXiYX3Ubl3iLDaDIXHrtbM3y27t0e2NjX/6JylkSp80H6
RIItw2FcJVhnd7edSnJvIWeGi9PCcwwln1cABCikDuPHyxgA4H2oCkPaCg1wj94gvF+LN3t+2t+K
oKc+wncsHVLIGPrjhnoUFS2qiv6dwXQWEbCMFgpPWkJuZj0PtC8kxC2UT0lmko8RO63IVcZlH59Z
XSqfuMW1Fe0NrKJhpNLjNbjcL5PwqLkX6r4VuCcwaVIH28r9Bhhnjeo+wwnPAQ07Mu/blopQFa6/
m6ceYPYWR7M0/WzQyINV/M/hq4lgNSoehhK9bvQiiOr4vVlq8jAI2rj2QU33Td4lCjMIFqWk1wqs
tbVce6Cdi/9mhGR+eQziC7Q8zzeGZM1N6GHCOlX8NEbO9sWcAiFXpQQW3rxSJS3mYewITKPCjukV
N5q1Cgl2zoVyrpRR9jEk2boCUIj39xgbCKT9bPnT2+P20OBdFfKxNoEjHSBKaC76ZGWO52bWBpg9
bpblKWJT2eoWzaETA4lF+bQNjry1w7L3rPJkISpWrQepagQhP8gPqG5qZnhOoMAT8aLGd8+p1qsv
dvevWFPo0qn3SAuDWn+JTVAgiw/ke3XEq9Hu85BwWuoqKCVFAiP2L7yAnmt/zoSrL8BxXYYnT6hP
a3u6IRw/vp4CfLPktceaosmEUvxh3pk50pOKNO902SMCqdBm0I1b+nDAt+1y8VPqchISfmCAwi6A
ukUmlEnCmBD8XOcACIt8E9giE0km415sacreAOWTikqq5moVA+2OiiQmrvYZZW71yU2SOQfJzjYQ
7DQFoq9Ki/xEhxp7G2rPvSA0JrRxE4/IIcQ9NEJn974w/bw+anDesT/zpLF3qAl9+yRWWQOBgCxS
2ScGFo3tQodzOZkEKlldhK8fxZrGKSXuMOvK6gXZGpshwguiVfWgtucfdlUaHC4HfdW14jhQwP4l
xdQjwdPhGPPIXwQ1LePSajAljl42AKaG52w+DIUSUVWhK8pIjrYvmFDHAi+2jwEgQ//4aJX0rmvk
U9OijoQVpcMrIEIDv92x39txIZf1U9W0fpMNff6p4jPVGYCxB3vFulsURLrszPAoi2yjXCkaBAq/
dF7EG6uXpNC+yi0C4w/kpuZGRLXDJ1sJOUZutQ3dI47H9urYhARl/60Tn4IV+g6xoItw0EiqYjKd
vWmpUjbNDNbKJDVnDs2zP3Mm+sxlhH+RtmXmANQt3+5fYDm/sQYX1NVSLnIlLn9TGryuai2G85Fg
cm5r0HiSGoUJNMP9NFQlp5IIL7hyElDmiv/FlHiS9looexzFm4glZg6QIJ70PDmATivOk5rFkQMe
Kt4r3NU7touU2BBZBJ7xq3d+H0zE4Seg0K96C/m3uFydVZObSxSpZhyBGS3pBJdlZ8+MW1/TGs7a
cxG+VcWWS8N2iJkwkiuPRIQsIeDILZItSoG8vOZU2kGVRrGxqa7LEALoSCFqM7FHlpKrYv4DgnkH
lUkQBQn3U2Glfs/WOmkGj5/+XtBs8rSlMSKsG22g6CaprUOrmqePoKjaPrWzEDXoov5YtS3ImPFT
1RMSZ8PiJwE4vIaC+3a9n4o60jy8bpFzGGw0wZx4fekmk982GVUWHEo9LwarHbfvnE2UZEJWXAvc
ucDknvbWDEG4UQ/Q0Y3EQtHS1ss/04bIGHMOAEIgn0Ttxi8MV7ow0dxZlNl77QmnX95Wz4IAf7vZ
dmot9AxLOpCrVigD8sPqnkq75SfBmBmmb/5sEXejaqdE25vcqKgCaIxfhdgA18XrUCOjMJrWahlv
eZ9NlxSGKiJot6E93niMCfdKQFCKVAvF2NNKP22OcD3LqSDAJkPoE3NJdWjn9XmYU6LNwQOKCLPC
SZsWV8qiet3GvIXL5FE29vb9epqIGyhjz57xaJi+T9Av/g3QBFUXyhfXShm+V3wqzsrXturkRLF9
47BlnBQAeP9+I+7+Nlamt+5Yb8wfSE0fn6CIK5JyH9UelSNMiBuKbEYFbl0V8Wt64auaQ9GXDmA8
mQgRDLZbVKAtLl8dSmNl4xWB8hq0FvwVhzpwtsra/8QOJZMrrcE25yvgFLsYnug5bdz1xCiZGHQb
Uqvu9IHcq2GahvqaqhgmisJP10Bi+cMtxDDWRgzHFuwbM3HDb3fBuX8Kbuc1noNVyI0q+q47PbID
DiRGs0VTviyIslWGegXxnR0n3/ZR9LgVGik5Buzbkvxl+re=