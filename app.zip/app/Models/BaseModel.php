<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpIyWVe44NhzqNqKsUOj9iVI1BB8JdM0FeguLEW5xBAfvJrZdyaI/ZJg/ldAZXdZFrkHwQpX
Ccw8H26hAwKCWyidc828pGMFx2+gBx7cqs6qudlIqynjR3+wqIi6LJOvYxhjaO1A6xg/bjFWSoBM
VCKUeL7aKQ1/FSeBh2hYyN9fJL5PYUkjn4R5DFIlszvy0gWgXxGuSg+IG1ZC6fE9u4XusWA7M1NW
8gWh+ZHP5JI/pTikUCrIPKXOVp4cc3djzwqOGFk7vgmggRGTeFMWIDFai15k5SioI9GNY/eAKlrI
Qt03HYfd/oQsVGdf44DnDsbasiIWtMt609zrDoZrDqHcGjTdyDBWjiZvMG0wBvuu6kUwfmnddHlE
2jtRH7CJAe7RZPRJIF5hRis31PG57RVu4rcXSIP5NPdTn6W4Svn3VREAll3+zVansEC92c03o0h2
BrAyFq8BWkPEaOP2+d2IJueNbjyk0xMeZWFww6tsjaKGyazKx2eEWGnpJvR+7JE86UedtadHHMnr
nIG0c8EC33ABo98dtmJh0Duq5xgjFU2eOsxAb7aDem6cR34+9DPpFKM/a7/KQ+xEOkkw/+3Rtnc8
38bdz7u/adpbdH0OzucHKVzZs3DBxtKUzknTLkXHjBKL83fScbodcD9N2o3LAmR9faq0SkZsAIFw
mfe3W0E2nTk4Mv2Y3owJSrbkgG9AytzxfqXECXeKgo6EQ3I3YfoEMyLoXMLYVTuCmU1d+yahEHA0
YxPAm5C2baWsw9nugxc/INDtT00q2v5Cs49Qglk4wuvAQhMRIQyYSKOoC96WJjZWBxyWZFRDZo5e
dlIyvpqDIkambR7ueclZ5TPDrncSzKbatdU+ZMz6at30qv3WhUP2UdjQPFsrAfiZZwIqyH0El9j7
Au4a50XElWy33ITd0fK/hPpxNB8ne+2y1TQJ5IuADJzJPn7RX5IF3jEylv2BYwvmXb5wgyiJr2so
CUix/4kB2oj3TG2r3vEG1CD8Vvez9Aq6nsPLbOuOWB+f0mkWEF7zId1v0YUN2ORRgr6zo2f1QBUx
oB3/OecqRSvtj5E7wtvqkTkJERFG9IQQ3RZpE1rkjQXYxKrcqWMomNc/VZZ+L9yODyEgvXZOPzTM
3z+dld372+sriJD30IvVQh9qtKRUYgp1+yZ0GMGjqlGEL2ASjie1zVGaHV/l6RTh7tpS2K2fHN5O
eaZZIQdz6YqkT3a9babNVPP6janHZB8HLORV