<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPswCnqdbGV/zRl1DKchEeQ0KRj16uTnnTy9vDHV34aVAZ5USKYoe3KJ3/2bjzcRvFU8Cs8/f
DTdkkv8LbLVkorqNbiyzLpUafunUlPLCjWln9S4tpElEdZvLHCyBAO4WmdubC4kwPUtXCDDu0qW0
3ffmCoKzSCnDVdwsOIITU0EmauxKUh8acDEk3ir8IExAP63JQeq+XcKnug4JO4ER6skBYKzVkbbt
Tud+jDRxoM9rLhA0VomamvLt7c4JoSoUKHVAnX+MgeT25D+EjpKkAQLjijN1QDLCEtrsxWbkaXZk
ZgZeEGf3k664NutpBOl/cMHDNezKdKGB8/obc/AQUe6D3BG1xjh6w9oRvafpvOcMX/QrWJVH768p
Ir3RF+A6oFh8WD0HHSvur6+5Ps0sq/tMtYQDMGAPQL5NnkLpeSZ92r6JkNemqSwsAWWnf23yTrYD
At6L3VTnqUptI3i+EL8myFQrUKaxJqfAfdIb0XgunS/gaeB5XYvWaDBxyosy6k7/j+JbyYEGE5VS
IIsB7mKrJn2pWHqSMUb+kjusBuh+syiFG+e5/HhRNmvAUxU8OLtMDZF3zi89K4SSW4C2RC/+BXcx
4bwDikJIZvILhKIg+VIQraqZe86yfhGwJd4k9EI2kzZxjCIJNdiq/tjQKdhLI4yZPqECM0jC6qRj
7SdxJUxf6mrEUcjXETNK/tPHrto3OektwvupaqsJ760lzptYz61ylogb+tyFxoMKukL4+18rnG0E
9xEa5Tp3Fb7NAM4asZVZKF2YeeDYqj5F57RicOC/+p6T13fNxWZqPwvPa4qWkjAK1iAQOQLlfRLX
fbDPiVazjGsUQrftTx2EL+vKZKhCr15TltwG0IxIqRjrGGJQpuR1JfX5+XHiCFsnwIFzRUa19fiW
vLYhFvOMmUhcEmDH9O82pAupI1eLC3EPz/253346fubUi8IajDD1DuOQlfbBqeIJI4hSjxg3RwBU
Bdkb4dMob2+IwNowKX8M2K2tVAtnfSpsERsGl5c/Rmxq6N75VrFkFrZ/HI+gtlElcJRDzDuZMQJk
BwuuHd8/cBq/abkmvyKtYUARiwf/DcS3t/NqsTO8kaWs+h6a5K0jv0mJN5i2xmHi9ECoU4Iv+VBu
6Djhp3UeHvrj6nZr5B+d+ur/ymbhXy7O+ueBm5VlXg5ciw1VYsnaXepLRgT7MTJA95Rpww/982V0
p0R1YGTlPSlaH/wK62k1gf2XBi8zYVqaoMXpjirfH14=