<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxE0Q+g7N53ENa7+oIkbWoNgAYNOkeh49xcuaSVqorATJVgMAbE6EQ8D2rggyT1TKwop9EVw
vva0A62+GnwxQJ2rnmpAZvcBxMGmLyWAt3FMOEXtOjkoqt76seakLaGPs5vHFbnpqcEJE5/bBP0T
6cApLzfcowsi9Zq+IgrS18zQZPdfwEo32PdmAgKlxwkb0AqUeBvbyE2rPyaqt1H4uKK9/2QW+uEu
DsjGuI2ZfsNyvsASocl77VtMbK9kpN6U6oYx8Rv5Gtg/oOGMaUIvJ7aVDaDi7Vyl6FKxU1Z6OC69
qRWPO67mDrsMYXc+VZWlPbImdECi1Be4i+enkcqiA9zQKHWPnPS3IyR4wVgvfyO+cTGoz07pFRWV
fQhxYzEBq2UEljY/IUkeoNKS6Scr7D8gOFbu5czKHTxZ2+BIWBUqbJbV6PaNH9u4zR56L2WQe6UW
2SPLCh7SubU7CW0eX6f/27EgpiatO23X5hcB8wvFeO0DO9DluUEpVyBSFZMpW/KUN1VAPgEY+STo
Wbx/f9G2Olu8+JrNsdxlstjxsIx6iWSWNGWVRx5flZjJWPmjvIj6owHhl4NGBDfhkTjQNmwGZMHZ
srUo/2dNjExhQcJLY6tf5/cIVUsESwV97kTJ9b1bPenC2MVn6No7xGb9Pa1ktrUfJU28DsUW285d
DSzQbQ6/UsSBk+Q/s7gMRmIFev/EdPU9c7dIMXzpPER8YF3LWatsXAZpIDGW/OfGp/uTTsdWd8yE
xpAHy7lpeKlk8tW+Zg+Zyy+xrS8aApsXEbAbrCJCK0EmeROMjwGxHysuKNO1YFzESkzhAHgCsq/C
gvgbdHm1I+pGkVaZHw6mLBe707xR4ilVCv22Ck288aUR/hlY4Qink2wFU/1+cR1K2dhQEDoIXnbx
hgTS0PLKY/NjCJZajR8oiS1VSlgI6fjVu3GeG8MoTkkIPNN0rHqDxhKwcGGnq6ipNuULHms+w2Ut
zFJNceJUfAMBMAuETG4L+asb5KwIjo/YbLFDOQ/5JjBNfVpAybhQQ5G9xc7SIIE8XvaOsP7OL9kj
d3f3Uqn7wwanc6WY/XYpTXWDLhymoAqBOnO6rxSsptgvTjQM6bVj55Qp2bRkMEBP7SM6iXpSMGW8
Y1pZXpei/z9U3CqX+jNPZnQ3nImcCNf0GfR+hNNjVBh0+QMJwKCmQjfy5RijG/67QrwzDn/hLYlH
6ohBLvpPShbPlfxq/ggiVMIvFm==