<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyDzl2TQrWG88xmf12lrCyMAqU1R7wcBnhgueUx+o41W/xG5jMO9dA446Ptzez6NHn64ySt4
g7Rmd89cx6HSp4bxxIhWRwYJCZYJdKuqVChvOQq1cHmFqiSFnK48Z3kA9ORq07nVL9rtCRzv8ElF
tfa8x57Hf1QkTK/6DXqzYagtiBN5jApvBNxV/Z4VCn/oZG9EYjMKbZOcrIw4cT3uqXbGEddOSwB2
ZPLTYqj9RihPmYGKTud2NxizVk1LUH9XePOUw+bf5rxjsEZ1L4EK3FLilLThuImTpFdSauyVODYM
AKWK0GkKL3vBfwidLXWFdETvvlovwiKlNfNfPzd6lScXVJ/ZTxmdbRzFFHbpK/pOLVuB5to0l3Od
kRlIR6S/Tjm+RiHRECrjLNruFlR6lj6838qVdZCvDfJLymBuGpqiD0My/+RmsjO+CTVpsxh8CY4Y
alQdRIwgjxPuus01+GXL3FnTszY36eOeYrPo3vagFtfk1MSDGFcCqjEGCfpE6A9OzXjKYH9eclmq
5CGLo4gFTGrF7XngaYNauCQWZao6vGW/IKuMhAGoPfz95oB+lV7xR8Jl+bM3+Lx0bHSSaEzZPWNp
+076cUmWqDHvfR6wZb+xIzJtf+mbsx0mERcbOc12qG01XG/DzhRzW7V/vfF94bYzSM15rpv3f90J
pcLZnObArgiNGpN2uFNiZlPc5+jTI3AiNkNeAZ/W5owCrpfoW5NGORgNacXOhxUdjSX23wYCQKZV
UCzYWhO2mkdK7Eqt0sMahnjhJaqhAUULE867qUvBoVYTCUbwA7YGh2ExNO+MXHWfag5dH/jwAzD8
J6yNB6YLWhVHEZJd2XRPTQxk4RsNvOvnqDl0SiU1z2Wie0RU6Rj/+8O0nkQrbv0FgfhHR/sY2Oeu
hFL3x198moM8mgeqsOLBZmhFDfKXAg50Y1upRgYJDs/ppBiAG0HxsUCVODJvjzmrGGEWsP8GkZAd
VvcfkkXL0KJPaidaVxPTxazNPvyDUSbMkLFG0XJULlDEOL6HMgwIRdbTC02XTnXRVgHY9v4Su0RR
xESzESHY/o5mKdcOktylL8qjAJx0iVC3oBg/JBNXt1LfT7BM4t2gZ8B+loTZxJs26FwSqcOuIaIG
3cULLEBfl2/cUlC8afQv/UbY04X2rX48R0yTGHPEM1ld0ukkXhfL5g83ObxFBS5e3bpapmENGK12
sR8Y9Jhl+RiTwwBYKuZHkYOYf15IzbpPyB/3ONF2