<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP//0IGqS21hsKzM8c3/NbEnLtzE+scw2RQIuy8ikTi2005sd4ureCGz9a8XBKGebUjETrsUr
QnI6JdsfRsNiYIAyWKP9V2yZAKujuGADYpCDf9PgM2tHGCR8vs5AL/sm+uBkZE5ZTUw6pA949SE2
FSP2bGu+30iiLwh/x2NizdZgd3WOMM2g7+S3hKPjrr1Drwanvqi8qafb33QlrNMuEvRpLMx7PtKk
df06c9kWSsYpic2WQyYZ2iyoBe2wSconCfmcDDLlWsO5PxOd80HtjBOotxDaelnowhheeOMHszMr
WPzr/pbxD6b30NvpEQcsvc1oxh0FgYS2+/Tqx2gVPNMj3/sy+8FchbPhKwa+Ah1yuMK1WTULcyT/
MyVIWkVgjNGpTy86LUxc49pcbh+oj1g1qthnPIi9ksxuRVfBxIOXYA7E+DTOQIwqICAr0+caYll9
mKuZRaManTdN8J0gecitu08ilvBiKs2VaVGoO2AWkSpKMWlgUv8b2HPJODD/NDmslW6k1ZZ0yqoN
H4sGdF+OOuKG28mJMOCRVuxPaFldH6jsJs6o65kkVsh2vw201UMYsqaxkzBrPMqNAe5FOEOq5kZq
22GafDTf/5Ri/NfLtG4o4N94zp1JS2n4EmNR0iJuYYJ/1izL6kVc9fEuLUgDQ7nD3u1qzokOhWPm
lesGjgA7TSfKeAMB9YnGYBpUxloaFR7UZU8tD4VR9O8Gj7NY696sDhYgOvZJ1SOayiDclbCD/7bu
76f34TQWwIGYJo0ASihPsieGcjApfJBXOKEbSWHhV58PyW1es684qqDNE2IJbvc5unlfLYc3EzHa
HMOaafnC7vUxJ79lRIng2UIAal9HtwPo4ChCuAgCeOjPyRjWjzIicYxtHtpltj0IcilOdM98YiH4
3MK3hsmDbWdznw9xv4PQQNfITl+6yqzVoNAYttf91Kkhbpsav/2Vrvutau69NFuJtBDPMeT+biYY
ccjQIhWzvzc9+ytUZAPtomHKY8BWnhO4acm2gbrXQ3QbwhDHq9WtQj0JU2VHuAdh5h2e2SIYLuea
YSs8AhOdBUm6jEpWmDdTQpgak54FYBnXIk7m4UIDh2jN5O9JH6HpM9E6IJ45PAMXtTFTesQFTGhw
wTJvtH2wdxmWzjJ3+vk6+HwuPJy+ZHFfda3WJi0iCBpRfjRxVeUuGNcA0+Cfc4fHBBmB7K2ny1WB
UUDEp2sIEcX7xqpQvJZ09IjLgNzcBrO=