<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrtJ9MIzZ9vBk1AmHz+KocJ6gJDpA7ij6Bcubko7qYdqL96KUKldqngGc6R+GHOqKemFnNoP
6L+F6WbQuQCZvjy2EmKQ1rbdgZjJIwfT6RBgtUMPJpzAjTR+PV+kXbGNkdxRK1UHl/RqBY/2Sqe/
5Ddvlnw6pBeud+yNcHAf1NSxsiItrHI+8IGGdZWUqklRrvTORa7F5SuosocsJNHztH/ipphj5kVz
wUNjIJFBBOMx6NgPZjcpqPgiaIq6F/dtecIFk2WvKiNl6PD6Df4hcB35xwDgwk7sYsWQ96T2p7eu
nOfQWFg8GHhYBOJ3HOA4K5boHhHn7fxdY/ysQrlnkZ+kUphRBI4qEvbVlsR+4Gc43q7144IjBz0F
7Bv7bao5FtNEZl/NkbThhQCMA6H/kncF+vLeWaDCFyIBeE4HOL8NMPT7BjXA1zIXZt4bkuVB1cqM
/67xiXPoIwp0o5pvGXEWA4elclPl2Mx16QMJEhZyPO/mQtHV4x/BBIcZGpf1FL0acKBxLkZTnV/u
EvtEe8uR9JQkLrB5c61zChni0RQh9ZVlBljqWQ0iX5r+R12XXUJnnz4TxnVjYVE0UxsYpHIndDRy
RfRmtx0VOHlnjaUR16Cr8uWXTj3SJerpg7uhhGYU0Bn9WeRsoG54cpXFQULZCGTjHFKtHEdq/sAU
ldyzdaSlkKS2igLZaeCfzakqY58dNXj3lY349pONcSB8mzZJNuqKSKRBfKNyXhrlaHA1T21yTAHW
yNxtPqjLdVT3l4CXh79sS2JMMmh9z0Akmh1xuIS6aP+97oP9StGcfCWSiizQHPL+hPKLk3By9DPI
NTUqKDx8UCM43XTQCzWp9K5EyqZAEb1m2TtPP1bJ8WwIbrTK7WGkHKKbl7A0sEz7lKP/fyLDh/Ou
DrmefYenPe0hA3qx6G7vRJcZSOwRMBj4mCRE3Z6pcw4ha/cuAEjsJLGTuqRGClN34mssmJv8fzps
qGQpdlHh5KBQEvdhEyJj7GmtXRyZGVyVAqp+b4AT0n67ArcVqFAfEvm5MxptAPEJUs0B+6VPSoMl
BTmp72R+g5F8tizJcmt7vQ8dtjSIKCM8CNAagZcB9iabDi5R1xSSVD4krmH85lhMh2DwxBTXG/+T
JpPBnbLYERzZgTtE/DkFsd1kHhIBeg7PiephRARUri/lVPSKUmSfKu8fAwphUtoXlWdf7PChaGa5
5SttcGxJQsauMl3BSmEOx0TRLa664RECKznz