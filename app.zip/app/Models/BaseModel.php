<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqImJbxGBREHhN7RVMadBwEGRGr7h34o0gouQaXwKKOgd7yH//bvh3Zwjs1czYZddRKkkQ80
FkfqjkD+BR2XHhLq5ZFLokiVZWvJ4U82V6No1cduqad7Q6w7cFWUJf3PfhVfziL4IdEczkKqsfQp
WizxMDpd6co7Z1iEqzqKT+8QWEb3tuCLBlknCVT1436V1ncROiH7aZiJPgdqlhQj2Y+uBmJ/MQVs
br8w+y8H8nB5nQ9LmyiXpKr2yUciBUmHt2mFAWetD6Fa59t1nE8I/Q3FmwPf3oz5jLQ1Cttkb+RI
Z8fH/tJDGiXduRTHDNnaW1zBLIGFdsxVCiITHkevFelmXF57X8qLTQwjx/NIUjlSurwpTBO5Q0ME
av3O1mAbSmFcSwTP1HXqqvN9WwpYc5i+UKyCQ1n2KAitavgLhAN/BgsYiP5uPcV/YymbzXX5P7Br
9ZYBTkpioz0ipEarMHAmA/lmOAnx4E9XRSon0+Rs1w2WCPm0Q/10MN6H8TY0zN4j1V0p9wf7nRyE
d/n6me1FzIB13VCNRpchXhFi/ZbDD6hUbk2gHmy7x9pCnaMEMyT8JhOZOEoXWagKlpvmYa+znlzV
BXFCLmr2Ca61bDe9Qg5XFKX8sxpeHmsOIoLkmdI5rNfhfyVpJb5zpk6hEZ1ae3PJGFypcExD86T4
hixMDLS0+xrZc3UsDXjeqQyhRapt8z9U7nOQEUFFW3PcbKE4YgLAzo4m34yrtEcTDOCMQTox81VE
j0vcsgs+qfyvR1U7kR680U0BZDKm0KauSfEQHqEJd45m9AyeKkj/ygb64b8VsKcdVH2gpt3VatOs
w1mfhKqEPpD0GRF6Ko18/Muvbi0daTSR4rG9lN0ns9a/dzUk/YrDskB98UEN/tE/YOFlMeHtfCRS
AOU9MAqaX3ltC/cPOCWlt+oQQ3efS0L6NSoRnjAzP+3GNU/PnEPU7YTkOQXKPD+tWVDCkBvPUlvf
XJCJX9B3HBKKUdhi2KpVvNqnlrfMOMm6Sowx4xpb/wP3kj5zQNS8XfM+tf3xfKymjA/I4RKZQ6k7
8jHULksU73HTOMzHeXd5Guial0d7l+kTZ82mS0yHO3ybMz/fVBA7KS/trvPl+tZmPyYrl/tLdVLS
8qmmym88tfeOxwPyz9/Bs6q1+j7M2v5mZE7bmzJ7W7xpMkV4Als95xTg/iKgW97U0ahZ+RNsOQBu
/DWWlh7jruBb0QeFUT4RUnRqk41cBTy=