<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmw6jtp4MmnpaKSYN+UtsIcpkcjzoqrezDSWM/URb/vXwOPyxrikpqCJpXOdw+1NFI/M7ZZO
/fnR7apY12gB4aR70eLFl8+VzcZIzW6tyg01ZdfKRu/PipcKlnDqSvz/kZI6gXva4jbI4L6J/Jsf
WMYiNmUj5itF7raGXa+8x0f+GoySP5ijPiMvmESmvHdu5bA0WcqC3GcaOPI4AMUJO2ee/ybe5wDn
ZwC4GsV1t1TJ11T6EdrlEVLjmJty2kBhILbUUHujnc82gkQCyqV2yCGmDldWe5TbRmJrkHuHV4vX
j91SR4nC3iCS1z9gMCBFarqj/5ryZ9HByEnpmU0gENfvOFSnt9PA9ADKxm78vXHmKeptGzbmB9ov
yIw/78WVAwvg768GXfTqmBhn+pViwswOzako3J395oZOgsj08ry/gcxeY8E7RbajJX8in2gxd75S
0L7IkuTt0913Pq0X4oLlXMMVTFkvzvrXkE8i1u1vmysBbKve1gIFNBLrChYPuLCrWwM4sDCidOfC
/ZYUlc7vU+bJmAO2uSbNuLKk1imHBdW+URpQW+noZA9z74FmEYB8724WcT2ms+1Q5sZMN1OsC6V0
ehPKNM++rbaMK7u703ReSzNY22oCRsGDjfIJyb/k2XOC8IKXm5LVPdQO/21MFY+9LJ87yTcFbh2B
S/vzsqAp+9wAzL/B08PYGk2BliEqoKDLB1K33T3vOwrmwxMw4J9dLHe3TmaMMHfZxcdCqXhPiO4d
Are3jFTVJ5+SKgpgy1Rycz8B/ooLcbwHIaFnDssH+FrSAuj53XJHgHJR71ZCPSitnJRE+/AL+3y9
2twqTBZfM0jJ8YRvz4O7s/v0yhu653s8ASeAf9a9PjrBA5G887cklWc7if7ZfEoAOKM2vWQHRQIQ
v1nvtGqifgfXwJ3OfbPUH4sEN9RF2XaKMzBiTxI2UFQQDYrKiC9edGSXwA2B59QcM16XuTyHS9vn
MmqR0PSh6kDhyHHdlZImQbEp29LIogcxCKrf8ZSqvg9q/OsVntGi8m5KaejRXmUMVsYLEEr+l1+/
3y2NXPYD/I5+eXpn7I+tyYY3hD2a4U9Q2W5X3DKtngiiStQ4M+t3Bk+sRef66L+Vg65y5JzeD4cW
oFgBn4upEjU1rbJW1bAzfaTYnhtgNZ4RpzSBZ8tt43YbWl3tWVY8eDPLqFfj64rApxZ+hUiXbPw+
R2fzhiwocRO8Dx6DVnjMU685DmjW/G21V2X8kQ7QL7Wm