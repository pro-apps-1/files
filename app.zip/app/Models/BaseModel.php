<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr/4CxavcOY+n0McceU4xGrGM3h2GuQFByw4e8sVZFoTD36JtdWbFRB7/Kttk2nyq7hog/U+
KQW98Nw4tqXPn13hxkO2URyzbPyBuBv502LzW3w8I2XTue5ahx8vzR8MaHtrnwiOkejPfAwwhhh1
HCXA2n2GmP64TQWcDXItevO1wnswjSHMrH5HGyyqt6IEY0Ewldv4w7H9XuynQX02cJEk6UD3qW8a
wbtFckb7d2X7sFOjtQ/Y/CuSwb0T+6QDNVhWH33ZmUmbimo8G62q62zKbya/Qo2o15KoAJzsMaZn
GQzyHaeifDvr9EV5l840BaaeTK8ujnsB5sXEK1ggfARyH2r3J6LxI7X7Lpq1791jmRfAo1fwiEWR
eRsl0IA3NSn68hHCrrKK8VFbV810veRmA34SbrX8vdAhLOIqcws7nyIoUCkw54gnwOLVBkResO0R
RQ8+MN+JjzvpVTrlyXLDon4GY4iIWbr/N1TQXR7TvX9+chnHgOQbFTyoX+w3/x/KjnNTTi2j1iuN
YNsrvi+I0VYhocD8kEekVOwbWFlDszheiviR95JAyJ3ikoe2dTY7SjVtDyH2x2PIVGiOUCo5GBME
5FRSSL5MAPyHbzGHGewyK5YKSrUaVU1jDQxNrsfPds6icNJ6KgSX/qiMUxEEU5ubTr1w+UUhtwfB
XR7xrCgIYS8S5g4HOLUTfhVejVA3z3GGLlSlUw+D4f8lDhoQ7v1PZFJRd8LeAnK2LfsaHXu/NJPe
ytdGM0trlvArIlrqYR6pvN/wuo7M7mOCunWB1LWtrUAIUm1/O6Lv7oRIhkz20HziX9uWj5UXeLc8
29A4oCh7xwMZQaqGIckvH87kXHUwevSHMOMo8lcIFitxyseVMxXbbAkLA9L6Faeb+DZghXRyGjpE
xp9wIgn5ugDVkA12AlRZJEEvUJ4QlbX9zIhnfY4VxCrhWCzKUe4TGmjUAYHx1g+erqisEh5FB/lm
GtQkyPAmyRC8Xck/wemWe7MJAWWb2pxI75l8zqu0ICCFPOQq+Fe+aSBLCvE8bEVsAM2YG9JZv6cc
J2xrkTn++QxK5AP5cN4RruZVqYALy5zgBo+46nFEJ5ocIrb23akakewFKCxX+7AZm/PeRPtQeDrm
o0JaDRErG7wlLeGZ0289l6aWN5xZRHmqTxUHjbsFhMygsGB84dFvjDeOCdBKQjh7AuFp5dQxVIr6
ZbGNM15IDMlIJqZbPyB5/yAobRbUf46YVrmMEM7NlogfP6LQe0==