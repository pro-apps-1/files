<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw8e+aacfTvkF+blQiA17ZlYtg4Ye47AgSqsgFjFCOIpv4nfBDc3/CUZOsiQpnD0+T4vGsM9
TmDT7JhX/SeTDRe1vbNr03jcG2ZubeZnr//4Z87d838xboq11ysa7z55O8ZBYm7LO8wFAlOXYL10
729bfFlD8jLQQBwvsO99GuLrtH9hOZRoEXUeomJLGYZ4tKD+tD9o8J7yo3xRnm06OadClUz7B87U
SetR2lelN4wZwZMotQB+UenAN1L9V10tHCOFeK8UlJdPArgD9XhjxmGtTdsUPhIKPbntKK98fa4F
81ozEh7AgJlyETzu79dm4cQ6vxLvRPphdMFf4a71voHzZvdYLpGHL398IMkPEGa45yRnJ0EETs77
QqOcsiJv4DrhVU2GMjoUpqH0ZQGAZYtakBI2gOx2qPgkP3Jz39yGc7ixfEaeILjYKhO4C7Z9928p
w8LQiCalkl/qaoc1lk4+LHoOTnwT1xHl43fGOZbROvcDN5mmIjbllAQA+I54JUjlfY9A7dlfjOOt
fyrFQc2F0NrG9lUQPrn2tNCrffHfLZja6/20YyIhFxEC2q+ifDdghM3N0XO07/Fy4VkIIT1uG4jd
Wfom2zNpR96J3aHaudQeK+xULRFrT6YHdCam1E65L22GUaK5YB4vkIyT/r3Uf0+YVIqKVIgtnrNE
+ZFmFyhvajl/LWJaxU1ogtC9eX949KKhJL/4L+zBc8ys1djBAispY8sil7lFInaumXgvp6Oe0rsx
kck66elvVew8lznOtzdJOwgL4PnD4QjYFpUjLrx3AVSmVKxRcSiWQtuzl3UJ6vjGSPwuBgRTjDJG
H3zlFpQ4lMFmQuHo9G7r9ro+FTzvOfRLDEnHXCxn6n0QU+KTiJvp3+kveZDWifowSdtvePweoFHp
A/b3luxg3V/n+yk+4V2x3kBke+3u6taHBuUsfSKg1NZNx/50HDIN4q1Pzv+XjL8EIdNmVerC1I3o
w2yBy7wsjrui8IDLP7gw3+XCnBj2wq82Wrm8/XcphftoHBMyth6dshuOAmredA50Etd6BTgHCB9Q
y5KCIgEJVklCf8gEhF5YlrVs5ymuz3GUczMlZiYWLaWIBQWZZJYAgxvp4NiUbwC0mzNQPNwnJ/jn
f+G5zZ044HDBjlsW7Oqd5652HynOkETvUe7CwSw7r+Z3S+o5I7NF06rahsNFSmRs+WXtQxmbUtDa
lwWNNfj1+rGexPoQCQzSU+A9zc8lt5kzDan7GXoMimfZSNC=