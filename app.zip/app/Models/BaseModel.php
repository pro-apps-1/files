<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr9RVL+cz4MHlvheVAIEm5/b2I7Dx243oB6uztUnnIKNCXZRVdESUiWt3Td2ABuXvfZPRCGB
QbJci4OIxF+LTUi5B2PAzDTtR5oH1tHmYyHnkWNcbYZnoGl6rrrLfTlZwitdchXrUsFBpa7vUaMV
EDixQ7JHTUQj0HTRxugxi8pB1HjUevq6AlAfGn9btMA7tsSQP1QxPjvCz6ZqbZC7Dm3dP2nIzRfE
Vh3tEw8lJ13dNObPuzInW7AJH7y7KNHfNC5a1wkSve3f/SmM5W9QCEVAiXXi0bEQxj4e94BiEqhF
hHf0/uDwmraNahMD/f5/7RULxa6kW9bvwdYeL6xSY8apZ3wbecs7hOep5QvBqJE9GxFxflGpBo05
3wNNs/R35LVndFzs7aMsFmrYvobc7AQ7dvZORs/CysWn4lB1+Rk3vajuOBndiIF8yrpi6VTPEXDv
7qaCy1Sc4VJdgVhDr/SXiGYBud7Mhmv/VvCDfKGAKaYNDutL8a8UUbNa45e54B8zjXj99XGF2nIH
URTcmjR1hEZQxTXuylv1UjUdvLLd/VMF42viJC/fQEWsAj19pgVcB/MxLWuieljZI3lF9fQ/iIT3
qGGhngF0CCt6VzqeSxI3unwQsn3SvE2qrdQ5TIwU+dZ/VidccVJpTob3Hao9H8b8ruiKUDLFizaG
zBWm+iKUOxxhasVJlGv5OBgbeYjZU8vYjGwlLcaci7dxh6Pkq/xCn0AoVY8fKJv0HKATIH9+Ncw6
bRm0p5+IJbjXZXY5NPH6TUdFvwy3OOmeQ0YotJ0nN5o23VGHs74BOg2rE8WFs2/ipxCS5RpztiAt
oCRZs+ZeQHi/V2kNv2hBxE/QmV0AsG11fPNsPLjpSmaCk71zv5phlc+QZTUW0878N9tbszaDb7fm
pFW4o124ARuI86EFd8jgOBe8FZRAERSbm3xeGQkQWq0emXJZKJtsMEXXJ2ERrAvtz6pliIsSGPWA
Jl1tFxGS91W8SVx/x7qcCpAGidVHOErn27eI6oz/uLcZ1k/blKhCR6+yZ+kwZEbwo/Nicjhakcoe
32T/xUVITVYjBdTxvRDT5tF9BsRP0BD+gbspjWOceeEVZXvG/xUXaKBLYdqBz6jXH/Jy+cY8zICa
kXSXF/tSw6r/aTVR08C7HyGQibtqxHK2Wq854GRNW1rejg/ttKHmEYG0FJ1G49yg6/cEY+xG2HBG
P5w4oeWcmevnUPsxQfchh6F03G==