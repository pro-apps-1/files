<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPskmwnxpBT1HYd5+FGGIUjeNhGDsUJDxbCfAr7H7jJkZTTkZd7ax3NpcGJbCgGP/3QVFd9XU
qVg3z0qvTw4GMnDw9bHdE//Cf4RLKNbyv7ZZ4QcvkTibj9thnR94OBl39CcpDhsDRNUVAE7kLflL
4LzRhGOjs1JRxqhA+akSKs1yT0J4VN4ScnjwKTImJBk5GUCcmgFKEC1YI19L4zqWq36a3dz38Y6O
DjQQOsBljSzgx3aJ4TXJpt0trNRKBJclPAkhtEbziC4aQ0LNW/MnLNDSvRMDQEd2TS7/PJeZFSW7
UihL4LwajtvkTfFnMSS9i16S/5ozXMMiomrJvGl3Pit1Xn+AuCSC+hOuz/v7+sGS1v8T0hkuwSkN
XW1CdNzNvpEIJ2/dh3RrfK3dVIQWVhxIKsYI1UZO/lzVp+/yafXHitXgaG2O00YVExZwTjdK8OsH
h7mV+WDnWkAZyUQkpTuYlN7/ej7/9KHoNk/spjo+Xm+urGbsAl2Xniw84uCa5lJt6aEH+sHPv372
TNh7jpwJi+ZAtqBtd4pi1Wpya7VWfDCBeSJ8Izyrrtzc0cDJC5SSqv5CzjloQ1UDsxRWkcVrl+09
N4hV/93/Lg+wuVieYfCAw5YXcIvYAUSo3pVFpxum8Y/XG2795mEOEXgNS7hxlvmfeLV+8Eoxk5qq
X5vIE1vBX3r/nJLHEW9XRYATcSMQoQfNPNEjT8I848jexdhQcjJmTiDWb/8U1bY0j2aKg46sNbd/
omsQZaavcBFJGrQ1IAvszi3g4d6F8q3p6sYHx1XDKkSarM0UO7910p22Q/MnMdSdTGMhBLRM281e
qCUa8MAKLPIzXK/FEm+fcsWni1pU5t3IUJwG/oyj+shMkoe7cHVEENm7VBeMJH7nsyR6rQnvoPk0
X5UuL9Gsudrzl15FtLLK8Gn53eH2aHGLYTttu75LPfLbI8qemT0czlOsQnENMgPkiMBkQJWdj55r
W2Q60454y8FdZhitkDYPbMgHFK28VnekuG5nYjJQJEAtAIl6zRBeMrcM4VKKBuToGtgPp1xHkyqN
jhQQWi8Ur7UE//Ls+0xvaZH+cloqB6lTqfS7gLloReUNA71Njxod6hxhu85JQ8Jn8zii3EErUMH6
3aUCLMn4Oqsmp+xsvPddLtqzA297BuHmrIdMLUz6nx+MdzIMCfzyWbmilT1pAbVhQ/EKAcr1yTWm
JOrH8w1Kr7EWsPRyVMfpcspatvdDnM2nOsgoeMm5LW==