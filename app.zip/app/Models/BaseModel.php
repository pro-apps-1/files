<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvAI3FHlJ/NxTbEPrnfELAhEOT5hT+mo6zi0fxTlp3Mok0XJNM2P8xIsw8eQMNmovRwP2Sqc
IV8YRhSC7VtppuNiMYT5f9xDcpclyE0l1ddAeTda9T0W9wgKKQM2uyP+S/I1f4hTlgzn5g9DNEln
ZSNMWPz7vOHiSEkyyP3oeAgYg7Vw18nHZUYgeHPGYHWdgaBwc0iA+C+QXSS5OUksQZetvGuPg1zE
H5nWozvlwkEUsX6Qe3y2OElbPaRA/CtL71maKomXTnaoo+6tnR6d3X3ZHWCpRfXWjPRHGmrcmOsk
wK8+RzgiuGnEXI/TJgucY7nxzxUFLiQQDZacucQXkn9Mq2kaUwykPQL9/YeA1sVVTroBENuVYeHD
JAf9Mtvizq74Jjx6yA2AY+8XEMws524WKMGN6HfuvOOmmJeSTkagDTTaH7PW+K7wGS+quBjJUfxR
QigynJ7/lD2/oCpA1QdNieSknu3vW4jSGoYm6qVaqTNLXiQMypxTYhe1O7YfoxlEi9d0/PwexVmZ
r3ilrjxU1ixvTlhdp9zh8WE9826guZHCCD+Eh3Bz5CLtK7KnelGoqVhxew4QzKMSCD28B8zv4oJQ
zMKUd7Sia3lJe71c4xFIlUnvKgUvQYHe6uAZ1CgVfsqgS/8ue5V0VFfWiUXEnnBVpbajNZDOcG9R
285MEIqNAFhJ6pDSynPNX3Tgk4GDrzOLhydUokE730o/jox1Kfcrh5IHmZKC2Kin5OD98XReDuGV
KBtuUYYVsIKkbTmb6YlPUdB5grhwGfXtTAuE8rLtoC+/2vo4ClEHSjwFk8Qbi1C44b7Pq+t9VNLZ
+hZR284LSYatfI7qpdn1yJtzoDbcjonFf4EO6azUFwMKpd1VwUDtGo9W/dEjnazVGlWeyCzNKCZy
hCQsBejC1tTDAXj+0BKowXCE7MnfXS+zOGwj6LarQz00M2kS+6gU6m9j0XMaqxmFfmkGy05bsSuM
qjW5WJGxGXYDFHwqC/T4Y6XjFITqWC8vIryjml0xxTPoPvhOkxP8gLODDf+qVGexD7lTYBXeUACt
SOyConUVP9JGhufXD2S8OBvXYBqbiDr8u5QdgpfZ6Ui47WhNEmLSMYUK53Xow8A2bLWLuQWmPh4V
PztvRJIXXL8JZHALKPIYZLOuiGMj/+Z+MwlsEM/+8a9y0VEH/1hGJS70qnH5tIk8ZYKnIwisZ5Dg
b2Y1SMB8nkk88GUCcMBlgRySUFbMiwbMfhG=