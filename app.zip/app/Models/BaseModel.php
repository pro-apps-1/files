<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzGVfuWWi1klFTuogwlGFzieS3zzigaAhfwuGLH8GtOzNuejsERlzOZADS/B+DVjXg4J6jiU
6w3F7iHnL15jyWMXaG62jyL0zdcZHGvqqyn/Lx27b5nM47GRpovg3BEw+BdmIX68A0CNlJ81oN1s
bBsOVDF7RjvyTwWBf2Azd+dGwNtAA6xAZgBslMeCwTIIEQ7rQ1uiogUQOyNDf7u4D3P7HL70yjlc
nrdwigRY0xlUV7e+1mcHG4YamiOKTt0ROGXNlg30UZr/oXUPysMTD8bFfBbgCFuGvxPTNJr1deKY
E2es/vfwA4RIGHmWNeBMm1mYdn3NfUmBb4HanXCE2MzNozl90IEdBzHqi+WjPqIiYH13TbVryR+/
dEFV0D+a9Wxmr6RjXboQKuGUQA+/84ijc2ZcMdXDB2+JUGoP+TJuLA90lOJbmY27kxjEdgcMSV21
RuKDcdDkayeSsZ84ikkxa4/9oylPJtk1KUY1WhA6MtVDJNrhSAMDmWqCs8T5/15MLSv3BdzPbVCU
IGE5kvGmnYGERoKMh+qw3uWi9Da8BI3DQHP8JvQ7rFQnzAy4BcYFajRfJqHLZmxeRmD3qZhiYYVf
tYBdNieJx6ekFaWs9yCYHHPxt13OLmoiIrii0CWdKIF/rFbQe7LqQowe3wf6fHSu4dKjE70ZXeHT
kkty8yKdeMKqwV/VJ6tZuOLjZrpLJ+Ze4g9Aveqj3z3VNf69YeJ5LjtjzTw1i7JOSqeBimnz87qn
v9a280zHK72oxxrx/+wGHy2+rFjY/QfVT8YdnSDJYgoxB/LLRbWGWHJ6morfhh19cJeJ9i6N/qt+
j9G275gH1w+GAzOM2SQEAiAlzRtbaUImW0qpyQ5EOf9h8hliPlE9irZV2ZQQkaVlCawH9q7q4Q6T
m9IzVBCq2nGmffeaGkGiKX3C3D5J6LSKfXcgk1oaaURv+7DWk2ArQVf1hQTQ/am5czTmQas56vgT
pnMy3agYzt8zbvx6fHtJQRNz1Ds9Y0kn6rfrMyluU66SwDFY/tA27xIKNJfYwHsAbpkKAv8kuOdE
zHkqSEJT+EmYqeVw8aKLSfpvC+XODevA0ch1IsXp0Z/tc3/xyPGnPElhzuQVxYbIqZwoAwlGiZRT
+LPFDQgU7ZBHAtDFwbWLyV/5rWCTQ5iMxBj1KTz5QnrGU1wLAOFgSkgwj3IIaWDWDoScEkB381zU
jbh84zXuRGZe7Qp/0w6R6XdFf6DQZRO=