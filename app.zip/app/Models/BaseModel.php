<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz4XyOgnlScjJE1agIWdZxBYVxq6JSaqpFOfxFR2Dd4u9Y3PjOmbX4FLYFGKbRcSfe2PqBzY
O1t96Au4nYYZ1i9Biq2BZcorZhxkvgmN0QgFGM2k5/z37EkiKM/ewRytGmYhnxRwNctfFRwY6Mtc
4jVZpXGHnSjw40ktnpD9bbwKnfuD+8bA4DJJSY/n0Fc+rzyTQYRSAMFaPQmWAvqfTLob7F8cGcRE
aj/8h8O49sPcd55ieiG9cASFSRh0OGnGf8RRCu3yFzgvkwkOjFcu9tAV5dl1RFQiWzHLLq3Maauh
oz2uH2g83oi/iJNd/Yy+0+wgJCY3vzgRnGUBxxpl4dHI0ogvQyboX6MQZbU0DTs4doFKnMxAxj+K
T92IXk9j6u5PY0LHKNp6NToUwVM4gJTGMAEwH1y2CETSr1PXgAy8a0C+XkpRMYdwParlDSyXduvz
5aRe7+SgZzHqyZfcqCXrG32+pH7Fe4pv4cb8eZlUQdMDrAmRSu6zv11y9vxndQqx+3kPR5oCjQt9
KzL3XdauNU+2K1lHUIk3c2s301Y3VG1kWFJso05ldv6T6ahcoUiVTEsnjNVh+91vEGU2ayNaRe10
vMwRUvXFxOwg+U96Aln+MxM7RUDNHdBrjR8sxyafX6YNA6an0YxhaRjbCrs/P7iCXyVux88O5JQM
B2/MAxAwLaPmsqI0qwNrS+VF/EKVeQ43iEtaWisTIyCzHqy6GONk9WbGtO4xDQyewbA6G5U+0Ba3
mL6+fm79AhEVdqb74Gu/wHN1KsF8DRisOtu49dqC1vrwuO+Ea1azrLTfhBq/ZjuYFVyGCn6CAwET
4dEfmDllPBNy7oVwq8qEC5kq3jMhBHBrZnSs1nnzmUgag0/YXTnOG15HBA6kN1qVgz9ZVgeD91Ww
UTboyvwfWkDuYsCWHGfAJvzLrF3dWT4pcPlOhSzpk0adzLlqaF/RG5iSTSMEsEWvNmyR8C4/ydj1
SDSNc0ViSDlI0MXw4M6rZnO+nNYb9QieuUnDDoy/rHdQlu7L0sZfRnVEYBr/Kyijjoxe8ljVWVyL
Lj8sWZ8gBgLkQkrxToFdLMDaZ+PxjUwMQ4Kv8pOPUIXzjNOopGkhSVjpo83dat8e7eCg6WjrkKSK
lwrt7ko73W+oooB9SDz0WVTMnuxLh2uSTBzYXNTfE0iFBngudwQrLLNyuYi7o9H06DGokiba0gkj
LCNnn0smMNdUvmg8nOnpDIA7pwf9+X81hE5NkNbLlIXSHE8=