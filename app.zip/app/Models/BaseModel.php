<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpuI82q7pvW2tjEr3cCfLhEAGO7jEDmEciHX2X2NvHYIdVeQN7NUuXUilueuYm2c3fJ8WSnf
g6BDG/9EXfsfcMSL9HWvJKrJd8C7mZN+c0bafkOb/stFljvaYqgcZsmLzbb26xdnx7GQ+lcb3Y+Z
RDK4x1EZb0LcAGfE3e9MUHFOfz9U8Ho0xDUk5VRxOSvn3zMzZvK9HOXMf46YPLjYEUz1LOQFnAl5
MSYrzbiM1PkU0oUkn3qae10ZBnQCvwcbkBqe+PaEIxGeeVafOjSvwzbosPLWPVuIVsnm8Dohpw7v
Ow+CP6iP0xRXEbrSwsBFItKOghgs55Ii+U4uf2iES5FbbxNI0fMQy7YCog3Cwl3tB428kKX4oGgu
p7nfMZyuKiHd/2p9YrTZ4PgXkiXYKhQiwoxm5PaBpXbP3ESH7bEU5ReQ9hR9P9WUguIhpbDTEOGZ
CvDOHH92Yr/Huraa1g0SGBCimgzngKJWoN852dfWQubZQhCc8VRqvNeo+dp/jwv3gWJKEbNBiPQH
KBBky2lqyRZTLT8SjQHJIMH5eRuhqvcGK4chZnQXVMmxqy3C4FPwUVZ6Bk7NHDLjIx4/MCsI12tk
2ggD7oNEgX496JD1xYYwjGvNlhV2vS9fU4sBPw0SuxuW0WLspv7Avydn+jqVfKUq0xv0JAHoJ10R
DuoqgS9pVOYfRrAEzmBQ+XdtyQDCJ20ulgoR1/hnbYh/psyoa/z2DAw4qIBGjxtk86q+Ddw4nuPg
ZyyX5oVzhC8sTd8xoX0YbptnoJ4zByzM1WrulYeXRKkhVbstos5WX/0SlrACJpzs18D40ZHk2P0h
mP3DZ3EcLCQKnffZN8/95TKo5LNVleLOiqvXCertOO7Mabe1BaXy8a1xTcSBlPvq00vGapK015T0
E9BMdQG1EeHH7cldiDbNKfRYUI64BlHSzXm+sX0pdAe8939eGDikcqRPO7gpYVn+Jt5zNBQPYaSD
OZuzuxvYNfaovde0Ga6rLdyfX4FLYuzJpeIrT57WCLYZcm/M00+vWt49xlOJTGM3Hzy0H/b/vEwh
ne22oaw9NGvE4TAloJS97AUtGO4BH5n3a0egCVnUmpxEG23kKPLPhjMlvWEZKlaBAUynMmniME+g
MlRBC7nddrkQzMjZM+NGu4OeKyUFLrbaLqS2tbgxF+2hCg4Iq4qC/8/Ry+s7VO9KCHpQi0eg6ZrA
TeApGt8hBg7+xe23BJyv/Omi0kigLsXqdAtYKETU