<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq/RiNWgOWf/Cp0aM/39W23ivoiw1IP6uSvl8GS+oDCgqmbkjmh7cGxnGaKrcGXtmtD7bR8/
VLfdlrHsWKGgZTo7f7BxG2XrVsd8W9U3cVMDUiXU1eFoTN5I/WzkNCVZ1o75w8F3N+YZG1Q9HwLa
kYRK3jEOXy0kdXbFrYeSC9YhZe0hnrNHtpONZqXkSteVhAZ0cSK2uOyjwH2JB5RWsbXqzVRZEInH
tOy8JiW0WpeSM5TriWTZjcxbPlQOw3DuqPQFfklfQHTUxTZemLH3b0prRBqlPmiFZYl3WMkzgutO
5Yb8VF+hMlMLoAMM+7fat2/RDzf1ednEY30LaWC08COPh0cELpW+YRcd7niMBD7ZQBlNd0CI42nw
uHE6Dd965lbIL/FEujvOf185YYb5KChQejtr1nHSLnt+0g1O4uzJClOiNhGWYN5TPDrL4cBVz1Wf
1nZDfPhy/apNHE3+rD4jLfuBildbGoTN2v82KdXF76drJlPOsmDir2smaQO/Awq3+3LyupVuNqfm
fjNxGW0X6/v0AohIR9UG1RUT+3FY3fj6Ey5lXrVpbvTW2GwK6JRDsAnEw/kcYI9/JzaG58oQfJ3R
xqcUd2z0PCRvm3S5FXtVHMzkG30iFkwXZpLP3KvCQAzch8eNJsiUNDAbUsErdjUF9vSX3vZRzPn3
C97FZxg34n9Ph9O7AE8tkp8igQg4+QXaxtIXPsjpxq14kN0d9MiejjlW4as0ToiFbkfIGZyTN6ej
qQJN6N6D/I/pEE9Q9YTV12pX1c11srmavsvAv8/N91EmgUBklXerxDWJy9EJ0PiXARdCTmOaff4V
mb47UDR/2deD7n634bN9XDfosWEUYjRl2DuTGF8ofM1JjyM694PIZ83q3n/I1CSN90wcqAmBu+m7
lWK813bjb3w0gUT+J2TKcD+PSjgUgdga8Fkgd4PGI4kDKPO8jXehBgtYwcYtlnbir1zIb9a1OXfS
AYi1SYlM2HB/hvfT9nbXNZO6bLrU904gvuEDSlBkvc2sLO5qanRi8xLkynIUKkLHkQhWqTJk9c2P
OME17q8oIW4GGBiap9+v6Qc5RHYhFQzhue8c5zH7HoAq7uquYtGih74su/99TPfmJHvY4ol6zyRi
kN99cYo4oNoxzBJh9FRMAz5lS6QbmUzOLMtW3ziKt+NzPWdD0XEYRmlxQmTKIGVsUDDHKfMemP5o
A6zRqvf8dOwDAO+CJ10WHxRbpY931c58TW0Jxu8i9gOQAtuvpJCBQm+8IWmqDZCteIHpY/1TgBr8
WZCR5Ujo9ZFmEABED84oX/JlRvdkSJzB0l8GGsWHT3zj00T11GEkWrE5P5dxIc26Aw9G6xwjYLzz
bkqsIQ4Fd4Yy2zwQBaTWPbp89pLbGU4dgsntsZtZyvN6tLn5rNuOkgT9Zv6pwbcNeXYCM4M3hysH
uxUJ50WtsQzzBuKNPTWO0OPA5rr+JBcdqqpCLBynYxR6CeELo7DIA2NlzJYjqWYRFebF9Bh8wVsH
7LiqrKZJhRi+TNhKY1CGrycwNJHfWhnpN8W2EAGp5sIrBhwXFsaM7G+veX89qy8l/0nT6sZ+Xm4j
xM+ACHEhcPijheFLkB8Eaezlc9oxFXBnaXdSOYj6imw0pChfWEES6X7qn7d1U+GPDN1iQMlVKWOb
QzZUdnzcg8uzKuvu/vWv4OUbgQAMCBUW0ggqRxIeBOntaBaiLys+dHp0sPlj3vj1MarLRy3n9By0
529Z/cPRuIgrM1Xikyho5+LvfkCaJQe/LkCvxBQp6cfnvwxj7laxUQYstnUmkQeUctm2yv7fWww+
806LucJT5XBr0lgp/IlEm9Mmq2Kdc4L+/IJ7VOgiCUHIYdiS2b44RRPWyTiYvIdty4FLx1WCOHF6
G/NhY4fDpVErtXujKurvgsUF+SZBbQYX1Nv0cAwIj4HSgy+2EFLs+m8mPVEAsUp8ApAu1VqB9mgV
5tyZRsrJMXIynB9aRXrEyM7YnJOhQw7lrC8/km6BmyNfPhVXbsgjMr97+QMkCjqvfs+ctv2/RJgI
59+TACXaalT0hiciiQs0TPikRNfXDrwOZ0V7O/FWDSGkrvdjSHrYvmrYptbzPMHDr6Sk1PWPBYoI
8YitLb9NCEqnP4MIrdMTLDUyzwPg1F4ebN4SJY0xXiPzgAL09EgXzheJe7mvOCBnCCKeIaBiO71c
pulK6tzK5ideZrmNKADPJe1jjn9vb0iG5D+nNmOrI3Bl5aYBuR3FeOig7AoWRM+uNBHzzVz1x2vj
aoIo0wqF73KIbZhNGSFBgFXIWa882uoeHF5Gfp/Cjz68fue78qHMwRfBmPoTPT+sENTWK/uJv+Yc
1u+OKhqmmtt6FIA7We4CiIJiSqBI50GSjThXewumoYBNt3xKzyyUbeetZbQ97jog4UrVK3dzffW0
VTe4vHhLbVCeS6iRH2dupxvYzeAjfY90u/G78e2JE3QyrMSU3Om4MBMeujvJIgutDKm5x8UHo5kf
AYKTnb33V+NTD6+1mr3LampVKIi5WCXFtaJQyFIRkze0ajDb6EOf2kpq/zxT6fR4mAajfkHWzcws
o3qJdL8evpBASh093Hk6Eg8z4ShKD9nKJX2cNP/tLHQGHNMEuh0PsLIB/YIyks0TmK6LI3P3QfY1
/MRdfJgC+B4l5inPLMTlk5SsP128rpEaUDmGOWzG8bt2nPyAIhMq7tXpFdvOiuPQoU0JBvdlqJHH
86rgXdJMsnatZktM4qHOK1hl9AGHXOMSTOmWREULXmEW0jFOcHwr2J3aamiHpvMN+3ruZxVGwSMp
HpHdGFIXrB3boWG/Cf7gZO/zhv+70RTWuctjT6NTzXuz3oyVErbVS8q5+cQZ2YflOQLwcZxYvLZl
6Kny7NgBZM8VN9Kxu5lAXqp2JAB8m2lJ1hlJSOVBmvLiVYl8onYpPs3U7ZhcXV2dy0KjfnN4k7vG
I3OhWZ+XOLkq/H/nvqUhZnx29morUuQNp2ABFlzv1Ii7ZenIDlGabMf3XI1qPSIJnOPUBQdHvoC5
cr719kQxB249ZR5IYYC/wOO5y+d9xPB4COQp2VwGA4hIW0PNgDTkKxRw4jZOlKR1+fKgeESMMDw7
NUJB+lGI3sZqu3SY+ZHhYvDip0eU5fpssX2LME+ZcFuJsmIReCQrDqWL10OS339zx9gSzjMlgeRf
+q0kRQhyOFh/Mwox+Elt3RVlHeOt0vykpAjXfUAvzII3mKWGQ/V8mfTJzXZNRD0HpxstQU7OdTfb
XkDbXurVHgQVoL9woegvcIi0LqD8gr3xxOoOVWuHg9nyw/jiHH3y9TaaDsz4gUhxO/7+AW96/Qko
CGGu7rdh86stoLJx1dSmyC2mqtkkCQqZGMCPnZ2cN0On7w/Xf0z9tY3UBTm/BECDoBRwc++XhnQY
3K2FN9T4Ao9FvAmqzlcmMGAgyZ2+2IzFSQJ94ummfc4P/rUp/EmQ/pYKXR4Wt2lYom44yG/nyMlk
SMORpHod8HrqfAkaKjMoUHkJL2s0P8RsZ0WFsAISDI0rnASfa4Vr8oU4+8ry2wPgu+Z38YV9RfVY
E04CY15+J3rZTKWZ8ixMCG0jBLVn1f7D0fnyjv/vV53AeyUWkHEoaY13cxAEjY7FbgO6Ga1FqvcK
mDxDanMDtRwRqfkE9KTYYkHcR9NSq39EZosO7T5EIDMbkg7r5SvSLeCiyIZq3+5AjuMDfo16gP4f
m/W1+uPLCXcAuRrxbWk96I1iD/tEXdKG6wC7Xw6h6QqIRVyTilyAcL2qfdJhmdN7rf9r4t1tcghu
rDY2wfsRr3lE2NLiLRosdmIs2tdNp6wtUsMDy+B3RNmwQmUi1PfUHdQmjgte2ZC2WvpxcwXrzwiM
kYd0n7QEwFZVol0e6JibCDe4dftW8ue6OT+T3nmWd3qzFOIEVGNnwIX9NBCgLyoLK6gy18jMDRS0
jD77OFuPJK6S965egmcDGxg6JEH5GP16M61EOVwSEvXT458iiEFVFlYFkbbVhicVuoS7kYoZT50H
7pfmGU1jv4GzMOFb5ovc4rksrtz/OX48qaAlrzhMMF9zw2QgEW8WSPb+7wJodP3bhJVwkhlz/oc0
60V48VjJ1b8+WmmzEPDO5RVMdwlJs1VEVAypvC6H5OUUBF+L8ARI9qu5h2M6p5nhl1t4+A47wvXb
I65PRj2xol1f8lOGEejCfIHawAWZYY8ko6DmiIKITbW6xXpNZLUPDRE6QfrUphlYAMJzRZA6QzPT
q50IHqwifEMtUFGAHhG807zVULhpxZlEjnLK1gMBvV717dqXJfz90aTiyCt92zq/B3SrsEzaxzik
5PplJfG4QoTCyT9Ydxhn6ptPu5sXsAXEPqGEXZwLw7f0Cpl31CXC1WfJ0T91cJ1gQwV4bYVQB7iC
RED5xrnw5BvSAN3Ol9/l3cix0/V9vO1P4Fa0FmVr9r3ObtZCqPXo8Jt/TgniQKzjcCAhkl4NSK2Z
8DJoVojKd08snLbs/SvqSeaxnzYplc4Yr4GkP9hfujyqwZvBOEdPEbwiyl1YbQSd8j5HnRx9Xa9b
Cbcl51Rs4oXn2s82Se68rn3EAA1VE1emvBeKdr6MO+BfeVuQ0Xufch2Xj1s5WaXMXJ1f8R2oqoAL
YVZUPQy0ieE90yg23d9nUab2IjZeNfXT/pg3+tfq6stXzw2BrqpTlkr7y0KAX5h71JPdi3K0LlHG
A4fBAexLugKfTP22y2o6gkO6hbfODcioHUGBQTeOt0PzqB39TYCQ95UyNe4ZlsmaWcX2kq5UURhC
38+jUiQ+K4gjeKNuQG7sYKGx/SpOnV5WXCzzlL+gEn3BmCErHqKD6XWZRXnwV+7JWeHY9rcTB2Yg
WKkFTDJyXEUh2433PZEZYsoeASHXKTq0AsOnKIhmiM5RJzRkhWxwPtVnIDpoq3w8A5YRX7kODIrg
rQlfUw9YyDyKmIcX6GuzIS94Z02NCIZBC3ggDtt+XOMgCLTb+S9hunUP3X5sGHHISTJjZRKspAwS
R7GSqRwRbiA+ei/P8NN6ANRACfwmdubThd1gfYdkQQv/sXDV2vZ4p+478iswGdOju/zAqfP06rtW
gQAS8azuQpsPRVLb7HvU91Yvyy9PeLXE7If9fPyj70BcSfNM6pGtmmz26APz/taouhSX+VkV6nqs
9n/PjkRaY7/cjO+1S8VwWkICL7Sts+1m2qfH5VIZzveReVLETDZFab1cMsh7oRFF9/3K18XppXEz
qLXBW6tVl7nWysC02RPAW/t6nuG4YDcah7hIrTlSV4zhtY0idZx6o3LLnhmugEtRmihiYYOw2enm
p/CIQqPa63sDtulz/CwFKkoQQA4qQRucuy/CBWPcVRwkBo6M5KkYNXFmv//Q6uAX7CUGnAZtYPA6
VFK0VWgyenn2c+DEVb+mYeZCCH1wCtRYkYTP5KCY9486Z+8oXHYZtQNIbMzSL00WyEAQzm+2KCwW
woJ3gPS94kZu0kTFJr1lnaCuZioUw4HbDCcqSH0OoMLYzS96lJNlA50mId9PuWGeRZIEWpUgQf91
/R5shpg3lr9+G2FP7Fk4B9c3+7avBwowWvHsCqI+L5g25XSFlBPR9uLTHXwXEPbAPLoLETQz50DB
0bddGKyZhS3HtrQAfatVxF8Zz8dhcPedZ5fNxnlgeZ1GgjxNG2RE0wVaznA3bo+g7q0O6iQWCT3w
jcOMIEVDJe2oKAr2mgmYVkxHDu5ZtUVAbGqbK12/sigRDb1hCiApoEUYZnU5Db3q/E99X1XO8c8r
zYqNzfu9YQDQsOB9DqY7l57GkHfJhwrs5X5F44zX7ULZXdcODVaDobD8/WIlG8ZyENHS2Vy839NQ
I8v5se+he+PvSTx/HTastkSoiWl1UjNuZ1Hyw1izuVpIiLJGT3j4i/ei0NUTYNNVRu23nChiO4Cj
T6Dqnc+G2pKQKjy53WLvekkWSKneywyTAaLHeOHIOhCrVwA9vjXI0uYLT3Ol5N232dFlVSNIB8Up
WWXFaUz0gnz5GjAwOWCNR00m9hMy3uSQ3y8p/p3+lftqaGKF8N2Z4Pmmog1aG8KUhJIUXQru8zw3
HIVxjKk4t3xL6PyW8ZdZ+01B2WYVmtlNlk2xtTHK46RQ/u5c2myrIryjkdojSOGlex4zV8OPxbHL
JFUj8J6Ls4WRCMhJKNsM6ayIFts33fri/nMffZ88lVMpCJAA4U/+UJB5oum4VHcR8fqs/oi3Z/X1
fzkIsc+rFUAwjZroAP80+uB4/rpLnuBHQeGZd86FYEGS7uTPaOMHmTPz24fs8UPIJCe7H4/k+9zj
XV0wn5IU57rYIuExrNUoqmDa+wSgjstNEBf+41gR8J4W589MbngVzmC4hRof8d4uabjdA0rX7Ewt
9F8sqCbe8pVP7UCscL6daPhdJB+yVPHkht9M9riDBVPbN2bdV/lwysWNwvbj2HV72GgYpSnz7Pb+
cBdPsBXPPWZH8LvgyYw+chRZ3SBv+OVv3staolL/KCLxyX7gkaFSpj4siCSqfhHrdPXLNnB/4HKD
22AIP4q7DiesNa9POxJJuRvn3zexKjQ7ccie2hu8ne+aYLwowAiLltJXdhDNMC0cLgu8HMNqioUB
VCCQS2rPMY6XwB7g+MmxxrtfrYkgXurNov9a7bxsZ0SJhHmu9e9fGPBIuOXSl/0ti0Txd0I4HwUX
pwc/kdxmUnFcWPhoRnTNW6tBKa+vAFgJnyhnsVDbiSvNr8ZqBebNK0FivbTUJE7WGhSxXC3jECq+
h303oCvkJbzKTzPZBQh3EzXX0uHIGriwh/B7BxIDBofOcMxpYihz8oAvMp78WR037PvsFXq/L5A0
JTEj+QYg66dbrU83yhUuZIhnuR8XWSGoVv4b8zXndNKdtuQvn+5Gc3xoT7zDqroRfHwwfC6TjtIK
l+E9fihP4/FXtByXkjWfwWvW/bdkmS4jEWCQK1NxVxxk6m4v0ZfxxldR0VkcddMqNvYhUQt7D34v
+w+3hjpCU97/fIkSK3da1v8OCGDXo94UxA0oih01NqumYqF1iGHOeqym8LkxnHKBJCLC3o5ocT8i
druORQQuwvmhfRKHhrJts6kXcQ99ER4Y9fSFab/uz9wVb2n8a8WOTfIBlMQdMwegm6iCtYQKv+d+
6+XMjwOXcQk/qi21M51Wt0jZML8FJ8X1V+okObraWfidCX7HRdBdRXCe8UrcRn8J80uJV68HUpaB
lyFNbqKskmrPdC88m3th7fTSmqhHhCUa+oSbbfI+HLnarStbNY2nXjG6l9VzswcXooDcZZXwpLrH
+8TP1iOPS7qUm5zXoYGTDEba9sZWupjoBwyg+Cyz+IwalFVFhw+vAerqAf5NqBv7HaTSoy/9zFCs
7tm1Rhcas/ipTNtHRnTaUkz0BzBO95gWXW8omWaHW97BMXIcwc+wUjQduKln2to+pE3Unal1La6W
zWePqqzacyt2jlCqdeleKxWL0dSVYyi1BSwxk95E7Z3j2rkM2vU3RSONh+Swuy3W+N7Buix5sNd/
+7aYzPBYg43a445z1u7D0n5jqd4pOQleYSrVq7L2ibDsIrB/bZTwCRAhqVyLnBYiL0ZcRzgJDZNx
W6CNe8aPpBU4+a4uhAlSrsoj2TqmzEamNnMqqOIsONRMet/vTKD56FdBcO/8zigMb5Q7PC079CrB
M0CkMoJPLWwxgVFn/yBCziLc18nhqRZJP4y9enTfCiyFj1tK59S+Z09xM7eWhXv7+I0GTggCg/qV
ZoLE1RgMEakYdlpNFSnOOtmwO/LC3ynNEXIjluNI8xTOluXwdor6WtpZA8WBz6hxNo+Qg1guqwYf
3sdYyqxZJzNvG+JayjfnsuRUCtDcAjjzzw4PSOp36mA5v33RPiTkpPF6+CO5vLo9TIdcOyaD/6XV
jGz/glZ5C0eTanUzGviG6Nz+a9iSQ8Y8NByieAmGNDEvtkxY9pCTC1Sc7uAzr26Mw0CqxaAxsEQR
T68iRollww8Lk+a4ZfbyQTOk/BcBunmqVh2H7IEBz9hXvWJ0UzPgQ7KbrW2i4xQAlMfISkzKeRKe
a0bOvo+RYukc2AVbd3W3YzcUl9JfAnuYnN4vqPf4xEIIVMXqis2hzix1aX06QkTngPeezcoAL2+B
8ueR6O/OsdMXhg5WkrZapWa43MQQ/gddawriPMQ/Zbt946idQ5AuIEs30jqQ1UyeOIOBZJb5zN8h
IqFOOgmhCSlLY5x+DP9EGm5/qxpun/0gy8df1q/Z6ljrHfuzZC9mra1eW0OvqDGzzJQxuvM5oWji
1nv4P/KkEn10GRQ7Nr5NeKZbPXlSHoPdaH5/pGnUnNMx9Em/TIQrl5g3lqOJqufZ4aGWOO/ZVce6
059FdWmKSMfhqxu+5RF3GVcaBpXiAGOqsV1Rov1tIhVo/OHt7bjh6+tw1VlFLuZkei7JoOprycGR
Y8GxVX5D6j7qli/hemIMvYM7R7pKf342THKCBNh95L3pDc8hv0liseZOMfwpOPNpW5X8M8uuZHU/
34G0TBbyl6DUgnGb176C6/kxf1PgjxGHYs2IbFOY3GGa1opClPlLzpOS+xNfm3v+Q/vjXf9ri+AG
JepCXiZWU/IAWMFeBJ9TaJi+s0xfh0REJwgu3+X2e4yjpkv0+HLB2T7ONxOxAoaMFHOuHJzMHE+1
8eQukQ9O6gl33v1I1rXH6+ir4R+cmMoRnmOLlIzFlynPPr4pC5MVz1Lu40KVdJKDXWG164YyeiQJ
UI+/Z/V0PsGBB6gcMEytgdFLx87V7OxLjRA1bAE01A8B1KQxo8YLKlUZVan8g9czimHH9LMpQc4T
VV9UNy0q5Yz4BG5cgu3tT/j2IPEzEreIDZZCm40afUAZ3idjCwunBJt97XJ4OXYdHH934F5vbdhW
H/7S2Y/CgGsUYO1MjDp9P1w8tEQGAYCiRM3OjIweX1s+kEo56MMwxDzFUmTHkpz7FHHudJPx0YcQ
SdXYQJE254K/HEG8XzrT2vZwgy6winzehTAhb0yRnuAU+plYtDqifWs9CSnm/91Cr0tmAezQXY5s
bMLC3OLvW6C4ph/L+1lO3T1NM5RMsc6yCNXkNc54mBdkoyL3ddsGXCxZgfb2uL6HN120M3k6bBdx
zZQ19zjwqZUIZHqgpTd0wcw2aquxJzF1bIyJZmC/l11F7+eY4e/AFgO1h1JJBTyT/rhSpf6WdVeZ
M/8dhlRHtmuMsYdI1XzYieHiRK2uDlBGa/Qun6jVdsKwVoiXmvPFxgSegGNl2averjGhHL0oVi6v
fYKPkPxJV0iHZrA25eEnYjvo4P0eyTB5V59PYNKKoq/NRJ9TNDurNijZ1OOI/yvAsht520RVDYWE
bnCj5C4r7S5BWSQ4laUL2kgYKQkXXyptYzytNx5c9lMNW6wFuqC1CzHcBGovU5eY6LSUk9S0PXeY
Il/zRnUOwPYJ+NF/86aHdHGmXUUBScM8YJV9W9mJrQ60j7LVRLzKSKYWPmkgOVhXIEV1hU1ujGMo
3Ra81o5lzfO4Pp2965knJnIH9zUZWPcnzx8MkHInfv49hIxubE4uhzYUZd+nRg4ALhoWAu3qn8lD
kCPLUWnGXOtLG2d4K0O/a8tjVP5Mj5IaKynnb1hL6KmG9jC4ALEGRqSSBvV0EhHWWux/1RkOL2GB
TXmvZ8JfMSLatRJEd6ZjztFYIgYVjFDwjiC8+vcWcQEEFo2asbp62Kp4J0IN050WUDHYs7xqKchW
V76EM8Y8kANT9VZdfHAXyS84ANf3Izol8afDw6y3V6530P3d3Ok2FTOdAZZScVPeUoZF9pvUcphp
wsECPbKTqlsmTsYWL8qt0Xhq6nzeWmT3dlGcSs/Od4ALiSHYhbNATa3Pg29kNup4tadKuX3QoH3s
cE6bbjOCPrymxtHCGMvgQSGVLtaqGWYFaeNsPdSa/JFV8VX6Ve8+PJ7Q4j+oqbyDhrfyKMviW+JL
EIkB/fboudSrOpZRktrOAFgtodOXrxfrY4PD4Mb3odTj4tl6NuUYociAexYpCBEurCZZPN+6k+iW
PVWQG5eAtWg5ghKrz0pVY/9VaK9dR9cMh7OXcIc7+5jcY1+SrlFg1ttHoUnYL/t5OStJS5l/2tXE
/PhxsAPnPo9w5pgMDUeQ2LHPM9fliN9tBZ4+PkjeFTGHN+07h+3Xkrb09q5A3qCJSmeiVFh7Il+R
SbRgSoOOlsTQAW7pHDb1I4Dkg3BBANcSKQj3vaGiCkHrA+wlz4BM+BuIs6EgHKzl1W/AoSHGggFc
Gmyx