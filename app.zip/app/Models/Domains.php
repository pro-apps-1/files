<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnXH2BcTqV2+MBoTcdFiGfO3JpJubXtRTe2ubTv5rypVQfJPlpvMOv9gfg1lg2PXlm+riXQX
Fb/ZTc8Ul6VVw9iT+y/pHerQ0XcEeWGdgjtR8nGHLqDlhpuD6PJwDDR865qkpKwm27M+ymYBK1dn
D/ToKlWoUNhH1GRv+KwgWpTLhsZt/fAzLeSX5uti/I15siqwUg963KqwFpi6Am/EOGIJi8yKO9mI
XyRGmw+pmJqjd/tu54G65krKoOF/HOPtAZ4r7xeLASVpR/ki6MzQ9EJRHVXbH0pcdEiqq75N4+mZ
FbCR/pRH1+d9k6guDYkl3c5cELpzPvo/svg/RFWW06cfSwzcdd1x+O382NAR1nwlvGYY8g49S8UU
WyHrOx6HMW2uFsL8RIe9j4XiU/Q/o+awLIRQpNn0x2iSU/pnGFSfWPcAnmpcvqQJc4s4M2b5SeJV
I1r+/edCDRfuRtO6JmUKEiVXbDjlQT/d69Rqs7A08sbkmGRmlsN9bGhLDffQDXnXITRPyO9MsMNN
yCee2FE6Gk8vp1K0RJU63GBfZ1AEI3cSQtOCAhdlvvjaECF0NW8cHRkK6Q3D3k/NSEfdvuZDFIN0
gzxEb9JzekXdgsOtC2uiemLUBH36TFrvW1eupnEp/JkOfdg1heD4gaC4ZbxT+QKgrsqQYzILWJKb
Me2frjMrS2Fvefzo3KVyOtEsT6qTxU6Dp0ZycYUy0rS4HS4Ret7FbyoblqBI7k6/fKIv9S4Wh6P3
prlIzCwgZJJOTNfG/td21I27yxEn/wZLKsXKw2GSW/8+UTYzlrWvR+iBJ6iKQkAQdAW6y9R2eQV4
EfjnS3+vrSUcTFpukd+RD4959HXSw6Mtdkdgp81DT0bkGPdehB+zmkBF4esF5RpXkwVsxD4G/LGt
5EibFzqZWuzif65MaEUGpgWgfetuegOuQt/6WJu+WdCY87ObKvJtCa+JXzDMpLeN4Dvvbw8Bfr7l
rW6/X3DJ9LF/NlziJXNomCiHxR6z6kJXm+9y87iMlARhhpczjDX2puZ3MfdI9uxRp0jWNgTXuyDy
zOGVNIFFeQttAp5zz5U2hAhNZdvqkMrb2LqV/W55AQOE8FI2mpsj2PkIoWtYhnQRjkNvYsf43yaU
OM05vjhXK1k4BnAiA4OGvZA/vbv1piD8VBY3rwld32KnBj/aZ99NlXPx6Zd6TYVOjGSjJDoITKL/
TQCSyBAQHUPqQbdjokSpyVKrdo6JCl4snnjJC2WSaa3zhjtyMhksvwSbtz5JAq7EGVp2Oau5ncg7
hMQNk4Joi5rwvVmphn6SRy/iMkOIfVO58mqcrJquICfivGOJ01Wh/wNrqTPOiyrvdrnnHbVoneu9
Ng/oqGzMNY2k0B5S4O/gnO6qcOO0H7decO0RajO/Mp39mlENMQ5AAtjxVXPvysk3VKgg/9TWmF5S
4SAB6JMGpR5EQbBE7LynSArxDzsPyggxmaZfT8C1tKQOOSbCAHKpygQCeOiCUIWSGgf7dE1Gxu25
DqxodGFHrE5kch5kZf+nDLbenV+JLwDrj5Z8Z+f75TtNm6Q3wZyUQU+1lqtZQBXZY15ZWHuomlx8
7ElKV4VmYXiLe+XPgHNC6Nqn/OQ9KOj/YJlK2ZRzKg9RDg+9gcP0sm7wYzBGEkwE2XV3bopATUE8
5HWBcg5TCDy0E70Ox6BJlfM+3E86i5UL+1yZkKO0flEoTTS7a2Ow0VEQLZxaAvD8SoXQaYWYCk7m
OgjQieecvAPj8caAWQkrR155TrN7lUX/qbw3Dli3AJdNAp3qE1VtcHUuTZqeGjg+rgGHPK4TbtgX
PUsJ8PKil9NBPeTHG+ABrt3Z/w0bCs/vkc2eq3tYwBqaAx9txDzZRamh4Jtq/TczOrs/yMWWZ+L+
gU/X9wVQjPl4PcK2a73z4Sok1aEKKKi+PSUGgU8l6ah/4VTyKhkb9sEtDx50/7WWoquxZwOPadr/
MvU/1AEZm7dYpIH/cofF2au4t4FU1vo8Qs0VKEL3PCJOMdqfsHpmblwXU0g97zdwE/je56Y9LTtp
R46Vg+/nNBds5U4JI6934lJEq3WqjPjtPVsnjvrTL/7At5n79HGg2lMG3SnZViugr31K1wyrGFpO
0j8bQ0z3YlXnO+54HqzpBLZA49s4Oag7+ZAfSLWHaPS+QdZTQi1wiMUncWR+/FK6YeUScI0bHQX2
HQM807qJ1KV/4FcX5BBB4H25KBCxXwK/XHQOhGuJRUDoGbyML3Oq+44R5SzcKJI98/nOFZcnCK+M
sas7k+dbZWVfcZV5glZgxb4FYXQflC9byHeKkS4eSdFGbl91doux9V7xuD5bISiqQe1g71e3yp96
PruNIJ6aBb9+8C8ZFGE/cEbxyhfLcma0djsFdTbvJWFBUYY0yC9WWe9Z90ggr7Myb56sgTxWbcVA
vI19B3RAOC/RYiJyUo3FjdkZuS+HRhMd42Mbmf8/o6fAmVWOEIViUHjl2Xbv8Vl+9GvM4tI3EDNe
RdmM9WWv7Dmifvb6zNT+bGpPgNU/a4k2GM/gvxaTbUizXmi7taM+QvkLskggzIDKq1mSd73B5SMl
Cz96Qv7ObOb5OnzHV5kAWPYqf8/yjUXwozGRmY22W7AHYDuPC87rWfsBKxXc0PL5RiziGZje34CH
iNg6AiPO5CRLQ+pr+Qs3JDxcME620rCz0PoNtRf4wAEmNZT2rYN3eYUGDyh/rGpqcq+KzLx/946E
2AdUtN8ouyPFDC+9ygQ6e0yqLy7Jj2pcJgka6VflmGhG27TG5M6lPyDwv10l1SKejAaT0k/LhRib
2JB/Jx2miZLcgNZZvcAPyF3GcSv/JB3IePdR0XWzvHZK3htNfDT05IAi6uJHB6e+tLtGOS+wEybs
iDvX5TFH0ua6SIAwcnh19Zt3RG43/WesZV2BS82m/xOGk4i527RVVtgA55Si0Zk7Jcr1suYLtuyY
iAlUpPkNs8PMgqYdmiKlzqmQrAX/A47B5Spw/d1iwAC/h6fnLtoxR4JFy+9dkBgkzHOVWBt/MqTc
///DG+eDwH5ds2J2WHPX6095wIH4KNDZZMvztqKidJ42X7sjESxehzvqSYlX5cxUXq7XHyI2GnpL
Uu8DWJzM2jN2i9UfUnHbziP1c7CjY1SLLDd+HaHh96Zbfcyzts25GKNgBz+Ve4Qynl4kXoxjISIE
/z6KEx0cYj2Ye71lbyHOsHi558SGyHKdR4Lyq8tEI79W2VMmEtZco+AqrcbJhcJhi61LU2L0gHJL
Av33iKStjRVi9DBMX8RP8N8salLZRZ46jBEOxiCs8Ylrb/BLMNa4VLS8Btm2tW2rg+y+gJkJJmBV
AEKXVPvkHYMFBQ9bkFA/noTfNpTyGC2TA2yUgu5IaGzt7fYZcLi/br9WFifFSCzO1nJMWFv+4i9/
6sESSi2Crs0Jv0MPIMldRCHDg31C3OQ3gA8IOfLtBfS3ZqyQW2HfP9SVE/UjlG5pDZVBILfCi6L8
ts2RuCP74jUN5O0zEUd2nstW1A2/dxSKU9tDRfmSpqMfpGoZTEP33PF0KjYRJrsR166FgX5OifrG
HiCY17OoTV7XpvHQZNpNntlFERYRnItI9cq8vOPJg6JOdKAeHMCBJEn6CG2OU0UClQRKSCokasNB
ksQIG++30JCZLokShwpBZzK1ABZSckYXhb4PqeNCLflPbpTpzOcqLk0cuPQVKRxldIhZW4okS0o3
iWIzOgI0gTOL3VcxUCr6CpRVNz5H3VYSH43lbvHfk5jO6sEmHlI5UEwiVSEtJqT+1MjK1G76YEIk
5d3T8PXrI7Vd9mNeEtQ0sWBhnseN2OV0pjpxS6heDKPT+RgRvVKO6XHX8J8zQUDXzBKKUy+h2tpo
A9ms6nWTgIoqf2nP5bYEMf7hRSCGRZ2r3UAzUf6Te0kDwvVwpmb3o0IAiYVjEZD+NVpQJBv0eVoy
HhUlfoccxyccXh3NROZoHmNt4bjExuTHLMKm0Q2PSFWm1A6D7Cc+A+SgOPPa0l/KFfAtvViJyXUc
TffKNYrfThgOG9PD7nk0BwBwfQXv9T+eTsEGAogiiJzuDHlriUcqwkAHRO/l6P5MyggikHwG+FwX
LOCLvyrQcEJ+gDozKqR//bXWIHWn09FVfsimzHNEsjWRol4A5Q+suJaAMnBJG60DZHsWoLxuAjyF
UlJHVGzMB1LDbexjpGYuzyM8yR/MEnOzEhAZlrBTpLMKsdFpdyGkAezUQaE44tqQD8JsIAENeRIc
yQp6f9/EM+eXtgceapJ837kbhHgu35NHc92xxTYGEC0jXeSNJaaG1zQGYzgMLqNowE0TB1JxpRPa
HUKMzw9jEP6lN+wyB64+x+ICBCB8bc2Rzaqg7Rl+5bWYSNMYFQx33y/aUAZq47bdpnu9loGR+2yJ
RQIhBAv2tWFUuJ1XGVg06rFP+p/CNUS6ct7cBHKlYcGM+t7TFKExxFjR7V/c/uFDJwKJhxHWN0TQ
texNbjmSHTc69NcEoT3Ci8JmpMDKyJZ89CiVXbE3BnH2cIve+9jpzY7AMS+6mFpCBAsNqb5tiRlz
IZdOwmWvUzYTXbquCOiv6/bCz18e/ciudatr7pkGzg0EV+tzDUyWrgyMBDdNtYZQ+Zj7Sd4og6bO
B+RwQ3fPrFDZecV+YMOgOH/lvnvbxGb9X6VdrSI345wzxmmUx93bmvBtRdXTtaBdwCZlzhGkbDME
HDE1CXIZCPcoagdsyb8ty+kM9yVGHLa9Yu4caN8It2l7HI+P9lQ0Q/EL6anBrsVJxXWI55MoDFDw
AjueWWI9oxmWKXYak3GT/m0oilX4Jao6RCA7T3MK1IP9iL8ryO5lux1F0S3KRzKg9mmYu+o5wewS
K245hylDDZtgiXGLwBD01R6zT4GqnN25p+Mdxl6fSwdV6tUCnLyi8HvpUwMB1QjvxEFUqz4iMfg5
brSrUgmzD/sOWQT/PDBUmRSY8kieftDaNu9V1CywWf6rrHc2r1lEGLZ5eAzhbEmVi44mrgEQlhJM
8b8ETWz9Pahwu/anDzNVnorioSEAkpL/s2ncdaOXxnynQcuaitT3rRTwiy6Pt3OP8VeXc9N9ijQN
vp+M7bgqmn+QfwP9B+vTYCz2jNgypPKuXdLJtel2r7HYPSDZu08GQOJszcZ/BA4CgVhLj1N5LNi9
l53cHRklS2drhrjxE1LMUtyFw2sMru9NHk2Aug7rbS2aDsyY/+j8i/8o38d5CFg2pq97QX6yGsS5
9AoLz0VRwjvE8BmpI00bgTumsHtdudczSjY+FOTT5Lmc+oDbMaYR5tGr5nHqiKxswF3t7VkOlI0a
nefUzvxIQy1RA6QbVb9xDNCL8gcQsdeHwLNZzC5BP4lv8LH1NnTh7oBsIy1xJ/G7O1ZoIWXl4aEU
1hlWATKtH0eiMHUzZSFzGAdhJcZH9H+kMuzOuZ0sM07IuifjmIW3CAJ6g9rOAo1T2eI2m4gQ7atk
OZ0VrgP1iG6j0XXaPpMTA/yoSw+8OD+2KAnw29+Fn4tg4RSamIwaI4Zx5XUryt2+mGq5BZeJYQ1n
VRYiJTTaCMDNCm735e6fmjvo0x1nvui/7bA1AfeJTXbxAu5KQcXHc8/q/LHGJjgVoVjGZg96JIEe
Bo2CFKdqB/Kqkn5BShbmidAn/Pd6I09Y2SY8d+q0BTwLjDgrifYAMOAKauqcCOC2q2oJTWmH2qzq
3aGWUHhTHtvLV57FVkQBiRWcCQOHpA6Ybl/lOTvf2LffgrjuYvX02WmY4dRgzWiJamonEiQ5heg1
0iGu7ExyCN24Kag9WCHB2UP0kCledWdRyP9hM/fsr1+s0wSlUDrxiMT71yTs/t/QEn5KGT3jWETa
9CVQ0UkpsUL3Qynt9gvQB6fg1j7pKMOkUg2GpI3/zMoObwuRyq53MuBeCQvFQROrwoATyDg9je4r
RyYQqUACksLq9cgnru5J/SaNwtGZ2GNDb7WiO9Zd5dsTjmutc53jKek2xYer2IkbXjWcGhbfw21A
oNf2ujgyQpcv4QK285o7NKL1WcFKbNsEEpZ5rt0+MSZBXx/d3RLCOp3tV78FDSBBNah+vg7ByxYs
71dAb2QZr5RDsohPNvtDiH+ZB9YrECJl9NwI+jAtlEr+vuUzuzk3Pf0gmxt87uzXq8AJkmhX/L0a
OXPi3a4qPYrxLo5aDdDGjKHWAaK/Zv6aKlJqamcLVtL5hZKp6xeNRr/ooZgA/tTR3D6HvTaID2Ij
7qTTEnssvW8MeyY3WOjBGNEJpkBPG6jrsJ/3qi7BsryUTDWI/yREjJ2UvLl/0I6NKvLv0iP/xWma
X7TFRvX9qEcQXkytQz7bBEy9cIGFRqze7GK9GbikdmJeGAJIgn/Ni4b9i/m+4yruGtgEoal0GnLB
8r2VHuy06iA+TQFrzD/khclOZO+ifQZ+KCYDKZgtThTTL+z6UTu5oXZDKNcDTT+3UrkIv7DT3WaP
deyaTYodILl7vvq1thSpAydn6b7Bv458sfWVnSBfL7iO51MgTixu/13eS6TqkYK2OvQS1m5v2//d
pRVe04E7fTgqEp65SgN8A2ddzYNcFUILqc9oVkHkaTqKKVSPQWdI1d7tAl1DCiyT0g4OrHSU57Fw
lMntLyHrNctpFoabEjbv8mN24NtD+Ycjdb3JuI8GeM8IG7comLAO73I7AvkLzETQI9+QQnSl+qeG
riDyLRd0UGRAikYoUleLkwwz95U8Z/Fgt8q+VdmgWJ2CP3JSi8TaB5d41WChRbpNNZrY+Hw5Jj4O
03ETtwhHDUQL1308m24D7v9uR72y1d7Y9Y4oOn/NbOc53fIGFdZsAuSzPa2I/AanoUxQ3yJ4Hed6
PnHwVFoLsleiRy+6+OVkL9Mbo2YCfErCokT2/w9s9Rpn/F/4UrC2ESHmCh9pPuZWfYx/Dhk38ySi
6gpLAW2GYU1igS+R84Vy7QHlPl88ulyQNSVPw5Tl+DPBO0JP37W78GUiR39BBsD3CIVVgv5L+WTs
CSJ6eMIGt0mU7K31nocwN68wmDq4+Am6hocBceOI6kVrlZl5Ans4LwsnUeM42nKr4Lg8J6G4AVc4
/Jr41THAw+taErpDuax7G2AI4IoAqWM6uhGqgFcC3zKIoEB/OoyOil8jA3JcReoZ8ifHdgWUMt3V
a0h+JCop24pofnpwAJYoEMDF3RubsSsywjhcCY5kMXNaAL1t5QMPIluhsnRU2zNYy3h9k5Jwq14G
BtEaeoQcbqA78ulu6htznP4IMX01eroJyWJgbWM1Xb7NrEarcc0i5/5eeqgU4TpCpJwi/j5vc6wf
ma34QQoTZBn3nLG41nIOLbRs/n6eA3Y+A1/n5yU6LwvZXfu1xHOf3i9Cd15HTCtv0GPy47ZvxarW
XqfvPam84L8B0XpcbgoUJfhza//JiMtssbucJPyhBiyc0lLstiFxKPes/iHDGl2Thc4xBDZdtb5k
0zgbqM9hYO1RhTmgnrcFR4A51ys/T60TYhzcFrtqJDpUzJcH57J70uMj9ZWlPTK19qDqmFnqC+wQ
aW2ENuh/Vom1hqnKVKv+scFt6BzzX8fVll5lGydTFkerCGr4RCMGs0ockn0kIWTtKSLJ7p2gGFrv
FHYd9jbfwBobFnt7VeqQ8eiZmzq73NHjSPRF1qikzlhsl7Mioa52V7bKTi5CBDlYlElGC4ENUN/Z
iGh6eKZk6VK7mi1tGu6TLox+SoW9o3F9AUREqyiLzYH9pK88dJdqLmtWhZR5fooHhe0g0TPaxUa7
jghOy6EE9oGwbn9s9H2xJZHmWFMiCW33c6MTPYGhEM3bPOdcPd0D47+q4Skm7fRE47iQyD0thxHB
XgQNrBL6k8mmBpcuIFB18pdgWb5As3sHl3Se4p1jTbGXZVei77WOZkBBvu445/7qBDdlUSMwG6nt
KDZK1YtfVailmZvyCJR4TA5xFaBmejMvXBgy1ILadPqloGZrV9kN6RI5HNyi+hIKA1E6qsaLk1qD
11zJYNsSYmgVTYJrxbfcsG/PiZr+3GeGNcj2Ilr4nsmsBjGrELBjVTgChVlE+lckoUJ5uwt2Ej9e
C9G0kBR7cUF+f9PZr+nkdZDmIcPORsjs6YKkGYByTrvw6j9w2hTdLrb88TTM9l7nAxfwdO0Sv1gC
phB0Xlk7XamSxMZb09LxbeNDM6BZLX+bo1/o1SN/ssww7BzEQsA4E3rq3HEpeSuRr/wvJlh2iwc5
vdK=