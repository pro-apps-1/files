<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqU9pUw2EJR1MsHOpMA1p0mjXQCnjnLEf8Au4UASGhi0BVo0Ea1A6EDOGQfRKMsBhHPffiPG
5EaqsKbc4IwZH/D09dMXC/6NJpsbwVfGcxPaxMkW4eI8rKGdyle8SO9Nvh46TM0jJnG0XlMRLnqm
wyNQTR/RwBRUL/Gf2HS3uGl//ohIYaRcld+5n2Uf7M2TQLeWPYLRw0BgE8nPKOk2ftBgAVDqkDyK
25FlA2DbDyH3nAOJ9d9sXi6a+rF/ikMd1KMg/DTf3JtsYDJIK7OUWvKJvdrchKhpLetROqaysvlJ
Yh0V/qlCOlnBQcZqZ0t290xHTFM16t8cgceuQsqpRToErhaKHhuCULGl05rOezYgKHf1jynbTdlk
z5WpYOfTN6WRszDNNVsOFdEcC0wpxjxczTZnUH3kFkYNfSDpbNLss2hldKPPSW9R8ZIau644E5bM
iEtuhFBYh1pp8f0ZFTW4ntbjtePfeKWZWI1CnZ/h4eDm7nD0Wz1Dj76F7dB81SiTqJSM9vtnB5sS
eu0c7Cm1sIjPjbM+DMwx9mT1YjWM/0jFUT6bgqI2QcH+JUFgc32tkf1xhxFtEdIoJq8roxxaMqJx
Us2zO7kNcwNQKIPvgm4bJIQfFL4sXgbQeO3Ux03YiI9bDu50sXCkTwh77Qak7zSCcmuhQ4Pnpu0E
abudjP4EIeOBFpQJ/b+auAX7bNwKagUOxNtYx3gIcc4/u6mVWLQpkzzXRqqccbLbFWbp7pIhHAk3
XmzN+aOXlP1r4sEqHuFKoXMMLvg2YX6P1GtvYcArjj0eQhCmw3XyWNqp3mBNs9anTAk5lbyfihZS
u0v0ik/wGGxOzaTiiduRJvEerWGvDeAo9lkC7fow0ImY/jsAAQ51flWb17m8X6KgBmM6BYvfwhuJ
aQDu06DNDD3mdXSTsnO6bZU1ZiLR8u71wAx3qHMONDrhHWy76J7TM0/uM+wL2uhx1AgWsHyzYprg
zknAAS+/Qx0wMEhA+tDrycASvFEIj3YZmr9sjyZfmUWtk/ZNkUJuoSt2EqHU/ixwkGH6kLEOB1aP
SVOS5bzpDxV4acZMTOwaGV5fUqAsVHiW/TY0sjPWLTiiG7wq0FI8JTNPTb+EtooGfJDb6J/mwg87
qxsNUfdBjue8PeIlZL9T7KiUOT3lDf8Ml35gSfcKCE7vfd8npiFUaaUl2q571iKIutRJC3XPMgSU
QP4+cvVB9rxD2M1HT8jI60MuN91p/vW7B4Ws53TnHO5MzV2V5j7Z52JNKW1lv9/DMZHFkZ8VBlKs
x8m+kAf5mrL6Ki5ueqTY+fAnquGWOsm/tehMLu8g91EA/Eo6ooHVk/rQ/qK7gal2ow1jbzRz9Wyc
Qkr5tydpKxVNn0Am5VVbm8C4MezQ1hrehXANW4iNTpxIlF2Td32G+W+8b/Tr9ehu4c41YCDOdx/u
X2vyLXspCMuajetny0JfkbnhwTv24MKcL1IbSoVf8Et6Psl5dPObHF10Jj1SnTnjxfEpdXaIrS68
G+Gz9P5j5SgUh/dxN++Ilh1vVk/9P33FXQT7uHfSz89lxh6Gv42+y1jqaiT2BXzpjn8b4b5H4twq
3FcMook3U+Supy8urDmXUrAIFaL1XGPBtnKbVO8bScbdT5Ih6LekK80X2dU0+9TwsCOmYuICo/D0
C0x9QD6ugW1pLwJRS5//FJiRNeX/GiRSWHu3t/HOiRZVLdxYEgYxXD01kied+bFQrQO0WRNKN609
xpVD+/FkJh47WKq3jOTyQnpQD6NtCw91Wf3P0iVAHya6XvpU2OLQ8iDRj4t/l8KGGWKUXdzlJ9My
UNjL7Ag2Dg0eIAL1ppwI7acZj8ArtZdNIos0nlm2AQGddZ8bFUboHU79e48BiURiAOegPArEigQE
C43rQj0R75mCYIkzzDZ2yW+sLAE9i7mWMwTkR8WerMYAkepEtCcRssM4PvDg/b3gfT1+GHtaysyT
pNqJN5jnsrQaSe7hENdE10mauFObVUDEyHc8hxRQr01luc5NqqvWeth7SZlAxhNqgvrUfUaeydlv
Js7l5KbkFnQRYaHOWP4+eT8a//PyBcpHaJrU71+bOWLdBZccvc4Dv9lsPo6/fP9+5AdcsF05cqPg
QH7czsrOd2fU+nAif6MP9o+a4fFu+zD5MJWL0qMWPoPE42Z6OcEB2KQD8IFkRG04kgi7BcerEwUr
uh1xfLGI2cCW7I6w2TTssAyK2q0iJhlkLWh/RynOaPywlCWu0YwO+lPqzGCOHEaLs77mNlhWrPiS
hiLps6ZHe8Z+R5lNllNlMlA+m8eidJvMQLLA5UAeyl6Q90B+H9fY/YKUJsKzriblbDXR6RCifDi4
hWF/yC7mTM1cGx1hkNpZoQMw18Wn3Ug8kpOSHEPNXuG3UlUHUnemA0juZ21HUfau2nMyqPMisKyc
HLZjbTQVLW5NcCRPUrQWSVn+lCWz7BUDFc40CjuYcfiGGjBq5hpWbZ3W2vuMu33TRv106pzcRJQS
WKk4nX2yiGnA9vwyj+WZ2wYWWf8jwrZ9RmeXdme08gCsxkf+Nh+HGNAV+f2f5drx+kfr69PSF/VP
doz3IfPvUJAztNGchjBbZsN4LWM2/XkC2C4+esOdxf4cRAORVOeF6mXRJC4rDZy25ndlMaDupIvj
G6IVjIJOLFA0CjuZmsHFAjGVj/cCL8/015gDMXuf9D/Ng39O/+uVJOSlD5fyY/lTYQExfTzTU8gs
v0m8v6Tn432loLcCxWg4OCirSy+W1o0jylHfB4kVb0oQ7uBoqFpAneHYjhS5Aok39N+9mknFbbG4
y7HTfZM9zZWgaSMl7hnNl86MpSL4vn9PWCUK+Fn6Rfjk26/i1T1yICssKbPl2eur0/OD2rzmGUqZ
WRsq0tBON2y31UTOZVhv+57Kmbwy2hBxvp19Kh6CpS6DYgOTSJ+Gudc9ECjbo3TiA1wO8zJTs2QN
nqAT+c6mcVV4zrDh1ffEVHFzCtee8xyk25oghe6PJAoWvbMuhfhKamZ8OWH/i9j/wK/niAPEpDIW
BuYsI3z4yIrlkGJDUwS01OQo8sma4WcHHCxJgrOs5rq105NnAvMtJY97j8ABp/EbA5YQxdvCJz7l
IHwlW4AGC6O3+PLiiJZKFYPqvWcId7qSJMnWWBNYJBh9O0+EFaLptGVf2TcDY5qi6T/5GAdw1Z+d
RvKIzMWwn39tO6IamFVXTKgP5DVNm5B0HA78Cq1Wpg0lUnY6sE0Vsx5XTwITCyWnx7bsGC4eIfWM
yu4bocuZKvZsCSSlG8x74ekcNMHU+sYCrVSWcBWuxB9LdM/XHFa01bcKc/9tykwHViYvlZyZitp2
e1s/Ym6nRGEVOjfho5XAHNF1SZsqn7ZsxLhzySDrtR6MLLm/4Keq3/E+cuqLzYK/zdlLD5hBnso3
pVVMKJGPdKHC1EEj9U4x/ss7/73xcFNxBQ0NYUripk/+10MdRNMz5Goif18gUCmC95J3xU5SZAJ4
kD2ETcyLCKTvjeNE8lO3FmiMziAX1A0MbLIo7iU/soZlmLNDbpIvdaChybXMnTVheKZC7ErrSZaA
NI1nfX9LXRDldaWn48aeJY/xbJECLksNuIm86QEYHXHfnZQFkGNyRbOpmvtMhzGuVJ729vcYI/xw
C7yEaq8JSulPnYJYuXY+J2sUIlNgiy505OahPDisZOUzT+TG14Do8JdEB5UPPER0Ey8tqBMYGeCq
sT2L+mECD1JtE6PZd6SXBcQ3/pqvh7DhyECbK/b3zBYX1XhsorKT9gCj6Ml/Cu+djnxfgpjY/FXP
efoG4dIjl4fuDoU6zSbHWc7d5UTngElS/4DzR8uBwUCTB0vMtmBA0e5jugX4fpUN97jhCWrwqyQk
Zvj2+qpvIm71dhlxissUXScAWr0UlccGIJ0PHJWOwKahSwCTAs4KQGlij6Qoh8Yu43ISXjXT1dYk
WrXm6xlXbPVBOY+ngbSWEEO1sZcMqkmTTdhAc0du0dxxIFa26d/oTAnItauXB4KTRX5lEqW8TYiO
NzZ36F7surfrMyFclkb91LCFYdjwtaCLKfLeE/zi+Qu0TEncNaGSsahipFGhcgH3W1olFmZShDEP
U7t6CtltNVBoIVTTrZTnDFy4Z1ZmlhcMoONuWj/BXX95n9wa9rKCIx/ejHKsPARJjM5AAv6ycUoB
tW6JkA4Gy0iEM8WXPS7pGl9hkOQDynS6O0CD3p5gXCap1B7h5vgQdaPxQKthKxulfewtwSSdMYXw
UcFbc9x7tgR6x8pAhs9G/5Ss3bFl8s3t/42aEFlHBr1fQ6HhGpLM+MuTNKy/z8xpNcUMomGAu8z4
FSVI3T2uneRf3Nv2UigBedAjAZLoxzCXEhj8bQUVPktze7TK7RemjQSTkpenTb547/nzYFj6641J
3HxTvM3FuUPNKo+lPXfd4yl6NMdoF+8xzwYQy1+6/flvfFkRbz18LOdSOvaa/weHYAtp5HqZjjBk
vXSrOYEQhwzk1ObUZMVRRGVYlrUn9O5tfEx8WvrE/oBcHlLrWZWfib+en3PbBu45K+ZFdZxYbRWO
mxC1+TuUY9fwc0uxkQt7iqO3ogT75KQOx3VZYivL4Z9a7Jhrp4K6nBu/Ki2t2Smd2ZAung88fXAl
VtvgMd/QJjCjBSD1IWpbtxQ9zVjWwvfIVs9NO6oCz7PNCTJU/fjuIt+fQnMmzNij+fMcIo9qgXip
h8B7XiTDf6vWOSo/ZAK6AOnIh+T2eEP7iG3hnpLewbJR2ymAheE6TG2OreJxeOHCsbFkffOoUDtm
MYcH8O7l8G8UfBQFs1y6IaoProRYEEWxMz50BldLyxgv2f7WnEa9CgzqExTf1W+0b+TUUIUHErBC
L9e33Po8BwyDxNIes1cRXQ/EEQKHGzcOvAvFwOPy/jR5oC/YrGwkseCQ0snF7zuSO+/ElndsHn0G
uawyxz7jY+rjahDTL5BPVyfQTICQ/ivLg066kK2T28g//ARj6w3RiyfkFtYNJOYSJu9ePXArQYRz
Z6uSPHTQkkduKeATdsjek5e92p5qjEJPL8vhrOF0Qb+fA08alGw1g5Dbi6iuIMHq3Le4JqxnD/V/
qz0PKyb/jXiMMWtZvj5iyAA12Ke681l+HHUA051XfkOBApSgHzfxSTHLf2RPbbtd4LuPHLlz9GQ4
LMKU1f+uGj2kPeaNahJQvCFb8SAryc7UgcLpYWFyMeA/PjWamhveSSA+pKg5RILbnRBjtIPUxbXs
iq0blq7eObVJ65QKEUZyT4ALY877/QYPlPuXZt3jaRSwe9F4urQOa9kO5GWB26P9o5YN0O/rRL1K
am8mraP62LjkSXgeTdJH98wxuaeMTnoBRML6KPBoC4JHb1YdeL3bVKOYzsrYEY19GAUIzXWSFjFu
EdPWrlfkO+ggknqEeBfDHfVTmgJYJDu/+08rmXlU5YRpaAdgmlh5jcgF+odu45dKcbhXZCYtcnqn
z40suBu/Mqnirodw2LwgfwJJbwBfeKakkQAKCWCnajaExWxTsk42ob8IBpk1mfpL0UkbXvgD/PWS
hmupw4cPjSqlCBImL5wojKkC4XSxSQg6Zw7TYeXKiy487QB1rzTg+UhrtTbVhSv/XoJUtu+E/uax
lKLf/CDrLOMsm5bMnIb3Q9phg/GFyW7aaHsNg+6dXd8vh/iJ7I0Sh77fpAceMoHmskDp4MgaElik
A4sfw+xUH1ur+SnCldfhpLaAJVSpzC+R9zEzwge7n4gmzIm6SDlHZd9fHHl7KQhfBC+mAgARVeGi
SOwZeRut1Xh0rb1IIZxbJvIlVE60PdPjyHtJAGSfqauvHgXEV678bijymwDLoy7MN1w0FSYMGYln
AEJw2S7X8bjAucRYK626U/mtmtlYuTN+NULJ3+0sRYpjdRPgUl/qlM2aAkquKXowkyxmcOoLESPs
XmIspEe7zpjQ8WijJ2L4Mw73vD5+EBT60cZ3TchIGqakbV6gh9ot01K20pTCAfKjTzJJ+OD875VB
/4tUMniwBda8AEaK6ySg49BIwCAsPWRq1kCx+aa4HCdfG530xkNisG2L6C0FauffnfDFL+VGYL9L
epg0AMcxcUsXKSszrKXc+91+LQb7LaCPtapSrWWGlrqhaPD/1x/lGf60OjMdQFqovIreYhU4n1IC
kpNRyCV43uphqsiCq8kBLWssT4lW9dnjZPzcOWpCIlUK905rwpJTP0TwUE1Pi5BX+R/7HrtxpWtg
gqTr2YzdMVVz3pTkWOYFZmwalqyaiW5xhW9dvhUil8TqIUyL3bZtMjcU4FYj5ZzBSXrTOscTjNdZ
34AiStmlaEN9gzrKj1e/J4W8V8gZFfuok2QDcQVpGX3C3v5CXltUFXsP48U6oZMa2ylt3jNPjtm4
JhoLOmsFGJarys9Nc6ASLVJr6/VJa1K8nP4dTHhc2+LSvx7YKiWACmS1kffBlliweNMiiiq/omyY
c7j/3RVYVnMlVl2vvtXwLGIaazpuu/ldDx/KyYdvBn1V4viAPkLOutHwHmX9v+DJjeGGYgi81qoo
+WvigcOB3ClZuEqVlyEKP24IKOkoCkCGkkkIuEVk9fa4xKl2jxijPfzY8P9ueEtC9/tOf8McMhdk
R8YNGX7JgmMeGK703i4CzP3r0FKrChOqgjCzeEqXMtpSWV/P/3ESYgYhV29tCChMby/leyKG+nSr
k/PC6oP2lSPwN0rEqixj7+UNXxQB254/CwOza34pJWJfE4YP1IFyivZt6+FjyVkR1epbBjDIrwQM
7x2aSAYg+Lp896mCi+ppRHb6X7tx7LSJdDYCh37XhlHjeg6ef/bM1ad2JYjAw/EX1FIBnnMhqnFf
iNGKyuD8SCm0sVMyIK/Bp77CjOD+PfA6Q0wb7CSMLczpTK+RlgPPLmug3sCH0IYF9t1YiY8mbJIv
abysq6EWmN0uhxr8e1gcpmRM94H4rDG+MtWjZgWhElHMMv7fIJ9mzhGQy5316piUnroqXOFSb5BH
m7U3jklIkMriYGzARjw3uIY94TTIFHD0bJ7zXbln5KQB22QP9/Nj925sQfRXqrLAY0wNsln6qaB5
5mrF7L2j5SEOzX0KAhiuNCoWRZKuJLvLKR0HNk16nSaJU8qIaQwBYsuqU9qaQEPj6h2pbB3M3W3R
bbRO+5K+I6+b7CgsuizWsHJ2oC36i6TjMRm0N+AYvDnrhCafXwxBA057iwcencqQhQr+t5S0mWXB
NhZvn8NdtwfZs8kpf5hhEklT4spSdxsEXGBzQ9/SNJs/EPU5qD5JKlA/N1elESym/YcmWwlvh/Fv
u//e6Sl5DPbAKk3WQCANVtPZxtoPf5alTc/mWWiIEurWNFyJj4wA2XzbfvGpL1xwXi8C0/HUdTYi
JYTXCQ+YvoqoOx2OtF6JfG6I137wKdkjubtg0WHqXaWF5GWhTT7PDiZCB/kdoe3Mw8HBgNrBcau9
NCeXqdiIloL84ETUq+lYIILCZN3tSJthkWUGnFF1vb1Wf1D6Fpdabi1yrcntg7SvYLbw0bgcDrJE
9KuL6LO/da1mx3NyVKlu3Pgmg5sn4QB06ot0jxH3JwD84gkqsiqEumO/ixpUkO4ZUpvODsmntODp
5fB5eMO99pYtp8ec/h9ShwLiH7uBvfdDin+pESiTeVJlLAd06ShbDzFUHMSQ5vG1Ev6OeaJ7pyMz
1pdiHdKhyybikKZNEcqE/18wipIfIgok58UYnLzpOVhUTjpZv1WobbVEnTt65Hc8ckLpittjWyrG
+1h7nF95qSsNl4cuLvStbOy/M3IqjF7r/646Q6pF99AAWRv7085xqVvV8Q79pd+fpJCT2zj3zOma
M1CaJ5R8um3CtlLBd5CD+VcMPOOXjL9T0fQv7C3jdr3WpoPCJBaKNWOBmf3gaEMaBcZg7EDZIiVM
nH1uHO5DRw/T3sp9Ql1PXlWp7yOCn9Ac3G57WQN+rrM2cZUre0jpm9jZ9oEv3x/svsVPRKQGg8vH
2vKgwZ+8EIFRK/GgjrLUIBUElLZ67DO3XNfBcSM8PufBUbJEeSFlyEQ1QG2VWgCwTBw0pEPbn+Rh
U69T4130FPlylyTNiHRpfutpRjvZANJgZh5X4jEVlEVlEcy+5eJkiFKjU8CS/KQqhJ2ZWb98JzYk
1d+fnSqMqPmEHnEwi2mshlERLVGCHUvGDwfY15qDW7vaMprYuE9Gzsd1plJnDgHbb9mWQc6cEulD
5NtBLAp7P0221u8Ogf6qRtz6g0T75gfcfgapVvSJoujheikTrMO=