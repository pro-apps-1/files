<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv+V4ChABEdjatA5wG8tp7yiC31LuY9S0wEuV6hiUEvVbAdWLg4qhhmk4B2sePQY8Wh4YLjy
yiTYZSNky1ryyioJ5gtcO6lUUj2qpxWLffAT8ja1BuFoQN4B/llJDf7jwdUgnUY6DGgrt60bb3uB
jGGdLudEiAW57BHXur2KVRh1jF3gxxldIHTogIgvZRF/cyp9Qt8jIA6VXU6q3eROZBYhZkAznM76
CMEyzMm0RK1brhRXt/yrzDrE3sDEiWlVrEvhgTMs0bR9yaI/G9MPSJsk0lHokDoHYT1Q6P/fzru+
s9Dy/rMk/M1FoH7LNELUYN9O4BqEJC6oBI/j9df5u9Qlo3tOZ/XTsTKUwzU+jnDIQ2rgR/ZAdjuP
jGuw8gUYfJdQHeqzxk9zYNl7o+ZPtr0PK67uVVaUmQRRU3qKzGiWaXLycbhKM96J03LNO5EsxeKw
DJuqtNWbCUr3yHpWo5sxXfPKSifrmQRxi/U/+RUxrtQpSj14s7GPsEZCqm16qJXtCDFcazdWf15y
sCYTBoWIP0F70HScEB5dpy788sbvBzQJ8/gUz5i6jksBovgA/5NYBsgsLkh3LLQPk1kP/pyPUwL1
0Lns2L+kHDXNISTRWh4tLyeJ1dlhQqNb19UXNW6EQdM6iUzoZZvVrL3HCIvxOH9+Uad0ufsMW81R
S+5N4iVwzJZkcgYAD7YC1ZFcPsE7EiEqGzESZ0awth/VOpj/WWFJlax5WadKr3N8TwmvYwF68YiH
4HOIHuE6lh1I0gz41nPOd+J2zejrrC9XvD/nyLvYAKNmH79+9/s+hnN7fivUIdrOxjS6ASALBpju
4V5b5jhlUlXGH9+yZwJPsWgLmkPBDXohH7Nk3ajlrRnG+sJr4TSVfwToDRn0mCQ+8xbsPWlwxz5r
54i3qBr1r1SSO1sOgS/gWWpUwGgnisHmQFdNx1b2ZyghJYRMD+GZ6ZOqjs7J59BX6yWUA5073jlA
ALs9exBPAVyPAQ9jmy08zefH8vyslsC4vRVzUFWSjL/4yVcB6ZI9wqnYys55On2m6bhd7NHF/A1q
Sh4z59tH1HxGZztBGT2OiRziWIf6WEbe9oMfrOY0Jf54BseEjEzEYW/y4S4CHmla3xtUq2JHhpbF
4Bd61mk7ziXnTzxfdV+TZwn0VRwEVsh8r5bH7e0KgYmdGs5KOFy9zrD2hMa4IVsvlX9lwuT4B4nI
rloRsZ3ZXGR0ufbSeVfxm41K3sccmVR8R8WSDllk1Bht+LjP4vZh5ks6kioFG0/EcZL3wewxM0qa
mjecJHV2knUZIwrtXESJ65NX9VgQh6mGZ78mU8GnAaep8Qqrh/PYofwvTAAreVAWJ0iaYCUBMshk
feKNf++q0vmpVBf7kiB5NgO+L9cxlVXzj5xI41EVmMFjsMDOFWn8x97PA6/l9NBp52RNzMMxH6mk
ceYFMEdByCQOWx3M2c/jG4H3wlxfrIXbGU149frqantSR0gpEhn6A980DI3uSN3Y5nZUfY/u7V7/
6kD7sC63CaJSgyOLhpqcdzdlnKhcsDgdDZ41rtKa58eTRBvZUuURezsL46jFQaGD3wOaWwi/vJ1R
ntiAAELrydGRkzRhX/Qo1IwITkOen2syCXenCJ5FbfaVydMa+c4ZhrL52POd2R+K34OiI6cZ9/jY
FvpxeUxd+mAFMIKWhMcFlYEIhlWM4QjOyoIes0SQPOv7vWJTu0ErfY4LT/25a6qb8wVpLMSm7V0U
s/ezgEBTET+cXEllPjz+8fzoFXlA/Jczpc7028si2JWKxH8Xo8uheoQV5eIn1ciUJab3xRh/Q1AX
MhDWRKnYVbD0CI2L/PdV2d4h5kibi7lNKy5Zgn5HNuaY9N+9q8mmFqEaJrNAyAa7Ld52AlxzeqOD
MAX/zvMNDPFpzFp2S41DbJ5noMiC9XnaqJInRuPHt/yoqjabGr67akV02X9lVmTNR6TRfxxoP0VV
RH29tuEDuM0tAuSp6xV37q5MUEXfO4Uf953XK9xA9cXXNkVpKOn707CXEY9oHQQTIdw2lwF5pbyz
dpfXZdWTcXNkN8UWw/eXNuNNKxvpzxtDeZGrK1ExEiB/LnObZ4r56vJCoyjzT/mMaDwhQOKCdi3Z
esM5Ow6AtsidnTpXS0QRaVtTpD8CEikY51Za55gFxt6rjoywKvvhTM0oGLhI+qd0n4D8e/akxkY7
MI0PPasAnJPSpCUt+qYwq/U3w3+I4xvWg22MunE+NaJL0n9LgMYz6zBJIRAT1dikz5pf+yaRdQCK
8Vy8LxFPgG18vo+xeW6qj3FmoJOM/KnMpqU9yxri2SZs2baK5j3SzeRLRLoMinWZG+whWegt+/yv
r+GoZTD1mL2USexkF+hP+AieImAF+DlJvWGJG8KR0DZ3Ci3gggk4Omzfe5sF4zt8la9QQfzcLVRX
sPm+L+Tah5HTJ+jZirk6lS3IWHMYmv2omfZwVIUhZuLTxrsJH4vZcrvAdAA8zJ9UZxnuhI+OOIVI
wDilpvYWSFlqYby5iz3f7/clrzzFjBqAdLBODW1CgrwdioQhfcOZ8jRRkQiayaBwYcSpOoct+Ts7
gZ7GWfxylqoSbS1HJDzFIq+bM0y9IrzyZgCh1/UYXHYqhVoBXKCQA69A5kKueL6IeDgL6WbSG6Gu
KCSRMmm0sQQ3Tdungy48InIK4LWflRUlS4xQyWv2J1gYOuysxGuoaXbq0IyVN+Yg3VUgKyxKu6SW
rqH8hfv2NWKJ5fM0eqt/92g1gEU/nyn2S2THdMA+eh4CM/NSyBRDH0dW05WMqiXSCDuYReaSPpZz
cqm21MFCfy9TFGd8aWBsa8v5B+0TUkGLfFNu7BT54m3PK04KPUpVp68nmIO8dqiMGIy+5Qu/ZRgv
0Toh30FWrZYbNnWYb0xRUrS88u3e8r03iTwVtdqJBR1yRowDP1rkc4CnPCvLGwNUMgJ07czaplRR
0jLQIOkidAoo20eRCaigas5IkXn9jMZP4C5SLXsK8SFgWT4FB5Q6w/XBPEL71u2V/EuvdNNzkAKt
u1ILILOmLia/hhiAfo/UAfhyk+TDcmKG4e69dpkX9EMKcLQGJ4SFJC911lzlCBHNvYiwkfWODfYR
fLdQ+233bc9ef0Zh2Hsvc2iIaNBwJFNgt8pMmADISPS/TaK/BDboU+ui0hEA86a+L5zkXhnpbrj+
Fa7Ew+kpbGBhBDbqsHQZ0igD16HeEzaGEI4LnQq9FLaHWHCWtdfb9klhnkdffcLEK3/2quGQcHQG
UOGHk9K8whVZSHwApaZ+J1daqf/7VoPhWhJ8TlcP9MPq6bXGbWI+nLSCexGRCxKq7f2XnSaQvxtP
HkmE1119klJCITh3UC0/DDLmwDKiy5XNgA7pwGt1SzaNvD57KUHSFY3Jvf9uXDD3C3Yw4Xa04OqF
v8diC6zam7YRxKKFsq04/m0iNsYApIyi5pvPtnkvvuIyvcggXX8Z25sUaRr/h6yLvCqTa7r7ipOx
6ghobP3cnlHgkjX5LfTS1hFQXEasIurNsDX7XbEw+mXVoGGgddozXPqbc5IVY6iz6w9kXJHizife
dRHh5TMrfv3OTNKLKziz1gfASEVfY7BTH44XsYbV/RSVwgmTMdDe4iko46Kfb8N3HqmuNJwFltpY
JA5GMxV3n1qvUhvWM7WInb1WTa7T7/nJ4Ep0YQ9lYQx9JC1eM4m4IsmAkE/S7Bb9eQ4OL+TF5NOw
tbeTSzoYLtWFfwrEpHUmuZunaYVuDemCjOCqiQbwAMBM+N6665lKv7bXX4J//0Ji/4+P/FvdT2Up
KgQX1HT7gmpp6eOstgQ+1v3dd2BWdRf/YcHIx8/7OSLBqSOvGDEytsjrJEIVm3RPguhTRVnebp2q
cltbR/M2t2+a76Crz//Ybx7yLEwH2gIY76JZFIrJKQZNVSowuogCpEInKOp34gQmjqZvnqRHYwci
XjT9lyqsHJBGSlBLLIgh7veR4cSaoqDh6m/VKQ25+AoiG2TLQEb0MUQorheKvFG0AmYRAeVC/W0z
U7q0DmuafvLLUnLRuGsPhwK5lkvpSK9ItMIiJX2oY1NBc4f9gAHDCdil0I6es7TXpWmqcgkcr9LX
JsACuAlmJe1FxbL4gHT5DVzfx0/fuLnDESi8QR4VIFSauotFmMG/ceXxup5pH/yEfEgX6D8Y8CR+
/NQ+XMJwKB84eYdssE7gGm1X0XyYApWtTa/0R5zJyOcfmiAagtqo8zi3L9NiTYSpUkKVMUd/xDPV
LpsCD4dGbK2XuSGGgT+9tlaiwFEn789zJCNaoYTpmapcE4G0lKsvWsh5EwgcpMQt3zjpqMeeGc0u
28XkbVE71s6FLc8A/p+hiJLjRpzPtSRLkO0vMOk52BKPRrKge1+G3K+5iJ7bjkJ7u7ePVWEXNPrb
Idl/M1VljyswqXebNvxZv7i67RviVV6ppF7fy0Heg7ZItTV1wc73uoxHqjfUSym7SwBrENGbLt+A
JtjJiI/rw69AqGtQtQ7eNx7wWW61NBf1aSX6Kt9O2TehkBo4il1WbtNN2d/PkGjekamHfuE5ikE0
hXYRyWs4bSaPnPo8RA/vXu85CkdXu6nmZLdJHOxATjh1SIthRVXw9tgJR0NpDlYU/I6B/T6SbdAb
xK6G4q/SuE+7Y3xTH4CNxItpfHf12NUHVlAA/hOc/m1qEvEvhS7O1VWLUBz9hUEQdSnN83yjEiSP
vkCQ4CfDWUn+LXWCVMynUv55zgZlgU1W7y0VUQukGt805d4B0iyPzFmJNoz/7q1UnQpzP/K8mtkp
A/xNWE9lNNReWJ1Z3ux6yRt7TW4i0ebuRMMFEWlwu1J1DiTkLanL0jAEgRw1eGDLbG4iAAdLg74t
aRG+2EbitTE1s6FIT+zTeZU+K+0XrXQ90NcOEEU59U5VaT0A3EARYxJDsTdf8RFc4dw/HVQu4Wr+
WUxfhm9TSHXUSPx6EdAzMh4pU9dqGKKpNtoswDwZ4Py7rdIBgIAhSrv7QxAduQxvOwZ4g/vLEdhj
ChCSdcDLzuwVd9Fk1hpHh0a2WHCh47l/f24/BMUPj/Sl19nECc92Y3AyLUYPN2vzkNmYIOz4ghdn
WecdSOfdV2aNgOxo9wtNM90CsSkn2qiNfRMqdaDzgWIArz3WUerttJs52aS3Pb8MUxPg6//HDW1E
xR6FnrIyMIzHE6kCftvScGnGN7Yz0lZpBHrGR36eYpqKub9jozddchvng721znm7U/bEod2Dpkz9
NVih0geBMADi1l1qRK4M5T0XaPi7dqKkbdhDZlfckFB+13CPDRW72jwIXTC5lDn5YODQfM2FD6Ow
Y4b5M5X5WR59y0pCki3t6Ndw8Cp18DgxRtRemGQ6qUTpfkkmlijjYlMtmjJFS/nRITCT9rxkABU8
oP5rLbvas2bEJ2Yjlb8tvkMO+GlVseT2r7jisn/G9G3VsUNmfgIAVMwKGc2jRzdfFbOl/hoe7uS0
a8Kx6N+KOqjmJkKupPX1Axh0tXb1hyDmic/jhm3sxm28J01oMwynxoIHmcY5BiuLu81s0tUYDebF
sM38g5gmfedEEHNre9bh3VynoonIyqwyYvpXP/Y5+HCqgSYXHpCIwArFE9CIQD05PMCXDsOP4QnD
Uvj4PSRQPXQmOiAPsaCLeYTRDgqJOnQ3q1lxeva5HPH+OqipuxZzSK7MHbSR4YH8XNnOQzuLM1ez
Tj32Qe/S6K0rLfVkZyiQtuAlLGujnaXcRoNuqjKClnIGkGauhnSrhvaSv1rFq2/4BSwVS2NuoiKn
o1a3If1CHO0W7IvkNgirJt9AUn5bwqcsRkrToQCs0L54Q3s9Rb0JlG431gDw4pGTcTHQP/77+r2u
SIDb45ieetDRZuJYMN/OgM9JCnTQDBZ2cCsjBpbTGxFvjzkN14bzv3Z1RBPUFR9jw/04bO0KrEAt
1PELEFO9zSEFnHKbmdS3xids0/C7SeWYO/bCyn4hn9anthIvKnj99QxOvI9jHYE3jN6Pb7wCMn4L
Q2GMczQY6By9aTtlz1SgTIYYdaA/Ec7MtOgW0KhmOWIf3ae+Fx3s2nGhxEjS7Z2VemDLQ7vapk2k
t4wJelvjWIa9MdpBUlLUOzhKxsmmgFnpAebxIkKSWjqi7N4u386VXGT/uVooIYK0UBNIYzOuR3Yg
8aqX5BNZt7sP5JlzXKNqBIspXAc9UiMbeMHY+17S/+wDDJrKVDiUiIR3+ooCao0hst6v76Weu5La
0RGvTpBGt1dK/r+LPewO17JQpr57PNcvJAM9LiCALNOicRwkEsUJbIrk728NRgwh0K2jJcxlLhQz
RN1/CSXhiVwIGOyiK8cEB6UaRW1mdgX1d+XZd8vPGBdXj976FMXVa9TeUR20KNU/8C0nJqLLBd4k
dj215u5piDUac6RFNGQMYFuT7cABvnxuoUNmqtD+glsGMz3QNSXN5nWDg1RP6982sNVG569YgM97
qQhh+tlggWet2RpeGkmhZ56Z62gOFbEWllnoiziZw8sDdijC5aDnkBsTozRmIKPoMH810A3K82C5
UZH5YwR+QrF0I0WKDcnCnSt0Ez+0B0t6ZfgfS8/PdFpw6YWfQZapBjxtjw5V170kK3xJICBiVYnG
JoABd5vUhjOYt9IU0SYF43MZ9g4wrK/iD/S8duyx7P7Mx5oK01PJlXy6afv6kApn7SkktreF5TPr
WTOL0bfIy8OOR2J34Sdlqc+uwuz8KN7gpSEeJbTBJSZ5jT1AMrP52bpyWvPxDSU5wa9ZDUyuIu7b
zsb+4SsmWR8mK9uGKh0sifBQUCUaG5PKMV0XT/803a29yVZtlVHtaQDpWfb/9Sjh5BYOqTODMYkt
fhAseBdqHl9G0z6jbyNPMkmfBcBypRa6CPtMUg9F5CF4wn+4lE+8akOKu6V/GG54oNIUurCFTzG7
wLvYTYF31yKu4XXUw340bRz68VSDzQvtfa14qJR+UQE4Y97uh7pDoycmKx+FRF4CrbRkc+mObVFs
Nz0vqspJMSWMWFnw8lh03uUSDh19P5/niuyYNvMiE+1vZDHQa7nLHECXUj+lOAAQ2B/+OX//pP/Z
vGOsHceNStKUGpCU8mcF9XDXfq8LEaSINk4nok3O8L6/1fD+Mytxe/gO9y6app7SyW5kPZr9HO5N
naQWE9oL1w9FWPfRJ5ECdnm8Ap/o2PyQXmPdd8pMOiG7TA8nWOVfhtkuAYxuUpOWkR3Q+I8UeM7u
0xCG+REErup2sGGG4cOhA/yvlY3EwOl/q/RapYnljBtZr+ggrgoYdgNisTtk0u0jSyWSRBaZ0+I8
4i3/JlZsRrZBBsZ2RHlZbLaxCi2y75fEOAbz9KoGvfKIhWx+8Hp9J9q5uHQeey3bUzgtPySTZrGs
VMNTZ76V89JnqxsjweUPQCyFfycnXyL++PpMZu8RYptp5pHo3K9YzQYV52iSEuHh46VzalEYPArU
W9M7RB6z4pebouAG7getaFiKnnvG3oUtEAc8225s1MpBaU/Gc67/9ZhpUrZ9GCHqnq5eg4smsZfY
xADXyfQRkltLOLRlk4Kbs2siXkA19NZO4VrCXbdRVg7Xd7EvflHaUocGkwGa/mN/R3+BhfBO44Dk
KO8G9qco6WgLWrzMgm7JN+H8rZqo+tDRHa5fsFZ3/0tW1/Z4QC19RBYzHkRdAobj9nauoIXPjWix
IzpNrhdseOPBloVgp+Sv92PsxnRir5DKezTz03yH4LqfSRqTfIVsli64Ljjjre2knRNGHWL1/h1m
r4R0hH6YZ799kKvgUuSk5EhLwzvamd36CS/Hp6uvP/0OtalU5zzz11MSXAjRsOjgfL/9ya5O1uhx
BvGrE7hRNO1EPU5hlW2zf2SCc23GeHbtOpJpHl8gX+YjCEoeZtvXHJJPs4gwWR7OtAbFhXKaAjLs
u7ltz0QmQwWHMfUw8YfaoN3/Sih/eBVRN3kf4WcwqOLT8qB72TkraWM8b1Z6EPA0fP0eAwetcMBa
lRq1snFodO7utOrRU3Hohk/KJuJrMYDL2lofriou29RtatJPsk04WeLOBmNLdYsD1I6UZq4pFPUX
8+P28f1z1eFmc9JzECYo4ds1nVKPPCsP5vEiVJxrHZ+kjAhm+iPUT4MN2EQpUIZ+5sqdfrSvCgOx
wEvYqyCxsUJp0sSPSdBewBC/ABJX4fc59aGsMXXwh/P6BUp1mZDXjdf0vhClsdA5cdgc+Kk7tyNP
QpqzJ/7VYtGSA+LPi9ytFRyEyul1DuQ3tQXxhN9Z0a3Q7oVZGT10Pj137Bi+L0B+eBCZeNUu