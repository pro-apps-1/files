<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxOSodbvgyv+1FTVMc4RsOFCTajgjufL5+Om4J8f9uX64h5lE4BmtvkZoPjK47+IJSY+mTY/
KIOI3PYsI01+Kg7sqQ984PFs8R0Vf8SBHQedFr43Mk6WGoEtEEYqDgSJWL9Ost9DGKCArmTEjjVS
gYlJLuaQjYeNfhooSYsH4ndOZdpb1f67Zw9/1dLPxbtUvVhZWZAYOYv0dYD8mdr7xhH5Ej+O677M
63KGgueYvazqLY9gDWy9uk8anOmCqZ5OiN/M0mUhdEQ0wVtC5XO2MZ3doh8LOh9ih3sLcnnGHq9A
JwqQFsXLNDv/QkmlChha2J9UsMDZ8kFYQV9S4qr4xCB+Tr0+3gxdO+fYhusjlrOeY6K84AxTsHw6
Ho3xwU/MsuAGwcQ1bnoJqYjgQlr8nCgZzKf8TKpMfraafXRieybQvsE9ylcpnH+bTgosiP+U21fF
Zt+fNfEiOEwm+c7hrFDMvBeDCfXp9EL/AuZ7M7kSuFWGGjklGY0V3MGPFGjS7evcH8UGQQSNUSPY
hFVaEZIchUEGC6WEZkqt7IEBg2NvGcXqPZQ0k2lTT8273nevxN02j1iFnx8tTYagJz6ZrMgrAAGj
xC6s0FOMukNTrhFu/oiKym8p/kv7Z90t9Pu4xh5b1UxHPgEWOR8t/npVb3WF8CsXiTplQ+jIb1Cd
TINmw1kbxoACu0mIhzz+YeMFzjNORSpShY/Rb/ZubMYORmfZwV9YXOCihZl/lno/uN5ytxz86jsU
A1vW3OgZSlgn3QY9jyOBUyNLt7/3WiJcDpqNtlddmcQ0xsL8kiJ5O/a/VQtp08ZsmjmpzQ2Bfwr1
NOgm6lDqTgBXDZLUX9i6xnDXfQg/S6rQDZ/iiNAr3bTBn0T1xVE6q5GGoJLSgXgU0pV6sUsMzzLf
mPds0s+kQFfoolXWlOPEeTTNSElR3ltgu+bSXKKEWNllEh3DRH62fzAG1Z0enmIyJfqps5dQBnQ9
HYkzVl6zGmDvX0TPWP+WluonCvS30sIIbX1Wkwv3XvXnOHS1mvyc75ueUKQx+GARVzjsZZeBCZ2U
BpMonG9eF/D4A7aFTkXgG3V4ZooYht6GDdbaRxG3KEhuFvC7A380QpEj1No7MNMbrNqEo4b0+uqG
XcoDqCo4B8dfBkvrWPaDjIEk/ILriAOgWCep7gHiy8Sa3Hh59Gh5Jcb3M8OpDP8mVbX+kCDOiwWG
FgJyUD53m8496d6/8A+CoUkOKLo399slNs4RdruK1C/5p0zd9H29hwnPbK2+5nmHAySbiGN7RE+L
I8l5ATW4ifxbkGwC6EtNFGq5uVFpOMOQ5v8ETx+fv0sQD/XgmOI8NYnI49qP6u1n7qjMCGiXVU0Q
bsGFzPX/wPptI1FhHGUX2LX71MLWFdun7PZjIzRuXN1e9bUHA3sJ7ELwa7zJhoj7vVCQbPtpXeWb
4Z7ZD0NPC1/rjlhWpAFbKqXR9kfLj57f5z2J/yRv4SA8567Zb8qswdX0LRUOZxXjD15pZQBEw9Lb
4KFh2mv23wf6HmpxnaibekuIZOdZ4TWSqxe7hpENa1KpAOWtw6wYLnCrO4kXQynCNruD7GfAFjKv
qElmQb5h+RrsDpgvfNLLjcIFayb2DrSTnIRR3t6W9xDFdUTyuoc3xkYoP300HDA00IDoh+odqKx6
wV6aenZys8JZ0q0eNKVytQD1OTOt/y925IDXziv1gqXtTMKwXYS58PfFHCZFnuZRnzyb+ncFqUHq
y4JwQNeKlwrk8KKqpFOi36GlDyV6wHodb9d1PYQyP3B53VdXlqA6ZrRr+8mGpSzF7SlKi69+k3wt
q/BzT96YR3TUzerFtEVNqKdDq/b9hOVnPrJdMkka4153CBza+aExB/bWZcT4ASrlsSYVPHMJ7oW1
ABRBfca5UT4IS8rzXnl+3BtxOYRVaBBRW3R9DkSffVdaXVradl/mVwbK5QbJ4vKpwaWtTefpsiuv
i6v58kgj37tKLrWPaZ2JFH2BS46Pv4mMudtTod24JCpRcqIwNSS3Kd6MRUfLLOFTVd7/g6accKVV
gGUAjf/4v4hGoxvCSO87egIJ8nHh54t9Z7nIZfP3djVO8JG4i1NG2iktaLVBwsyK5jbpKDghTcfe
ybRxNrXIZ3Tzp1aMBsfB69V/ALA9wFA300OlcWLNQ36MCMXhyyp0neKQwxuLTSJgiKjOCiEvrVXQ
6pU9LKiM2KWQBvhpgTlrqMHiJw9Dn/uPt3wtzAu3CabIEilFYan2ga3MU7MtZL9+3HjZrAHptB2Q
oeWOUiQIlfAZAIQK0lTX/+oUtBMxgx2I5pTQYCQSY4nmVV2/UQ8vnNLQ5+1xxRF7t9jnTwLgACZ1
dwu3PwliQF6k7pFlHuwUlTfCs2jgRaR4OgdtSX7ZMRBOw+EtKSyZULOJYdPJDELMao3y4AfxogQ3
6Ro17+lWYoidXPd0Lw4FvKNWGNqo3wp7RIhkGB1YqyYeH1AMZXaxdsZ1uSSHtpzSoTV/Z8ngSS07
VjVXpZrJcll9MCkB6Dc+G//ZagieoR9k3+51ZQfrQyRTI2CuQrmpaMkSj2F50n+txaJL6upimfe/
4n1S4GdHY+NolHamJTa8b/wLVnWlK6FbqArTsg/El75k4KLjsaz4PQkCdIGpAHWmVT8zKLFQTAxF
MtZW6lXI1sfChrv+/3xT+xLqyL31iXVewnP/nvlT4nXmGBjaEiw/5GgKkVnHMO20k0cVw5KbhbGB
93YKyR3hRa8OuRe78/vmtU+PfOF7+uSIZEVkm+eIdoVQgjYWIOkmOaZQnOGtQkLni1t8kZAFrIX7
nm9S6gfg5YHcigi/pin2YBJcUQe83sfcAdpPSaH7UUOnJn2g1XoSybNGEzSE5sLrw/siIRMDyPA2
hcnfxDFaHucOls1czFHWqjmDccJnDQBBliS7pV4Q85RVltweLe+/2QQzjUEN7PHJB5H9fpygDQF5
k1XXwv2xQUUOq4YNcDFMsILK0iwh/T+qk5aCNkDXgyw8qsSx4WANwwko/2oLVIK+HTJkZ4T39rl4
/UBpStBEPJtuG9hixGDCAYze4N0GWkp7FJ3/YXJrDtbSvQQWWZt/E1khxt0W/G9nlJR5mWQONcAR
Dmtv6aCGmzTYhFftbaGZ/wZoZmxb4DKLK9nUs3L3Lr9LN56iBD2m38lPcec/xl/2ANji7CtoxcY/
Q+iPp6sNDUS5MsLIbrlo28h+hhsmkqQiBjItQvfQbsHtIc7NduDQdeFPLcYJY20wBsgvi1b4OzsZ
h2NVXeKjrfWqQO45kkYuQRF+OAdCq/vuni85iyMBp3VU6g8810NbOxP3+c63XiMzKUJpuolWi/FF
BnhbRZRMRlYyZY3Wutz3L6RE5YiJMC2v40eGbeFUkyKmVxlRITIIiY+RzI6Ak/CPdyNAegwO9kuA
pyXWHhpo9PAaSvc9HfukXSK0DOxvjMP/2c4ShWVuSBGXxF6Yb2Gqb6mn/g8cot3paastSdvR104Y
IPqTaVshMcGYifSQYb6AfX443lQkXLGPt+U3fMo43LA3Ryx3Qn8NL/R/QYBLJXep6BRruRy1Axdd
U+Y80oW5SOt+rKXR4wJJ7gr+p+xX2dq2Kn3ESFPpTBrvSgLzL3LKS71PhkfRE0F30VgJHN0heBOX
83I0erD4xO94CbQCtSm1pZ9Lha4wzGDFtHWUvpFdwGF4Bt6qyy9eGP3nKJcL5tX1+OngtCTi5jQ9
8N0ldpbSDmpTEWZLUasJsiw2Bp8tXAaPUCqNjby1U4K2ene/PeedBqDgr+jDK08RBrGT/yhS2gtn
TyiGWSY2GxldFuToUvE5jZ6GBXsWvBHHQXuLcaMnrX38uQ/BZEK1Xmn8oCTs4cOJoVPgSM9htVwt
2CIpWNXbDCgXqVX2ZMy+hlaMG0HXdJbgcm1aBPHSPBt1Hr2qaRyuoUQ9XMbHDWUqLX9S3JwWU7Fz
HniMDdw5FjsBt+LXD9xa+Ayd6qty6BwiLFkk2bbGpRkEf2afuH7TrS49V9/S3Sne2Ve5TOMAhn6T
tHW6iAaE50eSzLhvG5ozFID8sMALHpB+f9RIwvmXTgHAliLPjxBfFyI18ZJZ5oeiz/qbcVcC3wyV
b4Gt2W79dqkaRRnlffT9/qxL477/GrI2G/n+GWCMTsn2lesaHSoksleEhEM9C7FQ6Ghe/+474Vjc
CI9SKq+c9go/Dhbp/HlV9GR6wdOg0zpJKtzVx54+VzM5MHdBTCUheHWTyaVwokbPNjq9ZeGuVCBf
PbPEViilwlQVv3NmV79qeKw5DNgrY3YAwLr1v0OBcpPevKar+CjGz0aZQ2LmAsPT5/hUNXFpHtiw
XLWaxPfYy4qd04fs6A/PiiNp9HvBWN/mkFrLcZ3F6sFRIrZ7a9bDNhF9CjbdxyhxVm0Yh/XIxM+z
7eWZpU6rhcdoBvpc07GZZsBuz8HX8XWrYEBvu/qFkwJWR6EfOFPpr0F2K8Z1tH07GCaoTAYesxpB
atvaqvD4Pekbtv5jNeBXJ0YlHNPLMIbYoFow4FN+PeC5J/SVK/Ck5GureXLtAvmeSMN483dqvEAq
88oTf0CRlbNYOk02qBrXTbqPBTuQ8XmTc2JE8bAQavfsen2rWTxauL0l5lhhjF3TvXwmmEUpS37O
6sJUzVCX4+jQzEgasIz2u9itvPAfjBehf9/9KhaMEGqhdxJcWxvbIoM2KrLQqPfUcsfVH3jja0pZ
UFDmiqXdv2IPXZlkvwrVBiIZ53Hs9xw0SMSr+U+ctGkIHtmv8nwnpIQ+R6JOy0DpVF9NRvtLiLsx
/jCRguEmlbn4u0ywpr2xdsRSst5H9kOs/v8r7sXcLT5zBEzTKPbObfaf9UpIvl9tRrqZitP2v5eW
KieZpe1FgrxutTR/Mrl6EcE+ZXUwhPPvfV3EqQObuW7EKksarVpEEKILhZk5qlAuK1fFn52MwM+k
UjVgYqqi08iLN9OQQzhhqkx2HNYKxXIkt4jV4Uow5V9rigb5/jZB1w5DkvK8+WzWnl+ycmPbO9pl
bWqVzx7+dTsZ0qMIT7N87DXxaMU9WjIRmSR6zc8m1BFjIN2qrH5ByFbbAXVqglk94D6DBRQI5v2y
n0CJdxr0UX/mcI04cVfBQTNu3hCjamWk09wtWaZOphUIo7cpRF04FxXZTQ6GueclmrdUSpJxf3Mp
9oYKUXBBR6uwfD09/LK+NKzaXCvEYg5WR0Q7kKMxVnCrbtVg4DyjtgDqBsnDeb8tHQGnjf+9TpEz
4EhP+ghon7yDpJX/N+NlQRqnmlrq7xPRplM2EKbVGareSBKZH2uXOnSBydW5DvLjn+siRJLKE9CU
o33+fOglatpc8zVPE2369Kh80T0CRSE6HanPBLpUt/pTw+f9OjUpUywSH+QQNiFWoURaxT+5MxAU
yX5jKNduY15a0GyuRVToYkZYYkxThiw8hqw4AdTPN4nbY/JpSwwt4VZIffQFUq7TYpuzMFWmaidu
JtvNa3lcegiFBUOFPxxbv0vK46gKWZS398ImOXgoKg/0Rhc42xZujwhLZNsBVRvoVRhE85Iw7OAx
IieowFPPNt6jjXnoLxwdwAh8e9MBwMV0BJRwA7NETtEFoIPo1zsqOolpy64g+/aAAE942F08XkeL
26RTcRYIrtP6Obb6UpWd8Ixn1Qj+fpeFZ9PF3TFj83S4cLVblXuMz7pUp33+h6KQgNzXuHZupYZI
eTF5pwcB6hHXIaJ4BAC+9k7eFUofCQiq9WMLUXZ8AvM/uJCX6abKX3YxIk0v30K4kp9DafD/MSuA
l25eaE1MrbuCCa9cyWTEHqH1JmfLew94krXB+HVEbLjRYi9Y6Lxr69vyPH6Y44yjjDdcTqmwlqNT
FVt0v7m6Z1xc8FSG4RjrckGmpZgCYpzcQxh+IsybkTwmj053H/jkjIYFL8v811nDiew/rWIclhQ6
IFFirm8thxwpba51Wjdhqv0u5cHGxTJFQUdILgq0cBS+GCglXNM2kKVYYwp2yWX4IgY2njXGbkRe
J9dvC7zsC2jRu6m+8K/R1rRh2/yJuHIWB5YfM9p18D49XaONSY1OHze0hSfWKN6RuRwTY7hwtEkt
xShVnCOYPissopdzKrsaixgzWqAZ9o+zB//T07YJNkr6/ENWrRXuUEWIyZDlzvM+zJc+QUJSnAP9
OgrFiLGX+NVUfTB03GxOUWGT97KCH5hJr9Bwv/xGmAhiaAJLWrh/EDZphFbkM1ZuWD5+e4k+PIRx
hiifJ8Ji1hZBk7tLtXYmdl8lRZzOfvh7jx8noPGBlf8T7vqBE9nw7hGKhYNWTNlUciwBtUf6RLml
hwv34d5fSOgQQa5veBcraQi94veTOYdH/geq+xuo12tzjq9uIpeOY8EiTcV4M4Mf1VGSUJ2z3UKR
+0xDOTC3cCZiek9aen80O2kOKtjZ88ntSTMinlalV2MMZmZRNS9KhfVhkmkJgjXo+lY1KAc6QHcl
wPTptl4aimnrG3whd9dpfOF7P1j5duw7tRyYpMt4UEZg83OaXyEnQ+ESBpk58T21zfeZMSzC3FXH
lM0qsOqnufW/PNhTqvEPGFWuq6q2YdGzTXqWQZNCpeF6JSK6/HSDLxzhUdGThmPhYS5TrzqF2e4n
7cGhmAtJtYtCq/uAErsB62Y5kCcpXi2D9QBO6k2rdcAzB7pcpdVwydkBcvXVj7bmkEIJv3YbB/PR
6J3Q2K5MeoH136FnQMSpNQpX4eLCKaQZ1IpxjEiUCLvjdNRUGIve7YcXYTDIzJja4w3qsuX75fgo
43/M/eZNMTEdEgzhWi/IjbmWIZNFzwnZp72rZLcf4yVwZSgdaX0/EdJogLRuuACWfjgmeT8RrDeo
WoCIz9+0DAmLp/2GYGw3redCytQbwNl6jl0+H4hd8VxC0ImEZzsNuTcVAsy2+n5T5CaGXFkRx6J8
BNHYBIvyuax29NDddJTWwYhpvYX1qegWPOsxLGDFRSi1Uz+QRHQjpBYGHjPzE5gbDN4vMxIVfhxW
Wx8IQp0fGHaLkHFCKpjipmi31A8naC8QsbAByWQiz893UxlvCDM6SxUa77bx6L3dxwbGDXDWs2cs
UoTM6Dk9Wz6p2SM11gYR9tP6HYsUapuF/FtX/Rwf9YEWXip1QmKYl8kwN9vwXLKCdl2VmeKekG1A
KsKqvSVSlUYM81MW2Tfeg7Ur9+v15OG+6/JEr4N1inLwio1qT8wIfjiZk5gFs9aJeJ8Haactw+O6
hgMXGdsIlJ632q3l5sSjGUdz182uOqR/K9GBaAfFyGJsRWQB8Vni3oO0NiUOAKoMZbrJT8OWhXth
LgGlqNRDOs5bFRKHLfPqR5/eHCi1+TlqEUv1xuDiM+RaMXFlXdzZxKAlI7TAb2tNqYshmT1FnVDj
mMRwZjvQ9+7XnYhGBsSRRqCKdVYKHRZ1yYUDyNE5mI+okXb2XJIaKpzoUWbQDfDIHLgzFVAcRMZI
nTyBz6QInJrxpGcV9aVEkpO2udyaJ2iz7mNHc9mDEhJMBsbtH37zbaArTURDTJdtqUuhUD1etFQC
TWyf/F9fuPE4AFHPNU4Kq+Pn4o6uiTzPuhj+V7rW/CprMp2PLjnjjbYpeRTHdLL7E1LyKB0q7/QV
2tBY0f40oTZ5ZKDk8Tzx4EU4818F0TRLuhn8bCyZ5n6nNm/dMBRiWBnAcILl0whSg4k0PAKpY4o5
7wfPdtJdv+YNhizCa1r+N6TqZnLMizf5RJ34RIx0iLuOqR/kJedgj1ZAiEvp9CE0XxU6JWsYAL7k
Xsm2FI5Xd5e/3dJl24cga127CAJGs30UkCZzmvMGS1m2ESlb583WAoFJeUd7iKrHqvHIfjtpInCi
5P1gCauwyEsW5A8Hm/WxTa6Ha2vwTS7qPaKhpjBaqfnZj9R/a6Jh6WS/X3VANV0xCSDuObgyyc8v
w71Nrw1+m+mSy6zFZM0fQL3X5hSMJ88KI/fDAYFQxdK2FfiZ8XfJt9tJbGoETqrz8JiJshTtf0FE
8AY9tkIXBGC9AmQNM8tiVzI7yofdbda43iCFPgd/zsDBRqTrkRZ8YrqzvwuVo2XhAwfcFVKwNLGF
I13bXP5hPftGyB7IRC8DUOYSdkGgWijWPH2h86TV42h9FfEb4vYgTfS4KNQ/CVg7/rdE6vTa1JJ8
gtH2umJm6sitK/irY77Gg8OUqst/7r1yOz49uv1/jTMlcTKaoP3Sgj18BdMHORLutTGt3GFpagju
/5P8xGvN+QU5SMEC+Y1dvvwMtrDUOWyQV13UWsheljdKf4hWfE+qRp9O+Sy2xlqeXWo8Vr9dOq+r
kL/HfplQrrAUqzRTt1OgpXOXq6EGWieZ/IUN7dLOqPFQOxSbPFo74JEd1t50sUFSr6GGmaUCNnOR
8qlIYbOAJOoSUi7hpquWH9hzyXhmwHnDK5aU9xDbkWGo6wPuIitYCzMWrXgnIp3BjN1RtbkyGxkE
Vj8TzvzvGyHSBrdOJU9K0kLpMsiXiAhrDtosjPrueJWYNMF4YZx34M3H0tb9h6Sv8wlvYl+eOHv/
ennMdjdk+VccsQrtBjo+40H45PJl3bRzDPCsHK5xd1ZXeXRa2S0WqrQVQZaj436ByHyptOMrC/fS
NlmY3APGivj1BlMF5iM29BT5YMYJktQKxq2nKv8PGA+f0Pbt1KH6TX6Lld36ARsP4MuBNp/nrE3P
oLf+hZx265gLce53qA3y7ymWIBLtlq9OwpuPsw3Do8NDIK44ulnVymwcLIhXWC71O7SS3aoRVA01
tDLEw7Wi6UXRyB6rFqA3szq6rwRwyYDb859qAnySmU9YVCxROxMG8T4Hbz5h/NLBftbDnoG9E+H4
QSH7bKpYMXy6u9NKxjJF45o1w51bjS3QJrmV4W2U1AX7vexZXqnEIbuUa3bKq8AQ+Mk0SERjBApm
hgk6CJAoAGcHsgHUAmHX82VwMJEc07QnamhL8CDg1EZF8fcyO1GR49KNDGHJ13xihLxwAMTWHekE
7clEfYyr7ze/OBOpW03x6Lt0Y+/3VqPwioUM+mwO0IOMUuxyhHbj3z/xMebrWJFRvDdV9LF5unTB
P22EU1Um1zt047rrmzhDbxA8qCkPkoh91WvYKb5cJei/9L3CHaDozugDqb+6wTMJb9zjFfu7DAOW
GqFR5WE9bO2Uj7xDBeDTzkTnblE62FJNHds1cEIrBpTZ3VYeNP1fs9tH0jNE2eKT7tgfTt7hANuL
ZWyZvGWb9/p7E6o4s2qcEZGIzQiku1y6nmcaEIy1zLxq5tjg75I/7kFncOI2Krqp8ed1l1ejmQkX
AxK85d3y+Qa/31e3TYHD3YnaU0+rU/oimqepeX1SsJuATCi2EiDADKJREbfte1rM4NSmeXET6qTP
DF14Ab1UvbPHb+HUaw21GIzplhKGTwv0JGWVdRQZA4yAf0eEQVgYuGts8KIAHUPjuluBEHEY/O+v
MTgVYBYDCqFrZRH6fv5AGkiEepLrAYMAQVz/mKsPxsNwjCNPAfv8JsxVYCri0nfBBjvIzGgVkVb8
zd8KoE3XOJlOmibGCHsVIcP2BTDqMeiISe3xmdr3ikIcjPn04LCBpQG/0sSOtlqNCct6I//cnH+e
y2qjdKOZc9uL6sqqHEyL4BOv0wdgD1IgJp+X2NYZVJ6xXAuK8xaa6Pi5QeIDoHMyllA47Jrmf4RC
hpTYJmxz0in4N2bfqKXR9/yOHcxPzhOZfJ9MpdTraaRbQe1+FX7h2xBTHyRtBcujBbBfAndFBIRu
cxQQJIn2xtv/uDKg+Gy0/Yce1aDaYXMVxreGrhSTEvNo9hrh5T55M7BG60R348LnMNNEUbXzAcEg
NFF5gLQM/lkDTE8DqeE7vBQvwPWddOje8N+tqOpW/W2+PaHmg6dC7rR9hlTMoYOxELXlmVwlDvLU
kTRXi98/+gcEta+tyMtp8prVaNoWbfNEEIrxFtscrc7kScxk5UeKr1RL6i1hn/tOAb555IquvDCm
16o1mYXKf6M0TIO0LkjsPjO3MnKdPIOwD3BvOqz4KRvSLOJ1qeNBEN/64hCBGk8iUcZTa6Ayx60J
XVqOAgecc3q8e50OooIBjjOzrf8tM+fImIdAZRFcCpbwV7bixxr0PTboV5Yu7m81yeGka8JWo8ji
EJWcix5qDrZz5a0smfTjJi6PtwxCbcVKQdGsM6CQ5Jdb3UhdQkU+/JPE1Cbg1AfDj4a2rtRnj52g
SBiKSGb1