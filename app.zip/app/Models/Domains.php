<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx7jt+WDaYJFo01AorMwwE/+rdz6b0H3cEryd/1zqgIhKhX5KIt5/bzLAP6ui/lXyDe1uQZf
tjxxto/QbXV5wPMfdhaYKMRS7u4nACc0B5hqXmAkh1qDt96b5fNHsDZ8a6QZ6Dbsi6MZG0ieA5rF
GZIhFS0l5gJLNVOBh2r2T1Fs2rmW//1zXtNX+8donF4LBhr/aeih3kq2ck+EE4H5ya4kTClXjshc
rLfv5/VDjH6wzdU+xe5cwvc2CZSi2XjnoMoy/baduPHCdVQyEGY+b4ss9uU+f75ojioqxfBnYnpk
ZdFHqq3SFe1k+DEkiF/fIeu3pD3mM5qHpz0veKekINgjeIw3GBX4d/XklB4GpOLiMgqndT7kHXhR
2cnyY6rQuVW+MBiKbcL7KP7XOUtZJwSclksvBnNmqmJj9MLfcfDVkCc+DXMz3b3G3a7j5q8Og0Iq
+0HGfq18N6DM7wIOVWzlxJ0u0/MscUNAsIlyXMEJItkAhWLr3l6aC621jihfMi2ayIp6jcaEwzIh
srG4k+195pqjdlWTLlS/sdUiPXyjcZ3Z5Nl5hwpbZkNjiwBOfsPLFOY1Nw4K9eBNkZlWslthLu1T
Go99G9jjuJDY4ZXd+OEUNzE9mGBRKVDXRoazrafH3Z4U5Xdp2Xv0Rwt188IgW7l0sC/+TuHIB9QF
f9Ti/NDuJn+G2mUAvJYMyYvpDonVXbyItMqHwKu/QuKcFbtOualqlkpt6vkOgil0lcNdigNrMQrx
HAwasR2G0OcUkOqOzxslTWT57ksWrFSoonbUeFAkIIgbJlZnDyuvPpU1yTtT+zsgIip2PCNv3oX9
YjcYy+9FbzsIPDYlRBTHhZ9ajtzTSj92Ls+Vy4BIGVdjFzw/DvwTDpLuIWmk2hPUIx89cEbt4W4R
hvg2EmoCVhqewYu5DwOOn9VEC3Ruiq+b5PGLvqQHy1nZbdjYIlNVEXkZXYZAI44a9It7qSqwOJsv
kNlbQBeXzSsNqItaw28Ho4S2/pbhDcjhTRMJfq/esy4I3Lz0KQGAWBgW0OJwduf4ftIkdRf55iux
7JFt3kwgacRd2AerIQtLgc/HvzkGCZs+pofJ4InHKG8YWNOicMIJN+RNB9gO1+asp1A1Cbb0CRyR
La5MBKoMJiqVTF97EE3vnyr4skSTsUfccmGarS9VhmxY0Xy0o79o1OMICN5/al65qQpvClzMuAUN
WDyg5ETldWP3oZxA3k7ov0/B/ag//A0u/78VzKD9irc1qH9KRgOkbEuKkVW7hHw6NVJ4ittXHlys
zAGigvN9kg8KSAFj6Xnlc3zohr2WtO3p12WAKQ5TQT1UxEqwd5Uy9QQXftzqltSVQRz62ZMecoDm
WQr5LMkhPk2+bqdYDK0cXIaHRUbWoPSVFWLVn65+qfxoIzc5RAtGy7Fxod+IfFBgfNE7m2NGI5M6
oTYLgflfkEfF53hFYyLvVW8lZB+qiHwHsaM9g69gq6vd6PRs4nmvYaqwDhxTut8LSQ3fp59PsCYS
boa2Xgtkwv4kms6ppTKWaG35dFDkrWIEdDLczKI1JwK08rGOYsId51nZvGBKWhVlyuTV5nnoCNFt
uhbQE2hvGwuDolLDPc6WvrjNMhDgq/2ZNG1XtimvaEMz0cZL4oIbZGOKRbLAr7ym6MlGOo2Vy6zJ
o2gjQUuuWLoXmKa5Tr5KkjdFioDTSbHl3Wi23I7sjP9BrjZrCOwVVVFMjJG5IMAQDGUzu3H6gaQr
96TAu5y6MfaZXQnzCjwPsTC2ooHVhOzw+ELF4rxBx9+ri1FFG5B7BnaM4aK7b8tfgBzVgqf4vVt+
Txatfvs5mRNr9Vmd26V+/kcCvbIK/6Bcbu0BqJAi+MBMJ5higGLd+wQUyxr0LKIFAb82XRZJ7U41
P2W4BQbfqUmivxpTy4maSEuzMmUBAaZfYT9J/M6++bg0lmnY4jbu8d00uf/6BHGL6pHuRAFcyd6M
Py+x+M4ZxVAFC1WI0RTCGY6E+9e8Jc5IzEcYL7Pl4yYqY8LS0DtBG8wxB8DjWO+g751zOh/5qBre
/r0l5O7ZrDGQp5SPOZt+L8S4gJAi/cpvUa84zh6BDR4WqeWOQu2a/vP2GO26azCto48nKgciLAtm
faz3QN+jt+tCevJIqK9l5ZqiVfzzx/rL9NFSPsGg0Skig/dtZsVSrzIjOoTQVFvwVlGaoVvWyFXy
rxQBmAW/kg4jRJIZPP1J6+T3fuYSxOyOifpYvJPdIem2fThGlPvGnvyZEDHphuOqBATRSl6Uis0p
AvftY4oDDp6BUkzFQ8zoHhGa+BI/9AxzI0fL6rbgjTIpaGThIq63fOxSuFhf7DPg5GjYHPS+H480
yjMCX7a/Fis5G1a4ywI/PlFrZ+sP58vT+tM/S7eKp16FTyuzC5adkBaAizUDK6W5M0kQceQQTkbC
3iFKln89yxzsAiHjZ+pn4dnYcl+XrGDZ/8grVcWw0fVxNnniFUdVhWY1irRGvTQiX2TyUqE2dMTh
A/EC5nudDPEdNcdSpQOmXkeg3kdZN+aQLzTScRsp1JiaSIaaSAfDFfVoYqFYahTmuh7MCIZpL3MW
3I7CmlmMmxeleO6yks8KHHnAljeoEGAGncXGbug3qIldmBSG2VsQJ5/prZSTvp+LfPQWwi3RgMfN
S7Xsb0CnJKMOg0Ax32Q9v4gjUlqXrJuE6mvWM5IqLMZushT0XAKJn9Q7HdhxO847eYEQCv57kyLX
fJqcJ2h/vukFoaGv8xMTOp4YNuIup96jTiBWxlKIR8VS7gVggH0lgsNlKHncdoKKSMgUhqw6zfhs
ysp+vS/S7Uns7haie+18ceVtkv3JmH12A1lUf/z7xXq1ColmNuBHf+9oTu/tezPZQ89wq3ti8wEJ
v5cwJQsuqgQD4Sh2r3ETsn3xBcqX0tcHuT/oVUFmDLzfky2jLAFeWl89RZVZIa5jImg1wK6i0N/S
/eY/Qmj4Delq/UITFgLvWw+/t0E6MphFfueTizvMQJSwMbEQttr3ZKslX2bOc9rsW9skQ1g0ld5x
bckFl8ksQ9KlLrIZhQiwNpw/NAoKyL2agij8UH7b02UT8//8JT285lHWefBg1hWuiD4rqMSgDqy4
lMx3BSWEKv9Ew6p47rGDm0ZMzTDRCeD2CDCi4Kj0T7kKZz8OXNeQOz7452HLxq0ZozBDtblAVXOY
FzUjf0/JJTb+ZgZpeKU1Sz4nKAineTsbuxROOXqd5iKq18LmN8RQhGO5yMPdzSEeWRzDkbKMaFDp
JnQOKw9zAs+KNF88z6L7/lCTkiDZdGWlNCpxHB3d85vsXJy3O8TaQLa2hM3yeWXZMSXMOK26j1bj
WpHM6PzJqZtAGHhtbTiPUPqTx1roWnqx1eQf0uH87iHV7mQaiaYmUpGvNWSoFb4Bnx5D+SX5pEOb
f8wd5iWB2QPBKOhODHzey8lOPk7X53ADEqvLrOneZBGCGjS3shXfGt8NAq584XmTRFOOCLsBfoHf
SJV/dTzZNuy47WUXKwW+xh2f5WyApYUM3nHqB18ndvZQvalvT4Gqq8o+ptmegHcz8Ovub0okQ9gG
R6FnT5vHEwPwX4Pv//FN3xQBrm15Cui6pE4Zivg+jiHSo3/ZfAXphK2jEVMA2I34/hyLQMjvSPjK
851jz7ExfT4WLs8pycB24/A/DbcctVazXBtuDDy3RdaOk2+UCTNxLFCS5NUKFfI4Sy7HSGhMIFZV
GXJW9/AUPV1WbzcFG6PDJUQ6A5aJwxowWKgG08mZCkMFBASISUZQRmp/iiSEUDp2G5+KPbNhwywA
RI5AfrLSQAyDgMUjanNiWwoPNwa2jkTUT4sKMXBps83rUa+XYx88WoOxspZsgXKFY7bYU/8L7G0L
ityAdT+k0L/EI1KffNkFb2+6yitoH03+KTLwi4KDeG5cP+N0IN6Sw87VbPLxgT2cX8awIhUAN5Qe
6VohJ2czaRFFxHPqPyI491qhXO4dIWNvyMlRaGEW5O1GrTvRSDOj+LN3otsLWtj5AEXb5ypv/8Wk
6l5qusdIAColRreFpEvQ32mDTtUJpl3MI2+L8J3u6oB0Q1IoVXq7mcFnbOmZwx+eo70ewboGtoVG
w/FuxEletEiYaCR12Hyvg8Wwgp8Ez/uC3f9/TriS7R+d3QUkxfcwzwv5K0n2YIWmtoLe+FcBD1wR
xeNC4mceV9q9qdu/UTyifTtCfrnsMOyQmElfMiVFgmtzWHWDUnLzbbNl9TEZHEPxYD+8nw2V/L67
biB+0XcDaq/jo/hmh32/qZzKV+2nuo1AOpkF1dKNIK3UN1vTvC+joxw5kcAest2UBV/3oUGwgU4l
B17ppruiL6vwZ/tAolBlU+Zo6l4hfbfGgDLGcl0NBAnzYcIrtm0ILfRQyb8mb6k+aNMYemDAPQMW
Z4mj6+biskjaJe4Oug7+3XvkI4qGYeCTPu+Dr1oM3FjVSkO1TI6R//Yxs3Dg/vOOA/DP9U1OQCMa
fjIPQMkvzOx527euWEhXKeP/6hp7aidb2T+lRKRB8Q2iEZNPEq23wc7corXWnqzgH78f5IDQlVUn
FXoMwls+3Iv3EDeGTZdlttDXQFWFa9ibhEJy0yPh8iv9ifaBcraY5gmGMrDAH8/ETm9cBdp+P+za
56AnbH0NGUSY9SmZJvWMj1sNe5OqYwqacT4nCv72DCVPt03/mb6/rN4EDDbbtE9ICVMbfe2eRRMM
YRsU6iEJXQ1RFZ6u0+YnGxzk0t/pKcxLCS2GXxl/OZOP+GVY8BIvcOgg0VSHT2d6gR+zANUE9laN
AAPa7f4W96VZ6TVf15q+erEEmYJUtd5Nr2I4a0DV4JWG/KrVRzixxchNL9eKMcjWqIkGzuxMD0sd
2W7mTFEfsENi3mWi/qtsyoT17kB3TbLJvMhEo/M1Ay9+ydTB3WWVpBF+Ymk6NAC9kIJ+IIcemL+2
fVa+qLw2gD+nCZ+j6tg1Atxiz4KNCjnT+WYammC3m/2NSwG9ygoWidZcv2USe9FLBd0mpiY6bjkF
k4mlSmiguu7hgjzNLMVFBUTV2hJnGMswZPK2EZ4k+IpWe/hZ7kX0Nst+DNeGefhRRx7IzNVybanE
xsKHW6qPEYcm+yhn41WtBwiOoY4Nnk2f4xp4uDCopADdx9NGxVSTpAuCh8keQ0VzKZEtNvNu+MKB
t9maqEgipb925CT1wNmhwidei1SasdFnCPMdQJQXjTEaR5NyvIybAbab0tgIo53B+jiORizKPoT0
wjOk6NkcvMANYfN2+sfOMPPHZokr1rjUpfQzUPEjg+2tmXeMJo6RQB1OKqhzaRdMxbnfZIDfJShJ
H9185gyGqXILeZC25YZxSRcOvgcvKaXO4NfHx1ua97OKYiDqorXYUO+H2Ye0Q5QTfVaKnmbS6gFF
RcQTgHmntGHtvdRNavt51S665X85N1Q15inuiqtS4ThnnHd87BCMYYVfSdAz8zs1ZyRRq5IVs9gD
obuxsjlsFSJSU0UIHwjFrifW/5qFCiiO/tG30hogYwtSRHpS7R9Oznci7ZGoMgeQX/06qiTHmWTM
aW7TvhpS8IbXM7ms6skt/gRfQdR/XeBKYzlqUmzJnCjJNEBccvGljxxfVdoqSfakhPeDm7NNDO9Y
emAaF/1t0CDAoJ+kaFAUd6/bG1h9slgThhVTz5gEcCDshsYE04h+IKd1TeUheOMWAE44I84XSWk4
uRHkLrkCWZ72FJ/6dacRs+VGISNHBxmqCtPRs3BrdBIIih4/5rLolv2+t2kk/IcUxMoCmzsPS3yp
ZeLCzZ4N5eyIVgDnW3fvfgBTDjBdBVIKWUmTEaawvhcHBFrwody2LMcLIN9ICDxaCqQPRmcpr6jX
4XdD7y98PHQyKUuHV/xcYIF66peLrsjmHj+ZCJ38dooWJozYxZWO29IITaicYyU0YqDZmaBcbmvL
a/OiDypSKYYYuULfatCduVGPWHWEEZUfrPfCcGOvfXWmx1t1bGEpXwbkWHBOK3Y5UBPWKme1TmvV
/xP24vCjpbNvzt6KLn5hg49F2mYP5M9uFWOs0/hXa5SfeBXI1tl7qVGZ7Al1YWjibQbzc1mlE6o5
XhTY9xc9louDtLUuY4VpccXzS6lRpOui7JqVsDMfSVA+jhHbdhQ/a1eaTUe3cP8qDuY9M/2lyEOq
D3W1MuyLS+5HZnJJb30sW2kvpqFtbFcLC3Gd3tGzDl/LcfwcvzI+wsZ+bzcoaKr8TvFA+W5Z58cP
vhIQo/NhHh+hLHV362cdxwzLm6UCmAjHL7tfFlIEQucUhmOmSIYMqhXr1f5enuK8Kq4JZxpj1mIv
QPwQ6ajoUOEkrdM2r4aUdr1RcHULzfZoI/FJhLCEUZ/eO3SzVdYQOOsP5qTTNEEyl0Rq0fhKUBj2
2XY6Lj3fpz86FMZMUzJ3hkrJpfLFtlq2ScV6Fl2fTREc+1tFonuz5dSw8qQxqqWLsFNV9w35ch9o
3HxwwXb3UDqhmkckqW87D1hbfXx1dDHLgnKWuoC2ln3GQ01Y27hRHNMhlyysLA/bWGJdXDXxSKJl
7Cnd7t5SqwYtUUaECtp0TgILlukgHF7Jgx25Gu+4Zw8t9k27uHzQHBaNCr2K28YWG/jaJry78oBv
Kcnnxpu56zSeHNgckhaSvxAEbkOM04G5+LzhvxRedRSdJ+eMCpvw8CBW24URkmSwSPskA2+zuuxk
Jr8vZkdimN64xMzdgfAfdt1aX9JlPObdpa5gIsZpeqEh8dUBbBzXPOSfAxrcPDogIk+nc/AfDD1Y
u7OHoVH2BKsWI9h+iSNhroyvG+c60jLNCyBSryyM3sRAmmg5QwbyKWdH5qjCZiq0l0wEMt8Ok2jT
lebbOSECXv9bmzxx81Fj6yk9zE+dGgKWcoZtd8sbZV4gkEM8WGfHZ2pwpI6pruwkaQNr5sZikwuI
9F6uPFGxjdg/mPk530RS4Q6vj9m+DDlDBiVRr8fT0EQl8NA5ZrYx7TAYfnFKAN/Sbo5aM2wMid9l
x4D3CqPcYaznhKaVXgsHR7kNYh6Ty3gooKKBqzfUTX+LWobxiAYLB/gJkttt7/+aDIryOX4UnlBz
/LRRtHyXKrFydIT7Z/RsHi7p1EE23Xk4kmitebOHSpHNsuY4Fw109u/wK4M4Y6zygkBv1pxikxSA
x10V0nTlRRCCQCU1BUne4XJHoxHlBq+cEuQyiNfP/goTCjdCoXS1jr/4OEp108D2ZYPsECLZrz61
z7VSERDeOHZYDzd3FIKiPLox4vj9U4Bgt2q3Iu1YKbRYyqCjKL8aUScDt935E4dU67hNdMH2Nkw3
OYc9ka+GszjfVOmapnXxNL76nkjIc54CkHGqetckA0ecPWiwKrhEp05bjtbgOsxKFu6DGPQqKYz6
GfOQXqRAeTKCLI3J7u1nCJtKGfyoy1qQVdM9+p6gHxCib/+2envwNANmCiWbkL9/deG+CYuaB2oD
/cTlUjVlucoSpJYj3t/axwfc9ALcTet2olHJq98rk6xtVXO9CqmgQ8rT1Wjd4sQF3Age3DlqjSIW
+vuZ9nLhrtXrOWV0hr96gQBBhE4NsfgY0rrv9u4b/5yZfhiSXLDR9KPUaT1arxGaCzZrWRk401Zh
Zihxl0sZf+cisfKYZ+PObo2PBGPMyTkd/a9HZzSOivmwk0OXQyVX6GHBMeG168UINeIqeHhpS4rP
9mUlrzUQz3NdQG675dimLBekuUUSVdgezE17z5KjLRjX2YamOGiY9gZ+0jIy+7n60BvjVFxCK4YR
cIjoog8jZGYDgheT1o8AzpIgdgvgKNoyIgl0dgvDIpkHMFbp37JWgctmtgJRK4216RlUf8uaxRIa
5w2Rv4Aq4TTmPtMOmJf3a8+GiKzwskb+Y2FQcFnb4uq9JuNqTS4LIJqSYmAOdR8VhjoNJZy07Su4
kB+gtJyOrqzAsCItu8fh5AQq9pj07D+BFm3F1nK+1UCMStPOoOysBvWKu2cVOmr2ubgbqU2gqgw+
8ratAfEmPqqqlDlAsxyMp9VxTw/6lYpCUFlVkd+0aFMs5DCwoY2+YT1MTZlGeW4+yEC43KAgcpF8
q4qfRxxL//QLq94UWlBnli7XvEjhqMTTQDHAwSfklUcADzKTq4auH8w6oK/66isG0vqMiTD9vDYr
bQ4qHK2uvEhVLh8LGmriIO/fxsvndIRjk32a2mpMSMV39OjnBwu07lqBVyr5dOLd22DyRdEieOnD
JKyY5XD5kgALaU0=