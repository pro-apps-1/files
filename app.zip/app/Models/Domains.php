<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwCtlI0Kj0KNuTee0oFVmZ00k0FdyB+KaFu84WbFBh2nMC3B0pLRvl0ScfoFQVKPQqmFDD6E
3VltHTPIDLmsXVF6qmSLcusE33b8/eXWUeCfKgROAF4V2yrvgyMJs4R+RSX0FUqvJ2ItBkxcovij
/FfOVvU/wOklxz2Lq8Nr2IWH2J0YTAhDzWmvnTg6EThX31bMt2RlN7MW1ni+fQj8MRENHEiWcRJM
1eFL9+RBDkgYXu2uP1/3QEG2msNdM06+Wt0tz4FZyh6F55dCubCN2OI5/+0cyj5gTqdnSNIA87c0
IaNtsd9+/u/mex6QaGMiAsKe0P229tvJ0DR6No723i3Tij98fp4/kjm7Hih41u1xg10l8MJKbDKR
tR5+g46tmSrwGyyJY4MtpyYJzoDGQvM7dwIJPIWnAUqRdq856iWP+k4wMVcjYIFLyG0mf4+FPgVr
FU158Hm8FtlQlbvoat2jczut/h/OKkLDts4wkkO1UHwe8L04Wr51u/t+DZG1Bv/hhfyL7kpQ9kc4
8Hy9lyVkOf2rbbbiza+HhOCgQA++SHKuJNILkX+KGHreIUwiPZA1WS/Yb1i56gQmn9phly1Elxd0
eETSLRlLi4JwfptB2MtbaBGYDbpr+ZkCgx1pp6rUOmKKuat0DM7gKZYZ2hORo81DxeCecxaiM7dN
Ucy49HOckbREihWLC6Lh7Cn2A6kb5/Ka/Bhepik9hk2VWH/uHwHzPefdAjEuWA1NYjxNUwyuHFXK
yzQ8XGmTBDjmvdC0Uqd14aX0HhqAMExW3HqC1sKlg1tqUnJOvXokP+MXjh6oKQ8BYUmw0jD1yZ96
2EX4Oond6niQa9+Fi0EgYJufdWLk7S2TiqkYzaUL17ELdNbexp1fqQ+NJ/AheCRuk7BJmWsNG1Gr
ZMO/DcFX3lqMsoCzCcmtm4/tXsGoCfx2XyrmqZ3G/N2Ut0bj26KpmuGD4MFFcMdw2gvtqMD686k5
9PypEGS3E5YaRD4EKl+HS0yNJquBg9oLWvEZekSTpjOTnmg/HbepyCemdgpCOESDH3wWRyuIfHsP
b7A4adkP73Vnxo3dlyk4kMxNpayF4ja6hsFkL6txA6kd6KZKJRhKlycpvEJGpnByXRkwIbveuvx7
JMk3NLfnszhDGOKb3g6sReVQlCKWyod/LT4Ff8n2DVvTPtcaz48KsXfHcjTTawugWq+YJhQkz/qQ
kV1ztPzvq8F/3A2uH4eZUY1DTPOfT8HFb6ia6NO9abQN2oZ62HhvbNTBogSzaXhNn6fPv6hvPXyt
8rUc+Hzwqsx3NW20scgpGTByUSV6A1iX77n3ghJT9fdk2yLJO9pTFoyo/r67jAq+1cNW5OIxmHG9
Lh/SXjFssCatU/C1gdveUY/i8Db0yggzXsP1ZlHXSa2Zvi3TG0ET7hmjFyIHRBeryHU7Gmljn09S
n+VbymHppg/CKDqd38Ux2g+nX09kCUji8PfA6ZQeT5/iYpDceIm9nCbHL3CXObKWNxapg3TkJ/X0
Aooq6+cIT1BN6uETBtCNS4Xt+1o3/qeqbaKcdfnSV7+6dDP8vN9cSov2J9cMbll4vObi/I386XYZ
ehiK+fzB4uE7ofmox7f7nhmAW5/go12Yxe5jZXrZYM2fbaKQblwQtwIa2iA3K9gocqCG+1L/1CDm
ekKsEUVGC/t4UWNqO0KUb+Mm6cPqCD/9f2+TQCsJPAYwZ+ZzrukCRKksmCp/XJeOu0EPNDrjysUy
Kkm0BfbiTTVfc6V5blfcDaGf4RkQyychNAxzFZQdAQUsbFLnmfGn/O1mWZdCDF+zXIIH0z4svFHw
JLWpa1K88NzFp8i/jCJD2B/eHKGVDk/iESGFUq1EgCRYIX2rQdqgsPu57LXeR+hJceRVSurzxoV1
g48HvLMx+apiO8JUzfA4KMRyeH9z4bD9vTZ9/7DhR4pOqN2D/Zw9KuweFnoE4Hr8ap0kn+JSw3gz
FMQ4Q0TLdsWcdy+RAbmLaPU8vYWBax4LTaH0EG8uZsJz9o0dEZjNDi+lAdAGOSSv4HGx09tpGLHr
sluZjNpf2/L2Q7NyGR1ZYAO4LsFkKNko3gFhlUXF8fofwMH0JPZ97rWgnxFChiuEiy4SJkU9feaK
k50X505lw97eqh/pRqSokGkH0DYMiVgTEFyVkMa6RZ7sFY8Ef35nPlAcd71Ipg3Z5C+Ezer93Sip
YshytdAd2Sh8x+o8UrS4ek/eYzGs6zO5Jx8RYCvoXS6eYVRITSihuRZCY5mrm4bQy1EqW+BOgYdr
elX3Iy4eWPgJRpuUiZhEXmq9WLXXDm0ShGpMgKhClSi8kPZoUZ9tr1okd0mW4bAl3J337uU3FMhf
oVnraNCSuWKr1/F9OtLVWn3X+ArQR8m5QtHA1LzOeW9lKfz3lLwFglCJv+dMj2BHf6E0hUaLdZuw
ylfdT/Bn+t17ibT/b7zDixWh9EGPbXTRNjQf2pIlM2YfqznDAav4jlpJz9e9eASTqD7IwPi0zKno
4KRerTaH30hcHaIzdNs/KvgsCsOJ2upcuwrv/lfYtEE19iKZOih9bMtQFhHXal1fbE8SMB8/HsUz
AUupGGAnXCw6qwSOBjBq0II1qZbnIze8lcbvxd5kW9PlxUU15EKznZZK00ckxuAgrrNMOTajHOmV
i9DWGHbFwNAJ10OUXkZ0zu+g2cVzY4/+36M7MqygyrO7ljHhMA2QZ4EeXZzm3BMHRl5RkJ6ascJ6
wZyn/YwbZYRjuOuxRysfgqdV6s/ZyrQQg58TsAxhDSoqt1h4YqWsyx8RsYlOUw8gL14z9f/z6CsT
AWM2hYURzvsTSUyMfZPIedT3qGq/uk533tIjtUM8gKjo3XIJXOTWRNCTkQADTxiM9PFQcrjhtVmY
WrzfaaxmlgRYnpb6q7PiDVBxJe9b8TXdvuDtxSmkBMoJDBxgX+eCq0zm+SM80Bxb2Rip2GGskFXy
KCYAsQCUxZv99fTA2y6b+x3oHSh6FHXqbBqkEpyJM3b/CFf5MCUlyhUVSfA0kdCsr+0OeabLdli/
ixQdJ32UdI8bgOyjcVxfsHD2q9F0D8fMomZytaNmE/2rTFyrvBuIv5Qi+Oeb2A5NZDZt5ylQwNnn
ZDHVOBca3X6d1PDvtMUb4P811diobACD0S6TOLNRaKEytMnogM4e3QpRgID7sYfVSVUI1+2Yk2Ep
blOXHo9UE3BysamGH+Sm/cFkLblYi6xFCv4sMgaIs/W7myS+yLEvVqCuq+82tdTkK4w1xHzxbtsI
nxyaygRfcO0KVE0JIXODsFhoYsKVU+abwGUjx5i90RTWAqtOfzafljeHKYIPG6a3MPTurl8rjO+R
WF/MrcsBMPDDYrjchz/sI6BbcQUFz4YM9Cn9OME1FZNGti4RuG7xt9ZqxUqlDIgcb5NPUg8QTDj2
ZLFHDXe4stDIg465un2y/WhrGtNnVInMOrFgDaKKboeU2sPCxit/UNIkXTcW2M3GLY19i2BSwmIU
E2tSXny/TwinSPNjQNOqIv42J8qmshn736GKCp7WVyNf13+rSbBeoyGcvGUIheZendBjyTHPS1re
Vm03Jhy+VMXPiIt0KRrrsnJDGwz3LINhL9zi2AQ4o8DCPt2GS62YmiRenh9UYUUlNRi0r+ArUkWN
xX3uV8MrC+bPSA+17kr9myJV4yhw9bF5SE6C6975w11D88Sfb6reQtgIVO3IUUVzlQpR1z7R08Jw
02DbYLjpfhWrdgDnEt+AaCbZ0szH0Uw0x5DCvaXUvfq1IJ/q+nN/i0X5ClKj+DULlFf2FavvKa0f
FMJ6uA/l6t9Wu4haX4mjM9pCr534ggxbXCUhxnjWTQzp3iNtPRzym7jQA1vzokVrZT8eyiE9R3SZ
mX6+AP8tTXg25t6AHYrHengjUrNB1yBlzbtANWnc3Qon2i5HO9rX79HvE8igFWKCZXBO/6OTZdin
AkdmiTeqIB4G2itw56C5vUM/GF5U9WljWbGBz+A0DCnSsycHqlehLVe/2xL/FR73x3H3AgHaiE3M
94xxabf3WWm2CsiATy5sZ7HZRTk0kmg3aLVztRelQJlRb1dR4NoVeK+Sx8srIkumKv1MKZSsPoaY
FP09levmg7XgRE2gRlemR69kkrVlwXcE3Pv+hZAiyOGc7lhA0E7+7TKpT7W/sFiE4wYIRV6onAw8
TvgiPLxkvuE68FJzl8pHJXZyatxca4ML9SowJyyO1EQPkZKgcZw8BDABHEKRPfShmnDHiCI4808V
PaPxIx567b9FyPWjnXghd111EBpgix3xiZhUyIX9/8fUgsVjOvFkBygywc02DR0N5TcjTz0UtQkY
sZ4XxZTC7KSBJx6utwSTdfbINQoJGOpdJtyY3wSgcv5D+XVAWI3o7j3iRPP/xHmn6DhTWe+RY6qt
8DwP42TvBumOFmxuQZL0rUs+OojXsm7md9/r4G/XMtrqv7cj86GIR3G4GQTg0ac3Yeu/39XiybqL
PQX6EtUO+v+c6a7IB50sdYz1hthScpa8qmEm8HNVsiM+vPl/tKxbBkmFQifMUwpcNrxI8EHg2+Bd
ivvhCQE4xrCbQoAlISQA3h4+DfekFgtymfBExeD3RYbvsNyRPOSS2au1sUWbRWUf9YM5NlKYhiyG
FKDfT0EW2k0iPkMGTAFHY8SXpBoAXryUGiwjaATh74hcZYVwBeEIzYKQqzHFCv8qDHBgp+n3ghcH
AfpwjuCTDtKC60Gu2rQtf6pMfejrjLy02EXYg/Qr7HvtRj7kv+8+14oRr0YUpVHnFhNsU9481Isy
y3VRi6owYzOeZ4soHmtwknOIVA9dIHc5Dn//niws5hBBbcM858pK1V/wGbqGfc9vzJ03Q8O7XR1/
wEXmnW1e8hfSUdIfcMw3T1Q8enoXRuwTQMBV4ZF/L9x1AeHPOpPoeEwN9pThlqFMxVnoUug19KnM
3U1Gni5u1/Tc0RvOmbrT5Uk6EROC5Hl8dmZP6RNzxXY0ehuJmRmSj14VcyIOjySB7xqL8oC6lHv+
zpXarLSKVL8N2KQgwmbi8xPFaT9WAebhAc1heJxUgEO2AP2U/O/bcp5cshWjr7jJ/aTh67SpVuSS
z6zm0sWzrtG/TNWTzwyGIijiCmpHEKAeieM5syjCneIldnVt1ZcexljQ1DawUr/JcoG8PBwiRVzD
rR/i8UOk0qvOL6nv3VVFvkW59P2FDECJ23lVNASX8MeWJIvJ47C19Q6MwMk64OPeaWNenhwpEd8Q
6MzETbsjil7YDkQAjMgv1fJkp5sv1lyG1tqs9voj3gVSxWPyzTPa6itZL4d/cXic3rhMXN6r6Yxd
Rvo7PIFdwKeFMzDeMDK2hf/8LMrEIjnilslermO93ZaozHVc6CpMd+/dG0GTXsO3SVH2VmVgkkYF
YPiVf67ZXQ3UYa2kDL8m9X03tb9UcqifTqlZp57Xn+2wN8bNR03c4i2sx7MrpRCgkuR/ryiKBTHQ
fNLYJJqr/uxLBjFlMqcwMnd51h1D3e9CMmjQRr3iIisMfbA+89bHZAFiAB0xI935tBHneDUIHcg5
V7IX2GPB2M+ydf7XKHnknk32Dy9eqJtCrmfQtdT4B07GZHEw1N7w6bG/45AXAfxBQJ9J1NFd0r7q
w2pECLfRO9e77OSrXZSaUpUQBeUw/zie19ebFHcu2QZz0ISnnMi/EtpmlX6lNwHPTOhgRnEodVfv
TPOqilyfgRmCWk49mUdRcL6vthHz8DaPG7jp9cU9/CrLgHpgkwzxiZybEzcTQjyjopONQqhvdNiN
1QBWprf3XFqQWXJ25iA7pN5ue7TK7BWDKqUqP/zGGX6pTmYmKHf4yWU2z2fHWxYduEofLS76LRUO
cGLUzdJ/i95I0tLnwyhcLSXPAPajnhtCXH7j7qwezk2ikSWkbrLmys4KpK9/K5WL+QU2s+PzJQgl
C0j0xdbjPxtwt76oNFX6wmez8iAOTlRsSnJQKfyu67Ki6uLrUcfOJt9D1tH6MDbk1zMiNyyQ7e+m
uC5A/AMJlt0wpJj6W8v9sc7Pqxis9OWPwObeROJy1itUnEm42DA3MovxxOQq/3VnJTtCi8rgru9d
NH9VqZcYu/ZqRwboE3xBpS7ovOZ0QuIOqZ6ZbqklItrSKXjzNubR+i85pgKm+SEFT6PhN6pc9dSL
th5ud2ALb7+2rMK5I98VAHvOtKfio8e5OmCSy2tiKM2wTly/vtS4nAbAgiSpLRUITfmRkzdyUYrR
fGdXs3cRCd2IgZwKnJv5of/ROYuPo2Uh9xVpTSSBjsHfAW4ckR+c//58uC6cclltrC6ymxStEEHs
+zk5t8I2RYq9VlRrkH45ZdwEwBDRQ+nWVfptKb0+eShZX53JHf7TH+KMEHSMyqvM4PmIcqebIQGz
6K/X8R0EObHTUyn7jmptRgT+3VFZ//fWLWd5mCCLLaFIaKSALHvqROaHRfp4/B52sKHOWaQbVn8o
aeOk+4aXsp2Bs8VvI1RxlyFjv7dTl9yjcG+F2/PUTVqQTt14ZtidjDgrCA6g3gVL+ixuC41Yyckt
gMhkWLeY/mXM/ks4JUPlzPFli1ECU7VGhgZvetfEMfJaSfWdcev/yV7XXQGX6QMeRWnpQDUSGHTx
xLsS2ynd9h9UtARLEcF2mnLmv2/GrmdN92HGAH8DR5G4+eR6e+5igPuqIbDZkImug41veQ3DMiT0
tCO19/SeNS9LC6aSZv3bPkaTBySvBVxIH7nJG4FmGOfDKDX7Eg2CJ6ZTfhAgqNOUZc6CGuTHmqv+
iU/e5UBRMC4O2ZqWnz7NH5jKdFd3s4dn30EtZbrt4UPRI2A4ECVKHlHqdmKzatCfpuYvPQKU0iiR
R0kEK2Hx4hCfS+y1u+89NzgfwQlLxXAtWr5nUCxhjkSoPXx/aqbkZVF6o89ZeiDHcEOjI39REl4k
N4+C9s/fSDHAah17KvmUvSrHbnp9WtQik3YRw32vioE9eSD6RahDRNjjNpP6Ru1Wi1tXXgm6qFRT
00apfylSt6CLd336e+rqCESw2kVi3ACdFt12PIcJmmkVg9GCLOAEl7jmIO24tu2oJTkwp0v2TEUF
r8NqYotC6hQUnjBIFfCwGAZAREnh83ZapImAWS3msDIffG/GmTgaHWU96jDO/OPqwXSZlaK05vij
V6Y4km8T7DolfoXHZknRjIGzX+lqVIyjg0+SJcKUcOkZktQ3o33QT9fkzj+dlaqJI8nmP/pBeA+8
R4AkxmIRVl+gLQzzF/VVvjY6Lsp0YS2mGqryDQOgisJGo1pza7XnjcGQeE11d+4qgjTUOr8TQgwx
9Z8PA1qT36NNPpEWoD1UpEk4iRRBEe9jS4NClqI2v5/Y5OIYZtbhBuym18sEmcGgCfFEqAXuw2xq
OPf+qF+N2eYxLoBli35YaST0yIaho9LLrCCQ+Mwpe2NRbbsOy75azt96NzD1cFB8fLxxk3HDvBeU
UDPs1Fa/PedfMGXEJJMPxYG8u25f2BwpSUmel+wx+2w7tOoD/d8hd8XnuL+cONtaM+VHsLTV/ZO/
M3wjgQPmWBmvOGfFZD7fmbyk4s7C2ROhLIYoGcHhDX6/u/bV/ywyxCC8wju4/kUBRTBKx9ZWoTi3
l9oqLD/pkzr/v77NSbQRWXdF0nXrqHIx0+czzMLbZvUWwT4/4hxHDgNaHBPMM1Z0Xfz9/UPKzVu2
o++CKWS2Nl9Su72ZfqVYiQWtO5RY4qCEbUlQGv0jWC0CVvZTU4BEbf+SGFp25iQpN/3byCpTC0gK
LsARxneBQY8wpK8m+2HIqX4/FQfOv11sXuxL6ImiPjddIN30UdzsGiFEJ1HeJ0B1e8+CxePC375P
7f1KBnGz3sg5WBZ43BHHli/1tJFQhLAfHxFjHcDTRLl/oYWRvcOASmy4LElnWp8MFLupZVOlrr7k
AMLKZl6Ek2a5i6qmjok9yZyx2JEprRTcTdeWLPUHEilipJFWEyGTiL4w30aab6+YqxK4lFIY+VRX
VfAqCoZWccUpW2AlEqHIplFeZIMVjHO3lrYAbXOhXmV7vqrYglp+oq2oxwyMr5GOA2N8epAm3lix
kkQvpRaLOxAUcfKPyD00JdMenznRfanDo+c6pvCzSnv38ok7iFX0kYPPZiHv8pUuqdeT8E3AuzcN
8IokFv2mpwQeaSKso7dI5qpi+UBSaUm6ldcgvr/CcycfEXrFH0ozkGl2bOzfMPKxV5XMQAz6Yx2o
