<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrBE7vfbV+JTS2EAkUPryIj058XveiE1LinRWz+YjU7pNeaJIWtAPAEzgBpjEyNhki+Yq+aH
LbbI0EqeU3F+E1aKnvG8zT/7muv6Do56Ouu/uDrCmH0J0qIdrmQi1RjyMM9VpH95thGhrLBLmZku
yF40oWd9MQ9SslTpVASubxohPDyN8D/v/23fSt6FXiU9d03IJYfIchzH0qmmPaGeFYQmX6Awj5QI
yz4zuxIryLRC957HHfV8jrGPEAGlr01ZXrFjawIuw5Uteh406+EjATiE/PEOR2z2+/9x3zY2zTOO
/XSJACzUStQPp2SaSw130EBAu1fYFr4JX7nbHvYW22TVgx15aFihNAYYYleAb69GvzGNjE+GrL8g
n+SoVRrjKq6HMGAjnh/DAk5B2Qgf/HA6VImXrMBgMvUVNqMKAw+c0LfuckWP+FOOtYipc9mSIHQY
9eEoHbNSblFevXu7kMEHN/g8xmGujvyPYqNS0hzg4YKe1v7aghhKLZFilCQmbpZK8FoEHd4O61Rt
eAeCx32m30WX6Ga/mt0Nh5Mkikn1BH8LhMEyPKSkFQ76kyzvMBa6+xM8VZaE0YPf8lre8Rm2FH/Q
yAkPwLiWh5NtYTsayZbVgyqkGLfSKSOFb4UCHLEHjTOgu8vPJ1D7/ykyWOkK81bOiIehL9jZdJiB
/DZQFrATC4kDFuTMy5Iax8i+FlNL0tMKcP5kxN0oXBdGyoA2fWpTW+Om/Etp0M+SZiWWzym/Oey6
Gg1r3bwou6KvPmn/qs0iYs02Sn4ediXeqz5kjTGcJ4jT3EorGELES8eXQsAcbbdgjLDcCI1s1F7v
nBXznpXW4M03cRxHtSNMpzAisRyiMRM9pVOZ+zo4CLygOF+gQDvovKgZzBgjXqNfBL5cEgHCV5rs
R6hxGPalAZ48WnyQXpubDXhlo9iiKage/ZXQ6Qweh5whL78rZCYPDLltidgxJ9CMwGO4S8GJRcEu
IzsAwKIbzZRaFLUokdOG/mWEARuzEVy678obxX514xaQ5T3RS9fomDBhkC4xiFDen+7ZNqgAOjvJ
L/hSbYRwpIPftM3Yh9++2rIUSYw5pj0ZDoKVw9e+gxtEXQy43lAFyHJU9czFKjmz+jfkLD09ROT9
4jJQ/iqVfzYobaVajjLxri4npyQR7b9g9mPkahAcVXIohuRmv8fqhRIsWapL3SR538W0B0GhAkLb
kiaOrHtORLR6DVP90MN4ZwgNDvTCSKoYNmfuhOaUAF8bBDJiz8Op/MyAuqitKf6zHA5CSF6wvJjP
NRvTXR7hVbcW2rE62f1/56IqJ9eXjvu3oiusjileEyus3w4YabJW5WXICQqf9kObqiEVExbb7/5z
weKfDAoI3ihf0b+KMnIwlLRcbsjFpa2GPDw4NYoFzCy+qc9ulyvw8wUYV+ArWDE7f27opYBynWWp
45wM7C7ssCurfkSgXwqnij7wvHZhq4pEb75uA20vxDiiNHC697x1vqYD81DbzvK3+IkwqCIgzrFe
HAymEPL9MAjFUdvpOya6lKYYzMZQp1hRuqFN4CMbX19fWbPfVzmbbKAn+OJppv4b7L6T6Ys/DcWs
rFj1lP7fu01EzziKK211uYb2o41YXv61p079TXnX1/h6ZLnVt1f87fo03vz4Jv3UYn4outO+Cuns
wGx2uSwAfuSR/mYLC0Q3qAyi/yZ0b5C7Wsgmnv87XemaWalCq5BneFEYFNB9O2OxjMjARceTwZzV
kBf5VXPZefcWsiMlcWs9sLDvum085aMBYc10OnQCKFwdXVXiAWInqA3ATVkZGgIiqwB4WhHrf4ad
Fs00YkbL/EC93cxXKSpP/4rQoSU9ww7pVy6ZR6QDbDzI5mwpOYdBoYMDXvanfpLlJzz4kBbaZKYA
uPDovapMu+sihX60ZO6H6kElGhN/hGflUcriHHfUjJCKvIaIQjXfbCoiAHDXq1IYecv9hUwIpKaH
HCz/4soXlGalMAsIOJPLz/Al16UMiXrqUmEK3wua4m7CXmOGleTm/khL/izHPdCqsYU5unDRCNeK
ro6Z0l2Z6pEdz3GX2veEFzvIMmJsVDD4bEStEGfLpKTU8r5gfCY2xZxqCvDjOChvPb+YHTv4R05k
twIPyME2VZ290ufzCJhxN58tIeMHoeJgqbkPAIiR3v9kb8VUjfoqGUAde+1SPN03TXG39qDtul9t
urvMcUSZ6F5k6NLhVwnQCiyh3KMfv4DRlDDibn12PDMeoWHbJ19xoixn4XEYKlP3cBzWPgA82zKb
jbqDPERlzg1WT3idiNthCZlgc5uKXEiRs+nqqO2hsCtbt5943P2ttnQDJ2nVRyYSKDBiUyRxY+QR
7faAgW48bcB6O2/HLsW20oOm3/c3Suwbua7nlsROs/nqx8Px/3N8KEGngcn+hjO7GoKQL9FGRSw+
QAPMeSHoGEio41EpZDLCchabc4IyuPIeFSYPpKt9A8BffpynJHMNiKWT1LoWfDd05TuJeG0TesdB
mQsa99YYUNN94H6elltb8SyI6erm0rtBSWEafnNNwwEerFuLPy7CADwT3OWcJdk+A+7waublJB02
Rl2AtbYP/EwcLug6eSxwj284hT4ROzMsr3zL/TXdIms3Ra/vpNGXTCez/qSpVW5pdi/rVQhzbUR8
yb7z1WzI4IhhNP+uPQn+ik2F+r8ZBQBeRmTJkwcUGcfFrb2I6N1ByGDZ2KI/E6o8Jyg9lrB8IOX7
unaajmvlJOhkWgZmpbLqwjITFen6PQYhJxo9hKUQKAXrS81epMVfIB5GmUw5sHmfuMj0dcqeqGZA
7gWZl517cOPV52fXwKcWiVxg1IalsgOI2xi7BEZ+f9pc3YKjayzDNEnhJs3zH5cGylUFhQcwsnD9
P2duR275Q800nnypMvBm6t7uKf32eE5Ly3jloNdnNQPODVNXbZgJjl4Y7c9BFGyZschgSsy/zc3Z
cgCdrnwrOUf66JEHhBUBeZdJUjERxqbQutjmsuWSJMs+y2S6RxcI492MkKVkPQBVJG3942A6BwQA
X/yH6pHpGHwItxKcJ3hNf95haSyq2VmvVfWBnv2t5HckAjAUBvF7u98q64nMD0FjhmE9OPPQNYmB
s1ITuR9zZr0i59sRjbV1+tHYro3xY+jyr3YGrcNh24o1dVNaTMY0ky2278y6tt3tdAqtzSsJxZMt
TrO8Yc6V7box4Gq68s63rl0lveMSML1guI1sRDWVTkKxaxz5f5XGJcFPTbYUa/X4c9G46coRY/g7
wWjI68P5NPrMW6WcCbQl0qgNDzgzeB33vfVppWqZ8MYr6B2+cTzaHEr/5ArZsOsu6ZD52KebPkWU
IQHA2K8sQrnLIFqe/8DTa7FRaoDgLmhULsEFLwA4xPaMeKcvrSfX2nMggcwHV3JIGWm1XEq72usX
a4pmJm53nZ7MAl+XyFE49cT+slZ7H8JOlxQhZd4Z5hqOQ4/8gKndWDNDVkNv21SOKP/6A2/RVj6w
O6VMIKn5lSgA5TpojuVPeAVKcUbSzRgkc4+SrUtKKQxf9TnEAeGxI59yxvrEdm5LjDeIlIDxze9k
aHxEwGu/jz6QPJhi0s5XjKvEIHg6SN09lSku89wNS16VwWQdy8hQHg8d5mtfQs9b+9wPdIuz5JW8
gnyrcoqVaADBdKkpmx48SgABpoOlFWJ8HwoJNrkcnuMR3x3NKmSO44trl2qiGP0woTGRA8Ue42/m
uZZtWhvR1Ne+i4llk+TjL06SeqMKxC4EblUaZ0+uYnBdKTAhNQLGMxpDO9lHfv2mj1M72aQxGLm/
d6L+62RqRQDjWFt+Ar9bmDxQ6eb07CDCOnxY3F/qXfReymc+iS1MAOKLcxaMWchJ7dBH+nurugm2
oiaNAWqJaoxShhHOohUaAaAGP7+XQmV3bGeM/WxuU8ZTEcNd+g+NS7jM137dwZRpNT2c2qPHkUN8
RMp/EU7zruZlUgl6kceAOzj7jBKWAiOcby8s5v2NfGRDXkK5E9qerNCBPnrziRdF5nrScAAXaxb7
wgDB19aMG6VGFv+6HUOQCRRyfKvDNk1TgZDoqTnfes7993s0w9k/dijI40YKHAJ8KCW0YVzNAjw7
Ajv7wy4oFnBeYoMVA541VtSRXmJFLRd8O+Nfu27T0DxzwY60DaiboKjKWnZ6bzuXur5531OzQSxe
WfFV1Pbu86Z/7puZ2fLsh+HBixa8FNZPbraiiYgtTm9E1aWLx6tftN6f4tSTXdhn+CnQknWeiP4I
xLm7l/q43mEJ7imxj8qI32szK8rI/aZf8rCMv7pZE7P6u26bcr9lLFt+P4buwzdYOGD1Z9T8qs30
ic6MbE7yFeoniszbUu9Jy3imvXJN5Zxib3Vbznx1DVOFKmvHDBMrC2hwhBTzH4yLl6LLvYrHjDiw
9gVPC1AMKN0bPfgkf1pq4GJ0A1jwqWdGV6eJ6i4TacGsJ4OCY271YgIgZ9L4hE7zFVDvMGeGb3Tf
9LkdqnEApt/G5d/TkT6yij/RdAvjX2IjKIOUoIqlB0qhqDLAMMvJhpBQbGG//ox9jBGuffRHdPqT
irbShHSuTDuj+BIjQzhxB4E+JPXp6rd5h18XgpdHBEIPNdiQPC/FWEbi/HSa8EWUsjWasl7Calww
pzUzH50o+aL31i3r3LInx02TwNqVNV1WdMDBBsKmZcvXKqFatp6qlO30+ch/HgSnUwU3HVAwaBFZ
5aEZj1ZGV1Y6PM0D+8orkZTrrTpH51p+YZaaaxAL7c23EeeRA/yNO36pNkyEQllGw5M0+qS+gdHw
4ljqoqeAIq6TZMGBfxkvydae5P6xD5qkKcZ+g39jWl7e0X6RVuXZqm2UBbRhZXvxb9KP75xa9EOC
1nNHJ5ZNjO5zlYoIxz42oYZX8u3DfeCaS2URDY2Y4+7FrYeWuukPTHFfKB7uGQIU66sE3MYiG2Tu
SyDqsGrJLKehnsm/vQBxzDFQIqZdC2aMm4EDp6NCTe140PrYRXQx0gjHa/pI1uXqlBs8FqmJMSQM
mdYQWhocEboNEvnwDsXdrAQ8TFI+o96VXMcG8f5iqILivy67rH7LfpRP1Cl6vq7tb0r5wvEyAMuw
wBXuCcOI7m1U1BnaI9yNujUeT5UfoqzF1+6L3oJC32GnXQWrNDdRf/nrqjckZ2zYAMoLPWdhg3u4
WW3tGPu62taJNxzAVvkwv+R+3KF3xHfucX6lI1rwOo8s6za8hCi+Yrth88UHT6LmiVhEgSER8vnW
T8fXrX3a7dcQrmb3IjUhyYvL/FZia05jiGOX1QXX/y38aDXuKo9fdHufurl3rVw9S8+Xaq662AL5
tC8xtbc9DS5j6vBCGsG8YvLGW2ROlecfcz5VmOgyStbhqy83wiUgdY6w9Tpb6aVBSXCBP4iZ86Jh
o+LQbsdyj5wbQrnQkzTahXZ9G8YyRNL486waLOHxOXbR8IfrOwMaDF1BK4FPbs1/CI6bbS8YVE1r
lRzwAY2dD9v9418Tdntz85Kruim82iryEZQoJvDSPtw972t4/Xcci8MkNbqqnHbFDXbqzZQhmZx8
pWYRLE73EyyPFTGH65yI1gbf5sPRJjISN6FH8+8Xznae1HW2DHdzsgjlnfGfftbxyjIowFa6NWY1
3AS1Hre8QfqPTj66hCAntS4Lig+KBVTu/rtw+SFswX+CXAmKxDmQf/RhKKQO3+crcF/4I0Vx2lAi
Kn5r3cLR/RepfxiNsiS0trrj62U8009rFTN9+EKb//xgnOImng1FxyZBFaXVQ6ovFWRHK12FxM74
fi2lnurIYGTQdwrirh5KmxwpGaXsd6uFyD6jbNDSkOAJV8C3ftllX1BNUGQRQunMkTPr7nTl98M5
mLqahXBfTpymLP0Ia+IGTQMmrPNmFNyXymPXrqyxWfYeAZPVyacGms15l3zKSwq+DJzreyqt37DY
sB092+bsn56HKVYkCVrwNHyVRZEMe2SfJYO4FZJO31HhOmWVtoAGTIYfsnRatIUI4kGWquvF/AAj
2p6fFb1ma/WZqvKEFv9sWkDC6OiuJkJTbR6hEjM7se4UILDcWSIqaL3UUhi0n+dR/RrTPuYbseGK
VnPSc/maQkOEZygpj+sBC82N8T5GMKCfbL0S8ck/3czLXjogzu+JuQhH0Z8BnobZ1WDJD9d++ljF
rz/C7uABsO4+4wLyliEZBNuCcm0LG4eavA2105ABzFUV0ZU8NiP3HJyR1NQkwbQWplJ5UsrtjEtk
B7FKbONIiDpM3Kwxd/KS9iAhfRLZJ9/rm0+hg2pA6vNsjE4avtidSiaR77Pmi/WxAFDqbFBJdELD
2ySEBuM3SLIV8E33ZTf9LLSvMK3R2b53VU3+qXSnek591ChsPNBEDu5xP1wKOfZu2weWn1KLcsQj
YV/UnQEAiLKQxhCAjhyJ12xtIinaOKT1o04QnUDFrrgxZ8D6ALdDFS6QXwA9G7rQ7ur6IrXfdZac
mCVzejwg4o0di8MA0kR+vei0vgNPNjwpN5+dIqLWtkrEjuPrcPXgfqONoAxLd2vBTYafs3/E8QYD
3rawcCbiqROII2YVoTc5arsmH0FFwlSe0F+OeptnnBosp1zprfV0SaxZQ8mjCDRiMC7VGYAclVwr
MWIZo5xt4aH86qZJQwDB1ZY0DuuJGIH/0cdqC5q73prygFxD52Bz9G4/YecbjtrwEDw877XFBied
fFX2oGH7bXBuH8bOHShidFvWoYQheAxFgKDXqWOkgYBQRhA1YFNfTm4xeuNgIv1TOzXRIIDjAPJL
dUGA08FsNWtsjaHyTOjZv97Wap6PPqEYxTQ7oBcGrlx147lcugFjMdGbwp+rLySA16MoCbYKgEl6
UGeAUwnCpAnX1Rj3tyV4TC1XkGA7F/tKrlhI/4uQyextuQAEYoSpAiAXgEtTDjIjS53jBUTq4w+0
WrLhGY9PfCiDaeYNcu1e4kYKS6VhnFtT2lPl+lVnEaf/pmOqLLhz13gUh/HG+Jczepr4yEHrneyH
hnn631krdc0NUFRzPkyMr5TUosY9oZZk+LFKRv+LWgpWzXwfWtc/2Lya+vNcAiek5Y3q2FOU9Rvf
8H0q2eIM+R0dXNvGxFcbKQ8zWi6wC59ywljOz3eSNv3xkBqxAgcEswl0XHb09ef+KxI9ULlK7C4l
BqT1EKpFFy6zhBjm170uNq7/dXzc/NNjvyiJfBfneiuVJWRDGwUkkFlnjFOCKTjKYRSCrx83bn+i
dEhuO15ZOraVqxVoYrr/NCaGy15bcwwZRfl2jY90A8PyhJRusxyaOVgx9PPsCZL3xkJGlnZjnh9t
7M6TykqNa/JnwYLQdfz4eugWW/gpyeVB8enVpMaTLuXDA9JlPe9VLnS5WDODCe4xedoDvjQ8CAgK
JBGwZcjHmPVrUQP6AcVIlSpoWEFGwuxOTb6aVw/qcd9Z0VUOIbscfm5udoGvbW3wpjei3Q5qJPZ6
1/XHx9gmyrRf4MsAxwy+pPkFCnKUMHK+GbXV92Pk+m2b/OWBWHhDujZIVwoPGjwzRnhxGzESp5D2
YH2+LR/7RqKJ38e7sXhxA/WjxtAqwJRX+PlUKUw0Kh9ytLYNHDMWtJbVTYnAnDxSikhFJbnBKt5Z
INN3Nfc0OJRWpfnJMnFSeOYfBOhh/dkA47dH457TBru/zBpGDwFzlW53EQkANwJgo7v+Lh05lVuk
GuNC4f+1w7x8FZlaslh2+j+i8yHQoOcusodZFP4f55EbfmbH76PySvaPirOKCBbGgesJCgaKnnD1
6vxxW91SRSmFAV2CiPASIEe33/GsAOtc3nYS79d6ieB3YvOUU93TJZhr4ouYe72QS6KfSux8y6hP
xCYMReyQ+3jYMhthvrqd1ZKryLczGvrSYgUxazSlDNPKMrf00yk6uOxNxDORMjaX65Fo0ZeNOW3l
Zco7T0D+iP5b7Pe5oGeqbJM6pjFT58ukK+waS4paWA1aq6B04G1CPI6yIl7I4V46W+BSwdHpsT3k
Ko6eVLqtWY1208DfbKRc8T8+XNdYnVleMeh8U9z6gRFYRDJ1ONydqffVIxn/9JN6jpFg9XlYBfy7
QAdiBF5LuG3mnoVzFvpGae3e/hSYGwE6FfFTZ25qHILucYQeKnV1eDDjPWU+A7xs8bzikLYI4LSO
pseCTy/9ElcHYYpB+4aS6B6ikc7JELJBkKfmeQYILC4AUpW9hcPk1tMVkvIN55CqbWUZETy1b/Hy
GGdqdwr6ou5kPBGEA4j+sZMunemqY+I8Rz8aiqnQabfBMK2gf5W90JwCdGaxfkwl6EKw4yxXsG+t
b7+SkRArJSRHXvEyEwrylW4GmzMTilOaCgi5+xAJER6zOBlagVO4