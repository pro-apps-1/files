<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqZTPv1wQ5pO0pRoir7lvZk9NVhgSEAgGAou5XKnvz0x+PfBfJ2a4FQF4NAw2rD2DZPPQCTN
EWIs4BzNPBBbKAdVdQJU0x/qkVXjcyl7nKFZjLgk/CGoj3G5ctcYT8NNzwrSK+yH2yBKDZMI++9/
xkzJXvGhk8LsFPy247uap7X0B/SGqWgbVTx9mK7fqxtYNVw0IwJeaBSPC13wQtH358RWQkELJDSd
boo1v91EMR+ut4kKVQV0qzp9QCLfZe/KRjVwuTwEsDRsN/vT7QbbsKtlWLrpVVI4C+ghRY7OBFdO
qzKRMnunvqUdpa4f2eFQGQrt9hdKHO25Kr9oN4nwk6c6+M7h9O9bmcyNDarKWfSiTTZXQ2vRCDbh
JLq5cz54xK5/eEmWGkw2W6005NaGNPSUe4hi7qBMe+aBVe1MBXwRfocZ1dTS44j/5nGFGA61fGBM
A6CNZrTYtAsGYKz2ufUmY+3EeixtY+FDvHcm2WK0ZHPqBS5tEoCRdeti3qxvI3ajupCzHJYdVz2n
npGDDmMPyoFe1TF28WmUJG3MADLzpPX7zhC8tLpiDlj8gQKFYJwykcXzl3Hx8tEfE/Jrk+rn1B0q
pTBqDiu5J/GtqNPFXKtjY+Qx8XUA3bRqHVaYppAemcr6YttR5C0sXLHhK21Y6h7bI50OrnGpNPOD
UmX7dPxxxaFnYAF52d33CySESwMCbx/mB0WmMNJFWeHxRzAkKPLOKta2SsObx6UQcC2lrpSqRbDb
FLvqWZ6sSLQZdtPhbo0zhXiEzINhAh0pcR/k52uQy0bMQzrffL8QxFej5kgtE/2SyN9wt+4B9Z1x
ITOECl9KI/uXXkAKZ8ZFbmCG4ASdf4WB4oSfCBDQaPM99PR5WOk0NO2O8segbLb0GFobZjR8G0nh
NqcfjRyuTbNqJvUU8oKWeVOwqre8TLGDr9TbdLLK8/oTi1TNj+1+1gZXjNckFp3HEicgswEX27z/
A5HgW71tV/OmIVyZDVUVtzAgqlXhkiUZlRpyDwSrN2rTKBRzNPt+1lzFkk4+wG2EurAWivsdMKb7
mUBPwZYl348/KMUDnW29OCZbFd2b1EPu6wKvDNO7x/3i6vyJo72vXTrMaY6mNPezQuG2OpLNP/iI
JPeYecIaO5QY7qt58bIjE+IOIIKp6WH8CWReQP7n7unKZscU1D67GuXE34D3PZwsuekY0tikJgW/
U22lwyYS0ytic241xxCw9ExICEVQel/fTshH+wvG7dVP5L4hxZMa2lgz/WfjVZOZQGaV1ip4IAaH
DAWul9puHOIPSwexqa5pKzPTTKZPumYEENxO5PvueHIeogt1ROqGYovPy0bZ+mj7T45SgZsfKEz+
kfVewZHeX0wvFx6Ni90kipI5eW51+o5NgkedjI6A81KF3r+g0nsOlkwEExgyKNMf08GPgEE9Q02W
MCVn+pHEQtb/FpBu8wHGHgcO0ejf0aRaR9HVx15Ve7yLzATvCvPf8ifsNXFcE9mL/Z/jFmY8w/wJ
vf0uwYy275sGAoG8zf8P1N6HneM4MqDgnUgfDG7bdOgsnAiraUW8Ko3PdYGZEbiKW316WAcpD4Kr
T0t0cT7ALRo06dOptL7agHoy5POdHe5mYWkZmhhG6Z3SRrHAREiuSnaKh2zgiSR0eXslZDwNZNiT
bhG0RYpXCgE0Dhu8JohaRb+R8e8l41K6H2fJ1immEm5U2+ozYiyK9HfSO33MPDtDLr+czayYDhdu
jUTwZXelovh5cu6OivzeHrxQUdcIhRtcGAQKyDBZ6WEUnZGD9YGXpTxqNoLXf6qQowSPScIb5Utk
Q2QZZVkqVhlSvgMl9U+JjLch6fA7Gn9nSKwBBjRsTIe1KCpayOWkwAa4HbEGJMEk1FRxXxuLE7kQ
ss2VaqLZSaylaejddCc54/YTGdXbT/XAXJRIhNmzWKPeeMx5WKNy0strE8SKwKXcVU2Bk9E1HclD
Th7hkcjvScAu0/7OBGOBbQKdT41U9+mb0pjSQHsUCR4KX4bh7ht2creBxOAR9hzfLlzvtN7A1CnB
bJDW9Jwyd5oPbTZQaD+Dx2TkpCWtZzf5k0hqW70ju4K8OC07USyiiGMSA+bdz0gJ9upY34jegk6G
huM1skNLLaMiDdG2W1uoG0xyaHtAex+DkMRNXykhD6LQX7X5Sun4V0sO6g58IQgM0Ziw8Pz6McMU
zNVbumaJAg6qtidrtxcHW8KXD2My2xTjIEfHA/LQ2KH57UrhXiV0ApKBTB65R7WPiQWQ589XKv9A
ulupijEzEbr3aehYW6sbmrILp8n/D655vjAqSeGSdIalgPiVcE1xOxGcKxdaajuuBnXbpV2MbBsV
7/GtlGwBAMxssbd4ufjX9kxF3IuO/vnNS4XYE3Tkea0pDpu0L/0TP5/OCp5Nw/UeojAq1+pm9kYL
tQ5VdeIvS+9B9A62fbZNQ0VZYf43I9rk96QO5dDhwX4/NmV8UiWU56XP4jH4E6L3gHho2VKPvS/p
Cq2scWhBW0Lfj296M3z8uWIF9BW+FbmccJO7HREzWaQ6ZVHZUs5hbE8j82C+Mmqwvu+toN3CIzc5
y8zyIlD2qm8derK+hcZrRZPe83DeGXQgALXCbrZuK5vfxemgZg9ooTG2pxSxl7DoV/I8UlYT6jc8
hUe8+TbeQKGOryqc7gMWY3xe69CtV7TvwDfrlJHTnVzx4tNYN7TC3fQ0TVb5CokyCKAmv56hJ9xU
V4DTtC2WJrhOxHubZeUACamdyBxI2q4pd3AYONcmRyzT2H3TyBcGRyrnvVYG6F4h3/7dcOq1qeO9
lqmLS0ahzxahWixezUbGPJPLC+z9sCCxJnj/tafUVCq7o9wijfH/aJEC1wBrggBZkp+gARjo5yIa
w4aFPyVe2Yu89cDSEDAZFLbn97348c+KE1zej1rkd855g52yyuulzK/tZ4sGV8XzcqvyocVlbOQ2
am5EAMGMIUl/2ylPBftJnkcJUh2Fb6efeTbu/v6bWIai/FmnE/bMMe25+T/lbEQ1GuELBQPjE6Dh
AIRr87FaSCzdbiZqCEwbucGxSjMgdZtzVWdXLqJlmp5nqmIU8m0x4Y4GE2c+f+8SEwS81dmqk9HE
/4qKuXHF9nkGFr2HIYEfCS1XxUL9sI1I6hGNiQaAWxV6GK3F8MLbAXiP0I+PxmQuA6uhACGBoSqP
xzga8UiTXW7l5xY20Cal/e37zlS6ThDdB4UAfUSg4wO0N9LUE9mIQpUimFbFH3jaJ8FwUhdOIvUM
fM66aa8pcagVpKKeSOdQdvmerq7EHivJ1KSFWY1cKkscwnuuKIWPPyJKB+m/zdMX05cDCskm6hoq
8GeRDKoa2sl8IXBtxoeYnTjb2hnVrGXh46H5zsaXwnaq65cNqgDYYY5NPWnin8KgUIWl7zjJeszU
9vImW0l/f4IDivnZ00cZBEsnDmdqdEjLy7DoFUFYInx4hmg7TtVLQHVqSA+Z9VF/Sh8dY06mWCG9
l6emrAQILfwtHDP5TthqqVqrU6ErxOnsI4KZCM7TvVd4K02k/rhinUlhjmY7EmUMDUyBzebKLXMT
/01XbeuRB/fuWK0d+qnLDkZIEigJCX0QAofsh1G64vmvqfOzII8LE4aaZ0MorYZIETDyc7K4vbEt
T2clxsyZPYUGp0ZbQciCtXLwNQbUq1MwPJYTehGuBIAMgQbrlKcXLRyOs1uPKJBlw4ZMCN2jCv0E
Q1RRPfks8z/07cyU6Avcz+PP2m9CScqmhGOx6l1Jkf4TGF+jmOskydMX4fnq5TTAwRz5RBKsvUWI
h6D/BeAHl9SLAU2GOi0CjmIOxuAOtowFMXQlZVguE3B/oRqAoMwyXF8VE1u9mUvqNduWqNCMHKJV
EEL6azj6tHEpjOpd33PgpGqviORPXd/+Uy9IgkxNTjQcXKmFP81gb8F0HUwPj+D2LO0Mu+8m2etP
s7PmPd3pmvuLQbYJ7XnbiurnYkisa4OgblWSduqDqThRWDdvjUK6y2totPUyVXTn/s/k5HCSbPwH
slMV7lYZU6dROxGdYVpzukPznHKNr3b9Z5af5PkKPDVvw4y1kgDxOLTHThH8pBYpA6Wik/P3bSV9
4OVA2qXHV0tgwSdCUMT3hdJdlvQ52s+LPXXvE2c+b66RW8YyaKBxliFt2N6wRMqC+iCN+PsbEhCG
5nUUYifcl8vN50w+uvO5gC7kbWwnG92Zgw0iZwoSaO1ckxzI+TCjP44wtaWfWMFMX4J5hlu4Cjj5
lbAUYhX7s7jXz8XTgjKnw9YHdbXamgQsWaLtXor7wFRhQS2IyeYFWrBq8OqVYVgM4wSWB8MygGjP
hLKrT4didq/7RE5MPdutn/d/xe+GIu28kMxEep8bYtyTCtSToU7QYuWujbGZlIyQ5vjmB/bJmAW/
RhGKkQrSgPYHIXtZtcpjuDR5ztgoAo8icVnhy4rp7QCXAvLuErZ7xbx/NZ/gly338JLHVV1Fl2JZ
oPUwvvLGEIP8BOPdGvfwK4GTlZGVvgVX2+/4QAgI51BhQimOEyYrHtUXdUBfjGUJX43uKqWIrqWB
YA8tS6nXSNGwmsqfGugJTsoK9WzhgINjCjISppF3DOEZWHWdVfmzewPFaAC7WxdRhXLoP01gYhmU
7revK4BjFtRYbOU/IBEbah3dlgZI7Ach3lAFJS4FvGYH6e91sVLOnU1YKVna0a9mzzC4PYZEKT0I
AOWdrNzQ+kTjYIlQlPNuNWqJVCg8+9xNXVWv0qSxQ81gLkSMPZ2gZ51vheuRAgrlPi4/lVoEttdb
sHxaPgpC9DuNBDNMGFyqR0eHk9UJtmB/C9MCFZVwnFcJEB9TXQSQQQkKJ7PxUbAGWpAI2irznM47
fafi8xH8wuZfQ1P12VfGwUMPQp5hDw/6JMx8fvLwxg63Kmz8Phkn6CzWbaynCJF6Rdbc0VUyUZH1
v248TT8blI3EKPvT153k7Rp7VUSOHnrfoxtseyLSZg1TLP3OiHaU2I517TvK4oBCcMevjiqj77Zu
kBifTnTeKnd52U6MiDtRaEfQwFf8Fav0OydsA+Risb+Vns0Ej500f9D19VBVmEnYpUs3ehmoOLbv
AzOKscoIk6pMGvQX9+nRLA9iin2I53B9hLgihpssHYh8qbsQYE6waZ48WRvcNn4iSnbItYdjZlPD
MurokGz+nLNipYVA/H0sNCNtMhYUsL9Xi604MEUGuURLE1aP9K8zq0ZzVUz1BpzzBccsaMJL051X
1fgMb5fkh9xTewC6QzFve9Hm6D+Sf4pwW6ynvcWRr7bGmRQ6GVT71DtD0PaiMCUaY0Quis/B42RX
PeYF4sQd5QABjhwxNIJYAerbhMbr9GGLOD3SeUlpp7T+bl+xAh1H59EzduH7WN2Lslj3Nk12+d0h
k6EW0XaPFf0fe9wR3VpbWqsR1CAnpQvuX7T8OL20uAXVCCgXM8ZE3vC4iuzz4RlSwMIJFMOMK5ld
3fj8X0nFLrgSj/Cwc2lq+Ge6NoXp9km9UrzutddtAcAoV1BJ+3Gt5qza6Wb7EA/GgwJs4zL8f6jV
5EZ0Qb4DwqB5qJzoeFaMA8vF/bd2GnES1wtMLbpb9jf92Bg1ovOgB1Zma7ysrjzPDPSaoY+q75O0
NpMuqiOexGXGCnuo/viIfJ1M8i3Kj8XtTOiATmleS8LuQq6w2cd4c76mvSg0ifNnZjvWo/hcOXvt
8Lbl1mUsVsnhcmNgd8ss7gb1CjtDyQZVdk8OZxuc1mgz0ofmdP6lU6JMVQoVvSSSC6/WjAgHMM43
wyD03ZI/xQy77eDTAI1W5V2mM1nHdG/DNBUsfa6sAxPKKPy/NZQx8fMD2R/IG7DoN4OU7/+JOSNg
BYRDZS9tyF8pjUzOwKjoJK/QXeKob7SfpYSbCc5Tqorz5gG9bsBegfxsw+1nxjePt4GOlffFBzHP
ie0G/OfAWbmaS8IPN+ZY8Y3ZWEv5WjTL9iH6ARXzzpwy04QH7BsA7qm/fqJN9NQtcgXjW5KbXg1+
4t4F6nO64E58b1OZgx/tLI7fePzLx28H8fcgSlobNboZo+J6eeREPThd3/MuRwLXH32thcBVQZeg
seVog1hYNOXeAUb4voT0WelupiE9Z3+/oVfVvj9/W9zq4zjpC8PfuJkldEeJazhpPaOZU3Bp/TtD
xkMhNwwPl6vRhm5XSJ/WeB5jVfc5fG9C/zvSRkP4wmds0E9EBP/y9rqFJXXpulp0zrF1kMhfgPZf
RQbK1kKkx5YkBZ5cLzwnTgPZJufkR0601Jx+CRaiUMxxa8+EasY3/CheK+zdNqHqCe0m++4Sfc/d
LT6Y1ZJH/SlL18vxfMQWnbnFCioKpcOwzlIluU/tQGUfOP9b/FBGNuHK7a+srnYsf+xoXzYjRttt
ERKXmsr4t5LGZ57ALTbQi/U+ybQxhPv2XTjWjWJJEzDy8hrZuRuCOJ6Ocq420JD8JWOsbYvcDnV4
ekH5XtDfRoDMWIsACkkj0skOweXvXcjMEIpAOy/xLYvaJlsb1bKEEfon0V7cbSIAXEkeX3tnqizK
PDczis8P6OF41dg8JOjmiksVZx243L50R7NYKEgYgPcAUmMCVbs/FW38WumkL3sA0l2WstI3uM5Q
sWqNGmi/sunH7Q22fFxzvqZDSxZ1Oi5KtoMM/dhlebKBomBciqjuHYiGLEbzyKXn9nMzyuNd7yx9
Hw2+qBmBf3iIh7n9Nkctz4GE+V5yEX6VOyvap7D6BBRwbnDvSy4eDGkTpoR5AbaHqWLPtI/F8A7c
xtwkPJ/1uOumtBStfymcbRbTE9ozRkwCAP4q+OR+7F9s7Ru6C045pOOIYebTI011YgI7WgworfVW
+5PLAeAZ2LByIvq26Ws5ECZdrx4FYrzTHOQnIV+YCOk1HMnIH9PjC95A3iunNkQcibxxYCyWG2/Y
WmJYXhGqTQxIZ5FOSlITx1Mlz7APGxfuvEDGVPfPKZXYBCuvolLTFRSR/PQwNQn8yUfvkJU2gHYS
xetSTQwoeko4Xt7BgtqeKqEsTxt/L1IiCmsPxkMMNazatR0HacAcVGzT0/AXYOIABgghKzXC8ZAO
0Pf0uuyY8wbt9MWZcZ2wdFU2n+GcDUQGA5LMyDLwHtHggjLDShss9XNbQauJq3QbuOkOmeXx3EDw
qUAJV8yCPsHlSIxBPGnTqRmzIzDG9eGmxvlEk8vu4j/JX9LKBuRo+lg3p64/fB3g8d0Uq/l2dMXv
AsqCTGzYS7Ar2U8mB94oTfVw6K9f4zwgY6tScwGHHVFufwe6CEnEJinim6EPFICQ1RnHvaerANec
jj5hHArhYXWYCICBtSsaXrZ3UpsuaUSwA+p+/j8Kkt9BdbgVuifMKVbQz6j3f0e1lVu+CBPzHIQJ
kxvJkHBkefQ8gnDiL9w01EbWRBXW9kvmC4m8ZPp+7ActlMLprwlme2uDSnuVTMDWcFbqhP95L+mC
CK4w6w1qHl/Uc4UOyyh4eYcunvnQzTPDsvXCsvnQKr6f4mLLujfUQaF7wA0VCyaRiSoHVYw0RDFc
/MkMtJlt4k4+YbcWrif2/Mtt8J2nUWi7o+Y+XhoxmCyx65IJGtjoEkohD6TWnXAJXDto2xIe849r
hDXPkm86/79goWUlLSoXj8B2zbGFeVkf3rVMC5voxa/um5DLDTkPYP/ybJ/OsXN/eg2EGPdTTQe1
VmunhPvC32qDKJOGGuVtbcd4QDSejgLc79fGRsA1dVROO8VpMiuzU6ThXv/2xQbQwfT0RzPmWMNW
civrRmDJ7b+AETNob2nf5/gWX89YqPMkgH7TVRgXNu8ifDBiewIHYJbzKux3aM7N/vJppsxzdx+o
bqddWNgQi0Xjal0uVFK+Dv1//dICVqnBJMCr22aoCmW0f/D4jFKuAv05PJ+Vp+8GgMlQz4eqV7J1
OyTbyOAM3xChI3F4TNBMcyHq2nyB7bTG+rukC/8tnU8arb1e3h+78Mc3m4nAaOJuL+K+vifQugyF
EYj6mf4RdbrDUi6OthTuJ0D4qXzKzEcV7j4ZYrt2LzNRyiHgRZOfN79RY9LKu3XtnD8GqMERx6aR
5NU5elYCnk+vq+nlEE2Ln2oC5yJapGpYh52TNe7txvVQ9k/3iURpFxzYyIV2U6hPHgDXn1das7DL
ocr13RmvMohVQX0YMTFq6vMRdQXjxUvhAGgkriICeTyTXPbu0YXmsmiPQANek9B1eIx3MnAHTcux
OdIQvmWpeZ9a+0/6hdurnkQd4qNOdWY2yINic5WQoa3lijS0C2sA80yQwKa5gBfIvZE0QQF2LY7t
OY34nLKC+zEu+WKBnB0xyq+RLV6n/q/0E6w68b0On+3mbgiWQCOet7pwBgd/YUi4pSrPPFZ3rnwd
OPyEPV+jlibxcjKl6QRcUEJF6t3XqMpn7Dsx/Sz6ltbJa0qWPe/CQeRQ22tysAKLfj+HDWRryNTI
gQVS4UdX50MLwOsUW4BFBHQU8slMHd3ysyaq5PJWIU4Llsz0oPRteS8Me8L4V1Y8crBJvShano+s
ctU+3HnZP5xK2ifmFu2S728VyV/0bN0RzCSjz5CKvSRgB8IeHvd7fYz+qsjf2U7Y4e8UD1sVybBf
utf16/piPxDxgk6G92pqBQpIAKPy8Wp3/XvB9z3le7QFVPonFdaLgHy5fsdneGBkk9PGibOazwcr
fb1L0WIn/PqZ5sXbrAUk9BTqxiEcd3ShqK21idCN+VIEFkuoEli9WperS7i9ddj1QF30DUGqlDzu
Aoe0mSCnKElPoQzDgXWgP/XH4x4VyPRxEH267RnS7A+B3kuEl3fV+8SU45LmhXZQepMpiMMnZRl7
PWNc9ynKXU2YKcgbuPOnbNJzSt4vV4oSqGGPdRG/QyZkF+6KBuz7WN83IeOVDy0Rr0BgN6SnG3ML
T7GN9dhfINLlL6BQggXyBh/bJGo9eWwJZn2TYLFvl/TMm0qp8hK8LYPndFPEHi/NjORQRYA7S0Je
mxg+0lzibAV/TvGbYCHOwUEjpAo6Cle11FsJNvKHUjgSliIH3Bw4pCnyxEeQ1+HnaD2evAA0UPmZ
kAOzSg81zxGj9wCxwvmGNwUF6ibTtuIpN0P3KeltJ+wivVX+SOYtvswzGZiD48qk5uOApIY2EpUU
4HAKybAPNuSFQ83idtHOO4jqBQPZw2k8V5ItmQ6HDul6sS1Nb8drSvWjP4fJCMLXIUNJuRMl5wty
+oT5PBOH1VcnU5m6gh+Ibr4CkQIVZCcEpS2qUGRF4zJ2ZKWIdKxOvolACNzqlGtCf2kn9QtMcx+k
TX6tnnLYO3Dfp1dT9z1F6KlqCABMAZK8iJ7TKIc2JG52/oSb0BD1YEYKOXv+/TqXK5OYXbn9RlJr
sqvZdBb/ozPWV85wECJS7yZZ9K9E6l3S2a95uritcKxN7z5S+MVVMzKGVtdXkJtcr6mUARU/qe2h
d/DA+CvoOKbkJX9XRd41hPAfvlYP3QmbZLf/d2hfc+PVW/XrJJ2qJs+BU2NiNmvdNG272Kianypr
SAJbeNMAqF11zAdDfK0zzMPRgx3YuT/AvMnlwEo9q/i+wkXsgknCWz7GEykVjb1BowpzmkzTAFHG
q5vM5xsw65stFnBBL+U7BB27s1cocGfZuAA8Lo3bc//repLEyjhXN4QUOtz+EdmLew+g8YTguGMw
CNE1wss3LhwyWfp6HkSMBKJhC90NA0+jwCbB05D1ZWkTMoL/fdB2USKQp6onHttisfXSj5O8wEVK
qiLMUZb7yr+KFXV8h1iPo5mTsSgxLr9OOuWaRqDDRiBP3KVBzxX6fnqZAVn53ihgmau2a3dXj64N
aSgNDTeTvaWfwiXSy334t0kNp3BYBq+D8WfEEU2Sx1Upb3EpL11LEG098kRoOpQnthfx9+tF3jc+
cjsCr7wJg+JHQ3GzLAAI5J/mZYyzrB9vOWxDGIef25l8+uNwTSvBVPbWi/qghte1YYzDBB0AYYLa
+tDH13lO3i4/1k0DMfK8SR9cW0rYr0UZUHEQ7xvLRWtbrQ2bQMKT38VdmTfkFzJZoqKfea4G6+5m
rv9oBHR9r6XOp72qoRVfNJr+7QWdriHGClADWdpEHolGOpDL7v0EzrIxh6d5tQj2yEPjTnImrtz+
ZgSeN6CfmZzKvayaKTb+dLpBJi9xLmTrb/kg7c8DV7T3ihizvnx5qq5V69zgiiBDVbPsXOWx8QZp
/YTHjB6CjZ0LlgQMrBi7C/pwDR/TRf//p2VTUNPQaAqG23Xhpxi83ne0jrHYQIi=