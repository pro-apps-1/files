<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvIGfdrLynfo89ypNWgIEB9yT0HsCS3hcV5gO1HqyF9v4fxhoB+c7cMOia40Vwk1rTUCSv7S
E3FceB67JTG9bzYJtIEKBqapV8AhtNV6khb9Hxo72KXmI/6RZx+TOylJnQ6iCSEyaSfbLgpBYVq6
WpxL9miniNQ7OfkFWN/mEuJLh7SMxRnDKiHmddw43oXO/AkfJEdxTpSMS38mAeCPlaGv35PvRZiN
xUySCaeWZoukw7wdT9Ykxb3chTRFbeVyaL9R0Ndcw3OBYl06iL2goSIbkbbjQuk6UHbl/EKnDO6S
guTzRY5yyRL81acPFl+CUzzw0jxevr3bC8+zSqTv5j6rLNNqcssEA7/PZbrgtu3caH6hWYFK695Y
Hf4ZR1vyilT161SZYVmWGTIvOQ1WO1mPnocO3XjUoCsHEEfzmqPV8xKY7P0wjV+QePmn/4J8LHIa
MLXSw8ZNnR5OGRJ+rQ6VMf5IUp7e5hOqw7J3cWFD9Pbrnau4umkiLt02H6EfMwQ8a0OI334EsQLP
mfmqN0CaUMx+TEvr4z01EPJzKi52hM7TlgGATt/ErlN3JktV3LZx6KFnb0RfuYE2YbTsjIPrU5Va
0zJ/rOAE6Z+mB3NWSC1Tq5bHJwrEQ7mSHK0IJ/dfL9zLGGC5v08pKcj5o5LGv9u84glCInSM5EK8
MiPYYBKgg1G+gQG9MnNRRKrF5l1bx1iAzgJ1+O04XuVIG/oU5bxrh6xvah7qqxaxUQ+i8Af1VlUJ
4yKU+5cbYu6J5Xw4s0ArIpuC41J+4sanXj1XBdx26TwVGMp/Y8gvMS4MURxL41EOlmE7CQqYhX95
O5wDyo8eTiCQTjy3FnXkgdzu1qAGA4y1wF01whlNnm1jyT4DTO6IRuZEt8MVddr6ItQLbCXyM7aa
x+x0QfwD7/xvTgw40rDRnuuzrPly+LXg8FQw9TGjdgKT9zxyKVSYUwvXrl8funng1I8mM377qRc5
IV0GsYoBmmH9C4UIud+nc2clk1sDaysSDK9ECROS5FtNGvBsY9uKzO7U5sIgx3O1Zmg6BQRm1wP8
YDt6gZxkIWgIw1efcL7XH5WvosbZFRcMbiLyqqC0cP3JEv1KiMmCYv4Ugpsd26Rk3ikybO2aU+ZE
CqJqt+HxdlyLwpyLntbtTkcTxYYLzoNfpIcN2TqsQrO5ttGOh2UBke7oqDepUzFuYq3vhAMhU9N/
vhxH0Nvep1rzK/zF0Y3prce14gvUSuc9EKywX7+e9d+a1/uERDRIZlH/G5s52WNgXvHSkS34rMio
AWypYKrxDddd3OTV+q34BR7ymaIUead3R4KIzfLGyVe3X3C03dYSHImuTL8j3mpzLlzcfRJTctsf
SNMr9D0lwrogKGoeNNmRYQZGugjMyhXsYgiTPnNBV2c+64R0Z2JzYeSfB6TDy0CEcTF53WcugqX5
ki9UkUAYNxZWo4k3e+UTZ9u9vaG9frj95U32iCBmJC2YygY9p1IqlEdv1Cq6wmeaPQyC42PSfJkZ
cQsJGuTsOyxGmuT6f8vSIg0BiJ3ofIwceBJATAcs2lTC2M8gppxjTpJu8f+ubSeWCCX+MkaBAWVx
cvXPSm5dpZs4CM7E+mIMuhnadoKGrkmrvxMnHBEisO3dlXQct7uRmkbjvVXXzHv64aoqLkOQjGxR
IBfhY7FASOgqVxsLy4EIInruzPaHFsXLeHBF7qTQ7yLsKJgKpcNzWVlRChLm+ipcxgl+cZV9iE4n
8Vzg7r/4ARXEvS4m2/j0njmb1bWXu9Hb4e+UQ96q9LsrksqocbaIG9wAFgqfBYlcu8G0RBU9P4JL
9H6nITeLY9e3bIL5kbfLbxFb7vWwCGtb3ctv+dtHKtJfdomkfzYHdfeOBoqYKjlAJiIgAO5VIVjX
RRzeVxmPr6ct4725A5bH3KpyWGDTzrpMdk16sZW3+PWaDbKJDAlv2CGfxKlyoT64T9zD7khknKt4
wSbf5UvX5TQtLJG3V4NdHxqGZTuhsPSB/+6qq1lhnNa9S28L1r6FcQz/3oXf9Z65xRMd0fx6fAhW
jtPoea2tW2PtM67U9rt3RmzejXErIlo4rGHQ68XHe01w3LFz+3kU+DdL4KFxDLxfV8oMR0fTeb5N
LquHob9iJDFkGZwTR6i9g6V1ZhMmQQqRcgWGHLtFCGF2vUdqmUWg5CdSw+hyJT5Ao45Dnkter8dl
68WpbbPAZ2B8JjRcI/F9qTcNCzZwo/LwHsTwaDYyXY2m5Iry+P3kQpa4TuHeZnhLPW7NlyeCeM1n
zdOYkvCExPDGuOYVfXaLVH/RJ3emBkQ3BTgRV+vnnsC8YSwHVLqcoVMARRadVQ5143ZpwpjZriLw
Eg4fdUlfFRQ4qvJe6to+l772VL/RTJ7sE71rljzxiuYpUF+d9YsTSH7sd1xYI7CbC3h+toPu50e3
4Daopk+t8GXJ3TxiiBPn2OCxJGpDVy8MD4oUhxeG2Kffs1I/wOLsF/rZ/9MwoV/Id4nTLelUYNXh
dF6nig1PtKnbLKnizvOzNy2LwcDJ8pv1YhDTCVzJTxOY6PRLSo5lapqDHc20xDygGC9C7mY8F/6I
ESMNPSdHK1rpRp4OK9kqvb03Do2uRd1NpSyTV96CKmgBLTWljb7r5Wa2uBXvtYKT4d7B/aLmrzBn
YWh8wJWHCwkl6XoyqHx+qEFm2EP6zks4ct0UcOMOCXLO+MAYH2qzxBU59IFou0Nui8WR5XN1uGIZ
ZwwOrHaV/njk5TZWgE8G3qTYMRxMhHVtXJahVQHMy96cJ+ml+P3ZEMMHPFGqpC1atagsnc0KoeEa
h1vfB1B/idQAZt0u3EBYAiaSHTQuAa/xNhQ22TZsEfIU8PU54p/fBpqKqfxuDL2ooc5ICLQKrI+A
E28bG9PsJ4K4IjiMkduplrqRAQsZdp/zISb14HvcHmUmbHCsVylIisEN+dHNjD5d6gqD6G7dGiKi
vAwCucxVmo3zfjPb23BFzwpBz2/lVRpa/mL8OcFnzDKezYrXjamd0U+dMBdkXRt+409j5RdnJU2+
pcpVNAI+xqlLIqW6MuQkJxb7Cf2VeZv8ntoTPjCPXAsSzdiJ6R3eGKYujdPmEiBhBIIlHRC6FflR
11oZR7FteFAZNMJKC9Fv1WNoPRLEZwb2vhcw9fagX8fepbhk5wOHL3N804M/FsHhj9HAJf7FPWI0
X1pQQw89hGA/Pod1MhPviWMJWlO0DViUpmqIlPGKvwYc7SMmcadaobtOn2sCvV0neXszJ90w4ux/
R+xineLjIgAPEXS8ldncN/2yjKPC3PU/lZIZGnfaG7oQQIYeK79FKwYZvT3G/CupBJJh/hRJPp4F
Sy5hC6CWn07AximUoYlGoLJ1b+sFSridBMu6NnjbB2hkCa5Uf3VYyTGO+PNHlRVnrAg2JgQWHxNS
k55y+NKsG31srjug5i6uPm2zWFJEANCRBF+jKPYplnapn78WVeExlQByRdfYG1vnY59jLXQ8autN
IyFTXK8toMqWdROxRZsu+Y27aFx6veT6V8Anj/kGZikuZKz3ityOYgK/ZakCSka+X/WQSYf2XUVm
7vheBtClBIlhJeUNZxP/MYXYfnMFM7ZGEJr6O1ylmxNQ3LRCoZqLOC/wY9LI2+seyDU8crHX6r3U
aQctbFrBwZMxW1QPo8U/oim30nJpSfTYksK3yo9V9Km6AXSCbfqO7FEtYVK/7i3m3hf4dT01OooH
M0QPu9RJIq9Yi+UOFZGWdjcso9WdZqSpCKRkaT8dAGqz38sZq0IiXyleGezgaKfs/vx0Ip3urmd6
ExrMd2kIYarA7ukWPqBvr2vQK2SotX91Cy4lwWBGuACdTX1/TAi1tTO1hpOgtYJBS5kh01Zgjpdh
ee+NbabW33TrWpIo3oil0jjCorYAvOYRCCbSgHwYaHwV4PMijxfhOlGsencVHRuOsXUn3fs+OUKK
1EPqP6u6Qtcwyx73ltf3k0qJeWQtirQ1qTCe46SYNRWnAZPy12DyDn/VN8m+a56/J18Z3iiNLRx+
dBrhD/M48sTqfs+QBj2RvMBRwY4RI7qHoZ1tRkDVSriC5i6DZqrLC7N+6rXTtvpC9FOlLpOh4/v2
ZwPQLceUu4Q6LlA6c2a08+nbC43/vacOZJvKZg+pLXH0vkJ1iCJnDA/iEtjsMqAO1WVPVJsOOYcM
WVHkDp2hCTVZzAnsq4I83+DQ/Fl4Deyj0qAYoJDIQsKzOJLI4/N6+NHmP2KRk1lXrt7VSTLZqumL
kNIxpOaBUcUnanSfKWlrt+rIvf/z37AbfOpqxsk9RLdViCNcIeaAcLPBHcrdfS8uqYYa9yjK5528
b6xUo/5bQNMTnAQO8uOMEsnAzXIfDyaEfhXmblN5zYh1Wtb6SxRicNBMcwvXfyNMNnEY4b1lfPHE
oRZWIMRtk76iCjzxqjqweF+banxb8NjeU5xUndBvp+iqW966T8ejuJhcPYsT2zQBS4RUntvQ/n5f
A5xElAioEHxQ/S126vNjR+wdR2/8jMYO2rulZn0QisHsrNr8d/fW/TyrXDyluRC6Lm5xMzVxsQCr
RJksrn5YaDOPUEclxp4nd2u+jYfsXx0xebC7jnswZO/OFQ3c7/OPPeRPkxGKg6+Du4unFX+2I3Hd
CU7qXfJBralE0OsO4QZpFWJlnwLzpe6cZhrr+bGr1V8zKWtM2oZAdwIQptUoo9tRZRUYPaXxGzo0
ax7G24K3K9H+z25SMvEbMfbTUpBluKYBd4iomIgVlnX3oTRjD9I6lE45mH/B9H3+/9iGJ0jLMgeG
awBIw2XJSuHg71tnavj6UmoYS8dtUO4Oc8Mj5WKA/zuhLTmZLRMhi38z+i/QvkhXuSaQOfSuUAjk
Ko6MKQH8ndOLQ61aXQdCY7i2aCE3kEehxMwwpprx8yUTxHNVgZccnL1KpXn9PGlpukb1Lg9WyPW+
7jw6emXF14hjlmkMJTtL0PEuceXZX47YV/MpiaKKaV/WNZ4UNeGF7FpuW567kwWdmkTNSkzGncqT
lrh7rZs+4UpumEcfNdDDvnVvYoWqt3ziH27s4EfFAmXNIR4F0Xrpae5YX2y8wKEbMe6cMqU+8x1g
mqjiCSl84rQUp4+B1xQR9pdAqwIlZhDfQ7KYHNF4wOhP5Q0PHGbnMthCpuEClB11878fyYaUs4js
emGtWPYVWE7gP1FNCOqQYw2WhtrnBdBe8gWULDt9mV5TWvRWA0M2nmqnUoY1i14Mnrif3fDz2dLH
ZOGeENVanOR5VJXfr4zHCGZ45LyqWkRUvSeaCItcWB2mYc5/DOz0YF4MLZrp0HGJ4DDSJrOcIbd2
z+bqFyoxIofL7gqZTZsNKgAltF1/syMvD/1aky7NKZWG0tytTGSmoHpkeumztwRHJSHrcrYLUiBj
lfthfEP0MhHsbvdrPKygkK7i0u1IyQIJoMxROM3QjXPW6Jr2Bma97/epFKAYYs5kMZFEAnwzDOb4
XeS7HNP6e7gx0s/6xOs6s2PQuNL2YVbNKk/Zqr0Y+d6GGiRv2uNIjs64uRi68oT7LUYMhboOUbHQ
bznBe4U42CXFgELPMuTTAKydxNsqnkhFgCXvWmZ+ShYEcsb+OjJrwgwHKbrq20R+VKuulemnQh32
fwP8CFasn1Q/CYxCHQcU+xyX5FiNPHtI+Y8UnkssAxIGwXU+Mpw4uK7mKAaYxEQbJVVG1ZrF2FVw
YmHfOew7kMJT35LL7xkbC8j9ztQ4o0uPubMRSKpDZDSb5w4nlCLH/Eqd2gWwp9DGD2Nb7kRBDvdC
2CxkCCBoevp9rtaYaROxpOmemjhaCBiTbkYnkthzleUlmAi6sYrEZfNiMBFFYULl5j2XmdwO9e4G
tc55xYehdAqVHjT2far7oBEf9vovTadPZHzp6FghcTRD4iJSzPZlk0GLnKy7VkV6EWcusdtGOxzq
BCKBNtkEjq7UshqVjCZ/snccY82P+4ssvslxI3PC8hlGbS9azd2r3rMbGQoUd4op0Lf/pQEZnWlO
1EAZOfkcL5yv07VpsW1advpQKCtFnsLqQHgb4TVzqkwY9UUNIsI3I3vBFrVidlNWKR0KBmuDUUpB
xQMufh1cSmPtNrDkc7XZ8Wftt24iJrbrDX1BazQURflOsaCSNHhI14cxNsNgXtm3DewkY7mUqInr
pS2huKOa/PBHhRfQ5mr0zV0i3S40lHIahg4n/OTfomuBleU/AYQy4+kWpgHVqMB8HwaLCOJX+QiC
X6qFo4RWs9Zq3ReUhztE/No9cAjNwrP+yq11HrpPsGyfGs8efum/9BqL9NwqBz1oh2pbOR/Kqxaw
itOWLSU6ZnK5rlKv/Jf0LsGKKdX457UVaUhyrXRmQhX1PLAdbdUm+R1Q1dyZwzCbHHlY/jTIvD5B
gIjKkG7L27etclA1jddL0cdMvXdN3anRgu4tP4t4gQgd+2B/RTMqMnd1wqCrNAnKw7P2IrMccWje
p7vXWB68uSaYyVAh/6qjpGqkMZU226isZnpxi8ujYhv/oa4xNgOEWOmgJ23wYUlTYrZWoj8B/kpx
oSe2ccLSkTtY/xEusAfYX4x/Y35qMAeEGrGlcTmEw2vLQHLcsMq3zYLyBVEw1u4Yg5cEqlMlMhmH
DNxVJ6BsEymkUC0GqmBQyCB3nPLYXfP8ZuGtHr0J1BJldotWvxOn0hrrrZ0CkZ2IUcPyBjTppIty
w1KhsRqijNcHaKwJaDP1IW/Dq9vB11cglCHfNmMQ+0fpOpETE5R2wNBuZ0DhNHo0JYdjNZ1cLYFS
TJ4w+zi2s+K4A7q2/GLEVQEf1nIKRfZAAbIasg0d7b2NeTxGGs8Wpjg4Rei3obadkZ8Bf7KdW75v
Lv1/6sWPXkzzmvK1Bg8ekm0mXvNX/PUx3apkoeCitS4/+4lLGetzZz4P209tQJHoGQtdLQ93/xGN
49ZOzgnTlFMqtdAvY4UEkwAjUQddNGf6Be1CPhiEc4drSsHCVoxbjZJuGl+XHIZ49R4aO7uYHlln
WEUe8scqxTmzHu2r+fX+EA6f4MIFK78K5M2zVyjGvrQfX0LceuzMv3DqgEF0MV7WjoYuk6Gj0kJY
T1c3JAAO/+v8b30m1U4HQU+DiFPkj1CN7nOWEmVsBB++yyOEqBcMGNvipoPsJEoeBj+KPqXx2nMD
TFB61npKPVyH3EK68CtOQr2PJiQmVHpX4F6MdUhLZV6IRErDhhhOdx8hrJz3Tyv6P4ph5Xc8eQHP
AeoJr2cEAtmjWb1B3q/gnOw3cXGc+mGSTJAqjqVS0YMW7F8AAOOuCWj57CzHhmQhK15Ja6N4Rax5
iNFrUL/1V+uF5DODCiHsMbEZ+ghUP5I3BhIEm0k8M3ugCrQa/P/iowrCuFKSjavN2ELz+zod0gF+
7dzKc/uxreGLFJrz1nazejwayqD+UHehV+mC9rGLmP6P5OPjVVVQTl3zeDzixlKw2hS3TeVlN1/o
CGqupdN6z1JNTZSwFuw5HG38x9U9A8eWlbfffzDtjHWtIZQcadTr3R83X7WUz924YU7ZjoELcK8X
rCtTmfPeIj+ssgytZF3mP1pgeKZoP8rlxY9x1yDHw4EHWbqF6kz7QjchjjMz51pJFSsNx94wPu0D
RaBGjliR2qFEIH5W0a1JcgxQFO5CSai9YK/Y+4DRbL/ZX+o2zAkNjXsdb7BZ0jdRCCC6kUgzOogG
xF96T7IYoP4BG0mcKraCORYxYrTQSgZNRpGRgNxf6OrDnMp8nXZ+cfa3pjir3pVX4iQZ3dlj4jtz
FHFWYR1qoGgNIAnt1iBw8lrH9XhxRsabVDhpdmesL5tqnfGHDosALlanOgTtBadB2ueVDascDphK
za8TQil5EGA9yj9FxL4LO/Gdw0+Sh9ho4aWYRmOxiETQiHmqELvr0HsGk4lxMkWtcO6XVRfHbG5Y
j5JNLfsQnWDgdDUH16rVpxRRAudjsaoO3Eq9lWaUslUk3hAEndeU0z4PM7EvyeWRhx046xpcubtb
az4Uk8oJC5VI8nTEfmwEKZusqGb1GVohe0oHcLiBbep/NWmmfKUslMfTBhDcd9y791VbAz3+oW2D
N44bub3ObMEzpNdiNsz3cFAPELccPec9l8XRaqZCiPS2NU68FpuNCQ7FfU8hS0qvYQ1tBywkDCRA
usnEotBLP2fTJy2YNNx1UF5wmg8gmH46YIJ9IKgMsXpbE6a4ua2RLAct5Fd3eSevc9oJhmBTffcT
LOCNhhVN9Jt7FfDvtkXvWZAdBQ8fRhYdk6+BMdlcgb0IfbSEm4hC0k8+CE7yRIhe/n4rAjTkM6hp
IDpUBCMb8t9MM6/ZY/d7cd7/+leKlJ3dFVk4ho4Jew9RBGuV0tGEGs1NtvKcuK0tiyFArzDORiN1
E8CgUN1pxFpHh15vqtvbetqpwmlZl4fYq2wavUWtamQ7hvsj1NjTZV+tHg+kldewVF+gpcUBOScs
eGU5LOS7QpLPf7WduAcNe2Vp/aKacRR3SrFTqOAzovvRCnfEdnrzr7eJK1IZ7fUHWuSuodgLnnCS
bZJt9/mQdHh88sERxFE4cHhdaOG/Ek5nHN1jeq9KK778SWvATKGJJFPgU1d5nLE6V5SVvjqR2TbT
sf4UTjpJKrk3awOXtDSS2yfhql2VIIBdNvjoDNa3zBhDLrW6DVDgchjVk76OG/zvvfRN9SGO58x+
oY1XK5DC6m0EcG8IQgzbWegAe3QUj6Lfh4gAMDzM7WA0rvdN3bExFUDyMf6FQmQmdj+fR69sL7US
dcPqJuX9PTBKjRclGUocBAwKLPhz44rhU3DaqLVrbKBSaHODwTXgwgyi/x8BrViBvb/1nGmHIq39
Zjis+QJyxh9wQRRNpXWhGyy2b5E9wlDuwKv9NMVcfAExRfTPq77AElBnrKja6zdqjGO4j8I5fUwH
l4C48SeZntHlVoO9GmtHDiM2ISn8sURwnnbEPXiODeVdmDqJ2uYxHq3ISU/CX+XAcFkWDNJ3+JSW
sQUkfozpz3PsZ19YV+WHY9TvFyKsEWUc/79fuuffMRTBDlYH5QS71HUHdfsm4NXQAOaDUDvweiG2
rIxQtNU4BRGTRn400XnuIJ8uLNoIgqGjH9bkVR+KGiIeiI2xuKGglXs6KJSZPsSZ8/TRD2d2hu/T
LAp6cofM1E75TN64GMPAxYKMEbs9JWIYD1/anNb+q8kEzhxko097OjgnxPEtRfv78w9Ci0POxV90
wcOcBKOrOyq8l0rILPfk3Xs2Zgj2pdVAOnt5V8y0EaSBDKWH9diSsNf5ne5jdpk5+UsVf2Yk9hRJ
UYnjInQgkC40qPJfsccN5cM9rc7QOAlszmk152OAbwygXTHKwIBmAd6KRh9vbAnKsbHjWOFiz3sM
9WezJmt9p0O0WZeoPX8KULXM2mtvOyrNwSAI9tfqs0zBOcZbfx1H8su1fVAhgsSon1K5ffPjIedw
L1uBq86gI2I4NCtAwX6c51ljaV7hsAGemRaRK+0mZjNtUQpcdv5Xz6EXwQyWOPJJE6iXMgmqiwCG
uyoTuOA7rPX4wlGL3xEqxU2Lt9Fvokc2Od0OdR8+N6Y7D0X5mrFNQ/mMhwqUlIegQbru2RnqfRab
/psh9ku8/Q7R+yh4gX+fzdrPxxv7RVwvOT5+YtJ/LH9zzKkeJa6MIXnfb9WUO2KXq4VDApUBNKLt
58J+xeRPqRfJ4iqJ22FgHgZHuZEEU7fObLUTFQ4RssuU+FxgZGdK7+WNqt52DUw5hzggdarqOFSz
Q+tWw/ulO9n8ROHN1J5i1QCUQhdeXYwdRzTIzS3dO8OSZuREej00eq1mRjpr9VBOueSbIEBlqN/y
90v9OkcJmy+LdM82nj1zeqylk5XpOOVES/E8o7rGDLC68OlAuZGnm5mcn2w3LZcMD9mBFRdGSr5N
W8yc+H64XtUswbPB/G8bl9etmPtS8btlKMm5obFygWZgRVaEUh/3ytoho3U8H5fwApOeemehTxTS
W5pyY82dMpPvNm6b8mw1s0mo2i26Vcc6fUFMR8UfEczCHIibHIgve+xXmSWeMhQ0JDDX7bAuWwAR
+omltaYONu59PmIVjuhWMoN9zkwnmUB1aBHwsDJzQw0K56txy3uA6Nh9rBzgpqy6l9xb2eCiTyLK
T71c0xn7qPKAaC8qhb6nnZrM6OSt7MmJWEMLdh+4y2Sa/WiNzAUWGioGvOS+EWE3rTzaPffpsOHi
xBmP3KDyA0lMagoOAAxPgJWpRrSeDAfr+neOT0tbMNhf48WoZp5AyRa/UN1f5wBO7U7kSSpPNTGe
PQx+Bd5DRmuFTVrD+AZ10X7yTlqQo90CFeFlTsmqqu7gvgbBoIL7tFVpWTUqnQ1ctB40Ycd808/j
T237EHCGEIrAWNOr2jTw6zME5KIiyGlJoYBoMetD7CoO5p//dQ/ljVgc2Pz0dJ2eHPBDRNu2ES1o
+sXFJrQ2GWZkmIEjEDR3ENlhKPJ2o5UKgSjwkHCLNrqz/BOlAW3EagyirZ7EexYXVM8JPLNfTe9A
3iOpmdwdl1v9ZL79p9TM5aKZR50weJcgCRBk7dSfS+v6j1HlVagNG0tPEGN/PdX9J68Ls1fTpc6v
Nxq01BsmkRzc9qJj17mppTSvuLHQTAgNUWXNUQoiKdN/bU8/ANCQxOjRI+TLlcYGjOsULxBN9bos
yy3941ctVbvnTcZ0PsfGg5E3X5ruhorGTH/56VNcRTZk5lY/XwxB0AIq0cCKuUdlgcK/BbHmv49/
b6THpYcOMVzKi9PUiYvGeOSUZORhmknRtKMmt5PqeJTzfjxbyLgmKHNTTDNaCt8plGEWpW8HUzTp
MYkoMSib6QbjbC2R5F1UcPwWSzemmn2Z3eeOrwMvyP29bxq6PDNaFuAF9MZBGCVpq0LlgQUkkJvy
cVYhHj1uqvVKYEXgKt4X6PoejLcXvcR82X6Xz2oWECkn04PSP8YaC/1x+5DZky5cTCEmeGoOTc8I
VQqbUwvVWjp8Fv6tx5DQYoO3G4+9UoMywbwizRwWRjc9EcBvWzxiBRJt+KkS6oioJ+SpyukRagfD
AGO/xiJB91nSXORw+hJ65kijnYnR5i+YlnX4VgRvx2B+GE+qoAR7WKJ/34989bAZeSWZE4XaAmzv
suF49oJ/KpaTCzYBovK8+TOpU4MYHAYsUCuYnytIdoo9RWfJE4qrzLPg468cxueOBna8xrIWdRXB
rhWs12X6PetoBFONRxypLVTgXOOjOw1JOf4x3BfT+HqeKSQ26h6vbdzLcEu3oWDR9tzCAWSavPG0
Hyrth7CJLNAiUriXuO5rrlkiCLamfkxmHS18BV5tAn9r43/13u94TuilwyDSJ4E/2ikZzgiiU58U
WYsHoI04vTSNcoBV2YNkbWmfwTyx45tLprjH3eCc9YyUl5REeLYBC3VpyAQ1v1kPf4CBIbUhjQlI
QA+iolvmzo4EeEb9R/yYpnqQEYsPkapjcZJk7LeI8XY+RMy0ZkKGV/AR8QcVwBNRcJ4xsbZ9YRVp
Gsaj9dBUqC82s9yFmqJEHJwf6icdWMGlPc5Wy+8pNPMA8NIsA1OctVWwdQx0XEdKIRuiy4auAnIH
+vRlYlHEYoMQqA9GDCaUNhVxAU1X1NR8iq/XAub3w0hGyfTFA6LexmPAbWWmtp9ZGaqsjSELPx7E
+syUTiQb4VNFE74QhcCCSQscZxi4xJtcdAINz6rvBjKMlCdTLwNBl1Up+/I48QiTLHIoKqQFZbeC
pMFnJNdfaH+ciYMaLNcE4GtrmC24hmYZiS5lE66zLdRaTY0Xt9XRp7bI/uMefTveisYJRrIgWBPX
rntn8SJum8c0w48T0KZAqRr3ernJGwiBxUG+2/fzd1gLBx/ikG9+ILlMkl37TI1lBl53ruVjOe8t
ZInncJRL5Izxk2bjd76M1HQi0vFa3fh4grlhS37FAfMSYTjUMdQc/IcspkUnzO960/5tt2LrHWIy
K7Yp95ZloK8ATb+f3qFhQlqSw6FArLZ5MkF4kGMqVYqkppTm5waVJalhGIlYjmy8cYIyCUPeU3Ma
M2gJ1mmhx1OK2MCAjfY+tgpapAROUzASbruWhYwostxik10Fl598XVhPNQ+Zec6lrR3XdpOaLfO2
D4kNymaq09u9OKpjf28x8lXtbiLGxatnRU5K7SGpDym+NcwEQtNn0zS+NICemhsZZA7n3FVzQMDW
rbeUX0Zs2gdF/dhEW+I60W22g6t3IcOUlpUHBFp6bia/8a/ydsj/7q/hR6g/kbFeqbA9YA7v+QLq
lV+Md0HYNMwKYuCH7rWSHljnQTEVJ8Q7VytFJWi6GiKSRqX3zq532j37GTx7erbJQe6dWAU7hccD
Eq+WM2Dv70riCpzgpL8v7cFm3gU2pfgxX+3nH6P3KkGU6lABUGUOabod/gC3NFbzVtmKaohqZStI
6gkY3dAHkz8xCSm4w/wpruFbH7XL+FYCrjeReqrtbbnyrbQ37eJU00Fowqsq1U+J7jZx7A7L2r0H
guwjx6bPfvfBJkHHT+JdTEJgqpYxtwBWgYohEBq5KLQGUv3tKYm6CxOcRRq0FjMmXACtiby0xsku
oOluphrPW/wKrSFVmApR6LC8IyAQTjZ3JbsjSAxiSeB5rd688/S1aEhrpiJI8qnaUw2FAqCwK83A
rEZeAHeQDomGUu2fWDpSj6QiTYJh+yJ+WabPUoBjz0Fvqph1R/lh2WbZ4boaCPkI/aZsfKeNleHs
dvF50tTPmMtnIDy3wGgYS/QlJTB2MPtesW+SGDleLCagfjNM7Udw3bsaFsTVSaKMyTktfWBIYbzU
vuLgFG/qgUpXrGRLFxbDnN5kcCi3hp2xtuuksSzGEfN4OBENSEbR5kyTGDQzZTYxTuae4slhG0bM
UYl+j5jVR1vkls09nFmPRSA0jZIO51fFaC3vg9RkMJZTsmZGpCckwD18Ca/2inwcrK4uPWpA0h4j
vp12RAnjG6S7t+M9iKaRwCo4q8ytcnc9spPY7joHRApsBkJ8LJks2fmkkD+boCmdpVxCws8ToRqo
LmUtEHCAofOZY2R6gAjW4342n5xRMtJHTJA3HtyYqAMRD8c2xe2y6qxPqL+yOE91wOMkQkvpLihM
YMY6N25UafzDOYmHnn6vWEEl127pIMWnm2Y1AUFU3KKKCBBwKYjeXCPe6QDKdBlMOtvzMovQvnJ/
IfIvT830JPDUPtcRhTSeaVYYlSdtBZxjwYt2iQAhfmbQTgKsvMFCtnFhA/YS6ao86fWdVuEveo4I
riy5i28thHt1J1O2dwWgUnXQzJVpALMZskY53QBNMtOTL2Oimaguhsaf2TME3mc6xDhzWQ0WwyVA
hvOe84JxI8/HnSWBZA+pUNnuiw14+Bl2/rT1l7gEdQJksOJ2Fvuu2XtbD8Z6e8yz+K+7pyECiuKB
PDuRHdfH+/p18tgw0nQrXTFQZJq66QodUpD0rUZ+qUOYYKGmoLhvguhWp+Dz9Wx10lKDBRUygKj9
JCG2qtIoDRElZfMBS4cVegze1L+NldyXCsvE20Z9embZOmuH5eZdK4l+WPmtisVf2iRZZGZcs944
mgkeyMyx3NhonVmKl5OLWZikRxQPtG2zvfKJabJseWYZpwW27f75Jx4A2TtFqVzjXk+UoXKTcwYt
CQ+Gx5AgHtT+p/+gLo4t0NodHO+X2kBE9jQMwGQfCFcq37QQAv10+xr6TxVdicBx77/G8F9Rwe/q
Gi4uN61Sy3QCz3Wx7X5m/pkNvShgQ1J4pwfm+2B7hQCZVyzFvZCs/x1Ct5qLdiqWS3rhKiig2rgZ
Z+JJDPK1IsH3ee9Ed7Sg5yBkwX7qFVXfC8baWxc5kVbCE2A7QOBAsSu9gQg7eGoOoMK2MWitrGmb
/ZYav5OCJ/1UaV770gjKmWuufIl/KNosOFv9jGGDHViKw+05ybhO+MVOaBGHHgL2Y5bzVqKYwURK
ZW6sNzQfQGCCkWiAQEvri6Y6bpLun7rahRiL2PECSaIlEArdVuLlSZSUMTcTogY2e1ACpwu8l2dT
8zLsrLIYxsqT+NN2D+SZML4Ffhbx70rTPjlCsdUooTz7kEigxrn9r0CwxDeHh7i/r/PCwq4lKob8
NSVJw/IsXCtZ0dRhONOezcm2Sh0Ta+PyuOI0KulpbDJe3j4VfUGxwaiOdkRdEc9vfRH6OzEFtN1G
dyPzOxP3bUAadZJ+pnihsmet+96sRdg6l4wVp1vpSI25EORq/30ukm+m5LZqCsZa+on/J76Ym1Y6
0q+omafx49bk1srezcT+xYtogZb2nft2ZRefO4v6a1OJX/A7+B+Gpb8w5l/pqlB0MjvEx+Kpct/H
uYvdBWVrI0G9Kft11VdpozVZYTVxdxqP18rE5Kl7XsF3NoThnMCnJ3asu98NBovCS+mMdWJeYhkM
PK1k5yKHuyECg0np+GqfU7QOtSJ9OJGINqOe7haZV6VpEhwgZzqJLBed0eKzFZcIGhgGhKHnwP+H
pqRWtVvSz+qXspMPBc1dGNcoqhSrI9EuZVvg+4RQu6x+uKq45OPo2iCZeDOR0gT0QXZVCYrIu0MT
ZKztS3yS4zFb5fCDJ0Ts+biVg6oVDcYhZWIhularxKFCwyerpvGkTCTal8epttJRsxmsipGxhGM9
yn2dbZkLyWzoU/hjL82PMSVZxKV761YaaCjy/9KNj+iFHIn0cebWbV09KYSuakybEDBLXDsUZv8r
6bLJbeBFgF95bVtll9QyEPPBL92YdbrI0yIolUZtWvvkpYH9Mh9Q0REC21NWMf6wtTWrNdupz/wA
e9rw8op4Pf1hib6eZ1M/9vcY6xfqbeXsxThj9d2pnxSLZykxVL1yn3vd0TUV76jrhNNvlkYLBCfJ
wwHBrjp3rEh3fLjX8IS+wcFTa8N4yoNnemtG6wnPsQl1kGGmKIADk19iyYIcLrKQSGuJxhbH/y3O
v6vsZ+1QCqjhZDPNE5aokcEvb0FFEhKtzTR5L7aJDJUlycgo2TerZusiq0y34oHbRdMtuhkFjIt6
aPgwBEUEywfjQmI1VFA55E9SHjeH4I9WLka+nYYffaOACOzajF+IqnzP+S4uSF//3K5mIj7deWtv
Tg8pVLUC+21r+d9FjmNtCOxaFvMsYD1m19RFUKeM9ZgK3onAJT9OHO3uo/2wB6m9AdAu9u/W47ub
uB3RHt9ieqs0Y6saGcJoE7eWJP+KFjAY4XbZfWiFE4lAFhYES8Gse+RtK2g1veP3uPvllWTEAFw9
gylyJ2OwhsdHxQG5YCuMwRFhccswXBApO4yCEG2MHhwEaVyccQmNZtCCA1+MN4JybTN2RgbHuRZX
FIkGFTMJt0LBnJG2JBT12E64KOEnsfWduYsCA7B9c4c9ezBEnT8pjeTBJKOl2PspZPCz4Ezl5NFN
8N2jl/WGJRe4JoigaYsZcPHNkLnhzruLQgaXYlgtlNFHLGxYp+OsUZ4RNjf0MDJQm4TRZNOXO7mX
x56JEnGvHB4AU3x4ieszY4y5sc4li86Rn/KbQg97DJAgn15apI/Ck2LoeHhYmZHOZhwRJ/4ps4V2
EAx3mmrNOFUxovhPykKqZYUOckYSNe13fvwgE2Drm6XnbMuKQuKRiRnl/2YGZnnX+nYIiEFIz4Sb
bKqz7F/ClE65bDza8whdx2EcV/2iBN8nzI/uWWCYbXrufZ1z5mKU9e8NUkGz4f7f7QfltwhG/g47
QLwgXkhkC6KsoKG2zmySyfzBodJpG/XuTCOshfvF4c45aujKfP3j6k+rvELfO4eZgPc3nmh/XuLA
324e9vAgET85RhL3IsnUnYsb+VXXPrLN56zrIJymyonanZ4PZTgmpHnARXTl56OZY+ukvV165HZ+
CrKjyaCHYQ9ikoO7ZctPp1yIOG+8uyDEQea9BoYcP6/jqfa+5jcrHfuncplaiNn1mGjUEb+zMEe+
/A40edsHwaV0lHK4VxdrKS/E1+iTTtxdTp0JD1AQi+5x/zUjJv6WInQ5m0C4+/oTzzzMIb4jzR4u
yFaWOkzqGd/OOPOafADe7gwG5AU9eGeUQrKdg3yZIPfch0Veaoan6UW3oXFXxKU6FYTnvwxU3GeL
TpwatiDjeegiFNevmStyDGCXQE2XAIISs6dtPz07x8XJUJJdeFhE76+j6zYbQNl/vo9xM3h94KK2
vR3e+ZZKKbVuWgcSiRyOUwxO5c+tAVd9YqfL806eP/0o8fvg+Uf8rSJFH32Pcc4/28qk+tiDIPVh
z72mjzeCtJPz6XbwwnhXWIOF0JAAplODUHjPVQzj5jikXQdIVhqDYMz6gSuJdt4ZAQ8fMY1VAGpm
GQ6AdHR/h/hX6VZCzwJork/e6F4kZmrHY85qircOLMBqqjZIGLoCBAUjvT/eFJduhbUWc2Y/jHkp
zprtp6mpRJ1P7spa7z4O1Y5gtmlgnYlCtpcr+EyOSnsyLQKUGZN+drOqqkHm7/vEiKzfQvILvqGs
yQFtzqhNWNyNsJ/5Z0edPSo1OaWxmt5X8j+46iaIHComn2hgtuUYxKKSXmh8iGia4jAWA4xrCt7j
1DqoxkCa+09EPXVYWop3GeSX1Yuh2W6fKTNQgAm8rQr6ybxOsYbkohRr/mUkCIP6Y+FDeGncnZes
ru1ZeFcBeB/RrFDCcZ6ryaOjSzLhMWJeHZjdJzZDVsBDE63z1gMXOyzRpE2JSX8uxC+zRxSSgK8+
Wrrb59z3isuhYTCXf2/YCotiMDt+1xiorfUaiQWby+GQ2dnl9EFEGBDCSVTe1UfkBIxiBV2aqBHL
nh9wTc7Q7x6fiMZVP1r7DHwOdW+UST8jNForNOI1q+IF897tA5CQ1TgfZt8F9Kg4uWBXwwpORcg7
f1nPv5GsbtzLHFOprvOCVyB40ssjT7EPLJyfZJwN82B930Jd89PFZYV79Hf2rIltwRmM1v6H8mlo
c0yR7Wal7l+0oJqsjfeLQRoFkv5cMf9p87l/aId8DVDzWFwS4zqIX3/bUhVu1d0E1OxkZ4869/I6
IdpcSwtaH5HXK68dFtbzWU1Sj44F0gYNCN0su1jPPARH0+PDteiVm8xwFSy97dnmcWsmiH8ItIpK
+h9gpRUwssHBwus04+BsX0hWNSR7u5bLPSd4cmC7UrOLWSuuPNKhhO/mP29hr8DzVK6Yf/lyN690
yj5M69NlefBZQSnn163auSdx7AHYkQOXwoo6LhicTCg8/ENIDyQWWEhZxT6qR9U95r+PqdQ6AARb
DuKYOLHOOFWWh2BnvJaHYwz7sVhdXCH6cBjGI4v8/kApN6ArptDXZUmfu4bUzBp8C5WGqRCFNu4a
NzLNTNdSMasDdIiXmfWihFY2tXzpZAjoX7zxbMxOA10+vyu8mDOYI8oIiN51e5njwHHpfP3s6sFd
yqy9G8riYxK4+3WCBBqzsx7vfe+NMLPRKFH+fAejP7we3r76Xmerv97+4Xd94CGeuHtL1fIH/azk
YboHDxerxnVhCSpQl0CeS/y5wL0etlKF8zl1yRHzUfc0BBRhVZKNmcuEq5owfKQ6KLtuhy/A6YX4
p4kRZNTcKhmfKmREOlV9+jwfc8d4BcY6n7G9UnU7JrbgzEpSJ3ruIi53306ZnmEpzQ5OQQ2Ft3PE
80L0iJHo+cZpVrSOD1E13RrPWfjn+BHiHzZbKFsG8/gWn5PecgtKARNUXZ/AD55dB6/lWJ09Zwn0
KkQpO4aKDyabZ+HWDUOPotkoCyfoVarv3XtGFnv7p4VE/NuKjUTocp5MLBnqPN6E9SuatF8/lAOJ
6cbz04JiPi3TTikcXlkhWxCxLRRGhD0vqW+6p3NYtJ+DTYhquHp/rGUDcPx9THicaiK41Tavkha0
tkitSc7x5kQ7GavqzRndxucLf7ELIcbnjTmHKaPgkexvcioi1DC41tTSJyG83Ds278ig8wE6MWZt
PpdvCM8XgCTij/mUWSrCT+ppnJefojF0fvrolY57DwZCi3+vjUH3RPwnJYw921MNwGNvbPgeqHQx
diirj+prbo5Ri0AxkWdZsMehnQ0SHj7Wu9G1vMUjKSeL0/dStft8MPRTipVVzI+B76BzfDTWnPKw
/vE6jNkd1VN8xv+7OHEqeNuKgXqXE5y33qqh2aAa5288bzsqryLgGtRZQR9+HE6nkUvenmtOoXHq
GYPIfTpS4w81+/yVXQ2xa4kKjWxz7bMS9SkAwh1mOMXkBGNbFwKQ8AV/z2UCII4Z3y4BIaxULJgp
SJdOCsefW6bD2yiw9LISKiS+753KMBzK1Avr83kvlyy6owONiQ3pAkkt5Am4ctUz+wgLe3uTda5V
8Hw739vckfR+agdhsPMHFyzc+Wt3YMjA3HsR3C22my3fEipq4UUpzbDgWfOxqAkjQzRuRl74sLGu
OghXnQanLyxI1Z0S9cRbygX4FJO9lhvIRb/8aWGOGr9n5rVi6nw/8JIqBRGpo2bR/v2POa1oX4z6
vgS4pgye9Zb8sfbNISiSIC46jkE2D20HNgvlt83I6RY/0riXNBUpuL/x8cqkiJOrY3skJqAB9T9c
X5wupxVlBWaDO/9Kw0VNXF8i31jdm5DaM0mrc+g0d9dz2uBMO+58lMe50+r87+wX4UlbIu579PfS
052BcL9DBhkVQsaqecimiSlYY3a5ja2I0pSEfUi4h4ZkOTod6w/y07198SlG8Qrx5f4dHCYVDZZd
I4IQedJV+2uqBBNruSYoZFnG3ZwUafCFxAxX7El2VBDIVptExk7ceqY87QmVY/I8cOswj104UPbd
m+23VVz+vUFZWHBdUGMJBOCJZWxlTuR3Ge44yxppfmUfubYnx0OnR0dS18QtQR/2+zd/tjXl6HxE
hZkaSL0X4LANUN/wxDIBher8kxRwMOQfdCYnTQH5hDmYGwguSU04EcHeEp1Zt5rnXivU97C/ySQd
GKiWFRy7FcYFHmwzPkURE0sR9z7CrgxUD9v7Ksca4sioC5FXLVPR5yOa4HSXYe+U8nv9nT1xLmK0
mk64RHcnC+GX7jOfdlt1yCi1ioilvMNFBl8qsNjlQhWJUfxEymwdTS2tphRCV6hJRN5siLvSVIZl
y+6ED558CMSQ3v5sjrezIi4wooHVcUOTQUZjTFpxA9r1NSxU86LThJOrKFjYnAHeaNC/xcMsa5jl
GwV/MACRDsPu2twGe5k2rJ4SBhXN3wzBQorcuGBUmQOipTHc5/b0HigBmMKRjcfv3XmV0CmS46Vv
+z8SYwNE1Z/F/BpX8e63OcF84FJFV8bCwiLP/lczrB5vkGQkX+mY6xISQ7HKNI4szA4i1IuP0I6G
ipCBm6IbytNdGTu0KmBDhX7ddHiT5wSrac3z1h9CgnnC5UgjxbZWFUBNWvtJ2KtAuvQ/1aklKePy
aUE2N5mzxS10pnHC70NTiyaPotRiMzD9CTJj8Bh2kcxftXcYO5tne2SnFQzOaZQH6fSL96JPqeNl
hCDA+iO91M4fG0B/yaj1DBEJHlfbeIQWy61qIn+Dhk+efiAfwLSoFZfMszsI7nd8DzpMh3XN5uTA
P1ZtYOec+FrR63AD7pUilmkUJYEYt9ICqc6O2J9lZnQQDzZR4kTJ6iEvhqy7XiaT0EsWGxFi9hWm
yxY1u7Y9rudsn2WRgeqkW42b0Z1YpiPN7QNpRR8ddR3MQZ5pqOOoVshN62JMQeIJjgxZpPl4CDnH
CPwkhnrBaY6CUmkHb+J8EMGLB0SmCRIajByc1AT1Mhigf9Rt7qD72sjLNBlEDKREvWSUc3hKJU+M
RSOSwvTVG99ofGigWIqndtu0oUuNbdpc4/oSwENXrdzMCs+NXy1rKm4Te9PDs/a=