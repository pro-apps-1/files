<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPypbRWJNXrCihWlx9qy3CpKIqSt3vNJz6+H8mYAxb98mZaMme8GFr9tk3LH+lmp2yqz46e0w
bXfSHjF/P82RiVIt0Icry0BouldW0wMLcmAxK3/iasz8QXJDaGWxTrcQpJvlgc/m+e3l54hwnJ+i
BeqbQiT6ruke6OGhaN26cYpBDnKu8hpiZYqOVuSxo3+ZsoY26ujTNH+MBSGP5hYHzYf3qDhd3Vry
PQ61OduegnpHWoGNYOoAfOTp1raKqzQ4aHIyE2eADpHZv1ITmSJY4lsWpyD0PlpClBKUDVkpvspc
qeoATFyS/LlPaIslwb3p3sPcks5OPK39jPFpTOy0p3TE1s4sAil12/c0yfkyIOhi+7pCNGPnenso
8dPvV/7uhmYkq0J2ejuAlYZFCeqRsIDRnRLeDIBG5WSiElxr5EYGTIiYQCu6XxKt5g9YOTDqD9RA
pkYDDPbaWzXdLpItAsG27lqkuulG6F8KBaKNhQP/Z3buDP3eftOeItej4SueaSZZlUmtXWwcsbzH
plLusySsgH1AN837nbbwMQQ5uS1wVew7fn9u9AQ2fKw6f5thk/nxPpTji0Y01LKYJgBkrdhH/FE9
IL+S+2qcM0aD2QDMA+Bw0xRhoFQXp1VQC2OJTria0fuw/pCQfOFdOySFmYAEaasHxNHhJNacnfVU
jGGl+6NqFK67/gaUPgEjK4entaUSAuhjI416ZxCJo5cYz2grYBpFMrgj0lkcDpkb/se5MS3LbXXJ
vE1Y+kfRuHxloG2ZUQLBNfDbpXg3XfaxKBNJWkXAARLBV/APSVco1g8OQ6wHYD8Mwl7iJhS3oVmC
TZ2r4mC6QakZBBbpaTal38/ihCojg8nNGHzHTDOXvZ7LNZtsMzdai8opiU0WLI/Um2kURClcQtBb
m05aBbD+OZ6iH7AejVmrVoEm3VBnqofwDpsvIqXv6s8owfUu8ZWOBm4V8kXJ8lDllfLvKz7e3pi9
7vQZVZ0jZzKrcWbcLw5z7bzgO+dEFSui3uKHiszRcvQ8IycYx5YyD1pJTQvHvCEXap0Za3v6ZsRy
eny1sQ6GGl/TmaiE5/K/JoVeFcScL3SkbgZg8WzO7DINf/c5ocv/wqgHjViBCNGTqj6oewxav8IP
hY8919OmY0apKQAo3EIQ37rv6xOL+wR7nuCs0hciN3Se9KSRk+XhzBMODFKt9C1lMvhmVcJDrOcf
gxzWCCFqGJaXhdvnJHEeEWJEo1nRhQqpA2H5XjHaGNgk0AyHworCLmLmrqD2gS3HsRtg88qmgF4s
m83vP1V0UIVVnTjI00PuAdgIwXBdAnIa43bU+QnJdc1gDoTZjkej5F/BaZY8aVXDTDtPD+yWuo3k
jKjrCi1Wlv73KsDqRpI1FYy02l43k5RCFmc3hNPcqWAxd8RBw4Y3Q2104NRAQ6rQyWRaoKmeFltF
N2FRk0WIx0GCHFZW6KTxJdlOmzCI7Awu8dx73SHX5IU3d6XlHboBxlzzeRBzQDSeuWzyZcEUKwvM
El9OiGAG+7es5Hcsf6PEFp4AMXARdJMZe6gTtAXYC8iT0QyI3F0mxwnz5ftJvzGs9i55i0Ku3QQA
b9PfsiRXygNZK3yt+B8McjXiHKDqfXMHVoIAsM9CFnmgJ/sSZXlkIG9sfAzv5Cfdn/5eUX61vuTu
18wm6rrSnEWgS6HxblNgc42gAApiXyAV0+vdrGlkqE6KSENg+71RMEgMXmaT+eEDP29RetfbkQOA
S4UGA0/JqxR4aVnBGDR9hYX26WwcRqPpLINCVO7R+Xg2wnd2bKl33RjinUDViAwORgO9wzNtlvo1
55fgDtLZTPC6ySUgGsDQfm3As245XSwWfT6NojxCV3a3oI8hyldYuTEnorJvG9zAG9iO4cY77vmv
461ebo7HnzsSxNHiKlfvBzQICwe0kdrab7YFAu6Epo2pr2ddR/cmpJdu12ZOjRpSM2Ls9KwQtSlm
SM9G9QuP3iAMVRuEoBllWjGZbbezWki4yQXZbI4aUm1mo8jVFsiLHb4g/3B/AUmMtAcKfvQhYa6t
ZwXCUPb0c83dC997KnfICz5gKJ1qKwHbd7YNBXIiZDAXk918WRSG8W89D3Q5qDFUFhPrE+A7Py70
cazXDF8DIIFjX/vXbJiYnAukceB8FekFjgIUZukcXypfHsaOTbKKxHnCKhe6tn5A6NvJDAKsHhGE
16ZgUQDYr7DKCRkTQqYoDUNx/8Fh5Hkx3LSI2Uk/cCAw7LZ0y7ClKLmsFl4PV9brKTM2puI7nQmL
zwxVwCxPxhAf23PE3neuUlqx4vHaMBlB2m7qG/TGTYMyARo/URCfsUgdcll690SSsZ5pG1fAXZZ2
RcNdnWpAn0ZAt6havb9RJFysBR4ESeyqLwIiNAFDdSU1kSeFHvSMUnpxaazehwbPzpxD7o93l3hA
f/1jjm3M+/NcKl1C5dPj24AnZgHLWi+pC3rrgrMhVevV1en4/wGdO7hVT758rQOgDC5StjyUFgmW
wYtsRNkJOLeN1EQnlDkkb127zGTyTAJK+SfUiNsaCVqBjqDN6z8f7sg7X8FHqVdVfLG2cWg44+4g
FO4Kf+FI/516xlFIrFQyPsq/Cz6Qy1ovFYjdXVueaewB+p+fo2lw3YlfaIOt8FrMkvPLaFr2ldD8
L8mwdIh2fSiOcXWOhSGnJItKVhZMpWi1Qxula+tHMzFeB3IP3pyBcRoUsKf6PEOi48RyOWt02vOY
kiINiL9NUZQ2u2mkwrgkmeyPnu0pf2ZLacuVY+/ZmIpIP01173g6bEylaFXr1CelNFWhFaeDcfIt
PdYzzxfKj1iogqGIBXudM+DLXhpofHqjx7QkRTct0rw6HcsQnpb1cpK9e6CP1108EthpqP7vs/fp
cS/ZP8osmmgaGORaCnNQDp3UiQml+/dAry9bEDmVy/MeryPtlKnd6WkWeVK6NeM4AYmSyR33w3qb
jviCiwIXzUs38H5VzVx24j36I87E/jnjtviV/2X6U3i9T2z6lVs2k8JDBE4VOSX2edBLzDj9kbBn
GtW/rnub1v5/Ib7C+JGr+el0XJtj9GVeDB3QBpFtu8NkyCR8wvi045XLXUztfAmUPkGxeVRyuDjX
Xc23tCSIcu/oCdgcitafy3Za+wC77lyMGTrtbtavRc5y5NmG0rALiJcE1f6T9WZojjRN1Tqf7NYN
WQ3KDngeSzTC5rogodENB4UA6OY8GUuxjInD9/zAd+hX2U+DBv+nIqFIqNOKFKb5DoxA93S76v1Q
pxfqew4lgVHfyAENQ4fm+dDb/GE36BRpREbLV4AAHLKX3dk75ZJiilr31G5pDsN7zf4ReCKVMsDu
MxM4mjX/BMiJCU25NcfWMbXRO36sTwkiNRg0R1h+dOGz4IA4CM9GpqeIfrGCN23UbkvLQNQr8+9i
VuUKiI6vlqlnJ5nou6jyZduPGLEekXdFpDK0sg0UgVvMe0FxmTUL33XvBnxj+957FMuGiKU6X5Yj
OyvWJKOVX3MI3FmQDbgwIsQDFqIVXELRP5ZHS3ZCCrJArVCzRNLMtxe+GnbPJ/GZmv4gqxs3TC/f
YObWY09GqNd0FyzT2SPLoogskMJdx8tZPRmjiF70VPuRUg9IckWH2vKpdezMA8MHfcg7GedQPtIm
5qnxKFRdVLEeLb7VzaUtkfuV3kgSSP7D+tuGc5ILV1tYq65nlkFIpv8Hxd08lq7ZIEq4gqpxEd7P
qQ+21my7K0DdJZ/l1OPvW08+ohZD8I64+fHr/m6xdVQw+l6rffK5MvTiLB9XtwjB/tnH4c5ZoEmP
S4L+rBNR2Bxhmq3D7qtZq+Mr05u/XEhquYNOrmQIfiZMYuzHhnmpvLPX/ZKrNf4c0cp4D7nCRaAA
9rgLvHh6anS6AOyK4buOP6a+0w6FQNpFAkfWtiC6UpUVJRnQ7xidR/d79gPg+upiSrrgkP1HSFWD
KkreYDblQyt9nZvdEEYq9B+NqOW3nbCjvtvasMoeGIyFBj+FUOojZHL2Eg+9e3hCzb14VtPToiMk
j32BzRdnqnHl9eiVAzDNd92O0gzqh7meHL3siKyiKK1Fgjo1ONs4OA+gEVKMcqhDWSlxjIyQzZZ/
xPNCL8a/2Am4joriqGhLKEfxeMxVSOC0XXurPlon3d/oc+r3LfcYvqLcaUa43nZcnkGo0BfxYukL
1mTg0qOMH6XP+odZMkf79orgvfHBtHOsWFB8eTGtSt/nbiFeMK95hXc+PpL/H1noAbtxZ/TrC6r3
wzH+3gVX9w5EDnVftKuXdbwHTgEliAj8OQVqm0NcVYiZ59h3ZEa2w8Q4jes3Krf6GpxgOdECsIlg
eTstcyVPdPGBbmMCJLsiboQHRtPEm4QkQKtsMTgmCgIizZVVbTj4jRg7DkGQsS7htHTLDklejmlE
l05HscefCm8dq87rC8v59E8XcOxR7pvLaHCMJlzqGSrXrB3WBMMeOy0oZWlDCY6xyldtky73LNK8
DMvPPs4m4WDKgXq1u3a0W01Wno9uLLBqs6TmKHi54JlDMYKVYgVwvf0Kc8rX13/6x9f0gyn0qCvk
1ygAC2SGcaFuYJkxJe99CcN+Ye5FMjfeRxJpMBjD9eXhURPGBC2q65FA/4vUnW0IMZalDZrjw17O
PgNzzevudXPoXpUD8YRGBG56jeBO5lMczrIL1jDph2o/7zJkvRkN03YRPvl3K3Zdumffv9YhblDk
0bfYh9XuN9+0ZPfZ4S37H7zT19rJGoAGVSpReufYHExWzQLu7IRgLqRKdzPQy9auSR7d6ErlJMDe
sSvTjKpPm7YY7nOr/pdZ6k+Mp6SDc1aAdYQGYRl18WcdkIaxKboKUQ3kp3xk83z5x7XPfAFzxJiT
eR5CTo7LP5iOqTgZ93GSMNWEPqXe8EtM7+loigaacZuWqBxG0fJ70AHpUHObtvmKBliaz/p9czvx
xgnmZ7hHMgVXA8z0KdYDUqpGhTEF3CM0O3q759dlqkGzkwbexJFtuljYtEOwrlyvkndSyhsEnGcV
5Rd1Z2qmFcZadSOV/K4qkx8k436stRiD6wjM9DwEIKV9ERm4/sgYYFSJsY/s+l+8j20bHTxaZkVR
bzJ3PtjMPSboFVGdwx4nvlI0NDBKtsc4smBMGoP5uszUZYnAP7iE726DDfw6D/Xf9cVJf/x3xxPQ
6zF+QgPMNPA7FI60qZMZvzCMA5huRNYrri47bjPxQm7/9q3lN+KkyI3Wkki3qXUOK3Z66+40Lm2p
+U6DHkFBSiW0Qv5Pe8/5AGgL27pFSo/7qIBcYIyIaC7pQH6tZCCJvDMa3LTna7f1UVfo1/YhlqlG
9znT6IXT2ykIukDnZH6ZoBNwyMINMdhWfvFxZrtPm/xZrxMeJRX1QXPq3i6CWKB9aXFH7bvIB7yQ
/7SOXEQsb0QSs7ArM2/yWIqUUeKtWJuoZKBhLLF06xVmDVFSV2PUr5c2aS+clkODchQDLRPxylJg
Ygym/PBSHWHz7W/uHGUWDdVORHJrXIPk0gBUZeqY5dMammiXeFF+WFS0pCPvtk4341rOAcc2363T
DfReAE2dwwyBLFWlqgKovdyLA5bJX9lirdCHgmXXw4wzq/fk3fmJwndd8gmmYt+L4+aIm2iw+K8V
ilviNpVlQlEItNVkyoVm+RBzAcGskTNslPIO+1nspu+JFGT7C8/V8r+d2DXLVttUXi/wELQNA+GL
iDSX6LFYmAn0XAG1evnadZ6tecNb+5Gne6TlTsD8jzfey9jJWQcspW5wQA2JuKEiRtGGOlcSGVea
Pp9AZTz4VxkQ66uVXTng8F2w6RYSl3kRMsCUm5CucWRaSQG3HrHm8fXeaa/YC5pBY75z/na88o9E
GGz+Ufk3RaEx0QmzHAQJ/GSdIj0kWq9+OlYFiae+/MgWcfSBIUYCfQgVfJ/EG7nyCD+I3LCh9DVx
RSgnPJFDvR2kP5+WNB6Khuv5/SKc7E/vLBqfWCcETCX0sPz5dkD+8AYZCrCpDg1Ko+tA31euqvwb
zGTwkg7znkpkP0fFNwLenuzaQ8rWtpx/q03RNsgz/CmS82NLspxUcMpyqbGedcJr0P0LseecQF69
oaXDXeNmJOGebG/ONHtst3JNrSoZvWvEZikz9Mt6J+Yj8n56OYSix0baHVBagY8YTISu5IGMvCH/
NfQCQBvx3dvC8PCRZlu85DgLE97/YmODbOofYS4qA+eMyn44aeRICoc/OlKTOhGbUsGoLim/M2M1
fC/9uFZKLeb4X2GOe8BBlDvLWpTb9stsPPC8RCSxXpvyghKb6x8NVYMcg58Xg8oCVtcMlqA+M8l5
nmP9pe2nmz3JlAL5kVN4A3Aj3la1CMz0DrjH5lhga0as31P6NMCF9BajbA5AkqgSyv3hj/nlrfhO
+VgMID/wTT/irOnbDyhaIgNVld/ppUw92NQkMmEDiiYQGJ9KUp5yyehjYjSbewR/6R0Xo09nJ7R/
+7QIvhKJsD+YC0P+8QCtS1wnjo1RmBr+hePQGJOs0Q39EjGkOubaYHzwOszoKT1uBUa0ScFE5byh
8MFDnO/vqe+wRCss+JaBrHc4nX2j1imVhTnjws/5+2gBmlzL4tnYZAEsSN1Tg6tv96zsBYPHRyqJ
XUYQU9ZmVG98ZAYIxR+enV2D0UrUAWb30hs/hJiIDLnE7l1uD4obL2uAOSk10JwRVYx6QfDrTTeJ
wrmqaAGmZczKh4e5jWJkpadGXfyZm9HXTqLfT0Vrg3YSjCz4B6UGPMW4vHmsw9nlEhBXv2xxaQ8F
HlJdnfko97v2f4Gvqsn0zEoHteCs+VulQFErbp8RQBXBosDrbpM3b/Q9Ab+Bn8wEz2zZI/XaA3Nq
4j64l6+xXdEMQfjKZQMrj0NVtcsSI03wn+/cV2FRNtjC3S72htuvoNRCNCXyieMCeYnFn73VQyyJ
7mBSqN1xmmbGz55B4AVp8Z3J2JYzDTjwjtOTiIF4nqQkLzWuriuZwpI0T80jW8XrKOo/Q0FyQ7I4
E6vQtqypegLdsQEM24UxTOpn6IYhywiIZdanKubhZ38QdcZFPKLPknPY8up2wlI1z2tmHRzZMYQ0
39GVcVu9U0TLoK35qRhMcIvXtK5hsbsUzR3vGyoUq+ddRLwZ5OL9Mg6p/j+/ucPBJsyoiPWa8Ycr
f7XzHdElC3u8v/xZfCmNH7Ir+L4q+we0nNbgZZ32d1Bds/gUVIxmuQZnxxyqfUbpXxSaf10gPKhe
I3U61dYK6YhGYn7Rsbh/79DP23kuzs2xuzP6YOPRxm0NAGj1ZUdOJLunO88JWoWola3qSbuUeay6
yCfR2PQljaat4gaxX3jonWVUsy1EqkALhbpQxvRf+ZN3Q9F4KWAcQfIEqiHKkF9oVnUCd8fdawIE
oZGPjxfd5x8I4TzN9tC95PGPHO8T6zUcLlL9EdDo9eVV2m9S/W+WqhRtmy7vCNizeoRIs5aIxHas
ErLPB9jrMvus8ILGuAeBnsBBPr9nUSTKLNXkooxIxfLD0eoJ0ZIHwVQS2fyjsKDULpThf6eKz4y0
mX11hC+dTKjaKjTiYgH63onwaLYWsDHW//5f+S9pVQLeeeu5xyjD9jLEMEgQrpIlNu4PTIQ6KmDn
aV3x+8ndyobs5d1OknFcM1BvPikoq+fBgsWDfERy43eSQzuid+T/ajB9MD98vOhJjXeVnrUoccBn
dAMzO81voKLHDgPRItLy1Xa9zXtLrcz25GqTJFxO3Tnh4FwiLeBfWPIBpkUgLzTFReNTgNyCavs/
5UPphKNHKcJAB2kOnGQzZwxel6rxckwuvymnTcYweUwlrw9yANweHWeZ19OrWL0K9/HrCyMr7UpF
ghGOBSTQHQMQOEwSZGn37PmPGfBnD2XMz1Dz7+gY99U2WLD3+AAcSzupHJfVTxV3rxgOdr4KVv3o
upJnvuJPLi2BsFVInl3/bKT1KFS/qoEmZxMmQ1uJpDK/wfGeHquQEYKD9d1YB3lnRjgBIqqCFM0Q
jVSzacOdMYIpP1NVQStcIJBmJYoLy4V6bCVsvvBBQGdQi87nJxLoBBqhWRyWhg3GpB3n+g5ujA88
XwaF7k33Zxt7H1GNj5U8Har/Alr0ImcXtN5jm43F2Ll1wbsARlC5Jkivi1UOVnyDV25TyxXxrdHP
KKfpRejW0ZBo90h48G/Dq7NzKc1SbOkyPhdUscvHq5ipIF01zQUkqhEseLqvs1h+QKgDPTj++KV+
hIFWgNILCzsDYRCkn/XOYW71UT6Qk/ktLOdlLHZ6iNoGM0Nw4m2t5nDIWw/nqObHTWvRAuE9OhUp
rXMIrrAyWPwKP8eJFGPAQeYXbrXFf6WdmX8YLmEbi6i1ZD/PkBMebZxFxKjku/42i1FmDPwz4/ct
dMoAFVy7TEQyAISQwcSGipU2mSvUFrSBmmV0bOxh1uaLkbY4yKhEAyN+4s5/JJgAYBdkU5rff5Pw
SQGjw4PDw8ehrGRk8Q1hDHQMnv92TlsTexwPMzAlZ1nH9rYbSoErvLEqp6+5ZOpd3p1SpBK/D4rs
g7uo1zK5P784xpFRybSB/Uqw511EZiMSY8OSZ2yJTCi/igLl2+Q4L2V2HxDnsV90RIcBYNOc5QeU
5D+V