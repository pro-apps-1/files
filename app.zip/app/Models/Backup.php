<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoNYD9LKXetQ8GoXjiwuKg4CtccDUKuCq9guFXQzOE/rxIb5XvQ+6MWovm5Hl9zi+qq0JLWl
ZTGrBaIq0jxV2lgvILUvVK7aQ+h7O3D7yMojJkJfuQdgl+VZAl+wS/JQaS2QTAKzNIs7TyoslWuF
3VvENwcb4rx8HSqaUrVtpBVOnnKk4fEmpVXmMX7KkFr953wEfOCfy3CtkSUvahwqMsSG201yShYZ
g6fN8k0iJCD+ob1k1rfmk5jlyaTYYuPLAmXDLlQDKD5JiWCuRryR8iCogfneKbMu/T3/050qZK6P
DZCe/vCOZAFeoFe6RAfZjykloAtRBTrW8JkMtTn+xsoln0+QTV65WP/v4FY/+7O1IJJXP5cJuP9a
kZO4v8g7AqLaKSToEQDAtbFq30JviUDYbvxwv5Bq7m9DltUhHiseLYuDfqEXqZl8XVgKAGfzIU6d
1XjfFX6HXVlTdCLdOaKvNLCjUHdUlwPOn/ooHDPtTP5l3RJYNURMtYmWxtGc54NDb8jZmDne3JiA
2ByLFYCeDcmLrk1FoHEMwIsKx/Fkn/YeIuVknh/GoU6g91CarvicofgRAanFy37g8I+HfbeDyIFh
7l5fD6gDZgunuiqfV/KOT3jUZvIpb3reGPDzlFXPMGPuztMKwnfG+/s9LzP+I3NMNa1R6SND0IDc
4MJeevrjT7wN3oF4G+f1zAt3fdHs80i8qmvY0ITIWdocE/hCB8dFNPVl/83ctYMKuBOf0mBMu2el
Q3XRmAjihtznpOvxoudYJ/Oc83NPNqgiXE6TpWnZ3BY3rdPzSwx6XZS+XaYv5+gGz+iKxfqPWPmR
3zJQarbD3UH9SWGYpj55br+ii9qzeQXBHkhWg85/ogB1/a2EIf8wEEoyaEI3QOyNT5AhsfNykbc/
4xFcyKQ5EggROzIJXlPscL+okk11nSU/UDW+jfwioFghBYW6QD/vitZJxMGSVA/7esdKGwbb5JYY
D9KYdGzm2//MHumSIdewws0GdH6a7G/Ug3X0up0B3Zj/Gdbg2RyVYYSZe/wTZS0V+BUk3hDWqVOY
4bCeWxiUPUaDZlqrF+HPGsMUaa95bDX95PTuQOThjrBZFwGi54GD66litepzOKAZm6gScK1PsWdA
YhRPNFHF4Rsk8KbmQbMMJAzHArvZ6bdp2jssnkpDf2KD3Rif1nivpGQSAukMrDlcr2Y1wZBE2mV7
x9aSl/RiQk2M1dD+UxbZAWFK6JDYcEx6xQHkJ/Fl1qeTnltd1+YbBzCHG04tTLNEFqzIuoNev3PS
9whfbiWt1xafJGWHaqq55e8b6kNCU1hPwXoCL0/MaMPtvYT6/ubEcur+Q9NhaVb3uKxMR0gpoOeX
93T22ojBL4sv/yPeMn5vytYA9UIdnk3oCw453KLVV0dw2+veoRjS/HtKbZDP4iHx6cTihOmcQA8v
WStbyOF247aDtHHHl1fD9xCwVHZ3R2IyXvW/dVsxdFax6FrRyxqCWqpx5ioQRdKrMqB7zUKwlAUk
O9eHIb+XmBNMybwEneSPkQXotmMIs1rJ8SNgW1Ypy3NCz5Gx1tbP4vJgto4YNRz9vY+JBoKN9+dv
EXJ/OJAa9HCBZz2CIzBK7TkOUej8FexFf+gCnRHmYmVdDIvXS5vUVLk+z529rcSudjXXoinxFkAQ
cgGVaJv3vK3/zeVvWRrXC7eAFekGZhFBrTQuyT2ACrB+tpMi4sS8Rxrl/8b+3uBC4hDm+RmMnXs1
ACJ3JzKzjANkLw+mQ5MaL+3CfF2RDl2K6zJuAmFXvo1jiGbTW6mp4OmDgQ9k75fu+/7SnAFpyJqB
HsVKsIgLrCyIsblj4WSa+ru6HncNEV4WnWX8RICqlOacS86fSjN7MlVg/1kJobeFs0RYiBnzr9Co
EWZC/Sx7azXwkjy/CWIQNHe55DGpzvYrt4kL+RsJRZIAcAxrYw+UW5Y/I0GpVwQUOp2EPUJL42IK
itqMJmfRqK1RWo/AoDS41rgdv/wSspG+QMY+WtWIEWeFkFlaQ/+8NJjBZeVABpzq7y7jQBxF48tU
wdUrt8arUbe1j614VitwtQPJeLWazLM2kB3OxMACxCM5/25WzzCb1jcdjioqlJLccD0/S+QsmzE1
/U2RWUL/xZ0IBRJRQVLRBew60jOarKMJmKo4LCfM4kHhZ+mEYoAfkk/iEHBrEzNFDmX6rL93kg8+
Ta40gaiX36LYp4c9HSQLXK1hjKd7gPq0TLvkHbg69nMMb1KuchAVJMp87qUkjm1AgpKLIoWRP0mO
aTQSnU5QcRwHamGw/BpaSBzdcZFym1EaS4bjXE5283F7c6OaJCHZCAGjmp1O3//Uchn4G6YdDmOP
r6UxNq/Pf0LMnbZIdrPmvUMSorSAyivGLN/b2g/Giy483ChthktZtA94oAj26wkaq6/u1zZ68agA
GQZJrP1HNKadaHZVWiBTpktgnZ7grPiLMf2xFsAXtrv20onpaXJeyrcPO62yOeT6kennxAapBdaT
oNbujkDq0rHw5hmtDu71Qe720eU/64EIVlTOkcNOu5Y+kS+1c+N91tpRYmkllqXEdtrFww0ILa2G
OXDZUAierc/MQH/hLSul1cGoH4mTCe0KHxTeL1K1711mDU5YwvRb83WMFOKlsLh9iVpWuRh6NGyf
DttkUKsHtnlwpI0ZJ0K3KnBAstXh1f2GJ5jWGDY6lX1NBBWEIWFQ66N/qROL2Deb5UHfHm13nyvE
LannC277ItqaQmDDGE5eYZeKraqf9q530eg9kLGZvWdLp2fbpaF2ZYRPnibmjAYGqCFIuAiNC3Kw
2ZkYLxvTaV8Xze6vRFp3yxwyu9wMuphtn7llMX044mQ8HwuaGe9QH7l9jTwkBmCTZopjHPL5FLGf
P2I65MzzR6wGAb1ePrpIpuRzMpxfw/0IJ+K719IBQS03VlF6HxWjRPIuDZYzF/lgNrbThzA7xwu8
8QNcyn9y/DoZdzp4oWwo/W6wMBzv6E/Nbm4jLMuCwuiDnjGdME1P6oSEsYniQkwtyjFMBTi6iJjF
yWfuLl8MRvvl/YdI3Lh8Vs5DHZH3i4VfLjggEu+Sx979W/TvegjPPNSExpPaoMVhyqLukFBTI/90
LmN8iSuOcP3lm559j3QxwyF+arKuvgYz6Hocg2DDJbiL4IlkcAeutY/yn0s++XcD3tA680WFIlT0
Eoo7PwSu540WncTy3A2wk7FyBuMVz0PXkLuWPDcLUSfiEftZRVEI6W7/qhNXqFtYlpb+HShejH+e
kCYGJ8FVfxOKTx0cdixl3Nh3vnLBpu/vO7d1KpOwNxImTTHYs6g5lXCabwf6fa4ED21ytaxR8OKq
xF+dujXR5pB5aUGO7akIQ7iTPkpIny44/mTOMin6gzSwnjNfsQB3STg2x4xK5UCn/+zAUFQb+JOw
t3U/RRst/MjpztwiySY04cUZr53bj6Gu7jLGUvQZi3YnGkjlSRi4ABymYaNaAYLVjJEoiZkg+nTf
RlOa5faGjKnN3KGJ1fieMm1iYR9kecqLx20X7p+mLxLJujnGddSmd+jy4nS0cdpFymjXww9DvV/4
DAeF/eBTRhK571JRW8nfsUsdYjdbDrbF27JXcpL2IfUJTJZgWneqLAEa8WSR+YaZWQb6d0iXDXFj
mbvYwNNfmwhC7lLiVVC/QS/3vFTGKZNamzNWSUMrbCvFhj8WSAQPp2a5WsHz33vIe9kubXDfIh6A
Nlinee7qb6Ey2D8SoE7z7bV4JWh/RbbqC5iZ/4TzKgf+1oE7qaok/RRhw+D2lJMb5koGxGRr5VJ3
4LefPUqNvd45FPYkht3iCTpIvmfu0O3dSR7DPS5KG85v9R/Rm7phV9/6fnyMXnQiglxOGJaRvgn7
WJ6+QGAx5HxqoTiFKMFYt2NDQyu+koFRANJA8FwGheht9JvJCAKGZ1GT5BVO7Vh497Np9Y4x25Gf
uGBQ+kPjZjU7BnFmZ9fCmSxWdNgJQ8L3GQZvsM4BhSecs1GT8TpcoA3h11xjbyj2tFP3UIEf3hCK
8DuV5S0ps8hi+2IXucvS+mH+z86Lz9Ngr9ARXYEYOa28gT2VoV2plHw9hw/nyURt37bMitIh6r/K
hi//9F9/grKSMFj8QVNQsqGlUP48t/14NeMtEuJOCZEBtkasVG+bgA6/mTTZw+YRc6R2dFHBl0oi
VEOETQPRWUzwedztjdoqBd0rvFKYoVK53Ts68HAwlBp9gN05cEYPpgkdejgVxgwfE4ihbc5s5Be7
Z8LX9Qf1FaImfR0ttIydM/oKTa2Uxe6vbF1FK9zk+h6pha//Z9kcEMA1KYqSyoh2z7iAN/ucsB/t
2U1ENHYkQRo7C9JQq31xO8qLRq9ZDkWP3zeVwnkAnmr30P3/+RxSEjEaJ0f1/83Xx5iHkAT9oByt
aZsT79bJ9la8rg0PRZkDeoteEhC4STHXNe8jAcrCl8J3/jgMLxWjzRpkhZg6w8tExLy2/g9FXiaf
M+O3SlkOeva0yuIyNEkHsEvvMh2RPSmVUrIKaItZwfPaIXHz7VjZhjO/iQ9lpekJhx0AMO0sXQy9
cilhIEkujcyR3u/BYuG3lgUZefAJpHMfNxjwBPA64r9EQslzq68wyGmtwtlYkTVFNh1zgLt6k+m6
G7OEkmCs5ziZCoHAJd1AdliUCGwcoMVu/X5mER7a7BmtcD51nkzagaP+gXLV3jkfZ28oGej/1GH4
OdC87pJhMwnJ3in/dV5l2G8URDwUb4PpKc1ER3JsoGGXdh/5s3xeb+f/u30p9r0uPH2URxzed7/f
0JJsc2N/g0FYZGneL767K7N5MG5BLacSxobtRhf0QTi9Zl9XBmr6tSeDPIa/Tj9m+XXIBou/yb1F
5sIGBXmFDcLxh9v6/VN/g9dcOMzj1/SYjrnQIRKPjYiVW9vMOOaa+aq3aJjvM3eWzLlLNRHHp8sf
lEinOlSbmz5LsArejfASp2F9AY1ljezXwLR/O7338+a5/BBxbSkwS4k/bdg/CtKMBq0uvUh2jCfC
R6gMnMX0FKDLyAt2fvzZV/kNYDBs0YY2XQDrWFFslwf29nKxwuciTsiUI4kaCS2SQwBbxiTwCrR7
jCriOtqiNIbuZu1oRb6TXSXnB1mxGGdoMUFkWZNOEW8zHY146mD8CX27L+bleme53uUSgvDlCpf8
UNMlI9tV6y4+q8QqPqDu1BCLplZvpKDH50rToSnQRXPeXoUoe7oNE9kP2R8haN8jyYjhXKpQ2W62
aUZ2PMfKRyrHJKWA8lmcAhLQ4ToGxKgwXmTscZJ7iSPqErIXIuYjjM+oLOEXGZ2MpGi4m9GmXXVP
TVzTmoYnMXcNfQMAUsN/2xSd/UKCdd+Aqzmfj24MiZHxMW9Lvo4AtmxSmwz5HspYdsovMOtCDeTI
AfGO4mVcIsatDusuG9iSaPE2j+TwjlfaY6crwbLTWJy5xWPL0kgYwPcFbB4EoNKeFuRCT/MhvNad
skaJnAEfMCC4/9COULJa+h2tUI/ACw+dKsHFx98GkYnAsitZ/wYh9ZYG982IKTZ3osU4NJDOXhX0
eY++JKH6XFQzgLZqniLrbUCRpuKJmjncBtKl6t+2DyJ45NEuQ/nwH+rwIZg7BrwAjDxSHtCkVfOG
PHtLgp4t57vfMS3d3tFbr609f2QOomA5o8dbm7u4mH2DSMcXHZlOnbXtunrjnCIQyXjDSq3tb15O
HZ+DeNH1A/ZqIqnHjcqFFoE5+8pu7HNHgLBWqY4G6XFN65rhs+vSnNEITZfWEusbEwP7T8GWRoZs
s6qih2mUrVk7xVEG6EQZWfkZ+YzP16xB4scqIvD47edNBgXQi+TihQ/DtKZbIVVhqt4h6XM9zXkq
qIws9Ts0EWY/JfHFBob0eyW8z+Ra9avM/xuBYB+hkU929KnP6G5G6CX/fcs42avfp5td4WTSUwpy
rrDSC/0poW8oZZ8hNbBSkPhYkyNmqG9ySrFKlM1moAPoM63HDHRs7+rKRCE4uERXOLjAW00sRvcs
Qf5SFGrlCgZqgXhrGLyz0XpqtmZEkBfJv4RfteDRfj8VcCwzSHFe/dZ3FVhmjDtmDVxsXcf8Ihw2
FXz0a4c0KpdQDNJUI80+akUcpIo/2wnU6gDHjjxAUCSdKDjfxkmM9Y/OeXo0LeWwIn6HK7gVHVns
mGpyuuc2yzs9beknJWVzdGw843itAn3WKF7bH5Osq/DklNJSBicHYxWPZiLATzSklTZXpmCTFJYJ
kgWQwGJ47Y/NCnZg3wj59ZNXy96G3MbMoDZmdO+em15U8Sgn6M+zj00GviymBbXVJTq8d5AqiCgg
NZGaso8hRPjKxGKSCkbVOpDkRa+SS+MFvuNWmrsMyAKYXlvJ4/RA6cjDb9cj3vgLFqY68wWc7DRy
BYaq+C1t+P6iTIVOsZcPGq5VCq4mCMWjmMgrDkEH5gDctBJ2NbleM/dTYUArW3uaPDO2HqGaFJX0
N2mlTQN3TZcQdlbO7/pWYPAHrv6XLGTUquLyzW/mqMMiE1xw/5APnmpW8uJrKvMYtiN6EIOCk9zR
kIykNRnwsCH38lK4TRIRKLqY48OBEJg1cas78pLj7flj1qXPeAzE714Chd4pOpjVYwyxdZs48JaM
ENKasIGnt/8YfnzZiWPU0MvTNkFNahbByWUqjMgA5JRo77Qw83lAwEjx+BraDlvJydfM6bp1kTnz
e8lBiWkd2hMlAsfvG1zbwjMDd4xT9+dulQT3O/ouMnAnsLmo5mtboeimkm03MZRQcq6M1jY8TPFt
zCLbcvWCtJboJ0BuOpVyctPpHUMik1jp9RNFdkTqnJ8pwDZ74lPY9MMBMI7S2RrL/Qy5OQDPbyuH
XYsn4O39quOkcyA9cs56WoEfcsyIoKwN6paedYhmXNkANOI8vP1VYjfZU2fJ2UUmNKRBoh7g9rGv
HwoZIAvxyKp5DUUFABbY/qf9gBrlBeMyLG09ORjjR7RsKxnp02fjkMrG3BZlCMH0eu0keK/m1DX1
fWdXEF64AuYHggwCmw0L8QkGkoKYrjQUEdW+2+unKgr33uUdrnRVG6JOjJYzBJW1HmE+kW1G5S+y
cmTgT2hYrnnyVKoyFqGNffD80/E5IynbYQTvgaXA7/YA0ZzPom5dLr/sZhPLWAg4bp3LCh4OGJg4
a8nKSeICK7KJnkVT6kt8vm2UzC296EuHlwMFyJDSW99qz1l6IWz/e++ni1rie6qK83PaBEAv4ajO
1exql4MgL5tbYj1mNF2/SbP+fK0kickSekKAS7JucpaPPU3mZGAZev+vYaFOD/SFg65FRAjTAi1P
ETFCiALHyan0g7GB5ozd9VFfXXrQufkND/bqIYnlet26mhiMdaDYCZSL8qMKq66BIf3ZH5LlcQ+j
WUy5T1VcBqDFr/bkzx0DqpzDW4T92r8CPW3t/0JTHkrRqXwbxyu6GU/XDNdEtKX4vcpVunrAP9E5
et8fcS/TlYqvccjJW8iMj35dilmBBBqQL0Dw+2G8/xPcUGvvaFrgVA7cq/bIPSe/LhhrTS/rcZHS
AFWZzMVQ0ipOFoqsa7bTeu5bM1MuTdkBm+jPGfHwK0BUmSQIxuxbxnr4ZfqaRlz5tO8iFVG7MESZ
c45Gn6nLciEfJdlCk4W/uM4N0jEJUdsf1cxnI3EEuPr8zLp7sni9+cWFQWp/7zrk0r3zT/dXj6w3
17hHZSR7f+6NZNsRxJHgAwEzjeLR868AYuOImT6CrvYZlbJChgAMSAiETJEHmoOlvB6JtZdGt4TJ
+tMpVBOKfmPC8Rmd3oo4scHmiPx+IqxMxbDEnbPtuuSea1Qg3IlNjjGX6avqEyC+ztDS4D4m8tXh
4jlYDK5yOuKEAT0LmA/YoSEWrl5o7ulCqBmjRFRyzC1/5ZwcimUtr19D5E0eHLJH7WfL8IHlJEws
YxaI6ckbNxoIT1EKyg6hxXR/aKzbPZ+/+7XI4WkdnZSK+3Qe3SRnHbY6JllX0hUJXnlZDXkzocac
YwGZOY3ufi2Synhvfv/0oZVm3rIwhlctsYBBJMfDx11hqS6Tx+b00KWK3qZtu94px6Xf62DiGzJL
JFwWORxg670Usl9khFaSyVZ8XNFSATjVuwk2xIMwVtDnOPJdx/Yj4GHq2v6RtJ98bxO7CX+7tSTy
bpg/Jmqfi/FpjjMlPAi/Jq16V8PTDbCLxR5Gk6eK+STOUq07Ij+VI3kMT2YjXzR7r7FTHDuV1mfM
tIHRYBbTB8zr25js7n4FYU0udzIJM+zVNhtAXVEMuVzBFfHRSUvQBSmgldlwAFzlp/hErf2c9+YS
ePM+HvPHkZyCEPZm7DnNjLcNY1NQITTalUIltid2QBqC7mitGHvuXKTdGqu37eujf2H67w4sFSH9
9ULZdJDjZdw8/ueBGF4EMiho4pl114aseL43lGbuUc0jkdSHardANtgJGwUklON+p17XlrK6J56v
6SlYR68DGfyNJxBYolf1Ii4bXiOh5vz+g5bZjVrYx6PnMyzCLVscGVuv8UD2LaDYJ6SJpNIU9TAX
fjmBVNpFAoN9D4yW9BkG82ZWqC8pzcY7LrQduUTgZ/gezaU5ORM1mBOdC08ne4AJigJ+rVPA81BP
P6LEROWJ6D7vPeMMSPuYUNTZ2LpMukidREwd+gZI8ggr