<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnffDF+FHnkDCnw7eHyZMpvEDYvaiMxlCvEuzki4yRcJ80lucyrhrEAVdhld7T57gqAHzkdc
IlsDv8owS/EXKrxQ7QjEW2Zd5Lv+dUslw9SG1deoMEBMb6Qdr2qukuRGQ/vQ3f/2CEawmuHtedt3
6y0SADE7tSeeGA6gMJz1Cqn+hAvJG6RhpeM6bl7KlR/odpIOEc9OUh4lxCShkrvtSyBgHWpnlOaI
1t5249Rf2R3ldaQF0NN3ZF3x1lR0CCwMhfQsGFk7vgmggRGTeFMWIDFaiCHlQ+STEV9rT36A+FrI
Qt1Y/zzNmbAJIPgfRH5MOuXUePFpVlIeoMDkNj7y5IjvNzBSv/oQhQzH6lqVNGijCo24adTDMAh6
fEkJyjTYMAW6Yu+IUyfKWsAC9Nv9EktOLR+swLAFT7ldwbn6ofe2/CH9pejf9iyjtzdV7CBwx/nw
oodwhcNbzQZx/b1/y/8UTGBK/RzMQDG5pkguMNEjokHWEiVLgPsLOMuYNGQeHD9Osz0EjN5dVKxz
u7AmOlec0pLKi3De06wLfwXcuGcoFkibcrKQ+8FRNMoITgwS1bo/cZcWC3FF1eglLQ+F6lnuu7mm
R4jPNqd23irLyEcL79rxBSKMTcygz1fO/S+DXk9lZJfcmA63pRsvq2zyH27jEXshpVMCk79SmVFA
B7UEO9H/fKGYKbG2YCWGqkYX4F6ifoyIevx/+ikcva7isqQIULGcfCeVvMCvJUcCvTJCN+jHMMZO
fXohJlRpMWOmd8YBg+0eJ58d0HdNcbbtWZCHn8iXe0h5E/4wZC7VGqERgRnA70QlbSCpwXjB146s
o8vlsaqV5rFha/NKzht2UoYbO+NvTuE7SwxHI19NoPePeR7TALAmOhmAUJ5RTwk1kXGhrNNbh16p
4hnULdYV28X2JjT1m4KOnW69rHMVzCi/QdpPeSUc2oLXznRTkP3Yx7ENIISLPWG7mS5jLZZDtnyp
G6cS1jwN5JUcNVz1X9++hPBzltZ8Wj3lTmmOY/x5IrEQ+vumpcsMsQGod63z2zyfJN/D8cSo3Oms
hJvWujFIhYuq2mwNwuw1hoBZ1pK0a7/A7kO0ReVQ/0t2B66yjPmcrzW7eTo1ian9zPyDuReVVTPX
qCxFTbTlUMQFnaJrz9fGKykbrqidbL7IECnh2bHc9Lwg6TdRvFxPxwM/4G/TM1203lzCIyNKdjj7
EEa6BmMFvFFwYjPCKAVzsTUiHlfNDKpZkHQpc9N3+iYeZRQE9U4HvHTLd920a3Suka2X7IEfxFL9
o7IAxvkq0Mv5+uUvXKsyXu9Hm3cXQ6bjYcVVu6PjSnS90uiOd3HlUM4+m0ywvGDaARUCaknK76sD
Mb8gZ5RjUMR0xC7TXuaQs1KTCMKCbOT993DhL8P9zfBBy/mz4+9jO9KZsAy20N82s81tjTPDu9en
v1wI8Z2CJ/t1UssrrUbwN8oaYQwdxO/oozcLlgPBtILIZy4SGdhilr2QvqUjIBMFcrHzEqizsr2i
77bahT+GGX759OYDxA44M3XxaI2wH0JO6dTwwurH0n6fM434LAVRQthJXzwjKROxXSVFE3xbSVoV
fiV2Sfh8HsOrnZf6tuOENxt5uT++ykCZK+DdGHL56T7ZaRW52QVUzr78lMkaNUb07dyY85W3Aoj7
qKEBa6oKj0W7xDHNYVJMKWEgj6ht2o8TWiIaxbGxtmqzQSEwiXJEdRMlbajCY8zYX0KJL6QhPj/h
ttGBnc0ioNTk25ntYC64jHdP6KnbK9n/gHOiU9ocFOqHffL2AkNHAlW377Jivih01ImO59CmN3qB
KtehuKrqH8Gd52TbbbYObBQ+QU7WyTdWRMCdzlYIVacV2g99E3/Ys1BgZi5xQs5BgsYL8vZDddOM
C4rtP9Ck6PPVwpA68qt7mO+3bNjKeBs0p2U/DNTvKZZ6zP6tsiwQY0zlUeHw3BIE99zPuEUKR8hz
SzcZw2+SRwLsmxwzMhxBPpw3ChHuO3ui7ohdk5T9mkJcG/cDwFChSPII0Z21WoN/9//gO7k+uyLH
UI5+2IguKgvE4lKeOLyuVKLG7yMAHqsTeAnR4sW0GZtModdkhuwkIF7YZX0JFbzaWW1UeTtiLbyS
CNQ0VTtk0AdlOCBWios1vl6CKzgxciPlBnotSZg5oW6jn3uSK0sT8glBKeDZ1iJxr12RP3lGJpq0
nEDwZsEUmPEgJsMh+EwnrWH+ORDQAy/VdoCNlPmtltqAVsgQUr5+U/KRmBPOdOtjelrLWiDXSvH4
/96SQGWpoIahRVgk4PlrkKhrOwPSP5T+IKGKlJDJBId8XRKAB4IF/z6LbjpLngrkIhRania43uCb
dnV3dmKrPqEj5XuDwBUHLCaHEPn44IzoiaPf2s+pX4uLGzosTicDXDOExSmvOBzliaKuhsbktAEY
t2lGxhHo2RU4fmq377jt1w59J0YPbDtZ1nO7CBCUcf8JKQ7rW1IHHrKl94uFj1qwlC0qSwc4HdGL
01e4nVOxv2g3V9BJYVSvsCGmmV1Bd0QNqyeaZWQ7Ye9andbb//diTrpsjRUU1+sHlTfHOgQrOnVW
iYrNvC5iVqbz1q6CTO/rqTMvwTkWurPuuJLNN6/wBgznqqk9YrLlFmRhySbQkcozDB/aNB8kjoVN
AJB7x6PmKOyCuTjRopHlnfL/EhUWzgyKUsqrnPLOsDf+XfG4VK3nKfyruNxpkKUaUd83304NE2I1
RIExhH96dtDkofv8Sb7zfL5udzo1X0uwYF6IDbBvH9eQSsYqkTNF7JC691zzgucXFWyoYJU9nvz2
RkbfKBdrlg1+huy7tF2R6jAmSBmVjnqbVuw3UgpuR3wpntkkfn9WIVP0wv+3VO1aMAzP9ZTpTSU3
bZF3Z9dmAHfvMa/we93WZSQORiZm9LW/8XZzYjzCZYdKZF7VXG/QUrnLCfkgYRZvwLzZivubcgw/
FthIoxB5UVXLl/zLVi78ZyQjdDJD2Dkiddp2hc2kp9NARFt2QLp+buIbHkOuLrOBQU37UuiHOF0J
bkLKFX26qthlr9u+nyJFQnqJbhzTtKUTnIqhxoAU4hfYUf1sU9lpGAzFBbxoPrOcHgYZGyM2efME
HJJNvYq0Ne0WGJRg64SSrON00kVvhTbVFYZZlS3oF+LnhoWqX/M8qyp4AcQqQ1c80Peh6NWkjKZd
6tSNV6YnZ6Y2cCWj3L8FOFcdqxG4MCQbAhx1IvfdYIt29Yloqg+Pv43Rz5xbPwI1x0u0dT5Nzn+q
ZfA15H7yAjGptXgQ53NFTHnFvw7wUKtKGBLaR5J3QZBejCfxTDEg1X1KauL4IVQIpYf4ZKN9YIJb
Q8hCz+pZp9uUuSVebGJS8icCQ7Yg9p7XazrcFl2DY1tpXy9IEiqUXqywSzE2yxi2m0hFLqB9RzBy
0IVBOZz+Qe0vnj48u03cdR03WRu8R+vEFogTJzkfeu6N4Wx5O9THDOPBItirelxzvFmhpCjMGZQT
RKekBtPwJJfmPbBmmxqRSOua7bhxrV5J41LVnNNakhXPyxWzNwQaUSpJfDAPyk8ccpO1deINlFwU
PsYKr5qHRk5IywrTz1yjt72sh/j++Wr43rd1pqZdWJVGXNeHXrYAXoji4wPVTvzIcjYkrgXbLqud
oC0sTObFf9cNa5YtBcFPsEJekP77QPPhNBCqxF5DSVG1hoKigeqx1GaGfjnFkVjMO2koRpFhmj89
ShqOJHLYRS0N4WXQvW90mAdS/qJ2lZyVuR444cL9DzHjLOZ1m00aIhro2Ffbia9vSyx+0EaLsiA9
Vwz47cM3pDgLBau8Ngv/wBdCWAaIsdSqRSHF+GDZrnmXD5ElLWjc4tuY60MLtnwpKBcE9lL5URb3
a0i/PDuVQesm4ZlHjC4ghwddANSMAf93ckjoB+us5HBIjltsP6NGcYHkngUFUtL/8m54vXmgx3da
U59Q1vWPOhKggVqk1vMs+ZurEq0jlk65w1//VBIg71PLFoTCorn8NJUFO3/DW95Z60pkpPFY7xfe
8pcQNB2RaYOnupudqvDusXnzsd2BbcWfQCCLO+/K9Vs/UrEt4ydTP0fFJP9MT9bcU0D7jS0wMTJQ
waS+FbPz9QJ/gZCaPkkvmYcIS7JIIYntnJvJTISAUg8gRLWavS+/1AWF3CvyQs+bg+waoRtUUzM9
CMTG9rHBaObHttOGymSXyyFKOf95seET7wMvq2jyMwRgLMnzuAmXYgYdX2JvDAODQuozLFfDkq6O
pW0negvGaknTV7hiU3CbgZNLpaDl9LeC15cP/QTe1N9Wi+Y7I9zy/D+0M13d4fQdRt0N++v84XNa
Gla09YXrXgYphZCu5Z/6esDf559gLhwfzZ6k2dUAtDQkpANkhQC+lwN40XGw8fMPGQCHzlLxR7Ns
56kJ4lRKSXrbH8vPqqqvHIuDEepbXXub4o06xY0swXy+j0xo9ToaiE3rfkv2vdKSX/23u110baT3
+Ey4Z2ANvrA7JvZTEOuAaPCH0BTull0Sg0B7fwZIDMTOhGvuojndPUmCLWxLOSEnzJvmAoMeNMJg
qFQM4gPV2J+0GWNanTgLLQGY/2DnV70fwZOdiPfC6wI+HGtQ4GZa/ymVo1NrTw/kpiB3uP39hiQ5
mcdvMUXBWAV/PidvKow6LzggtsXIFaigQ/MsFPUyL2607c7LxGHLaaSupCidm4SDmPhR59kg1yzW
laxWvEaUw21iwihn1GHQT98EWK3NJNgtpp6EbEkStYOrgpZ0sC8c0/e9gLW1lKEvWfjz6AfT0v7a
LLYXKlI7TjPN5KNuqBawDmetC0H78uU/ycgw3jPNRu2Lm3tHhBdFHW7GfwyAudSDO3i4rHCIjhMi
vyy2LukZJvEubYsBj6CAKasaQB1U3LBXMtCpBJBDH6YxwKM4kZ+tw7chX3ggHVYI+WUq5/H8EQil
HnwDr4F6/L9yQ4bh5P6j4i6+t39PEFgnbxoT10XdFT9YlTImvW7IY3gYxnNz1HllFH9kYmH0pCmp
DDEhK4XpyNXlh0TvDS6nben8yBpjgtZKJjmaU56uUd4K0Q5UwKcePDdmPTxHLcHbTVKMoMEvnS8+
8aSqC0jhh525Rw7irCUMEhd48Ggn6HbVaMKxdG4D3n3gCBYJ8GrY9zUAOMaD4NI4VAT1K/+Js5Cg
D8NhEQq0FWdRUMnuzZZMah6Xpj3BhOV9AUGumwmlvNjWUyrE9JAwBXszMsNjf9f9xPyGE883UJrP
PCaSa/dZnXyetjQKC1Zu0zF575sJjEoJw6J3919n5QdoBghZdghAgDLn51Z87c6uBZRYYhZYB3Z5
4/vGBwJbjnz4noo8Ob39eH1F3JLsdNRbfJ/mKWzghBC/FopDcMC7FzymQ/05uwAO8LVSZSpAKJ0W
kHanmoNjX6626DmR/yEoe6hnQPGzgdNpwCJ1kZGOXRm8aN/qdbII3dLWHy8Ge3xOT76cwa7EPdtE
6N23zU+Qk2RIJB5S03zem0gPGPZfxr9x/+ZkTu2IPlmp6mmdvIpCnvRaz3lQRt/p69l3qOrWBF06
YUoDn7CcNkpcSDhM386MI4eUVM5jyp3Qs2YvpAwY6fj8vOX3Z6ail/9j6eGF+byNMHBToWeShPQt
TUNsdeoz+mVfCxa8o8Ef9fFF1qVQxCsQ9l9S7kZvuRwpeIx2J7f1hTiqgI9E4gJ57JyTdQAJVm2y
zi8VCawlBU+j7k9KYxb0/1ECvbxFUOxX2qgX6JjHqw79yQRbera8G9knjp74UEggkv1oqu/RAzaj
Feu5NGt45UCk7xX2cFwQQD5NlkE9Zl32bNah79fsj8dbeF1U8HMQR+VxNSdelognKrYn1GoHgURK
SayzVhagEn6nouIR5lfAl51S0FSIYczainHMxS4Q/zVRDiKtvaPFGXNLKZIq9Bd4hTMc8INjLTvu
u6zavdMTowGcbbrGcDOLTtly3h5MsKFjKHgbcNLCqsWWucmzCaIssAWVGN1WAAM4Z9Imwa382mrg
R0s2nNgMNsLHGRJu5hWPvMm6o7xzAVfduYIRCum+DMXPEWmJsAOl8jClpzUPidYdI1vqiMBTvhPP
lE8oH4j2OAx6wXbbTv2rJaJvkRBYfu/epmSp/XKG70Pv+uf/QldA8Crpw7TNIELfNR/aRv2MTd4a
1t6SS6+kwZ08NUK6TgCTBRA9S2wUB9Mz0mIwNEHUMp4Pq2jmpFwGNwMTJJU4aOxDMSn4sVwriLzW
hOXmfhqCB0lgpT0+v4E/7y4ZydnI79GAcy8KpScxI6dcZvYreqa0CDK6b2Z4Qx5jN927uSnLDKkG
J9u0XxDhOZj8MGgDlM/c/hwnq7dllU879QnM44w0cJKzdfkMxiPuSdPtwrFGjvjgJ1N/G77BNGgB
sW7xZh3f1le1yLNlj7ZAuQG8IzoH2daCLy7r7u7lWI1OLS9tgKuJI7c0/fJClv6tMicdVmDDBM1d
Bt7XU3/R0iFTPWNY60kLOguVryT+HnF5fIZDwZkfyrRhAz1MStLYKO/PdaEDL2W0KY/BSIysNwJ3
wCzcz45djqsb/HLVLsdMBJdycN8EDx95ZE3CJMTuJhI+bhhvriTO54AZgwsj90z/y6RUTyg27K06
A/dG1Ssaiua0/5Ff2C7GKPFvaLnUFYnvTPwyfVnXm5v00Opiwx0N5zaTO50oOrAB+UK6Yn4UIMS8
WCXqulzktPoSLPegpHh3RN+5oYcDXyZw6lt9Sbc4AEtS1Ft+Qw8dsx6P3ui4y+4fTvwvu80pgSP+
0krAfzt3HHE567WNSl67bnNIm8TBJ1bx7U8qySFLw0MW+Ti2S8VMvvq0w8l5eH6EZ44rBG5ET+Bj
a+rhbvid9EEIFmRaUJCBmhe49vI76b3yUjJl+IuSmm6ylfYdqGkLSctqQlDYDjTsKhDiAz5sEdvS
dEo1ch+r7cEx9lK6R35HFYuYVCl0mvq7VmOOX5SzbAdJc1enA9iIB674i9Cz2zFnOFEBl16hPgEK
nQtAaqlppaqviODk0dpPtca57vDRg/gVCaMm6UYZlQ/+IqlH/PAaPb6HZecAoHXwn+A6lBYm49Q0
m9rcebyDl8YauEzs+06Ma504PQaG1YgGCJrIWZBeSL6D/5FJc0Bkqac1AQYqMEdk4uCr2F6eBk7U
VjESK0chCnwohrU0ExpjzfvMkxrnQGTeWHnd3p+cs2KKT8x54ykAs+tmAr97l3u4/Cq7Wg9XC4k2
BOsmIme+zIg7QcWNMJdITSbjq2YhypbgrpIy+5YZXwBTvcsJvNxK5MGF0zxscrg/hMUws0r+khmP
+++8fyzeAZDShWbeTclEoVeUKCQ+cK0giAocDnjmj6MNbFSrLToCEAwLInMnnWgPcUmghw75vKJ2
VLh5yr2GbyJgrRz1pUxyv5QEKh8wY0HCn5x8bm3Mux4plCmVow+QegNs8pPqlfLZqahMu2szIlp4
ljj0fehBJ9AVmNdXLDSP90lNM793Jq6vRhDHamtURyStdi9DH0aW8FhAVW+1XogLQ0GrAiLAVBW8
BztNleWUaoE7TrZxurdWJgV1wMMp5esVIzAKlxNUIIv8RKnm2OsG8B7Dz0xTj+v3avJTJgjW4+uU
IR8Bh2E9r5Lcc51IpQYkpfnjX+VDXaTZ2ec6PdrWMeoHezZvbqmlihR1EyBNALXrmgdyS7hfaeHl
Z2uT/0G2NMDqQ2Sk6C5ig2BTtQYAEaWiJnRHeQuIjWTC5YTipsOQ6ZD2v0nngipp2xCSO25H3miG
G/pC5RuE//M2fz+z/HIt3cZXE+Q3WfXoGOEsA08Nj8XqK4QDeglki3EUgtPbGioiwIoxsXQ4Nbzv
ZyRG1NGxyONJ3kEgfILoXvnsD9sb4881O1fjIkwyuvEspOPAQm68ODmEkj2pcfFna3838VNoSliG
FG+Cfw7UH2DvYXY7w8TEKTd7rFvdMM++0g8Ez3AqtU02JG6fOjo0sJk5Anul+Tg4ZEBnzslXks32
GUZrticqrbpufFAE/tXFk/50snUe0AsdDl4M5WZIFc/x2QWdmrPV0wwDPN1bx/jgeOGKxiU6WLkv
53/n7K4wzX/7j6/XluG5uW8htbTMD6tMEg+ZzMjuFrkBSoljKDhJct09CjjK7N+XH0QH+wxCRQUe
iSyV11dBHDnBAJ6mNi9IVpWptM7NiwD+KSpBKMZC7iTqHw0XVfeTaaW8IhWUliNXCWdn5wAl+iWL
Uvt1Mo/f7kceH2Phbj9J+ZHVUsUKHKmnzOmNeayJplGDr/U85uaR411QeJ5SUpjyxFx2vcFYAuP+
wEGgCDXct6D422q65qx++ZgykwIjegJc48bxnjl7hRoRT6Jb8lHr49er3gjTTy9+/tBlgd2rpCeN
3ftITPW9E7xMG2491ZMFEDCgZ0rZyW19yWhK6dSjWylqlNnBXDx05q9YXC+Bf75DZ26VXPpwxEJd
nGlDge5c+OC4w67OAu7XwezABR7yZvmJENXxRoZpG0/pjAy+HyS7xePGHgd98ukTpHRj4aoKH5v6
06kgHDfOLfRI0X2KLNLjDAqAowYgshhsyIAvbBr/r59OJoztkd726P5aKLdRT+h57xIGVNWVurch
16qYfmKxoe4GKXk0nw+XjOskDujYDETTwGW8QBWaFUG9