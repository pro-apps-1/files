<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxIf9ZloMvl/muj7inYfodRnJcJoqCt+7y9XVvxS4Zuh4nUTLyoPvHAWCZT5mRIEai84MoLt
qJPT42mXkYH4bI5KJ7YIc+BPt/oqnBw9Wy2NlL7oyFZb72IE6oSGAvmB4Yv0a1IRC2yuNKxYWmKw
EbGU0mNSmUlJJpTVgBXMbZULZrAf49BJIXRPkWhS+1jIPE/1URJJaaXdNkkeDOvJgP+jmDArjpBS
COPYrcLYMAI9ZQ308EOHN0NGsbMEqtvdKz33Cddcw3OBYl06iL2goSIbkbaBQQ7voCrjX78vfZIS
AuPzIp3PVWekd8d3vB9At5n9g+FDuYRtmu6aI6e9oC+vmMNaisxVWeopcmFiKA2iuMOG56+BwNL3
qsFfpRDPbK6MvC0uXECXV7fafgZNa/oif2IcBpkaTJxiVUSTAalh+6hqdUY6BozJb6VRbetmfgFH
l9FPXhwBQlpn8fNWFovz2/XSOmqqvs2gasISd3r3oW7L9ZGKW+MuWxnP/Yo0b87C8L5uhJ56rF7u
Cp1Ndpes85BDv2UIJobIgkACWv/Cu2DvVBqLbg5BlyB2fPSaJS56bZyYEgj+zqnT07l/3JYl/Wu3
acpjlDE0HDhrgEM09rIIeZNO2XJgtG3plteIaHB3KR7pi51WHxOY0w3f6mOaAI5cp4oj9FSQBusP
AmYJyOXEThX3xlW0XG4eX9Df+oyix6STTGG+76nlXBysTlbWFZhOxWYEY/oavfY2saVJm1gIVxOM
eu5D4Y5Iy+60wVeRNYFVYiJBI0PWVNbActWvYNMKaVpSA7BKTfF4TRpGz1IHQIM9SPYyuCXpEdKB
e28pEANxPLKPqsj8ApPbaqTFHx3ldNSScUfW6P5vBJWJrktvI/kMu7eNPTXFQLapXRvH+SmnPhc+
hXgzwQcgS96QkaH6RyOdE4jBzTMQShwmtYpiDrMHZC+T66tH9Ksem60f4NMi8d3+qGqde6gy2+nR
7UDEw1zyEqTyhd9gNosOGFlwoEyiS1NX6tzhPat5HCsyrtifEI6sIAUSLklniG+ipVVeQdEuMz59
v80rhhs/xNZXCVGfvdgXdUY9eiJAaF4ZFiWPIfsLZDONtdsRoM787uXvapLXFxljHA3//XoeoaUE
uK45VlxjIAEmBBFLgAOaQGORTnsVaaAJUwM9W0K8J5ED4WI/YCY/yJwjoKEZKT1Th/LDosjdY1y4
eLwrAQZz9anA7nyuyznNT9Xo/syjuZ/9Pqy62HJ+OM1OtIFr+V7PX7aEBjwUm1fZ3g41pCbtWJ+m
GAtX8UPGhtE6BjPVEnFFbfJ3YFcZnTqBZzURiBFSIN3adNDK9PZgHXyznoFrI4xAZd54Nu2vzHl/
Ll+Nm193VxhMtMRK/OwsS2S0mUhEURugsviuXBrOyNqgYDoAO9O8VUvaUBH1Ww9t3oYKPXGRzd8o
sxbz7lWqm/cYSBcTGvN4o+8h5wAJ4yUPg6J5yVH4f5hQtWcRpTx5it6Fi+sL8qyjvAbsNtURjU6k
2vC3brAiAVZvZGv7JhsdmnR1M5j2rS+nnpdZGy3q//qQxW8wJt7jfvNCOjNGBtbb86+ZbArl0idD
0WINTUYV03R4Hue/a8yDfXs3po2i0pkEXerIYkwy2QJT8iomKoFXIIDS9+HM/nEFEbLRaIflERU1
qc30CqKEP04h2LQ+rDo0uvAe/1qHBK8U2p1qEsK4RtYV3A8d6H5he/IDj9Z4+mfmyrm8piFCWAeF
Rep6uI7nWBbZw4B4dEXRZUaoaYGcEe4DYtMHEUzauAsmWt2hkZlC+xT/7DORplVuH9Q4huEAYm6j
6ua8NUjALQWPjEkt6SRyNi6aPGS+AB1hxhZd3OHXRu/LVje1CXUPaQUANOxiz/6DVoNwMdXvPFkV
e3hHb4cOJYSsdDzE4vpdmZUGC4fgwjtuV+zFdQ7JCVMwnqi/UuE7KLQ96EchIe+14cixjuImZXYl
0KXcPgTK9jOJB3OBzXjgmiyzuesxm7ApDci4XIX24w+2mpQFoGpK2KleLHVK5Tg5RTaGdyjBDsGW
42jJt57/nuVwBFtvgu8ISVPJy1UNGGeZOqlKVRCQUVx43RHBHRVTnt1pXzd88FGhgvQcJzr+FnTh
kSViGUnIDKmZqvPopJCXdkC5YKhuGgDmaZhqEzPH2q+aGAf8bWR63oFiXVOOoNqMRlg+UE7OFOiH
E0SBL2BsXs3Odo6BD74211F1mT9Yred5QcD1z+eghgaOH0ysqA2SqmdAQof6SiW+q2Ns0LuzC2sR
Sfchfbkc+PWNTXLVzdgOs8JBHM5NTKSw+Z6usV/uomAR7YHqarp33ZZuBQRHdj77UPTRaHkyp304
yJ6VsUhcMIoC76HKWj5JEtdTkZ/Qo9bD0GB6R6j0yJwBOA2COyApjxbAsA3l3q8etPntOgRorLG7
KWo2b95n0e0mIjGlHUHUgYXDulUFgBWaOtVM81N7BpsS6pqhy7mUUR97NfsyLVBSN292vmjNFhJv
Ov7+cfR2iY/yvnVG3Ctpz5epMpN/PiiDtJV9wupT9DyNZz1MqNjWdZ2qGGhIZwrejZg4kiKm/0Ja
DFq9qNXOTNYY8akdQBIRdyvJgu14Cht4W69IKgR9nZ1FPUmEIE8q16wqwtYKfN8mF+l45Vg7ErwG
9fAp9Xv0rV0qTbvuYZREmGoamMREP/K55zkxk4MoVUfiUVMfMTenhuB25OQ5u5ArCsSOWHAImnyB
FH7NPK5Q8UYDLp5OuYJQiuUoSHm+GLcZNV4TZ9g4L3Ueavkth1YHoyXDIqbntg0LjAbnRxvd5GYc
gkulQ+2obU51TOmzpXXsQutYBb1s/3PTJVFS1mxZtW1eybjuKjmEXCRXAX0k5DSp1F3yIqfyvg4i
cyA62E/7tRLql+p5OL8Jr3WWpWbtIlV8EgiZeBNNmXCKJgZzYdx2b5GtCZlFJYG0a0fnwpPxVT0g
7GjTJwgHlvRwRHXQ/F0RjqBWwXcD80kFhFLzcA79SqIlWDHN1XU4BOKaVhu9rOAWLzI9ScZXN0ih
JaniEJEK7SWgWrMOPKySLmd14GRbJ7r9R4cdEVLdMKTniaL35j+snAnWqIJ/VBv5olgo9J0oIvzH
oLU8A9DCBKYsIRs/ibLabPB+cx66zAdPoh/ILln8n9YFJnv68oRBzOM3I7ci9oIG8J+u8iFyWThC
tj9loBKp0LrTVT1qnTrG0twb0eth/S9DBgRLbXpT8LGw9zAe4hn0Tbfz2m1kvYxDN3TMgfnPhtaS
y/Of8BWiPHRhP3lrlRtld6OTavmAbDZveHQoBouE0IaclFvYPc8O5iU9j6U66ZgdY8OK0bGhxQIL
TQ+MbcPhLtOOQpXqMY1AWJ/eJ/XORF+EG1HesneMrbihLLX7eWfVvk6AbVePx0EbmCne9ZfFFU12
yqCZM0AC6zQCx+AJXmAe4N4WYouaJDMScWl3m+pGPtoG229eVCrMEo0nyUanXxJZVrEcDIf+xlqP
K7/MpcMtf9wgPhIQJUa1wOfbXK01wXZRY4oy6iRbCNQVTOzzsJQKisR3ZsfYWkDubPoOoBE3r1V2
IujAwjEA59MrcuyBDcQUmP7IH8rcXjcipaDUylhY9U1Bu1HGJeRoFbetnTEPStuKnnHKYlfEsw88
oU59O3NlSHW5zWb+MAWJ1rJowyTWDnZZIyUUdlxAxiFHyT5PI9SfTT9dQUsSrQdjtdl31pj2q+c9
zaUd8jMOALkm8oQ6UTQPz/ddcwXnYtHoMPEKbAgwr+2Lm1WjN1NgfVQeYtbtPq9S/si7y8wA0yK2
wo150FsT55FmvahHKUf/jIBkSab0lBu3XG1f+ZPFWs+tt6oc83FiUcRBfmgkXg1TtznzeJhDnKoE
/ilagaSTRXLZ1/BA8K3x+iVvAraIzUQNzk/2jgohnVE4y8Ft57d7jl9FLAmNiC503tZyxt6zY/ks
I1HyZgG/wY8TW7QS6Yf6U0nG/G/y1tqNaVu5eWqN4uzldXmAEtAXJWc0ewSXkr7ZOrFxJa8aJVvi
t6V2n+EWiJTnnw2dNZtgRgSJBg7kkIM5bGGh8ZhknbwOyMeUbYK5aMvHtHhRVeC3z9xl6EQzhV3q
AIFGpGW0hx3qcamI3tJXbiCU1aJ/yCggFcJ44+IrcNwhYivLDgndPr16c2H20dklIyFQiwJ6Zq7s
Dt7d8S9LY80V57jziLeQZmjt4d8RowWSjdxh7cHiy7LR3qeHKrDG2wxjQqnXj5c/mQNonwk+SV3x
967c3lMJVbWRwbyw92jzrweOCAvQP/5jJXP1qIUFuLOpVwC27AoI+DEKDg/w52w/x1eOyHwv12sD
OjeG2irkfxoRSsmd/QX/nBqYjhenrPzPWIhBfGdH3zxlvS40gy2dAcPQ1nRisXYYpNeW0UQuyi+z
lDJMTZ0BSwHFf1q/3yrftGXGrCVbEdN9cF7lx2WcQ+uMHPH+qAu+1ktkBJudsfPDGd2yzexPvxeq
UmLK7hUmJCFACdsoQcpkgDGRHTWhM2YhWNs0DPfFxHBOoz0sXnXaz3L+03wuZWmHsqwRLlrFAeGT
IU5cpbb8lnSraVtww9/sPhrEIOLAVDeKyi3nvC/ERlc0pH1jhvqUSkqXqfJALGEvWjzA1QLO6s15
YjqVI4GStGWGHh4PDLsvftDN+62YEHj9WwY4ELH4UCrM0Y6p51C5o+WuVuBauMRJ7/UglcCC9AWw
yOB93w/309ZqaDFF+uMKJf7pM9ybK3zt23V95Qqr8yxEA8eYZXVUpwQidfW92JF4QdbSFvuIW9ci
bsVFNypot7oo446lbQsvTq+Vwhrphu25Mcc46YfqYu/uUOX0FTzy/CyvWZWLRZkjYhhOUyHpjqR8
lbIhr2mVQN7Ggjx6sdNTUsUeDKMQ8MBO9i60XvcC0wppyr8r6wzb1JamwSsiqjTzUOgy8WielwmI
SrnuFxH2kzXHeTMNX+EIueg4nNH9PxPkQIyxZ9qYXyIibqiKV9hoBtDwRP59fUm1wtQyU3RhOVcK
8H0CG7HoDHTU6y0dPg6xaBaFPaWHKNm5w0eHgdlUE//UhpdTK1dsVmzcNilHnqPdliCdTSnB4ZKN
WZ8GCHPiYl3vAVyCeWdExVpZpB9wchgdW6uTiubXfzLy14NpbULZ969NGzLro6t9BGVwfPlKW4wF
ie5k1kdGB27/NYiqHMnIRzDNdxhcO5QuGvD9plfcBQEAEBIhB+TXzWkPvLYWbc2MlA+si4j5TNTb
z7jrK0+fD3H3PeRaI0SKcJTluHAn7od0HqC/xzKu7drZwRHXMdIa0tLbRM8SpSuYSlTLdBr+8SCF
qT0DyE5SZ6L3976z3ZXC+VYmqFE+jtKB/HQ54CBxGSbkCiIgVLPhBO9GWPkQsNIG4WbXPN/luVlU
Z/Uk40+32kbDUhOS1a/3rUMFy1eX1zVYHqRDrQIkj0eGyNJQPgMfzt7bAE4ooUAfMy3lv9AFqH31
v1EtAfzJVHkUghoX2W4z8cQv/DUgIo+SjiAwBeGxMtjl9rO+Ely5c96x2HBLGT7DCTqi3fEeUko0
Pkmj/4pyPJNmPcwvcE4nC95miAHOOL/lGCj51wWA5mpuy9tHAbIRSrH3Kda6p3/+qf4NAQjq9Ujj
sBZutsHL7/I+UHrJU8MBxmBw8GUITGglA5ONR07hMbHe0IVskuQWynJGCetzqzrSZ1CVK8guVUA+
hpUsu1YMl5EC5voRtZ2F4cOba1yLToHT34DnRXjDHnuLFpu3EktjdGcNRY2fd4c2X/hFkeh092lT
BPOwExq6DGsVAAu93OxS686BcCwG1bNRrPFT/vt+cI0W6k8D2H8FILzPLHM2/Co79817ty7Cu+f6
XkXSDeazqyu8yq/y+EvMlEPIX9NVQx0onAx+BculxK/stiqa+cJ+8KxsoxDsts8a9MWsPEToQmeY
5ZK6eUsmO2oYq6OBbluv78Zq57ZLSMTfpJtaJeSsepSG7E0Od/+uodHg6bJ+Jdx3ck2HulbEsdQo
I1ZlCGP+D9crey94iQi42KZNXSUBrIHZdrLIULx7O90+/VGeKWqmoYHQUpu0uY/3cBqqMYNdiQCs
bxGjz29abBHxX8E/ZDAWQiLVRL8fYcpbDyJffcTY8Rfgy8mu0P5jYzE3I3rsPKEmK4huVHfxJ5JQ
MNaexUDOwy8BPttwdp0F3ekqeAZDV23P78WPKWkkpytH0j/4jj9V83GRnfTKBBI4C0bP9a1TgyJY
d9+IfWb5Rj247077b1L0SzpT6gyB/8pRSghx2ZRvtU0i4Bno1R9fKFnv9SOQY8hETtURrGpZJPkX
5ZGD4S3DXaWlresKyKuGgUCA0P8A94eY3bKGbztmvy5VZfIv+EYnMYWKPkaBSZgxEGJSEtgpf5vy
Iw6bJHHmvOCZEsVhnmCj6Wc01drlfQMDCo2JhmW19DcbhDJjR2Kff9XkPAcnQtAg0NKimqvhNhNt
wxJoSrEjj5dDqAc6CPqYdMnC1mZzHnBj5MxLfRbPHIRXrPGvETNRg4fMM5t23LYKvv/HKgR9MHA5
ZCamShfYH2VVLF3A9Yh3eZQT6Z84FKA2/qt9I4ycMmO0FZSPSLLcSwlkEgf7cdq+GhvvJ21U57K+
g0slG0RdacNn1cFuM9hRV8IRfp9ddPnagICZV6OKtUvGt36iwVfobAu1/b+u84suDw4AVaAsWTq9
lwqTXvDAzgJHWun6m+PqWVWwb04Pf22mcagZPHIx+k074ShxQJ+jKgz7xxTG0SR41/0nOjbR49Y/
wToEIPScVN/by4nqT0weTDG0bhYQbYY+UhbS1w5MZ/qB9Z2SkMiEpS/k1q/XvbSFjGtJCoQBT54J
9Isrb3ufWkzoXef+DfvkoPE+x95GSYJ4pz92NSbhMQKrsiA+DPXidg6jQ09L1iP5e8s7134PZEdF
dHf/XfUX6rW3O0XgcgErnXpdUNLaPCk0J91353AE0IGuVcAdm98IaX3txdVN5mHeFaGP/YUQzm7u
Qol+Opwx5qu60wDY2r5NH7zADLSzxpjkXShPqbT555L7mfzcCdqruczfViQRTptICSsF1Zbp262g
GcVBAYcRDx2BY0qv2RNETzrrSizCtxPMds9wU0OkUUijJJ/kh0yCjMXaNijNbOA1Y5cWoq+RX9+Y
scW/fCRhqVMw9msA1a6UgpA2A7oK42C04t3VJ4hOnb/KqJGt2+fOr7yRazXktuLdYH53Xc+rEE11
eNAHeiYbQJJIsv4E7tJ1koWS3ZKW/HpTcVOQ5nlhMhQjQXJ/B4NAEf25f1BFLdQsA2qWMh8wLIxP
u5FlKnBBLsEhW/TljpFi9MMps4/zGgiUGoeV51UdlN6GK1vXuHHtVk8M9Yxd8vKsnAaD+qOi59Oo
fdJe0RZWBn+GIXX2EcSYfTp9794pG2Lo4vkksi6NeQqN6gJu/gd7bIZXw/W4bAmjfI0n2awOsGXK
V2paYFai/IPulU12gR9GA2a485ToTwAvC9E8xElZ6HjQB15xiB/s66RrdKNEhDeuIDo1awNhGZAd
cPO6iAgEUCl6v3KZL8HIsXr/DSk412dA7fPdckA4PMMf39QEnQxwYpdVLyj4w9ivGEOscLk2yI1S
qO12UCOuH3Auv8yc+TtyYrBfipxKwFyFIw8bsUWj9BJ+UsvHVoBd2q/J483dN+2PwEB5O5WiAAt1
XeJ7QSo7127slWSmwCKOOI/1hfYHpltqslBNgwpom2yAu4duoQSAwUZqFtP8hYCBWASxIQC/0yV+
sDABYv5JP3aPSci3p5oXrxzRjL2MPwK3kfdaJNrtL3YrG4SOW+7TBfSsSpqZhAgomeu+wwyCkN54
Su3nwitlY3QBf0Wq9bEggICCrB4o117kffFPzUdSKemZiifAPKPaTtuPtKj0BX9BJTKLdEcipPCR
eOdC2zhz9JlaWbSN6hsWSHfw7UWgeYTgJ+bkhM1Y/F3VKxqVdaucI4ncNsJB4oaqGWP1Ew6ZHkgW
MEikiHoRJj3+Yo1iNzNS20AZrqx6XPqJCws/QT+eEd98gV/2m+NJcWJUXL7USJ0uJFnqqEDz4ORF
HBR0GnbwRn2+2Z9/6XYWWIDUTSoEw7bKu8GD5/Bw9Fs07kwRcI0KmohYjjOwajjPdaxIYCmA18mC
gQxQFRF9ewCnYDEfrupyLjUnQbM9l1A0p7ZvbEsJ5Z4U+ijQMgE0QO/SksYe2Fmjm0pIwhlsgTCi
saYSN+zjVsW7ToSszL6Q7AecQ6vdErJM5MQSIPFMoaShQVXOmnJ9HVoXSottYN0QuaT5dQMGG3lM
CAxy4APchZK5Xx7HBNKwVLsm7qOp1chcmWc+Vh+KR3brM1IOp1NHJOeN10eOGBi9idDvz5n3itHW
hll3iM3JQp6Y8fb1XGlBYPNwEKvXmb5/uccZR57IYxDlEL1NeieOhP/h1lzIAFIEGSmVMmRcy0rc
+ck1HYGGJIYuxYn8osrkmzEYOJ2HOVUj8AxIOVrF5IMhmjsVciP+AqQPTpPe34nHJD6drTM7q1lI
rsuG3rTStieGmsQh6syTLZq+2Mx+MSwd/s1JgkNyFkjtD3Wq20uqjvf6sH1Y4J/oKmzuufgx4Zr6
+Ez1kDogqF/ZFt54keH/9Io7VpDUA7KNEaQEvmBFwMxowocXf184Um==