<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxunyJNoiyawYzza5Z3cMOanz0d9dT/Kfx6u9KaAYfCbmoyV3a5sArIR4pb1Bt6Yo3f3K3Nz
f9WxykIMCJlaCVWlsQst3k25Z8mNDJFfzJf8NX3Vw6o2KAMAzF+yDNuJUYiOYA0AiUgxyqmqj/YK
7TSwWQg5cJIo1WQZ8NtZ+U1hwSCZ3aQYSUgoK9+9YZ0mwPBG40cv2y0YibT4kAEW+MlvOaFRL56U
V0n8IUmAxVpR2zT4n6+XZ5qE1kdWI3ermAtoZfHpRblOCEp/A79DslgBtnjgthopk5RMB+nDeCng
5Er4/rhKWsRzisoxDqllDkkR69UnJr9h2yuN3/6h/jGYQm/LS0ABl7nG+O9ZGx6zR79miTwShY7B
fHe1ttYQjNyJNtFML+GUQ+Vvn0g9/+bAdpNCa0hzGFwdG2QpvBjKMkRSspUWfHGl1dckHH1giEK7
aUu4puAMEobgMrd7ECV6JvbrFemUvjDu5NQvEdySOytqIut5zvPlxAlZ9IC0ELi73d4UCKTNk2xa
GyN03PgEo1cey9+iPH9Jfu/H+BihO+ksI5cKflS/KJ91N9u+tRWb/A7OirTJPa6WgRqNBNLToSfX
Cf6h1f3slp5+PuIFoZid/cYW1j64G+egH2M2m+vXH5Zu8o7IdaxvB0aS4tNC6l40jiYMMWtNWTlT
+vzLjkkhSpA44vmumHT6QD8jKBnkgjY3j2uCFJVPoH9VhHIlpmzuDwmmHS/26N+W8YHwu6rU2bTw
nmTUdgRm9C9lSR3Gx/x+8oKZSs98G9vnsR9z4rTvCmB+sJrR8hsFxZ7pqDEdVrZAn9JcYYKTf5/+
wMuGK7C1BnyWGqKZWBeJsSjDpNBic+Tg2kAx+7LJ+8osw2B1uviSYN5tCm/Fh3zm7bXh5Xl1mBrY
bWmuHHa/MvWKm/Be+rjp26pG3QDsB0z9YzGC8ZOzzrikzFZmuKexNnCN9VFVZU//6BYBkSIOY5e6
G8ro/Z5uHfz04bOrjaHcTwRscLr4sQPLmtus5JiBtxdiLF5JJCtArQ8kKmeuoL06kCfpZfdo+vw6
w3Q7D19iE5piKz9n5pLagcFUkoKqWcsSx6x6w/2ZjbeOVU16dG/27Q2DIV0CHAAGsFq2fa9XbV8o
lqWsUt/+0A9TfLS8IITlDOV1bzbpmCvj/dAM3vVr4oWilUdmGaa96LixELp8HRovQunPrPc6XoOK
BdH0bq1hiD+R3zrAeDu3Ghv2U826q2jANcfWTpD0+3HwNrOzpd4/iQiRw5O7uXZ2N/7/OvfV8GTE
7V7Fu5ASbSQewkRI+ekLuSQoPxlCH3Jn/e9SW7k+Hp32GyoYm01YbILd/ugJvJXEZ88GCwpo2JX6
3ojUHvv2K1bLzRNv7vhHL6BcYI+6wJk7eNUDHb6RyCv+nBPpq1Tyohg2lyp3vvgY8BJ33R26zn4N
6p1LjVSCG4ZVRHnpeYvTZfq7GKPloqQsspBqqOSTIJe3TeI0iAk8ULLwX2DcGcZ8aoT1+Lidwcdp
zt8HPOc7qBjbdnG9FaNwsLbZYlsYQIbrgcK6mcPjhZsPfzM1fAR+EdkuZX/a5PclN5rAizFDTH/G
XRWYz6b/ae3/SyESgnc56akXBqucmj3vyknkX0xqLsmfn9MIVElsrlIyhWXG3ubPLqZ1eDbJ752J
4TvgO8s1EQu5UFItUc9QKQAZRRoQjrUYRtP0g+Mn+nkUPBzvG7CP7sxmZQ+LcE1zy391DEKHiFh/
jyaoMks65SDt+LCHVHyXt4yJeh8MUe8WHWcmrEq3ENUlxRTiftqLUdEiGLMo40KKWir6fATcHwD0
WLdObTjHDMzJs0u7qRbJbDVZdNVYAHi7fo6NpN+cEBLhRy4uggk76rHCN4g18ZZ5ryTc/ypOr7ws
v37LkrKZeClv2iPr/YBBw2aAl+QCso3eB7LemBrelXFAN4OA0umNY2m3fwYzJ5g1RaE9m1DeiUr6
joHDsLNBzG9OBY7kNx0zkFv833IBX/BnAWyUmbkqhpAh6XYsSkHTxh5O6efY2C0zFPNPd4/d1Y8K
34bCseKT+5SioQ9ZN1FVgc6WXNYVUm+9tfUO9YxzdhUjdKsi7aAlsfLGde7vcdyHUl4f/xsDhslo
LNKlJ6cQ9jAckrtsU1AHB623fIrVAcQRsXlubRWL1HqoNbiH4o1EarTlv0wEHi3FKPHIBUZMilxN
cH4f1i2y2tz0XkcpPsBkOfP/pveMBHOcvb16BiLy+MtvmBnus+hXnYTwGnR8FKT5lYOHiNNxEhUb
oKv+Lx5cRjEmzv68AI4+4z7Iy/jEGvHz6iOSfQpo0ys4/uqE/9Vb54p+YetHJuJTBH8JAsiHUdbd
hmEUyHRfBhA6rj+C4U44paKOKUyn4jFULjDbsBl55d3D7cHTHGuq3v5aE1zNRAi8AoS+QdylpKs0
qM7AbJcfFWtxK/0UvMaUbgsKcDfePv8T24T7DElX+HGLK0E4SF9DupdpUJ/qW4XA+Ydu5RCNKDh2
6MBuTZN7PvsWwKe5dNSGfdkn3xkbv0/gBnHeY3NU4mtLuHHu2KNTCZRIvf1RqAXgc9vi9f45wPdh
xU9CmDD26qJiATA8u1DatG93hd9DJywjD8INlcmPDQoDV11julnymT1LmDOdpeOY/DPwwtLglmcd
0XMtZ23+MIaEB8inmhtKSMzxUUf5l/xagy/hJpV/cO6cbK4911NHVhoRQ/blMSMI3S3vrxCJYVOC
AXoXfDGhhlTkjicsZgj7KUa3WirY0kXxtrnmNbMos6c4lLuKvgZQAQRzIAnISeP0tVsP5RZoN92o
sQU+KSs/z5CvT2Ku8Gs6YlNybjsMo3hgwrc7jz6nZMvS72H+OFOfW8NRFu7Wf5kJgxrW0bVZn6If
Coxk5kdhm/Po3haEAFCaPa2ewJYFYsTzv7+72XWm5HCbLODWKkBLHxbUD94mtAlzAoYSKJLToerj
dujJ17fQO31zaK6q2VThAQSCkuDb7BGhmjVI7r0vWQBcas+5SC3aNcZYCam/VfacsvL17MpuqGJu
gQ4Ny4qXhWn6qI6tXWEsbyAKSi+Ik5wJozUZeEwRidTx5usdjQ/AFMqvVtvbJtRGoMUO53bfd6oP
kZ5frfl1SHtqdKAPW0il9tTVVT+ouN+HE6mX8vRyChoxqInep2KPlOlHKWRvQuAlg8QavvAYFgmG
deMesSE5fSAv+39AH/BSinZ36OjrKlczk7yGfkdT+RjipskUqCzE9S7Rw4Vf8aluvuvcAOf7zhrt
Ng14IuIN2IenIELgoYE6To4lGLQPit/BV/o9Oh2u9J6D/8x13x0DfgFiR/aXUBHb+8YluOOpVKaM
h8h04Zz/cq4NuLZH+gs31rX4UuTB/JhpRMhExISzOWvw/ZAMGU9epFsNoVuXLOiq2fjzydCejwkx
B4mNYkbn1BfWkf0PTLCcCKRdKXiNmxqvHfaUIjJEWxy40BDJ5UkCrHN/t9HFAG5gg+X22Q8OaLHM
y0h9YMMJxgJH5A+7eUFBBJ0aMQKxoRUgK5++2GEBZ94VC9qb5b9R7ONmjJUKq5vYtxSa/wF85Dds
+fkEvEnzDHyditpIgtSMZvdHJOcPc7MnIyOagfjupkswlGcvQDDc+p7M6RiWqOCQh3zw0hdp3ZVs
+TElL3YjFc1CvtHomfmPGCR4XixTcafAmjp34eNFK7w1N/TmobQ85GOaq7ljox2zoACWH9LoYxvA
A7ciGscDlU6HvGaACDliTubVIhogdgMAKgYnM4ME8GasDwMzD+gHzR2iC0N/9QECRVbVtI1/UEzF
kHHViubKcXp0qJ6OnBVabq0bqagsbxlNqi2WONjGfCB667CEKHfvfjcczjek5gU/1bBan/GNjsMB
0WNpe5pxIEl7n9tgQvP2oC3coJirJAm3UqDLTqkYtgCwVd1vXuPH/qTTAIbupFPW+oqmM1oeXDOe
6RUUW7i6SHSPFcJqeUma8rEcwyC4UP4bRcOa/bizBIGj3vwNm1GHzhEbab/zZhndAOBGmEyuvjqi
gImFuWaxg2jrnbi+3ImNbPlH+id/pRFH1oTZOwjwRicnoag7ck3H2aU042p+Wn1DRG+ztCrR34XA
GGCLnHcgbuz8LHqhptSO2lzKB5CsDqXp3qdT/OI0f/OTW9AnHjTHqBlaowoH1sMYhiDhmXbdFRoE
LUuQtb6yxqWFOIn6rxHqDnQhc0hcwjLA/56b+u6jLHJfJtgy0cNqnFa7ClZb7yEDonx5fxWQTNqu
nIYRz0qRJe33z2iNa+0BFN1X6G1Xn2RbJjmkkd3AhY2Wi/v1Xe0CMa+BccpTwAMdEhwifMgXq/Fy
dL36spWxD9vMIgHgyQPwPfiQYZNHaGJD/J0VtUr9jzcTQpBZ4NP1iCeWo3r6AdLdHLZi42EA1BsI
9sdUtUMQEBWM+QTuR90CEruK3TZNxGp3BK1VaE8lCuaja/RoPHyT2zodXs1MGYwVBwXP9B6w+Pvu
QWYYRfWdvyCjSryXNW4wZGAYApTrUPHF3qVRjVULnUfxQB2iE3sZWXSYxJ7gGHz7iFt1RnbYPfRx
VRpJFKbUBJg93zT80+yGjUnox8/js/eIUGowawox8CV0ySoyin584LjInK85KbZEX9qHX7Mwb6xP
JqWcvPj8451RJTIMxETFZ64EV/2ug+jtyaf0MwfhgGYrDt60jm8U3pLY6HoIKqcqZaQrIFt3wAwS
8y/aMoQvG1b105BTKdiE2+YOoG0AKcbcnkhmOS3s1b6HULdWLwcaep4psAJsZX/efJtvX1xlXP8m
zfKV/y6MeIoOJDCw47UaOonNeGq/G8LoH19npqFVCAaroVFwmOl0wrHCO70Ax0NCyUu8XwiTWmRe
XsOoP6XdQlr282TE6MJd4m/0Ki/ZRYmmUNCHZMDMl+AuMg/JQ88pZ3aEMy7T2I16DErdzoYfkQvd
AUxlSFXlvSxH8omfkBocXOwsQks4cP+CbAoG3NOByAc9EFtmIErekEReV1Ap/YXB+eXWqlQq672p
/bO2w8d0mWVI+TQInGyU4ntEAns3s3jEs+AyrMpb1maNUMl79YTbHMs3HcHEHVtN0KjJArZCoY9O
Q/ASNYvVnhkN6sACHDLRrEbU0n27ZVPdL9crtiOtuWbGO9K+Sh3aOa9o7IwAGyFg354/LV/u88BL
8ozz8zuM6L56tMsJBuwfZbJumFmSMPfUd7G4nhXPu2xCL24JQ0VcUfJw0BwsrfuW74Tsp88+0sN7
exDK9Fas3dsx2kZBHIMICzqjvA47ooTcFpepIgttRPpfEsVFr9SXmQResqYmDWguaHfjxvUvVs6r
9zvWf6W45gsi/58k5fih+yL7RQBlsg+CWbKpBlGUPauQ0llQkSqahDPwSygwhjEf41DRvht5yF6L
HApaZD/qQaafZ3Cjd/e0ddZVsz4CYzFA0Rv8Vy9qJTgQYNN5gVgKjv5auchBSD0f3VJmYHkzvHiS
lj3UvCRfFQDfPMBYVZlxQquiWj+H5gq0/35zDqH9U7lHuAY5Wqsu3BSSAPOeA+5MtPMyull94tLP
MmE2bgxuQMhuCh3nJyDo1Nl0MeoJoTyM1CIE57bY/VSQb68ie3kqxepB3GRkR8DRuoD0okgIOwKv
MwcKDf4R2UdVxT/C4h0QPtKKc63kbCXwa9TVtqRHK32YEcpMaQ0I773qH/FTuQA+r3Mt/p+JqpyN
7kesN+xs2lK+63Vvn/+/qYzOshLPVbX9i6RBwg+A6yFvylDBIBlp8PhbzcidRh5MIHhU91TFrlDW
o8PJEWSBgejo0WGHmwCNse8o3mslHmByHBT0Uge3QsI8O7Rln89W+vksEdeD9zlf481qRmBY5d7/
XV0fYNouhiAAVTdOb1Piuu/uehLBXMO3wnL6aL9tRaa4TOsDlk56UPV1zj4vlSYyXaBHeQxOeRb8
YR74qIsyeyWVZinQW1J22qKqWAK5YX0nGZqBvGBcGc0W9sGm5/p98WFW9+hhGLXosLs0LAuo4eb6
wjHAK+/OUpvV3Ka8ogVtyiEChLiOyctz0LTZhzALVMx12Nq1vNTz6eWUI4/JCp+vbRCaZbT7k0Kk
p9EKwyRjjpORdEX9QkJnv0rBGy61SUIgRDw03m1G2sa1AG6PaUmqo1TQ8W4FUo5wlWESraL+2M9Q
7gzFyR7Tz1CGxOqM1WdI/6ne/KndBUxLmBCABSx3djpojTuRaxP8S4U5kqn8ENDTeMcF8aibXgIB
oNoDSsRzX2jVmc8wStMiwVXPzYn+XA/iWgWdaqD5uEsFp58cq/MGVdm9H1hsyE2wTjHWtEn0PANx
XAMqmoiGqe0s1hm5+rZ/mGT/iIskD1pVZmFhuIYvW3arNLntjbk5uvQtio2QeeOvvgAHE0aEuASG
CQYY/4WCt4Z8Q6T8IeIAjkfCQf/ZPA7bemPQlIdVMOtLu21xcH0eA7VSxCfJ3++DglVpmh9NuK4u
77v5JFOjdusaRnB8dkplEE9Tcwh4tOls0yMpKdEFbc4Tlv6qCk02pn+3tcOpYFgv52BRFYCDcaI5
3k8CAReBYaCrRiiwmQr7ZrM+Qw6cbcqlupiHAAc0+FgN1a666Qi9X/EE36gxtOuhrHR/NYOjJE+O
GSoKN55ibFSJYs7UhSp1doP6BvTI6cNVxQIulN37k9xtbaiSjHXPWbRY4vCeujKuwGE6hotijvc8
d37iUgoLQmVhp0Ci498VTQgW0jy7TqpQ8/2Ui4LFKek3UmGwxrhxcvfLR+XjrQzeaQZgErSIQlwJ
Kx2ztpDvk4Uae1jd08WiwG5CiQSuVXGZLD7+aeJBje7bG5RPJns2GF7+Vwx4gAUGr7afPd9eyHMx
CdzPerbyiTwYktbKaNOCMgQQoOtqKOv2zQVE2VUuvrvZsj1ebxVAHHCqvZNcasBoliErZBKtq3xo
8plTYNP7dUtBTingl6+twZ6xftydMrl6Hg+U9RiYB43psd0emvDHPygdMG+bk4cWgBajFYiSdvre
zkAOtlyGAd3JOUiuX8tLsxJH8Y0AKInY5tGnfMj9EWxrgE+wyK8F9AbofA5LXsjT7XSUjL2b3KpQ
5468s9xh5re+v/nHYEOmfhycfmO1KBeuXEMi/uvbbBSsOeyVAF1iUHVDcjgr0Ao5XApdGV/t8lnU
RjhZq15rFecaAOV36R618x3w78u4cEOBjB0MXKYwDL3OoQ5lQtBu2Uo3ppBwanXJGGHGNIU03NPC
XrdubljcNeQ7zT9uAierASvi+Z7YaK9jUl6nKtEklK15AGcJfdw/Qj5u+4YkJ9win+f5+NTH5IDF
4NPEkI8wXavcwFfo2DPKnTlfHMzza+b8pEZeD6hn1D+RUwJXPEawJUjqygzqX057HUHLft/ClNb9
D4a9btyGXk59NG0cEx0L0xzLsdEoWo3kDhgOBt3SFnkJNHmm11337S2aLb5y5RcUe4pNBk5i+6ar
9vntA3GFTdtSh2n1WLoZcesU84rJNquJ9xFp3FJ1U5+k8rnFoqjlNVPr0DTRJgZwxNvJn8bxK31Y
bSgpfABEWFyotgm3CkXos2W6I6eKQvCc4LET99rpEphjHKjjOE/I/s6RdI1Huu9uEpr5GrL+4qLt
YHpSfLXXhMcp41rBorQd5wL+OjL7Uzsnf1R5yzlWSEC1KDDN9iisvG/xSRDiSHw6gFUYc6n9P6bP
jmfCSbACYxOq22Mn8iz91q653ACbTZqLWG3EFcH5GR60hF0dL6pcANhNpLXQkZ3lCfdf4bFDvSPs
FarC/ZfJCjGKsTa5mMx0HW9ySv5aceU+tqk2ulZMeFVqG+mByt6k1uA9979U/47JcsR+SP/di5n2
weqNy7JTN5yKspOZxg1fQLH7fgDZvzqIncCKI7I7mohv2Zl8hfjc77VfT1LukkB7dnXdBPAbRRrM
yOgZuv96py5ba05aQF2iMa22LV2ig8QO84q5iSmOjjYDHMHSm2dxmojARPDWhQdye2JE3dp9qvm6
J+Yn9y+AoJ5AzwW0Qi7bbnnrj2gWcCx3lCuEfskn5Ak8x3b3tjHIRZfZd51Kj/NwJdPDlVB+5mTx
Kw4brkCJhkL/jumiCT+4/2MNEnJGPbz/wHeZISMvazL0MirE0jWJ3pZUluARkO8iVpO+BkqmrAmb
akIRXtmqtRuTaLtd8Ydo1UmH88P6fnyt7BZUxgvz8Ssk0xNw1E0t2grVAtYOtCc4T42Iac90zHVZ
RsRi3+tA1bsaLriYW2BDaq9uCTMbXys6z84Mwukn0AsQPXpoAjAQxgL0vQMbMxCYxlbp3271DeLk
3WGiCLylUVy2zm7pxESZcnYxAky2+SBj7h4ni/JtUTACoZhhnzRJL1jE4o9CJWe9b+4SdCt1NmII
iJgA5m9TNJr8czUuD2WV26F0Zvp8VptXyJFmFvWDgKR+yIIBiCXaYJqWAYF3xSu8SY/2uumqNqfx
r2mFHWfh584LdKcb3pFz/eNqfr0faoWx+vxIe4kttmOWx3iklJMDkv+bOcTUcZCO8qOjdgnBCfO8
8BqMLFApZvw5xR+Uqw+D01/UlTDBUlJhUJjyPFzICfYt3XKrdgxiyr5zramx2FYM/lY12UXGw6YA
nK+IgA9H9HL+bnqDI5MxKSB3VOKG0+ohlAijJERlVkT9vHCu2BdhCtCS4QkjjQWkiLS=