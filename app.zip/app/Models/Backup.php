<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnP9Rs/a+5D1yQRwJ38b2AoMO2cWSyhQ5P6uEqw4ksvRKlJYMepcW6hnkjRAWWnqgGB2NfCH
x5qortRlNLnV64XHNu8rjoOk9rrORSRKwmaX3eyaxcytlfDtWcCmD8xq1qICWlfiKPlrB03N1EWj
4U9y3So1+ru7Lz0IzBwQUcb+KVCUaLpD9KF4PYqJ3FCApgutIJ2pVn5HkMtt/55evzGMuejmXcw2
m5QB0c7+fBpRZm1tHrJ5/oyiOm19NyMw0N/buTwEsDRsN/vT7QbbsKtlWLPdNhibzNVhIvEUaVbO
rDKR/yDStZJKnYJCEWYGsUp2Hkyk2da7ExNMs7S19/+Ts/HU89SYOPKMTtRY6iV1XUlv1bobPR/v
KC3CW6ARddIJIS5V6xu4u+TE1KlO5qHL66UgmJImcOAPdG0Yc7zL3ap9pvnor5VI1WyY+V5Sw7t6
Iz7sjWyggVshi3KKawPE7saqL5SkPTlIMheX/cGCNYE71iYPf3UwJtQJO/enCBbVbPFuB4Y2cfl9
pfdr8mwya1s1L3WeIz1va5BHq9LDq31jDf+vI7SxNpaS32RpbU1buf4vLU8iaYwUO0gEpryhx4Q2
/b+TjxaxBZR2VTfCum74MSix/X/xElwkiEy1yZHONoYUMUoithuJ7ez264xI+5n1qUAUqFtMNePQ
GSBbJhP2nfykjShloy7DPkU1jpibXg0nFTU/ug7Zarqf7QiGfdudznbWRn+fUkZNs7pHikw1w7oa
P18RgCMM0bZhemDJ5h7jjEIqh6MXhfW2R7PexShK7qpeSGI5x5z7UhNagpO6sjcDY7hVs+zuOBp9
ddGLAUxfRJ5Kw87aPVriLvghoBs8PtbWE26W1qHrlAg+wDI5KvZhz1sJ5vKNYOPaq2ZpRmyf4u/P
2kYk5s5m3tM58H7o1/50eg5DVznQ5cpC7BkWvLN8E01NRUNHE9YDUtWN0KcoIZYnl2wHYaHVXFjC
O0op76FRMFzwPHVHxMj+l7TPgonZOlzqp/M5Xs6U+zSczXiCPk+ridrtQCnCTisEAqhcFZ4XYV4p
q0MC5PH/dusuzExmqeVAsFvC9S4D7d7X0xdzUzOaua10HB9dnCe62IBWHnHIiCQfpVtuupTf1M2b
FqrR41UhxHnBLYcafnY17bbMCiU9LIX1xpfpj4D1FLq2qWb3b+znqa3PpPIOygf8OfhzGzDMkiUN
3JJh+kNGu7Y9xZPCn8xeINoz18S8gTjNe5Wtm1F7HWK14QQn+cbLIG0q9/yAtvdzJr4Gg3jtWuBc
2NYLUILEnS2zcey9VAGhLQSbJydDhkpGsGpEGuARBoAxg+5fIxx5K+TWdWLlzuuH3CeXen/54onQ
azzTvKUAmcOqvoAPqgoZdEjyIF0dQvJX16LtWaPMyXddqh0DVLITNtnsgcG9KKfELcvrcWCny8dv
CxFunMmqJh7eq1+Hekjt5P3o8019Vaqo/wZ2s7oAaBJllJYmsziVagxkC7ezm1Z2ETHkJtsn3CFT
2CkuglruMqq+9hS+65SUFSekIYCLP/XTD6vFIO6DLFq5pdPW+It6sc/6lswF23s24x5oPMovzjlX
OBO/xqaF1KpQrewsgXtLzYn22c2xrh/R4V7boWeE5/hge1fMuZ2gwdh250gCYdB43MZ4RjR8YODp
x+kf+k1kp8TDpaNoTA0RlfYX6gcZ79FBOJ7mRZB7qg7XT8wt9ujLAbdz2cd0O90ixK8XBMfrivh1
o4TSUwr609GUKl5FHK28Kege7fqpIh3oACBHo5s1xVK/h8E5jKyx9OWCwGO5blmh55gz/nF5M+ZW
xLtEhBp2XqCAcA/C6MiZl6y2KK9aEWGJll421lMWA/Y0OCXRABbl7AlWOGU9sHJ31W3c+KXmggAP
5/qBBDFwbRxNt/9FTfpQ3lZuoIuDaxLJy/nKgAJAl/JE5MUJUMB4+sNMFlFaUciCSybj45qVtJcj
XbVcqZCA3Qatru8L4NeIcXxAkUW4+fdEpBc5AL4CiApeMhcIt2uJ7TprDe8Q81vF5aPrqI8A2VsG
Q8ZDl65lsrzXPCBcfZurfVkoYbrAHzX28LhEne90eRl1D36YLrR+j6E/jiz7wx7nEh3wtKU0s9ef
s5S/ua9EZe0lNi/Zmon163chkBGkAILvmd9Po2SktRxgI3LLk38HRrld7DYtV03OcbUWUznEUY2G
yfYubkak1CCDCeUErqvWeKS5+oFAkwmPlFt3o9cAg0fNUsdrHPIPJkEvisNljxGFlT2DZsYoSSGz
jZgBtL4lbHq8k07tDQj3RAnVq2AX6k6FSU99SF/kzrHds3l5Oq1JvnFM8zDqqfqGl/O9OeEgZYiF
5c8JsyyHZR/NWA2XCCRYBA28VLTVRUnLiQ3L5bVyFpzKyOM8iUTpacwseAD3miXBIRXFC+uph0+A
3N8WUxCJGjCg0Lf8oTR+pDS3O9sjGFYo5VznDEOkunnB6Lte5mRRm7VxTMPgAIDUap5LNjbzyFDp
aZ8guFdriUp1Q/gQUlmDm4TxJWNFQryL4iqaY5ZZEGO0dZ7hyctwNn0ELk/bH0ZNXFmMnm+DRLw0
6dlMgEwuqSXb22Bljvm6ky4BUualtZXURjIOg9P1UfLl4KsY+7sWJ282JEbzjHYHya/CPMdDWi4o
tvpJfww6Wi1Wrupxu73Q31Ac3mJuOAmnHGvaNJwkq8PgVEI9RB8FAt7awlCxDtOQy54Y2pLwonF/
haQEQ8tlxLYuLEhmvC1av+BNW+sUxPv4JIfOiG8b57EvPqp61kYweY7F6hHK7NwXu3gCvlNppqAZ
ZCeBzs1Ba5VOS8snwB9X7jcXdvPLtAxp/K4A1tn5NEDspbtGsVnbONovWz+jBcmkGrT2iQPK5WCA
x6oxKf4oRjklknN9u2pdiVwe4/yMjynNDLmZ8vP42HPlEX2r292RWGIo5F0YWhJXLLjAkTZPFq4Y
wi/cYTchB9ZdOP+J6ZhLDDTv/ZPY4Et4MFGNp+8no+cRAS5BDCcXd/+eQwAvrLKUKa97MWcRv9Ir
cJHNlArZyhPRJm4rTc2Rh7mISWB8GZHcTSKQAKgAy9TGnZYDUCTM6ZGGuevX/tMsqJ6NFUQnEVTS
boC5IZt4xbvLlECEYoaBNmdOlFAgJOkUR7KiR9EzhEwzgBerOI+pH4imBaZCn8aD0tWCIT8o26nZ
VeHHQPYS+bzl/kBAqbahuce4fNOhlaTZxTilJ5sQGPB5KV7cLw71lykw5l+oiW1BhhzvMVWcbouq
8QEQB+cn1TdYqubYBBDDtIukum5tn8u+N/r36rFpAt3GcEqaftH1I2hVO27fMDNu9cCit3SUxlI3
L3KxiWUd2CJotKcszmTKPOYsQ5W4wX0imxoNstdXTKkc8WW9YPEu28GJSsF9FNsuYUeaGjKQXPEA
ooIdrmnzelQHjYp21n0dS3a6QGEyqmnwVC/PWfPPQRXssNdSocGORaJlWos9Ej/VEKuw+bvUkiOX
sVvIf2mhU+S+RxUSmdpA2M0GMf+bmMrCEoiApGAJii3m5Z4ldRNfsJ/ZDN+QjauXMbna9as2jDNI
QZBSmJAkUiTBTjcC/B5EQ/lDX/C//REeJDGN+Z0YoF8qAJUnjUfyFhpEVvmZ30cWeti0OVmXwvsv
ALp+KnQ7X63npDSBEzDwZfhFG4OWmzjVeb3fOuVbtCJaSiHVkUcNg+ED3R9397PLaAmXdr/a7cPR
dhagHqWNFHp9+21uCoz+0tF7TZgdGNsOMLiTEv6lUPHEEL/fVJF/G1ZN3JdwlwQG1mVTNC8zvNZQ
QGiNGOjKXhx8QN3mMDECU15NCMoHuK1Oib6wFm0xdra8/lYQaCfh+wcG/hBo6kgQOuigG9SfwPMj
kDLFkpb1kOVR88JecOStn8nTuU78C5DpFygMqk/WDJO33mUWDhdFxOpR9Y3pTIMWqzqYawMskzPn
vZ+f2Cb993ICch4bG/P1VUw5ODfS+zJUNxlKFdsJlnH4/eFhCTBXlBv/ppTHX0Tav9aD+jjz64xc
cJDqSDwIhGltDLK2P4M0hz+Sp5In9YDJpxOlHx2sk10wa+9H5w1bfBnh/FJBaZiQYv7FgbBCBS5o
6phYMXTXztbH05a4PAnNBKJR7v00X2zDIVBfsKHhaVrnok15XHV+VZ8CcupxRvxvTYe5wDHu1KdO
Y8MCSoKQP+2cfy0qquIL9gzoOmPs8a0TedcyQR306if1z7fegbckNIQB+u1xIv6/seSoMttNcuhW
4x2MLa9/0la90uha1Yot0NJrZdOesasmc8FWpyqwnWMRsWGICqqkoB3T1RJADUUcVdiWoVtlvA+R
9Lrm00k2pErlGekD1GhtMJ6JiOD/tbEg2/lxbC+KRQjVEZA0+Pr1obDI6BdzasX5j9bemTj0wZbI
UVb58octcP1BNWIYaz+dd9LKNOlSYsuc4z2hgp9yuPOk3SoC3FZX9pSksmn9//Bc371SECbcNoNo
iYK6UMmYjOiskWz2X4Q4Al524YQX+EGEoeqVoNP/jDY0fVJHNPC1h6+SnN1K9tq0qzlp0xsdaGyq
qOETbBg3gRVguBTU+KlkqaxVYtxpM4h607O0GNRJv9Q84ghrUsZRlNT036gmbh7aABxcJjm1MHX9
XbzD4wwURLC9RRW0o6YYoR1PL/KGA56azBXrs948erVL+3aJJsGAFip55ZJxPU3b8+TRSW2yom1l
QcyxAjuJVr8sPf9vLrzw1+tBja+A9eRNpAF7kmj1B/FUszaHV5GcALqOFpPnlVSTpf8pRP8rUhCf
DMHzV/hcY5xjADqA5NBMZGZ/NXvAZE1z7hhIdb0jmPqXjDR/w5ePIX/6O9U78wdeUpG3n4q5QoDB
CgKsQ5BHa9edSQbKFrKWMvka24ZovaAMJ2/Jm9Ci43IqxgSHNR0HmUeFdC6eTPAwkyLOjVxKVcWj
rD4aeiDC8fP4Dwbqur1X/1sgk7usasmwFjJF452z+jesMqyxt/ZfJtEnpFjwBPgl7wgfA21onPcq
awHSoW2+VPlKDvUbIwXHP+2nj7wKqudF3vu1RQ/HCnmHCABWhpPVPmvD6beJxpc8jj8C+Uv2Hwxm
lsFaQVUhLIF+S2Waq/qA91zNOVKvRvH9MZ/oeD6xUwXIzZeBV8JdG4WJ3KemOUUQ81o76U5x3F2q
Ujk22cgHbsobpYVYBLFRRaSf0TCCBhcYmolh8hp+/W+sT/UM7Z4ptp69borG0fSWeEtNgXFVLVVA
QqCRWOTc2OA+AU7CI2IBuUyFx7XvIDAT2J8/wLqvGk9zy4p6EYma0MJk+t4EGhj/PhsqsjofBX2s
z0Td9dhj1y/eZThe9JTpn9cKuyyOekqlOUNszBAVky9Nw1xaPa+ctcA/fi3oa1KBrBgqk3jKcIGk
8NybJThbEulfaD5jHWHEhw5Jg07b29OELtDkf9Hdn4yifArWDT2eTz/+GExc+Srfy4k1FWWNJOPG
Pa/X2ulTg1KqcfkcxvOMlm+MASP6/xoa+vOTkkq/Sd+fLTDRoDomTNUQSRhPm3VUWhqA2eIe2MQj
YTy2L7AT96M3lBKs5nOXK4JmrfzlhbInnDLAlwGEH0kFXvTb4gemqAXPMiIcooa0lfSUfTtzpY6Z
7/tQnHCi2a62PSMDB8e+M25oxYlA/veZLEppPzQq6qWq/ToKbeX+NMeZAdr94XxCXDReeaSZ1C/y
D2FXEjmVJfgktQzc6j5QRWUJD4LKTBQEu4i4ljD+JVEKRwQtrzB0WXEvno0pVsqvi9iruCRlTUbY
2uZQdjeA9Rqn0jjO0olVnGkGshtm2VqwV6RiahA9LOuU8b/ObWDMC8r1rsjG1vZpMYKVQfdHBKPX
IpOv8TChDtENB0KeAb5O1SOVV22lwYUA8uKURTzOyUK+gSaI8jA8Qw9g4xWtb7ohW9zhZDnJl9v+
rhGiHadYpe3rX0v1JrLWoeODfDqQmt/xZXorNmBwkgR5KgelxiKJIDTR+CjYj3tzE1NPhJiD9LCF
+Hc5M1v8l7xvFj8KQ1iQdroC0ujROVFW3YfKXlZNK7l+O2bFEvcicOak0DuZj8IfrVDkhMv6TcOV
PdALUHDtuxiaBPdpKkIovjpNSSXR+EIllZXxIWm8Ioz8hpWWx5XymI58q4UxwDaLyn9nBR1S3djx
0bMf1UA8Kngds9vtfMxdG79WVq+YNY4dQHPaRq/Q1gtr/X4N+t5WgKcltk3vUJgzYPTIw1ogCsDP
SHAsf21Mzu7aaArqLNeqv2m4YVRaZr5OnXKbTfPHqwQZcClLqUbaka4ktyjPFf/OoCV99WOgHDPq
SwyCOVTbxMmtkSpHrIQwzfrtrARO1hsHYgrWuRMROyPTgdy0jp81eJOuxQejNenoSxRX0hFZIdil
2vPhjwxPCGOoqKAYN/fsjMzVq9m7Cp6KgIsSitWkany/S/zlo4n5E9cY4/npga00ZFpaTzMf//gB
PY5XJMn8XTuEDSb/hR4zadum/Z6cBhosADKW4AVj4hrhjVXGjnNSLujV8g7+gnSPOs4TjPhS8pKV
Y5SMqngiXZicTtVIMhab3Ae2GCZcJ9YpD/jZNsg6XPPhqT3mkcp62fJtxB4ZtTd06nRnxH8E83KJ
R8hCZkEwERMO6gllpTG4sA9seqhJUIHRJ4ELOIe6kb02Qtt8G6UpOpXzELcHqeQL4lB8VGFU62xD
gdykpl0PNUXDarCSuiPz6PuVT4hn9M6VoWns4OvkH2nj44as8Nq84kOZc9L8M/DS23aRKNZB1Skd
Puwn3mJVsX8c9eWqEWX2ZcjLSweR+RHUsr7C1HWk99s39KNMce+NDoDfwTHDI2jf2sfHngeHyurK
4fcGUgHKrUnNFkBfmn3V+tae5hIHxWyNkG08RyMvXKZj2zp9J5jZq9H3pkqnwTgtfIbEhsH0KlW5
7Pl7XYNS6DCfvoNV72kwroiqacdDFmlVipdI9mYTkXAljzi423NAR+/tAJSb+RyZEcaM4lesXQZ8
TU5qa28VTpWijsU4ux6WU8pLTL2x6rjGx3KREa0Y1jpmCFFcNbYQuAp9PB92ZORbyqxm5673YaGG
AfKfZBj/YyVikKubrIvJV1UJrFDtweHf8NGQUnT4D46rSwJ/oE1G/WXosnHC9ZU6tDDLr490q3gu
XNNon6AEm97M5bGkeIwpMwDCPqR/YI1lPMtt4rZqRTLX+GbPGEK/HHJtYEzK2vqe05xyKHuKrkUd
bDGh1KOAdmkACVyTaCACONPuZzJL29mfa7YcvN4sDdhkUwrCefh5LxwVwDuIMWDsoVxePqQuu6dQ
fOPiEZAP2Ay4tN392hBIGKM/+EHW6L63vExnCp5BafQ4QIdJ/q5eMLvBDJta+fOOHRpN8neQoKrh
MiGHm+J0NpSHWy/1rrvbJwcE4EHo3xM8t0Qb+i8wHnTUrvBfPM1+9ka55oYRfNaBeey4a8NKEJVa
hgRqnFl0OHXc9H+C4RfskiVKPe/5XGCNUqtMGO7TNGPBpzWPwqlsE3eKWYGI52XGfSTmyGK8xUGS
ylISUPXuMkNIce9upBUKB386nQhxpOlwDr+uPCK1L/dhUsWcKSKf8i9E499qPqrz8Au7sylGIx4I
PZL3hLh8FbHs+Y4VJJLIhwg9+KJMs1ULTgqqFmpsjM8f6+YhezNawkQ+uP2xLAN3q77c53OBFmCR
exJI8rvC4evr7S1xEjAVIAUUfgxQ7MvV6/RnrBkTQhE+yfrBjIdumKcFxX3qsu5NeI2L9hBVMviU
K92YTa8ePvQiN+qZWfRQb9ue90YeIegB5wv4V6uPmWpFlL35uRvcKBYR+7cirOfSwd58aIrM38j1
L2BnPr57ZIREpv2zvuae9LZHWRN1IxgcTdiTOEbyC/0A96bPaFBWUjPUxiO0lqt66LH8Tae7jFS9
o1n7/6j6KOJ2CmNnK/gEn4d5HeK91S0I+K8X72J9gj9pPQz2yj3ELU/xS2X7O4KrOwtcLOnPkPuc
+HZQAy+9D+F8fu4gH66CCd0aogNXOxaw/AriAlGrPRVrvj8dDz1gOzN4VUw2VucajWNtc9lAeN8K
/zQ+1NgVQUN2gjr6vRxejxEK/8KK3WZ7OP54s5T+IYAOdSUe1rXyv1v+hBfxjE0tWluiVblmaeam
80CqZwT2aNp4cSKEu3unkMD+T96izd0WX5TOEcLDJR/WNVXA5kpUYy0mCEI9BKCQuAoWBrUeWaWE
cI1hDszkQugPqZElTByZ06E3nZGUuRE33yf9GWOJij6SXzzJFpzKhM8xCc82hTHxLsGdGfdzr7Wm
xU5qu0djwru8N0MQbFSrconMYQwXcenzhfkYPHv6VrKc/5y/O+lN6Tbk8FNgk7+p7TG4C/3/g2Rm
Hzm8Ab8lQTUIXfBBg7WgvQS9NwiK/nJwtW4xbbL49M3i/l0pgJYssfV20kJwxKRxWU07gik6Z+9b
3bRqM3aWbtbrkj4DzhpM11MvZxG0nm93bIcZzBNV70KGFYY2+2H0gzXHECuwUqI7zM2gNJWSFVH9
vKr7dZLs1I0HqW1YpxPgbFu2WqRBDjplU3G/2qfovz79hA1WYatg4v377vUFleHFHWaitErJEf4i
Ekg6UryQLqXogFZUu/sElT+Gl9GuRFU5Kmkc331a3cOrAYSL2L2Mup7sIBMjL5DbFPpfBLdN2Evx
exfTFKJC42LB3mE0E9m/yD9KrvNOU2lR7qhrxsYSPDjRXegyT8Sgw4BTAXo031eDa+MksvPMJzjh
PeraBtAs+SGqfMzIi3C=