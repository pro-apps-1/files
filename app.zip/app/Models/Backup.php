<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt1qeZ+CznOmIPet75LgsOnKC/W4qv1l/vUuQ9tVTVH9PKHmEXDd1BLzNtR1eDEuLNVHqDPZ
4ZAZd3/PXCX9MOYe0jBwTQ3wbXgkTp6l/l8xDV6vJRJMS5nzui2ZI1wU9C7qxMyoZlrQWHf3Uod1
UqDopwt44297oOToHfrm8octqR85Uy5aq62sLaVE/gyD7Xl3TgantmrVBMBLQ7ctGIcbdtYgqLY3
fw+D0Evc37p6iEA5UbyRGAlqxyXX5WBBDjNYhubOxymazG/Nz8XCYKvD8DbgOk5bb7wdfyIKr/uu
i8fPIwk0yJMhK1Cs41VKIBYAVlqXOoc0Euufe0Pcd5A1/U5YbBfHYxMIIXv86Ayrc5q+jXXLtbbs
MSIBlPgOcsCF6lO9jNMyEIvWndKL4Pbj2hF+R03m0YEbzVEqPgiMhXgOfG2xg8ETr4yAtomfU9Fj
/+uQDdPWXrV/dSbXf3T0g1ddMsTkjV2QKePs9ug9e+6BMiM+rlY7oz2tMgy5ncWXESU7i0DFP4yP
SyrNUX1tOd+U86uA0mfEBucu9u5TshEUmWqXVFMVxYz1FYLcSbSDd13usxu2FvppteVNU3AoxGED
KBJ8rmQk/08nV0kdb+sulzOfcuYx+HOvHJVD+eMW4CoPjKi8ZZ4/Ppx8yDsBI6R702/21R6iof+6
0GaXs9s/QZeqQ1pdw3OCrCZb527QB/mf/cdmUIQiqDwhLpg+V7Bb0juDHUe2Ey7Q8Qzm+hd2GJFs
S9bSyWxiNv+P+PgM9gHi1I0KKXsKB4HZDjbpBqzzdm8FSknennzLTNQICkOWwUWVfbkDuQGTUoLP
EahUJOrqSMqXODmsl22cdzNIe73dUI0a3TiHGET6PEIEY1lF830OrqCevHEzURSzLZMb54Tf0Mk2
+P/2Rz1+9JF+ii1BfXAs5vZfa8RU1ovj3P7ZEQDshyjddUvsllp2aSTKyA1ZeKneOHmpCklU00f7
5rQ7FaJF318v+EAKA31DUfSqtMhmIZCLkVpyftXtyCtf3RdizcGQ7orzOEkRCaE67kFun3YY4ktp
I6tsqP28zN4oWSER49m982nrFLHDD0riK3S2QytdXCygHMKEOg7KeohU9THs0Jyt1jdduqkYO3aB
hwcHJ1kRt/RHf97iGh33q4jto/vseeyGelOI6wjL1lH+OHPKBMzrrWE/S0+7QtVL1xn1AZj+JY2+
WufeW9+f4jPiS365WkgHvx6fa6DYW2VrVE1X+8brzXjsXnjXvADCm2+xPi0/4D7SV3AErAX8aGP9
QEU1tx9NoK+Z1xITJjugiNT8GViwSLdHkV6s2NyCq+w+PCEFDFhBwRroRuDLrfr2/rG8xYMPL4Qx
MMChtZr86a20gBiQS2FkBXFd3ntds8dtIZEctKl9X8BowolpAgO0TGN+GF2FgEff6eTPITheCT+w
Mw9vT0T7tZ3FdW2GKbkO+J6EP6e7JAIlvaxuOxBmKv3HnSBuAq9WVxmxDclhDsy0d+ZxPme7+Cre
0EV4S8X1oGCxesLYYxQMiMoeGSzZP7QkQiCXWGJ/5rpyKbBfW+QYGb1nPMEZuvNuJz5/EoAnJwpw
07Li4YnIYSO8W7lFW+D1VtgT1RhO2z1RQudzhduG2xn536FRuPHmORwaPFYZQMvlSGKMtLK0a85G
yT09D11yxhFsDbRcOgD8ZNf9pWCD5EbE+uaAPfB6j737luFs5/5WICr5LmjafspsFpY5WoVLTtRV
UM9GbKJr3A1sir1kBAI4/qpl6hoQun3WpCufqCUhsdv6YisTfIsQ6ErlDibic0c2lnkIym0ZS+UW
jFLK7NhfudyW11MXrSBmtKWIqx25tyOe2OqFCM1G9Xbff+Zm8BbK8K+o1Hx6PAF+J2oebXafzt2g
OR05w1KLMahQv61la5q2j9Q+pZPk9majaOows0WpyTskAdJYL3ffLmzZs85BjJZouTsU5PZCLI2a
cJjFU3FygTRascQl9PohPHqT89ufJeGUq6ITJORr630rMGearK5eGBoalrZqOaQmxExzGeJvbFrG
mGECjuuJJSntbwor9Bp+p4pj9hW1oduac4xrz1P2kOE+W313GT6lLSqKWoWohJtqIWJjm8bJqNiE
h6EiYo6VMxY0eWpw1jrquXE7exwMWphcgqLnw2sypjUDAEy2FnYOJg81MFqt7Zw0fDqVneF8Z6zb
9+dvT3EL9ltcWerusVM2HHvwc/5fLAU61ef3YhGp/fynM5AnnO+aRgIWPyj7nMfX0shwdzckAN1q
d37DRquPFPtCThJYjf5uOC3S4Rf3pe1OeMGnP87MJyicoT0UKoUeng7w5B0pSQrpFcfMYr7GrW/h
lBeeBQcKQYDu75JMcmY7MPMCX2ARXoi+SzXWDeGHoIq+6cPTtfTxEyUyHOpPuN2ghPoOcujNMx+9
O0BMfE3pfL6/yWY/xH4XfLsJOFK2cHZFQO0S2WAsvugpRSNBc3Lc6s0pce3USx3oNM99HCxTHn+a
58L23oNbHM6jQh+zlLYTwC9UtUX0VCjkYOQ177lJEzAl7hUM5HIMYVSrG6yuxU+xXv0FCvy7DEqb
FTYFH949LpPFmzelLkKM6NcYms5clxUz0wxug1Hep+9kV0w+Rcru9Bir6mzOU5vAD9Iszar1aaJ/
gBD0dJ0TkS1kbOWmXHt6tiFHrOvoly3Kjr5yfrDJPS4Y9x3UEKWf7yPa8+8x7PM/wVLGFpYqHH7S
M1hCDdR/YVaOIvWSLJhEuLnJsk/ay39UO4mIyVgNhJImzL67Yl4tFO4To6pbgj51FuN9ritk3xfg
DJU7pA+czEXlA1kb2JTDOaNRADh9rFD2ePIION1QmdTogW1Qewc7RUJ51pTRFUzFHbEnbj9r6owD
y+WZ3kYa+NeKBCCNEL3V/x71s/Kebua3+qpWnE7ZzifAKnLl6+RT9Ki6T0/cEYsx1MBDnXoc1/d3
GbeQXbJcRPtpN6YdovxcdT8tKfR/11MWpgdVypfhNwoW8NX787ZK0pTRNq/ke2uaE7w5RPLrtwLQ
eX2P/Wuoie/PS3Mr2A+brpPsbQWREpJjYmc9ZTbIcucMCD0Q3y7OUDtCLt2L2Nuxr1Z2aSeFqEdm
h7fxoc6pYiDYfwwusER6LQ/Du65KLiC1pqMeeT5S1sckVzk+t7Yt+NQOaqIQ79U10xaXUIOHcOR6
uOcOotkNg9IxfLlCGQcMjRyb+uegUVVF+iEX+aswIln6V7B9fIDiwClXzaqLOv2CzHpKo4mE/vA0
nVW6P2Gw1bOHSPqAI+8sdwTSr5bQaQkdwuI+AlRk59Qdrj8U5jbjms9o0YX+HxbsH3gp+nAGFxNO
kpAqNSD/6Dstdb+zOjuFa9b1Bck/koIAXSfxbraczRsbRiZ6YIHKhdodGl4Wdqup5YIRvUvJGxeW
iOHY0TCR4seXyOitpEtZPMKg3KnSSAhpEK57Dl9uC9qqK6cF1sZfN3MqVJgYRFhRrd66H2QpPUeS
a4qjMNM3mAMl6uUL/OTHwBL1ES7tQkPQegvUIlq/dVPJvtx4VPoQu64/xyQ2lht2R4AM+no3L23L
OydIqt7DjbdzEpPrnh36aWGwfrm1vknLxJPPycNEhU53ojKlh6Jiz1OX3E71pXCL2jVzHTsmfkvP
JMVpwza6f2y9EqF2R9Psh8wyKQdN+Z54zbbs2G+eSm5Q3viHsX3EueJ3D/DXt86y/Q37xEaAR1qn
J24nlQU8iYPWA6XbJcD6BNODiHqap9k1rGmDDy5kGV/p9SsmZ1r4GbavHRpgl7UTPjHM7lAS55XE
ygQkuF5MFwWlf48c744RMeNYT/51KXs+PCEkUR481P0xV/INYqOMdpfjcKPmTuQQQ9rQI3HqYfXs
cxI5loRpH4CEupzZpu0NuV23q9BZty7PMeHdSWmAdwD2fLcF/QhSi3ER2GZrxr1c0vAoq6sCsi7+
jCKYBcJytXNx5AsYGibfqR5O9XjvwznfLuaS4edpAFdrGGHtgzpghL56dXFqOanF1ZBfa6yCJPVa
4M4K9SVu6RKmKbnZhi/jyLBhclYQO35IrNBUXmty0XaSy4P4mQzl7d3fwc09R2thGNwN3/VdvtMw
os1bg1HEInhB0jIB6B3xISanRbl4AmV5T+T5bwi+sXCJkiUjy6hlrEel4nGge8B9cvoLIQqigFIR
y+Mtzw1V8ZGSk1E+LQ1eTKiCvU+CWhx20YLho4gDtfNTP+Kog8vY49Q//WaEMDlfNyPM1rmOZfe1
ewgLmnhZqiP7HNpTJ6JQPxhK/dCJVNjVmGzAyFmmsrOYd21B6MLEOmICQ+DvaHNJZ4qzs3habGzY
Fw/y3OFJqjzu9e05u7Mk22U+3t9nYbK9oblKgwAKQb37uYE2Cya/+v9GqbXoQkjgUuszVaRVEWtz
mUqK6STCQ6fg/KvavxRrTsZOW6opUNcBLtopLOhn1vQUqLLF9NwnYlkZGhll1auXnjDE96W17jmV
dVAQTvu9TVR4DDUclF5IDgjacn/LN5P4tknuvVNTqOxA33SJoOEoOjrR91c9lsjXIgabOpBLNFoJ
Cp6cnszdZuMGSe5MarZtxjIO9EpH5d0nSD1/Pg35ekkEZDmWILAyn6uSVkBBhYshXoE0Yktij6BA
JC8wowwIGH++e4LSjUhyQUPTMF+V5yQTzIglvycHpnj+oB0W7soDZjJ31kMkrBRr4jtCyps0ia1O
nXsEWoQgHLqb+R5gp3WDY6UCdqdLmnjzx9zkBM9Bg+8j6NvI0jl9N+SSPAZnJzQoUjFA2NF5Hp9p
xxBjxHAiKesZddrpqrzI/MGTLSnUKREEVdQ+aE6ohMx/7NuiP036HVKkWCwExdH0uICYbyXHaTvp
6qgPcpKQXF5fW6+yx/HhBM4+vqZWvl9uphJUyU3iT4vRUtFt9t7D53MJBhOvbTdlMFXxx+BuyAE6
9JhhDHNFu2HuQkX188nfepUUx2M5DeggvT2+RKSZdOb3qDlzEsQuKax/v6Qok1WrmdljGR37XIzl
0om3kZOABEu43eroNmEProrQm1SWCc5HnaIQ64dAycRER087lMonERlECjWTzEZECg3HvkTo+cTg
n6iHK+aHmsV4MmPm6sFDxt8hcG9G5GwbHu1crzRjyPeuYiFxI1mv2QCXtZqQsBiaH1c2uLLYlEIN
eY6/AEX7h/aLJKkFlYlQguXZFwR4MfmkuuypkxxWoRDas7K7RnWobw6LPdYKA1JkXKExEZX2YmzS
mOkPlE1t8iqAjKPTatlPOMaevN1nMm39grskWcySYm+A5fIc23qIfs6pq5w8f1A7/T7/MUB6v5f+
llV+9Wt5SSoWEPmL1FAkvdHBo/icC3shFhNwwY3/5bFEqvFZ4mbJ43DHjyJd7ljWuhKwdzdzsxO3
NKvohpxjVAWlPMgQaSTinWalRSalHCMIJBy3FsAHVml0lxSGSxd2edM+Qp6U2O/23DSDJC8jJnaf
v6NfH+NJtTHfY9Kq5e+IJ4XQjMwgVv7AEgMt9FyiYW35ErPyHLnACLgZfj9R8UONQpjzwv1DD/Qx
3P/HOuU2NOePtefJu3+o5OLvv7QotDjnDQp8oWSc8w2Tcu4dc1suZ69PI1VBFSamEPpW9ndzCJtR
Jt3HNIIOHLhZNi75oZODcvcCVMXSXwKQ213FujiwnP5ZcguWbc3YK3rZTXEOt9Ee3FHmfew8t8gD
VJM6SrFzxAktKL8+RP8M3uamRI6Rc9CwoKxbduERwhcCkAiasy21bAxcalug8coKprh4b3wYJDQD
Zqij2JOOL86dL8k8zWARCewKLQV/hJ5ePT8lUiIYVWri2X1UAE2DNd4REuBqiaLkw/mRGdEgpUqj
YTFWZ1QRtDqqM4PAAW5ZxX+YQcUw/xo0zHhzmJzYH4H4GKfUc56V/QffzbUxicWJi4TrKwYnhnuK
UBRcGOQUI1I+qokT+ZNsPzStXxavLw7qdPeg8gbunUy8IcPsODGjhPewET1tQX6HYhYPOUMEVhuT
Mdl1yuFYRl//SDh8EymOiEDYVu/AmEQB3j80JXNQmU5+RJYrFbsMS9HyruEklBfXFl04+K622XpF
18igzzsp6FDpdnPAHPyk42AI1n5t+Jgh3Chjxh+uC5txWlEH44WxlEYuWBipwJBvTdDSt0RPL6H9
dnPJ2iXDUY+zPzqmvbB9y6I2foS06JL9Q8h20HPd3Lkmu+5dBfX0U1HNwwCbwFESaZrMNqs4byPB
Ti32N1pFttbcbl5a362n51cFXtnOcLs2mXMjm4EfI5I29SprV6BgSrfxD0cw1k3fRrt/AjzkVj+i
PyhgbFY/WKrspZ+R4B0ei9ziCB7bk9vDt7mZu4m0twfguV2KNET24dltqNF1d8g/rsnQeFceu/Fa
Q92zoxbUWFgAum3DNrB9nC5TcJVOZyGtCUEBkf4nPWfzESow+qemwWe+1dNzMC/2Xd9m7pY6djUH
1vOl8hK/LGkC61Yh2bDN4v/Y023zz418yTYYMo8tzadW1sKdkoIOCuIYr00mGFUtnemhyELk3o/u
fg5jRKiOJ/DAetr0jN7aUeFut+oYaIA35vfzgPCVDPdHEwwI81Lj06OQ9O2wbOB1vwkR3VNOOaca
oQsgZfyTrqJ/uNNcbXO3YQ8lglKGZFdHjlzcxZHhYdd9ZAhdN4ZejqSvK6MZfE3oi8wEZynfo6s6
w3yxxpSB4+7IQZ6w1jy/3BnWIYvx1GMHN3Ssc43+n7080V5JgJzVSzzvpg3yHdmPUID+5ANLwJt5
oTrXreK5TSQW7Z5+ehjANfHIMvKtKviJjvITkYzLt9zUCgQb2PUTpgKgVI9ZdqXXyKfldSW9SK5C
lCgwvA8d6U9YbBhxnadlS44Hxo8tGbt2xjyAn5bnQeIiYXwtJ3l+oM9WVqMj6wlrdFMN9GZAWuPh
b2F/a/h2lvBQOEquvIBXZg5dN8W+Wae6T2kHFaO34g7GhE06oDIMeFfEP46rety1YCqASVlePrgR
74XkfA8Cx6Ci9din8vuFREWnzF/GJy7/xZVI1B6pCgVqrvNboA/Zxq8H/i8OMM8tA6iEOimug5oX
S0Ghi5Om8sEL8IJ5j7MnThI1Rm2aAqB73M0Ba+sGE0MJ1JJFdI6CEHxNdQUbpDBFkvkMC1+JfbUw
kX5tqvF2p9EPq7vk28U2MioenEp8/9T2DZ1i5CkvNOPh/8p6mlAfgEmc3SSJ15fRAmSSjqQpSwa+
RUK0b2dQYMXHGcKWx04BOjdME432AERZbBWj4XmkQ3VFqf5dp0keidxGij72pbc4k2NI8zgeRmtX
Nrowe9fbiRR4dxqjG+cugVP6CERjVNFtECMbAuwnYDPuRqrKh/JTyHfPMFTkvib+KGo6IJDn/d6D
rqsjOHocJA0giUxW+5TMyGP4ig7msteJ45Qf/f1fGsNfBNrF0klfYQy8Kth0TKIHLQTAfrpAtqyP
4uKeSi1uL4i5UlKnet9Iqj1uLbauOyeng8kwsYrrDfXGJpanQ+rqqWhAzVUlq/UwOsTubivlKRtj
lQ8iNHaT76r/zBXXzK8NiE0RLoLfiEkhTnuirRY3+NQUN6AFJtOTSslrEVXgt4Noa1al3wA8FJsG
Ijx7JWaK56dm6NnmYbqnE3USoHHEBFYnpUxC/JC9gMN1Hco1ssxOLyMPaIQnnSqJNnPbt7+GZTlE
3QGfj3sGGBxIksopmyAuer6LNHjsNE1WFN5Nff0FBanxLg4OkyA0uGATqUl0L/pPUEegWYXGzEsp
sREKYT3hsleSU91F8qrhN5s6DBv04Y7g5a2G97bF9UrLBlMgjP2l7pcCpQYWBdn8UpDQVDkSdNGr
gNfsxw+uVyToCYCi728nhvIKOWFwlOzjss2yARB++39WDNLcCzcxCfIVltCCjYT3QqBOXxW4Ghue
ax1SBMELsTtLwrtXK9evkO2NRvdiB/FZAhZI4Iecad0GN5jY9ltPtaxyDg168FuO/tZ6fKsMmpPp
2FjKlAjdgqsshN52JN7hIr1/z8nbFOJDnVTnTSiF1eHttfRKKRwhSNq6iDRsYXzGiUK4RAoXcB4H
Srlkta+X7/HRhKY6wfZGVZ4hxqG+Ggcr7QX4fX3j8E5RIrsGAy5cX3AowGXcPgan5OPxqWpZaZ/H
ofhwvqra/SZ17oEmNPKvL4axEvOXUv2QEUgCruzpn4txkhoeFrzeREI7PdqxeGM6y2X9Wd+wfOTZ
y3U4CZkR76iOxE0oqc9Z0DJ7+9XVcBSbE19nrqY8ob2h+oDpRrTR50Rkd8lgG67RvDj2hMeiaGXq
m5yxm+Inez1Y8OEYHP8zvY0xs5vlnnxgUGBMFfbjNQweSWJGifdjwQ9DOCNCWxZnUSJaYfL2WZkb
wd1aTSJBqAHwCvlhZxgTTRnT1SbSyE9cFWji8m+9G+KKA7xh4jBRMidoHFh8px9g0QCHTf9+sg4e
qlqbnvqqikj2O2MDzIzUd0OeH0GJS8K8WRlz4Ri7o5TzJ5x+ZzPvaaEkJqUYRtgKkNOd+vUErXIe
5Z3YhWfQLW0IOF9+Ea/6NDBzFx/x/a+LWA/ouV+vR4AXtDkT/cixqHVEmHbjwxXOfGcKkpiRp/0Z
Fv8xYw47zVldghsDnvm+9jBbn9iB4jWXDfEMYDbutWxMgb7aQrixkK6WHr25LW==