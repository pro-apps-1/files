<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsh1KFycOsEfy7elnTnB6iZlRqbE8zeEqDMd0hkCRzulmOlv3i4gWHq7mZME0sPn7dkDnd/5
UXUB8pWkh93WjJgVtef5GtwNdR7YhFAdS9WPVWhPnK2sz+ZGkwkCXjB24KLAhONTZScmSmPfMoQO
AOmaHCgy2jNf6eoHUbSGDhzwcQZ4HAcCWQTlzsNf5RdPbdoeOS43wGc/Hfuq5RADYkycvKX5KZLv
l0GAvnG539yAv/dvOZ99k9UrwZCCyC08rPo84FAnZnHPpE9J5mc4XV/W9l9UQbCdbsq1KrQXL5r5
zzno4/YVDFR08A47bbrwoY3Fj6pZ30uP+6IhkatIqxdKdc6P9ziWEgm6bp1QeAK27//k6zzQwV3z
MWJ3rytmv65L9VH64grMrd4jWphtdjAKlvNlzR6AnXPMWX28GzGZ2GRC20FSXIFjpXgIGd7LAxM6
sq7UnvK1sgRJan8aK8isl7REHgJI0SMRD+l9GYUU2rnRt/fcVzwt3g+sFcSVOHHvlskja1ivbJ6K
fgknKgPdMFCSNO3fJI8GCML+ifkXcDtACoxZbNMSL1qpAord1WivMKGL2A0uThed6hJSINP4E1oC
WiWoSsF317DuRArfIi+3nTD7Ud5PmstYTvDDQ0OSvLTfpeHhbSX+CPznnXBPcvqmim7LJFETkImt
qwMWvOm6+66mvswFLV+IOxSwt73LGJyRbKDNbDUdEB4GiwcgveZnJ3vrqt4+NVuZVjZOhfdJ4JCG
Uuf2/c2t+sg4FRs+6+++Il7toutUdnj+dUxF12c5I5TgKLBiYeztlV4IsYrYAoNuK0BjMkTc8b3Z
X2BXMGrtynn5OrwO+OQGYsbVJnZ8cKYJHUNERH/Eh4PDYDyLmvmnEyygXh9ieOrGf+G9Y0FsEDAM
qgD7QrwIRIKaim1gmT7Q1c1RtH3b7UJwjsNzbOQbPu1ZRsqXpQk4hdoVOa4P/XhON2A4oxymgmD5
zC3Ly64bu+lGu7CdCY9yTzK2czBXg+EIUOBH4+wWaPdCc9KmRVBrwf1vMgm8p37tdy95cOphnfAp
GQxzIhT89fn7eDVPt3NZvLHRhcLN0KbSYXcUyf9M/vtPITUBAQuZohBW+YQjY//hjTeaaSJDb9MU
bQJ0gDvQ0aC8edTzBsGabMOM4C/DWJ83qO9JBu97KICzrKYYlFOq4mwh8/I5hYsepfZ/q5Xe7dAE
xEYMb6cTrpGLW4iMOrkgMhTRKR4glGBPCfTjlL2u8c/G120e/SXLyjdwBksC+sKM/v2NM31bGTSZ
wJ5v1qpRhHOiUQeqvvbpYvtUejTK44xGZ8MNlDNJpuV8mYjuhTBhd00YOoCQ2UsW+oiradZR6+mc
KGn5LVFwaa9PUovqJXKKJ9sxR2znjqFO9ymUDA9IdkGApDuVFsgMf2qauKuBr25aZQoxSwxqzRSi
gnF2ys+gvYXKr7nnouqosZT81gNuobUD6dL3mqZ33Sox3DcDWi8iNosXahhUIE0uw/DJ82xtb/1d
STv2CMHAtjkAGgKkFZh9NPQZOjVAdplDAa/cgr7Byy/FZtP3vJUz6ayuannPUIfKBeBLw5oMZLcG
Cq3v4ASp9uz7CUk1UXLA9GMiZl3hs9MayXATR4xLNzT/z5lDUmSDN5yfYOjfwYRy9GZlGh1D0/U9
6d8Hzjj3AC+efOMcri1Z+LCrdjuOlX3/PYrgcbJ8R87qqkme2BQnSYoULI5+CJJ+35STwMmwbhUE
FauiLVvSwBwLnkb2THnwRpYMJpld9EDURa87/8Xla0b6cdEweJKbFgJzBPN0aHxz4eLAJHR+56/V
Ulyqu5tAThmAEIwP5aKLWSTD7gudkvfIxGvpBX0aYXTm6KAFBZ2ZjM1JgAg5CHnD5xBqGv9Yvzgh
SlRuuX2bvqidS1UW6wcDHH4H8ucqpu/MWG7jcXLIV7x9TNQmKGDe/VcO6t10Mtgq585ZtFMRHFTr
6GKWPxr6VHxvG4rZS0wyC90zDr90jogFTAeUWsf8rkUDcD63LIpHC+fQ1PR99HVL2zV0iZl/+++4
r8CLgWZlWESw2Owg2DFEjSnOaa6KQMSAJtotqFmfLYXJ0bFewHoVea1pHAwmYkyNAomMvOm+YlhV
VGrAN3Y5XV68WBeKIJe4ckawWK8L0KwmJApxiH8kAuvOdvgiIXO8pH49dv8StAWMdbPq7vMKN534
8yoJu6ZfaLbjsG4glSYvLS1E8okYE+IyJpO9J1OSO4R/R2h6D1hdBI9MludTEWj9NAB89mtb4Rce
6887sQ4CZ8cPKKepBCnvrC0oz9OoR0Vsc/R5dPuaYslsVIWA90R8ehjO0YjdGwckXPOZ+LesnsbC
wWb2JovFbzh2P+4d5WBGndvkqBrzhZX/EF+mbM9lvb6MZ9yq//AbhVpilJNjeu1EX+Ls5m02CJvH
/sI+j5EbhDRrOuk265JmM0xLFYEVTGYaiQOoR2y3PBSsiQQQfu679qxrkajKr2QuxBa7sGXNU7Fd
jOBBYOT3D6C3HZ+XTwqGvZTEcH6ISp2Ucb4Ceg5D4oH3vcP70AZPSAM/yV+qsXQLlD0H3TAnSnlV
B0qWzAKVTHyPMENbcHT6v2/U841nqQ3fsuse8pDTHv4dOwUKpt7dR+WKoUV0Eb528XzffV+cumvZ
/GbkgtJyKVYE4TJSu9goUZjiGGFoYNghIPpPhtWVoJQpqYTqIVhIHDM6xAnKjT1JYhx0m55LcDEf
32d09nxrkYyU7AdlBpVIh3tc58qVIr7hLsqJAVIkf+6mwkKQRL35FqpOzN9+Epus1ySTUCPjTlaY
Xa/CVWQGMO/e9djHzLtuGAI6wi43V5T3PkIINb5Yd3++3Ukdc8i7mylf/OpCNUVKFsP48Stxcb15
/2L70iBE2Ib99kN1fS8i1ODO9SQ9fF5KeIaJD8RiRriXXa8MbNGxCE48U3VXpfmrfaDJfDqx8xJk
l71uUCElznNBK0NZTVk6QtTZ191BzZ9yE18coe5vtPlL0ZMH0AU5m0d1/4zb+3/6Ublrsm3ZQiWV
JwBUowaO4LZXzRH7/M5qH5TBePHW9v0kytlfZIVN6N0tQjlBH5/U+CY5hg0JhLXajvVbED0Mnh16
fvkfhCJ5wt+rOOuZOtpAXuqNRV2w3EchG50KAgqF4P0Z8ySlj5qaf/cCQgqNbwy7NY4RpyhYEpam
69oRNZt01SdVDHRWW4zkPdtsah24bZMZs8G4QFEDKiZzw+rbeJPEivnbPuHeXggSmNiGBikJHE0e
BaEtIy2jJv3+6WJtbT7qhoo1mrCOypC9trYTw7i07SxBL4oXIYOSQMSaS08G3D5hS5pTzHp2Su43
OGS6LUQaXuZlDW4ulE9XM588cBYtt9cChyFf3zOMOH1SB16p30X7FIz8vpfWcETNVj2iGcxagqn3
+NiagcHMEl/q2V7KDFS/enDoOGBdCzW+UeP61e0+ftBMBmTUffVH4EWrViTX3WC5p2dhrz27uIzU
trjs9juP7Gbv129Kxg4KrVJVV9YE9CxskPgoznE9+MwXMxVUCYsLUjKS5z8R65AwyHStGOOvUGc3
Xn0i5GzYRNl7vUItuFD5+AsjFY98AnY76eJnbo40wwYWeSWq497Aecu1d9s0D1vXeEa+VOZRrSDP
GIznSAyVgkSooAVbRLikh/0gFmsvsaG/n3wyJuTucOk72qMKSzbiTbHH8nze0eG6Y0DQ3afKGGAB
rDpi2+2be0oSZ8Yn/bvY1ZbxDaH1qN/o0PDKYOAeu8AmXAbd/nY5AZNA8UFuDUyuNUdV4i6XhXai
1b12uuvfQWmTosE9uhj5n/aE57KZc2EI4GTJ3E+Q/7PYEdxQm8SmVDk1U/aDgmK7PejRE93XWjg9
SfDod5gCtvlhmGGIZfBDAUAwwS4xaoJSAnUIf5ZTHNLTgRUmPKJ0ZSmIbx6V6K2CYvkXBcfC53fG
tFggKevLtkS2ixeTtSixRIU0JrVhLHoOayTRfj1tvv2+XsfF8ZqnJx3MoSDQXkFOht4N+7s0xqmI
2c2eG2mM80qIwYENHFTqL2LZs/5Hdi10JhBeq0xE95bTUNo2PVCTucrO7MZ5RtUXocLjbTU8sMwe
+x97xfmDmst/pYRblA90oWb63oJD+xQgvgXIvexDgA3KMspku6LkIgA9oQcUFS0c8YxWvamfnQyz
eLDz2+VQrGtw6kTQG4iITmoD0liiqDyg1t+/+qogKysEQ1QXfvKt3UYBcDH2NhvXAMMx71Brs/0h
EABUXgsJ0tNicLnyLjUzOKu4db+Dg0tzTOzMW8I80eFyX8HgrSbxNNRYoyesGkjBA1E+52lxbpUp
9crJhVUCRlBQ2qXbOWyiAgHKP3gONObJpa7ydQ3Qjp0HQNV4zZfF3aYqwMTwWwq1D55NFquc5dKb
7Pctu5J9v2wF2kAwUV82RGQNyL0ko7L3D7aXz4pWo6adNMYI9KuJpjB2nTS0tvwGV7jlgmWImimE
GHsOgytT1JSc+wboqqbaSS+J2RvOe+Bpm1uAfqGzEnt0OJQg+luaeXtPiRgYg9QMqY2KotvbkvC9
EuI56Y1MS5eVBKj047MgKBqxIoIOimrSUXgoZgnvSZX2HAfeaaxTycvy181bsA34jNI1zMGg4SOo
rHyY702IvujF4yj2cTCR0stlM7oTI67T6khekY1WUnLlDtc0+bHPw4hRphlAae3g2M3AAvSfZBrH
lnRqVDAuFG57gZ558Ezllqs5SVo0BsIhLQrHPqjZeiJc52MjyaCETzdRZ46Xpyfv0cxkf489bFSo
lhl9oTwc9RyonuhhxrSF/xGa5bpMh1yc17XKIYvSADRfe1tcFnGsIVk2i4g53qchGLhf1sOSeEhH
RirvmirLsedmTVqkIw1QRGWBBVF2b3XJmFXo6BtbvnhFgS8C/oPCPtdl0kkgem+dUq1QZkYPKk2K
38Y/lbNZkj4/dl/LEvbvjB1nwS7jYweaWrHvI5U0yCWNnLAR75Z9AdDwlmZXBgKMOLCTrkAOwVa/
8fy5L7wHXubDA41bVhcFNZwNjSyQaQzcZ50xEYtUDDt17f8KE17NXJYHkla3WrGCq8IlaEtUrBuI
mtrmEp8La/YRvYkututwRsGHkEUo2rc8N/XUAYhleCFV7dmnYOFDSvVDG2PPk0DQtywOBcCFYGtn
PetHeYmOVq4eOzMDscYDAkbnrGG3Dy3wTpBLaaWR+D54bGWkleJh2nhMRGmkexHc6JucvjgGiImx
fEESq0QBu5DTYgXjcc29gqjnXBI6mpsbS5obwRtwudUQJF3RSJ3LGY37oDf0nDV/VMNxTxsM8Ici
UWgrmy4UWYgX4gSZtlWqqm4Xsd0fsXOp/mddD84q0dE7N1eWjP65Jk9vWS/xc87saetUqhRmYEVZ
EiYzzvhYlCaR6EkPeKN/yEWXdC9Yf9mqG6gmQNTiNV2HIlcxBYrULdbBgBMH3RDrJjKOz5LsgXMB
8x7zsVQw1fLvK8ZWBbTBLB3X9/ygY0Fva5CaYrtca6BETcgmBmAdVhUmFYoSoGhxaSrqxRtiKazV
VdpIvQM/mT9+Fa5G5OwqzKhbaD1rveitR6pEyhaUoRRuhEXwD/kyjYjRz/0H0o2KFJVLTT73dmUG
AUiFXhdYcnWTin2n78dEUgsoZ0+Z39Gf4Iv+2TF5616lVJsfVRM0lrcpPrEobdgYxeCgJVvEWltR
vzztWrEnsYThpmzymxrkKGxdL8HqHZtu7LzK8UBAh3CjE/aUcjidRPJZ38s7DNAOEuG2fJHF+lA+
KHyJZjnXRj87IBYyA7Qyw0ufHpLOf7Dwj1xv4y0pK8XmW/IuT5HBHsO4rs3YL6qO//P0+Vw/qzB+
WtWqLj+4gWoHG6klHl6eHbgoTBMzfUvsL/sxJlMNmlxfUaFPiPzV1JPaFPw3bZOB3Fr4iqu5gK6y
NaWwyEa+i+qIMpE2Dwp+vEK6RDOBKnxHGSZz5EFpS+yNADlivCOkUnrmEmh5HKfQqkPLKprS0YhK
GQTKsX4eY2uAUJiv+yFbmxbW38rIstkBKzFRjjVe12Vwx+8h6oXA5VlMLokQQMvYuBcY+eWFgCJv
wbJ282mgropG7kX+4lqS6+t8mlUUlbEVXt+PZwDKjS3gRQTSpiEme2Y5nV2AQK44eAfLMmzug8Bc
ztsTsPLHnXNWJV/xmu6/foBV20ZfJYdQUWAEvp4oeD/sHq18ebuS1gJ0TQSYDx06zgDnyZjvyOTX
YEjGJraj2JV0UMshfJlu+8jFwv4HuP8bIv3qIIWXh8Ah3Op/Z0cy9+IUhkZiu8pxwTbdZ50l7dgo
adZq7GNdoe6d30nIAN494t4/dQq95L33DT4w48OEx+NoqLnjKcU5zZfIknpGbJtK/lCYaaHjTmzf
7KhsJp3eP0+I1BW9pTk6cLCpTapL1QyS5v+EIAYvGdoSad4Ywvr6BO/J2ZZkZP5/Yv42CxmbcF7i
zSftcfEe2WNcH/HIW3tz2MXbBaMse4J9uZg8CWeLfeDdk1htj3QOIYDrXVnT5Yhn4DAoJlykq8f+
qd8nqHc9PPxbpocXL32pteYsxymuJgomnewWQvamcBkMMGpgmuXopgUcc9396/IRs/VWoTR0Qkk4
aa4HHah/1TqGHpUm+2c3+LLWZjuMLCdVl9CUU2MYkyb5EPuN2PM+EJZTcKH2XSZotkZTe9QJAFFH
mchSu/ypGr/KrLaibcCZq6R+oVMNhDa4yVwo16JcgS8WELO+i+7zb2uqJq+JDWjGAoOkRWCCZm+q
8BdSRgxr0och1uXyQrgI1I2POQm80xj7ycmhQ0z7I3H85yAu1Y51CCEJyo3l7HFl186E2kshkxNC
VSo5GewXgHT/RJh8tV4Fb+UKmpDGgsXTASl5bi8pIzhphAt0dxuYt58YmSa+hQwEKyMB+iMS1eTV
HXsiW6bPOJvOdNydKIYaGGf4GScUDdn8+2VjhQXn16Ml9oYAqgzdSQe8vnIF3PqZJdjf+dFxiYmK
GXdKFgzvR5NR5/lrIA7H+PZKlp9xX/D5AKKV85vIHHrTH6Rw0uStQKjHu8wRn6EguLCrlt3dlN8T
f+I93bG/l5tknbHiLwMfor+N3pduDH/nwJ9k/uHbDSohKSvTlvrGvmvWPk1Im5OqayOP7SvVXE7z
JnA9Eb0tu06CtCDf5BtdVayQo4yBQ7m/83Z+yeToCQdPRwBPbcSLVjo7MYnhZlZVEAsaEebzdUIZ
soZmpqJ/U+ealgdNZhni3aW+3L0fgA2Ut96ScQpvwwo33l0cGh1QSj86oZFTLEEL1PIag5YJn1FC
S0nGKrkZU99BL5X/AbUpRyB4m++ixLSvHcldaMSVJKh9vmDzld46bpE1U5U0CG3wnmzQBn54N4Jv
TvrbKvgNG8JqG/x6QT5cbWUGIzZqRkgGGQBI7mvX4S7fGaLTf7dl6cZun/19+n9FlNlY/PW8L+/M
gTzRRtIvqhkMeVjB1I6EL4yUnCP26iNomaGrB8UlkYY4PvvxMK2Vcr3JnSId/auqdYMtAmCEMnRF
KgSsDNDZyU846ruxVFnN8adaaSeMppNNTeoGiDVoOsJc0lygih1Sx26CPiGpEN0JOdIFFibVgYSd
ptelpEMyFhSM/YM3n2L+uBaaRghNOPshU7sCGHApCxf002Td7p6ikclcbBpk+EckdXZ5LFr02qNu
QoaQMXl1SbZc+DdCGWKX4QFQ8iAF28lBK0xGLAxS8zZofZInAEWvYeV0W87Hlg/gx9m8f2aetg7q
YwRcQV5W0hVuyKfLw0x/MlQ53vRehF0/Ztm3wDgBQAGPHVvMfWPSLrFVXrrEckF/h1QyYonRmO2W
3Eo40JO85KmzsirH7jG/hdAEyUP2gc+fEwpGjhtqDNr9273YQVKgpfxVD/QUPEaXEc5E+y4STrin
fcFFLQmX/q+dYMXxLkQGPUtcixH+qDkeEknU5q59P6oEPOPINtHr59IF5lsDb0og+DFO7ZvcXsgJ
bo01gyTerkAxcs4IrFSzwUDs/FzY1fux84Ts3wAONG6/DP2QNlU13xIYidEIrVXr8igYDVOhwC0X
4M7FfVMOCkAP8/0E7DJZpe+KOEBgzMaKf5s0T7hhV19YtfrHcNclD9ZtmS+J3CnAtKAhMJJG0eJr
iy9Ob3a7bH+cLuKFtLfSuKOtnQfFPwb0G9mlovtc2kl9Dt6tseLYY5X/u9ADhEKg3s1LyqgyDx7g
xQadgS4jTvXV+PZBZEjkODKDMr9tdcAyXDakwUQNxfgqXozbFiQq+1nE7fEPL9GLlZGABPrmflKn
SFuB4n9aPlLRMTEtMMhnG5T4s9VqdI/nvROFMQzfNtitxu9CMMjTV5DYRWuh3PDSSHfOTJIwwa6b
Rm5UN28/MWmkmFQ+G6hZRbnMC8iNmEgFhqEPp79I5GIjQGuSPmor8TfLhHGWGTjL9tMs3Wg6AqlK
YwcU4mUQfbxjnHIQsi0pJDOraWUZqSMXZtuBFa2ks8alZuKG6DuxlbA4OKYtXlW0mAzDbMtkFfqd
MrpM/tC7eOU3b1NC4Kl31iI2XqwD0wuNfDEs2TKJdPybK67DoyQ68nbOGpgggWWdHS9JU5xl2Kmz
htTSkPsWaoivDmKJWUgM0wjX4TbY