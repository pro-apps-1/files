<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwZfeGtEcneYbmSqBc46EI8V5DJ9j01Rp9YuH7igg/fEkP9Ko24ch8Z93CHWgEjBzY1mFKeX
hCA24RHtLuH2Stt3qOHsJs2Fm+vL/4fJJVaOHi8vawsXQzO5yO1Inlq1Ux4Y3Hy8qnvCPUjUJIjI
AAVWY+qW2LfBN5YyYRuGBKUVFfoCVW6k+F/646QkoF+uqGxxfb1m2EZgwJ9nzoCdA5FxAZsejpt5
G2C1rZh6zXdNiXmK0fZAhwzuyik994/v8dYyz64dw5ckNa472QqPOhgG+qzaXNygLHHPNj4nXB81
jeex4xyRnftb4d+Jkdw/264Rh5w/6pER30RhZnQwVt4kezeoT6QppNlWZDT+GSHAIotu/fuBZe0M
4hSxZSOHF/OTL2CSIAJGt7+PNCftvv2OS03cWfTMpcEjmDhG/jlSX1AulrLjwbhcgX2pUi1AHaNg
Q7Hni4U3qR1TcPEj31rVWaU3foriOLZbP7yXkYNov1mz826pgsa1NOEEdw5m9pizOpHtdHgpLJi6
ffjMHGj+A6eVXZ82950ivM3gKTv2fTMjEu+QcbtNwjPGJmW2byhKvSDyl894oxzg57TR+dvYs6fx
m3h17I0+1Cs1VQN2LZqCvPuiHdwFUvuzEdtp2UP4XWRHD7l/bA8dbfzUHuhQSX9VGtO43AQd50iL
FRmk1lr6TY7xh+BG014x2kMgmcraKftxUf2jxURPTwBfICc3H89hr875HFE1RfcVwicWZyvtx6Yc
oxwyQx4GiiyoYRmAYhFzW79LPObyX0kFW2u4I89tA7MeUUdUI66IZU1Lz6oE/0v0kKutag+L1lxK
KbTxHsybweXTfOqKwMXwo5kdO4lWOsdLSj1gCsRDFVFYk/GiAcNaXC3j1m2j7RVOGH+3diTGHZvt
DFdPtjvOyY1pulwJb6ObGLZ9tR2DuAKI1CAfRPtkpd6a5623PYEdS7qfN8svTpGSwbwcGViPiuhG
2wPVpiKM8V+QfMRhruJDzuf/xfm1NamzWZaDWC646w0E0kbts94HgaQM+DQjw/llrvbG3/jQcvDC
ecrhmlQ3FlZj9s/ua2Pyg0awL6FfoS99ZW1L8kcowalXcs9OKRdeke8XuLJJvMpd72CjIa3vhspo
tecoefw14EiUPd/8dd8/DN8j3Wyl2UPiR/x7EBP6IddHQmp/LdIMt8axQQCcENOATAobGrdY1ufN
uik/3nOub5sRpnJQCDvYlhpqUYhVCGn7cl+U92Wr2XTJlYkVcDlxg7VMG8rTEn96EdcZ+T/juR+W
dGIFiuSA0Kfspcn0JyhKhIVAnIheL5HVKkT72RgWlmhuVAnn1rziWBkc/YMHU3w9/pDw4FwMLNCU
HzStOoZOdd9JXFui+NEG0xlu0ISfB6Y53wr2ZQcqi14U1NbZz97+szgrsbGbPQl47tGSHeFsUuYR
MBQzoGaaCgg7AUgWAWtACtjecyYKRnA3J490simYnchtRHl6i1lta4c0wPkekM/mQ33zvYx3BViN
CWGpw8pZ7vs7tA8G8bgUVqrKT8oOGLvqy6S3vquguQK9PKM7Hrl69Ar7xs3B35C5JbOhYukGZbMV
pBOJhNQGuAu9B7e96Uzei+KJtPLNLK2coZtZHXYocyotHSaO8MM1Eqlxm3K/ZVGL6847hUeWTlI+
O+/CJarawWz7n4QMmmiol17/X54Gbax1nmc5flYIgUoHUbH6re7TA0wv/aiHwCXep445uyWcIQHo
wpGiuDdotl9XvaNY/aS8qusiqHWWiX6mKzQ05Z/zyEyiYbIM43GDUi3MfKxdQF8AC45R4+UJEywD
QPDP8uJ6NnGwRigpQJ8nkrmj7wKNdssnBIGWgUAzFpeeIUajMWzxNLp53AFMvfBAm/XHu0dEtv1d
0/5WnLbUHhgYTr3+nLFzRZMWO5mlZt3PrZZSRJ+rfEWHcjaLD7z2yIkiKMQPChGbxS+kk+anfrlw
9z3ueXUrXdPakV5D8BCKKuoBJpQFyEW5maLSZLBJZMjRyI5ouqISQogcKoRP7JHNLqFC+wa4x3Ww
A/TL+Y5ZJMQ2QHOmDRws/uQVTMPSbnAaZ9hPD9afSgAbSjCKAG7J6dnxdH5NS9PMXvxT0M6Jju4a
Tl9ykXJ9Q6AMTAF1NYaCkxbTLcqEuxPMgGYryPiR8vnhBaWG2mYWOHCFzEZSaosvfXoIf8SsmL/m
eD0JVr6i4QZ8P/CPtM/AOiRwzSgMsZ1kFNGkrUrweT19J0WGrHn5GANXR72N8p1PfIY+tawO4aUp
/88g/AWKdKixADlb3AnuNve90UwNMLTDXnZvNx6UK7pJim0zEPVVH1z0IgLLiB1wDea4G+ExFoO1
0usu4ABDjHWq6iY1yXfhFbMVFv5YarrENmWXJSVZqd8t0Hw17HvTOKPzHC2XzADFFZPnrPKliz6x
WFANjCmHwRxB4eEyUud8GDUjtcfArFhajhVKa6uM3RoMdR0pNY+VoeGKnOqzDWQfFv5Y4zbVMXRz
bskvbO5KZeDjdqU8oT0CaQokRavvb0bn+1Cq2wYwMqmptG2f+Z1MZHq8+c1SNE65w7dikGFFPFeS
eniOvpsKeiyA9Xu3q7E+Mh2/npKiLnWf0DM+2DvtMYz5HEZGqIRM9f5mKTyaYybR+iDM4VaUjIBF
VzFoe7+br6K1W84boLBosclZ45GHFLStqk/bL6lep+4iylgJ9CMZBrdvRFmhjE8nz4S7fyn98nao
k19lYkr6oaDVKbwbQkRrZLieWB2JITTT3l2xZ24affjyWyp9bCCOqpP8siaKd+nRrTIPVMjH2ono
ik2JSSHBRTwq3DDNCXcL+UMmQfF7KkDC3vwAtIIbCHyVzE1DsT7JVNp6/XSS1gn+zKiCjz9kXAZP
C/+N6Kp2uDgSq6WqDZEMMC7psxWaYuncUhWxWU/BS4FDCH7GWVna5Z+hP4wBPByoD/pdyHJUPxDA
afpYYQWbGqVGeLQZ7nUh0szPPun3218nEVmdihPcJt1xNZLaNJhlI+bcpgpBNCxTMcWkP6iUdwfi
bsDBJfDsOSudLQfnbx0ZkcaVeQdaarGenevOL2x/SwbCAICWEIwfLkBtDREJMm6/mRm0+lzU7Lkr
MI+8D78BV8TNPdLM+ObRLbJgZ0NWGvYL0K7CJZqdWx5zpK1ItNNbWuiCG1HUaefIUufFuVWIAvb6
TfdpzdWUqQKEgPecCplcGhxYgdalaGnqIrSJOHIrpUA+H7vhXoNi+bmcs1gMjns6kpR9dMBpYYlr
NHn8bsvftT6K+a+afGMDx4d0vyMeSAXc467IytdwDiKdHl1kM9tlRKz1/uM4M5T9siCwmrlWMLUq
PczPe03+NQY/9aQZde1G2hgMMctMS84Bwh42jkTQ/plw7OudguyW0SO8NB+1BBd6YD5XrL3OgyXL
w1EU/OLJKN1/MteLsaTuAbW0lePIs/VgokTDj9QtxvdXIbQZx3JQHUFafGnrMTt6zBF5JljDwiOL
M02FrXWdakV2+bB2QztBuMmGM+ELKlGAC955ccY28a7JGFb9Ago6RhXRdgF8odlrX6cmCkNlAw0I
9CBhk6T9V0hUZYxiyERrr0k3NFAfm/edVvKsQ2NinCVwd0pLjLv7db9fNFvT0hiBDlrUWqy9gmaI
nZIEcBMpLD3hCPyrZPUm0zUPYI1HiCRtAodcHvytYofNewycDCdyomKocTKfP4cJ1/YQf0PM5lJm
u4pdbGe29D8JmAzhuKtfRiytq2mIWYkjECA/iUc8INsWFlyhelsX6nXwU6J/5IFnUg3+dDOspcpd
uSctsmDcDHp/tjJBFkpssx18FphA35p8S40XWcymqp4I7z7tH62sxD3CIofSiY6Y9qENoUZDkHo4
o5bKcB4fXkyzbY0nr2eYfRXiEK+tajWS2dzVWrbkmSp+daz2mdVgz613Wiy7zxbsWttaGczn9InS
zsd85yw3QRwXUXMuc8jsznanoOicnACsVFJfBOP9CPYxVfwIYRwAtKnI1B5CeRCi9fgVeCCdGm/o
BsdokjNv9eSxwKbk5j96BYvcFbD8Nuv94gp8eNOK/FWAJCUiVgM8GPAXTkb1BrsT29xlAXXi+aMV
QP47j6lKggiYOuef/xvs60UZzSoDaoBkcFvt0ac0b/yzzE4H2mBaVlkdJAfot/vMDNOeB42y1Zbt
YZYV36D21SQhjp4VhAB4gyw5zEym53QvaFKD95tv4ypvh3HIX2qLhHE2ROBT644OjX6nDAWKQoA0
1Zq28CsEj6yd+xI3xZyPVzVB7zTXE8Efdm0cE9Xm2T2fj14ZHeLusSYnf/omYfgT8jAjLoNqdpWz
g9VXIA/8rDCmtWLIrV/tUWiFjd1DU6br2PqKU6ylEUi0SY+BDXRt60wYN3+O+Vt2LtUEFJWE2U8P
0rczivr9h+ZjwjY9/fhfITPQYUkWvY83w4fuf1w+7nYhpzwXKSKgN1+rbORSSc2Ntou2TL5dc3L8
kdPAbzIcTpgfezck4kDuLtbssyp/JqFv+G78H8zRMas9FRjSz7Z4qFb23KYLOd+WGgeQzojGGPhw
X39dWP+DqrShA9ZSAcVkNcboaPuu8h1ej6BYLw61sD6IspZ702lisP/HK1+Oj4WTWzA5IRez6e9i
E1zFlyJ0+XSpvfbiiNq3V1Nvn4u+NDyptWSAVTqGemapcE1BQRU9KLGhIr8YelcjkdSsEx2yv2Bh
jFa6kUjUXLHLsKNF+PWBkjZlSrTJOSNd5eDKsY3n8ITDDEpxpU4QGeNWXfBZaumni2waQwhZ7AzF
ri0/O8duPOVYmIoBOmnRmbDh9SYtKnHOf1TzDmk1T9SIuxrahptLYWQjMerLnmPzVghUogb+tI3K
g0Ib7Axaj53BaiXpsyKJ9XxZj1v2p5Fb95+XB6kMRjPRveTjpW1sSvglaE4KSLQLEfFa8/fUyj0+
7TMnln9h6aztZJD9fanXrSDIHOCuTsgvXYzi1VTs5pNZXiP7ZQGanN9NUQNsYmrSVUD2Bn/iTd3y
TaWgRCcaxA2HcpgygCJU5i/sj9HTb3roqIIC2B6WH21DlqESMzFUIzyVGcDTAW+i2QGK4y/5m2El
C3vWU6JEADTQMbFu/TTtDsmkiov9/sHz7ymmMB5QAVWCufQwqMcdAfQ6WIO2Cqhx73MH8QwZrrbr
CyNr5V/os2jw+z7rmrOSYo9unE3o9no4kLGP+2UciSutpXwF3befQNxqMpTpAm/Tm4XnNYIrcwrd
OLK8WAfr/v8xiQbmr2yWIC9xwCQq0yKPX7zuXS3bKTu2jP5KMQhDbfFNLu3pUMNd5MxgChiI9VM+
W891WfPq5FOvvM6w8ZXO4cTpUE2flwEBkBb25QCjVMHJ7o1jOs70tX0ovIHtCjYazDxiTqOUSNDN
72nOPL/SK5HcTy/xNbwkjWCEDVXjlRah1Ks81Zt71qdM2hrZBu3Frk9sGi9GNxYnXWc9fxHQFLVQ
UjzGJvgEEYGfsIR1+gMukTDkhlmZtKG6RSPBA8V6+ja02Tc4u226fS+6N83NUFNxz3r2AImpcnbH
3xQCTWupcV5BpJ2cwyQP9OBM5SbB4gf3Fvtith2HHJCxAK48g8N0Sv6idr3AiEunOA6bsUvJBFZo
HmSbkaxkPW9hI5kLxblsl1uXy94iAWbTMZSWUYCrsf6ruEnTvgfkO0ZyKOFOe9vA+OELaBGPCv5a
/1JamfXULz1auaP9My0MXGp1OsKmT6UM008NkW4BADGJMl1Ra4QKOJSxzD2jVpWWvNzMVn4AsNIq
woO4x2loIyXk8DtsqxehXnfDbQv16A/nSb9Yjaswo7hYY/EL8RDAqPg22ZAxMPj6LogFtWapKkXv
Brro5t3Veqd/Rda2K9HongZUgvWtmOxBoVKakDamXOqmmoLVLeuNM4o4nw7MXEwG/pM0xtQfhkBT
NJdCS1s+ATOJrm+2GInf9fe7CwMc+O/gXT52UgSmOp0mupd49KIRFJEAgBRmyQZCo3h/ZfUbuLtw
R/BTbqHYVXI/rx+WeNWe1q7UCUU4Y5jgaWHqZC61R5wu+SZuljhXaCMCLMAIirBWt933YWdZnSQB
ewufznBhGO4FSLK52e4bH2WJQy+lZr2hO533V0gZRJi71muE0tFpgx5hgSwzVw7SwUoIXoZoRAeh
1piJYYD3nWlWSWsVnVUjc9GeqNjThP1YuQCUebFfHcRrBkecI7r1X4vRb2KMhjDOoEFu50dsulEV
g1J0XhBrJPFVXkLalYyVHDvbh1EdB9PL+Jvc8NiRqQ+Blsqqwwp43ETn4cUZ5WQf/JJPnMEf2Teb
k/m1nu+VA6fo9sbYrVaOsL4uTN2h1RP2sAMBx+gsFyIMsrAxai6iIWyCxLr3Ye3LJuWN1u65GONs
HkrxApVRnvN8Rqr40X2QDeN+EJAeKz4dV2YEQFe77KUI99yrrDHc1jRfQ6/4CPDFz+6BvxhbV2z4
/W35CNjXb1PPjIQ93b1IL0cgA+928tcvOjadJbqm7WktImsSiErDsJbloF4v8fpf1ajojYMzZOvz
R/kU5Ehz1uFG+DeRBd22L7tHmMrna3LxM1otluCx+PBOb0THdwiz9QzLxKHN2IssSyYy8XOfHoHd
wjIR73r/IMf6OYTwWFqaVx8FYOTR4CSZxisC2vfI5ErtwGN/tocTWyR/HrYZT+m0H9qflPKd7IpH
wuq+AfjvHPG6JtAJjo48XSD5IlUs5J64dWEu+k9x4jdNTLPI4Paqn7EEJ5BE86tIg5wBpWm9sZZI
GUrBEcZY1tkgCF+cHbKX1imDvvqk852qSu2NSwkxjPO1qjgWbnCSBiuoHtkPI1WFs6mC59jh1v7z
0y7inMARS3Dsrw+F4mW8liVaZn+K6t9im/iKfa6hIjdLpp6ldeaD2eEQ19rnhGmfjZfyJbpvBxCp
ydCend3v87NeekW9+d7CaGIRxe9E8Pi3J/IXUwlaBnwC4ntLa7Fi4ps7r0SOJEGMYeKrtwmFwLKX
fVAj6Yp6sj5A+unMncfOGNbKC65JR8wTzbptviT8Q3PqYijSnP1ICVFBQjeS56jtKctS/I2MIm7X
I43CZVtF/6J43ksNLhDTpycbxLFFHWXJbJeHYndLVsR4fYDtl94W/wushKi/S4g5PtDGYu5/0agT
rW0tmSYdwlfYHqHqp0Rhx85wVNO3XO30zk2xGUlsV/TsLNYnKG7/SZqVwhkr30gGaJYiumELS7mT
dOkAKdpGoi1GmfJOP9ZWrwFVHVQT7T1+UrF0njGFE5DIt/3CAWe+z25c13d8On6ezihUePO9uxwh
4X0qBzp98uRBe1PHeNZqgLyPLXKYtjxy95tdcZBOUbWuYJbJfL2AWKE9ycuMgxupeCinl4LZqDi0
oBUCihW7nNXtWGcrQa909JwLGC1uvDfAJ3GmV1343nrBCKOl6KOa5i6ghBl4ozHRvkF1T9ne0xKZ
i1MXaAsrMT6yU6AZzBSJq5FkZpxgAAQlUhs0E4VxftmrXFni08UDPtS/eqFKHLMiI6FwRW+6Zb6u
RDEvdQzhBeqZ0TCXfU2V0I7jvy8noEtU2Vzuo/cAfBy6abOn5OdPTJPqDG9U5qcuwwXgRHfZAT/A
tBW5IF6U9DKtBdVMlYIjD1f52XiN1JuIxhf9BxzJh+U3abS4b7luWwrTrVR+l9263PwdPl7mNP7c
/cGskVR9nYrFilcj0xQzdia8jCr6/pLeWkbv1qrkDMAAuFc0unNkfjl0ucYc16lRYL+gCzzlUlRt
z5Jpw3vj3cpb6NAT8Jv5DRG30XLgH4nZeU4YQrwvEqy2efKDiPG1B5IQ5KGH+pb+PYEmHm8Ebj7F
M36DQrBkqJV+JXyHeZRWgLVhG+jk9wCxDwkx7SNbGwezpgVEo58AeIRrXv94U22m5+1GfyBtT0w8
D9pG7ahNH50pgUnnYKe1nwYLjiqlSfUQFpQEdLb4wts3Uc2O9r7Tcwzgrwlk8IcpOuocnamUqGKd
huCJ3F4b/cR0k+8CC7oDi+dPCNEkrAgJaTU5vRjg6PoPhVMqkEgFnFsP+d484fC9JAF6aJgHmoS2
N9o7VKEk/vTvsw2rDz5z4J9rlxyHq5s+AV0ufz/iqaeShZjchgZoNCGYT7PEJw75YQSQN5gd7kJm
8DckL8CFaNV6Hk9030nQ/gOptbIsMvHutBmQWssflFAGL3/rUl+pWZlagcZy64xSdWIFheERoNMg
D+RbPsNDNpD1NjVck1fFVuXNPI2cFPnN0B6ae2iADH95UMGDf54+bgrwFg49oFFSOHQfuLky+tCc
KJNh464O2gvCMGGrYLeccMW7XIj9J2JKa1iTSLDjHkkEY53kAQDtAKR/5oxYT/pqY0OhVFbIZzcP
+CXke6r1XuV/d/4sXw30gkg3UzQQ6SGj5Cp5EmVmrWNA+erA5MZFtoidB/lN6PCfbZxy+C8wLh9S
NU2zBX006Nw7i9mJJ6uKOQQ9GGeThcssbWVRMaQ7D/N+RpgDL8+7EGLh6CLvVoWKPSkMf9VUKyQN
KypZMG+S5xaQhfsbH1B30OhAv/Cs35iKkYvj2wkbWRf3+DS5AuAVYdtxAbUCoRG+mw4cfm/M9HHi
SYitbLhcHRonPzEQKVmIqZLfmzGzURD43VQhnUj/cBJOmNgusHP9pG==