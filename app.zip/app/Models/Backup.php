<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtN3UHIKO49SOItiDz/W2GKMK1NYKt8EFuAuixFdI6yASHOJSAjGHvh7QeiCZklxt29U2FZN
iLiz5TsoL8AmVv0mjKvLS050TCQ7bm/E+gwRQ8aDviFx8L7NZEBTMq9Xz6K9PgRb2CHP9m0WbkZd
iNCzY3Vo12c4PC6TcKmcRJ/J20XxIxssVuoaAM4L1GM2A5DXi8XiqcYRx9OSw0mPijhP5Zc2KxDU
5fpi3O7bAEkFsuxOlf3sEBUnJMDk9p9Sch3RIdpduDuQEICruOA6s+HRjUTa25cANkBe05RA8S6j
nRrd/yOc7XTKsGJVBU8HmSv41IBwTK9l6cEL3tOMKg/cqNWNDuoabzb8IzkfmWL25B9/mh6DrgIW
TfLoi1jBjgxM5HmcsFyHirookG+RnHHIyUe8w0orXdQJWD3Q3yR4LDRxzRcJEB0z4NQlyqivHlP9
wOeBESCEkCkyXXKfCwi/gNTuu2wfPTahunNxSrBjY5sBC+7DsxGQss3LwZ74RTmeDzVHbqj+fz1R
95DdjbwXyvsTcmPtHkAtyPNFlyIbrSaTG1tF0rFgmHe0u9LJH26yRRwvhCqYVHERH1UyuVP/Uvf+
11FRUnrY4W32M357/rTNuDhqP4S+DkOwQ3iz9c3NKGf4mC9Y51bHbj7IrdWQQu518xJcMgxJOc6B
aOF9uPTU84GAANnZ/GlS1jymeekAA4UXeYSKkyYJwJ3R7/u3TY8n3kqV2icAeIwwrPx/2Pgz2F5z
zJtGu2QGc10nYN5QiWC5xGxjCL4Eo08NkMGP/+oNDe5jiauL8jW8K49HrvYqFzHmh3r4DnyTGUfc
BGGz3st37hLmNeP0LAjsjnE4DFysyplKYRLcN7OKv/XW6uNKRrXeoGTg0ffWE60AcCkr4iMYSkiL
2t+8Q6znJBV3tOsHoZzaFnsjhQJguaw9efnKVs4WgtCq8q9RVeL8YH7mRBUWsQJWor3gdqcLuBj1
X/WG+OLc8/yxCMPt9MQvhkGl3yYGrQuA7bmeEVIvnyX0DdFH+deEdEG+amQVXCb8gKkDoIaqYgTl
EnlczrheHF1sQoZPs+CK+YduG5KPalLhNLhiO3WBe+ZKuA0YuenWOBOJ/DnQwy5pI3g+kFjgAknC
XZTrwGYoLTDdp9D9WzDoBedJJ+QjhEk9kPj1rWBWKPMP9iywNzQTuGkrKrteBdw0YpgPOaHNrbjA
McIiy3XADrrZtsjrKaUmhtpIaCz+cdxnWsIbY89r3nDb7MGdIrTUw1FVawOjbBaDzQdPAPKspXZt
0WCbG5DvmnRtIJENzRcnaTiHrPyqhvo47dROU8uzFggFTkfmRX+HuEFdpatkbraLLC4rDvd3atzj
j+JYqIS+w1K19SkS0rJKSjT3I5H9vyoCnPEGzkbfbnCnU22qct/XgCZXu5Z4wsusoNThNXeVjtb8
lFj6/gt9m7jQ/WpgYpGONuEXZIlfs/DuIh7lVHZZiBpdaBu+LDIuN5AGO76dxJrh0R2OdnBQzvtq
lsTCEiX2KwidHOZV1LIQmyyRp6toxiruPfHsBt56qAVAurW/fJrPYx5s2+J/q7Gp7jvxgFr8NZGL
26NERos8k9u+FJl5Z34IbRIdwFY/UpHkrcM7uSMOj2a5DWBxU4wfHVmRJdgWvJZzaAVfg4ZeWwWw
lY2x9X7vFQiZNMPYBrR/fNbr8TmSGndRSZbtM85NqxnNBQfP+b8wZ795Bq+1nVi9JbSUQV9Yrh9G
T3wedBK4g7SGCyjC99/2qoEW0gSxSI3BxRvAu0wzN2zmEFo+BW/5i1K4KXvus5eWXAzvY85mVDly
I/zsEQqThDz+pC90WkMnRVPSXXuq94kOw14kanUYaGj9Fp9hLLkbp1xjG56g87sLH5cO6wXZPf7f
B6lY+yz/pzNKFVE9S1whtCzVSuaKC3kVjEvWnIsyvk8hNS+mW1W5HJhHKlF6HXibMzjtS1vrszFL
AYK56N2CdRJ3w2YuYVsmWQOSSZRbtTM8wcF4Mpy7I5q3r+G4bhVE2QiPHsVkpaxVUIkLlBPiJ2Oe
oRyAAwW98ixVLmCE0RKEgMD8vUgn6qHoATRuf9qCoQ3NaehJHg02mmf4NRpw7YEm7Oh1t4rUbAPN
VxZwf9oufv/nvXHjJvBxC5EU95p0UP0wytUOs7ES15CdXn4Nbs19JimzCET1k9TG/+CrBrOQBaUa
IAbyYL3BAU13mluZxU4ebTjXtPtkCYzWrNaGNmq95UAMeH+CIldcKHt7fRMW3JQ9pkC2YKoaDFtD
89L85d3gyjlPqru8Gg3pQg6FPjcBczPT8xJQ/iDnapDZyyPIJGHKRMjwFsVTyOasD1BuSuHzwiNN
dHKVSnkNadxOe1rZ2ODBnubW//PGsPZHT2iQh1LaTzBt2Rkl9iB1bqtRcbjjKBzX98K4iDrdmU0L
SBY4SQnb94AwWDMnxuIhtw93zwG/xa/Zldid6uqL6JL5f4LAWMiCVnYHczpFE4r+9WcVwARby0xL
547LZfQZwDG8UoXVKQ3dWbFlofl3OreDwiHZL/VRd6RCkMwUEcGQt3UrVbzsrmH++sXvGV2czr8X
Bamk4phjZfqVDm+lhLdtA29w/40OsmKKhNJWmeAg6/gVXkUquOncd9jJu0LfjHpoidfL6lVzvJTF
L0eBcMUoVyN6iMlq1YTDpbxoykqV1iNGWE18EX80Di8+Po6zItKkD9qkKJltUrB/DfGrBrlhlZ7p
x8xjPHKfa3QGYnEd+x3Myd3LM05KAkKWBzC0pqFmQLAtEJgfbJlTxl3qDxEgfrwa6N5+8F++TkRM
tDVRqn0hSD0kWh+d7dtUffLSJSxd6KsHMLPRFk/fR2YvSCzY/WZfRg6lOttrErScWA2U/f0QTpAW
7sOUWPqUeBT/S7lBlHcIRUgWMQZwbrnbNNe1oNLgA69L5PrUVo11n9fH3npECksLz6eFHKqgOHnb
2/X43Uzp7q7xvdpMJzy1QLStlDGnRiIF66hh3hk7XREOFYg94S4SORGPFYUDUiRZYaljULtiv9Tu
9IKN/4X3dxHNULk/D3z35yexP/+AATGeScROMaZtKYWrjFCdZa+8BzJ/1sFvgilbd0anjvNKVAxj
nnyIAk6AfkNE3qa53sj26/AxWfWnHqSLsx2qW+cvgp/pOPWbhHgCQqrc098Yd03JaBn2kzqpIpbT
G7eCdGb1u3KQEuTRHuPhEK9rV6SXHm8+lwdRxLTUioajpz46AKtmfHBL07jyqDCX0rFuKrlTXOhr
iOtAwj69TD4geOH3W5ILXF+qi0R1n+oU2AFcPyDJOAAYoFPPiOtXXpbncii8GvGLkULRh5vI/Psd
/I73VT1rnz9pFpDIpXYDBpvLzmgIw9LVLIHaKsJJ0eCrKlskBRrZyKEV8p4xfxHq/zf0as1R6Msr
aEzHwamFf2lQBp6xgYEYJJ1sjeZ2QRjViJTNNrl4dM+LLRrJf3IZDyH5uBpyU3qNc0ppkFn169qa
YLFJ/LO+Ofp5E9+NU1+BEpgBgqPTNldsnDQZfQhKG1f48nriRSCG5kIh6rHjSIubSv3caQ54lwJP
2AcNMKp7DhWbmyqgytUh0GCH6QzaW3e6HCdZwA3+tfeFTzLa+h8qXzJpQB8DdSeKsZvKqWQKdS2x
zTana0FrifOLGFD34gDPcDZd7Gvn2q+9TvYu/rs/Kf25EMn3BgfWkGwU0iDJ8fNZvANERxeo5u/N
G+G8ZY632y1d+FNSbhU/HOvCPbt/DUw2CmsH6ZIIGxge/RuAtp/lJzlhlyGjcMgpe81rjr3G3FbI
zC5DB17atoV1oOPbdsqOXXVe2lhAoqGCWCAEcMdlo/BgGfA0x6lH+/aRzZJut0gHmui0g+KEMDXe
1GlrBfAMkTSRzwmLFMWuqfZmpCQS8MtyvHYI0feSOe/fs1anTdSkLEj5YVuTtc1pfGjlt49zA8uC
VEO6udB4bOxcsQbZw2sEZrFgqwVtOBUhXLgqGZlJsMIIaVTcgeNVIzqTpHx0wHRoBERHcC10f8em
2dht/e8L3ZPoXOwsWNORpCzRaVxmx/uzEAZjluVX2vbsnLLG2dpJZpwzQlgzUiarOnZ2groplm2f
5nabT1UkTXqfMaHR5pkT99M3w3aLGB6KWM5H+XqSlgjtXzR8sjVwiuvpcVD2qCJSCDnJaRlVx+xr
9EjgAmkOVef1Q9fGwBKhtagLpjgnjjITa5VB9eZyz/j0tH3XWwCjqSVNnRflMFK1QXmw+22BQ4RS
AvbdQPpVQRI4aiQNwHH0mdfv2L5FZFb86AvxUHlrKcMwv462ByF7MCMPgyoRh8BLTRTh4D4Vyvlu
d70Ts9VrTH+OzdKa5W1YTYOrPxA/Op03XDO6qX3YY8VaC4OlvbF3a8fxJHEtvNu9O7Lve9coINIn
/WS+4cS3d++wVY+Fu9P8S/FmCd9mlj2/uBqa/y3VWE6Smrx32+NmUgZ/pJFp+NjxWF8D/Mc+0quJ
ShaXh/7lLwPHslRlbtpZYW2XWjKEDv+aDuLpJZdsXj6M9yl16fAcmXiSPWWndDKEAGZRzibuuT++
rnpknjaOsYwE7y7lRdunmyG12VNcuDYn2ZdIITGXWCcw/54FhJ6wvg0I/Xkg5TXGKrqD9qrhOQHL
ZC/FCa030oRPxPDU4f0mOtMAAXSm9VIf+FSzc5e4VrIGIxzCEpi0Wnho6Z+PO+7tXQ7D1HtQNT9q
GQPiVtYzNvqdyAkpR8jU2oHXVBXH/jIekRNOJg+m/ejGC5QGeLAEdrzpXN5Dz9teG7zz8qycoGxq
y3yQkNp4439yvagHwGlKzFWxoaIGSOLohsT1OeuAlw/UyBhS+/4bzuBCCEbdvkv2arfxQiVF7smz
h/XFtkUikioikPLYepKG6Xb1zuKZbFD896FQ/SHY6jbU1i8cJWRGo+7lxC98f7aCw2Eta8lecfjo
fvedz7+9N1asAWnIazhlqPdHBFsouLtSvx4EjBTssBzxNySQtoCGrLK2YEmRvXSa27hnl/U3W5Ru
VFDaT/BUFi0pa8ACMJkDytPturRYL4qTAHDVHTx8aIXkaEB5tjQSz7tfpYeapMlZ16Mo13dyd7BL
BpIoEHtjgRQkl1ye9FTE1ew5UmeEKGyO87CWuFX/UxAaraF35Kvr1NckS5PQiY6wlw1OW61RqkG/
kOZUW+MBvKJQlJvaX7IP41KmZQOnDYEuKh9MDg1n2feCAVHmN2DcQXFIperU3v2y6L6kKg2LsRLj
RYXU/P1H0/S62FyQsoVc/C2NtypR8ToSa1KzgSTO1gc6uR1j5mYlEcT2SzZq3NVLJZcCWtwYrw2r
M/dwyArtoIyCH3Ija3D/EasOByE6NuNr74mJPdqZhfWgS5pHL4secqO10y+KtO5lC4YOPjlROMpw
nZaWj40pdTVI0hggc03i85F6doSarWHrR+hFSeKp5bYm0ctcfwV4C11YffZnc1z3wTfca2o6xM6V
Xeq8yxEH2bDf/nBEh8p1qKOxzSYEprW+kJJA25vzJmy//uh37j8+nmpRwp8Z2egD/0fsVPp+2B5+
jXs+wUivqFrqUh7JqAhxjKCaVjHogxbqc059RpGmsTaznq52XIJE4uAjMgiDKgMeirtegfmOs8/c
RccNoKpD5V4ZM+sbnGNQ4RTVZeCp6Io8GfspRUaBKpj1kpit2wyRG7NDFLKQT/me7BfKmNBSn8sE
QjOz6nmvNtOA3nRfrDu6STlfb80A7t9cFatIqxAJk/b+c1VZBmJAj4uk2w3n9azAHoERLibYPFTi
O339/STcNeilrHRiT1auCQuCb8dll/1zKWNlTvZYFuw6qJ/wKNtNV3OuUp8ihhfR02ZfKjlZBe4r
IGnnrALAMqY8xSJyJzv3wFX7eHfkdVEIksQL3gkNT2TFtz1NAc3CbOHYfQEj/QM9mflSYOadX+Pu
AGKp31UGif8cpHPqXyvOMnLmhXqgkCLoMSxORHeMqqYHV2Hxfvr92BJ77VF5dD+m7FYlyVGLELbu
GvD5lIo3SINB0kCryfwNjSf1hWj/rEJk4ARAxMoQZT6GgLRPLILH8i2ddJ0L/yhHQJPxvMiehRxM
HQnR4611wzotJcM7HMrZegN31z9os3fWqNkTKn4dlgo5GIidBKMLWy/QpAgH5un6SUOMCQ9toL53
xwGU950us0C45Bq/5l/IFUpb4UoR6XmYDZu37yTJl6FRxL1cp1Pww8OvjbB3cfR0Hk8AD+DBoMYc
SAu9qcRK4gHpTrhE9daimTY95PVYDuUdhWir4inPsNNI0kiTt8TAGdHVRCgSM0S3VFHcuO+bJSox
UkL2D8EZKxe62id2O5tWme95mK/lsZvRODV73GGzWUWopBG/KaG3zbHvwKgsEd356N9zDyLyzhHL
6M+fuOm/sKsh1UVVMQ+3KtRkUBsKtjo9zofxqCA9rn8BwPr8YV5uxHruQoXi5KjptE8nfnxSzhTY
1nOkkSw+mcOOIa8GziGDv/yU1m+q5TIMwSO1jvMZkKQzGv9ThbhfRrPwnJScejtzsvdvoRlm1nzp
WOKtApxbiBoWuiWADvmmNAVrnqeCLmJejbGRQNAPYjFQhadZXdHHNjfyGbJ/8EsENScLUyTeFoeu
apehpK5UtrfZs+83GeZWhS6ZJhT1tTPhN96Zj+Dhmhh33a1p0xJBPYJbETZK8pQtUEFyZhsBKt/G
GrraMwi/Nb5bw1Fo57BTMOMEaPMEsfBZztWZJ2fxZ9pfO0Fi+5xbK82/zBU7aGLzttOJwnPVvuKb
OkCbQQGz8T3ANrdRcfXVESeQx7GwhmwfFsveRuhRTqjocCEELQjF7IuCj7UokhNnyLqDk+7IjskU
4iGFr0BgNq96DIyFKS1EmszBZYgnI8ReAMh8ucP5yCTQ78DNgOdtMiOCm3ldtvB5glvDLKtHWG32
Tn6esAXSSaZXtmBf26cSMpE7vqwvzsLCbH5rBRmolyI3g0+xZrXAAzfJ07JRVi+ZZkNyeS0rJz0I
fSX2I6wCqukJwST6uN+rrikscMAIksaYbyoAHnGQ63W9Z+K2g6rCX32ApG2ch3wKB1fvhQdl6FcK
CKfAeM46x/rA3EqQBfaAJGHiX4YNN1Ccj5i7hznz3Tmh3dZTt4xM+ifRyUYgoXKZxwVSsmzccTcn
sTIOK4n+BAHawSlueTeSpdMp9xkAIHWXL4BwOwHTsp5nDMbPUSQRc9CgH/eXRcLKeSSmap3G+NKQ
Ppe9YavihJR69Pdl36RwOMPsIP8DsKIVpCXd4ornMRjubzYjNdExZAKk1z1a8uzaiFQFaOmZTI0+
eq99XwaRgMTnwaoDhTdEx83AX/EbQuP2JQM4s3F9ZiLnxKHOPyMFh51S3VOjvHu/OSkJr41leQDF
9+If9BvnAMAjf+v4Hq0XNeeMOxVGEDWl1lvazz37ZFehNvs1b5WZuBZfle06Q70BckgcEbGNNVrZ
pXc36dH9/NoO0wvvwz02xof3k2mC0d1HidA9zeDW8r9Mn5NDtf2VZaipTXuR50HLl+6hOEfRsRWh
rvI8NR6RodmQPybV2ipVTqdRt7juBEw2c9YicJVmNUwC9uXc6lQKJ/3NqWz3ZFPI18WA4h2BCQ9s
LtkMrkExXWWidir4Y92F+xBd0fSupL4BAZ0OIS0Dbwfrm4u+tVlho2qnFzcycYahCH9rxKTikrcV
RktdoSEngg63UI0V72zG8CqOZw2djtG+zvM0Vn22fHxL7AlXJFlVV3tTmAz38ulJIBc4LxTHMKSq
Zj7eCy23N7tEvwgub0GRMhTE9Ejw9r+Ojoyoi83VLD2lVa6U0Md/mJ1DRMdORcDsyI60O1QtZBGd
HNyC2sFA/4IID+ZlRByzl8NxBZ0gpZ1xdHoAvrfXwTskcm98qMXMoZjwnyw79vd75Vce4PRi0j6N
NvAusALHClHYBC/d7mUq+cE8KSoQv1Z9s4oi4c3ZggfzNsgungNc40DgIIL9tOepGUYZUuRxSfOI
itk2lC5ingC9RfGOuopNY1UTYy85U6EbisVUQOLLN5FIrOFDXDf6mgMi39OpCNys+lD6PsyqVTyq
IUVDpWAT4mAorzxzAm2w4CK2z34mo7X9qsA5iveH9INMCU2oaufJJ3RNBH8qbNuKa0tX07HxlYL6
e/xAhpyju3SYnu0oW+qcuD4NWIZ3gUV+XurmIhnqf/oDG/dShqG8wG0wJCC6BeOc975TrU7cl7Em
sFZz5kVBRmgh8qBLfe0McuymlU3qopdY98v0xXTHZOwxVHgok8Fm07O6TD/H2//pqYvIREFHrHV0
ATqBIN3Cbj39NnS5vTYyLPCn+FVb+sXgD1UZyxIm+coHZSwsJTEx93u4eGGqLU2Fy8pygot0Wmz5
NAakM5hXtGuBYxuAT79ZUExgoQyHqIts/Chi2SlXaJPQ2Or1dw3ugHL10eH0fDgtnmGALH/0sqki
tdCJ8pvdoA4gm93+8Q1asuKdaJ+oTlrCs06uw0MjLG7F/tTtf9IUn0TZKIDwQzhzEo6lys7HY1c6
caHLwD2zpYQf5lPTUHiIXaYfAYfMWOEl2y00Zl6TNhB+ZUiDyi2ZvD1ziOQRfYlElA7aR5Kgelac
SooiRE4toXA/flX9WmipwOS=