<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqPiAkUo7w/8IuA/nCAxWY4C2VKOC+X6Dl5dBQJ4Y0MZhyNRQzhxXXdF7qpyX0EXmRDuxFkh
grU3a80jB8mmjzndbeObyzqIk0j7AyYNZsA1lYoNkxY/9NksMyvqMXBirEC/S/5/e1DfzU9afKnO
uv7LVJrvveqqkSd5BkHNiTvg5SmhpdrkoO+Kgt027Dhs8eo5XEOs+9Y9GFRuockblUno7TCPCNQf
Gz+ks/+Y4AWa2Tf/H+M1rmkqUy1ESII+LuoNrn8i8NSPCilXjyMnfmuGuqO3Wsz7l093JX9reAIb
hkb2FYt/Bw2vJVsyIi2hROi/Amy8seDjS5qbaHnINo01sGwKJHNPdiim7A2WECn3x130CrO9jqqY
gEhC3bOU/9/dxSP70PsfoSZtJv6NHSdActuUa05oZ6wPQJxAZbsqXt15ZOV/BymLK164Kz3LDtvE
9GMAtPfAbYowt22vBWVBJqk1Jed5Qwxyo1bpzMvJiGE/cxCE/QQkDaiW3HKapA4jgU4po4wOAdy6
ngRs7UQmWT1WsC8Pz94Jg7m5WB8PrgQ7YJQo1AYHxJ9ejoe0sKtIlL7u+ySFWkhxSg3Wwf/FAN0E
INBq8ckjoX0VPGRpe/sHL726N4Gk+9aeyE/onphz7nW32a16Ga2Rht6JbcXy4qM8pU93n3Q01Ss3
turYN/iCTuNszVHetNsAUD/pdLGtbLJehWDMPrfJhpX6/62yaqpaLqKWYWe25QcLlnqGHGBRB+/h
sUF3roexFXJPn88WNtB3egQ0EZcBJMuqhJzhwUvJv8Blr454e2kwNJBaJXvdfeCsQVzUUxFHDmqw
jSf/rpcevrl+fwUGLRzJIJDHFd8JNvFpVdZDUxtML+Cqf06MidmDWum4HJAUW7dat2tC+LeE6vrs
vftqmHJ5unrdcYVwqt6VTJGr7BqnXMJpAdYHjQ8Y8UTmmA14LSX1hpEr5NMbnSfO/dozH009QLoj
OfpsyrFPTiVR9QNOzE5f/n7XlZWP9BnrTSvQQ2g+KF9fYCsuZ92YWp7nlplcwa0mb0/zW/OTR93U
fWCBzKuoAAQ+qzSG1FkiA05UBQGsn/v6xNXdxcC+deJwsNWxAaU8EKym3+dNiWXHp7KHD+Nrhp0L
H1i2MpGCLzNUkU8auSIiXWTSAZfiKtFcOu25jatXuipBMwgKtwpqa/ugXCml/m3QzC+CjeKB4h9S
d3h+/WLmzWte+bgemVu8Ar0neuaJ/NbwaMMVs+QpizalvJdHiV5CCpTgIANaK97830UAV2U1fvDM
gSVtvoQFbe/hSXLHJnsMtISCVjnBjvdpscU8Hwvus05KkRPzg4ym9Oybpc1zI6BzEpXD7BemGsZs
6J6ZY/x5BIeYjkLC8y2E3O437iPJ+y2X5WuS1oRP4dyO8GwjrfjWKbWr7H8aXs5TyliU7OtW2Drf
ukFYNCFt1kcQHwzW0z88UtQoS+qZzAMMV1LbNjRXfs95oZdOrSQCSxdg6SjfYa13O0Fo70V0G4k0
SrQ1L7+r19FlyFlZmJUrXZj9DFUSCX2gJ47lpqrP2FesfNJJUC74sg29Rdk1d0mgwG4sXHcrJp/w
U5N06FcYtZBO6GWXwQHbfsYjpbNf+nluoCoWCQtNB6mw2M5+xO9W8aINYjcpAxy05ZyUn/ev4ZaO
P1G1UpqFpigfaHinfi3gGCSDUl/80gIN+V8kOXhF8RtwA8e2PXCkdQQtNe2Uk7gq7724DQJ1+vV8
64IIqKnOzR9o7JKJQDFkmCae1wFdski8k9YEtSPOIHTV/ahXha5L/0FZZyhe49JWu8PXiFLxCZ1R
xuPNe48VGUYKFvZytKTF/2TelAInvIhwyTHXPJiuEjR28SBELOhu8uYMx8leCxGv8UGT1OpzxfKi
KGYnTxOf5btmhAlRPUqCJo96/KsP/MmRGsm704tJ7fMkNII/yLSbVekNp4hRQZThLp0qFpSuOox8
PlFHwfx5U/uWWomtxXDNaOe8M/eDGay3xHXlfdWJAkQRtuPJJEUOYAHYvpFRgHD6fcQ7FXcwpEYH
6CVIPuPE7mi6piU1ehS33Fz9+BljfUY/i3IJGyzU6QhfVk1pYP0Ng93w/W1Gv51X3lRnw/qrSu3D
sWwxR+wgdm19v+1/P1HH48qfrkahM9ob7tmJGD27JwG1XTS73DLoUft9JTO3pBl3QxwX9JtUQNNt
q1iJTLCox2LexSlNWWgEh9P7cb2lgZ0Bdy37Y+JQZsFAh07XiBvrEVf3M+A6ddbOSTaD0o0Ybmko
sjqZpiu9Q7KYNthDQ9KkvukXkuY2kV7HX3JZBM7jjrd83Np5OLg21J7YmxTUmbY0XkkWfhhz5XAd
+XzAmf3cU2DxGWqKy3+LYmQzC/Niy6cp5ervWJERI7/KdYqNg4K3VCKXOeZIHE4oLJMEBh6swPI5
hO4Yv9i2d8Lx7QrUXDkUiy030d3Qph+IjCURJvO7YCtjx3uupsHlsWhCpXn0MSUFwns+/sMokIpc
PgZ9ltZ1EA1wyu3k+zqK6awFdyyjvecJeAkvQN+tRAKIj27s09wtJlLG9VvhRCbPpToUqPeXovAR
9a9F4vWDG+T5IrbCkbFCFiXFqY3YjADx2yhCYXZ54bA9iajB/KrCsq/DZueOsa8SpF0ERqSbHTYW
Fez9j7AvZgXcQiaKNcg3f0ClwO0BvJuRyfR0NMh++zwZsxXSDitotQ7lAZS9yoE/rJ029n5yUE+d
Gip8uIuFt0UkyxoEM1SjTHvRcsfJAYjK5HqW0v/doRVdog8XvoPR3pqhew2LjECkd5C+rxOV3LqM
nAyQ6nva0STIV2wTZ7KPc6qDMOYk5LJfSieRocvrS1aAuuciQEn8lyaO3v4biHFfa7wIUQDPoHqm
uyAhGzgYx1NILV/RaY2aeuGCBXS4X3ChNtAnb0+HWZNvdKfb6l4E8M4YvJdelPWoabWAIusiec9W
57IF5VZz/RbiADEcAIhVawH4u/UfG4HGSvm5Ss96oR1+PI7ViiGbq5QT+p3g7an5AVgwg3RqEXBI
sv4Iy6483OkP19Xp1WzX0CzplJMyQ+gOp3hWS1eaWcM2LmaUJcGa9BcerLI+uhUOVe9KQOaFIGyk
fLa8AXKBuWujKiIrE5CRj8BJRriJs1IMBfpYLQkcFymb+6Cc51d2s+aIay2NdAgEcOjsgLnapqf5
h1pIxACstzFmDXMMCjGvzmMd+JzCXl3bNvMf47PBRnBjheQ2PhofdspQTWaT5Og4qa8v2g+Ejv7g
zsfNKsxLtTjERCncrq1TBSHFV1BpUCicTyuJfeJ1NsSdDtyjrrFvGhMnP6xGX2dx6IyJWWzMGdpp
ez8L3rbad/bMl7NGzYAtsB111MI2WLXdxnGYh3/39cmMLGIfKYDgA0mw+ghX7tJpkH+ohIU1yx9s
D/jd5xfnKdy8dm84Akb7EXcVCLGVOXIK2f8laHO3SZ2gqGm/XIyLMtPFCSECZU06SKqKkPJEMTPe
+bODHnp4oiKUr/sRTgnpqPVbYoWilv66unQkcfsrZgvAlZ/qv6MFHB5tbBMlCSgapbWOFNQvkFiu
5bvbeNTdHZ/diln2FZa6Uf6D8Olxf66iqDkFKO5djUqKz8k3m7MMH2ZI44yJ5tESfYkHaiELaAwS
yeYd1VccfFfObVFCEaMQttCTmMH7uinjA5UuTWP2bjhIz3rYvEKaAcJS+1KkNJZp7iQisDxaYwCg
U+iobHqQh2j7Lv5ZFYeVjfV/hQsdAFvEb/hZp4BAcUgU+veBAi+j5Swj8//Xi2HH0IJWnjGt12vm
l/lB6RppaQa4xMMQvkYV1n4kjcovv+GJ/TpA/Jk/dcBNEy0vpuX0/XAi4q9pumB61ulcah2DAcS4
LCeQk8g7u0t+czBAkdnyQTRMZe7CFfyenlI2GcvV1wT4o5VCNRCh82SNzC/y2TVdzCzLlaS4CZiK
FXmUMgtM4ljxCyeARXQRNr6Uspy5BO4QU/MlppBIqLD3sl+PlcHp3eTuzTGuzCuSgSzrbEXu3/2g
D6w+fSt3L4yTyiNQ/qrLGJ2upbFFP9odO/dXPM8lQjYIBmVUVRVHj9yR2CwVoKt8sV2osqjSxx18
0nrC6Mz2enAUJGsEb8KqjGY4KOdnR3e5V1KBygipBln4rBeRHZvDq04peH26OPLKvoKtxKPovkJX
ghldkjK5sHWuuzkRjLHLSl7iKIHiS6YTm1i7bfdmtb3O/dTG90AAKcC12pORoeRMm3FwchUCdHHK
4i2dn5mlurvb31lqGoSt56QlAi+q8JtV9TdaRXrZ30PIwcEx+PzakZY09/3nyK6X24o8P2o/KI6T
J4/YW+Qmv9JMKoZI6MR1XOubUsbFoNP6p3UKlaX9/ixnTx9r2/8ccMBA8Xu6bth770yRhFFY6yhi
QMlMTX03aBp7On5+I2sWlHN5G985ZPRsBQOqPaP9q5cjJ96jZRK7dfKbZQ1oDIh/Xn7TQWl0P2zH
lA77PmQexmKq4FcF1pJ0WQtHKSVUUgjNKlBdy9pgJBtcx1KR5QeeP0fe2hOI0CGcBF0qYdnlwjVP
zQeUECfs4ccQ7ejepdbflSnLCXW/nVbPz0M/yErbbL/+qv61XltmSjP4GHWAe6AZG/8kuqQL7CuG
PXbd6vtaOfmFylOG6PDtMGPAW7OegkQH9/FJnNdpDOJ6dzxYE9EHpyZswpVV4c0Zec7oTRr6wNzI
VNCetTrLUnd0D8k2uSoZKxG8cw/SQADiX60XM8MHY2V8tobAOJvcY8yozYHXUlnXpuR7qEWjZWAE
bUe5KA0RWMVPBa65kLeIZzZWIl+jFUMiYO8HVclY36wXWY/QKszG6DirV6qVPzCxan++voZpC23N
GZIfcAQM+6xuLdQH8DpW9yAHUp+SQUseuVsGZ3vKsE1RJioqPhNxn0elAOG8MgYmu7N+uBOFwElP
jKudI6V+3zJTzd6pPt1NgDuSaTsV2iMp5JYaNFq4irRd+GD+O6XDbXsvIpPWpkq9xN9rFG+m6ufm
dM1Jm9XQBk9qTZ+l+evfy3+ojhMNYQT0AYxDcSAdbNuFqC3koxHGqjl/52ZUgfPOR+ZxGJ5+GN3B
Lm+OfgeHyDo1f1iC8k21OGXVZGMXEUyaIH6RSgNvpfPmByTncBuFqXsxGVyJn81c/tcUJM3C6ghn
1SpiYWMYqqBHIzUHI1daDNivZzGN/wQuwfQ5Mha8SPQmrw2+qK/XQwib7WDMg+o+2RGupnLh+ryc
Z8se5Ih3l/+cYvziIAjpgm9gRup6+jIRksJgIgSzyqqZb9GdXSz7f6setIyLnWZF3gsqmLvqEOIr
+x4SUDDjMUWIXoxSmHKK8zvS8V/t4PFUv2k8WambOmJVuWJTRt4n3iDh1+KGCdTjkhiroYGOf9jT
cKVrLsFVlPzR62nooqKVsuF58hdyo4DR+rj+HQbN8DWvDl11E3rYdoHc5dRqbPd2nHEbQ6OgiAxF
jrEaZLfhkLnVo5BQ+M4TVkLTgXHfKxQI4JVWmGIaYPzhS+lwFdtFDXZg/o8HLAyU0yGxwSOd9MWH
lNSSjEgfFmn2OyFLtMz373IRR5+qAF9j3/Hqvlyf2ya0cHzb5TRzALrX2CjK/Il+9UVelBn9EPr7
vj7BcZAjqQ7xc5APb1C+bKgKMOih7JydYtgPBBc8WGzT+KUSQKop/hmpfpyBOO8/43rFCaac8sFM
X7yo9U7gU02jTOKgtpNGGuYPz/obFIZLGG9g54tfSu44rKKqiFh9O9KRWyOOf52zNHs84zxXXZcZ
MFUabpGtR2VK+7qt75OCC2xwUdAcXL9LFXvHIK0r9JK0+/9QXALALrbdGn+yBnZe3gl2LDtc0R8t
8skJ7B9UfYuBEJISXCWCYi/DTjea24e3mm9tUpEsV8oS0emKenocImUp8xKN6ZcRSoWG07g5yvMI
IedBbQHrFRNQhGGGhvyCdTicwmBgbhtD0oml75hyzdOtWbvb8JR5e6fpE8ttSaAuShE/XWnuls1w
gbXdeX+QIbc7RA/MeK6mxvdjIv3dkk3YsNzGnBgCwQqRwPmKfoPGjoNqyGOLL3baXMWdoq7YJTOF
onfbCWVRtALM4x0gpjb9R8zY+fiSjx3Jy9sNw8kHuxGi+AE2iBsjwQM4OfTFLPIFHI6OS82phRGG
zTT/dOAuhZbT83b8mrFclGQHxKXig4kxUIyd1GXuE03lXpqa+JhqRojkgUq3H0E3K8OY+tgtOeYd
CmUgksaUKp+ZmwOFnzJyo1a0Qe5vrqp05lhdWoVEyN+B2Y26aA2Wui3/ojZtwD/HELLZX81OztqF
Gq60W7VIBRWIIcTkyE8m27mPwI4lK3sJSIbxeO2ePFfgHVvG/TlfczkmyoDcbjR4OYY881LkS3Ym
qwdeRkCiXUDhQ9qdCNiSsDzmJNk4xYGfV+Gqv5braego6UtDyAJmDQr2kMUt7yTEZuVs2A+LDEST
YZtS8+xRuYC9YB6Fg8Mc+vCsOjAF08zGs03uxSDS7UhAWP9FepR1+WchWCz9aQ2VUzbgI9JTnf36
Td3/DOu6al8x7+94AAE8ST9ewYkIbg97M9chJrKKw+QKKq8BDz3RnxJUUEEuo/JsbsJtBVka2La7
cWVN0b5OL13zJIz4ZXWGh9FatGNHcHgGnu5Qc27VaJODgagTd0t571jPNhRmSv9DZdS80ZIsM+dX
hLKVuuzJcPwPZE+Y1U5ZV4mdP7/JhsuMmgfI1gPjLfjY+qHd5YnaBoYDvkeYie4rTQET0w0hoerS
J12M3MY6k2BYuBeWHPSefOdrxaTOz8R21ko8YR3AJsEA9VIB5E/vxUDHI/iX4A4HA506RfbZanwx
mg2wuBY3ohFMJO56QYf0speDjDnJ4DXV9HYzAlIMK6sTNQ70T1M1TepAuo7SeeUk+rXcIa5iQXDA
Hj8xVrd9NwhfybBFGpwErP1vVIV1IBd3dCN3IusdOCP7o9KsB5/dD6tCwHiVL4PZUzfiGSf7P0u5
VMqBtY2AYsbzMaVkUrCSlPnXJm58avzD1hH2aArUaLNaHl0VtgTK/2oQYsXycu4vznixHzZg+fU2
LKJDubi7+jjtQ8Toeyg7eSY8xth1k4UYP/e9FJrGP0Hqs2lR3C8oaMGNAXaBQQTfGi38eZtdY1xt
6/7ZtT0mqp5Lbv/I7szQiuvKeBe8f1nx73bIZTsA5fWa5AiY5HGD3EUNd4aaf8BzHDb4fflUd7Oo
7+eJiI8rMe+j3O9T0RQ6cLLVXuDk0p7Y+8xkZN1lGHP43iG5wJ4i7MN6AhlWICvlgVlydLbgBqsW
bmqYMHZkD5/cMTfJN3sDWsuHWSAw0GHEvIWB785Be88tXQVVa1dr/fK6H7rMvVNVQGbHobAmdH00
Xgubju7HER9jcRlW78mNh35DrWda+99Fu6l3aHEB90FeZAT3vuYcXu7WpToo3Rk6fgpgxoqbAtOn
/7cSXpJOGfZ1PKwaM2KcHM7g/pvrD3vbI37O2Cmv72eI69KOl6iq+TlGo5Jec4LwQ7wvT5IJ38GU
8IPLkVmf9vpg5GgeeeU7nmK7H+pKe7DPCcKSUOL1d6tMrQqCbPCNHJB/g8Hxk++XItaXf7ACfjEU
JxL6sVFDDpQOJvAHtykf97jb3m8S/WaXllgrfkz68TbPrNqcV67FtUEQXPR5RLvsgocQ3klvuVA+
MBJWxxXFljRuIOft7M+r4j8LKR3Coa3plc74YWwq0LezCpjt+GQz3TY00+9tf7tqAmrRFvcTgsXw
p3b0uKD/Py8KO8Zao5j171gpxUoToVDtOBG7TOsYE1uko1+X+0px/MEjmJFKWt8FByjqcsumBdNt
E11A9BoIp5oTXSO3gBPiiLF370GOJ0fHDR+6BjwdyzkX/M2DgLl03eeTrAf4nDxf7SflvLHUJmLj
LNWlKF+obz3nBYecOSUSMrIzur8dhBjCa3zBfq9dEyuoO26TlLQxxzh6nK0Vu+ukUnxr68S+Ew3g
2kZuX7zXdLbFCtfZoI644duRvoCwGiwKSYi2fA4FgLSB1lSpWkIQK0S8MGC1YUxmKll0laY9gxJh
Gc79DmEvWmuC6lRj7DqXd4La5ECg/5zqb5VDNvRDxG61pfOl3aZ9xo23MA66paWv5FocdHLD8dF3
+gyxqkJ8Qg6AkrNqo4wyYQgiUX6gfl/c99B2x3O0U0RCRRUnNGZl18y7WITjDyO+D5eC9PxMQ0sB
egJKBD8LwKCGhrVXoDu+wUKm3afxuqw6at8qzKsAd16yjUvfESJcEHH7I7u0/wRnpPCoiFBLVXXi
38AvEldsW/kmyDeHiXKopcDb0bWJH2Hb2DMyYCGqq9f3Rn3I1Aj068aoIDsySnpB89uu7FSpOu23
s51SftyjDvp4MtMpduSPjPToaQelLEIZZDM7CBt8BIFSZkwyFiC5NjJummijGxp/GrTSs6vwnXef
lzpRAkv2NfPo5um7jLxOfeoWE1/7c2kFwC4AfMid8Ma29pKlJP/67cBWGQxV2d8qwfpSGen69IyG
ZBGrva73WaQbUhMLFLd3Z0dv9z/duRqgngeu4VApTZaSqffiCjho0dyJIpuo8b0MjUS/GG0p3j9z
qUCYtFwHoVgL0xQnOCkzKtu3AW+ij0SBpB0=