<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvliCc3Td8TNc0AdGyV3RBHMzqjH8/BscOculipQT9aGneSMGMfHXTujAAcJpaYqeI2lygQ2
f4nLgmi7a6WGZ09VlNX8MeKtuM3niptAmz55Ae70pSrqedtUU2InKc7STMd4hjd8kaLbJ9V6cHnZ
AN+vvIxvYMfhGSOHKdIddc2kQ3Ghbt6fFNmimJMxFZ/RzHTlNvaVk8gVer3OCMSVhkCUURAhg6JB
nIMWh3e6k7sXX2HKS3FJZFVEkgQyi62ya4wQnc82gkQCyqV2yCGmDldWe5DjUP2hX0nRm3aKFP1S
R4mEFGuH0vuAIODBUT7Fqspz8McZfuFFGvOXPnmZwIIQeyj0dqqfNwd8+Tz0HmNTU67hnDUdOzOZ
ReRFuhGpzDQEE0He/W1blo/5QmwCK9BRXH2vwBM5fDklWtf/3o8isPmf3BXQCoHpfZVfxqajb1Jl
rTm4HH8r04T8Kl6xOIad9Dn0C2bLJvbCcTajT3lYXxCS/xbWJg0S3ETRUbYvGAfgY6cKm8wvQlKQ
LBQ4HaTOVS2s8WssbOtPd7bD6bY3yb2AheRj5qHZHDNYX5MoMSLFtB6hJVD8WoDKIHWBhDOggJBD
HUl6rxy5dbnLwyP3hfowBGDHVSCSuZCF2dXnB9HudgnZ6gJoe34jj83/gAjWMshXYLTVrJthgOm5
k0dSNgnABf+EwxpzTeqEWHy1iqrL2UQlvwcWaTKBqKRmEGCRYmF/8mtDKbWw6a4s9EHkSlAA/uaU
YquB5RZgLcOUaNdNyKtcPwb6+oRempIYLhu0XyOW4pE2TJgPW3GRKKTfU51ciXwulPTJ5DQAa6Lh
vH+iRhCSCU9Vd5CeoiFzaN3cKt9cG59zuC7D1dNQYh7RjprZHWVFtR5wj296FpwCGDQ2gdyqcQBY
DNkFH2FCvoLvf2OAh6cN3RoTWaqBg2PB1caATKVMGVOqeIbXJL0wgh8Gk16SO1mLfvVOfHE3jwBl
/zamVz5ZYGaSKCAsJdCTgy74ZrkZoACgRgrdax+zejUMZeS6ZVo3nI0HgLoXnA8szhqLiWz7x7j3
erW8QobAAdL/1W6RTll2i6x58JUySAsdiQiUxczeEZxOGcXOlFbJ/JL+dPxnQLGkTgxMrnj3Ghfe
2HGXGSzr1OUiDxP8RmMDZdHIYo5qr+i2DsQYNTqiQmscnyDADUVW3wkCIhuekvIEzRpZgx43JxJ/
5wtlJrkhSz07W1NrKsq7hwAJBU2rLSQCJMIO6I/8/croUKSrYjZ7d25WnEvKmG1MIFfP5LubyKEg
H+k1Ke+BxSCkr4t22gbh/JsULo3J1UtrNL6VKXNA6HhPNxwISOpSs5IGEJSg/uZ9B2cwrF/ls4ft
vJTAg73lFcFVh/3u/ItzMsSqXRwnvpcSGabcDmd6MQ+9kUBHjFfJdwXOByItGU7G++qTC1/A9+6U
kiF1jaW/9i9aYTZV0NH4wPxP/lLX8m0ppkuYzGoqLVnQp5Pq7C227mMvZTBbO5ZNyp6hdbh0cXaG
SfAfy18YFVJOUbdylbul5AVJC+Bcvd2qAlXfjL22Fnn4mCh3hDLtrQqWWLiDOKuVgaHkflPW53Yp
P9unFtm+zAi6yjZAwQb0ACw3Ow+7VMnmlHi886cW19LYfnp4FbrEcuC0VpifCTru2O9wkNGrx9qO
6qofpgLypHJ6ak92gkfbtJ6KbZT2gMTzm6O0/om+kRblVj1hVdCiPS77aMONcZO3Wnqa0xhEq13o
/W+TaKBhRRAA4LvfcZzCMaFIMWPvvmyP6WDfUIKHCd0W/MW94EdrAnlW8hZ7ppQBUFUPlZcXD5tZ
tyAGfBfnC7mqV6Lmjvio0kmGyysKM5TAJop8d4sfL1l47raAaOiGZPBozgRwnPfUB7Kr1P5yVMei
CLqPivlcQw+KRGyEZORbE+GVqOZtFb0YRG7Kuwy/q048zsR6lAo5HkcWMkPXVfsy+VtBWtud83Og
HYJbBjMuPEL1Ic82Gv0iysTE7DdFP8/9dqonbuLMkG3geGTy9EpluwSGlqa34jvPSF/MxiWV5er3
KFt2rrNZJtZ84iDmzARBsgkZPcv8uKw/CcF6Rji8/Vka/rs5mQMeAAEQzKLAQRUHV/iiiwmzaoFk
+6PuzDfipZBtpN+t1i5BjOiqGbiMuJGYxBVBMsurt/ACHtkB6UHuUXvgYy5DcrZIyB4lFY4Ytt5i
Rx9Yi2K4cQErKFfs33sKrIJ/Q4psJUhzCYjFexjRzKsIGfFFtqPt+wvSf+czk3X6aE+i004KrDr9
1n+qXa+1lO+NRJDnlzb3wYwkHMGhWw2opuF7uPqdi3vW6Wh6eQjTHMwg4FyAj8yfp9hH5XEk9eUk
vCzGs+CpCCde6l9U/aXjdJ5Q7o852D9Mb3Im4h8cXSiFzkr5KjXHQcYEONCXvddtM6V/rDLuZpDZ
VsWcALMY3Dg7sX4955bRWLS+lTl45If5Aca/lgADsmc7IF4eROaLTrW0N1sTAvvQifZ1dHRz5Wzj
Eatll5GBDV7jQUU7hoIpjDJUwGd8t1OQe+RpnbfOq0zNdz2+mIVRkgVhiwA9z7pdX7vsnd9t7phA
Au2Qlb98EJxNaZ/IPrU97KG08bRumZi26uiQgmAFERuslP75a0osO+k3CfFWESHdDFUmo4Tx6MUO
qR8Ahh+pZHoNW82gkh9Voubnfn96KkHkFN0AN+c4VHkzT9H3Aqo160p2JSfWs04xjiU9QqfZOQfv
FHdRZ0uhyFtEkNCVIMMT+82L9O/EVvH+VFao5ORLisBC6pq9UD6eTMEyD1mkKfcWPh7uyyg0x9/V
MpHIDC6il6u5z7dtOHcX64os7BBO7IRW2wQLVZfCpCwK9SKDexlpYWjuQJeVRs7LJGiSqOBP3Y4L
N+LKS31WT4xf/eWLgrXnakX4YZkjQq8Nl3qFSyNrTDdtxz2ktxjTYo/5ANlRteNBt821k7BkMjw/
Cy5Igd2PiyA/3LyZCsFMfl36QoxAISlkuUqHe34TEGpmHPZLR34tPwu7CwPWaXwyYvUbs87fhvS0
vWYadVuFIrqXq67CSp586OIRiWXk3VOi4e3J0kqu2/z7vcqbExpP/f4JKA7pHhtpAioekpcnuSBn
CTSafiM5tNI+l6rqHhFLlVaHOt1pmfFzYFbUG2s9hpPQbB8UC7g8xQN+d+yYeD/xu07Q21r66xFV
YzUvn7v9Fl5wEZ0VQAG6oXSueHZx3RZ6Nl89JrvLVLn6y4ABS723h/dYFW+oE3dLh5qGcm2JsmkQ
E58m+sa42hjSfm5HrMCJqJF5uVahs5ouNrwk4qfDv9ig7b6XLlAfgnWaUMB5LsU2y5faAm/3ACqM
RzppAmx5pVp/7tSpkmFu1+FXy5APeuBvS+Hm0rg+HrZ5r15vB8DGkaLPMTcUCAHW/jkBDF5CoZxL
+EfnIciUiRvHenExVlbpgoeZ9j+ZfK8OT/q+58TtxAmo5e6vaPMAfn2PQQ3zIzRlMm8vCW5DYN6m
X2ZZfa+HVJTzeGfgz/Z3AkbNAGVUaHuzG3YvzTvqYWp2Ur/b+F+phF3UpE5knzZo8qhejZEG8IjU
eXk3G96zM024RETCk2xe+r1vjsOaNyat7G6CfMCgbhQTUZuQsyn/GGMXH9q8XVFuYXeTxX32OQtJ
TW5hRowUlsDOs2nCvI1lCG0btilrFMnwBREEGXxmIRoAcTg7o3BGUDaeEyKAucpcFRCgClM3+cZY
Rt7lr3FF+tfLJZQ6EsPriWD7Lm6IC16JpWnPkrG/q1b5J+YM5lvyTpGWVj2U7TrlPuQ/49jWlXIf
gZbt/z8CAgIAZUEHEg4PrvIK7JgNmCWwiO/j/ruUvHVshdxxuxj5d4t28CpdjXA9rQ/HghGwE8lD
TCupSMzCcrbgdgADOWXvliig0R9gyYBrA/zQKDcO9k+BKRAoyMBDHpNS4Z8sqzBmohLH1qQMwsoI
LLIRmsN/wk+OFHqzm/s76rv7FU9Z10tKUlO6KktQ9+bUzBhFros7a6mujSnDBMXG55db3ilPhGqY
99g76WG9MTAfckT7GITYlL7hRA4l4AgVhTMetvUNzl3zca0C+kEYieowaNpvsQKZMiYxuqCm73sr
m6DOBkFKfLHJFVKlGKwIxwFY89L05t7FerI7tMugm3DkkNkz/7jqwBD9gopJQSYNxkm9Y+honTa1
prwHd27e686X2bXOeZY92RYvayIo1xBHCMM+nkPuGfODxeH7ySpZUltc1MzQG/uEscbxeTniy72F
9LR6yKYE6Dh92ZkbkClIRpfHFg3HV9TZ88r69CpisFGmR72VNxWrL/ggYpN6WLulOdDcvnQaT51T
PU0lyPdGMvuOORhY3nnFBNbi/EVIwXAAjv9OxmWSDuT2pLv8E5dGUvcD4BA1msDbx4+M/1ckwiJc
TxxTJFASH2DNNXqgp8J9A1fzkIGnkE/iJD7E52zObXoKnncUDPFBsm6jBANAFM2HqOs0cfDZ/vmX
LiJ/pYwnYGlMyTpcto8Lmohf76hCA7Nu4l4jJjUj9G0i39SWcXYjYOckKk7VRzvoL85NaaxEqnru
bSmRylQ0CgMWPU9hXNOBtflKyMZ4DQJoERQSD5lJ7tpH6UYNw9GPeSQdjb165NNzMQhwSK4G0snZ
Ad+A+XpXcWL3mPMKX+MQyl5Xw7lL5puaNAgZNNrjhyDcc/LmXdpAhRm+hBAsNaL1vbsAZ4VxVLhZ
Ftnnhk9nqF614ZhF8ZwFZNQ5ljG++PC246eaF/0FEqmMScjdg1zUaKL/UABrfPQU5M0Fx6qz7kB0
zzibgYQGeaH+RXgZ2346DssoHPJxdbfgbbp21uI6PRS3xODdvpTFtFxjQtMSkfXtZN/SopXHQ/G2
2uraZ3IP7X8UdrXWSjCAhMMG7+JZJItgjVqlRfOWzl4xPhpGX35fvX0O7I7A7jUlquwamnPCqVXO
qW6oZMUQl63O7WDRtBLOKcjF1FE/CeVpiczVX/i7j5Ebu+DGNoeJZL2DhmrAucQ/dMZ2GuTJ/m2A
QICshMxuicHlDQ8teg5JrKI0+W2zXd0Fsxdm4qxqwwLZk8hqCmWn7myEPeqL0RPVdX2SR6axHM+n
T7oFy97dlIufHWrfto6tL4zVtIDmyuDSc0aOb7+7ZhsHSWd9ODfwTiFF3xnm4oIDKRr+bCLlQJv9
0TfVTVcA/ACdddk6wC0So4zJnPradP2tZaGhjOWeaos/r9rwIj31elaYN4Fr7xulD+A50nBgit04
8gKY8VH+kJUpEthiIh6PGiulZxlvZJyj080s90J4dsVhj/aWkB89ox91A7/beUHRW1/SfJbkRYs3
hDCpIZXO6P/iNHd1Jw1a+ytpKoAzu76Qc21jrD0CjOdRUJNhdQf5RrKMFiqPWCH6YeTetPmi3E9R
i6nwuyfoVK/6R7nsgdA9zFs1y0xf9LIG78ejYK/jFWZ8sucCLhyBiirKo90z96C5tqWLRAaYOAfP
svh1H8o20wuRf//yxH2vcbxuPfwWCvta1ereBMK8qkJPSI4Rj246/uC8v2CMWHf/+CGgbLK2VKIk
QlpTh+7QLObLK9glD6kz3+MndD9yljcKri5oy3LKsHTbRj7mMrp/7goXURen2MWGk17czqS1Xad/
3NOF4Oj7agKSHxIWQQTEadnz9tmszPWYlm0KnPCt2dX3Y6EP/HUWzUL4oF5ULGz3yN/mzwjoQ1h4
zvqPdxbSnhVyqcEty0S+GPqSj2Vb3sZ4NCFgbPHad0EQAj6hwHwyxNN6J3jxO6TtZXCnETxqt/L5
Y/so1P4XbOyzV2gQgfKuO60PSOeSmbPa3qAA2h6JUpsM9Q7pqLsAAmk7m3i/UCL8IsD6ptiDt6H7
7D+5PwEKngZvtLlpSZFuVrycZA1+Pcq5al/9FgjyqOD1MXbmvg3RbLbM5mIoTiCaA4q6MQu3zSr3
eB6ZBFKmKu6IfGJBocp4cR3bvulLhEADE+dWXc/MwkgO1WeA1YKHcIpyOuNOlA/KKEonJ0yw5V7o
Nfcd8tEKgcGTt0LZm2EBk7gGzFgGEdIj4iPoRqPqyJqbbZgUUh9gSLqimAKd1VwtD6tB8k5j40FM
8R7HxQ+9r2QpG0/nlJNWnjwCRepyXtLBROdUqKTAbvBlh/VakqKoMuA4wBHlaYj9ySHiQTnHmmvb
JYKjzI+RCSqF1jIiaHcGOZXnRYohoaHP3KJXZryHkLd8gNk2Fz+h94+Mvuvy/p33CZggzBelvZNp
1V8AxUK+BIxqBNr07GaPL/inSctKibzuWrT+hSyeTf5Y1XRvy9Pa/lFayHcZQ+TJnyGtosOZtoPU
SwrEbDIT7PIXbCCtMin5eX/gb7rjS9i0vgNFwXQh6uJgwe+zV7S9dKkKOT9Phg6abI2ZDCanzE3n
qGv/zyIDSwkJwI0QYHqq5Aq5STtvAfNM/sq1KsU4Thi+roU1v+WJ26nVaVzlVTU6tlYR8o2cUICg
Tk2udP+d2X0OCotiamnQSuGnzbVJ7rKKueUMrAwKqvyWgi9YnR1uGJYXuAe7bvT1jt/aMCmrhOxF
2A1jMqQtONn7djQ6GHHAhHvdnoJi8l+nt2A4VwgQ220vrU0BqlgcNplEX9hSydNlsDQYWu3JKPm5
1q2DalPEnyoOaGVreBrW1w7NiIjJ1Z9X3vPBLNaBM3NIw7m14aqH4eg1JmtCgDJbfD0WkwILYWjn
vIZQ+5tPiPum7fSGoDBx8qzzy8FQWvFfn5uhehlOaOT349CCeKrDAsMNLtRdxwlQrzLlIOB4pi37
kRAwHmeUDQdJaYOzxYyAD6hclDfpoZflAtMeHnDy9sm3ES1vyr0pg1rEEkgohUC5wd6oJi9qtXEE
nQyErfPJZqGq0AjLZ7b5XUdSEc3T6HhRMbwXNr01Moo8VVX0+QMS7p29tx3qkhTLMFyjixDNR31j
VFy781KAQgkz72scINk6rjINDyINHvjp9M80MmO2qhs80xnNu08Z1HspK7pQP8urcVU8gCzyPTn8
qQ0i0XeblnJRlTYn+h0CU2zMCXolH/jAt6ot00EM0Co8vwLSgeEncYX1QN+JUJhvOgexUKGWVPy7
fZAPJ7dboVr5+RyLgqMRw01GiK6wLSG/7BM0wDZE0Q5RKmYVSZku7DP+OHA9/H3V/asAdT+EnMgr
POuxr1Ned7IRuxjrNFfsEvDvQ+8pf3tejgFACUubdxjVmjKsG28YnffpOVN3qmlzgfbSXpSHD1nX
zTrxuxwWp74oXjIt5chEAboXAb4j2FU6bXu/oVA7ZLj6NlvJ56z/cwcrcXBvjAigi7XEswrHWxlo
yzlX7CZfA/XpIIQaPFE1gO0Z2i1eymrEdT25klmNIP1To8JV9kGfVaPvkY7Icw5D5EarnJJbFRli
hH34dM9hZ8Zm5eNmA/26VswFO1zRJwfkTgjGh172Cbj7Wg76xqIyTbbNUZtsQ1Ydrm1m5cHNxSQC
ZT+gK28k8nfEvnm6J1vkKzYUeGGDoTVP0EBZXohXa8kluv51gJbfTLsX41/R8CA95/XjzPV0IfOL
e9382pkkwFRrqUUdpLIFIM8GZfQspqgTqcvNll8YsJg1ylBeXyEW6etS7UJ5NTAEYXm7Ji938l6m
7XESUR1pNiJAM8BW3P1GchDtNerb2Nmm4lHE2a00VRIB/zeH9/9cSlU37d5131JTEUulNhV3cM7Y
Ezc56OS+jR5ICLzD5BZ7KPyEXC7/ZiWX2zGMO1W6UfPhL2oZIAm4OiUiiSlxUyH3OTOVgOT6cPYS
Z+zsFX7C0vZA46HVDJcE9ZvmjCgJ3WKdX4yUR+wztr9bH0uUbXTKp4qVvcpua/aeOZK6i7Y+b1Wa
4cElRHPcZAzWs8XG+hUfaNS2u4J6z5VHemFSumOzwIIOTv4I2w/UbY9qnpxpGE2+akWAq9MB5pee
tq9IfSPNxPWxT7qpWsN7dq7LeAW3IjzW4rzdWBWj36W2QlysSYeDWTfxGN2xIrK8A6iuJzwKR6HG
ofnir7GE5OAwDdI3PIoS9HQPxYGasLgGMGAHZdnh1ynvzQNaouHGKTvsUiTNxAsM40lN8BkC+jF3
9ABaT7wgZOzZMPMXmaZaVQoEgxy87Zij7xVgL8jxFhtHqHhg/gUbuZdGD/tvm6HiarNz8mTY2g3b
8ve4yYVdVGhs7nKz8EPmJEIx/zYvAOTHTj9r/8awnF4ZD+rb38CdBYASwuQjW5qqFi92LRg+QJ0i
6t4khO9jHkQ+I3lCyXGWfBEbVkoAm7f7Igi2XCLQo02PcVuE+gSBOyLqpKv3e5QMXzlZVccQ6og1
yRWHZ5rtTl4fyI2AysX0yWzsv3TfStafesQTMTCbbXGD5crfrwZ9Eoabs4djdHSUoyfDaXQmPtdI
8HdzvYXcLT47E09QNKbRbEqFjLjmSgdyRVmb2b06FGtFM6L7vZ6wAfTlMnJyY+IZY8Ogw+Rmutes
OQJqJK6MlnomCkYN3WI2owx5vkpSkRJTZtnbQwJkOKJGUIwfjLsbJvFs7zW6H6KUkNgmL7lalcTW
f9w3bjzqUltm7WopzqSb8iso2GHhTBHNd8R6IKPbg3tEdhDJmPNiDwHTfCn/H/LW5/n8inxuIiju
3qiwXwLL86Ba6JBQhrdhlc0pR3OuddPLKlptlPJTkANWA72O