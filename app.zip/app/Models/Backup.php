<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmWQOQrVhbc39lJqZdE9MTo9rGXKzf/W5x+uOJYKMK3TWIaiymBe/kD3UK3WuvjIMTgRrQum
w3fBnEfI8C+usi6ICYxba2CvtJsgxzU38oMxJgVPJVccskXYpGVnJbDx26Ru10qm2B+R19Rfa9kd
G1qBeiP/Txa4WIAaXkyLGBdlxsQhyz5qkDMeFXn3c4PUdhTy6QxaT2vhMZAr5bYC+iwqkU3qn7Pz
g4Cfq/3px0loGMOVQvwtN1Fltr/yAnuBwtxpnar0bIC/IiIrHvjcnscyWm9kHbI30oO7UQMC+boO
lxCS/+8NT3D/ZYiPkdmN8hS+gsObQrO+U/ZraBcbPnztrbel1v8HVmOvDzwRY31vtVzKcFq+XJs2
kUzUt5RpLDNQOypeYOvK+RFNsO5Bso37ZDvj2rZFqzABH/7iadSX4dO6W/4Q1EvoQcmntUmf2wnq
1vchEib8B6z+k0wCvr2PQ1LMaQI48WCImRSXCQ7h4Xt7GQA0MninCxDXL56Szhe1CdzEBXFqEgT3
/sL4G8GhU2GLiiymEBafL/gMcsmUDsPRSG7YJ7HuX64T6/MC+MRJwJzK8azgM/31hHl0fyVXjnUh
+PyC/vBKpje1+qzeqazcOdBRn0mDWwYm9slsTWFs44/A5UUvvwlBjXmokYpttuDBuxNISq62p8/y
jNW8n3NMvK1L+sm4pCRPjDhalbyCMPfrTh6vWX4IsAWXSLfr9EONjTJNJT2VaGkZd/xHL/J6X72u
Mx/+S5MqRcgxVFnM6BUV4jS3cciO1ywO58YSaCEcNrM+3SdxYHonc8Nfbg7900MEb8BMh+6zhd8g
mJd+zkf58fQonh2ZWX4TDxUvbW5cNRsRY4EcnEeVmcIthayc0pJjFLwYkhJa6jPaW1YQ4SwGsNcB
/p5vYl8Kce+kG34u6PnGVMbkrh8bcOxAiuE27VA8qfR3Oy7w4enWk5412Zh8fptnJkmJt/MDkkgz
8rtLW3zc0eaOJ//2MW/L6NB7ohEHawvdQxlwFebYuis1TWQxxt7zJBdVSHtfU6/HB0mm8J+KWzDG
LidDOW3R+dZH6JjGYewxtJuQyam3hVsdqm5fC7Jfj3/WlDQepxbPf0DzEK1fu3Z55e4lOusbLMET
hrKNhsbxV4YWTmIsdCSJXFvPUQB0cam7iO+sgMDI+Pv8JiO+6dxkuGkzTRCze27KK2iJGD8MbTV/
u+GP1G+JGsXLOeacd5bB9xbrL8NBbVHzcz6cwTyT4FVPuDOp0uySeLwvDhbnIj8rhLi8naMphWJW
Qw0nariTVCHx3UQBYy+P3z56KP2tbPCNAQp+ZEVuft/vzE+AG/iFIfGdhWm+XRHZlVkUMQBb2y31
GK9+xsikMwixwEphpPTKaOZlEXOfOTGK2IeRPhRsN/bD4344VYExeP1giDeJCp0p+Md6nVs+YT4d
ZvT/j4I5kWaQCqeMRphOOcPN/Nd0FSqaQUZklF0i863JotCtrBjSd/41nGiRkqwPi5Hxp/e1mvZk
pwePjWKFncWg9JGty1e4W7hDhJVh6qsNUB4mybXzRMv6YtFEGOXjWZtYSBb1Y6iVtyuJfd80+++x
I8yxTM4A2ebOYTK1W+p7PjbevBXXCW7hDWeTfuC26sSa5vS8wWCI4oAYA9qWG5WIkYHWKlfnMcj2
SjWwTkmD4vv7m1k3nXHReX8qd1yLWwzwTgn4tuqfZVyDww35PDNVbRahIp0xkNtRqAkbzfk9sqcA
upONGs816yukTDTIItpZbC42Yv9P9+BvL5UioGzZHb4TNK//diIMPdMG5dg/P4ZiUPIg9WulUGvu
PSqPKQ8V/FaIP8ONUGKMtr9NQPd2DuvkClsC8tYFdpKFGgAiO+e21MGATg8oRQ7XZz4i6Jtlqwx6
4GLo21S7VYU1yx/HIhI/IrsOrf8uQiDAnQxMU56tRHGi2zmFVi8diYkdXBkLy/EydkfVTebq0x00
ZFEuUfXjhUXwOuJ6fUmV+xeo4MyltQ/aCYQmrLyUwhD/yd9KucCcPYc8eQUc15VKos8tCa5oUeee
dy7d4X3aYfELaGNhNb7tEh5ZhbgQ3+L20YYOoa8JvN/oqcgjXB6TJYMKVAmjEit2xE/A+/ozNj/9
24QW7f9c86kFuH7uew6bOl0RguI+EU47WWrJmLDPMKxKeu19me8TYZjhLb+iS+3AeOvwRYyWW6pj
zkMDGiOPc8ELkD3TCg/nSg6iZhqeoe9fcUKH1xHznWXJPnXjl/Y+mtKLXRf83r/xiSmLMiK1P9EQ
Ve3T257w14YxJMwt2dQz4DJPY7KnPOHrzt1a9p+yxatU3JweOEMWlLlUP9o2WvyNftJTR+7Zm8p9
700B/PP9ntbZyklGe7tetU4SfU6yxjioNVbE2t5LXWhClGIay/ZFewsjri0ceb1AAksjiHbxvb1Q
7nPpSej78OISPs9TsSIloqMoFcYZbcbeFywj1YhnynNqlB123yJdR5bPFY1No44ZRoOryJ/UlQbP
CtdYzgOJHwT206pijilj7Z/qi7WkWToysNfGVzlHCwJCyastsZ1UEexVcsnCidlBdqgWbTK+UA5m
sQLmATMAlxhZKI4VdMA9kvrV8InLxNwEhTs15JWLMjdgeIgFephMWOXyqzEumZz4LFQCbFKnlqU3
2Jew7Vgg5MLmmd/l+WIo6FLQerqNwipXD7bxn7H3uYZ2vwB+Dow8h59P724/V+x2o5kHLUyGfBeL
YE6YL3su8VlJLb5+AE45lCfBwKYcNi6RkbUJd88F1dVNVJrhsWNgt9/bSqPHj53wFYi/vAXeRzkJ
77o2d9QL9iEKbp6bUy3dZEaee8gwG0E1kMXeKyyRKL47BBDfXSL8GbAKjUPKCh+aCsgYrqVe2984
NUaPrPl1LjELkgWFbGx+pGSTVtHQZTHwZ4QVxfKoCTrbZwEaxrXAjO4YBT25JY0hXcGt2wx6B4Wr
b0ImLB1v45ia2edr5Js4OU+7pfrmIqPRmqGDwlnbG+YMfgZSmgx5SjGm0iaGBmMkIAs+GVZu/P/z
0WM6s4rHP27OgsfJ6EGZi8DR8xY8ZaKnnDekmoFQvmfDkJZpTVy9E99UBOCPINls3AWJG6RwYTwu
rVswz/3D8O0UE7MStfHcHXu3JDS28jYNIrU3Q1IppwrVuLjNmEHRnQbmXJEulLzsAwJdtLeh4VJH
4LEWCfie9oHu75Rartl3QTBfQJv50nF+z9HK4J8umuLZ8dp77O5dtAvfYWEoqDcJciJnNQ/dNvzN
FH3Mt2OqVf5OqMzswhukmL91kqwqiADXbFPyqfZItZYzA5xGdhQ5kuxLN2WkLTbaspbkTNUHf8pK
cNO7Rdvspzqmy0mxawiz/VVqMfbEbnef7qENksx+et3zSAsPAISc1K1So4SHvrILcGJdU2i2V2TK
Ku/eK1bU188H/q/kOru+I2vh36GFHS8H5zEezHkyG3MvWD/PRvZy6SN2uCXVFVrnPdQ52kgcRHoB
mOrl2HtP4j+acQG4SHekpe+5f9ZQWDpQxaJD4h8FYcsg3+gXsOTv3cCt2iHl+I1+Dsg0RxjoiwS7
cNVBy9PI08EyyWsmP3Pjral5vBGS1CWA5SlvlXoADG5xOkMCxSC3Dw6wxxkT2+mv6gfDgASXTwMR
K+gVuC6OulzOktuwf3+WHG7mcUHXOG3c6qfBVeMF6LVwa6J3zA6tdJd93nA24WCz9AqAKIJla4Ap
HCJ56XSdc9ZB+N9miqS4X8Z1tC/Sb4zRkoMz30Z2kdkaGavJ40J//tE6WuCfmzIojKwqQ5cCIFBn
rNCcH4Gxtwnm2YSQK3V9cVlPQiRzWYJ2dn72gE6zSXE69XDOwfHGOHg0dkj7ulaTq9/Lrnruhwzw
7CbjXOU4MCi2+LgoPP6cD3WuegtD7d1B6dSIx7mKnpguQZd6G+iiQI3ElhWGMopzaOPg0GDPgjOi
7eNHOjXq57p+exQwQSDsetbrUbJx7S0ZVecg6JN5JqLkzsEodxrril8lKgjJbajfcts5lD8YToXm
cmzixv078uTFPNb3WfL8fY2H0fu9Ig6E9ZvGN3Umt5jmFa9it05obYQ+gidHhTi8a4Xb5DQRQiLR
sUZHd4vZHY3wUHwtWMyf1COJ6N14IxYeQs7N7nZC/iBv7ySJ/ofvXU+PKb3Wq07IxM/gufybgXYG
gCacVRviopUo3XnwohHn+kbeTk+hedutp7idEN07cM3FNOC0EiDRyM27+tJaHtrTN5clIR9xNpEx
xmPevFssV1xNjnRFJNZB+FzO4SHKBxoZcrlet/AekdcpajpqeLSZEXYHceeh9HZesWjvKT/X/lNP
3UCCJUKgkV0/faT1W56ujGfCkODOKWCKB1/Xk4sQYvS+rwiIyjE4WM5exghd+kkjYnigEnCWayoZ
wTn0rWi9FSUZ9S89OQQH//hOf3V7klXk+8HXQNdwpTL/4MkYEEAxJU0N/wq6niNxM+puVevfkWtg
oPQ59bJoE/dW7Yh5kjcKqt2XcMjZnCDE+4VU6Kj9K/L4WKVY6pBBya57N0Q9UMpekmA3qgFkOWg8
JM5COSmB6mKwcUoMUW6W8svY8FPjH7iBjBMKS/5Rz1+ISaSi+SGoZ74M0+JM9VomDTFQTD1NMB5O
JLSAILwGL59AfEqIL0kYRSEH4OfwcbppFc/W0yH3FnYoedTaGYd7NmsdtTf8I3238NJRvLK/wMLt
nqm2/2ajWeoQie1g+B+k6usMjDWMNGgGMzSkz4FYMXqmsO4f9/hulwM1LvttWUqg6KRTDOSuuogL
iJc/vVf6V4i2eLYzBZd/NSuJIaqT4AJFySqJsbn3+c8r0g3wRpkcELtIf9fXHrX7xy3gMvfQNHwm
sD/DwIaz4eKo7DMJYhDItKu6EU3UH4orOT5/AX8DJ7fIkX+ZFU4PE/ceU5JXDNVBO5CzHpTk7+SV
WwVVGkNNuwEmNB+1euiH/pJ+YUBMc2zc2vl7GLUZZZSziya0pIDN3TfTYjmqVoeqSDP4ZilSrr6c
mWcFoMhIENprunmiVIV6+U8W9AJacgRkdf+gEaC2QAZiRkDdDmfh+TnLSZN8y6/G3j85Kn2TBArD
Ef+URu6QjS3GgIFLIS15imZPNn5tIIz58mqEBm6jaHHjo2NOAKBg8Mxz1aIBPb2fgcndbx6jkpB7
AbqjOkaiU0e5MuW3Z70SOjI1+GDdBx7TkFHBFyVDeF2IiHOQwxjpCi7HfjeEVe6m7dYEglEQseQx
36U8hVOPTBLoHvUiRHSfN7x7zK2VVsFJuc9LqzjEaLXWdGtSh98CyJHA4viin3Crjze6I+u5GnWV
pU8+jStSFwFaBHypT8L5EKnHGeFfh7rbyqVM505y1iK+AKuMdlmLMmkuFJiwguiHZ7mOEmomMn0j
l2Jc5n6+BI2aPSxk00Dp32LFwdeOV8pwolQI7jyaT/mXURHwSNxc4pcnh2aAo9pkjysVpXQsKm5i
apjC5RpiEAOrWGEKejnhpluY03Fsr88IKH1rHdmhP0SLjirh4JB6BWACUFMO4CXflZF91HY74Isj
EKt14HR/hAEsM0gvQ5nIMeU8Dwn/DG5FNQ0dJXh2elDeY0LgVQlzAokxMQloB1pyo1CbtzneJY6d
aR9j5xtpIu6g9hzlCpF9Btb/jxpKMN3+TpVHnOFza4CVYIx7osoQKGi66QX8vMsjzyR6GBNHSHZM
eJ7BiIQ04Nxez2keXCDQ+JYIHp0jLtbc3dATMgn4ciTldwpLj+jbfs6mbdSQKKg3R8IuaIa1PuK1
/7pAJkB2POsBOPd1NnfF67VGQB8i1lbcJU4kU7ka2o/T4RVe+18CvbR/U4WlE24+y9lCal474SQC
3l+iY1c4B97LR72NrqVXnFNpedoRYdQ0d3arjqlhv3KSKn2DZlkGaYJZDgOEutMETBeGnbwFf9zT
ivra1BX7bJBZH3MXGPRyQtjnSjb+3HBKIbksHmksvtwu1Fidy2Qg9PCZ9Np12sM/tvsbl2StQuXj
r5Ur3PGdOeLyLEWWCYTfBoCoTyxAw86Bs+e/lKdcXTclzksJzybyJDGbBOf1nH/vk6djFuzMgsCL
GhC2Qvz72kn22m49WEk0Bj6240hFIlj1EYzHn5++KTO5ZiFd7zkF8LCr4L8ttMcc3UKfquYWTEIC
ywHKDp+gTRMibItzGdcMPkK1Yo1/OV5CFZ/T0k4Y/x1lPShsSv1cwFEKcESnEavmANtFd7wKu07l
cNsTo8fCr4F/NP4vxIRZHsj6mpKYhn0aDDDK1D/UHY2uY211IxVFuULMl3qVoiDzQHFMIxysDg6z
r4Pud8kpZ+fZlF2Tskp5IqtrMHbpe3OPvg6Ot9ONn6kwavGcLHB0wyzlrs+4p46mMj1wt7JfRD3N
oF3e0RszHhiu9zC3vAFCLvh9Yo8eDyOXSi5WSk3VcUfHYcPLcB+Kql/nbhgaMUIh9zKfkwZJib13
k+QgixAD5ueALkUkfoX9XrXOUKAcljtqusBCmeCxDLxV3HZk9Mt0WC4H4+4CwDhJkmdTv1emvkjx
065iMV7kS5Egue72gLNXkqJYLVlMyyac0j+x2Xpret5X567O5SADV2fJ34hzQgeQMlJkgIdxI19H
Ck7rUX6UyLoqr5Ug4SttuApgePScoTJPbQMl5vaZdsnF5rdDgpICXs7L4p4XVIUG82A5XFiLWLXp
15kYVCYJ5oADbJzP4hr8RXTqa1vrb5DUHWj0uSSCNk6zELpy2p7n9HYYtqgbVqXoyDCrJYLE7Qot
gN+d2qbaiyyZRCXjKS3gTZgJIgwbUbNtRH5qrfRXVT3Fho6/REMzB+4knTEN3hPJeu7G176W/Rha
DCFZEAonijhCBXEp/3PXNJlkWwjsK5pXVkdkqhyngm4YJHv/4KmLNMEFTejvf20ZZWP8K/+nIPTy
mRoy9shqjVEgoJC4guZwY+V/NDPoVId9aJNtcNb1qGnZIf/wjxLV7ZhsW6DHfto0IUFfFk81Z0Hx
aQ8BD+N4VA5iveXBYoAiM0fEY8w19yd0SAI6N5U0XN+sni5TPWpyaa8IqLlqbRBWUf9wGOKt+gq/
5UIBU38fJxb+l4NhbrMfm/mCAn4vNUxqnd06hwdvb0JXBxFRYdAdrF4xOaiA+KsI64zGj/9kGhjX
KXIKyDYaN/rQmn3c5kv2HjoghOjpSPfpFvnVNvX/YxT2jx9ili/mk/k3dbLHLtiZZxMwMEfbv90V
5q5lkGPfAbHHVcRum/kq1obAVc8rwOwxwWca704imQe3HtRtkwxvfEr3sYsPT6XzArGfyVL4HQ0z
xXwxnDTdJyOGY0nKrdnRif3M5frmmgcQNgmxXJqMsfnKAWy1l/vQcm5jS1e5mWed9AhnYnK2vr/4
RMqmuz0cwa0AWYaciJChawJOsWJGl9KkVR0At23USehL06K+6WKaVe2ysWFkSYgIBsv6At0xPxDk
vwN2rlsLleKjU2k5kKRz9UsT6wVdNhPME7+Gets8YneUXCeN1Ly09X/OifxVnRVI4td3bl+Is0Yv
Z2L01AC8v4APTzVYFgMQan7oHGrbRu2FC1g0833IM9nS/v2ly8oXotws95vQhFVyu8Occo//2X67
xbglTp350jB0M/Z9ltEmNPbkm4JF+ZZ+ncxHgDUdvZMcRKTEBYhHL9YtRbtMNJ7/EDXmcB2Q8lRl
tOsF2+h0Ys25NwXIuxbxcp8h3iOho1fIIJr13O7CUdjIlA1RtEjqmBYpoW66KqBymm9SX0a8ofmU
SN5KYPo6zrjQESPCKcjOkEdSRBkvg3YE1RDiNpyelDFYn+vMdM4oHy4f0DH2sNZt0hnksN2Xmra+
tGNwhADGTfUcWDdV3AD3sA2QGnKkYRk5PoNvJIWsPLIMlQKDsuomC1GSfPIWLaxQ1UiRInafPq7z
JpPN2MDavh8LCxUrQpPxPfGYik7grPg9T//PbTFw3/kGI8MC3YyoYvnCOlDmCm9UCSsM+LXnEKEg
JeOXtM2Q5HWx45inRsx5zjOA6415XAITbJC2N52x4Ebs63siSRfOi/kGBMrmR/8YDKGPgF/KYdMp
ZYS3ZtsQEq54LcFAKViG5NVSjSztVkWAWouQys4Und4bIplXj95Gh6kIt9zUYRDvD4AXs3E5ak0p
xaogZYsk+NSU5reN0IkePZzX+0d/8+NxIFrQ5Yo2yoYdzX9MRIQ7AquwvjmZqESBaO/+LNmrIU25
9ymdN4FyswkEux8l7IYsHkFBHZ6p2+LhFlFmSZq7yxesjSM53eFruP1lNBn8rmEdkqgX5R9B/rEO
E28RLp5/4+CQ11GrkdWmTf6N6jKAHmsz+TSqebsFfYNu7cJgVtHkaWFB1w0H0CaLSPf1GuWAjv4U
kcZs03GSwfKPIgyiJPgpGPTsTiJgZoJvBqqH0JlJ/HIhkdchqKFfuC66cbPmL5bNJHEL+N9LAi0n
+vrel/PksTB8Zh8JZ8bzpqckSf61liIqrs0HK/wZBlqfBxhgZ/L4xWIUxMfgDlx1FX3GOsiIBY8Z
xqpEuoOnpMaQxDy7+2HhW8sXmWtNuHRr7cwpIAi2EmmnhfDe4Wx2++bI4FamYh6o/IpIH6KFW44F
5EqfooDW+1RXHLT76FgvqJvC9nn1gxsuzbCNRAAGxYs4q052dJzGg0psUScRYEY79Astq2NN/G==