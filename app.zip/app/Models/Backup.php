<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvRcenVScXXOcGWsDBiWzVOv0aEsbUwK1xAuTAhi9wNuyPFcI4IQKcJndutAjlvuybAb7HNh
+GQHoV21LcfOFPJpOyseUe5EwhXCDhcUMvES29cfqgz+Ha1rMnOmnPikMEIOgySZkBogHKnMHcIl
6oC0phxQSEiSDLQCNnU86iCPsJxg8uQGfquNK4rxoHajI0YFBRD7n9+23rGjkaPaOqqNFLcUCOrP
YO1emPosbtiB/K7JqiUK2vpN6dtzXN88lJ8C/DTf3JtsYDJIK7OUWvKJvljcNSnY/bIpu/beYPlJ
ZB1lvXTyP6KlFXQclX1l0GbnPSJtVSH0noby/cIG1ccA2u9qf4WhoQilCHEDTkY5Wc7obv/7tTi6
YaPV8q+HMAfhCKiSJjwPbjP9ExrBhqpzU50K+kOWibZNuw+8no4P+4bjS2hSR1UL6fIEZelDEV+F
Yuwtg+1nSjOUxj9kVzOOXU3elzlok1Te1yzbHjKTORf0k56d5egQZqN+eiKT0WC09iU2Ubr2t3u6
/rcTlHEU/TCtT9iKAdGPY8bvL+PKjQw6pf/CTX9XFNiLwaodwQLc2NSuWACnc18zYXodu6ncKMs8
RjgwzxqUZpHs69OOBb3yJgTOGfn4UoNX4cJ8EmPV2m26pJWxxOsw4cU8nXNh8ohTGJAA/RJPbd5o
m6xDofMUSZtSSdJo7oDTWMQ96nyjnjAHWN7W+RZtrnypemE/pECk0TMEksR2ZTJMel91aRnCGZGH
YSQNwP4R6a44Mj5jmsuQgNjawQ5fSihkvopJLyi1yOiilR+rrRPqA3lHAwDF62lDbOkZhE2BwCBG
ZJhDfwm+WWsZLpRGseDiz08x22UV5OWXy8wqy3fYxToxxb59Y5nFJ0isI6uhqIJgm08aE97/3XAo
cVH9sCCVSaGBFIryMuF25wBW0khnbpuoM1a/8cKubnSsVcFBgg4KJZkWz5fIJ1RwZ5Ly/AyFnPDn
lt73gfAEXvsxa61slz1ej5sKuuzFbiNvXd6IhyWSwjfNbXoHN5CKxud8WfOe9gzbA00DdX8HbwdX
v+nflzFuHWmJkV3aCNRbihkLJtS5cc/rESdLOY4Y1OhFIk7NC0UOMHqui1kZZGLe8bKEJrH898wD
SpWcj+4xGeHUAUy3L9gZakqOhwsG2dtaRAClmPfAuQg9X42mZIGdrWIzpcC/ftZC8+S+xbNZZbB0
63vkIR/B1m0b0b/guss/QiE+IP4e7t0AfIu6t1pP5wx3bYmRFpH6mF7Uyd6+LemKgxqCeJF+9Li2
+bzwcTczL1MWJgvR14q8eaiWewFViMr1Ho+kasOlssb7gsA75PWBpB3ZFr97oy6VvybwDr81q759
CPDlpzL/DCO0elO9BiASziaJcnZZEv3aJf2bCUnfzWAuzeKrrvKTxOMEGCsVamY7EWwBAOFzLY+d
g8kIV3AtC+wmazG9DJhu7tBTqScO6m4ilchKqsq7InZwX6QOW0Xu+J/PToXB0QoaTjHo1V/I3jnM
A2l2efVBwaMsyxV17fipht9uUI6Q3+cw7yLpQBio5ZJKN2R0ivKScXEnVNoF+cACsLBGE+PBcpGU
7Vif5neBRr4rOwElzE77o5/XJI5bFOQd5Xk0S8xi0fAArgLQ0LP79Nfu+gEI57QkVn2qae//v7sp
czXCiLDMwUavynqaOmWUo5VnDS1BkCqIvV9+hesB26vFjCfTVNtupP6KJhqN0Qmsd1KiFvHulCv3
2RhTMgRbgOzOzgKEhdl4A1CG+A20tB4el0V0YLMNjnuFR54gJtsmTnkxxjxyzxv3AGAfM2COjikU
5RnPqPjF/t/3B3Lvv2ryd/ZNXgD/CTdyBlpQMHrOMatqgGRLvY8XmqYB7WpNIYzPqLJN5hcMaArs
XwHzFaHlWYnrY2hCrdfFAriYsrXXNiJf6mJN5L2ln+noXZaQUZis5eAL300+3jD2+rnSSHTh1omx
ARhM7GVVo4HKlPBQzOsc3FCV/5YUFzbw0rkKV8C7KPwJpeispNEy4oUjf2WzcKRQzCDf15vRpsY9
UKims80U2waSQ2M1KJum2EY1rjCEuSJkCX9bgDwS0/TxScpDztNZ9bjUrhZUjv2Ubb+6YtacFYfs
NhZ6bOCKrOIN0WzLnT89VEzsp3d0yMXbdwOde4ekCS1SC6GPCYpB6mkrt17DpQlDSMYyr77qo6gJ
SylUXdWMExZhXCEIQAkmZZlESmO7EOvVBjyrK1BE/ywuKA+eP1KAMjKu8tanX54/T4r6h926UomM
ZFPAmwJ8+T8QFW46dk5hJJRJI8Ux2IX2WeV596i6I4DXv18I1l2fSbrJKcXIUD4DOtLDt9Qhc7SO
YHkmIDYnRHpXYFx0Row4XvSEl04dACLz6tZOMkC2Ux7ds0i8GFzUYNu8pPr40F8sG/+MMk0cv6v0
kU3aeW9H6cV2SKNW/q5WAyHyAo11IZTiuiV0dBWCe6tXKlDYCFs82RrL/l/00ZvJUic7MNBmspFg
6nIOkSr2SH3FzzxbkD9SdW79oWc84wW0C2bA375yIMp+eR57fhVYG7RpJllYPhRSWtVPngzfqR7M
rNULdb+bsv6SMWBRAMw33tieCJ65TT5NgJ/Gqb1PXtgPAWoksotE9zxNGnrMuzymFTzFdgyekIaV
B5ksrslXu571uxqGQlEOKxe1x5B+jwbDdf7FQjxJPUEuxtvW1W9rvnF3y+4n5fhLgsDhvfunJoma
ifcRFy34bxnUHz4GJreOKJL5g6Kopup7eU2uQYvwfVhD7YFG+MWP0NATOo2Qk/2AGhadquyTFdNf
xw/EvIndXnF7z5G7dZQyPDpFyXVTApz0dWfNjscJEuKuFNw4z8nG/+H/zUXSYf+LEydrS/pBsAwc
C5C3hfkEX4g9DGwvNIE51nR0mMaAUmGuQvAXSMgDWRAw53E1UQ1Cxj4YDSSUuDdce1nwQggaWfLh
JW2M6eoEnr7XDaKJqm23vbzPs1RoLnw7nN2XzkLckWGT9VSlhC3SE9p8o744mg5knzf4ASastQDi
2+A44MVy/8UwNXj8jm80BsMvijd2jC4FPSyv9agHVCSunuTpSG7+Nqh/uOHpeWICTcVaCVCXHlvG
HduEWtHTfTjB27eg8QccdfkyIWsQjwjdosT7omDgw+OswEOVit5rgZtTypgExJ7Pmgn28vSjP6WL
MhJWXJiFAS6FFPkX3JGWh9wRL3wEJojUsp13X9Vgj2FUAkZXXtnk0Eh6O/zmvtdI7YcE5Ogi7abE
A7eC2ogNccgnuXkPS8lBAl6J60A3L2dyfpklJemoWcFDVzMIJY3zMbQHhz5hNrzGV+fKnW8piXgs
aC1SrNfcJZ0MEruFpfJZTD0K5fSMSDX3nYpQWFgXfecq6jpGvgxZFNqiqy5S2U7S9Phc6Ke0JFT4
MbX824h02o7AMQI44/yoVeZuKusqmeWlx6BxPUSk1y2cb1bEjoR8DPIEx/z0ZN67qp43CRTrfSuX
nGmTkkXNmwJXcbYHhIqkRL1kxD3rR8Rzk46i7VxXQFCwSTFINPmg2nDvsmTzYYrkX1XrA6mCbHZp
UiZU0BtJL4FA9lEP6SAh0XmbI+H09i5ILIoYD8p/ld1YKYZ+qj0XaSFtlQbfqA8KIcIEhpB8rY74
rftqlVNIeufcBHwfr0I8DRJNbky8hR75DJAYfDgNvNuMEbNox+aDTRRjvSBVr/3YifXwGVSPI7WA
o381GJXuw7kq4IOReJTLUtIwwkMbJBNI0rij0D8V9JFmsHRivwaYL5XK/mqxdfp+ij3K7apMkO4j
GzOkmxrQIAK0hima8L4imewJg8ej39Yls5At7mR4FjWEzkX/LQNKw2zfy8bgNdMTcR2Tv2UKBwpZ
pP9FxbMmrwaV4kPQrD/jTfKlMYhYeUatKx+1s9OcoauH1U+SXjBuza6TlkdPkLBYaIPg+B8t8APj
OCLpOlJYm53zQimQrcEUlyHjv8UCoOovDTxtOD3w8ig6g8x8h+Fj/yiQPs1CE+FJxoDHOl2ykURL
3UglfoJOCoYdFd8h6ErYeyjMxVGTBkzyuvO5V8bDtPk0j/xT+MRiOqIP/9zU3iJp3UxwLl08HLJ5
c/1YKhhs8I31mbFxscl/75KOxwtJ2JO/CBxb5AY0rYAr1T2w+LsTqsUUvSSB5D91pr8WY+WAAAuM
rq0VRBIzvE/5QX0W/Rt9SNlUsQWUeYx2QhG1lLO5/iHV9pPFm3dSu2ZrHfDq8PPSdXN490xM56/b
xXUA7EVnXnGERmroVTzgU0u7bvy2944jr2ZGoLO0d0yPTLR8eWMzgPvHcXbpYUbpLN6sHOSWgWv9
UKCGqzQjmLuZHA85OiHMaxPeDyMPElU0ex7NzF8BRbJ7HjkR0njxxZ60rUjU/knmHtAkkUNWghzd
4QGJnNJcOAQDHyGuBylf/xBOebZTjsqFAXCtG6Bjup0Fx3TRUXZdEbAdNl+ximY7D6b1WmO0sNUE
WEKcn2kBqp9Q3iUpk0t39QqEjlqbVFAbZGZMH0ID2+WYmlOTM/VLqW2q8rr/Y3HrkiGnsCSfS6vz
4q+8AjSnMnCTznR5dXN0akmPg7VL/xycyUyCJlRSDzDkCByckIp4/eOT9a1GxC8ME46VHRUMqjiv
a1++JgspfSxrRktDJ2AKr5tAPqOffKA67m79QOneaXR0QfQL3Lz2+DirZ6iZLh0a59hc/8m7tKbX
4mFc8tCXWE1vxK52qMY3Sm5QugQHkpfs2sKc51ny5QqBLuLdmVSA5oqbEVaQgCLqj38xruiRw3ul
iaMoDeVH8v4kenpRxEr6/u6C/SLn8bR9gPtdLmZ1iE1tX+w+MPeJNkemZJOoXid80D2/1QNBxUbx
iQZjqDZkC5o8BUt/e/jx8sdKN2KB1sepnQ05iUm3ZqHhYhXTrO9F1SNey/1r1G57D1ySwxHwrX5b
AYsMWt7TBPpEKJM1/AJIQsiZp08Qo2NWlI1Tolf7HUqGuHrWZkQq4kB0fc6/o9Dz1Ag7qbF+wxj7
kYj2jQpfKWrW2cFX+zu8xUMk+q09VC6pBfjOC5c0Lu+1wjDN89AOpzgLiVWv7K1q2Y1az9fNAndw
3phckyhkptooasl698SQCI+ckba+EPbzlddjaeRrjdGNRY477BA0jMeuGLl/wHj9WPtFXW611NJT
1K5mSokBRUMrmO3wcGOEUKGLcxUcHjc1tdd1jwK3NKyJLoWDPbKmyL7KhuQNzVcOgTbbQcLvQ8/j
CNifL9B5lmiYoxvZKryLfpURMhhODAOo+qG/Np7XzbVCJPxLm+jXtrwbROmiGyJcmSYscr/mIPEo
lRZfp2MkCjWilOmEQE0x6sEQ8vLbcEdPgKRGlY7uDIH2cd1+DxQHYPHpN42fvF6MS2huJ9sonfnz
/fnRSY0GuNqfR3NdVETe6z3UUMJ8ge383XOKb8eWPzH6zVoSdC+wBKFxyLLAiAGTV2U/Dvb72S5Y
X+JBj/X3CpBgzmKb+LpcPVzMlVqTaHSQ6vDvQsPHypsKWnhxaLCf0TQQ9U0V3TFnicM7tZyalcD6
2A97lL/BmeFJob8TBlf5gENLLjVSfl/1dk0eXuTWv9XxC03kPISER7TMHvK45oyExYbJPxrbHtJp
Xq7+QjyL1WpuhQrpqYG1wZ6io87ZBICiOkh5qAIvXSl+LpMCKiAykNzyxQNJzEe9u6S/tDE9Zl7x
lNC+wFgFSnBFsTYNlNf7M1XmJYG20NJIhcUpk9HWTgIAVMXsyQNpXSTckZbzTWRk593R7sRx3llY
x45+6r8Trarmsh/TG510FaLmx45iBJqkPvMB6M1lCS6Zyl3NLzsuPeHDafmN/zftkBWJnWkS2KLt
P/7DoKUgTaGNUOhQLDav5jevlqi5m73phc1CKmU9cLGmCdwAKjicQ2ZKQUuh7nvUDxNjTl9ehMio
vFmE8PwkA46Lt7NFH16YAhwaZbRn0ouIts+IE4qsyhqkObswlW0rUuATvUKFzcHlXGKmLpcH4JP0
f2J7/B/A1YyF6zFVFX+rctvjt/iA4/ZcFp0gMdw/VaMwjAyDdhPZdN0qUMkZAO+uwpwmzJsafBGX
OTcgU6Z6KADjNQwjSfdcilSu5zEf+dRkPdUs7VDICP2la1e8m1p56fjerZ16rFYrRxPEt5iDSBwR
aNsKWIbjjX+ZMJG4S7dXDdp/XgCquDrBC2WX9WmNz9oV/LeF/F7ajBVvNekd//pQ/FIJT1vAih26
Qvx4HTv6Pz+lsx0ImllFi71B16RJDJxapcFOiN4XPC/5gO2IfThHKnPj6VdlnAoU2I9P7HNQ9C6H
gK0DvL3YST7K4SxggqCm6b4e+CsAfqiSIebKbAIYKNOOcHJCSd8EniQAsUQytJHxU9tn9njB8KCS
o1gBwnXRiYXjK5JD3w5DtuduunqhNXmhaC4H7j8hHEhM5Yr+alhOB1qc90pJmJjHaM8M4ukN9WnO
quM6gU1vIPOvZ8SbRGni28PQJdbslVQDzXRInCde/jG4QuMXtx9DZce9pxeEMV+82w+kv47nMPNV
3+M44ZaQ+FkBHUGZCzb+Rcruc0qQzhBTFyEpsUsA9Qm9LIU7lwWMJqx9ESD7rj9FcZCCqFhH0B6P
IvJ+xFbdZN5a0U6XScpzQMKi39cycts3bwVVdaLWUTswz6162tkYeY1xfbaNYl9kJVr7v8kpqkka
rK3q9lyc8gO71rauYWkodJjkthwPpxphjJ86stAX40DDR28pwELcxA1eQ7PMP18AzTx9B/Nr8Fz9
8QgEN2EJYOnQ7Y79WWk6foLvZnRWfqztstUVQeerTXtcM1/qnq9WwLp7Wg14zuFDy8qHttm8EC2e
x5pphdjzr+pc3mgZnVmm618IuhqgSKWYmg+9GFpMvGJlUoqOorVKLhZ8yJHLIzN37FyS5MfltHqr
6VTNoivRnMue7dmkOLSKj5wxdSOu1WLt3ZsNuBOP8rbo0B4TTuxGcwh+PhecXU+mXSdSohnDtGPp
yNKqiLzN/p9UFilRMJ1NVAtF+aKkHLVzh0IaboK0HEiMJ+LpykxT3bn5ZUIG+HMfkY8+IlywVnRw
2jc2HwvGCu9ctbvdbWr7t64FmQKOFPPAnGoKLJZMFmgp9EPHxApCEpEvb9Zvj2We3Bd2CwYFRdM/
EvJa61H8tsAtRhPFS33MM2EIts4SoAg10tdfGguJPkHkbAUduRMpjRDT9xfVMI8vKM3806qDSij8
SvrAs/nXV66PebGENPbg31zjKFnsp9l8UDau+Nlyihxyzq8EjEagSeuPmAoiRXF/J/DPnKTeOPp3
rKDlYECLUF0rOfH6QTWMNyy4fBx5TWvJe+dU+ytx/zm/8onR1hUE++CQpprzkzNhvsfA2Pl15oa6
cnjjjEfN1hcKwlXm1H++Y5wlCcidWEAB/9tFy7x77Lz2a0HqVMlP59lqYz2zuNRF6vL1lKMhVEgf
FH7R7S2vyWSM+6fgCUMGCeagPldnh3I0Ln4WJO5Qvyrwroc600oUrC7NNgfSzDqUqkk4u7QZaen/
XDgHetSLykNZGa88+0t/YP4Q+k2kRx7S3j2LLFymi4QEhjV9/o6xZcE41wPd1a8MCJHSkAwwAcpg
PVcMAD3WpTkd0/wZTHOjMEOFwvLzMNN4Pa7Daxlo70YC1gC+bfQ4JS5+Fjij1jQbFVZaY9lr0RGI
rLGn7W41Q6OsV89u0ERGxasHErpOTY1h05RUJrDGwhsiojtR4DaEiqVHhPcEQSByS+3er1B+CdSH
JweXtGUdzaG8mX42nMJ8GwOi8LQFS8/hLmIS12SsfF75/bwQkarVIqXCPR36aOzOrjgixlqE1wu2
yfulgl50jKV0b4zioIHxJC/wg5Vpg+0dcLbvn+gIjqqNTW8S2CzgLatKCeaxqP8oellN6/lnp2aW
+m5YQcCXCYsdRL3yXAdSJ0r+6gnKhryv1+rC9Mp0pvbVHEm2pfDWmtluyjMGcD/pct//CEZRas0j
sFVZ4dzEFnXTR4LkUEJLwve79/UxwWfLnjossP8RQZWZDjqNUCbJdqYuoaI5dvszluaBTRQF8vTd
gHa4J5JFUFz5j/egkBFFbkENX+XuNG8J999zSKNyfLU05YlTybcHmM6VTm/2gp4ulvlMhwB7DIo0
R8lU8/1tVAskAzr8yS5UkrJiynjx+JN1dvMl3o1xQdOT6TqMpvXdX4lajK7Bg4/bpuIlJ8tJsR7l
Db/eMv4KIqcm6ifMaqjRadbbp2ksugirWC5Z0og5tY0jueEVrWJRDa5c7z2zyxk6+UaIyc5Q0y+6
uxigjDE4G9cRDHhObB0kDshNzJ1eW6DxqRctMdqSPfPNlaYX8QUnsgRF0aNL+OytC1BcvUZyIgCJ
ojSA+/oUaZ8O/yQBdh8Ad6DYLzMjhOXeYexaardGedbCcegpWYNMjyO2EQQZ2b62TQPQqT6fo6KU
yBYrFugNz7SQtD9GHQCGJpJcINvqpZX9I1wGztHnru2YLYxEv7HJwSVAbJR+RJ6Az7GtChvj4P6i
DPMR4PJnBhSYQRALkwtKuoxwTWCXwqgIzE6xZUtBsZlNYoO9tI2Y8nMvnUPhne/W5aLGfkMp2yyR
SLsVpSMGLGjA52xb295nH0QeMABVDm3W