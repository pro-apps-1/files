<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmRZQR8TXbA6s0pyaTsmw2Rge3XuRnNjmjgLii8l8+BSPXyc3aKQQCyDTbSh04RXm936Ug1b
swyVvI+FzGxURx8otjLSmpRNt8LEZIzThf8rZfh/hwk0CBN3IqgChqjag/pLToZ4SPaNKZxAZP5s
KMcSPG7+lSV0Dl5ZARIliPdu1Ws2sHKWd7CLrTtekVjwanJYIJlFWkIF9rRBLqi9sjaEAJOZQyW2
3+g2ruvGv3gu8XGteAKm6TKQsllea868N8bdxgdLjW9MoV94lq2LcN4zhW9rQpZHm2hAeTMOYHnU
FjYJ4LCGCAMGSd1koQGhAhM1d5kZikDNdC3JNbZEai16oyO1Zc/suTrgaJUJpF6qclE1BvtX5mtL
hUTTW0lt3zVmx0dF07AFrTLxYCsvjtJMJRfk+k+q196lEwibXPh+Lnr746ARpv8DDzLo71h1+bwh
EbfBIJPo+PA/fhw+VK9tox6UwYNiZ8O7dEnH/WD8wYpfXEAUsVbXD2ND49l7OSqncRko6WX9LXT8
IqS4qkP7v0rJ8d0s4slZyNzGzFgXvK5Chs9AhizRBagD21HGzdxwTAwbwA6wTbCSl+t3XhA/mKBL
pds8I+bngP6uy+Z7AWaTly26XAd88W2taXvwyIyK3NsN9f8+WIw/oNogsyFrElXRhtT/avfk6TbI
S1j6kBraL3QPMWcRc6uIws1N1mudbwmcJtD5nIDX/rAPnP2K1p+MHXFxNJJptxeN8VViRvBPsdbP
Az0zNKLoVbpXXxppyZtQP9gKz7oO1r5cE89zTWDcbM8ChqLs/H1HodHofIlprXi32ABYLfxT1ts1
xsXvfZS7LyYW70HBSayscda3KGvG9zUsHqHonJ9YNLyeyMsHFm6fOtYRidGdXS4SJEBYMUB0anRd
8W+/W0oS36QJAa2CrfD+pYnRBL23AAIMsKym+dK0tm4H9NpAOQ/YGC8sAgkDqAwr3rvyimRkX3+y
GCogeW18rHgiJrT0LSQHlvi1LCw9ErSciuC+SMqt5NLM/oG9OApRbmuBzmRV9CxM2jliZGmpw/zb
9TI/LVWKbkxsZt/NKUz9U5CaFfTFJRw17Y/pmggNNa8GZazVaQlXU9QK0rinHLI0qkoJtNqM/1L7
Y4s0mgggnLrh08a2T6jBegpypqQolhso10s+j2muspFzvxeuj8lQggMo3iybdpJIgLSsKdPxxU4L
d7yTohaUKs6OV/cDlbCuFswB7f1JS9ZfXwQh9OmAU/S9+YBXE433ACvKgniK9JWuCFkAGyYYlIAy
7lRGSjhlq2d/nkXxQCBzSADML3Ysidj/V+5GWwiwGB8A4daYJAJ2Cx0n5Eob7RaIOdMxFmQATh6I
ZWgYN0tv0A+Qq4xhJoyM72xTDQ6ey+E2+otF0zv7aMfxyVGFOGrDONSe2v59IbVjPWuK/hUj6Xr6
Zp3WYznVzPXG1dNCoOTFD0hGGwjvbbK5+uAngPhwd1QcBMMOvHpuTxwnClyJ215KsiIN3x5z3Mbu
er2Dt73rTlcsUqLP2WXWDN3PUvAJE0oFivIk/JGEZwR1bUqrMNKGv4tCWx+Rs9EV4xb5gMZWLxEJ
C28dJh7vcqhP7lqEZfwQughnQTAddu0LGHcXgckcDwZW7p8mtCgoTGrDBsgAihfNyJzZYvIw4H9z
GlssAM3f4xUl+lU+kV1Rat8zCXJUtsyIq+8QerTFNEiFu7abKaeGcnVHmRc+AmU7aMSfvVAcSNb6
LInlxPfzmAqN3TR1dGP3969K8EsmwCnerTTH8m2un4RrWFUkYKgcsypYB0bD7lLuf16OnOEfQASF
qK1hOSEbojJ0/sVCxMCQ3QqufDddixZnGoroQGMvoq2YUkiFHORGxFF6b3MnFaSvd10AqcmpVzzF
7wPTcuNSkmq1wH9oB941HLTyfjrDPSHlULXEmxa0o3d87cwR8ybJ8ksWroMwTVKzVTqn7/VauRdF
YgEqUNlAEiK1ytd33Wf0k5IhYduuJRGwEKJeR3RX/xwqW+o3UqiWYmSG3KZxHY+T7rRfmKl/xLsq
dK2Nm0E3rMuSZcqLRayI3pc1AnEptxHsAVRYGgkPKYFA4C8fGiQimuLjwhZL4TGmSvqQVHq6hroN
EoKpkmi8fEW5IwIzqR12aLy6t0sXmvVhospk9sL+UTm3xLY3DCoVQqzFbvapxIUfDWsGKN0sbjjK
AGlbR3bjVAIY1vSGx0W/JGK0SfXclyOXeaAViDTTpSmVNVVpfriH78p1vMzQYorF16EIJ2E0/m4X
c1hi7EYnx1cGNaTulgopMlnLsUI1mnZxT6amEzM70o+wYeo/+PLvpi0cZL5toPk6V16nFVnj4iWg
mYWp/8UYWMC/rjPznv256Dp0LWHmHVlBIfM17thyV5hgpym9IOei3vFcC2VLsDRH3AQlATIahKzb
H8PVlj5tqh9ke8gUZdIgMSxpJmG4KJJJU1tiwM4OtBs5MZSxBZzWHKIcDCyCkJqV0N085cHWgiyO
9MLR5rBzZ5SFvF9zpfdKXIVS3gLLmeV4UEVffBqtWLtjeIps5GH5Vp2fnsqVPnpIJXltdryMcWq+
YeGxleh306aF8y378r6EYKtDtb1msShMM3tjIN2wkFQZZE10QGi/6vvw2Xltsjlj7R5l9lOHmRKu
sGMTnSjc2x6J6HxTX3RX0UhxjftevLgUPw0qMOSiKLHUly0hCSKwCx8WKrlt7TNV5KFig2H+62Lu
a1j/h4QAzCaw2T8Q1wzgtTHdZNnC+hxTZVhtJ0k88koMeHdK0q+VAqoKoOQWGVW+HQMxzhU8f2jn
TILKQagYWT7VcZW3rv47yUsX+W64bvqIPG4UoqE9i7jJbxAl7O9fSy46keXtutX85Lrwg5Y//hfU
GkHXCV66CGi36JNxeb0Sl95RqB/vGhZLwXaTEbIGtfX1Gsxk2iryk7siBohz5BWPY2s9nrZRwc4R
W7jp6VphRUu2mSyLWXwKfbbF+rcO8XDvkAE2ZJ/YU+GbyCK8YACFwkex0+MwCqgHzyU9Dh5q835b
Dee6U/MmVE07yYJ/t2LLu/uHtrOYqqZvY1a0c50E9aHg+Z7wOavsPQ8tf/pBcnRCwSqXnYGSxBv9
e+Q+WXocDaF1y5rfqf0Uqm3YaXytCFtwZ+rM9UiYp7yKAVqZXoS70kFcQsG5OSK/5ueT1LFNwmvP
sQ1CL7XWFU5ldPNT15rT3D+Blw2WTRiv1uIo4r3+XVBHINVYBD5RSwRBR29+h3qmeY0mTHnllnM5
jcCkYbrJdxUPV9hDNQkRMz9+eSckzG1vLWC5yWUNj4n+aWnuI7SeBsnJ/krFSK1cfnCqXPDCIaFM
IFWsUCcPp10xvE5u5KVstpQ+/vQeIbqNwOyuYzImpaDbBI8uIhwXwjr7cHLQGwQLzfLD92u8iQan
ewSKmtNbDMPbBpbmfstigACwO856e+2SmnbzXz0ha8L+aS1xdb/+JNE3ag574sm+nWREXPjwnwwx
h+59m2ZypBE6aaoFtb0S/WAZJPWjHnOT91lRVgm66d94BecytCcynqVXnv2KAwWZNR0miuxC7Bn3
diZT3+0og+bF2BKCc5OrJysPNlx+2ogRkpls5lP4N5ldDnK7odpy3746CMurk6+gfX95I6/o8Y/O
txLaZXbUl3AAyDhNHL3znSVDTrHzk/bZjUGC2yU0deVtPjCVJcHymtdJd459Znt8peRy5DMqSyTu
v7r6k50QZwZOGyK47W/eK6+ztN/oPvluKDMCAytv9UpZl511bnmYS2AOSfbf/sIn9pYUKt/vvtxk
/PBH6MHBoxywRns3Z9xDg2ri74Mur+chihhFWD5S44Qxx/c7Uw8Mjyb3UUVX+hT+N/cxr28tSE9o
ZhCA3ctlhFjzCZKZht8ddcjg14owRMc2sw/Wp58A4VxMAJvLxIElHN0YiwbMFI0/2r102mSldOoq
+6s4Prtu6eo58cQiRxTJ3rUr0yq89PuU1MfW03LuWpKbkNezvUJptenCivIaCOB1x7hbRRO+6ZLr
FO8FiTg6t3GRXQ74hLT1XBc+9DtWeOoDQG95XulkriYoyPuGMrSgyHCrGIcUplAQxyZYjvDzrwyL
EvVGgiV4DLVYC2JGP5B9DIx/EnbdiWdbvknXOgC+uy6R1lNlVS042zhnkvqGXNkUU4WNwRBAM+NT
SXs1nXFLHyqEjRNT+FqCChoQT50z0c0+Lo9YveCdp/SApDt0ZFd8tCH1kK3ZS6AhrseGFZEGPf8A
rKqvRHBKV1Qx1gUo3sQ87erFa/3hoQWOiQkMJF7YOQffyJwxkQoPjFrJXGQv+ndjXWsTssy+UJ//
YbLr+dk8WDgJSz069wW27tVZ0xvlu+GU6Kk25w6pIaVSSHUxXqqXxGduq56AK+lTI1sW+gN53zjq
oyhLRQwTnKEOgT9tY8rNJUq8gyvoPP7WxKKwBk1/7occ80n0SSYNIgi5XFLBK4ca1eOOG/3S9x8Z
rI+nBQXh5wHBo6ZSuaMm5HfmXdnLyLXnbvWiq9+ZtfISQdEyZ6cKycVN91XgD4P+ChNOmkHjFLjY
QRRPcdT+a6izBNJLUySRR1adipKrOeZrnGA0sRyOHo7I6/O2f+Mi4KZjDkRKIKEZmDxKb8MRevqw
PKdjMHkSdSbyuS8Wl15Dmiqs5Jdknl+gx/6YNhzmmmL6h/76j4NYj9TwRi48pfPT1wToMVtwJ4aF
SB0qY1zYeeyPJ2DPZepvyRC6XLP+FSx3W2t1puGeHwgdu0Y8QTR7R0JQifpJf5CPgN+o09Ha+Xwq
OzHvxRYTspMbrYoye4agKTqtSNxMAlSPMRPE/oB6Qu6r82q0HF/Ca6ZLmGMbWLitMmItNpjR6d74
kyMF+3QRvA58g7kn08aswYmzMPfstQasYLGOGqMmcSZMuNtoPK3fhW9CWbsxoVjnD8h/tp9+y8xE
AjllwGTWrYYcYGMTqjCTfxq/UID6sn/g5k7YufifsmQoLnGuuehMaUWTGHJBQ9iZfb/JXeEFQU+Z
bwEEcF4V8Qws4vNUEgrmfPD5S6Xm4jVj99+W59rpnZj51bpBk5rsmJTWmHJKuKqdi34pa6EntECC
qzPNxuDp2vz6YTjLAmBHUrNBDDNo4FY626p3bnAwWvZlMmyj80RU5/89bBuHjh1ZzoS8A+hE8Z09
9ou2npOtQgKaaEu0zH4eFJYMpeg5MMtYKQIZ7oDDAoLspq6z39L0RPhpq4rhyi11BOS9rNBZzvLu
CAyq3tBpEiYSPM9daBZzXJj879HNp815sqLBGP9XmbwnMyO+p1jSRu3/jN7ZsMKxq+EA4nlLks2+
KwlEJNvIMr1STTCd6/jsTrJa0zL5eRIlIhMHqOMEhc06Ns6FtlCp1u2OBOYt5PZPH+C7TADOCEij
6rleDlbxiCgU972dtBGOdMlUS1hcLU6ToneoYkrxyefw2uF6h8pMf7VuS3ckz+WtyXYAf6g5XLEA
STmqE9XFFlBjxpQIlmJWN5+O0TlFlnBBJLufRWdFQly9vdZPVARJNOPF1gZyeMN+BIlspF+g1kBD
TwFdo9VpDo0+9LmPcWSveuFPlSh/jgf6FJGXVQ1j0s36pp2zvALVtPECk50ZH0MDwMugr/YgRt6R
fe80rUXsiK+w0TazfZUZcSRGj1ZCPYchR+SCnw2tRuXW0AyQhhQ2rNe2xPujpVlaJbgFtj8dZRku
GHr5GEUUBmcj7XyPepzuWP3279l+72l0fO0Tgw5BrtWhOZrmRzGejqm2FOAJVNzh8xjwqCpYQAvt
LvYNqzHH6WoVvnUcj10nN2t4egAEBHXADLD/RPAP1706cT/gM+V/cq6lcRR7DaisDEZ5byJBUJc1
jBrQV+QzSRKUfQKnU7nzE5/HVINA0sF7Fgc5KtHJC3Uj9ifIzImHsuGFblOoNDk/g7fZa1pTEiF0
AtvdxRKq7IbZWGS0SxWWFboc8d9024CuciH6+W9B5pX2iIGjf0nnkC3C1DjfaNmnVtiKImipAB4i
EkI/gV9aZFJT3cByLoEJnIsQop8KeeFdt7d6cJG511FWvAE+Czf/ouYIfrfgX4Y9MTjqdEXeeYfb
kfPlg7iCjcgf4RPvhvMQx2E3I+B2tOtcroO1P50ckGgqDC+Bk2pqevnc1VTdV6aErd+1p6WYthMp
GABpfgpFdk+y0XVrgdSiMRBzFXDWMI1NqnwBtUY5PQ5S8Doq/33/Ne9YIP0vStjAzIxEtc5B0dLi
hi2c3X7ztq9N3JbXvqFBszyMXS7JfW9VDbxcO3SPNwXPXgOfTLrvAD3oVJdhD+drYM1qnZ2bLWmt
fs6lmB9ROLMRDOVZgz4bv/4aYB171fi2HNhWwfWHZe5WQhVfvJBgxeO1+NrFD02EWTldyloEN0rN
oXb59jOAgydPIuFumTh+zzqwG7+Y3maw+zuPbOZHGRu0ec76w8Vv9RrCFx5E0J62rNI//Xv7ss3F
xwACNRC4K70TiJOf5PpZSMqR/gGZ8UgOgVEMn+KMLp1ZVCHvbFOJiGvY8Qhi0T0B6liamSozuuba
u7rfur5Tg1KYKV+PI/yQwGPlkAyG4AJMM/krEzA7ys9UePFJoBhqU5ThGMBtKAb6K8+V+2Rc57qN
/K+r6ZY8tiUsWOr4R3yPbKA8VvGvT9yfxP35wfmCRxaE43tOX7QTxBRwJaiJTJe4/IAKmYO8xqzQ
jJzlcExsMrR5l79o9GrqYGZeVrhguSkzSKpjXiVLc2/bpe5FML9xMm5dLzIPkxvI6BdKmoGsopZ4
eW+xQrO0Zg8VZsLkzGSkwBNoZ0NzIG7Ly5l7CFF4dTOWdvbpVTtg57qg5wELJr6NwBM5Bs49A3Du
BasYDCFi8fLJEMqqwk4tL56xxS7aw2G5zbaC/0/nrMb38FfVA1qLuRHj5/coejBCmcbRWYHCZCYw
6OLD0CQgY1hfPJvW8xZS/8X2r988r4/kg/Fuc0jtW89RLcNoZXufxq/bOurFjZILN9X+vJ9rTsjG
JVLSqm5noPcenXP2soCJI3wCSVarw4fOndjugifp/8WRkKw1bz0uBXNj617bbRNhP62nxNqu+pW2
Sr6S0+kUroJSsi8ipoZOXXg9Fv7Tm6tj2GCBgZrztL4He1avjdO7mVTA3+mpe9bw+K1pXm7Q3MGw
+7WHoXXJKs/WfXbUQBtWdRd1WNhqTTw6JBo6Eqx2IHLgVbbmlPMfTntP05dcdVddSwa+DA4CPlhp
c3yXM48IPbFLX4MqCXp/mmt25TIG8DurBH76uPgzHDBYlvGdpWyVcyZaI+uxgpxbChjhQpRZw/Cb
EHxkXWipYDfz4K9pWLEZfs1rLpzf7eLRf39WiLY/gx/psACP3WznA8bdEIJq3lUc6mVu24HMxgyM
slnDCqdLeK1czpbiTfQzi1ElHmTADa3N9SH78RTVNGjFXF0K6g4z6HkNM4cpVkEuyT5TVgXSU3t4
FsfZQe1F/U2LHOQDsDvRjFngr69tMiX8Zj1nZwoQr/bNbnPvC0iqLEr4z3rfHQopaOJ9KONVKAag
FMsd6Hiic3ILAQ0ohSDrB9AvnUKRkag7Eivqj0ojdN7RYU3p2RvfsNe/9GRswXhnug25db+0aiHF
qFHXn3Sw4Mu7pp1Rrb952l0j31RLIe0rG28r+P+3zoEZ8Ncjb3M/Dnc/LiN6+xNlGfKB6pD9kUhg
JFEHg+udVArfW7UYtCNT+q5qODgYerESWITv3yFMaZd0nlLuy6FMPmLdhjduPFkg1thZLjtvErl6
GIt7Us8Z8QY+SZwVSMHtU58o9lezXraOxvuHv8vsh1ACHrx/L3afMgSoGD77ASNlfG45jpR/oHvk
vyzB9dj1usz+ZKKQlrOpgkpyfcXawTV/8iTrzBwlu9RcMrBKuMAHlCR981I0J53pkzigu6INs9cC
xq92st6aXZc9c4gplTMA5SFwtnP4/w/wKdu7RhFCp7NKUI2/zBV2UhZ345d814Z8JwD7toNRdcFK
nxxo7fhPk1HWIvVeXFdBolQWT34CLGBXdU2KOsZJ63T0myXU+UGDPBzGG6CfaGiE/59yyrTPoavz
cZsAMlJ1A0FuukqbXWMudoevRRJKy+1RIRfhTkEB9AIAIobow406nNW3YeMWLLy+bJe6m4oawa7E
vt3k2fDcO8Veynwf0W340zqp8oyRuK4ZzTOAKigIECCXrT2jPYhNaJjZtVsGZtda+bFhziM4lxKD
XV6k4KjLadlo3w1TnzrNKeiTX/goPKGUPp8dAM51k2jZMoZgaKsT5zM3+sdKXSAPt6PiX007j/f0
xZGc6iPi9dmN5Xzd644EOYsIQ5XDTY6ss17M90k+IqJoiobCx5fRPKCADQEQsGRmlEfFmIXu1iBb
oFZ/+95rGYaQuKtCxvt2l13Mx8U3dB6ECG8h8L14rCits/ld588P0jZSCWMVXdPlaiVR0t2uxGXx
EJW8aGmNN3aWzqZvEp7h+KxzssRcQ87F5y/sOCyNvuyOkMHnoR3IZr3oW2Cp0OHcud1jVcZwTXTz
ziXPS/mknfWxsVegw7tYOyk29SkNA4dDBeACaooLH1KtCedpx9zO17lxOV4g3XrAvd9qymC5J9RS
Gwzx7Segxp5pio3Rv18qFrnxpv27zgmTNYWspyNoOp9nsoxsZ8YOJrsBwYsMd0c3A1C11Zxk7nT6
LCTadyQjSEH8huCvqbS=