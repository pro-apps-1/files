<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPm+p3wXVCVIF9bsQYt+lJtThOb7JhexOXvUuJTs9UTpwjtBUvxoT5MDWDgSwiFqorIOTD05f
SGiZnxQ166zH6hGVK46vBprihL9e9OmNFrRO/D24u1IjtvPNPYBW+aqMyCRdX5VPTn7KlDKcjZD+
OQ/GQhuwkomaoIP/c2if6HDtlQwT03eJJdEPgoouHVKLPBpcr7BFarnmfDa2MHXRqgDB4GSC4H+A
psTqnl5h4pbxLiKcxbaICN0+kgf6BE5HUez4cGvBj2YX+IbYrpdhsNBPbP1ZOfGVWGE52TEOYFbZ
humO8d7kCFY5JVkV9+qWnv0hl+ThWBcKX5FHnNzNYwebcY2pNMYO42mYc7cbSvTZ/2hjgmdKEEWK
h4zTjSlSbzIOJIsMYmvxkaPUH8pH2hbO0qhUTICcT6VrlxdHLZVnolE+m89+xdjcONkKW0zaYZwx
XQJuw8ljiiVBR9ZYXJH7Rt3r2Ryus/GeNUAM7LdPpqv2aNZKJEgCgmMVJCdlUjWIOjuFpSOPAAhZ
y7odl/eUITOMzBcqzo3M7cJCQAnn1ROov7/A8cfDU3HJXJt86TYsbPxJv2dbOr7HTD47wfrMQJuY
J33RitkW6puWOm54Y02BJf8sx9c0BZ+9pvYFQLg2lCO6ncISysx/ZXhbsyLGHi3CRLzWY8s6tbUX
CnfPlvfavaEeCo2n11uuf84FpqkSHNALwaGSJx57k5V5g2BLlUQK64FZpsF5dGFI1EtKO+kl2ivY
PaR1eTxpz6QX+V37hTTpOvc1goPWAFVN0ojQNg72JxNDv1rkDTok9NP/zgBHXVXHuZu/uEcBumYN
C6hYzQn4+hJL+xh47Rg5LTn7a79Uy4kyPJ6Inw0xz9kY0hpQy2/bw2f9wR/CPQW1ZNELvP6e6q8F
ofCZqGU/kY8RGHNJeO8P294DyBW58RBemNaHyecxPakeQfXACuMwZBIQTXIzcTC4KlWF5r6SJwmN
R2NrcRex7dIPLVyS3zDtdxgS+LO79Wvitcu7uKqsHBwH22SfdQnICF98AfASpAd9pGAi64WUm6tv
g5863n21aVzH1yq4lGjXhoTHxcKxsoFxpWjsPJ7G717Ta0brqyuODuOK6IMKWQ6IPqmzeO20bhNm
+mGGmAT7GJWueZrTkeM+p0GHOqe3yhP5C+AOrhsrYAM/071LafzE6sjhBswwfMu/2uHLDxWgok5q
VM/diPE6VYXwRBbZ+wbl0ZD8PtLJmkLD2rD7TcIcR9ukRuIYfCq/RYTqVDEHhaCFXPE/duBNnuOL
5EEK9qFQcR5UGB252Sz2cW5tD4An1x2mjIo78zPtHoVnegL9lcqVHfgFlc6AVeFzKEbPRiFgofWO
zV3K2ZVEsVqbQ++8Z2o18LiHHnEysDPtGXBFVGJDB82LUmFH8M/6k/o1sEOWJG8rpz7VZegVoYcU
0IMb15/jQKqNiTCksC6Cuky3X3UdJsx8bm/CN1re/KDVhBn9G6blnQVZZt9def7WHvSwvc8QCZzB
J4pglSgPsqr90oqWULIXCSD7aKlsiDlR1ouCusvNNP5N9dG2sXVKmg+4HVDK85IKK0oGNSccPXOP
5j68j+pI4bmhRjpxmXFF6k/vgDHCZnZFH/oBMM7eEDii2aYNMNZ1aFj7XpM9z2CMR+/uUgY48+aH
ZHSHMH4SXwFM7mQrP8Cz5G8GWL3/BmiV5ROYvw/6eIvnmp0JCK1aXMCKL9vt+SN6anI0iXY7mYlS
Zf5x8yCD0Dgu7UMjK15m3/LoFVoUqsqaC5CpC6NgGLWlFq2mOY5pNjcWFXIn17ZTcImSpa60BhU/
MN10MRTTE4maloibTRrD0qqiS5FOqL1NCep/anH/Y6dzI84rsV8tgfhHqegWrJqimOCI/g1rx3sh
7Tv/sPxjlgI9ceY2euNB7Mfiru/uCKJplHqvAvQDr8V/ZupdKa50ywjWL5NetT5+qQAIWwHNTbTN
jfVX3NN9pSR30wsDaJOrS9Ugq5cHFY8GyfDaNdj8kpiXq+mwZb3Ux/ui52PyBUrFMD5NcDOp2jaU
nf/0SLNW9vn4TOSFkVlDAZcGVUErO3zUmhNnwuXJDuGDKRx8/IDufnd956+YwzKeaXhipywxQ9hk
Koil2RKWDs/hJt+keKCppfhG0zDxVuAYnPIrC72ECDYeduMY5UQkk/p2zWEIu713czvQhq/KtAGg
5McKGg7SOBQAhcL92Di7pB4CGIGJyOztzCNEOqDe77JCDP0MysFYiZ5TElkxbRGlDqbDko4zQxTA
U5hLbdmaXjMr643BokZaPeuQaWmTD4eQH2o4pBQNcPXyAoqBFzg4bQvKuZNsEyyh3Ta3i15YlpVe
yNK2Jey0f+v8bhJeH3CKufZG5UJXgcD5JD0118HSRW0aa8a2rRo3wnOo9QlsnUFEhJ4EHaqIE5Y8
WiWfVetE+Yyso5laR+MKCpNsQepcW9W3AdeXeLv0sGK2BiM7eefOtwL8EGM5bG5KUoyk6HIVntel
lqA2QCbDa1D/e73d1rZABo0F+OnY8Pi3S5DYP+yJAl3ZR4Pb+x9JMk+zSZlkgPRLU8YrkQbvDCwr
BoE0/fgpMhRFnjnxMwrGz/PoWMGLNJkofb1TKHL9IJ/+KAxG5U7UzTCpIFXYZqdvv0fXGT5T7Q+5
pIYfJ0DNqF9fO8UK3/Mfj9TtiemhbdFgq10+gaBUXbjDdzWuqfg4mRMgsR3H93a+YwLDLYW+VuLy
5t7/pA0onsSBuv+2X7u30tKmCCs/g/zYmlej/NbCRiFgM/Umhus+sAJe+SwqN3U2ozW7wJiu9glI
pg5wRdmWtS0AlBxzHtjHl7uS0jH1NXfFTCeOiq/wTqUrAi/VdOHcBiQWT6uhFuO7b9I5TmDnDbPo
UY9/qanGF+idRb995bX/fLKr7xWffwtvbYPjROz2dov2MXrPnnuET7Bdvdh/ikBxlM6lbPZGuJam
+mtEIx+LUq7V45+AyWIevvp+3O6uCKz1iJDbpoPZff2CKnl4QCN93+B/h81MfcVx+Atn3kp2Vzls
XciYLvC/EXMtDuQdOhdduDiY5/kh2hdDfFX+CyT/3IA34zNczb4aPjXNrE1j//K8jdvLbRZA+wwG
859VAEN3vkJjZSXRD5hIgBHPX/DM4VWqiBFc2eUIyrjavf+r5hIvx1rPrrFP7laRsoszEnzdzCDv
p+pc9cWHd9sRyLYV/SOlAqSUHwttlz/byEwZetJng6n7zEo/ZdtkbLSbDZOqvnp/I/5Ph7gNeNYW
cVZH93+h8b0IutvJCdw9Q6+j/gl/rQGgdR249u0X3FAxz2qCzPOryxRA7JGRXStDi49wQPGvL3IM
l67lKt24raQyUCbRdqkmxY8iuYcNckXzvf8AFd3uBB4t+iDeZvz46+bfms63uJwHK6MTA5olXX90
cF8j1/DaiQuifA1G/zf/TeJNfkstf6b7tLSSbtTl4en5qwn7SUDya0PUDgU727ZrOWgZEvvivOor
WdX+ZGQ2kSCzEadPa5xEGKQ6m/ze2YpDj1dws6oRA9WYhY0Q7tsbEFLobI0K7EmQf9F9j0eTdQ8r
XaFO7589lFOVP+8Zbt3sVajifykrTLz1+Qi1ThoE+li2EAZVjGzMAhbL+veXurEig3URs7vn987f
JQnu9zgKm/kP4LnaQLoK5ACmmWV3IYqCQtfYK0ZxTlKvYnMRzf7nofGXfazzzX5LN8toMGN6+/ub
/3c6+PP1fSuhg8Q19QEYuoPgTRFhaSI0B5q07Ng3CO0YmFWq/qLevnpoPzvoiht5aog5Ao1kecQl
REW2qxvi1tbmvnEQomUNrG2QwCRL80m27ZFscQgywdvAM1B0Isy4EAkcb5INCqWBmSNZxstFyy9S
dTt2NHKeb3W9hWz9nE61egjuc2JdOphgP1AAaVy93uXPQmjb4S1d5ASzfRrqB8wla7UqlATQmqWn
WmemuMeX195JCbgFHttFXoK5K1wzt3+SS0FYo8Pt9Q03OtYHSk0jq3uGU0mk4gyh0SIIThJ1WA+H
H68JQS7ioA6Nfg2F0sV59hMykSRj6ieW5OVpfMmwvbG4TggfEVvo1hjMCjXqsPPvXBlR2AyWHggS
lreCIaB7rXKaD3OURI79S0NV52sB3P2tEX0p9YOgSE6N5v2QpuHypRNrcXzARWCjTrbgjnWYMZ+5
as9gI4hha/zo0dWSePUGvZ6tmQvGK90VklGLCx9aDZhn8Dd3ug/6uSkVcJg9GaQEokyPiWSUUhMW
/8h/IWXSnyllyMkRWRgq5UWNkT475Ql5S2DCm6KU08vmcGFDfi4wS3i+YZapQ6jarsI7q8ite5Lh
GS42DBKiRNabQbIyvquCeSgyyWobxuQ+Ka11RTJG5kKfd8bOR8KUcgv/alqxgDNFAI0CV93CMXcf
50EZtiXJPvIsaM5tyjhFkj0IhEJtje0o0o0Q3I0fvH1PZ0b7atHl4Fo85DeeX3HkgSbCWDRV46G/
T44hU7rNfguJ/J0E/k8HKtbYPCsDmDZpZgJzlZZJg5xTUfCH/jl91BMd7fjk3cmFXAG6OL3mP3qp
eVfz2NrDSzOPqT3XTB7KM1QbnoKg3GTlu312h4XCQzVBGEZ+rum9PsDvKZT5bNKKRXyrZ7ABZY0f
SAmDdxjDYk9IisVKYZeEKMZbx8ULNYcWA3UGA6DqS68mumUBvrtCavvk13w1LfMPCHLvvjzIuuYz
LQEDBBpRGpMHwoRAw72n3XnfZufovuv9hh31Wjesnf7z2zPXQOSbo1+Db7iPbS5LXlBjunhtGL9v
uc2k9q1xEhgplq9OM2mlFzib0szu7DIAUJvBAqhoy0Z/XAclgsF1UKDcJi+MHxpo9EYAKYBeK7Ip
O03W1iUgVBasWnTNIj8RAh6kKjXctqD6lttmGdHjyTMbKd2HwokyGJtl1ZIwsf6Ub7EKRl7EvDBu
LdSz4RuhHxz7E/BIvQn6qFtdob5burxqqsadlREttin8kdHP0sCYuEcPYUnM8ZjLnfqVott5QDGr
fBKa7ygdE1Sx9QXnhcjYHgBdHXdB57am+SDd5jYl3dwtFslKMBrseCswQ/lwl74M6thuERh1p+3q
qoSVg8WFO8qXZkkEkJ/YHbeG84CpesjZ6LRpWMUncUv+cn3QY2FjghyEL5xBsRzLj60Ebw4f2riL
0C2XUnCkkuSYLMAtDbsvpIwPGH14UCp5ctGipCZ4MKSoV2TPjdD7WQNYcZ9u1eBSNqhnMfLbd0VD
D5U2SU9i+zKmZg9l8yiMgQFYoenrtSD7GnpLUheMB5oJLuwezfk7YfEi0MmG3vgO2vwnsJZKksPn
yL/lZR7nrxni5tpXUWJPKJqI8d3dL2JdH49urQnUrYP5e/hHEb3AY6sGKjshvFJ4Rp8iNsuQ44o9
GzDt/eKPou67OKTSxItzuXK+bpGGmVfuBzCV7oK8KLXHTo9Isx0fxphd1RBD+4JwhIp7WxTaHcYl
md9bCOob7nu4Q1/Y/3LnywExyPOlbKoBGD9H6fnnI30a3CQOWbeC6vZQHUBv7cgh6Id3S2Snc8p5
OjXIw7kRrtoRxepk2gPAM4Ff5wbySPC8KOblHPteGRuvoiNEKIq375JO2/WHiIUBIcqbsvUxb7s/
nlJy9xklnIoLQJc0fKY8+trauIrivW5FuGbSTZ1eUxDYbBDip4/6NeO+XBHt1qOSCYf9LJ/qXFZA
Vz2GQs/iEuIpeJC9BDyzEaOjLGfFhJunUZc8LKCdPuGbclM/eCuDLDBylbcy/s6RGkUYYC7RxoJE
DwObU6AjEmhWYlTzE++dDJS1CEo995HkE26LJegIrqefsJXmeme1juYmbG0FoS7zMEIKj/OWQ0oy
qZtPrvcUZNdZwGh0nPHyQm7AK88Tv4u5AUXJ0CxaqddJvKnECY/R/UNR5jI+Ma3bfl22o7Io4EzH
AbNcznZLxHzoMU2TTasjfikaoPZ+2jcxCFXugSKQ9Z8Igea16ckhfEeWdR4KHrCCtU/1HOcmvsC4
BwiFt7bXlFxL+zzGfvz+ST0rn6mPq34nMV1KV6tRsv7P9flYaB0WSfLxn0xEYl6D4l7qJc0IYc3H
mHZ+sMXqnBBU1+qtuptm4bWsajFqdTOuS28X3I2ASOB/BdYxAelkUuKqB3ApszVM2ezCxG9FKKqf
cbk6X3tE+AWMcRavYPX7aNLqZ+Kd01cU1Uu6BQ4u0pZcpXGwascuGu0JN0aa/1CpGJsbVDm6yyPo
y7K0oNssrq64u7s0ourLupFvEtkcvvO63LLXJU/StRRoACT03fHOLcb6LO01O/ZRiIn6Kgh0sne5
YnXnVfsasiIeAzs1HpNmVgEbKlExWioa87uXv7KXBZ8EGIFX1H3UgTsb5OaNEraaQAAWmTvi+9Kt
RjBtWHVFNruD/tq3iZR2SVCNk/afEoAqNUKDZFEl4a/f1HocSmPQX0rSMKY6ZeJIV0R8NiYuD3UP
rMEB4bAz2VYm1APpH1xKvs7/aFpvdsmotB1Op7doO4j0jS++83hqCsJWg11yJnqMrekLClJ/2sQE
JYOosDPTv2c284UB8uQqVWlzbwxOREyHKbnGucIOCaA1OUvq/v/q8H45iAaRgbHByaX1i7DSJioD
CRG2mbkIrCThGr0bDCrYqyAlfKC0yocbvFn8EzbpFT02gHwRxmTocROhWc73TAuvTLK7GaOaexj+
viyqFxSOhRVmoSEjvw3k1u5SyneFs6bkCcrEYkevTGjvHqt7ttIzQBZCXdJB6oxDmCY0SdUizAiN
AR8BDZt031m8yvB4UnuFkjs5tBvYa8S6Bf+XW5Zwdcu/C4WF0RD0zyX0nDj4p9AhUK2yCR42cbM5
M4phMviQtAmlVyo0+mHsYsMkmkzdOb90tf/2QXDsOd/+1oGbUh7e+EI2soEP/rfIYXf34SHWbG56
7JCzBDCDvy3vvAPyUtmBr/L3hQp+tx9CghsFljFME2mpOQECMxSwjQkbr8X8h+JZijk5QVPB8ZrS
BR/UlDU4xSQiVP+/TX59iCDT6LdRBYDi4FCLgDyT8VcN/CZZuCkjrtPbQFQ1c+yhFVDe8BswKqFd
7bIFwXXzU/3/DKyTgnwaxK5W2ouo4zcKcxPMWgGC0qsncPrusPAhlExP7lSbGAl4ydHlWhuKdlJH
ER6fYkUudUrk7oMCSf85zM7jQ1Xke4WHve4QbKJBtEJd8VUi5fWJlFpe+N94l4y09Hw7vTPRynaC
RVPOuIBTlYx32uZivvy8P4ORkoUD6MUcBpKC65FBoeLG+DAC1/iuDVW8HYHsEsZd860sL8v/iO64
rw4cT6sUKBcqWpF5V9TJSKKAgzuedWCw1Ok0nD3UtEWhWTrnPQJPcy4PR+toO9R4bdzQT3PZ64xb
FiUhGNzOdnWsrpfBpRHo3Ai3b9g5WqqiOqOawN0dZ0O3Mdtd7SA0UbPUXAemPj2TmaBGuD1n+TYr
thbz5lo4uL/BNW27Za21Ain8c8p5648YLz66PyjgrIlM7r5slyP6eKOOpmYn+vT4lSXGpd+Tcgff
JZXTZnQicnzNFGtbbEtpRAwya6/qBDvFHAyf+yJOtrT6+r2r0GA5gNzeuhsDj4l9EJiZp5R8LMJl
kY9Fpbf4tr2oJNFoz/lJvBB6KvCVZ5a73bGxLbAofPc7VFTPfQBc/WyCi9F4/lRhJV4Pf1qYLzeI
o9Ac7AcjZ18RhZy3fsGNTv5Ky8mfW1CUjKocFP6MqfN413NN6E6w+ti3i93nBQoyMbCjenhfH4IA
kfhVmXQL9Kbm0TsnKFBe7CaEjh05nVd3O3tI+pVo3sTP7TGRQJvHGZU4VLEoCnJhnSHsyMe/In/n
5bww5BjtZdxMRUDwbXDx7A33dH28YUkqt8ypVEKtT0MNI3ui90tyR+6mD0v0535zluBakLRuTpy/
RSsnO03hKqBCOtNJyVHRkR+AVmULaY4fuBi0bkRYJqLn5pjAO0XMD2o5fKOf0CkqvmswmsOdCD4Y
OKk6fpTRMQtQk9YoFa3uKA1OKswje0g42ch5eOKwDJjtwN76MCgKg5SZE4nHUDtxKPjuoruB13I9
gJ1UMbsu51fDSXMGQMMm2VFyRi2pWdLvo3/IS6XUrLKBZ0AgaDKLIZN4l5jWM+qfvIBydJkNB3Mq
PYbcgPvdD6TO9IG+KJtvaPqZ8kbIa9JF1XxysHdb+w7MvqoxkTOXJNA3KxaltNcH8MnbZ877iXnB
B/1T4DZGYZSmov0Vuun/V7sbzi4VS68hJAxDC+XEQh0jByoJsP1JE2s2zlwHo3F1CdWZ7qGoySKx
jPp/LNUoRiUzEOwRlQdleF+elV1RTeBeh7jejv8J21YqCY7VHhuCapD/yhNaxE0pmOmJR/Hc9yOe
HLvfoCRhfxb0MqoY7gUBRm00weaYv6aTRNXb7N/aJDsZ7yqMkrUmqZvnnRtcYkfZHNsPGe+LkHTb
y+dxo+qdPvWJA1tCi3Ong5++PQJ/+LKoRZkkXrbck6Ttp0cHk3JLIwDqcdELYT0JFrhNbwwtCr4+
QnuOHlf063ZbCt5TRs/h2PgZANRZcIDaxWI4GIh1Nmje55ug8EQhjybC44kpSCrYW5iVo20fur9x
iWOUlClo1UJpvd+g4pugZBK4di9wx6onx7mmVv/7LoAg+UqXBKNd3NWDr9+705A5+FBBR3Wbpt5T
f8aexfG=