<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/jzbAyu3ss0nPC1Z5/l48Wn52PSqZLZJ/G9DkTamVgT/9VNgAw+fcLoBZCOpDwwQ0dezkB1
ZgrAuuY2/9Ny1DtzYhVjok4aqA6qcn00FnW6lS+m1ZPrXsqubteVX1Iycta9O8U1Gphj/2p38qUR
BpMwvZjxCoyHFlymGvfpxMO4dmuQ3FLSR+t7/aVsSCE/RpjpVv6uVjG3/y1Pk5eFLjUOVdE6rzOe
83wlNbQ+5tBo5I7Bxyk0S9dKRqIfdSg9GzbkvX+w5Id7ys/xh1blMYJasqLcQyE6FcVsEWTv/qdi
8pvJDew7duvb5CEkpdsOTgkWLdjW6t0h3UtgCuEmuFwep/DSKS6ePPbKeVWeirVH5fjky6mB0Wmq
jZ4oshRsIvPTGoq2iVAx4cf2mauqtvrMnhs87Z4DAqH9keMl+h/tFScAgs0/mm7g9B5MTt4brZX9
iHpvO3SVUTK9wycikXpE9xc6kiFo7bFZ9aF9mWKG05d8bbWtSBa58B8fQa96AhplvJTCbWQHUmUO
iwYF/R5EaQRVeId3cBD1n1E93R0X091F2jTZa+eiZ18m8x73+RVgR0MpuUERQuvPnSk/ZEsXPylf
GD4+9LUEc5NidNyzjaji9tzOWKj7lG/NNU3I+NHRqqMFXDXVSIOTsKQUBX2oY6hyv/2AECUpi2gV
yfHMOpzUuOPC1/xOe5+Fw1oylG7LnQv233xm8TZarzEgipWvGKywaeMVTqqMiIYPp7waZ4OtzFmn
1tI74bveDnthdqEyyFVv5FIRoICVcChrxwwXx0jkJlbWtjhrdxi7ZNtlxAHzlHYuLQz+qdNDChta
7owthOWT3SzAYrEmjPWdxn5JYneHFPDxdRKdoezEDFqdZqZkKnWwTYL+1O8ZqfHi/Ym9U7ue7kUv
7/lFRi8WJosnvSqJtNM1nh5SOYDQOH9ng7vDjxajaJFNpNmkJDhuRM/lXCE87YepS1BI99S7OAAw
xMkpepfslmLdQ33/Yan7Smx8MEjbklC5I4Xg0lPFGqGtNVD9yG3AYdPpd2hx7mMDbZhKNSjINC8f
uKeXEl6kllxAJVNGDOwIV9cjbPJnZkVWfAqS14Xhk7sdjDG6MwVDvcw1xrLJY6jAmS49oOPl3LBv
JWfmgCIaOIhliOvXZ3wx7szckLugQpIibTMDfytFnHQXGnCDYC0jeAOGwRWb8nx+vakojxAlNIdn
54YDeNtF+I4c9fBjrtz7JET2n2qGgRrLX3sL6CoObwtaQbo5Ajr8/L4NuDipTxaHJdvCXtO9DDUE
gqp0K+CRKsfj2yFHhVqnB9HOFbGcXEwWGiI20i3vf9ZNrOM2ziDE6lz18pr/lNnAQONNI4LJDicO
XnnasDfI4pxBy+BlOWvB1gKe4A1raCfK3VA7YqvqTHkNe6TWso+Kl6sAzLjqxKA6+pJqDQXvnDo3
Eh6dLqrwj4Vs+KSp7N7+tKOnEi/baus2q/ff125/FcA+TvRFXjqzRx5nQEJ7kWgTVJkgrazLh1VG
JMS+qC1h09YLC1dEE5Uh+K7pPVDLxDir21LpvhK/vAlG7zuakt2gDw4m1AAlQ7rUlaCPDcyhYG5H
TDHbPvsMJC6bY0qSx2q1F+V1tT9BCr+4P+EsSYVnIUmN+xzwoEI3ta2I4arNhgqEAsP06xZbgC8Z
ISIp1yHsAyVQklKO/u9TzcziGrtoGdFCT11HQOb9NUxGpBWSpwwT30TR6miLfkRWsXlO1VsB70q+
lhCCTkrPBdygS8iJc/1FKiuoS3UwHjMpvrib6bLjHj6PfupKa5eOyXqYRmtW6a9m3cP8ZT/EIpD/
ouQXGTChPi8479UrlKytBbBhRWOsfm0u4BSP2Fcp+dWYMtduZ0oVGM0hGWcBf5YUMVuhL6Vp1Q2g
eP3asHgtIWMNSBcozBIX5osSGN+MJSHX1xDvzkgZy1sCYuKSakYr3fYKWUKburngWfehdDgKojpr
IB2hH3N/Opf6PXz+XkzDEA8CR1zxjmfAVUupfJ1MHUrdFRGwJ6k/DJV/Rth24YtT6FOfQg13yML3
+Y41813mi/+uVmvGD0xH+WX3/KJSJHaFzlFCLrM4G0f6cpfAZ8jQ4cpr+NlwfA34BPRw/odS1S82
VuaLWTu1turEkGYTicvsSdX346dTW54zZhC6kLLK1ZOSe3U2tcskg6G+Hlf5mMgrpFOaektNWjjm
sWnbXlt4yyoLgxS0Z2j2+vp7DB9cTHy8TzvkjnqqjCqxG9KAS3qRRAOhszXUX4aMU11XmwEf1by9
9NapUjwBQsJE4Rv+IkvcnM2Py3+KU66qORdINr9pM3YtjyENAP7BMrgHqTe/SClUuQwoQHWl9pH8
fI+nJEjlPJW09uj1EVyZD1NRfRnCriftqVm0SviBFzfvyiHJ8gZ1XBSdp7qj0fc8CApx8VnpUl3K
0rkXEbME7DezfdbUIDympPQjpeIUCe4XdlMAbJ2zJYiayKa1VNBEUZtpbbor+zkI6CxMluRxMtZf
o2gjHlkKKv634tc+i7d/sETakZ2s/NbYYGKCUQvdjygs13/cELkTTXvhmUVNNBScmVS29kiQdTvV
kGqJmO8SIG63CKktQaDUz+yY8eV9qkctKhr+F/Rk7DcZccE9yIWuKQksX2Vvujr9saN6GSlIBr+O
0fXxPYouvvsOOmk9v0kVaB5xskZIx0h/6kP85ri3EWZfzj7LgYc3YaS7/xV+FHiiGpQpbrnsTJtQ
759G/M/1NoFMgxGJA5XGysDHffImdB1QRsfO/wcu7t4dApux5ciNSFQR3sERUAV6iSAsTujtvPRD
BuULxisTTkuh1WYuuQtQghj5EDWWVkSLqBdEHo0eBO1IGfMlnhaeHNiX80NOa3eokjNI2Icazhvq
0EQ71MJw0iBcmHDBgqlOBIN+gXFUh/FOflrE3/70oH9Q4PYpPf0BGjpmyRLnOL6fO8y6LikXa2UV
T0ni/FfUL2DeCOTkqk9cZ2jpTz0osYIsARi7taWkwz5vRYWCMtgVAX+zvowEA5GWrBMsjeLWwVkl
/umxwvFXdqha7NmAzLQvv1XXn1eSlTFoRAS0P7fnyEkIfPHbN4ySQQo8AatdAVRnAtwnCYnoXcMI
g/Hwy9oxvdrQWfBWIvq9kT0Qd3yi07uKp0t6yzBj1wEc0lylb1n9np+Awd4MnAOnXGOD4OB76ccU
D+Y/LgasVPSo3TnY2RzXrr6orMbYN8mvT+Pzvj7iKBYAeQ3fBzWdBcH4ABZrVtDAjtFtK4rrPWIK
D3I+aR/tjsoKiz0cJvkW/iqHX/tei9sA5xJNop2MWsr2LAsFZ6CoJ/53O4k54mo7dWvgkPSVwiAT
iHKjDfTrNJg6+Ps5VuLSTOOvrUQcV10CVQOHa8KxW9cpmUl9WCHQ0sNMZSy90YaUHxE0VxdMVydR
E+zh0uZZolCVMG8/Aa1pFfD+GFeXJJNT6l6+sdDWFbZffMQCaDuo/lWUd0KP/vdlWs9Mk+Ptz/fX
zLmzwxplw1q0V/CaqGsioyph+NcUkXMkeRxvb/vkMS8dwjlqbUtIK3Lb6a5tB5H53CAd3dSxXeF6
DafD8YprVC9Zti3hpc3MxUoYqOhk9/cG9jMgj/0XhYWdw6SAIXXtgdufO0tjskeUD8tKWQCT5QOr
NeUD0qjBGYQMa5IUkTpyNnTpn+BG/zQl3A9ZejLwFin8+Bn6ybDWaBZYxcccwxjgHhU6fi1dEosa
JWjLLIh517FUpg+C8NwiCgVs3IKdqTSZStA5l/saMaivv0RLtx7EegiGTzvqFyZDB9gagj8vohYY
EnIKYAc5IKKfsJsEYDr6+YRKPgd7wbJUwsPGaINhUUuM5zoFhCFllezPKjKplHEctQQdQA2fFYZ9
JyZyGd6W0T0pHr7SN2E/vAj2XH6cYAAfnAQ3kNcBSaxTHnyQHTZwWurQjcGoIFafVrRkQidrJPUY
hr8YlUoc7nzCq2qOzeLU0kpvK8L7QW6V96305wrRBfjO+vuqRbhCPMpNn+uEjqWUmiSgjcCpDH89
drAQmgtSjdx4QGKn8Bt7XI+2P623IbQ6qihq/NU2xiKaXoaGKxgpZQE+T2t4X0TxLgD67WXKYcb4
rq3D+jWQCibQqn6ETjUGwQDhQstpBqyAVZ9xqEZYhsjAI4sZzCAt7d9Fc0jWSJgIW/R5YWdd76Z2
8mwk/35uYhALhm69Jp6wCDkLlcCG6LBxeQgYaFaXCKEsv7FQs0Ka7+BbBXseNNQg/wrDYIBV6vOd
Qt84SfJMv4c4bcFTUUQbU1sH+OI1GoaoUEsRAwtu8TGz691bkrh9H+GE6HqozVM4e5E7Is3eKVaz
2lQYs8ZxsidtWdOG8ovCMNIMiVI1oWRWhTYU352aco+i3MhPmaIs+2wRFzgsCUL1eUlZ5cOx83Sw
YII95VLZ4UrfxOc4Fa7CLfaUUTuLcPTlzhy976TTGXqKZgqnpDhqCpCbcm7jriPTjqFM2i6KhvhO
KiFGw8AbGY1XU0ykWHBSz3Q9s0ZZAYQLE+IeEjPThlEVlNjw1NRsZOAqIC3kC2HJYuaK+O0+Ew9L
Js7FFveOaGAAld1pgFoX32i8u+ZHozK4hydoV7jHgXqgdvchR3OwhZY1EtJSk0zL3CVRpLaZMrGT
mCXXsW++UkSMawZ4P299oRHgIJWOy+LvEYVV7KqohTZqw1iRk64dKrRtC++By/hLFmlAALs05YPB
HNVxTI/y07+d86p2DoNzabUKBRqZh7xV0DlzzYberCSvgx6EPe3rETMCQiA8WrgSeoLvpg2UB+1g
xecNHEretaGf/nefH1oK3yEZVvIxJ9KQ3YMcEWN29cln/Ux8kQC24v/bywG0YKHF8UFFC9Se4O/o
3E33nvX1D0WUO+jN3XXjD2p5XvKNmZWebcdpxzUPdvpbqItcDb1SOxijbGl2VGazY4NcW7lpuONH
xFREcsnTdjyVe2DI++OBGK0N80GMOIWjmtzJlEhk2JyT8NNyvATlVs1AsNbfQamWcJywvECiDdrO
0WYaBZlQ2ew7oi0FGXP1vNModFd0sF5oaFDFJj4DxyhguzUkh3AlAtCl06m5MuGfaZrif9cyHhyA
+nILUX7sRCV9NF0m4BqOteS/A8Gsw2nmTyrRnn6ydsUsfxK8OcR/5Y5wDk4+B9dEb7omHsaAZYWQ
hDrMZlPmMl/XvkTvseExI3XLszLzpINBR0IEemLBCgLTKS9riuCW48lYnYMZ06+6gAo70xvWe7uz
Ki6yts/ZHbbEotYuFhWCEIO2oOEwkxOMNlGo7J0bcq3SnYnw2O9k0/HoJTo+ql9uBrqjpRa4E87A
858BfKK1ya8EPP3orCm6uVA24nA2fJBhbLkGM0uQk94jQ6pA/MgotEBkscB5W+Oi0MGLJRiWCRpR
j0FuuezhYS4d3DjVeaVZRqHVEsRaDgPMAIndDabT4svowci9DLhGe4QU4dep03dwdXwkUkg2qZZ1
v6xogXInfq9YIYgQtbgeXKqZ6od7LATILFlkK8y3MqTVcoSHueA+rAchfNfaAybwc0WFUCQAEHp2
9ELHRYFahM7w14CIdx6PJg+xvZ0oL8ClXEUWOLPsjX0ntXOrvyKYqxvDqszavUwftRtXPr1GtNJt
Z9bErABdaSiSKuC+xFWbVSZEI6dqtLa8RwYmYttGbXydGgh9WGL/omm6U+A88UrQHFyXUguO3yfG
aDnLFTClLjXQmx12vR9jwoZN39+pWGLifCqTVh1TiRigwi7HdDPytsmDV4LCONXQzY/NobYGG2Xl
RGmMWgcMNGVLyvffUh4dDIHr19R0afsSxnO4Q9VeX9RLLmppS5VvIm99LC/yuZukItXtZ+m59Gbz
C/tEMfiOJU09unhRxz9QeJ6mJtKGlsPxMQHkiHTPAUNWRRK3tsEUdbn0dpz0n1ZEbZ/2ouqj60ia
gIgITTwA6G7I/OvoMhF28glp3TgYOZv6xhqXE0R5axttbuT9fckDavs68fka91fRpfcH64NNO4sW
rBj8uaAi6i7SOeQmMn4d2nyUAuKKr+CL2aQXk8SLoX4uP9QYnYwSX5xnPSaZwSlix507MmEl1tJ7
j1Mn2n/TLRxgkqn2Vtxnc4YdlqgPOjjYOFAR80116iQQ8tH0x5wgan209aXPs88rZI7SMXKDC7j9
IrBqNy6qz4kf6FPl7hxEaB9j0hTGWth/wWdItrJZpQA5hNit2pShkoGa3sgKh6steGoodUEEfpyt
WYDh0QZ+ihkPtNoMyS7MJnQf1UXLM7XgsbvTIUqEsYqlMzbG5u7HHuNb6sbKMBht0g1D4DUzk6C+
L/qV8fB6jiiNLu6jn0X5dg+PgN+4owyhLjkMxE/e4l2E3FMZJxw2ypgZ0FzLc5x5T/4RBcwKUGM/
rxNd9ZbLcnsvkC/WmipqVkGGWnDkhYln8xNfVdOmcbTfdFowoXjCUSWZVRohuzvFMT38fG9sdvUA
P00TnnBeWMQqVAssHNe/6GfCdBsajqJs8KBtdn3pbBCEj1BFc2qUC4mgBgGWSCN3tDg/0/zaxQFw
QCfRn/Z9hc/aC/BPmrQb8IyOnfp3HbFAJst+3e6WCG9khCFTEjcuWESfN410B2KTJ9xAyr8M8keP
9EeYiyafNt62BgURHjrqXkkeKDOFhWZrGjXzuOgsMygh0uPvqHrYjim5AQK8KLoW7fkyC0MjD5kF
IJGUTxvC0JYXyLOo/A1OFSjZJv63CqyHD087UQn33igpXoCYNMRHgwirkGnFQApYh23aaBd6wiE4
uJsIvVWFcpeDFuhBIH8XVWzEskVYuhjrdWI8s/+VeFghEELp/Lyraw5AufmpidGVujOJ0iwAvnQS
yOclXoO5zZqD78PNC7aOhF57qteN0SG7/xdTdqV/tISqJ1dT85qWScjqSMZPa9ZyFLf6HikNFtMf
u6V3J1VVbe1sf2MpyyfIVLXqh8S5h4Q2if8EpfGkydVi4aysI0KsycE378UhIyrAUzQbcxnbAXZN
4WQK+8Q1vR4YgZBS2oD1UCwKqqd6Vd92EK2aUWKGnYPPngQkOQ1d1Y54vyzz9p/HINM7UOoW/qXE
TcpGiDRCXuIfR6IpOlpt74y/MgEpBsDyY/CR+VPx/698wz5Qz1qqOamtIy5i5Y1ZqYTTTHLCWTWP
kb4qAtqSqniLogkEyiOdTf4ds6i6u8PXStEL9JEROywb71MKdpAECK037ZuJ73CV9924XMh+ro2Q
F/QVg5grL/bKr1FH2/+4rUBaJXZwg+V8OLs+dG0ktmItW3G/CTuUclejRyozLKej0kkg7+WpyfEX
+9ILwHM1fxA1SVaJxBTkTIo4DdNFHDugvHRmEEXr7njSCAWP/zCwS24kvFBwdyC+nwkZt0OXG8zY
A97xqKKVqlmOmO3FzUBx49N3ZAp14TCXknq/182Y6NV5xBS2Y1XeO1gzhTcT/rAlcWRe0+x9Wm/d
7SlY0ICnH7vJ9do9jpZ9GZZxaFv2Z40xGiw3bEvjObJ+C0n+5Y5dcJXaauxCohCg/kmU++9sLxE4
Ar/aW0n7CNLoVhhhZSNh/APvl5ImdlcAdt1n3I1HBM+zxldynx6Co7ctkC5GjbDwFZdbH4kDTB74
taBdJvuT8NymEmmsl731w6BlUTvNW45pXQMcEHSbLVoFrqmx1fD6XalpFbAmdXv+RlrzT+MGRgjb
1ehRnxhpcUNTM36n5hLWXn4AZZT0QTDsMd2GrpsDD0BNq00zmWSou7P/syum6KA+Q509U5uhe1Cm
feCBqpLS8BjWEiKne+lOd3dMiDMaTXLwz6AkfWK0bOW+8UYAMEbM8Dzsz9aVXEEzzOT1nHIq9FEY
ai6mKQ+G41KQAMNrMQOUc4qE57U5fakvm7UieawfWgt66H2ww94847EUA0Qy5qnRCPixryamS34p
2yUowytuwJyKGClk/7hs3/Bd/MX4yR1dcpedL2vdtC+vJOGljomuf7q/t9zPT9SPecBhbxOOsxZW
3YOuemoZPrfn0Su+GChBuTa8zhTCMvEguUS9GQ49CeMsB67Wwj0qt5vgBHZOEjFGxepy4Z7EZhfi
yKK8pv8hRBDo98Ktifmh/Vy083sZiTsNywLmI5NW0L0fNytu+E+H3gFR3txXI2qfikS0IwVxTGvL
cAVSN38qfUGYvTkXWFpdL97GiASctOEkoDiPKoZ6Ys9OB+LC8/TIoGGzvEuXg/pDrpumCne9A1CZ
UkL9ym86Qw/n1wAhjgOPzbkmQ3kVLTxecFmS1u5XXr6VUzSG/qyaGf24/4yHGZRnl651bAkBoLrR
nuOs0MGXI1ZHLgzusZtPCI3DFXd8cGJFlnQHM1FsyvsvIp5uczUFpWYcJ1LmKpsauTUi6ySNjb+7
y9iNc1uP3N2l0E4YqCG0xFuZRyEG4aDPX21hkYXx/T3dgBSF4mB7dPknYAf9/oZbpy2o/LTrtHTE
JtRBAm5z8+GlVIG912SV6AT5YNZ+ac/5dDT8M4qaWQlM74shA3LoEmwS8WsleFhbAjU8MaFyxJ8E
22lPRwi8nyxFgKJjTm+AaBkbLyGQt/z2HO1yGvFsLSFumG6eZ4JHpICwYL4gEp5HCR5jc6QDTEJq
KFhQKMj4AZuPHmB1h2uHro5qUMWGoWzu9neEQxC3nCAzxRTB6Mr3