<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvIsJExa9BN1yMhPpQx23sEGEH/7T9U83wMuecFPpYuTqWUtJcaMyO7vbNmeyRO1vLhVEmdq
MTO4UPDP/FngizVukDWEXJqTlEWY4wtAJLOGgYMTeTUHDQzkFYeUMwadjiv1AM1w6m2D9qusER+Z
G2kVUL4OnQ8svY8H9JRJj3rxLoMt3e1nwsH8m+iP/BHekLeQtFY7WC3Hn00/oCtxT89xPrL76ckr
8Wv2brnDkAS5nBkmuXiY8RnuIWpWX8XNi6ktGv2yD9MuVnh1EjhBxNnaxAXdX6fY/qNGd/O7DOgs
UxiK/nreLy/fz+r1SxJJ6jKbu3MBRXC2KRA4fwyJ2krx3Bg9D4boIyyAERWvlIQiWdo3sR6w0otU
CaoHLS0ATHXfsrGGU/Lpm4U9jBnfp1V6w64Q8/I0X/ZfKL0aYFG+9gM/TDV0tSlowCEXYd736klD
26lRtAuWU+HU86zjXBm1FVT51cKwWXoItLto3TBmbEkeryo6byHxtXjAu0bzhqJII0YY9fKGXQKs
y0beTDbFwy8jBAJeijCYXGZbplu809Sb4yHw9bqMojI87M3bl5LZVEiSBfegfWvlQkKd3JU3+bFp
N6EAw/KCpAQL5fawQkIKpom0xcCqf7MtoaFBNlimo73/Vow3jBjBLGyjRQjO60yIK6fCeV5Wp8zA
zwCNEYrKg51LGye7QbrQoIMMiTVNdEB++qSgcecsmGdqy5J4HAtLi6+Ti8L6DLuCL/v7+041aZK/
tR600klcILPDyE5JiG8c44S+vIXZoSD2i8KxxXucjzntumC7BY7/qxRjKIf0A2Vtkln//la5WW2X
4XmZStJzE1cTvU3+hTNA+ihJuPsqG2bePW8vUyHTjyrQaNzdwHGDy5gXZfN2DXi0Z/yUE7pqGbZB
om35bAW2h/JhQ0IVI04OG/O2HJYFxmpCLAEQ/1VOlyeclTIDBCgKBe58zwO7t2XOQwXhW/MsLNpe
Msvf6/z/lRoZPVLtCbBW8WZtSJcVR8VIuCNDn5UZvsc7GFuHOEleye0TBqjIy+cjxPzYQgzM/FSo
7Uqo5JroguRGHFS2+Ys4RULot1zuw6NDRjH2GytkomxUi3KcHDRB2vdzhpAMYQpopozFMU+rcWmO
Y9yW6Bee4sC5atsGMEOMM2yXuXhgv6y828oF9DSx0YpDQHnLeNkiOUWdf2V3YKQeBh363keIjhh4
ZSvB0LA9bN9DlNtxt+w8wVAHZGA90gagj7t8EFC6JogVLMPoU9iq9A6t16fPq0r32fK7tETEukkW
RLB9hHiIRbrshkA+qiSj8bi7WSZIpdUKlb3K5Oiu74r21OPe5759Whvd+Olu0LMeYJZSRmtwMwds
9EHafXgmAnV/mxJvGonyh0dasoOODgNva5OvtsON3DsUlALJb2+G6wXiAB3Xa/PgcMwNubaOlomg
8zDgmbCaLmfAv7cJvElT93dE70qPQZLuQTbl0IK7fuy6pFLTLZ73Rzh+nSWg/CTbMxUzpMG0NMn9
Kbu5CipmdShsdSFLqwLvvSq22DmitTI8rw7tFi9dOE2qilaQ22+7koErFiMWbf6U8n/RCSIow7y4
iSmWl8WQkpXiktqFnd8eyau1LA9KbIhzFd+kDGxYI8ZBslh00BsWePpGWJ/XUQteRYOu8h15FwF2
8QguD4DRqL//6KoZ5KcObTu+HW7cuBFWSZDLosULnXt7fsSWrFO2dxCL/bMRmJjCcEtSkC6fQmqz
3e7R0rQad4mH8QfE4Tbl1u9jfkoKtxexdH+rsQosaa93PBa3K5S9j1hTveocX8H5VHiEzsY+dj9w
U9XOddR7usFSr2e87U7+qEo88oHfW+/vqKnbf09RpBzW2caH4mM4vggIUJW5JM6LvAhvL4IxO4oH
UQR8YGpKJ905p2A2/4VIPAQ656xoM7WGw0Y/k8YiZf2k5AP9lKi0swC9TtlEdCosOZ+zbXk/mvai
LwPdRo1ObzuHVHXuqlNmlIkCz61VvTICFbEoLetMgz8o/4U25r/hAqBHFa02p9tTN9wy3l7KIgrq
6HpbSlT1A/nx+pi1O/8eZnfcAALec19muzlj3DHMgsvetqKS3dPtHXRZ8u6k5+WnyRuRy0H7gFR0
VruGdg7kr6/sH5xjCAqdL5NDVfV7C9+nz2f8MbLOcCzP6UY8qrnWqcGWhpzDgyBUP+WdA1Za0aIB
THrjecqYUVG4jl+hO+DgjPxu1crtrLmSP7UrGQ0ME7dADILXSxn0O/fXLbLIkWwntU9/tpysYWOo
CAQI3End+JQH/mVSeGYYch/awb0PjJqn4P1I7p2cjudsxUdybREX7ZQ01O+DDPVOUshNv42koLYr
mDmsic8eVer3nVuiCkh2Q0/rSJsglzWsdZX1erzxnsVkGRkMl21EHO1q6Xc+w1FjwUD7M66vUuFV
QS7o793Rf54YPoq=