<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnz3nxjnypky39zIc5S/zwHbf7+kP8ZdQEWhyK96+/M0mTfcB2Sf/rz+jbtXQK5IlAW4crKP
8r1LZrhV6zOA9IxuQVIGtjKzs7dIUq8aQOU7ViRG6pBVCuSM+pGeZSQSR7xzLcqSXcDObSTJz8mR
+KJ/sfnxcIQQeXhLdP94uem+B40g4wrEOHpOEZrWgHl9RFT7pPoP/VaN3DqRk4OLIInzFGK+HdMz
eM9Rqf6vR2j1Q4ExpLLiVFBOCdKzWFaLTRs7fUBSGeAicLBv2dluRzNiE99Mcccb1n9CUhW5bVWl
MuX5FHB/KlPhwsEwuYz8r5Tv7hZsp8VDbrfI/DhSoTh3Szf8+2Jc8OxAuKya2pLfX/YW+NAoOKmh
hhXEwdQGBQJR33Rrg/fz9YIWBhLWyIc2y/Frfe9ccwQJdQpxNBCqmBZkhzMDkNxP6GYNGGDRGu8S
Fpug4ILR/Z92fxF33Af2rJ5phIVUdGZUrnJHUMf8s4jqWX+N2S4BJWj5wl+Zkof4ZOP09VxC+lTF
C8dV3fnrSNo6W4R22+VssdfGIdfq2ADsWGLi+its8ZhNxcS0Ba4cXJLTCKDGmNo/gdGLUaG40yIU
BcdFCj+CEAhv7JEfo9DLFi0xd3GXrUwEbLKntwdX4Htu8SZHHeXKayG/SkFSCdZdtmpwX2x3bEPg
oXv7I3XvoXM7uUQv8D2uNFLD/LpKVYpJG3U0SvatzaYetRXjpEYMIUOkfU+RddpTwWA1wcbNVvp7
NIbHS+w/6jvKI4LHwdZ5vQrutaXQLrGhiR1vOPnYh5jRC94m0zys/UV5sTVrU/6y/u2Irw+dphLP
KLP1K/StwUX8d4lk4i0UefTQaKier/6BqrjYGjqJ7YtTlAWdt1WeJRY0JNHbWoIXlgKKZff4zbTz
8a94X0FUhu7KOJQnvwKafeFGBMqGo3W8QSS9zOIisMLCBnD8d3ShrL0rHGE6af5EV4q0G+VWEUU1
c/aRt35TwbbkmNLFhiI7hw4gqtMmCz5TojHipo1O58V0ORURuWj22QD6aUIbam+Rxx1L5zBK3GE7
FmTPz1203Nmigng8FeMk++pYQI+/Mbk1z94cYserAwc6bkTjInutbQPSOr0b0M7jKEa3J2N+88d1
y0q/zfq2bCVoTE1z/leXG6gQHSCouFz3cza1GFtSa+KiNpz0jEBGnYX0tCM33Bv/Nf74zf1S1KBa
mWLIrobGt3lvJWXrR6tQ+yd8Eb3hs1YwE3PJIxZplmQEvN0z9PBUvRVUM7Tn4BhFSBKb0jSuU+9O
hdPvNrnlV5GMzw2aT2XOAUpABX2XUWSQ8xilq+SeJxrpKEK7vT66xYB/CRI2ZQik8k4qduSXPi6o
GhN9Qy2S5Id7ANjm5ITSRJtSPLUy9pyUbes2Psv45qYwHXdJ1AOFYVt8Vur/nZ0f2B0Peoy9NCN+
SNbdVCYT6frApyJwYVBY+Kxo4VkxuV27TXkWRbXvz00cRAyvdCVwx1lqhMTFOIDgHL5muy4VEHLX
A66TXSc65Lu7AbV2dVRwWZI+jWEudeaJwy/VjMzJ4DB72+5PHb0p/oAdywbVPBMxtEz/3tz8EI3v
dUkSc22lXFR4yMQ74NCYki/OrxIXlY36zSdmjbba+4V4uz0fCOwzsac0af7wNDs2+SVmMjrJh3O/
9gOda3yZRWog0qbXIwxTlMecKu1PeAWaKVeG8OPtgrYysX98D9wZecgkfByvmgyILgD2WyebOSar
qmvrSXVuiNJLcO5HWV/Av1edBKz1D8yTL8gSmnwAhE8hBVPFmUicirrVg7W/sFxQHix+EhwpYTXJ
Hb5GbRdQNFWsn/T+wfbRN7Jt0hDXvZEd5YakBxaYB6ZlS1rehRoj20n0b4knn2rfCFygeJaVa8Co
l9kPWoHbY3sOUNezKD3n8MkBLbTGOEbWtRGJogwbyUwGqmK94bLTSgX0Cyoi4r0jS5ptLMSDmlZj
G6zEUmtwVbOPScXXzJPg1+/yVE4EavfQgooM4FZp2aWHPyV/g+oZmMzDMQitSuYYVCe+IXdnWOkt
25Emm5ctrHI+OnU1kvqW9AZBtEBoMh8/CmjbRR2o6xlWTxJqpZa2dkHlKkCFzBtCG1Sbz8JpNWmJ
pvCAdvb/DYJMT96I62U7Gf5NK5xOjIymoVbVrYPxQkOZRy4kQV6evyMJXZBLKRcNPp9Pu46HQhvL
PPDdG2rt1lnjBI1g4SkwxUvAsMeehuU+puQ9FPJq1J0LkZfVyPBm3ZvWuKBOix7FokaBt5amcJcO
xUJ8rCH3UAvyGTr774HiNj7ZML71nBM1SgcIqdmnbR4HKIOMZHA77q7sSU/LfHYlm/i9Drc4nadU
p73Il0JgkMDcAGHxkqaDtpgOvQvfapavSwVW630aXdxDPITibGQ2Cjrz/IdcAvI3PDCNDWrhi1RX
8EUvrzqL62Ix6yko9hOe/ynnSiSWNt8ahleipi0=