<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwVsFI3GP8ONhIge0mR4V5WD4/f/qTnWclzc43JhRBgbOlyWWbzwh0HtGSHMYdaJh5I2R9G1
kge/l8k9xyM/DfI8W9LvPboiHjsIGu3ogD2kogVw5/UyQa1XmEL15OCUGz/SHcmjO/edndWBVDWW
ahkAjjFgCKHi09ECsihw/KTAg57qyKhUW8nB83bbSVvQh5p5mBtz17ofpvhDUM7k4tQpohmGmsWN
u5n+KMaJV8Py5EIduLJ66X39rcpH3yYhkVKWk7OKAnTu21puFx0CpmxcZijGR1+jaNLZpVB1YHRy
uT5A005nW5XA/Gigk3l20WFIRf8M68ADjFf7YYZ5ORQywjKoVkGFHGooZ4r3LRLLxi/g004OYWgP
guhWxuM05bPE5b5b4PoyfIbJCAzFxU7YH6Nt8umSlxfMaQMFisUb3FJJfXXRftioFkSxXpiPmxQP
KHS4mWdC3pj1bjEL/EX1CHDO5KkcEO5KMxlNGZwTNOcSfpWPLikmNhgKI0kx0kdekGylrUkpPftE
f9NU4ahNmow0Q4rZUcjU7qVob+NPa1pKRFOWgc5BHZMO/koJAFQ/rr4OurPgEHjtxAptwfg05WCe
OiNoOeuPk4Dgw4hcySb28hU81/QVaIZFEVN4qvPEZ1j1Yfn7cvrCi+0zNcih3f1iCi7TVUx8TkLO
nVUK3YA2Py8pZ8Jh/yhSuYCQK2S5kLY+d/dtYhaN8RAhJV9ZdrEPLZeupyVIBu2I26JOWaHPXqQL
YKWs4MYnvPVnBAhbHzGeUha7puzXH7XfKE0GS8UFVJvptu5AI02NpoSMohi8o/dAHdFMSd9fevck
tpIDB0DuvrPKyWeTJAZrMMy0rwCHXx8dOrrERkfyT04nGxdNBD5Of4r9VggioDiTBXVdZj3WttAB
f/8vR0Wb7s3DsN/W7lY21VPSzjtuY6UueTcqZ0OLBfjXLqo2gU2YqTtvUn5DNezMi3WvXAJTnPh7
Awda3gqs2/29LYzIQhbxyO9DDoHSxEvJzuwwb4kypsH3Ds6R4LFXVTCpMW9a/qRZ3vuuHnStEe80
IoDbuINrdVztPdhLsBKQYzwoVDk2pivP4f76qPAKjP9DYCBQCe+lGmp+OylWDXkSJFkx3i+3mpwV
WKgTd2Et4sBzIsoNKeyEW5OIqRLdicNVENrcxJDsNPVKoofxvhR+EblLD5GOrtBStxwY2djw8Nx8
ddx7cdyS5SCFK5F6Kf6f54NDwaCZ/RPCOwA9njpMJGkko48fw3ZKOtpcblFSldDkiL4PjohGwyLh
rJxsGcgHJbbOHeup7frf7d1jgP+iOykxyyYmT6ZDRWYPTbCMC0wQaCAYQLk1KVzVQL+Dm4JSJvXA
xr/6xBNL1SHV6/7brvbOFSY+NStNCxwYAdOYHnn7WzUPuQhwt0CDLefBIGcRoenjk19hzyGFKAXE
SRrZKGngnfzgFdDoDmFkpohtYYwek13DmeXWNBQQa3PGNfEZFJ6mlpEHfNWXvcE7GlhEgdCcwTJx
Tj+qp3MNq9AvrWZdopbT9XT+flCZWC5V1d127zyUYp5Sxt0U7YFGmmz0ozvNg9SGD8kVHUQQtbtA
ASeCpJ3rzOs3QHi4O0Eu0sliZwtrvbUUrF3OziXIpH0de/Sx+KuXQB9Iwz2ba1rKByPqlTu+Sdrh
HVt1gKfsO2EzzT5KQzjGOczEFonbJLAvS/P7f3BJtbihtyOezg3dfVQwY+Ppl8mwzUvuD+4+iIhg
9b0MVG3g0hCOQtkQuD3ewdd4tfpnOUpKtewJIhysy2tieQ57cTYyqV+JSKzj695c8ma88bXYaJ/h
rb0e8SUP/rJcIsmOYYOanqpF18EyYqRxYcYoH5vWcY/hfSyZtmCuYIkmcxNdB9ao70U3MURNFtIM
0/0Y+nnaLVPRNAk2GH0exvqNWoMF+BajlgOA9RXxJL/f2hUAqE84vKlu7YWt6J6Xi5YB6CB93Pzk
srpZHcy/cwAGjrKZf42W3Tf0CyVNCbC0bYC2wHHpWl9tBNKA7rmhhEhuAT9fWTb3GK7/sMcv+bDU
hbLabU3mVDFDDBSFSvgScs6Fko3xYK5d32J5Cd0hxjsebWasn0hf/vfhouZM8sT14L2ajWHHiHDq
YejERNftFcd8NWz8l57RNdEL8KuC6sHHUJkOTRvg/yhwfY1sWg65XYAeAQVlfvx+NJxUwKnsleLq
XikbeqftbKN2UleYTwh0GxEB8rfr/0yg0OYnEgf1+UT0nKCKbUWkz15O92y/DwKiNotqCiSvas2g
BwCenkQMb/As5I/dNYL9vZ4WwClgyK+9Udqhs4Kazcrpkh6o49hZDAUZHYAMkoUhnAx6li8GQviz
re34ImeIvH7PJhVCkba/MwK3sBeRLq6ipa/2tIVaRoIoLxsZi72quMfBLF96cvlxwgaqrc2wnGf9
22VzmTFMD7auknfVQtFtL+ESNmigLp1BM9p4v1RJmA6pBijg