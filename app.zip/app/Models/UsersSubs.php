<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsXXRo6Qq5CNOxtw0gwxehvbzJ/Cj7+4EFeDCjb3unG8YMw5Mw8/A82gpAQrLqgLJShGHoJD
iCzs3xjGRID+62yd3p/k65Krcoh9b+eANSOM1Nvst83ZgnTyXSS0A7Fz4Y9iZcj7B3/Etx4DxKje
2uoxiVVxe+rDVuVOkF3o1y7xEd1u/fA8d5JxIgLqVzer/RJU5bQQvNJtbe6zrAqmkMFwxiRkRrSs
krbk5Tuk3gH2Zfk44HzWzd48474SZxyZyK3+hn+MgeT25D+EjpKkAQLjijMnQKqHHeU9bFAS38hk
3gZeR/yv6zH7KpyoTBjYqwawd1VpuFEKAr0H2PXWYc0svuXC8njfVB2UBo6a4Rk8tnDS/HgaOfkZ
Jtb5WnvcOVFv6jyNji8diNJXAWgbP/3s614zFv2yQp4LNZzzA0j7LJaicHPixM82g+fN+bAQVwsA
dl22fG7huUM3g1JrYhnze1gzq/fG1squhqB4DvHupXsoWzeohvoF9eCFFdOPu9elYJJduUjVuOLy
0ysdnULnucuvLz4iFM6jc1KV0MB7Q1mcVMXf0GIWbuo4hxRj3O4RTKs1gqX0yuHrd6fz9HhsYIKH
46c/pEmsfeRlZJ/sl1o444P3jgOBQr/INmbmzo0B44W7AGasV7OdjOEpWVd7wVfuGUM78Iu0gDlQ
N2j9qlSUBCXwdCVmrMRAmvqRXmj+rSjBAsSa7O6+3wWHVck2YsrAB5tqdZV4ROtUT/NugeM8S93T
Y8ZMeSwr1FranKn91ietxu0XOjPKQIcRkgfdhu1pfYmOjF6XkomCGiP0wR4C+bze+Tv3MmnyGSod
KGeLTOXgaESlIwwtr9sSRD2CjS3CYTn8FaPUSr2l55aEeP7oZ9eI6E53vBcdwhabTQcGP0CU4eD2
xbjezF4QpdQ/T4oG3HISRUk979mWlXbS/GkbZ1cGYMDywVGeVoaZwCgNTXd2TsBaMRiWG1UV1/VM
omPz+rq2yc+FOe6TY+pEUgZaXNrnUeai3ocYJoo40Xm7yTZBXoQFUcZCSgloCxgBRtigE6LDy60P
fmlIRgJm14KUPn9yWSWd53JA5b975CE/bUFSyqbjNYsUh7owJlot60eTGUE14z9zAxTANMHCmrm4
TQREmXAc0DRfrnxodeRBix3bLYzNV8PBoAoTkxZpjjP7pY8V9LEF7q1lYG2NDkY1f+Az27kKxLD4
a6bubRpDul0uw9XYDrdMU1cI8FcJUC3sxt4wMAavuKRKzAMH17Q7QsGCslcEe1bupVJwLiTWnr3P
GdpbeqeeT518evTAKxcU49bH2KWiCrwv1ZP5qcK/N5SareMfbfyLKjrmOOjpz9a8yMNXxXWDezFz
4EIq9I5MfBt4ff9DQwk/5MdWBi6HW7xyKy/MX4pTNJK+r1zAbSnnzbHa0DBo4kh0jRiEwPh5aqJz
+LX8X/ikpcsbGlzQoHikPT6QnD9/TffKuviWwPyiZ1VKBbbD5zfdk7h22msMwilODgNBd//8XnGb
bI8tC4eSN6VASl3Xt4BZ6x1QcGXGQOabuuGl0vwXvJkLYZyBoCc3v1IWCwEZ/JQ/XGo62nmed4i9
695r7MOfj6+u8dQKx5Wu21h/TO9xfUxTJnjDO40pZ15qR9AoKo5JiMhqx8EGtNehs4ZPLPgLilqD
U9cVqXSWZrl4DXq4skrf2WLOZptYlfE3z0k97d3qdPyUZS5H0bt9uL0pdThKlFVHnncYu5z0hW8I
kfzsTYc0OQgvspKa+Dgt0zJq6/pLOoutDXG9k/9h82h4rLV5Mxa9T5z5n0Qw1iAF6z8qGokC9vIn
qtG98Rb2AoW7nAbH/Ok0enyKr37lUp+sWiA4moQEedDJtGwyKVMinqx/vuW+u1XX76sCiLoUb2tM
oLyRXfTheCIedIeUarBFLNVHWACxPnNgN3X+Zeg4kGZNahuVXP2LJAygdE1EeGimX18MfJRi6pRN
aQ3X4FQvd4SazIYEpirFAQhvwROGCiQy2Ovr7Qm/pD14Jb3scnCO8Cw9bvKRNn//TR74qNM82kTF
1LH16jKfC21P/ZTn9qpLaG1361gNVJY6pQPGishhtT7Zu84UryPCziJpjWcU9sl8CHFYtfZcyVC4
YOs5O+sGjjGHSsHL+dXWDCmTwWfgM5KY+RnqKJ5PM+OWtaP8mWuMdoLcl17tWKtbeIdK3o6Ls19y
sTYgnIryvxiwDk6rOzB9XqmhCor1CgoAlVD97l17iRJzRf8eTVIKSa1AblgfjXusXzElzqiS7jf7
3fJvR5bVuYIbxeEj1+bnVKtXd1KL5bRUoB3Odp+XlXfby6dtkA6o6w0QFHJlDqnMcqrYYaUSZytu
H3P+ash9UqZcN3ZhMgwNYNKJFKNr+6ziCCyOaHkfoIZ22Oo0K2B7KGnHIRSRUHdtftsPopUhz5Pn
JEJd5ayFMH1bH520GdpTn6hhPIiAVw+7i0xY11EF76QYNnh5ym==