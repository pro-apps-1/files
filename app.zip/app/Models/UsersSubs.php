<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzqGuvXumTVV1Srskx6In8h9fQ7NLEON1uwuJDiGT1OcvBrrDLulk+4xac4am70embGVzQ7a
cGPe8NoX2EZ4HqQTGh4/cN6uWGXm7WL4OxpsDbae/lhnWNjiEL1DWUwZE77M3NnBjmmjQQke15V8
61bciF377CG2U8YEuPo4b9wLpvRfzNVwwexvVGUufFIQL8NVHwi6NF8mxue4bQFAfv9iawfxtLmO
6DedHTXgmlORR7SnEPSzM1Sl+RE7Smp59TG+nc82gkQCyqV2yCGmDldWeAjhmGr/RR/B9O2BNP3S
R4nr/wC/zoAZcgmYQSSb/qnxnk6lUSaCyUttiq2/AsUzM99WHFGL40IYjc7C7JcRo8A4iliMZ4mu
2fkTa1UWgdQTRlKMcKdcTgGox3HX/EWZ3mVgkJJyf2M4IGsxLPfIcUA1Yo57HEHirgVFpZNhMD8/
dXjkd8Q/dhsHZbwEXrkt+ENhUHHAzGIpnfQVIxqtCx2KHI0A6LrBoHRc/Elsb6HutBpfJGnMjt7R
kvpwtyk6CfyzAjG1bz4I/sRha7ZEMnjPnOis9nLYICnhR05WTiTBi6+2LLQYXjXRBFbAv84XBHe7
rMoewJl5QKnxZk78P1gyhpZ58D+L3BHulQAJ8H07jsZnlfcyErVCkRLNhwP3tZfcY87avLi/00kC
RYDTGehA4lT+N0s7THURVy2sX/j4wqn1d/B6Ot4efjJv6pIkBgTeZh/qDRQSUXBOKo5BPQ02pV3I
M3dgub8cXr48kOVrPufbvcLOzP91u2BDME2Ro6VOLzwol7tW5E8aaOiMALlFP364oexCHyFh8tIA
NEJ5bxVSSKwnKJ6WgxJVPNNJDHO/Ys+uwDqKBYYnzGwqpvOo3mOGbZjddZdBbDtH0LqLdtys0lum
315r+pRDscYEa+JKhUNsIb41qirR3Ubh3Nc5p7RYWktIMURczrEBj/SxMQk0FuXz2Ws8jgo0EhcC
eh5TAMZn6pv/K6S8sscTpWqZelMY4EWt/aRKEAuGtFS+EqA25eDUGn8gx0GOAbYok++0pOKTOQW9
+XpD/TvNJ9jo5EE5U9lD3C2T2o8Pk4gCqal5EaRSbtmq31deKz3LaqWDhn6dIiiulBravxgxX1g1
XNlc6V6T8qyNbXbO516XQgXJTiocimtBKMJmHQDgKIJraGg0yFD5EnLnDi/reLCJyNnP9Q+M5LVp
ontoh9c/AVyObIgIeiEwWypedZ8Od3iKXUxcv0pqsaNcWDX5Ol39sfkKFKP4FbHJ8RNHzcWNNhAs
xNup6klP6X3vYN1HoVIVeUEeMyN9747/sUSGFZek88x13UseY5qVAzI25CTtam8M7EVugQXamn4b
VzY5r4jypQ22dj377+h4c33svxxkmzke+JEVS3Oglo/aFg+tiOQPVKIpKIpqL3TL+jeqPoNpZ/WQ
tamFBj0i6X8dZXmif4wfbfmPGUWagh8PIHFgPshmdG+j9mttv+VT+wbUOptekSQlpUk6uJj5e/Z6
2L44nf74CJavuiTc2KkxKebaNcKdY7h16ebIcOfRPb69VIn0VbQIgiXA9ys4PRyDueTXmrthoKs/
+n5Xn4Ug7NGCbl+QKmB+or093Wm+U7Fr0DfWImIW8NPCs+cKc28L6yOC8aehUpEPUSUALYdKVpM7
y/OpL1w7ITpgzh/wY119J24P3XfEImkNSe1YsGNbqJxTfOHEhRiSWiOTPFDAD30WbfK5tuiGKR2t
bT/10WVBqUYhn4PD0scgIm9/pkoDhJAp5j7YUBel3OW87i4qERjzk37ocajhGzL2tza5/fYZJrjg
6fmlqRenP6tlRqvppKF7stkWSR0Wyv7ugznyNYJ9kTKZBEIvv/8usISXzbqu1P9HPibUoTvkyYQB
vOJbMMjRt7IP4Mvrym2IJyM+uyeruI7pfgMQUAR2aqeI7QDdTc1tYZkmZ6smj/tJeqi4ZLKR9rz6
zS9eEqoZXbOZBScxWengUpO3802xSgJsI/xIefj4vGWu2OZxvRIHJ7WT0SV+0JFxinrtAGETPLhe
9klsTTxo/yHmUlc8x+CUMq7HTKh3HVO997R36C/0glA2lkYOSbl/Lg8xHQLztyQUT4OU4IlRW4Ab
9WcGKsol2A+OWsl/AE9SCMTdDchlclvyK4Q8ogxZ6ueRa+Ia+ciW8xLJSdSnC7Zlt42qIK436f16
UdU45IsOQicBwTuL9zrYuQgh8eTLSkmjETSvz1vLsJdlmPtjViaFXG6BRulyCVCv5sJeDDJLEFGE
pNy3fJ0EVl7idDmlpVHIu3I4meY627hBdGEbNMsimPLgw/PuTyxu4aTs8dKX5e/thb975OXg63FF
EV4RU9hP8nDAl5XOMhytsjpx8AJCeC88lzrgWsT40fUtTsTf28QWq6FN27/mDyWUwpzp3vcqoyVw
3TglUHLbTvXBWE9jGvKGWS69ArXRuaXsfepiVHuPIHDNluhnIRFdW1Br+V2I76E2xUELYeIB8H9G
fAXJ+hXSgz8onsT3U/TntH/14gHgHP5xjWTB6my=