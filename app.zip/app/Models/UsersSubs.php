<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsqwqqsqkoTYGUP6RbdZ+MRcjNnCOWCNxzaD5AjGtajpyuwVW8zZ1RQg+t3O1mggHZZfd0Pm
nbDMtjUE2NF5XZcnDTZdhBwutiiTk4Rjxy+cm/Aep+M0kLRTuK+GPlnVQzKriAAjTQZLDROLwLAc
jHHkY7mFbIqzUoEMh8E60UjBvAbxdhu/p2LqDsL0w/RQVOOpQWflZbqumtzvf2EFIYXrlHTj+pFj
+emdNxf7kxlf8pJMYZjdEK7RzFjnEBwUogHt62VXb4oTzhmv2BwKJROdXxx2RemsvQz8bNVVnK+E
yzBJNa9ecjQ3KucP/ocY6EQHa52xMF60gmpFQog7x0Sl0u+Ch36XdJEdOaTh+Guit2pKfTz8dEFv
mg+RDqoX4JOhEhp6PY6U7rHU2RWsKxVCIX9MWEIRW0OMnjbBTzdSJYTxYpPAAjoSlWGUdebDtGWD
n/Nt3CKZPEgxv7niLvSrWJDbR7M7DzMJ8/gihg4UwhQ/quqXpvHH7FQU59PSzKCs1ZUzsvnw+fHo
NbtOyYnz1Ez8ji0m6wFkHnRsqCXrfr5+qlCRR58RVAyNXifa4671FyRYVN9RWFdkDsdyAsHDrv+s
MBHQIgQMppPMbjZS0LGXEk5EiHu8ffqokd5JIN0ZlcTAz1yu4U9F9lazHQVsrgqmOE1v2AHeJ1c+
BkjnD3IgZGul0HvmKGQ40Yj+RNwqZmTgs2u+elyfa8L8DUS5lLwUBkR4iMnDy1PnoxQx3bVzwe5q
B5tBHAtgrEHwiDaCb7V844driphvKXFxrOu+NGyYRMM7I0ouSboD3AdFYXnyxg6V3Sj8BbigTHZV
z/48Ld/XTW+Kf2aghI9cw7XoEiEgUKjGmPwwG6S90bvzKNh2SX5u6l6szhcKaBWPmMO9aewFe6Ka
aF3JdXvAa5g3vubN8IZBto5Mwa4YO41eOxwJsTuZ8HHWsBed8VRIERRG6BDkVFnw4FEO20kTyroJ
AD7pqcWLr7aeZDdZnIXygtE6+z/XOHduSjd51etYxntlD8RXBdLlyKjUqk3p37mGCGO7ZJK20HlY
yFQ5v7CGHkmIcqute+e78jD02kvCTwFRPbk3bPkbzjF7DgDYCIq3kCBQK+8LT5jvn66vxwqWzsNv
B01BjI9SB1v/S+D41WZVTPNBFuSnPRvcNuZCHmFGUxo7qnOshtIorC7+G/BV9wD3XJ8WIIymytFi
OqGza5RLP0Y1ap95JMMKbhqmRCPyZEo9Iotw04oW9oyobWz9292wHzTfikMHYNebFe9QolyUfGhA
43u7KqAfYm3InSZtH8DPgGbDU4MPCOVl9EJtq+bmnpRlDhVBMCjQnjXrU56giW3RYzaC67lL9//y
9DNmUIattutIXrurCjWSTRHmXJYCPO6SLfhqRSDx9Ake7Z2qYgMwLxZR/5sRAzen6RNq0zUl5iTL
dA+IPaZLhqgygRe2RzXYyWRmvNPFXHKH8tQb0lVRjy+w0P/jrdl87CIYCljAtYv/74NirUs8/4/9
x0Ir/vESrjZGGVyJvqu0pj1TY4xSE1SMu/+f2IabNlnuMy4OOrOG4zPKa3UPZRmsS7lSA992HQld
kXXQL9LPckItyFHdTrPznENnsF9XUavRveHfwZc8PQ8mKDlb930f+2ijiSNQCImYXqRjJekKynCz
vt0U2x/gb/iZZp1n+SYmnaYOAwNWPF7e3PeKQ9kdyaYYjo5sTL1Kn0HszRMZrZUAJo48YnPNua4d
SSaNQjuz6BOKO/ZkGTB0A0q4m7cCfL9BMmH8ymqCpUT+JWMgDmobZlW1hssCr0JhoMewlRb5q+1d
t5EQIrj4QnXybqJCX3AAGa22b50Ubi0NDagJaanioOFQj6AycjIzkmNeDuEKqDwl67pFknn4drbN
9ygojpvDZhkKjXdBcU6/RmVbacspAdQgzhTDTaRxTiQdsB643vbQGfk0Za49EVltUp9EmjZrY1WT
dFcf9nnUzKE8+41yiLc10BO5iWFZS/o4VYDxJ8hcBmtDJxZgHt9eRTKQp2YDrwaCxMJ+l9cH4bS/
Aat/bTl1mfwkDWZXwcUfuFX+If3VWakVnCJAC+6zLHYmtPad5o6IUnhIqF4nh3idQDsiB7dP4vBC
z1PIsFRrtG/Ueh0tS/HJI7s7tXnEwHUPPK4ps7GdvIpE+oi78pwLXD+Qb1fqe0jSJcHUBm3bQOfq
w/wbIaS+zuhhU09lq9oB32rGIeGckbzBK/2YCpaUBQmM4ADLe/pCdRSpmi1q6w02u1razIpdtHTR
P0I0wQVqQNtU2+aUBfgaPTXxn+gL6YPj+vrpXmMLhx8z6ifj7DojqmSSOtJlYCW4duuO/JAmiKAC
NsL+knjvJ4tfuCa242p/yUxOJ4MjK1vk9UxUv9OuGGpW/1s8TWYUqJr7ULU1TIb6tj1gOUS7tMDF
ckiQUKVakNNI7iixFRURazMZyxtI5+GYGyKokbRLsOEvmZysmqf61UaLTMqkWGOsD0efFw7dZ+4B
GsQn+wWiDTTg