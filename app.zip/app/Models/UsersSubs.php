<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmfZCBP6quYv7x+bbVEfxPssFvIr+FOjMwguMv08fb7aavYA1kquL9K4EVbPM9CIiC91nlml
EhlsPWcC7GCKj6ferYyPQVHdExGhFTkbJBhD80/kBOyInrfASLMAGHj9gWdWrK3IkOkhRUTCrAbT
4VmMLTKsTzMU+dVzTmq480zskc2J2SzZ0irbZZ8f4/2goaXARnwTaePhYNu9vxNz7H8LPRvx6RS+
RhTiS2g516nHSr9TSX8kivHkbxUVVKMsiQibWFm/shcxgvYq+RWdSfyMU+baKGt542SJkeFmV2lB
qRXAR4hNYcTY8v9R1xO93rw6gQJtIruQA4+y7X9eNl1zZh2smM5IKO/GSWqa7z7BJfPXXFcCWz7+
JXHAixiMy4lY9M/3UAJhdmWTcSfL6VX33agnSwHmHh5hRwQuKrxJDhOAxXuZRPomQDuDOhcry8hx
N9AmjWKWDCw5O4W7CmyFnU5PVa/o+pGD9dWA9kV9OsEX/Xx282NX+WmKtvd31gwuWPzesIr/8aMc
vp3KAxei3AvQImbE9ChtRVFR8HxtqLqkHrBIlWCPLeFLejdoOeoBs4Bc8lzNfdeGpll7I6wTkYgN
mIQDDwb+0zgbrCcgHD5yoCDmEEFRTvgeUBlw04zM7Tl1jJAzsspolgmBrinUngzju4cuNbUmxjKW
VnhrtMjHaBQrYOaNlPfemEdw3vUl0XRV6//ytxrCexkbZObcbq55q2udVXiUJ2ne/z/HMYZWmHyV
PnRT1W+Qg21DFH4moVzsdqFLMdVpz4zOOuFT/ufOwrPwszVyIIi0ACZfBPuw5PDaBjvVaN3Kgrg5
sD9Ea1FYLruhmzNZPzv8EIYSHxxbL3YN4gGz7zOtA7EcvK02XrdLMclClUK9VCwI9AoRzzHUaW08
GUlRJz06PeIqoDMJriV9ZNKvcjQQRaxsREM/aKaCFbXeCX2kCKrRELENVxLPleHqOeoN2tcM3C0j
wrSbkPw4seuuSrK5EiQY2hkl/5O26EFrqJfft0CSGHXcqTlSk5VwnH/cq+eukr0Ly7+TkwQJke6N
jbI5UZzDTRzOJWePPDrAsMFTWstgn3teLYNinnMqeuAJGodTPYcPasqkgLK1aWFipzPs0+TF5c9n
rjQjYzXO4pEIzGc2fe8uDFDKgpArqloeLRQJHggflMGhLfBQRg8hrNDHModdQSUvMUyqwZIJvMw7
d7shfv1+MixEEyCixD3bqwYdOkBWEvRAUsDqxrrfwPCBVZkhj2X17W/8qHCQjbtQB/TNo3Cvb6d+
zQ3Wje2G+CR+fhNdq7n+u9NkceNNcgDVTjw9LEfNZRMhZwA8AO+Q8pXP/yfEVjHA6jGN+40hX3jX
0jDlbAtmnxZyrDtlgIJwWuKXRBRGfoKxJr21kC+lWAj/yjGPTOI2D2//07yoBb+AyH6xFePINrus
ZDnFH7cVaVgvhSbHRSyBiN9lUdYVZnvXASAUC6Br6J1r1bOQDW+uArs6UTgUtdCtaWcIapMse0hj
3MWORHuwEcmi/ao/YKssEEwx3vkNwXioKNU+G9J922j5vrE3oAGQbJDT6JWH1ZBSGNAyRRj4xq/w
GM+BbblSIYrhOr+Ewm2nj+JCxW/eW5MILFLmtzkU+SUNYAaM4EvsY8zXT9ZObkEMbqhzi21US2Oc
NyD0ur/PaefjznzV1rXm/kz4RXOf1G+gpncxt6u48brIehKWcdsFkB5MOh4xJiBYBcVMkeYnXQ/R
0vhkRvU8dpqn828M0zp1G68mnH4Y6veT9NTXgH3wESSdkm4SOl5IS1lDkybrwJgB5TMhnlEp+iu4
2LgrB3fKMX4qP6Kr8fYsJex3drCzDczUP2zcWA8j/KLwcDOPzBJf8QUUufWcsgslGOFEdJDu4q6t
gUoeCblPTUAJAMLOUugRUsG6mzVZgpX6wZg04+s+ezGU4hqiIRaN9XTN8PtovGuQRJwgQ2D75iZR
wxzfEhaYNzIMvHqmFzxlaB33Ou2sZ6K6koOukYhpwmQHI5eldHuUxbRHWLUBJOnfTl8NfpbeyJ3C
YV2OmF5GuEXx+FJpW1RVw0GVeqoQrAGHIqKqGiufppyPZ/Pg5c+3OgRT4YDtqlmpo+DiaJaJZRum
NorpYLM23MCSy4a3bXm/+EFEk8SRcBNvl14bzKPAMQXdEYFlX+J79e7AibPA4gt0bHtwrL8fYJZS
A9ff4fiJlJQKWgumrkrf5erIItAfyENmQu/wv8WsE7TouyTY10f+b8JDs41w276MD2jKGmbmB6X7
a4kpWpT0Q46x18Vf0VdCNcZrvsA90lkYMc3OoKGZ7O62Fr52QgYDx7067D9f29QNP1fU9nAkeOTi
UcECnclZomSuTYyP+rijPhl3WZe0EOHQ6ifrQdV5aFDtVqNRAjR/YwoE+R7mSAjXQ3hY9Q+eJ7Dl
MJvhfWO6CXQCTTzmLeaWazmDGNJKvhoC8cCx