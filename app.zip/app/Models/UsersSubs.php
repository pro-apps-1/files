<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwkoigky80UCkMudYB87aNqww7IpwP2O4yiM3er7ngFrwVa1VAPqIXpr4GTeY2wONV9uOVwv
7/2N6+e2VAwdPn/V2ceJ7ovsQIj5hi12nB411uvdcVY+L/2u7WBjNlHYeRofG6v9GK4Id9M9SP1E
/lsXjcuEYdDgLiPkbs1X+FAf+v7k7Zl0jasKZ+NCL1/Zkzb1LIhiCHOi4dqPCM9LX/0TxM5/+qVF
O5z/joWXvoRajACGo75Wam3MzyMHCvN/5DENpkVnNdmqLogZkL5iG83POWvYkMdHikNtuVVJk2cj
xODPAWXW0ej2S5xXYa3ubw/vBNIzB0XVYIe7P7/9uXgs+3YmfT6QmN1Z6hVM7IPxr5Ux0+z46/ms
4Ca+9FmGN584NKpNG7FXhXkzGbI9QLTWWaIb498zma89b4iVB7P/V5x1X45DYEjJdibTrK8HTNGz
V7GwyQNIQvD0MiWZ7sqFu3qTxwgZwzQM4TAprVt5JtaBejZBIkI8x3rBT2e2+0V180+WNFI5vd3h
VAoI4DXI9dnCgOmlsLwkw+LZQBmZu8GsCvZj5m00trquOQN40nxWdCoINvS7/tYWowDujVyoafFU
TVnF8zm0zd99zjcL2m39YZCRzJct3ejyqXZSBmZIoCcXUA9X9V/CeVRKDH+XHdcogO2rKN8t07Q5
pB0nTPYubR0swcJs+2s/TuD5U8ZTbqWPYTr2pGpQKLUgVas70r+ld4SD7tinjtPM+jeuiUXWPaDT
BBadJbvGltWWS4e6MFTs6qidE4dn0c4wjzhlOs2MCSVaOnbfAqeZjLlNnbnRwC9ZIfdopLGZP/5L
tSq/XF+cujp3f95ukxZU2EJnCMvoJoGplUDa/kE6xCIEckIU2R9AVWxtW9tXkQCsM4rDV/oL+ywF
Mzw8/CmO4+0bB8UmQU4wQ+nxffAMPBxAjzsWWBxqLnQW5IOhsySjkkIaoLMY1B3axIpvz1duief0
2YDxd9UhdZHS/vnI2Vgw2Ficpf80gt3E9eHh9eQ0jCyEeGKhyYJzbVzg+VWHLF2Uw4hj6Y2MU38B
6CyDwaoPCf5U/Ry0LxsCWzhKImpf4MAMJn2IpZLG+bGTJRPWk5YDLG9zFJL64mPiFdjMMAN4Gdr2
8m0RudSrP6PMPCjg2lSbyncv+BgC2t9u4WvyPmTf2rbUAlYi/WMduudoEcT2Y/XltE6G5Nkh+FLc
pHZVv2dTkMtYHw1FPXqi6nQobeZ7h/9V9HhxBXktre18d9EWrkoro/z3ySDjZWE7EW2LkS7CoEwn
wAjL4NVk8Dt5PhYBZCY1fSboT5SjKzHgk7yEX+ybCaK7mcSTDMZ/MMiWdj6aHcEzlWyxYomM5xzH
WfNPZgXTsX387nvFnp5HKaC92YA0869pTFBT87TM+sUm0sIqqte43dOBoga3tNpDID0p6wjo9BZ0
WhgDvK5rWZzZKfptlWPtOXzKcachzSAi7U4qS+lZqhyoXftoNTnYJTbncjZTTCQ3DsQIvpiR8s8e
1gB+JKrsWDZaYbDXt5MaYEu8RyYhiz8wO3fLLP7zRJ+5nZF6CwcgFkY4UM0AfQSpY9pgiQAnb153
cUQOUsluKM0YQpVbYuyG0dkfNCL27wqkicuIHemYyDboNOLG4tX0GYYr2TKxRwudWekwVin6GYU+
pQpzENfFIhVfMtqFzOjUGe74y7WYwuPJAvh8VRO8EmTMqK1tzDbQ0iqLtpCTPqEL4TX4GoebDyFo
eDEZJvnZVimsf82zFxz6Q5l6vkJJ0Avtgw0c49AzEQ4VWHQBYjFjSzf37kf6shxXkNnQ8ZRu847w
Bicd+YhArGP5oCOT31Eeoo3y+u1/zPkz1HstxoPoT6bZ6BRBBDjvJlEurvv7gEZ5iFhZYVGO2OLV
6sC4BJqJ9c/kXRFNlx7HYLzcO947e+i3SanJfBYlfiWnep9ZDWnRA+mVcgBr7UZxAMpuKxnHleh+
V3+95m8ZJ3sqU2Lmwfra7CJhnkYVqCdMHWQsFMF+yXBI359DtKSNvi+ASqm8l1T+6CaCrMPpKEeG
2SGuV35Ky+mKVUlpziJrzw+wBev45f6sma1tHVYjS+0zp6VGYziNiILznj/dbul1/FHQihmWEpQN
SRAS8QdyCs4+WB4uMIz5lM+m7vAPRaz+IMzzdGh6t2DabMn2Idlw8D3dOWecxn6+vrXQmR6FowQ2
TdPNquBfft8Cafx9LiCs37nviAnlMt3FOGOvg+P/D0zSs2h668ddgpad6FLFCokHJDeTE+FyPvOw
l7WRYCWzYBTOCHaqcUbnhhn8z2apWP9E0yo2EupRfSp582pQBsEt3PFMZxLyrdWlp/RptPtfjard
q5wOYIWGhL0w/4XCUKDOhwyJgOzsgHWurZs1SyN9QL3WXVfiSMDphq/nOd86PMJvj5wppxtFAJNu
LN/AAcl9/ANU/OCAVZjFrIbgWFlpPPMigIUmGG==