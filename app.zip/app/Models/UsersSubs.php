<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmnsYa1Tv0vt6AeVOoWU2SiwWV5/CLv5ChMuqo4lpCNpGoErfdQB0WVc0Ttbc5M8c7JACrTv
1B7oQ7LBdQRm7Fb+zcMDCOJXN+tSl9G5s0wKZ5fxLnnWgynZgvCDZi+TEhMjChehc2mRdFt4ssyw
D+kUD7EPLvOUwAlSj9C3nR3BdadzWr863rtxpWDQlzkftnz9f1AXyKYo6qBNMVZxFly6L87KYAd1
ZV5r2Zjd3/xyRZNh68vLliacIn8cEM7tVfKtfnDjqKeZJQJYb92MQiv9HCfd/wKLew4t1rzmF76j
vAfO541zcel08Q7dcTOmeRQiuV+IAZQmcDezwilt8ZcAQLwkS1EQK6dnnIrl0dgpcAwvtIRYyDeT
4/X4OnP/c6Uj+PC0JRn7mHVFpTFV1UmDIA43KyGZiR8lNs4/we9iq87ch6H4hMyVWy4ufWGUlfZH
XR3EL4YS8SrKG5NWSQuW/feMbZR1JWo1rToYWpJ8yyUbQhq7cv87PwBq/mVeFLEIqZggO69hj79y
2v/6Jqc52VyaiutypyXh1rTsJmr8lWWkvYQzjHS0i79wcJAnEIm8PLfd2XxuCTQzkNyzKuFYbyiV
uEHZnDW5gky8qDLqmKF3CKEbYGJRYzJ6HIWcIpJkcsfmpW7u7joMhtRSBRD0RdZn1Ets/4x/UnAg
/cX2KuJ/drx4A5sH0eKDoLXrhC7ZXghDx0eAT2c35argLGJcfil5gvEY0mrVt/omVMRlUhp13T7a
09GxltUKhq/FSGHIK38tqnvf8zRz4aDJRed/FxBwKaycuLBOmjGUl1krQ64lSnh4+nensnFb5CJ1
NGqMm4W3wP/n4UPLs4eV+9Z/rFDMnICGO+laNIvwP11GDtarPQa1ZGtMb9G9bvdm2/5hTM4kPKUE
559XPLT24xT+tUjKfwj24k/SYb+g+OUmYdbXimknBhdZL3ZSGdtvEzZR2Vibf17eKE6EclaqI6s1
LXS6YuEDHg1D8PbZNRdMDPU5GQzkWnbgItNcWEVcs3HKwVH8uNBOPc/r+h2JKAOYx/bIB56/iRxz
DUlMEAzJIb0GMKEOkIbs/h7T4wN90uGkI+pb7GYGB8407pCdFPJ1iqL48CWdEr9NUpX75WFBCWbU
JladaBt4qgSVl0M42AsJWrdvz2htJVgcJOdnDJQRvdFQzyLk+9CfhHk094ukZWoLeho1aLfbDtvn
1Sf5AJsa4LxqwaNA8bpGDmXnwGEQeGdDn9qqAXYwIi1bCwiZX4KIWQhZUyyUd+2kHQkzcpanlUQi
18UG4DwBxpl6jThALEH52jSpSpRmuucOqR1YooPeOn1XVoMJ3oiBDYe1k6jyYAgYP7R+KnGmY8hy
h64ke+F7vJYnJr6bSk6rx09Cf/Fjlw7KUZupzqg/EviXW+INakR5ziDTpTCT/+LIydknmBZNvCE2
3N5aVqFkjbiJ2nG9b9qCnAXv1pg/XRbUh0AvkFgZshIFqvepT9fW/R7yw2X7uNv3MpQ9nproHEPr
eUr6vb/fUF1MBoRQW1MGX1FjziZRThMaW5WiI4x1gf3BWtXuasdOizpotj7Xa7lZlm+cdW/V1mE1
G356H98q1Ir2Vj8KYRGnJEKao6JZGlVbH8X03kUTnLRzZOSsSbJxPztjIntILHeTr2sBpjTni0Vh
dtIRttNFOmefVcsU3uFtSb7/+pZH7lytjhe1hRbIOG5fY1mdIjCuzDZSCBbz1BbkoInU2qhkAByt
RXBsDskg4Rk054nO0YRXpZOKPfYqqQY1xUNre67m1Drj1aB016ZM2x9bnuXjS9QgRc6jj75jqRHp
Km8ItQqJKlmw8roSfGOq6b19HD5SpYZe4lbjcKbQp5UaQETx0WDVfR99BXHs6YjOK+nVLKrRRKsF
ydF3Glm3PSWenZXYpJWinh7yxbjj+7arGqxGLRUAVscJ0LIxLa0b4UTJ9hZXxv9zxsRwMT4L0gRE
RqO5cJUsBKzt8CBpxQN/RSF4OJPypAk4XoCRs7V50qvsDKINGzHnzu5rbP/pDZ0JLkuPFH07ehZV
R4hf2Na+adA7GVmM3AxSdnYtf/Fcn9eFK7SYByohGf3nVRp1B/UMyZRE92lgirKtyotrGymRRDc1
1cdzr2kXt9MAodlZuasYvUrDxZ0aTxVcsCfabeYSLceguHLyiCFWtuAmz3GBCC1tbV7wbWA+Bc+F
ehZDEJ1rS4Gp20aM+B7MJzKAGG/Guoear6cTPQPJr+dP/l7EuE1v/hkW1357Kw+0GOAMlRJXvdpm
2kHDmddGnGFjxKqz8IgnTPvJEPERs48lRlww9HU1vivqNsk0oX9XMju0ZdSg1MUUS83XzjJ789Nz
8ZrmMbkL7MkcA/on6kIf2/daYcKbE3wkmVzm+eAUB5noCXUbgP+6QTmFyUZWd8c7Jfg4MJ5ZU8mB
w1ulkDn2/aEorkD1QuKZCKjdrkvhfwOi6Km=