<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy4GcJS5nc4uqCmC5EU/0dNotyQ7RNVb4V8dNwAPKlORJTLDhQn4v05tju3nqsRllgH/iKOC
XVKJUOAy2YtsM7tE+mVqyeCqtGqhbeZsHN4t5mVWOnNUw9JvpVsM73kUcjPb42npUSPUxCFh9G4P
6FsCOs2hiFg33WzSRttAVlb0PTRui5lFDNKhh2iGUvgYE2JLfXHzdTTkJC27qsaEhnWJrxakLij2
hACNMfSjKTAJjt8zwGlcaCPHIx28YEYEeumKmtSn6RP6XlHJ5iRjwexuwUnLqsoG/DXkNlFQ/7Z1
IOANU46JTI3/Hp8u2wnA6fzN5Bdpv/UMMeyDd6rqpFIRFjcMuCy9KgDgOZYU+fr//wZaISiX5AQc
qWw82Xlubu8ZH+SUWNOR2xlf5Htw8C6jh6BzbnftRQwP8PuQ7jV2qY7i7AUm+iPmi/Z1ll1rAjSD
TBVHQIuLjdM7g07CAy8S7/QT7Bn5EfWNrfLeOlL5qx9ES8NPS4NzWTaiQwyZMWQI5u6yWJJFzFY+
BrULFIHCcbCJW5inXFdoVe4WgsDK1tyD/8QhuEubhWruLPobEXxdxfEYFqclPqBPapXs5HTwWJPO
RV2UAvGnNSNouBX6EV63a+CQV1zNFN7CCui8Lg7HiTxJvi6vO/zVkE6Hgbt4iMBhqgDss8oqFtjR
0frTwyD+YWDwKaYFmKPwA8K4lEvRTEvmPLvsfswyakpPxr3rBE5x9pd/tF+2CNc+CXEdflHtxrqN
1Qrf0vI+oYoRAcr/ox+T6MwIsMbDSYUerxuRx6qgVP73zNs+X6UmQRxLyxWZo/IHk9pKEMYPCoDO
OcOVsTO2yh4vmuV5NW0892HHLN/FDW5ro73wXJMmEuT1CJDaG3bEIyLaPfkKL+6tz/WE48fXSkOQ
uCqjKbDrtgN4tGO0sEls63rVMU0s1Oa2Uo5jayIyxnNjNPIHtRypBVote1wxn/X9mjJqv2ofHTgU
q7ZeTe8eYOv5ZbEmB+ly/8GZ6O+pUmS+PZ+UN5IVVj0mD65SzGEXMqTjFV/znw/Bth/qD+09eZ6e
l3aOx+gMPd678+n2Tch2MP8zA8yGutHRLhmGX1EbHYwkDY/k1ELHiX/xyga5i9kh0WfjmLPZo1mI
vLBYG6mxQlvvwOWmffS9VnnJOUZiYrVMXcjQ3M4uog9RFX2TubQ5rnmK8xC+cMa8Wuk2YgvjnhNb
Z/ZMthcS3YrR6g9t/3eFPsjPmcV5gLR7PfgGSRZYe1JuMyVI3NchMeUpR89jf/CTwIP1R/GeQ4wi
aZGGqDsum560x+3B0DQ0G+BFedCVbxLPaJuagYq7W2MfUDIQaj/ZT/rlvKe1sugfE5nLoWPDhLXH
lyvWGr4r3NphnroVFm4iTEVBb06w8YO4MXQrfaDFYTr3QlYX1diIMaQEXTZgreAlGlMP/n2MUSVA
+ahs8I35n3ZfXHyxnG0eZm2IzrRq6eE1TeEVmPYjPA1rXPPh/7H+PaQx7vvDjpNBp8WX8LHsE+v5
b0YShJW5lnH7PfpCyC30Zn+VNXxhM9BZodM29I/0zg4H0qIPks77sRGdWhiOFemgGSGU43dFEPQC
psCgdT8WTZfLg8H3oO7QVt7Yc98wG/U6q1TlFxxpwtHAgojY4bTXiTi9fD1009JxvcudYrAORTdk
L2scoah4ZWIxIWarqR71DKuNqenGKV+MNfqLFOjYo3g8jrStLCSGR7SV9IP6zrItbr8udgeE06Rt
1li1/Llt6kFVKPqJBHR0AlLyf7BI8474+SahinH+4OB34L0CTMx1rel1KsG2I/ZGAnXuqaPpvPGK
gsqdoW5iH/e6Y+35nLPOpQLlXRUsR1ZTOoQWuZQUt17EsHVJ0kyB72w69sxug9KXd4ZtoeO4Nwc6
4xn/5kKdHHfK6l22Yan4f7NCSC9Bb9EWZCYek8zTOskhwCt/idIoDDymQAfC7Wr4PpwHH2Aq8+Un
k3sIp1j/3BkxNtG74TI/U0Z4QUrCuP8/DgdvPXcCtuNPaugXgUac7HSe9u2UOH+cIwL0/uuMjgA2
dbGInfX3BHJWD6vw76DL0sWL7zT4oCya06EDqVHl4xvfLQG7FO/4LsetR4nJzrTi9PyZNkjWZOs/
v9XULOnK3wsCOjBGKP8gZzbjahy6t7CJTTd+0R/yQ0EkJs82LEHbRfSv/EUS7iSty9XNdEXuBNgr
G9rL0QsJahU3Oo3TjZkrBL871ASGs33ginhRxQBB8n07Oa1OQ50vYuss4Xg6pS/zHiwayt4Sz6f9
8DYMYxOp+X1aJIZB3SPoGhahYzKa4npfwe+d001rU43RpwVb+olD9LMt0M7tirluaEuTIfhVfYZC
HbcGqErk95fDsKgWK46/vQ1G58JWH5axnbxflomlUIOuVmUwCHQ/JfFc/Nbuizx4jg03f9NGkiIu
6f+4EYh0Zk1dwPeBqBd89NTWzJtKuuCFqQYssY550W==