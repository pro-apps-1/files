<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmnVFa9v7uDr18EhOSu/GL0Xf+mxk1vzdgUuwaPrYMmCRxMYTU0GeNnPOwadvzuAirFF4Mr3
vXzo8YsTftqr7+spEkyPR1bUAmP6HTNN4yUPL3E1pyHGW8V4VCqe/0cP2IN0Z4wCBvaMtsDbfqnb
iHZ9fTYlYJ9d6n7bPOql5uESnO6zpgU7ZMgVUqXUVuZuCRhddFVMJmQwNrWfjXV5r2aoK8mcH3tQ
6CjSon6CEUnD1fecnY0hUWYLWokUg7ySnPR4RjHLK0sFFSqLpROcz/6WCajXvsx0WKdVNCGpKu82
CJWbJkEXGwL69Xvq6GitTtDllepyEXLx3xmpuKC/mzzGy4ZsQrFlP9DZjvWCShoNUmfQWKpsU5Pd
TJZkLYvZHKDWrtJ7exRr2N40c0Vn+Nv2muN63x2vzQpCVeSFxpa8Nczqm16DkX/ZKuXzQ9zwtrQs
cwQ12vkEo8uqlx1xC7UUeQtXIRAvOxTXP0qNsxElybP/mXQ7UAIXdzEnuLpu/cqtDETCT2qjfK2y
JE81nxKfNiK2N8uvQM3DI5m2NlMwJqducidSs3Mmzs50TSRi5ELJpx1YtjegiccaxOgczcDyUGVq
vZCBPa+7h4vbVCOXI1XhTNqd51AWehgLZszgvHdTLB/GpG3/R7Otl6IQ12AhWOytSjgaV2+mJxmE
rlzxjcZyGSls6brxPHwCu5LlE9WpdMBs0LmcuTKAglQOmJLWlYmEJNZ19lCg3E0WLF3ny/A4bTOd
pPj4GwdiQTZ5ccbsG8bNfcPIHkjP8R/zvTdc+vX2sMDzT4Dmzn5YI+C3vd1LBX54GJJ6yjlZkLt5
MkWTaxw8jxun3zMkdjgihpTFtuLAML/99HKCofLuTxeJhscTSM8/4hGBO0JlyjE6MXHWvhLQrnil
LUtKeKzqvMhCEVr1DJJAC/kanjjUn+iDDHtb70V7fw69SiCN/KncgjcPu1b2DC0CHNpQFeLy5ei1
SGGVRTznTV9ZoR8s1D51/IfO0Qdoh7TW4e4r+xBJRwOweQcUXg8XEb9KyNji3rzDJ2RP+jhCjG4p
ZAVV2rCP7r0WyQ5V1jeoRJvuQJXCIwNMA8X7nnkAU87E+ySxPq+e8kN9I0RCzGzxjQzgKnNja0GU
iXxElo0wVd1tuf6MhvhiQxJEkQM3pz8JI/B+JbXAEIQhSb7HCUp0KxgB2ZqJBB2vPmfWJcXmEiGp
TXVFZN4C2YCXsSztjhz4YzOTBhfyquAE1mG9q4wsm4D0uIA595qrwdI1wSUBkdlLveqgevEeNhrR
Ji0l/UUQjbgQKcZFtgBEw2Lz6dof0PN2QGo66NWr71onWmmZuofrT6vBmE8GBrYSL11YCsrasU/J
uFzI6vhCks8OFwCdnV419s5yaYRATihwoNLG2pvuzgv2ARdgQ1jNN0E9Ayy2RaZxeOu4wDJ9pSZ/
NlAO1DuxCti2kfReZAYmzUrMvQZG1B/Dbo64DK3yeDZh8AlZmir/0NVybQTMJHy+PTPB8oUq1Q8O
AT7GCKW8yOI446v2b2ZYb5TzNxrQrcyqMe7dm1uImWMThSmXhbV8kY8BpbPXLTiYE8zJtPhyeNVA
o+sX3BPF4NnobkqCE/hyGH5l0XE5FeU8+LenktOmfY5XNIBH2YXFIGobQ6a4rU5/zGhVij+VEUqT
vLrFOOFujqBUdTjeuzuYCm7+2aJm73HNX82YhU97wFlO/4et7X6LmKu/pt+0xckNdtg3oKy/nmZX
+uezuxS1qXrqkHEiJoaA2c50chJ14VwAvmgHB42JBehRLBeg8D79wA6UrQrqlFvjbLFZPGmkM6Kw
y7+mOheLl1I6bbTy8iVCdC/lZtWSylJjYLGDRCQT19nEPOBBR6BMG3MOJMhg9PAhZ72XDVY8PUus
AIJWu2zK7aOanvrSX09DATFqwPzIUcKlohC2nejUgNQugBOE08JS3ne4SkqPudkZb4Krtmse2qjM
qOxOo3dcdJUgG/ZC9vszV60oH0XYrNdxIS0/hYMrMAy06MOWwYiu80vRrsPkFcJZsYXbPzcphaCg
fQGkbAcIS/wtHfvp1VNiNhV2QTZ8IWlb1/SYaaqorsSRi4gPVEbCCQeHvwKm26VyffPoGb71HYMp
fyTsMo+M2ig/PqyIeVa8jQjqE1iup/coguTTjJjFAM7MZ4fLrtWJ55E5kXqvTKzqvf4cxaBRyM1t
JGHLzJsuIf3gHRGvV1wmNIxYbAhpMBr+id1sI1/eb+Uh41nmSNC8sixRcZXcdQr59AoBeOOXnFLw
ulVjvjcsTP1XOLOf1kiIsFT72NB7qMJDlYgemeN733YZ2UeABsrHN5yF1s+wvbhLG2mTiX2Nl+Z7
7lXRp4t7RzcYQjuTpNoIwlhg2Fwtbdm7GVRpALUREHev+Z1uuT5OEdQexM1FxolHP8tbPUVGvSln
Km87Z5vGbZtTZ1p/jfYVkWi6ahE9CphF+N+p3x8hePqskQeeeRO=