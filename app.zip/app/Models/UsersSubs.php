<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqhzsYLeVJyATI5F1dwxOeoeWoAFsa+Lm9cuWVpSyn1aE/JR5GQi4Wg/ARsymaOpHKK12BuR
rBHLWyioBaJ/lIGEjcvWrS0mTdG0FYAkT/ELjZsvsRCQ74ntkMpWJaEXw4vxovmU0QXOMSjRdsDw
gq01kBA69KWbp89YUSvDUvTjEE8njlrCcDAjC9IssfpdL0YLCqVW3q6wrd64cdAgMWPD37ycgjZy
lq2/5eawzqbmcSLv2JdmdMEXemD4r2OifzSQwNsmmIHe1LU3zR5LSrpbjUXag+w1pBWwoZssumVw
oTLD/x6UPlJ3lOIX0ZqeHbHykB1D6p4uwwAAAld8ZSbxgMU5CSEbMu8wa3MbgXuhrzttyoXrY/p1
AKcRbvACZdH7I8D59uk3Io7hB5SpUygyZDFkpRGmpm/SSYWu0PU161vegNtPg2Ms3bZeQL97Ll8A
g7thk3dQNSFaE/DyahhLjzdFVsWGIDUxOFnYBLoYY58sCenrNU6fogTQ5/cB1CzEU+YOG1ARD62X
jhVDJHNN1LoRqAUE2O9zsPYIkrcdCFY99YvWvbjQHvzZ4bxY3v9vw4o4gtXVtRpncC2zgqXMEZ78
jvjrn0mhCHYLIxh/uK+MGaaMyXN5gE/0CUtur+oxaYp/pUcszFDYKeNqpArehTRCbZjSOBKMwNsR
ahsW0Yr85j9yvQKhLWEbmn6UA/uz0B8diu5kuF1//ETNm6HwgJC/2HS5i1FBsrioChmgxNxoJ7bC
O8+ItxYyLDjkc0ttzH87dI8PkQsitrkAS7BFSDDUsbGNd8MPeBMlvPrHkQnCUz6VVEFaMW/lRIVk
fApmO2A9xNClLCMcGZu4aQ9A+zxBNji7baWJarqrGAIuiKMDCp+PIPs8iHnuTa6ve4/ZcTw89Cgn
tS10O2tnEBsllMxGqJ5wjrBqcA1PsCWUoHPdE+yJWPIKr2U43WWBNj3iKZxB/mjDlcjmquOmVrQz
rW8U94RtCHjcA/4e6BotYqdBAaxVPNCBTxG0BZrCIOBQ+WoA7hR6QktdguD7oaElWCiWlFKWjECY
5PAnI55Oxv3hpx79RpyZPMqYX6fb3oNWSH5V9vPVRWZPT8RPpOKX9t/h2z5XetG5jsx1FdO9kdOF
rXq0Y6aeDKVnDEFpWWv5HhT1QfsQQCxP9ImCZvcLutGMslc3AT1j1vmt7G5t+L1lkyinPbEghPX7
6XwDaTP0JjPVawT14AfC0Kb07GAzUuDPcdXMvQ/0IWmfSeS2BWgNdISiqVb0S9OmKNR2qhTSXun0
A7arEX1xeLGUGTdkfC0ZosdDtoOOR9o1mHU13d8KSQ36t0pY5+FJuDqA/rTq/v78CJP+ZoKRQ0wq
QUs/TCGIndX07bFznd0C/peq+tYQNfwkIIZER6lT7q9j6VKIHUBq8NrrGaNy41u9ASsa9t79JQyz
gDhhRpPdtxFy/9aLIWY2I1XFEHlFR7eWLcN9u3gsDdmX6i3daivkYMtIxvt3OZNvxOKwrefGTwXQ
eNVkHsJvnA5pVjGTTg1iDbmJn7nmtnjynwazeBwrk4T+dIIaVsHxUrGDa5LIOh3nr0DNhyqZfolJ
NEzqMcWgG6I8JUiaNUzzY+1MjyggL0ZRx5I96ZyRU2QBp/tbNrQcyXxBy5ydY23Vn4JdD5qrsDYC
pFx1zXhexDdNWWdenKGZSBseii1gRrMzSZW3n/PTKZLCJ78qrnw0gyfxJkGnLzLn38642GsCYmcY
TcaQZ6U0VHVKyRl6Il5uf17nLEtRQMoxXDXleiezCk9AAy/CZphwxFfaKsMmVBpHMl+otQc2LGZM
zatB0vFlWpu6ThZjJBbieDLzwJC1kAyuBsOdeongwxJVyBdNOpwwW20/8EVGbFU3J5VYs2pv17n4
acMeFq2Xj6LBnXI/f5A5A8Xio6d2dNUDHJ1EbYPPSGttWRkXjoJbCHhSSVKZSf1T8Og1lBJnV6OH
0QWUfck9ldF2mPvNdNJP6QT3xfIts6bdiuf7szOT0Ei3E7sQz8TUpMArQ/TCTySjOnBhQVaomVYu
wqTDjkP6cZ/AeIw3rdaeUDkLQGud858xkjl2xS8d3wwkeW2m02ggT3ADYbZsVAHiDienFPniIPbV
NhlDPRoXPC9Wwy+lO1PbddfhCbvv7LkCnf8g60KsYNkOoUrw7O/NXp1CsYiIV4N/P/n1NdqX1rx1
gOMGYv0Zbn19Taz9S9mCFoc8PFwwGW5h5EOD+oq2c+skRtg+6907G8zzTpeJXvjfnpwYkPWWDaX1
DFTVcDi/BNnWg2DRwYrD85L1am0c7Qdv0zPAMm0ca2WLo0m40iEOWYyitcYfUBZV7aUISD6MT9tk
ZdaEDkhEzQrT7lq4AB8Xpdq/dfHX1x71wrlc544YHYoaSYx5ue/IryUZVIbT/ZTbJFYQ8kfhaRo8
/xzyEc/H9iGh1jXXgISprWrNCddbvO3zPvb5a5mGmdpjMu1gFGvX+rSROdMtuod7IG==