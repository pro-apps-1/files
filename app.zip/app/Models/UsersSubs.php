<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvHOm0R67ZafduHL9TnRr9/4n0Km1iGJ2lPvs83ibxOBIVWjFyB5YZI6A4OVNrYglXCsAjdT
rG2tcdOuFgh9sVT77twbSzD5NOPK+9L8jSXDAR43w/lUgSE7Dbkc0Nft/UlnOU4TSMqnY15IbnKd
XzBKscp7SJaGutBdLmKCnh0ppQOIYVBmFcywRgn/zwJkTAhtNxW+RAr/joSgvXuPg99gNnvX88Fh
GcL+7UcOekoff5Qy9FsW+RnJp6VURrAr5WO1U2poY3b7mRaD5DgPUrjRXWL3Q1W23OoaucBfM8KU
zxkOAL2/snl0gwLQvx6IviwHA+pg/iom9kH5pzWbL6S2t6RsFoMKSREN6gUHA0xV4M3pJLxXEcm4
gwuT3gnz/Zh/Fy/XYxLINPCd8S8coZuW5wUQnibxIH0PhKiM4J20J4T6pmZhjR7sYU0SdVZhhfGD
nBe+YpDTNIDXsSw6kncLN5MlyqObGJx9s83kJv5bRuWSxJ6QCBBmy2FpHcBGwqoxM9oFdt9TH7Za
+yoAtOlUH5CohebZftXEHlz6KB5gc3UuefUZrnRaM7ZndRKVGa/7GuTKLCFah3QwdcKxANoQVgyL
P05KfQG9BHvnMiI58gtyRFpWgS4p+x46w2LHU9A7o7JAEtEtsWDy/x9lp1/KGFTIa/wFzObJqJrl
8LG08HWZBw2zHrJotbBiLVNL5+AG3BO6DOGHPz9DkjcQtdezvIbIXeXsUqiZutKTMA7j/JcFjo+b
2xte7ty3lD9TSAuEGYAP2n5hHtO18oSQ8QziBPAbpDhJQaFdwlNWsy1lFPgxTE8qSs6kWZApI6C3
/ybYFrnJnnDk1GJ+Nm3w+i5c5cF+RCg8haMAZe/H6MiHYFSAcu0UVON+eXgeYm3+CJD4GV/g3EAd
S3chO4yrKUXlh64L9Twl5Msfnf6SHAtpQ+v0Uo6U64p+X/nOvMPqsf/Rx2Bf3GxRyfanysn2HVGP
5amkPHEoOPtLRpDRiHkLAl4gLdukxLQUietyhB3ODnn37TcF/gK+sB51wxyReekadyOZC/+oTXxI
lfPQKJ0isyky9E5GfU0rS+CcrlpUuKUeAz0IUyZHqBdu1fijXO6M1Dpx96qMBvE1DAFgeOPrTlQv
gCHKSM9t/yTFSPtCdDajyyDPZ9WXudEF5J3LmW8JS9Obd54qaBhy58fIyWkMjKsLp+b1TtCOEx6a
zkjZBBKIzGCgwgJl5pyk/V2AEuJrjF8OR4Q3+6BgMEu53Ilv0FctSPVPU9krAkqXyp7tqyGWG9ru
Gq76Kj0MqvpYdvFJVyoVuWknd9583FIl5aoNomwuGpvH29hU2ns/EKjr5URrOOJuxN6CtZaS62SG
NnsIC6nbHuP+7smDMxWD7LXMGvs1uyy9fnWNhhWt/y8MnnPAlkw1mCPi0W4IugDIgVX9cxsEC546
fCB3IitXYGJ6678QBbSrk3XKzvFAZFqfHwgb22cxisCcROZJ10ZU1cLlDKO2b+yx1XrmZOog3Wph
g8lG8z2fTFCO9jmVIZUIPaxM/16bv7dlc9/4bdGCq53N0Q3O0x6MBJLdTCExxKv2lJFuaoIl+ivY
GvTO6QH4Ip/p200JRqQ3rKDCJh72DCLxry9sn3EdMyHR8/tO5EugDWZGvGVn6vLkEnG34kilYDkD
yx6CYD+mEcBzyA74HvjtNWE9UyLYHK+SlSaxvLL8+/cJ8X81feC13ToH7nB+AXWut/K7MTjrQDL7
DCdk+dBLsutlhyP6iSc0bdXkJE13pv09J3HDFZGgDvtka89lQGhYxDS3QoNm5oYGYRH3hhq1t7Sb
swNDWUy/KWQlEWBhmg/iIE6T9HiLIDDkfGy5LIt+9bYPQ2RkA/b9KigKwxaOgEmlXXNCci7M6pvv
n0huOZc96kpwOYzQSG6f2spbWECBLT6Jwo6KouU0U4ZLxkiImyfdpk9mHt5d/qHYn5e9NCqKPWDZ
07M5Lxwmm6cBAlKWtYniaG9ohBLYO39MhpDfwEB4vq3ZT9a5lJTyBQSbCKr+FZE4xAbZGvOS51ED
aeTk0XtSWItxbHQFrijalyvixhpVtG6RkmxlBytPf9RPlBu6KUqNcTKok7jsN0lW5jrxtVcvoJOR
0bPOSzp0qfSfKG+sNOQUWW2HffE7uNJ82DMeksvspJvzu9nOR22VNGpQDnaRuM3GWqB66gKmalwV
kl1xyGioN6Rvm+ewfl2GUWEmbKgrrjWgRZ8Ma/mUSQeaWZy2YM7f5GgeJfJ0ibsVKKZdDRaCUjGz
qPvrUtBehhPDFLL7uExG0OFCfmsETmzebmHmFxcnx4cZdrKVVZwlcAXevSoNFSRqmiy0RVSSEtvR
47TvYtcgEMIu2dJJm9r0WhhdAKY+LMsnCIibZzxGMJbZpAv2xv41HDttLaywJxeziwmujKmj/JIh
bvezr4oDyuf0AzRWLVpDN6c0GdEbQKBoCSyFkVomUdUYi2fALG==