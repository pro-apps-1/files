<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo5Dp6cZ+JHEkgLPIYHqDrHFOjiKeMydxAwu4SdoVtsAEeWiXI6twJ9wtyaGIb4f9MsRoVb6
uHMEtv6HqqMl80JtsNmLfoeNrPahv5dk4ggtWrzDwj73/PWJp4AyWpUxsSd71l+sdgCvebyZsqdj
7nFW3r5XFvT/uvKgRGViL1mLlLcSqJidcunKg8dPVu6JQE0CbQMJ8wjfUTuGhl8VLpxgsWERgXsg
Pqopu1IOysPZ8YyhWqkpbliTCp53GFGo96+WDDLlWsO5PxOd80HtjBOotqLbCPF+FxI1Q6UasDKr
i8eej0P8QtJgoZJVRCq3Oge60BVHOcNn0C88+kUsCaQCFt2RdTLOQgXCq60gOe9eUTkImZg5nfdA
7FzhEjnnCEG5lxsL2wRYjBLFDAZwtY3rj0gl/A3NK89yxOXqaNzvTyS48y0mpn5O9/+8Z8sKAL8V
d3EMTUTsPHpxSLhUwYt4SzoehkLP1UE4uPpT1MUqDKjWskC1gOJxDpCwfhhmFSO26OBfGcXFNjaj
iQlTga+Eb7gBN7ZixOXELKgwUR5nJ5rXaQO/Tbf4cTpT26R0583/f2sPKi3375t8ToQZuCR24hfl
lwkfpJByXnrTRpESXctim5c/Q7hOXRwXTB+hOqwtQWuvf20WIK+jcbGNsuL/E+f6sYcgZhbGqYUZ
J+ipXO8C/z1VbAA0f5VUcXF2NoKUHWaW9ShIevc+CzCv6rJYx6nQk7N6gtjeX5nKjtcLNBiPHgzv
Os53qLrfyOFDbq0hOdmkwyeTAKxL/I3dLopdStNwA8dy8QALiuS9orbiwCQ+EW1gzRKxkDMwGuIp
j4Z7t31FPEw/KFLkfEP4QeZb+IK5uDs7fL7qiSBo18peusgDXKuZILYn2ldL3TtE252zOe86yRkd
BkwLTy9jbAIV03c2gHvm/1/1DF8NjDJG/dJWd3gJbCh6SUN5iTdKxS2m4JUbMq1GZMznVej1VWfY
ah7QNKMVU3U5E/+PCJ0IGq/pbg5z+n7xCXNc+eb6UYvwvjRbwsis7Vb4IQ4s2p8eOq51xl6NhUJr
4NmsYzU6b4MMx2hDVCI7/VCZdB/qh+eqvlWVV2CzOgenay0vRtB0kTXSRd+ktRcjoTOAGZNAev55
YhsNx36E5A/4p03Np4XoTQCnu+50uNE+MI6Lzq6GoqBTytp0lHQRGGBl3wgxPIVS3DqkQutDrv2P
AwV3bGjLRcT2Z0WCkqnh1vJJhI4n7zm9pdGXfxl9n2yTOelM+fT/r3LfgJFRvZavBm3leRlQ1t5N
XXCRoijSEAXv9eTU9giWTbw505igvfmkzVBIIq8M9jA+1QK3p2b4/njRZCrgs2nS5RSarw+wLG3I
dXTuqve3U2K48i6u1/UfIHvhiZ5mo0pprNQzEh6AuSkXLH/tFIaM3j2E4wcgKANEBNy2oYNEd+/0
C9hAm7KC97hNXtELv5sv1QU2+s5Z97IRCh3PNV8vgjwkEKuEWzSoqbTGrSWJlpRzOHkpkul43TLp
RPzwB1tvOP31ZKTYTflIy8DQPwZNYSrFIbMY/5oAq+4E97gcTQIAO5pXR5kcKPse3PidMTNQ46jE
ttEC+kAg/YlGk+lHTVu2d6zqZEcRFhpD7tKHskHlh7HdRkV45js6QL1G8lD/YbiVrrCw5bAEq3ON
fmk7DvYUgchHwYd/BRaTaXS+Dby341OXDPjwZb1ZTq2sVBAjsUpULxHA7sH7HMRqK2QgVCrRXEG+
MRDhR9Osm7z0drUsyJP2fVuHFgaxi9mH4irwwkpkikIF0e+hOLD5CiexeXFABJbiXDb266CmLMu4
Q5s0NaapxLcIDwh4ubKzjGiEAaL4hh0VwG7Vj5HdXwjtmV4NX4LO9u6MQOmErfHOOsvb67FOkrnm
QwQAjRP6PZZm9q3ci7K/8ThpkMFuANYkT4ocsawRVOZ6RPrnsIvF3Bozsil9sNlrxKVSS0c4frkb
Nj9JlrPuevxZkYPRhGTO4Bd/ADtz9dKu/USubiP6MmjTI2lKDBi52/y1ZHUGDILBVHj5M7+mIy4Y
ucEJNAdBCO6liGJuPUnCDUlQIJUu/6vGtutHnbN5bQU8Wg/OwqNChFYqFeeFRlWdSRVfViMgst26
JtL5GqJdd5BcWc+ycw8eaMiiqF/rE+tVJWRW2Ka+glUuo85Qz9jigEDO8QJYz64F02fbt1dox+xT
J45tAPU6n3AvUOcUYdTW2KewUE3N/l/BP+BJ6w4sylBFzyjRIbG4Bs/tlrE6WdqV0xU2uk1Pr/6S
SMK8lGScX/2JjENzKZrGYYvAvO2uQSJ/2NbU1Gk1ojRu2xKbEn67LXhdpdFeU+tUsSQF3eNoVhcJ
MvQ5RM3NiGFPZxTi/upF2iadtI3nTjw7wvs5r5peDaO6J2bS/ZuXuU1WfQ2yailWvw9EvuN4xixL
LpFimuAXp9F/GMGSNVyWO5f7wCDGZpK6USaVB54n7rkGqR2bIFbULpAi/vNdQDDRdSuMpD7HryUk
Hnj0+G8hjMPNB50qUTn8lx/ajNXPMu8GVsj9lUOcL9N6xpri/xlcD5k8gcdWAeF10tYWZZy0VlM7
MqL0YZv8Q8PhaOG26UGR2D4B3o4ufY9MEeGb8v2DgXwkH1i/Wf1fX6L8RQ88GCyrgiYBwulCBoa5
m6E5XQ+EzWBVfjxkAJ9qG1mcqCJVkbvdx6YQWnLAl2NRnvhmx0pjPN+oWNs2UnVb7TcbWhSEicx3
DoHZ3uAwOJe4B6k2mRInQrMQKJFSkLC226e56HpsZq8c+v10p35xL6eWaM3iP6fyi6HW2vqRVB+m
GEZHrtAs6LtOnALra2N6Sd/ZWSIyHSFI2jFm+SDj4J6O/CeeSWM3hHdJ6uptkaFzaOzv2nguf4Uk
pmV6WuLEDdtPc5FGktB3CYNJDYM6Wvoa1vNsxbs90aua3xZIM6RD7aASAjMRvui8B9y76KpP2dTN
ryTonN5+BlH3st9HSeVRELO1TVgt0TwLLs4ONNI7J+me1dnauAoQiv1ptXlc52oor9UFwB8G6rDG
0MhlNjp9Mrmbh9/FCyRRPlykgxwhf0bvDX7h9RXu1UOpp7ST1QAfEdwB0sz0o8w6IYSJ2qKQHX+I
MlwQi+e9cYFmxRT2xoE5uMHFvzsXTiv2SE5/WiGYsSR5NcaeCw+tRuChCi++EWHRkCkrwpU8eToP
8KWfQesSOTYrwkX1D6PyBQrOd/I9xdPmWlMiwvEI8QldNDq2fQ4v+58frcBVgbkttiAp8Tx9YOcA
JjEhd/pGYGagd6rQj6dJyImJWvSFnfTzL2iMSbS1GLVjfU7DOmoRiWW1uemdy1+4fBZVidpiFroU
ddq/dtqMuHDzaLqF9uW9Ux8NJHCaCnNpzeewNR/N1LmZpzsvCwOcm7JONwH6/y7mPf8BEbSzeBqS
VmAleAh4Qo5FNSgsJyL+BCnkAZEXDvyMlfosYNs4GQJTmfGUKxukeZfiLKgfh8vnC5ElsZ9qhXPb
s19ZSanOwTwHzxV2GqVdi8ajCly5T8tPmi3hawPzY/OQ87YNuRZlnIpjGlffNE1RZQzq0NkSZEmZ
BSUB3g4NtJR5cV7j5/imbJfPEJCte+ev3VZnOSZQCjom0PlBeoehRMKOm3eT8xxTTJY7Zr09IE5P
Ovk9+SddlIf3ozyopy838/Q8ZFS0B/duhP39BxCB6dMsSVthuQ6xgSa0A53sAUKxneoWJ92ZzNzx
APTvWSb2VTwsxNSUnc5Yhtlzbzd1Tf1PNR0MijwIGL9HroG2XrRoT1cmmr6PAIDXQIRXTMQt2tC9
9aVQ8kgdOE1AYq/viuf+cyEKHuhYf/NbxwPVofzsRDKcnjgGBmBmhcCrkEpmWhzQKtmCb0ujIMpN
Ty5Vb/SEwWv03MRbdKbaP3+MU0S2LvKpqwJ2iYUHrTlDdufD28t+Bogyl725A5mhXA7ynVm4O/en
o28mVnqdgFagpwiz3Ud6rV/1nazez6BieWdHMrW7U3tkkAMOqWJpSOPOzPnu6y2LJxyTRte+uNME
qVX74Jx3SaKB+eOw1MaF5TemUS0uRzJs05r0Nzjbfj4EuA73bqFC5DARVvkaCm7ETVsnZ3GBLZ+w
fqW3oPS/XCqQT2kLuzJwwW07My9RCxz8t/ILMb8Rtl5e+/9lhA7FkHteML9h3zl5I34tGwnSlrbU
2AZXW1g8Jpv4Xj6z5dhXM35h5GvD1aWnbX8YUfL8BDU5hGiHJt0jIxlcJLEwUqDyA6mu8ErJaVre
ykSkzZyCaixJTZr7tMOI86fiob9/pqk15ISiHAdILt2V25Q+zMGxcjTl3eNFdSJyhV+RCuB/BLC+
qovnrY78cSIFNxENoRHELm+QhNDAGV6/8AgCSmDWM3e2UrK3Mi8E+tzInoYkqHUxZl+wPh5cFkDo
6FFKDRh6+V12YHqHgdFzwa8cbQH+0Pa1NyCi/yABoLrmsad3jhb43V7c/0k+b3RmommHvNMzUXu4
eORpUE4Jz6yMrzQPZeM0bUQd4Cpo1CAs3aLcOHJ1jC8hG9kjThDank0LBi2e0TT+myeeMSzg1ANr
TeLS69BwWPzqAC2GvdRAyWEMvasB6nX9rPGdAdpDP6HKoyI1NQGwfouwPJtfiP0TmP6Kma5bLBjr
KAZUbrU2tM4WDWcoM8SonSZJlg3ev3Q2HWQcKYAFSCmJrN9h3fJMcFSGKqOk8VJAtPUwVsNZUwNC
a6LS+sb4tfiURRQdtqUi85RopM86O1CnX8Vj2BaX35/NyeexGI9VbfY1328GdjyN8RcjKd877sZf
/StKwXr8ZDoC3qlLpefXW9JJ3cw8JgLefCgwbgugFnVsLl/grkYyf1IDwjMNAU7TocdMIQTHtlf0
ELWK9N5qgM2KduF3wuGLCYg5w4U7dVqIjeghbGzCyko2CGXraMbYkMQPPzwGXD50gRIt0HPvmayn
PztmMrQ+thZWcw3LModdaQAY3wbUFLbBqX6eoFSI/to8l0+vGteC/eYkx8kTiHxIqmxfR3CsQ9qk
H/rKjfOmBd9J777QMwD4sVvxu2nCZuJNSnWn6Q3gDDZ5hfA4kx12lcaQK2I/5Nxqz088ymMF4kv1
YdFhLLDyvesfA8wgdMrbC9USltmXi6VpgpBdxLJ/0mh/4d/WBlzWFL1PEb6g6Q9RfYkjaefK+t3w
ZTb1YXaXy8+tgerWfyuHD/XdDQPTUqaexFaaQm3xJXRH0mJkv6zFXjtwQ3yO/puiG5a3GQIEgaFP
NW5fRZbvLXd0e2csM7WUOKOHf2KEWq16v8ih/fFALGbeuxEJuG4J+aTJgGeldMm9WBWchRf7lNzn
xW6p6Tju9l6qxifR+hi+X2KYWpczx9n0L/hoZqgz+1zSSGwZ3qvilCq+g5TSClsHPmltt0zDvm0C
FYSQfS0mQNoh0oHkHFvbxg1+u+oclap79thChyLWagT6lPRl68VlnQAlCowAp35nSqb9FVUAyKa2
A1PD+RXRoe1bjME91mtRUuPfX9MONb0tNl2OWUKuITvliW4/f2HAbtnEqNFFB1ZmN9mOjq3TkYYx
rcXS0W5JqD+SU2KKIfJorwWXocxmgJl0TQIJ5JXAU9p/ruQ2DCAXtHWIdDuhIRxw4vsDo7qx75oq
9MtkVV5P1M9ifAh8KHQFVBChOwzWFL8d8xtXoCoQQG3ronpKP2eaWhklJ6I2ra4ZoDm/GOxT4gdS
vMQ2FtPpMLmi7WZTZSxeSkwW2aU55Zr9dGsKc9Omq1zeq8XFM9pgFI20KyEbJqUMO6ksN5RDlxZY
riMWVXGk1hBL4p0vcjBUjLYBVTu+LHnL21DBXl5Cvh65xPinhXOgp0e8GVQ8o84tIzoAk50bidPY
0EqIOqHMTf8VUY1pDT0cGwhHIszkYUQOXTgt5FRH2DOe6v2iHj3Rqof5yILsiqbfhnRsAMdZMONH
mDu2ujA0aJ05KKtsY005rPyD6hovzqy/xx9y7ZCh+1ibMk+pTqYhgFhM18SQnoqV8aBVx3uiT2or
jvBtrJINeegT4gOPbH9JjShrI3AbK3d4CtmYKpKJ2NbDuxmTZ3wmXuMZ8vBBOE22W+3LFx00qmqI
Z2Ol/wnai0Rl1hYoJn1hr8iQ4rcVwiu8vuao1taOgJc25t+5M698ApxYNnhbk777Q2boucQM8eAg
t/McBcNc9NDG4QWU+TK8hMDgO/yaHjLvvWvEfmKaVWoCJ46ebkR7MW9cakO9vtXXuPsPUWsCWhQw
kI7YyRglJ3exd9usAgYdK8FWQE8VNyxwgzYmDPvi/K/SjXHT7449BtxKCMYQfE0FKorCIet60kdm
UnokqdcqxGKf9vzbzbpj9hmKnlRuTtXRVP9J8Uz2I9hDmaAXLGJs1g8jGX2PxpDPS0Y0Cb8YmiqK
I9pc7sKihaA2n+ZubLypX8YrjODTiRVZbv78zpBLIQ1UC8tnuxuH7l4wCdlaB2JuVHu3SbjeHJke
Zfxf+zBAQ2LOh6bokcoLK1f3C4ydMyL60uUfOBvyg0Yg6fkl8wjp+YsWYwQZV0jd/xL2MdanoR99
Fbfuln6arMiIID9aQPCN9LXl6GQMAj8qGFu5EPOLp9lL7ldjC/Vwdkslc/xJgP6fZpNsi/Y9cI3N
GjJgfHRJOVZVfVWJS/n7TdumXq+wzpdNHvp7tVPYTcJ+ncwshvx3v5krE3CQUYm16YkubmYK9ngY
7gTxLFwfy/IVv3QORcmquyZ5/MbK3nI0XY7retOY8bc0+ztz4Yx5PVWQHODA0nUoICbHU4IbURBT
/D63bVpkrcmgPhT1QmvwnrFduQjllrLdbjMiYZF5BnZ3xxMnqV6dMstlqMyuvJy4PVRYZL8++63V
dMTPdtWIKm0oQHRxddxHztm5+7Z/zM1XpsLAxfH9kWJ01AsQbH5jPF0mTwbAl+sQqVZ9fJeBMd/Z
b1UdIoZFC+e3/9xVdq+l5LlX/2CQo+T97OLYtD0K0hopt9lOOtpO7gSsBR/OmSqA5J27m2Jrq8LY
uZhHlxbJULg/TUcOZOY/qnJ4geZytLcJCSq6k9jmu7+AQayW7QdPTeNx/xQZe09KXLC+o7qxrY2n
OspVASneaBRZ/RSzG9WKQ6Y0tDJns/3IY3hUSxQ+v+9h03r92z6LR2I6Qx06I+ZPjTkBCTYPq0Nz
0jiucdsxchas7yFaH63cKClDqcCtbV+WqC/MTtdYNwiJxUZVq+ATjwxQu+oYgw1OFS9l+CtInVif
uhqPstrwspUqWFtBmt+AhnAagrB2RijF63D2zntDU/VFPJZIO4jZM5bxfmI/xuX5Nq8wJyOeUvU/
JeRFgREcy6qHKHzayBws6EIOEZlFgSJt5/X5lQkMgnw1yRxOPRAJaHPBW9B6p/ErncFec/GIFSuX
h3HIE1C475ha5zjuz2TRIqvmfN+OhdF1XMjLJpVttyLpG0haJKRiqpBLcZ5QrbAtaIMSBmHBY2aK
HtdmGyY1WP/TJetJsVw0QvsuN0yo7EYA8tojJOT2/XuviFIS2raiUmSwRswc1tKNah9qAPj0letI
Etp7oKiMaTgoJHxw2Ph8rgfKTAqI1sQDHyW+a3jbaMGTJzWx1tdYiershxZz+MA0LhkW4kx0vnVt
jttVHm9b4uSt/F8gH/i7LazedM5wFGIvO3cLCG/ys39iNYALR7Ifb1p2b2CP9QpmuwmTa28xYfCE
tZiC/V5G8+QcX5pqwLHlh2sEYBIRIzGzJIf47/BhGpwenzEzAyZ1Uj5HxH3vwmHI+dN+YZCvPfJU
qfvtMcP3GkgpUNnCfWbDTX0Wd6MQmIld+empgoNO8EZyDtm/PTK6MJf7yDgqwyt1x3jbB+XaeJvL
8cO4zkvNzreLOiKqamkEmqfavts3c5Z2XSRt6ds+Hp9Fr6011AJOpR+QhBYGzTwEZbIQn1G7V8FW
wuwZxZE1j8pT6hBTQpcCbAPvk/6y9qTuBYGPxbbymLGET5Z17eBTni7Tw0Asqyo7+i50DES3ECzu
nBihQ27SQzkJUhvUzTESgqbgX+HF9sIJrL/L8vy6T3W5H9JaeWGnatKOvqmx/sJ6wIqKqIaiyoeT
Br8l40b9inNjKRt5E6Dm6FxVkzAuax9rIcKs4EpI1f1B+ZwYaKFUp+DcNBH9frV4n7/4eH223Azk
xmona6+UMD1I1iRsCDjduQJzwag9d75lbU5Ok5UbhzVdpQN5lXtMn8w0bQ4zCfl04dbcz0YQHN8Y
L+pmNO6ZUj5mrHkuVb9QnakCn7UI43/xmTA1SEc3MT4eXAzUN3DrSV/NElMXdL3GOQM5vLtI/FnU
Jn86g/xZiORHt0D8vD6kl4OBhizZIXlsMFRmLRaL/S5QBUSKAWihLuf5Ql8H1qGLeIH1qX4lkqlO
0n8dMcIOoZJ/3Hyt6YU+5adENTl//ir8Ukucy5qCGAVcRB8h1zSvhPfwowKe+5kjLKQ7ydz9Io+s
+dSOqcxD/zGcG6E6fG58Ok1Oy46X7LCvV8oh3n4YrUFko/4o1X/kuQsefy10CH9/b2+4iPp7BAa/
kW625GDmSqx5CT35R2a5gbZQVvcgtY/Wv5E5h797DkoMau6uoCVZGdLIFJNhDYzumHyeBPZ2XXjJ
Rg7Gd8RppDXAcd4EeK3HfkGfq4944YHsDkiVMoWsIazlNOhaNgvuBaoc9njAgiqwQgi5N3+ywvGJ
CEwDFaZAmpjKyT3rvAF8UoLlyT69qTwkWtTdIeEM66pzlZ7ZlMP4lsUXCNLgOxD2qFUQm9EMsq7m
fW+120xUu5Ro9J0vWlpBI4bqbYGp0O3zJm8zpk1mnOADhmc+lTEL263ww7ANkPg7A+G88stJY2ve
abO6ZWjU2fCAnxW6M19fAgQULWamzP+/+GAqMUqRjoMa6jDyElH3D1w8HFyl2lMOiVzVWCF7/leG
xRtveVwjNrS2XLdvYJfI8MtZix7d5CAFMtfdx9FDQKyCpYDCUGnLcKIjRTVYmYCF3qbmjtFKxSe4
q4Hc8gJxor6ktisfdzeLt38JaUAK8QDQDTfclh140CLOcciRZfEXDrD5RQNriIz2OvASTO/g1MuR
t03vGVHExbct8CBARGj67ZsavkAv3qkRLiO4UdPFKrjzd9S1yNwoT2JDLeE4vIczpxn30tfg