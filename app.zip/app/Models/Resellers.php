<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpzlcLPb7cAPS8GCTUdPyPG8lva8R92+5g2uZOnAx+9k98InkwOQQxSUXZYvexwNfal5NGZ4
if70h76/awRKKerSsqv39NfUakKxGzqU+TBUv9Skre2KiVxdU1gmVFVf20zRBfD5hBu7mYKDFyzA
r87CK1nZOzsCtwiVkTfNiasHh4rvilkcLcuYTsUMujOZzKRfY2hmUBHPgKkE2EwKNd8xe5vE/mZO
xtciWf9RdViQHVnZlE68yv0ogbUT7zPF8BebscOEfIpv+5PatZdjxX50apjkMm+6GiuK68FnjQGH
K5DpotFjUjL/y2JadRtlMo7CNW2Qw91CVVJINyhJBHArDP+xslejDhVt5l+OrjtHqBv/m80njVJn
gjKSnxulv1vyucY78/mUWzzG/Ukgw1r93G2rfMG8r/E9aEpSYTKuttcyGhyPvQyFZd2Ff7bmridX
MZl9RcwQVzQVPFYA9sHE+SHsCXpjaqJPmfRN/5mATeQXv/ZDOFViLNaI9V0Z+EAL7eyNXmPIqr+o
QfJqRMHHwSbc8hrwjA7X7TXCB2k0IxkSFsARNakXDn9IPuK4aueTAARtzhN+HRXJKXPKcXG/cKhR
SdrRbDOO2Wx3vx3W8AD+le29NYusyzQTG70AFs/Gk9DeGcx1UaYGb42VXmDgrCurG8UWMHcjQPn/
7PupmksXQtqjl3B47s3LQlx57DyfSHoUdG0k1mn6PavFrb8Ao/mtCjCmKztp/WDn1PtrJE42FpTu
WFQGxPyv3fFs85IRqoxt+cBNGGvqSbVl8PF/GVUBg+FN4zPQ9lw/bcj8vc/L5UansPWEm42N97v3
6FvrTO3LvmzjQv+HY84ORhni9k4Bt6KFYm+PL9VPiUgLM6pVA5vS12pi2+YTP5+H0yulRSmEW5Zk
qumdQmL6Z5qU+2JnIAZhef34aOOq4yL6i2fBzlJExUhTrVndbem2U/VzCBjX+63kYO1CkYdCt9yU
jhIgdJeRU/d7a7gTT24dzLArQS1OW3yWT+id/U9OyCEIKyI32QCxTumnhDwfo+kK/sZTNzIsoeSx
jf/ohytWRmbAzUDl2Vi9U+26gKWG0vprTCwO49mqP/AO9iTXcNFamEDRZ6lVO8v6e48VNsLjY/EX
ptuieYSwNYPMTHwJIO0ImXSWaGMFjhZzVT8HfAcVZ0yPBxsNGIQZOt9lEQnfKPsFRpX7SPXp1lpC
/4LzZkwr0IZvoYtfZ9OHcYJbor5AFtVpTalBg4752O2T0xjlYW9m4xMkHo7/zRars6XrAb8aUTRv
ilvwlkd/rhbCNW0oTiB7hWly39G6idP2s3uGKfdm34iCq+8kyPhDMT2Twc0krop5XJuK9cGikZWT
X3utZZXumA1NsH9uvAEnRvw8k7QuflEfCg8R66eo7CB1pZ3T4Y+5u/mAb7mF3/HdCAD7MHAH4wAF
4gceqjJyvpM4vBU2mUhG+VUMsSy9pLh+GNs+BXu1HO5Um0qzbk1+QqzjENkhxd0vMtoVIHBhmfqr
dI59OLR9SiSt7PCp09i+Fwa24v7F33lC2SdyFUg8/qWczocS2T2I0CnLQ6R2Avzt0H0ZiCpd5MYJ
AXf5QPgzxbPc2lH2XSqB+ReBS714G05pZukZeF1jcoOvZd0J8bP+t8jpszlECYECa7dE0N0JVGBc
l4+0uTdstVsOMDzv9CAJzrq49pTtssRnwj8HgcuY0ts8NCT1Fa/7lNo70Wt9b2D83IQkt8gsXb6H
s/eLABnHh2DUs+BoCLjnJdrbKJgojkBCn6imKFSdLgdC4V21VGE2b6rCPVvnA+ckxPXSaH6feZg4
bHQgv9dPeODOQlkPZ811kUVC4iZqIg5q8BVvvEhEAUzHzW9NxsIa+bpUSqsoagGbw8LFKfVtoRAC
j43KJuCG6+CCh9roecoysNj+Lntev7lUkfn+GI58r/SjGB1ORZi/dQd+zu4KwDGJu3LG7GJj3jxo
EofotK+SWSNxV9UA7BYFCb8gTVaG5BybrykmYiqvLCYOK1VneuO/9Wq2Kr4YVhjV7L42dqBKBVyY
pFkGYDg2IRYzG8SgMuqBBqh0ysgu2QR/86FyhdxUbT7nViZDdgidZeF2nXYbjxIs3ZyCYLlwRjPc
K2wzFpR3rrHYLDtf7i4rxoBwgSX/rVhIYzrHZWttUv3Z+sfZF/1M2BQOdyZGAFN8DCRa+SO1NeS7
MFsLeH9tw9/uBghNdWNoSXxYkoTAf3K8sAwtdvssMB+2USgAPPEBsb+1KgaJG/uMf8aRKs/b1hMe
YdX/myQloSSXDIMNw1TkxT9mtvh0O1bHzhP9Uw2vlHOFdYAZp8LnoKKCiLmBZFLObe9Id+GNm8N2
Azh2oVTZYQgEQjNCUVwOSCl4DSiacl1ssCOo//o9eKRKOyGtJkN8GHc6jRzjEEwJ5vIyLI1YoDjT
zAh5644gOGdNrqBSIRx/M0ogAm8t4oEEH/AwOT2U9pyeOD2KhOC9iM2+p2eliH5XoM4gSuTofOAA
EXN3fIEOvApBEGzRmLzkOv1q779S3c4OsF5lCnOSZFKTp8GNuL/W08NdR0LdWAd04sQZEFimdeO6
Op618P6WERSqJlxf1DYDjiPtEsea2OrD6vWLvdeRx1kXoCl42C1ifn8EmjT8/KqSMevpJ5zY+VJb
Ohg5CuLhuEwncGBslozif4O8AhyR39Haxg5QAy5B5fQa48fia+jzJgcM8XgD8uDMQ9JNgCbHG1tO
PKIn5/OtBRSUpLoWRhR+pMCFiXvIYLwTi1Tnyj0LJl8j8PsLYofGe5l+lkre75F/Sqnte7SzeeNd
Vt7kz/jbb3Ov5a42hv3Snj9UYf02dMtBxGtY2Yp6P2NFcgc+VpMEEZqJFNvWYj8DEvMh9QhLC2fg
m5r6J2aPIW3b6qhCSQ545982WHKfvyBwYddGKZ77kbzgZr1vFstjFrvouMVGqVH9cwHCTFvQdfV5
Tj3fYs1dtqsvhb3EE6WBaSucUxoAotrVuiEDzVw2G2OUuvh/eTX9sKFwRvDRdLKU9eVKLxqNQoCL
1oYSg/IxG4MjKa0jMzRWhhuEljHc234aBYnahkf3B/y5qKHCdd0kOBNvkU1ir8PZiQS3WBXDmtgh
qYMkBcze9zA5qZ1MoCZaR8PFNRn9BEpxvO8/8hHfGhS1nBcxjEIEDMfCtIqLumPgUII6HlNX9L6s
bo0mALkVqcU/TCOdr6YfUK9JT7mAKNVPXn9D9Ys1DP27fVVsSdsvaD7y3TbCQTdpZYve8kDrDsaZ
O4IlJ02lrvcHNxP4zai3oa4/sV2cm6I6s2ywaG4W9l90to4n+YvqmTvSqSGvY4XsMRddgoXV9oLD
dGeXlkkiTR6uRd9NiyxcXQM2/341T9AEOuCUXd5BgVyk85u413hTyLMGD1flIquDyo85WoQYyQo0
CoHv/qbPsz0XqLbTxwoH++1w5zynm6b3XC7Rh51roYTY56uHkH0uvXzqStq3O+FmJCRQVEsZyOUR
RFxVjgKTcliS+9mFWI99YUregid8NXfqgVqt97h+ckC5Dwv9vReov4Any1cyW6YX4b1HVT6Ke9lv
SVUz9VyVZhbqHT6Ys8TJdFWxyrnWUSnbqOyd3X5Nq42ydunFfjMzDh8OXulKHtF5TDL+gH5UHQQS
t3YYe8IMpqkRZOu6EIY4QStgtMqJ/XamiMTLLgUgqAYIaOCCvCMw8ZwmjgPFHDmoS6QmldjyirJz
kjt6KHuSDMMvJ+EZhaASRKQtRjSc3YS/yovVRnY/9oCPZD4DEOkVkKqRxA+IDqYUCuXaCBnkkHkQ
s8FlEkMcVaM1ACi0gLMejeXZ05bGuLZvJoKOQq5vKjq1/rIVqm+G9MUX6nNgLkgoaMpsxotkyNCM
RaKxOBot6iW6efxlWo1MHWBQHOiHxMUI7XKgNlenlXwspqYW+zZ6ZsfHk0/kywpLQh01UDR22abG
pwukm/jCDYEtSSIUhAZP0CJt+GmGKvLAkt4izrYiqQMtvQk52V5SV7G0taxus+jsFeNR+4BsG+Y2
EO9+AExewBIdROFHnilG2Ebu+TakEGJZBEX/YSYRLaCXsq8Wi9bkAYusbf9BoA+1lvFQXPin+KUB
KXDsNWQC6/z4DNACbC62eMRcBepydLMTNgJCLvQTpNLNtTIodmP8gXWUSv4rG6K79MeG0Ki00pgO
cOn4fKl0QTAmgmPhAAYk4XcBbnPw+AilUbE1XNvNof0RoZCir5M/VtPfz7tMUIV2OsAWXiUgONqw
CMoBZpTKQXD3VPS4Nyj3ijUx4yahGlBSUowNVbkpwG/J2sd+W6+iffy9v8ZCIfQCfmlNQ6EzvCjv
i7P2ia+GxaxnwdV0yfemdrONENmqeCB51jwxL+QWVsUzKTrbe0x0BcT+8q9QwIVXEDZpeSYFGTxX
s23hPsP8r+LTPL8bHGJW2S12NSGAPTqRNPBAGHAm0PJXQtjx+kKrSpul63yRVxjzU8Etex2tj1Sx
VpwVZqLgy+CjnpE+oP7YCJT7R4SxTOfMAfQAK41Lq9cQ1vbt7NI3/B8ZHLcsFlNdQV4tRxm8j+vA
LpCquAaWrwN1AWrCwvtN3wN3U/6qvaERS79mwg5e90D4orIEO5xaYkvaVsdSHClMHkfOsIaoVYxb
vKKx3B1AwyUjsRep80jgkRl6kJe5oWR+/h8MLL5O3R4+cx7vENzQq3za18K9rIURr92O26uSYZl5
fw+xYAKF0yf38X0A7eYf1QU73Xdh6si5R/WUP+ZYOCKHbxVwsFMmOCUr1VaMZ7IdxtO8rsaJgdhq
Zs2R53O4Y9A/6WV/hvgRf/DefPHiaZOnGux6PN7nOsQZn67yHZbSRve+iGfRXmoPN/CFSlXBvJX2
MXSSx2YMEqUmP5VrFTHvzD1jSaJYkcF9V0KB3nwUDkzxjmQt8jrwEca+i74pJYTa/NKg0CuOnkJQ
0oGWvOet6RJJTd/WpIUIUgiMO+W4QO5VQRm/U/KtkWBJVgbuq4/LB2aPWazMYrbo3aQKWXc5fSh8
ZCoxwcwCp4AgqJyazjMQ74uQtjT47Yen+4Ac8WWVt8MKxyGCaw4ZkPIDoL6ctyIG4euE9/TqaVNQ
GmBrXi3gzwT+abGM2F3HY4VGB5/x84nuUTtFGaWPQ+p6rqqt7pkY5lyu7rvL1zxTOL2UXq9QxSPk
izDE/KWfxMUuoQ+VAr9+d9Hu8URnsk+4b0uMPUY/LTMD088bWfPelz2s494hyMPGu82UUO0ofc/y
m+6GfgUiPtSfoL3QkHZof49CE05CrajHk2oKCBVksg+S6+v3L4PoQoejV7yRiT4OduRgi9zS8SiW
XfzdRmVDyJkxv/9CgAsg9STg1Q35zove5FvgekZrcKLQpUdTaQ6xs4CvTo0LKdlyXCCKn/y9wYI7
gTT7CZS8ppL4iyRk4VVe3CUnhdIBagcwJH+LkwFe6YC9a3ZpHHWH3zEe0etWPk7zp6jqOZhYY8+b
WPyIuA9GGTnig4O6x0/w0adNspUCA3jDLVuXedhAcivB3OCOHIAZYW10CchaISsCMQoNKvuzFVlJ
cEELpHH0YigbYj2MDmPp7GxhyAAOnA+zgctSNlE2qgAdLt/903PqtfNecjG+hOZJMU1ZPIPllO5M
Mv3g625VdGbJvcGWfh1TfaP+hN22GF8MZu2LflNKtSMRwX/ZkE66OMa4BdjWchaSP/106+/mBRkw
XjjifDovdyVz+xUfgI0j8SbsB8EvwvX316BoHFydD4Ywrib5ciBBmtrP8eem9ahfzqEPKKZR2fX0
DHibR/pfG3fuHiLwSQ7xPZI4PJTwXXvm4kagd22vQ2oEV+gEaR+JrCPNnYxMxH+mJnTY1aq0wQMw
iX4UU7UEVXkCkvHv1YSAxfC4+6/5kugquv7fC5tygb80UQQUK2LpEOpEiroI1+mKwPssOIBObt9/
cvPnO0PnJT/2p6Jt/9SIMGuIwtmXNb7QqXdKbXJ8OsaL43Fil4hI5zRjxybLWzONAGLwgoQBwiES
8INQVtREStkuZlOZV3eSqqqbx4s/bCxndbUNVKsC9UJKJ38z8rTjrmQf2Rm7ATyiEX6cTW/rX+dy
+omY1TUclk5lZgjl04AJAMdxH9qWlCZiNQx1Bis1l8vuKoXb8d9Mub2yNwxanF9mFq0BLULPWUe2
HjwVNhrmrvR+imuobznSTPqk5tEMNWB2fBQb6g3DQ8aKcKni0Vf+wPF566vV2oS+B53TdMxGhnzX
UeQl2tJuphpqZH1fzwtoEpQH0wKKUjlxNRXh+AU2SCHfVUB6SJ0Tc56jaxSqModOBhZaTqLTgMn7
ZqsQc8yZse/qI72cMsj38TvO/XCjb+GRH3h+jAgiCG81HmferLH87EdmvMKtyPoNB6K7VlyKYQfS
AKCTs7po6lYHnhc/DgTJ2sDUHCau4PdmLtq+moil9zZYOlhJczS1HhBLBCbQU7E5ahwDg/RE2/Qa
VZe4t+0dVWRD3dg11auBuXU4imy7HkED8SA1siVOVFIkwFvnDd7V++ScY85LGwfbiNrYtDPXnO7Z
d4pjrLC/anL26AnmvZkDUr5fxRkoVelY7XXjtyZruNYkvJ6JTU3D6Yn5BMW9BuXX69jCIVERcct9
Dw9vgPi8TxGJieOXK2JSxlxudHF808TyHIt68UXY5dXK6QdNuvXbUq2gltDaCBLR6e9YCWKi02xo
CcTa7OSjgOid0kPTUs1KMac8fDkk/LWpsDiX9crpHWIVjdHSZNEWYaOWiNLLZvPK+ZZnTxXygq53
miyEI9zi2RS7gW3FNU8ARWcj2PbQPm7bWV4aESxMA6V8PLhw8PNn9+HjRMeRB8HDNPudu6zQ4Wxb
UCMGI4RswGBMRDP8tG8oTjG4Sbm+himCybZ24sg3gnXn52zWBUyhzhtn1MBsbHxgdS309auzl9FM
sMC7AcHSC/5KWJaMSBk8mu+ugm4gkCeE1JNdHiNfA1Djou0K1ASF4DCXtuDuBVFwxFvwyWHYEvaA
sPhfCRunFcLxADobWr634McXjoa9NG3URm9F1iL15efcOOingQIHgKjMmmJAdOwAS7rx4yJNqduo
2wqJonNbLmQcXtCVNndsrwbrg3OzD0ccdjPZbQaJaYmq3sq7oZKawzURXrjMX82RIDMWw4nWU2Nc
vZHgtviYXh1VL9m+vf5L1rvm/YkXAXPkT27urcR2O9M2FRFxuSbVbqJqTkt9vJ0EAjUT5Dl8JWVq
yypEBbxBYrplqzBSW20EUos3Y24zBy+24ql+JLw1s5Nn0bINvi0/a0B0McpfIo3/32eEw3UxLBb5
9V+lz7IykT9xMTpwg0+S+HYz65kCMq7Txv/cmcMFbhlKtc83XhJnGsW7Zge07pBgwSD7qPzl3CiI
Qk+26kNkG/mXkY6AdWcatt6nSeY0Hqy4dpb/o8+rCNj3kVq8KoYbPGz8Zbmb1s0XuQMKG1mmGa18
2ME2mJ3q0rAL1Ygv4Nq8DnNRmyWZg9RVlHjNk2CT6NmKHwx5U8Y3KVfS63AnDEIXSJjBglSxcJQB
V3rrq8+GSEnzgE+pqSzmZZjTvlQ4nR6gXUJCdsTq69sqGbqqH/hFQrmN/r7s6thZZdI8Cs/jHe6G
tpJId9Kfg9/ZAzn7VozJuSF0fA9RsPJkMHoLj5wLeyWbX2C095eAAfqswWg1WjP5oWduUTibt4T+
oV6UzNwBS58POgKlqw+a6UB62X/mbdl8Kaemm8P4oxLHyGAzLh19kQ6KBQTLKZDwAbnRakQV8N86
tFnmwn1vCQqkHYv3zH/m9lLdbelJASq31ywmhQyBEXZLjYfl6U06swW6Tlq+j0MwJqG0Ppcjhhpg
Bt9d7zltxO5fmw5gZvOsXMc6QeKL42GIf/Vmm8ms0TKtQk8XuCbD71iAIqeTjFjVYzMctrWdLyog
Qlwvus1d/9WdUuy95t7/I1NF7gFJ6VdhL39yvuwOyzZwWXIi6/wzO0n9my7oBL5evLd4fsnWC5QH
nF7nHoO1ul+6h7Fhx96dcjPAJ1QBlH0FoXKCdcw/d2KevOZ8fWk4ohO/3LK0RZypd94151D8c2Kz
GfrxFq+OCWD5/aKmy+m6oVvTCGkYS5MU4EJqI6Tuu5cqouBwpr2oYOP0VonSnDo5VVgpohT21J6r
BHULFNJIQaaK7JNgQ6Dq5VS/ZTJSKWMHdwMjBs/Huy5HFGld6KBdsMk1dhDM1p67vUkkP9PbX3qV
Yh9+Czadea/c06sXCMbncGh1PHOMoEKhT2JQBWKoJyymQpcZB+Y/L/UeUewFh7vE++YEY/zuxR3p
N/biD2W+eiY0EnMm80ACRxP4whdwzyMwUAGgSjSxBCQVwdK/TmKZUBED7MYjvCvLRG12MwdYhwId
B9o1z2tZHRtFiKRBO9XmqoYYENEkfdYqa4fAwE6ZUk1eu9J6sE+wAikkigOZLijdlzjwbQSmZn+V
ENwyZkTunMsacKhojT3ickCAH2c/shJi9Zt2xN5sgFMYq9AaCP5XWlJfkuAHEIiHFXYqgD//ewce
5qrkTiHtCxpjk6H9iojh+ueG2m1VzNapd3Q38R0tYiyT5+IMl7Dx97U7V0VgT4c0uMf1PrR5rPwa
dVCE4xak5DBtHMFqq98ABtcN/scyXdP6yPe+50m4EGeFJLsM3SkNYGp7ojgcUUz/vm7jcL5zcbrd
77nGnfiegSIkspMyWTEhjY43OuAZGrhK12aDSda9BjcbJTA32KXNUi6Qkd9ywpzl0KNDaz64WFjc
8YOKqhjO1bzDXZS/1Tswa/bZyRLrU5x9K8mfXVdUxkPD72wYTjSNYR5l1ohQt/cJhL+kojC448+P
HtdWyAO4yoezJ4R6xaxm/baXRCqU9AoOqTuUeMMv9fKiC0/+BATb3sQtyp78j+wxtOb+1AersI9i
+BJ/bgAgW3gV4BX9Qvrr1fGdlTCbf2gVOt6HVyiNBiq59Ojg3lg6hG0DbC5XgLvGrnJCs0cEu6B/
JNCIPlMJ+7Hcvr1H8aVPMPAy1x2G6XfItEUenfn2XwCPz/3cthgKOYfb/Evr7PTZSHP5NrAcRCtH
82ChphDvO28ctAGe+auaPrzYPfbIKOvBjaYAbcWYnTNY5bDaiu+m4ap/BVyZk1lM9D/3HMYD85dL
7xo2vfbckMt6TkuYB+zuMhOfjHpsWml2MuGA+AVK5SPX+N96JuRZI0Uk1lQ0vaTvTDzY9+4hx9xz
R4ALQs237k+PjolcrsWLBg8ctxbMC1h89048MZdFLCEZINJphKPyErcwweD0xv5NetU1g5grJUMb
GqYMdATOaK6JvYMz3eAVIk4+pCVXdN9Ska0uCV+cwEdD1OPVnxh7PIfpGvldhTXVw1EawyBqHD0N
5YLFhkF9AsteJzbX+VYm3nNG5m/SANS9sfT0XP9SsLdUCF11TunnbtkwqPvbdKL9dOBQn7PfxbNt
JIWR1QXDz7/4B0xwz7zbAFi2ZsUx75VAv2MH9cBfYJYxbqc3KVf7nWFk0Qd3StOGDsjEbMSh9qFa
YmnLCltijnAQr1fWDNhYYBKA/9DuGicAVxxKtJgeK0+JnSx4Z4KE97P7NVydi9kz9D0GoERc+NDw
JQDokOrdW0i35cwKYURrb9OAVEb3VS2YW9dFeLa49qDeaI5X8fjRPl16tO3MnZYiGRsfbOegthiV
RrF63au5KY38HU6xHphlbTHHzwJCF+ZgKw+8a/I18C9Jtmzj8RoI5Ocf5dmSYQZOnXyBukLI181R
vfgDaNrmr0WouVORp+x58hcxpzHMKECpRGAlxw8NMsQNS8hybiXE1Hvt0w2G28oL4AvdXP9oKfzl
IOz4nuOb4SezSFwdEDJNUmBrMfrlAu6Yy1cgytrL1kuYtNNCpEesTWEbi1heqxJwXZP4Nd3BaqTj
PBZAJBgQBGhsCh4QJafHG9SslQ8gSngMfkqx/7vnGf5Rfh/8Dh7eor8wZFlkqv42XVTlCh5eMxp7
rCSr1v1fqotTP6rvixkKFkl74bGxlmanjesD1ycTsqAmYwLStBU2G+gmSLlluNyfQgvC3jECJS6w
4xdnyvNZEkUFf1QnFH9mNrygVTM/XtHVTfxbng3b0VkewMkjFsNiVl56Xk7JPuKWIRXVMfofVXD+
Ekuct29Sr91NZh+MDE1hAwsO+S5Iybvx5Xc4/mhaQHtt94hWlWyWzeH9lWofZt0lkB4ZxhZoBe5C
35x7/h9iS+H286rDD1sScVmqA00xIr+ouUKAkFZ41nc2HpZbAzkuef51fW==