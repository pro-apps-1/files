<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyamy5K8jyYQrTjbTlkFazJkLASj1ig6aBouCxMQUUvvLbe8Q9ns5a1yqf5eZN73dHDntRRd
QAl4yOsKbHh+rtDcEQSICG/KDY2YvhSPwqNEmyNv8hcmFhiq8Ay9lEYh27dLQduuYYK7wdkySb8V
+GxaMvsh7TkdQaiCKAbpaFapXvCpEdrdgE/8nadLKFksg6YIDkr6EeXLgSKHKm541F4SKIGd9+64
+swLiCLey+wBwlcGhAcBQ0TV2VdGfDT5Yduaq6Wd/76Lpb7MaO8rknKwR+Liw8QD4fcn4GClFj3Q
SIeL/ybAtZKKY6yucdtB+83Na/erP2GQ5EcW2OaQu8MaQqqhn5quC2cf3+zaTedFhnftHgCLQa7m
417qIb3Q2n5gDIz9HXDv2I9gN9M3S/a+hvsVIJTmCurkhsbjACu4vxwcevIcyW5Yk6Bqpkv1YW8N
ze+sgFhhxLU2whSRnvx1HcWn+ElqHMv/rV+cond1BSbE1lQJeyoFq0MG/+UuDtDrSNo5j9XlOnl+
FvRjIrneyf+lxHBufE/SsafRpkeOb9sqoL1GwSnmKDjittVay957SpSTAGFKjyNi9scYutn9UEjA
onax/hhXEzIZsu5ZkyPHVc20qugk8fOp+7Gg0xm2BNDX0gnbuLVviE7J4RF8FOdlGFVrzxni3MPd
3BtgbGjXgxBTkkFwYJO5frIhK84ss+2zLVuhmS44SdyLY+KMcIJ10IL57G1t+9q7i3vqCYC+OHgI
bw6Gy2tL0YqMn9G4mkMlHPFR2ogzlHR4QDtfeqv+2D8V+0u/m1m23oKw733tCnaOYMYSUSi5xxGi
miJ5w0EBsavoO8q5eHdMOC4TCKKVpoBDDHJz4lK71qWzljICjSmAB5v+KzWt2KmGslfSQCNnseBo
mrnMVNT05w4aSJhHZUxw+VvgyGOJWSJpmdT5kDP7cf1YZROjq2OtPBUkMpxaXOC/wxlNat3KX3ys
7ZdK3D0+ka2aB05dZAvkSevLuJNqPMFqBBaMYUhnv5GqATWFRJA76xxxE9nUbv13JyRiNcE+58HQ
EzK7NhJT9qC0661qsvdKHvcUfnIiN3W3CFkLt1e8ArcwMn2j6FP46RjAJiv1VXdTp9c3dYcsLtf5
rjd8nRs5qoj8ory+zHBl7uvAAOfhaLCfjc24udWza296iCr1ASUuiHF0GGx3WsZhk8Pj5Ic88Ir9
YfrmLa2Cb8RioRu6KlPnlmrv5fjY6oxNAA7FFpgkEapdXE+AU9Tcevxx6SJf2peiNJ1pwmwkPtPF
qZR4VJDbcl6HBpKV/XHtQH98lysVtoUSDeHvnFmjMtQElGQDw+HQR6Aa+RHXE8EIp1M6CU7Qt9yA
s4LUxmdKw3jw45BfQYyPZO3qI6Ikx88v81owpNkB/tSZCYtQRbhy37SdKnhRWIbPJPtPenzqILDH
70AQOmWGK19UMxrqLPm0yelW0m0sc6NSA97c+1CD/fzNRb7Bf+VwVqwi2r2syfXWrLMnyH2iSL2r
8+v78bBO5jVSicZFcLWQU2oNq9c5Ci+7j4C8qN9vtVXtR8SY2Aunzcza1LoBNhut6F/HaQgQaC1m
cEul7cZ7itiX8GEpugfCJZJHmQnPAAf4iZe8MRFIEhJkU7rPp6sXB2pTC0HB9emTyeT0XmhBKCfF
9cg3029w+wM1RZHwTh2Umj8i21Y+i0dpRRh3D/fmlda2Fa9eoHtEmLCD9NTYyEGwuk1pR4FjJIzR
u03bfuI3YSfx+B5IQsyWZJ6rWsyHgbFW/d4b26dYjqWcw/5dLgijUyicGGx7K+nlH6uOTg3lbRmJ
YeJXFrdTJUm0yb8zdtmow21gAK+jkdhcZ2dexTUfGHrDPUmEwZ9uuYK4dHWuqKa2qdqRwhV0Y8i5
mdaUzqreXQvuJqhWyUiNYeQF24Fzv4Bj8XlIqjv8iSr6J5tI8sYhKV2TRubHvUq5RQLbtkI9Md/4
G58H4SfNA+nMD5cfSUG9mjDMXHiPeKonmjX/v1a0gIkBTFjrPW3GYQap2qqt6aaJtcemne8rPq5j
RdNj2GOlPvO8CgrEXpIWjC5jqveefN4cHVkI5P/gDDyCSUtb38qK/dEnxBN9yfukZDgCi4z95syd
8lMGxa9YQuUG436wCDqwl9UWRZ1O1l2EeMW+z0TVfRdEf8G3TBtyrIjzmSVUmjzyAcCDQk0LOx8W
YLy7aE0s4jEyYJDvz7bIJDfDfFldo24PdvOrLtWvMlUEO9Yrqwt7y9hAFKeVhHa1npswIMl75TJ6
YehwMYTnslAwTMXXUzSaYPvHttHaHZfjUYKKr8V3ZECJCKNHcHjQiqCcGt7+d2jb9MpYTb2B88pV
enm7z4Cuzob93A/G/QLBl865UsSTxmwY/mScgZ82ri5Y/f41/ptdPutwsVFrzUpCzd/ghsomqCh4
lXLdCmV8ROpVv49bgsiwXHKOZ+/PuX14wBwBzqrMqNi539MHQBwW/AgeXfNrV038euM+0tcYvjah
vfmsIsw52a4c0g5JQLflOtNdBl4P0iVKXZh8bskzbWzf4Gn7kkzGTBKCBgbmG5jzoZXbRtaBDnhN
nvLVH6DvkxAtbxFI58W72TbSATKNKTCKTbKXrd4YX/BniauKAezksoZwYk6L1ZZKw8DO0tsHssjH
JLx9DsteXS56DEo6z4LGHLfsrZZKTPsElk9LHdKQrdx8Kj2NqmCfUTDDpfCcrK1k5y6esDTI9Pyn
t0MYMUfr/rZCuRf6TXc5Fd7TLNBZPeBJ+bYCO94e9dPGTwEMABll1yUFktI3E42QV0yVgri3UGkY
RwJTU95e6KwuvhtTcYjUYoXwkTx7vI5ibMSM77e3b0jUpU/fbNYCeSI95NI2CLAotq9Y5hDb2EF8
kGbhJsAVCOZdFPMJBBJwokhoH7ZNORzamV6ORzm/gsKLI/ZhksCorawJvZb9pLZBZw+utsWpXYwN
m3/u9kxelSYxgyiEEsAqGZq3DMr83ibY+Ix7jSCqtF3/WhpmymsmezrFcDe3Cf945/DR7Tq8CwSR
9iy8a36D0Op+qu2sm4l5h3KDLgNQJE9TiGbElXg5bPtGQ57U9t6o6FzxFHGe/ptkN9YrboSdnWhb
IM2vZJfLKIrgkkSxW1P80xmRoNLtxWNtziCpA4/0PYcjrIcawjaXeEW0TOvE+gOFArK0Mm69OTy5
CgdbZOWLIulOTn8/JnfyWpGhiUv0sjQ2WaTPs5H+9hLw0P5iNjgpbUV3UgwCCYbwwtYqCQises9S
bzF4g+qA2OtrXIodP+hzs/Fi879kKgae3iX2dQPIpLJPh64gyPw6npstLD7YDYDcnqUGTQ0M0AAl
epE68pQQn3Irk1fILa4uDDKRqRvj9++mj2BCtoHhiRVdhttxZyGo/UsEWJZChxGQ5XoIfiq9lQgR
JmzwZespqHFMsH57MPapPRvGJJqCOidsma1fXiSBi5IWO9s3D9FUFzwhSL+p3FT2qsI+fNp5GOKn
Q6g9spcySUZCXglcoVp4c3cpa+Ed1kzob/ztUFFB6XgZD1BX84yOiyDkEDBnXoGB1wDoGcROMBwB
Rb2Tg4jX2uo8NMQDdkU5w3I/38+VVM1AkunSbXM+qaHd+2GF/zYDKB/AtmRYLhwpAWB9KAMaO3kk
B7J9daRcCmEMkSV1mfeGnCrVMO4lqfbw0lbBkIkx8q5kcnUZLY2LGr6+dqh2BLp8a/a+fyTmZgSX
1UHCiT/Z8HbW+lEazUFldxeLhkKQYzhEGRnXgw/sEx6Nj+PFjID6JuntpMk+Mt1fZhjjlO2FjgzE
subm4SOdU8+MAdgPQqijkVqBIGO169Pa1Ul5IVInyvFXx4rkZWtnBUAV2BHQwOETcDPM6zMnhena
R9zCRsSOsprz9Cd9PBzLeGEpmWCvnpKf4dAqrr9NxMLEi3YA+oIRaBLA2i6WOh4dTYTtpDYArJcA
TVhYbpYCcDkC8075IrEuTeFm1DNyq1xeSy8Bgv5cvP2BlBmf3Agh/0yvypzeJOh+XpHBdCg8I4sb
kkg3XgGCes4NUIfcg0hgL/i9YpeT3Qw6W4Rr9aoPAd7GFRMfJ6VmLCGxCmkhCx+MzjPKgubrdv+V
rKKG4pCie3fLqeX/TL5OExr0l5Xcmmja5WTjNa37wcP+bdClzvRkHC/33nBB6xc+m4difa/VTrCZ
mga4HCNkvoA3ujIlGnNGF+AEVzcQSp/lEm2uCj6woZJPyHCeepiXGScPajmp8CuxGi/Rftu7Nmhb
jZx8wQaksyVPRQ3dfcLHOQbKV++LeaCMPSrZm+9Wc4wgRmazuwQLEaXzEmNQ+NiwQZablQMUGqSi
JNUyUi9ip7gm1jy4IF23JkKP5e/RBn2XsJ5AmK9BRWdzBznxLDE1UfEvq8w6LdttM/G9krBi4W7n
Ezvc9ZXMkQfYDMlKr9mCvd3HOfVJivEl2LdHNO5V6EFXhr1+iyi3CsF8tBHOdUwnv7EBnTEgB/nm
V7qDfyMo7sxGxzCleFNU2d7lsNe4UdM71HcvRR07ARNH9XDtahcxh3k64UdyKifOXmIRSCjdn6Ve
9zD6j8vWn4ivrNGQkrGzHGe3Wp8VNjTSeJFXpF+GrFmqRgCZtC4t7SAAPT8CSySMvhvNxiiaSw7a
RK2edDJqTtp4IdoGqcs2wxnohYgxwM70mhoNp46WXsHSBwnnsvRsEkbHl4sRNgVD1Xqw5/ABqXtI
Vwn+mOtxmYcIsjJ/ug3/R7dvf0D5I2Ce+Ad/X19Qc3TdEgp3bVjC4H1qwKodS4yjoVIXScD9ijzN
sOVqdvndyzpeD1ACLxDIcZdKZq3W+5TOCK2Io0mZr6PTBU9XJMPGZyKI9GUYdqJYODk0Y3zCkLnq
eEeDdjsjOUvdysuQSBZ08QOnD3GRqbjPVOC/vNwwGCxe3qCs6wYjGlFngCHWua5GPSoQnhzOwLAy
7fbruRhSZQ+bb1luXkK4JvI3fC/VEtihuZfhMUDPc2vFSuwondCCK/T8z60KPpO09fIxm0jfC7kf
obkRx+/KOm/PlsoOBm1dhzfJXj30Qed/IDTz9aByYcVEYzLBSKY4zt5HwH91z1L9nrAOwwPAku3D
SN+CbegE+8SbaYlVKmaZeQaWnYS4t4AvjB/BBnvEpa7f5SmHtB2Psc8pnqanqt8gwKcXd1e7S8Rd
iiZpdDQfXYT3QF+p3qf2QfOd8qMbX3BT6vlL9yXyWWlr2CXW4X09lMfh+Q3bFHhuf9sB7ovZeLM3
qb62EmGuV7k35fxcvMTCas4t2cgwl1AiIefQgqPOnrnVePUnQEddyBhRZenA3Ol2szL5udtLBbWB
QXZcjdDqxmB/+baHDPVC5RnN8yxdqyb3y9hEXoyEisjftKxuiI0jsRSk7R5h/swbrMZjFOg33bAj
YLMB5hhDMqmffZPAN/mLWQhSpen0d9I0M6SsJ59sKcdZ5F0AqghNkhiwAjRmm0HhS+Zl2jTbL4yR
xWcLr2w7ZvkJC8/YTPXdefS/cztvehhrf3uSjfXam8EJCLirV9ujDEefP6ZB4RB65OrUXjQhe0lv
DiF+1qq3gobpKiQVKdQd3qkIQTM4KIAoQ83b8nYsNTVwDk2D8JPKEkoCfH4c1QTDAeswa944UBHv
OAeO09SkaGKqhc+G8u7Bs6Ud2MK9AuhLx0gaTGOO8MDtlxjR0ivowLNa3Z3ONse+zpu+MVz83zgw
9fNj6bodgTGwbg5pNwLzbVgi+5dWPKR23sCWA79T9EgTp+PzUNUZlV54Ez9fCEeEDZJJGqSzrzaS
i0rEgEYYgRZktisdMVVe9syryZ/9TYrSB3Fryb1CuekN3zcsjeU2DcQiCCwkvca2fbI/a+be5RvY
S//lEJsrRQfpgdyq+ObguNduZJjnED8kAjvV4j1ZdPW3EYDOhZ4z68hi4BmRPIMFbEjjpYeNwVAi
B/xQ7zOKirlhJW0s6UsswzWDcnBgryrNlMUThyCepdg8tXw4/6Nzg64ZaXYDKQqoPfIRlibvKfjK
gjUkJTJTz4qM/ZXPZbZd9/x624+RD52Do5tlL70rj6pHYIEBF/C5be2R1I4k1lnaMYlbk2DWEAfm
Wj4IUM+QE6TP4nN+G8W6CADRbn6eL/TIyti9zBkzdZKDjjEv1JVpLApSla31gdUfAMIWL18+DLlA
4V6PeJJYY+uYaDWr3UrtLyFEdrIimIzUDrF1xUt10NBLjMCdMLjQYr9BTRdtrXenr7ZY8D0z/1dd
4gJZ6PdmzBzl71TNcYS8SY4i/Ev05kxNiplDSZIXSd3513DRsUdhlapJpQxouxYNpoyWJ4PZyNp1
vak8ZoglEMMCHvxq3x+DoQt/YTLFCw+CekIFOPlpNxNQ2xbXXfh64GaE+IGcAWD2j6WtcDTkc7fl
uTnsNHiF1xjNTr7j1NB5zoAmAsf9Ek1b5B0zzptOUzVty9FNt8OGUdPWOLt+tSv8ubolpjw6rD52
bNqxe9xRnO2vokZF5KmVzfQxPypo4xffN3eJBzhQIDxmW4OsBhmqQKwbhHcaNsDbOi1jEIBnWmZS
iSO1SYQhzILuOxfotZh6hVzkImJn7MU6yqmIXy2UCdvwO0w8kPzHXwWJNZigNEU5OAIDCIjUGM/k
5g9NY8A9lXH/FhDqrCWBKNzZPM9rBSWGodTh/tv3PWswinFXn9KP7jYGC1BjxT0Qj8Pu/kjEImga
w00wUUNuK3L2coGmuQ3r0eV8XiUzhDBCvjfC626W3jkFLJSj+44jqSRnj1ihC9wozv8k3NUv9Ttq
+G1+DZSCTtiWIDgtLWZZoNbsoVYBLY17QQUB+ZANKOgUCdmqNovDhlwRtSuXsA063KfaEpzRurbc
MVymWZCukTqaeTBL9146YKjoUPX689wP1obEm8dQIOG0AdfMO3ga8bZwPYTX6Z8nAUmuGpARtj+r
fWcIS8hcl9fEqRowZBQZxQbLqPPEnSc4WduAB7misbmkRZBiLbNB4Tg08tiNAbdee4XB4uz+H6H/
jRgjkKBHkuXiZfygfcR4YHGmAbMtjbctqEL53Q7XaHgx8qO7HjR82YpfEUjmvDWwTzm7okOgEQ0q
DEtzJuL8OJI7bAH7+mDqs3KAh8ysA9h9Nwxs/0tpNysLDGc9RMDi/uG5SM1Yf+LB6MBSwSwI1FUV
V9imh2pacJzVYftbTZvYJPiTPchZiwWaMI5XOYnzaX0QUE6xsBDC9YVHaLnbHpCO+NE44KfK1vc1
9/JK+T6dID20dNktQzMBZbboNbeujQ6RhnBGoMZcU4wtJ1CqdaqTGpV8lGesYfjc6uBiE0D7ZEPt
wonHMmQ0rfLx6t53KtDxDherItizXgdPKAnPkbAq2ofnRtZe/WrZ/FXbSkFhCVLeAG72XCCuBmVv
77Ga1Q6f8+O3nJJkNWhuHHUbpbOPNtK06dmHtVr/p2f+2q3w4qKVo5qd4UTQwdKUZXU7QM0ij4ZI
FeZw0gxLtk5LWiElTD3k7LpM+dRX3did3KMxaMRibIEH5qAvPyB60HNAfmSq12+x3My3u/9UO3ja
Xy02q+mJCvuVfkoz+Id2pWgO+RyEpDfMFwPUtUybFrtTS0lyyoiLmGbMSzP7Aa1FQAOLRVCqCEO4
E1x15DD0ENW/m0YPda6Hgzc679+fKbu6k4QIOglvdUYcWcsRLOMQXvaVXQjNOSQH7sFtQDann7WB
61vW/tVnA6iJ4Ux1bUR9GqtsV/ifO24s57qjy+8/j6fRqZ2MkuppDHwaNagCiMFTWCabFTWH/Gix
Qbo21tuP4frHcXAJ2+XwESzn3PqG32doPh5kX1A4c6XRRE6tDkTscaMclb5iIrt1TFFLXhIcBvn/
bO+uVKCm0Gr8CcXcAlWCgtlybcUoWdzZ+71QzSBIAPzsAomLr7B4Y2RL/s1K35EPGGj67HzlvkUD
FSPT6RTGfUIHjlc3YzGHq4pohO5oo8kTO15wKQwKjQR6KLlaDmP3PNCYz6p/EY8mbWGIMjDDpqXD
IkwHfZ7xfUKiSzFy+KORdLt26wnde7pV5zifmfnxoWD06svs6xEaD1bBqwJm8ale/bAyVi7OWmn3
pWA6KAIF6vY2ps0NmuAqTn42eoKwsurpnN1igW5HZx6kvaGb7IDFRKnkz8JXlT/9FI45AGvBNeBx
WSqwNYGEPAlQkpKvk0JnbleqxwmpExL8cS7ZKc2mHBYGEWwGfMzkNHNbAqIy4dOGp/gTeiYnqWr2
oEC/lnDXdlAsv/d2s6BPs3Q1c9Anej0crF31wfNXjpH9DPUBgEZtMrQErbulpeQ0ct1rrSOMun/R
EfUbso5mMz7VyK90GJfd2//hP2sLyjOIvX6RCCIMDlqn900+tm5TcrAG/ZUMAeyPT1ScNegj2Qvv
bbIs+IqxI1zFD78etX/H1UffUWrzxh7OMiJ8pOCDSd3wBr2xxkiAl82lXww7T6chDNVq7x0HjwaT
hhPAjPOsTdDa2QXkYc2N9SScrDeGFOB0igHvcyXqSFG+LUJTSbBCkRDpBuvfpd1J1trbXxCL9jW3
iSCwrByLigPKe6js2892OEnNxfcok7HSyHHQKyDR2LHU/zhZb5+2AgToJ0UP/Y41i9I8p3BEEguv
URhv8M2ZcJWjmnVMcYW6G6K6DCi0fdj2hfQ8PFzJdg7U30dgQhNvsP1oMwmX2ysZkweCRnTm3Prj
WLC9yzm/n1zoW8CzCCv41z7bIYZWJTc5Zd8usLIYyeqtKNvn3lO1DN7hUMlzKJLy6vJgZGnzDq+J
1+cPsk0D1Rma7CAfJBRJmCRRyXHHRZsHHPPchE8lp6kf4KvpBcDC36u0puG4+iltZNCKWZQn8qQt
opWMk39h+s++GNf+mX6HsWDcS/2MVTNLodYl0gQMXdRCTuA8hWi/w8rLaJbQRILj5/Fdt04E4boZ
BzKrKy935S9WqlB5994bT2K1dCg7LojGJLyUEfT3zT5tPNAsBvoYrPIbdfjWHpyBbsGIo1LtFc0q
qz6Z5WXVv/rBPV/XjxgrUNigOG9tbCAvdzxpJwjuJlcTwq6HTV5qNedzyGkP5f1Lt38rSI3gajK+
GVAezAW5VLNCTHU9OzoNx35BCLnjZw/DcJDo7rssVZKI8XS/WZXT5XpEkfh4oX6iVqHumSYsrpV1
BqgYR2xAG2yYHrSOk+xguJ98wbS6EQKfIwc2mnw7CK7qLwCUhLuUtls8VAkzJTs+JDXdCaCD9YtF
lXUJ16Eens6XdmPneu0e/DizeY4+Jgh2wmRe++5hi53jDhVt5bv2G9kOxff8hzAhllX8uRYeljJ7
oenp7sVI4Wklj3LdJbzImWYPVLvQgeRslcXK3e8ix9B3OyI5ewrmW+//hYpPSgotxl6YB4P/DNIi
ni0TGffaxWqDWuMT67fyOa28rq3L8Smbg22D+zhn7DmbbR5tzz+ORUDLQrBfSgCcu+4v3ajGVj7j
HL+NvkY47MAoZBK7MFfTb+vffSfJ22XkqfNm7CCeK3rLkJ9Nuxp4WkdRQN2m1PxRXgJkFl++TH+L
DtYG8SwsRSAvi2WxuzB2Hi3wtHGZgJM1VIk1lRkjJt1J7PXvQeBIHf4xYBs7FIzVGfcMSTXb1SxR
4MEGuEzsGwA9y1TLdRzZ9c319OL5iwBzWQg8Rc0mObyQf/G5wf/2cCx6Ci7fmadYYfTbtdnLIw7m
WEKzCVY585gnuVADOW3M8PAlOq5Wtdy6AlODrSLU/zJVLq0AkPpv21zL5QuXgZCuptti5zyp9xng
qOjhvK3MlQ6HEpdJnGn+l8fX8XBGTSSRD90eYTNZmlAub2ACqOFhJivRds4Orqf6xwsTCWAY/Pou
4rbI+yQVzzOo8z7cW7RmEWuEUMl8RsJs6grVIHSxd1rXGaQayFNjYFkERBZHP2bTMPiiBgv5X4ku
tVZ0xJITYslh42BoGEuzgwCWLzJ5WUYNK2BZR7z4QuRtDLBTw2cvJOtOgW2FIP+Cg7Aag40iVYhz
pVoKQsp9/9OH/YYv7d8hWcsNncbYx1qutwSg8P2BTOMfRQF2M/fftWMfwVUHZjq20f9hLRcKkM6c
waYrqe8JaAET39pPSnGSGScM9zBa1n4Qs/chlUWmnFkxSLahJmaPb3REqMH3BFK8ZPZLghmdld4L
lwn7PKH8HJTok/d7wuXckA1fz82ZyP79OVDep8EASQeQWu8PyWSkrIgX5dCl3hXnabPqXzDQ+eqa
qbZdthAEGNLEi5+z8noD4jq5haZe3c9hMjvYitN23iy7jN6DwnZT8nm+YXVCiZxZ3JEUcpiVKko2
smWOUxgdZbW8dS6tNeYpNmNBOBzeX9+79GIV2WODkTAG5c8=