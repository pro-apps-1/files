<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp9keSPf6HhfT8KqvKeTBwTgdzK/HF91aks0fB+mZ0iIchVG77KtocxDGX5FZuZrznfGgP0R
LwVBtG9VzBBvZNqp1htvIWLt8XveC3Dq9M6EztAE66CZpgRawROzqMmGazKKYnPcJYIk3mF3g1yV
awWEmZh0POaaEZc1qRURTWoPsE2Q3RY2Apufjspb7w0el4v/A19Zqu0jj2kcDztFgVB6OvBXnm9w
je349gfjXoBymx6VEraNJs77KIb1ZDJzjWOOo34PjaQ6z5CMnktgZlZfx5KUPkHIWnkSnIk43RD9
0fPuUO42uyu4xoxcBdLIVciG9uboDTMInyDvlkVgYyIQzS5Ln7Zcmpbfit8NWh6qydR1Eqy3vLzu
rtfJCtDxLL8W3cjY3hfZhRIWw217ckRJnoSE8aRCnZBeqdSYUwjJJULZoZ0kAn2sLCR0mr0eB2QQ
OH1pBs+pXNh4dId4Qs0s8dlVcqEP1ZrIv0U+lgFKiajx3NS7y60nvPWXP2PqxHVemLgMu8LXpHWm
xGJAMQaacE8FfOl+RVjkxMO0i18H/6jOo2quefxojSmLEQe+L5kqQveXGs9eCDePuvtoGYf5jiv4
Hq82GJQy1ScHYg+IVn5qoKWPRc5Q31hTXD2zNJykk+Hj2xFCHWD5//YEsc9YUPwERXKzUrYaXRSR
HlKMvrBAC9IFO64sA24iS2/1iWu91LixKoW5Y3i6ZkPVczjSI0hMISg738SXw96DxgDBdjpDCX3q
P9FVVPAh18O384G9XBH/UjRjBoEMziCCJQz1j/pM78DqGirFbHfZ5myDZQvMD3Ff+L/As7hmSMBS
qcZH2p7zDwmBzzcpubOz+99RRPqx0zUVCGS+H6KiT98hxN6k5ZzNd/084k1gcV0k6+nZ/mCtETAN
WKqTQAnpCtutVnTQnwrTf8wVPlhNrHM2kKtazyvAsMHbnCQJpXb/oBVkv0sbGysDPpHLh8gXP9fc
o6z4FzuFlyvPu0//HbentsKEyjyuFT6NA5DDdsx5GlYTOpzGt2NUtvT4NRYjl9gqDSVM4dRiRAOT
wSWnyv3kl3AdiKURTBaihlBYHk2yLFk81vTW0jG8g0cyxJVfCKRQI7FYZ1tqzPvTwCBUOVIRofFJ
6+Cj/5aSE/5O8p3AYVygEtPIOsgWBD8qDchQ/8pSn4aSrUGCETLD4mp33S56tF4IuQveI50Ahw3J
Js/RAkmoiEDKDN97dPW7qj5i4iGkoi467fVTxIAvzxQLEcq9pvDDMIzwrcKawuZxmlzQBu/3mYTl
LgtC44p0oFxxpHGl9ubcgkKpJNGOqukqa72NbtGaH44ngawMNgrw2F/cE0AYtqGRbWpuYbBvGd8e
N+l71aZLoSV4W42zTXdwImqA0hfQvgOpnxRZolyQjcl27Icf6YQjKR5m+/pxXXQCBt5LQdBIzlYc
dq9fooM3Fi26YylVya2/rGgmsMxExQkBo37V/I18BvjzZ72yElFfditY/Yy/gX8FZnyGgOmeO8vB
Xrql4x/n/sSADjzARDVCAbijT6gTUW2OiCKGzpli5uyWyvLteJbhqnb41YP0n12sxC7M8UlwV833
DNEVLVyZ1Js7ihmH7ueHZnn3i1kL+UlxNvZMS898JQf/F+JFqHZ5Jvpoqu3Imq5vMR2NTKstPHyx
7WN8/F4USdNpwAXV/paVxHnjZsyT5zi2eqAYNL3sD4a6wiTCXXS5w/7KoOgOYWv1aFsXjEderOfu
coyvFeT5/k5mrYlmshUT32bjQ2NWAkPvjZg2cesJmDhk3k6aaLcMFbgu2eSh6keIm1pnJDwyoNs7
gw5eh0zVrR0He4CuzqLHUhF5PCehZHxdWb2lqyFGPrgmnJ66vyF09wjaLIbYrZNQYDremhojkYK+
yEm78lZb1j7RFhaVrrm2Dw1CGHM/sir7f+c//d0H21hZIx90N5uMcucRHiINe6EvRqYywqAD3SVm
DzI1KgaQQxEx38SFi6J8q8id1uy/Y+vs6q5GFdqvrtyPe26htNPnkcrD4jEABErhV5aF+KBmhbUh
NFfJPX9McSBfZ3du7KEbmK8pgeCPkeA8f8IBbrZ5wpqNHGRua19fHwtyIm31VWSD6rvmEeU9Dvmz
lERZzYYD+XT86oJ+UEg7MPjPcoJt2syXK3xRW8/iaoaokVcPdx8ENn6LJjOTzXv1Wkzc6kF/xJ2f
SX+4lBaaidPxbIa47NZgIXtDk+8hDaaobzu+Q3EKsn7EI8UczAnJn+Je7u6erkkv9PQp19zpcO7X
U7UXFv5ZP5/FKrPX+/xEV6HI+dT645tL5XwBZBPPa19ruWhsBHS0dQLb6c4rK4hjahD63hbB+NAq
oKRTwkyC0uSOf+SUy8C3v4+sOaQ3UoGNLwDfWyYrgmus1/kAXXGL39spY2gxMeJcEMCRStnD+WPF
aVHwgXQ/13XTPfU6fbDmw3ac/YDatO+ZoPjZDtXvYjg7WgfPkCvlpqb5wusL6G5K+69CRKbV9ExJ
OE/SWtFkpaIrIwi66Nck72d3KLpVhiQQ0TIGunzZVAopo+r+iTBfU6ahAGg8rfa4a4moNLnob01y
M0PlrKEcucXUOcYBNSoeQfG6uAVyUq2rM4ZSTMRHjhxJNJlPxu+prH8M5L2AIPZV7o3bTEm00pbZ
Mvgx/NfSdaDZdks/dM6TXTtsKKid/OXhrS/25dBgdWcRC3W2oeelN8+c5gN/Yhy9+jOJg2xFriCa
HE2NAOHB3TCxkOg9CS8UfkIOPbYXxaChV77yaxUqHde5zzpCCInt+PD3imDnNNF3s5ZjInZUnMs5
UZu3HO1m8Q086alFyprmkHmwvsggPNfodiCFGboBqxQse1n+RgghB2d+LACwmICblI4NK+hhXirm
bWhnCiwv7tUESjZ4iM6htWJbKE+nLWFjHH4aO0xNJXboaNO40vGQhn4l1QEwLVhTpfCN3HQfniHF
RBsNWwybEpCGObWE5ReQGuBcZILZFpfXABI+qVH+/HzhTNuMky9MaBkTZ5/CyrgkcknTqCjvWE7U
Z8qz0hfm4dotS9hyTbplxnRi94AnaxU2PP0V5t7/Et2RwTeBSfoc/Hkqt2ajyX7Ub36nzESwX/89
UAC+DPtvXJdDJ8oLhSm5CXehlay03oRoDMg+0GnM/atbX3HKCd7pVS+zcuv8Tg2Zn6WdkvrMYVNS
3FYdT2YVAXHNqrM/qVVUhreTcMkFaBlyNF12Z+C6OJ064GAvoM23cWzL2/uPQdftAhdpeUASXfuP
4lp8/M1MOKxrkDuuTFfHBLnJjJcp9Ha8dBQQNIW0v64paQ18tNpHH3krm3QFkHwidd3iq4P4aRBJ
lOoXrGDav7LJuiNm5RJAXGn3YgqGQJXIvxH+XEq5Mp8UeLd2egw/23bZC4gnklIjcelMQQz+hxQb
VVyAtsgPDcL1BAxp9ORd49t1A4X58EzhH7hQbH6nQtqGLnKR4Ay9IA5Uyh7AVmEWptBJZ25Qvn3q
h37skd8kdv8GPWbwft/WeiO427mnynOifpjNSpLZ3gR55FaIJxGqYf9yOO9CNbvLlATPOPohNB5k
y/eDfgzygIK195Ic/HczHxhBMv5NyN6x3QHrID9t05r6BSDZUzfP7BXJNHphxsotmjMzgYWxmrv+
O3Sipy4G61HXWQI9I0SL04hn5g2Q1EbPb9aCGBKUxmF64yzCQnJPSUenkUfVvs+tW19aOqgZaEOr
xBv++DRzwShevNhFSuYxvKr5z5x3tvmviSoHnOKbV5xx+G8IdU3ULbglyCrh3edeaaj8jhZx+AMm
qINe+EsnIUKnlBtKc1rjBhVMYb2BsHygkI1V1LsmmD8a/kGvL3ch6wViMyGeIF2UL5rvjDQnh0xf
A4QbeuYtkZxK36rBUNc8BDDTCmBX0neV0048n8bqrUpB29UsYoCPIz+5pI1d750v4FA4qJQirzI7
Blem8lcK5bOew/7U75e9DJ0eeBvZSgkHebm1DG/IS9NB//RhHeuL5tbBUt91WhMXbEX1/5rHSZAG
SWSa5pNPlhSG66V4KB3JqrXtJ2pa6Z729WA02FrogWS+qO2WOXhFrlPXxW+Ly93+/B4Rf4GDJ1Xh
3adgFfG7ItSH4k2aLhy4Q8MLD9VIiUribJ2NlGZj8+OXLcTQXiqHp3BG7DSWApYyJlTEXg58f5eo
hV1MkShCFvHsk3W8zO5vLSdHTCElV8tkSVLtif7QotL99uNZzt7/fwdOZ7kkJF6DLmsc6kEpPfyG
M/B5Lhr98YzDHKR5fJHSq3GibQXT5mJQEWU4t4BUtShvW+lnRZUPbyIL8bM3DaFhbgxQ8SZp6iNw
IW0Z9uiKwNpXoAdEoYL7OIGspSk9ItG5BPnGhHtUoUHO+VfWvKvZV40jLsL7dwfpe2WH7+maj6wZ
SZRPlOs7PRzXwEAnCqeOQjwJ8fqQc19TMM4k55CTwEaUry1CHqH2MRnqST4mOER+DoPxiyadacyY
EakSa0jigqLRDuswdWBviz0O90wGkS5rRK0gGkZTbnVvVqWCepqQcE1UBNMbnnxUrXdnY9QaoU6h
UH+D+o8PWffbAjpugFvGWh1LKz4b9NKFBCPSjey3DXS8yz8qpLhnKv94wssdMltvfGh/teLu5aGz
VV9dv9RpvlZetb+VVsMK2BhA20RwujQU5X6ToHs/bCtxaFqhONoURefXsC/FIzwKDHQ+zVhO4FS7
bvdtLK8hQJxpmydykrk3lcmwD8kwQl51Hw3SBSWXgXd6xJ3g40Vr80NV4bvsRPEz+9J0GhxWf3ka
3VEEe+cjNn869w7a1QDdp3ktVgrLfO/4thOgvpu/UtfudocZW+HTOCVaBEYlgEy+5rzZkIzfRAw9
2pcPxhMBNflfV2KpNodA8A5Rf68AnqIDo1Ch1AuYFvdFMibXZFsH1mzaW0JqAr/k5lGLrEL8Oat8
8yz5i6qc3FLexqHUziK/xPcTZ1x9xWei2S0Z7PTyZN6Yak5fLwyMI90x3PFHGfT5PK/EGMAvbBM/
QR3YmBv2gf6OUrLA80bDFGJg8DmPYciqOiz+HODW6sgOc8OlGFj92zFfipt6H0g6ZuTcFp9Kt/Am
hr2GUE0+FrX866W31SOPT8zBYnyhu0Mgu4lD++1qkDdWThBeLXI081NEX/oodKWFTABd/NLxXL47
7KzRTeE3YB8d1do1qqJWheSuSyPlMCCryU5xxb6o7vI0oGgpA+qofEJZXA+bCgtdnYAg2M0UY22J
cLFLjrH2yi37anc3Aay3M75iHQG7HtnsxqK21JPdgD0A7tAr8p0bwO6paGKUpBeYxA4M9Xi9L2Gx
GwiF1wAQQjkFjk2WxSFU7p2aqZyeb4GmXjUQ3nj5EDdq6ymHbWCCkxu55E7XGABn/ahTOP+RL8X3
NxklHH0xRZETzujyLL9OlKnvi5VKmSBwOr0uZ2yxIbHpqHABia6CZF4nP0p0IgkJmHuXEkVPrQ3V
rJFdrcXBjs2YHbxbLMiXZxJRVkglkad0nKqJKVyPYgy18NWHxrDCGl6APS1v5N1AYmCawuZ+KQIC
cWd923vsCM5ziHBX6p9L6dkRyjLMfjZu+M8YMrU4zhPddD8JNiqkWfEDbZbphkjMM75LXwjX+xCl
6dJbpzaPYmLbEw9wuthL5JZbXRbwvrjVMWzmhaZCS+u764iiaQDlnTWCgy0xYfBuUoYdVTHxbjsl
TDvUzAJDM8AVj1U8l20am1ec68CrvQjpigVIwC+SbtYZajADh8T9/Pjw7+rBCKCFpbCHmLEjxesN
snuXp3tmHbr7HYxYOL3NoxHqD5bRkDkxobIu5FgYuh0cFqw9l7CcRNZHgWXf83PpsY79TaKdhHOx
EmNI2P5eOCP8PbEvHnfQECAktIBlSWMTCYfTo4ZKAMIgNhBP7bT9WaEG0HAKT+WMaHWaTq99NAEb
hL2FMG6jcIOQmenFaEMap39XK4HTlvQzklWh3pbHEhLHqFjlJuoShUsq+1hClaC4rKbdQM/J1REX
8FhUrNaM9X0fOCXx8nMTXoi7DjIupLmbfcPdhga7Po2rAZR+UmM4tLSTGvBeOuhIdRzkwU18rBQ7
D6ystVkb4w84aiwDNcC0eBRjmTQaeI3PRotjMFXLJBj2FcoEsLazN6D9ktLeqtsZs1QSu3V1LWNK
iXLUIl+w3MJAKeZ5M9fDiJPQGjkVjmC0P/29mJE12nrEDuNmeA92aJF1lCQADKIxnLza+akFKLOp
+nfsNT3BmstO0hGYqqu7WtjHadXqfTyzuk9iEGaDQCiKFhonz/8oWj9mPpAEOKfyrKozZQhtmiRc
eoP0EEN6d6qdzApAV/tq+5W8NaZb05cWUflMt1F6A8PxO+HwBwshWMzyo07lktD++DS9WFA7bs02
133yh2A2TtnqY5VkT+kwEZDEh5kMxgvjl39Xwa6+BuA7nBKE15nOC1XV8jjSDTBKKHTOtG+G+mZP
Tp/9MjdObQSFGZPUm7X0zwccLruH+VFaEtQ14O8614pVayFJCO2prWzim8qESWEzjDZFPZ8m1Bak
afocCZFEyYBGaVTb3W6f/jxEQonbvw304BJZXPKT2dKlm/+7uqt7fJcTI7xb8tCltlip96ItdcpO
daOoONICy1eP7NS2nlyofDHJ87yfG8qdwBeuCMZx12K9OjcX0hZPsEukopiCD9M1Av01q0tQnwPq
kc5pHl3RXEAcE25P6NHnNzBj6+BXqi4xR9zBILLRzoGhC/iR/4Fs0OMgsM+/9WPsEOHcIPMd+rS0
K/gP2Ncql22WMxdirERyC2xIqrxBA/PvUHjJ8SqwQlpbxbauyxcTR8gm42ENPCVZGOVWbqlkdJNM
0YwVbxzJNXfOt5AhxqYUlCd8OZfBZzYYf2nug+zV3v8aSDQk7DWdE0++iTA53oZ/zZk8sHuw66Cz
9dwUuTRQ9XLlDp/GowjouP4mcJQzZoASONmNwrpMxw6kCWFPJgMF213tURAc5zY5CXyRMKDc+ns8
Afx1/GwCYx3hsiTM1I4CcHneOMT8tsFLt/fC2pjqQ/HR89IjAPfTtKz4NzA0bP5Yz2BqVCQXa1Yl
bZRfDeYQrox48f4E01AV1l+L+O0YrGBgZ2lp3SaQQu4hMF2fCWaTjyKb63YGq1vhEYSc2acuSJsC
nCY/flVX8HRh+SnS35YZUTs5NOzjIULPWOZvFZl08Nqh9s5+kb5CWakmhq1GZTeBOl3AustvLxWd
hNL8o/YE4EC1SHTHmFrW/3TjPu2dVjNZmboyIlO/LRK64dLhCW9f5oaL7SClhIi2NwIKnlcuk8Bz
51u3w0B9+lG40bYLvKgmMgxdEmydw5V9HHvycTBJZB6h4XWsYUOuEUQN3xEDpL2sUUQKWyAKT5yJ
X42sRP2an9RMaECgxvoNuVG+hjm8LkEuksdjRy0f78wK2eUKH2vFJT/4oNpalIh0eJrJUJSCoGKj
znSuKdUgCjQ4JBoJdRlbUTQkLv/qjMdcr9eLXFz3Ju92taMLUioGy81twB9SumWDWFsadYD4j4/o
bk9szyOEavpKNRvs4LawJfq1jQ3C1p3qCBl6cUbm2wHlnU5GeLweTHsCl9GDgnGm38ZOUm4se0cF
07cViS8604hy5fjp0r2XBdiPfNvxWKgPRMMooMP4nQ+im8oztPlo2+Iqo3/ZP9XCxdIq8kviQfGw
TlmRPsF1kEQRF/jC3XH3Dc4/6Gu2eusqQZiA737U50/Nu1pbSljpzopudersNjIcyrXgVgz6c9GI
VE4sD8CBNRauvOAE1SkyFVbkVGl/lwH+yf0rzf4YMWVLdCCSk/ZsnCY7BFIM/teNPyNmDQtY1FyC
PwulwG5+JjzJZEb27zQQZW96OqCGxoqOHp5DMugwhtYeJ1vGF/FBjVEfEzEmtGQYfSAOwqFeZa1A
yCrn64c94HO4joiSsltmvhRvE3QLqeOg3sQ5JhhvwMt/zmk+4A4GmapTZIDMCHBMIkM4x+Mk2bvt
aXWF22X57RtUEQGB0xwXdWLU76UZjckPu1loG6I9vQiUzjkNdOcnm1SxsTCJv0VkC9BrKUM1uJbZ
J230bpaRTwgN985tHgGIYY1+XCIpOR0l6dwzrkyqaPPcSMkF96PKbJ6HuMO7za6zfnzt7kqgSRjD
24iMpHVhHClxsrhSpxoTpLp9e2d0uNfHZXrzmnNl+yVZpgEivY3r7SfUi5CFgfgl1kxX3d7B83YO
3J03UBM4MJsRNlETb1HMnU7o4qrRn3NhtFmBZ3kK2Lw1Nqw/pYt5xOe80xbjwcFhNo1TZ7ZvPZzp
4LLq1WRfAlrCezg6aZuhEjePIBY38kD9o8NUfhbxlWG+dSUl4lmv9HgSivbvMtzWH7wUMhDPTZAU
aPuiKinW16ECTlWG4A6HKA2UbLIwP90QvZFiK8m2cf0rZQDGDYBLlvpFoYdJP/wDsEXnPxSNmzr+
owd+WJlfLgKRPqHDR57OftlYpWyvkIo0ujffxrIB9f0uLogiE8GI+wY4Emm+4TqpYQgOwgyeJ39p
CFl74Pep3/Rl7/6ZC8YGHXNoB85SPbCDWyUVsWLDnFrAzP39kHEd1y1KLdQeyfzcffosa3VDx/Nw
tsB/V9SG3E0s6k/xp6qtIri5Qluo/4NDToHS43WGLqJTqJQEIr1TL7Zb01A8TaEwmofvGtR6Yn5P
RnBKwKUTTyAQwWMgqZ43hksT5071R3MzxL++9sxCJE68MNl352YqNo4tzvFyNxPzL20UMlc0MaXz
1KE7sOeQnLD/uPqi5JYwmbd7RcME6y9YIH6xIQbQ+bN1QGMqaj/3VJRU+DXEyK7/dQVuQy3IVdpM
vH4fA8ZAzTiN6FSa1fKR8ZvHOontud2nfXKnGM7lJ2DBvILYllmfeNt5gXJCzZtuw60LvMUCtms1
+fwHg56OHFpBnA/89Yvh4+iwhXHBW8985J93xcdIS/Z/BDEWzcdTpWN0MykgDXbJzar0DgdZS15i
AumQ5y8beiRsEAiipXisACgWH2RF+G+wlLKYDmZbpc9YG6LfycIy6QrKWnRU91FdrEbTGAtAeMq/
KzesgTa3TIkG9POB4pEFrFvRh5eh9aEJ8nAvTC1bE2lYAPAzQRDdGjxYTXmt5/ugxO8qVynPvE5/
dc69fjiQbfRdHJKwAGvSCzrMbt5ghltnnEkVQ/AAn1MFI1Lg0BnNs2jFlpRmODMrcUYeZoxNULNi
FVCq9Gd8U9cy4+/InAj72YDCQvg3wxOdS9+8R+evZ+jw8H2f4DjBv/wdBui4b+MDzFGpziVBJvOp
XdvUBztG5SbXgm1jYALi8oumPSVhQQcA3e12B85thbMTV8Uk4kZ7jZ/ZHGH7atCkVfzr8lyi79hi
+dGZySLWrHX98v7+pGcWNTRyK3x8u8Y6jLnaKCX1cZNJ0M5QAo78HuY99hV4XrtaKHw/huywLrd2
Y8wyoHWMe5Qp9+qtcwjLhOqIWepgWek5JcJVKj5cEvaZD2r8JQTcxdykDo+rnOgT9ickgS5gRF35
13uKes6jhRrgHnqKhNM1hLfKBgswZoWKM60WqCiLIQbbRCX9RF0r4tt0X373PRW8Od8Nx2s6VvTp
IP25+y00QZVG9a2kZOUoWEcolDmWtrosSaKH//DY/Cw3dOwYtVa2RFzi2pz5xvK2EVBTXkZjdTs3
QwMzCw5MXaDlkwRIRVF028n0mfjF8SKb9eci4UnTGGVhxp6QX55abv3fgPiY2fl1yx40GTIcq0j3
T/YT2nz2XVW6CqO8Q0oHKAxitnf6dZSwn4DHoiKlG3gw9A1dHUxtAuJvpb2LW6VS65tcGStvPs6D
zJYkZ8OmEgHRjsQFequAZzbfhgQwEGnQ+QDJpOiMsGFLI+YtFLZNtUkcCcgmLO/d35sozMNRVECT
tb8iZaw4ZEKvDiF7OI4CpF1/1Qoj2EvRlffgfVMIjwoCuhqsAYP2R0mMlb1YGTJXnsiYgBGl4Nty
EloBlhr44PIyCcWVK3BSAGWeAqO8hGYloDpmZeSIgbO67xeJ+uYpJx/lqjux+90P/3YVMlhhaKsN
NK6SZ4TNCQdrG8cVZhE5ukDxCczgbAAXjaevstNMP6ZlhxdIuJeKoqO0uWaDOkVm8dvV7946Mc0i
bn6MTkPfe9ShuOz45xig9+bR82l6hl61iY7BZ03+YGUhfFNtAjMP0+MCh6A5HKmYKWt599n/800G
GT496C39935WNj67W6PMNfX+IuitOPhFGTX4+bGpTSz90MerktymZv4I6bvDlnvdLJO=