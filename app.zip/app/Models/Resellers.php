<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxch5/ynNLBiy1X0WjonJFC2Zj0GdMOoa8UuBdxoyVEW4gVh2CWBTvZGHgM6m41SmCOgwjLQ
U6s9imrNcA5Dawwcf+n08kxPmWqj2m5K8qbUwrbfPK4Vb9wlcuhpeek95ijQIWxtHmaSLbtkxgX2
YAs4ftpRKzCnTXGwXA7zIgFuthAog4Sw1BKVChubeuBirGvboKVURlNiY0AtrK+7+O3bHQktbEAZ
PbVXo7mTXn5lvOXQhIlCBwr2n9Gqcs29CJyCBFA8EKV1kGqKsfbxMrk61RTftaD5i4Uaen2yinvt
kfWV/qIFXCrrbQix8LJtiW0C5/1Vgcbidbm372yGW5aczF+zkwFmV5qzeTXIXnUFAaPbNkkb7bCW
LuIAbrCzVDsEf0LK9zmII4wR1cMsU5/QlrSLu01d5VnpXQm7h89f4zYBXzSilPhizBrEJ3u3uhsn
IPpNdMTMyQwM+7hovIPJCxANCI4Zbm5JXnocd2fUMQgGevMPpFGn06sryGM+9tReCeouZP2zoNs0
dgM2wGmM68xwBV+8CGdLlwwCH9xkK51YQyzYE4CnP3IFFTzVBOKnozfawL1RQJdTORfLKFmY8lnL
KiJJl3+fRyf2EM+DDsHbzR/bGZkxP5Eyj3IFRebpdbufdlTkxeueEETljCVjWyYC6pshRNMWvjcY
OFSF7TixYXln//SD2RPTgO6UHGpLONrvV5fUno5SE+ytEG/40v+mvfKptLjtDqJSPnDbzNHxdq78
jrJY9Xi8v7KewlaPiztmDuTcxxmJzGkNB4cmU6KEf5G5pBvjjGKX+hnscuLp6UgVjhBGAxt7o3i8
vIzrb1WWOS5NAIDNnfI8WgyCJ8trdf6muugaf6LvUm+8eLUK0SaqxvnC+npBVjSAzdT3L8RopGwu
3EmrS7XP4PqeZRU2LTl6aSmKmQCH0cbBH3zXVBaTGbre3yYeEEbGiQg+JD0lxtCg6BJp7+UNTSsV
xh54nXKZJp41wyse8I+7rbuFAr5PniRm7nSD1ol+u+DkTpSrx4/dVcBlT4YrMzDW3YeuCM7LdSnl
ZoO5JJA2klsqkpXOVRp+B3InNNlTwiE9GrP+7FYfsIkGGXNWdwmjDV9pG/LYGeJl4psMtkgLpRXY
zYQV+kGe+Y8EatRemL5R+nOSbmhz7XfPXVz4VrX/4ZRF03Wc/7lbjRAp52nHBpGWjdvvdXzaXZd2
A1ai0ntdUDCBYZIbVOcG3PAdhGIfIWMxYriOHQokJUbhAO2QMDqpwMyrd5JhrKUqwbDcDtUXlod6
l7IIdrRb/b+7OkdRy5Y4ttx1MmUPJavGHXBbZdG6I7Ft9w7b+Y4ZBEX//tNSoXPChBoBE/YfFSwm
rvXsKQshxqYKEuYUewVt0lOvOalF4TvEX/1gUpemNmpBPXknpUgxw1uAyg0ngMFHk3QBimhcIOen
zr0V9uWmGGOwNAsEGEXIlNlk3Q94H3h6/7rkpOhKXG0K88WO66SbR1QzW7cVtvqbxRLGyBMXwHp8
7fGJHononpNGHl+rbVMqvrkuhb/nNdYyvxIR7XK/ksuj3zrNNt2BJwKFyN5D+CbuNR413fYSXxqJ
xRuaHxPT4qLzhz25JGLzBz/IvONHmYXuZx/i3rwhMOgH/bET1RtGdZQ2bzRYOy7+VGaT7FTP5CGQ
ycCAWeAw9olTJ8R9aZt/GNnj3/0luBynxXGBdfN6kJy9TNsDc5kx7OWKyonGOVPTYADuZ1OBJqbU
3Aiw45wUX71lCNP/VQPg6EykIOKtQJkMBi3MXmtgynKd+tSm8H806oCScp6ZlFV6LzGX/FS5gJAD
jBf9iB8eL5pbhv+DEri7kl01UKgMKqRfMH4YSTQG9tDR11BOvbjAb4Kr3fE/dFms9haYDNaBgzHI
VE6WxSC95WC2owgA5aUMihFULyjY27HGQjOndvQyfweN16EyM2w/a0j8ZDulZvvpxVUwUw9/cddf
cROo4ATZT0QVDUdwJQ1tvMCcUMpmTtjAE00ek7rsMUsJVmNHbBjBTAUiKDF60aroNgS/ctlTO/9G
KwwrnAuVoos4x3akavjaz9bHzolW9Mwb92csH4hpWyJEh0sQROaWMqigpm9/IGE/YLnQVnZtM1QQ
9gvzGRw3bb3bJbSY6rnrRSbFl1ckhv+1eZCeWWCmZX7ZOnyfJZqTefkssCv1mJOsi6MHxf5Yn/5c
ZZGCftP9H+r6vWOWbW0/XA6y4imsGTkjARAooT39LHJ+AcoZfhAtfgo/r8eM9mGwxMO32BswjUft
DHJ+AGWrAKxrg91EC573xgUvzWwuutX6Yfnva5LwAzCo8BAgVrwtMH+U18oOA9x6u6IVqKi9kPHd
W9thoWXbRNA4PKyB5OuaOVeDLxtwA6IyplWPLBVSkgqQJO89K1ua+bLzisL2F+V/QDIGUCAT0nvz
dZFMzIzUmFdp/Q4kx78xypCUZP+rMrxCJTNrgrmf8Z3wp2Cn1QcQkywOJrBquJBRbOqtBwTfwDOL
5CjU47esSRqglDVkWN8P8pwW4jbRVYWrX2IYpLXM8fu4A0ZVRTew6D+BBnzW+UXMHZYuCu8XO1Vj
wgp7t1Wg6dbf8QlBkoCCoNAVXjKi677SG296w813dRUINoMbtHwrUN0Hz3OvzwOEj1BWMyj95BTS
WSrvQFI7qOGaQ78N5dAurNcr208IFz+zdVWcA4BPLZZvBwkcNo+M0ZJnD78dgqWsJmt/+SOE6js2
ETXKh2l/OeIigYfxR5jhwQFTozAgZ68Aks/9QowzuXw16Bhsa1tWYKy+4PXO/d2vcb+7zDBbnlDG
AdV2JoI9HlEyulyFI1FgY5tpKOJ2txMR36FHJz+uRsbci7kNr0IUt74xuHfngeNI2ogQqjiMgJrV
Sf8ngWAImmL1atw6V8brlPzfTjZ2MxEWkZl9Jbecb8i0MSzJ+qE6q5Av8kqQdgh+2zmbo1uoehmf
XXRFvDA6u9v1fyATJHHDwx5M8FECIE4Cy8yOK1fgQbe87jgcZbfe7GaCzESo4Yy+m5zPgh14CnTE
2be8yh+xe80QiTCmJ4ejU84mh/OFV//MYRjKY4UbAuyxQ0gPNvozh3Ya2PinpTbMbDF4j5/bV3rb
CdgdQg/F95z5OjvNNtEC4I1ECbFUihYw94IF5sdSD3Ws8RxLTiUzt5HVctbwn8NYpXZ47h+g7R3P
XFS/DH2JQtG3V7lsp4/cD6o5Z3fnmyotlj7YErX5A2mt6EexMXtKzV2hcVbHa07p80wXBueUhE1p
f/JXOAdgCohbgcsOOQPwGCTKnH20WMq/4GO99+AilQ2zuq5gjDkD0B6owpTdQFeC7vC7CCzGIiMk
LQtDADFCmICixsBC8MQt6+L87mibs6bl0sb9wKPZg80Fn1h2UobKTU+Cbe5U7adz59T8/u6tE0Qf
me3X2ssP7xYTHFrvREvL7QvG3wY8GFbOMjR2LThsS61xhdGmunZXt47IFNlssat59p0bfPZiFTx8
77YmKhXBDRbXzB3InJKGvrGgDg/dukRXzrw3qRXOD9ME8t25J2puOCg71F8R0zBL8sfdYE9PQVqN
Sq7pu8fWr3LC/NMLUdIpaMdG+uDRBtTbWtDbaDnDJ+nFW2GTSasJt2UKtjUiUcax4LfeHn8awGib
L7k024DkOpEae3K/WahZYSUM2wTNv3qYgfYp5QJPpkH+azTMsT3HCeklelVW3AmW6dINe4wxFHjn
7kPrnTBF5g9DCY8LMKNv0RCW+u1WHX7/l8ngIDOVbjCM9AIzchekjT0+AWX2kOekiFNdVNVrQ710
V1BfDtvPVQYEvaHRHYx6v3r3R3LVRN3sFV6kVAimwVh8T7AGGuldxmAFeDUyTUb2bya8S+7DyLe+
z6wTwVJ4UvsVvET0RWgZTVg4SFsahCz59ClnnpWoVD1gV3SOCwAwhYmcEzxRTsY+aSd4zGMKDKEe
3++dIAZr+I/0KKwcfXSkizADMnnhXVyg0ofLd2ClwYZQHkK6AUr4mPt3NkAjFswLlMOeu2awiPUC
WFdEfbjYcokxDg/7tPy5ob0FdhOnA5f4cB/78JPJAIyQl8UvybY8RWfnjhn7o/AkgP0lPFzi7uso
Gttoaflbm+kFcUkwn8og9ZrI1RsUPBoHzTzhLoi3iLLa8qWsDrPOCDrx6NBgHm+k3fZDlMmwal6E
pYyQkg5bNU2NSFuJt2WDtVMtWvUq99zg+wLCUoDbBy2/fVn+UzhNx35RrEEFWQhzzlIwpdwYhtN6
92Cw6V3+lrqvKAQvbcwKaNKT2c4kFQHwWkyUcW/WVST0FpMcT+5Jv2CTexxwORBfa0LKlp8nOvcW
zjBUjSsHdozrXVuj3KEREPIzVENNYuq3fjwoEOUdfN2nE2Q0q+0Nzf38mWL0DpIiicQx3GchAFsP
SFJY3xllw8Ml/jmVsu3TnwYcLgD19FObt6mkORzPp3QBDSl+IugpeOTysQn65hyQsm3PAbdz0nRY
TtWQWfju0o1E+vKF/e3o2S2wj0Zk6s7bmdQS5aBzdIUBCrTGCw2WbbgaH0o6XQWNLLFYj2Bk9d4I
1UQ3mdaa9vWTQXLWbfkrngOrQ4wqP1jAl7evBm0dGD8JOvXJM96imY26Kz/x8WOdH2Q2pNsKxsPH
coACsYNw/FP3nEuj8V84KPhVVP1HSp3f/b9DDisOQVbt+jXd7ZBEFzSlTj4Nr7L/t43dB7Awr683
Uzu2oxI897FhZPELZNXA9XM5r2SYzMWXjeGwrQmCGHG778pA9ICVMmNAlIsmbiiicatRztdmYN8C
wkSHLNWsBte+Wnd6aXjuUCGX9Xc3c8YByocs9764/iDXa6cjId+4PDqFVWJoa+z7QPMadWO8dlBT
TUwLDSD1ewKnlQc4ERBJxzhjyDd//Ppzbspk/UDm8XuEgb3HZcJy1bYO7w4MIwy+onv9RTbmcdu2
oprORUm1EMqss8xkfpMAcvzugC5/uPXOVtd+cAV5j9P/4ZZAuk8OFoEN/PJJ6z+ZXdEUmsroy5tB
+WFjWHqSBvfB56Xx7+bVFVWt+2H5djEulzMt9yg9ttptNSrA9Cu6mel0D+EYxXSYeZ41taEPlBaN
GdyQK8v1CtW0LFB8dtdJD9rHYNOspbn8P1zU8x4NI1tWPlzhXLmlmccVcLHn3bP8A7kmGBCHgjbD
ZeXRGc48AUVSu3vfovmjurb/6Yo7KpIqir7D4qBr/KKfYrTkhk+Im5q93OFMMlnEA65yOCLfgvg2
a4XqtAGqmdNz6H6yrr4r/BRR8WxLi3OM4amKp0S6QMGfYuRCS91pig9NuKmYOeLmSzyxwOLgbzWe
ZEAZ7GZSR+xuVOjtFda2FrBEI4vjP5MGS1A8pqgDyqfZ6wdop0ORf/H4jZbflvdzXMUoyaly8PNP
HcAOAqYNyXPosopsTWpXfunr2yf19/OHeDSqHSEZTjgfMCMZrHYMqM5vMvcYN3HEjtO3z8GlCVsl
e7kwnX0+/pZapl8MTHK3TBvur9Gt8krvuETJf8ESj+lPq9XYYejUBFMt1lsuGKVaUFtpZoEi+5Ag
ZQl8HMkKGRkMlX9Tzg8h/cZKLFVhGjax0MaWJP55sru9ItxXarS1xdM2C1eJfsh9pRRKQRKG8bpI
jKzWxjyPs47xgaiumy1SCOL3QpBucTgKqTQSoVEfWdJ7mvbgog6b0fYeqNBUdBjBWH6d0TbdDz2N
9lvkdKZB+/guiW6wIHcb2iy7dgDcmasNHol+d0DdyzBA3TbyM+p5Wx8RD1FuJIjJrMRXxF/s4mle
k5Y5J8NJsxu9I4PofA4h2J5c9mpdZEnUWlraYOgpQ0TmNMh/Ev4DLl3RRLdUs1Z4pagwXGx4+VQt
M//HcWHNvLUnDu9wROQii607LJGmrXgYuz+vB/us33VXB3P/mkhw0Xygnunx7z0+qtepR9W+4nO+
KJAsnCLJ0ryIebWkpekBhQiKP/Em52pE78Urqk2SZ2znWjf7UlMSMVcq1pDy5F+vIxYXnhfmL8Jz
cr95ZjBfaao0PsYD4LReSVSlv6zA6gqHhmBH8Hjxr3DsEwhUtFj7WN28vvNn6zojj3j3v0XFqSjk
wUv945PeDslhy9UokKPCcKf+GPgVZFtVtcX/OF0nh+c7DUWJ65jQAEtCA3MDcksYOnEjxWZwfEt1
ZgRYins22Hg5AmlqZ71kp0KHkuWNQo44X3qtGhixXW2VR8ahSEImt3ll1cyw3vm1mth8IgHXCVm4
5bbuzPuoZ4ekcbjSVeqh5mXxubB+YnJTpSLsDdiP/dYEAt/2vNejyEtd4nDiJdfQ46mQL471HP1E
B8sYkS/HHvXCBlmvq3w/88BICJlHacOSm7jp2W/ZDMfLy0VZFGy4zdeKbZNDIEm8s93nwfVxohYs
rL/vkND4sTft9rtJndSTMm0YqhsdcAMf0+xdxAqf11YHlTNe/mJjTegBeezrnbAerfjQKntqNomz
MQ5mFyjnNwsOGJdVxI9xGfsdM54kYb9yd6eXtQiqSbeTCjf+amXGqrQfR3w52h7E/jV46nN9+jGh
YNbmw8YIrEu/YldZNmPftFUn18A80lgRTXMfas0vsEAjawmOfng/YmUGcTMy/vmavxqFbNbW3PVF
SSoaGG7KOrGqTpBw2+9TOUXPkOyi9hf7za9o3rAVUqdZs1Le1AGf0EDdwhpbjDQUsaXHHSy7t+aQ
UhBlGJC8HIcvDKLia0HtDgRmXIgrJWhoDIFQyldxpiRgC2TeHji8MV+xmXowaDYrwhAym0/mVNTk
KroBmx4xA7AQTS2ZV/upHHj1g1jGjJgGe7GhGQzFMmJYGY/j63XGy0Ge+w1H8i4xhnxrWOHIrJ+f
dLLzKI1t/TrGQH9EUMnYmVkk26RD8fOrwbM/TdADHDfQhAIe7WzRVobAKp51paXeu/3duKnWneFe
6PkoVEwOs0EooA+8HJWU2l4CxBBgLRhz4t1WHBFhGbuvo1u6VxBTc9fwOFrf/KV84ajJ3eMzvkUC
/HqGYY8//y7pYZDqVH/xLA9hrft+EulKTEzCy+Hb66XtNEImvg9pml6itGGBLavolTzHkDznYSTr
16ZDCjOcsgsMPvumwmshKvK0zSz2KiVLzKYUoSjwCxErzPKAcN0EpDBhD3CH4thobtecgYGTLNmq
gMTsixW8EwJM6L4z7oafo2ttnKDjFX9pA5DidLTNXGCd29ImNMyg7IKzr/xbmpij8FhK2pZpRJy0
P8hZKEKd13gqCQBqvlRrWLavse2nGXTcKehy8tifawtXGAv1GSBjYkLx9Upqu0Alc0yvJv/NoOnh
Qr6BWYCJXZOCKRolpTi9DBLzdCkQcZLWdUbJ/U5NCDSEOyIJ+EvVb3kntOFPYmJ4wvR2p3aLaemm
t8xYJPjkgWFGNiFo7p2ujiVVQuRajW/tFVMOfesu6Q2EInfcFuEWCpdfqglj8FGlHgolNVL8pJdA
wWxB1INUQ2oUPnPUu7sd1W4lUboj7AbkEUh6rxE6gp+68SC+WzlKUXdDiAao1SrFv16HBfH1lFLp
gC7fxNuggmJMs9k1b8MOWBv+1AANcxHXhR2UmX2JJsvlZqnEK2zwjw6z0+kJ94AT6Cr7XiVT2z9s
wVJGKhOLB4BJl+EHJdBQifsGIqOR83JH9zquICT3kbXRCGyDBIOgoEe43QvslsEeyIFyUSZHybBv
A/eKrOowCwznz1osgz5FS4wkO2Dsb42meiWevYXY3fCz4OsbKC/8E7oU1RaIxF1vPEYmiKcPbwgR
aVi9hgMoyBmTJlmdGAWpxNMM9gt8YIvP8Y2UWLyJKSXogloAKdgOgj4HYoGShwlhn9JM1QO3Dn/q
Fg0oBI5SZQaNMEx9frhOdIRjLiM62GA6v5vI5/5YSQkjEaX/ALQr3k0p29CC4VJMIQHRd8Wx/3x/
7vTeJ+KrJNZMAiKeIQsiI8dP2Y6ZrNobumhqoXrESlAnhxuwOOBOo1FYuAu/24pbh3YiBWDS1H4N
2/K8POlmtssYWCZKlGWI6KgoiZywiLGmdjgRLnaxQkOwiH2TzysRE1afJ6Km/3w9hhOly269D0p+
nSob9ysWySWeVh1cTxQZrrttvgEFezYDMsGQpEuLcun6rMw1jokvQNg9oscG5jxozhvaBoVXL9kY
/IyeNbHhcDv4b8zoD7UdRfRXU+spB8rGGmfpkFDmsWy9IQZ+yqy1gZIEAJ3n4ovxvHskK4By3B1X
3i/hMyyqWN3c++MpcHALaG61YnSdvv8TprQrAFyN5+DLKGQFzTyXLDfyueXPBTVianTqH74+VnX3
iII6eqMAFfotfvYRZeyYFmBhHguWnQx1n2Gi0UuUtIwIKaTEDjgnxxcGliXEYmD1ws0GqD7CMHt6
jwhtJpedK1j1vrZQ39P6Clh6ip5NsvnFGgGRHr7IEapc/VcQBHmDNOcfJklU/y1geH8X94uZgIK3
H/p44J6q0vDfx6E3MGKdmb7bttIFzDEPc2hWdZzcPiCQStI/+kIngtxB7OOdEJ/RoxxO58UecnjG
b2O7KbeL6GnLPhqHz1SqKHrml3G98fAjxQjvss9dHMWQqawkLt1y+BEtLhN3gR/KnCa3L3PiWpyh
v1DSX1Vc1Da3xX0Dy2quQtAkEleF2nmWW4RgClXeAPE2VVnjoQCvSQPGlTtqhzi7PTV5I5M0xCad
k/DiCIbCfGN2WdDhK+K6/Ivz1alzERLa6VXG30YUvLhm4v5HUMKEGTIaZTYRmyivQxZKkks8do/p
Tu2SDu2Iw500sezB+pgnxyDbpRW9/6czGcOE4+qhV77aTHCCiUjiMaO+pSErcZ9bSVBO1iUyglRT
dFFR3QfJGsC3HRSomfDh6unLkEBqJFznERFqsrnp+s8PbwDeke6o0OCLYkCrzX/MCxz7y7n2Cc5x
hOjpUHhho+9hInBsFMCZJe9WYnZBFRVV1dk4hyp8qoswEnG0qaK/pDNwsMRf4iAOJnuH0JARH1/l
4Nr0Yl9Ea7oV/d+/2HZIyGKBzfTB/ACIp0b1khM01Qx174xGarMo6N+qeq3Wfim6tF/Az32y9Tmq
sXN8JoHCyRAnyx1wDakRAMA4p6zvjOH9so6l6ql8hiB2zkGSeE8/4EOzImsLzpYaE96zFmBz1Aj/
P0w38x9BkcSQMFfoj8UfzbMp3ehvb0yNYHCMpU7QmMAxUTG1qqiX67ML5H1sz07+ZKLsH8mbwxRm
7e8j+GWe5bBjNUw7ZiXir5UpFk8nxX2UdHXj2RT+y2/1/+DkymnzdK4WCzxyPSuS7kc0DusswhEG
ivpEO/AWQdMrmeS+JZ1rvyYxqw2dp+3MJ1wcbi90rKFqGX/kX9xW9eWFOKF0UQrjOnsUOp3o4EHn
ku7geKZRm8c3t7mZdCn9ROpM9Q/FTDOmAjcJx9FRcQejWy2hMtweRq5Iq1U+iWFQNRNDx+UCcryv
4gTzCKmB3PN5y6sA61c9LoZnUj4dAbT2mIkvnAeeZJa6vJUYJaXcoPt8s/Whp5nFafVd6VwjZc1v
Ms6lK6HbOh2bNpjiDZUj1SDYyritJx3WijKQsmpJXeuNaqnnQYhFr2YXrQjk8nsAm1RXMsqsBD7K
VBhb/ifK5wwjPOPGZFbwnqmfXr/Z4yKdKVx1RZ2iLnXiteGiSAWU1JFO7g6Kde8F+GexDhXcPlGr
R39Hjlw51aKZ8enxMmn/q/IajQ0QJi8WjE9UeH8ARGwFsiKL3dl2P+yEUV3Awh/5OleN34MwrbH8
MM51EM9Jh2cYyTknWDikBWwaV/A7YurRLKLi/TjNz0Ulf63tSUGgkfeDlycnVHv9kx3djUp4NCv3
OvA41PPsUiQ9Y5uWswXuv5Ye+xKZdG8hcGhM9l8aN0XaE1wFvRmZtx/rVfnmVpRevffrz6cqXUcn
tWqhBfluYBi5ooaxJ55Pyb/U7ZhvWUakvIBJSbf8ffcUNMJVPRx3L4zHG43DuAwR9zBjU44kmjYO
ZvFdswxX1Upc/SM/j1uom0V5O5xjEzWjCniPKk1xb/fKudbIWi9joUB29OmYNoJWNPK0PYbE1oK3
Ld6QxgSHlDYUUdrwMsJ0+Kw/i/hJ/TopjjJTw+WwREjKi1OB8WZbbx9uf8ZLFIyGNY7yODVjmLAi
+IGIMvC/cLeJ+Z6RdK9ACK0OVQrEQ4paARjDPDvfot4xmcfdv/15+Ab7USN2ldsrqM7xHBHS02mE
xA+ouzlVxu1BAr5tlU+RY/fYftIus7PdMW==