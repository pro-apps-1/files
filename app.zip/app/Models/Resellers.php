<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzDtP4riyrnZQP/nRg4V26nyOVWAjAy+DTH88jKwlkqCEP1l/z0svo3HBgTrBo3aZckS0yFY
dQAjiL8mc4MWdt6R8ckGEcW/0B5+38lFQZQW4h7X/Ihomc1wQkg7tUBtK4n9Z6zG1y+ZJektfN+o
qssq2h1Xw6s2cm1Oyr0XqJQka4EABtJs/gKwuKAd8V3VMuIM5uPSiiT29EtRYrLbewcIhre44jUM
fQIJkQ510RH1n6WV9q2keyn5sc7awXoWQT5nn9Q0jGZOLI4Bt9+YPfU4E1LlQipukcbhDnrxo7JB
4w9gCHK2U10Kfc9KrqS2B/Z/5wfR863GiGQHM1+J150DoGZEFHxi6iV342FxM8nj94E3xsMaraIN
SraXviLUEWja8JwJq82mNbdKKJDIvibWAFXfJWzJXmGnFg82kDl22WDbqWe6yrcxbDCHZYR3RRxg
X/ukP7PE/ak9Cfzo5gKlLNnWjSGAZZlHDnJH/U3jJsvRhiTnlLAvRkxjoZlAcny7M0fT6fzHl7tG
cz76Nm6dd/zKLGv4Thr8sFIdwa9M8O2SYTY8EG0e/z4NyysAqc6SsJMLSXjQq7DWcEFiP/l7R2F6
4c8nMvjy++estGCxjbMj4K467iCKu+/+Ruc+aaqGd9X/rCWRcfPp/vlC5IeGH9aUx/JpmXoDYcAf
y7MtA8NSGE/GUQ2HqMt9UCMMmS2hll+salgnnbn7iBcJTb8R4TK/kvdOaFrhrmJ0YXB0DIGr8zo1
NcKs6uInBsE8FRKmv2c/9N+9dwi/W5Tft3bCh/PjgKDgH9YB2yAGiSJB30XGcvT6p74iYBqLdurI
cAVOWvSINYRU06c1Aj2zfTPvgxcjB8jB4ekY83RSKRaXpPUB5/dYKuP9VOIsOWtEUljOKGvJ7orO
ro755XLobpwc2ctJqu5CFdVBt6k5Y5dE7312qChj/dKNMb7VXVfq20HaL3Tk9RbPHjMBUPsEErQB
tAdMJcTO0lYjFIK1seNUVrJ7BSfrC9I+5WRLk/dTN5PQT5dm5p+bYYyQMMRZ7/Ez4Sl3gPqCEi9T
iP+2w++e4a7VHhCgzfoOjx+hMgwekXx8KfmG5SbsV+Se2kag4IGU9zNbmpsVBLAewnXxQPRrs+kn
EzuHab8bcB6UTuR22+UEzGG435w1C73aBBFZY4UlzVv/1GffXYTqUq9dX5DWLPIh/YT6WSl1yTL+
e+jOrq4Hm/F6UztiyVUzO/FZypbzkwGsOM9jpKlw99xt2NJ/CDT126uHFe0U9gJ7HGgjW0PRwgVz
kgrYxoDdf4y6lKPBcNA3iW7zi5Q4XA1WZrUY9PktXPwHwDnJKT7qBYe+syVECnQTOWA7gu2/Ewy5
NaOIKYKDZVgZN9Jyau9MB7O6AAx1t2mWkxjos2+E6si9MgjSsaVitj+VUUU+3mLVaELwGbKPXqfG
vYU+blz+kydKfT1EukSoidc23vpgS4LdqYqp9CZav1ORLMBnVRuoejlVOngmu4rDn8v6O0lrCInj
rloErAp/Pb3YEDYheXkxrkpOswEJ03uYV4pYrVml8mLUEl2t9LKVWKIuY2a8S7MITvxOL/jnpHzo
S014uoqDG34J231mdGmt4VDesHGjnR56zPdjHK3IM0jpGRkt56UviuzAFIQNVIidgKYSq//b1hOs
JVZ0dcKdnfQw5KbhuZs98jj3Alwg4Tj18HdWPqEfd1Rohrd4FPwzf+g3MRBMwtNzQLWlXVxjNbX1
ke7xC3aQS8olyYprKW8k059lLxPnmOp4TWglAMx3EPOXDLCn9sKDmGhO2HvA372ziNJlC0YEsHya
hoIPsywGqqrqfqlbvoTKK+xc6S4wjDBrl0T2sxjXO6IZ42Is9IyrvN8S0Dgx8QOZUKuoRqKDLLhv
yt594Dg3lU5TkRIwG2CECT9nhalQUNom03ExMGuM5Qa9QiI5jJToAnNmsXGHA/raUaLwDmaWGuzg
9JIlpyMoB1ApiKYDicqkjGFW9stFVzCxlh4m1L/As1xwByZkQJRRQ/lFJLRnaEMD15MkmvbzUSih
6WIlKmGBFkt782DQTaIKbLs4qGj39rU9pkSAzkmUcdtyK+niGLPwSqf44a+I0iCkZzRK3toTd9Wg
W/JtUbaYLuZ+DmSkhc7KsIx+WcLfpqDIj33luLYSu8igOIfPx2ZRX0zRo0IRFj3YYUuTqguzt2+m
iOSm47mB5MzF2nfc5aLUVPU03kM1Zao4PLHQZgY8NY5coYcjulhaRGT/iNUh19fFiKsuqCA51kkV
o/efBpAXlNfs9uXov2/euEYx6RS9g/BFHDP1RRPcnlMAI9IPd783uvXnyTCzGTcLHtlpc/ueDj8E
IhiXMGm3fvL1ifLWcO1qM91QmtifaToinX7QdqqQHjKiAWtFhAlikA5N0Wwf5Xht5ikO/x64994B
vuA36LzVAGljn2HNQ/O60h05mZYXcNmfeFsdAL/HdDbB65+Y/hjvrKu2TnRekEiuecE/t17Z5oAX
fOOxP/fe4fKMoFY/xwrOIX4t5m6MPlCp35C2Cz8racPkLaDkhdPsEliXevapUnEte//S8G4z4Aub
bdSI/PPEaUGVctGz5E/uiQesREqePHf3N9796eMffvDedUPZPzVHIyDyizOiLE4bV+rC4cGcCOrO
NPYQGYqRihqi7ka2GMl50lcF47/Lx9ucimqiVYWYOIZaG1CYGHW5thXQC9STtWlsY0ZTFPRtZdiZ
m69WYZ4fB3Ord4YmqGic0JHR5lWBvWy+yuvi5RiqXK89o21m5KXpRW2Rf3CNijfA9upDUEdF/DtJ
gQtI3Q+fbQXYHS/IbtKeAv3HjQafq4GgDwWGdFjHbVpw6PztYM6PBcV/Tn2r0BvAARBOusP7vdjj
9aLgETAwKg/csNh4UK0rUvPLHuQ6ASo11Ee4d3TFKwMN7mux2n71+8ASCLJnQo2zsUykLyCzseuY
TTAkssVRBt669i6ObxG0fXHDn2Yg8pQt8gkGzdO8ef6KTyQUE14Ct1y2+LUmvv3TXl1CX/YNvLpU
yogakxwUDa3QPItodRRNUm+rPsNuoy+s3K1lWtJURtuTRZw1Jd9ONNUg2QvYm6bb0aNFOZyUoRlg
nMx/I3L3y4wnRmtuQU1vkiyHUO+aNPrAAalBwM8rfBWun2mRHFpe2SD1ZI1pwQswzMkH+dUNIt8M
YxybKzSu/Ix8qytnYwJIehwOO36Ma7GDXZeKGFjy9c+FkV3+2K8VlvqJosFGseTsLkJbk87Msylb
GDgBKGsMyNOfNR/ZyLbnMptSLYWBPbMKJcy3OG8RFom4MqPWdvjFPsrkR6bXp93TXJP9aAC0xJ4C
qCJon9NRIKIL8CDWiz5S24R2CxeTj+aBRslcY7Ud/psqZ0HXt7hov8sg64atc8WWZ0bF17VnKccS
0W3qttPDOYweM/p5aF7fJmskcSy1xAuO6uMWj1VI8aMD1p2dcJKjW38vTQi+zHx08/jKvhUytZCq
zqCPJFivIIxCuoIHArBx0N+7C1rSbB7896NK1XKGffCU7lKTJpt93G/VQhI25Y+vMRHD391ECSgd
gKZkp2457SCA+gIXrfUGD8nYFGvhrpJg7JLoQa624i+jnZyWfLSEjYE2JRUiqNUgy1owZvTSK2I+
fDaE32RUD/nnwyZA/eCfv7RsDjQe5gplSYFJTkqxiNn0HPQWtvOHuAb7eP/79uy5G8QjPLw1noJr
wPcSXYoX3rZSHyx9lz1id0SsODnSO63ERLyCL1HLrbctRPpsCJcRzV3GdsK0A+hhnJV+vENKmzXt
4JDhRMiZ/yLuHofgxgSQyiDD3r+tWqBGQVZM+Xyn9+NrCfV5b9GYqBaerOoB7ytEWuTAoFaiXEvM
J9y7FePpu31k2cOAoL1E+BpqNGfCpBMGGItl5i0thqfWFKyDbmOIYErNj8LQB+CwcKZVKm6isyaj
D4ltXncVfvp1iKSY7OVCC7PO5xlOcFbDL8RT06NgyHOUWlop65hTlQWkMqF9iuSmNz6iG1eZeia3
wmxsSoEzUh1p3QcuAIjAqH1Qd8z7p3WV38MrRHLVF+FHJenaTdhVOKFVHmWsTdE5dec1AsGW2qWi
MuG1t/+QeEXBAfE4m8b8vl7s4rERYLEVQIwox2sAsJ5nZp4UL9oTIjJrYZD9gkMTGB9mAMthuoE2
tIb432kG4DiAaUzeX/EhHykdm/hgwE3XKtTYpa4+pT2MWn0Be433k/35OLgBXT203puceKjN/4UV
LgxdzXParcBX5kVLIkSTV/8obnq6iHnd+9QHncYDszA5iIYBEhdPRO6DYxOMCG0fcEuJe+EyTd/B
s5vDRgxB5s6B6AtukhtJ6lREOcWfwi+mrC7RUjBEt3ZgV8ZfULYZJuCYi2hVDpJGQN2MfqxKl6cm
a9AnmGu6j46vXCYNmzX5DDOEB2s0NzYxWSeXpb+8wtwvYDeK5rqfnHpfk1pwCiX2kEVLnCw2vtMN
SJNpZlcnx4NjV79FawGeEqdITedY8C+lrVQYxyTpVs8qkvT1+pc7GWR9sm8OsJ1RQFgh0F8MGWLT
aebaBorB0HpzkFjkXOdZSCwG2051Y6admJEdNLzfa8RgP5quqYV07pKegEK+rJ6Ok9dTtcKQrcYw
HJb8/vx4g9ATjrj3P2ZSsM/f9/4KM+5UKQuzv2yOBVujOykhDDWzEQiBj+Ak7bZ+4d0K6s8Dy6ik
nlaYlQo3ZRsqR0CiHOPe6OWRLX1twnLiJYvomLWe7FpCCloC3uBf/jY5xnnkn48NMb6h1wL22Poi
aNkQKniH/MCEv3jMXBHgBZSLiGCkTsUo04e4rwx2OrHOmTiI8y6a7D2K9odK2ECwjC8pdmy9Cbz8
YkL94fxXHi5+uoBdFPumO/UjxOzhlEm4fiIw88MnXPUIDAU6nj80MQAJ+Ey6g50bAaaMBynS+1it
XSaw3FVjiqw5XI+Ml1TwqDUVH/iNiGfOEUB6n+u2+fEKmeRCvDJ9dbybRCNvmPFZ25jM+2beh6XC
1p6Dd213iCus6MTStwmRbCWOLv3mI4lTONltD2piyDaeH7i67dXhtjyjQHApUt0fvBwCQWQKwn+6
ffeQVKg4k4aTnHOkNwepmqNIU2qgOHYWs3dj39VM+b9nXJOUOkza9e6g/Xns1JcpMiqsaFrSn6Ne
Vmk9RSI9oupyRI45MlaQmxfGSYK0sYR4fG3iCLc7/OhED+LSowufTXaxBFpwoGzjg5pjsvPzXBaj
zk1iqgqFTyQJ5rYEBNLDxpqIdVKEpKHvpoUZxyyDut2JtidmI5N0H9ZFP25FhWBeWIQwitFkFLz7
rXby6vE4/famw6NuLHpVIjeknJ0zvbu0GMOoo2h4ODIJ3XBJYtDCiHVO8dSIM/GWnpvU2UrO6RNa
Qajd1zMvVoqhxj8Mo2AkLMAILAUKxo60+VWawFWWJ4YVrrvqJnZYNan2IRV5bHAvkeONDH3Fr6Y5
60+mKyRtNRAadzbXbQSMATWHFlrrNRIpfUg/F/RNMwSbcaz4zc0DAsIWC+jwvhp/x5L9QcHHyFPn
VF/Pea1UsYcRROzrJuKDAXISvvoPyywFEluI+AFazxG1jTm8xkMCYMDz/Gl7olGRaqlubEqVrAoV
mmDlxdJigiN9f66m6ZEcY8cAceTJKGiRFzo6V3FgoO2+bqntOO2qFGieBxtrXI6u3HWL4E1olLzY
mTtBh06FFoI8QX3OABIQhZPC2/kSmU7LBi6dqMtMjMd/xjwnd9f5kM9q8xdfFG7dR4WVTpV8l5H/
Lj7+aukOOkxFH5G31FUCe2OMH63Ioje2ScPgbeUS4XqCbkXkj9OIT4jQY0+7+oN1QmmY4QjROXae
DHqPvstHNBhtaBQMsE+BuUE7OR3T+kQNdoZLEKCSrQ66ADkTlLwkQt6fQYp9HvlkH27Pw1xfz+ZF
CGaXfmlNvmB0PFnRsLtM8wlKGscIh4muLOeKzwN9O/GHTHYD/jrVw5HnOBHY6XPQ4vXIB8ukBt+S
ti9XkW/80nmcnKnk96sPkGiAeO6+0xCI55m0C6qRXyWT7uN/+P/TJpychGObOdvNIJ11xFa+Pasn
lf83B56Lzd2QxxoZLBnW35bfqPLjeN8YoARWzyPr83qwZIewx5jE8/GS6pDu/Sj3CMLDjyWQ8Rhs
Aww43pLNsKsQzwbo7b85wPmSBYavv5twvCwLvRU51cXi5xlqM1GLXXOAY7EWs4wANJkPb2NPck12
8c7lcJP+aAAgVq1Wf1hz3XX2w2JYUwdIiN/bLQftDVdgias5+2zLK5BaaQlQzXXOxiCdXId3CtmC
wg55lWsc+KcTa42R5DlNPVbzjMQhVOWsf4ZaeltM4v6zM0p1stVXvIPtwZYw2FXeaUh6LyP9UmxI
hUCQ13fyWUddU9Wv2WeSBLmsbiTsW2wOW9ciOwaXAqY9S038/+tYNm1s+3ZByD7HUo4sVhJpgDc+
X3ryJOqIeKyD9fYKjvcGn4VppKDGfNIHoV3JpFbnCVbt8lQVu/3ZqWLfR/v2Ls/ND9hq8sZFr3d7
542rX2G4+Fn+Km4m9/xVs79z4zTPxEzqh2LD10ZAz1F7sXgk8V+evlbZOF7sXDEc4Mu9SAtd91qp
RdMYtp6gxLUIKPFsnbvAsdUuhBzibNRK/su2yjTzUr7kqkqvKY+VWCbS3ZvoekGhK21gWDH5c+P+
ZfKris//lEEp7Oi5svxIejRWyceE+Ugs6m8QAo/Vpy126486c5fyCnS6NER1jEdCj/qtgYzK99AY
eoROBt4EkQJuTFzBadItjdDWrSRkR5e8yUPnE9QVAlfXhYv7YJXd2IUc/p0a/a0huzZ1mScIG8JS
0ZU8pGMX8/ZiILnUn6e5SpLxPsbp/RnGzHFfr+HhToGiXX28qMjNArKWgw7B7ZqETpUgKoIcmXfl
nzSQG4DsOXb1/z3MQleacfq4WHwrWrciMwFq9GQysF5sZLBbCts8KCyWH7fKTHrh3kD/rZdQ/pgZ
5xe8XxBmFovZu+jf8XZZfdw7VHyozSwSebvmLwO89Usbg4lCXohZsghprK4OJAt/fHzF4dwIKYpf
XAsun7i+qSwdstIzLsRMRhukXkj2PXJ6RxkDbxXCxfMTIWfFFjeGcB7S7njd8PJFVDOwsLC+mvgn
kS7jMkkGo+ilxmvAyodSQsFgz8+4K6GandX2TN4RkzVQekRWc/b2FjE9JKNzN22WK0x2zmryxMs2
6oUAjxhu2cY7Vr2MLGRSAD/snhsgn+crvMYOd4f1PL6XwV15TWd5bRjfM7CxpO6FETB2IPHc0jXe
NSlHau8oW6JTnH7yrLMEJFxpyaPDlWhcu9tgACU6Qnz03qq1Jm0DEWwOBIEpwQKXGWZOuTfYBAR1
m9Be1Odue1K+dbLpOJ/S1lCKTY8uwGSiW/N0A3IzK5hFkwTcLc7LE7l6UjY3w+J0JjX0a5JE9E6B
JPa5gLxnzTPArPbjJr5HNLx0Chtc9aS3NslLKyZsAorpZ5b5jcy+GTSU2SzeWgljtYqml9GZmi+3
t2CWJBENkDk9g5GvEmisPgVpdGbpeqyu/+g+bpi6IAF9nGhqv1VfFbi03yy1wkuIa/CRLM9zxl3F
0IOuW0MQMGHkHQgUV0dxc4SZi/ZvIbMSp38U2QYeQFQplehIciBQhf+3FYFiN1OWguJKWNh4P8Be
acXI5Bfe+RukVQcJFjInezaIBTVpLU0raan0mKj0GJskFZr/JbATXmlKGZfA8HrMuBYblkP6miAt
iy88G8SwMG92pkwZNAamriejdIFwJTpkHCU0mWG1HeNdIwLIhstmkEo6WHZ3gxtasnlUTiaMkR4k
VLS/UgNUziUGBY68YjLigQXYYp/0IFbBEaPSi/D/Wg/AepGUX6Sq66PKaC+TjFxh5QGN3TFy+WDk
z/FOuGusXNq1aZbofVGKc5bXAA/LBf/TCrd9ziyYvQAYlkPMmcpJd4HFZSYMZf54swDLpph57vcz
l9n0Ji9ZjLtkZ5gwfNcsgPVXj/KSo6N7D5186E+eLpsXbyztQHjMnsTRmxTeH7GUAkjESchv09SB
fBPMvl/pD4FUBMDCdblJbCnnUvw4XWs4M6RKyGNbptKB2hFd+EyBnNftavzEcEjFgsROPVtH0lwS
5IXQTVuVSUcpkNc1I5xfq3SVFSMVwYEn1b8YI1eVdCgn+94Z/t+rXoQGLxLuODBkC1vlYIPd3079
U6lk9NcHyVTxzPYwYwC3jDT3gxu4OCVxwQz+E5dyhvKPEWtPahKDZffJhp8l6lZeceCa8I0lj7xI
+ERjg33gSju4lAR2C4HvTJGhtqIWIrCLWoHgnXqqMBD0EKZs6qbktgXTaZCDtIM5EmtovQ5mOgF4
5arFT7JHn/+fUZhX5rMm3LOSBQ/8tuDKs9q9SSh4x8MWp//X9OrTQnhw2D4XjdG2uFBGQn49W9Y8
nl8Iy+wqkTCaLVx3Grshwt6uVsZAaXdl6eo9DfjFZU84UOU4YWNkGAwfvDFVcRTnMHi4mQerddfj
Ug2pqAuEu1zngAJQ+RS1P3gGqOCteDp6UXji6qctm+nxjUFAAsddCTiATjqxooCAEeUroABqRO+i
K2B9bklIIseEt0fddP78NlYSleuRvFeaDjm8CJPzr5nneVDRRN3Ir6PtNRSB3fhqT0hdN7uGMmtD
2fgs6lyfKj+WdMV0TwSz6pxcfSmO6gD9qS63ZRtcjCosFkDkmGsV+Fa2HIdtYZqv2hRec/SuBITz
quGNI019trwzE7fhlTHdFnKa3uXUYT2HqhaLH9l5D7m4/8Ltv3I2buudP6P3g9Y86RJpm3+ewLEP
rsu9K/r3q4tPMrMsc0OxssBJ7jCxhQl0zv0CJNMAhcQ8LlR7b6mwqsuKqvaFzVxtlNMplQS6xQui
erElFkKSE3AXZPNdYOt9M1W4NMT7txiMhaMHQeE2+6Re6/j2XNwOFlPsnuiGQ1o8r/BxPMcoPAAS
i9sXmop/TkSOV5SzTNnZUdJEc1lrJl6DGUJvAxvf7bfs28nZT6UPSOPsba59Mr0ef+cfgUctT2bp
TsVpbXMB35OLY95k+SopabHJNme21ef2KxMChC8CustmEcVJjYsDGp19teh+lmLEzoeCWXcieO1Z
aVp8etXVHryd8lmzPqOK0Q1Xyns5KKEWJ+Kju0==