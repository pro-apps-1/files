<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzsBxn21FjGdN6DwCqmTRmbwy9xOZzrp0QUu1Zk4SAEZ5Ec5JStstQ/oRayhjzHseuMpvOGX
NYxVn3tZ94O5HZPBJpbM64GY8T6+6LznMzUDVTzwkx9QK9iYCtqWZy59grRzkMNFdzBq5MEavVhm
XfzbCrgoFOL1fTLWVtjCa8huMAYdG1Ua6fk5r2z/ec4V8nwUtvEQIPCTmCi+8SIagAEamKaWo7zg
6j2Z19iuzqW+8oRclRCiSbIBbBiUFVMVO1SzTXGh5tW87FW/i0pF3kQEo+9asrBluAc8iEfDRVpX
qKfzq8sqvNz1qIRBy74346q8lQMK3C4T6Hc+6eBf08Ho0Euwie4AA4dtSb3r7VcPfBvZi2RzHOOf
MiFSYWqoYd1HxAXO4z9rDx9Yl/FEaUuXV/1LShCLmskGpGW5yDxVGbuLoOpIm9I5SJBVi8NLLKOK
dTBYphB+9mhhLaGtMZMCxU9B37lh1J9zX2/6LTwhSnH4Pydi06ijDRxzVYo8KoIdWvJobXe3f1r0
iUp8qxw7MgPiS2M2NTbaK7PR2vPAnGUa6Zart+Yn5fKd1t/C00nPL86THISkYQAf9yiMs1Q7ntle
6Mv/J/BxY7FKWVbHy005blb1MUWfvwy3pHxTEoxpC16Qw3J/seY3/jsiFUqbOd4iG4SQIT7skA5z
2OClEYJAxgGmTnzrpxZO7hLk7DcHEzcgrkB+CNMysmZhP6BlDhtcx7Z92ek9S7x/R8KIXUEgiwiQ
bm7mIGWAMjO3vS30tK1Jh9o2JkmL/zOE1Nnnne1+CuapHZ0uPHvazl52dojaHUZ5ofw+OVa1gK1V
xnC3IwZsyXv7TmLdIGKhtk9xqs8B3UK7VWTPjWVL9f24yXxO8ifupq20i8Ok9+/Pri8PjrVUbf8Y
XegqjDHrrU0HzkbtiuCiJ0wO8V9qDaq5aURsv+Zv1tM0JTBTvDeR6Ko7a6D+bkW7nzKfAXZ6/+e6
dtkUCp5+LmK/Z44q49TLG0UTvhXPKhP4WDqUwTwws4UbatQPoqDOElXtvGtvbSI1W3FuLpTPUuih
aSu3ZN4nK2mtQuOuai+1GFQOZn/pehO7QCT31Ix0E+9sRlLzppc4/0f77BqtUojMzQCuRYR3kGwG
FeT4RS3Izdg5u4gJ78z301iIS32haiZvo8qQ3FMvZHLYZROTNB0ezOMYpPDB9FmHA2lEFoHVNR5J
jqb+tzBzWvz+aUGb13L8U5aznr4JktQ7/U3ll+bgUcGtMxCtJqRUt5SnBQOniV48NGnC8SePbdU7
tWeaGQVgtZAGjoqaNnckbIp7LvXqK2CXDjsAoWuJ17FHdiTd1/sQVAdGrdPLo8LNKzjSNYY0jtq5
Kd9g4/0rHSiSGll3DX6hZrcl2cWKZC4G/tEwPPclQ66qM1XkcUfA10Iu1rAFcrAijqic8LbowXt4
y1U7oZ35NFqVe7Ond8DotkoCXEelbMnxSw3ATnPJhnoS7Qyd9hixfKD+MjInDQCV1hzot78u31o/
/V+/8rBL+qJyr6WViwmHFR5VFXn6qeT4df4HXVy9HcMtDfUw1igNfpf11b/9ZdWZ8DuSPoXhcu8x
//yAaiyEn4Oc+bEF1KP1pnv6bR8rDiCxLqAGlGyMZC0czwUriUwldTmODDSrqi3pbpA3qkepTGNf
wHELbujxAx005LKTbaC7D4Y3AqN/stESTcJ9SZLbkmtzo0abD7207IYtn3iFirQ5g7wci7Qdn/km
dWr/4lwGhkKb8WDbEqTIMcExj1dVHRGVGAgvshUCroMk2j4E7DR7/UOa4ZNLQm1HnkpB3IRZd3yx
CUi29kVsA1hsvAUfbsJBNMikY0DGxMJ52k5OGckf/R0R/wkEQ5te65rUUQSsOupiD+fIOxU+GE/j
gBoM6TWDAtfTeBNIJoQU0AiXRNyxoZtSuWNVZY0vjNd4KzPS90t3BF5/fPp9UiN29UoU3VeG9mg9
Sf9sDs55zaKfqZ4TO0EFua/GXmQ3Z2G/UoiIYunjZmINd2klCNysM0cX0yEZJy/LG/yzf1r2emxe
YOR8qTvehf35dXcgb2D5xjISjVdHnQJnCP6t3/eqC/FeE2DGm0RIO7XKhkEOV8kymzCZfVb+Qxzo
UCbmO7OWdKtQ3p7i++XS6+lCrSHxBmLOnaOjqxyHXrplgIEXElIzYxfRYpO3H92S+WTmKGSW5Ml5
XhXsEc1NK/XDZHH0AKBFaYn5PyWbKhnZbApm+v+OqCHncWBBnRL10/AK2XsLh5Vyow9jQrGJ8OSM
WeCaIvSvRoyqDBQhTuubyf43R7j9ceCinA9gToNxPOitZ2pHNUmYBmV3iOQTUqYJynCm2q/WH4ok
oOuAWsQaX5JvW38lrT6RcwE0/CD8KJ1j/EPGFiQfAUdcc9oiuGnnGOy2Z+IxjWvb+UfvxQNVVtju
5ND+G6+CPThH9fOQVShg4pkap2o1G2JP5S1o7zMYpYb/m2LAQtM+XeA6dHp5q8ZAJXLaQVQ2ioWx
GkUUxtsdzaxYtK9nVEcEqLgNgKc92FGDGK4N/8YHKIxe2lItcuiIfeuU4h2xRvZ6eEO4niKOisn8
WUkkEDZiC9oy4MdTZtniR2tJeABdyszEqb2BqrL562GpEL20JOsXtQjfe3XF3KcAZ5W65+lyOf87
UxrdFpyYgzeZgHxkkzYRuenDogp1yIozBQMde8xA+3/qsz5HuuACxt+KTv7uWVv/NABNm6rCxHaZ
0sP3Dd/jOEF13LFfogqXNPRsRAl3fbYX1cjt7RhAyQ7p1UQPr0BR13fEY5oH8DLvs+Iny4ncbHgD
kx55OaOVuZ6noF+aRu4nmh/kaFgIlNdIXRI8iXX88euUCK0KkcCnX8gs5LR+RA/KRUq0bvAAd3k/
xtV5QSc19hgectRMucpzA2FQZZGkN+V1z/uQJTwo7T5BR0uPU5Q94cf1bm0OnD6oGowWQtOol+XM
FHSmwSArhHjQZFvjorAXu+voHm46HomlK6C0x67BQqojKFc3E8I2/3dLDmFp0RhjqT0tngLzCfxV
Q5JbxDlK4gP8vZZF+M8H5oBUmloEzuN3dqaiMBtKKHu6qW7JJc2l+pN6uZ74mS0dB5vyJyOgKGPt
UcV9CHAHzt8HSHC5VXTI1FusCF4P8QZMU9IIdriqFq3grhV3E5FhDKz1VomNDaKDxHC3PxmzfexR
TXPhjzYTCMdsK+iemF49TkVQ15Ggp+h+vPkl636sPHAtWqy5HXZXjPT/6ynAmCYMGTrkrSB4Ac8x
bCkrnCOAc44vd4bNoU8neEnA0tclcDm5PyX1qCoXujKNHoVY18MnUZ3hVBkHHdNXWO3KfV9TJhAN
bn7zGQnTUDFhEG/J5efmoFpYifckxty+AhwJk/PjvAWFvHjPfpVa8oD6dj2aIP5bG0+YrrnBI95p
yb/UTmZqQsitXcwsv6DE//31PvIQQRsE1ho+2G1aIky40LmK7161FHqr9PxueoJplr5y6vBqjmDd
n3FnrVXfytRscDoMoWTpesyfNk+staeQnMvjcOsEZL6h7kTG9Z0scAwFE4Gr3TuaHsAAlwmGPLPQ
RzxejzMVjlr0NifDdZqehRdhq8QpMT81OXGay2V5wnVwuCvG0CpQBWARYlOjE4mD6vopssPXEXM6
ywYlONPIiFnLO7VdltfqbfJ2l8+p7nxlVUBohzauTBN3gpFvtDtcIwDjenX9wDCtMgJMkJVz+f3R
Pl4arlk3Errzp8Iq0CHz94feTMP5U8AZyk7yTJgo2DLb3Sx0ylsTTstLAYP11YzqYYbFxdBFg0nN
/MHfy5kbvM8UPO4q1n5sMYg8RIA6bM3My7V5OfcZcywPwW5jt/+kc7yDoHMWOSmPEi2kLeY6cZYz
oShSHrqXHDPjR3Cmzyx3Wjjlt8mMLpvkfoxSs3Cc9NXZb8aRRH8kPm0f6+fnMZrkqf8LOGSJ8h3O
AzMKLqEf5mdwQ1KgAwgOUua0P836chEJD4R3vad9pP0UErT41BpgCmaYqwR/jHYQ8iC3BxGjoybX
oZyPTTOMi2rGFH51nnG8GJ5JBRO+UI8F9vFx8Nq4FNCQwLZSuMewdDTRaA3nVHNRES6SB2SNiFnD
FpsjUwER9yfQLoSgwML2u89x0jIFOCnI3sfyUkVQChamNp50g9GZ2atU9q/X3QCNkZTwZ3dYb/Ta
z8jym5DXv1epkKoD93yuQ6ejVIPoDc3Lq2gfpGiYzUE5r+yY9HMix+l5SKu8rC9whDmXni4QGS5h
87tacelYpjByL7cSGbMGylq8qQ7tUuatG7/S0El/fUaISxUbGodGV93eGbtLyrviWC5//8CXkoxZ
XXdlddrXaNCruJR8G4GSmy7hNpsX/52Q+v8IcHdW9AgGp0ysIKLawK4XkYgZQjsnkXY9CJ5ztZbo
7iNfSOBr8og/uAwQX66uUNKDNww+joD48b182u040PUh3kq0Gb60pAdBI+gugV/iSJv8/mOiY7FA
lZ/mRMPLY2MzHtL6prk1eDUQfrulgMQVprrzWCknSDCCSsnkOwnfFH4aCMSA+2LGCNmbLmfgMoX8
nFzghOHjnglgdgOWFs2ki/i6KYcPZeWHINemDTeklhEcyXXlz9rdEKpGfJINvtY541ymyQ398unV
g62bt10PcYaZkeoc2psDiAtpV3AijgsuvfBsneH2f0K+0nwHaLjoLjCLkZ3kG0ZANVR0uGaBp+Dg
kgavkT9ZCGAhULokY+ti2+aC9aJY5kzPep4bMTTOOQC/HeOPDRbJ8uAz217vwNVRhEj8OsVbAxKZ
WXQP2hwAhSG/fkrp828VkdB85N/rnGZ/zRseeYkBm5ERRtEq6NP0tD3zdVtsOZ9+5uj7QXXxM6b1
VxrRh2h0Z3TGyW2wRgdJ2Q9+JFyZjr5RiF1A5L5Kvw5GmCKLP2CMc0GlvGxGpKJJeKIL5eSw9/3n
i7PGuAta3pDRG2tGcwi2TzX3MXQWPGWzjwFoItRTM5fZpUU43cwuJe28RyreetN7j2PSmgt7E6Eg
ieszlaMvxAvp0e0sejz5wKs2imX/y61/pB0cojESLsFUgls0ABiuXSPauHZcxIe2klBsLOCR49dX
51HW3VhWjN8bt4QG21HpLMarpVjenKrH43iMn9EgIYrL0vWnuOQYUNyfGSZdafQlx7QI2nyzNWAL
pGOIsjgDrKZJVsPAKFDWeu/u9njcqMWLPVF8Yr9mXQoV1bu0u1bWcXSZ52EqJtxnplJVIU6PcRvg
iPg9knr19OmHaezgAF+1rW4zVYZNUrvnru4Zjtg1f4AXAIuKA7Cd73yRkpwmO2LhJ2GFXVHDUJ2q
rVpAHdjzViC1ZiHvHq6UUfCqAuXf4sBObDmzrQNOFaeE9rCqpjdwacRRcKL4u4RXbKsGSoXPd6l5
whIiPpOsj9Jtd7UA/P+HDgg/Cve/xGxBDgQ8xbgPv3XSTxy6rHr+FJqsMldp0yQVT0CLTuGzgqcf
7K1Ulo8xeDUAI7hGS5F/aF96b6IZg78t3t+ykYW1JgxKRMDDYFdOtk5pSB4Yf/2L8Vi/wLZ2I1hl
E1p7YMRFBVCGVAnFFMe6/OkT045X6BsA+S5qM0sJV87mc9cP7BPxuT/mNT5Cxmw9B65rfO5I4R13
ic9lw32qvmhrr4G5jzQ1IMvki/SrV/zT0gvazeJQogXbj0YQyIt+JcS3w/9uo9W00/vL4Xn7g7Iv
eTX9imRypmzHkgtLQmiOOMI8wY9+dsRSiMCAvYwKieKKY4U8Nz7J3sLlhr29UloE4nVsgAWwhA0x
Zdh0BAkRBFk4PLdEUt5EIKfauWQn+ZXg4s9FtOpRCASTnNlZ48tHOeS7Jo/KIKkYbTK/MB7fDuYe
L4wOBWbcNtS4V8WGv/Rezorcl6Qv1aKZ6tdbHzXtMGDMGFhnt8XyuxTKb0dtti4e9+fPvkYtw2nl
Zg0nXdZYcO51Cr/IsW9l4HxopVv1wUwsMfqZAQZW35Ye+Fd5J0nRJGq0TFW/xSlTyV9vYHX6c6al
j3GLQzTdFfFYK2PJVgwilQlalPHrtzjIBRzDiawL8RLRt//m0TWKTpRtCeCV2Q+6YbMn0DzSClIL
DMWoEetHlZgI3ouCN02LBnkhL6FuB1UBkZtQIS1oA86gKBtDwcPQ9lzFozMTPfxsHL4Z/6ka1W41
KTPjVuEy/7vHUCSEyRO7LZu/pLz3dP9mBwuMCU4JspDzoCQ6NL833ibRIlPbqj8ALQm7hRDhckMS
y77whEszIZy3RdBivFHNoeP/iPc/saS7fSmKHnRDbEICofi6MKxNSAdA6R39AjgO7vZC+wI/YGsI
6wRogce0dI0A2Gdw67GH7lmADehsGg5xbj47zYIWaZW6ZOXW8KSq8nZI0jaT+H57nybENpiprvJy
Nf8mcgbl16uLUx7gNMs6iKgBDmRmLY8YBiXEHuHekvZKS9aiQcK68uO6jZVgpWzW4INFuKHfkUqo
Kadx6skckvBJ/p5q98v3MOg3JZD18YewyljmToAOWTeStTHB7BWBiKAeBZQzNKVUCSxFt8iccAxg
2+dNIEZLs3k/kWWJ3eBQVp2ZvtVO2nuhBTgXP1hah+N5mTWAtFMSzms3NdU9lbe5fKDIlktE4enK
Pe6v2i0CkjAVet7Ee3/wUSsP9CHEWmMj+Kc//DNPkdCHpTaQj27bHbbo1ax0FLOZdpeBOVjiAax9
W11XpBcog0B2uWx0/MEj0bs0caJTXPj2/Lt4na0tgLe8Oq8CjIoEMQYVRV8Zxt+5QFMGdQn2aK/p
D4d+wLs3d/Qj0Swu3tU8LW5epY35REFrOX9rqdXJgHLiCJQjv5Nx/L0EP5L7o6y65E6FcNBey5yX
6xpRswFhc+CjqwJxG/OU15A7WhlfLbVqeYbr6Qx61bgk4SnPzNjVtw/veyEIkzXz/qFHkPSjvJ5t
Fewxzz1E/2tWAXvltnLmL7uquzO4AchT3SE2oD9Ckuri1Wi6UP1Hhz4+oRGgxx2kX00wJxH3xRbj
+E5Ov1djiUOkE+1ZnZaqY0DQvH1zskiKBXJir4gT/odANIWagKu+NkLOdj9dVis7SqQryOMiYT83
qldAwgvye9E6TfnocVub7+iE9gRAWFI1myKiCxCLtm6tLgnxb7+BdW9j6U7C1YzwybCAj9yWCToC
raFpO+eLbpgEA5nkzEgdHDo4cD5erZtf7bwyAy8QggXnZuZTWd3pcxSwHaKp3KzJ6wNX63ByqPAT
9s3+GHSS6i5RkOzbSKomicHCFpAzjQT5SlwBrvU/s+JZjFFEZrG77RbEUGljw5YOCVf9EORKs+Mf
qMn3l2XFB/dlt9c/6FaC18tcyFM4l1IO1zC3Yt7i/g3nkvbyhvgWieyTBkFRu7FnN6M8MyloPBCF
hu0o+Rpm218IGmoP9IARvKpgd/+tEzgwZqmD0rcnaFzki+nx1sSe8Ci7mA+rd8dzFmqaYqgCobPl
J3cc844MesnyslU2uMJn2k9QO8Jxs18HLjy11BDyqWx0lScAtJWzag9iGTtrB6dq4rYZ6Qb3ZEnQ
cFfFcefF5YjKlFBr6yIstIhL7VAP3R2e3KTKWp6FgSUU7UV4dO6momX6W7GJ5cCDdfKWEF+G3QXx
jRZP9b9YVSHugfOa61s2yiF1IzllGs6OhSKM/FrC9IvR93xz3Nh/xmY9iRWLR4HYxAAa8RuBS78m
rKcFKqWNnMGxlULcz2fliPo/lschnDlIjwTNR7rlg5O57LCcvOg7CakbVthexZtEfmlvm4eDeeLe
4LxCWD8Vmi32aJElQNLG26fD31AV+MlsBJHCwT4qVmAfB0p3SH8FUbJg69dWWqRjwvDa10imY8gv
H3Pz6MrQmxfiiJ0umZfKZULNvo6IXgDbuxfhjL6gCHJ6z0m7wug8HM3sfpV254N6zwAj3dHC1iDq
jpEiC6b13RhUxIIgIjmh3TMyHaCme/DE2peBo5Kisd1Oh/tUZjTIy/LHPhnbwCDrcv3P+M43aq+e
T1sCGSC5S9tVZxe4v/8PI1PQALADLx9nu9t+T3A+PaG5Emp7a6O0RB2SJRGdbB6p7LvIQsH3O8cM
qig4t23q1tgJr69b2bFlLx7k9lzrk8h/jGxS/OGfMR0k81h29fTLab0UaYfz6mClcbPDd2d1Hj2N
/nbEvS91Hezved/iXlMqwqSNXBXMfWmrLnR6nXI8nNQM8Ek8W3+OnFiXA3rGl7Nci6Et161h+yyl
fA60gob0MIy1Kn7fY0XD9APvsOlwLkb58J8UomCNRyusEH6a6SZD0/SPIBCjkhswQPWHMid/eMt/
Yuo9KR6ajxhBbdvv2ke64taMIPnNsZT4gTWr7FIeQTiqbEMrEqObIxjC8Kf9N5OvrhKgc8tg3sp+
yGtNNaG09TPFC/1IaRycB66CkDgxzYuXicsKVgatwij5yqJCW0MIcLOtnkfJPbQLi7U2zSUgxBMR
Wwqj9G5JjreP0uYsr7+qgCN7EPA3zP6icKj3n0MhzHfxlt0PHRVphNmAwnvEM6/fUn+lP5vhKvl7
uJKKnm0ACMD4UoHxcbHCOCrFUFLym9oVuXzZXAzZ9tM64YE0pvs5f11FVH8DDlPVOGWBoE5B1/Ey
IYA05gpfnUbFhlgEp7rm3ncy6IgLLY2rWs7p8VyeOadpAu/qSI3YmwDdXlenwRJsFUd7yYODFJQg
551AX7UpFzOV2gOA2xvv1HUP988hbtMPhcl3ATMdWVdjFiDwtRvGxXVPbAJstEnou50YE/sUZur9
LolyYG7T4y6w2ifYk2nodtV3XnDDQSuoS3RNzojpU6i0R4lfTZ205LRXkaFxkkbC4GPSUz1VQG9Y
s16GrT1K288+uj9MfKP9YgmAgSoNMkyzZfRhs92/HNmHqQOoPrPXQlAwV05u6gnJwmMWBtAwTern
VZCa7b0BvyQXj+uH8ZyR9zwnrRCq5WkWBxz04vdGCfAiVMqOk+dsrJCkrab1Es0QT6sWY+rA0vTT
WnoG8B3MhwwKw24V955VSFriKW2LfbsuWrD/7bPlYFOLRnW6/D1yIHgoJ0AwGfrYIzaCxj8+LcBE
oJAE8OzFq35LxjIk9q7hIb504ola7LEtTCx0pqNRWagY1biZw4cV53k5deU2zgf375z1kOpKWCdG
CqfmA7PUTngkG3vVIfVZDkoFlCN3IBG=