<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+yUzsjRiSjC8jrYI4he25vOBgJxQC19Vh6uBCys4G3oYx+mEhcnU3L2DkGXySizoj+iESlb
/831vrdR8iZfAWCSBKzqFr0FnN9cZ6cqwUtvu6p5kGLMESzueU0kHUZnZZh4mN7VfzgX2Ca6DK1T
HUTRifBZR4vIXyQ03Ffx3wwyevgsty7Cq1teXVs7BVzqn1rO+85LwZRs1XzLRJOxad7VIcWhIcZs
RjJVqzVI7pR7Lt2t87kOvVID0QIj6v53Dfr6XQMm8g4wBvT9zN6ty5LBgYPkSeOiVhbKgHSWI5nC
uMeW/y9T4zwU8SIvxrLP8CNu0/mf4RGrUNtfEosfqqOd+HqRp5JGxctCZxsbh5Rs7wY8HiAGGPrS
dW0oN9u43BMot3lN0z8waA1MRj1i+/+8PCMRk39i7KU90LCkxhPYm9jsA1GeXhKZXoZbb1XZyiDd
+xTk1dWz9BcLiS5bTT733pURb5FYcpURf08RZueqvXCTIuJMJVK+E6TvyqWrAQd3M/SRRJTcCTAl
IZzC1u/A6nHxFWBRmYSI60A7x7IuoakRbbpEfTFDg/n5+4OH+Jfx1aZPVzHTynL1RP8qU6Q1d8VG
7/0d3cgIfBSaMShCsK0uBR5dTd6HWj3TSoHLDfIumM9DYCmOBnwkPZvWdx2j88fEiYzlRwQBzHSm
ibq1tS2vra+2nifZBf4wMT9PchU9kXcMDMGD3mMGYnH2Hj/Q+wfk52ePTn8a2I0TXnGL42Q2Vmkn
sMaAh4D4W3aBzlgS+CZ3kHDG5GR3vFuYT1O4xKkoNuz8x4mUj/CnAr6fDQHnMctw8ENCTvGP5I7C
w+X+v7oJxKoELEO4/wE+5rMR849xYBJrz3grIe0UNrTxAX35nlYR5vyvrcLjNUXnwvlcHe4Vsuiq
mHkP/xBzvRsUsDJCRQbUCFTP8Jygi67PC0ABpKTyGdTfHXhs7F7Pq07jwxNjd7n6tVrqx7Lw119j
/6I+LLDMMV+k1XhlqedXfPqQewBLWL+IPsTu86dAvI4dSOigB2as+dLAtPG5cyXXT7YW+HwlDgkK
W0DgY3hzvtwgCkfrWrOA6+8hOOq/6f7pReuB+4eX7Oe3kOkEIPWdTJMcWOxcXdB50SaZ224+i0qk
ogV3OeeoJZrr9n/9Qx5RBudmxNqMTi5Itvf+TLpXTF0IJiEeN2zolFeteq/pQhtwO6KFdNm/feqm
VJc9apfpGXqJcziWY2mEQ8XkHh1pk2izlOAPzwWnYaa990RQ0nqA2CDoJwNoxiAilzQCsJv0JRmK
9LcmlF8aOBnRJ7P5bRywArM4bo0Z1Jao9EVTiVe3J+ahHBfhA4ubyoTF6W09GbXPy272AKFbXp53
0EiHO5gGBoBm+sDgiOHPpeMQmkIBHM7Mndn5JAahrru2scVcq1rb9YxbLMYNJO67NzP6Xn5hJZta
3VwoMyxX1u+969w5cPTzVP2Ec+I0GYqDPpA1kKdjhvgUgVjmBh2JbHdXFhQ3vMsyWA1DY3IcQIZx
xrrKOa+8bYIeIHirw3PuZFSePAYnkeugvf00WmFVj64VxtUSCIt9OoLhYxEGpm8ulEc432JoiWe+
WLSCV2wnrdX72fpUOj0NnYMglwJetdoNqrL0czIe5R/fgW+834QzCnGHlqE5EhS8MlvXjDLq6D9X
86jIMZ4hgIrFp42BhsI36up8nfy5svbi9GhNZ0tUKGGV1ua25J+191U/si4kRPeiXzd/fspGhsE4
kvvfgnSFuRjy+kLWwoTJlOodcXLkUz5yY5oWSs9H17FqS5Fq1VKu+629bJa4wxO07TykhNkNFXh/
mavaGIsl10TxGOG/lwLgf5SmdqI7c8mlBHb1drl3kRC1kjT1YQeUBl+EZm==