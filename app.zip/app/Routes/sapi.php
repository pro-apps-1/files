<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPytCakz9WsV050y7p9npT0b0CiQ5oxzYyTrTHt32kOpPy/XTPNlwz8yiQGqaLcdZcy3CzAC3
QqRZZJf/z0HDQqF5yi5iWtA5XhzmGFuchw4eE+ir6SJPKz5qyW/60tjxa4WVmFuF05JZ0le5Yygp
ckkNqC62BJ7lWbgo5o6PIoXRasN+T/u5lyk7pb1ke810wCy1tiDPM7K6qG/h8XwC6EWlGLfLeU7L
2f4qAro+QXhx0k1C9pMdhOW5unsXYgGSOXFnYzrKlb1g6Cjv1nFo8DJn1qxFQF87GnPX+0nxgTQX
2c9OMFzw+PAS+3HlAX0rBzOzyNt2nCYX321SE1EjPELCIzZGURLkd0TXIfbfeziMpAGLnG08vu4o
xlvXrx4Z8GuRVNh2Z31FQyqxcuRuqT5xzhuSDCAC9Xps6+cC2bzEiKOY79z0U10AjnpuRJdTYEmf
/Rz8NnxExBu4/kyJpzmfOQzAyKYqwT7gTpQ0lwJ/thVdHvpPQgTZK3iPXgFO5SA2ByBgJuUxqVRI
aMS6haQKdDf0oSnUZLscxzmqkM5o//CScSWpyrgefs+nYfCxgJiqqZb2cdJ/Fvnya4NOI/jc10po
MluI/0pLY1Zf353H748JwxqQ+JidzmxXM7QsuNCZI30e/yrocidElyrH0Z3BiDdIRQ2V1Ny7eBe+
BmHr+eU2zWzrDHZ+EK58q0ZxRCsHJuO4TWOc+0e51f+EHlPhjXwozttrNPuivk4esm84FcB95+Z8
lUsaZz1e936Po54m98jrcYMG8vh0T2yh03VH06kaprRy5iad+s3rZvMDgyh+sKSn91azyqTAXOrI
mVnTeNVbJNgr+kzWxQc3+p8O/ZwpiA9PSmyhpqbjcSKORdOpgOhnq5CRSVpI5V5R/TaY4CxXX2Jb
Z/Nzcfs2iWuCNrucZ6ilwvMxy2pIa5FLc9OjEMjDE2mKDUhbFUJxirO4NHY05QNSR3Ndq5wlRhZR
KISZUXh/2YoEnfuoSxtKCk2k5ZzxmWFX3TOzzw8m509GLziumgkHynnbPS7psbL1EvOaZgytQgNN
Kc/y7PzLIatKLzjDf49fQdaC8u1/SLfUmSXR2SKRMXERWTvVjHVTk5R8kvvmhvSLcu4mDuHwWMXY
YEImXMzru4PppqXfJAKXG23rVjoqs8/CIk+kxJNwUGfsWfFbPCxoTNtMsp07UZzRjvLU90Sup5lj
cs7WeRir25rC6TVl4fTdGcbtPUSgZCoeHsRdJd5nngquoqGvPJf5l6z400nJDwb2zOvkZAb0tBJY
40oaQ+IsxRIx2faaBempQfwvN8a1gXxp5WTNFHlUtEoMFlz9qhXH92mWoA7vlNDIzCUuPtWnoofC
1v9N3mDn+xO2A8jz17p7XKNBPFiWlzSohUE+YImFj04/2/856dv8YGOVh3GhH6vmRmqcwH7ZmW/B
om55NkjExZ0VkcPitAeglyMkpkOXTnQLCN8i8nP7nKBr8lEU3fkHjBPvoeG297q/SCLHKj0zseRt
7suqEU1IoQYG+cD43bW+Fkt+wWWQ4YzuacVuuUuzjOyHYZIBxkzipFsRSjN3ANnXlMRG1/zIyAcm
i8KQYD3LN9tqx6byjM0Fijl7L+ewQOp1HwAyUMTM7Mzs9o/thHQ6BUGobDFz1758vZ6FcMEEuM5/
qpviPATZXTb7pVTjJCFPfYFrzYYI350UMUtWTYBQoMjw+XuWxOOOUzm20QOLuO0rk0BOkd8jBTwP
69d/HMBKj4alvzUBWpSWNCgoCpa6H8rSQIcOgz0eJNUMj2D0iauWnqFwGHI4zdRQDnZs62gglrFK
AyP+emNJ8stNz+Km5Fa14DbE5v0OeRILftYlMK6fHG==