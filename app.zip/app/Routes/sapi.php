<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/T3Kb0Y4gTdEu37SudQ77S2oAePidKpUe2uLuE2GsdOgBH6wIyQghNANUzHLKL69wvQLsAq
Yy36Z1X0v6wbNtvWv79Vr/Kg2JD1V4P7g1vdTc3ZsOdNE4GbV4XkEoh6GsxcOCjzDksGlWfzBofi
vlVXexPK4X3/Ix/zMl0UNMF6U5xQwUIvpM4o1ZacD5DXzxbgImVmZDPjNU3/O/z8+XW/OBtUnYe4
DJIJcy9dHsUmA6RZIQXAtiaRd7+IW4WK4H5Ik2WvKiNl6PD6Df4hcB35xrbbz8em1DDrD08NtSgs
mefSyXz8vd+3ephDdVyxjxXpSVp2Ja1uZ3+dGEy30tzZlJuth67nL77kbCbhVUkywCbR48AR7Wr7
hiVp5I0zsZDS1GXsMpdAZmCS3ydNUmSkHEddXWjD9M47ZYdkNNCi0YDebfuzspN0059tRblp8iyJ
239bFWX+N52a6/Iqm68PM+5FQbLNQcj34kEPX03XtGrZiAi3AKSTgcKBXj99LEkrFlTfVzIBXcpB
neukiIXPDgwtpqfC/Vrr9SrCCTnhp1A3+d4Mhp5kadkHk/mzUs5kR1gR8/o1uE/iQKf/Ia0pAqfj
6qdaWC8pQ1kiSPuJAI1IZDaKd8mi30d3vVp7tWuPtGmdqdt/wr7AeC/bjbtsyELULOa8PNsgS06D
LzzS0NEQJaxcxbIEhnancgYbLvsuP0DlyimJtnYBkALXJ7Bj6bhspVSdUX7jpvMi0Fc6phYOiu59
qHCGuc1yWtg23F3p+ypPjSAMeiP+926z0AOCCNtDl6omNsU/GBaFguM+MDV2EkJQWQ6paojnEoRs
h/GSs8I0uYY0fPYCxvkypcqRdhR31nwP/YJyQ7H+jIZ9n2lklTpIEd/d2K3+9EidpZeaRSP+qh/v
Sr3NN6qQh2p/zNS+751qrQgDzEMkytTF3hHSM6KgPkUOFG6QdsT1lXMbIoe6Vo0tp+kwGDZzcoRL
IcwmjV9KU/+4u7RYkXrVUO3mqqnT67HCGJd8kWOOYCj4LKQ6t/eHcIcaptOnB2l54+69dBU1t3Xj
/13t7YIfZXU1Hsnl9AL+yx47rwE82F5Xp0l++b9sbvXgnlanb7SZiEGdZP7PLhmvzQU3aG3fxOIe
8kvBLesGQW9HP6J4NVRBAWwxuZ3D7y4sqWD3GeJRoVVdpGz/lERIEnJDZYdV+GdHE6en+Y1j3GMf
rgD154kXoMpZKsH3OvViBI2nDP9XHZ6+L+ZGOHvTXJvTvyXhnoCq2GtPQp3D4F/3O2DU3FZ/uwl3
ZdgrlYydmJvmvp6ER5dYPlCURt5K5VmjkB6UyXV5eAn9LLXw/nHpsUbyFR1EupQ0P0xxkh4sq+kz
fb4S/N5W1STGNKm/2kD2nETz5eb8Tf25f/kB+8wnDUBhFwP51QsB0/KDWjCi7W+2X0Afv49aQoTV
3DjjnYoFTxAi3G7w2KAhs23q1S5kZylMksqSDvQebUIoVgkxcsGVDHQYy5a0MwE5dorLWGGbzjDS
qY/LDPpID/z5usrka6zZu+jXAsdCsxsIkkoCUKNhKM5HTLarB/NypjBMYWY3IKi/kcJiCTpVNmIy
nfEHt5jnIQp5xW6qwM6Vj9NsuCfe1Uyx0TkqZpMv/bzZKfX4RgsM7DD09OVTptbLhHaU5aVL+Sy6
29tDzNQPOawDMeFfshs3l1tOA3zuArFMdW58g/OYcjGzejOjRk4pLdHyTgk6g/cdGivj/mBrwFeF
3Rq+n7siQk08piKzihhpSKVJURm4jZbLTcj14oRcAWHUHpzZuu7/ATMkA/aLl9zaqho5wo7h1aj7
Coh/2Oz2hlbZjO1ZwgNY7ytILuC1gClyGls/RkuGWGyoMKzaeHDFF//3