<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtnC9UYX0vxFl8+mopq9SUaSihaU2yjj8FShPgkMtritsVDZvcMqOWpPsjTChdQHHRLTxxb5
lCelXp7qrwHeRYmgk24DgQMCCA60PcQOJ3gv6lbCflJhNa9lyiqkVelBvUGZ0gExuHtnJyh41oE8
jUlJLGywdsr42oLGmDubZLENnwbLu+e9e1POGRPTmL6KJ0JO226t8iHEtiE48U8zjV++fQODQ9qq
KFl6CA4FmhVts1t8ODaWXZAqHzM41SO0xgHxIFHX9+XPhbv11mcj6MAwaFlGQet3gIWg4rqV0YMo
WRIAcfrgD/SnTCmKi7Okc0TbKyFC7ig3We4ubPh9gxMmiuFUIBOjO5v5rdlWS5ZLG0jqDsgsV3JZ
gIlgQmYAg1qP+y2s4ENBFvdd120n2U+p5CmSGXQTReaNhvsx5gpJ2Ad5deV7HO74T9aS01X0Oh18
GbOq6D651ALTjz2jQNw3Q4QBAJESnyF/8RP1zL9NRIPU/54xP/DTO6BeDIZ0LRGIXoBB405xYIyL
R9E2xZewOToIZAcA4rAaOOg4xveT/4qcQR7TfFdJD3tfeZjiHB3jXVBMdaybXkVAxs7zOh2mbLbP
0cTSXulabav2e86k03P4kwoztFSGtsFyTrZWOfLLR8AjWdFygBnrKSVatB9TbRGRgN1IPEHcHl+w
SLwDoYvPEvQZfTldlFaemQJOkyiw3vTD/o/xnIZAcqGhD1ykAhMUinHR0+rQttEx1AoU2VFmA44W
p9EpTYyNlm8WiHsZpE4ztZiTEEnF1zZtxomTTTB9kW60QGkHP6vWxzPmjscWzT5gocy8vWRfZi4T
w00I04+d/HdUcuQ8Nhiqg+q9G1otALuPtRAnu+AhSw33cvWgzJheu/gl9x3M5QnY3LUmYoB74HDM
LHn5I2WwTopWIECjaPzVDxwwGgIauFzbIQR1vExJ8orIlc6qUAenpEBXdJSdj4gb6PNabY+wQemK
ZoK3hooBNTXmxLISWmDJIbcnSj9tj2BLgiRZcv3i3PjnaPNX/El5ybkHzEafuI29ifupKHmc9np5
wftlcv47SaJATYNSgjQEOenPSm/Dk19HkhRmyRIR1LcLapDLj0Dc9CYAOTGbVPi2uUeWq2vE5ZEU
KiJxjLQtYmORft2qkp+ngTHGeT/ifXc0KiNFjBbqOIZBgIVuwaGs9ZL436N98SXpWOAb5Gwe4LPy
iNrZAZdM7Skox/sqfZrwd1xKBSBq2+90i3GpPTRheSr+OpiNwmhZdRY8xeBTXD2/FsWjVUM4mr49
HfubvZK9IhAxqTrLOAQfeaK8byL5ZbaFoE6zZNrklJZu2YkwG1nJN84tCreb+mZNnWre5QSYLUg1
MG43sK92lPAk1qOqBkGLeB3TtLNnAzp/EwvYHz0wfrMTUUsJ7fr+WIcUPfG1lx2ZL8XC4WaUPNTE
fYiuU2qHQOFW2IpJnBe5CcY66sgjUUIm+xW2lQBGnlSVo/Yqv/V51vialDMQKWCZ+B3+apYhvPZU
GOjmqWoN56TLlE56VrwpAZUAFsD1khTsGSBZ4efaAysDMXR2ZTQtslpv+PmenFyk/0ffjF9boq/M
sHgrDhDndRZ+fBNn10C8vh5ZCL/wSdld3RKWf8Q7ULtwH7k8Z0ed5elbptFM4pikAkRDG7FH23il
xTE9AtaZK8oCi/9nDyFlyf2eM7pwFOpNc9hHRm3Gzl8TVzoyHISww6avsAAz1qwQTteUjj4Hn8TL
8ligJN9+eW2+5GQeszkqPMfoZMvQdBdVbF7W76jP9IgE8gNP9Z0wNAIo5u19DoIuXrbaHJrc128B
liNQA1skrAwincQNNpO8jdtCAVuVoZ0NnWSvoJzkzD52qcWQloA2ONj1/R/lG/52dQP1KX59