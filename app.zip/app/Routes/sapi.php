<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyUXPb9q/+vRPW5Yyt6GaLxp3wAZ9a3SYuMuclq+Tm4Tc6fUd7roPdfcIII/d1q0ka9/OuVJ
nWrvgPbR77k9iv9Njjf8/7mQ0bTcwWZXFVTmciyHK3EmLJTqTjQ2y+kaRwdGEH1a6qjREW1C1mCs
OUyFEJHQ6VlWsFLL6veKTCqBkaUBBT7i6+LTCIv9ljNXWRUqM4Qpi3SFvG+7cokbGCCRpO+shjo2
aBRidHCCuelNgCg+M8zmTHmgum7Pw0vEHW/DscOEfIpv+5PatZdjxX50aynbxdwtD8FlTU3U7AIH
JbCI2qx6TXoWHkvmz1QmaZCHyvIBCWxahFSSk+ZntK1ScjYmew34tmK8g4XYJKi9brISwpBWP5zX
jHVv3scOb1nHcM660LwTEGy6kOMDSdSbs0SpR/pwaeP9Yu7nPQeVEETs6P1bXBxFEVth0X7kTq9O
VlD5q/S6IwPEb7cIMQj6kpLPpqxAVBIfV1/6IYYqw/zuFWX7Dr/+OjQ+PF/NkV9QsScdSJBrtlLM
MBbTq40qodH8WEXD8m4CDBsHFlatk+IAutjssZZohIKL0+Dh6iOQSNg7ksNG1eF3av51fnX63Gn3
1kxK7+hsdgWOAD45T4xjIKuNZTWL+auJq2+XxxpH/2Unptd/cg+D6zIq/oLR/BATyrcAMvoLyp+A
6e+xvRLhiw8eJJP4s+mYwpy5jTOrC0WKBT5fHPjr+LkTMx2G7tV4OofiZWfs2AqnwMWYGo/aW0Qk
Yg2mP8hX7NAv5SKwZIkhkBGUUNVEbIJOS10UJ18FuR44VGbgYTlUWI7+xABJhIGNMp0ghmoS7Hlq
lagYFpTZBVR6W6ldf4y7o7KLtLm59u8Fqu69Dw0+uffnBpV24hs4Fff4xWPv1pEoQlrhJ3KZAsvz
CxLmYAQZOQpOB8tN7a7yYt0VlQem1FQFkd7lZIgyqnJBwJ6Hx2pdiDdX2WMG3kplKx0PhBziXvJJ
OyTFMjeK5DUYf1rloTazXI89KYKS4WAROVYEcliuen8Fg48Ss+839C3qxmYgm+i83gXMnZZA3456
8iZ3Ord91Y6T781Hj3S8a0bZH9oCWPrU5dacrA36YsT+oFOlFoDuXZU9nbdenpzezN0/DNlFMRU1
nVreUO57/ueHryvtAAJ+7ReoY1xtqo5gPzOzH9Bgql1O0TPVAVnNq1MiNcnfP8ADoS6H6nXOSgtc
hjsZOevJxauxuDyLPzXO1TQ9KbK8YCwli+LUmch4bxUHWSe1GUff6OTQ0G6qfAh2TbbDlvG4CIVG
kP1uWlz3EAO0BGC/ulXslcfBWcGTnnvRcAM6N8VB/5ifjTC17PSAHXsGBpQGiUQhms7V+9gK0Bvz
S0ckamFNtPE3QHTDPmr8CyVQakC5nWkhpY6FY/0XgrlUPkuwAZhRiPKMa5bTj6ma3Q3kK6MATao8
2kZ0xFMNN0NAZORP2/9mIP36DNOFoAUnpz9Kyjz7MoYIKQ8xHM1vrKwKNGyMU6HSOHt0d7DYKi5z
Vx3UWKeUiAg6DAVF3xJ3o/0BnqTZZLfe20ogn8Uy1WXV1konHmnIpKsI2BSsik8ErrknXPmX1m4V
WrhUOiQ/2/MLnAycPZZDuUF2+eGgJOnD12/SCa+9ZhufuRyXvRiQ8ZlKU1P0yl9GbFGrsezbQHvc
HZ0ERRWW6Kb1fA9VSkan8KwB8+/Ub7nYIa5zIVnj9gkX3rwrnYGHn5L4Q7lN5oSWCwf8q0dioBVy
h2oTcsfqXUO8XLdI4QrkQEmJtx7ohV1V6hmUa3EBeKmDVNGDpTd/bcdyVvixKp1ht0tGx7ZbYGhG
wo4siUFhWsoznKEKCrSu5Ka6ThixSbMgRGg78lzIdChTuGn4y3/ELvf9xB6vFLVA