<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv74ZrzictIGQGSQV2Z9X2TbBy1RR5HQvEL9mgYszBX83PhYjsY2jgN6+Ji3HFvPeeYM0KPd
23X5mEPdiyhOZJsPaPbVzDSjSS1NqvLfwvxV4b3mIKAPfWlitOIWrc+IiIgxciPLkJTolW4MjEvQ
TyAkhO1BuOJAz+7rCxbv5SZdPinX87tHN0UlCY0ZoL1jBPTKFwtJWH+PSmIkb3RWq040Ujs9CVMf
fHSd2j8VMaEQKkOwrk1/GVbuCOWOVH8wYspffr3nNdmqLogZkL5iG83POWvYH6guQQk3+lqF+JlL
xODPAZqX5A11yiq1OGlqfimID+3SiJSJl0nCdgDHAK0TPGBhGU9LdQ1x162Wh1MR9KY7EsdC6//5
OSTx6XwaV8DZN9OuYhrwHXHxDepLaLwRNKB0MvuaCz7fkgxb/cNKqgQLikdH/SIwECCousWx0Z/1
FPHe03l0Cfe2jNqTb3chWdfcd0xA2rs3WxzWEmgd/KstZEwiebLlLp1xfDdCNOT1jQSXle/TIeSO
7Iz3Z4iZC81T/B/Pv2hSY651KC0ia97spooveMJXpoi1XKNaG3NdgipTVnDi8UnHzHp9v+4NG7HS
+eP6cR1Mc5xqVVVG6OAeT2KQNkw5eDgtFtsS6sPdNTL7bqLyrVhDCjKR1GzH5o3YRScE92Vuinsu
vw258XXyB30OkzqMGxbbxxrvqYUJfYhbZRFwCaanWq43hgV5BwFRhei0uDq9NaRqlpkmZkgW0pag
8DS96DmhYGzuj2pvTZkZYFPCQ8CwNQfYsrz12gNeUDYg1uOAsb1QE8Lo0GwJlDtpeQBw55iuHaf4
WTWu7cu9Xcv4ZgG6doieJ9X71t8CLmAdAmmzxisyt+pNc8Qqh1StOXLbcSsVXu1BVQgKCi9z59uX
AnH64a1tH1dvOKeKRmg7vfpJdzzpFGetj6Vi4LtsUKHpEny448/yygK/47yQUvgxFkJqpI27iQOE
ilS9bjLPSriCQCx7SmvhLnWExgiR/+3/z1hQj1aKqEXg3XKZ/mbMtAHobgZphkUP+iQUGbs5NqCj
mvls7mW0N8j9CyqzERgpFTQSEDFyK/g4sPww5STimVMRZIm3JEDR3Emk59bpigDWeMnK10y9WOht
nUAluo49syORTC3K/JyfHSnX/pv+w8Pk/9MQ6kprUXZm4/XsgJOMpoHbepcl+TFC4d39QDOW5IBv
qcLbMW86Si3O9sxxt83cPSw5+b24B8EP5SdbFaw8DvONXUnsjqKIVqJ7/vWbAHrICRrm/1U66Lk9
qAGxEHTCyDCblpESereEhU44aIk8oOdQqPsG/VBkEAV4bOV283qL/isujxaK9u77l5hXeURztpzx
fdwpN28E4pRDvnP55ZrARqbW4ZYmc5YONRpHKYAwdTC/O9y5dw1Q+vlB4XQgEktpdpx1vMOmlUJF
zOSpGIm8FpiRHOf3/n2gV14pU/43GgwMeWuYY/kuWu5gNEYDlnEyXYwt7QWSCezkrrdYeRTeHBrc
WFNiDY5rE26C80HG5xZYFjHGSsae3bS0GHCbLKdFToK/IgJQMB+E4P3Zv6H1FYKEVSccqmOGZE0F
fga1I7is9Jz6siYVgJ9kMqc1PISmZO1k1s+n75Olz6TGy+mb0dvTKcChx9GLvJZIcX8N7TOU0vut
m97rUvuQi2Zm1s6II/pJRN0jL5kW+TYa9P46dTeZjTQBGXn5NziV+PLzGcPq8enEIy1uBwZvXdBS
IugmZ7RhOklXCA8r/qX2EH0+34tAHjef43Vl9nC61nVzqc8vEp+Jq7ENE//OVjq0UicIiHMj5j3b
ruhmrDBXTwFfansPbWWljOYrzUk4WKVcG/rbnROzC1i6mH5+a2+THz4eGElz1VFI1jYlFZgup4I4
gBaz39G=