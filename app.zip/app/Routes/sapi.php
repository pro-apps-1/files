<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtVF9FYzXft/9BWCiTkZeCm0sEEgIQERXeIulPa60pPOYX620oxmugmsrlRs6o8BwaaK7Bkw
a6pUGaSNO8H9GYvY0U34Wci43pux0zykm5IwGDNK0CLd/lc1B/J2dwRVyd9gb37+AFIsgrTYfjb6
Kmlp4U61vILKaaVQc05P/tV3gCEN2cH9aqzfXqKiWFjbVq2vy0pPkEEHUc9836Dn8b+ByzfqIeSO
XQkZmHsThfrbRVDVyfx6HizeBGVmIBF5PtwlBFA8EKV1kGqKsfbxMrk61N9f3RVBxxkcqO4oZnvt
k9WjPEVtsF7VnOC5Pr4D8r5DnKX6yhkYO86U88A/Dn+ERDaPdPzdrp+qf0JPEamAOUENacu+4gEc
YvbExzNuw0ejGP+aQmsJ1l7M62fAN+pTD3Etn0Mi9V1pBDAsB7Z6bZ3dSMTmSfgDIILoknChtroB
ZhQTgcsBso7NUoylg1D4xRwyX0Qyk3dW6KcVFJDhuJ0ceY1HQ9kElsyngoLPheuAljYekuEKPUKE
9U6j49InoAmlj6xQ3Yaw0LdrD0kAof0pZUeQr3W4Xb4rZ1xrfzsVnTaEJRypIGWhwIiTXPfn9/VO
ViPBs/6n6o80QuGPHN++SvXvaSP/1AcfbhIZhYM1UNOCKAixX1q64T8dY5wedR12+AGs4UR1f4BP
ydYyOA0UAT+/GUIXTU1nYilXLr882MUgxbB22qOUd756wyWbzp7Mrw2MeJ6/SoWqDPBXj2gYpyu9
Ak8g/vdu7gmt/6K3XIuI3pBaB9nG7UbXfLqIzgGpRWXOBgcvVe6rYQ0RQhxX3iSEL25OcHSwjXiO
pQ3UTnuvZ6Ckv/jK2Tf/EKAwDZVmUAjSViaWoM1HYJN0MZlj/xpdM25zyNJEJmq4agMY7iwueh+2
jXZGtzQjM39Cx8s5S56IxR4cseTBDBvmffUcwqbjPDG3AcEFmH0JHfDS3JLILa+NHkKuYCnPnlsH
ZpsbXRI9tkGjmD6OBw+B2Lw1a19Yt6jIiyKPmO/yeCutzlVSWb/SSy7AO4ZFf9WEhbHwhkwBZ240
rdVbYfHZ74NDU0ef3CyXbvCxnTbb8VBNDxWKO5PWWOLLMUpDKKYudfu5Vl6dSEMN+SB4Gl98H47n
/mRgYVKAaz7Bn9oIjWi5TDxFrQ8QglGSTJaEdFvMyeaBGxTXuT3cG7IkN2EdxK+RTuJ4u6n216Ke
jBZONT4diTzjRpq17AsgTY1qZnjFJnL0Rj4blhAObCG8Er6ai6DoNxFiWsBasdL1uYE7cdnpYtRj
hQa5MU8lnmj5e/hnJvuqP78fS8HKHM5BpJCHdPdeW6QMXMsUUorRfSf8HuzJ/xleUcINqCMC5F2t
6N/FqGr4Q/RWTp9tgdJNvd/dQoM8YJEZkHWvO4Gu/ajH4rHLpWGH/D2Wy6ZUkZ2RYHQuucdvPkwI
SMeHuhuv5w2orT9+q2nLLEeNMOqvN3Far7r1YdbhrI86gESJnp6q4zhrkQpW5d/uRDA5wDItlGRg
nKWgKaMErqL+rPfZ0lbLCOfSshEOWmZIoaE3Du8rW+20dhvWHP4fBk+t5ruIlfYXmtrIk0WR/7Oi
AUMIZtJl5e8939Pd8/BuHG6AglT3nvkOmlMLviues/ohOLFYnVVvAYEq07V94JjHsWmqJX+TQ649
iLsnMDJC1BbKVtFbljp+yNm7PKfg9P6+L9pENdaIvHF6m1UFUAVj1/B2uFy18Y+sgefmM/DCnO+K
Sd4/1MagFp3gq9eMMr9oPPDEwzeKKY+IiODPjAU2PbNY1wyJTvjuZOFFpJyvNMgora5hoiMDFOgj
g6Br4wXsTmnDzHL5mrKh7nxXn9ArNbjTcz6qHagTKnFKc5IMk+f8nBi=