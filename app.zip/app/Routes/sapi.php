<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz+MV4H2IKLi6rNfPusDP9iFq/577+P8KyeLOmSoH5VY2qF181GowtRYK+EqaqwObA9fOjlA
voxxvmHTwk4wbE2pzefAL3EgPs12myfCFM8QWaeiFuzBwTV9jrFi0WI5Y6FjtznrS0upmhBh/07Z
z9Ty9zYsOd6bCCecCS3IxovO7XW9rj0pjmPJm7mu9rMsJfYH3/ITneoKdB2zb9FjuzFlj1FgUhRr
5S3RM/tk4hHVJBuG+uwjqYFZD9EdH2FNvFNPPH+w5Id7ys/xh1blMYJasqNXRRdNq81DMDDKCyhi
epvJLlz/ivQy6rLrtHQtqxaIrM8F74JgLvPEiQJ7LBQiPfLIW0s5sE+H8TmhPnTPkm4bH/Al2u/R
e+npufyGdps3tLqcOSoEGSJbOqW5WBGMT0eSEV+plVCHuNon0Y0NJZPoGY0z97/fwTbY30HX5C2h
CTIFZKOJ+mmOKJ28XYnv2PfWp/Fz33MG25AKb9BE4eXqIHZGtfMOcsU86r/+bC/l5n7FVDhlVFo+
YSsvzm1N6cgGiIG92vG6m+JnizfqgYpVSbCH5WkYq5YmMoPLW0azImVYgivRXN5VEQc2WsR4tZ9N
gLen5m8RHP2Trjl3rx16xFtH1nOoAKi30H1WSq0J6wip/paRy3yLyHGFFQYuKe6E/7b6pR6djyjW
oSUYg0DztBsmADsCYbgMyJODK/KLZxC2o+GC9UOBqFwOROsTG+66OgUzFq5izP4CVspDeyrMj4CR
OO/LPzIuSM442YGRbUbTaWw4uYcV9Izo+j11oBngEkkVQ+aTTKT/Tz/YIGStz8oX+WzaQwQkwyUv
61MM78KAwagNWoYZtk+gTZWpjRKVKoTZAMhnsreR5f4vy/crPlHn87msTRKJIoJD7uvERAp9O+f9
lzAzZLMtT1SHqIT7H3v29OMmm6XoDa1t9y6UdQh2T2KV+xxh/R7Q21yAmhKqWHaI550cPoZarzPd
i69i9dN/KQc7AjmMIv2jNsiSZyJLX7DBrys1MfyWYAz6QFpt2WoUXOyqUBX6bUc8OThx1jkymSwI
8j5nQIBGqiY0nhtKdT7tTyPBO+bTVGKRxmmhJtiXZGopFwre8gBK1hy/wjNkMBJzxg+08rYLvA42
knGSbhWPC0Yr1l0pYCq+X5hxWUiIgZlO20j9xb5sVNXPVRAqBtX0N2DaVshcagREQIo7pygz8g0G
8nASABR9hvHNQaXRTHiZVBchno6FqytfAqiZuWhxxIVw6NIkNrNH88xWdY8nqFTJq2R3Br2rqhhl
tNCzjBrEdfjYeEj3dKbhodXjeheZqZUyU0+spDTR9+Fg7qy/EE78+ShvCqfxVIBybVD/Pzcwm82D
cUw92qCiqtsvnhm1L1FdjdChdPVpVz3H64/TnU+aDk8UfeFLYkVInN2IpjDAf6rbJJjTi981Teq1
dvCH1AVzg4wHeM1PZUV3PWmWRv6Liak0/3M4ISwFHlgdae1RY9busgw4LLTKT9tcxI6hej/Iy0KG
mX5pGINx8zpGCq8T4hwxrUEt6d0fCpeG1w8krQ8H3MSwpHNFYf8q4E+QodU0z7WkTPyeqxKNVTs4
TMGzj/Woxve021+xpbXGxO2+AOBocpBazgLNlwBDC8CjWUVn8vW9B27Vyd7ZAjxm/Kj/64lO5vR3
CNv3DXcZ+FT4Bk9g050H62G+86/Jm6AofcPimNjh08kBNriXlWbXytGCWLxXBzb7OVHudcXzQ2kY
uIpTwb7ZmQRPa+b5bndpgSqY/F5SWjJ3J/n5yq1Y4cgvmFzvvWm0Tks0UvPk4wfOjzX79X+u+2xD
NcHu7BRIcTZWGsiEoRTegsPzbASt0a677yYW1DdXPCYYhbv6AkkbQ9e0T1kOhPjAmT0=