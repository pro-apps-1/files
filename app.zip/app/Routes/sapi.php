<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt1lCPwYvedHkwoalGvM2a+dAVjfAwPboeYuzH4KhGT2tirujaHqhOoMtHlt7g/MEjjin7zC
Qkh4bbdxoCB8r8apogXOsuXssjC5yMIiaDyh1vdttQCkLizw5nWZ3ZczVhvYmc37ytBadcFJSRYs
UAVwFJeiTx7iDaNxZBCk9vb0Ir3GT9UZ0aOaAvyoYHM1ZgtpY4kNvBD7ilibtkeI9JM6MB3Oc088
4rTf7yFR7jFYk9kcf2gIP3L3aqQfo/CEqx1c8Rv5Gtg/oOGMaUIvJ7aVDYvifSyB6o3iPuiluS49
qBXADmV/xUFpiaqkhmyLVFGTa5USTge7bZXb/Wwb3S1D/zdV8GwoILTkLX8ltbGe9S9TdVBBUYuw
5lAA7oR7tnJ7bC/Qbbu1wbntjR+jq6O5ox7ysSVLf4cXmiMaPuuAcvaPsAVXmd7bzRl4MkDXXvpW
Ddnhkkb+1ilAgWjAnn59JCbPJDZVkoXExobBtVLEiwbuI4fJTKBiAObZi71BxkCixAOG0z9YomOW
MikKZUzxkzxsQnilbypaL3BOcBj8InrZelMcOG0vxw86OASCqNGSBYlLXEwZDFoxds3j2JIqKyYp
wesohvyHNV3K2ClIv2NuyoSs9o7Wdz0YGLVzbiR9/2mYjLNJhrfJ1+PC1UxZkv3r6RMO7oUsoJPe
X57VGgtuNrLLI8b79XBEBCGu8iaahnZm6ambN+nw97Kth4xoBJ9WIyIM0kFC2N1w12v4mFcclGWx
mwKCYRNh3jLLH4H8JSRFLXcQ0MiZr35iGLpliISg41CfQkZKBzn9JWWmdKtgIqAFLjaaUyERjPXu
NOKur6qDTEPshECjNZU/T6G+JzFFV+fC9hMEYiLbOD+U7zozIIJiojVquyxtCgiB69GcyWruAl1I
bc4bN019Zxwu8xbafe24QmfLBfNo0YlNR2rBV/H20go28i0Nf7UO2jUGi5uD9haAoQMbKZbs765r
c0gtQNDLc+HCHl/0Me2r7BRXUy/5qEY4kwqF+lWwFGtOLaj/Qe2fxVK5XY2/zFap3u0rTTME2ZCW
7yH4Da7/YcslmGm6Ss2g2ezHeGufKcD8SqF0evuWdMWB5+ewr+31uj6nCv7SfTDydY2C+y01mIEH
LHZhKHezYl4YbCzct1oD3jKtKjf7jhdSlheuHu1OPFWeLWnAqQCrd3Ub/MyQc4UFNbc+3EWZFbVk
5A+8Lucg67aKEVb4J3ga3Ib/0GXdb3kh5bAtfM0iLIdOvrwmVnuqvmKJigxxEAsEZK2YVGGALIo7
MBpGCEDxh9Uht7hbcrc6YVHIMfHUOHDDoPgJ45/mvQ+Cs7WJH5G8f9HyIs7O+3sTH2GscVcHLT7W
Ex4XNocR1ry+qr3ywTmMEm5EJZ9i0djeApw4bP6VhN3W1Bp1+xoJWlTSDmd44r0o/mwXMQA+BVw8
dU0oMfBZh+KLyPLH+PBrpwKbEd7WQLGpIEPJS3w1XZucuNLmyqPK09Fz7ZdVOPQcc4jJPtvaOwMX
KWj78oAK9+3FsepEbnnBttuQOIiMKc0dB72ZzMQ09pGUY9Gq9+4L1Opg3E54u54Z639OXkmdIhAB
pDcCKN3b6n9qI+5ZAQogvote/vJnHp9maC8+lzeKBkaSCRBr5BaoonF76X0He1Xa0AZ/JG/fGOGv
BwflGYGtkArTDbE7FXXLOseWBlD/A0C8EVwmNzfU27OewLE4o+y+3lIbE7rFUnh8mfkAtHPaeYkF
5dPnDskA6Dh74c+Sa4MojAvfps+dDZzjE323Td5JNdTfXJIUA015i6PUl180/LRttGq37WU8nJdC
Y4bRvpHQwHJymrW4fiIYQq0gU/5rCnQxsgO5brm2x5fmud3ux+20ahLOD0Zb