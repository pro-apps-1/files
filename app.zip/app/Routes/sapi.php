<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw1S1bALylfbO9+JSJ0E6YB2iFqjhkJihkr6qKiscqDp6Xp0OTGUhkqmds9AerFpvMbPkXi9
lpcmdy87WvVOxOhdaONjEe8/L88KCsMdsfNPAEsqBc4AXdezPYYkwDGZuwDnB2AQmEwfn1WBpbIZ
4salLm4sdXy2eBt1xZ6JatzEu2/kCJqQZT5H9hFChsuWXVx5QVBHMLN7eFmahwVevxjmFumI1WdN
i0ST+Z1aSBcsCTShEx7qy9wnOCWmTqzM9mnWJLRsZL3HKx83E6zV6oB3CgfZPsYLuBI4qUD+V0H1
6JSpGvz1r/G7hRUEpEPrGK0K0tdkEuzWKgmX5hikEO1VeDnwrUbAisvjqGGgAU7RVrAQ8HVJrKJz
GkD76VJo8e9bU2m81qV9FvWOZik3kB7I95jddTzPvxXv8Nm6f86xhSJWy6/xozOmtyPcJPFM2Gpw
4n2O43Qp4kmhM9vWg0fNM6jGZknUFfGdmf6g8sfL1RjVhd/vgaVIKkfDnuK5YGaKRXc3/X5V0xoK
gtsbHCmpGZN42EWP2anvHChtRQ3JapIrAIm9Y5NMBQR38Z5v7a0sxN0G9qfxKcnminaFlp47teGJ
0z9XmhPGvzV5xaaCLFnzzWO/vA2Pl13dzCfScRmhO0KGgtibN7f0ESxnm+R9cOTgA+PYFQYnJIBg
Q2HeO1X5C+Aq9eZa91cWhzOBrYLFPo7ZrDNSWI/naL+CMYNIjYmRvqeiGySl+dnXok0xNOs/W1Us
R6YaEGWr3jZPYk8kMjojXUP3E/6t97UhuPmz6iO55P7lmRhJk4iboiEsS2bTHa6QLnz9ZcAGq9sn
6I4KzLO7hVKwefDs6uQRAlzHOfNSWnvFPWjdCOv40cx+bQfWJqIfzMJ8qATs756jitRX73RJXAae
/Opz0Zv3ZrhpPVrmdOZhy7FRURKpie41JZOmVBvtI4uAgtQTKrQv9qRUFyoZkQMkdbzuoBzmSt13
XkCQc+NEvJ8ufD0BKta86svevIweS4gPY73sZe0Q0cNDmo6EQHavdkCuyAdLHWp4hgOiynnSG64P
2gA6nNPzSr9VwIzKGKicwqqgQiMzHFOrRDDkJUyjfTQgOPooHnA011cYkWATWsZv2uiIxtCqB04z
xj5AGZ1avSZi2QmCnZqnVqiEosCIHRbSkMSev9RmSktvKmrcYqcLpEIMyBuLlXUA3r2pC4CgV9g6
pKxkkR0TMijGqgKCET4gsBRxWc2d2YXN2CsK8NAtc2SCR7uE4aeOpEOQE+58IZ48XcXwGt5Ho/Es
BC6qiqlPraZagFz7FmC4pfYCAlb1BLywW/3QhkQuA3DNfeAEN4cgiLNqNCxVOGs0ahxc2Zia9aFK
NsLBWRaDyVYskopGoWC3WVbp/9IpF/N8jCotL2hp070/KJA/JeBipjfEpmdRgOOOIbJh0GTy89y+
hu1QAkOUvZWspAouxwfNVlcx6WGXg+GlIGLJ0yxRlK1Eq6bqpjqkC4O6DFiC3llAV0h5Dxc15Go7
caBUVyy2wSu3csd6d83vI6xMYh6q/RjIBcNs8j52kJPU37Q2BEIexVZrvpfJIgyteb+RdfP9b0FJ
8wdjVXdCW5kZh/7cqNGJcKwcuKIrB4j0wMmJfvr3aYVNtV+Gd5My/o4O+UGO0KOe03G2JaX0tlWm
x3B+ePoKpVNR6BrEQOQ/nM/qVbyF2haO3eKQcgUfEhMF1XS1rPT18akMQtFetzyf+CFdD4xtZFH8
s51Mufgh6shWPkIHiah4YtNjn5iGsMJ/BHREs5xK+/9WbZZNn57akS/7Kmk15b/mxG8ijc+p+6qc
/kI2J2Ch6ul84iB2D5xuCwDa3ikfN6cGTxwYM4pkbBwwUv0/rE49ZZSiQBn1+y7AJQJVHHru