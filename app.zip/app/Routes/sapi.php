<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx12oS9W7JBrVO5SuLxCdCBAlvj/JnQs6RMu2hZwwl+YmUfNXEYhnr2vlnN493t0kBxDoCJG
up5C2TQN6QspVanM072zL+0Cp7ElPDf0kn623MV9luDTdZ6seyO8wbJLkex9cke6PmOQr77O742Q
8lrxZ6KSiAdvnLtOoEq2U43xWrx5I1Nuc1ZzUr+WDFZd1c7w8QgDIcn/acC5trCCuZOljfrKhs++
54BHu18CvvHRmpIc+n96RV9e9t7tjulJu0h3DDLlWsO5PxOd80HtjBOotxbjVDJYjXhwK6jgvjKr
i8f1U5ROGM5gO8swhxoSbmFdWoWY40OiXv4gp4ZFyF1vS7sXvByU+APVyTxXYFX8jIhXAYGS2bDe
59sxU+x3cIOr1jP0ihgKBdG4eZPXFsYE2DSNos00CH2VFngY+Nnn9WxfIdYPJjrGcoYflXzBH9gU
lXXn5rrbe8jyYe4/HOOt0iy+Tdi5NmKIE6h3fs92dMNL6+JEMv7bTK5cZUAr5Asiw7Kn4JDCfCGs
JENccIVJI6Ep9Bh2S16HBOqZMUyFy+0/whktsVAtZRMPpntpjjRYhLyJI93KMXJ9HDcarpJa/uA0
XfoMlWl3yIKMMGrOqc4TeOkCr1Et1+4IdnYgyi9G187YIdIoWBfY41pvhGWxZBNvJhmm5otOMGpb
qjiL/Y+Qtw9DryRBpb9HPjmdqWKOTHRD36y0SJIjVzvWXZV5ZJq97/uLDGefeGqrmQOPs9ujjb5n
APT9WhT9nneOGbnofUT7IEMfZGKnqjUO6W2hwXUmRgpe5HPSojJuxPJ4HRrz2G4GWkbV4yoCGASj
KgswciVj9xmGXdf4iZ4pkGZ+EyJspxGUNManU/n7CMfV4e8svG/fg4luJvJOUKp8lDXoLtd07Ll6
M2K8vtG58m1Iz+D1z+u8vryZorOzxeH2qrxae5PntPDGIu8xvOTZLT4PZ5dCeFjilKNLal/v6Fry
havbCixdxei/NVzHcLmgl74esrBOEej85BX9dPPgLCp5WA0YJIltQHo6ihKqmQZMyVbfibibcDOs
86Z61U6mtQs35dBHfNjqH9aatkGdTgRKPr1sAxbipzTBG+hc8++7IVbpK+vQBeZhuKW7YZSC2Vqs
DmLcBFMxcvkwmBnp51vVfl01yWEMOsuEZvWVb+r7pQE+LlhAHioE/6jhH41aBUdOh+mNNvAjyKWv
K3Y9E6nvU1QZ7dFeCbLGbRVBbdbbYa33C00FPJZ7hJ76cjxEmlAnK8i76kWE/n5kD808UcE0+re2
euRu0gtO8ST2dz54G4CD8DdL1lJlcvT4qeX4Csat4xQpjkRnBwyXP4VXu4deSJlpIpDpWmBBZJvn
ed8bk8QAyyNcG3AhWs/EIACHpd4x7/vdoBky8ietexMdLk6+Ng5Lux2dM6TDuZWTs91vhAJ6r/Gj
vHanNl3JO9/oIIePW9JWc/Wa2rmJlhDOAYA1Z0T1xNv4LKWGw8ajTAEYy4IJ1iYUq7+b0ZKcyCyV
dyIQ6qST6znG+nOo/8tUIiKkx004MCafoXt4mHYIp2MU7x1DNQA7q7TO14w0ZdlJGTirojssdZZV
1Kh7WMo0IPVhfe4VdFiu1VTyJ3XNYPJbgNutgU8gtUuVs8bJcdP7mWhbGMyRzIirzZP0+DTUN4DN
O5/t84anHrZF0L/3EQeA824txTiezsD8YWlkFcU//qxzehoDtMqVlJwtx/he+Mr/zEa0eLPqfJiZ
Sa/KVPT63VfYfuslu10NXO6KTm6bb+agHf8/jxIivjpcfZlMov/gfci782DPF/dfcMnJyUaVJVRo
Uq+VwSlHIRT3dPR9itN3rQshTjtEw6m5UmdhGHyU0SKf2RSUWNE+TqT+10==