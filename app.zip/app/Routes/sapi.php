<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxafukI+fzRBH+ftnu+Ld8Nv+HifJNyn2UHVCjz6zzSg9epWbw2M26acluW9v5noxR259XbD
utp7ZpuSGpOug51EU2Le07Wjxqc+YYhPtZwoGMlYI+dkJqkT6KeKtmxF/kJdiazATfd9Nae3i8dz
xIeSsfrqyKKlVU21M0k2Fq7B+Z2IQqdY2OW3GBFrcZzeHV0GjziTwQbSmAx9JRl3t/vkpP94xMVP
itpeaOE4Slz+lxB6gpMoue87ymSpXaJgGgHmmxwWm7ezVyeNcVDbdJI9JwIjRkyZHThe0dN1mN65
eZOgDHlJux75lqBNUBiZ64QUKbT2aF5WBpl7q/dZpd+LQJ6MqMog3zuaV6DeIOWrhFTLRONFIQqu
3sqC6prcoH2Zs8gUHhrA1TN+U5r3fczNjH+v4zFK85Vx41GcRSPH2YZygWIDzYEsvaF/rn8lITfP
ZVb9paae4bsBIbQyTM+xUkaMJPfKUL7NfvgDClwWpFZ6pBzmpNHUlMQLTXU3jPDFoLUuDtFZUxdT
dBjyqKOjii4xZXh6FWYCaNv5JD2cU2DBUrjaMo63rfmsB4kEs+SxzBrZagqJ8V/wAOSp1U7Maxt4
O6UkgvgibT+szyJRxTBAJ/39TkHacd/yeEThwdhKXxQjUoWUiAjheui6sXMN734PMZ5/S63RPr8F
V8OWWMJz+MNZR9aVMsR+hO/S9UF09P1RsYQpAX166UjGjvAiZwvL+f7nsVpWPxZGMNVgEbHC2Cks
gpfGjuhV03Af8Qfes6qk3VX6auMlTuArroqdcg6Bam5MRXN+AxO9EcrAldutsEdNi5E0Zu01S9Ss
12GE7goajpQN8I8824fOI/vscxtx+6apaHB4FiZ8M2MBh19RZkREm26WB/7Vb/kmtFnxMzjbikbs
s2knGO7wuqIJPKXGn7Ao8ZLLOfC7Sv3yNwzgPMnowkmmGLT5waTcN7OPp+bNpKEu+HW9VsSxUc3y
eFJAtGskdUIdpxtKUdr8KNaXyoCUDO3n+dif5t0S0X8j10nIrj+sn3XOKKu5Nf8uWXHTSBhzMUA6
Z3vSdSVJRsNddLn8pmga3CqoqPWU+qZ9jd/6MxkndRHLjd929N+WKRUIvqBHhsAonljGhkW4nKYz
ctmN/S4FJqaccjNt4vYKNRuq1t74dmUQxCdW4yGCPiLii9NrUMVjDL/83nV6Dfg3BahipMz5MTg2
0tA+hj9BQI8gS+gZL0+oWfYyKEq372W9h8DMBun9Oh05sAhRZKuwECSf4/yopVH9+zLB1wT5iy2f
RqnPdeKfiNObk42QEdRHCG1n+pPm5LqK3i9LJL4TPmsMJr6Y9FIgABwzkKWDEF++bcVGJULiygm8
MY8w6BAQqgrCmI6SFt4viiMRBV+cCNiA6Xw0CB1ZG04s2DvcjqadnAdLA6HunHNvZ9bC1YFiDWn6
ch2wG38VCzUcIl6MzXhikRQCDKYz6deQQ8/DjLoh5qq/fP/GVOpwW5dgYH4dHHnEuzB1Njl0MEHw
euIGY18SaG17QG+FlVJNnm9b10drryC1Ae+3AyL8Zuse80CaKPZP2B1XuSG+VCCXNmug5D/f7FvI
GFzqkSsDOGa2ppfiQQkYANcqUcvhDDgKyY6+B5HYmfASO+VF2TzwbzubY3hyCiz6MUIv+gxl/vVs
uZWhPQdNPMVJQAQuTWWjD/XWaZT4vN2XWm7uoHtWAXr8bQEQBVaIlBzQBttavrgUKjSv9P+hzPc1
u0j/tHkLMopfafoXg2UIOV/Q8r/bhS64ScM2kYJULUosdQARDgok74L+xc3vVGOp/ABo97C3HmT4
DyelKE5pZ092YPwk0U0PRe5Oqb3S+XXWDqaOgykkH3Ht3GRdNIQ7WhnLb5T1di78sVHUkk1DBeC=