<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/OdcWmzlduZEEGFByCmGm2uUSUy0LcIsf6u/7niydQOHLpTkVzsU9H7YYIwdPrjyJf8kRbg
kRo5diAbnrZXrh4VaZUyEfj3XjPRsfpcrbr3qUOgjqGgYpS6Nix5ZsRZfUftztRq3r9n+f75xL8b
8IWoCZ3E1etvMpFFatUDcyz/LN6J+d4xbxf+mUOhG7UBHnxMv8NJn6YhNFMV5dVmHYsv97rgfCwf
fdOh+Z1B7Sdk9QQIg/IUdGr/l0VjNnlKYHs5Sg1YcngZVFhp9aQ/7plPf0bk87IkqGxChqL1hpJs
f8frmy1Z8StevRZUZigSkCPeVigpkJDFC86R4ZcOfyRApxehQ8cXiYbGyvDPH3itjaepNgMrqJyW
pr1NwhA/RNSv3NmtNMwe1CaVHcdSnUonQ2IawsNJb+/qzg1KXAHhXQPP+En8IpJRdfQxHoH+gbhl
hi9sFx+yUGGjC+Dn7QHr9OsxK0hgNw9GhqWsJBKojh7KrHBwyIdja0NH43CgOoQN7lh13jukGjg5
NHf92JU8kgTZJsblM1ygcJCGHhk8TmUsIE4ur9KUGJlDNaYAmjTRLncLm//lx06YaIeln3cW3Kwt
gBocsrOGQUaPXvJt0ZrjcgLR0RWdA30F1Qrt0/CL5Q9ADXd/BBRIDEF2M6a4EPjzLjZMmk3USqHQ
JbCeyov2P5byjKRZk68VtTuX50kbwzW4mC2073bBKj0zZcERrfpPmFWKmh11YinwZK09R1vjuLiJ
8sekgQVgyHmjqMN1EzKKWAfJJ/gD5m5hbVPd3v5uI5iTamhnLgu4e6fwCO37QUiS6xQ+L0Fa5AGe
8CEyyf7Zo9DJu8zXLVIsNy85hQgePYVyMY2ZucmPKghbbYxqFnofv0GmxfopQQtbO28VCNV9K49v
am2SgIlGjvAPLNcl3pOCBOxLmBczpSpKVyJaa5KkX90FyXr/Ym83O7t1DVmkTEWzhfa9tjJ5QRNU
5yo0pSvDNPxbVAazpgN1kn5w0ov6xOEqt/9GBnWP/3TWsvPu84MylgHwIHj8qZ/Wbzh443/K0o97
HDexINesSFuIq7yGNlZQ2c/m8qLlEsHuaJZaqawDnRq3bYzLBuYRRo80PzE1lAEE2pzFSaavga0p
zb0AQXCd5eBma69mk6ybm9rUtG135TjYYgH2CBbQbXqxGRtbsxQPyz/2YnsKPg2cg9ioAftEEXNI
hXMFaSi0xKsf4BsgzgwEVMXiOuQQ0aPApxSv3JXWGpAcsGqJWI+6N/iwqastDQVuZIaZGeX3MPVY
wNsnusTjj1QFIOlU8K7vKMr5s+UnO7z18ko+7gBy5Y7jh1AE8e7BVE1e9ZFEfseqcaA5dI0quz5j
Xet3Jk4E4aVy/Xpbdh1gPR73Rq6t5wAOY8iVsDQgNXFbV/QD/DxsyckhTF5JABXA4r5E65rmAuIn
/mO0+OEyt2HbJ26sndBMhYIo39o8Nmad2BQ9CFdD4IgxQjma33MDQy1hgp2GPHStYof60dbEflqA
VoCs6JZJEEcc7bg/BGyCokRg9E8Qad/KExeTChc6cvpfDGgeDL3ktJX9Mo44/PCRXzbjLViimHmO
mYXbXx6NitjXtRvgymVgk3jQTHX6ttlmxCnJAVyUKQqIT1CZHO1HeC+AEi/bjFgnPDJJUJVot/AS
4pN2mwsFlXLjSXXaIgpIjpc3RW6b0sgEtR9q2V8t6J29VzikE5C8x2pMMbiZkqMxWqwkUd+YoQdT
BTggQI/h/3TtrKmT4fHTxWZG82UBvlpM6ACKGAERFRBnNCc0bshh/5uNM1r2rLUAI34FcVEC+ASo
QNmUxhcZOZqszyUHDok5Dp6Zb62D+dN0YekkBmbvVF9wxa6zsphVgG==