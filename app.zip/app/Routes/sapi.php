<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPojEDfti0OlIwOsZlZz2gdn/R+IkS5KRt+XLlamTR2vG/+wflCb7gOggQju3f/dFsjoDlZO6
tiTMRQmV8CX7A7MqjxWK87EtDdI/muRecz0rngDA1+EYu1ApiC7WmSbe4ZVTmfzRzEnlSwj+CaX1
ux5YAlCbBZST42vLKAJ93eHxHl2FVe7mOfPd7FScGUlM4mt5l08oqwv83gQQ7RMVOic2CIDtLqk/
szLkLXmRkbZNTXjrZV/iaBfeHq/V+QDYtP5r29Q0jGZOLI4Bt9+YPfU4E1KbQv617OpQpOCW8VRB
4w9g2c+NPJSXbkNPHtKUV4bGvz8JdcnGrXRKRaM5mAe2+wlQKn6lQq3O2z8HVypLTKg/MAtH7FXM
JfScK9+29ks06utb9uW1dkA3np/Ow7cYxSTq4Eh9ppl6d5cRibmdPj6H1ksr7WnbdDDsZtiPp62I
ZvwA03YF020JIagUVqZpU4Kc/xSCyAA25Xcok9sHeZ4I1h8ESB8pnMfZ6h1V+HkV6Q1ZHZF+qUid
BS1o8v5gsRuoq1ueQlCM/Gi5vwUYLNSSiSYfRq0KR1JSFniG0eMKLRBgSmbAlU2vQVHIWX/KHIc2
1LUSSA84CH1TMR1qQbZ3lwPCwbXRk81/YuGKNsIzIGrPkPf+/xpPoMIS3ZOVyNHteRb8sMCbFVjB
k/EuSjcyDJJyjPgXvioYxoWRX/AtRSIbj1VS2Mgc5foNLSQz+TKNQpsSErkbeEeiewBJmZ93/pC5
QV0JlZWZNnoanOsyJmMTAlAMPPFATPwtNGIkAJRvvVtkwsC7NQOwmrXrGZxhk55nmMXmORDeCltA
E0llNS6Hm2DYSfBRVMg1KrMSu0qs9NE+6mXZbizjRdrTZ4A9icrX8KcrnaAK6nDgYDjTp0ZT2JVD
mewzdBrnscY0OJ/52pwyxJAtsNDQbkYe7pkizQJv9w0AovTFteviHQ6roLSL387oFHOfDfFsMFwQ
jcJ/L/xLDKeocyPhcabVQ56dxRRiTJBo6BDv4FF+Z5pilB8MUvXMxiTEbcz65gPbTCLkMHM+bp3g
VuMAmZbPA2jLseF2pQ5ueXRn9TokWeDkbD2C1/qkR3Ehsq6HOLUBV7v1Kc1ZNmO6v95caugymYG5
oHZfEQhlx6sf0WSX4cYYmxqmWqQwb7vtmmcY3mPC4acvSIjNf4+Poob2AH8UMlCjAOac/rSkaxQd
tPz+YLcKmrpJuHa8Je4bX+Bu1yn5Rp8xv0k0FXTYAioaBHWAhuR2MO+KZ3HpimpoyhRBYJuGByTP
9C2HnKcqxC85NWye06WI1OWBI8O1s4X8hEzS6ch0pGCU1kVZMAkUIb1cgOVgL5TVdJJeqbwg/t2f
8a0QoAIVeU+ToyPGhI6JRfc6SqGA1GTAjfuow77LOuFY55RUqTbcyhPJ0RJJSsQAnhfsBjGHLZgp
YNMsbD97lcchd2V9Y8vZcUpVEM+KYWodwSJBGSqdheGwSdgDTb6WgUBOkt6UmIb2IhnZA8I6itk9
fZAdChW08dbeB84xWC0lBbZxRlm1iRMv4fZDSu2Enow9ow6Zz5lQdvmwJuL4aE/Eu8SL8q+U3GO3
sC8O2AvwA4hQGwlHdAL8sSzvEj0D7PbMuQrsoTBAk5xqoqZN/5B/ubv3m5dPdaRcXG42DMI2zu1u
jS2Rizpt5CjzkgZGv12/CRvWgQaGYmVRQYdtkxK9t7wnWO9mG4TO0hnO/2AWCPaOT7MsnrW2uNZ0
/No+NMUvHPvcaQr5i9t6/bkoAz0u1YZYHzmjmqCpVaI5ITx7W8kMtqCLHNjDfX5CmvJNKRGEBzGx
bZhVZgq5PdHGPw30ihWV/2ylsZiipJfItosMum/RPWAVOOh41zvzzNJzc+YhGXIzPqYi7W==