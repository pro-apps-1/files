<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyqLJyn3oBFZ6jRQx/zQQfhv4/t+PTdSBx+ueQmxag200QXiRKTgrLVePTBIBg3OfjmZNL8j
S2Xr5J5c+4qQaA6K0T2zp83XD33Aue22udSn7u4oGwdHjnfBnCjACy14KCiARJErsuzCB4mvr4bQ
6847CkUm77IUnsW/m8vN0MaYJeWk+WG7PC/hMPtJqMkD6YWBqvKpDyJWv2TJORQw6hHRvQRNUe8z
KtLJUuSabXtDx1u5IN2Xi8IjQ5xu1wh2U4DAfBZeLxUYiG0Ruwqfsmxzarne6p1XfwTst958bXZ+
5nDa/yGdRzZOdKvXvKHoz3MUjpsPjbiuaemG4tRRKb4tDKTbDHXIWSMDoQy9dU1A668Rv0vi1jTP
xi+xEHmYXUsKgE/8KVeDoCaDrAuCXPzVNVCEH953l9tqKyh8SN8DM2JDjFXmmhrVhevVALEYU5RT
+OlTVSu1kjO5G/JXat+k/V/NYUlVIAWXHHsbiIYSUo/wNmBgKAGf8U8NLGY2zDo6phNH+9/gJdLu
uR59rTat/M23cOJl+ali5fIjTaNym94rHybt/9EFmPAvwce1ebJpW/kvJwhp28GKql2dTVIrEJ8a
wqqxoRDsrNi4jFN3e2chPChHJ8dB1iPXqQUj2XQFCNt//790rgTVERSq/H5QMowGqkJYv0TuLhsA
seqBzWekjfMZV7JL/zNx1H1n4fqx/FDXgYFnjw5NIi0a/LY9+3bxVINcy8UkbOLdJL/87l1XBh1W
EFKbZLvygHAALcBTxvzwe0d+5vHAoDFyiiBBy7vuEXa7Jhs/zO7z2Gi66o6IY9Iy+LdUO/969Ai4
KbENDKp62aud9+P/oiG2wnBAuipHbdQB/cm/ehFI6Gb+7jPfjbxUcZDHRVS0BSnApxshMKmnLA4b
V3UZzkBrx2Cdc1haPZlOqKVFr23pEr2j4W6EOW/c31Iwz6hMsYd2T2aRcXRkJexzvK4jD3NkrNrb
vSVgRV+N4q4UajeZoCkElQ/GpgEL/fsyWtOOg+jMerifVfY0uM0LLvP7A3r9TYixfSfPbz6M+TMm
OyRlRHEvq0S3y5fpKLJwug73tPjczFGLM2wyxNZKLakVrq0oPzhsJCG2NoDKU8pvLmQ4zqwVxFqa
xnF6vxFSu9ecai9WXtLHcahhLJF0sZq/01fq5Y5Zr4kUQZIaKDwduAxHRnI/KiXs91niRZ5aS75u
dPEPuSDAi2G1xDocYhQPV8dPDDNme+zPh/8kIMXA2Jtr/qWI8RELM2ACnbIlvmQGyVl+x611GZTa
b0hdzlLBJxQf+OjLWCgEjNWjLhv79VNDOWHvUlW92qGb/zs2rGV4zR6pyavPT0+IWnNGdp/ZmwFb
y8vI2cX/+kkY4uHdN3AIHiE5/SNSIw5Q9o+sAkEu1j+gbWQWgHMtOJ83ZIftEc0N4624iI71G+Hz
4B6cElntz4V+9jtRg7jZ0NUqXQi5xuVcOAoEYaG/ozCuEmpiLMQzqw76T4D9oCCrT6kEAzjKAu5v
EIj7jLu2Z2tfyPkfavw1DANIzov9w5q9wjEAmXiwmg5NFGtYz3IDuhfImlKZ9wpaEXV+yCvzPCed
aVpzMxo8KoJTXFZYMYajtLqRkVd84iYvfEP7VOrCjesmoohhCyZR8Of9hGymhaD2FJ2t4nifGujG
rNtqzpqI7s3cShif6VjlQ4aI7+yCqEXWdPCXH8eUQpBb84DwdnRKf2TSsvuDby4mOIl8vsnnaJKx
Xc2XaR5sT0jKXewcNKdHrkaVUd3gh/OFXlQ9RArWucF562/kovLmWMi0AhhfQu+/yfi6Hq5TRWWX
Up47u5Hytw2e0rAgPwQaPoGSc23Hrfet2ioVlQg/MMAP