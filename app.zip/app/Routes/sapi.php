<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoWQlceUjG9DvzahINLqkCjNIGcBJdO3MDPpZMgm2mDISQH/0WnAr2eFhfjFefBVNhm9kVM0
SHqjh5Pv5S7axharkayVCc4OQu/q+RZIW+ifwEuB38T6DXkaXN2aofZwXzRmfrQrETC22DoJMPv4
WL8r+6Da4+f7G7HFwDVofMMZEuBZDJOkTTcE9haBjh54dbaN+GYhTEJFxGHL8bcd3siN47sKUUkq
Gb05gf6WVgyok6NITQdB7VAOgcaDRLrvHURRB4fyv+3U6ZaZDU62XjlaMxMxPVB3LoAyAnkHnod1
hSIzKlfb/hVU01vTnF4LTI3UjmTtVlRs8BfiZvhwXsVX4QviH7Bmhiui9nqLFT5xk53Mo9umE9/O
w5D9LKgkTZUrU9T99t+Cexv3lAflY+E4H3Uh/IuQwBWg2mgE4Y1IVKWaKzbeB5vwZABL266wEst6
+OuU9IyvyRVKn3zOcsCMAOAMNDQZ5flroyVUn1GOPbzkvO9XPSf5rxRMa3aXMlvnGOaCEII14JJU
vYXXm8W1wCTQB3+joDY21ujRl8ruJQDwpfMqhz7NrdsWRRc7M7jp/JEFjEGOceCKMJRJZw5yPTcb
0/QMf22C7pqIUhlz26875LaUFqWOcwMGeD2JaY8C1D+NQkbX/pFcZydE8G9Ng5V6hfbg8aJ0vLWF
Xs2tPqQMpGCVQ9/5gFfKkWWjqdlyXJ513+shL5Bj6wKk22265QL87kIJF+E0YOgND6yJUKSQkbDB
87T0TD/jieOHjYlZnEvbrhkVxvHo2xLwnASdxBUkVzAHnSpgkM/wLyjJz52ZeVk0a5441AnBvcIs
hCFO9LSW7rql+jFIEAeAMPpa4qoUnuXx4adY/htIXb6ujzQ8Ig7zK+wIEygMknuGB3qNtEbB8k8X
WvTx7WV+CuAWDskXCLYAURuRnhP25NWbr2HGjC1NwKncIIKhbs71eDu0/pyLi731N7ZXUGzXj9Mp
q2LtJ+UpPt7/4CIVUcxuN0QtwmGQ+exwfz1rD1KvOUZdUacpj323/h8jH/IqgyTOzLl4jUGw0bHP
eLwM93DsaWny4oDtPkmXh2IBiq1/Wl5Nrtwprpw6xh4lI1Chl67m2qne2lEqlKWOPMKGMuECAQa/
hfJqs1oKMLGU6UTxviVEQyIyfJLqQmaioKaqQ6VHq2fSbNMAv5hViT+wHt5iuyVQ22Zn6412YfWd
UA39ixziBqXxl8R9wGdEjvJ/134zIQmSEt7l3272IXUTGSJhMp5TcCMbI3O4qoJshWas8Q0x6bUh
S7rMeTS1GqmB0hn/1edhwuBIReOfitGq++tEmEMZTQLaicuzNvZZDEMl/BcXI/581Z4Jx5HP6+1H
D/uvSKRZvQBrotVV2DPEUNnQxvvZazJO0ZtCLfFa/j/eRl3bpj2f9rURiDIDb5/lz0MZIukwDkrj
qsozGU1pOuq/8KdfhUGokSlDGqMWYxQogHwwPB00VhdhTsC4+jvQ3v7T/xCfte+e71PGph9Pfn1k
YjLDQvSzo/V6Ih3I7IsoIVAxafzNKsRxXLmod8J9MLAGkONUvo8gw3JAEtPUt9dD2BIeQmgL6tBk
ORwAUdi+B9J7IZZh1F0/a3KXznUT0x+Wnfa2xcvGyupReITAH9gXhox3HDJUnKA+7H4xe4mGcPRR
0FSD8ZQTJzyFItDERHBAk8JtQmtQUgI+220Y+a2Zff5fchgMfit3B4cb/06sKdnX3D2ZtF7x9hVu
5vkGcufhr7FWcnG52aoH2Ghla/rseW7HFJ8QoqnOj9cIQOMQw7rtqHRjxntPE8tDKDZUljNNzyGN
bTg63GEE1JQErp8O0qkM37vREfThTIEXd4Ylo53FKw5ZrNGbfPHCeNS=