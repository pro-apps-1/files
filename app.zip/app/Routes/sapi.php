<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtDw0I6WrVaMlRcK0kdYMnRYPx7vL61BEigK9ZEaRfkN72tH5n09gORkq2Uc0GThDTfMHfaW
nujNkTeqrbZY7WCKTISaDjBWRfNK75BAQLYo6yAK4WJx3QxUWc/LUyZxv/D3ugOrE5MrWisquv8K
1SfUuJNlSS5IIhqiEqx4p+fiBCXc9cT1uMPBJPYC3nRYEGL7PDHAiXNne8Qfwh7ow93864BtoJtC
a1tL4STx6hqZxIcDM/3eYjHW5m5fPi/Jc9KA3cxKLL0DZptD5Sss9lVne3BLPxHGOEaX5YKfrZM2
0YyuCwWjdhQDzKPhtkuEwxRentp69t4p9wK3ffTDjYrcnOySwJ/oH9LQp2XA5jS3BBbDbb33M8yY
IPbKdWB2r7Yr6oQzS4uDtCPaYHsAL/Ft1d+s60D3vq0/5Rs2WXPTmlVz5kPJAcY9hmKZWXL1Qwyc
hBhEEa2mBzrNn4JKQ1QnFjWbv/w+/OXUWf2NjHT05bn5qHWxnybFpTZrRk11wYoFt/EygG/+qTZ5
nb2JMt9MImFitxeVsTsgp4MXvACqe3BtOLwG0dJ5VboWyd7CiFgdIUAKa4GvavOhVirmylfPg/l9
1RVcKcDUPAOGImyQ7XkdUY9ZVn7TiLzGcYZ45UnurslEy9CRQSqZmVEAgxxy91W1v09dP0ww4lRf
Ag/43OMyeBKxJdfZwfn3mqwSDJe9qQvKL9FPgKALnILU0XHSbCNBkWvQHYrbROOHH10EFI4Q/ssg
7MDhT2q6D9PzlYx8gwpcRv5jPtEvV0iTobYNd9lZOZxezBSST6O9j0pv2R6Ea35V8kTMqZGaXbpi
Rbncm10NKj3n+Y+SvA4qWt8r9HJDpptww1BD9bFVmcXUxD1lNe8qJbOJVloFB+jv9fcaNXrEIrII
D6jacWX1rAnA1JdaHWBVGBlb+6mbhKGwVuHRSvP9uKbB/w2p+hSeNlFyaUy0MiGzOCLbtSdrRL5i
XzxDyxa5TbqVdRj7Xd7aL/6J/3kQFNpX39wGhepRVdtfPqt/TjNAMGwnXeygoiWXdgq1pzyO9sC8
JvMbT5nYbRwEbJFHYkpBvNOBZTB6J9ankIA0MbE1Khv5mgatPukNr9FzA8Otra/dpC/08TFMf/b2
0u+EEJLUdlBNDv8vgk+igTczXD07oiMJerG7uvdHxeTEGIMJO+eocXUORCz2JEAcUWb+fN48xxWN
GlU/MuxlmwTPtvCpH7PM1M4HWzJLCb75CtU8q0ki13ETDoJsE3jWYnCH8gNHGRmsGc4fWqxH0Rz6
Wa2bdh/PztUN+R67EOC5aOH96bhclSGLOHUjsenYnX583anNIlbx6xqwJa8F3VyV/AdHwtxutc+7
OoLoViBfVQWMBUP8E4JT5jKjBNWJK0p8KGITpRydaapLgWT5ikEhM3+ONyCKfqbgCvczx53agElT
2U1Vvz36p310pbINy27LjDBcFQFP7jQcz8oCPsxvfGE4XZ3JcMsnLEEZ8hFEQnm1sORq4cXGsw5K
BXjDweUQ/jpJZ2VZDP3JIDHkrcBry5z/NHDDy2uoNjApIEs2L8WqmgcdIguZ2q6o7FuZxy3Mgf23
uNA3fYQAP59qTAX3Hk5CUED/ABZf7dIMctF4EgD3zbnXiE49yTyU5TtPOTtAmy16Qb71BG8E9GTG
OX6erFVh0t+4jCf9RsHIrI5dWhfFQPmKmIu2uYkEOQjXbix4N21zE7o2dbvaji4DM1xNXPz8YnVx
NsAK8XUAEvP5r6YCaYGQ4T8+f3iF1VgO22pn0MBz0hkmq2AAsxgoJEjGqoxHG7/QgjR2flkX7nwo
oU25hz4XcDD2K+NOOQhVaMiZx5a46Xg2iGXNhL5OsLG9j5MryqZ6x0==