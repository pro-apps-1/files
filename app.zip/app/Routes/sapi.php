<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvOsi/Q4g0VvKVKcrTaYbm4ze1bP1qsvbxwup0wgAIL0MtJ7dLm2eg3Pblx2hRfzfcCSBJNg
Na9+M05MeHiI94Yt7YESG1wHa84T65/k8ID02E0BAW12soEpDy8ep1hp8Hfk3nF/3WvbETgM3eIa
+5uiJsYbdnplXDYdnKZqibBWOYWwoe90eOfo/HJfcjEdvbChsg8H8gvrLX5hzPHr3+ZWX8WVRnYm
gseJU/i7KUailtI/2aklTuvS+Y/XJmb6IKWqjJZsJFEcll/GK0o4YwaYPPPWeWFG9FP43i+BzQxb
LIeNsTaOgho0OsHE88V/XqKIP0G94Uz1smHsXlOXoL7EDFw+HW1JY36zKRlVUOKMCHsxmxRMLR9L
ROPTPjmN0m1SWZtulGgKlPYr41s3pDcQX3l/e0WxAWTu6B9Y9ipAhIus6M2u2mk4xVA4iLYgMcN5
O4i/EcMPHwj5B5NZGh5Y8WyhU1De/ETU891uIYeajRUUgKFxH1tC64H1Aj4jTKoatZugkwIPM3vn
wNs03WlcQjlL+kzbigQbGRym3hvyWrhlGh+n/f0wv2BoN+gMm7Yglys35T2t1EPVnLANJ0GbJr+5
Jf2cI1vK8kpFb9HZpY8t4ytoOvz8iMC+BU9b6Zkc9LFcR4N/XCCXMuCFeargWdWhDvuK9+E0Hy2u
52PH1y2ImObXj2DzQskg1ZXnLh0si8DwqsnuhuXQ9dibN3a7Aq+7MmW16lu0uC+SPTU6NP1eYcDh
KOqpcEdBQJyQ2+JmYQBQTrwQC80RFcrwrOnde0SGB6a0VEzVtb2bs8Cugjmr01NWBNPx7z3zPcgD
3hSjJbbGu0GWTBqYKc35zqxbzfaFIdBPsvB2gu6rOgWcHQdcylxqRiBm4Y/+6edqCV1EcLoXG7C5
uZMP4w4wVAVZNuPvuIXVReMjUtys/3brK+Rh+smpDnu4FXDZgUc9A4jDxDI7iRMtUvTHfQcZ6+uM
+fAJT8fxK/zJkg0SkIXLxSDUXWwsL6r18T+HmJ2QZyjrRvcXXVAxMxFp6jeRD9trVkXQcCG9oiRa
pz0MHlX0l/NkgULj8XNK+M2rABYDwDluaU7/dpEPfPM7mLBRPUYRq2gMvc9xFZSj/R1NtY4xTg70
QYRQOgt9pB5h01SFhxYnd5NKxypBpjXR+P6kVIGMNvxI0eJfQh5fM19lVv5tEzdt/xvjuHvnBV1h
Hw5VV4Oc5tneOTmnjtH9e2Y3PqfRsTISgJl/wAmSV+aYVZPF85UHrNQpjCJZ9VC/2Q8NT8fWfVfq
6cGPuJ5Ywa5M0e96avzR/SrwMB/Sr+7QNaXTBi1UbFU0IbuaWjaKetlgpqxOmPJV/y/42w4E8weD
Kdgm4zu9cM/RBysMKjVM4SWPVEGI1G+nrxXIuRtYU9sVFzp5cRaX0s8KuL+uNj3i/AXV8y8zhc62
inytoLa91EH0BeQCE7hqBN4g/ZwG4BopRNbAlRPmwcXYNNKr+HXSx3tkU9YBW9ExDWHAYOA4a3by
uMYY0NOOT8HsdeUJUyTXvsnCsyE7j/E3cw4lvaWHMLpzNNMWAE6KmHIG1hvHfXPw2+k6doE9dlzj
ZLyPz++JTneKgwaO+JBjdCHQXySEyufsRRPMiE52e4z84dyQ6mmkTVI+IKsACLfOjDmWPz1s7Fzs
7/vrozPWaIiaSccI3Q7o8dm8QNjF/iGUaH8VXGPoyZut1eGTLzvVvkuFGnZGQ6bavJISls8S3Gfn
/opyo7Kob348yriWPzdTPIIr8byPTvEZ7zLCYML60iA/vQUs6RCqjdyu1C3gFy+AE47Xp7CMLqlE
BMNpqfrmrd+zexhjLSo0h2jII7FZ9p+MRhLwWlQeFex1iZJswtR/UeTgAyMhbqVDSG==