<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnzXjKm0/0rZtQ8WRw8PaAY5svymnaIv+hguVvB+KuEIAOIJW4+PbPdcnyy+oi/ysR3iW6CZ
mKfMk91c4UMqJJX8CGoRhwHlqDNQowcQ6PczlJ2AWBN/MCfUpn7t6zvGjq4ZJ/oaQ26kLl0ChYJj
0mdgSfnDZ5y9LZ51+l/qOIyZ+pxJvsy3Zncw8mqU6BV6KaB8aoHn67MLaAUlZJvlGsVdZOrcFWaj
NFpDIHZS3NfTEWy5aE2H+FfnEdn0iPHLUdFoUUReDWkAy0QnKAh9nAMwMIvgNhFQsD1/m4WR9voh
isfB6xAfKMKCDR/Glebq8ampOMFQfzMNnBwrwCcQceljD6OBLp17BTC9Ar+GcPT1s31S4iXrAoOn
g6rf3/b217i8gCEwDjmpgYrBLjQwSP24B33VeQpNdgOPJ8mn5r5RjhTo7PswISd7o2mrDuUzw+mK
tFhluAHEunlwO5usXLtQNn6aJbqMqYkKaMDyfJKpdC0Y4NLV8ErHKW23IA5XijUzi2YJQ6MSWTKb
QAk+fdFKzVQDH2IB7q5FITIj/Sz8co08AVmOlHsNliCS5lq2yrqByu29Xo0H+t66SNtDVrGk8w0P
VsZ9dPoWPLBN2zS1NbvxZ+GLscAsxX2dOP16HpYFKgWrmQqkCrZ/uISrgVc/lIO/gDe4OcUQzfbo
AD4wOeuJfUJVTgrYeUwM7DJEBvMfo39IjKPqQ4YVx0oLfA5amW5mV8eDFScUo2jea8A3IQaQu9wu
Y7VIXFn6AnWMHqyOhnBZEmLkZ8rZN3rDrXELJxqHibheF+N4PMrQYI7UjtLMd1+QjGVI9jpsiVYx
sHmQgKBA5OMvPJJo67j3MXYHKczIeHHdfRzmzbOq1ZtQZ+2RKPzva3XJWUg9MIPHymrjPNhX6p6a
vz4VTvqoLqWLFitW0LJFJ5s4CKbbnf4KNl84CKaiJYNb9ktf090ACnWnS3EiHOjDXKapsRtcVh7U
sOjKU+p4o3KZ7VyGCshCaxUj9aNkcWySS3q8wzDtUiWkHjXOHfnI6G5PmOBwPfieyfsFUEZxCcCJ
MPclkatEB4iWOcUZKQzJ8nGmOlrsl9AYZU+vvNoqFG29E7pwvFfYacCTsGITLMBayFXi4IOKx8M0
lBi9NkywnkWZcgQsm4x/xeh3lQ72Spy38SJdo3iUahdaib150z7e3nl6i0Uj6HRuffdAolOO9SlN
j7Gvu6hOnNqoRn6HACkgl26sZ+2JRaChtz6NHKVCMNB5357SaWp9tJX/Y9+L8rHNw4ACPZEzLxnS
VG2gPrLPbDrLc9lV/+uxfZTtk/A233tdjaVuiWOWqGDIQqXDXrqnTrAROk++immteqDUnxQQf8Es
eAUg0fiNCeXTUci/utSm2Z+hWy9VIUxxvLTquMEjzIPijXlI70d0wXUEyKaiZxcN7DivdDstp/yd
Dajv7g8v0xGdlicxwoXFZGx2z1Op9E/Q2NV/tSjTfP5WQvRGbFji3NkYIhMhaNvMX/mlLPsWVaR/
RFQ+oQ+eDttx202MgMX5f2pkSYDkxRbmcq6JhGc2mAmtSccNnOriVwJ6jVq5oRq6vIPHA2h1hPVq
hYntJUcw6tlXEQjSSNc8EcoOCJWRvkBg9t4iKvDMVWSMuvYKvb1HJeMcoSO3UdtWQlpmHfdoIhNV
zF+1s4K7GOH9RTPAeLMIWH2DxUYPhtqE1Tg6d5SQEYJuU892bV3jo+qUN9nvPiu9cHVblkfnMA1P
wrGNVUyW+42cD7gq7X9XVhPY1oFZWnEU90YqgdPoqwneeVvrOHHPFIUGKMKrNIVjbbE6pr6AqZ2l
fKDr+uSAd6djnpP0yTQ1U7LcJDIblXU53/ZW97pOiad9o9HR+CFCwnLWpAqU4O2zYqaE1G==