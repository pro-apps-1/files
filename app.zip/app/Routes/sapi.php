<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+YL7m7/daZaDZbMYY8v5L4355//y2okbewu6j1iLnjhuzqoq6Puf8++zgMwvUUeE2SJ6Rue
Fqv/if9Hmge7TF8BQGTgtSjm7lUHO/q24OEYB5iPx2ifdQrt51dyJuM7NiIxyOZwzjiiBhkYqA6G
FULVjGn4+j4mD0B7OloAyvv7b9biRXa567Wf4s8cRv58hdcZfeN4SvgJViTs5UVtDXD2jtCfmBc3
sAeRfKrhJQHlLnwLIpNtwhA94AJpFWHVk7fqCHcsHeRqKnR6xUgE+EdiLPTdNzsIWqgffutW94a2
b7X4+1yo720cHuSHnlP5qxm7CpFVLHAHQ1nKUvPffZdaePDIYNMbUmyVOV92DFUUGRa6jtLhlma6
x3d04ldUQSG8qlddx1WDkQxTPjoz9USxKJJPpAu1+7sbGLBpds8PAN01Hl54ZYCYMYf8AncuexWT
aUnAmEuCBbrEME3fUNR54RLQWCEF5HIxcdteKH2mQEHzrbnUxUGfJWZ9uxXLOqx6tD9Xh/H57jSN
saJ8bbeGdvXT4/vQCyt/z7LE0OMHA6zIZmwJ6UxjpVg28H2BLS+BcNUtBSR4h2sxamEyhutHLLqu
MqSdlQCNtGwczKAulEUMgbbtaPLhe063XCDs1ZTN0QZvLWqOb2ckpiznA+mYK0oKpSG1tX8Y4otO
q8yfZH444UeMVz4jwF5Aa2FVEW95HG/cX2rCrB021lrSVciIYCA4hDtwLIs69PK+PhmdC4YW99zl
cws3CR8YDCnyDEJXT7f8D+t1dSDazIxas3hZujfeFr88p+I/91LKj/QGQDnVl4Bzkhb7oC5XoC6W
LJ0g/li+a1BDWDGav8i2RTqIxxvN5a4I0KIbKY8KlAg+77xnDdIC+dxnD9Csu0X0nmNyl08YNjH0
DJyQGYVb2WdMmqcfnQQNZqVgdlVuA5KhkdSUHUqnqC9WnmKl5Hy9rLpURQRHQG2ZZRKcIKGgj1eT
TNWeAgxdadRV6hFCCFy8qWh0AX6h6wvPgNCP2XHe9793hqV1M4Oq8zW5ZcS0DHJcrFcU539pN11l
tMMnkhma6+8740qTgwbiQgEpMiPLW/qh5ooE9o8jXd5765P9EWOzg0/0emd4W2Mc5/R/J7YuHxC8
+sE6AubFkkTDfh02vFOKCnnPBuyVtJDo7p935Uwmcwa6GvXe8uHDIw+uBE2HnLtXKnsGpc8Ho1/w
2uRqv5c+l08rCF30kLuDS5f3ufHsfp0lXgANErxJf6f9ySErfgGAHwoKkLFm1i/dYg54UWOQOwU5
Zk6v+KheVTYFm98IQtyNNiLkL7D9joPZUqAb1JT874DIeE0kWntWm9HN//Pa/8x5OwYtKlHaFjla
afFglAr1xO+JJRsp6Ai6JYwy7XapqsEIs01FrccQkbO4XZjMOz/BVs7XfjyMHyHqwpC8/bhCPBuu
WTgPmwNR0aOO651z/lUanpkYV2yDIvpdM/W4yMXq9Ahtw5nLXYpAjfVCZTIML/l+iSH3YJy3EP/T
6BtgQ9yjZErrzTv7d4IJDTxusJBzZYYzdUeSir8+jJBiNhKbQDtWMJTiDx7UGkbp8lKEhuxZCcmo
GpHSmhchB9OScAW0YpKW/6pzea/myenagRyEg6X7xVPKxiDsNX15iyDdS9P8Yp2hEo/mvhtf41ne
Q0hJkozoVqwJ614Ki6u5kjOSs6sEhL1yEacrocMzGkZigseZCbE5sPrduhO9rZL57qmOY51JwPrH
Cbdc/Gh/UeL2+DTeGFHuCq4QdZIzbRWFj90f18BWV1rJxxZ/hn2OK9N280VCjoVj3BJwDFCpWGER
xRe0T20ZKQ7ifc/dubILRdHLnlJdU29yjtN618IS/2ZyNRS7EGGS