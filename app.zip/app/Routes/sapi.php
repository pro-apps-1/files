<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPslXlbZJV0EVgY8hU+4dFimjoOwowPC9xQcum0Y6YBm4HWxET4GBXsfb0QKlsYS4UpKYK4GM
ti3VBS6/by+ouObRkQzNKoqX6k6EE6OcticaWcO7srGJR2HE1tvu3yCCQ1yzUZRXNh/b+4UbVBgz
Ip9pLhYS5K3E+OmHCeMw3OulqXORivfvkpLSfKD5dJ3fT+7IqJM/5a3+6VpkUfVXkrK2Pa3bXfFX
ihokfx4LMCleEhkRLgvnYzb/dOi4I/CUbCK/q6Wd/76Lpb7MaO8rknKwRpTcsFvU8BBa5fzRbT1Q
GZr1/rf/fxPPYixYA/oAbrzQ1/332lKFAdDtfNeUYAqaKPMF+5hMKWhmZ1ei3yEEBdqUz4C2ruQC
XZuLD/ssnp7Da4KavfTpPg/Saz8FAtWbIGYCZvsbSPqvQgAvNn6QqdyYeCLoGwytqEQ8njHKPesb
ed/1i7AlPRwWBMBe/sBhAGVpCZWK4uRNwfbbq/7MAH1E03qdfZRFlO932XL8HdIGId5D0hKHf0CX
lXXUaRnQs4hV+aejzrgQJO4qtfBp5VI6mB0Ju08220+k/lLTdpep2KU8aemwbMrl04vyorfnEZVU
KEXoeopQKKj8nBQeYmDvUnIk5/tVKDojSDepg11nbW4dMjMzlBo9dbTRrfzD82JFAGKBCusF0wPR
CAhtFp4kOJL/zHKt9/v3WJLRrs7ys0SWJL0vn11YPdcI2dYJwwa66k/7Es+CBo23xim389P6TvbL
uYpqn9epduaGKbuwctm4r0iSPS/tdLH0b3zRXl689Qae4Ow2czfOFrlrN5frzMJFf61oJvNh4m7n
Z4ZqiLLjC2PGEqoYqXls6FrwpdsP1Cku+k0CPWCJXJA/UA9IdGqMKPGjiWwbz2EinAjfjv6FIjsR
UyGQ5C5QD5FVJ7/Q0/RYrJIcfCGRTmiOwSvMFq4DtkFm96IwMWCZOKFndkpeW/I3AmjYTQsljDYy
dgvigvgdKIwW/PeBdLartlqmjol7c9rzr0PY74MKqcOtdPmubH6c+UwwZzMQMZyobDI34x6naRAL
iakGSTxpDf9bPQiDrfp4M8NuNNBorrn6fuytNt7IQbtOoQmjg8c5mAF3DY111kwOnhJmRKi7z+ou
Hv+OVdZC/mSfB6sfFtKIYDWXv8u8uJ1BAR4RQynbslgo5I6AqwXCZZ7k9B1+50KXzFsQcygpc4Z5
thYbAh+ImorX6ZvaW77alE7lxhluVWA/y0BR7N+UNF4gYxbKFYhtUnFgpsIwF/88FPXo75rUeYuk
yYBC95TPQaoccPqqtRraGAlk0tqes1N6+jFH6kgSCKX7/2ReTJIJ+yejHa5mgaCUaPZsdl4tSAxX
bNjCcL33WDgmWqtLbnk6zugvaV8iJMqBK4adHeycydDG2+eo+iyPdzLbRsfQJjDR7tfuPePM0hsc
MoLpY1P37RYaZPjmsKg81zLfS6E7BjVCKI6vkq31FNikvySqxJRMsv7dR1pJoqTOjLyHSkhQDetI
+k3o+oAXV1F6QRzkGPDs+0+Ssz5iOERipCOhEne3CX10GmmN+mQtHW1uBxmVONicsEU4TWhV6nVz
VN6ZbEBkgaLlyjaDOYemK8SakxJBGSxjHaKko8LOMfDAEmLqo5683jqZdOTRn7fDlF4qDb3L6P5z
D7qtVzx9YIoovrVByVSOJyiY6j0OObj3KbHiYYHJ3ulQcvKNppLEuu1aqFSiWlyPS/3Mhrx3VVp4
KZMIrE5VmF+QT3SwLb4du+0g4r3eDoSV2DX/JQy/nTjoOo3u2SzL0kgrMZ5ivx32M2n/9zMwPk9r
0lSqQtXA79ibkx1r6BVzHqU4ONywqnolCRrEKRcGGX6Y6jCW6WkwBBmCnj/1TPjsv+gcMqKoom==