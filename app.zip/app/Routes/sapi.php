<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyyBy84bsiYsCCXbefOkvQURhFXvJae88R6uuqHG/Gm1cPeLV3+AoBcybpG84ZDpalJ0t85U
ZCugcpQ13CTUaX1bZ1xKH5rKZtlb5Aw2Mcn6LgoJXmU+5F4JuSp39SVJgINJh7AxRjtCD3MzUg1b
TcaJZfJ0W+stLBwq2zEo1ROMr4wU4MeLV9HWIaeFtVJGYyl4cuvLiBO1SmX3OgFBlSYN0lCngNAL
WVd1N6l0uCEqkIRk0VV4J2r7WrDL2VxbA6BT9+6KJ9tsl3a8lfHDjYU7lhrgNu5/0sAQo9pAQevp
qTDZrOorrJ9tPP0NABaIjJzIJssR07eatThOGAoyVmaTNCkTcrk640xDutvQWEED91l1pDAPwfIU
JRHRSkdoogkPAfQI7c0tt1040q7QoYRhGPOcUqYCwhzoU1EXYaqnNRiJH4ZZ119ZPAE3JvuSM518
/buzbkb2OjcyvD4R6lxy5w5t6l/2jq4oy7+FS3jaXhuV6Z0P6na+SVhq0fHYeECefbtos1omOKVA
/OtV3tc6+V7EDCN0BoOZiR2IzSyWTcn/g7G9Tg46zIgQiV6/CovUeaLuG2QMS8Fm0obhru0Fjw8/
eeIsRgGOW1R8UYU0g8iVS3ijn7PvAvywt+T1VpNIamvQgc//wLICBpsQLyhUi7k7+kMXezmkDUX7
qWOHHxlkzhxLJx++QRlmDsznkPL2funxaEy7lZwx3+8nGOUgkSpp52C2OUl5VcLyJWU/8LR5pc29
WBkxXY+5agqNEl16n5/CY1qI/JKOHYwjDqCNfPhqjWG3LuZuLyqdEeyTzgod01mzoOlSg6lPWDoL
MwOekJ9ioEHvXQnwNMDrjZLLN32GMK0ryjNRlHU7eYYwI7ryhghSajr6wiUaAsAUgZkUsktSfWRz
ornau8vVqcC9cI95u8BR51Da14Eu0wN93acTu+OT2XdYHLq7FZ4BWpebAq+ElWhqFSsoZd8Xi+M7
PaUU4W3INocwWFBt9buIIhJ74FxDz0ASUex0YHnlrIWjXBAQ1AvVmnFFj4jk7hyuHf++2ezUYuhB
JbKFs2+nTiav7+xg9vqO+QvsD8/5uxZnawMpdtQxTwu0Hjzt3Yn8Avh9HrRTOa5c6etLNaGGxsvt
ZsAs7UiXiSnM4KyCQzGmgoRE24nmCewqKV1zEqNCiqh6oMpIAt4A1XvCP6otoeIgbVAh8ldQevMJ
9kxsR3Xn0VF8fUtoG7OLQspWFzP5ZvPAWOhY54NQgRe26io2EG0XAtIrlsKSx1oWcCwAiHLhQow/
xMF4Dc7T4cnAaAhpw/ea6QM1Rq1OcbUljMuY5IKFqediVq6CaBJK6KY7RaMmzOrhGExY8KzhPUn+
B3dt0ybdICd85Enp2PBdZ8FY9vN+lPoKfdEGBu+xzXxtafH8royXEKBYogAFfl0+Dz4PIHXhRnlj
aFSkgpIcMqbEsUTzO7Eq916+IZ/3oy3Acv/bPROEMGdADhWV2+hu3tG0cZFoIBaKJKJnQYDQ07bX
c456X5OXao3vd6XIbnUoSE5Qg8Hwpm/HTSMfpTvh9qvf5pge2Lqo7QxdVmuxo21Ln8o5VmK4FX7L
jONv60uLFVftNPzT5k918z8nLfZa0pc7I8dFBmzmnQ7vC22zNNS1BegX7LkK7EXatkDBpEw8NZ4x
GCH4CovHqIv12ewLVstdLkhvzjiz8iSZZ8ZMQgqklt8BHkfIDvr5/GkQso8ZPrVaUAmGNkQQCtrz
FnUWW6cQtLWA+xmJ4ssKchge65jjwm3Cenndd63l5/uOa2+Pach7B0Z9DXO47Hai7F2bhobGcTZX
YAiR8dSeZutzbBzxm3Dps0JbLnK4cctjIFboYWzqZbgzCMJT4iKPlVLMgnC6DAxEBoWhe23/aSi+
