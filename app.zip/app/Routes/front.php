<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvihqHxVg2bHflP4FGDijxifHVTH7cOJwOwuHZc30ls5BhCHVPq3bm7uiKzGD0wG7atC9P3B
xgwLMVIJf1scsXkgWfsg9PGil6e7HRWAhl79AYCCT/Ud78SVXLT4S2qPAXl7ypU9US0K/5QJ998N
fPQjDB7oxAod0JxgGE6/o/S0U34n2DiDamfZDQh0zYLnSGVGWcdqh3gwtgHH3B4jH9FsM9WAELbe
+daIUmh7Z6zQqi2SDti4awtsfeRuBQZTlmEMB25t6JBBuRV5iQSE4ED60wvYW2Bn8Q68asBzoAxf
IJu4TTtApfcysFA0PGEN5SOS85Yw7vPG3XCPFLJZsS95LNHzHEVnhVSja+1aHWVZAGqGoYqDxHwt
+7jtgTx7AK5k2xqNMv24HCsvVWkir5rH3Uj4WLVMhStm8hegMjc4Rg8uGhWJ6JGDebTVyhjSlKB7
rHpFcLCnyOGPDp9bLb1mtM/yZioFyXmLytTGH7uF4h3o49MLzUlT3onCUGAgQ/2ZZdXw1Axx486W
UHWcXfUDFXSjzq33+xgZANr2Or85OsSAngrE749Qr9wO52v5D6+5P63/NNHvnryb2MaPYj/kBtlG
CC0djgDootI5ChSVjn9UxJtGp56R7PRIb4nm3oL40xTGCGwV1EjTEzZsp2B/nval1neSh7JCevr+
V0K7lpdpsYZa4ZgV7mYAEa8KhN7nQWrelZWo45UccOIpUYKg9vbpMXib9LKN5niraGKr4/txBf+I
YmxFvr7Po9mqq79bRVTlDPbPafRyWzQSSUYCrSMDmCkTQxOaLmp5GTGndr0rbIONzVhMR0d+gn27
JQjNOVrL6mjUEesZcW2+cy0jZ60Iexzunu11gGImWM+ocy4kthsLRjVn3flq8MiaTU/4UbgToXRa
+rldcIateehenZq7QfeiMGVvmjOcLiZ3BSBCPrRG/Dz0UGbFDM3rvoy6zmae/Yx5i3ZYn/NJH9fv
SmKUDEhz0jEyrFAlYeYdS/y5HteKA0Xuo/eNs+h0cHh3fSgantSSrIvVvQMX4eSZeIXKL6KJtOp3
GpjOYBPZRQnYjM+vY3WlI5+Xyef8Yobfkcod1byXi2qGokKoFKBBy7IwZJB2nf1b+Dk5SCeo9pPX
2hyb9YLpocFk7/DOTiEZOgbJWWyB6tMYicaSETcGTeb7E/wmX7UHxC8pJoQQ6YccJf3XpE4OuWjq
aWMdsrRncA7cIVn8ZDlFueOsNqEEkyHC+jtiHy56RkPMPM+YxB+7OJ65lHtSFZAr/G8ZI9u/9qJz
8Ye3SwTp9W378TakH9rPxGEYjeOvaTrS31ZyAvOQ+Mm4NPqZ/ZV8N1Dx74vQ/nZcXWY8iUtu8eWo
LMBKBgiobYgGoVvZ5FFn4HHOrwShlg0qvSRlxdFEgBcrKB0BTXsP552Uc+4f4yPiusGtGJ/He6om
KsBfIaUTdpCWGoHPLEexFLROHUu/HUYoZAZyT2qE3borUow0E+decaduTlJ9eTQneQJCNPSbcBZo
AQuCgs7Azy4Azix+uFU2Ssp31awRNJdH46LYtvlk3JEZtuKeOWsJ9Zvm1nEW1A9cyiX9sCEQ9r3i
ZsbyAu1kPp9sTU7B05XymCrw03LYFnAcmIhKBEx0xlfUXt2ES/BpifdbA/k2pZW/h7x6iG1N95cL
CVmFCtqQtVP7HSrn5sboptQ1vJu/LLkOayCkU7bVDwiXs6kHc3yU6eUcIG+WDPyUqTSK7Z3oayCr
QEFsbkgTlqAsgGFnE0h2ihvv3n987rr5WohIyA0otqNj0tz21XyqXqSq/ihGpb4q1io/xPwUsshg
FV+COBvCwFp1hB2lk29SJiTi9gLHkoUBnYU1J5VF8jkhbWyiVQven/73TVC4je2s2S1hJEQ78EPD
9sOu1KEPK1nFaW13Rm/WgeAi/XmO2Vb4WFb5VU/JKXqIlm6k2pfxQfCt+P8P3eKrfdMb57TUvCQi
yiYA1IY0jHa8ClCQ0xoRatQkEIpCmwUjO/Oxaq2EGbHhUra1rxkddXM/OLnerriMQNtO/Y9Qs89E
8Hvv47pcLxkwrfydi/pYc4sxkiA3fs9s2NJrlMFYpPexzyI2SlnZIIkxj+OJdlrL4P8obWMuinRZ
+FcVSbYB3IpU3n5Qrj+xA3A1OI1nGTKBdyccHPqL0osWse6cPFK/ed3jWNrNCk1cP/QawrHIwsU1
RfsHJuaSUO6gClrzomJq4WsjpBjod18iJMqTY0Vh7vDBdNzETswTMv70Ttu49lMJX4V8MngWYonq
9KWTVwaj4rqHZiTaYBwgDPpT928vZJHnfEVVPCBrItbWInyt5ef9tYHYvmRsdVmcege/0RFH+Av3
ctQ7xkYorXECeVtdpaRvGOrQfhJbdh115hefOHq/RuXPDZtWWE+KSZVFGzhH3aM1AmUlUqwycHuB
sW9Mf9JQ6h3R0vI0dDdbmkUTcwlEFd3igtzpVNWntTyiAIE4zeCmrCU5kChQ4F7MKQJeaGKSc4nc
d07DPSxZEYdsmGtlquHHjIb6gStHdJuhOgGlkD2LlqNMRJ8LXKA1zEYJoWAWWJDV6txDoAvtwkHY
bBCSiWJflAyKb6mB3F7I23eRZRtIop1JrkEvmzaoM5tRJuXz10s13EKISh/f1s0RdXpEqeXgXOVe
7JZU8MbpxnEu1aYhmcx85qb8+2kPCKHcOkDC4JCAfu+sZZKP9V2TjEKGhRB0M5ly+2w6V1l/lTLu
m6z7lq/n21ipxjcuvNUhbqMO7xRYJDWtWgldJX8ZM0Ql2OTPZZkdM6Ur5fsehdKVbacbKcAvmkmJ
LzpaTxeMKWhI1hIDyGdA6L2+8PyPvm==