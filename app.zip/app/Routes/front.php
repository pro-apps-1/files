<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmPU2UgS7lBDMOESoIWLQfvpBV/0t2Ic2eEuek29yNmn+AzqyzRGHQlmD6nv1yt/89qNe8mV
vMoQvsjLdRHRvdlEgYIjRFELW7pyLtawNK0ZHMEkiQ0M94008zFx0IzFTw5lSRqPNAgwzvqV6gUT
qh0KXN2azHGbXjPESi/+y/kI3Vrvp0WiqMsN5WQYdy27zzq6cyMj7Ej/ttdcdqhWVli3REB6pMPm
7MVt1zbnVWL+1gq6o2Jeq5If7Kz+ObYYdiT+LlQDKD5JiWCuRryR8iCogcHhIlTu4xU0dszJvK6P
6patFZ4ZTcrRcMm6844IqLkiQ4BCRYwwCsRRYU5v0KjaK2iBeK/09duHJrUi+RFE+n6pVPp4xOYr
CnyYsafW2fbVbv4bmBVZIrn1GKMpSqY+4fBgve5pP27g5uQCZKD+52WUSPOpcqkWmLG/3gRKcHny
r0jt5CQBh7ZQFuIpwmIGK5oMRIJHnypplmnh3uO5cnlx9cMPmoRpYe1ivsFwV4ULvxXqeD9orHml
ltGeRysgsbKhtO6PsdVTh1M+GiGRqF7fqZtHkVBb+tW+kfGtX1yuUwz8kVXhPXGfllqQrKJOrllO
FRTdBA77Sg+Y8FwE6ngZlEDAhLOXXylK7CViPEXFj26pL5F3WKiG+A+FT6xzvKi0RYbfJsdnEnWx
/8h55RRFzOYFiFcMpfItCyPds3x8j/jS/WdCxoYwV6p9dtrjhSaMDGJzCZMfSHxH7zdAgysTS/zY
tkHh3C0A4elUWQDbO5fziNjP8s7kJckCt1uU0Neq2F9imj+idUgGPtbfzl0VW+E9HC/704Bt8SP1
llQv8GEIx+iP6fBc4G9urMBEs2IFdxP4aAwV6jHzmIrPhTNpniX9nse6pDZhS9LXu37bIvcHl46G
a5C/atuqEujovuTvWdROTTdA6A+jblMSu7E1wd7LO+56zNbAPsy83prGM+BkQzibW6u/FmIIB1vp
wKQr4lyUeIO7BVyQS1xvrXCiMcHDdE1q0aDIrtqzoBIMb3eFUg5lPDJFV1rfovy8yNVxFPb59aRa
djQWdEO4GvuSunBqYl9OK594OzGeDKlmFj/MnPwwiFtQIfpptZJ2WTxMq04LuM6mZ7dmeaMRszCP
bVZAHi+Etm83qM9DqDaIwfPTOIjeqblcMdUTXZujAhrXZDDjCy82fB+pd92kwCVIhFjo2qIWIwAz
rlKPgZffn8TavQ7fjEgRKbA8onSV/47GsyqxGYz7zbCrjA88tZA3lI3CKtl7d8ztKBw9JvFkBVqI
iKf6Zc4nCwF4lyyOFyhEk39RBeC9nvF0ARJBhjQhtZuDscmhNl8a//VsosgxvUOLruIx9lrhIPfv
/9j3L0vpSQ3/ywgeEmUrJGE7oWe3tjWUVuDPIo1uWi4vM6X4J2YPXXjg9vLT55KuMt/fRkCg7OCt
pXU+rw6xlclg1p7k45LGU+ekgKPsHJUCEcpDhse1V1+gM2XUskProqppVoqdPcQya5PA7qj9KBPK
j/NZDZ4Go9jUMvHLHGxkf/pqvGfaNmwxhI8FL/hz2gIumYK6omP7m+CPZN4QvnZPlxcTsRkaK+sD
3WNL2vx4pZMAhgKwE+21InqEMtOAuJD/PjNmD/gopE4w+9jlsVIVaRdd22WgwsUTRiTYnS/Pic1h
fH2PCtjT0KdUlW7/Q4mPvdy7iFEXZXiURb0emJYrED99lIR5GMdSNmuZRNVQM4JFpQjQpngssZuu
pibxOQDprTp/+DoCkr8L6WMVvu2TbCKwgSj0XZ8UZF5v80sFLAuamateZGPloaHlfYlQeNn+OLkR
LeA7YLdHvkKztQDN4K6syPSfnoNWm9pt+HErFb2SIHnIEeoB0IpKBLq3bZRS7kkWRTXa+IeI/2xd
ZBya6esmKdRVPgUMEAfXb05aBal4WZeh6J4Mz5UMZ0YxcwwS1biH7B0zHYQfDipK/TAf8//2p8yJ
vt0uxU4lcHiA+MlidO2wQYSChyyTSPy7hlPIpKSVkjLMQvbWysfH1ykimHQ1p8KEQPPiXyutaalY
4CkbqZko/AvX43dG+s/gUKBR4gOMZ4uhWIkVIIm7NODRolvpTXSQutwabZ8AsSxECz+7KNN/k6Ig
7lWAMRx3vAHtSyAsbhl6QJyE6tbTLNYq+8/DuBKqKmbvNoGW6pe0ZZRFHEapCtnOfX2Pv+Kk0809
vlaP75yFPQkpCoNZ3+EC02Q4Q+FVE9mU6MBnVUhZZPynuGAcQ54k+hyERzfJb+z/i7zhfLHOqknH
9RhUckehYrVd8+zVcgnjIeUgTZC2UYOrA3xBTRQbPgVmrI9F3WX5KAaxSDK7pR/pN29kltW2hylV
rvVRRp5Jo4X7eiZ3lorSDlXrfY5hDyMgLTjzzIHPysXMg092gGIDwr3Qmva0iIQ9g/mlRHGUxUJh
dcwazAkldd+iZBG9G9oN9bVsKIifwFTGfSNaJGVFKh6+Z35DGJyUEXDK0ncnCy79M1MNhFCFTyLX
PoToIoQF2JLq5F9H5OW+JCfujx/ay7nj4T3/zoWecXtONzScflnEyAkf8NtVJOw6mGbWPcFBVcJ4
/t+HcxReWaXruNJfj4a7QgddtH17TXv+HtkFyZJbC29kbkwpRtmSiQI6ONhSgksdAvhuiqrip13H
32R5eb2Bj+pHnjf6dRwj3x/J1pQA65ee7dyMvkckNA8siDY832y=