<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy++VDJgFqKSysFfznQit6IT8tl8bWx30fguDXwir2k5OUuJbuJLLRp0ZqeAsjhQMqS80GQ+
2uwAVM9pRyvELJtmzA3MP0Tqtt/V4XpFV2N5Cc8RIpfkkCEDgJjh+OXzNqW+fGfkqZJ23RUBzufE
1Te3aEoMfQgfBa5GbtCDg9ebwuRaO2GvsUteKzx2hlQ6yE6t9rQkSuNCADUYZPSBoklxm0S2nMqT
8CpikBCVeYgkYr//0sbL8K1pxrL3qmL1HVOG4No6JafnWqg7SusbEtg05FTdIxK1KpZzZ7779ONa
fD0ZJI1T81DcwTYuG4yJwxeOl+VWCBqJ8eQQv3KDB48f8CC/ezMspWPvQ6WHnOBFk7pSPB94qFe4
XYsMm5Uji0SNfAj4UidF5yXb3KHLXm0kWpysCKEDGjMRlmsCsn1JLNhgTJ6Jza2Im56CXSWmPP65
LM7I/wsZI47/Y4udhRxsrXqVuqkMWM5/fF8Dgo9HoCL/hdJsacoAlo4fqylZgsBx7SNggKugZhvD
R9rGXXapwU9l9gZo7QWQbpGw8oFtpYgAh3Ctj/qi6bEmoTdJTVE6TXeRYsk6+084fF43egU3JAMB
uUpXqvk7h2aT5VsE9n83XmLrm5OtIjqDQFcNb7kYIA+mDjnuZ0gcc5x5RSc18dZLoKzXSlv2pWvI
XJ7rXSTRX0TuxrfaeSUOQPHWuWRkav7kuYCLTIQplU7J0g+ogJ9zplLYpiEKWEE8knZIVEb5sbFr
S0gOFSmh7Lt4siNFspQfe7eWzgRrt+6duq09W8yW76vkk7bjsoKXodPcZj866GS007lyuULUiNk7
E7EGrgp4gGx650Vi3Q9T3TpHNUei1qEVVFihzG4toa04zuhL35YZRyt+8+bc7ITBM6TJYw4/i8d1
oZf99T+sBlsel5Ra5gCQ480NTOs9rzPbOu8hDJ+Q9D+2wPjdkw7+4QbJGYhP38xLmHjcf/Zh+CXS
Ae3WXcxRj6Me6MclMDIOXOWKWpOJvtYeb7U1FwoREF2cTON3q2YR/VMP+HH8ltNQehCEp5ban9y2
yO2Zi8qVMgCp4iDJ3FLMkQuTKcuKi4H5TN0qPRjpWY9gOvwBxvCcNXbkazvDo4R6Gh1oiubX3cBv
Ty3goFOkeXeGELUl2RydA2pydG+Ml8ZHnNS42p9ddBjNnPpiqKC2DAGhVGj5+DX5n+SLDRS4I575
dhU8T1PmPzSO5NThV/LGJ08Ieg1zvukg2LptVnzBWDXUPrSl0Q9974lxJddfAlj+dw7hmGbigfXv
JIfuNMDOIB6d2zuD2KZorXsJNLarDKKWWdJb/zTEjqrreRz1fq0g2QvXBhKTNUinqM9lacUlni+e
ICFNLAXSK0GzAIL1GKpvh6PscL3LNzBK5TMjDdAYfH/SPsXYjJ6zBJxXN3zmUkLjtKjHaWcJVIw0
Pw1tPYvGWrDX7jGi+pyvAgVSHcdau3fh89tfTA6St8jTNa9OBwelAw6T0pz2U3MIxcnhaniUu3u0
eXLUjOjLWksCDJixYngrVqfZe1SJiupONteKTmuXTOb9Y9u9qt7DLfDUHUFuuqsnQ6VSjHYGVCi8
WZJbyotymJhqhO2LpA1D9Ms3kNl7LR1RFOOEsUpcW2K4tYxzPPKL4ARzcc9YCduW+VYS6Ayxi85D
FZ1/wyb58wflVQ8Z46ELLjcsA0zgrbQJS/g7u+JjkFJGC2F/sEic4WE71JbtG0LvOQ4vhqvnfY71
Q8i9FomC6JxbtmAU6r1A5+mdVPO/WwRH989UneJcSdXclhxmRfweOKwQ50f1vxqfbOh/S0ReBZVb
jTBcb2o0EyJrVgFrLu/FD1Y0Tu//GJvMhNNNkxaT71Bjxbu8B4XKs5+K+NrxFXyNdM7YQdMl3aRB
O+lqrcdSqvykU4ozXjLcCG1F1df1LaAidOxETMMYdAuM0qCU6KU08vySC/wXil7HLHmXqvGbu5NT
AXbvVC2NAnZl6mkWCiQgMRKWOIhSm8EAfdMukeYzr5tiHu1VsFeKyY7ewZHPVzI3oKSGizTA0WCi
9RU2CGFx8UeqdojEDn/KTYjC+rDfr3jXrTIABObRav2e5fLXBZspZ8jQymRgjc+RGoLPqqiAa+Sb
1nkH3Qf7cwS9jBMEmB1tTG/ysMd18WM9iOwJJi6xey40Z//k6wovIvOQHnOfR0QuKCkmrRF5l7/k
SKqOY9vpuNtMssUwM1NNKu/UsykegZYEFV5P05xYE5D2O+VQG7PJSvumc2FlVFGVUkOni1lgRh/C
YhAQDiU1CotNu45o3nwqkjYCiNjZgeFMYt0k002C8D2PQaO6SM1HIk+cFqCSBc/v3WTHK1oJQiEB
VynXZw0A8ypWQ2dVwCaJG0iRwCe49201lFPF4HXglZhz2r0ScNugu3FJnsfyx0ubsST9WKmpBBky
8Ckb7XoZbJrBnL5LzYv2yp98mcIEdCRTK6EIa+lc3Tlj8tJIAANM0SEPON5bK2OwixYvQ5D/klcI
56HPoigeV03ki/D2u4eP9/qL5nDnRFNhAkAinBB2ubSwOkBahFm+bDY+919AA5PDpccnwQZusbyn
LtVTesLIWQCkm4H1kqY7l86W0sa3QVMaAnZ7WEl7xhXuZv6fzpcv/z2Cd4h6Y8owpAUAZHyOmDOh
R9oKbqo+pqwhVfCVqEZTPwmQny9rdt0F9wokcTyUEaLYPJ/ZlszB44YsxR4U2bABbKAci5InUbR+
+MQLKcVt84n0CEn0PQro6gL8WYKkR94QkdBVHHOL6OXIxVAhmfYEvXHVxdY3i+oI5tVk8clz+m+r
LieP2kQzsrxgUe0nlsqXqhULeFFZ