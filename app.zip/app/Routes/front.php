<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyNqxxrUPTIo9obwdWPs0FSC4LgBYT8bn8YuIzS0grC/fVTYLDVy+pBbD4Cb0dJyng+7UV6R
bUy8KzSga4H+hfqr4FdqCyCkK0WwQKkWKDkfndpoMrvv0xOFCYUCnPhabg8f5fvgj59WXiPvFHQz
NiopwwG2jmrjF+AF/LjdKqqKaINlSQDzMdvfKYNIBe+/PkJRS3AHLGt78jMzJFyF+Jv45omgy8S1
gf61OT2hlZD2hHk7IMsV3Lm0tKGWgkpwaay4yLvyD5SgexbHR420sM8EOk5adyxFo8Jhl+me0Us3
MYe5cMy4SFFWa3iJanmKlnubXt+qXImGi8Zs2ElrPtqjibA8uiUCmBYA+Wm33pWG35DUCt0ZefcT
gi+qvN7NMBZQ09EsRn8Cg7IL8rw6Nu0aWVawad9M8PGHiqm26/aI5BiErvyStNyKnsGLu1dhoxLP
PnI3uRDcX8MAN76kJsNUsPClr7BKLSAhR0k67qDEg3uB+mMht710Ksu96OL4PMKZblB1eEysTvfB
QOa62o0jY6G3oQfIZkqH8KEmcYefrCsunh2v/Sd6WWK5ea/20JjStK8ReI2uUg+XgIwzH3H8IY0Z
bkRh3NP+A00m/Mp155SSdupl75va0q9Ec2/9xi35BKCn7M9bJ82lZyJUDiynBtqiRp7S/NWBzNyI
23TGSKJiWspRUYfSkPh+tjUybeVdJfOAC85IvfQVy2T6O08WlHutaBHOlefZMNxycGiUahCi33S7
cerMd1PdLqwkkssiFHNNnm3lY1onoaQ290oP2VwsEP7k46oT3+dLtGcoIDuWIPHzthJEfY7jyIkn
/f1XMelvVraPqnu8/6f1/oKpkGbpxmBbnKvizwrnffoFXVbrgn9V1VhfCWE7+rBzl0kHRFoHk5Tz
MqDGzEzcoNryv0dmGrpkm02pFOHDWgdGYsyu/lvZjHimLJ4dTVN0G9eoE4uvO0sz0hLQkvlRFZdo
sISlNw7QG7vlEjDClW5DDd8XUhYs4mq65uwq3ctt0AfzOQUk3UnV4wce0Ao2SxCOjpdWzKjhbCE/
zapOZfpd63Mei9Ykj/HHDuFo4eYDbIq5GFOA8xefm9yAg/imQz4bcOC9KWpfMdhgYpRwnVPDV6MB
znYCVxIR7cPDOv4daSVKfLq5sexSHX0ZN5osIlme7f+Nqpip0+4lfKRXsK9sTmFmsThnfShHDax+
jsS8aWqE4mq80xEodFItyskRbp5Gn5CE4Y5AY/vQ9CbCK/EoGp0WCd4pOChZi8tESuRjckH1AnAR
ZbC3BuJhh2cH59z6o9QKGhE4eiZMn7to1BIvp5ydbnAbRC1YTj1QoNPA/vSneE7GeEFM7LQv3LQZ
RUL2yBxRhF6WJkY4R4v13TzGvRERQ6y9g13PgQ1Fy3+GrSN38wSBYIp20JqoCBtICUHwTyL150fQ
7NLtKoua7+VrmtM7eBwVWDeD3yK5KPjM2+WBxg6iQnO72LauT/032r3ODIJamc4012DQbYuZe1s8
YH9Mk9jR98yrXSdpE0OvoUew8pWwMfAhWT2hpCPA6p/xhXv32J8lIsYQSvim796vmYxj1tf5raFT
Ui8JmouBdGk9jsGF8xwEyKsxRcyIrtTPnddbt2JiEJalfvpRBP5VjpirJG7qjK7wwqeh2NmrRtwp
lDYNblTbXYqruqSrp2F/IaBM/k08qNGthBjcleK87JwPsOK/Xnuxe2Zbgcc1Wpsh94TQdZUfiq4O
gCyTvHHtCACcI9Xjg8evd83BdyOv0Vr45LWXQ0fzysTiFiE05HY6b5v5T0nXtPZJMOjhcI9Mr2AP
4Th5Vts+0tWE0udeUAug6kOqD6ixJtYp8CdxmIYuQ+6BDS1qJ5bwgFIiAMFRGvMFT4hynmAdcsI9
02430SuoPXXMeTSJagYG3uvtPvWn0uUifXHD8lp9UL3d4nNycp+Ja02Sx/ZxWV0+huVBuOe2YjTf
ef3ifocOW66M8WNbfRWLm9+5zalIwHsa1IOTwvNGEZbxgSO/XAe37USx42C0g6+J5RynjkV3cYzY
CQdV9GjMXV/xHYuTTBGsMJdFZocm5v0G94uBRmSqBGBF3R7zVQpF0KlEKoe9ZRChMklyIvKvqT5H
LS3XQDNbHlDnwLVR2bshBWg8DdBhi6/4niwqMJ2ABol25DaLTjEN0tfjjgH1bAs4yMcCdw2+TLoe
HMWn6yoz79zIwAK79YY+5egF86C7ZOuH72WTIZa3AumBOpDtTuAXCzAUVS/hh87JhXWk/aicYmYn
0hO0I9w/9qsxxaLbfQM20deaPEEiWQz29Iwl+/anDXRWQw0ksY1lq4IV/JtUYYf56xUys9WQI7MF
azwWCE8FNME19nnAcOm0doC0jr8h7ya53N4IY+qQ1JOzq39j/UumoGav2M1AJSqWdlERIwEBu095
+wBkNGcbMXFsYDkLigrcXjOdpMAoCfU1gU/DL6yxrAIZtmxzc/frzHN2LPbD+n282riYta3MaCyh
KDeNlKc/nAgKr7QwWf5OE/Lfi2eHBoVEUDRdJ+xpSUhHv++QpEWXgiztDYE1ikWxjOmawl+PBVed
BaHvTtSQnIX48FDy4s321Q6eJW6aiI4pT14=