<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyLt6AY6v+2FNwgDYtBgTW/iXVi86mE2GBUuYUHxTlPZ/Xc57xqZcFVkgYiiLNrULaBECvaq
6yUs3ZxljLQDQZxh5r8rLhcTcLXllYtcKvgAD2JqjbhqY95uYc1vwiI7YmKXI5FzNBZIav6ohUMz
TFRqtIZwpASzaX8zUYLaFtX0VSyEpM0QKSjlCfUQeMOgp0aZGZO1out0hBQVgrlboLgIZdPSzmtI
3Bg8L+yskK/QwUTNj5dlrojgh6lJMMQlnijxGXwzETahMeqc6ktl13TsVGDhtaaCGvkxS8fdLmyW
7Rr1/u3NgBqhz8dgsbfc6UMUT5vWSdAc7biEE4E4yo8pEQVqMTN0oh/TatFjJRjLQ/JJFXUTYAp4
wqprhm5I/at5qET/scaodHfXZMtq3gris/8jo82keQvggtnGwAynXgwdiYyuswe08i/An0fPmluJ
AW2yzSomk2NV/T16kdj8VD/xr9nlBnRd4gZCGjt9TowjVxVBxWb3YNoCrexpn2t3lwafYN+WbL5F
0YBwwAnmZj5RaxOx16Ki3Wm8THvE/z4MSiU8RtQi7p+zmut1cZG38O0VzGvhqcoqsYwXLxhFVJ/b
ujhhZQxN0nDXGhRK0XZwhcD8j/oXEVuEqIeiwlpXrKL7VhZrLp5csbrXAa4iffI3+9+e3Meh9NAO
0vOw9mG+SyCoj2GZ9wLCu9iEJ10j+dY56JFvSz8TbFD+FUH6dITODftSVWKwdxs5IHWNxc4Fj6cb
2ndDAdY0dM8dPrTV/1uXzCUOqZHNnMS+b40WVjO0wB6HNwGzGNO8HTXTy1C4yI4MaGCjdVRIP8h6
hSX9RkOSvGG+BfiuiswFOsTYclZB0RKxB1ZQA3H17ESzRQCJJuLuU8uH0+E0HitD0feGbCXPHvEp
tPIvh77iogsF4tP9ZDyR9aOOXXP/WuBuFsq4CDr5sDqQq4SPB8hpcaQlTeXc56Xj71sL408bM/A+
icoYhGv29jfsi0stU1A3YK4bwLibf+VXHHqCutlN2bwO2phim1OFzs3gEYJdd4KLuWswIsEGispl
zM7odptpdf08Ois+39vZmmWddfcUktQBFjUWOlmGje3zxQ1PAXNxyW8z/gxNQGHasSF++vLGyraW
RjkX+Lio4uYmUIXD54KRw9DrNLzw8pvVE9Hv0YpaKzoN5UcRCMHLwX11wO4EhHu6JW7JFKlnjAA1
5cfC9K4NK3c7Q4A+vnnsr33dcTOmzn49tsHT6TwHIsUD0J8/Uj2Tkw3AlTIbUUh5xsr06h7/ad9G
hwI5JfI4/iXyIEKdBS0tsqf/it8eWP0QE//SACMLBDXi/hfjEI/RZEO4+PSHRf/p9O55TM+zzc8F
VR7Jgg5XK8cBg8C/4Jd7FQ78k+iSFK7ZT4FPWwMSYtJftrCs2v/rgX/vclCU6QwVmrIo7b2FWyOF
ZeDhHBFnPiE2m7IFj3Xnv7qm5fGNuyLyB04uGm0AwyoW2ErCyVYfC52laO5wQPkBzoQOu2GoD0qj
vc4ZdL3UMC58FZqXoj/hyLpgPqsPTRFRJoN/WkBoUkazVxqelxj4UueYzcVWD9bwa+5QwOw+dnW+
R1gxp6bYuUJUuB4aMmdiD8X+ZqoKLZ71cenAr+TgrIz9iwAZAPgGSYRZFjU+tabtTs7Z0SfNGT9x
Peu+BxLZDDOoXoCotFXtTCqdpzYkvZB/3uFViuMvbUd3XHJBlHO75IlNQ+ne7I9P5zEQZ0Nu5+Jn
OYtiQK1TSmeqLdakDieKjEurCp3lQHn0h8FDRZA0ZQ+ckNzXgCwUkxfjzOi/JTazQalrQXb/FalX
zAvj5QwCDFHAyYg6I50UuZ4Pe2mHtlJ6hNIJMRSUwoHLkjHhiTbLph2P8rARVupdyKkel3d9s4fG
OX1LBPB6KlbzyoA2nJSRVVOGqwSO88cMB8yORb5mjfoTuCb+vzvWOJfnMDUfoBrKS9EnkYO2UrsQ
TufKLS/KlqpDrtYBl2mO8vKY11l9Qcfv9tkKn8tp4Jz1v5GhnUI7xmzQkIEnenqmaggY1F+/VAHi
AU4Lr5XCvCuEYGD49rOcjINjn3MtuUdr8et//IsOJllLdsP9I6MRFGf2jJAIcJRZ+tkKTeSZnJCN
7ZNlw95j7nMOaEvdJS/Xq29EqM7nRjrdqi/0KMNZkCt+592sgBgICSGOHGBbkNP5R+cDJSI51qNs
6Kb5wO18X6a+qI5LP/SWpKll3yH+s05g/zeXfixF1T/bnovFDDFhS1PnSdI9KEoAS9Aa24Fwxl/H
Q9UnwdsB3Ea7YgHmwyVWsuDAdI7BWPqTcPYRxJZilNVCQqeTKKyb0zWsbmHwOyfGWMUTe1+7UikE
ZW3xY0FEsleOFr19ZlTkwNCxs/gOhFPI3PFLEzO/2mW4qqrOxJkI70gSjoMr/4sQhH0xhM9Yxyyq
utxxVipFBcjBlOWoAIZOg2izy3jEtaEEFn+N8j1XTGXU5YWwLsEz1UIUwQoHCq21Z+tNncKwZyXM
W4JZd2PqzeDXxrP+Lr11qsbcTQ957I9Jo6o1l7ATxj++58lJqbcwq38RKSnIHIP0+64oWY4X4gGs
Dk/+nD4VUDeKnWo4SGRlG88uiAQJ25FTMrdfYY+gUM2xWW==