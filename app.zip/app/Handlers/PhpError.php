<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmdjgX6VRIycPZ0/CdG+drbJ4ZcNDKEVcy8pAxn8j/AeogbgJrLN527CzPHtdTsKhMahIgjr
qHM7gyUOc0npUh1ZSMY6BER55bR6Bg8pl8GZjEMvjFklnaZOS2YUFszWYDHKQv6gwo5BVWcQL60i
3Xf77YgMum//tmIS4HNUx7f1JaJGH/oN59oM7F0AzKpuI7v2dWoT4Gihal1z+KiJ4UDkSYW9AdTq
/S/z/jxAVT71nc6BiPq45Z4P7KVOMAV+HnUsnOMbi2AXEY+NIVLnj/1LIwgZPAw/DDAeitSwy1zS
JDfgITKUzeG4fuYgl9m5kkTZQpZEy1M+qAtx4Z3KQK0waZ5gq/vfU3Lx6MoYXpIGIVDyPeezHCNu
MHG8WG/asBEdLNsRDeyJf1APASqaMFFdItfHYA8rMlJuEwgQugQL9UkiJVNQOrdQ9oOHyofzKTkG
GOYwxT0L3kYGDvXn+p7xwsaJTqHIZZlywXPlgzpqNAQvXiBlnck3bpi3n6zQw6tckfJfOfCa7bjE
iLvPH2Nbxvug77nLn6P1zHR/4BHoKhMGsMlClITim/E5Xnn4cmYX+O+jKrtTZWs9964fmY9oYBLk
WLRFhYRzpAT3/bJ1lMkw4KLu4IVhjJvjfQWes/l/WdaxFfGU2F/HdvaRKL3bdgqAVfRh4USi5N31
TUkkn0FkoObAEX+vgFEqHm3XFw5F5MDxUJJ8Q/6SeFOM8rrkTyT/omD08nePTUXCASR1IazDaO55
cn6VSmthe0LwP9adSWdB9fkYQq5eGGc9vmczIRfZ+nNAwEX3vZ2hi/v6mwjutkiSqpx5luHtQMrF
ePiUUuh5UMid/hqNEtSF2Y1cOrFQx9W6Q8HGozu7SHyzp5+Y7JCb7nGGM/JP4NcthTd2QOGrU5dw
I8LxoVtcSCmalt3AqACq9uWn5FI9ycmlmEM6oEpPXSlTZ1nJR4iOKlhOeIpgXRWp+v0amAz1QqGg
5vczCWiBxzFe63lZGIB1YrCbaB3XFPFAdRGHJ6InWd6+Zu47/+BesQqbjdeiOkgS4VZSrykKl9C6
UTcaSl3/PuvxrHo0lGVh2PoUlXzWOy2oxKYs2u0dH2zOOK7K52DJv/yeTErz7P8EsMYbBmuIhJ15
Tp68VcT10K4ji1y16SJsbiWgSDqvf77xYusFIs1qCfUvfJsI5+xsn6EZMAIb/rXZx5gb5YearcSY
i+hHOc8in5uGtTxD6AJfzQ+xMW3dAPBVf0lfhdakuLBOpqHB9Wat214zUc/I6WuU9FLYLzfnppHC
7M1ryoP1cYZENnmcu76MQFdhJTozmdPl6owN1ybYti8CmTmS+oHdiuLb02zn4a7K8HDJeoozFUAS
rOxrCWwVcf5Z1zK9WQnGVX6wNnpLz1zsvS7OvR5ckhFWuJSUc4IxvNUXilZ8Xtya/qIM80ab8FTR
aGMmtTsXlctoL2o9GoiEK98G2ty286PN+PmdOi1MHLCsRw0wOuAm/A0lNVqczc7WjtACidTotijN
1Yuw1EdGOC9f1rdsZiFK5APM5rOUhxepV3TU191LEplZ2dtdMc/K0zKOSWR5ToEABSs3CRoYzukT
75G9WPubhizAFQKQ+L/cgaK/Mq0J1VKF7ci95qB8rcvduX41uP7XGY+Ia3GM3nz7WsGvzHfSfqaF
5Ii9/7F9m29BgfGcS4Gw7nc3c7AR2gKF4x3wlha1nGOhMWEDoEcuO/IHxmyzHq+CPkUn1cuvfPLL
feUpnInI9dGEXEcIKSFw9+HzNuPE4DC+mLRdPRYj2pKDIA7pHkTNI2ZCnayHLmefYCiAmoB7MYrY
iEcio+zMnKOSA0Mx3+T7SmqvJe0Vh0mUsFMLwHipvUYMaRDR345GoSIHdQfuQ25fCSDuymO+eMj+
5Jt7jGuG/7ZWDLeofB/vEwKSjLvWTOwMARUVj1D6x+Ms4ZkfU9mKA/hxk/OS801dKwIrBdTxkYbN
izRuvES6Qo631VbyZAWLjRb4GNVaRZS/7oxOxn7k3Brxjx+iozVk+/fzVyXuQrGdLs7eyjoB7im7
TzuUDP1NVFy5rDYgCYM3vLocIV/KOCFvPyykhGhd1o2hXiI76KENCK0sY7zY2e6O2Wt+7his/vFN
H4HUXdJKCMxDhlCjU78oFsfUS7xxyrtVcw2vS22vuBBTS46rbrSD7wEBZ+Q3+6GPFlwmXoVkRW3c
qLVQx//CPg8eTXDmITSVorPONu/tA/b45GLeFHp6D6V868GVCBifbtrDe5SgLkq+9zvo7F/kPd6c
v3sgdd1AS3CHCQ0WIBD6+HZWQVdFlBQPgAtkqmxVrMUve0VDoEF5sLOd1mo4LCD5tVO62aUxb+eo
pe38gVjksCn/iMAol74lmvxozwSbcw69nB3FT2o2r0zDv0bjJMMVMyr/V1QteGNlBeIuYq/LI1ze
uIpmS6AXED3Mh+Bk/QuXs2WaNxySnygexKU/d3+2k8Gxm25duGu6y8sMcK1Qmxp4vruzZah/TmrB
ZQjmiRMNQByXIKTm0EOesNqLxth8LJV5WpMYvZcxRgOF/TATRJ6QzWwAOT1wfgbMV+Z/6IemHw60
amYbvomNijiAEENs+ZwseiPN0iJvBpactnqO3agJOgI1ZHe+aL1bIov0U4LGqdTJwoO2nQHeFpfh
fe8qw1iKRdvMTyrLaFNPINQtD/zxEog9OJC8Sr0MZ7EPf+ZxuL99WLp6KbUyOFSec5e19I4C2CXr
KLxzGOZ8megP87OCw5488X+sfjXNj2Tnle669AK=