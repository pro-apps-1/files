<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnHPkHG97W9Rr8GiD/RtcVWKp59Ov8Gp/y06TYUMY+0NqmLkCmGwykbMqpSbk3LxAe9A8r09
w+p6HRtqfwNkNtnfAwJ70WSfgux0vdOT7w6XSxNpBXPsPYWzHzZlOHcPp4Ha0ttWpVvG5L84ljyk
AZ8a6xsjPF2KlvEAOD7mVrBn3PRYoPJKLKeRbyZhOxNV3lgaJ1gKIUHfKevSBemPaJSJJmWUwu0e
213RCaaTfWdSOWymxgfjRm+4hmXMHQv/3kidxHx7AzclYLZlp2Jr3zVqY4o9JaqWFcITKJczSTSg
U741/hYhYWyBSXqnP+8HoB9lMgUFRW8UE+/4FrbiSsWP9wABBUhOZPxzwRv/WW/xBmy3Gt8fWiTs
UXO+CUceg9RZ2rtfQWRdj2lPvD1Ijxswga3DSew9G6YIqpbRyZ0lJloiuAQDXjVxt/TAnTg+qQNT
Qf/FwzFA+sG28ktLD1mNQovIY8NdxakUB4yhpzkhqPmdMNdQZJZZY37YuVm1YOjWKEFfmm42B+dh
JUn/0Qzxr87Fbh53MGcrhjtx78CTjjuH4NlSwbcqMDorlJcpH1UBW4HCpGm6V93SWlc/mXMclqVp
ob4kKgSh1DMgkIUCy9e6j+edQtygsGCjZ+xjZiXE+A7DOlfDKZ+gZGqMQiWLIF+4j3K2Nlwz117t
Id+dJqdXTHgyyU1zgeHUmtAplwLZUFjXwXFByVM8gBaN4+y+kJZVA6BnfWv8RWcZJu5kaSMu/zq1
hf2W1ukK1i/VfQ/Fg1DAf/7uwdnZCHFcSb65vXq8Irq4PqbHV8Y+T+FMcIbwpQPr+rW0MMFJMmP5
2RDLq122PXZcgtDWmvv2bOvhU8NTijgZJHNz5t45oAxTY+SMCRzM3j9NKTab84wcZZZRcPGoDxax
Q+7YXEPU7bKJ8vY8AIgwxRmgVaYMA2qsvd0gKaDOgaiIoqkiytz0JIj2cRw3n23iGE5FBxHSsZhQ
/XnriloYHkLeAkprJbQ8XL4c/xTYltdzxgeRgO0Dgvsy4dAy26F7UxM0Qi2sbFa6Ku50wu1/bTF2
U2apGCqezDv2eEN/WRNN0Xy6oTejYvys7CnrA+zzCgriOY6nobAjkO6smuVaBhmF7PnypUrAMFwX
5TR9n/wTp04R3eKn/GoXRWIeU6bRy88l7hhJl/Wm3/q14kyYoZMq96PTaXdLxC9XP1tm0Eb+FmK+
jXVf9l1ZCemhyFaUIgE8FkpthtsivsLb0+HECJs/aOoA+wGBWxWUiYSN+hz3h6a+ISQsw5fIOU0c
9tya84AFYJApJaUtVHjbsVusACoV8PjtAMz6yLbry9Kjk41OaGGH44jQILKTackeEXSdR9sZkOT9
2Vvp4bBHOAwaJMjlpr4103dTgdZb//bAyaLMrltv/nVykv8BWRekcmvoMvy5aF2XctAoPKwWH22Z
KGCdyvQkvP42RB4SPeSP6tCMCNltLHxDDoH0n+Q1M8mIwqRwOEKlw2cA1F+WtyHBZtOkFtz5zKSl
wmo8M2gzB7xfiK9JLKDzyU4DMkNkxlCaj+lM+ILF2REYNBSSAvKRzVZU75BhYtvcLk1UxD84oQWT
np/CnI1K+6T0ubeYM/t+mJOZGgnSuvOOTlMrH/R1vb0EjHXqBckqYknrl2nFTDqPy4oLox6FjXbt
/FviYn7UXFQqEztKKolKflbRSO3CLlza+Kjp1fKaEaZZj1RuYdb8sFQ4U/qXNSSTJgDZSOJzhdXR
roIF5at0An5YfCiHfa292Z0VP1HO7K0fohHN2bE5PxtTCQJ1L3K20YyX0vp08VdKidZjSdiGGBV9
GTZlGTTl7PZ6q01/9XaBVpZCg/cu7su1ktR0pZ730dz2rB1GWDklGSzLMhnTOeFjox5LN1+3sI7s
QLi/lTMV0NRnkR+xgh8Cz+4HcJYqYVfMsWeGlH1nFpVJRq3CbzcTKkWTdlqQYmLIQC0D2iBQ45vE
Du0tk46qLysPxxG5PzVHhHyus+a5TWgiG+ieOkyHCEo45DtSKigoAhZWjHfuuJLifIqV/tZLHEN5
hlpJribk4htWJ/NutWUKbLLmf6zh0rbtqp1f/ifXaBLOJe8C66bXcPkfv9uGFQD/l1czjzCBgjv2
z6jTBikaqoigrE8LYkkHTHmDD3joPGmY8kpTRdbAX9ku8/QIxK52cz6UWhR50UYhya3LrXoy/gkR
YNrRTpkc0mvh66QMDLlC9AwpHzd+IGb+pLsKTRgq6ACJsWdzVx1eByAt6ohfFt/3CUuom1yJvZqq
5RwIQxyqIa+gAf238EBuT94rBgmtmazPo4c6+J0JZA4z9diYTHM7PBoLOrNso6k3HSOs1J3H4TZM
YiEvl/d/o5gZLExuRlYcAn+nKlnsvcK4OHr4MOKaLO9Hyw8GTlmxQ/CTvgbc5/hZfU4x+nLc/4qm
rWRjh4rBIIKvsPnyX46Pev0trfnv5nArd+0U5qm9P5s3GpFOZU6rD87UJXpyrYGCY19uS37olE9v
uKCZss7soQdeJXcby6Z/phHx2ewbtZjGzMMvtja5gCpQPmX4adn4dBcnXAzh0zc+lrzK+yO=