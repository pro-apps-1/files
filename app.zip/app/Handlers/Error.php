<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqMFNPFCJAQaYLB8iE4TZ4jSxozL5rjm2fguwIIRNa4BSy4W7sXJT1hdaxh9PCXq48Ld3F2R
PoUV3SwVfV6pbs9SEl82UYWoJd7l9lgn4r1vL9KWYsatP9TZwwb3eJssZpAiuTTlpusyf0ziSKfl
DDKHsA2u/KPOZu+CUx90WCwyXDq+371Dn0OzKCEFmyL3oPSlYN4rJKq6WbNg0G/JJm0RHyRHQjDj
sghcaQgNxqVVeciTWJMEZ8HkPWx4GsTBpvQaCEF1x2Mp38X0OBGOBrINoG9bCbXnqhh8PO9Url71
ecjq21Icb/6gBoLcbEyZrWvPy0YEy/Kp7lhA+XE2z0bWu8WP6KXoQ8GRsOebV3O3sB/qvXjd7nEj
5PPpzgaGJWP7fb0++sBzyO3c+A9GDW8CIeHxcZERJoL5uwuE20nXQ9MI3/qb0Y4Vl0OJpLihJA/W
+Pc3oXMr8NzKKpEcY/1yv+21OTisMF09qvYWtRmgbvyUMi29ZD2C6X12zt6UypjcugfSAza73Cpr
0BShJQ/wL+9Rh44MfMmUChAcNGmJvE19ixHKvnUE5ueFmVseCMGaQjCMBJ2ynoBqipLKTAmGeYCJ
Iag352uVMhEVYOi01PsCqz/Yx75RdDAVSbERWiFOOMRkfhZKJWL/8H+NcXgnL4Iz8p9rElrTnzUj
zereyMLChCUXDta6M36Nj/rHm0LDVGpq8zo52TeQxG7pqlLqdWP5UddyIZw/44hgXBJvkqF3+BqK
lRIGeRZhucPZgfXW1vv5bBaVFdzXBzoLPHgD2w0P20N05eJxlqBCi9GUkHUq9dREWMOHg8LwMdzB
Es2K9kD/jF4NKAOOuPFSlRETRdx53Le8PBHliOatZIuZHMBFml+QtyvwspTx25ji3oZc2gDzdu+u
cMQTDlHihNo8tXEjVBX0cGYLyTVkTyx9zjql9HIQbthqZSEgj4JruRFOold7eAMf4vgMlg5uf3EX
tfoaGf5Ik63yfXTHS/zXACFpE+OYwsPA1Xdt61RCr7wCIcQ8v4lWJnOih1ae+sKtqx/wail3HLlL
LgjMzeNvLtPWDyeFLKqA3Kq42F/SKpav6V5NA60/tStQCqNlPF0ZE/9+1P3bhcmEq9HZBspi2ifk
LqgWUd8hB7ce63+O349xkJqliKd+fUiYAzA+MCn/Bxa1Pm9JQl1GSMzts2K3wJ4LXjQg5Td4TjIZ
GADoGAAr28mreeim3E5zxcPIOcE7aZ1sGZjvianj3VOHQ3iJJKnYE9nWO+Zgj0tC9FylmC7ttAWx
o0eZA4okUZ+7ppI1ne9wPniJ5t95vVtB3+2JN5SdlbB7CPcgHuShPB5jLe06fPCahIksS5r80M/4
iRU4J5yaRdi/2xE1TdDrQOyMBB6I7CsXG/ECkY/6kdqBG6yExT6PE0IyBxCTrLEc4DVxUx5EYQbA
fVYMFrykFdNorAKjYrx5ZQH5H59V6tzD8NjErK4qHpE5nQSqNBHjRCbUBpZYvnEyNAXXk8Chc9m1
9bx+H/KLDj6tK9VfkPL3fR5zgOMJ+mwy/pMCoFoWXQHhOrPiUlDFfl/m0PIYpR4QbjfNaievdS+r
lEckVGtX1w2VlYQLrzheFye5n2tej/LPBi+fE4Idshirt5Nb7pd4a2Buq1NPkhUl6EIf0H/4SVha
tHoKElvEWBoafqT1ZGdLgMwxEHl/grpWmnS85/LcZ+FXHidumVmhXJtQ7s9sD9VUrIHcBKXh67wG
eFKH2q8jC6CH3yvGHcudn6n2y5lyoAykqfKFqI/GYtSOeUgBd1zkxS9qIZqtLbFp5KFmIndlvayY
Zue0eLITznxkP0dj6W+XFMwo/yHuoDFb8MokHDRGQb3IvCY9IPbkDkQeeXWcTL0kDsFQ9nvcbtfj
nlkqOul03yBPChEAukxQut/CkywOY+G74oW3XIO2onQWZfMw+E426OGRDp2vMdpeDK8ZY7RIBNFd
apXBE0TRM13YaMvEgiJaL7qRyIPxrFkduOT44lLfWJ2ui3LDET+SsrbW6mHIkHnk6F/QRsa3TJD4
PPYhzCzJ3mQwI1UtKpiwSrWNTe4N44Wf+qA/ExMv9KMVNfDs/ltMqQaSDlTYjX92ptg2dVzMPFSa
xDUNbNQglF5wQmOV6ux1s8Acz+HQkUbzZW0bvFsGuEIZMyx+HZFGUva71JJ7RqUeSB46zomW1mxO
Vcb0maow4MqRop+wLVnjFhZYo/K4hRY1Ty0HLwKBXPma/Hbx3as/MGb/BnpZnEouSj/ousLEdQh+
4RKg48vaA8utyOnopjWEI690pxQ5urSRCvg32vZwlMFGOUsX302+vh4f+g3CqGJkKG8fHmjwm4zg
Nl5Z5ko00b92kA49iL4UU9b76oHXWAXCKUMl1ctJzGlOQw5f8qByEXKli5gJlQksGLgd9vw5UkIL
0zAKvn6XZHNMwWYOfmT6mqvEyjo4q2L2VsP5XH0GZ5XplkP7cU9Cqsmxq/KVwU7YVOdrJC9Kdwgd
72qE9N9q93B0s/5nHMLDKNrIgzDYETYQ+rgyiqBuKpHZoHFihsOzkG0=