<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzu0Uof1iLyE7Dtk2Tko1UMPFHFtZjKvaAMuBJOahoD/OlOEEKOf41MJTcnMsc8pEmGhKJbQ
rKF+VelfYnWZvkCqs74h8TmnbYJzXIfBlAT+dRfLzoF607eHAJEdXdQyN8DVuh6CT1VcFWof0CqE
RRFo3EhqlmAwYeK1n3AzBIom41hL+GU36CM966IZJ4iVVMOh/u5mXShBAs6AskPoqRwHQVSmxrYp
bSrYSj6R0r9BTLkwOVuaATDROJ/XAwDW+6zxz64dw5ckNa472QqPOhgG+ujYQs4LeNzZ4b42UBA1
iOff/scq8LqxKjLtQcv9tfsHERzVP7VLpFievQwLfoqc5EfI+zpHraTiqsPhWyVvkVk4x4l/werg
smiJmV2wgmKt4a8wajsVxvVcJh8NYezrS61PYUeh/VAkxfQsPS7+HwUNp/R6UnrN1L1z/3PbZ0ld
ffQlV75aPRf6AJgf1G5GtGJhzewhBoGcpsISaf0lT6U1ydakhUZSZTjgyu0EVGLpDOgasP/lknjF
njf2CQH7HDLDra8IwRKLr8/9Huwp8sAyM/iOCKVjwKvHbTj1n/bt/xa1wVfAKBafvqVooFETlg/R
LeUOupUow7Sd/Ot0ExGK9S+V3tJUX2Tm45XvGLy2/tbTOENZatxGfebNvwA13BPfFba90T2+QWI+
Mr+ZbKTskcx0Uof1+kIWOGWicS/phGpXjVtqmycpmzwItjr0w/pBDPPp6D6zZM5G4c+oS7p47P6m
05qIX31UGM3ESQOFcQf1CMW2kjgxDOrmux128YbD04jK1teLaDn6K+uhshuNQPJwqgD0G3GR9KEY
nB9PwePU/yo15qPlfkXZK68Hwkqz8uSWfG/xQ/fQ6RPV8qLL6ZJJFuM6qmgpQv440HRZMOsC2Tvi
qs4qNnENXCNnoIAzT4hht4WKC18OAsvKv9sNxP5LFI2T9XtH+Az5egN0Yke84JZuXgOU4oNFE/4p
oyvLuPnD2vZKBIvtPTXeSVCjUfZ08wIkN+kblzqzHO6R4/A5wmppH+MIsRckWb21Cq8MNCdTI3sI
ZTCeIU0336rpHSyde7XzY5MGfiINYOvwT/7sW/MRFZt6pVb895tyGcwd3MA5XW/y7vyjnhagp3F3
5e9Tyv/gSnOwsXaqG0Tr1dhq4+68mqi4qswlmOiCNe6uf8xIr4e7tpUoi6S9HTcT9qJWrn37S4q/
8TI7/5imvYywtbuB0tuSzV9npDg+j9a8Z8I3l7xZAbVzlEeXtDeQL6l/7mmJDBSavzsaXRebOCVm
gQb8WD/1qD8Top4uG78fGlsbLclsdx7WPjvHpS9BpeG5B/yMr/waTVoBuo7Icgnh/uTvJjgoNoUt
Bp8xtRJ3NSL4cngkbgI7TY9GFLpAw9+xgteefu4PZKeVSLiONLJuW9Vp96geOTiz2mThb53wKTs9
eAPsYwBiuL5NAkxDVrNPvBHM2yGrnCwwhAz5lXRn397kOEJgyvOI47cyw74wPHL+HUowT9vNXaRj
nu/gC9awuIDQ5TU5psKkBOkZIorWg1Z1yWkGSXQPHQjuNvf4ZEefy9jAn8Adhp3TixwABYuF8M5l
3xMuzdEKuLUmfQxbGTUByp8IuXum3lJs0j3u5VwnAN2ByeA4A9xSvu8R4mk3KSOboCDk8j4K5teK
YpG4mnsYldFsJHiQc7owkp6jeM93sWZkdomryKg7C1P9nNgdwsZtMkv1Q6B9ItTuKUezCrpm8hyJ
4kk9/pRwMVRnQpFtv0rmahzYz5Gg5k3cImWSUetz7eA3ORkG2JxbNVl+y4zKHLFmXOOMkp+zJKTx
/SiG2FjFWgMBmDOnQ2YT9PUtwcaky18B6XrLGHA0xBOa73FyBCTpCY1E5xDTBoxiH+M89uX06CrV
YYU+pjkfWX8aQqjRCvjZi56VEphGKsL1jfD1V/Y+IYjRwWU0As9Pr0TYc6C0zX2gfb+MNG2qnfYG
fdAsKDb3BsTmEslBgRSD0pkw9glD8ZD1vZhp+4UX2FjMSIAGOJ5MHPxVtHYnoYvks8K14//ecv9T
f3TezrxCntP8FI49uoKO/K7gwKTjS8WVVDCZU/2zIjwASFfGGK978oPpbaT/IXlc4621J33xY9fh
lDAODDzla/cga9/WhKvlmE0pZrYERXBFcc2iphj02JgSe0n5I0iK9hQvB+Zx9GEL/cn7P8hXLQUC
5W5fLWGlbpvEyjBnD8mwBZidyafvOX45bDKdn1uYVbEnbStQFVOizUBj664SlaO1NQHA5bK9Xj+m
A9/GJAQYROqZ1DjnmfqMX5V3SWcDdRD10iFWatJ/mqp9gLG2OSmZFSxZ0jfZPF0rXDPk2Ve6yKmi
gLoWpx03dx022dDeMbfp8yu5xrWx+0qcXxsFfK8QXOQBGTP2YsXv/BlsB8ojCMzNMMLOr9CNBwuv
/r6daGshixALMoGG6OqryUUx7TFhFkwkFvGErIWLuE01Hu7NDvgZu+h6xxbVG1dIY2GoILBJquOw
pH9B1/IG/OV7Ff1Un8NEZAuV5km2TPV0MsSuOAw3IJzsfWFSks4KflPBLB24/R7MIqt2