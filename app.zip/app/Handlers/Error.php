<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqEIL/2yGwp7kK/2qsAOwNCCTNmgJN25oyYVOMhw8JenO56uLtLk5HNYCpz2xBOzKWBDC373
/L+P4t086pF2DPr4vs6Xx7AT/XIWcTSQuxpKnsrSXpIhijY1ImJmUoYrZTEMWCc2uiQh+C+EJa81
eGpwP70O+iJ8gpeSupqOAMfd0OUre5lTY23jbCCN6q47MDpNR1XMBktbal3oDqa69nLrjD9KexVT
3gCzs+UD6dxvGG9wgrjWyH43hHYlgPRlQqTP/QIuw5Uteh406+EjATiE/PFAQR9rUF7b8A2+AQeO
Ve0AS4F/EdIRmyp4/4bQntS3gQ/D0QIWFcvEFffo8PEIqs1gNOVpCw5eAopzPb7SZD03psd0nlRa
5nrBWFVnUuqew4JhsZYta1fCkzb/Vtf4J4RaP/7gyHnqs+nzmbYK65p6aM5WY7nMyIxXXXI4XQeZ
ZWYvk31aZizdiXfMuDyWUhS30+cqumCagVvSoEbItgjlPnUxFhejCWq6VA2acGjTeBjR25tmkyGC
z0r+btSk6du+SOqYfCpJKfOb6eF0+OSnDO709sm6k2I1j+0Lb0uSGffucirq4CPd4jVNQjTqwG27
QjD3pGVmTwuNqJDqtv1QEd9xB9JYRSS0xo1Mh5KoYjgjTUbiqJkydzNf+m+Ye5N93obhrNg17s+O
hkOTNTthY9i8d1mGn61cRGEGeozaNbtX8Hi27/4v6/Qr3YMoyO7JNYWl64XEzbYb7phBzZdXw9lI
GCnz/dDvCkWgBE4b22N5EztUlDmmXucGyFyNno9Xtwoe36aG9luxmFRiv7OdYn61q7Wsm3BKqWZl
SP3pBd6sjLHMonFkyXO8xJuCxABgS64OspP5dRuSq4I1zOr+4y5N0MAkPy5xyJVSwlAn8MQ8E7G5
pNRkFPJTj6MgcLyCdit60E/5ZELVBTinpvAKREwrtyt1kxxvSpv327et04MkncTAmOYg7/2igzVw
9ClNOFF3O0AlFubPP4dxm+aB7BoA1uiHWiiLMdG9q7pYNBuvz0lJgwtY1PNqyVu70H3ykLvthOoe
Hjge/Iieo0sNwn4tfS/dpZUs08e4PEhhLhIbhY4eX7TAf4Rcq/UkGcTee+mVDpj2qEfMLtvYQbEh
evKZRuvFHHCZRAcYFSlkWBUKXzeQsLQxemdJGoGl4W++y6Qv6UIOkPjuAIqrCL5H1i8fO4KKz2WS
KwQ3Z/cACuDkbbNSbY51HpKGCSeTH/RaHEvopQlEmA+ujknMVBMwhpyjNpFsOPGdqjut6dx3T4sg
cDyoga0ei3U0ZC8TZ1N6cwpAc1vfGJgRUyq7Yc563pL+SlnRSClGazlR0AER9pDeLdr+Ko9WsqMb
Mx88kdXRd/N9wnhuwNUfx79e0v6CN7AtMznPwHTViCbg8XpsRzT7bCD8qJxUdDjrCKAxn2KCBT9v
Ri4GQPAz2ZqAlBKtgSf1zZrZzLQsGHSfAvXWilbV5exqrRkbtUwJ8qgMZtLaez/+gEEpFH+JG37D
ZtwTAg9/LmMO2NhSYJ2VqCvsaHrodM2lbDP7yYTdw2NfYpLJepTEeFqOpeHJrM679+paoLqZq1xh
dra+Ajx/62q5yhmOuwTLR9sRZUPbRlnttwUC1QqsqkobK50DkNlZAoDteT8VS1VLtfMDztaNRCh5
vcbnTe2P9LRTq+0ug5C8BNY/pVNh1O50/zvW82Z61gaSO2TJW/03BVbVGcVlxtzioDtQYkjebrCH
wgogrOwFzEO9lgoq3SdxFIYbG68hcFZ/Wwm0B7KVfKr5ZMllsX0X0N9QPjFiaQBsAu9YsK2Jld5y
CmcM0dKuhZuU6pwo0LNylSK7dY7EbJVWguH+l5IsEbHtnAX33hU5Hnnz4msgP8i6k9gWQICbG0z0
gzIlbac7EZ8ZbOgZNPCLv3L0GpCqGpB7XVBqzWaUPlvVey7dxq3L9F1Tj2SYotF1F/dY29f89kei
3PGlzIAG0HDbSjEKiZz5LzZElGQDNBWlqMKSrDwPcHxcrqco8F6jxuYkPBUf6djaMNmtCn8OWpNh
q0O2U88SsRq9rPNbM4J+0rqSt32Vnwj4N48TI5MdYqXJt3J/CG2pz2y18HNzG5fjPeWljcx+LZtc
nFqzzPPyhJIIu4avxBACAWtoMddsG0Yy1mydu1cjAZw27BDAZ/7R3BpJJMK2OOrenuCKMETPoL8D
jVneIrdf+YjC1/2RUTzYcCfqU/2VdSkBhwTqfJ1koat2ayVTBLIomjEHhuQ18+btbgbtRZbG6WGD
UC5O1Kak8u+1wuM6B4d5/xjdvIgTXSNopZFqQn2EsMfct6BdCCnxS1QH2vXDgGSP25CSEqZT8qpS
d56TTThi8mNNQ9emJ+PyaFKmsxxn95Ec09MhFmUAqgsFgwZ7ruHFZajVp1Nla1xHSAoofoeEQNim
vAdVIsOkqh1tS5tCIz8GDakk6rZts8vqnNJM6LQPJ6K2tQsGd0mML6m/a5xR90ReuFAGqP+OUjhH
CbV5UoDwwlftVkhgXS16mgirHnSCkO7RdcFbSlScPXqV0MjYJUqiu3K16XGDJoGXB1UkpjQ3j+bE
uhm=