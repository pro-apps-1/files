<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpRas0GCLI4hoJbD9m2JAGNO12bveJDAAEaTp/XwysdMOEt7zXspQprILV8jlc8j6VVIbWMf
EKQ1cehQvimEOu8kC1wxWjxsWvq91SX6n9uTUr+C4slOoVvxLSEHoj1BhVbBYcmvvHrHN04dLRac
JM5ZXPSZBpjXdE2+O9Xhb3/7dtrfbRaLDuEPxrB3zb/VFMUUt20JIk3/YgfneTurGM9HYijI9EyT
bJUSI7mZJ8KQYWnC0ODk6UxSI73qQ+ueqdEwTa8UlJdPArgD9XhjxmGtTdq6OoFI7OUlj+TgBNaF
83EhENAzpLEEqC7oXBEItaciKOl1HpBprkb7T1Bo/70cVVmi5fhEnquFB8fTuKzDOIBl+5Rh2Gq+
dPxXVAbjCV+baQ3UevR8cEgfW9iwcD27iflVc+nVLhIYK3FTG2cMV2lpfA4cUVNQTp491gdL+QXG
OYtwINAPa5Wsh7Y2iXt+X7sp3ZwFTUP6aqaBO3kUMlJxC53yAoM42RGpUZ7W5B4gAJDcfU9l7Oif
6f1/PVkkc2XvLQe3nh4P5GgEDZDdOOfCrRnbWHqMXT1bW1BsJZFghDUc5NbKAHLOwub9NshJVW3+
FZkbsCkEv+6eftiAGME0LKgRkHMeLjvIoawqsAZAf8Tjp599Fuv//zyxtxzjUmwH5kK6K8qw5tcp
+NaILpXCaQzEm3vXd5a1uIY9kE8NkZO5+7doB7fCTPeqFPVJvZKKH96D2nEGzd8O30A5dMasie9J
mL1gtya1oeDQlH/qhv6wLGjCfDkBx1J1x8jRjTRPsY0CH+OP9Yd15y8v/o5KPs4/1OmdmOr5voTx
MukFB5QZ7EpVLveZ6BdG9Vglc/a6dHsq5HPjgE+Iyxi01tuvZdALN/LboTeBhHQV1qAUO1AYQKPP
LsKNnrgErwFfPQ+HPhgYyYsHJLbSyOsnu9QyMzi+XMI21PRpGnYbk/qZEDJ9ngDoqpjtwm+x62vF
+vAfNQV1FTRiJZN/G6P6io5s0nUfalCPtHh+i7bLHqpDNiUd9UfyeyhyZuChs8KC6PTtTv6NbiWl
wNWOgyZ/dfH1RbulEN05Iej+nqKSgNnYlsT1V2sVZTW+hP7qw4WpQa9NY5rDtA+92HPp6wsDDyYr
JMdKa9RBu76IvhvhMEWDsf6REZaW5/c7n3O/Tr1jkiigpRSAmSfx4+bCrfzmFkXg0Q/G0+fbuMs2
uGB7nI3J1GTkumh19+Iz6kNqS/6VJRCm+zgdb745T4xeXP0S5U5KunPWGBZsj6Ca2SKnVViGnbgR
ZlwwV38bIqUw49c5jJP/eEgnzfbIM8/9166ykG2JktXMP/cHa94gK/yTN5rwU1OlcXW7deEWMZ0u
eDaeII0lxlC6OdWtGwqIL66rzZSNltRxByxnZ7bkz7MVyhMIh/0owoAm3UDoYIP/VJJlR5zXvX02
z3N38iMXvJkYJ2dvcB8KL9kOkFYdkW+iVmHgm7p9nXODZT4cYIc5L0j9vnr4dpSOsB9KtcUWpTeF
wldlbr+vDosKOTPvzHmbB4lmbZFiu/iWsZsrqYzNDe/mxEGbeqAzRF+caXLRwVqptHJK8Z3ZgJdm
MC98T6xM7eIndE7l6C19vDQwh0Y2X8qDjXT/kTAWbgoPXh5pneMPvryP1stxvWPPaWbIwH3ARjVe
3ArhhmtHwgC3uTjA/o19n/NrHLb4IU5WfD/Y6Z3ivkiDbbo7M/yB5qyNgVeH4yY6dlucDLNZYLL6
4KqUBWndb/O5KcyMQo+PvieazQ74PhWIPdbiw0Qntali+uy7goe75Su768Y5nOgx4yUD++RZdbI7
7bftax+BuhH4Cm/kE0dmQh4nLQxekzsYANssUejtgFKGuNoCOZEG9O+86OeE6GCadh2yRDdWZXcV
qa0paWJIO/tpGsRHC9OdqgIv9jQHNS7zRybc4I5YMRwsfDbBl2pQeHQEDxtdvCu97Cm0a7Ly0emc
b1gtoB5PV44q74i8yIp2xIW7LPkt0B1PoUypa80kFSVLgVUV2tJtbZ4fr3uDfnNGAkyLAnB3RmyL
BbL/1q9VeKWcbdr8QuKrWhSBR5NciJuQNGIHLGNL06v2bkOe5cL3jmFASXJ7U4gNR0iqKHLgkKpP
znSOy4IaRiQ42so6norq748JSnVB3BpMud3lsDZTrG1a6dP/x9F7vEryaAEtMx8vANUEqgwxEtcx
A/enGZxjP8PHPwRojpviRDuAk++wf7r8cYndr92nW0wX1lZQxD+dA3XjJyYPzAypjon5Y/dvBvs2
WLUy3GId6R/0uQEYJ4HIMNYgjg05tZs7prj7APWDIcZyXFsYx7q0UjRRTKwDk1BIHrg61bBxhQD7
sqtGaBqfVqiQAbgCMolmEGEcfUoP84SuHpE3BfZPWkbaTrblzOX4AeENE3JjyVnC1v19camBDbtr
VFkKe1iV8cUiTjSg/W2suJhBuKQ/h327jaHH59dR9gDYZAYSSH5ft8tHHuToKQ/o0caR9+GsVtNb
z7hr2aIJWcRUXx4wRB2d6a/RU0l419jxoW6uHae8cwMz1s5FbYSHb1FZdd53Ig/v45rsgjX5vhW=