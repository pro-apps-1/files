<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp4UqukfqYUijC16gF652myOMNcX0wWnmuQu/mcvA8XwZrrI4FmbbIbXf9HSE9qjfRho66xD
nTgUI6poHnDknJ+p5JTHTr9aoSKdgPMkTZ0dMF6rYEnLQIKdzw5VhwUMeYHC9F1+q/hntlDbcGjf
14BCKTqXgKON2cc1Rbb9o42pc3Jn1Goqk+V8dgZor1un87f0HI4d5ywA+E0jKXU8yzLvLLEH8Yvq
iteN2KnAr4m0hbFcB70fAZE087yN9Q+vC9ylnar0bIC/IiIrHvjcnscyWxzXULb0R2H2EabRlrmO
7gil4UqmqHB1yTH52OR3CEfXULp1ZmGSxOw+JrBMXTIAfpZIPxMigPnjM9sVK9VcfviHfe9iieyH
S6v2OE9DG4w1YeMD4x5Ye20HECic1yNTgJr/zDKl78c6zqtihdyDXQgjAvRlzYpVCGS29fmtjSIn
k0IFGoBQWYSUsVodIo5JdNUDLihHUCgmK1QQbaaHdeNXGM7YfnIRVYllnJ+UlN9o+2fO2LXgUMi/
I/vCxmoxIhIB7pjMet8AWHfS1+uDabqnPIqiFV0rWHuJslVG8rZSS9XxDV8uvznrVeoqsgav7gs4
mAhiE1RTyW5zpaGxH64nCJUjogIDizusx29lO6TIYbjuMcU1QKUUPMdDhU9eA+UIMTYa12jgnh5E
MalXUT1048rOjQFwWtysgsIxXu11dhw32HOn+CLcBMZp0AXYSYEbjRb7MewgleR43pD1m15K//XH
FXICgfSj4YNfYpU016KhkfNNlleECvI6ExshpXl8pzhIBoTLlMyls0UnNJXpCfMZDb1GXtSLVJBY
XiJbbZ2hNBnvdaq5LWFmTqhaONUN7aZHLCEzfMzYVOKtAFcYcY2QP1dFc3su9e8TLjfx40jUTAzM
XMRkQsq5G/I3zbB22x0DRnGM4k7jkBsyQC9yR5QihTkOq+WQTgC7BYxrMn2fLqWM4hvDViFzTQB0
wC5R2RQvjrM6LRNt0mSJsfdboR7bTgMFY60LxBclRj63ssMrOZ9gr9PoGTu/ryXcDdHLnc5EEfnO
eALZOBmoLS5xSKJ/4XOpgrdXVA3N9U5OlRB8lK/WOGPSbPrJuI1GxMQ+nqnQP5wEmzKnKgCL34UG
cH3uCh9hmZ68kO5PtQAYZSp/+ei//Df4W1K1/o3e+PDJN5tP12AQsmfWjq7ECH1pAITwHjCFgIvQ
/7JzOnFzphNIinnay7Qfr76iXqx2bJ55AuHR2IxJ1FI+kPOdh1BsK6DgShXuUNLPPEvHDQPDhLvf
VWRkIs9XL7otaD25B1mCynQs08tt9JNief3idDGX40Uxqfsjz4F/pUTFdO/1tj8M/oM0AYeYWtJ1
+xNxP7njBxFnwpttfxG48EF0LdCCgzqB4x5jwujFPDltmekghSvsatWkIEMPQUQ2SIRRIIyVdupR
et3qkj7x2FqjLsqhHRVD9cjiRkCXdHWT3xGbhcGAPLK9dO8ewVOEHu/G1KAw42cNjPlF/RCOH0f/
JdjBosKGNzltgwbcT1J8iamK0MUuuIHmFGkVTPcT6LXkl1bxhyVBn4j72Zk9EL6Aec2+Oe8Vr3gt
EYRFYlyEFOatNr2zOdK//pOq7DYnaoRtJWeWmyR8N+BwY4O4CzNZkMpYkDbSSVWxd/WULrmzJ2jB
HPc+Buz84s+qU5AP29Kp9I7yh1zfsb5hrMRbOnaVEdKfHyRFqe18mCK5IvwltR0FI/zbbo0x0f9z
tfsUefbJQoleW2GYG0tHuSyUwsjRIdb/xTyDPhxrI391zlve+ZPv5xPROFZJXJBWtFD3aEqea/UJ
R+hychKLJckC30MLdnK3bOsryyfVkE6nGLp7QALfQD1Ng+Vw5xmsvPUOtWH7jo/cap0Snl/KBvEf
ui7K4IKHUu98V7EdI7RHvfRA+LuCjkAm+MPIOdccKTwDoJINHsgU+c0/KNfFQG4i7LaFLSDROKCW
SoS8uCusUdM+sAFUBdwImPDKkkmWU139kYDMedYmMbuX7m0TJgE1ZJRV6F+iXhfMWUrtSlzi4Ern
vozRTf0sDECULN9ZJjErciN/XcFUfg5BD3PYQzaiP7Q1LBddErWTtPE1lsCnmGWGAj/Xv39M1kUX
OWEULW5UaHsnRYRNGtqN0ZTW1Lho+kXtsqcHpI3yykAGCpCz3M79/dC02zdPKmja50C9uPORcKXh
UMgWCNXTvTYG1QeT0sXN/wN5VNx7mKChJgWsuJBIjcQKBiqsyqwAZLYgPrTMiAdDr2hPxIQil0Qh
hGSGXyyfWhPjGSOH3pU5Mg80pWjAYwHL+wlx2LVNCW58TdddWyPQZoiahXjBmtmma4WK2PDIs9zL
RgzWyU5aW5Q4EIFOJ918OQxVGvUEkiLScLPKlI7jJHjx9uo8d9KSEeb+D6Sz0RHJE/MvuDRsYphs
9cvFgNzillut+DHwbRJxAhxfmg7gjnqerOfc0wmEAdQaA5tx6qPf06idpi3Riz8ExSZRQD0JNYQf
ytkdXz51fxGVo6l6WM5i3tdTyCS0vRpv4XKbPk5CQTFNbi1rZ5LO77HwdQ4fokHc6EvW1g/f8ZgJ
kGkfxTl+pfmlUML+7oVx3MreyZYltPP+dnAXwSaVp1sVDair+xEai+JgIVU+SeuKAxnLDkceNebx
Qf8HYKNsWtmpeLRNQNEQ6NW3WtnH3Cpxy0DaPrnN3w19OOlOZHlnunRB6YtbgXPOaS4TMrN914p2
3ckQi2xJlR9CI12lNC5oSrX6tmwwanLLEcsGGf/fUW8kxf/pCC3Z0pJ4Fm1TQYeHmU/SMtVCl9DT
ekfIQnRMtMWD4/XzTx01WttcPN+PbHTJiB+sChWoDiBPMADTVjSa4ZIAyMPi6eGmF/Q81YBZrDeK
R0esvdGXo33D808QLvmFkZ0xioGmMn20RhBndmkcPPwO6uVBLNqqvkznjvq5PelWEncLia6W0Y8u
zSt9oAQOR35C5Tks+hXt/EpYgv/cZnkcIziU3G==