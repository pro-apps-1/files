<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrczXC07FttttcCHusMiGbKaJqL/7Z85g9QuCRuwo9mP4eH7HG9beEhKCIE1K5XqzWgZEajN
ypaC91hIaIcqmRi280b76z/uCzJCcRGFIlzv6lU5MLJ9iC96lex+kesbXe4svFywGaPbkyE1xis/
JuE4V2t+As7IEsZ3OnPxZnv+GD9QYjzysUJ1VsNr/JZOXokwbnEXfUnBUT1cuR630Kl/tOpDOcHO
srSf4/fQNl9OjzoGHwt0k8Ni9UcBHzyYMbAZRXD+6Z68SCA7rRq4bKjocVDeWPqb6xrQEME5aKSQ
kCi9jFDmo2+vaKFi0ywFQeGKUYCm/tbn6W+kayi20S/nNx6hSxcqDwfTz7E80dEqGqKo8G4hdIyY
faTtykLrzu74JM1b+tIe4vSXgiVnxHKxC9y+8iwtJhYSP1SYZShBMupG/Kq3vIvg+ZiGHBgNHYuZ
hhtKchtFcqD+6SrSbe7uGIKYy8x4PMgM/AO4DkYzZvzHQkY9CsUsO6KdjLnRWXTl/lyY9y2wpkw2
qcmMoPdyZZByL0TNtebi9qf50hllGjZQBk/E1hHQH3GZ2T0nsmPvj5VnB3XzEFNsvXffqiWZfNBw
P0oe2GC2+VMb99diS5dBo5RA0jwmFSN4QgAX60ecmk/EqqB/h/ki8ONjZr6TPxLQbToSJ7i8u3E0
vTaBPOZowXMyQY7fTpiwMRHZVvA38xChVrCYRIiDUVVtprJ8IZQUvtDtk0ln31IDMLsMwZO+vDDN
osQ8Xn+AwqAJq8RFeMyaTx1+6IWmvg0W2oCVP5+xxs4ky30ptJsTKQhnjRPw4tuGBGGGWrSVBkcC
JGXXFrola0fjIQzVkKYdZN93prs3rVudWn6T/nbml99tPKTi46vSw/RgmyepNL6Ftdf35nLM/53d
ivv2FS+c2qTDdCqmb/8uRivkcPwOuob1LfO3WdTWn46ojxISB2NDzrHMDR1oTcFIg2XN7zKfqjTV
elc82aokOWFLjkQ27cQRHqcWDyx3emFDDTArKc3aaLHy6DE2EDKq1+1DKTxsHj2duXLGulFWug28
8VgDKenYKmp9KsNdblrRXDcuICcQLglpDmFpsCCkhCUN9KOMqKtBwKNjEUOVHspAUfUy3CEA2+7w
gMSPWM7WGjJSC25UAl21j+SS2xs8pUAJFRjL1mFjrWX1VdbbqYatNHOpYUL1b1RrGNgM3rkPcUg6
G4rVj9uvlt6MyVfWbQ7VdshhHn603tvTaqyZbUVH4J/KjmcWKJgvOVKRnxLfp7gQHj76Vo114/IY
JUlQwATrLNFGm3fa49NCg0d9GC/P4+MuiHpSwoHTmFlaVf7LkAfVCA594dWmTB/w2c/AJBxvo335
4KnCz8cW5N1wk2Cwv7bN0SjUPI6NrrUQQLmSOeIEFaNwFpV35exgfzwCMl01h/0e5dPc+Oqocj3R
lc7Rl49+5pkJGMKoyVREr8FOTUebG7ldLTbl/5+RqPpRwkQ0KfLTzRlatMs8LH9ZX0LbTfGt3+cx
tPkvyPrDbPXxBGaoW2pjbff2Q3cwVn9cNpINVgym2jO9/T1YdF+VwV35/TU/wS3yjZCXBcbskfku
0Y0cuW6eMcqn0GTOR7wWQ7/jax7BiscLTia4r55df1Rtze9wGYm3RD02wwZJQ7kRcV0+LzgBhGGC
fsmCdg29UGTDTRy8t9205eaIvRMrL9ZrSZN/ITZDBB3N83WOwe/nir6UmUqrs8jrqrBZnO8NoO9q
tu+iahy/DA6s+jhzuOZkMiF47DesH582mIELdc9+Lthkmb++gHGkpGxuU429H2gwvYRtP6mdTKrA
DKDoiyBLLKhCAQron3PMtdDtUHmEt6k+RWOcqpB/+kiOKJBXkKFW5dY2nif+n+YCAg+w4ffvksy2
h5YYofh75ZewhoylQRGOQwme97TJ19w3md9+grMht1vqFPloX0ZhoEDxdat9sN/yWrdKi4NoY+X+
MGxBlkTG1+lRu2+Z0tkIObbW2fQ2ZrOMpw048kbPsnzrg4ndPmbGkC9fLaWts4zNzbKz7ZL+8K4m
WEVlf8/EaQuVfyYGRs10c5yVQYgH9qaDHizt8HUdvmo55e+biHk3WYROFVuT/zRz/VmZkx+XADRe
Jd3lrqApdu6g9BrRW8kJxVV0k5URQIBojdx1o8w8gVdBeHNTLV9MPIXCsh4RHg8kt67Lmw7ilPwr
po3T07R1y/oBxRmny61Bz9wTE9F13O6e4Yo/0Sd9RPhiVTV8aUcw9mYJoNPgYPvaC8FumjUfsUn9
jLDBAwK6OqIG9QFM3M3MEqK4I6e2mGz/JVhvfzpIhdkMf2m9t1UF6CprEJhmUjPndbLR30Luwtjz
hO7iApipO/dZ3ILpfkahyCHb3SsaRkNL2nIBOY5SNftGtnqK6NihmUetdRX8t/8pSyjJuMznk1Uq
j/rW7/o1g6IJyMqj7ioqv5VsWvj1Vk22NWiCmWj8YJsYGXp/gZ4ery0SsKADn8SAJkTOzzyglqLf
y2YFVTI/5NFxH3YSA11dznShWPuRJUJDQFWSAenIxXDHEIrGO/DyxIBKL5fMjscXYHb2lKI38INH
jCcgUjHIyb3jx5iGa0jBLvOmGvuXERLOwe/iRcLx0rmK70glyVlohrNiwUphHOP4lZYKTo6NWyJD
UW9K+f0rUXI9ed1SVn21q+7PTEddSKBGR+eFgffUOoE6WP243ZsM8dzn94YJ6S/eVMref5J4WuKb
AB7tAbNoBi8hdpfBHHZBlqXcndPtkEzUNUDUip3Ff7QSRg6GhnJopMxNTAERNY0TpOggj0eCRoGz
ETK8KqFrNNl8AJX7/n2YmFHnbxWee5zk3/U9NBQGcbPgNA0wxlhSvlceK+HLvhPpiVICHqVnMuLm
fx8ELX7305OPsQ+Sx35m++Hb8y18XF0Aql+RQhtTaL0wfyDA/FkaTxYLoELK+YIxf3kk+qhOJ6iH
lhEbZHGcA+u4ALneYYSF1Bi65q6g/t3xp7q=