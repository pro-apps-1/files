<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyjXH6g9qhnDLB/HINmsRDs7G5ufSLbhx8ouAV0Kh0aHEAtzs6+xUF4i8pIwe/UZcjU7LUiv
5PFsVuJsBJEZLV6Ei5rKRXFpFKX7UQ8d22MBWtaJJ6htDClpgCzwSCwWzVpBRiRqLl5tQyDh3IUE
sVl/dckuouJUzoLytwDmx3qmjqk7TyfhJRUNmLlchmN3zaVCLHUw/ZBT+Tx2dpsxpB5PN0uGxtvZ
5yBHdi/qhb07kzUxrRXJjJXqUPVAov0HHMz2t4A2h9bI+Gfx+6/Lx3YILYXotGT2cibg5QheaLk8
S2ek//rg5bSaavHCjodv2O+ShoBJCG44d390zbqmsni8SlVuObir9mvJHMADuy+cG54iJKnlnJtq
JL5lCmM1WfaKn4enYLFiY8t9Ty10igLouXPSnGsH+GJNGK2dw2S42z5czkFlxx3pEQn8VGHUujSM
iLBweqJfIu5tcoeHHGYX9eDvaqxtXPqKwjqSnXE6lCyks1heGxhRjyS72bOAkvq+O889vwkhncd5
Tkr7klZttjzoy87LQmeNej9NIW/PcfqPFoueg+W8hO/5dGgjZHgej/wHSy4OqxDOyrnsplLBfpKk
kC7KwDfEmbgyrhBxvMkTWZ0TEYBcbXhUn3XTKcS6uqKS8MjzRCcBxxNTiv1TnDIjsmKsCpEAsL1l
zwOHdeLqOU8uOcCvTa43m+DhbAxwX4Ns0yYkJlecaAb+168ZuH9pcR/uN3Ug3R2siZqsjP4qlzjN
9NqDH1R6aFKUgAN7VF15BJlwmN4bs+5S/DZ8fi+pCjhQeb0t/FOQa+lf3wFlxAOP6gH/Pdtajhh7
OFo8IThNDFhoq82qGVB0hg3A4JKlMvuRsCfjqXQSX2e+KYRCYhr+O4gKAY0UtCn3wiCpQiLp+LBM
n0f2WlsKBR/UdJXJYUyKHVzNhi/n+MM/5v6sUVgvd+GiJrzymrlj6+dPN9k+0lM/qulEJ1jSceaH
jDmhBJNIEcEuGBzevgOMttksIZWubkETs61czA+jmiau50RANtVPZWzO2kQwNiBlNqhlJ1MEayl6
S8j+PRDxpu5+NIdffnTW3rRs9uug7TfSwGUj07UhyNt8r7Ac3AYmPwkPOTCgQsGpHcIQHtIRa1on
yZ1EInT//MlIEo0xrF0EW55a+GMXEl8s62XaOec6uxm4S3wcokKFGQi7jkFSejVullv0zFMk9xHb
0BwY6KkfHdrIfF6puESICdIeN6APV1tJKdHH79UKBqDSP36mw4cRzw9LLHAe8QZXQsmhDlRxVWJc
NYO+YGWBsG5LmG/NlR1rSXXjGrb6L+bqXvaWMGrXbwzu0Vau+mKe/x61y2nmZ3WplL15YA1ACOgQ
EKLxauipebHzUGWXIiaWX6wrpN3EySDQfbODGInvzMDh6ZDzjQTSCvPkCCF23grDvDXhcL90rv6J
pVv5WSWUL2OoJ/hv/5KabR5XLblVpMxtDHuMcH+26FD7qrW08FqLq6sQsANEGwOWKPczDQ964odw
fRFP9tbPQzzBnIS9GhHiB/iirksHPbG+/SIpKAV3CPOj4kV3+HzqZswAlG8WjYTOtxacyorVokip
XgGp8g21/XO6wHrbph0xc2dSUXAjddvgmkqWysrAbN0x9VRPmRGUCaj7LuwqNyENkucRZcStW735
7Mtq5pAGz35cqcKIhGwgycQCvZGpnY6cA1e5IxBVXL4lx0CbJTtmGGgBiwnE/+G+qgAiU9+HaP83
QQZWmeNebvfZn9tzMB3gMUlGQZQR/gQlNQbSfIIvTOFDJxnwohR3N2rT9fnQRZ5toQX8/XOxzPJh
prkHN4TN2ku22FndSkJRLx8h0eNyel8O5e9zgBK5i0zRWYmdAaB72JxVmg7ONeR+mgxfGCkFk8/F
5kFQ+UX5DkkevXzP+J3ovZ+8eBYjEIOm7mPHatT9S2hG/FqEpn52ucEPM2wytMEuDz/J9X6S7vn0
pIiZSl2hgixsApaa05nb0BLJnQ4kSKwOft02OHxDV9oqxAtBytFlsw5n7yJ6liprvxb5gTWF3Rw/
m0ucav8pvVYdiQnHUnbEneixwcNSWE14asVM5+ytudsVteHpjNXy2+Sbm1okIdCPxO+MaFpmT2pF
BgYO0Ob5boQyScs0TNTXv/wx+823CZ4F/1Ft9/Ozp0PA/ziVPFGhPsLKzgzJUSYmGYiJjXEUjWCp
k3jtdGBpAOKQBOioOPFdjshg0lEplbHKZV1gAUuH6tHi5Z8o0hJHoe75cwr++N1V3iZvciSrKNK/
drhb6rMm9Uu8+ndodrPPEiTNCg5kGw5WLVMWIDm810mWHaID1FzdsC63zDw75nEfEUWiM/2CwvJO
Bh2SRByA3J3LNw0daoQjtGXK/rymMhhtQoVfKwnK9vCOB6rvnTX4n8CHzIVHQz2scNnSXm49s2zE
d6X0LrOqiiUYJvT99d1ZcQ+gU0YCxRSK4DLR+hu94oBi1sLg7VEoVJIuvGCKK9Hger2EO7sI2N94
NCgDVXjPEpNEvgwohStmyYsTiMFbmpWna+UsBhsXdreOmCDiRvO5vaR2WuRO43kVv4IrWfUBIRhR
VoRL10BDbdIFPvckLedW/F13YOKgp1AiRzCRLz0UDZd+8c9WBCy+tc1I/TPd9xUSDZKTLieAdnWH
Rhf/WhsxO2211bw/i9Tc3uQ4ektMvUYugGj3eKBe1ujgMALPXNntJGzIjo0tbXgnho+zu41ZncYY
xbblJd+4zJX/Jo61rqjv3N4NEVSD3tntzvJVAkLDiRoCS4yADpu7wzal5b8hh0YyXqg4zyiVbrNZ
6EHhBnZt7KX9KBNqUAKuy0EC2mN1ul7z4Nuwn18ZCVLB4DZTyvW6NahGtIyBw21asU89ZmFzfNdS
UbpdAa2lKM6SH7E7Gph9TTtWDFdU6wmcElSwjjRbYCeiyScKnwAzuFSOrvJuHmrbNC5oHyi1fn7b
J+S=