<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs+uKdoM5QTpRtZ7Np36NyfILrkHYoS6LEuAntAYQiRukZlATVn3os4FgMGxswfz11ZrLJAV
hk8ZyEhL0FHIB8Fm9wHVo3XrTc3t2FX64nSJKRn/PZ5GEwUY67bmcz4JE5th+aoJ7jKj0fDfXgyX
MTAbC3AEi6SlB3xzAT4ByovJrkvuSAFSi+01Wabs9XsZOy790CLXFylZC4b903OWr+Q+bFGPcZN1
ZbRt5kWKFRZTquKY1UKG6mrD5Qke1kn+k0+4AA/qOIVeMQvUGGS9hHbYkf3xzMC7CY6KXzS7k8QS
iW6nYWZ/XX6HORHCLuuKwPHqYAmsgd/JlXI4GDYphNGvvLrQwLKNG8ghsYSb8u+kqiSIJEfIaTK6
Gj6P7+Evg+iKXQYxkyItdhTikjWCzyGt4aJenQJ+5R1QX4Tkwf0JMEiZdxnME6JKj7XxnN8NCZXP
ont5eSOdYxqWnHTD9bh0EbPSO2ED6Jgn94lV84ikcqp11XFH0BeNZ6gwvjWwsx+HX97KrDiOcf8D
42PSnDBZlmbP+ZdC+5gd4m5UB/YQR85RojTP8eG1W3vsvIQIv0P84HY/5a6HzMK76Isx4/LpbPQr
gwN+2Rv/QrUy1P22WEuhOKxktNxvZI1ycv6Tby5IrMFcSF/7HFZaa3VuSG4rwQIBnnNeA/2ZYgjf
rX+5/OSRV9Tqj6SvDnd1DQdiiibXNkZykewXths5jQKpjSKcLTfZmzxLnV/D7fjiJk0AOjaaITBe
g4V/X0eMy74C7GuxirWKgw0UPxFoVgvbSaShcfjGpv2ELm8Vygjsk+jSDjN34U2oxQRQvmV24OFF
0Q+WXiPkfWvjlyEAl5+WVQyrgDMr92rscghQsivDW+2wdRW5Uc1bgPFtun6ymyIUb5DvwS3C/ocj
D/orWx6kyrNrghnqfEfO7i9rAcRxZ3hPwt2Q7SeXTLgPrUSz9RAX3X43ox1Z1yeMG2FYFdnfjNCi
LkH0C54PNMTA5Uz8J2CVwREp+rzG5vQPMHoQVdu6RsUuNLhpuL74httgyBJDK9/cy1aBoenhKDis
la1qKveTSyoLcCa3AuDZdfdcDAPxhoNJlosKKNRrM1PNcCrkDnlghKtnOw4eE1aA