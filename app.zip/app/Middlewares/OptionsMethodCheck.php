<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpOzv1DvaTma1FrnC6Ym0t7ajyfV8KC5GxcuTlDsyMPehODJRHaIgp2n/In+JQ7HC282Z0je
d2IgwcZ+QgkO42TFDoO724hn1uqxaqo4Zn6URD+raC/zce52+nfefD/RHSuW+iGjAn4PjpJ9uBnG
ReT+3zQ9YyfGcWSDMWXkcMHUhXR4fQuUUP/Ez8okmvKkH/FIw34in7bBth0GTeth5ZveGCftoRNb
68zE+ocnRuV6/AVGJUQySJUBJ4R7HjRKEHDnyh6F55dCubCN2OI5/+0cyXLd3ieXjH9gUWTpKqLt
86jj/+GtTgDZ0LY6IsNJCDMiD8Rl2Ek4pqREYT8/rvpDE0YYKwbQWZ1/Tyv8gI1UxStUz1gHV+bF
uq6WiHBUIanyEdFNnG5xWUGtbbBK7RCqMKCYp3gmmDDVkReOb+TeCOr2I41Wz7UYRPpsEzolV894
gBKMkcT/Tmt2yhmWp2THY0WMPdvcUEKFTDe/PCflFIlEKw2GhSz8VTr0ooQTOV57JqyBAqwnlWmk
LxQIi7jYzfbSFxCeiPNHbxEcjNk7IS661Oe84U0linBE4lF1c2pAV8XPrUWxjBQtrCKJIK7SgU09
EoJu8qGWZEMpfBtuQA+bCoFaKlF2nv22MOh114UultkDFUJ5dc2jOrAupERHaqGDzCzNY2x26ZHc
y3hWOz4Cr/21/ImLwzcFXsMxJCoenwG+NpyURLHXtYO115tYl31yIwq9s06L8fprpbyizSwVrkBp
OslAs4t1AfEHaAiYC9Olw30tqHGi6avPAIcuKHKBynpgGDKVi5/1+wKWqLig6joF9xrKfdQjoRpJ
3LdYcnbkRiZmaQeCJjsAbhiTKjpSjDvyuw7/8uf+xS4IWAggtVgzN2F5/+fAMWsJofLfPVwVLWWO
H1QHc1Xco/m2sc1iYBg9eKYyoz1Ne4mSklaAbyHBRdv7SUkDzeNasOjdUFRjGqsNPEz0JaNyd0bR
Rv0JZir00kIm4Zl4H6a4JkOHzltIf3dFp4ynFGYNVRigQ8OqNmyMeLXFmPU4ul0ad2YQoa9jEiuB
R8pFRSPhGev6X6BVl2G18OG4NYMrdsowDWy5/Z0F5IpoCgKqf11N4L5LXpDfVJ3HdApN65zyKipE
kuCuqpy=