<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo5rU296wK0M7xNj0VIghDLbiW54oC/U1+yv0aPj9Pp5ALH4GB1iCtzNP21rBnbNvi60JauV
cAhs40MkJRfNU8tyCQ8YJQR9T0F5n94uStDUAMY4vXr17+tE5DGhhjyiPyJMk8y2O/29o4mrtbgv
UyRLtQvWvdSYXDbEpkKIUXlKH9yCEplANFc/R1QJuxcxjdiKY8Gr0MqSr2YtGlb6G9e2AAggYDR8
oyqtteDyJJvd8Wy4DNV7QoKba4tgwnj/e0DsWvKXlaL3Uh/9X1QHvBbCUHysXcEYArtkUEvMw6Nb
mGa3gs//yRB7s5fz2nyRDN8Skx8wPhNucuYh1sD5SjJrlDOmxQ5eEhaDlBx0je+UjIeJ7r7I0Nez
+MW4au5rWYRmHuS+3VwCa7sbnQ4hdKbKrXla76uCKxGpfMOPZGBcZkYVga7Ljy5bKG4TM2oF9m/u
youPlksZk6UgffMDBUmhNBSsPrBOfHlPjL63/UDFc4SKaWfjxeP5jZu0CVkjq2dcm3tqgtgFypk+
rOwiqLlgBJhVq+XAZA7caaIkDc/u5Brn0CahE2se168bOAen5F9+a5rWnOAWw2IsiEQngd40xIjd
J5QdbnGGPKEIxo3xrfRMg2M7/BIw3QShWXBG7ri9rfsV0YWQEESLlhz2iWIAstJtqd37bZwDH+5x
6z7o70aJBeZ2llSZ6ITQ2zERWcnMrkTY8jvDNMFlQEFeis7882nF05eVZPxf778CgiSRJIpUbBKX
fTG42PG/BtSptwhoWwn1R7mP/NUAOmkZk9epYjbYDzDoRZ+fiobJ+WaOGHoJCAgapDFZyIhP9SfR
fCdXPMWvyVmwr4wjXCo7k+IvcAoljwpbALuwiNDXMZkz44m5IxErSuRh/DQVJWR/2T+QilwLxj4X
PQX6DeJIXgonJzTJCbqhBbz1Bld/Z1rKj5Gg8VNgfDdHZgDWrgw5Hol+6lYLHFqi+HCRtiaAnWwJ
1+cM75Ve2KCVNC/vf3rM5d65QwobTANt8xo0KMnPUdeDsvZNdYeEmIpW9oa3NkhvOc3zfRGkpb9P
7YGJStddPSaeo8I42xtr1Obz70klAvI6G5XoDWXqhaDAjzLHxH4U6Es1x/XGlxykxRC=