<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx5u8e/swfQWZxYthDiiGbrbu+9PuGISgugueVltN7QJetEe9Lti/lXC2tgwI8WpCTr3lp7t
3GesqxPx4m+daPDWm6dsupG0xnkvwOCNKlYogVG1nZ0lZnmDdE9yPn8POYF2R/nxPh40b8QM50cL
e9FgV+SKpW00rWwSNzQQR7vPvQxJCJWo6golSEVV5QP4+2C4YjsLA4LmXZ5C136TiRvqvw0E+W3x
znAafBnnqrpifAPDPMgrtJ+baDMCnD78voUC7nWRo2Rxs85Hakb8U5GQAzTg3T1ttXh8lsrr4yAz
TsepEFXDwnIT+u/RVpZXzkTkNe+2T6H8GT6S9RDcbZ1/pd+26QvKnH/vxWsd0+N0s1FFZhZFXuLz
ZckgaqXbBbNAlNaz25YGH2JIbHjoKxZySYEmnZEmRc6692EhLoyxgof6SKcb0MlgNDiQkCk5hJ+N
i8sBWVFTvK3Z891ej8dwd/cAv6M53E+m4ZtLdRBdryGcIKFhDIVKv27SJU+OaRrQu/T/sOO+D7T/
4PGV3gywESxEGlmXh9EEAnvqwUSHUzQEqZUOj02doV01okr5T700v6Pr1eXVfl/dX3i04m76cpXx
8YxeWGkuSQreWOenltPg3jcBdmMCQdvWD8mf3OV9Trfr72mjv7d/QUlowgB8+efThTw6PxCSSfug
ZP+C1EUdHLbhcTnjxc9EURJqj62HSX3p9ahfM3y8Zki6dnG5gvNS2XIpw1Q3bQm/5HCKkThRUYhD
KmWZvShMD/yvsjPnlWouoeDu74csT77mNqr3FRuAUCGCWwL4119Jkvg/Dei/TmFnbIU6zk5IEPGE
hFjlxi/wTjuUgoeT93yEVmrz0liYCjJ+rMeCdxLg/LYixzogttFjmzyR/UYHijNcz3DOSHeuAjBc
M1bbgmAfY3tdMBIjd+e1N18JBUYoE8g3lhX06wWFv2o1exkfUTI9IREN2judYvLBi12LtfNLoJcp
LUnQXSBhDIrd83rNcHgE6Om4eEBMgvjtVH9YDyMCnlOzDeMJ+wnlVh3QUgtDz3XqwmX6wvhDb9Us
lvQmifc2GQNT5sWNKlNYWFzt6WPNHJeo/koQsE+VrA929e8L9naVck0HgJXifnus7F8=