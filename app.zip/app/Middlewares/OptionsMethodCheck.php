<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+XPzL05zSrdq9bWSn4X5OHKeE2UKdfqmw2upkf3ff2vwl3VITYs6SDZHKOVniBUYPs7q8p/
vPUJcwMFB1irRsKzU6OAG5hc27mH7XPOe4ETs7Yyx9U8WnYa9sN/47pg/eaizoIGGyLmvKiBjuVx
UzsB1WYTcozrpqovP7DMkShUhXRIvPNYIxySofKf4vF/J4E64QlRuiOEoE9ZE0yZfpPKt5JGySYp
DEChy9Wtaofe4E3nsIDtBMg+umVsqIRgXWSNZfHpRblOCEp/A79DslgBtnDkRMZ886n3h7/UIing
xyiE/up7sEg0UVubLu+wsNc+NvXGPOE30hYCUIL3efTWI/rI7hbgQ4mQfjP+4J8nKqmqcMDiJ+9h
QeIS/Un3oCNVmeFn36RCXyN5/zTWweYdrWZZ4iTwgQcNPE2PphZHOx5oNuZMs3WSa+uXmwqYIgSs
m31vBIfjN22AcDF6rJ5ag4b2p+4/NnSXaJ+JNUyz143cVP0qm+J4qLOeVwUeQQUv9r9bhBCWOMtY
59m7Ae4eZKdIKEUgKfGIGI4xS3X0dqHUvMmZVj1NJQVI8nw2+cc5BGeF+YJILQxXNVcj3X+eHIbO
JnoXn0okmbFhArtKf79LZNdZseErsRMzFz77mMdPHW0CouiEFmbJDoKAHqB2W5z03lLiY5YpvmhW
+4d2Uw/UW4G0PgAidaM68vFf6KUK4ueQLzd4qDDvhjAunT89rT9MANSePgbelgylUSXw+7VePK8s
5TEfrTABfKdocDosqqtXPQrntfRXNzzJkxgkKQ5Y9okKnn6Rk0oRJUekPuphNh9/jJ8xfNLPwe1k
77nmEz2AV+es+0xAG6ty9w9Um1PWMaB0fEzchK7jWg28Qrr4goxI2Caluqbb/gnLmH9YXaN8u+VT
axDiKHpcjrCkQYRdh/DIbq/PuwJUvxoPBqIkZQTkuG8Zh6Gtp6ZybNUAmnvcdbB7pzsHtGcvd6wQ
KmWxepkmNhyuUo5m1bwdXjkFv42lPqERtPoSKGHTBXLlb1fpHkj0AvAbbs6ejoyt1+b/KsKAlsIR
Z6sGpuPoGAnxEV7Q+xk7KqxDAWEQmzsIpR1HdueOEchKiiCrIV0vLTaOpcr86wckPh3wleWvLTO=