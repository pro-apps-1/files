<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrjayQzi/ic0QQHaZ0bD9HY0jgLou3axTSzxOaeCAJLla0XWluAOY9W0EAxVc7O3dUcOpQfE
XfIiFGz/zxtuTo17zcHnJ6lf+iAhGYcK4yRQWijOKkkUs/Xpbbix4C0ZYs9hsNIDDVSBXQ32aUK8
6pK0NoSpUF4fNUyLeUIqGygRWmlks6/iMj2U6TJn/HGMZcVstnh/Zpkvb98NiecPVR8iroDMkmiN
uVNlQT/WXPEeUhfNxTLmNU6EagMGraGQxMeo7IeADpHZv1ITmSJY4lsWpw01mwDjSkwrqt4WpZVx
RURIXuewIPyPdocvARPR7CM3oWki0upQqhegD/Icq+cHyTHqMZBl2dEZ/zTcQ/S02Wp0nemM4OTG
W//UAF2/RDzmabaEKDZMlu4jv+XktjcQd2odTveCCYcKmBmNSnCJjUN893EEBgvBd/YP4FddGmeo
wClsKwYKeKQNsb8VCrBDmV6kgLlw5ohyAnzIdH0eLKc1YUGW4t0jRyeWRgSIBPDOGDGEET08jrjv
5nvEzWuXUMDV0RQDmE9qBCkLebA5K+cop5GeegGFvR5A+UdxW5J85BWzefBSwkEZb8zv68Q+yR+K
ZklAGOhYA1yYNcek1w75xFuKcMCUfGUCpquDz0tF9qdTGMDzW4FBHZQFD0wuMn975z3flT3O/e6V
x8T98BJLRLNbKKHvy6M1B2zofpJbU0AtlFodmbZvD1Mws8quKm1IlK3G8aA411lK9Kcc1mnkKOZX
N3ErnvKDCUchuOMR+NhPGQW54oI6mn+4XebiCPM3SvVGfcIE+kmLS29M4wEV6d8NWMDwYKAZlYky
5ahqfccAkn4jum+Lu1cMOXrl3EElyRR1/CwPGH08eQvLrOvALUZKFITUkSxGUXba9pvnJx4I72oq
y14w2O0TdadaAoNLh9NWtE4m/UiuLfaCxQzIFo8HokUg+GfXsP1ojwX8jYO/2AYGydZCYFqXjHd1
8o2sTArgFPE6a0Unn9vr33sCQY3K8SxxWCFeIKhEinFV+8lQoy7YhC7rhKNp1E2snB1HoA8j33MW
XWbMjV27NWkAwpUXosv1g8FTMzyUZFn06AUrz6HCmGUqSxFtBQoq0lIEJGwqJnZIv81fU0GCN2Rq
gE0qGYS=