<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpFsEyigQ83iCpQkwBKLv005YALeEmatJPAuVZl6bBppay4VBLApPY40Oc5xdcM01tq4GvQw
fsgI/Shm49q6vR/1PjII3zRzWpTQXQx5GnUv7dQ1yzUlac3ch2xVi78fl+lCIkgNcg+uKyDeraH5
v4zHupsezGU0K733CRVmmBvEx6o/NOI8XBR2mmkVPO84mgr+GHpFUJ5tHVXMKG50ciL1sqJOTssR
QbAPDbAwJR1XSRtfEGg5+7YRmAo3O9Tkim14yLvyD5SgexbHR420sM8EOezftPKMuouQxoFN/Uq3
LYec/vjQNNt+IZUwsEI4FbR8EN5Ha3yVK3L6wIoGbQNsRBFbaI5SO/GQWbp0P2wmb3Sl4QNdxqFb
9wRqeyV9ztTinVt7gVntRzrh+nVwqGSz/nyzFzFy7RQFLoCn1VsBUoholTjwDyeBA/j5kSmV8Yaz
3xjuYUlqi0iCASjOUlvePVobT2ixtga/dHciVO69OyXOsChPQhiMxjElOWQhtbq85LREzPOO96H7
cX5kGMBA183MEA/jxbUpqzrhYBD2VWlt8XjWbZ8I4cF+kJ4jA95af0K9GwJFEl3OaI6LmBuCk50V
DdaIRbj9tIbGPdDSYP5CU6mnAjJZHVEQOZ4m+P8ZcmR/OhKRyZzMOpGA3774TpHcJrq8uTKLrRwB
Qwi9l8wN7lJupwUnrZkC6qzYqKVp1pCfi4JailmrA1rIiiFHzdMMjnfoueRL+EaqQ55/qlGwSVAo
bH6OJXQuXZcJkO7LflJlu/ORj0E5OMYibCSkAMPdkwsQUFk3bH+Ub52J9PMebdQf56haZZxNT4VN
vdR1YIM4+m5KnPqLJjSa9kW0M3ZFws2EuANRfsA9iPX/lWfSQLYbivKFDKKlBf9Ruha6NYx73Avr
wP4JzfoNfnLKPc8TTl4nvp0xgVdwTJeUKxA5JkgYBd/jnvmuWbntxJlyYuTTiTQjlctxoZFmc6j9
AwoBRLzu2N76rrKJhAPKapQHjvqIe0lGeST8mTGLBHWocl8vpq/j93MVrmpzyX8leLSH+O23gTyu
o1Nn9+BHvRTtqUcy9CZ+5YMaq/tJFLoXa9/L5X4pMmWABymuFJD4pnl2igFzCZAR