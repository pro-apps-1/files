<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrYRGagLDhTjO5lNQV7sUVbVaeQo/QLKuvouak7kJtErM3LDfm2x3qxulbpD5D6jleJ39eWP
qy4KPlhVxPHYS35t4A2EyS2n1DDxQ6Ut3/k29rr04Xu7Yn5oS8N3Cog/nB7LoQVn+JAOMKSbkSQj
WURCahZg87oaJnh5LapM4j4jsulgZUnntw/G3ScoxqUWylwDTi0SbDOBkax+VDx/YHvF96T/QB4l
Myxqm6tTvagjcwtUc1vH4KFUkmHW+VH/pJ4jRjHLK0sFFSqLpROcz/6WCbLnNR+6Za2+peZoQe82
SofYQ0qjtFC6MFTJqrrT0xPqkhfrThnDe5y8NsDwMV4JQhpzZ78By4oj1gqnZicM4Ohe/aEQXUQF
hpYUC4C4pJxj/Rt4Ebwg7c2DIf6R24w9dilD6OojMYJ9Wzmlgt/XM8oaaeS0RmENRi2KWXeBG/JS
9iZi6oGDpNXHAm0YuyMJGYjSKsYmoH0Z1Jg1ArbzCAqLXhnc9GnkV3d5/EWVHZZA38FyVOxvY6D5
/cfyJVDmBnQBIL0TG3hEtTfoIRXQxhEeXG0r+V2AlWSKQRQv9xxNi42GLY4qieHYTQp3zheVpmCo
0eb+aG91gFVLk05bnqqtHFXOMhTigCX1/uI6NGxbdhcNsScfLPkaXdx/Z48L9F/Tb0UyATAaII86
MNk5Nc+10bcBIcnPpYxcQNXqh/rcr1ihoms4unzY/Aex9pk02kiLfAI8fT/haEJINwL0fRFRmfn0
AYbJ0aUOav7X06aX9FRIERb1+zBUZ7JzAhdv4Btb7ijr3EW7UTVke3yLzlChrVNw+IwzEt5Yx03K
4Ind+wkrSP6p6rky21V0t8ihrkbCBl/zbx/UkKSPMfNLJuoMMm6SRxtwei5BNVZvDENIoBIeb6MF
7VN2VXI4wJ5vpQSEv6RhxEYgSg3QqNXgDKOpicktBvx4R3iaVPmr8pBezJ1OOveKjGbOUFPgHvex
QoaFt1QHA+QSRbvCJJCAvVlr4x4sXmjtGIvnmqX2pu0RpYJt7sVqvO7dIIfYsHGGsUOvufwwBfRa
UldXchmroKIDw0udB0otn2l2eQ3IvAJ6lBq2ZPS1hvH7vgTkjTU6Ocp4p2jU9wj9Myt4eWCtIAq=