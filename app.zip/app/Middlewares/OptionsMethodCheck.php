<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtFapn5aVZGcSIHQCj+2WfrtmIM/YYpTpe6u1Igx3FapddKR2QdrGXpB9c6kkpN6T6O1iK2n
8bhokxXSAakDVBEJgLTubTFDOuJRPdv8tf+CzUylg/MyEuZCJMjHgf5KjOTABw4CEmG5M7wiXB5i
Ac9T79XOG4hFRjoQitxHyKaznXWS7H29P0hzUPNzLpC24AnJoOCpdaUrcs3DFv7hxlU9ZETyQJsv
SMt3Wn6oOn/KMEy4+grlYR+iIuZBdDV+UwJ0CHcsHeRqKnR6xUgE+EdiLI5gPV0VZp7UJX1lMaa2
nsfgJzsyvpiHpEDrRROeLdhB/4kVqW9gTZqn9TOVubCqHz/VeXsKLXQtphx9YXPKTcPDECMTJoNn
zZ59oW3IehamuXJS5whStEsdPLgZjrdV2x+ANtMl5MbBb0awo9CU7td50qC3+kxMM0EofqVQihfQ
IQRbEiU75TmIC2D7Jj7jadpSZXujoUYZKyqZeaAZqVymfan6VDByer/iy7b03ucXCO9ZrF5CV+lc
FZUJxR/fcz/8MIB6JGRGzFtuTRuFu81F2WiQ83Ab9FvUdD/N/yyPPKjOrQ2Zoh9cmRWbYJXlAclE
+xSY38aVH7FJVlMGY2V2/8M2V7EF/PrdiHAsAf6P8tALI5av8OAUr1rJmixuVtLEjTHEtji260Lu
R08FcTfDScqpCSNUYNDhlIH7AmznIrIsE+gkgF6BW55LdDHncND1nHKtmH2OJFUW4J9s6r6D5sA8
OW75G1olkmWYBZ9zPDcmYzi1ls4B6T7DKh+WHQSA3YXxGBuC5CQEL0noTQnZ2lZ3h6vY+akP8CCG
p61XMzLADJBtJDK4/N9a4fuBykgUG4VJadUpgzpl6D8SiRWcqBPYT/5ZfkxJ3AUMXy4eqK9F2j0z
jQZlmdSBlmkPgGSonnMCNpiGUfg8oxChWGzo5U7BZ7pX/xJYNGYG8CAGpSD7T9GolVh3TnlPrP4h
AsapK4GjRVb+2bUkEr4JyCzgVNQ83ZhSXA+eaizIuMyHQR0J81i0RXXuM0jN/6Aik8CYomi/leMz
gDfveXau7F6T/gsW8179cJrzFcJ8f9Y/IiE6Ux/KqVQmAZ8+hvVUV56tO2pq6W==