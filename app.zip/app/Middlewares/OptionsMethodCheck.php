<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzFgq97iP2ccwIf5ic4vuZ6vPrimD2s/0U1KRBl3rqTtIdgJkUG+tq3zWcbEKzBUb4kR5TRK
pUPl4msQGlNY0/hJXhNV3wioVlHhm0WC0lVn4+6BlRWqBqifxZVxBiV7jCquPIuzXfYVu+28+/eX
X6E6NaqS7F1bNWB19eV+X/TMtS+q7qAJ4Y3KYC2M+jqYK/8tQFurD7hdkAAGt/kcvhYr8LOA2/Tq
nw6NuLBbynoJa0ox+prEI8Z/U/msNb4bAz43Ln5yXavASODAXtEDfJjwW1HhRM5LX4G+tqKd3E1j
uTRB6jldnbn1iwU6HuZ3JV4FwgbZrlQH62dcG4WReZk4EY3MJqps41n83ZcdDcg1S4tYIvTDTMx8
3jjhW2UDVGLa+1ma0Soaw2daXx/nlswE0b9NxqrwcT4YhAiDJxlC7AFWiorc6tFEcLFKTcIBMKeA
oIqOSGAYUtjPFJA3yaXZAx+nBVl6J+34yeYjrXBKrDPIbgAw23UpSjhsmxxWbqOFEXZTuV/pIrlK
ht9DulmKLkd2iCAxMyJZ83kw9QEeJ0zOno5tG3U6+8k3euv4ZjHTYtAZhyyJznOwAhw4y/IQK00O
oYTGlnLqW4wbiTvdCtWOgf0H2tBfwLKdW9Kp2W6D0YAR57PoUkCn/ojShNZaVm0SM7roN/cfmouP
PACOrrtAC2klw+2mHmDzf1nBI/Ro5t/hx5/t8mpolOfDoodUNyaj6FW2xLPe4fUOmdJPn4SMglB7
XIVG7gGM05VmvhLAIEKhBEuEwv7EV3JhIuL8op5oMm1aavJW+m4NpukMhsgZeVl4UJOpmQgJx9Zq
BK3LsBdxi0us6eTRH3UhWAosEFm7EOHToliaB5sZZ2fuY8/Py5hH0oOWpIkAMY3PGcqSUNjMm+lj
JdTiyzV84Hmk8Pfd70wE/sRYAZ/JXDDGciH3KKAcy3Z/42HE+XH9SU5HGyzu6LjX1CtkyzuB3eIV
oHd47z/NlS/8qt1Uqk1gZWY3Gnh1dcLBRomALJJnwX/CinhEaTCgNir86tUH7QjQ2eIGDN6NktHG
HnLIqFcq0hxWXDFuaIzvk6ykfMx0UMxgVYEan7WzOQqWJcS19jPmnXLSOOFGYAwjzg/4BzwX