<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoQqiTws9WeHJsia/LQRIVpPIPeAGsk7TEGWRxCllhWScs1ZUU0AUUcGzopV15GF39tlIw43
ixMARKcQbw5XMMejj7Yhd4Ew6srXdDMj2sCDfjxQWBnMnUiKTShjLnYlyK0Qc/97xesgN74DsvJB
Oi32FUg+zCnQy+TVc5r3Dex7+9atcB3r0oY5vUS+z3iukZO/E8FMFwV78QYfGR8uUDFY5loCnmc7
DLmnZkmGOmvgSKA6UfhaV/O0Vt4QzhaDpJzSqQ+9ME/C9FKFr/I8J8bEJI3XQcB0fLYWVP2pFo/+
EAsAVb4IKZltYjM4WONKwGMRMA1lFJ4SqiZ9SkTkuDcJvfrfUuERNtKBxS9vJzWe3p80T9lInVMz
/uk5KxQ9qwnoN4nAc0sd5NmEZHyX0WXA4uWp/HMUG16j/JXvfOsbqggixh3NmLhwiYEdhIkNfNkm
zM96SbiFkrSDm2PGXBmFdJUaI5E/JamlTdRHPvowN2aofUcdqNHdV0i/hlFKDD6FjiMXxC7ILcXK
0l2KdS0jS8VVOlqZOQNYTxw/W+GRzR9kt02q2i8A2o/6o5Y7sbpZd7kR1PcQvlCOc6P0cfryEUdq
Y8EfixK7QNkmtaxJrfjc4XeV4YP9wO6WyYEk24mJwEda1vzG/tTGh4YXWsiddxxGKEbqR9UqWs34
k8/9lxhXqLzdwHebb9ubTYndguDViBg3LjCw3b2orUOAyaKIQnOBBswlL66/2gRidKCX1kCwgp2q
Fi+s4EAyT+sfq0VkVPLpt7En49v42lXw4Dwc/xjlZf31mVZXizIcDvKEYECdwyX7yUoiVSRh6kPz
gIrrqXi9vhCmtHf3jDVXdhWAKm307ojgSvygSmuDd2QVS2OeWTk1r09AnwMY4LLT+d2tM/3XzwCu
tWLJaTLnRwSNwgSgNq5N0HbAU56fAKu6n2EETL9vaGhr3WNZTItv5EpPBWmp5mFH1bPyni7U4Wvt
cjFjc8lL3LKU8425KEwSgrugmDc/lbmU5iSxFvNlkSSMsGqPmRO9bMSsj0fRqX6eakWZzdDTDb7h
PfWGDT7qp3sAmbpTmPnWGojRn5CwMBfUVM+QuRC8kSKexGEAxrqj4E3EkVU1JwUj+C88P7T+GWeM
Cg85qpSGvTfS5x84LkpakfS9LnrP69Ea1Mfyz4yu/xosLDW1WIwluofvJbDZCrQkPRYe2gpSvZHJ
N6VvkJavTH3MUN3U6T+uUMH+20/kNRsAIUhRJI3lAp94NSVSvErGimgDMgSDZL8YuSk6BPQQT2lQ
1ZLZRPXoYAJAYc3TDmEL7WBx/2X9ezEzdPBtdkCvRHp2FLGhOQtDE9SW3g4KX5D34H8kvEoToNnS
vPZlNYHneotMsfOn1qp83VNXGiOKK4AYm5ZXTLmTrDQnW2YmQcS1zJx49DxN0xGFs6vH5zIwYsSb
qkXVS0QuhufcxiAKhcP3gI9/wFvWGR75y2rrM0W7tmztG6dEJkWLbf7bn+QcuT20ZE/spexY5vjL
ubBuFjSqu0hRNTKYMvvW67doVLjJvUtyOZDi0nYHja5yj8vB7rsLfdb9OKORs0MoWCQgk7ZQN+np
8TJrUKFUCbBE6QacIOUhP/CPbreBeTjSm7TYfGhLhqbMcK0pb2MjgDoA/tVg1ZrLOGn/rZB44yD7
DKW0pcJL6T0QPMtz7OZeHz1+aQkI24zvNgpHI+s3KmvczA9it5Zr7DmTW3g0oHPLN7kofPIuwRxD
KU2J9Ic8TQf24EErXX/zwbHdNT9byfIv/9jDX3hiAKnjRzPWDdJhMf0SDs3YHHV1NyQuz2FmtOmj
pKFaJqJXWneZJYL68bOLLAws6tD89uJ6n1LD7WYCjg78ijFbXJG1D6m8BjSINbyiZhYU2q9jrTd8
MzTwxh3Iq5JP/skRz0QspMkvdJ3JYMo1oUhUmDp2cxOrFGusJaV6a4jGJtX4mpO3F/9KPZTgZ7Uj
sPK1KnnH7dgib2G/B8wUsmajzoKXKAZaPhIULdFfgxJsl4/ReSeE3aUtyycs+nmcnZJ/L+L89yVe
k7hafCGOOhGVJPbkCsZODnmg8/z8sQr5dGTxdP0GhPbabxerq7B50gT/Dfof54bmBsY5+QKbRpYi
Rt8f9Q20gdXvl81svHte5Tu5HfIuVZQO31tH2dSDlS7aZUP2fYiZUuMgBPO4BhJwWh1K4jdC4a71
5/BbGIw/KNaop3YpQNfuPgzmK3WewvgmjDE9wdwL1E+sauvf5DCc8YWx9KUMHPIE23HBhVPkE/rL
Wetl6P8BrpWrie3onCUdMvmg2BrkAQqxHWFY4V8bb79chgSf9FXcYi/7zFT3yb3y/xt6GGq48iu3
M2qBfA9mFIkYmOpDVt0PM9zbRMkP51Vd3YNs7nChGepHlXv27sWvFoBLakkhw9HH7JsRc7lLjbm6
JL1jMxstxjQxrXagpAyRZh+UtcvO1dDKgdTnq9ak5dXQErVzU9iB5E3mEl73NdWBEBtogl76dRi5
gQw0bEe7THWOm+CpKjlu7jP21slifBtHQpwNXUeupCarRCZeh8MJ+5VwoBlS2FMRoI4XAapmPRfi
PCoNiU1bpaVe4PQdTVSOttzcMKKVV9+Zy6Dc6jZqnAJOmlmO2s+FcLW28BMmw3NbDRX8QDdf+9Un
24wgPsJ0vbE6whnSlSC9j99zLY7mSTxaHo64A0ciVUhf2WZ6UVU/YoKAvhCTJEux3NX6TnRsTYiH
/t2bbqzvtHFICmRLb64hI5DcdG7eqCvAmVHp3TKFGtNKLyYpzLu00pVeUeuFBQbraNtoev8GuvOJ
cMm23WD1FSwXjx0ItX2b65Kf0xQR7EgMBOh9RNgKPw1gaDDkxhhW52tehVWhDFVGAr7jPI6rxi2s
NKLHyCYo6bK2htC4YmFXifRQ+cOYcjI03yhvkKsLkoOmi9EyNWhxIduu9HIiJ5EHBgMGYwDW4g3X
uxdDsRD8zRu1k9K4HuEKYPQjbnFtT8IIKSBURy3adfoiHJW6mGX5/r5NEA9yiE8RbQhzpgbojDJS
RHG/lBETS8PuRds46V+bTyF+1aCMb7EbmOuGjYbI3g8s6bCeovr9QG0lVB4Gw/kMeDg05MM6cvX6
Sd027eWCNSCuoweNzW0wGSKaoqBb8Do9LKRV3ozsBRn/hvp3qEVt9jzhlDi5JYEGj6mvkxpjDOaX
KgmACvp2OyAl2YfM+McNYkY0qHzMG6QuBqc57QD5vFYu4DV8MlEqDluXn9jMOHJ3LukEYxDoB4xz
VxzSIcRqZ+8cEyKUceHt36RIsnvdoVkWlGMhSkES+Y/u5gZYPcwPw1kzblw1T573y78FVkgdkAsa
rEaALD4rkGypWFQhUUY7iL56UXmMNdHffT70KD4iI9n4CS8h0e+vF/jA5/YjfkUY8bGp5+dyYIDP
fYQk6XWTKsHojRdD4ay0ox44Ml0x2SCjxD4LWoEzqvRq40==