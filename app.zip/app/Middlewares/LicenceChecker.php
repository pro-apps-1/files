<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpzzvjvA+TeH4wLp/LKkT10vv98xOiSJfDYc0hRWC5k0Au9pzXGHANUJxsmFconKyqytgSas
XgZg8a/+oAnNZ9NIwzHuWKhc6dAO4AaNn8vC5o9aVhP7c99xYU1NZ2GpKzbp96Cl8mMvyQMbPx8P
g2bTpXGbuXIZBXf8iNHg+uBDy0mKtVtG03AobYotfB7F1Tredl+lvHIJTHfVTzOuP0c0Kzhe8Ut2
jKkKbB/DCPdAJgKHVLTuSIamwOq7PXwDZguHw15yXavASODAXtEDfJjwW1GBPIXLkMRiVZFwvgdb
Nj3B899KBofvfJclSNycQEqI2ztxYIA/90RkSOOjRD4W8PxorSLlUKNi7Bp/wbgKz60khgVQ9Ik5
Sgg3QTFHNDjdXk0tevY0P/2zdv7hBq8ckjzUKQ8Iz2cN4cvsLZRUOf4w/0+y3uZ5qQpWvCLLReB1
JVj8PZBbcRNZMqFMonF8j1f1ZBEu0b71zXGkDMTDFjSI34R+9e2KEWwRD0E6LnEHIOmzkb0+avgK
DbqBWB4QoHXKP8XKUKz1fS/UFfZCN0IMn6HKUwDY3FvrYkHa+a8WJhgmRuDTC2xr8S2LuxBhCKle
rqRK9NECThD6BPq7+VlL9W+KHo2K+l0CXHORRtWdZWeB7SDsdLesD9QS9zBvsjWc3Z4zgLcpiS+p
wGJOkBOqu85MpfpILxOYfyMnE4x1D69yTKoQh/kE5t6VdjEMndPpWtUQPqwKGhP+l0Zz7fMy7hZK
DfAjS+1JX83pSL+4ZmAJ6yQWDgJRdrewabt6XtPUbhuuqbgX+HfPCYrKeS1LohFc9ewBKrwPSg84
9rWJVPMB9pqqf5QEBefnuKX+D2Kzf563P98eMqVi+wjdqJGBQ+aGwvQI3LOZ3FK/AVWHhhAN+nIg
uMf/P83as7LjFJMWqSnJIJzLZ/ijgEvtZvMVsYhxIZ1QCU7UBu2V2E+ocv7VFKxT2YJeEQGaayH6
j+p/g3I1JQ3qxJF3PyLyRXPHO5aGTaZncZsxt2JwObrX8j0UfS9XkiiW6yj7uRRH9HHsJ/ZWNMUR
Bblx0YPOq2uVLfG/Xs1l60vpq6obp/YHVyUD4RDm5JglZMSxX6q9UVw+be4RhUoA/BLcmTATXEOc
JpC/ndkVbx/1DbJP2KMHds5b138fxbxsBv6XsT1DfsFEoRq6X5ppeHBJGv7Qi7xZ5fGultVJySmx
JsQpAt/T/3akCwXdXO4S0Cjl6RLVSBbBpMcEqP8u9eQ/NNObqJhyCytfDKxwXEe8ZCBLAMeYZ+L/
eAFqPV+WLJOgPIVq+4tP5b8/5q1w5YtjOsqmRAqUAXm/tTFvzddMw9mo3e5ujnF0Hfa01qkIVrWV
S/3vbuhMSr4M21LBcFzZoV3Lb/tSc/SSKWZ+g2miwY4FtSIAN8cD3KJ7oLqbGSSSBUT7V1w5pQN7
W9UnNod88yIf/8mTMEHWUJUgyARby9WoQzl/zRuwfXfMWydXa3Vtk0k4ICLX+OOhN9DWgeJh3Ttn
yavbLpAY2Hlc0NNdhEL4fY1Y3PDbO+WuDM0HpbccrJY6kXHbasFmM4Oaha0ldDSkgsutVz1Yt7TI
Y7z03wzG73HwscMi5bNxp/phiaBV1SVFhLlH7CaUZcwfSTokcI25tjW+ByocWrKJcSnp6cGAvuwg
4jE4lU6LlpJAad8X8c6ZgRi95HtOWIrI/xtTJNLccbGkNb9c733YMBI1jOLKwy2qk80sUf/AZm6G
WCVKrjKH0bSoHxdX1sHCgxCN8CaoInTX1wfVnEr4m+lsam0xSd1/0fHljTuBEjoBQbwOyEq6krvb
TI6KjqE/0LOx32x96EX3iNQV5N7XKIlOGCPmJER3P0ivf2zZOVDXtkHzMTdNN9LqYdUQ1s9IjEiB
U7NPB/kwsyaSIypXsZQ/CBIzFNblOYC6FiKYH8sbX5ho2uivWIakOq4A9dMiCoz3BoS20GLO2uB9
lZKOhWXAYjBFgnSW2krrV7a+m1eOkoMGrhQBfXYQKjigFr2GwULJL/QI2Kc8OfI3thXyAHx/KF43
fFeBuAZQExXBtUW3C2YqdkbU7kBU8AC8YXkFmOccAp9EdMQvnftzVIwLemEMPURBfBgXyW5vWKhm
UQNNDH0H83vFLnahr32NcwYrGJMD4VByhAHYxhdnC2JHtKbARp92IOe5AAc8P6DhLI5l78pINsqB
v8yul/HSAI+XNH3y7TxJ48qOaZcbouCoUqdQiJOk6k2iFTsTyJNsuZyWMJL1IoszcRlBkM/PoqVs
hDcbTkI0qWNIlzD2QumwBmVUWt+c6DCZx6BDYr2xBERfwo7pZfFYdBMQuklo8dxPXQzIUB85RE8c
oAKaChr1nMBAYKhb69dPu+64Jen5rjaz5DQW+saHHr2Sgel/SVYvQem+1o4DNhxf2CsDtDfd8ALN
crMgwHKJgYwyzJyENeNmt8yw/lfuUCd1gFS5pCdG5hrNButR2w93dQtIvCJLOwWWx1vpGaVUazTi
iw9Z6cl3+ZVQgFwXHixVg2PSMrauPhCoiNac7B9Z9SdE2CVYwH055NCULyYHMO2XK7RAxP//Ld8h
IkUM7arxduhWmzKsMhFkfdUCiY7fO14CAcX+QnEEtomoIAMbm01ZpHxUVjz7KNasuq5gEVmSaTzA
L1qCnKx2wlV5Gb4nb9aD2UltqvQAUQoCs8s3Q1xX9ly4+RHfdJNI4507PC3W9E7YrNvstN1BduPw
0YmS/wgJA7ONp72V3qv0VTPUXysMjUuLBd7pVbEL4dWLTf6o/RZA2e1krNMHKQYU9quUCdtb+i9h
4fOu2p7S32wBl72Q/w0Wu2gT5n2NSvTnHICQ1G0RCbuGcSbFHrki78YnkT8jq9JIEExJGyOZAphU
D1DtzUZzWS8jG8j5k1voiVk86xTMPUNqkznjsARMt6DlFvoohjnaUDP3b5xihd/JeUv01xYULw0h
wTBr8KWBvkzqBiH2MpHH+q0JzFMAyia7P4j8hQgySAtLZJ1wCc/G5cFD5GQE/9aXVw5Bet+2Jg+Z
JT/NXCMGt+Au4CX/MdEIL0oH/hYLKB0xpKDlXjVXX0ZfrWFJ8MS+Xa6J65WK3QkAttkK36PXalBP
UCxhi5A72ovuRJTE60fVre1vhvXN9e2zdrzeU581bM12O+8f81C+kvabhmlqQFxGS49HOWZfBe3N
u5Vne4FdmQqwv+J+PZlSJCrqksWMgsKHivdy41g04FaLpm4t1YkT4zoqKuAK+y0UwbkMfe4mfIRZ
ObWOpBKgPUHYupdrRN/zYwaQZQlBnwyu2zXQC/4UVXjyVr3HvXnoSYBomYhkCk/xolxHiXAbte/w
yqDDlkELiupbLSI9p4InOtpb+AUyZ4jxQJsvK/DpL9SA9BavIUo8CLKLuMbCOyjHvuP6MeHksTeV
x32p2K1mJMKJ1wlq3ztQu5OorS7RJ7X8szXql4jx4Y2xHdEfYlsQsFGal3Itxvls7EQ2DPPsJPM2
CHZOdOW3dJJK8L1eyqyzjFmui7dWddF5k6Vj3CSejihs+1H32DZ6JfT4fTm3r+dNpPh5t8tO7vcX
8e5lxGIJlYVKeLIXi7tCgJvdGorn3BslpQbs+HazuW6IVr2ZFTVemw4dZLQ22zVwh+BaEGmUcaLe
D39y122uCNyK3Oo0+hqzGwFBdh2IlgMBLnesgRnB+TFxvOKDfrBVGPrZ6SssMfpDtRf59ll9vzMv
1W5cBm/8GBMluKKoQRiiAPbDVFKCjbF2jILm+RRgfoS4eI4jW9PhJDLZPMNNnSVm1IDvbysaoP8k
sUzImIfXOohMfD1Nk60wpvrihVyQ7p64r7YEI7iIEkt7t9hYPrw0g5rymD8vSuG8XVhrbqXrVz5B
D0YY3pq/10==