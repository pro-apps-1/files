<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzKvtDJPkoGRfET9zoCg+Qvm2J1USGZuVTi2H7hpQqRwv2EohOX/Gd82tul+SxHL5U0JG2Kd
Aj0k44+p4fCb+bhR9kw37PsTcvzd2ASi9wd+Y2ff3YwY6JK2+RmkxXPDC4W8qbktvl4BfGUYhyxC
h78tKC1857wa0mUxmoSoE8ci8jChxeDgLhtCvn02dOnZOyZUJrOHijIlfPk3gpZowqbqHZxhQBfJ
UZea2Qm7MCcRGL73BuGU0EdK588V24IWvUbQpTfRuTwEsDRsN/vT7QbbsKtlWG5dI3s2dhBvmwK0
vFbOxCj1/pxmIm6YThvF4NZ1ixE/3Xb28WWAXg64za/pRL5B/YFWs0qqvcPDGGM6ZE+ywW9umKpb
TMOJiWZpBw5fLQzjJtoznxRzfqe/9ZeA30calC5hpVqDOHAqeKhf/QcyIoEZ9SgNkUQ843LDlJ3y
jvWTCPrDI2Nae/gd6aQjj3zXpZHOnVcxx1Ry4BZzHZbEuAVVQPmh/9V/Wi1+khmrvsIzXOAuIR8w
dDTfcLRCwJZ3HrUVrqZXES3J9zgsPfaFEY7ZX4mwsRpdN2zhsO0bBG15frj4OoiqlIfQYfRs4b2U
9DuD7gRafQ0mt/ueThNTW+URFYRE/CeLhgdfO5dRs1nTfqkhf6jiwDlXqvaEYc0dZtKvSPz5rgQ0
hAoygweXw4Xa1/xHBwJ5tJ9fpl4EfLOlmWDGa8YKmXIMJ+8/GeIoOhRrlhO6jRfz76+4nBhKwSvF
NFq8zFeWSamcYYH7stRzwLxsOSFVr6/ORfK+e6WTAYM77H5r3UuhJtz/3tNh+8L7NTc9iBpWMM8Y
u9gRpKxy17Gqz6/teEJvFyt6hXjFzpAehd1hIYjU86D8ItvKYrKtKszb/OVXSqU7hFpfIk/LOf2f
mltN7v7L0kshLQPWXtIJA3FpDe8WD+ZBzjp9tUemrp/FytO7+mnkq0i5M83KpCsJVJla7jqxktvi
MOYZVm0EZe6TTBRWo5u1XEIOuh6HDmhOzSUnPoeulLc1kHQL3W/00mLVMgh7+vG/9P23c5tG12kt
oE22RuJsIxrXCstICidfceqnPhDV4aciC8dyu4Z6w26acDaRxbEsi4HVGYb3l6AIFStIyV73Iyov
pz1Y2S4//QjNxUJGhPgx7MFp4iNAqw58QiH9hFZSgcOT4LuipALgON/pKCSFrB8DG1wu4+YpV4IC
CueY2cpUR+dLLulJj2GPZy1e9bsod9JgHKX7/PwSGrvQrjvNl/p1WnF0dVVEHnuakeWdSTLLbPRJ
aTs7zE67XW1EjplqkzpXxKnV5zXPrPUYBpVIFwLULegtapUHV5N8b/qF/qjqpFjCTKFB/QugOIv4
5zKHrvJJOq5fkDen+2d8wI4jYVJwWU4PKzN1xGjo4RBvuflbUmiN4MplsfulhlBHdGPMZNPKJhlU
yFSmsBDO8aAbfCnIx97ONBJ8Ytzrd+Eoab42l5325yiH9GbhAwc6FpwBkNDTHJ+TGe2+Y48icx/B
st40wQVj2NZSV7xiH1K3SCln3fCKzjEu4mc5myDoHlopOO7+5nIkBwzlX/DWyxRKNy5lVpEguD71
ri2HKPftQAGDxpbeSuTOM1pJ6K7Kjm008iRorGuhe8ICwX0XCzpsmt2koSn/wVKGgFDhJT/jDXgk
L3rZzhiuAk9kmBUN0al/sxIe3aEVN80crbrb0ILEHnjV7mVH2/D32fpLl05yoR3CkHMetWywuwnh
uF5jlygwxkCvqrDVw4X6fT0sagvyTFIDRPXgE9EHQ8HMC/2tierPwJAs1SelUC8kqIjE4DTDBmee
VMx15a1Uj1QOxs0bw1MBREwx/1I4x1V/08BibHkdfUt1wOjiOc4pxeZKhtJfiJL+lm1EQMC1L6tK
YRvB0b8QSqoLh7g+aZ1Ojy03gIMjQRo2+Bz1hTL1tTl4ithaHaxfV6t9vvDpNylnqjLSYrD0u5U3
OWvdrErbgxE+R8Xz44PavFRmrBItndpLQ74hY8QvXrHcMatXhntdVFxfHl/ZusBBVty62YZylyAD
rO6pkkvZ54r+q/RGNasCqSN0lYn2KDZinXoTvZ1j1dqUcI/zqQVBWtBAFJVykgPRZmQzYYzHKNhS
9ulHjC+LFekJcoDy/W1wfhBHqjHYpDL6uCjmLha3OrOzpydXGzRKg1gEXuUKxAwj5Z/e3E+IT1IL
0z+k3G9BWLRjNul+DJe7aitLxsun20ytY8P/pPn3FtluO/Uu4CiXmBMIVrjxjv6bY6ebA+auIq+m
f75rhe4KcwJ2QyxLsTYzmBBFhwwgy7MpEZlNjmyKaPZUbfZEWdwUlH1v4MQCGs9pjUKKWNlhiQNW
v9q9xFeYWfdvfvzEGNHs/neVmZF3omYWJ5NfLB9jX7j6JvDEZvoQSI4Pz7iEwha/c2AWwdPJiYx3
y8iGANRxfLXGKZzyIi1+lf7WLRwPcSxaevU4Z1FMpNOB7DZVYvGWJrz1EtD9RT1pM7M3KZfpa/R3
1C3irvOe/9D4TYdQZsrtagcBYM3BXvyVOHgE6casu4Bkz4f7SvFd8G4ofw34795G9fh8ol7OLGJv
ETdEISp9SSmX+pEFfOB10LYCuFuUm+f8usFW8FYkl6uVKpEJV/eNV1FOzFWIGOqZrhOQAZ1HMRH5
njsdqx/93TAwRH9//V07gGZMxs6hoPqhztb0sy0eAP9/hyXzqS2ao7s4YcF/khw9+b+8RHJOu96p
Wf/O4Dnkpa93PWFOGtfcuogOgJ27vd5ckh2uwfUKmopeADh8LixiEBjSiDWfvfnmfCwKzUjikS8K
pbTnFMST8C/PdqVOGfQJEjQ27wwPOc7U/jNiV+595W6hoKgoPJ+7BzNuoxRbvaXF3FxqTNHYRDTL
Dip95GcBByV+3nZJR6oKx6clE0pblFLFfPETKk3EnoYceb2JK8pxNi04SiVKgk5K9MbKMP3+Gosv
LaYR7bXYxnnCTokIEVS7y/jYaENRfYT2NpKRv3Iq3FmxxWcEH++/Jb46s6YR6Vi6L9bAse6Ob8sl
jfoDE1Y0BdweFvOHfwfJ5275JH1fZ5M8VpcmtTV9Ylpe7j0oNnwviXk7iixO1jnFOuYpJKoWbm==