<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpV1IlQ5Sa/wK1/VrPO6g4c7jHdQM9t0hgIuujGZWZM1Apaws7ynmVBujoBDHFFIkp+nETiU
5beedR3MIr4135M8++z08q9O9yzhS7VxOFAcdfasd50qOGW9ZEIBWNE15Cc3q1/FAkhGExhe6Gn/
tWk7TcZ5nGBKNt58rB0iZxz2DL+Ng2DCQf6PLU4i2xQAfe2Cdz6iG4ti9tFAplJRq3iVNTnEYmFE
d79G6/iu0vmTjLyUysDtce9Y619FS5GBC2YFwNsmmIHe1LU3zR5LSrpbjO9chJjB+O8V07YquWTw
uijm0V+GM3Fz3UWFBuS/8gymrX8D9c4r8bGv/2IS3+4LfjNAtYzcHHf/VRNYTqdEJZjr/lENHU8B
lf2i6+mMf0RpRgGnrRptgnPdQKlq1veHhLEr0nfLQoGQ11NFSL+attwofQDqMzPnytkaxbX+51OW
aFBNOgj1Plj724q711Uf77aCSeeDdyjD1uOaWHEbR5DWf0Ktn2sg6QuNonEIROwT75lEC94vHyXi
O9fuqxxkO8G3GbeVCuM7H2q2/8ZpbdqlSrbDzayRd9o4YS/w91pFx/jdlGfD32cvp2d20rvX/5kH
5TdWmm4tB4cl+UTtuiwIgS3j2CHRWF3GvPAVgeWZu2oj2rJ/R2brnKAhOLjwEkwx6+hausxt7Yvw
nQqQe83rA7PfAk7OsHM/MCFzwJLwd4Nt0u8DKjuf7aGbsHUcR1b4NHHFNdSTmWoZIaDqjh8Mz+rr
SyV9X2avvOTKvXIjTGllD00cX1ihyVJY1PiVhvwT2dCdqhVtXsgsxhKkheQ4Cx6cjr3l2kwXzZWw
KeDeqhV6JQg40GyQ2jTcDqGVg92gc00t3liY/qpFbwwABmuou+2p/OrRY9RtriGcSKotbtZx11SB
3TfRkdoosKqo96z9W4ZaSwswd1bFmdDH+A9C/Fqg4fdRUoxuzPZyuEaCWtQjl9sUnwODD4TqQbMJ
UH/Mjy/PCyJ7jydTHs3Bx8spqJSDTydKsV70UiPV6sfMB7XOsu62JSHFRI7PjYno+xaH4VGoeWB5
RxVIUONJJ9zLSiLvyV0U59oIDByXYzGDKiU+AFo2k1Tmcu4N19Dq2trp2/g0eyhUi1f8xOZ0NDZm
lmJjHgVnKWP26YnxaVg+7CXetNYGEzcNCTS74b3g9Mosa2PrFrjyfBuRcsjh/pS5b2riiYaIw71m
TKYolajf51eIPfsMbXfktiTJ3sc1J/tCza2ePdv05MzwaxPVEYPife8vJUNhmsYfG1rA3dJhjvMU
M3Wvd0bL4ZyO/BTv97Hsf+INGo5Nt26htjNtIbuv/HBcUH37wde59g9ZivLgAPkpb4L6o0oMtrI2
ArAGSfWm3u1uKJ5vLcd7A/jOuJDMXIKQbh61RWzhHuq5492UeX3/uyqM9dYCYaoK/9Sski6Jz0zh
YrTooHtmPWqw4DszjVh5yDQOa6NyGWf5qWSRTscw+QV9ZRxa0XYFllE3IFZt57TfGZR974lDSNkD
HfF9idsR3fajCRTXTRCeFMSnguh+SSZ1BoQ84PfzLImBAWuNqCBuXSa4t/flJb9AS0r7KbarHKnS
PnTQUPht544EzCR+2OJAAf9TySVl6YLzvwB9arKXx3OxUa6GTi46MD7Ue1gow2cKJXKt9cKMPKMk
f2ZH4fsM2n2LvnxlXQk7R5fnt3zzK+o/oRRT8tF4+MgxS8sJVK+WAIyMDXq8dwvk4lSDfNnp/SR8
7C60mXGZ55yJkO/3fAHyJFvMXBCH9qxR+XBQMhSdmkpzt2vMfPLfOzks9hZtZBqAhWSsMV1xjQXB
cTs2KTi8SAr/se3KPgsJ9zMQi6+DYa0rZMvAtogg55/CLKAqh92inkYVfH958HwBEJYYbFqXW2Cr
OJTUIQFBCUpXx9z8nccfNfChcI8jFqRyXFzqmGFAiD7CLlQsPkq7SikU4mMh1WcyWT4iQ0VWUuA/
7/Q/9cOptKdkTvGNDaHxyt3Hb/T0bO/cuxBIYSGwbjP9IUTOOSZ4cdcJb33VCRLl8//fDagWx51N
p/QCoQ1HVmghJIW9OJzyP0N2GzoiJYdV/MNc73K+8Bq7ZbQyfpZLhT8/EnJPSAZ2Y/jy25jbpUDT
NdYqnkXjoXNiiMeEG2i3Pzb21r/NgKJdLqDEtRS/1S9Ueej+UtUjie024aF0svj7VS4l9zJdK9gw
h0xcd2qEgRFKvIQce2wYRVNS/aAy7mElK9aJHfPVPtGOxlf9kFbBDM9gioDKVBGKsZyRuLd3E8qE
GVFM3OJJBWjjOPDN2UVwZ8HN5ggz5mN0WXEdoe08JEspJX0tAJsedRdUu5fPc6LKUYxZ0m7wCbYL
JNv/0tPN/8L8i1LK1U5uuk7XDzLd//W6bLVFpDBC3mSmclgZ/kOMcN4H9jFiY4I4BS0Foad2AzG+
baBheYfL97PD9HoCDTMTAZFaRGJww520s/R9l5N0J9TC5UC85DtFg4AhXNsy90Jd++5vp4sAyFfp
tscVeSnI9jFRAbCalwTn8zZhLNLlOcZ3ySK1Mtr2WhAh09O+D9kBYHAkU+tCVrUpz6Hs3nBc1wQc
1npubovzKvsryxuzzoslG+c6er2gGGtSwypVabV8lUDiWQRfVLmfiqVeqDhxE+cdhEU5EE/cakGT
3XUKMCzAXJST/T1FpgcSWMP9HzNh42J6vVcAZvwfrgtbpBfU2/aHXKtxheYt1ezUJHB/twzArrJE
zNNvH/ufA485B+ylYsanGcnYtKv+l5zH99Im6wATqQssGD+xZoKROxtT+db+qvZCNaHjPA9K62uF
aHw4nps06PAjOZ9/B6l4u/wyTx6Nwa4M4VupQ+hmR3hDtgkjSAxOv7O6V8UCVGX/npeWX016Gwt/
4O9itbg19z+oWMBPdHyCjEDWSFuXTPHE80TQl346H/1O3ndNASpoVsP2eszqOiBnod52+KZdxaam
8vkaTDlAdCllQn3DiaShCU5TJ5KUyB+CVdJiV0JMSctwPgUruqwgGaOHttIWtemxOL0ZeKqknDFs
wbLy7MSzZOHXAgSqY3SM1Jbs5Q6g5YLAmbQwRDx23ijeEr+olqVXGc0n6wVGFYBZY+dSgFWYsgMw
1OzgekqHiAe=