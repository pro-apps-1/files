<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn53T7N++KnxXwNXLYXrWq+mmRDdv4JV+/UKQqEWzcA4h1eaMlGDbCAlpT3xbTpzH5N0Qqy1
PJxBzKaYqBsxDTiPjviZAmBH9EbiEEIPf5QBTiI3+flcR62y5sPyV4ajd+EdSxqxcgptAqJLQO+C
pVMyhFI6/NhrYqmhJ32s50CzXJjRZu887mMzWWcxzRdRFqRQDBgbxrY/JipLMdDRxXwjqJuIspLu
m2nuxuL6aeuZgbTq7o7WbBabmE9h9MCW7jq3f9Q0jGZOLI4Bt9+YPfU4E1NmQvfrhgwVA4MjzvNB
4vvg2LY0Imd8P+XVvXlWazvUlxDQ/+MgbhPd4N/zwjodRbVq5z3S4Ls+5f4CbXzek7ySG5ZPPzCN
PLVrDBs2q7frMZrtRKsrxH0PvOpoSiB0r/V8Tgjh68ATCDLYYTnffXltlKzU+k+gElvEWlLP0Xgc
2Os/DQDpD2cuHWQszi267vof0hZ8155VZwS+MLqwdcnLxV4t5MEUUFTafgDM9FtSfb2AKzbZsVSV
evsAP8tm2XeMh31fyh2l+gn3a1uQY7SImkaYemU40Lp649UCHZuQS06XCS831I29PSMoTwG2Fqls
uuyh1pRsyq4Nu9afs/GdGInAYzkWtRlmB9t3AjCcP/DkRgXT2qIcUdT0mxWuNHW1dLeJypExbbN8
Jm2qZx7ijk+HsnEfayFn0GgXoTV3MopxHxk+dEdow7Xz2j+krd/DLO0MMPsL+K+TCt7+Q08uiVtT
hBZA2aoVdWqrngTa7jZHVh5E47P8GOKFmc8ShqdUq4BrWsn4txmzoHQmC8sJXXPmE6wSY+nu7ced
g1Jk7+sffyfXHgUNLDQWbp3XzMU5mQSFS0eFpl0QTuIodNFkYBlvpwewESjuDAdi9nh0oKki3w/9
+8nqb2Mp3b/gQGzEi49Jg9ChxwhcQ0rtCD58+hQCBeLPywp2EQWJX7Z1VX0tKzABj004Ichrtqd1
TDsgeZzBwLt4263/tLFwRk3VQOAqRt8JkPbA/+Vt+QE7Rg5Us8syBgFmufRFpH2nnIL3b4WiNxQc
LTcyqYo3Eo0cLbj/OjNBTQfC8h2r9W+3IqKkOPoq0RFhyyHQ2kSIv0sAL/Jdz8YZqQYTKgmZy7IP
JR2JrrLff+qSnWCuz74QLuLK/fFzpFGtO8JNAm3hTHpieklss3UF9j7vo0DziEYKq0rb1W2JbeCc
vHaOshT45DYUph9DXMhGsh6oKlaKRHQZDSPDyK94zG3csOw0OzjRI03wx6X1j6zKOGgZnvwGHz/X
RB58OT8Qq6VbUxpumVi4e6JX4J8ppmI6tAiemqb6YLKjtkKTHly9D1B4nxyTtvKl1K9mYuoGKkd5
wiMKzGtinJ5Pes5K3EASh6XlOzdA7R7tBG9uw4ljgI/zCMqofc2TrRSSODmlAOGsM9z8VjoVxP0T
vtzK9UKsP5cOpgUl2jQ80qHqUJXTPiVDAjXqJFuEN7QSOWnzuVE/UuiJtOrlXCgG8G+jOX8KAwgW
o+Ce0ha8zCjM08XhMAjBhuKa7PhU0TC2zhOVcCfa30oQYrh2AeAGEKahWaCLPjB1V0PxY4Z+KSdf
ZNcOOxZd0EwI6iJbf8SGed6y3u+5OWXtlj95/6ZqvLp+uvsw1BBFGCcCDn+RPIrOIMcy1P0B+ZDW
rk3qN//d+wWGPQCoEJC6GaPbFnDTtFaz0ZdFvLoLZpU3Q3wK9lXXUK5y86HyI8hhp0hJ1uExQW/R
hMg5HjBuCwdhi0YDs5AuWQwuEoCB/VkK4eP013lfvjGv8MFXUjMS7G7cKJzq/i7NGpf+fqddOcSx
50vH8ORTG+rekxV1kXjGtf8Wplq3LESqBgifvNPdQuG2Ae1hP3Wme2REnf4eldHabJ/5DA0mSTeT
XCuEpyJtS8gLrxQGNFU5LUtyivUlkxIj663GuTFxPUa8WalZ0bGEQEsnEf3Dz20rv2UWAlcvGrUu
Ym7Z9rPsi+lKHsSEgN7SfEht65hKoOydawdb+uxDZz+3FGVYIFmzbFTmMKBVrd3JdIh/HUS0pxS6
w4enOSfLBEY3aqnqD6LOU4QkPwPmKuhtU7TKbeqfebXSwtGUlqLvh/cuXKEYjI+oHxZNxtvepCTN
rpO1P51/0nMMIeAJ4o3CtwPOzo4L5MpS6ZERaDLwDmVXM3J2jsn6Mlzy+OwmSVBk4driS1R5uxA9
RJMsbi3ykWKHPdbGWjhNpmswwRGdlk68CkwE5880C5If5T3nvJjgQStCaW/1gVZucGfda9gQDZyB
6ktzv0qZ4EEUv01Mh95FjpjmTwgGEAmYVaSM4P8JLOrbv3EqCbHW95D+ZyXdy4H7cFygPU015mTQ
FpgY9FyMPykGTiiPskQHmArm1DCu0581vyHMPrfMX7ID4/zMq4jUNCwIKs6ihZYgHTp2MbV1rxik
Gmon7ssGspKMRvz1q/e8GrXq3mg0+pWXY5yDa1FoN+OTjReibo/2FMZ3vyHKyONMWA0UgflfPmLl
iYU6xw+iYOXR23Is5qkleQC4/dn1FGqsmRY1/zezx8lsaDoDO+v7PYT38JxPe+lMabT+FyiLfhRX
uWoxGWFleVemZehmfl2+g0mp6cw6+sNahzuWYE07dX97D4gpJ/eP4Bd05oCDrieIo3rugP7vuD2q
6fSqFOKp8E12PR2lU6ma7/CCSPPsoL708yJwrekgbzT9Cbh1oKOoStP5XRbMx+fHkE22dhfH0RX7
/pishdZEo1KFmb3nyk0QTBfCJTrLU7ggy+3JUiLykfruoGdqZOD7uE4J0mldOnUbNAMwmOAGl7+o
4ZTUrDQr32wZKEugEpHtjEj9dxglvSv451H2VNC0OsJRtCxpDWWMLiZ0RgRz8pKmE9H2Z5mTJHM9
g/+WQZXpGz6Roksi4WXem0c/YSt5Q2p14ERIw48Ycz+6U0KVjq9flwMgT8nVUyy8xS+WW6bYRl9U
77iJuT4jthfrrndrFNyiRcSYkii5x0TVxRg7kJ5bN0z5Ibp4lCOjuMCHOzw0uxgV+LlRrH1o4kx0
2K/0cpLmX7RwfHYtEsVhztgVulYLEOhZNMWm23OTgffrXAt+sWK2m1k3q98J3E9uQk9aqC2ZbWCt
btEM3d6rAqHNLzvu8idT6wY/1476bcBk+/XMImVadaB+YBgQep1uDFLlJG7uQh8u144Trr2IlawS
B2FNFTLAqF6kb0R/f5iBjQlyfO9DGSedV1YO1W1pOf/Zd975X/38syODiguzNrZLYGSIQi8e6C3w
QwFfK+ecfmac5cHh0TKZHhESRsj3M/TGZ6P13uJa0fd3BkE7YWMFdh/ihdNqgegKnIDvbE5aA8iU
mHTrBH1t2KkLK6FKi+8SaP4K1YiDdxEEN5jKcRYo5aI9lia5q6pC1rZX/xOi90crIdHpEFbHHt3c
LStQmxRnV/yTLX6ImHECWdnvCfSvvz9BEwE/2idpqKuOXv/gmk60FS1uoSf5jPY7sATS5ZxxctDo
PwTp2PbhmhPfR8NuaY4Ihura0ZuZR/m3KfgX2/n5AsncHvbnXiGliMMn0P6v/abh1t5vIhmp6Xhv
UAUMRjAoWb8dxC9a/KSzoWWca+rQ6L26qjOntCn96wUE+NOWJFPz7pQGaSFGJzfto5YAKavG0vVK
sNeYC19XBb4Oe2gUS79EHiIHlm/u780/I9PXd9PNOM1KaOJaq21rUORCDIT+Yu5RZL2ppFob9GGN
ps0Z0pCYi+wTZfhnfSeaBQsowREAq2JCqzbouIhRaYAENdGV8IUzSAiUYKf3N4Owaf8t0Ztc9lDM
k8nv1UOVcDWWVJJcvv+F0DraKnjWa8yTPkwPczxhqCjVQwz6EV4DMqo9i5sSlrFCUhAIy8NmO85E
fFrD4CTHfIu1NcFqteGWB+IHTrsAoK3XuKV23nlDVfzbCYRVjQHXOnhQsF02h8r90sgXvTjlkm9J
4F2XHDutMe2WPP86wG+jWSmFtEkU4x1h6ytsH0pBYUvtBFfldTDVZXltgDT4guOVkgKYl9hWHswd
EK2yB+uziWfiSOvmpspVhNgBpQqDQmqw5bqF4obDEH6mTTAE9hZyk2uLONy5NW8jT/doA8F+wt9j
he3WXr6HndywbY/ejiWX9oMMk+gFDiRIn5xvxyYbVt/Q8GQK3LjCtraQgjRoFQrGe+FzRYUmyjOp
OKAGhUsz7Eg0tiOXuHpZvIIkB2xdEIIG+fHWpUy9fU1Ed4fmApzOztgGDnJGsmt0FjZD47C8KNqk
Ggcm34MbgDNfuaERgkwNpraechORY70W5dCwKQUo4h9phmnNgs+LtRsTeA6MD8/C0rs0ZWpdUl8j
yCJR94X8+Maj0RvQmIZ1iEZKGwtaHzcrwL3KDEFVprvew5pXXIBt942jrm0lAYjIQlDfdqycqx7i
yLbOdNZs8HXilYHuoznWfO+1LXODUCscx5galxXXrMfAwGqpoqLLZkgJP1y2J8s2F/DFVDVpMORx
zDVTAtmw5Dc2jLqhhxkA6FvDX2rqtpiiL4FZMUE+flHH75OArEq6quhJkhw1sbYEz3u1gCgAQIfp
kCtEH+17VbT2/f7qhomfG/QtqSTEzYd5axk7QmevpwEnqWTIjPBkgeePPQAKrvVV7NAaERv15zbe
cW/sICh/vaHzHpA9G57tto+kxy33rTD0Mjp2vlwgwi6irtM8JT2qpH5MkGLwn7a6m/zUTUtNs0jG
0TgmKb0CRj2OqVRFBbRj3tTV0FNaZJL795OPxeF/Svb593ZcaNBqW8KTxyKv0CoGn6y5u8lFP5xZ
LZsnZPP2Gi3j/B8gf4HkqRbN/udLLThP9zQPduUn/HhaeCWF+e6P5/KoAvvQbT91BLJBDMzaMm7u
aFLis+q78Sn5ZFM984T+9HATGuh6Cd4ucQUw8ZtAVyze1TsKxsoIpfGEtjJ1+vzYO6pu+58DxDRb
Mqm1dss1EfaRN3vOP7GlzLIlCYwv4EwVcNH9AcQ9Mjo+XW24mJ3sp+Pv4GZZKjRm9E//wdzVxPcP
DJu3Zt+9JPvY5sPYDjYB1YHDYhOTdW7jI+86GjZc8NWwcV/b4e5BtV3aHMKujQsPX9o8cFa8tCIG
JqKcWFjF/2VHEBy4wAsCp1f5q1WUtIGXTc1aQmvyoYF45kgDg/vFHkT3BiCu5K7/MSr6Iba4PSeG
Vv0x2tl2uXrqaI2Mdscg9h5FdcT1c6CgEjnaKJxoyxyLYUxm+4MNyyuKJebUDCfAK9HYjWF/z+hf
k7OartXIo4Cecf4v6oX/HVEgS/K0ZgG3SEzG/oeZKyg+qZrwQ2s+JGVMYh/SgU62oNbcQHl7yl8t
v0Iod+SGujndpo90FJJNAmYPx90dr3Hm509YOaVBg05+n7pMrb0g5/tMWV6NJfH0lo3oTjINs9iC
DHM7KrGYW1ObKx2q4LJNyDADHjOG9m0UMRJA6j1HeT2dKlvOMfF2o/DR3sLAsH5w2gh1CMLDi3VM
D8avIGkbrfteWn2EbAJ2uxgzJPvENhg+YIWPyYLjbsIp++2E3HvzK7+ch3ykkOtgMPUad6C3q3ie
mbvJsJRxH0AH9XvqmWnzhVS+qEV2WO70RtmiTQbvZSZNDPNwHVT7IQSq4u3smMs3XEMN9hSKSaHN
Z2vCk+DhzsjcZ5qOzK5UlkBGPBCYq0JvLiR5gCiU2hsiAe2/tiUO0zgK67XffZqdaEvIfqzd3ab4
k9cb8MmRj8t+M1+2ea/yJ4MaMfpImHXl07atZRdXAbQqA6qk2uXXYJRmcCu4GF+wtDbQlrK0AyyM
GfmG999p4gklm7PHROp2/dspU9BHrY2FJqtD+aBC0J18o6l3taH1QWGtYj08jCyirilYgmeY/yTQ
XoXb6R3IXs2WSP4pfQlAG4B+QdItQQ0soeEsstF+aIcEjD1OEHBi2oygnxqfpinExYPRf3Lu8EwV
TRb4YJOODYigp5ggvqqFWCmMODYAOTecpsbzTbCrV6mAZfQMZ+CWRs9usQns9xxMSS9Fh1vtITjJ
Z0akPPh2WscQzRJO+vEmVA2uP/00gxjJoXVGNAoFIUejj8PdaUs5tvdhUhgcNa89HoKLXW1E/Nka
VNa164Cx0k8sAVC+nNDo5hWWt+VYEzSW3dsBt9JmfnF/0PNmtNDfxDWBv49lvBDHuv3F3zL5jLxw
60/dVEctu5z63tVQH2iZe2QDmtyWzrzOCNswfynlZ5I0cWxBrqYjZmlZGIFLGnZ8VW1+veoVr2+p
KnKuIci1swurPLMTMNGr7Qf5Qr8d6exzIo0eqtrVuxWxjA45ZCtUy2d7qUTBYQOiLcoO/17aFS81
vcqChaItUFbmDg9G9O4p48DjoVEllbCflz9Npau0bibgDDNZo3LMqTKXxK6J3AwSf/Qg7MofujdV
aPInRmlKMA2sqp+XErsQW+iewvB2VefWYbZUS7tK4ff0mjtOTCKq5QvbdQb0HA1NZLU1mIdiw2IE
v1iZK2ONuAbsyrtVpArqTmO1gU1raLnGwEeWlwg7GCG873ZFn+doN8mv+ymt2quVG0L8DnLZLYXP
SEY1A8ajcvbE39Ro1K/38oIZpNh2XOXisGcQwxXhtNEpNEXfIoacu+GLu9lT9SuqIRQqyyJavsdY
naZqmvcS8ToY8L2x7mXnBZ7ID0S/ewdBnMMq2NvH/bOXyyJYyrI/heM3oIJq9m5RhCPQWb38fCWZ
v2dSvTczoX+sIvpLjVfc2yoS9r60wNzNcukGoCu37tSk/YmBbBtGFTdSy+n5nlYtUk0FYz0/+bUW
Fqfn/hITeTc1fiHfL2tDYQRfBZNbJ8xgICkKsf/TeK01idz2SwQI3hm/yDqWlxF7u1feA76/0Dbp
hl+kJ08sa2fT2SS+3PDLEAS05vrmGmpIv/75Abi9cLniHHCa/njgBsNgO92RcZMmlC3JYhLCBFdI
SYDQxCjXuGNXqGz0yBRwAMLdFehqivulrWiBSFI/pF5grmxWBH9xJyyeJM4uBjitu1qXRptTWBnU
KiiZhbR4AeJvEZrqVdY063DiYJ5URJRpdiJJnc8JBuIL1cHUhAZBKLG0WqTo0je9Nvhvkedr00X4
fBZ249eUDVxh6Jb42GDNnHOfZggYPN7lkqh3Al+KEJOgXfdpVBoK8Ot7apY4AcYWngBnDp+0McAL
m1jnNW5rnLVF449Zw4pCG/0KIXON/TyuTSF5eZfV/kI82hnlnwMGMtL4Zu769IKuYFAUahRaup5c
YH574OL++tmrw+Ucf1qGWWc4DpJ6D2YQM59/VFITmQe5YM755iM2LIYqyZSNZueH9angq2fm8aFb
KE6dNkMSEb1ZM1IjV2sRbT2l42pwHjGbkSiieTHyHDtbS8agaGZ7MMrn1D0TlfC0nI3BMkNNFN7K
f3wzO/r70P+8s1N0a0lmytCiqMy7KOoiCq5Wh+mg5ks1negJMa9tbCnayKm+9UGu3vQwaDjkPNq3
3DsqJVev4qWOnNWJ3Vj7/Iqw9d8D6YMOvuun48NZh3I0bGEHojVRz57++b0m/9R4Ijwbmr0wDjFy
5qRYSWEpAkUYv5WuhjEdusMD17ksJZyVYr9lL2d3vNjBR5aTsjcWpUXZDH5mB3rVl2nYn+qiUqMZ
iYjLD9NBIpqjG9d0vjTDWFPyuLJsXEArIQT+pw2/C2PN2PLqLl4qt8xlKEVeuxUU9N2KCayd72WH
fFW4RI3QaWaNh8G2YrelhusVX5x9Vy2Uft9qVLC1mWEgzB6nZpu2ESAvYBGcXevE/Qo/kkgUGpIS
axR+gSyfBnDHE6VHTWwERFQvexkwvdrbxeLEasfiqT8mZHnROno8P5/SZYHQpR6sul5cqLB25+Fc
JyWUaOjBjhe0GquZe3L7z/ki178nUaLS6uCP5dC/JipjoNAcpsYTjRkigtsD6GTyIkGA+Y/B2i+Y
z40tm2xjl0gBNQnOzjm/VWUW72P4xWlZ/n/zkV9fPCaDK4GCNM1Yv9q76cY9W1jPwkSDcQaZgS5o
g+xPistLnQ5a5Fb7sTUkLx+miyOxw72bUrkW1f5t2NwkwXBrB4iesuWpqJio1xY0J7DiPNynxpUH
ZrIPCw6C715F+E7gQ42Gk+ztcXr+T0hbuHY+LSJGafJkQ2G+DYQyLKzGBXrc+U0Tf48S2dz5pKbC
pXWIY4vgtRiZiwWxTGnYRGXEwXV5+R96HshTdPDowJfhc4ksmRIDYxGcHHUcIAZqAWF6cyeNdMaZ
Zi4OsrOrh/jcYYOwjkhxUGEWpabPZpjIr+AVOj8SfLk4gJyDP+OsRm1Rp4V8V4qQ3f+4H0Bqs7x/
XirNLMh40hXJn5cC1uxXeedCAjpLw5oO+dGCFNEFsUOjnq3lQLZmuoFvwXogtrbkaQJZ8Abg1QIm
GJVgxiupAH78hSwU5H4EwDapedUncrJ1w3Vawn5gwlJ3lj53wcc+hqYTTPSfIFwy8IUadty22Bwg
SMRWBzaiti118FoMzUEtBz/61AmlO3yGAPYJNDXsnAZ01PIE/aWh4dON0kyuyQ67hMB371nke6jZ
s8o8KSJxTKsx1mzj2LUXYm4iz+y+4QkP6B/dO+2nz6JasawBlK1KKtolr+qSdcD0x6atz4ndTLP3
u/nn31gXmbUC4bnFCjdbhbC8G7vYUEMSVLsQC/+WyPOAVyRgmNt6tp5Q4X6CnLGMiFIDpNgN+bcs
aWJg/QCcrWGVt4rI+fgIIbBbFrXpaTJ7ai9woKFVWFYcv+Y/oclgFaoLy3g5U/qU2e06Q5etZr31
MvHO9nU+llkPMKtHPd6ddiewMVMiGfPpbXCqHAoZsUEdH0WtpTAVOVnGc/pEWdXQdzbHhu7ERQQw
Clq1qtVUdIUDakzdY0w0eQRo30/x2kgWl+Y5WpTHr6+Ap80rh83QIWoVKiSqq7tv2VsmqtPnlzj9
um6cr3f6pSmKG942Jl+ijqLuO+eXXidZhGjPD84FqECekRzn66gWRCaezMbakKAlXY7chEwuQKDr
P8vvYx5suLYMFQBkrLsaLRgUbQ0n0b1NElyAbiusqSWmcDFmPzB2wZybQMtYiKC/E//hajBCaN23
rI/zQ7Jl9IpRpkU21+VJyMWon7p/lEDnZhmXEjYNsLZjKZQdq75NC1+0u26Ldq2QWrKDDZd400tl
GUQX44P0ClGFn6qlyRJ/SS/tNooeh+gGhMAz1rTalacgB7hOwFMSZzkKeA0pB4CZsyIxTRgxs6Hz
ESNfpVIvLoJC6nZvLzjWhVgaXQ6Jt+ik/F+/qdmJKptgCr84r/pO+qu97y9cHik7/qXzRmBpOid+
487/I2sCizNFcEkfhfdxV4kNf6Ym9SjlswNfRg7ruqTTh6UuHaMU28oI2MN9ZeKwDU86TnqAXDPk
Gg0z+e0FlhYNI4e2myveQQL/zLF9DI0NMcMqQHyL3OX1o7VH2jDjxP2pZVmEcwxqDuK04Ucx5wih
sVaVGPkMLnunskglXxTieGe+oa3KVA/U/ZtHFTXj5W6D+WoiPW46Nqau161Wrj2MOuVchAsAfDfi
5FkqE/wcO0oPnw1vGoM37tXOf5X1vofa2/zF2kSJXhFCO+JNg8hDMSbz0gDsN0iFIRf6wuXcj6WI
xeh5Ns82dOOnGQzAYX9v/s0vLjtHi/4gR+a3DpOcYm6/6eYQZnOotr0xZTQzTAriqSxv6fagafRI
4yRqZZhiT/zZngoXyfQjaHsKDe4xwxVy7uJEH1YMdoQn++6PFrMf/UcXUdAFsKdRVYHkowcwPEaT
xPMakUMNeR5k5NWudCpOLq52BaC3YTUSdh3cRlPXPbLGxsWKn8Ox1uV3Qsl+d37TKd3CGAvNT7TE
AxFm5FkWvnv1y9vGjLP0d4bhGn3/m76S+z34BWS68XP7bQF88FEu36/8i7IdADloMCPEka7PaVcT
rl6dpXNhwz9AH31ES4bbDKdcUkCJZIltRAkxSvkwRLmnwXI+vpsZlPtj04ktpfTdHB7OxvUjDZEt
/YxHl20T+8rVKgcem/+ccWBYPZ5DaOiCNpNN58Xnk4CrRqXB/yBqcsfntWf6kZtieNOF9CZxj+1s
QVH2vmqlNsYOLMFOdFovDBJkuq3iN1rbHdSrEEzIXNJtjHxsFLeIcnZA9GSNi/0p2Zs+WK5Z1ZkH
ZD6nsh0jTe07uJIS08rRdVkrVwB2ir3Ez9/xOaiOf7opPGybxe/2X+6itv4IzaD333+xNQk3Rs54
B9TPVhMwC2JmbSOVl2QjHR+Csc9wDoPZLGEMxaCdmKbBv8FwU1fCXTraadUGUzqHB0eQ4AO629Ox
U7kiuPnkB1KM967owUOoii6IeU1lse54ViGDhfIQGJrMhVMZGpITllnPbwJrDttpVFRjuwS6+2ui
cFM5IU8Wp7DeP7lkHr/MXzY+UdwpNFUikdt5f1DFugLyU1cxZwu9+fnMd6MCpVC5a4EwEXQzn6lt
dyJ8BPeCnvx8ZbIXuimKnxJYBgMu3cj/yq336u5qpRboLQ+javZSIbz1YJ0bT0pr7VhHcchBuGEJ
f4DH1ZhPxGCu+1oX2/mUOvfB33yVdwFlg3c5c8sIFuPgDjBwSMY96h41tRrgapeMwiLRR9OnJKSm
IS2yDaL2V1j60IWJ85yKhhN3kuctkfzMhkPVW/auHDgt35Sp+ix+Srwk86IA2uxtCV9YowbncuvU
7FASJ+l55ozRyIcaoBS4Nat/eVZlyoeBW5nvuieRjCdQxuBBJF9Ff8/o2l/7Nj+7I9NVE5grevGb
K1jCs8mM30PTeYAD/CpCMNz3jhiBQhlVCt06RgvlGK2N1yPDo0havSQK9sx100sYrKwYquQcsukV
5vX8ysp/IVoN9YxP9wwv7yaj0O8x6La5IxvfNPKLi0lOPqJy+tiwYAyA9CW4rQsrIdh3gLhl3ZEN
Cj0JugHJWOw0X1yXbso3u5oYyanevwrL8JKNZQWgt5EwS2aIy2kkyl9naVeD7aPvtMU8xA92/9g3
qCDsYU6WpV3sjFCPZfn0FU0E04wxlC64/untzXyVkQYznZU5rU9oyFlQKSkAMjMmYHMt+4k817v8
jhQt6SIX1VPtO8cy4qL2MWfPcGpZu0InhoX4xfg4+kp+1S6cnQN1d4ZT57FwMSczy1K6mTXsqyh/
eyhEMfOq7sQJn915Q8fBaRgXFyFLIPsWO2qFdQxA2crclVYOT+o7dZHsufnzKYX3YQqU6kaj