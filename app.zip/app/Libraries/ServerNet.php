<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtcQSDeY5aaUEtpb+KgmprNBUhHblCSKcxIuUUbFCcqfonyrKxQYg9KX3i0W0O2nCEuB2Q7P
hoCbWv27P5SUItiSRmUxLT0id5cIXhF3ZjSDmPdSZIhgQKmEWsz0jLbUS/I149ZbTYrmUoWEaDRS
rz0B3yL5X7KZFjh9mqHdByZVhYidjuAXo+w8Zo/Wt+GmP5RH7Q6g48Td/Q19Ra6pf0FEHWtu63q9
2S+WvQQoMQEV7WEOwfpMo0adiTKArBVBQ5yV7xeLASVpR/ki6MzQ9EJRHSXberosAc3hGSNR6EoZ
eKf8cCGZcdN2Pj6wrGFsnfm8pV/GfoDADzLXc+wANJ+E8DCu3O7SAchquXhVlhlPZ1+IoKB83Aqj
HLbBGk2WGxe2XFOURNFcxQ+p6CVgxmEQGn5yfioCvmM1gs/beqbf3O+xL1bcYtQEcxZWZhYpI85E
OIsxARgTAU3laApFnAc4Ov20y8yq/gRw7AZ18YPHHGe4JEoU6jVjbzyPY0LQPhU5BJwKQhJwOksz
BDBByk6Ps7SFQ1QXD1bIAHvqlssHJU8P7PM8MD2GZ3vapa0XJv8UTp7o9bWSirVtAF4puk2swiS3
uiPIgctn12d1tfDUn21xwJRYY1FLM3ziVuKxS/1Lvd7N+GB/kHiiYgpb2a8/omJxhdRZGuzcknBS
OfEUcAMpFoiph8swzL38Ct6R129wIlHCbkqZDZNTJaJ1b0d11+/aTvsNP27h8mNWs+b3YJcv6WqM
bPlPmOPv+aUCXr6yKdXyapgNj1ks2UQBpmmo78CbPR2C1acQBHSel7ib+H11M+AWKLMsbXorsvK7
lEhN4NqwsgLa4grgTekLRyH93TEJ10Q7TYC8L+QZZNMis0Fv9NKlTyCczXiOBed71LC1OqeGiYo5
n4z+Y9VJNBbZdYzpiS7izzGK6gcqNnIWpcpErnMqIEbXPdqHkUdllvjwlitgJeSbtogBsYuXyolo
u545+VERGjgQ608lGQc2Gr7472If8ocaTwkrayIK01uVIFRiflXMTPMdcBX5+ev9NrVWq/19SrOr
gJTda904cnSGdiNHeFcIIXgR8w7Q+4rnoQNLkhJFezpBG8D0HTKiQD5ZrxLivveBsx8OIYT3pncb
Ro5H435gfZfqqPJQGzbfgSwjrw3aUP8eIZIBkUjNttbECVEswISeNJtRXxWmtsI7W7lhQgbO0MT6
1b1T9pA3COF8qxKZXqdzjfkkQg1U7mUlcx/0NDOCsKiLVpBup0r2Alv8nOTDd2BrrNIZnO+WTuBy
VoJgntCfgON6/U2G9PpmsP+kw5tSMcdxf1qAGveBYWhcRnRK/2D549HdKn7VuUJVMhnh0AO2ay+5
9MTHmcyzaD+glkZxUplMvMlOaVFTa78zOsnyii2hraHYG1DB7WwLmLLcEDyCj+eggQfF33b3WHgU
+jWqrkWrg6gem+z8UCTPodkPi279Fnu45ThfXo52d7INKKLYKgNTAFL/GxpmgWTNVREHd0QwOW33
/fZhOt6MPUsJp5OPHM2NkKDJstI1f2b8H7ohFVQQMJzPp2P57VAPaHYbYwIK+xMImc7pzrWBSDKW
5zki8YKeYteabLK40vQNnUnnEkt01hdu7Plbpa47c9FOvzFtUk+9UFTbVm6Zb2/nB6/sllaMFzZm
DEqD0f7lY01zi8mJI4gTppWUuRW1/JGTptl+oq9ia2+lOKtS5uOgt69GiedfQTxycEqEHyFdlAKf
DjB61f//YRfjU/aY4Qy6Z9pW3z4KpRG1ugZvcAspys24ZxD0Q44gWGMaM7rIvE9WDhiItL3iWorn
TRfXPt2uhq3gZjXXc7lN5BMxCNLkgtVJMM18La2mgkC9mTxxD1CFTO3Jq7GL4sSEY1hqJpCS/geD
5+zWA5vbTqIKt4RcUvnCntge5xA99yOpuqGm4++YLTZd7PkwAZDR/RMvzM3GXFHIPKTRkacMp38L
fJ3mQmwPt+EKCC9xdKaSinzyfE5dkV6GjRw4v0C1t1ifIfU+RL7cKEVEoHsQyButBXAC9H5H5tZM
oNgGYUgYmyw6d6IMcuLv8ErMoyiDivDO1HqgP/sPwn42GvqmpWV4E8Zm40EASm49Njn1GcsBysL3
1gdp6CTuIjhHhhRL/WEnFuxaT49NjOFtXfvFCwXfpxTH90FOUvMSI8/p5h0Ecy7sYtj/bQGjWW0n
YWJPv2jTu6JcJSmnBqK0imOhOJiPvIYF3h4aGreAKY2PA3MnZGsjwj1kcEOcpnC6vdOr4oMmUI5S
Syk0n+ZOjNpeAM9e6UV9WcfQsLixA3BinVUgn3WJpZtU/7+UIYMq5qWWgT2PlYVNHtt52pXBGLlI
tSrQGtvlG2pmxbnXOPnbk4qVbAlsmDCKXaez2XZH8WgLFaDgBVgTn4DemEoKVEs4pkd1ZQ/5s9lY
PGcH0KYP1i1FFsmneU5KiwJbz0rKX225VdX6B7nEfKWqShI63l0PFOfXWM46ThJEpUFg0iukJAxI
btwY8MiC6Og/NPXGoRoTi57Ok5TC/K4mPjfc8E7n6Ww3Z4bl0/6/EXHoufaHrj7Ja9eLeZJ5arnu
IiRzUM2N80XdcdKGMr8wQ4WIaatRlysWVyHnQ+mBztIvJv5QKArOHvhfd16llIpfxan/VCR2/m5c
3x/aW0hMNQGId7UZeg6GKKPWwh9fATzCDyQrv+XrSVYJYT5u6yRSZRelU8rO6VjBno1oqVtIgs57
i4Dl20LLbn7/28sJNe08t2NawpaLFbfUqspon93kCjsmrrptIPGxWBpzgnmILTqokUZE6RPKdofA
gj/Ewom+d/uV8sYYvcFW7SQo1y8wa/O8Raoc2anA/KtquQPoBQ9VpMDMCJCw7BTnIC+XhNaW1LmM
PjmXkq53nb70sovbdL+jnEZ+dNoUGDoLZGGXUkCrxuHafA6DGiZdSiEdRrjgAmdwUm4M012GMVvp
fi6aWNLKKM5FOZ7EGmYko40thS1AQMcsBMPKTgWH6ikmW6bUjNZ4UR72u9DR2uikARrcSzEPkD2o
mSV19ScF0ZTPk8aMg5GXLbpfHt45hpjquFipKiseuBWjJ9YI91CConDiZA84KE6wj0kL8aT6HdcS
X3fKLGaOz1e0rGcFE9B1bBUEs7PaI7aObxR37JysbXM5bQya9rfVDJE67YBe91rUQUpz5pEYX0/I
7mP9b1mZ+TU362VkJfX64m8aMQhQqSF31WFYJ3hqvwAKvY2L/4B+QfTJ3tii02c9QtSThBFYRNPm
Ln3Quuv5ogkwm3YCkHhoWcbI84IvkFTDRZzMRORqrcgFr2dasR5pYUxzd6qm0qd+tQ1r7t6/+ri9
Ue54Hoz6UTvdsOClcZwG8wK3NmdKPcZSy3Bvnj1jL72nW2uhVB69BYWejTgMxIOz3VLc088frpNx
lN9wMqUeTcT2H4ykturv/w4OUSsKwguIh3UI6UE1j/AtT+aBri6+WQ9t5KtOoh1my2lH5qVIvnU8
VW5ZMTEhInK0OKJsDTM4sfXGuBjiYhyiBb/n4p+Pn0uoAYpEsV51g+Q/d0utq7ZxD6UUGNNemQ6u
HUxRFoZrY+fL/Wr4gdPzUzxST39uR8fZKRikqGMjuHSFs+OS4fTHbbsLvZM77igvcPTnPKoFteXD
6lQAUAG2uYgF6DUgapYSWSclpOzc8ODP5eml+yN8ADD8k/Y14a15LwMsHJqByUyIs47iqJMzJScs
wg3OK3lD+VenlUt2tX5T0t73i0YJVzQd49eMrIlpQ5PCWZG11gtE1NDVG0h/mhjCgXVuuqp77dRu
7h7UDESOkNTBS3460DhSqViLWmbMPMpc+VoHFyEBySEVBr2cSehJa+b5Rz5W7N9MRRgIKs0MlPTr
8Iy5gd7cAD1W7HLYAh9/tkYWtdQFry0IGh+tod1gQYZr8TI8SssnENsJjWmOOFtL63Lhuks89KH1
k2UTbMkQYv5Al4bOV6r212v+YZ96n3ixPJudp6mTrqSwEGTt7qHVa4uA5/7YxnydVezjKASKwg0S
RpIgn1MAd8yjXO1BYbpP5MY3fEkLcxMa853jfJ+8N/BJ73Qy5UDNitxFSPFLJS/NzCoeIIWqy5D5
/AWAWUk4vsV3rzGbGN6J4Guc3VePrtAE6ijumsGF6P7Y9XzLLGN7ymUbU6hjLSs+/9PI2KvbbV2g
qPY/3b2QecupXg4IirM9iQI3auFKySAVDbjIBBtp7JOlq10R3EIUv/c7iDl1Vst/OgwnrLiBv2je
8xwTfqThslowrs+g6oDU9D/xwX88duMMTZ+s6OPfRmYbprrnxFNr2HurhIP2lUPMOmXMYV7ArpHa
zP+ruNaGD7MOIqDhAlAFL/IefUugqeZt+SM8pEjnNrSxKCQYq6o4extJ2FZKqY2YLv2UDWH4kH8L
FGVi5aFzEgKP+8HOMHY8XEONBEu4aXLV2rd3bxm7k3Jcwn4Ydz9744NZe12Jfi3bWGUEPV+6flSs
/qsUsYQiXFUQ4Hpa96v1JSR4MlygQ3fwNwotvBeAOEI0UwrxWCdcltisn78hso+IechOfTaXogMM
7/TSMeujJmCOwBkQ1CxBAfeNxlTzI426xVQhZXwaMpAfDEqPIRAHlFGsbaWYFNYmMW4t3TXFfeSP
0fDQVkzuoZxT8dXBI/NbyPhR2DwWqA7GayuaqVniZUBSis2FFiETVeBbnJ/8Gj+EreCnlzqx4ZSR
yZatxua2SGRTt9+MQrqBIVQd5LtqSBTNDPcvVA0igGUVarZ15oH9WI92AfUq4l083ZE4Pv9nDDza
bOIg0Ebg4vK+bkOBeY4FtBjRV25VmF6R2FD+G4p/OOq8SimkaQkYg/xlQWrg04KYJqC8Fzo8XiCn
+i+M0SG/RZZi6k3JTF7XDkx7akGr2FxduwefhF3CUqQQinJp0VtExZD2H9x4552ZOB6oMJb2VYOn
Ens3ozlGbzmIRgInVpeEK4INsQ/wTFKnWrtKYcRiSjT2BDwMi9GcTdKXOOlyFTpm+lP4qgdC14Pa
HzWlLRgDORZh2WunwOQ5wl4sJKIuoNpwhxGpm/z6+RMpdrEawGenLRx8ULGLU+fRfWdOZg0ldV51
CqzQ+wXZ04UNE2rb5QN9utvTwekVPqJtYFWIjFQJ41E12rX5GTXVqt4cjN2+YJBhKPGLFKvdn/gM
Rl+IEmU7W7hysqfDn1d+nEN2g5GrDkFgPAKpf1a0r8mEqmpebgFV9TfjM/w6z/ipX2SV53PAqm8g
rq6tTNoe3+ZFRmJjf9VeBBCl3aYAuDWCQ/f6klHD5qXt2Kt2J0ZzYQWQhkAyqZ6kfKc0bxaiFnFs
AnkBc6vLSBQltHgs6TFZ2azixrKcqFJEGZ9kTK0Hv+ebVX5FOzoKNWRYM19H5L706jpOGuLbNiDQ
/4IOwJjcSdHGzSXHHkireZrvsdQK34k5YnVivlbDnDTd7HvfvzZkeXVMd9rHoAPkBAJ9cdEOuFOv
VQ8YWY1VYFd/joRDDkK3eYir6CXJ9WrlMhZJyVWM9rMkRaMRNektt8w/Li0XILuBSdk65t0d7PQs
iO81SLRa8lCOicmfnfPh8DU8Ya2Y8agQwIsVi5btE5cRwQf3hLkqLnyLvdn90q6UM0gBZdk3xTkL
xlXiftoEbW+Ye3cAYdZ0hBXAgOD46LhzQqs0N1TBYiYTcsnQJkgh6RmkkCUZQ75Qhlg1N7g4acC+
v27ZxoJ8WOBDp6U1KZZi0Y0S1kBAbBZG1FyM0DhIeS2PoKb3bkqq4tJFfX/x1gZghklJQCB5I5iB
WfXnG/K8A/yX6rmEfbdGxDJomarOFL+Vns0tWsiMOqqtkAVC7zsuND9l8nXX2r1KvI96MVAkzwQP
g+87c6d/XjZLXwBh1bW3hR3NfQfXcGpJIHTEUehrJ+oILVHwQEQnOGBOXq+VQU7myd3oMFiK7UmD
GSaRYLzICzaZeN/Rn722PI+Vykb+jA7btyrQv3VOfdc+HynonIeph3zZArSVsererLj6R56Wdvat
6j9a9oVbAOrLamr7DGR3yd7uM86rkTUbpTj4z8KN48aWMZknK30fkG9BAfa6jSQJZwslL0A5QVPl
VQuCh/IdlY3BYeu1iJjRrExaL6MBbgAQ5ro3Ltg4w6NSYkOgK4gdUlw1DY9AtgbcikchRGZ4ybit
d+UKyIxqNKgpayEZrjfQvnq065e426Q/zmE/foFO8pLEGrr9Xdm4fET51Tb4EN1oWj06Eioh0GX5
95xu6yFGcvmNswQSbDRIYH+bAROsoBZd8czGS0/OpKte/ahu+GQn61Von6QRb+Hj4Jzp82G9lgnm
kWI0AS0akKFhj07z4463+3jXXOI/97bGZRpev/v5myNHrlePhVmaMOPSXH3PVfMIn4K7iPR+Bes4
hOMZPXUt6vLbQHrqCwRsIDXbzgbXshPV6d3Y56TFDpK4Fn9g7hKSyFKqfvQsCSe9IGZvgl79oUNc
rPiq53/BdVdkoT2qYaG9AoIzM5Ha75Roker/rB8Xbzi3QpNew8wkLojwbLUIEJfMaRwb+6NLitwK
Orj7fDuHEfeUboTY/uOsPmdGBhsdRmnBZV7shywg8fyuuIC8QvcsV6dVlzuIDcRsBzcwmvdMsYLa
Z4XGMn5jFcbbawA/vjtMRTz+28aVjvuQfrqsRFmZJvwnyywyXbMonp9cJHvnbZyL7yTUChKBG2wO
MdId4lFectcYBVq1LGUtD+3C0tgHND2NbgmABoBh8/u8/Q0vv0ll948uZGW7I+dcKmqYuYbfDtJ9
qnBYBHCmjXIQUxrsYcNl4iXKRlRi76zwQImRkc3GT2H8p0mGa6qeDC+fT7JK+kuUtEa/Jq65Wy+C
Q7o6Pcciih61zyYWJc0OJNjn9LDrjy8hIcjQZ9aLGAKSMq4bzozaZKy94cXjXjKWyDkuZrGzu6H4
eEUr4Xm5fqx20NjIv4wHc0/zPodf9WMytt2qqDX4ZWmm9e4rOKQczfHatyLS6Coq1rk7CCDAryAN
MI9kt6UCPMYjFOHvDSf5i5+KpMtoNOZ2lKZjnf4iZg4tGrZw/iJdHX31NruSGCwW0MSpLv73zx1B
+08djtHcYdtLbLUCsRI0KHX+JyrjBXcwR2Mx9gsy9SIoAjFhysSYHd1Bj/VacKbh9y7UCDASIsab
7n25jP9kUUCxeVfQSbXPsfIREOnUbrbZypraEAclrhjtFaTU/tU4qlAIdjcfrQBY7iBndIS555zT
BqK8k2mhdNNMj12c8uQE16xwMHgciIwTKNHNNX//MmmAVJqKSq427pAzY+eQ1va9UYUIglJx8wRl
r7+vtcZMG3HLr8ybeEQUIAm6ZY8YnCVfmGYGBvM6an+Qu78kTx4Phz7/mdaoV0JToIVvYRFb22q5
s5xANo/V5PYpHlLI6ZAS1ThxXqrpTKXRzfATRGzx3XwHm7XaH4RdwFW7Pv6DldDzf8KCTXR3ZYWp
0hCk5hQApdj/VfFKuJHdKXG391k52ECSheoFaCGPqc/98VH7UNCNvEP/jezm6ulzUwWQ1qzfg60G
IusVostk/NKwnh1oq9yN2E+wEOkC0IgUz7HFjhg26wn+qv6VXDm0nhwOk1s1FfiKMjbABWXJoXaE
2DXZ/v8QRHPfXiCOMjwST+qzyb+MFqcjRdfdBC3A1ZqY2cihia+mHjYNzFJDYGlBWc8umY20Fn+n
m3uvmMWAE0Yz+mbFViInFQdmWkJ36nHm4STy5jfRfUB9YyXNTAifSfkdLQWWV/FQrukW0nzGt8x2
/MF11k+JUkEEW4CMHFP5ydnEaxwUyZNa0ef+1v5ZBMp5KuFCcDL3zcDjGGj7+pDt06xaXlP0yv+8
SyWwaaX2I/Mp3TS8CD+eZU0+n23XOlWseyUqhc6LrviHC/8ZXMKQhcfz1oFrsnpvjAosewBBpLjs
+VbTy8dU//31YV01hB2nAqCvB3KNBc4L4dqg2bE7fJ7/fteWeewMPS4GAh44BXQaQUGiEUEe3gaY
VZ+KjO0f+KKl4Wb9bQcFO+7bVz7tpiOc3QEuH9uHPkPHtCJCVvR56KEb8e0sxuNXzjoh9j6kqPb+
St/+3Ui5IT/Z2IXYo5++WpB/ugnk8z6qNdEpn21zD4wqIxQe/vbJ4gFTbLoXa1E7B3dTM3+1QvlI
7R01ucEYAwvJYSZinTGaoeFH6+WZWBF99TyvE+f0fqSpXA2D/a9blfZlWvsvjIAuCfSv2a5vh8F8
E/VdtoSm/r4TuxsqmZw9tm9PREU72y7sm9GIU3U9J7nLYWSdGedprxplmhIkI7HCMBbR2hj89Gl7
68GhFHqQ5q0NI+6dlje5yT/PJt4czsfk+G1qplFXNEjtHfrgDQSHrkAsG5zNGturKsu85RxSbD2V
HfWw/VEb9jw5hl4T5fu9A48mB8yZ8uuRqqfGlY8D2vo5Y3QTDkOizEDi5exetxAzTkD42BSBP0KA
1gGgmuqNABYsPqC+0ZXBIHIDfnlo16QtJM97ImfqS1zCpmmLxyDygdskV6mAAp3HwuZFBo4qSA5x
dSYd4gMtWEiAz9dk/YT45tbFzN4QFRMNw0MhsM6f7MGIDfK+4ZdAV088pl6DdBDdloUQJJia95CR
xAh026XIT129KVftWm+RklXWrYP2xdlXVaI7duXO8cIe3KSIL2Sh7j75Fu/JwAi2iIHyGWEcctxL
yocDJDO18LJdYehTuujrI5fai2GhqNpA8dluFh+fWjFNwnMhm/windSAtSr3q3G5bVdIqalU7Jq4
Uv4j+Hauhkaw6lbxgLmF3eXoNdzUGyF4+wCSnUITWPFJFZ3+M3WXQG8pvo6VjcPN6xk8/bA5AmW2
gmWK4oqAicn1ZvgZPkiUzegWWEtGtf+7nRBbFv4VNRVfS33b6kPgtHk+J9JHpT+gfS6ELQQXsM9S
tAdl7AEm87VOVEVJlPT02ljAI6nA51prow3kXUt8VWfEBZ7AssoqzPF/uTphVKdkpasMmCVSqySg
1VFUkCxq3IAAkkxnZ/Ho6KKf7dKhqBm+hlN52+fw89r7M5AMhKmKGFIO9budKyAARaKfiQnsVHfZ
UnY5lIwKk7ojdzdUEWX+9OhURlQN40W6DMeZH/rutBbBl9TAoIRZ/cEYlARHic0VNqEXEkazd30Y
JgovixAwEMMLesFOPj760IkC/O+E5Q5sSK8KZ3fxhtu5kbt7KSZG9ec6JVJJXFXKlKjafbsm2mWB
I/zuMgBYgIJ4VAhq9xzQtdFyTG3iy0jQng0OuDI0cxqJv80rgmbV5evpQq2PrjPTRUcOs0ySfAwF
P0riROgoWGCMBMHbhoRX0hjt18hzsQpEmsNn0hjyqP2/DAvL5bGXbp/trYRb0+iQYmMLB/zrt37w
LWGiwfH6dXk6ihkiSDnp+ErrzyeWGASl8ksEWenhFP5/20KuAXW7aP97+co1x7r7y4Uyicx1iUAb
yMVaNeG9/EvjDQ+8+E8a6zOo3+HnJKoVvzfob7E83rqR+58E2b+udSM71MAD1Acd2HOt97v5Or5s
GsyJ36x6502Lgs29Zy5uoc5lApDn4TlEE06sz8mlM2jtmN9e49X4cjitjgd8xRhp6zjfiGB+V1bk
QcqBihhNAwYfqKjGioh8GybUvYXuRZqGYDdt1gCHM+WcO6um6b2Ybkjk9sJvOgkI2LzO5cWmjLJW
SD3TQzf+R+fryhzxEhw337fwct6vCvm9//8ExitkCDcB6/vjkAvaKL6hL6K1tUuz40Ln+pyOe7bD
JLEjniWS5ySl5aPSdWlY5hqHf+//qxLc3QYDJOnYHGJWFiGsZKZkQHRQorh4jsb5GJs0RC5UG8dU
6EaQpVyT36nkR2ahUsRItRiRVHRGvyduELKNcMGm40iGxKRJCulKfWVxItMybOV0wNGMLVeguqxc
PKOFqVQ+4XioX6v45PQlKN0QrnLQrEagRzdRGx86aICvkzae8afNfakY4+mKkDPL1yE3CuEu8zpi
wv6Cj3SwhZccAI3ZW8nVt73k+yXt3GLdYn4IiYGa19sRE59AuggJwmEQavoMxoIbprKverSo6I+p
Z3KVOroaLIq8rknRFZPg3rnoKycm93ClbThEAnAw6ULI8PD6VOa6hyWwTM8YG/2Nn1mMOuyPi13O
Z0Et8TcrH4KZeBJzI7rZr9p08xMeQ4HqUvNbpYRrvtRdIpaE5N7ks2mMa2WL8Hkcv55yB9J0PBJu
x4hylc9Yz/y58330hbLM2kowDYyCp858QM+BgNYHq2yPlh6Wz4M56B1KPBa0tYPgHjiDxcKQ5ghb
+S3+8vEO+7WxaFr7uY/2czlYOhsizhuP2Yt6AXFCrmyKG9E2aXG+j/akhPAX8pqiQmqTqemKKaPc
YoHso+97qDJktA8unGbAuu3O9m606hAx1NNk8PxGQl+LI+MH7t8/Ouo/Hd6+KpHE47/BdFpslAW/
Y693PO9hVZiUFlLxj3F+lKEq0PragaClVW6vYz+ba+fnWnEpLhXMcDWACEa9pXO/cOOD+eNGWukt
zaFgNHM+ILuIkjgl1JP9vlBjqjaijgkaTjFpnzc7SdBCYP7rTufb9XwLgMjv2aYvcMRerGjvRm/F
+C2LqHDmDTyZPtj5EdfqzpXIyHLkZNcQG/3CfgV2CzUz8W9VmWJnVGde4kk32VH1tB6qZAT6Qa5p
biP9jXL5WP1sgekQRdz7ZAYRUQAEB0J2UnznVfwBxWBL/BzEyV15+3j+sI2wqIymFb25iG6BaAHu
0Fu54oKjsiQQVOB8AaXjW1fjlyxt3Do5D1n21sOlRMmrKKUcoenixbeCcPDGQk1VmEyK5fFQvIRL
Zv8wASI3ouvUhOJoyr9yERzQPKpTay79N7/yHVy7VQ1CqfjedFbvbSY/xSk6qxG0SCbcOr4l6Jwx
D7lAVGjN0iQiDnzt4BLdyjKiUIwqKVklDYD6BFXtYFiiqnGO2kyNe+rGSltbAZvrt2DOyqVlUtIe
B5bpkg3nG5ZJU7UqGdHahXpd+psAw2mdaHVHmb1s+O2QTjnuVcbpI3blUDXAduqVjol/BouqLa54
mS7HXul8aaYLXNqZBsWSdVCacGbQ4iIpxkJDdWpZlDH+beX0tLLnHgkjeLL93e+dhhNM8j9rGT/5
uoq9zS9ZoLpMFQ+z4oKxTrWOkvEjdZfvQ1FF8f9h6kKNage98nXt9NQqJWDVmLb2a6Ish/Yeqt+1
BV+Zn7oXao0Dpqv+trK9TXeLYUVZkg4TOwUy7LgZQQygDRKBRd1jJxDJJlUbfgj9YCIC+Za6m3Vf
9a+NswD5wiBhPKfhFLdNJWyYGhqavodG