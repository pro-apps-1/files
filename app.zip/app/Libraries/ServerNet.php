<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw8csaDSqZvq6S1FOB2DPB8NOOs8DhwsdVvuIYC3+81A9zpH6/eS0mgjBxUUKqOxoddGlXBY
M+siIIGS59nJEWDlKdlm7+6KB5+oJkeHzXdWGKAh0bBNlbdu/e1nlaW1XMUY9EaVWhwiSL7TG3yq
PqFmI2ivkeRBLRBrgTPD4ekot3+rgdpdTCLjT57YXS41aP92ZJ+JHc6cfhY/1eRzz6aSee6tX/Rc
EV7dCWa2p6Rcyul+z0j51x3IQIdxQVZ/N2c0AV5UV3HNAgEvKMn0WDbY3c9bQ0iiMY0cY0yT2Bxj
0rCgS/+m2PHZ2z0Mc8bWpDQOa66y7iDk9O1Wapj2W48lLK1fptFxKX3KlaEuilA1oF0rU6k3bYWg
lO3hkVxegTXZUznAVwjOoU7zyKtlvuaiKJRHYUuoZ4FjvBEpQipeHFM3wAJxJON34raTo3VwzZeg
yKboTAHonFvYtn8aiu98AA8lUWtqaOc4BdUPkJBJwMEUdxvtFnpcRKQRDUj6JDKcKaIeI98KhSlr
aMztoNHCxfHtyKtOp02OfpHpac+xeIQFYpJ6XeT7L+cuQ3XsTK6FqFp7PBhIyvGoQQNDrONsMBaB
s06/QLx+0eWmBBmM6N3Tz06SCuwnoRvDSUYV4kG6rlCQ9nJwunvBCyTxBbp4yOq0H17O6X7E5cym
I0MTC7qaVag5Kj4RPResoPgO4KfEcdhn+nfOAZ85javh5nuZ+b3Tk0zZ3WG+GbnBYfxCmjr8KerV
LOWJ9HZlYiHliGc9k/OtFlb85PTRT5jFMXO5oQt3Tl2HosT7gf7DFOnjkQD0nmYi/bAp4FB6uuXe
lci/QSsagrsniQ+i0uQnEGlzTn3dEDDR2Kp3lDmN7uKKkuxzVzhtJrdlGA/h8WXzDvQlHv4UK6LM
Clb09zq+v4qmHGXSEWngtbGay/JTdcswX7VMic6fD8uOiVrSSNVtZlWlYoHgVEZlxZ2738EMrWrF
TP1wibmVV9kffX0B4vrgucC7X+tUpI+GHZ7pG5JeTztpMLViM9/7A59Q0O9rQz3l8jcpVXkS8+nA
t7C8s7WkhlAlYU17hauxTxxMGrrMJB7BgTl4K1yHQ01dRWA4mXwYBonlLTw3V+URnrC9RsYU8+5S
w6qSpTeEIypEaar6uzHt7N9XZEdFOKhpf+wdaKUJP0SRJHWkRqbgvgaqYhN2dYi83GDsT74Fvy9T
IV3U9lViW7/71TTrvjIVhyNVMflAc6TfkEfmzvTsxPgSUgzUWeJUDVgkMz+suoPCFQuMlIAHEsNq
WvHc7zIE3LIWSqfv2q9OjhPD7f2vycLoIq5ljAMjxH25+NBCb5g2KnbgDuXX0bi7of2JvI0AyP+c
KK9ptSyIPFIxvIMQNgNptXFohMrO8GbJaAUUEx8fzoKOib4m55bqIvLS8kLFSqiaTh+PREMmF+bQ
/fhEaDJVH4XHMLhNAzzW9/z85m+nNA2pwUY8kdG0MIdcefscZPEihX4+eyDREsudQHCIpL42JeV0
+JVrBU72bB/Ibx9OTfFm9ccEEso5uHECXPUCw1ta4J+jorwrIZ7zQ503hET6cPP5XuyOFd/+T0GD
PSfK6qAb6vHVp6BeTaQvLI/0X76na2vlaSSzROGQK8PmZukRHynZ0eFStCxlaN3zPSjnsR8jt9PT
usSITOtkDllPbVIj7mDvgBfl/ubIlcvxn72DPGDPEbAsLNe8sYZXTFJUSYomDoGOqs9wp5JzJOum
JftsoHVktkvVJo2fUc7X8a4/FlYmRZZ1kwnTuvHBI4doPRAjxfxfx//w8Or+8tgWZUDptx8dy0vn
GDosEHw0dNUK52546x/ostD/LEEXM1A+CfmKaFzOCPrZXJ/QX+f6q/j8YgooTTNmwIOYahM08SKP
+fzKggusbwflB82nsR/HbAPTt4LSiv6OAb9BbdfBA2Wn2YK5gn8aU7LRhXrWwAKP08QddHJWB4yr
vt8J5Hzqzue75Ir60PjU82aNHsJksw+sVAts/6lQwVUO60SGOVpCW6XjDe6w1dy9D3/o5yQMQsop
dmOMA3SAbLtbvHj96wStD7l7d6UdweOcRjq+mK9noqFZqk4nd423ILDr7aMM3cWQN7SdYBxPDXCV
TqQWc0DU1RmdOlmkeRc0G6g8u3WAiVmRVOwBfZ9vSPYsGmmtu6at2U/qJkHtSmk3y3K3MmVpbMfe
bIhghHY0NVCMxy7GqPZXrjhRf5Gg933jXeMNlva4/ufI9FYgzouL9Md+w6Gdo9sbzMF+BN0IOO8S
+CclphG1FUOYhVp1ZN9u+1Wj0WBY4jxPoUxi2gvSBpUvYLRj3elMrW11BDmFzuMdSJIddSiDzH8K
iKptrDmhm6OchVkIL7nkpxTDMb3i03lX/ASjpUL16SF/gEUY6o0cJV12xj1IwzgJ5c5aEsyDSWik
NFthumlpLSRIrhAyS9jRSTxhbXMjXsmhSrcx/1wivz4NcocT35pcUrDOBGpcu2gyO3QLQ2eZsa0H
631zTMkFP0ArYFzWPjQWnBIITbzGgH2m5XfBjwgBdodnYqm5ZyaRhEtl1b8VNN4rcBQexTkVMZqV
fQ6RoeSFcLZg51eIVEV1jLZWIb1w/IwXxUCZmwRDINVdyKceRwU8cCMhE/NsAf/0zXYheRqdsVTb
hb1woG/2dXVnhGErmByZSHavet6nOj+aMu/PDAubsKqRGYiqD3PJsi1B+IWFKKJ0J0br863XCR2f
LyV3+RfuSPl/vPXJDaS3PGR52bDyqIHGSqO8HNIvi+XGE2f3QAcdG2ON8E4pN9UnDFls4C3Ec8n4
UqKMflEi0duYU9F5Ga0lxfPqwIW0915/2t+1jzn1vwXUW0hy5YzA29mSb9+WK40gxYTrubmKT7cY
vBuHEGj3LGYMrWxeDd7D66pIXv08Wi9MXuOHfAn1jY0pWTYI6YHfdVuYzPfeb/v0aXbKY92qBkem
99rDYsBZrWiE8zUVavT0ll1OCXPTXvaprTV1sOUsAjciYSATGSgFTIGwGLsJlz0SfuBmigq4oprA
Wr2+NQu1rSxUJOh9/nTUIrHWMyAsmmC1iS01GprEzFuFHasFkwUCfJN3nk0pwtn0MWwb83fASGwE
3VN6REvauL+YcTwx4hhXqWMTQ7HT1le7czkuT02oyQYw6e/qBa53wduT6/rdvaU36sJQ9vtPBPno
RKVuxG/6KIWB+fyqPfywO2i4FRmlUZXGPHYVBpMtaRQhoxxARuWZ6ceT1wnwaJrvvjiEbCMqkdwQ
Wdzw526bGmejpPUPZDkR8OtNH7QF9OeNjtve59+YEblTP2FVS83btWyEnmH5Yn+1SeSa0OQFcK/K
RqprHcME3QYAjtZtzrtqmnNmR0EWYfWMkZGWoVpYQe5mwMAXpwKa6RHqa4cYWNcpkvLlT/atNSW+
+Tq8qCqq+vZQHgqYYwYDsiMUwBJM1CAK3a9t3+WvE+nBV3tyFo2xbl62m8xwWxke2zzca9mRHBGV
ptEcvYoP4nDOkarNda4p1eM6xd4q8TSjQy6J9p5t7kOA6SAEIpuich1Zxj6RUfTvehAlEmcgTOv9
T++vebkY9pkwoNgqfslxSpE5ZcYv4SzLzToUp26FogmpA4mmYhaKYo0shVNhCjlvhencpcu/k9MA
xqOJTRvOCIcw3n0XWS4+uvaWQsObm0sbklKm2+1T1kkOz2WxuH6Ex7tWG9/FJUWfjaOiXc2qrPTP
3mCAOFdd8ywc1a96+R0MiEtnUc2mlxuZFbLDEDQkxs/qENq6QEoQLJSl6YXGDDanASScTerdU4Jn
GDiAgxonFdOO1EkYU5knlTrklDHOhGvxG1DMh3uGR8hFuoM7Q4lgYrug9brGX7vbvm3K/dAPC38r
q1HTgPxG3Tl6JvRwXhoNrptdQFCiPOcvXNxCc0YHm6x7gX0bu9UpEebvmg4X1ezo+BM/1BJHqMg/
orO1+rQIR5njqg3BSAdlAJVC7kiskdEiYr8NV118hCY4Tmc8MGhT3975YZkcoO6C1waYEH2eXs8B
0mq7veeBCrDq/BLBIQi4xObA8kRtlKQd9mrTre0zQ1oPFja8+OKp8p9y4sXl2tXe23s+BqlaNS+4
jDnVKBjWLx3GCHpI1WQQjWZ2XkgBfrP5+dmO/SDqGn7hldx/VpcA3m72UQ2zc5555mWYNlOTRgop
P3ONU4cP3kmjYYo6g4Y4efVes9SM81Dlt9NlgqY/WhazzBQqelq8vtxvEql1Ee9jQSqFaXXOK9bF
d/DCzDGls7B9HK7SgRgUglOGWkogB/Q1cIt7uut43a3F8W8+7Zls1+I9Tj0T24ptLxgPWvW8OHzI
HFzmWgGkrA2I4THs5H2ne5rADEDTYoH7N8MSzxk+5Cqx2Fpyoah1I0JVGnhi+7SjGNL5eBp3UtpV
IRlMilIz/pq+vrMjbXcvQhPcueCBErQ3fp2JEdVccGGAWsVs20K+D0cbLX5RspkmmQHdrbqLZjgq
qAgO6vJpPp3E3FuEUemdkoF8iqP4ICzRk/kY/tVjwthPoXNK7IzWEm76tdmFJU8IpIjs0wKAqak7
HopEf6vjUe5aXbUxIcEOHCTTp4uk5r/inPMD/gzAzPmZKSMSGWnXb2iNVlKAGsMDGKE2uu8+eliT
I4kb/tH27uruQuCWQU88u6yjQHL2Rhuiqnpfbc+PIsxjgCHmg8KvW5PQPvd5lkVNi8tOH/Id31GD
BNKgwYXEzeMvKqx9iaEVccPsMjOMyGw51lb7HBbg6U5jrtNBRtECiMbNTHe+foyvYH5/GtBZONti
r1RGl1VkgjThSKiXyIYBBQWMnZwME7h1BnPx0Umu3jFezGfoi2XU9Sd9xRY4OfAbDMPMOyGVz8T6
iYpGEJtBEHCvkP/kVpWAlkCztYwUqtxPyBkdtMajzet0xmFlwIlqVUYJio0DZNx0eHwDxUSXXwUQ
AhQGCkk/ceP+EAgoPe/eFP1FGe3d3FhWWvap1zOXuGZT9Js7fQTkfqrdk8MtnAt1CLBcq4wJ9yJN
7mE6vbKhLgIkSREcrHClpf2gH2yPMWX908UGz2PuEJ96OIymv8SrHOm0v3veKQF4ZdEy2lO0eBs0
OeRATYOV/pkDMEjLdYRc9UxQru3cGOD4Sdzb4EPzxCbXIJThbGIEJ9Q/Itm/SkBsP38YU9SOYThw
xtwRXHIVgvIIGfb0JKN/9qdyhbho2qBsR+68zOdjBoLudfAnxRxRE6vzBtnFDwX8QBwFThHHjhke
25i+HW+AMzlxCZKTDcDtK8ZwTzurjpqLXt1Vz1UfeD2lNCzlfeNZDipPOvdXjeFq8B55WJKMsVr7
Ik/Emw5os5TUiuENn2HN9lN8T4v5LjXdD1Zff5XPdU7IPTl19RPpRTGVBdcF/al/Q3GQCNKCVpgM
N1njuuiv9boyaeOkgM/rGJ14SKk38BlBrg04p/cy6zcqV3KHdboxL0m/f+l9rAPQnW3IVLrlKBh+
daoLwvDsmFXHoVsOCz6XVrWTzyHhPGytL4TE8NHyOPN2nr/Gjcbi+zaQTgSbnBlFkjPPWjM45E0v
A/PUf/nNE+gdyWzH4zWmimg19pKRguzp0/rL+TAdj0yUja9pRt8cy34/ymAfZ1SGog+ssIF/AQtl
Q7yZVMu/NvCC5dDqLgNS8hzaz2Cq/qz2m8ihfv1OqKLud03QAdZ9+WADW6s9hCQXzRx5ExFaG9K4
F+AS+odwQ/KqApJsJdj7rZQGJ7SKYgcmQUKCnfgQTaW3hqHvs5c+svQjTrTy8dILZbD0myuv9FVM
Ahz5z72b4n1pydqXKJIvfO2TJq2l3sZJyQdOYnfQ0dF1NBJCUZvFCEXGAWYWgUi1F+xQJbqPOjBA
3/bGeHWNp8PdVDEwpNfPItvo/qdbumNl4YSFGmEKh7yMzMxLK2DeOvcVlPsndaAsgcQSwbmZYq7N
mAznBysAjUf3Bn3FWb50TmlPoh78qIbsbQfe65slg5a/zzhIyAM8lYXfvyBv5vIrMZwArOFK+fRm
IfSJSuTz9LdBDhX8wNooO5STrObA4NZjaNi3enD+8bH5nlk6PAvNEWAwExidAxNSa50QOPn6YHal
pFXfeBbzsH52nTod7YQ3W8QuAX/fFePQPUxgpf13wPthXfjVB3YZxj23CFRsCxuPLLK6gFAXGsVe
JsNZ+EdARD5UuVIRa3DEdOmMXwT9CTcTsqM1bJ+NSkJWmJEYR3IP1izciRxY+5LGBC96DCcDEBCw
3g30jXBZfTsw1PCWHs40gRgzoedYqsXXy3ionLVcnWys7oXVpEpTmIRq3vLRx0sor+67uig9sZMr
uTqCp1TwAQu4c/lMrv+LT0skHuKicOtCfBYjpYo1bjfbBXY0ows5gedAOUAQvl5tpZ/Y6r/FgAD5
BD4RyiJmlig4hV76VV3+DfHRCuO8wuS2MlZie1D2FwZVA61SYxYZZ5/N6XrycFiJOd4w3S9D4vII
yKLhGfSIJQPy6Yr1681LDmfHHhSV0KCs9hSIBTDX1wEm/KxyZ7QkP5+C4ntBJQgSXsuYESAuo+JE
jqyxc47DPVumCz2WYNj4utGaqoW4DF/v1uFVwVsrkQRx5OIxOh9+FTyMEA1+oCySrUUkPAgYz/Kk
34BHSpjubgIS3zGxnX6UQJ64PlRGZHJRHc+5gWZBzGgBTANeMSVx1VRPqvydbUfreoDGi+dHjbdX
6jtNmlufrMLoAZvKeweiZVff7UUKs7jAEBSnSqlaO9lstiS/eZBqZPovguriQc0TjSiXJIDzkWNH
XMcXxakmYW/ifKdcc4HCMsrCH+hZXmj8mg08eAsDrmPRJHpEy6/4l9lu6TZoTpB6M7Nwg6T3yBqd
3oONgiVjS17bY19ftNAYMpzB6ibRCgYMzbKEv/BjQLYjg9VwYfcWks3YvZMfySAEEB9nM/MVue1U
KEWLgrda1PeIE5hBu8c03vdgtrY4hGlP94NkbTxC8C0vqxtY/kfX9pi6kOp26aRafUE8+2vk97z4
R0Ch1rr8xiO4md431NJwkToINnRK3GNPdCrVgvsHKaGQj++JVBmMVQuB67XKas/yAPH2dFGjt0n1
V9M4sNjjZeMuDNO3IVnkb6eU7fSSLpv0YB9Z9jAXY8qQwSGtgo2pRdlN5Cho7twpOvyz+vu8eWNG
Z8aCn8BC6OeEiE6bsjJs0hSgyiS/EiWKyN44MzNQrArEWx573XTfnp8BQnwI9CF04roDRdB6Pzb2
9fjnKngGfiM4noMkmczs62a46Ez1O3KrWP0U2MxyQcd/ZGlofn7/yq94JF6EVTNnKJa9uWQO3+RB
nH08KgkxRHsVIJlUC77Zx8wppsnNzFDuOtf3fven3AnSvAT/54d5+aP6dCHXfNpJP/8ABH3RMGkN
ZTbs2bAf5oc4adM4kPi8FufnClfji43T0PVcPjoe991wR40ANJS2N19lyyhrlI982Ej4cpK8AYrH
jmQODJlonsFrIdp3B+M0Gt1Z+4kWGJ5Z05FW911jUF8d0hnPWLUYrN5nDXWYr0HSWgNVnqWZxf3l
0ZkE7DeTWotUZg4oYQPU/lAmUMvRFOS2D6WUis3syZrK8wwV/xkaUOJHTDU7w5OgB/EY+IOwXquW
z6j/EHzKmD0bveAIrqN8w0sNOvwO/bGVzUmPieZhFmhoWzAJcRbPtnx1LC7pOtRFe4jMD2C8zkh2
GkjJNL2QV+xK1DelVmH5KP68DUfbc8iYqk1JWY1L7gWxXPFX1ka62H64ZUS6P2RJrGw0PF9R6NPW
BgQKYi7xga8XtdUxMn3R3kPN7oigKNRpE6hhTJrNssFIxUm74knIwxqLkK0BC1uHerL/0r0P+c0I
GW4aybuXMLmITDCGSnpJD2R0+k/x2/QOxN0WGyxq1C1wbvi7ywTiH9lpHHOkB5a+r2RD3kaQxo2J
3bkCcNuxpahrlZSX9FewLCrUY1tcjM48u8EgTYC5aP4iTr4rPAg0dMeVe+gRVWRVIlTGHLVaHHID
NdyJLWWvIDBJRJ54t5yH66IyKFvhs3jJ3cu4eIB1VSwxmGPxa2D8r4+UfqWQa8mjCBzESROged/c
vR+r1RAjzQVpIdzpC/4epv081cUWXrELoGvxwxo9EZZ9JtbNOyhzDVtTMdFF/GLLfRnWr07o9bLc
ctIqX1b6Fc/w2g9gVYqFHletfQ6z3zQm/9cM9AGShW0KJUmR8rY9kUUPlvz9AYTyYFILuhl7whSJ
joB5yM8kDAjrZhDAvxc/AtTr+M2D3KnQFsE8AvDYdxeeN5VwZhbB7Xl7cBOGo/KWq9hB3Kh04zwG
OwHlzkUHqDZMQrljlq3/KZ6wlPUC75JJgrnMIJO4/ONaHkLrQ1XoDqSHrrQZNLYRmLtcWWbo70Vl
bneBwNMeSoRdZ/Li+VA7W8DwoRT9dGYIGxFlwNPWlCQE71fwamCNRpTFAeIRmTgMp2fNaKEXWgxf
q8P+JTGWGG4sAyRl6iG3lIAlxzH/uyGThwUtJwW4H1upI1DB+V2uvecs4VyGF/C/M3rAAvFJGzHo
RnBU1EMuqcD4tbkahnbs5qgC/T6v+wfc8Db7mvOH3bJJ+TKXuUeB8K3qcQCPEfyLLtbCD9xdp/EM
EDkjLVEaOUXP/jgMT4NYguP+jpZoNSoNDZIc869eCQYcTyQzMdTSxvPt1CVs2xId2O1a3QY5JJ7F
rFA2VahxIK3PtcoKXOv79sxNUdOsx5IeIzgs0Q5BsKvM+KOK70uE+lcbKhVcsvkbe1M3Vp1cOwoi
1ay8AztffNAWB5m7kGKHG51Nlmvvj1JgBjEXI8sKk8BmlXNfYbrqszQfYCUV6AnDmWoOpE73+mXd
3HaojDzow3w5J3y9+1hXpjEcLWGsBNTnN2P1iR8JxLVGVi9kFIz8wGrUMyZy4dMHavoJyqNMvokt
xJPZSWzEMzBVunDKyPIfX1uaDyq/lJsvLa0i/9l0fDd1VN4cUesYmpDxUAwc5UIBriJra8cow/Wo
cRqwx6AFsf90lXPMFi6SWdKj/wrD0GH2D1XL/Mx/HGh8L98TiimIvLB1Tf+g8TSFiAUSFjUw2i3b
vzqh32RMrtT22qh4bLrcciEOHU8rE3GuloZrKjX4c+AJXtQIhcWb704vq0Z5n8FXuB6GPikOhxuA
BqGIdYcf6vJwizrheOTnwcqipWtHitL56DaZgB/d3gcqEfL2hW1fnd4uQbvNjmSsLGvwVt85l8W9
SBLO3tCePn1HLn/eA/z+EBdWclsMGv8uPHFQhOKbkV1gUyJAIA3zbRDDu8m8C4YDMtxJzl72kVer
qQbaXiG1zqmhnQa3q6ClNHGz7Sr9UzFt+2OoL+099kVyibIKRvzmit4PpKh9sH0H/dJNtzcNaFQK
KpY6AB2wmVQGR0+sb/PKxIcpr+U/eX5zepDzhxkksSJ1PCpZZ9PZiyeAV/Bhox9lpoIt48HNx/68
jeGHzAAbYNIin899lFlwXtd9ouwqh3ixsz4rUwQdrMNJRXo4wcDBHCggc+0Rvw9ogBPbiQDrQiCB
UlDMYugU9I+GZublQtpqNbgQrdQLaz8agJlU2vlK79F1zrZ7ZFP6zjtNZfDwlH8xYMUoe0BTegUo
uZOCOrr4mMEVzS26rXiqpUAejY+CYFUFdISTGsVHpFm3aYd9TaVvG/0n/s/pO3sIX9fcBviBKiI7
onyOC3wNw2l4TrpzGBJOmhx9Wny01V3U22CN5vkBQtaers3GlMgbXhh7hdyRJIKo2V9My8StwseA
qin7rWUtpu0T0uGLYrMxjO4gxG3ziUK9LDTqDdMu1q9LQCQuxWNr0oqwHY6p3Rfau00i6WlRFl5S
SixJkA5/0pR6wJvgA4prrRKuYdxeh5Wgbd7yE+S86NFc6JcbaD9i1/Snod5Bk0S88U9b9jtprqDe
ZnxZKYnyU6MXvfXtW9U636EoUwG/Rc91BbG2p7TGk4cJS8l3TMmhvjkn8+t24DwiY/Vgez42Ymvf
S2oP/hNeqy6LNkiwzdy4TgAJvROe2eLQIsN2XOK1igiMKOhESoW51YJV5/AbKJJQgvd++ymfGVBl
wUrb5mUWQV09wW3yEdrMz2HqlmxzMaVvYQcrXNyNXT8KJs8NSo2uflMA/mybyYI41ttpsV6qBFo5
OyETcSnFBqH/dFVr15puJzoKE9zl2nT2vMr4Z62FfmqVsK4g73fiHlMmTpqp1dK3HkbRr3rlovq4
KMh6SeCIV4HUTChQCY+EGw4Ep0QEUrP5Uj1La4OiN4ylWVb1T3E3FTPtnDHd4qogHhYNP0vXWufk
iYaRkFFlAOwC8epWPAQ27+LPMvSkRDkSzPDa3Rt+fVebtdftvxqsg3BnZp9EMG8X0dn743jiEfUd
lQbzoe0udbaposGCPfycBoqVMTwIDjWZdiAHAdOUl/dZxAlEsMh/zXbBQcMHDyhtoP3VtRD/vAlJ
tKTqV27QbjukMuZEo7xRU30GdOD1aE4Uqnen+h0RFJzA1Bk1Ht/T92MO1NnK141rUnc0Yf/TaO3g
AQbXUD8JeA3Vf05QT9YcES2nNsEdhK3hl8e0VI0wkEv6YzgJpSbXfKteMSiScCi97AupYS3961nU
QZTsiSrwQ1XM5QyMjInKe17INZF/NPsiDU0K5h+bqnJpg3UXjYzR06WXQjntvMaUcsZHVvPDb20d
nSE7zPlEvoTQC4o3cqrnVt6BDlpAgDhS/9CO5rUExM/JYFEA+XveQAyBqnGl6ZLXsx9/ydzbsLUp
C7y00taXgMT/Vp0O2KtN11JRdyrxGzG5w+up7euEyhrj6B3Y2S57OMfH+K/w7M5y02Jk+g3HtCNU
mWYVGWxCXV20mw6qlLrLm0jIhk6w+Ps0q4MF62Uf0nFPpNVx7zU/0XXCd0JrIzYaIAwxIZjxiXQ8
J5XTZn/YRUKXO9cfCLtYAPhF3dl4J6atJFwpEzb6LdH83wgq7PYNRlbins7QWMsqog92Eo/J4lUx
oLXO9zVSFH0mR5oFOsochhdUUD+d+OmVYQdGh7EXa4GcrNxEym/h5FjqaRQZfp2dUECJLv+mlocv
SUk22WMy3/DTJIys848MhIZ2RtQLZhKo5WhhO14/CTukZ6Dc2bREZabN0H53MLOLGftCvI5iOwgz
1AHx7xp+2fp3593FgrXaXsU2gngsAX17c3WgAPd1td3jlOJUUrxYRO8Ocdb7K0266w4mRo/531AT
HLMP3E9Ae5bhL4E1wJu8jV8RGc/3hspOBbG=