<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPum4QxmZl6+qEkB+dp285LpEYpt3d6yvPfYu7F5G3sNS/2AGiofv6+lsWYVOFmtugOV/oefo
E6fbOKJXCNtrawxay9jl0HLUBL1OxMLbiOhtqgytQ/4cXub5w75LL1DAZ5b8FRkUWUJC59w/qOHG
E5d0AkYJ1B+FEs5M+NMTjpsrq/lQ8/g7PW0JClZ1KRrk0g9fLM+px7bhKEMeHxcYg4/ogUriAFG5
QEvd62/sRJ1ex3RB8IBVCU9qz38XbE5FgMtezdiIHdElA4AIKOIlrzpiU/jh5nAt45QFwZpFPqXs
O0eK/vb+2bg3zGm0FMcSm4Av6RcUVEVKBwbz7DHlvkTHXdZofkAKRdju+UHk21tQbwTpM4f6Q51s
Y42I1NHwTAy7WCTyEVyI1PeZgVbo3dG5QnuPotSQBVUWXoxyGgdShnZLKMB77FLlLIbJzIPSxb6F
PGFV6gETKIsCpid7cdaj/pZdQOBztxhfJrztgKrehJr93gblJtXoQ3dc03q1cvNyB6wUBu3rFgfJ
9/jOje4vL1PIT0kZ4V8qCZBPQxC4oTaCze3qrKMAjxYbrA4C8sMgZ8zMLZLlotPbR1x0NP89QUs1
K+I1OxUSICRB34d3nuBV0HzLVS2cp8kk2iO28YrpC1x/YeAaOyVj5n7WNeaW8y2oj1+elT9+lATb
uCiXN6KDdmUMj8mbzsgqxiX+4WgXSlBcVacHYcf/5APjabVKxJJr7+GFTpLXTS5oaeiEnBBnTqxv
3h/28/9EZEp3fR4czJX/UP/LFrMnCupUzQAGMBsaUWhnunxzDj9SBhipySVH9TJcxe6XzWOJP0DA
xvUslI38Fkb2Mzndn9kQAiAlYi1dNeTXL1Ov6GSodHGpHycGVPb2DDIGtFcjXxd4j8HFJdKVRmMu
k2ceoKxpELPQ4cF0MiPB/qFsQ3/KVOjBBr6Ehiwz8ZF6rCw9cHvu4tWwcCQjnZCqqhrjYKBnQ1wh
CK0jBebUd3AO6okxwJ0D/uHOZtlKTO//yvFqN+gApEoPKB7sCHE3OhCNElNSd+OgtyPsbgyIvzXD
X1LkV3FUnLgW9otf9MtvqRWnMuVznmkVUIhfth3oNLP0At9KVQP0MQhcmmNwqWW6LRsLsjS7e9ao
i7sMJwhyz7BHs2JWPWqVcyWCoFdG5ILlukCl7uwfONN8qc4vaZ54ePkLgIBjPBdK9wlvMJX5OPS0
1fcZHrwAtZqpp4XdIB2vDrP1EuCXg0gN7ijTEm+9Z/KjWQXWPqSdFbTqFW0bCO09GqAGIiCplpEI
ScadvMZBA35s13O04EzmaX6PkoVYbePEu1Jd/tv4NnYasSKLUORDUJ5ry0j1bm7J9vb5qLXurEBH
a2z6554KDXkmxzyLCdSePcQtQGh2Trdu5Dawf7C8Nn6Ep7aiA3STuNPKHkjH5cVGSmZ41uv2K8lU
LQP1fXWbNzstJarW0UC1ELDcddU4/mwrWeVTjT2Xkd4S2noo8i/LqVFq+jYLe4m/MsEAUmlp8WkN
fOJ15N55A9XUvaQEvIOlAL7AmGk6hPFctkI50c42pBkss9InKqVAzVbwUvBy5OTF+zi5nbX1ZEbZ
3HeI5JS+JfK8AQfp6f23O7qHO3eROmnkXzjz14GYuWG0D5AT54OBi0SQhO10b3DEO826c0aPh1UR
hUX72HmMhgyANc0g4GlTRaZN7z6TgmB/m01Z0AqMn1RnzWdWAgrtT09FCbJWm8ijxUQfnylm1z/V
XvPfKP7pUOfkkQBzKF78AvDnfvhYU8jKjuY5mabZdLS26rm7e+C2Z7kDOCX4XNhrdHfCJtS1lM2o
tofAm/srjfTgTfQfH5lF3Vg2Pt6+2YWQbGv+m9jYlbHMuhmIa1RzzoYZ+aT6hnt9+evkwsNxaJG1
vFvt5nHadfR+B0aaJgof9+ZFwMkX0uYE9AZLIATRQ165OgV1+i4GgIdnibNqBmMhRUZYwrBqZ/wT
/SgkDiToG+j/EUCAUGxpRZIy0jOIB36+zzpcQHInkiqucMfyn/e5JStQw+YbCIrDb2g57tZYhxIO
mN/zy5OEBnTz1xITFG9tFioUGxfOsfCeIWVkag/OFy3TRADF/prwO49fjdXly6K74vZTaaTJ7xGG
XPZaa3x4OujGwg4P+JIizqqF90p7G9+32439yi+2lJjs6fcRfXjtWRzAf8ow4YqBo29prX/Er6dp
P/cVsG66ubRE/5rOI1DRuoJGkorpMajUTGleCpdPieRW/zNGr6vFy0P/NsFRASueclDACEdgN05e
ofBpdsTGFqox3SzlRJTmsWJZ1CO3vNXGWyHjQUTi8kcNEYoGoywSOqIjNDbpWsupKcylAcbMOqTu
6qEi9ylFtNwI69guSpEx7fUIU1ZfVmDDdvqZ/nPeufYzyyK4oGD94T3Paf5c5qhdBYs02rZgriU2
UYsnfn8N3GzS7QnE8x/2DeGDwzBHwmdTpqhwDTxf/6IKWkap1/hp9JSesOphkEUOMjf31kNiaKzs
MqPbHB2FzfkbSIzWaUSGwk3btZcQI48Kuhd6QRPoRq03zmloggYE53OidSy5foO2ku5t4M8vmyLq
QOyIYSwWmQcCXVH4dhAy0+YOrWdyCxIAvn7cenwnSMj7NRdGnRHnFIhJiiDvV3dKlf9koAFT5Inl
/JUZU1TIxuIEgZCFvAoW5zMoMz2WTVA94Z5Rz9/fVpKV+xpv4x6q29XLYkDttxWdNjo9swpRX3h/
rNbY3qo48q20zQ/3fGtzkrjiavK4+eJnOed/qMV8Ph+wtvvKiOsxsQOKGkDHz+bMDtfcmhAtTH5N
EsBtD0QsfV4SgbZgCY2yetAUi01P1WM4Be1KZj9/zRNrjAhQ6KFcO8IF3XEdGpxghBxoySj2PuGP
7PhPWQAMO5IwHCGbLo+v5TRjKbSHgwYD4bJG/bO3Mn+shwy9Dkes9zvzkqSLi2cNrx7ePBlFTFgw
KVssrMvIWXs4My4tRHEPWh5ASPrCwTwmFQU1tBbhhjcMdH1WKJWIJgFGJzFCpuQmJ9JMec0pcWg8
zopxsGZRjBfP5sdQZGts5zEwq+B1844/I2LeEl/IZ/kcyqVTtIJJXdWsEUmbox9jhVL0/h8pWZvZ
uduXWJcrmWsW/RkCUh4doqo8jTWIGoRg4aLjC2CAqHQI6EHXwtVjclEReSGs/HWCtNzDxQBPjOZK
kfzG0iAN47Owbdl+zUSSOXSLVAO6/LfXa0+OEPk2qvDXh4oooWAX8BwlvNCC0L1E7TxW5pG0IPaV
TqMZnCJ/MJgTAo8Hka4L76MKKtrtT+CIlXJ56SRG5fR6J1Fiuq3yZRBbs1N7j7y6nihYGr/9BD8S
g4EvElhL25inu2B9tLd3jdfOQ5T83qNXyMvsT1V4iExIOnUrtdld2nUkYuRJzbsWRFElrWlc4q9Z
/nZeJxIvryfJxaaMFSnWtaPqmCy72jYjyfCcEttk1VJqwizBqY0htPJI2rHgqs9tYZHITThtgEfX
ydaDefGTg8STb7o4XYLfA3sH5Gy+O4xFAIsPd8s2rWnreSP3xNPtII5bcoJ3XaTygR6eMUSij/vR
PPyL15FpVxzldIcTLT2bOz4opaynoa8U7LZQOditlpRJ7GgunyhyFXfeYjAatA9jV4u04V143LQb
UfgnASl/KlxNVS3tbbDx1pELEjUOjwm8bPbUZB9tsX4zn1C/IZzAErhR0/lWXKXQzEuEHUDpxVWD
tRx2sFnmxs2NROl5dDujTCxcZc9OoW1ekqVsInliBVM5SX8coxhi6ON6IGoa7B0txLRPju2koZQI
yfcqJ278LgqSsOD/sPRo1e/2Z70Gr5hwuEx+dW+JXJIkQo1IziBClObyG+whWkZrOloZstcQg7lZ
VTEhP96jqpHjnxeQCFZri5RP/MgaTdeQkn49kDiVKOoR1JDEEifnH4GJC0q+wwJbVauXGrkgstbH
TDrQfrTucE8CoAX3j6zpG//bVyLI3fjm1qck0Ha6EH1QFaapEcmmaJS8ri15v/jLzJ/G8cVHTMUT
NtiC/8+r6U02kIOMurcwI1JW2SPUrTjdMi1n5xn2kzzR8bF1CyMRD2KIJzmQfLcWSlZkgZNZwyyd
DeBrOHOCaNnfqQ6lHDA1sGDxxrABhDVvIG61WNHbXGP6flw08McqafgT44qtT/RPZwyulVMvRTYW
SpVovZrmFZ00WpUdeiwwpr3W09VgBWQnqjel8jHjv2MFQXVwd9sxhi29lXatg1R77Q299nuHGbPv
A0kRYPXD2GbWWGmoLPuhopd8dBuWvbDhlivvMxCAkHxi4toZfHCGJHVRA+1NWt46Dvg5UquPVkkf
XmLWlGT8quetihHXPYPD5wYeuQ9sguuhPaZs2iUl2kAAFiRKQ/h0rCkqEFHO7b900U7s86Nr48mb
XGZuAR9p7r3SsCr7bdsIcjLGAYgMVJdMlFxvMtXfTLWSDs6C7P2DsaaQeIfHJNX4p09V1R4ip5MJ
h2HIVGMISYt3v9oePHhOLlvjIzruZym7DUKY5S/EgR/mjZddmG8ZSY+PKN35ziOqMzcS4JDjVxUf
/4VF6IIqsR5kPywsJrLRdoa20SexKBaeHpKL6xFBWvkZRJ2s5jV+HJV5FnevVFowLcOCstwbzZZx
+ndI86GEWvRYnbPNKpW9sPv3Mg0MXzZOcoSLjy8IbEY9cXDrNVp8jXpB5GfU5+GvRqX4TCDxhiJS
hPYGJ5/gAOU0Teq60jq/2MgpJLle7KGiUIlQ48jGFwxnuXTWx7tU1/wovIdvMYHPs393yReZ6Mou
G7Qqa3Qf7uBdIV7Ovt7CMZt/a8Je4/FH6GpdJCzGWOqmCWIfkVB5FMOhCRz9uLDADKdMWTlDSxb+
BLkeebzAAAxBaZzz24L2pa6ab2kybsvrKvj98Sg42/TTQ0Ey1h5Clsbz4NrJkhVLIdHZ5w42Jy3h
mWExXPn/dAKImlwmsIms9K4xFVjU6ypdSVOKjgzv9Wzues1F3rkQcvMZPNTbuD9xOri7lOrIXmCa
HnIJWBUapvJI6ansX0pWQJcUGPSHdHNcLRD+tja9WCsHtNaC33KF59Fxgm33z1GL3erx2dTMclGa
UZGcx1PChMEj9oNWyooTESFXKuy8LBg3rdz0oZWMq8g2jF90SkFWVzhLQI7ZGA9TpXNEFxJNi6FQ
47DNAmnOsml7kkTfKNxLMJI/Aw5Uj1WwVtKNYxEx9pEMLao5Sq+eUbqdk0FxtXo6kLjthEimoyxz
Di/uIiRUAX1T4YLTM6uPoNH1PTkq6BkSvPX0Nuybxi/MGnhxvDPc8EEAWC0kAM6IbIwMrDCOqvt4
RH5dXKgC7d1XzuMU24tm0MC6qPtsTtwzXhmhxN8qZwtgnvNhxI20hpvS7AmY/dH6b6OJT3g4BQbG
/y5T+QSo7tP97G5iC1bohvIuj25bDCvkXRqFxS07SJG4x2KOtvD5iPcg+MycLj2pHp3hsHQbFTGd
XDVc2XSQcFg/VQKFiyreWfgJ0Wqa/tVQ2TL6cZupi2NeNhdfq9BQNK457EEW1Lgfd8wt08CrApIh
83it6e1pbedEmBQTn8LEOApcQPgtKZRyHy0tdtMqZyvN5sYQ+JAF8HhnM1zRtlb2aUvYmhao3qZj
7Bc2aGIsVIbJvtwB9OwRfU3jmft+kNSl+snvbPSx6alYLnhARy/DfJez26sF2FfNHBxBvx9lJx5W
mgdYZqxo2/oYJYDjTrvD4RIodhgrqXKB0JWsxoaPOzeSCIwGHcHtOUCbYfLbjlgJfu62Y2sfWpu9
BHCk40Zgc4eO6vzXv2JEZDOsYD9bEOGrFlbOMD32/o9a3En+yJk7eK3ks1VcJGjKq1WF4UpI5Hh5
7XgUQ0jSP35yc8zQxz4Jn+CCQD76bAJwHC//KludGHYqx/UC2z0lCpOEPqpTjaBUAVrsZBFai/a/
LgFxuP/8LiBiSzGLV8GEfFeKc+SqTvc1aaHGIXqMCXX3mooVh6rwi1LhtXnjX3XtO77BkOfKT+so
gNC4vSsnQYx3ud5RCs/AaNe675Oz14/RQ7TKOwgCz9dLkMRmSSHRyzVmT4buKcQvwmTtHJeUwlbm
Hf72T6j2AwmXuCfBCFnKvqPtghD9jBrKjqtbViVB28Xk4pNTq4RvBixIiCaEUoFKdHahNsgR5Xxm
K+QeuGREXxqeboXsixKHoWk6zBvinfFkKqTsmobFM9+8PH4C+rAoErDp3ff+QTCGTk4D1Mj8dtV6
Z/Xlo8b2fyoNyYVn+bDXz/OxUKvWSKMv2br1mMDOSDAbdknRMgbTSPEZV7jpjgxppzjtru29sZ45
aBRX3Ug2EY7JB/ed3HGPpNXefCDV6QDui5gOh8iB6xocRWcaBL0+MJa6C6Lj/OWrB5q6WdNx7/Z7
4acH88q1wW3oWnROy4HqFt++sye9JQtY9LSxoN35MP4ZqdlUWzMz+FOH+pihf/KVBK/pkJgSctax
JFy2XVotLwyG2QpdpO9Z3guP3l91GDw7gCzp3P67IVyaHDXzlVFKi3scHtynnqdIK2TF1rRQv4uK
vcuUj7BmDR6rtByKH6ztIubOc2J49sz6vkhSUrS0RD1IhSMt12ShkVZ3HAXbLH7wWe8qZVKjzHk1
ylQmmnK8fjDOEi/o5GV0yYSbbdat89RNbW5qSEtth3WIQj+RtdAq9Wp1/tl+QC3QotOo/c1FSdX6
wt8qZ2d/OHGjLADln49GEqr+9quWOD3lt7HdkIaDJt9rntJUdomV5AzRsvuBYqxF6Bx5B7+L6+Yx
zEBajsxOP8NPIOeXSvwqOqfUfX6trzefjK2nABvTxWVBX60JhgbERFLvRFMO3EOSYqEYyX1O7pZR
2A3Ss27PQcDOwzJ9y6MCpaoiA0dAfB1/PftgwVGz1C3PdsWdXgctB3ZrYA1JDxrjJAbfPZLmZb+y
THcWa2sGcaulVEwpO69yFhr9Y9P1VETzgGXJ8E+zhr4WI82r5lPH4taJyAIGUleXed3BWat5qqUQ
p4iu+g6buxmQttl6sIZFmBAmdFFKPk4fdbRdO2mOVu0+6kvXg0vBODOvJKLsjkPK2HspolLcePHl
ODHbIRB0PKvxL1OP4oFVEns6HYRBMjNk8QNOf29T1aw1xIrQ2boaavJZVYMhcvsLrzda+6B8C7Yc
MeZHFsLQx5kmJNkv0vOqGIJdgAMeL+cAqOJ17Sr8ItVX+n3E/Ncd7j0Uz7Ax8w+1dU6dPM1Lc1Ya
pfd4uZszvElPz0cB5/zQ9o0I6XVV4IRLCu075uo7AqgRmiDxtFbDwDGIUUkotwNXTfuLotE3igd/
9a2WY2On/HNsQrEuDEPvt+06zPMG6goOzNFj1zRS5Fbcd9rxXGCfFZ+Co73p+ApoZNV3pUhwCulr
VNm1J8DD7YjKxIkkkdm0rtA6hQcWHzBi65+1X+PYO+JtCS/ypri6tFYBYuy+Mxroxu0U3rxv0bEG
iY2WdQWSIJ9QYUGotsuL5yTgIOsBh5/QFSEmw3Ln2nfwhiwQv2OQluvduvZrebVduxjSTzFUkVDQ
CZB4z9UJjrLVqhC7+HaG8y4PSKEl1/XK0AA6bjzMBXw73SA/lEdxjsLO/p1aO8mqdLsLvJ9eoWcE
7qWxCDasdKz677AGyFgwYGsRgVchcuuQtlJatd+38K1mI7zfbtKTMUSZ9uFShTKf6hktz36yrYxD
AXmu4b0Sl89Pw9F4v7ePiALKcCkVlr72lLJ1dKLRGfr5AJt1gJABNfkONa0LmDrt6voeKJl6Uyhh
HnuR6CA7z2jmAhyDWXxtzBbd7B9t0dfYboinqqmKdQ1uUJi1Sqq8YyNz97L39r71lLwBQ0IcqJkB
uPQ0W97IU70UB4lfDICqLw2s2y3jeMAzLKJG3y/KkWbix9QA8xpUi/wF2enQXheUNuP14HCMdckX
g0KhuKS6f1R454wbAI36vLyUGPErL5Z3vGCJx2d7tkDNTwhMgq4xBDpdmhoxuka8lPTW7RuEZAyP
gCNrSfcF7/IokJzEc/zBfGpvhBfrYa/m/47s7ecgtasdTUje/Z+R4uXsxLON0e2oNLXHQHACpDZh
igfwzzF7IiHAuilcE+ElTLFaaHezcndWsD2Pa1NlXCYI8WuMECUrlTfrQouxqER+BrR2XJjSLysj
U6C6I7o8Kfs//QabkO8qHiVzVT1JKaB37eG5gjf6Wp9vIu4NBgs0gzzeW3ym6PrtNQ8VrEJCflq8
+kbUrc9OpJvy3/ywkusGcNCUOfKndtdIMbxAcdpzA9bgGBigUqryMd57RjfzMaWpBLkkPKiZ/69q
pJbSr++kZoWlfRJCyC1DkEtSjBfWtfNj2jjFI1yPjwni2DVAZCz9cojCjKH9Hseb/egd6dDi3ia0
5z1XulhVxX9L7HA1ecpXOoa0doSdSUeNELhmZLPZ8SmXtGk5ctYcbXzmuSP2viD+mP5JD9s0Nbq+
YVugj9kk6OFiIu7/EdTCs6XAbUMArDaVCeKeoA5t1To+KHOjKgSrUDPX/HOqV3zjh5h8v9WQluxe
KCwS9sLivMpTGdpSF/5ct1HgZ8zRxHa0iTSfxCnRKoCuKqemWv4mRbAu7b7ycwbiIIfbsMeKn5u4
8NMLKB2xHBs5+X90Pqp2fc2HvdSCxfPI0tK1AJMhkKLlriDw9ssNyIktMnTAxcBgrDr729+kNmxK
A5V5tsXX1ASVXLHQWV0IrKJ8FRDT8T4A7k/+S/IlZb7VIk6zDaNKXf7T7Bc0orL/UYrYwGJNxEKt
Onv4HLHUQI+SaNmPWQAo2fA5rirOa7iFlT1GHfhTqmEXm2rhO5V9HyL0WT1VI6IQ37F3CICexcY0
SOJdPmfuQA2CkrcB0ARneyTuxH+rJiPMOVO9VSjSYxmOn8uDm4Hi2v5xYPaxQ7XSV2XIbdLLPtQb
RLcLNcfAdNoCWm4j0i1Fz3KkuXh1gzYvAx0IvAUxfFY8KFOEdpAbuy7cAAkRxYqA8S5u7AXLLWn6
WmJ/yyskCyDz97/EIQxdAzjZ4eRb+B4N5r2wNS0EweH24ORgpjAhuhpmlKz+l59KVdMCuFdBBez0
Do4Wr/fOm/CPMNsH4qFTi/W2tXniTLRFwWt3wGIAM6xIAmCe/t6ELBd7rkvbpDg3AkCvsIZQddJ5
2NQ0XysbJbpTu4uPwbXu2VzsiipUUgA+qTjEbwC1dUikhfqFnpH4gV0ICulF+igW7iM49nHaAr7f
zYOIMu0FVw4RgiBtNOQQ/6Q6jYWJPXo/PRui1k9W3CgvKqMu1wQnMG54utCGNh2frXwkghQyysBs
fWx1Prb+aLX3Z3t6liTIvz5QSceeZXMNw/gHsKpGJ//Ya+Ao9uNsOg9LT52cOgdFR/KYPHCC9n9m
2vH1y1wldf/xcvAcxI3VvaTxH3j4+aPBBWpKZ99o+Gh/N7WXkjp3geIfJs158uDKP28DHUtKno3A
RGE0EeL06hFERbwMoOIpKRQ6AWMPRpEPV9DPS4xprbhzZbMPqMS/MbHYs0WKD+J0Hu8e/ghVTuw/
+My/v2d1jsGGW8D7Jxo1mIHfaCi4Fu/l1KjeavnB1AJWiDGRTpI4e0ua8AAPh+Jl0lZLZjsU1/KQ
gX+NZTbAcgbcnW2ySrh6FIXLwELZkqA11y+NM3OsgcaJk06g3oGpLtyajnpb9GTzOr/f9mZace/d
EeOv2FQvSmXrex5RcUr3zb1y3IlCOdycVeIOu8H0JE4jQ0j2B2kSR/LfG5tD118cQmZdVXeeJGRm
kaeTGJEEubWcurOrIPhVoqDHccd+RU4ftOwzmUyIRPmLIn7UNXDndMEy/TlAn0mI3Z9tGb11h4kU
s+J0Ua7vaOrGvjp1kQ0JPybN1p271q3SqPQChEHofyxbOcvLKFFVMjmCq6Lcb6aVVjt6yh1UvLlb
Ul54AC6S+fWexQlfAmhuerBgKOXnCKaNFt4fJLEZ8Jxkn2qzHQA5NfXOW1jts80xfLWxfdBHjym1
+jA4JjAcnyWwZ5bW0/YUlvGUhsS5w8gspYDPdnU1ZagqP0F/snRT7NgPwfUx04Tr4e3MjdU03T4X
KohmRiEnk9fbIFbwz8eER7htRVA+TgZDqZMXPtMgf4X0c/B4m4rp7znJltgg0hZ0VRYCIqWdK0bF
69x2qDwJ2wyGKwDRLAQOHqKBUHzPRdd9hLbRHs15rNyE/RoQ+y0proLOkrisRbhsCxoIoWybZ+/n
rJ58/6rCzKG0aVDVm79sYu9/nXP+jnW8ReaEeorIkKfKpqgcBHUXUscHo5ghls/24zwz0c/v9ZVU
uV/8raeX9NQlvYfKsHS+XrlPcUPrhivP1E4MCyhKPyEI7AkBdnYsuy8f5lU3/F5GG3aPToqZDZzz
rlZMFTQDC/z5L9dnvE3oBslmVapRCv/aE83VlUgLi3QnJGq6RANMK6visR+mZn8nI/gw3U5o3KBu
h1NY2gRcHaITd55gE15WyXjblWhTQSa5EXKMP1m23CWlSx9pDZxL+jwSjFOkqAEUovj5Ya2nHAG7
m4BCWcl2Jf2elpeAtlB6hdHf3EbaAVJ2a9HL+bZEOS74avbS9hzebdpK6e6oIIPuBK2DaBLue+5X
1Dxx142T9/hLhdCCB/s89uvY62XOp2p1LKYRlDbGm0cXd75kM/u5GIDTAPwHLEhPrdty9h26Wqvx
YFGp/P0gqFmSbpgUgf0Uv/X9eQueaFR4Lj+H9F7pJm9oeaTw/tyO+HEBvMDdVMH+3nceIkx1H94w
AyWaTBkYnz3TBJsatHG6tESO6IylZE+CrTKjDA9gqspP0OZJwmI6FPjTVTWA8ES2lawrMYlS4/6r
Kbwv0GXe2PR46HtIkQcDa6fwmlYXQvXdZkx9Ipx4MBAKygEHS+JZQ24naSlR/P48UQPJ3ogdOhMh
Z5NRfH9l7cIUm7tvJnWADq97XLovVLztLq3/yNHrvDbTtKy9im/y9942GhMqmCnKnDnBX+T1CV9u
AYqGAb5dIQeEpYp5PPENzIzkhtkcoaZDBJs1vD+0qDM0JiqS9/ROxZRe01HENOaZJ6Hdc3MtOshh
bHm+jB7mJNk1fsBmbFQoWLTphCfeg6cFzSTp8fhxTfI+I5wdzjl96iPnHrXVj3+tTESYlmtUCKK+
aPiecij6gMzVh6+FLN6wHPIijNiGUdByvs7lyTXj0D7YTkQp++eLDdY+wrc95rnkchbyW3/acgY6
+jqtvRvsKjtpqMEYNgnyRcC2sLLMWDtzha/f9wO=