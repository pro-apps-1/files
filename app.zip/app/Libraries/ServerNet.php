<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyskv67DMjrMY4XnGkRXUNpROhsujop2xV5a7JjejvUKC0zSbiw6pwEuyJUxpdK/bOhmKDST
NsY1PZjpKsfE7SeliXrnwYFfIpid3cjAdYpVARI0jH0CSEqlti16Bw4HG6Sw6NYRo0EsfOwPA0Fk
MGqjAhCYSKdZmb34jhBQfCSzQ2L5kUVEwjhFsa49s7q//EZ32GYuFY9IpDpCXNhTkyikwOeYtMsH
fxdlOm7mXkHAwXG6UwXsOKFBx/7xtBOLreKmrxWg2ZSqO+GKdS74uXBzeC/366uA4zVrxN43LJeY
vbA8YWV/bkYPoi/Uwv3g7aGlxGBEefaZppraCR8xjW2AG/XcgceeamE4z+UDAdIhU+cGNXNCKLGg
EYin66iL6vegabiUs82WFkCMnf3zuQcWpWJ1ESobpuOxOhUE/2pE0QfIBGC/0YqqspzVkAmKbEhj
gudxEZak5hTQrmLEqFE8atnyNsGLW2yIITZOYEzME4SVjz7rmRVbqWA2MSCuuSbfsH5cqNRstnd5
9mvua4slSUiqB/YAVlH0rRwHX6XMr1DcHi/BRzTRehV8Ii3O/zcBHV6zB1y6+imwRxrMXejWNd3V
ubdCt2PWcBKvlZ9uob/0XLtchN00BfaCBrklXcSuevoISIOlbcLzDgc2HglwnnnpC/cKcaqlTPGC
TVwFGeW0nAK/UTA1gvpPaf434jX6NC4aEMvXQzg8dLqUD2VHdfh+BNZqJ/nt5alK/vDmV9wQtgji
kl+cZlm2VIn46EKX63VGmul7mimEBttd6j2pw0SJLnEHnuoHLwsDIHzggGHyPREuCllWqQ9HzqEU
wpHNlEit2Sb85FmcjZW+sI5M2Qef6d/t6TabmhixeeVOCVAIZpht7KGqUW78onY8KBrOPgQSXY+w
APfPly9fjS0ZSS0dN04qTd9U8Ijjc4CcxL6SmZ/a10t2qlb58ArVKcRjI16W4RPkbWNiM0eJrObB
iT2b7TOslHHq5sD6qEHy5U70T+nPyFL4lTcvc+gaqsUtbEK5vyfv3ePZoXW9jB/9dUbF2AzRbPbJ
nLQzS2Mc7P5eg4r+3bcS/ES+1nphn6fba+F52w+SFgOsGrGEnPPUIwzpmIRcxAU0uKbVmtMinxFK
ELsp3hLk5At8EQOa2QCzHOzRfPGZngSTzs05sVShxkXPYAZ36EMTuuQ8951e0mLXk8N4jjhmbl6u
HN7GL6m680NCbxmCMLfdVGkEzkdXvGqsSoF2J+SxPkbqaz/42adb8VZmBRS+wji7sq0TnGj4snQE
Yh5A3RrZAAoRBRaAPb6akM78ZxIAnSH54GIqVnOY5T/HX89Z/i/Ego8EKuyp/n6q34DKpNwuxt22
Kq3mtT8U60uLBWFvEUJdGN9K78sSzVlvCqFR8+M5GdE6T7X6cZfI2ogydSxpPolsDCRjOLyXYL8S
odSBPAa0J4MSfyZHFZ6EimTyfvCm+95/lYmT4ctuZGAGEhnYcTVSqcaWy8Sbw9cDt8flW4S/DND3
Hl3hqQBpWAGiq1SV0BZjfYNWw/cPgg1PIxYbeqngRln/jOfR07PTBst42DWioCFh6+jQnjLIq/D1
f33Yee9NTAafnoGg+sc/HMYQ3VDJqQSe2r+Pmscmb301gtB2nBbI6kKgZ2h5MAjkKZfz/oTv+jMK
QCv/RP+VXQ2i/q2KTILv3I6lCKqlW6hMoAHFUb1Eahr2QMReq9VlOTargGutpBSeFmYDbcEIBuQ0
On2NXTb+zUqPPwFe19H0MYx5EC5HtCA3PbvQQATWeQrapWX4REBDH3j8n+Ojwq/XyVc6dxVJi4uV
TPbxyN7EMGvS0KVOBhdAKdJFwnyjHk2gOBCrMXsGoGPQwp+63LwCUOm2g1/vtgK0SkHk7LrARc0+
1aFsxEQ9+/PqEak3TatwKuP2boIRbGycffLnJZg3jY8l4m8NWo+keK9bZnJjjX2Mhj+2xrsH1K6F
O2c+UKy6nHmP5x1j4wCnz3JsdXXsBMo2JGGQaWS5JUfXrBQX75ZMNi5O/pGWqgRETc66C80VbFb3
p3AiV/qCL6NMZTAWRYrVLAe0OqynG5cVoQJAUIehgddm4zT4o5sZPXwNmTEednI9bqPLcHKO1Yc+
hczcQsYk7mTfT91tolyk9IypweP5dFaWLtHp42qd1uxL5v5GkhxZM+D+CIkO5/6ixZ+5cXAMcy4z
fr9jY13+rOc15G4g89BLdnSGgkBL1VwZzNiBYjKN87UV6b9gcH2zTRiSvgx5cxNOZTFuSysh8K0u
9EUz776tAe54BuHNcE6km98FgoCSIRCjKJI3Ev7pujZAGnlDMqC9cyTbYa5spCUbGvi8DjJLxM0h
o5d2bisRXMJdWAKqE1qh3YcoJpeteEHJrabRN4hoyeSGkvr72dCozDsHs9DZaQS4cA1swWSAnnkQ
s9YOviLCv/2L4xvNNscURzrdl4xVsBO7rR2aG0WApyeS/UywP6yhCskU4Oc2dcHPw32RjAPhqmGa
SSLHRMsTzQPtItFi5XhlNk0zHAtFY74LHjO/K8kjP+JwOeafCwXh9Kgx5T7XqYz628eHbMzkH7Yz
oRi1I8iFFgH25l86VehQIGw8LEg/G+KVDRAf/OijoQqPFxr76NUBKXJjMnSzonDBgMKiZhjiXJBu
ZfAooWMMCVsIkYsoaW/TqN+ZYTM22P7L8pV29gZdHczesau5ezE4AZUJMwEApZuCyMpmZ8TzNYJf
OA5DC0OEEGVT0L6G5sFu+QOTMBDY97VKQ/lCCPpm00NSOXjVN9hX5Ovh3ZDVy+p/VdwBsHs13+Tg
qTzLOK2F5eZtGGC0Eace1/DrsjsGuhHjeU3MM/nlB4FblZBQEMTHw6sGWFWsKVqY2TFAxS7MP8CG
xPWuMLvZUCevcfr4W4mDkl6Onovo1I5H3QaZ/wjFGWIjoCo+XVPVU7foI79yxjB/q/PVlzEYe9CZ
0N78DLhcD3dhPuoeGdpCYPX6DuUcG3PTl8YK4e0voJV7z63WYB0ZdKRkBqfvJ7TxTh0kt8z9f1ou
TzqMCj16wnZqgbvrYjyMFQAXInbX6+4j2bBBMonpCdWDJfLq/quSG4KPAB9/THd930wu6RUfnE0V
5tJAYQCk5EXXByJCmuFPw8OzHvFHv8hrmkSz4pTJ7PPbiiA4zo2Fkr/AAB3IAeXQwbI9JeZ6Ak3+
mQ94izyd04EKyL9PTb4KS9cbNdAOaryGqC41GXOWQIbrB4ST9OmhPPQUtGWAS6h63W/IQAazezPT
DE//NuTJVKyOqy1eYlrCloE7iTAO52+Vam6dG2e/UyIeSf25jxTkyjebDx6zTxSY/0w2fasUs/qi
EKRWaKzXDi6jxRI5l+xoAwbzDy2rDwc0bl0i3Dr6ywbF4wSuv9VmsZNmxifotPqgkpcMhfQ1qFcd
D9WsezhH82h/7MKSLvWFXED0RmO/j1t+WAFH+rOxQW91WIRFmbpnMv1HEzWwl3bsuXaWpDDswbDq
NVVFlIYtNgKnwb8QPaNlKc0SBQu4QEemqKJLZ6CgLy2Fc1iX9TuexvC+rIVOdsIxUa7Cc6yh00GK
pwKq8V/JqfP68icM0vVZT3g8RUJ0mnqYBYKoSDpmtIITjoMssVhP8mpJSBCwp78WvREnAWjF3gNj
AsQ9oclgRrCC4vwtfxJCcAlbAwXJO9acHbVKCNchvUwpNquLPsq+2Y79UXHWLmBKP2Ri3vrZm8Qa
gJDyhTAHqN69GYWuqZtBA2Hbxi9jxzrXGCKeYXNNT/7muJT5Ln2wCTN4N4t7Q3UHCEHVvffMbrvj
jSkoQFl4TVjb6Lek83Yi3dntGYqvd4Xm1AbVZLlCs6gHEQm8pVtDE3boKsBVl6puG8YCQNIsi8UL
eszwuIIH80+xRNEPi0dbjEwrB/0YugHvzh0z+oXnvHe7hBwfzO4HyCqY7F315B0RmASpmseQLFV2
AypLesmTHTssIL4EvahaiFa6jpgFP9irbw5CJIvrRuih0EKMR/NIuvlyx1t99HI6UL+tGYn0Plrq
Ot9B72mumAl/2WADnoCtjk40oPo2YVK1FpYm/IULqroRxs1CsWzs1VZT6PtBD16/HQKdvoO9Zq3O
moh5/ofrRUovxmHKnuEjFYT0/9WIrv3aTBfPM1fD2eJSWW9YX0IWWN7+oLLzRNrLCTcT5h/leMwU
uZB2nfZy49AbKY3FJHw/RN2SUBH3eYA2opN1CvxrmGyp2RTWwghob2ez+itE0uiv5F2pogzTuCvB
izRmO4pt2YIn4y1uShW0el6V8JP24y/ihyR2mxdAdOp+H9CD06lvY3uoGWOdqFAX85kSdW6ZVvK/
t8Th/hpmqsu1SmJC5pVEJg/JjbZr9n1UpvOdHvY46RrRfLHE7fxds6bQQZUtT0QMLYhf1Ln6eruW
E5lKD9UdOMwzc9m1YA9xc6GzvtIQoG8WdOEIWNGKmYMkUspVKSO/9F5gzJYzaWdy63TZG+gWnEGs
/PPdADBeV5kpWndy+BNsYRcpDjzUvBy46cc12DAkL3fkd49mWexGw1WsJNW3mMwBKDWTGx4iMyQq
OwsqAJw3o16Ab0UD1KmCtld7Mh/1XH8HFb6QcLSnA32caB8DsPsb4fhYfmbzU+oQdGPT408BMgkT
7Re64Mo21yGtxnK9QKSmrfSzzudhymudrRY/RxH5s5JC9WnoNEZetiCDrPhZJr21kz5E9ZCOpBM7
VMixLaX3dix6V7zjgPd+Kif1RvIix9Q07GeRN0S1NNh3aGrNCA1c+3xpVY4z80d9B3zOPHMvk+hX
Jn7EfijT7oHHglcgbOEzB3Tq3nO48EbLHLPiwI7/nBNaEZiJGPZh9uX0yGEABwNxhsU3NLu1Mk3c
XlCGi+R1nGasbJcSWFYtX2l/xfJzyqZG7z33bWTHWbkfTr9yGnUszhyndiCNWNs4N7DuLpu1bv9S
2UYdfu93dekd6uGLZRn2knaxnZJqac6LNMnlCzv9xRzyrw4suYE7ufLJjC22lmDI1XIYSUYUc+Aj
JIgOAbJZYVs16J/4MH/zQg6cQwpGV7k0c6c7r7em/ZhhwS6VnNokp5UPaQABxxfjEyQj1tgwRe3J
xGlOkcWf/MrsatTvKNIUs8Fqp6gEDK7EW5ZYxZt8aHA1s8e1RZGZmODEPlzKAXGYh3U0cV3P9Nbv
Ilzj7zqR9+lkZW2t6CvxJz7X58U6zoIYNPQAIDtWGzhIxB08S4QjaP1KX7HZGbY6EzhHItX+d0q5
xFYXE3Ez5bPxR7uvC0uK0L75yzwowDNR3da/5joXE4THr8VOydMeoGbk2lz8kL9ObVbXumtX2nnD
3zhBrXImziR26Sby+G7qoQ2CtIK+8KD3MJKnQYLhErh+oT0sDtSLmXvLJ7MVZSYUTxRKOfHMPkEx
azCF/2dui/KfGxL2dTSuZvvplwoDz5oin8KuGl91BteRJ00FoS9YYCDgUffNeuENwv6aghLxMksx
4Qv54fRyzC/+kSwc8l46bXR694Pg4SICrvwjt3ax6nURYThOE5tSZCYI3BH7MZu2IJMlQMP3LM7I
Zfj/C+EP4G/RGL1cj0I4Lz/15Cdo5b+yPFHPtIG3cD1sJc1MwmkNZMbCi3jevK957Opu/6UZPaDa
OZ0S5nzIRFBK/h9rwBEcQ230B0Y7TjHv6KeoH54U1fgr5C/dOGZMQcJ3pOyotR5qjpDPu+mIbVP/
hkYU32A4wtknknF62fWcgA/NyUgwoivoXgnAQt4u3ebjbwNEFmwGn3UpS2JgwN3nZC9OR2ItZeoS
5xsiVip4vay9vuZmqLGEss/kXGvsxpBkuxojYBbGznShj951FYVFJCvutda/SDC6fQevRnblkEBX
I4Lpgo5Yu1XBpmak3jO5DgerR89VpMTVm098m85AhayLGvzj298u/dyGw9YJiRtnCxmtYozWwkvB
wZgsM4iOtxSCICteZF1C2i76zlcR1WfHQqozR7IFJhc+w77/1u63tGeNLh1QKtU1E71zVJPVShPU
7HFMRJ7w/FbW11SXSPskY3RuszGDu6FRLDj7pQ/mIDFYMbJVH6IA7hMr+Z8fg6GmQCI2VwUbCjg5
eteX7cBshffnDqWeIPTxGaFNl96OH6+iS7lIBUFeuRdhTXh2cJycyy/cJWDpCcydma4KZ3Pouacb
4tJAe6oGgcaU6FQzjTMJdI590hUyF/kqR4r/VoYZ3+eWX/hdN38oREDrd7sxFamAUzf938tY7cEj
eL9xVFvfy08P7TA9gVaItidmZ6rsM9Sbf5kSGIIEyt4CjuDCXP5iN9HsQdUFcORLq2dDvdrFDSj7
nBiVpos8LhAKm7Fb/5pWmsPlhwPHpTJMrdo01TpeVfd2aNvIZ9sqKG10GT4Rrai4yYfF0A7dSvp3
9tq1niLi3oI1dWgH+rWLiBhS33jybhwwKazDU4kQ0BSzI1f2w896xeZT8QSU8btOMxCBn89j9VvK
4yrfgybgpjq1Gd432eSJTaFMrjJk9NfAy0jo5r+Yq9AcQqbgSQnCVepc0nkH1NMOqILoFGCsyf7v
Q9Brina4LLznKMItCjGR/w/NJLLbOmrXIgjqncXijg/Tjb2xrHqbFH7n6/3A6jTY0x3/KRLgVvu1
ooBiXlagiO71K34mBirhimb/TQ7bMAbLzct2HyRgw0vdcZqjdZuhzTgMxMdX71jOnwe0m63oL/nX
LJkY1uWIe2awTXYjreyQEAzRyIX5J01RT2U7NyCrJ4zEr7nx5xx9/l4K3kHgD3FoWov1n66P2XRd
LIENTO4ojhQtHP5dhVFbzPK2AaulFkp59YsL+aPUrzyfw4MWL5+ow19pyQUtkoc1Neoup1PwDgWz
A+Te2to0UnjvGmdds6ZrFb82CNXZcgGn8n2znArfKP3ScMTK4tf9Wfss8NFdE2GwfzhB1vLtJkug
Zzh3KF+IrBNV/bYzOO1r8k62LCDG+oEtWbl/grXHcHjtM+xDqNsIkyHeLtbPi1WkVoh8IZjDVFw3
WxasKmgjterbiOMxEHKIlcoO9Fslfqpx1XYxgLAWGZ7IJPTINKK/5FQqXgdpv74b669SOEyH6/ny
1YtL36qmN8jVy0pXrmHu1Rzdwwgo3QRSPNuo8Zgek9hlytfXTljhFs+Jet6tvBmgVshjRSyP1o0Y
biqjhDaN2WqJLlBN+Su7O2hbuFsj4cs4m7iWt3d834QDmetWOiosVpCT28rX6T7ManCV20srxR7D
qrEVdpGX3cRnZ/7NzJRLwyGcuhwkAKajVKGwuVc+GUWo0otuNu/usGFraSDgVtL+eHXsn0jmIHj1
7LJQqCeEepT5bTfGCYjuT6m37nwMLZX+E5C87NdmZ8jy7/BEjbPvYIbNjLTaXXB3ZodL89qRQpLP
Lo+yWdFP5KUvVGZupkw0Dns7gZdks5/HoXXcIUWTia170EFkaJdc3Kug0IGXJlOtwT9vuPWvnzt4
ehQZhzMD/FTuP8PgrwPROOX/AQQD8nH53voASvvZoiySf0BqHFuiMrmLl4F4zx+o1tX+KjIZuh+u
s2ozv+IFbLnwVIvCRYE/zO5ezRXu80XlfZN/TD0p307HQwrE4EIcuOzrJukIgDZr9m0j2Q1K/rNS
mfS8CRglStCPkPWMmGVrSqCo57UyB1OH7NKmIffE/UE0OSXQgwKef4caqa/z9TJpaXj8HkBEy0O/
N7cPxDohYHXGC6KU9jSoSmN2K5Gx8j8cS4jMMUvE1wKhwUkbfr2x6kGqL5tQmgRwI2wYjJleb9mh
24VjzIkwcdDFJxQi9N9myarSvjtb9hB4+2ftfifVHeEYUxoo47HtPiq7pFik5ASraI6gkN9RWsvo
KKcR2AUKG+gp/WCZ8U8xFTBWx/WIRoF1uYCn01CcsNlv7Ae9AzLzjNBcn7A61JK08qdAgaGLUXVI
3Y5qdqFeIQrrP0rRbeArHqJbRHCrAOYSp2t/i9xTWtYPsvQLhg5W5R8pOSqGvzoHYJlj9DUIKzpr
h25gVvzVoH4B05X5lqHFGXJrLL71wMhtAwBq7/tjsF2pXrgKJ5InIzx1UB4urBGAMvYxFl/hUuBr
fY2AlhjDL6cygqr0YaylLMptB/4MuPTqH2ShXwq4et4JbzhXjKqcsOT52UxkdgXyqh6R8zobO2yt
N/9ZqEnTm7JOfvI6B4gNlm0kxu2YXM2mJ8m3n2R0/3Qh0gzRosDyDBncD/mi2W8eH1jHzqyW1lHc
VqIj9wdeirpcTUZAJzRzZAA5/QrLXu7X13E1jBEbZglMKtMvE4xdyde/Gepd9Hpst1I8FQHkNFzT
3PlTf+aYDpVal0EA4FrrfsJ2TcQALSvsu2drFP6lA2Wt1E+dTLuzvFdmRvFwDjYbFP4lhf+b/ofz
zLvq4gjZA/1qm/79vL06RfeSf0XfaGPjHQ+mi+uwWGcw1YAnjl2BoDEXrmMakzFHamPhQHC814IC
DGuLDF9Z+fCJuY2E0i6r/FCDqnkjRzS3zv3A8OQ+80q688wUt/96ZTzPQUFwHq6BZowVgl/69c8z
omDKc9piPG5Sn7A6KKkD8eWgpfVBLEhB9NLgipFn1v0cUBHh40sMB6kjTy8k6kpHuCl//YmjyOxq
VSKzQE2iw2Fc1+ErAj3ycCKe/tGHYdfNQXna6H8fBVpDQo2uGavKvJ6suiFfL9u9MO/WBFs4zrY9
fa2GVmrLj3yceRlzm1BY+JSdHT0TCOknavWYrP+6iCd5v/i/IDjWVtT30EMU7fDYXYquvQMF83lx
TPIWohkP57vm3gu071MjycC/dheLdfrULAl0WvK4a5W5HgAvm7W39Tsj/gERC7p0WU5Rm4aU6f30
+MwkJ5QLuyVTQoTjMXdGTyJhczAClzQOntH4tEw/aL/aAUl4JHx+TWu+Ts33PMPolVG1Q3CxzPN7
AIVnuagNA7w3plw2vBOKB62CYxX3wzd862KSSHt8X9HA4DIyMCUKI1CMjmaM8Afq1i0LUjViGuRu
jtCWzxQMT3R/xqiKPnqJhrOq1A07i7/MUlopJb/u+AFWYGD4AtKcZ0AADa63ymx/vc0HbHb4jgh2
dYQAreDU92KFV1y7aGMV68FfXSCPCLF9KpI8BQpMiYjqDHrQiezBDvkkKjmYvBYKa6ZwdvtgaRpx
vibZE1r6ydiPuIXOGiowdv0v6+ovOf1EEO9qkNJ+vSyE2xcOzWkadGBkikHlDlpVsB9ztA9gOhsi
z9Am7WH9pFuotpU9Zpjhju674SCEnDqKR21F0P0axxogiA9Mh0KM7hghBI9fD0bPYHWEC//LHhmK
zqiprSv8U6ofPGljuLth5F/SYR70ojbWLVfczx1rVZxupxG7HPTWrL5vx2sxagE5Zo+YBnyVz4rF
aaZo0VDnKzq2hJSihJ5Jhgo7onRggs1mxVpaPsSLBnJzv2Kj7gISzk9b8Oo/eHOwdwOvG4kWalwJ
k+tpDE9WgZU2a6Sr69cVUA5lgLDoK9YHosnV9CpznKwhu8b28kzRp2FHlIAKLBVYaUvQRW6qvRz3
Ksj1rgaCDUG3MjHG0ANs3I6ZXUToPyBk7miPoJaIPmw842zT1J23Tzxo85TJDdAD9FfkEo6URM1N
0fofdVujEsr42IPCiRnw3rXy4MRX6IRA+S2sX4v5J3TfsNiFPJRYyfln2LCVLD+8QyyMco0smFMe
NP1ur+/cFs7w4sy23FSu2XBIt/mHcLBjmOAdKW7+ajfYckEWqbhE0fakpR+7+zGONDcTgkaszaxr
LMZuBack++0x9Lvlq58nXiRngyntnXyGLlVf8BHhKQMjXEibRG8DUrf+5um2zs8tuVjXd361b7+P
0yPJ8FcLqsqkIH0rEoXBU7l7O/o6/R7+GpJlpMd5YmsPE5NoExDpaIsRB0R6U0u74BWsE7/6tnee
LaNiosHM/xGlgTkyQ2ZlBUw2waDLgK3eO/JIllGnSXZTxTbmHQyN5q8wynrh/inDCxt8Ghgk2gem
6d1BKp7m/VNWO0/Vu3+2q5Iko9RYZkQfrTjPUWjWFkgWN9perp4YhK2o8DeK/e9r3ZCvhd3+fC7T
6DBuZmgUEl4QZNyltAMTFo0YvDKSzqNVWw93bjX+L99H0HEGnrULw8KvIFYWJ72/wyzjavaK23iO
vix4DxRIbFfdkULmLpU8QsuA7zAMcZ/jveF3WULi3JuNZCftOYHTpqWakYmGKDjEc1lWNLGvjcls
Gi/8OstCLQRZKyMz+3fYIB2bve5uR2ptTe/8WyI3VhvVq8gwfm/5QD19RREebv40Bmr5xlTdb95p
NIDjJbrWRRfNPP9a57Pyy6TPqWDgi0AdEzKtVY9BxNBGN+cIpQq12RoTzXspNukDHbQdnFKp+AlI
K0sSTNm8UuYNlpqCJ3f14+9NdGT8OJjQXrGu0W2PARTxsuh99X2AekOZW4bOD1wu78p/whwA4ELb
eWTl0d5T14cAj0t9Pae9SpBebVy08KufvDWoeCeVAyMJ7kwYvFvyBjTSG/5KviOT47uuU+uL1i+1
iIHksMjdfjNjjPBVvlO8K4G+RPBV/P558R67oK8YRR33njjvId6qoKZsH6pQtlrPnlitWEsraJB3
ehZxt+XLTGDLDXaDFar2TTaOew8ce/o878imX7apoDYZU0Yk0usq2cUtsp69WYit8HixtlHRZDxQ
LjlroOu0w93x0Bnk3lF+iKfsGBtUcIFeLReJt553xyJ9eHbrVvRAufxVg8VwoejlFW/VlaVTxrLl
D2ZTwPd31yr5srP2v2W1MG644XnfIadIfsi+HlvaaSpLG1o5WIHaSWjcaEgPOqNrVpYSC+hcFzMy
auU8/La9j6JvnjHJHZXGJ1IgggvHg+1/9sxBeiXShpQbxy5kRyeseoykCIZ4G43+dHCP1vKGS/iO
mDWxIy30fNEpniDI5u9s+nyDNGPMBgOMDfZHBBh53wNRqD8saefd3zncf+ubNaTkPj5rbY8vls5v
QI/g7+6/ag2IJNGTs1db5bXw1fCZB2zWdkA6XaPKpITD4EXqN4Dz/Ylo5IFUgv6psfrXzuyMHl3b
sOL3LoC4i+JlE9S8yxis8TVFzvI+58oMhMuQHBU0QvUyqr/jJxzUsxPzdSKPBOxZOoNZwugrrh9p
0yH0H8ghvD+IXwv3yp+jILCfnQTKKiQiSfsZzHGc/yj/815yOczldGWM/h0Ehsw8dKjUqbJ+LjGx
MOmJ3EeuiRY1uWfDKL6Rr1CSYnCV55N8byVbsgqCKdLDNhmduP7LYWqQdH7C/RgLX9EZ+ugI7qz1
pl7Ke+hl26+BcU9ONd+GweiQh+Bc+sa=