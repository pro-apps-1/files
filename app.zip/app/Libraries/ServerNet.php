<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+isbZ2opMe7Iz034rhiTb+lgoLPf/058fEuaKYId/DXJuTipGExtrnYR7Gh7oTeUWJzNbX4
WH7FGzM4xbSLHQW7eY+ZikknuxBSQskuO2t79afrU0SAquerI4hRHI3SCRQuQohjMhlAeSO7NG1P
9QpfzRWPLkGbZ++57sIVdqKslEEFyRFfM2WciyIpLjIKSl3jvRg0Ly3muq5yQXy249KQdjxklman
/+DvWB3aTlAMZE1fEn4g0dGAPnYLZzfnNJzEfBZeLxUYiG0RuwqfsmxzasXeE/pwt3r4Xg0+61X+
XGf3ZmDqz1V5H/i54i7rpVVecUYh5UtsvU0oAB0IBX0rsGnHwRO3R+WkerFACCNc/Q2dJKXkpLMW
U9fn2SIkQ5JufvIG9K14NOwJkS8rmPuYn+QEkz9rDoyccXk47jlQbhqjuVtAVhDxeu3SVeizCRmj
+xGeqoGgQqiXHU3piD5J6tOcf+2w3Q3eZMoiiY0ew2RRWvvJIIoBLDI18+nle4IOegSAfKrYgfLq
Vjh6+T9r0WR4c+WK3qxXWkx0IRfSj+Sq6qKu7pSsJx0s9ZrWrVukg6UT1hUc6kJ1baqRIP+Jr28b
KihmBQsnLuyoIbZHaTKgXWDSiA/QKfP36A7810/PubQ2usladLuU6uR6ujv/TKQpkPC0HZkkKEpE
9JlC1CPWcGSNHFw1db4n6rrFbiZ6HMONzwllQwmZy2yXRsnfRLZF21iO8v47ESGa+ZygdiXScUAZ
/dmza/NKz1p3rcj5V7hxQ91M5fnhAVr5y9l/8SN9urdNVAwCYriGxmvx2JIJQ6UZ1wTaGk9FeTIg
O7kq2oVsLUt3kQuh6U8dgQbhGbjjT0ViKY+C0qxug8VvA3Y4cyrIYvE93/KKqT2oGOJfZYGKYElV
iBY91OKTdgOx9JriC91iEP37D7E+vHPbIJwM3e2K5LpXizXMYP83uXGlboAAJsyUiHf3mUYhc97C
A86UZHKz+1pFxFb0YEOVTlzQlT2Tzv8vzE4jr9e5xBWjHXcADZesYLtiz6Yk1XiT8YCHjRqPUp20
6bol1ACk30gG6Ja9tLOdZsiSRzOjtfDy+Mx/958jaZ/uzQLNLGgVj11NxzGMuGPmDyTd7QW1srQw
OHvEoPcri953BZy8vhK9W8m13Sfn02fZwFC5nUHuHPLinkP6RlkQ7xa3k3MejW3PTslbj2VqAbm9
aq/3D57+r4xQAkvm3WbRMzUbOte9rtVfbw8FnEeBX7YfjUQ73ihDOwM5i2A1RS/o2ZVtT7m/PdC/
8wCnii2fs2wlKm94Ed6bupg81U17Xis1v59AZwboAOwR6W+tRFaCu2XPGc59/ucUCsTZwcHegAPs
zZvZYsHXyMX7PXOAL69DO2nCGIMk3wXCy2XBHqZeBSiRSbq6MBuoo1ZROMSIAvziRJSOBNdHBTEi
nQxobynupNejsMGk5iLtb1gCP211gmdp7GgaetnhGJFQUR5siW6ebPEHe0uFCPwahObBbzvCDOxv
FHUWuM4JdT/LrkHieAKLEbNKLOZiMNyaC9o/lvIT6VHqh8cblRYCAzSvydn5ZbZ87ooj2X1yeYCI
9w6WsutqoNC5lFt6wUObVoqcafdQmnUHHgKh01hM8ggZUunsrwpWVTdphdtXARVd4Wjth4L2YF+9
kVYF7Z3I4OiuhyLkodLb1qMOCK49n4duxng5c9YONFWPcrNoNK+JiRLLXnVlC1bO+MtqnCV13lkZ
pAfK4ZuAW8zHDpN+R378lOCjYt258Be6C2XP+HAj4R0Dc7nn1CuPsAIbFKhsp/tRvDhEWxe7T0wp
KWIFdBNMQ4YI3B/8iWxkEp/g3b9m+eaJv9YO3k2IBfXbsUoFd4ri/Ie7mA2vkPxrtrZFh3gSkZw5
f69c+i2iSno3GHzTOBj4c4/RB1wCMnR3Imt0RYfPd7fesuCaxZjt51AE4pQBXL3Nom7tZ7YJU5XI
SHHtQ3fxxpUOhtf66ixTS2dkSACipRnzu2SvdjSzGrqaKIfi9tYsSs2rQEt8bLDY8Y7DyoXRFKFm
yLeofgpsAhNC1FcLkrTZjl5ygh+/ncbwpMI2JbrSEqpyOOjbZoJnU7tngiH1i4owu4cXa0kGUYOW
e48E6abl6arXArUqHq5Y57QQeAD4kLx4MHpTrrl9p8mwG/PetYZZ98Kpwi4oEvmjRg+BGeQjw0yv
eo8LkTVmg5kTZ7rrqw6SvzzjvRTWLpcPjfpez+T2KgJvGKFkXtZ62CqtS7BWLHMqs87hJj2xXPo0
tYWW5I/5Vfy8YhmR3ykNIXKdHyizQ55w128QYVfYZwwO5WEJPujEnLz4MSQ3JY+uYliH0M8fSWNO
9YWgpSYum5SC+PbEosd7dTnf2f7rDP4SOiS1noCNJrCnfcAYKSvh7UYtUpkUQVO+wyq2fiKWP6cG
WGMqBMoR+TkACTR9SY/WSlBNuLvaP7+PAjISOHDyJKh4cnouD8zfmrS/DUSBh67KImWGGGwNXGwK
ox70y1nTyB9NBLfwpGAbuGRNiK5dxYT98Ep/sr5NQRUjAFhxn72IMvZSOYy9V6MmThINQviIPgU7
bq1ihmLiQABp/u43+fph5WFRFq9yn416wZADd/i/e7t72uX1eD3plHADqClKplE54vV9bs9HuJ0Y
25atbezCy/RDl3cZT4KjtqyrssQTWVvS55UCA2qMUt/AK8xB0HfWiNJkvTpqlJ2tOK+/4xunvLFA
n7OElT9BAKgaS4t/kkM4O1yT5PNLwbB7CQd6eEdrRRQ2xcDpfGLlh3KG6jMQVyDD6aS/uKbn52P7
X/6QsJPaPCFyTG/5woVIujCY9bFBKstelpuhH775PhlezePi57FUdW0dFO3dBdkxjBx8E5EuGEk4
JZPaf+Dz4f+S1mycsid7xOS+vo2/hNpiOVc5qfFGeHGZTa8N4UwTOP/MSETs9x7WCeTGeqcDp4nV
AxgA705Q3cP4hDWVLt/4CG1yilMguXWp21aZTp5uh/APnEyUcguwzrN67F7Ep29JWZ1YJgQNAhJs
C8CvGZl9rNUuct6mED+eU0uR6/U+sSPCzHxMRcn5kASxBquvJYfy7FzZ0FQTFpsiPof9taGUzAQS
cy9wSRrSOZM51XLExIZTzVlIPwU5lQZmtIsqcDLwFxtxVg8/zk3SgBBEb6tPwWylkK3EQ87jK+3w
ozYEJTlFzQnM5KA/EL/vn7RIOSdvbUo6O2yRPp5k+IlbZZDhdPjK+mRWqg7hcd12gjv1dTPU6ZGV
+/QmaQr0dnYfmIr2L7x0+PDx2tKP00RMLqJeoIhuzBHKIK0Vb8htiEahdXLxYx0UIjQ/3h5ugbIe
p1wnOKOm3+kj0InG5hWZQXyCoqv3b43AIA2cZ5OVEP4p8PR4VtJ8xjzfewHGQtDhpLHbLKctyYin
K0qwn4RlAhCJ/ZSi/xfeX4Rl5M6AgNoh/VAnAVmj2ptiJRO1V9P68SrRRtYLEaOZtAxSUGKcJS1C
j1xGupM80RtTagkaDj8NNbT+TSD7nhwRzrI0+5o+hNmBc4ApfGqLf8aoq8DyACWZvwDONxpucRWZ
1xpFhJM9zgmBRgvG4oJoQMo9ymm59hSp72vj71+c8q4mUMWaFd0koumpyRGAImTg7b8FIb288fES
7nvsGSEWfKVvQqwVUmm9YXNNzxRmvRk4veOv8IaIKYS2GobfcczzZSWKez1SjGlsXg0G0fv+DINH
/sX1Wg0OhtlC3h33sa4tB5vMEJezVV2MhAAXebjhCHzp8MouJcToOYR/WEaALIsmKF2J4QPBQ7d4
OnBeVNdyy6ISoqHpTsm1CGg5Uv7+P36cxZA+c9Hoer/5erPu2nU4h0+PQpvo1CQn9A/3Q/0LrNpg
x5fUQGV1pmpRSnzNunwgVM4G9UGbXHQL8PzDbkBREtoltbKqd4UQlhMcZ7FsQZJw5ZZu9qJLPRzA
n/6Ifew6dEer22XasHDoDyMa9vbIV7/28MJ+0CHiC3a9BDfiQEVT03DmdrIDz9DbH0UnSQOLFbiq
cjvhqb63yPET+sZc/ctg7Q+Lq36kTfyAr+NubBI2dhouw75yTUXqejnMCXS7CZ46vH3JG3uAYij4
H/7Q1kSIO07FUVNn3sxYbr7Yfquu3Uc4k8ls2kyKpnsc+fjxnv7ry3UrvKib1kI2cRqCe5JrTNBC
uNO1aiGbsTPKXOM1olg2KsE7GFRD09wjfTkwo68qnFFydi8jMJtlD6eCnT7srxYQTK2R5h1SGsrT
5dm07/8j5edW1Oyl2f2GsUJ/b9YeCqQFxcrGESDDt3dQm+JQZRqnc0t6X4WnkJJoEu8nlGtlHI56
4ebE/S9O21p6bKj0p4KZh72ckrxPdg9dDM3R9z9S5wdRJtBu54lU/CU5n2I8+ybKXXZuc10aRuQh
sajoJK9+WpQZ5xkFpg48Cfe7/fZCFdpZnUShxGdxXtYn8LM6WH83iZbK3jfMAlEPGzwvGmIxYFDV
LyOJB6+RnAJBKEPIHxJFmDjJxaEFBPJza+7jDW0rsvR2HzJc5557qzVPJ+tWwqKmLR1u9vvh2ALt
BOmukhCEIsCsP3Bmk+8MM9MmIwI6BgbeTXrSajjNCSnBkC1YOkIoHsxrMbofZmQr0jVNRohh5y35
aXTMltook6NUJ6gu4EXFkXaT+KsFHVB/0nux+Xy7Danj1vMLTtf1WBjMf3Q070B48m7n1M/8a+qF
Aaeao1xX2icaSv4JPnNFxRq2t5xcWioXjLe0ZmGtLiaZSsTKCcK/lVVMC+rkAOJCEe29NHN3xEeT
UkBjic3DxksFUYH6c71npZG/8sCgsYib+YeEU++MC26w7Hgey48U5xqhXi7W4sXqMPIDyUoOBBBJ
pqMMEhcFWoGbUvtZInf3JoSQZGCIjA9IDv5UyOKD4bKolzkpbmb8Lexz87ZrK2VtldM2rzxM1aKX
+jiQV/PXtgHQVv7/8bhPhnYe0kbiiwL9Hlj80i8W6nsLPsEUIVZSMSB7txGwxhIsrI03kPmzmryV
gWDKNRetYsd3nP+/EtYV4IlxCOMhFLYuXRwjOdjQVjGRv4s5SRR4WbwTVFLLkmYPXdrw99SxhoK7
Rta3g+eHmscwpUWpbftXxIoNuTw5dDo8y0tNxHFhuXBO4jx/OjRKzWwWFlw/x8UEq4OseUGK7GrD
DuK1yl3uOiIqEWM3dNuCySTyGLHLrSG1x9GF0KdcH1RuW4ptTgUdptvtgqBNjYaC4wdHKX4Rxder
M3fGl7hZA/bIRE6JL/dtNr1akNk/efULuM3jBSnRwLHa6hfsxGBlWnvhQ8FlyHyPoWM/YFbKeo9+
ekhPVFNFxUnAANdFBo1YpuICyy8IpuouXMWFezO6FhLk3CmpN+sz/IYe9njNPTOqU0C0QjRT/H4G
GIUsQb1daDJUwv5u02RFZR0FLGRnfpUYVSruoREW8eoT1clJMJGoZL/LA9MDGorCMPyMMNNW/TBG
HM0MhCLAKs/3Sn6T1weIv2XP37a8/QuOYzlK6SiBB/aIeYx1UMRUCN5C+0JtH8tWg1Zg4+Xf+BeU
t1/E4AU9pnbECQ+33iVhY7KdDZlXYxzyp/qT5bYIQf+ecJlir31DNAyO/uCtd72osP0oIo/4q0mV
6Kernj7axz1wzJ2Oh8unN+HkkzEIrYsMJdDqz5U0gF54bOJaZrgjHjFCBp1O7Hrfcto+f6TU3EbZ
a6puUaE9vBu80tSOFYqoBY9TIWBY+IHPKpPD3HIV6KUcifvMjo3FNiRnCLLzssZEJgoxoM/xwRAZ
1uojJsOmlqacWrHYCn9A/3LaTAierxO9Bhro8Tn2VlkbUwKq6Tt4zz1MQEBz3uoBuraN90t3qWWp
DUzio2I4csManMyPKMmYLJxtzH0h4VUXPuoxLD3J+eGctM2DwL4x89PeW+C7fvrio9kylKkTfuXh
OIRQrVsyinCn++v86NIEwSiNfHasSfc9u+djVGJrYXCMDSCP2e0plh4loAJEiPTwwT5RlNC3fTXs
1VDf5yfArv3+0Ehx55OTFvFLhfga1Gy2XBf6UcU4YF1Z+9ZXIfLx3pawJ0VqXomSg5F0P7bNmZe6
00+oN0fDRvJsNqIX6SzuXPxkUbD4epHdZHreWi7PljM5LfjBw9w8aPDFl+21NiHv3r9vgNmCa8k6
1Byg/tEmSqBIt2MNu8+aAy9CxNx7UnY+Fs/awzhqQ0Hdy+P8HF/CYvckrvbUS5rlJLyumLMwEgav
oK2CSSqsKwJ+IwMlK0PZjoJUAWfZkPwiuNDJHbZ/BtKqrE1oAPGUdv1lWncNsbJBH5GRttTM4HGv
SdjKiv3ir3xXLk3lMGmVowQkyOrKJivePHVRrEHQqrSD5niaPsj38Bc3NBq6iZ9EEH80cx+YlqkS
jvga0JFwIyBM26c0c1gtiWZtUkNtodJAmEzuUSg1jXgwyDLVdg4+VXD0xqOPNk8q6r/9B7CVyWr1
LXidErAoOeBSCOMK+GTVZa6abwKv6pQcc3gSH0YwRZkGks3MQxQl96bgEa2WoTemygPOmz+uZy4Q
rc8jCV7nUfrm/pk2iEk7UFX/1CmAMTcEACQc16K9vHex3WxMdjSscKlR/iw3mXBn+CYHYhEFsroY
7bFtjljbajTKfUx23LLY2rHRzSfIwdeUminur/aX9qxGTlamllLVtkwCgpJqs1n28bFsTdJGSWlc
v/ZwZ9pQFeDKl9OeoKTWMv0QV1Cprd/wgPZ/EuwEN2qkxlvQXc9/QVuTJ4VTlAQMkDI8UbLnMfR5
JY49/MY6Flytec5z7kQANbfGDbo0mC8o6Cgzg3ajIuxsnw1V5qIyAgiGjK2oHj3B1go3zYMZNgwF
YskFwFWz0I+LB/HBUBGUkIo6MrbEEnu+7cTOiL5I4A5fdvGaNnyGXv3P5PUBYAfAu9GLh21hfvzT
Gkv95UyvlEO9g7QDyQicAbxUQYUCvFQPs88s/PTQtHaqMOIJOLswTDhuoBrlzUQdygXeApF1aSwC
5a5wyrbDbrs9omFpjxcZWc8hFT3LYrSnqCbcTdexMRoiDfz4nFTZ6+swdyDb3uS3ZwxG2qH3K9sR
EqvY8V2u4yYrxoZEkbSFdEusu37UsfyLdJQAWDng8v2Cr/tJJZRYT61sv+6ss2YDqabEAIE69auP
PnxK2InivNol3UAgTU4sEthdH6sX1Vh+WHFTegnSbix4i6ffX8C8zDRhj+cHZIGGuO1DN5E7XKrT
u4g+6AJnpzQItYNuAXiiTEId6QEptHfJToP2J7RwiHT+2e10OQJtl+wAAcxZl4mTVGulhE5RjgVv
GKpxDGi6jOajk5lfHzu2YMVzGVH3hXIMzTMIBmj1sHHWi5pfdtY9pAr+8Z+stqyx081kBNL5TqnC
SWRJtGdl9Iy1WmRfcAXvJ7S59BzGzisTwlUgBUEj559CmpRYD/VyvlQ5ziSTp3s6DX/3fwn5XfBj
7NoxTrormddxYMQJS1AZVqNFD6JvFrIB7mHrxblqZwB5+lIvRrTt6zpGOJ3agrcBEaJmxw/0qZGz
8X2JQQZCrwU9SpkXNkTccXvOmyuKrx5EZGE2u6PoyBHzlfC4J+w7dFiu3WGz/tKvAwTX09L6+C3d
mWatoR6qDvYBOtxgWnYH+7+axvZ1d8bw8PYcOjxQ1mKlYTuI19W3OFjm4vtc73csn8WK4uTarlJb
iwACIzJ2jFbMQglPyeQQ5yp7bNZoduGjx2OTwSZMkF2GtqiqsWZ9xmTdJWSUUdmZ4ReLp7d2TXSo
iO4h1mkW6WLDdgHJiakfYlrdO8s4LcOiNfRoObhH60BFIskz/L0NgixVF/6746rKZzAXmqYzxBb/
RwPjzvy9Y8mubIAU3lziNEhgA4fw/UbQbfOQ8umjKAv2VefHNQ1N+FrxcS9t0hZmnnqdtUjiURuj
IQ9HxjtA1FPzOzz+8xZ48X3QLpv7ID0wqv16MEVnVVZEovW4IvV3d3zSk6YdD2+jT4/N+d7au9JN
6ZwrOViVTRSnuCK3+0OEOvrZk7Bm1aDTqCjIbibrIMlwZuBU6Xog5KquwYwrAfRDaOTXI7chsmVL
QTzCZ/Q4Jc++/Uz/QAup31DjGYWAt/GAvybFK9078Xb1iMRzNiYlFtbZXZKiRj4G+u3nAfckH29s
//o14ZfTmZDFtRaqbgEIeV37G206XX57NW92yPloQoiHZxDCiaSIyDYPXQSYOLNkP9kKPqo36PUN
5zF0bAx2uf6GEJyah9tpMhtBw5JGXOIvRGVGBj11E8GFRFisPrqF7RXcJSxy0HQ6Pw8X3sjnPp9R
e5qG+g6l2DjDBUl3U+ejAaBuZC44C91viQ5cmp2wTQ7KBflM/TbnnX8/A4/i6WEXisr9OCGnXse8
Tb5GN29fRxCnnVNHJcGGyJc8DBoqweyBPgu7X/eZimyBuQ1oPRpopdvtA0aamiK5Qlf3iCA9KYr5
I79xCv4HE6wM8JDEqH0D3yE6+zbpWl5sdOvxtR5tBH1yzs39Q7Djbm67RoDSOK6qtAIUCJeXNu3J
nNrs+d/++I+GLw1uh/9NCDochbfjJnMfVBISen9KZGXWoxp3SRsEwIiHJYDHR4eZt/osmPjIVoar
GIHMVa3xra4Kw0Ks0R3GdSjVAb21h0OdoM1XKVHdCTPjqL5SGvrHTQ+CbeJsCMCdK/AH6xFuwVLQ
J9BVKeP8hQ/IMOdUckqOBaY6zYTnXwU7aIoNVmmr4MalctoYx0Dw62WaEX2SfRmBHKfT/L8tndz7
jS+935nk70GL5UAIUD+uhIV2HHDOKZ1j3rBZ1BlR0CFx/RfQPCR3LaYkekIJxUWIZFQYU2Vn40fm
NdopK0YTWGdkXFWfTnN29m7FG+vpXcORKDQpZzFKMOcFuPiV+i2ft0EoZiDBf2aQpTT4Ox54U8VT
QZM+gAYP/6Q3Lul7KS4BoEEsNJ4wpAEsKvfSivGnC/zyGCh5ReT3pH7C8SbKEpkSKZvaG7aK/Zt/
HdoNGHQuzShld9KMICglNeglPAzTZbsW4vNKKvJ7ckjRIikUG8hPrM4q9Go1PsGX++XVum43/yDl
67Mnkts7+bXlyhyVCZ6LWr5nbMfMhpIqAKN7a+WMGVpB9RP4mEsaWev5Jdgx0bStEHUFN6Q734Ny
oelU48cQZmP8+7UjRHoprd2UWLT8NHNHuHgBiUpgop5xus9O+ckjOfNjg0oRYB5GfHGverm+KLN3
x0RvhxmY4kLfw4OhXoM75SpuNLqUhEalLRSvb6MqpJfYkm1Uupkti9mNzxKelv8TTvM5nxGh4r8+
x3lyDmKcaaXPiWtyUM04D3YlgQJHByY3fo8e5V+Jyc9GeccO552AZLUXrdgmTj7yWyU3xUMUxhgy
LJAfQUGE5lBaSKGu5rdmtpISKWAQJzXH3Lf005YP6Z0qAnFqH/tiFiY5/ajRujrD10suU28k6E87
oZdChuTbVxT0dTKHPMy4zfnlBakRUmIJlOr+q3Olr+SZQolIxAHahyknpBoNttbvHCTNjOQwLY/S
smeH1yQgfK/gHIH6ebAdB+RZtQ+UfXegN9DPFgVuHkYPtP7LamBNHvcvKsa54FeD3w3r/DSDXBqV
TvxM7Q6bFXUl7HcLGwQZB4jbvfM5uRQvFmJDyEWSm/UG6BcJFxYedcXZvYKHq7RrFkVRAFkavlDQ
XLSde4+z7G6XCClvLt7LWSlP2ipVMlnjAoXgFVqTtnXBT7+B9cUBYmqUXjhADLD92lQNRCVlcxX6
oaxcbxerUbcSHEjyEUfDNXoZR7U6nHHey+YUk34sbNsF8C26HzIYeDOB1aWDeXE5Bes+xofkc1rY
RFbyjwPaHb/ibZRBuPiuXTW4yEwQP1zvnXG/WdvMUR5HmLVJ0D0ghDx7S38CIlJlIQCNaKB1UFD9
GBD7b+8mCnipMOJLHZBzhePl6dqlxMEjkY6S239Kcq2+bVzsMlZxLc0Aq2F+jed7rqcBI3j9rJj2
PZkq3aBSzdsh/afnERuTcDE8GONAV2qo9+AcKHIYmZA8dBgtAGNaIp+06jFcviHSYgfvX/c+rG68
gUqGxrggYc6HsfAWobF+7n/P4h/OpdV1TV3BW69PCN0WxbW48pFfzdQF5mYanFOUdpyY9uJ0wlBU
pKwVHfpmRpujGxNTjNKgyp9ZSkSZUlCWy/VyDbfe+fnTnfRYoJzw1KCmoFBuwVdx9Hpmnau4IfBV
0YqNlnkvi0FsW/SqSM9UyTGWFaa1OUnV5oH0HcNMyV5QB6AFzhkbZqAL2F1iZ562P3T82K7ahFMD
SOyQCEgaz58acohkknjEeDINQ+WZ1gBBHQdtjp8E6jGorbWPDWPtZujOhCDLFP1dehLuHIY5y6bD
YvlMM+0r95XICkFj+HMdTfyV+1Gz1VfQcDSunxoTOL2oxHi7BzL9Njrv7ZHPhAUXnZkmliD1+wFC
6wl5wfgzKKjE1J9XFa+Cz/t6iFJPMyfBhiMFNtRiuNV0PNl3fGtGYAF6QrcX6N6G5v1rvhhRJHvL
aWQTGbq1OYHPf37mJ8jD58Y+/sVPLWRwNFRIhT/HpgUtaLrtWEhWNfqQcrCpIDVtaCPptco6NxqO
6N1NkQia+XdkwKCCuSpTO1XKsOeD/4h54OyX4syPPeNOaRLP7tibt2bb56kTO6YNCYHD8BhwuQ+7
9mws1p14CLeUIPBdP1i489pRSSv11P21Ii43R0bBhh8zZgTyeM3+RtPR3dMLh7sIXfMasBjfrEVO
cwL1RwgI96D2Or6QIG32vAcGzKvhP6cA4Wr9awZQ+G6Zcc6I893QZZZ0bD8At/vi8vg600mJ79Jx
sDs7EEWhZl9pm1iKWkSEst9bDY/THeOnGC/7waFPXiOE7akbhiTDGibxJyS1mr+fSUHickuYgjiZ
mu5NOe0rKM4Dtk2akB+afb+iwDizs2bJ5ZUvEX/zENs6pMEFA4RGE/vmoVw5aWWUUuXTBhPwQP3v
jpPsm/WGHy7Z7Q3MGCD1iUsVU0Shy/IWe8C2oPB8pf2ux1xOGj4stGjNfMOB0zEzOCJwvXFJzBcO
SuMgBhGKp1VNB5d5HDxYAy8doxFWeF1/98OXD7H+YD+drCoHRVokbYjcv6wWn3YC/BFdwJF3d/td
81HYBZVMberKADDcB5O+ZUi/CZdscvjR6hFIykb38LklrqfhzDcj4yO5VPOiWPyCCdh+bBfnglb/
nuNUazMf5UkI02nh9cAS1S4//oC0Tu0XENcZnmpHxHlikSQi8O+HnHtnLcPL5x6lvZ4c