<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnc82WpPGeyZf52VBn65L+UkMslKYkfi+xUu6wfryiBztfRv+4CWYhq+RHD6MjPMvTuYnsxE
9OQT9z67bMC5Wrxm1CyOYQY6XOGAk+7xbRKOmt7fghwT03jVTNxPfVHS6BjFG2VvrbaUGMpYkLdC
mI89wES9NWiYTmDf++zKT6wMl0odvP0hFbCzOKOB9+XPkcZmgHBY1QPIV6wx+MJkuZMJ1+bhj7Z3
nLoemlfEyWhJTPpUiFeAd8C+eoRi3nvlveWECHcsHeRqKnR6xUgE+EdiLNbijnuEMgjqVtNv/qa2
ncfi/mm0PybDbtQu8ABc3eMdv8ZqAv7gKC0druampAK/WSc8fuSlkdECxPHm43w4dKIeNoajxTL/
j8V76uSJLFH5rUbngC4YQqXTDsbW4XuH3vS+lnv2FWnaL8AIOBIjCCdSuRnMxhih/FOEY6DsURyA
57JpZAtXo5BFmO8rdkb4n+xqjdbE5mdxjUdBTtO7HcTR6R5C2/TI17Z84fT1RRr51EQ+Q6Jqcl+E
vMA+EWRPjKW1RMlHX857QLU62Gn8QG50TVLBfYfHoTMQCgpq7Egz4OTJUeHnfqhgUHaMaYM46Xik
ETVuuk/T3UAvT702vdald8QbSByrHL2L03fH4tNlZmrG8zU9AN4IXO0RLPkGv7e9fRkgIhgzZZMe
TIyNr5a8VLzZlCdu2tC+GScgtOXVPFxGm6Ie4eMjtApVIdJrrIPu4KYQq/qm73vU4KNZzSA4zegD
KqbBTnWECIORduivJZD7y51VZRnrFca7NxXx6NpShZ8WOmCiKzaFYhyXJG2GuDVPWlCp6QqnX99b
x3eZmM24DaBzPXReGszqhho2ArA1YM5eObpIYPZOaV8XyTQR5bx4IUHH3usV3ZVD+oYnwkaXAOte
ZEJr2OdDDRDh9E5DqSYKtTMxuF1R5BULhAZy1j5cW4sfazJd9bTP45hAN99viSunLGdaVRfTtFRp
dvFxyf7+uoNoBFzvH170vf9dt5/iMPpPv3Whv/W/Y+e/A612izUuJ+gHNndn0yTXExmzGS6dixxw
54py8cQisFlErZZ2roqkbNCHDTRi6hThPrGsQr+FHzxtYZ7jnC71fZ26alrQ2vmq5stA9l2UyJ2p
o7ZJ9lC5czWTINiHBniErGEjpELy0pQnI6JTKqRRb4du6dHe9gVuduNodo1RsGP4jrNXmcKfTeiZ
9W0+CRswl9pIwL8OLKNw7J8ePgWrDtKLY/v8IY+hL3++y2Zb40T4W0lsAEHG5eLOsrdOAVQ6aOye
sh5Uhn6GtjBrx2TIhMWU7ivNGV3AW3LCJ7PqHYxt42DC+cduug4D/vjQMfusdQJONLQzP9kMPmqx
pizG/AuFc0uTTJs9RlTKgCtfty4GIYyZBVRwOWa52Fmz4wNOeWw7tu9+W77bV73T026cOMD/ynOl
R4awkk0p/xcZC4hwYTAfCOhUx6BR2T315gau3S0Yb4HVf3WcwyF3uPzelOgoAk1ulqdKUzU1qlf2
dnFMld9AZOH5p0OGSU0ae3C5vR6kGRkNdVwQefo9TQbZIABoMy3yxPLzNCbMyoai9pCNpmcQkSOA
OtWcjNWz6sAaM0yxbooeSe5f+cGOpBr2MxqMUR5S+++QmukVXLBO+ZcpQcBNiyQcGBl+8Abm3gh1
NED4vaelCx+bCb5vMeTK7sOaL+0H/aYi8teddQhkj/CCIJ8cDdQ9xuyBYHT/tMZU5yypXB79fvya
gA7pbwJhY0UtvLs10rnf0GOUCVCOCze8HpJlBtSz+1sY5zSzG8rBx2WOc7Z3Bp5AYcFZDlQGr2lc
1X/nEoyprS1CPoFLpdDDW3HImf67G8NybhyYC7g7LNczabcnOllwuCUdtSmdHqYGfUyiIUD7rWT6
eOXepBzWFIRHuteD0oxj7Lr9cdTNyQHtrOsbhvYtMWz5Bupq41cB/CbDnjnoR/ezJ018ztZozfoc
DSUnVnGF3eGY4BTONMqtajFevz2FhA/Vl++KdHP1BXe91J6RfXQ8OruK6lyoFYpTmfqcx4FTS3hP
f3/hN2/hRAnxgP4RiZk4mQuLkvtcIyIS6TW8iiR8W2qLI72r0shKJMcO2cPq2k/eUv08dtEblUhj
hOwQpCsPlotUzHNRwjI6uHr1aFwXffsr1uhwU4o+QmwcQfUYY0zBQfK2axiSIJyVmKMbIXdT6Sok
yWDXFOmBJiuEX65FS7UFhui3EmsUU0i4swqENVVTDm0SUkpZQp9dxeCW+bKB8pDGXncATo6GYtRW
+NB33OGhNWLmG7q0FWg5+CIKc4V/5rEyAB4pioDjrwLmm5z1jCQDp+kPj4gzFJVoAKp2yaGxgWtq
HrcREH/8tv8m9+o25z5F/xfe7OHN7SL3HZ+JykW2/eVTXLBoARR8o/talLau4rhxNyvsJhN/nrdH
5dG8+tnJpoGBKuwrhMcxPSiLB5fO+EdbCCHiveV9iQddqMgYZj3FqDf3PsK66tMQzTvArjc/ghVe
yiVBLswS+ObfsIq7zyJ4tLWG3TInSl6OAyovK2i2syibLkociY+w0r+1iXPHR/RFBovzRMCDz8m5
Glww9kV+o92SXMkiDgNjejOEEX+eV7YiVr8tvjKJnpT2BD/+ZnAXpHzawqPrfvLJ+PBsjSTJ3ajU
xKVIEPjgqO6wUETJMJLWJW8p62YrzNVBv45eAHFtg9d880rVLm22UCxJMnR/UgBnQoWWq7zfqgNd
bFImEXno4boNHbZWrlP9Qfy3kc6kUusQXYvcnpJNGHGJ976gV49w8aBXcbiIZDqAUCPis53SYRHa
S7n3iHZN1Kgyp/Z6LrQ6UCQWWkrFMWrAvAxMcOLQN1p0UCwaKQwDhtMgqmNjgwWOHiZXO8zjLLHL
Tt8nCVXJTYyDWZtU3QlgEZu8ay0Iubu7+N8tIWvxnCyu+Wi+LCA1HUjYj+/IY1VQNFArY6i6kLQs
Rcw9sf72p2u4fv+91NLgHONLWhoV3Ly+6rMwka6YZp06v5WnEWVxZDDwYoBUPiyz5C/qWce2P4uC
vCFbT1bOIhwS420KUElgRiC3/m8PeVTHrAlqzJ+7NLs9s04eI8jX17TyDhrWv2M8BSqLvXUz204B
6eppWj7mp0nSwMokv/SxiCt04QT7MZtb57xQckB1g+qIVZ9R6/NRIy6+FlaaV0zma/ePB2+9YtOd
DWNnQNaulHo/Pfac3icl59NOXvUG7uccMSgRYuq97d3MNk4aeH+eC8pOnzRQwaG95CnqetpElZCW
LvqnUAy9TnLzCrKtjWpHqQKuoClkm2nErz52JZz8TC8wFv2deYHQxGEE9Nuxd+/POaQzWqg/MfwR
0gjH/Phl1EpvfougcGpKdCzJLLkMjRnEvnROnAhza3ZwavMYH6YTVHSnpCeaBICiqVTzn7+cGAGj
7h1bK+/mflAiS63EadaKVzDtck0iGTisBvBfrpkpp3sB2iG0HNG1UKMv4FK/1NotEgjeSJYZ/Pc0
GCCplNe2z0VzzUcKKZwWKdVVS6dYxsih/phOPEDB8Q5fbq6654QxtvMHL6Hxr65bxUDplMyihmwd
W1NgDpWhBB1RO/aNIpJsCLr10qy98uLSrIOF6/FzfuxZtKSIowBJAkTpVE4c9JV4FpYjbh7ydWB0
t1XU1KzCJ+hc08y3wcHFnTIH5hEL57rQj/ikEEGAjSdggzW=