<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxE26KQ8DE9fLLcCPUymMq5iiisDGE31sBUuXvF+RLkn5Um1vhhDuZ9oH/iVLzJXzs0YX8PG
VDTkNI3NzAOremogl6QQzREvL1JgMT3abkbReFOrOGQhzfgx1ni7lMgP4cN4c2LIujFMNHhrhYaU
u57Ao/BtbkeD+/fcVq1Z4nongPPRb6QEGWd8Z/34LHMmZydcyX6mftlpt27stmeu1oN24HA3hK2t
M4UaUvJiNIXDQ9LQHj/eHreEw2yXrRFBPmeXZfHpRblOCEp/A79DslgBttbkQnbEynytmSma0ypg
vyiwtFA0I38LxF+zSbVd1VNBdKBYvlQWryHXFlmhulLVUvwKn+O0STQkKUF8YQRk8swm8JIbw25g
aO//WrlmyKd030bHgZ+UPtlyPXDXeU5xb0BneoPFO0fxfbhjkEEpuHcEbEivRG+2KcXIj0ZHBA62
HrB7SD8lP5YudJQ4HFfHjsc+9+QIJ8xe1uF+gGxRD0d/2I+5en19D7X9TAReYTlwIPR8evdb/fTl
s6LkgkYNlfx7qCGoPHnvC9VPNM4MGb95G10p0DdSMe0Cp9KbNn4YgBxqdYxfbjqh7g/drqcQpLaO
7qwHi+VP2NSo+icgUitFr4V2+khLw4BOcK1P2T40OK1GuNngm3QXUUZJHn+P3SavLL7nCZT3UP3R
bWjXAHpyJnvFAOeAXOQgLKdEyd1ewYZvXd/odLsPdacrsfjWkTVezbwtKURM+e3ME0ecC6KmEu/a
L09Vy83mOmcj9CMdS1BIM5wpyPLvkIqnGZ/0jNJe036x+Q5dSVSQ9On26DMqcWK9QjYZCBzLJE5F
Q7dwKLikt2o5uAFtDoPzrtC+uKrNgS7y/jZuXwIMIdLTk4iJ7QAnNwWlozgk8PBR/vlH0cMGMszm
hnHEU+rQ6jGgEivfY/DGCnBRTLTYD2SY4d0dQNVUuo7i0lWbkGU0wLgR+oU/EKTyq1asi618+YfG
y/SD1RxB4w0HvYYG9/y1/uki5muDQu13usqFVK4CDRaEFNd020hTlQxf4SZbn73+5ItzgLee+Sf4
RuufmaTdIhWb3PaiGY/iyCIgTDDtzMSBBSO1ELdVJm8g2wdSAoh11LXORdKtMTYnhWtYuWJunobn
UBN9ij6N+VGBMjo5yqYjbriNyBJJ6G7tqB3mdWtFYX4HX++aD5XOnPnWgsmzwjfa/THPyji/SUv7
tIh6nhrBdZe7RpNwbAqqCHfbJjInZsrfol3a68v9gr16gOr1SRZSffG9+HTf10VIFTOeJilrAgTs
kegOhIBhC7Tt+IE0cHOKSuPKn5aRNRwms4yUiOAURMLrr95aQUIv+3be/sREjRLJpbXX9fmKBurk
Bidme/qLXNxzDUpPpDFgletKnrY4Vz0LkpgGU70IswSlaI2xIPy3N4ScN7fwTyJ+SiLX46D3T5S7
PSFqqnS3XfL9L1zSiP5Lq6Dk9gT/ftvQw3RkT0AGULVGay5lSubhnJEkTEUl0pRJSRvFC7URqq9q
9bkkDqlIsB5fZGF/LhFpuWD906I3nF2hbK16UvZ6KwisttDI3Ovo7xzNy2GcKJIAIeZe9oe755ru
SC0cUKtxkz3ZXQNQtFxo/0LqRpdj49yYC7NKb/eAuA17ePmSUNdCCMjIabzDZayWhpAqzrOsglAL
nbsU2ZKW67SEgckivIn0oEu6VKIGgS81Ikxkb/cFM7/VKorYr4Z4lQx4Njzj9R58wShVmeK+eha3
kcIRBZBaih8jDElG5VVC1oQSaAekU8nw3xwhKNF6PDJfaMexRCGYz4G4u0b0z1Tsym6GP5275Bm7
gSgxOn4Guj6gLxoYgto7Rr4i5IR6Agkhk/6GJNDHcH9QZAcNY17aKByZiCol2BUI7UeWgTWQfrJh
Vy6r/0Cj+amAcoQfA6DlTbcCmDgO+WgHL1ioIdDOzEuh0lh2TptP66/EIR1G4DGlC+s4n5IO/VF9
m4nWO5aVMnMa1eyPGsYNhKIkbbmG27Rsd2ncll5v2LxGoqBRwvMGPwvmRq3xCn1ZgkY8iBjOXXol
z9X6LniHanjd6vyx8dSaIOK6zMsfHrduRW7OVYO45dc/3cgkJeTo7z8z1ILXgmswwUgXs6VXznZt
3E0hbkKNFPKc+9NTPBAnnaz3Lvo4ExNLNIt0mJg8QMjK1OCN8M85xNpVUnomBTw8nYobSDpQ+IxL
WpzX5fSO40VWv0Ji2hsWnuprfm8otBic1GGpU2bj1/B/lwAidZMDQjoHzgrXElVyugqel4HwkeD+
VSJt12bTk4deFUZXUHOwuejnLtX8MFzaDbvydsVCsThcxKLCvItpG505Yss7w1n2OwYe8buBrLEy
g5u9CZk8xTOupJJ56jHA+klx7McsBbS60UY6JbCimNj/eP22Zo7pob//SWfpGa437pPC7i2PqvKh
my80PYdzh9xwdfDeOzYQr2sJKrIU+v0ZcAMDyAA9Alun4l8Y1r++h3M+DlsC+SSAPsC135ST05oA
WrosDluMuw6u+WRLcZlZpmxMUUeQiGKoCFPSuBK9GOxhRs+/uiH53ND0RU3P2F/BaIntwHjYRxKN
pNfoKNxpuNG7Z3XZu2AvwxZaotOpatST4QAZAWyFV2rhum9uWy8aFL04SUhlrFGlXUE1xohcFpMR
ScB8IVxKrksK6LuntGOO5RI0xqEc9TgktnSDNaE4ooYqdDOUTEIAx0D6MuClb7KTXk/Zh+V1b8Xx
72bfW2mx6TeOPYV38jB2lF2f1J3Qxh50C/HWTk1vrOMZ4GYNYR5t3lFRZMNZvQ1gkeSo2axKbA8T
lrKGjydmnCUCPagTFuF5uz56bEqYS/JxNWPiej7mWDGZ65wAo06mQe4rpCe6gH25j+PlqnmuVux6
wIMowPa2aEIaNYoCMk4ewXvX4eXS0U9XKjeAoRRgav1cRwPK6D/w4z3o7ElF2NrgEf6h9QEw5E8e
U0S77BimtB2/Ez16yKQteBg2Y2PQ0D+q/GkddbGilDHDoKUEE0CdV5NOxgd3S/tQzvXV/mH7Neer
NYMAj9siQd5au+IBQySDYyL1I869LVM0XnkHTvuvHDPwZhC3RKX4QF/LTDO/Y7Uxa6J3hDNBmyv+
TTosnhyv+OyG0ZULevMowUVJ99tdhqXF+ucjcX9HTgMl+cjZuV9eKpxzMeMQ89Z/9ldN71EwIfZt
LHJdGVwGPoZeDMy5MxivEZ3WYCjxXj1lJLz2QmmLl/Dah8Jp4EwLQXpUjWUXDN65OSlFdGF0cay6
9edhm0YVc4yCWaONHMc0TIgBEwt/F/t058YUzahFTESTATZQPRrAFvuuy56aADM4HA4rNAMClpWF
I8PBe0RrmM3B+3fYJSSkNkV6B0tae/rWcDt5wrz5xAhaqHttJeZ5JFHXQRf9RC1fBYTFPTW9zntE
5psSQHlFcR0VXO0n/msW+4rvrTtFfLHYtRhxKxSzArQ8HPprKoAt8pcV1FjigA6Q2s1QaddPqTno
sIOiFWblkMFfXFxTeeDe54OUhZHej7fXceSCy/xeTEwV+TyDr+h5Hg9euk2BRWKp8TwcWRQTqMQW
c38lNy/QRmhWAYRIcP74h/Tzg3cZBq92U21sgqWAapM16JqKoYtJSK7PPvahVTgpk49cKk8qCdHq
z5TjDGRXrhAgOD64y4CuJqeJbsJG1Zl/HSzuZVfmTwbA8cGdcT7XIGtnODRKJHX5zzQqvInz0q70
MRWgTpqGBHn5mVnbu6Zcj3B3yjuN89vD28DQ/DQfNCGVqxCPfggE05V/3bHIrDCam9sDaUN5Ujok
iC+6ISGrx8fGpVYMD1Qno3wiYC3UJ7iJMHKqJNU3qUzKYXtBRnWnL5EBVza3L7+E/mD0HirBVMre
z4MN3ec2hiXbHOLwJPMvrzc8yrlrSd93NTAU+LP6Zn+y1S7ktBQp44gCVJJxaD6JBeUMvQ7B6cTM
YDvciVPIxCzWZpIwvhv9zwj457ShwngYoiDBWxqUFns5RLt3zkO9lkE/x738LqTDN92aR1kwS9RV
6Bt0fJu7gY2fKKwRya0CN1efBQQ1AtsCfdq+5CubwNtcAnh6cR3qVergVoKMbdaziVE+76v9eqE1
9TuqBiEmH7QlHh5L7caJLHdoCyOox20lSyBTIL9LlVkL3M18myh1uPxWCU/S+dH0L7kCDhEXXGDs
V+JxJeJ25viFKH2A7NkGYuj/84i4gRlhCxy3ywMuMKDirddrXoL6x/8c3ONxQWq2Tn2CVkieOof3
67PKwfUUiLoLn0KHUSaeOhGJtPgEi85PNiZk3SeHjqYXGAxKC9CN9kuYxlcbdk0QiJ/qutON5GHC
6ri+5ifDv6/r8KAkbNlG0DvJKzrEyWlma6ZbaIcEgXG7mOTDvJEiqB7SJzod0ViJxBUnox3gfm1V
7zWH+TDwIaiNTP6p0z8kEpRiqr2ejzEOV5IaMnVfYdaNlm8Ifk/AwD8T7GHL9yf54VSk5oDuCvWx
C5SO19YADRmDsV5WKh5nyX/60vkUxeRzrTD7ZfKbLXl1N+zExZIIfifYYk4GlXBBXo2NBoGCzCEy
Ff2MT1n1wudDFyH+sQm+UdN+6fl/i6qzCaQi0v1uv6sSWgKXEszWlEJmrB4R4Iqm6Twb+IohAgKg
/0VCOPktmGwg7/9CrucmKMDKjG==