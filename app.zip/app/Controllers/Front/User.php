<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwep3xibklEyCEYQc7VHHFSWdBBTGu4PqwMu3FBZQGl1M3XtsRkI8LVJRvQ4C6wzgu5vbUDv
19GKYlLuwZyj0mYItcc868Fch0UxyTh00K9W8Fvi+9V9DZa626vMYrCTgMAk2nOOwGS8hN1qQx2y
TjaSh1GTLRJVRBPT2IPAsv5D79dm0dmER0R/cEui/SIJJCf1VUemKEHslSzfVjUywvgtpK2E+FV2
9YGHi/pEKqrJc8zuFN//kHSJ5Go0tuJ+3RgN1wkSve3f/SmM5W9QCEVAilrer0d35ImdQpcl/KfF
CGju/p63oiM+SfCCNfiPy6zoikiWLX5ewwEVxmu1DMCmo/u80PABB2lR3uPjhrVgULE1DdfmVv+O
gkkTju3g0yuXjWwlSvE/FgGmlfYKDjDpiC05bNehiMOuJicTKw5ZT6q+76iSVC/s/D8EivbfTZt7
44Z3vk9MbYZBtha8QFCcPVYhVa8wHsF6CeWFA8vN4RzWqUZI7Pao0SmPC+6bfwHdWbzOir4NYLg7
yx2y7PYRsVmXURL2FHkgyOeIcjPjKS5R/qa2L/PGu04zHhIT6dlvUEHtL4lDiiwm857coyLmfNA/
GKLb8N9pVytvW4oLXx8gM0SrkDqIGOIldV9OfliMeXF/NAU9Elm335Mf8FCEz8bCyXdXNBiseFZz
c2HBDKcPhJJ1i7systdkUmoVJuZ+3e5J6NMNQVX0oMgwIUdBWPEHEWgxdT0AoC6LucKUdekJsnCi
vt6GvdRp0PnGrFNq0szBZ5Bp/kt+njWKYrkAm790NClILZWicosmCZcuUAU7soley10elTaF+Nc6
ku1WDaRfpqSt9yARsNaDWztrlYgRLCZtYlDhq/+xNCp5uRHjL6zOVIoutCZwF+g7XjHKn5wuU85F
YwIZi2Hgo44uMOzc6srkbMuaRry4MxoL6Q16hKNWXZqnkhtKCbQTAn30rjebEDX3EljFlQNZucfi
l19M2Kw4wGXWaPxOIV1EAYfV3stbr/G+FINgZi+sU4B2lmq2Kn77Ce9lVVk9RSCNuYQP+eBP3hqt
9jKnMTnG+EJ6h2nzlvpe6EN5DXfz/iE19go9HpDEqi5LIm8tle/bb7n4jdN9jLifiO5d5uu3sAbD
jAmKhaqZy9UpdMd0dWfbCZ/WIrowXVS+VHDgzK7L4kL5TvcVGNaocBYNjH69MUzJoUvIasmeOGPp
AonIMmNW62xPUooN/mGOtpH6HJjLoY0Mu562RdnE+gd1tq+w5ubdP3dUZOlY/9R8zi8DmhTlmrkH
Bxh2siXx/8Bg1eqB1PESdEoo6sF4OuU/cwJkj5Iti4Tu4Z7gq3GEr9IQm2pT40QNcdYPILWBoHsv
8i+YJ/92qe03iCNmN3CGf4vOWD2SQRrGKWVSSESMcoqj7JSb94GdHLUMSgdccV85J1GNMU0dg291
z8oMhUC6GpaQp+iC0ffEk+TUVLXViOLgl/0BzgCAtUkn/SPsQRwQV8PNweOOmULaqTCc1YCXE/oG
Wa6ocpcMUl9RjgAGyBdToE5gB138qC10iV7RyVgWusj+usA8gCDp1k3pWlN+w1Ik7BYvXpq9Vp+u
14sUwfTmN/WDJ1/8N8YWh119GaI56MjBZZzCAbJ0/25P5mWblIlfHRIv0CqgERZF27qJDZO6ZH/0
SIJGOkEVPZsY4ck2jdV/s2LA2n5mkGWV4uxe4kh5lphibhU3pEFhX7jkjsJvSxlKXUHCVNkZs1PN
jZOV99KbOWzQHaqzWFmkq5TyM7AkbPy+jZWFbIVRocHuMqB7grjWxSPedQKkYSirPv6i7jK2Dtos
KdspWLVxGbplirInbi6Uh8kOQyoD4ChCJ18vG0nK6KUYXMve8ME2/zJuDEpuJJd/GC35Ue6OMzTe
jPot9pFYWThGwJOWmnzsbArMt5pu5FUO3evNvA4hZcRM4IpUclFnvsG1b1Uv7jfJz1Dd8PHPPEZK
ddpfMzyWE/8V4lpMIw5ScDswd/1NAXojQ5lsCNk6MwXxu0yDw1F4fBpRKl+TMfWxXXjG02dO6pN+
j8cjAPF6oSnHiLNVU4NQl8YmMp92czIZY/+rjMyfdT+Nh3uGZ46ecSzRuM0S3oAQ45Ud7iDNDiY/
3QN3dX/Hn+xRObai+xHiWMU0C2y2CRdWVNcDDqkfBgQQPNgwb8HlIzeFELWgHaUzDhIalMfh105X
GbomfQJM9Av62gxy1olFv5hgCCi8fKsFepXadMBEDFzf40awkXdMe7H+W8+ft1QGP8HO6849YEP/
wfInY9IN6rxJwiRRnkl2WkoCGk1s4HUVRJ5g4gBDcFgR7SBHUnX58sdRMGZ1oM2dRsVnlEoWhLsx
1/miXRCUDynIhZiaoaPapyIpmaK4EHj7quB5XkDESa+2bUp5NBPGDUlLC0lz5cHGFi/vA8/7S2WC
DYDSJ0I8JvQGJXlV43BZ7Y8lrd/p2/1UJy1hcA4E4oknbrIa8CrpoGW/5eZFKFntKGsMCeJZg97W
Tkr7IsRX46im5WDUajqr7pPWLaSoJHhCIBf54D1iiSSr9/A6xzF1cQkLwtks+grwLjjY6uZLZyy0
l4/TZADOvRBonBGXyFXweLhTc1hqSd3a69fvz6/DjDzzTVwVO8Ea2jm79M5N/tKjfxvNs8GlA2yh
7H17eIJev2ozLhu3lFNH6UlsLNKCN7nRAXJDOxG9SmjuO82krB5ixOvWLarvcWkiSFByPM/kk361
sa7uP2NWPUZYyw+orGmasA9CkHz9vzzo9GZhtcpXoPhjnwlhrf3857q1c++65DzyQQ96j5KeXwDq
kHDxNDv5qLlXtu+FhWZ2c+OSBNSdAQ5BOxliCu3wfH2Bg49dvUzKcmOPJ+13lqk1p82LQkrq7ov4
E7fQt/4NfKgXJ4jXPsQr6efXJBNAeovLfLHKbHVfnpIsZsxIoUjtQ4kQ1yJs5u6Bnek7TrBeu6JA
qglpM83yCD3h9auAlnytGrMjrjuE0bI+rFZffMkZgMtRvpwXlAFLSPkKnSEFOJAvUHIHNka4/Dqj
DxR1JV8jZji1uMuQcoKwoJJuGm+DPfQbGbf2ykkv0bqHBznCs4cY+L3bkgUmz3F5c8GrdftLKrpz
cCxz9RGG/1dlawM8g2hyM+DB8ebaVONGYdDJriiNI3lE0DbAauAnOR3+LlJYSE58OAyfxNxX80L/
mxeIf/3qGJExmlory+Zqqn/IJImiOCG6ddbeX7xV7zS/JEQZi8T4gyDqka8x9g0d4Lc/Fpt1D44C
hwE6qM5ea5KMNV5VCY9OA30+yTtK50Cze31A+lbNwI9kWOXH907NfwTNr7R8DeQ8RpO/N+fUc5fd
YO1WjESm84IPYDDSgFARKg/ishPW9kv6FS8TWDleqfYRd8zif2GF05AVtWmdQge2UUplzFWi/nJE
joExm+xkMK6GsZwDC8z2cx5BpuOX1j7AhjdI2twh8HnookN/P0i+mxn4gYv1M7nl86n5UUdxIfxm
EyOCnqonXxxbCOjCrzcai9l/3dAIe3HykqaNO4JJvxO0Zn0LtngPeazXN8uOQTK4qm8vACH7HxN1
i5qTGF/C0FDCv0ELAnAt8fHRNIgl7QbnEeFuXIi/ZXjSEBZi+XkR4B7+n0kFW2tAXX6UJMLO8z8m
W/mM6FSrE3NEx4mi/1RbbVJJwqOfe/9fixcx6jTXu6cdeX28RdmYpxabcDBy9n/fDGK1JNPGDy7e
oh4Y46ASCYbvT+uqj8uP4av+j+ho80ZtisnjlVRpD49PWy2ytszYxk0pMbSvMlEKM5YPaPPM2XnE
gy7t7PaOtyzTW0fjntxtVf51ayfNFReIwhi50aOwsrfiHUzW6ubjq1I8QPVjbWbnl+bY/PZ+aW+R
JjT3yTx4h2qRZRGkTIGbYfzcuCh4gOoTLbOml7iYgCoxK0tVDngTOVnj0aC+ZnJJE0+lQXvmkbGw
+R72sTRrr9VtxP6MDs74e9VFBltedfORexpMUiFdZZ0Odx0TYmnsQc/9j1QxlyzhZ63R4F3lxvQF
M3h1FgIgVBCaJ9xI5JNvPPFYRzDI+qNTx6LySaiSxpc4WIYzJ1kXVqqUo2lXAoI9CLIBAUO4Mb7O
R4ZqBFylchCeDGBHkU1z7PNy1TvbbJZNcnI9x5LiVFoOPpUk18YY/o/C0UWKqCK7VIcH6nEUrVJb
nCVq+U94SWY3YVXcCkIbl9FVfwBSgfymyHhffMOxvMrHfCDtNagtPl3RFtppPNAva60vEmxiGOmt
ZuzNQDFMBwwQxY28NiC0dZhkL+sIm4l8UxXwlP3n28J7MCDSgAKsJVjdfqX9u0MW0IhheqK1W6Ta
fQJZ+6/HcV8fGCrqbAhZ6jjv3IwUgYrDsg505VWMYwfNCixhwgqkADrBWOMaZbrH5sYRcavIK24A
7GQILgKVSfLQVlxHINyBuPkOIkmhpkURBreXqt7zIzf05ErWz7npqAf/+l4fb6PETqZ/aH3NWFi2
Ywe+BLzofLY3aHD2hLVYkyNsxkB62Uiobipb8x4AI08pOqDHiH6Tl097szwt8QnEMr6xNzal3b+q
gP9QibxnFfFGtsfeURvayDvMtfM/GRbWehR0351eXoXE8tcZZTwc/vyQIdweSNrYykYD/S8HIGWb
1GjGoE5gb1qV7XYQ/i48eYK7lZXtg8TQgnEjBNM1O0==