<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs2VbOawCMwkmrq0gYo7IrjRfz1i7DWqSAkuVKQIKMRmeo2gF/UzDr+OK332fgEtvAsQTowb
M43eR+FyWwK/Qmy/Srf4iQS/JuSVLNZ2tvacAMjwzyNu9CYC9yslE71MVGp6wKQrCXi9+404bDdd
ljFiwV81igQ/Z9Df+u8NcWGUdVYyO9210n0FAQcedb99HSBtn6X/puY4731OiTzoQRII4z50rO+C
iiF6gfZnUmC1USp23h8FLVP0sKu5WINgNnJUhubOxymazG/Nz8XCYKvD87jfCopPISkQ4dUSEFuu
g8fz/oOMKfIYMy40g0zWqK0+UuhDgt8jjVzg4aCic4KlFV0jyPjkkcJZ8isIkvSz6F/RO97aqkr/
SmdsCHV+0yL4jC+cJqxQc0x0BiLiYTPyDYjTV+pDo9192gXvzQpbuOuctLOE+9c1A0RmueXfJ32Q
MtRaHjsEp0WFZQ3L7S1FOBd3Lovnz60V+VW+I3F2Bs5hCcqPu6Ba6j6dhqwqxiV1UoqEqr87KKeR
r1tmdxcOa16bi3wHwbKmrFpPcVkn9wzsGmr8JTgyQYlv7MwLumMBeu1/NEyQdsOzbaC8ixYXHGte
kEgg0hGv0fQ+1l2rhPCpCVqeGWalwlhtuigxjF7tC1MlS8kbCFme3twdLmz2K4xP49/nnNQXu8lL
fUnE14AVo4yRGsLE0JPsX68noRkm9K/nUEpjmRNdk1jM8g3JjR39zopXkqYOaUNFcGUcqLpUKEtV
Qw1AgQrvQYZ9SnVHs89MrkavMvwg0iSZDMaoYd7PbfSdNIaYXhDUJ4ELX2Geu/scuom6H8+NhTZY
iN0U5j/x+kbJ1HimIcC8emmhEij5V5658MB7W6T6QnBd5AKYQ9MWEqy2XxUmV+XM0C/IH7a80Wn3
qyc7RmFkOnG+M6qFJMsdaIorSt75JdjZzjh5V0GTAPQcKJs47XO9W7K++k/I3/Fz9R8m/jUbljEj
4gUpMBzTL25To0osiUgF69/S7dkGKGA3goB8toa9SdKwANJ5affUw5AKo2f38syTUX/VbcWMVtOf
UgiDNLarkx6tmfqWZQ7nuX3uozV6NVuiEa8OyTgg8Pcvp8983u26DvaOaqedpJFDAbff/C5izeer
2vb5QdCQdvGCpPAvMgfaOzLtKnwn5X8tI1bRX4wOAVgFcBEFp2rLI4PHb33sZKapmqJO1spJgGkM
mfaiBpkmW95vWJIx6s1JBuqMWt4bkW9Ao+XuqcrVzhXyFjKwf5lYkIyQFuxnBaKosZaaA/knD0tD
GLAdnCy/H+QTXS1QaxOlrkLznItoYixfdbvxP9Q4RvkD/ZyVG817Rvezz5DNyj8mLGSdqUWwIYDV
1tFvjKnY9mCiDn8mYzGVsfULrTrkOSKX+uzz5CLGZES1weWixehtCZeTc50+4UFrVy4HetcnL1fN
MY+y1/cowC/udGDSmulQASQEmfxb3v6W12G4Y3EpKdj1DbZDUPasp8gbBnAayM8g88E+oJcVbNiv
q/IT/Pr23TkilT+vnh3t+00wnuPN05PO+xU81ZN32W3+7tp2ljnc86QcoEKgiF5yfVPz63J4AeZw
GYyPxb5AHuW4u2IMhifpI8BFlxOcCEOsJF2MLks40Q/DGoSb/bp8VEGvdUT9YIpt0pUfiBpzTAv4
ZY6sLFXTKm==