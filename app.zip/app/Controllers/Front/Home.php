<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpl6OfbbdbVVS0JtkkU/EM8m120Vg1ZZYl8Qlrs2PcG9gwxI80cZZp9/PPFVER9hgD6RVCUb
dMkA5USNX8/6sAhPfo73dghCOl+yyxEtXAOAoLX02YI1Rtns2GIpenWkyob/2zoyVEXJmVmTy3K3
nOAi8lhewtQphB5VKVprs1iv1/gkwK5DNPEK2OPpG2BqWpkGIPIAUdNIO8ff7TN+IAKKkQ5UQrtE
95vpOdZSPzYxXk+mE8hvZ/n3bxZfvxZDVKd+vIeADpHZv1ITmSJY4lsWpyD+RzBSGeuowtwDnnRc
qeIANuvE6KeMeUIo5uHG1SEN8jk7TMyiLLTZeNHx289CXpbVYkWiDiYs+UdqLKGBFmkLFrVBCmKO
8sHipeDzYeWLO679tViuV8UhRIyg+zFO5FlUcvfIedUOWYrYKzTYAZ+veq98e+wG9FfZq2PFzFLw
zDhn85NI7i9yCwt2V4RAm7fyr5ohJ0I2kBD3l1OBfqHJdyWBFYjcogRR5LA/HlpsLpMc/Hr03JLJ
spqiQ7chfw3Mesf6mwDn8IPGjmS/kF1Nx4KqxDTy6o+MFpheR4CoIIrpYzKACG8oXwwpLwWXfCJp
jhZaoTbPPGB+zITcURfr7f8QcCM9XimQqfSDSDzorAdYUgh76BuzCwzZxbF7DXT5GZUQhMI7C9QL
IPVzxFplyr6b/7LoSQPzswYovHznNOMkKNoijJ+VwxaOYPrr43EcR4WSmKqKWRuKQCAftoWIrkl5
7PHup06/K4ddIXI5rxjPDLlG+TWZq/fid46RqfxoVD+GUbWoxA26gc+4smfK844J3YWsiwyCNA2s
l0ZBDtkwPH9TH1g47Mp2BxCZUd27jO5UW4EjodgOCcq/bmXvXBuLVTMvf5Aj5rwKRhN9wV/w67T5
icbxmutqTVDeOnlb+Sc+vopAmw5SE0V4GKjvy6iqxIFkKu59SrFpZUzi98yZNOVTZ0oXQ7+vvZ16
GcEH25L8ytwGyRyKy8r+w1vGfAV1YbdXhd2mbXd6dhKQorHBqwdCBcBfXvWth1fTgdJY1tz5cOVy
OdGl5htet5kf4vv65s7SvR59kuXtIeuQ/LGuNqdrMGeSFLY6r7KRmHiADMj1Os4zcuTZ4DRjENPw
huq7MbNIWpAwtk+9njZ/i3jqxMWg1IAJvc2evWFVEoaMshif2DFnuk071tXyZYrLsTIV47oLTcea
er/js39hhn8twHkDV37UgFgLMor9otVriiBIUk89alJrAYk9iYqg7zs1qHWY8XsPhwZBjiammQnk
O1XxXwgTVaNIokcL0SiK0dqSsxbucMeg7VwURbdKWNUQen6jiGVtg2lDKAOUKeL7sgwisIS5CKQD
8nDAps1sYMCfpVIavPgxHhZumL+hFe5MkvONQjAoWT386iSjolY5Kcv+qRKtoG6yFQI8hLRd9j0f
Dd7Bu8HPKZQ8Pmn8aKiN3hKWHuwqcvJMiqMgEs4/bzOeesdIu5GZh7KJPxl2mb4WljJDSepgENV3
w47P0NulkOIXdx8HPgygtCd30Ehw2A72vOM6ildgGZMr1JgLL/JsBt9VObibszkqplQqPuNHyhl4
86Z2YhM10TCbH2JUESStWUyfIqkwLjEpgs1X2+A8X7Af4f1rp24+xVpXrRvbaeOvLfqvnZODVwzn
fBF54Ea+mxHwE45QRCM7K1ljk/OvrXmhft2w20wQgm==