<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtzNB29O2PKL9PMv0NdEo+uSccSOKQcrRyk6wLquMTuHeVPLYyoACvpMYsP/wLMyBTimJVJ4
gVKFmdje/MFJfLWrbD3v6KfiJ7qzeAQBVPDIPE4T0mvkad1ywVJZWsmfOfgTZ5I9iZvDTjfT28Qr
rJaLpA5SQbGIQOj1aAEa8XtuW+kjIcwoVpC57wASS2NQ+wjqPoYzo+q3bBFLzvKcI52qCSz0w/Ye
3UQzt4/rGEKSMUTddlZSnimEgtnZLHpuLaPv8Ndcw3OBYl06iL2goSIbkbcnQtA0g6XhZNXvq92S
AwbgBZI3ftSbRi219wrrCk2qNZ8fDqqGtszBTRC9KYgsS7lygXUrX1/m+YBlhYvqz8y8VDEAMZEJ
ZgfYoiHqnNAFPU05P6QeFzOdU7w+WVPFQUtSaTiB0Mpxx+YyfjE4UdMk7rdrGlb1hQm8RR6ciSfY
aHwHhCMlSwRvaPhaLeaclmaiqvdkMTRBJNrXiucCKzpd1BbujNfUOHvht+gK9zyS4Ybk7EdoOgNl
R3OYxSsFE2Um7uGPlN2K7ryiFNwfZA+SHx11GuOU98e5SDTIG/SJTKIHlw7QsuSB4+JGOlpY5I+Z
UBJw5DdSaPgl0oHe5RtYi3SARCEYarMbh0TDWeP4JNzfLij3/tYyAwERxU4NPpDPTK9dtovWUHOR
cg0QSgVQwmV2K4qbx8lCwS/mi5K2+qshL47UuEqGBpI/+i6/k+ZUmzzxzIQU4s4WSWUuOURzwDZ1
MLcOqchyaMi/Pjnh89Gaj13c0MY5ePCEJ2JHeyeEtfXkY3XnbJ21tESSve4SxVcMeRWt5vZffle1
6+a1edXkbQWQmyyLOQrktupzSeuO2jsIwJJiAw9pyv5lNNDpL7Gm35w940K5iEthmLqMxxYE/wPO
v4tqsH14vyu6R6NKjnmzEzNvztFUkzoxTQkTz9koiVsCBZT/1FZWis7zAj3xU1gV/4HjjjItrXkJ
g3PfiE4ggM9iwg3mK2Ea5wxrCm0ihcPbthvf9UKC8kk13nzHWUoR5bFylxsze5bjhuVqJQGSyUR1
hu4M26LH3CiOYWFZ2FFszgHG+MfVmYfP/9Cs4A+O+TpnTygQBkyYXok58stkQ8XGDGp8itSJigcY
LaxGWWvkaG/69NhuT0sQwXCGlm1v3aAr40Ne5jL6ElEro7NFqlmeBAnOZUJY4nkHE5zpYjXvWzlO
pGnmTNkGDi+5MQZ/Nx8fd5dQQSdGD77nslzhKCVSzktppZHtXz7okDxpPO18XVQB2nuv+CZ0Wgys
51nOuylrMiqnqnWds9eEq1phUGozix3sGl3ZqKNn9IZagNH7m/BEUqKEbChVH368FONL24MJQhw5
kNSj5RoNtHN3LJZ2vVTabuNRAVeetVeESlfIVbRvHIZOau1chW6wW5xbLW+uy8HsbsuRkVAu+SDD
UKOBkbVEgZ/J6PZyi3sYNT+DsPSalX6Bke/p/+1TTY4w5jXfUfV2TU3vRW+d70ehE+LNnZBSgD9T
4Wtnd8NhxSEu2PC74SD9bt7xM7Leu667Vcpj/o9naVvpJa43WTU4D8bnlK1CcyKFccjxefl3hQhP
efYrD0kyrS52/RZwe3vf0dMBgVV5EGRbVYbgOYXphGCXYXYNcnHlILviBRWbEmW09hztDjUlYldA
6aXGZRX5rl41lLWNpIO=