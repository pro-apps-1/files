<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzhrivdqQmZUWJSckX+hbNcCSZ8Xm7JMLf2uHBIBE2pAEbz8nuIdM0mpeIM2uPIxHU2dikN3
hl7RlAyoxc8H7C0+MniKofgwbMRbXOLQZFv7yaE/of43qsb2UmKUvpjOgVebs0bCUBcdvm1CLy4q
R4gRX2GQwtMldvF0UDmhhY8DS3a4jpj9pfpPM/MsPbX+06nzshA/dDviQfnUfEzppzDQnZyegM4B
5JQqvct/EDxxc/BFxtJ59MUN4dwMbqcntPJAyLvyD5SgexbHR420sM8EOhHh56iNlFZV7kDNR+q3
JoeqVQDkkph3bKZq+ObZ76N+alE9WbAcsDt75WZ7DTXiVKpDhH17uwjke7snkDxH7wewS5RsLMf2
MZ8tqJbKtDtxPG6YboQO6MMQ4inhRBb/ggaeEWS7jernO96Sevubd85WiY0ta60lb8V5VbX5h3KZ
6itgMXuO0Tw2agqwA/VVb69PWHuKBrbTB0YUHe7zsMx3Hk35H8gjB60Jizkw80rgbzPl6llfsUYb
0T5Gdhdmv4q4w0f+csfxnL1h0AK8iz/4ZSjLKec/BoYF+riXEEXFRa2WhhUqfemuEHh1hpflmpAz
7w7FEXngTsFIa9sW/PW8n4xzG8Oj76Gt4UGi6M8EHvi+9odteDbuUkTMnDKsT9w4Na9facAP4SrE
LrnWd73VInFNCkFHc6cIS3WWdvtLbDJQdTscqEySBZA6qZtbSTZHuW0OH6gY0EF+K2169cZ3dFTC
POIfpog71xKM3mQsO3vteqgoDCtoiGGPwgX/VE/u3AonWRM9NuyJ284MD4C45WD/xsSTrOsTwisQ
PV1KKhT1hi5/3m3CSROgtHjONUqqkTxycbpBvoyOKuAEs1v8g/hPXruIrnjSLbHM9ORGSp1hU9Qs
yPbKBIdxILVUt1jUSWU3TJMd5rvy3wNAol5S/1Me+wtctNFVzzbYDJK9yyHKgp++v3GcItt/3ebf
MGT9pncPmsZQ6paVkCiiX/8tgWgiuYdVZjeedF7I3dsxNnAGp7FEZeuY6k7qYiILf2qo42Whzzjw
9A87GnmZm8Z+BL6R55F5XJ4ZNyyYzfOPN/kzt6plW0iq6OFERrebxlA6V191e8mabs0qtuDAJ78+
oHxPppzlLpyTiK31FGi8NynJxSqZymRVdlD7SZwDuaa6aMVlj8vqBzJOPUkJPmsSEFVuPnSmIgSb
GFFRzNl022JNa5Jrgxds/mw5ytK/RF6MzUQEYbqgXPiMokb0IQQsgz3thAqMcbXWdH+GOeOZRWIs
Rm6wkfJyBm8kY3MKR4yTxY42K48ZYLsoHC3SwhUHrKYgB19GPuPAxpux/EoUNwI/41E+/xaoWJ48
Pgx4Klildda6fVUeaHwfp/Q3lBaOGT677GR2TPaPjrlDmj9LKQdc+ruwX/uXv5CoeffGwdISzlVR
RhvNDPPH3Na5r+PPFiV3Gv47QYoR5MD+wcAoh6oKVHArfxJt0rvWH5n15YXRoXqJ9BFSy9u+nZPn
XXSx9r8JU14cvKPAUaRw/ze+X2a2M0yC68qtgMvMh0HpTKi50+td3r0YhR1nfgc2/UyYkA9qFqU9
J3O+dXWgHVp2ANFxZemB8/0hGjm7fGdODZuuWj/p5hVDbrSwR++RDUsbdUTjQNrCRRi5IPLe5Na0
OMsRaA2m8zuN2Qv8zUcd