<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsAFKjaqGQSUmKt7+l023QVTfESJZOkA6zyJ1fTie5xycj1pmfHPeeIpU/Yfyg2ai0YMc9ql
VyHzk5ykA8PYlZ2tanJUhWDjSDwYuvIBzBlSMnXKwTbM9GXf5+saS4HjKtWAu9fEU4Gv0NGp3Dr/
DHgryYhVT7YvEjIfUfLh3b8adccdYWZ9oF3RRBsHj3h9/wE2DjkluQsVGCvDIjNhs8RGhHCxtL5T
uWlkWQisoFqeehoN1ol3lD1N5JvGAZf70Q2T0ZJLRuDc1MUs9o04TxIsCjy1QgRiYCC8OwLclKBL
DQEA6/yM2WCsEVrYU+1urrlTM4TII+620D16pij9Eg4p0hqrXt0kwcQfZhkgYH8/tYE50LDLrClj
8huZgXorOEazcZLM4/F7nxMFGhHT9LdcNTditJxR3vv8AOeeVhBQtn7i4Jcaebap2NrJkKrnqF+F
lby63ME3aRYYKDg4znrF7p2SMjE9O9vNzOijTWf3v9K6aOaIiYsn8CBxoO4QnLRQt6oBMK5gch05
QsN0ZjRx5h7bD+HDvEfzC3hgZq7il30r/L7gmKCFdrJYpyzRp2L1eHgmh+5XnozcgKlGecvI5AZB
qPsOIgknl+i7nejFuOUMCG0DCLYUmtPvuz0t0BDekd5u/p0Luu5JIc3PoLI50To12xdzR27a9krP
v9g0NgZy3bwbHi9u+MxF0X/aNUd26B11cmG20q6QP2fH2pyt+5Lu4BHpeYR3PxohQD23zO6lyIL8
xj77LXNSSJH0qPVxLKombEgsA6+N6R2MHeSl8FVDU1GMNOAeAgZWi3MbYJjNCsjGVbOY/OEV+shV
WMDbQrbmz3lgTSj7eXQdnkdyVZ9KEpOBWOHrhT4F9RPu9OrEfJDL5+BhfOXjxiym/tedC8TbvU/b
IDMheva6eRaYlvHl8u7jMidYqNzH7fYKfzh9l5M15M75jDwjTBM63cpBchq6T+U1pIYhbdgGBoA2
asuQqZzM5+bqz5FI6DPJBCimESZQSHr662LMXILsI3+4Eixxb6+sn9PzEFZxEeK5GJYtIJGcfPCJ
WV6eWCkc258cwcNa7jxatL9mg2s+Y1CMTYeQtKnpADd2MV2VecOwyp3ZJ/P7HPVd4iYqFyT1agWR
UbxVb/wASFFgtK/hjAOr/XI6mccsi7PyojctN+JaPDzyeitQ8i9dw8OUV6taXkBFKP4Q1GUMW/tG
lfe5UqVUFWKXVME1rtaUae+TNM9GpXKjLQ14OmCRzll/AIKgdeG9ay8ddedZDAR61xX9bVEPa3zH
c3l0BMJMBHS8MtAC2FCmeaRbKdSOU+qIBdvd17U9yDtCDsSi0J5wP/RKDO8pMIgREKDk+NVKQzTP
tgSaoGqHRGXlCynmhalsPhkJHGqiFvh1YN7NEw7NdOm6nja0lb72111M98HlzEJ0UNf+8yVh3UPa
NQ2gRDGQZKgk9iflBWJHNmIpzFSINGzLry2n/54tHJ1gx//lsogv3ZzMiD+n/cN7n9E4UBzd7L/+
e0QQPkKptMXyFJt+BeiBnYkL5OBJreIRZLdJi8tGePqRbGNFolrKexwKmBXIGAv/JQtBKrvdVCii
FeYlhooe+yrnB2CUeYnZ4E5OiJTgska2fT4inF+zSki1GXrylOCR362wAdv2WRIglILKPFuCf97+
rL6p90032G==