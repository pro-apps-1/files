<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpACKcR5GAT9a4x7HU43eErYX9URxy0R7Agug4OEyP11yJc0inc/cSqz+Z3zPrDEdpILyhmp
0VIfTGeoDa07U8KSDcXAZeryfq/URS4eGMYPjIaPFOhZVIS1rvvX7GUuujUXXvndqjSZ4w2uspzB
pgutSrQxn+14dnCCPxb3lXgLh13YNcYfBahlAPUFWtAJsiIUgT6nDoYu8J1T5vSjkIkwHcGIRQCD
LY2kqnT8CQtSMW15pOu8sI0uR4y+xJ50x8wB7nWRo2Rxs85Hakb8U5GQArvXd3tbX7hxJsQFxCAz
Tse06gW8cZ2eAXQcgEwu/MHAkwejv/ZznN1GTtXlW4XQYhRQNINa8Yi9COTpVZeWxqoMK2AdFNRh
ocQQcxXUujQwx9z/EShfLyRpszz9lKm2LKd3ARMqLLpNcuQxw5P9m/cPINJIBv+EjYDRbkUAbp/2
HOpJfrmX79iNyUOw0hobUWpxzzgPv3Lag5eIrcUh/OsnlwPDgeCIwJ937E6Ac7AaTfFCvl9QGqJc
h9fR8baLNVxxP4YBELuZJUhTvVFlzpCAOIGIMZRyzl4fXRL+pWgkq+FT7/UYW4w5GIFQT3JoGbU8
ZYSly+SjQIP//6WMlSSSSsZKMMdfXisfrMelQ18xO0WWMgIF2qnvB8I3AxGQ9VaNXNWTwmMOU1oy
1c0/YHoQL4S8dbcPcK2mOqbbh13fbWfG8URvJ+1UX+pQNQPcXM3HXq/QJzmzG9rZnpyPSRlsgU1M
UL3UGivnvG+nyPrgJ5PI6d7SG2wTlheEAaS/SDqHMDrUM+yNraTl8fpxLMPy48or5uNtaxLpQx3H
2dVZHcwVT6gzASkY9t5AsV7cvkvVnXTDBImqXMnPDMLInUlhkEL/soMADqgvbZAZiZjES/XsY8i5
JCpz956zaWH6O073a4jWEwjTE+U8OwyS3oyfwQLh7JRIvzY9xsoiKBqMfmW7LFN3B7MdD3yKrgTN
3h4J5cH8n11mEwjWOnET8sY34KKtcFMBNa+o205EBFRqWnHjwsxfBLjZL3HAaCZrcTV79W0sHT2l
WrtYhPrYDgoyRam+CncN+u2GM6RtvrihfuhM51NOaTLTKc6OrQHAGTdv3ilBcQS392tNe7x63Xjh
4FYG9CBQimY1Shm6abdEYY37/V/U64AKkQJhDZx0iMD3/zJS05pgP8EvE89CYqEPr1M4gpHnUuc+
GFs5eCY6GqUvoJANeMcprauXy4xgzRXJWOg4dLf1/2NyfFYmy/bDxe0v3H2G4ehlYMolGwewVgaN
AyopJpq2Wcw+oMCgRnlo5RBsV+F1TtXDYjl19r6i1YPSV8gibIXsAt+VtQ4WyADEQnfxlrzu0b3Q
2thR2UCWXd9GKq7RgzyJhPNtMQeSMfAuo7gvN2AqwYTAQLTa+lh/aPpnsQtfrI5nrXSpoQ6cuwSW
ccH7T4OmdCNTvIKbcWS+p0p83idxb3k67AbshTvCKzHbTa1qMr264DFZBvc+/WDN9iNwKRd0Cb/l
qkHOnJrjno7WLWggPNGmeKXRGoTyvhwRgvf8uH47sJs7IYCqmbPet2LfMoMc4ku3yz2RdZewIBGS
+dt36H/pBoqZ/JbA60SPUMFkf8cDjYXZxbuY1/LbuTx0DAB83X/YqRZap9zv+17czitF2bQcIWX5
PQMA/MAK