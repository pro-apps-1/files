<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvqmVy+NeKFXRkpgx6+sYL0DpCsyu4UlGCYc0gU3jF0Opivbf4Q8qYxXMugrCAGPnE821+Pb
2cN2JvKfhf/FHTNYmZS1zwu3pN9fszOblS0Vz+rTJEdtgo/RBQiQlbJE0acqfIIqwAUks5x3OJ93
TryG4Qws2xAWyhIEpi0LFmEdOmmcBnO6S5WEzF1GbDtSBfkYmHwPmVgghHiYit5L3GkoO39Q2GF2
6i5a7GVr1K+1QjeIg9gkOt1Q/pU/2T1jWxSHelPx4aPphoX2ab64hzVSx7iIQXN0APUvMu/Nrcj8
TbaAUV/NgP/PvBVZxfzi/lG4r3tiR35mNPJHQ1rdvmYeAfZFGbX+L2CPzG+RuSH11MgcKlSNr3CG
3QxVWV20HdHJWfBanOhZQdc0q230MpHwML6nIEWYNSGKX385lZd89oq8aly2OOD+T7EVf+elf1jM
hNKAbOYct6UZeswhM6bz5+c5W4iXLZtPp7QQolDVkc8vmSlKyQRAUw59ZGZA0pX++ccBV8HquIzi
aHfAGblxa4r14ojDTZ9x/YKaTnfMsXEtOfRkxbE3qkP1KqXxVIXL4XE7KmRK2wIFa1XA27NVS/Cl
ZSVk8fcUyDUlDMHVF+vJIE6PrZsqbjC5Ul2jt2+gbgOf/q3RrmQzTDuGrWQPp7MkQECWqxFn3rnS
EtWdv1jJnWhHCWL5Qf16e2FsnOMYYcbk+plquMp9gL0lIythas6Z18GuZaiaNSi78+vcIA27uhmq
2ORnSvxSFUiFUGGGdn8Ty+x4Ic/YjMp39PWjixBtzgf4SwRnUha3TC46Oztr5oEGTVjw6Tc8Oy0V
Vi1WDoW87YsyvYL31ESqkyfaejqaU5sEALd+beIjtuKVlfDvaTqA4nF+VkwWTrnQPDfNiPFis2mo
M3095Dbtx68LWbnwHDfikxT+6biXVFHZya+zwXTYUTKgUM9FqYY2YEzb+AyH7HdDTCj49gxzU/ZN
RMhO43d/cDChxTKUj9iTzBEZNz6P2k4AQhH9ClqT4/P3MDN1W6CPbZ83RTMpkX0n5chTat3+ZoRY
CI1lxrKVjkskqYIUo54CgjjkwquqhonWi1eYmU0wguVWyvABdBO/pz+O/a5+iXZxv7P8m0IBj7//
KcZ5pTPvwnEMep7X0QyQUz8Wn5SWMC8pDiNpMl9/8gs5hsRBCmHc/dxc7gD/3iUGtgFlv7ZSvGfg
Li6x7BqszxTZ5XYlClDaVcD/HQ9je0SaZUpjEyNbvJEy18GbMT2BPdKWkj05l9q/+hGXCCCEvK/D
ltVpnlO7Upi9ARUTZrl78klnk0r4+rA8CP9zYw3VkyfEUl/Z4aRKqhGEsrusSRluRGNzrbRI1e5e
OGzhWymjrOJPkBobk7ktMLuA+i6oKpMCxHfsz2FIqawHYXFoFH2+qCNKJvfbiEmx2KfU8oXbx3Uj
w17xLjgFOqCpBIpxSXsFl4ERtMtowXEFdHurNkU2zOXMnv7UHf5oUyVa7U9M7s2mCgdZ2F2IZeY7
+bR7jdk3wnx5+9bCuktS3644gm/ugqvOAxC84+9HIN6OV3uEUrPKU7tuhg298wMKbYmqoOIwGtu9
FylpypM4pB/gMjUBeUoCCRoZdp8//tMmVKg7SSdxJd3hdFIkC3qnd8SmWh4dzylm0OQTY+zOUpFt
VE+6mvzX4rJzHo/s0Qo2ecdAOabrp1rHIsc1vdq1IvseFtJfUmXvU1WGH1EB6Ja3WHsSPI4ZqovI
rGeAfCjHMVSjuAMZDUyqnHekhuPoPHqFepIhL7ZqtkjJHXUbyqafTK5Qbghg74RuSP0Go+tseYT6
mdzQn4qCpw0FyFwfi33WBvFAFVOTKw+aDyYfmCsT+SS686Xb/f+3TNIuU1Dai4GvvnqCMrAieQXu
0OMghgGxVp0Mfb6YYxvPLKJJJ5X6J6sGvAA0w5dRonhcc0CK8EZcJImUYs2KCCG3vSpHUwAxI/D2
a5lnf3/80454mB3ffGPnvR59VP2GuUaSk2AF4kIjhVpYIVE91+aojBJY+a8/psncjk9D87UmU3wO
o64bmfSUOna2IQy8xKLbddP9x5ZUZexaShUaS6RqdmYKjqf4PuvkRVtiQcB6RZIEFYGoWWPVNel0
aZq6wV5nbna9r23n4tNvfR0Ob5JqfA37fDpxB1F8JZxKlEyW0ElATOgGuvjNHz/X8wjb2P4PaVbN
Lsq/8U79OeqOtTfSrzN57GBluqFruYEvHJI66dGu/m1/JLkfbU7p80==