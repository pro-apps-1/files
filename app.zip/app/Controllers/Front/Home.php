<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqXY07ohqFXpihwLNtwrlOmw6dPm2fx73ukuN81jrb3FGVe2WHUPplv5OmOJDiFiKnUMcFsn
ctnynP3drQOAM8x4T5zIp/SCzrwKSgPjjygtVZ6xgTUTr6wfmmkAOYXdN9jlfIseXuNUCeyHwLfY
ksgNIo/5uNU0Q/UKsn8uaGNL/S6ylURsUzQ9ZKs1XXi44FpGCBqS3yXSbVuPXMRAckAQCgfqrGkR
X6RARfQols//P6J4RpcKVsw8Xa5KlzNkQ6rDnar0bIC/IiIrHvjcnscyW+fjmYwRmiMPAMHKXLmO
6wjz/uqmuPx+dUqw1raGBJGt3w/TqbkqltKQTkCLGpzw+PNwipY6jycj74pQWGJMqQVFWMn9rkZy
f3VeIRXMSXth47gEi2IVhNwAHyjicS2byz0+YWaNGmNqIvgZpYeU47H+SBH0FedwhpQgnJrCPdSr
Di19kRpd6B/RLtNu4ZSdZhsNeSNU4E/LN9f6vDGZkpBPVMJBI4SZ+JuxztHePUcdAzTdm0Qi/Zw4
5rdMc7I+LDnJzeQIU7tajxiJGUIRsW5r253rdgjyuFTRa58YdHcBz4jdsYdZblyzVqOpLhw6Tjga
PUtzYbal1LytP+8P+lJmohiH5ptubXJ0BuyhK2F9Icq6NI1NhDFuZOzE+7xcjaYTtFJhRBtghsE4
YfjzCw3/qCH80RAS0UGgvzaaiydCzoZbrsbLQpCs8TGQRi2VMUpwGoV1jq8WdBUY4asWp6o5bEEc
oNdo3nr5tXIlSBRx2UBjCypVJyjD5+9MO5BZxNJCg+zy/Ug5P0We8AGGWbDMI0SS7exTBtoRj8ta
1vZHIZRUAa8GI8egKuZ9kjdInbS+X8hol9sKZNOB38Cmk2QZtaYTuC2jdMLNtcbVr6U8waTVwvJl
zyXx/pVxo12n4+/iFcd906h3SnSPTubSyGTTL8WAOgrxk7Z5KCrYY1hCZXy8DwXQk3OKvUnDRzWB
igH1bGdrTFy/M94oeAdy90YcBbL7X6zXWgI0Iac1ynyz3XTJfu7bU/Ljqfy0DcJdstGG2MqWXARj
BZ4vjwLNOi48dXTCipO5ttCkR5lKqQouReGpiHiuwo7JALYrp4/TvHXtEUP9eMveW9KaCtlNR35l
aIWFOI+vE7xdbJ73b8ieAgt6WGlqjQ7wcNtYb3C4W/4/8W9GfdiYPg0/Jdr6dqcX4t49I1T1CtNP
LqgtHkt6a9b185Zoii6Wrn+71KbzLfjaqI17uQUIj0XMI58VbdcKGuIZumVhRgeuk6BqkLFXuHZe
kUHkUdfaD2VdmczRkeXvJP6Cqsb7VbBbDH608SpxvbsU4FnmeQ/RhpHxvarzfTSXqkXBMeSiXpI0
rta1pR/smbQBrA6TAuHCjrtGq6w5WsSoJUKbj4aSGzvb3VurFdKu1HmIhfQh6dlFz8t9DPDiLl+6
GY0QQN+VXYmZMgb02MOfDh5cM65g6hhf4HWOyNCsroGaTOArEb14/Zyd11VVCOcmx/7Ha4QRG+/I
FiKkcPS5l++vThiMWLzSYtgqVefiNpX2rRKQa7DYFfSPf5L7vVMRFJr/3D4Vgy9R6CEHw7DlJZMy
OouMWw2ckhZsJs84MmFK6QnkSLCvoOUT4HHBjRcE2h1TbaYzWjyp7exyYhtueMnNMF5EJxzdnyLZ
X9rgDGax7Whr3EnIZbh/fE7KdmLjRXNFeckbuGteiEuE2dl21sqomS869jFFUquKWVYdnK6V7vf2
QtFf2ST7GPioSlzOnxszlcVczIHv9f+q7QUuCGkP6LjQG/Nn76MmnogOBwxSbQJ+vaqBzpIWebzD
Fm0Uk3dCR5bv3A1Q7x+Re580yrrEKpCRi9GU3jvpCAybZFYQhOLiSCzRGqJyBfBpG6z16wvrzAyA
3oc7xauMgj9mKUu5pbO51CaPDmNx1XQPBsYDD4EJrNmdB4BypqHq4q4pz1b0453C9dt598UDSdRi
x3ripAqVrXm9mIgj+XNLgy8vxYxS3uJq8Tm+njRy2/S2PxC/PjQbMl4N29biuPNcXrLeEvM2MaeB
Q0AC2Q627gmZjf0nlTavJkUk6pJG9/iSBrQpLkhe1U+tOuUQ9uNE0nk5OC3A5DJo+2+hKfg63TTC
Ad3IZF1q3oYdLIOm5R6UahBxXynmEHFk8RSzp42EWbNjFxJPnjzo5U9cKnVc65Fsk0z5ekPS0zkq
RtpLxVy8A3gGlraiBrnk+uMBVmg0KXFaNf2oQCOFxW==