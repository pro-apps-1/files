<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuosY0i5Bd4iq7GTAAMuwVLqGlRjv/hm2eQuBcabclj0YU23Q3czb012dGAIPDW1fM0ibGNH
ezDSPHGxFdYqUcWlFIy2gDEKVwaTZDylIe0Cos8/zcmBM+Nt1V9t/v2bpWaQEj594HYOOzLzDFZw
lNjGzeW4lFgqBTB9wLz4+IeVjLShfbrvow6DEkTwqE6qTVzIY6LA583/Y+AEHZRPEYEC1MDl4GfX
/6/nVo/jZOg0qQZtsbyfxHfbcaY64HaZgJDrt4A2h9bI+Gfx+6/Lx3YILaveadMPPFttlDX575k8
QIf7QtZyTcXpVcxoC2saqFH1z28pIJwVOefIhYKLuRjzJ9I1lDP5AtFquAyKcG+yBw2z6Qpa7sUQ
GT3g/iG3/J8tvzWc/xPe7NhV9XH698ZkHuLrGl8P6FNcH4MyTDg9kjn836zbBLTaWwE/FgSDXzvP
L+B9UZFLWOz6e4EauuApK41ay5okT6o11vMfObPXpMn+RiODk5EC/6dxky7XjcNJ84qIXaOvO5vr
oSxvdtiVyh9VFsuMEphHi352pWA+UEnl6Lj0t5cKB9bA7ZlLFylzrVKthojVUwnA28WuzBvHeTqP
8eLBfFfhPvV5GtwwxOqZJdiaN0BZcMoEfaC2ghLX6w9+TTt++s3/7v4vZG3nDTNv5r3nUZUNQtkI
oFlXo2hG1rwd80uiJ51SbzNPPrL0UAMWyqJGKzNNYq2H/omqENVTfFl32h0inSKeVLYcNHI54p5s
eJ276HrO1IM9iUK95+T+NW0azRF0SVRjISTQI1ibSTQrv4pznwMMW0W+Y0ESUNMW5inC0nkQNUOh
2IRVl3GE3piLRAQ3uJeRKM1XU8t1utVoUsib+nOUno+LuYe7FGsiS2S0OKVkUwZ78vss0CfhOyWv
7P2Kvd+V6CWNo2xCNFYv7eTS7PIJB3Ar2Rag5h/GUOnBtPkKm90QYHh7UgguGSyNQgCEl91tFijA
drTWTKQkQI3ES/+yDVIYTnKrSdMsa18ZEBNzlt0P584QFjaAemTTtaOjUDaH6JI4Azd72lHEoqPe
+bqDHeiV+KoskY9gR6hH+MW92Och5jlEiD5WysQJDiXlq6vOijuJRbvCR1TbVGO4lgM6JMO5S+9e
hXFGlAQwjgFmz/wNBP6kqCgjoIPg7CiVHLvY7soS0cPgdA75RlUUSZvTJhIFwTmOYdXmZCq4k3aJ
W7RP8WCZvyD/L1xOaATcP2l8WBw4HMkrJv2N0yVyKhYi2t8jhVAX8lrcbN7jOdKu+LfYQJDrm0Vk
Lg9VujpidL7hd5cku1Xc8MfIlBAcfT8gQY5c3RknMerF3lQ1oD97yq+kkL0EtNKMa98cyEk0B/r5
l+gk4U1GPMw2B/bIErqrGijFiEkxuLoRbfEPFP1BCb4GF/7vwVdbUhPhQxYBcJ6bCg0kRaWgaAfw
rwfCtt7LxQwwEgxOjtkkT4fya72s7t7b19/sI3Rdmhtj6brLbLKw4MzEen9VSP92SgX7Ox6tj1zy
ZdTWGj6SALqxwfPLnoQH0pYjITKRzdMm16ufKgqIVhyP3h8KORdKaCJq3VP+PyM9gyB4vaYBPdP+
mT+xbcGNMq6UAm4fXHakyB1+dD3ji5dhxKPEr1HK89CtUNQjDPHC9wduqAjoSb4RjPzgKMX0kuTn
D0LNvjxv9hYe+Kmb