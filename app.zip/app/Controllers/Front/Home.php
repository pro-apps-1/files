<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrEeEBLv986w16gjbkaWPkebO4OcUrW9qCyETazEBBynL6IbftxzTxh10vHm8iH8PGr8SG+c
r5aRDGmHzcdolP1v3TXGrQxCkFogpImpdh7jCyHKAMkA0JvDuzbAch8Mogighfy0tFBEEVYeCwjk
+TCtM6kPX9jAY5mBSURZJsgYl5huk3qsixdJQHML667ktHcwsAUBMunLxbv9ytLZrW2sG+2ONT1L
MGoQaQhwqmP5fb7IEKk7HTZfMzv56W1kag8aseewTXGh5tW87FW/i0pF3kQEomjeFnqwB7t5B0Yn
2FnXnqekne6yFy3Y7vpT8ODD57KXbwcVC6KMtAif7ZgvuASBOKhCxjfTTROdxnxifcSOhRksIEtq
FgDI+CMD8twYL6Cllg9RI+UQdIzCH5F1SNXOg+Q8NK7w5tj1SqxbV/7Q/dj/onR8lB5ZZrMkIPB6
ggZGzpUZy6zFszm3+JZnJWqtMHxLDq3TNrIMeylczHd5kkC1hV/G59F9QdoP/IZlvjj/Qhu/yvAr
hnY8c1x+lyJZMAOcrjCedQqIC8xTYxKTdelTYrZFBmtxlOwv2ZZv251IwSs3q6JpLWZMX+S61DRC
k0ptQLz06JV5AiwvjWMA1dflp9o3Lvi/J2R9aOEJ+AdgRwCc60zo3J2vcc+cqzu1t37a9yDEQsJe
MH8Xw4n2bSmfGA90UALzrwR9rDeGHUDDIZK70TE9ZQsZJ3GAyE6ozuLPTjXN+MVz5CyIH/2cFWbP
mPUljVaYx+ixP4KURTKPFMGFAG4z4sN4yUCKBtfHfvJpyu3WQwd8ZmDq8SDrj+vVU8jHe3Djzuwr
YPH/rdZq1kSdQ9bUZ4z16VY1R9HYIsgMnHzGmT7oxVzo8TBmjm+RIxu99/LnVPAWottuYB4qNqT2
MimvsqxESap0Mh82/6jbZ3y+lX3HcH9XziYrIOcYMafZQIp89k0MyivULyqT6kRr0r0/EgBU8ySw
A25fXOsQ+wuh7VK4dthz8qvyShAbh3ZjvkYSIv0Z/OireHwxnoscowS+RYUd0fxedQenQOzhNmc2
QJPWwTfkkCQpEUUx2De/7uJfP8wEKXsJnk6G8olhsX0anN0vQ3M3Bqs3XmJJ2lDZcIIYMdF41kco
X4PtjVPXA4wA8xMJvvkK/ACe6X7uNVQhbT8f5svirmF4URHDSfJBmgFo0TuGvw35ILGGirUFI3vc
E+6KUfcHTNz0RGWwKO6V3gENKzwQUbLmTpsGjdXkZyv3A4v+cgV52dVrXmFoTY/qZ6mv89pG49w7
5F+D2ZKikHFr0FbjapDOIcVZx5vILYw9bXB9lb2kDVZ6NVBPUS6kvw77hqZVKQ8tME42k2+n46WX
J5jYO6I2xsFQYYtUF/Q4rbRO+ScSJaIW1tNAsG4HAVAf8nIFkI6+OGgV7M39mjLBDms32uW8e5S/
Mx0BRiDAv5w779uTsVurRgmZ6CUMOVpUMAxcj1jifcvSEjfXfF9Pc4AKIy/IsO+jvRRu7+Bgv4N1
IcLZnq7TVN3KRxn8dQkyHTx8bmnBbhRtljagJU4dWeJzJjjC6IlSd+C1a5x09cuwMxvs7Q3MidiD
jg6oV+iA4aM2AYexcCghFdil5qbY2kf9tLLk//arOyX5rZc/9thNXYIb2BUtXY8svj7oY857zeX8
iRJmB8xWMoNGGGilWj+gLWmhDW==