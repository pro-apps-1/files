<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw0TS7E8t4X5LS7bKEUVabcc+h5WYU9HxEr9IlLix6LtdI4c4XMo9Wkqc7CVapeMopvtkaIu
PSfmXur4hQnxE+F+kWVG+tdIBDzJPbYT9UtYJ9FkSpCsYlYjgUFoIxq4DQ6ltgHkCE7sHXcLox1D
SLinb4n81YD/K75eu+3LGYo8KJ/gVTai2VhRWbZlE7MtBdVkR9GByfRUDcSByu1Aet6kbrcsT9Kd
LOEyYXOQLAauT/ryYiAOnARAC8cTgMqm42S78jfc3gKi+VXMPDuvxUuHG9FzQkl+c5u4vRHtKkoa
4QnAEF/oWAKDyNb7WuWubZcOTsWuBvyc65gDdDa6BeHQDZjxNt+m+Ar7CHWsR5Q0nh8ZHicG+EVp
l274BFPRV+9tw84hqstw3J0WjcFSu2np84p7q5W9o6+6kM9h4GJjU6j4Mw9+OvVu8za9+tOB/VLq
H8zXcXJZuhYmI5csAUArX8wg8aD39W2zlTAFYVPvfIlTQJ3lzXZm5/122J4cAx4b6kWc/PK/NInh
HOaBrAagICBFbO/954LtibhhhkaFqA8m6ShsFujmiI4uoU7d5eYeK6l2ahmZxB2IFU3j6V55WKrI
/NWUkGQjMOfDqvj3hOIZyikdDMDV8L9gQy7GPn2aICa9c0Cj8dsJ7f3p2uRHrDBEowWZxir0fokl
o6V299jUVLz42MO3fmYdb4C8lbH1pCJbfgHTeweqDD/nIhWj3ymYUcd7/PI6rArVNJ8FW9LapXe3
gAHb52aAJWLbHXYKhmz8U/N/n3363YqCZdtVh0yv55BuhfCe8RtBQZE0PCs3BZx3fIkElchJXUzm
7CVYyYmq1rhbAn008HARYSP5PZPwj/sMJkCUl4n7PgWMKUmVQ7oOxntRM2AQDe6wAd9MfMkiCk7G
MXXPRAlsSOXlvroy9YdsypKMmWZk3KGGoFcrQSnrzg1ZZy1ndcwTxJCgwnQbkCN+9UeNawYY41wc
I48nko9f6YJ/qk9rVnBi6d0ew42PjUMwY72tJN0VWKheJOfXqFzOIQFGz2NVOMyoxLvHImM7YTf0
C+Upd/s3eHpx0KDaq02wPHgL6QkDbLcj6drlSDMDNaf9/arXzw5840hsoqgxJ2Jce0gzpfFu7CQx
n265pBw0E79gKQppYmusbp4I2QzNPI2rByfrXKdXK4dsE7p3KwmmPHX7PvkJaZU0cCc0pt0cdZlA
oR64+uxkdKrjZkX2ruV0Hn1wrRx9pCj7LWKEhyzTPoMu22ESp+sELX/v9Gbjd6ojsdwtZBVGG9EK
qgbBJuOSA2NR7kK9UfRyE1tUMpJVdVyFxpdDRgBP4G7FlTk11TFbkEyDWDmk9mvJC8ITDR6X9M+3
FplQeuvZE9SXhAlF+kT7OiHg09slRIYQdun7bDPghs/Jy9nJa2sYIzaUVoUFWBgyvJMlEZs74ntT
UbOfulCLGvL4czjdt5OpKwXz/w92qb+DbOAMmKDozbh8ZfA4Evak9qaPXj1jaYfgtAZ09jeIVheQ
EIZDAfHs+T5SOBD9/WEKPqlEiodfidwR+6GGFMpu7mPBLCLVG2hwWYiMbf6Ulm4XVdLFN7qcsysD
RviFGw2A30Yp4EZuv8PdmX0QoisoXLuJAwQRierYqIyTZf6qXtuqVeXmDXRuuFuIS5o5UGLFbHp4
qsp8KB83w7NU/7jl/n8RFWa5nrSRqCUHdTC5Xr7CrLb/YcM632DcrjA5xbQyKN89uHJarfeAGQMS
bgvIYG7sUX69+pNn6h6vjBpm8CmjEOH0oqutyv1XiFxL0Fd1u2dNLI1WCAQ0CgFaTDKwsH0fsDp2
wvvXcjY3VaAap1WbxLbyrNcckYgicBl/fyea0sXYjL8nBHsTSLkoOlXclJ8zp1SveXmUtjuhSX4/
UUfMwHaMxRb1thAHXf+nNqrT56+D5aRhi3YHpLc4wZg7OJjp8bsQnbxXyeuBGyVUvHZMK2+zGKlM
SYJm8ejeGv/ADvwiB3Oq+3uu0oh2Xxp0rEGrLGzlGAyeq3gyncMUkMw1agvByIixDZHORy0Pq2bl
6Su+aTnOgenw3mIRDoAV7kcXy2MpfNo5GsX6k8u9XbHCu0IAqu3tdmVt7uj0J8Zx10ku6MU+KEFt
tXwag0p4/oxxphixrC+BpZlcqGdAsUQdnUMwHfRrfGLUvznJS/ic+H5mzz9lOzQoU7sdI6aEosUE
Zi1f7SQuuMx1ta2NMrFox77MqLrBk75ZkykFlim/T1b9iD3G4Zy=