<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxu6fkaQtXhEuyGpoY8TIHMDmKVGypaRjvAunO4I7wzv4yoWg69N1u24nOIRgzJR74v5KERc
jlf4f/P8oC7Ym36o7rlSgDu69fRQmaFfI60+GW+RmQMHObrwQL6s9cgIVwCt9c2SzuEcm0a1lFQr
7dSWwTuYKWOAuLZt/rfDgDn9o5ewb2hXENQ5y//XQbJRoMr+gaLeyoRlpaK7oHRQ/OZkKA6FVtBK
A8w5o52P+l+2DuFNGCE6uiab3/0r/jE6BM1Rlg30UZr/oXUPysMTD8bFf8LkpDdSZ8/Y3yqcteKY
C2fJvkHSaMxmZRbI0UUkRnpvOarfvDlOJjfkHVG/jL9e+CG7xX913iuuVMs+2lrJQ34IZGtIrDSD
1UcCUfmbZJb4Vj67m41Zu2sQae1gKHYnwuEhfqg+U+A9cOK+sd0+xkkBsfFnVWD9I+VvHtkvyfJd
90BCgahqN7qBaT/eue3ZhGr++EA9mLrFmvr4hlXiKVQ8LqRJNCL+4hWGdV23cqOI1aH5tceJtVS3
HOrx4oiP8HiMFR1s5uOn1R2wGZldmXXlUdyR0R7ot3OuZRnYlttwyOTvwEehAxpITEZG8RDQRW1/
sZ9qyXK0auXb6C7RhbsRv6Ek/UL5b8gjE9S9Djz/BibtnrZ/flZLMZJIkRTzrfbZbU16JoiFUnti
P0fsDa0IHA9FGPKib/IUxEnz3ugfOok1waWebe0Dm4Bt4UglcQ4W6/3DhdWbBgNPyHDZJlK6By2W
0HljYDVK9UweXxwovEWupdy3I3tm6ND7Vn4is/lCFsvPzlo8hNzAK/46V311SJzu7J6jvprycR5W
mPmjW/xKpX0YdA/2n2HGfMSRVXNBxIcvwZX8QhAysHQ0EtjEDJAn7wE0P4UivsNkxvFzIAuPxM58
7mcKc6P+EFkW+3yVnv6xenLgUJG41d4PYYFXsqILRGRnAZCYZxqZNxdCs+j1yfclfUbTXo2+XMSB
KrS6weLUNVRFvLdNd7to08AKDzHP/lwJdv+MK1yujcmeOgEAOpzbehMzErO2gxGHm57OCjJR7XJN
ffg1frAJWx1Jr2HQTDN4aGm39mvS5yxrwDYXmJffyMPelHC9mhLWidf8v10sprEQFrjI8JtFyOfM
VXAvC2rSXyHuICJKNYkGUAZXtxf/AX5Q6VbHCxr5xw4C/LY/+tRG/iOXIh5Klivl3uRaokA/nxlv
nJIUu7on6XZ4btbeG7588WjwgY6ximg1/pGr/gSYnjzB3te64c2F5v7sBVo0RvyGhWe0gZjJubix
ORVkMSURynTN9Z9nPMM6R6JpnpEYfYwFwZETUGy8JwNewTEatDnW8M6fV1SubVTn0WgE44ezaET9
Pq52HM45vywxF+Jh5Qp5Su0OK7q+ixIjZbEbd/bkXmVdIdLwBNcqkEOMbVwqFOpS6cTfDNG4Bkbv
BktIWZO2PuR/y0jmjRVAQDT83lzmi/XYa+HEmkM7OmTT3juC41YMZLKxbLLPWfYiz6QTE33Lk5Dk
BFSsx7gt6+uYJM9QqR+NbOlyn1O8+4FPYtpriFOVPv1s3GPE80/pTzIDlLOqVKqaIx2W/hrQRYfK
qMbnDOwsZnGcrZYmPk1okk1TChmADjhu3xJ2zSdpFuhyg+uGJp4kTvQk2XLCa9sYskghjqnJMf/T
zGFrwLsCOe6u/0KBIW==