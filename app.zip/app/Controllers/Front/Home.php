<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvMyl3+LFGKmO60f7FFVk85/cTlnOsqhYTiunzhciWieD2XmxKmRY+lYDxNb1MZKse++LsZM
G6gnpL9zs5/CcstxB9sjykQUouHJMrTArwyOnbkxVuvycLoIdROUuulzmpA2xVIB2mK7nET762Xh
JolegT4TkgiKLF0vvf59jjbDsjDuJ4L7g/TV2DJLrgeQalXosMBdxcqoj+7bqUDP276jXAhd5yyg
zqeL8p/vFGCJTZXsteR50ShIt0K/NsSt2iBNiDrKlb1g6Cjv1nFo8DJn1quYRejWCrJryDpcInkX
Yf9A3/g9HFy2mzIovGE4Gat7b5+pE68ZkGtKso07E/49KkrUS7i8KJC+Nb2MQ1nBoZ0F6VGOqvnB
Q9OToQNKSSxSIQyGTg27VUsrdGlyv/bxb4VZRMNPCNxwvRrRKssDjw49cb5BwuRAS530HDS0veFL
BuyOP9Q3Y2e8WMHzDaufZQhebiMO8tYD+CBsiRvA0sRsqEBav0LVYsSMeTWi9fLuEcJKfu1GTu0s
6s/KeNaHLqmgJVHrczuC+wl/Y7QS69QVoKT/cUngko3YAP7CQ+oEdlPFzJAx7fpumr00y221YgXN
LQohNkws/byz2iiMz8y0rx8hVe8vvNY82w4vZqXM13JOD4Xy/wu3/lw0W9eJEBLJFnhi5t3Xc8yK
OUw4lI/J1JfGa16A1rGsGQ7McPzka2iTuPCOnQtu09NLlVbaW5Fo48KT3nmTpogRKFukGS5aDXmf
2Fyl02me2hec/ryjM+tPs2LbeTv0wBYLGrMhPBkt2/Nz5tyu4dQLnB5jOSGs4+oiwJy7kxefSnC5
0mjk2kmbz/zrdziYLfIw41utTlRWo+MxNcApsh7d+OxU6YRiDfWtt+waVnzgjtogJ9Tjc4ekptie
5Cn7cw+ZjXZCM+fhTKzlc9qPS7A20TSeRoIWup+WcWJKGADvZoxV/vLJr9RQpQw/SQv8eQmw9sM2
IjaCyAEX22h3xvwk73uhKtn6BuD2PV9RqpCnvoG3Qo7+pvmGeaRiDRk/GgaJN3YbrWv8BaIs8IyX
LWf0byYgVqWfkspbL7kpHU1gJM6dAOpedrOIZVhZJrB1Uu7drR8TSHzK/Vfxje1KI44NUQQzrXUo
IM4PPmL2d/sG7iqp1GtInWW6hKNrQzkOEj5Uhna7Q3Asfcx9DjxKsfx7hsoNd0B8BFxpzCxX/ssh
cnxe3K/azz2sQnS9DhxZqy/363wD4mHJSo/+SSxXNlnsYeijEvoCzzMq9ORvWeUbM70VSDIxHvE7
YOMu6t57WxmxbGGOha9z6XwiciOz6UjEkbY4LVkTNhlXB0MP4IqTEOcXMrshFlDaH284R6f0qv0M
pwHZHTDgGBE7E+bOvwFGxQ8sWzMEL6f3nQpvn/WXNAHyqy8FEbygR6wXxXCZ7YspcVXqkuwu+6vH
2EY5wxPA61rG+yvDK+mbckhtyGuar8Hq1F7y7HW+UUovV1yjvk+PM/MKH/siCrOvQA1KmxBdwV6P
FaPhxfrwYfahG7NxOBlvXPdRGLeP21EBmcHJVma7zD5ebDhxGZEIy/robo4lsa2C2iLc4PreN3C8
2ZsI4Ihrr/JOnte7/dhuONo8l6zSU4yRHUoOxgSIs8OWjFtvwwym3VOk2oxoz1VlBTTWOcrItPVE
D9yP6mCWpCbXC5ktpbee8y5ehpF5CEn4W79miB9k8oM2Ehlfi+au+nRhYXSgP/NMy2oSY9SKWvu6
DCfSAc8Suj+aEhNn19cVLhNS+8DzDWnK/uOzS+t6IHroWRgm8kWqjmZgODrQmJNEWW/0LGgGEpTy
slmpxhxHp35Nw1cyifI+S/o0khLPqnIseGcd3SnFxuYmGl2f28ylhw3S+I4D1MUIV5r3NlcAUuTy
0uRzbwKbu328m4ljw16wbAbhLtAvxvC/NycG9OMNu1ma+zuFvW7Kratc4TxfY8i7+92FZNuVgcMM
PsVDoFPTHQ1mu2i8qfqnl4olANWwKX/yVrvjd7CP1ZsiZMSFiXaxBd6ONWhUrsfEL7MPESf+EP2x
eaLR08hquTz8pxUOXW/MKWiiBY6h8JHh1GVZPlpw2WKCYnhJc++8Gz/dSQrSiW/4reTsSbC6M4Lu
un//hC0epgV286Pui7linHXZodSdqPw++/DD+tsfxEXr7S+bRcqJ4rJjpFCScRwjnaGOiP92WeVQ
cevIJLTu+QFGfDv5FUWVXPFvAFKb3Z/0bRSIC60zIoJqgiFLmaS=