<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/B3qVDTSoh461z4q5nNU7/hscU01umVmS085zcqjkJV1twjhxtf/DaNr3dPgMDHwVXJnY9q
E1BuBcH84jP+roNOZSsuTDPrLzfKD0GHtD5EYAQPCPNdRiLO56C8lYZNPYHou8Qxqhe3ckxIoH34
zcuqpOfb42VBFTcRJ2F1Rp8q/+e7Q7qHkipJxlSUkzF/2ZrVBYjjXOQi7BMUYLckADB1UOtgP7DJ
VWTZu1Rmmqjmk0/ua6MpKmbQLyCo6M4vxwJeKlpNQGqzzeZKqb1s7eEL4+RxR1RMXvyx62UhrcAR
Ks6h69ZBfEoTOm46TpEuuqQ21e1hLzLWOcDhSj8A8YBNv3I8TvOL5d3f6zHBRBx7p345mbISbg5o
tmy1nhrw/UAYr13nKxpFlvojMgegcJFBR6M/U9EOy3Iwe9nT3++RAxb/GrSonyRLpEefILIiGmah
aqgvunbfl1B8ZfcYiqXZdJAsH5cB2wDpgd0oZ7mbJLQgIQ+FIcpHb5ZP3PZxHJ5+3UNIzLvfaKP2
oWXbIukqn/GQ0mUHYnY/0gFa3PJ+eKb5JPxwI9bC9jJ7NUUdzxsWXPbJD9iYyzKeS+LQoFmjHmmP
v+aaY0kefdWIEpcMfZwS+rK2nOExGJ61s6l8VkwHepB98XKzX8qFrthuHhLmIokcSO8nCEN3mKXY
Bjk63flXpTnCk1eQwWH9cSXBBOccN5s4EkViQgfiVO/on894mUrMsg62byVlCDsNHA3aIAaGqFX0
vnVTycjg8apuBCIF0qQTMMZJwo/Ek+MjceZ/657kLCjQCZgjsl3J0a3X0zEDeu2DSFylYktF7B4M
17I5ojbRWpE2tfsohfUCSNP9YhIAu5toC6rp6OVcuezTGi9jeWCtieCPImqUhvJp79j0DTLM8Az4
c66FPA/xwkdpBfH5lNHIfnyvviddj4jqnQQFZ+ue5FUS9TzwcrswlBRK2qhLgqb6zNG5Y5qt4kUM
bf5b+b0T2RiK9Q4zaQHrXYN/vUHz+4373/3TEbeQdPejop+lWdb05PHrleeKpUTp4dG1nGJZZ/Kt
Faj0sbus7lfSL7NmBvLi2BLBE6lODsaac53AJwxJma2YM1ygTZ81OU7hDyM00LyNyS8aLA5I5jwl
mrbmqTJwWuyJKOzou0pYlFA4lYweCJQD3wIRCbnUeSRwSVEBCfkVYiECl7OgJykwBV0kfU7E2De9
7SaavFbz1fCIGwGBpHR/XOABm/XNkOaf4sun65sia5NaciGvPZAYjCgvTV8sMdi8B7iBL4wPquNZ
tKTZdLril9RaV7eEpmtz0UlD6IhffeuLgJIIR7UJW9JvQR6VbdScU8WzK/WOFH3lgccZtwmnjZOL
OCdB8QJ8dVvsxlESJYehYYuzW5DdVBmTuqB3X7VRoVf6NX72IucIPM/tfRPD0zsqICvQVMZH87C/
+y/w4uFzlmRpBtixJ2thgpVYza+MRMITBuizViR6aYfksaBWSHGDaq6Rb/SmRkuH28gjAQi0NiiX
id58Hf+Cg6KEYtR22JktahSMuyPWiH20PiBKeaQmhDueqm7DkR8xqxi9lRywoCnCi0rNhr30D1Ll
UEZHTFn5hbC7MWbBBA4Q9FlnQlYZAO8pLm2YOR1taLIDZ74Gef+dP93Hm/UWKeh4/fK5XzokQJFf
nRg9lOR4OBNQ+KElGlpYIhR14/jYOlByP+PrBbR34lpCy0aIXi0fhYqknsR9C7uiGMxOCOwguShc
uQHMlkvUszFtgvMalRTD9wu2Oly2RWmCKkh3tahbqfQl2UsLYyW4kG2qR/61q5YQeYQCJozSnh7B
QFAVZIe6WYjUChO0z1iN81kIEbYQkaQXcakRtgJaIgsKRuwCTZjTWKDymMvbiM4ZG4HoZXb62C5l
J1EFdXn1JiLL+FeQKxatx47bkU1JYSk4IgJBrgDlQEs0iV5cIETeSEQKqOu8ygaRlPHqRhcCRMHF
3EliTZhIVnOq8DF9rS0+VYMped/S7YKSdDszge75CXeuxIXCH7bJqsaqT7JPI9uCInRpLRdUE5It
y5YPLiT6VtNVHM+4aU0gmDVyVkc7xkqsEkEEkiqVCzTvN0HVfPk566LtZzcbPNN11M0PB7YIRbWQ
tPmC3klj+cxKXND90ylrD2fDHszCxmf8oLYu3nUzE19aMnnNyBq3xMGGL+WtcphfuQAZ1vSTT/79
edaTNc6ljq7T9u9X9dgxz8/tDk24r3d6CdbnzLvmo/Ra960pYV8pEV7NjTJZJEm=