<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyLq3qFquFDqWQwQO3Qzj4TEqQ7UPE8iv9Mu/z4S9t0JHfwVIoc3XhXPcBYLFIADsJTp05Mb
sgFc2vkwQGV9JlEWNgI3bspC4hr0/QlONYXcoeTaEDmeN8kNd4f0fxTocKKDgQuBEIm1eiKcFqAH
x57x/sgXfglY9HO9DSr6FjCUYTs7s9Xmiyo8fD5/KMVd6Ae+RFVezYB1yXW0wNAl7PiQgq/n5cXz
OY7PT5R0qTNpOsfbATvMxGFuQ3GVq8DPU6V+nc82gkQCyqV2yCGmDldWe1rjttow2E/xliL7z93S
A2js/+9QR3H+tpEwtEBylFdHYYu1ES1Q39MHl9iHYDS/o6Bnzay/b3SfrGMInPsmiW7mZM2roLhd
/d7Wqin8XWErenir4ufeXpWOuXHpC2cD9Qjvf1wwcryZOeDLIo/NDexRAjmX2/YZOAVKFP2dPbAP
w4K6WDcATaH3H+UDFHrBEZj6UgXt/MNm0Q8h/Xx2BoKtiTBtCkE6SdDDijNLaJJmcBnUju/PuYV8
pqH2/UPNzKRa7K7/SMUczZde9DxeSIJDVpsnQZiZSR/k/zB8z/Jhkl0PtvTApdJcBDLKBpx37+p9
UXG41qs8RKoq/fUPKQJCGsT5VjJ1vxA+6YgqNkldT5x/sXy722Vf02SKrwY6O2D4otLiIHHsKKm6
QzKY5o680rIm3Q447fkSzZv/aFWnjuP1zNa0VN8kFVwwehaL4qdOADXn7MsrE8zh2crztjf9N1AX
nrklksLvqvgqkhOwuS0P4xLa3FpRzBTsIviJClrRJOFFlPp2X7Hzc3GeexkfQd5D//3Z0lGxORVP
nxuxuhP4KlakvnaxiD/E7yrzIftL1OVh/77tr4DqX6qZWxww4YdoEbhJQDecMfCXDhx/IalgVHNG
4e0j/vgKB5VQspLINRZoYdHXg7IyTYs0PGETDdyF5Nyj8Yw3cm6E+Fe55HlfaREUfFg6E9M0Zp1t
mZCzA//05KLJYUZ8IY7a3VWKCgAJeZVLLQmX1fQnrioAPtYNJCufUJL1TZ9CvotnnOh2JMKVnx4R
Bb+U1PRCayxJapzK6vn9L5jkZVT94Rw4UeZczgkD/34z9gnq6B5P8to9AJJ2lL0oNT1oH38+ROZo
oOU7OnzLaO5akudrEnS+Z9rMj4AK3J5Xs67Sg7WEuaOqwMnty6znu3XnEarAxjST2NOppILFttDI
WIhAYrMjJCZI1MzHagBbxlf7qd1dCl3nCZSuzB9/qSEoqs1FDLXXyuOg57pPtnHsymjXFPXrH1Bk
eODiaMadYNlBobeqguU5dmNr5NXihjSswmgOp0NXAoDG/pO9H3XGTtNpBrbT/6SjcgZabHhlZa9t
nM3tIIf0seWgHJrNsxo4belNFr6Q8X4ozBQaNfaU8jyP2n8gDpfl1VSwykeI+3Ac2hkJyK1LwfdL
eFfOZ8q6D6JIcs/OdAbkd372o0LNZjC3E6MgZOHxE2BmY25+S1oIBUL2vqGIDqDqggRl13UusaEe
8Sy9mFJyjYs5jk8uGcMGfpZ5eAvoT09/aIOM/BRchGky2f4DmKveSsdYD7pFlXBDKghGz6YsewZo
7DoI6PBV+gRMkoq0vDg5tK+VEUTxyrkyC8YjCBCL6WKwM7iMhu0mVvX4OMkwrcu1hNpUN+O6Wby2
jRgLeWl/wkKzFLX0ybLZAZNxlRGjl9XmWxTCVCXR4essHyhkVB5XDHGWgcJ8U3JssRIBVqH/jU/A
YEE0FsPOUWnd+LoF7lMv626CuUYqlYW2Y/r391gGT49zenT5naBh6hXe7cN1cI2mYE9NAiiJwbsX
Yp6A9sCbXWfv6bgILVYjR4UMAWCea9Rjl+g9PhiVEsxLoac5jOwPzltHPgqehwxYMoQj3iOghZ53
dFSj5Crx0aq5ID2Ht5uGtPK64Hz4hUeCC7DD+T+Y+eJxOpcWitD6OjNi27/7xAUEizufncsSI/fH
rTI4pWOz6yJRb1lhR8mPHidlanujZQ1LCIwl5wTCgD5wFl/tNu3yPRXlGNW2RfRHmHQY9sDML0rc
cw2K8OzUpgwA5CxwgVL2Gh6kVTSdx+ZK58GtENWrOmEQ5WqsxL12cHuRBALI6GPCDyzrOZNHvJUN
TtWF4kLx/Fdx+EzIR43KaFc++fB/tU5IGBR8OkcjUcddlM4Ve3j806yi6MVuuvzfuWgTu3Kr+CxB
aw0TcEIIHgxxyeEgy9ydhMToOXWWWUQKMSvpuvN+p2z1k1wFbyYSXa6hNGDZLGTQu62HMoBZaU/I
nunAzVJhbMq3GWMQCYDr0Sr/gge+HjfLMcTa0S3db19XIYp5h5lWMqiO6TLyyyycVtgJuElRyQfR
dC71PTOD/wuFq77ZhfhfN31oYtxgWNziUtvvM2YD14NT7NxwuZCIv3hmRmp7rxMN6bNzir+SmOnY
o2X9SOyxwmyekARtyu8MOr/Ht5d7mpdgvAYyTl3l/v8cTHCrvOe5XvfMTVXziRI+BiWV22UCrdu1
51GL8PVWbJccnxWd5qpEB+c/L9YWLWZSQOKp94N1LzoZVZBCUcnS/2kHdHJ7v773bbN1WqxNToL8
Em3WGe2YqgBg6l+ad6J5VAKtmXs3JgVgB5Lli2I3xMWnUoc3z8c0Yp8WTe2ceW6mAwHhfz0Eaacr
MGsMhkcA2JLwbgGpbr18OjVsghQg3WcjdJjF8Hi1Mm6H3GmXGWW+xkLpP+zmtilQifpT3l88frO8
QZNIoLq2U/skQrhwZ5uitUTXEYTBs39eEIT1UJq7gNdWt4900qNhMAVFoxQ6W6KBuooKut1VIsoA
aYutO56a0KgHidd1hJ0TntsDd96QSU0hq8ty0NlG2uWTGnuQJanVuMOkZEUZJ9n8BeChpUhWNpNd
JUFrS3G0lUrlZcKgNC4Qc4KHoMXJW0R8h+FwOhIRDD9LPl0RNrXDJ+HKER1uzW5b8106ZrM4Jtg0
+vlrTjniPy288vo+Uu6bsjT8x0Dmwmf7v9Z5CTw0wS4a8IDcrLgP8oTUdTa+1b1ig8x6Zde/pya3
qyC47A/UQVsVQV+VA4uQx+jfIpTj3qea5yMwdKuAV2vgbu0NCBDGbKBTofrKXkykPaj1h/+/m61f
FUdqpgPImGXTflSOZhULLW5s2UPrl4dj5SgyHRUuAnAEpqlQoQajXkZj/Gbc2iEyaD9dBduNxHEU
JEFPUA7FTKYCUQksK05tDc5gn/55lsFz2r4RL04HNrup5moVm1Jah5KoJ9c9Hs1fCk6bXftJVfIS
VCDb1+8DxgiONLY7CCxv96nrVueeAuvUdSfXGMh6HQVDOpJ/lhwmx3J8XFrWvTX7fw0VOUfeFrVr
VInswZVziTgr17oib+iFqyF4kP49eTlkf5v5D39/Dn/MJQ5SS8XC/ou3jQ/GTKxEE6dDZaLZno6K
ZfAa/Fxf2rRzlCulutztyMnZvk1FoEcfn76TMaX0HtbUUHHtSVyYNKlClucZWCaUV7ooSkj5ENr5
nW7ESnFjPZ7bDKpgMMvHr236Ee1ajVP8ed7xKBiPBZsf51SHCmsZAoDY7elwVGiA+ZWL2jTjOW1y
DresCWLJNbti3MnkMup69F2zmNjDOTYjzZHlLHd/mZtkyFpPxSLwTMZYkbD8YvnnOEyW5gwCcJLk
H1AG7gVGoK4He4j0Xmw0Cg1sfHwkIIMN0LVjSNQTBlSg3eCUfpNgwTrh1bezVmUqBhaeTHFGeia4
HxQIvSHONo6zZ7qVPjI2GpaP3YlF+SdTQ4AQMCp60Tv4NMStjTANDEHqlPtkSKRp4RI2/6+wHvkN
CU5a4uTTNN35TG6Ng7GnXTypFh9MNc2gmg4uvPTpMjucJyz3DOxwGnS8AavpFKa0k9l7chxdw9sm
5OPiaNbicDHEp3iRSdWkaDxjsg3GQY4P+SaKpVBN6RhtjxIFoWigL5/mkF4FoI+UAWpfj96VvVKU
MOlaOa9ln2z8QsbzZNp98BzqmQIoCuJOi6W2DaEJjmuBDNMKuMqO9OhBCJLfrPVTY3cmGxDwNrEU
9d5rlhUbMDturdA4JX2ihcRqBXXdxOKpUH6hQ6tcx226bT2m+UERqjSvReRA1l+mI/rMWBmzhcYT
UhGlgQWoYqokFZqa6hIi14sPw+QYDDvXmqdmTTKmcZ15+SZnX3ZLpau41XItDZ2CYNT7yG/VydW1
kGE/hCgsc7sFVMaJ8gUhEzxwbGyxgtkQHb8D0WkErgqeYcAK9F3liyyNOlhXsrbsiHqF5aK5Deh1
UndiaF3t5uBShYeuKK19Mi6ceC0th5mnzgcFX2PzLgQqyz8R7p9sUKiQ3EC9UatK/eQVu686WLDJ
iyIhe++Ufe0AmMm0j9E614wvP0lP86G4ELdNsyvIaxX3wSlDTPV+4lwomOpU/dNqA54+ejO7BwiM
G9SAmoQ3On/UcRH/dcgpVvzA21Md9LUturlslXS4i8C=