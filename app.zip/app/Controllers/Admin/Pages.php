<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+ICO9BeG5cczKxriKu3zRAQJbLRZhWGoAwuD/N+mO0SkNPqp2IW0Jd3GhQRXuIi3s3bgZLz
PJYayswgObUHtONcEKt+zKhDaot8dEy9mvxwVWQ/8ndreSAmTCTVBDmTPNVdc99qbZjT01irppeD
ATiuSyeP/Qf4tCIoSu88MP55ee1TNRGkWol5SEzcJ9zih1In+IgQzjy9bCu28nEzylosldJ4R1Ct
uJlzBc1vUhYIbA1G+mng+bBg6n/MD1OkJR2bDDLlWsO5PxOd80HtjBOotrngYrRdR9XqNB9WMzKr
eufv/rVb7HPmHTc5fAoG31MgtipSC0VX7OY4TBFpGcW02WodjToGaReStQq6zAQpDLufCjnbSxJT
TMm5R7qPJIkdmffM2/OPrrMfU/AMOrlbjSs5hoRLE0CrG7usel5Lnmztn0y9SYQZnPmVCpqMgHet
8KD2Tga99gdsYvhLGlMbg5Rt+2hFnYaTo4xKI5U7mccmAg1LmahDY0Z3Yzf0Nio4X49z78rRCtfk
PXYaSS+YX5jIAP2M8IWaWSfv0DFpyCi4qaNA034PFW1md5Y6WJbaBs4xSBBBsdyfUozSkXdx6aVr
lwMANpRnwBEBVU8KLRmfNAzo91gVvubMsz0x1ttkr2V/rCCsNIb14L5D3/EhoS10vJujr5FBTC7l
42yEUy2sMSlujPEtLNGQISk9HF+YZTtQvCEXyQNtTtmakhBaSNoJMLIz0yyA3bGjc+twEasxVzSt
dQ92eVLJuOzff94apbkm8qLtEnIYjePfidgyBd1OuDi+Df5z1HoxJmMzK/TqHo0equ7ZacS4sZu6
sEpV6kYbtx52HTTWZ7j9eFVz3X4wPmK2NHhwMwHSXqzyGNX+aFx7ftGQZbW4upNvlLAHytJgZNAS
X8TSKRuzoTPqTyNWx/nUVafTWxusE7MW82SsVeMCGle0OIlPyLn/0l514aaguuoL2d5iDgyl9Ibz
+ExxSKyQRBVvS3UKzegmRchYsafRQ2keFeANJzh2MwLxTw/QcNNzwWhaUqhcqY8/Fmd8ABbetWKO
3wPzPsR6qmJh5pW/TTuLU42NsM5KTBt6LcS+aJX+EaZWB4z0WwFE9epoqdvM8BYqvXauc+dCi0uP
nb9CrbPVtesZhzj0uDf1oKLW+dDHW8uLcFCBRGx9DR+UqmXqlO42eX3dLjMvJENUIcEoYziwWA/d
no60k1keMEYM8ecsqfCH+JYZZqcMFcIOKlppVSe/EX65EKzwq40Bmc0xruOLkGqPfI5w0YsSUOkd
WLKceUExu4VCLFMDcAdbp0DL8LToPGd/aRMmt2WKlUCphE0ik1aFWEem2GTrenRdaAkaRlhOxq89
pqZTwumj0/e8fEJVSK4lECbp/oFBK3sKoevr1GwZkn1vdZ50xGh/zWg8Xmd/QWkfiurWn6N/unFF
HXsqrJa4EmosJuNQzm4hRvhvrA7Wato4iCONqABJ9uEdjCJYnkKPdhUSMkgDwVdya6qtG+L4Z+yS
VhAhs9ZuHNREu3XgUi5N2gLkpZifAS7RBnnzW6P7ya+2wWOW0FMpRTvYS8x6RLxqaV5mXSnEEMeC
5O9pjCq1p8sA3WL7v6LL2QvJr3eFotTcaiXahOW1MyZa1Gm8sYhsThIKLra6S30nQmCazAZen+ms
ZFmO1JU+Ae2xoQMw7nf5nkeG1CSckZ5LrdA0CwdCOBJdwS44eZJi1nk159paDOG2UAS8HSwzc7Wh
O3Rb7YRk8kUgPGw6EWzwiwIXzHna7hHngWIxloiYr9C=