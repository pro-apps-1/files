<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzeFde73pMAscj4BekzW3jPyL1BCg1anDkKhaeF87FnpjQ8kArSWfVqCncMOFcZ86D0lV18O
/Prrb/fLWB1d+hFsJqldRDLg7Vpwb8nfnc1nWoXx1TJQWXEgnWPqsHM70PnEcTjvpYpN8zpEG0yG
LmX/YVeR95OoaIvBtqA8N/9nhi9YDLVVcSqGnWv/DhT4DHpHzDUZnLDQmE9or/Ch7UnuHo+rhD6I
/607AbApprz19P0XMKKq7zv+0PuRxHIyrpenS9UP3akqAA7vAMBNEUlPSjcLScZHw7P4zglPqltV
+UDxQmx/xDXrB5IQhrpdJdZEmHY4O7LJlLqJm+46G0a/FczcCAmRdM/gvWhBjFv2+/g5TiMxLOtr
kRCqlQ8KSYVzgrg+Gjr0LM8F70VEbAbVSQWECQGRJfbVPFQrL7PcLuHSL7iL/+GumuAwj2bO2HS2
SfeZP4B789J3OsWryHngyX3v70OGqv51aY1RbR5jl7/nE2WdwZ1E7vzqjIEMY0oUcccKxx63751b
SLYsMnG77kXk9S06MK0Go3/qUbDttJ8U4FyDAjPDxtGNcHVJfScJbB7Jnw0kKQpcRGrKa9KOfNSP
RsKMaYnn/zhpBR3ZveXZc9/Er86s++KBLiEeaUpfbNOqK13dGK+ZrKyrHnC1ZJOaYiOLaB02Q3OK
9bK7LlE7b5lnzALek8oHRqatu/jnlGDHlBYS6f1OvWMk7sLXbFZfI0iDJx6E1UGas0L6cE3dUIYE
oLfLoE99kkUvh8OZBElkrzAbiHl5PYkp9bSRKZ2+2ohI3S+vab8xsCffvbwfWlzv3amd88YLkcYE
BkKxli+XcUP4TWV+LZth65TN4Fj90ODzXnec1OfMC7k9Y5oSiShedYnGR0dz7m/AOyrIBAsnJ+fu
b2cjigZomUI2PG7zNw8gpYUBGyI4aHF/6+pg7sRIJp7Z+AD6j+GtO5wreGJUJ7Cq+MxGpV5QNfwI
qFbYRxz3bcjur5TM+1Tv/rUAjUC3+DHJQCn3tnNsCi29E/0VXLPL6tUDBWNXMOXCDtCKkE0hXG1E
2wXJUGElh8ZizmC0E75tWAPmvzrrLS3mmeDfBVNKISIV2Pd8TFMFVGzZdRWdWMo/ysrg+469LzU1
UK3VSctHR0GpyNWrj6mU7TN6VNyCMMbaBGsrLRi4h27K5M4XDkTZOul7NDcn1yQForRIsPy6zbMP
1Q1M6Z3ep8Yc96ZGtLbwiedDAdDE8scChT77Q4qTMfF9fyw8xS32JrpV5TRA2hgkroyzqgucPBFX
mgdvtm/QFLUeBk9WolVFLtBOe0ztNjjOlt5aCUkufNCCo2Nrj2ye4VcY5tF/KoEEyis6o8eIldvk
IlHmvfN+S44N1Pm+pcjyzqnEcmr90syHxUZ84XUduX+q1eYGDTpYTM0EVakDx0tDEzQRsrfzicRc
0PLYtLW2GfTsDMXNonr8Pev7WyMXLQsCFZ7OhnU7fLjyEXU/WFGez4mFYtiHu+0CXyy4jCRr5OuS
Z7dArlZ39uhzPSApdBZGZBCx56G15GdMEYh11xwiDsbIwIEjsbcv/PxO8C7lSLknFhWnRJdcDQ17
nIdzLBxBJdpgyxEHrS447x5vaviMEflUL9W8x4tyb3/M645IPpGd4IblN53VXX6fTnIB5h2XWp5O
eZ1jPexo2AeBjoUU2OdHDgAXsn5XuM4lXwc0ECOUtFELZhXx7neDmKbtfzKv1Vcoip+96Wwl6PxC
5wj9Qfm75ZsnWOoKzh6uetHE0E3mWpO7+MEc1fY0xr4m5ZyQYK7BnyG3z1+OhWTUNqYaMWV4HXQ3
7lj49okNG8wDW+PQ2noyJF5x+tVYtrZluOAcwIl7C4eRT6WGsrMFIHMOpK8jM9WAKDYE6DUbeprJ
vzz7jIgYQpAMa0nSNKhAx9v65k29V6qc31/Blw7lRm1NhjftMr1A0+qCBM5r5yWri6hyst+eNaIr
q5cAfzG6XEJskk2X3h3n3GEVaAaLr5pnw4MMRCobYQtaFGh+vQyiY/3v6cqnIXmJpMBwBh7ELMBc
LPjRkDeI5z7vcOCEHyryC027jjci+b4b/8mNHmA3VrWgozDG6jwDzEeMr2zSnBEnqAW6mMCBz7/c
qaJac0a8eLVaRI1nSME2dl916kEiEyBuTAl4bIIWWdbvbI29Er6IzMtYIPq+5dTCqy18wRX6Kmtz
XvjtgTP4MUM2OgA1PMLigaKC55nNmSF4fehxkjLdEKguKhJ40i057f+espjVkJCX45LOgSvaP66u
Tk52DSOIQx1jtyI20VsVwvfKTlKNazaQsmMJk3WnP853atbjLBAmRzwM0nT7M0RE4FMFi77sXMKj
viZax3iV0nz9CPccUB8UobsmizkGGdx/iEJPlhGRABXy1LmaYr5JABnb6YGEzZcjKmRyFzM2iKMz
EK8VauNfhLQrdV9kqubXypGOKJviXVE8HhjvSmhT9kvPkJc5DoSh1QudRugigojOy/IiCHlT00iW
vwX3tawS4Dajd8k0c/EaU/6/7YwBlthvUN4UNGLA2uUdOWnZfhurXpO4/dy4MJAG+UAbIg+NmfJe
5yZhiyRuG0FIfbjZ1Wa+KVNVFgw3Q4mNxukVN1YklCKvxyvh7RorSe/PNLkCBhG/VnXxxcu0+8Gt
89AK1s/QjPTYyYMDJDOBEOlQ/NFKmt5kYBTujg86VBjIbyKJc4kiU6JzRaetPlLC1Gz4HFzYTcGN
/x0BVc5E1tUyHeWvF/i7TVIKqgDwJQXNBUkVf07iEWwb1NccI0q9Vz4/U5HwqgFTickQAXmDEdtM
+/KlYYnvhgdF9eaFYNFVugNmPEWnOTd6ToDf6033ydyGXTMj/HKtV7BLNtBl1U45qdJ1xWRtBgax
uc0MTHZpxph1Hqyt1IF3J/7BwWO7r+fNpVPjXbb8plUHqnsAdGu30XpmHGbBV66qJ9UEelr/AsVu
khFJSyfxsnwW6N1QoH18R9Z5LNS7wPWpVOTLSNxufTUWkU+ZQx36ABZ7p5JVttZNJAq8kdTEyG+D
vX6+L/OGpdMGNWRE7drTfpH/gAp7jcCK24zIo80AdxoQf8i088K=