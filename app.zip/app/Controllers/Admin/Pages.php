<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq7ITkYSZKl0MH3Zon7911hLX5OLupfGzPUudKjOXOBgWy2JzGqxuKJs/kDD1dw5iPQurFFn
q4wMY/v5PlXarT2MqBwK1oTbT67FAV5eWtNZJ803l0YVbwHx5KV1/w/g0xeu69su+mYXTeoYGPc5
NtppYkBquSjYAQWvOyOD+hE5JKulIcAlcaUFiggVWRQTtevxhMjSoiozTyYYEIE6JoUE6LHVDnNk
2JVLX1BPYoGm7ooJYyridBctJWAz1s5FGzPL7nWRo2Rxs85Hakb8U5GQA+jgD42H7nIxx8YO7SAz
TsfI/vbgm2chGlE3Z3RxTcgXKAuKuwwOvEuQhXtgozx4I4t8YVtn2loCtGuWgAjc7bMYctN30X4H
3WgtjQiBgLPmAHE+uuue5JhWbGH/SkHMaE34GdtqCOEaSn+zydXCc2ruVg+4/c3tkworcb2OqPRY
kYyAOL19trJYqkeeuDG+3UNOjxTGtRno0jvXo3WGIJ+oRIY+hSHM84eDZN8JcCYsxVsPIUBCmhZ5
qQ31Kr/HtNJy1Xkq8H5Z+d63NnEl3aMm6PKPBmIa5VEahR3RMiLtSvp1QRqxPnRTG+/rKIogBGMY
JyFxzAMV5vpxoZhz5hPWxoV26Lu/wq4RSlHshA8FRtF/ZS2EjR8D2+kYMADns6nz5QTabjeWuYKe
MFX3LDMSWu+Q/Vp3RwPUr/vqZafWskTHZxnyko0XyoDW8SfbhJ0GNdCCSWkkeHVRy4YHtaH0IAwF
DITjiTLS6CGMFs3DQf7X9NhMdKT3u7v+LvElWrL95YXmX5bnMtdix4btB6higWUbd35UR1Cjrl4G
ScaTJ06XSBgnwMe7FK/xSdKYT4DBUCPyQH6NyGnmDwaJmWHCFqhRAW9jOIZRs+R8ARcufJJAPGh3
pwDhcxBLsWpd4A1b4z654bVQ+7eVCRusEdtXKRkdCbZjh6RryejmQqOqWX12Ic5x3XlikvFs6rK6
taWwBqIY/NaOdvnXBXEstr4DWlXe4IQ2HYFl3BmIUBEuSDbrsfR9oXZJNjUiX38cUA4cUHHr5BxW
8qp5ju2/h86jPRgLSOj7oez5ARfzIimi3BXPzGyszXWMt9UQOfA4clN68ATAtpMFnHAd8KGT1pzy
+CHJPdPRmHGdZZVcEr/TIGyZqbFWTNa28X7+lSjkZ9LiBMJZlM7pTmVXKZu+3Njny/PToEnEEtbS
Hf/z2Ms0I0qpPIX63UGtbLsyI6yw/HhymiblHDX36x2DjJ+4/cKmArIEzrCnPDY65hmLwVKv11q5
GEoBJGc9fX2S8cXY6iPLgBvKrxE2lhSoNYtm6ZtFWHX6lH1a/rcsFm8pOTGkF+GhUdpYwHMPc3HY
X80YKYU95T6BkvBmSDNG8KKIITDIsHFRUn1BqEKqH4lgEIKg2NMVBA7BTuUgVvf7mMa0IwLX7iQV
1aXcWS5P96YYiLG+usfp1BDr5DGNLaurIX55ivI3n/nPZh9IcQwTD3wLMK+4Es+JOjLNc8+GzcJJ
Ri/SSXaWEWZofWV5tjL5ZT1a30u1tMXUlxJ6ha7E6TuIyVofKU/imdfYy86GkkOcUmeE0+yhUxcr
78iepO2a3eCKuLnpIiOgEIiiDN3mvuKvdX08vujA2dYn4uog1vtPEoa9WHq+liajrePEudjXvhzQ
0xF3bMfPs1P2CvlzlyRr9GvJbe0aCivCh414TO7Rlr4P2js8pnO5VjJHWuggduOpDPin1owcMjMs
FxctaJdMEqAFHZ9MBXBJmXdhhQ0HHaa=