<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnEubvLx56pQ0de2jfUZdkeYenysEz84n8+udvkv8UFNbR7ACi0Fq5qAe/SpX7tpeWwgfJ/6
U7PJrgwN1z5EFsk6HeY8idFW5bs6o8xJvbvffFr/byz6eiRPoxmndaiXxzexSGVoeK7hVho53ARP
8O+MoOwEkd4uTScUqfbt3XLw3iNKAJaqOfADzsu61wyeTLZCfaxaTObxLy1u6RAXMtXTzcBus+26
9n9lwxn9ZB+kMV5Hw/b/OhNJa2YQwR3fKuqpjJZsJFEcll/GK0o4YwaYPVfkoDZMaWcovnwkDwxb
Iof8/rQ8BX9dGCju2gt8yzASI78bY/7s98JrCvNcRwy8oKSawvIM9+eRRktFol9b7N/cZbwy+AL3
uGLNtJ+PbZanRH5rXyxWJkssD4JkyyY8Aqy7oMH41zvTognaEY3FTlyonc2HTUEC+m9I1eqcJs68
uX2nIsre06p1Js4pvDXEFWqMjpbwNbTWireIeNW5TCmlsJBkeJuf+fOLSBRWNic8T80hwsSWCeNU
FcFvI5NSNjPfh4/u9Z1EIp0JdronSdqpC/OIrxpV3Q/9a6ipA9WeJWz75wJfJPdAh3rEOqNrJ31Y
llmAh/tKQ620ky91o8tCrPDZhhAxCPWD947fADNWN3/9tOWAzT2DnWrVEjDKbFWpRax4gx+wZVxQ
W4AsW2LR0MYFSmrWkpj9hO69lQDtg0+8zUBXLT7e7vxk5lqfTCpYYh8BlAZCV3ATLEh6V8Fk+5Fg
pM/oya1yl0hVlIJ3HYpOLcT7aViufQc7r+zMAXHUmxB+6lBrj7js5FroXMqNGfYurIfvbwTkvAyt
dUAns6bswNIvJMmZczUawP5iIBNG8ikgXsVSTK4tYf2C+m9DihYnGJt6PH3G5XKuO7guNY/odLWc
o6LCpBUCdtP4DVJdXh5AobpHcXKpSircHBlX3ffigswEQOlotNVOYw/tPgcVJdAjv093pZJ+fs8v
K0HARTvnKF+9rtRrWlJxPQ405uMArsOzistWm0uv05g3xB7/p8EqSKY5WlVXQGQ5EQw4ye9b6tWE
Vg9ZC2Jkdpd2+pBfP6+DEHNwwGU7EauakNrmFpIzQ48Z2oZb5c+pSmu45UE6TC7USox/uzxxaMa3
vfLLl08ODfkMvBJgdxT6AjGrBoB/GcQMrLeOgl7JI5HsrvdQ8SCdJY5LPFpooTqOe2ZuKeVuWNbN
uYdlRGrvPfB3dv22i42N1NIT8EwbGEjWh38JjJONvHysv8y6MnJk8So6d0uWPf7w8M5X16Win6iN
XQQJVxw7WqW3a1cVLn8tbIn9aHY/YwNi+XDABjwzpHaJlFHRdEYqhBXGBFXsPOJ2IP8NJEgl/uQO
tc1uT2efnFjJbRgOQsKV/6SZiLOW6hBLci3l5LI/Mnm5/It1siws1r4u8ryzEUp2wkGvnRBhApMF
JyiogiviVtMYk/C6rhPUsWTrC72KA+3FQjQ6curKy6xxejb5pqJCwTAhiSDkCtMU0P/cZfUfWwcy
kIEQT6orcDt4ANW6CSqoH5AlXivZI9leEc9jk6ILUPq8y8YNa+PLhcswnDDsjU9wSZRfvDooTQOc
bRccTKqZlxRLiSBeac3V8nufobReXk43LMzhiok7TfFLMbRRxCz1j5/+clCPbPLO0cIjXmkoLMse
gU2JljNFONJr70j8u5693bqdRgGDWa+hTZers19dIcZwvvhQEArPjAGo2ZMwzT58uUE44lA96aO3
trzZPtmOfGmcHHkp1M8qwUtNTvsXUNwr0d5Pi1esdRe=