<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoB66OLOdkAg9GICfjAARPsH0/ZidYqUuyDg8m2Sv605Y4HZmQ3yfFbgyjRFTiyDAwyfC1yV
62fHTQRk0WcH/eHKZxvo9uxyEGw/9EVuK1SpiWHW0ZX5UU6H8X9MhZP6tkYjXwK7VN40DsHM5s2T
h7Rmzp1oIWeJ2IpdjqM6xx81Dg024w5DX+xOZ4wvWOe1dMTsqtjBdJhbiyLanBWPdDMwinslBD2P
7eZoXvBd9teUU2pDFgSgZRev/bcewAhAFHYo7IeADpHZv1ITmSJY4lsWpyFPP70LWhj00HR5dVZc
Ke6A01zD3i+431L82J3pcQeaA9KdtfDuLufs+YUw6HhrZWKrWAbWCTVRKw1Wx3kBdjNddfxWIyRg
4QvshHShpCvs4440rAGjylKNcvhYvE7LbSwcpk1TSHk0HNSxPUzJPXtLWredHr7HYed9VWzR9/q0
p+Wbd+BZ+ouUFrXSSvbXHtc54xxjrE1QIVSZOluCiMedHSWZBe5f0Vw9f1HmQX+CzBjOEdCdD4LT
vncWJT72cvQg/I5KyvW0j7RZ/YLmM1rHBR3G7T5579fbXW9K6zgFgXSHymld0GG4+acJdP1L6svT
sLJDGwTdq8JxOvUU5W5GNIbwHcx8sX+CG9/59/M/PTpoWoPSWUPFeuip67l/N5Sgd2tAzgaoyELX
28zhqqKX/lqYGvGGaobP8VrzZLcKsHV52LxO4YSO6Z8NrxZJGmfc/P7DpMceDU0bpRCQbDxGgSu/
XPVwjucZn1iTuzchzquWs9NPWnEfDnKwYNbreNQnv4KxBGqwxOv7Y3SD2ehJyOqIy//W5vjVoqFy
Th7Q81tC8cLmcSnrE995T6iw4qJET55oIX9m0+9+2ROukw5BoMD7uVrDET08DvYhoNM9E6RU+9tM
e1DALS4jxTa1RMXa5SaeoMHdAfnpWzo2+52Hp1AyG3IjFWzLlz0uDtd/9rBhs10GIotEc+RBIuRq
UHVXPL9AZR3136W+Pzd14Fz85Dl85Q5jCshc4cAjpT66AmlGC0wsFj/hyh3XKPD9AmmRl/T9VSFY
MZkIxu9NWTwM3nrPj3DXr98Np6+q8lbBXJGeJEQi3uhhZP+sMrmKe7U1VRVCZUg4U21QO5/LYhmI
x9DefA9kFViJRDa/Q7fWEsRVf53qKVpHy5XHAdXtsFQZNHzFfQPVbsOOLI1K1PAqfrnQLtNp1FOe
t/npqoFDOKzBUitnHfWGQ9s5d+7rHYdDXK4I1UnaX8guRPvfLrIi+VuR5dyh2KkLpoJ6741BDa4c
BgSHlzsropAd9RSQxnbLNMCWjlJN7fn08MXjlRoDd+NBg7oOoNufxgDttSTJ/n7H/ykB+41IJ7NR
r0QqeQ8T47tlszDCwPnJjwa0mZhjdSQe6le6EiaZxFN1n4olsNhLaxwFsTTs0HGHWDt8KkBReGA+
YcEZQuUJaG/dA4LSH/Yd8treu8udwzR09aYWavgB9S7iALEz9HdBVQ62MzgTd800/AkyIMeZLcnj
UYSDUOy02UJ8crWc1hQrYO3V5Nv3dv4R23PGJe7A/G88rBenakx1UuFcdr4Z4Tmd66gv9HovYXvj
PrRNuwJgw/5cSGS0G9Iy/BXpJyPsDsmwq499Bk/vgupFk0JZLN4ECKGim1VlFoeki9UuWpAPIvm/
pcCIvy1501V2m/r1groUHL1CtBlY/uSGT49iqgAkTZg14kvx+RrTwMUHhzkqftAodyc1SQ7YLg+4
OGfFVpjdITfisY/CjuZ4ncb7vGQWgyncZ4TomkqKpqUd8nWTBQCTADgW