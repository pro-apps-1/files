<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/IzyTNy4yeQ+NzazhboQOmiCAb6aa5KBgAujdzrU3l5YuzCBBZCGOerRL4/E9CNw2HhbinX
ku+b0bklHv36I+WPPPxmNgPM4a9Ezs8LgWGiMgi6jTkmjbqYTpUG2J18NO9CzLjOwU5qLBAkap9E
EFlFQWrTUEXLXGnYpgT58QP+OYknUWXoBvb7J4G6t/QUcP1bVtER3OfMZY9g4OeSnBIjwhODlqU3
a64w+EsCsm7iMD1MqO8sfuAGzTzglIp39QrClg30UZr/oXUPysMTD8bFf8Hc0GmGa5QC0Z9EqOMY
B2fmHi8DADH852Vp1fSFL1fHDSZ6UHaaEPKzvj75zSnp7lLC0WhXmWl/84AS5YfRC4nxewmMIMHm
fny484bFGCeQLGIsnIrHCMcGGb6ukXPlim4//a0o8TNN3kzzRWs9zCd92As1TKQfk9+Ob7ivI1U1
7r+qQcN3shJBliVD0EQ6xe9yh4K6JrYbRD20zBGkK/pev8DqrYaREO0/tfxMkDV+n71bMOWKMRFD
GYrYJ78RAQWM0ikc0v/fqc0DzPwqq6xiHH61rD2RBiFCu1STDr6bGrREpYPqkiABIBGAJHKDj/92
itQ8Qfeqv+ktLWTqS80g4ak3CG/IYu3ErRwXqbkbxW0HOdl/att/yWBsWkRhw9TQy6sWbQIWrai8
ElQ3w9uuvBSFh8Opq0ETOoargciRN/9P2q3TItfsvaLeWzkadUHoeXlxSll2Z7RsaES7+GiKBels
Qnu7NxvGBnpx3jiciJPZPL1QxGQKNAE8rR2Zzq8Qv4K/cOzWZAi2NNUzVMN3kSbqfBc0XZ9AI+aN
CAPYm7mUo3OqGSwFufirGX8K5Qsw8RvPv5r2bohRpp9ZRgXYDwJP3hasovBhOdwAj4bJjd6nz/vD
1WvX8UnDVUwOHQnOhtvI8mtL4oy33GyD7fIuBWlcAiRbwHqpHr0fDykrvKJ9EcprRNHXkVUbef9m
/k6ndFzXH49L7upfmM02gudSDBTseHlUKZKh+v/6LHhYhpvgPTtkbHaCJor3aq/t20O3D2HaioLS
h0QkNKs017GVvL/KJeCiIqE4/riZNCa25tww9txD1CQVvlfxfvwHD0QVPneeIsD9WsFNkoZmBj+R
61sO/K0pSV6qxeSZ4MI2/afTvBycUcqsQBeZ+Fa2Vwf7AdMpJh3vmk87WTK20ML9Ug5P+pbnjI1k
AhY82PeeYEXXOA0NL9+pSNjq0/MpnwJA1NIrwGu5tXowPxVnM349DEeBYXbiL/FPjeM2FeDOwUvz
NkU8qNVclu79mwluyfP9J+dhuhGJ8Fg12niH/UTz/y8DyDL7fUi5u9quax7Sd3J1dbzBOZy1i67Z
JISRfZSZpGYdhNfqwcTvs4j7eUig+l3OYm/epy83NNByw4KBQB52U40clm0pF++W9wR6XW4hzVdi
3rM9qQ3dODUpQkKBMKYWyqr2mj05ArYmaxTiTelMvSv1Ulcz1LYR/vOPQVhEi+MXg54eoADEGYr0
Y8yxQt5/ddyrtP5O60SevAfi1fXDD6luf4XhTJFafQTH8ZGMVy2liOXA1M3gKcLOz1bM5Mg9JjwH
V8Kjp9Y6M2E96AfqXh8VEgAAI888MsNL9ScHKzziI9nwMWBJpHBBBRGauUUn0aJE7zW0VFpJiZFx
ptrD/NkEe6vveDNRjb5ODJT6vc1AAcXT18h+TZxWTyygWrbB+jjaXM8W87XWiogh98mS2q4cDc91
+9X58HnMJa2PHS3AC5aIThqflyp7jrRlieCeIV1mYAcY6xj3