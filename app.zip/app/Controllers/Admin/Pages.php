<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsevEMIGbe5BRVkiHwuW+l1jqmLmPOMUregu5ofhC18AXQr7G3O4aOrSMg0bIu5P97BB1XdM
jS5zJCyEYNJ4vdmLGvWOR1HP3jTWTyDueKpiXn/jwismrpyF2V1yjyOMBGzpgzFFmFyq1CHEHExv
3vmmuZChoGrz+p23u9xI4Q2aGKxjWlHBAMkftCzb4FfuNQC15gMnrS/XqAHCSzgEWcOSP5G0G0Tm
yyQRrSEtjqzAr/ReGqtW1KzUqSBqG1N5GgcCk2WvKiNl6PD6Df4hcB35xvzdMYo+IQa8u8kpeqgI
jOfaUJArASQlZ4F9xhR5snjra4RwiuwCtQC2QWn8k33xT+NvW9PvbCyFoIu/TRCQoeKFGdtzmU5i
TXEuCL9ulBC5uRajDSYyknXQweGTVSsFzyPDcehbwCbqq29i22xED1u7rQMTZqJ1I4yvEQxEuVy9
v1jBM7UO5PNnAMc4pZLkscUVGAfS5TZSO6upcrQZhZx3/BmKS6w9ekrJS3vEwD/bddAZmlZ1cr5b
AibCGlKCilKhDS9kp5X87O75WCLR0UBqpb7I9cFFavwn6fNBIW7+6amiDuRf2nKMSQuTcAulHdJz
XvLcDLvCcLuxieULpaOMo3e/m+RAa+6SJmIBIcl0EVXoxyjUcZXKgA384Y/WKA1QE4uj8qdx+B7H
Lgw1ZD4CE02ILwK8TnkTI7COfeFW4p9HN1teq7TmAVTMmoq3N1iW7TsbrDpEuTrTcyCkl/np/Py4
2cifQBIHjEeQcA4igdI37PbZryTF9h0qcrCgrofaR8ZjVRSSZDSvULGWhy604d4gHr6cbmYPjTsr
hGeEavKvpPiWi8DbCDkiLqoS+jrfSfx3gmrhWavIsfTxO/7uPRrqmO77WmgJekK6s4/ZMbQewurv
Q3SgEiaSSQO8KnlIGu8x4EidTx7D+37fQM81grwLnA1JMiaMB0lCRhTnqvWjDmUIbtA7JNdY6Fb6
C4webO+KNSqQ51g+EZFWgNhoQ/XvDxrhp6FLbDVvPt4EtluHFg/yJl29DJ4zrF684yCr3AOJoeiU
6aGwebe9/2QQ27JBEPDeLE4bYnvWHRLhBtZsgmfWp7a2VzagmN/xAHuT3s+zsHFy055v+q9eGZ9/
Te93Ek2RBX889+IjnPzCR+17Syfv5/uWV2tC9HLO5VnWYTFcHCnpHpSVLG+bRDfNbYkk61owI7bD
yu92lQ7o930pOf9eQhaUAJ6YUk9LMsrPdvulrq5iJm3spHuT4+3+LUCWx2kuxDSA/sy1HG2lZjTW
BBfx8kFiHTfGshTej/+SAWxs4cAQfAzPmHoJp9CkynWKTy5MAyfpyyEiRdHh/ukL5lP3RaVlYDgS
nn1nMmF+VlJgsuplNJbo71umQOu9U/Kztw1r3xomORlFaMiEYmgu4v9+wqYHLyUNIJNkETnRJJQr
JNn7GQ/8Qf5HExZXQo58M4tm2riF3o4S2Pr+OzLTh8tEInGmfJsGmQ2dpXEL+iz2ryLG/fL/UAnG
vTm2a2GvEZWFT5lCPq15nXYTdpP+wpRv1uuWWd2fOYoEXKYbBP5QlkIYUd38qiaYER5B25o6LNVj
Alg7ojfBwC5KMOQbJ22FWojWlWBDnVKDythRCNBmy+rKxq1P/gD8sBVd/kraTH4T4L3rfY190sov
SvhjOv8B+R117OrzqUFy72XCqqIKxB6XIyIohj/8Pc26Sn3C1fPQaFvu0CmpnOva/5NBkbYyTOUv
p82S4NcEf4MswRHsy9klaieLWC6xXzEiSrpOkjZGkPImZcn2Ahb7AWIl