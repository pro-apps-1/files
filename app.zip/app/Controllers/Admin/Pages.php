<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqOwFhg/bOAzHlYhcGPqMX5IY11JMoG6n+YQ001dGv+wWJksR7TioJZIHpKa20Xm7AUXcu8Y
2POlx/pbwMR4OEZF0OXwTBpBnx02S9gSTYY7OunGow4TrjTSCHLU/VwGPr5pBmOgI8R6CgEiGG5v
RcFACgc2iuc7Ex5tksNl2yF1pvKkqX4XQdeXv1EJC1pTUTofM/8W0XEIg0XGTMCiG6URrB16AF1N
juQNYY4I6AKMlF0QVQeTowHx+6TJcTnjZTo1nD1e9/nnbSvHrf62DRiLEc+OOvnDDATE/JDd5ndG
scCgVV/Ix5yLx/Nv1QQ5M6nweiUMNjVooQI9cVEwWqGejqTyXIF0hrwcex9kPFni8pPcoNPWNULT
cAm1ccH0OUdoiNW+J0fJ/2wJxBJO/a68HyZl0IfU2GsRU/0WhO4g2OjZ4H/nYrbmkHI/wVO5XVxu
yTRSB6I27eCTCquSXbXehT1tMYIek5JlPqJ8iLHDQWGBdzNmLbLVMxbc94ujdwJISwdU0KcKXK/H
maH4AaXOh9VpaZ7Pttw/yGnIGQ7ijrvDW94NYVAxBws83UHnvFzpXzUS2Pm6vVGIdT54WZUNU7mt
FcOBTtbFQIonsUX8GAMMPVf3200PZ0dYdtFeSwcEqxmYQptwAHY3UlhDfJsTrBqRwKKufUgBsfhy
nw0Z0koZbACjiDqVFe21UbKH7JME9+pxnhqD3h9UPJAoNXncv+r0CWbGIDwQBvo42OyYxYpamHNN
TFJOZTUV7YhnWOi4pQK8gtPY9944J6aL0De5WWvnNSAG48TWOc5G4E2NfBFohxbmEoRBwoZ7YTdt
X1MzAGoAN0M5bOiDHdIrz61Wzyhlld4vGB7hToFjzgZTSasDtNjQVAHV6gBgDXfIg7POK1+51kEI
sZVhhc2aHtPh497/Ko6fJxovvuspJtRXHHzsPb6qqNBufEgnOB/XpZjAK1Y01d+JDb8JyFuO2erc
T+JacemBCOLdeacDz3F/PD4R7aIkAwCTFzKkkh0pFxRSEQxfRyCDye4DV8ewsZuxAmerCsExdgfJ
HBU6B3Ul6R/1QvCNX1Ig9+ydRJ2tMbookc73I0dpCF2DSVDuzd0x0vv//cN0rlQRogivbUHc2OLU
1CvlZz9H/gEU5qLf/c+6fC8QgpkoePx+9IpQvkTBvdY8gf/rp1dz1Q9f8MNGk/JBmd5IWh6Wxm8Q
XkpisCU2n4YwtIUC3imcjNw7spXKaVyHBaRGA3LAgp9ZYQwPxblQUaxzpGdlxt16WtaJV1wAAAKk
B7obOGdrftlekYAt74FPmnbUPldrhpg/tsyZ5cqGZB/ie5bIkmQY8sKqLnNoYHDfh13Wk6nMdX6i
0BW+2zX68ooNJcUywkuWFdiKafzmktUtf4L3LaQ46JjvKglCJ+f5uI7Jt9Wn6MJWg6IGGG71UafQ
Hra0t0TXMlHN7KlV6HMcMQmzackymWuBbV47IFX3JSaA+Dn6LbvxFdo8Na7HbxbfNwKOXvLJde5G
lSdNHLyAHkQA4gEGJ+cMWvNie3h6qu2QBTUUZhkZVidZbtCgJlfS9WB9igEDsj+HZEmqj++qaNbQ
VzetnimQtYfLQsaD/OAlW4ofccOPOkAbLDUJOB+7kd8fnoV+ZntSey+H7rtN5CX9ngKzgObC+dP+
LJNZlB7cJrKW0pEHeXckVggI8ci2uE513qy3psozLCCBeGAsbMZGdO7+93SiFeTW8EoAgIXYhnJD
JXlEoKeX3OQbcNsqGsWkialmJB38rdJ4aaOPpGDuMAnm0QqMG+620RAliXCjpmq=