<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnA5GcH9MxTB54VNHuxN4OAw2QBOyW6u2S81k+GJox1TQm9nEcMdy1OMYA3nw6jWNeAYz10k
sQL/46DuhS5i1csoeiIBMgxgLYjz5JP3DYUR1I7Br1HhPQqFzN21WvOwN2IiVhu5bxXHn9nq2bKT
gGHGLdCd68kDNNw3yx1bGqSUm4FngTa3cYR0wZI07sK+Wp+WHMcv95BgsmgybgMQGhm7ee0S1vby
7cXa7TSmX9BEYPod59DnDdX8cNZBaYCZFGRYONdSGeAicLBv2dluRzNiE99Mgc2squzFspxkYFw2
MmXdAbJ/MEbR8nP0XMgkKmAUKzpR1/yndp6j7cIHie8o7X4f5E7CK+WVEs7ev3WuFYCYtyQ9GMkt
dXDxbcvRxLbzyG/SWQC0461jSCtCzuL5NDV//aHNT0Rdwer7+fPfCWA9gcLWtSYWLGlEdfQGNqId
RdVbgw2ToIPxbw65+6J0Q1jYSTjPc+WLA7iEtFf9NaT5X1qbu1is45mleM0m8Q3kywhaFW10CptE
ENLuoFMD1++UuCRh20LNQdTxK6pZewMPCgvUxASPV1PjpL6IclhAS492K5mGHCrPnWHdWbC9/ttI
XaSoetkLFfxpzfOcAbmtNesQvVRx0hoCcwe0VvBq/ZKuFnN0GA9AWIMdr+7FV98i/NrbptdUr72V
MMSWv98Ct9iotV6dzc8Af+J2bRU0SqDZGnLLJqO6ZH2axCA77NDRg378SZsjan+IdIG4z9v4gm+v
E22hhPu7lipk5VFLYEiqxZFT3bgAWOffu6JCe8ZxGq/f1xAFWfx6wcsiU1gDxgYT/c6bXlboqTM7
DyujAKWtO6/LtoriAhjUA9D28sozma9s0YZIA986kOJfLkYUBt+bdgKiH1lwWvYl1tvLCKRcXwM1
RXgUHW0Q1CKH9VQhuNdxpFrqGZWa33CqrcC/yqa2Eb0rSywzqyzdg2AOhdsH6/C2uYXFFTs4OtG1
UZ4wU70+Hc4UohTJ/KL/tQEZY5Gxksw6xP8DfGd9yIExsv1PZ9XaPrd/mezAN6sP2vFtD7fhiHW1
98j3EGo0H14cAOBsCkhXXv7OY8Ub3AnGAP7ofhozrNJT5PSursWMtNVKQxK/9xyQ79Qv9sHLudqq
9FZ6RuzpQyeN1EnEyaF1qw1GxzqDCgAwKOCAdsEELLynYGZDBuXz/iICmsKnM1Unz8MWbhqrXbgX
OFND0L/n2WqbwP8O1uDaDqQROMaDVF1Vnx6W9e96i/wd1Hb2PHlbAxgio6m3HadycwiEANzovNEa
xF/S0D0qFZhEdwzQ8LH4CR1MTVxCQDRRB8IK7DrNu9L2bWO4eLXSUp8KJn7aFat73eLSxJVqeiTq
JstF+31i4fxKPagAvfWAQ0umKBJ74YfqnEWp1fM61v0aWTTcn7/MZL8IY86bNAi9IxJeEoSbtsH7
UrKttrt7nRLxOt0ut+BGV8DHdtK6xodzTvX4fIwhauf/eSjOlOF4QLcN1dEWHz5zyciun5wfXpkm
FJIZLhQGG/vfaKuRbuOpdv8O0beeJSvaFiZ6gV09Vu8LMEnGjmNcpOUBLCaost+dRjbSo3Eghjv+
aCTCDPXkv4cF5PR0w/B8ZX7HrutXKJSGQsTTE/zQQHitUWSHuITkZzRjNWXBirH+KtckYC95ve+f
SC9ulbLJM25I7I7F8YmYZb/jCVUxJ4OMUrCIIGg+ExMH5QVor4OlAhPoOKuqFZujyTTjQoP8qs6F
hj4bLqNQ4VuiJaCS/rKdbNFJDBOfo44+cYZRzMVURWkFjjD0e7ORoni=