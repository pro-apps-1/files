<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/zOqDYg4OmXZUmIJOdOZVpq8Hv+YP7EsfsuDadF0eedI1PPIN1F7oUYJStm90fjSPvfqcNK
73h52rh4nK39KVnVE3FVMO2yqO6MTdq7be0Kmc4rfQStmjZrlmJNW9uHRCihs0X3JGWPNy51j2HG
mhorzm4okHFqrEXT7iIxohbhekzazGOxbMDZVQ3RX6JQ9BchT161s6jl2P5U2qDZei4BEIEJYXX4
RM8i53N4PbQ5Lwy+zAC1Y4UTBVSRccubnW4YyLvyD5SgexbHR420sM8EOa5Y9kjEJGrBzl4Iy+s3
J2eL/rEaABL5yZzNzHEtSxlfRU22flBpA2jSx1pZKF/cg84lGaOYCFsMVpUwuNNiVSBWMx8LFJfp
K1u4aLn1s8TXTzSGqVOHZZL2FojQq77SAiVR9TGeLOLFUEPtRmbi27UlShilORoWG+SLAO+8BC5u
clTFCyjHkX7hsX3RLsf28gPxtrC48YjAHOfDuLAcBd21tx8P1Z6Q4CRpBujf4bEq+jDmopk96ehK
6aBZCDXXueyo/+Afq2JNRNKL9anXStJINgVOtkVNe6kKKtNGMVEVJ71N/LBoLTaxSRCg7scr6sSE
0VDXXQc+NPZXcCsqONGNhk+BA9vH9I33hrIhrPNfUZh/5LG5yTcbsdGILM5uEGqSIgdzORXRfbvV
m10XJKrKrJQoMgexA3RNg9ryo2+N1ShLprFfTfnLbB+mRPUdvEVCDtfLAH5w81151RRwykPozTxK
or85/kFf3LPgxwt8DcfvMTdCNQ6DBY20BEzrRgFnspiPCTsv1l9K6YYgCB03idXhOhi5AN3zy5Yo
EN/hJ/mics+cJRnF0yt24iIFYskPo8Jvz/rgDN0ISQlIUg+dxiuO8Tk03kOgSV6IwXxAAJsVCH5+
4MCKiWYnyC9J2duAnpGWPM2X8DJSuHD4jr1lMwbSNOPANcgxPBeWprG9W3Y8DTNh1XMUgZfoiw0x
kRgVKL52atccxOyjYM9xGNWudOiIkeCk+GjSi4062tqttV1lG5CcxRyEibGdOJ+GSfiV5LHgQ9kd
Q10WhQJr/1APkJ30JN+tG9frpZzyf0FvOVykAzkHw0YjUauSoCmOAkTabpV4fhNtj8Rh5nLm0HC9
jAmGjeEX1KIK535DAVlYC5Gkot2I5XZbQdC0OtmiUlpFkrfrV8EqUmwyBIX5igkPsaN8oDEVZwqb
bIrj4C/OVI0GrKB14N9yOEBYsvAEFGS4lLV57W9eibwh1QmXhZVUg8JdS2rEZqEUyADvWp1i4WcD
2kjRHuN0V070KXLiWbl254u33MYMLNnRPKq+an30p2djE1i6/wvIZ+bx5Gh6gue/GUI+WQ9CpRfM
W92K74LiHl+xUwXLn6UMWRP9QHZS2NnIKXK17uHZwx1KdqeDs5L5VDXWYDe3PWpOqpPc98sNW0Sv
c/g80Jrttbo1jAZqnD5y3m2PdQy6CQTjkpKfhRSE7liRjVmwsH/8ukvHciQkqbtJE90ZTYtqiCOj
ks6lTKZRBw2A3JQNd3f3nud9CitPWQ2OAHvNPU10E5LLZszMuk90xu/FSUxPSu5OOVKv7Dsv3YJM
WwxvRljk9Et0KR8SBK2iTL2tZiLMgkeF9jCveCcUATpOOxZMuajxLvUtk43pOFi8DQGGc+o9/aAb
TgsEOOCJkpqT2zZwWB8zIU/VclCGenG7kK96nhKQcVlomjM1YQkTnMaeDhBZWAUIrpzAPXiPe2On
FTEIXf0397zf0fBgW9jPXsnL6RJe++eahRya6/or