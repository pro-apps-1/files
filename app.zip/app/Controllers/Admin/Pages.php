<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmlpnIjTRJuC635G21oCqKNU0L9tTNBTaTX6/kYTpmmTzMRIFpgWMtsa/el1NhSi5oN2vN2C
aE+aG5sVT2Y40Rj/KAvkVOhpXWMut5/tuItBCcz0ITjPHofxCeL11DCZKeTnELja+lS4vhXQDLmE
az9kR2I4uKq7TtxjG8a4bp8crx/1kYFevHtjLM7V4qt/7Pcc/keJfBFNOq9IDAzpC1IJatnLQYVF
ayNTkGrH1HVubV309JTex6Zcm1JEnPy4GwJRX48UlJdPArgD9XhjxmGtTdrGPQAeaX36yNlrfHOF
82ohJVzrb9caNGav5JDv06eqYHPBn/8PonTQtgL9XHNaCr/lmgKLCSOLCsKMbit9nTDBr2mfyXFJ
30CG5K9MehUAy1YG2JSeSFud4/06M4So4kbXJ+PUii0iFrAzVYssRAS/4WPLqNamufHhbIwRbTRt
S2qYUL2cVNqayr2e+L5mE0zgAqXGeS8m5yBpRL7UpmaAYtbmEdIf75OZ3Jlmd3P5rcV8pphiVWhQ
PBY626w5zjkYoYRfugDPSaPxySJ4ic1UNDrFLBAnwGSq7DDe6vGDK+0QVGVkS1NSfvdKuXR1iunA
+FWnbISSdm6Ga7GWbzT216gwMU4DHjnxWyKoh0MAq8bu/szX9Gt+cer3pyd0taTFZle1ANgjEvrp
5mK9jhFqU0QmMXTSU865Z+CqOsW31Y8GnzBzhmnrXG/YPrk68gOSeGkGtk+j5ZY2UR1zkJWDq14v
gB82cInUY/5NSd3Ynb6HiJiohhJCUaRk92Eddam8v9gdANV/tAH9sYP7woOphDsFr8IIIRECjM1q
Wwx0qAJaOlNx5LnXIQIYJpI68ElekODQqK/ssli+hv2VIH+3HHiTsWpOIb/6kP87x55T+LOM+btJ
FOgzK+tVlSLZjgt/dGUzgmoDtr/A5UY+B+O2c33VikH5Kw4JIMZnIEEbxQtHYFyLYMZUsjn7qEPq
w4WMYKF/JeSrnT32Px/K83Z32ecka8Pn3t8F8XPkUQCZxjWmK9PeYcF+5t9rIYlI+QQkQNG6IdH7
ZmcsucZogTKq5WTvlNf8i7l2xEd4MYfFscIUA27V/Haz/8RLd/5OWHzra58a6/6CfpFgd8zq4iZv
peTZBKq5XU7iPb0LLII6e3AH5A00yrP/iZY3/vOM3DtMrsNvNjQC86sAdq7R4LyM7jF5KueaFdb/
L075DBeIWtJPDBR4tTssqLcAJLIz2h9mzcjyCKP2BcMJHDQM7OJZu0/nfusMjetmQdsi+NtTG+p9
jbJdGUnJ8qrLOMyB3p2uuw6d46l5VjWP6OYOxVgrhvMxSkae9kPlbzqHjhI0MSZ++brjmciOXszO
K304nXL+78N1yGl8gG4BBQamGtIqdtGp9nsySh0t+JqrwqNsIeR2jSi0n0ddHBLCGK/XwVJeoycP
sve4Ye23AG0mlWSAqR4zgsyYWYhQz6KgO9u6FO5QHOSJJIFr30WvlyOtYeFf26kLjMv0XwxJ+Reo
4khIEcQ1PNiInWuEriHfLFV+IxYXDyzOSl+Ko8F0uPXV79354yBpL0L81QhS6Ie+OoyLZ/wzfp54
/G6BXihhSVBTsUi2nzVfDXqXewwjESVNm224zTM0YcUnWWHHH2xUv9A6BnN3VGxIArOqSaBN6YgU
UMdim2OF8NaqI69KMeSLDViGqtgC0mN6X8XJhZxZQdOFLCNy8wLuPiDw21BAYcEdefodigXxTZ89
PfMZ4JMRCalD19ZNZyGmfmihDzLDnRFJKhgJ79Ea