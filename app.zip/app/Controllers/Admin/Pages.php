<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoEFIJigGRB/Z3DDt1Xw8uLiIgR66qvGVk52fzvSMGFibxhoj71hg1FWzh1w+6r/hnYA9TYK
lDi/f0uzvWmQxXhRv5MNTLTLT+DXwo43xJqYJMLspFqzO67oTLtrbNNErP0rpZMP6Oq5bv3NYElf
Tj2QuXZXxSWbOT8n+9RgeY3+SSPUnzDEOD/bzbg0s/WG3hbgv76EcuJTTAeQ57FFD2Bk5Ry9vvR2
GV42kuVxfqRDBbbq5rpVbIFB5h/SrUXYgeJOI7OKAnTu21puFx0CpmxcZii6RkWcYjwuf91eLdFy
uSHATDMhnEzUASLSqYq/EH+EsiuPs9T1P+FXRFUM5EKYZxtPebpI1sF2JNuuUqqXpy1PcwTNsErV
g/A9BH/zOQVG+nL3jI4k+SlQvoWLj3/KCSiMY7bvd5hTVK75QBO7xwxyWEkPwNamdSWF40650EgZ
yD2TDEMkm+en7jXvn08AzHWTllaqbraq7htUz8wDyehT8GsfN9RsHQiJzRm7YAnhrg6lzFaQ0TFX
Ep0ej7ntWEyeLGWndNamuZ939di5UXKu6FbJpB3EcmxJIUHCuhEzOx1+2u16tO2KtYufoZD1icxv
TEs47FDKEnjqhHvrBpqPVPDhwKTh7i8JvZfFiiDIoptEMo9q//tH2pJq/8NgA7Dd1HWjiz4qdCUH
D+Ri7ZCFnNW2jYqkHHfErP0oHAH4NIpQNozDPzjnYpWHQFgUl+Zfeh2tsI+fk48ZAxB+Krb5XG/j
BWbTIV28eefGzmfMpNNRLH5giYEwMbEC3IWvxXKF6OxE/klX5ysEtJasxyFn1ABEFHe6J/e2PvOR
JXWfhoSabWI4YXzSMoaUCdJzPNCsX+T/KXTkbLhlmv031zrwmiXFzdnpcITaiSEx1+n/0hrjl/kZ
BwdAyL2W4M9+Aq/BbPWG5rvikZRH6D5E4YY1gg7i6u0EG7pYBqvqWSjOjwdGxj19PZU4S2Qcj3IV
uhHPzMWRdct/IwRI/Z2i1ohSzOUF5Ar0960i6tVvObcdGoVEV4BqhhovjhjLvqHcr7VmgM69V7nA
+nE8kGpB9BTI3ZEZM2MsgOLIV2lbkn2kQ4yL10WYSiqkHE7bRshcZbKG/qjsQ4jcXzP20ZJY9oQi
mw0JW5uZLhSNDeztjCxfLUnDzgUdJMKsIE6l/RSL/NH3HsOCLHZUxTM9Tl+GnjDfBwC6xvFlUJb3
PdnyhOLIlfh9oBGAO7oadV9B5SPZFuNFs6LnY2VKGjnHvkr3Ch3n6Wzhrym5TpXt7R+DAQav4T7P
ta+bc/vXbP8IxlugqlX9+PQJLM+fKwKezT1UgK1HcJjwRqDJNVzDXW9YUn3o5o8gY1Yhw8aXpGTn
j38ij+9BLtyAyyyT5Yxsmz7zSV4vRGKQZgD5Zdo9rdfm0ObRSvyq8IbUpmrW4vurmIZqYNdiYblf
fe5HZ+m3zaAt/YyRSR4v0v/lreu1huGmczFrc3q1FQCqsM+mzpEEHLWFjKKYwlHLzMkfjxPBm12q
TRkI9BnSGCZkz7SR1bLv8wUbCpjZVDoCb4Tr9Nmqpu53PxtJR+rOqg0pZVbsOIBA05cPV8Z09491
DCV3RZBpqUw+7AeMKb7l8qA/t2JLy4q/stITtLBZ+El/ZPYWX7msfY5TPYUK06U+Rn1iPxhnA5At
gX3NkbGKaQODIQyWgjzt9L0FgwpML66E2MmaUMq9Z+vbobMtk+HewsJJq/L/XArOMhTxCtxEuVbn
FNjYjy30fwco+HHQjjweyky1DHj7Jq9mClcn6oGZGG==