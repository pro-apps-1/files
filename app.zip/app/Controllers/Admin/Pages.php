<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo6NsXrVIJzI9bLFFkRBBvVJisJI7lxPLBkuIG8url6yPHVJbsPp15LePG7VeuH0QlFn2Srj
Yti8xTaIq6IxRcU5yNrT1EjdGl/S5KCEFmUG89mqDfODyaclsnYt51sAN+/9jQ5qrYtlP36pqdPo
K0FF+w+WxN/fD9YMkIj51O8B0gJm+2ytUu/pJOTOceZpLMB6OHbtZf7m9GC+4kg17983m+J4VUYS
XTKVuGOpBChH1UWQSdBQYWG4q2oE+4KYaMOqhubOxymazG/Nz8XCYKvD8F5b+/jlgc44zPqdCVwu
f8eL/vhvZ6Z/beGJ2BbjNt0OFSYoJT3D/2/otLUKOiKi35mbqxx5g5mkEO1mM5xikKcKq6oRbR7E
8Gd9c67FNXGU7ElPphkLXhV41O1boS8VVzCXbpHfKKANRUYtunOvD022PJE8+Z7L9zM2c+TROBCD
mMTWC5mNroRmyuhado7y9J3CLyW2+s2424UTtkvDDYdKKNTEWlbVKUqhp5x+cscghWW0EnM5S2fD
mqW+goP3LbAZZNKImYRV65k57pgVjXol4U7NGOy5nIDXUn0vReMe7sMHQkwJDOKJtHsoBp3VBlOU
eVc2zKoL5pevzXQLEdPQuR3BrAOkmMPrg1Do9XodB6AhzRt4/H1dpvsNfw7WbulcqyIRGvvjLY4o
Bsy6ONyVm1oYpeI08+0TR37gJbk7bX3zJBmLGDoWD/RAY1GsNyAYyMRHcRw2oEF5J/VWYX5GQb4C
Gafb7JYy8wJhPU/sR1R4uc0KpFTzv4Q+qiy1IOL3GPVG2bzZvRqVjjzRFZQudtNA2d76/Jyd48QB
pNqt8QZDOSP/knBdnTz/sHOfTZTzKP3MYfpMAD22zsZUWXKwKyxeAbBwpeSFKi/4Yj+LUwyvEtwf
1eO2b40Qb5xtdFVvDaOKU7dQ4DcTLSZ6295r088Gbe5OdZEVX7oZP+tsjNj3o0NNW33WLzRZAG+I
zgKw+Z7RG9Ff9tS3jPBKySvQQvidBht2Vx5QVaXu7HUPCwRcLlmRlOYdKk4n1ZYwNMBYGWOXIM8s
9Mbu+6B2xPPrug7qDJlEDe8l/mhPoZ40DVlz+FggsYO6S7fY7+QxMPFrcHBGjs+7HXnYBbig4K9j
Ggh/WfZtVEDOB0SaPoiZLTYrNlPQiGq4ptigYKDMUpvyttSzrMu8t/s0m6rH7ZO5NJ9R9mnJW8P/
WAx5KeD3jXqipoEcn3LFNdA/4dhTrnW35+6hpVcIVVZYj/ECJvj9J6irsHKgscb+lojnHUL7WKEK
o02oAH348BZUBimfZPWb6J+wbQeiV47F4DQ3foqCJ6JoRbGBE2liDNPc6haT7egFLVGF6IlqHddj
uMBNMFHcyrMa4KDdXeCM6mSdyZ3P1fgSv8zK98ZwJ+R0szYcewRRpg5sDfP2ACW6Uzoa3ZT2yapv
5DirsvmNduEy3/AHl7e9EgDOQLdp6nah00o2DTChE3D8ETHUbrvz/LMprUL+JzYEypBMpYoX24MI
QBveX/WuUXpTOT120WaHmaNurIqEXs2HhrIkH3Zvt6rTA5wBKr5GhdTAV1DrtqGCEYqB+gRU+6xV
oLPZ8Gn9eyaQA568Yz0uVxChJpvwVVhPc+v0Ktr1k1fcLaQmBt/h7FMqfu/Ru42Bm1sBtfX4J+Yd
hM5crsBM9GphDNl5+CM374oQ3ZH9G7LQgVX/feoQ5fjsgOaPPHoDOBZh44bxwEVyPbv1iaYA26P+
tYc8fKUKTwBjEHcHR8LCvZtO3Wr6x2SNi1ogECQ//6tYu+2AARKT7wdV