<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPythC9x3QOdHcZMblK702aNx325ijgtqbQIuKdZcXR86ViLlJNHqsNcPpB8j4RACRPM0NVzp
EHo4VN/hUDTBXitudUi/39WzfGEmTzRSBg4qujQFkyEvCcBZnGl3VJOY2Qp4rKjCY8YVr3g9/Rxj
oELCDcxfn09Z65BxO5Mgibh6q/iWJRWNgRX8Iyh97eMUzuslBYp+GHImzXMYtK26VjmzjcyapgIx
Pr+jc5ans52RxQOrDrtc7aQE4+CIx0/R6zUjUqoPPhjLP//toGYqjdKiFjzkfqis+xLScZiCT61a
mCj8/m5p1oucr1JUga6NprHl2BNz+rSusbvyDyB6SjyJXcT0yY9FB0HDAQP9YmL5ZCiU9x7tOa3O
saaYALcxnmPhioeRAhtITWTF6t1+Tuv2H4DkLyEq7foMyQmfbnL9a6HQIyWlGE0ZrTFc6Uar2qd1
NU1AJCbGrAxyTv5TbeUmyB9mL0zEABn2mBuNbHAHwde6P9vEYFvoSHABxoqX9pTq7G7KDFbAHsDZ
24eubODbYZPQLCepuqG/PdkZ9Z9gtRPIviGGxtG4STWXBfcl2/MZuuQmX0y1syrp6xlfqnQs+OTH
on46zDL/U6I/bBlcqhKiSJBHJNi6yzdpY5rZaJHjWolj1qO1OaP9TJUUNf9T7StNZrkEjpVX//gQ
KiTTKOHEGdBVBpR+I18ACfug0h6shIUHTBngAYCxlLLORN+ONrr2o2iic2TkK/R+FGuzZ8sKawFY
SwcWu7lZGbB9xTOhKqorDwCat112HuCVItZ9kqQYWg9QzRp5QkI0IlF+6TbiWey6Bzxvog5/mDlc
qljAiHeXA7VsFcJHjdxEiWdFeKAho8UcwBnZX5DwxhyD/XDo59CqRSCS0dUynn+pzUgmUsWsQQKJ
83IoKFRifxJ6kmlMo6XkJZl83uT+EKU6ylFPKNs8J69jnS0vgtAi55BNYt4j4P0nCnQnK42ii1rJ
qMAlqcuKQ/yf8rB4CAQkdSNIbk/uLW6BEkg1q7q9NB/hGD4PLQ951agarUZALAF51O4hNf1sfHRt
0NZC71W99vTQdnH92qwSeapyw5DTxrCaDfMxoIMi9YUgjUD7+38JpmHKTLvgny1uCBWM4cAHHRNh
rI7EbARZnvLasyCYlszSS4kJANfM78iwWNwsT5H4cLad1R+eGsWsT7MSnZ1mQyFzUD3EwEURHhOj
RJXSv4XraygbDW2szKk7oeGfrvBLgkoBHZivQrGs4PFpgCqrpseWnlKw6qPGzIvDoJAaK6Srlc5Q
splggJgn341ljkIglzDHqUY8/9dTgXIspPyItE2VTzTf3F4jmv62hD59UKI83EczdO+Aa8Blf08d
zwhNMPteq7MzMYOY9Rmb5i3TcxUo/yd7RPq/vAqZuFySFbks5EV233JMb5Aq7RbejUnhZcF7UUds
1GV8vDtIb2n8pu5IFpT/TfvqOKDM4P2GI2WL7HU+mBUg9zcZ7uNdTHKefRHNfnToV7MHa/ujD7jP
DLoXh+tu5KRFiOn5sbtSGqRP19tW8yj6NS8pr7HSvUOfg1XqKBYM00JJm8obykl/t9L727XJu0VD
JtpvKusXBWXZ/oKH8ahE6OwP2mwB0roSQd8ow8qo76f1belODYEh3BCkTRnv0z/fUWD2FTWItJkb
5+haNgQqZrqPPOpBKvPKXLIGyKlZ7btJcJAKA38DQQTZY19D/IInhThp9VzIKejSa/k+5Ag4ITjo
a7tTo44AJqK9q1CZ5KtmAUbHoC4g/YDPBZuNQ5uE54kbeei9KHnM6xoQS8Mh1XYNzmP6Opyf07GA
vOoDvKSujUA6zf6zAnAQCOA24bWl7vKxwZAqahG0x/h6yxrgOebB1KSajum0P0ZEb5f6RcSaL3GZ
GlzSTXhqblhXrdswXQLXtzEUODnvHGXNRPypdKnmGusx2dIk503qXJRurlVI9jZOhTXIWp5ShoRF
rAsksAUg6MF6xl/YmAEVO1RPLi5VGzSZ/L9GrKwR7v5g9zlxNc7ag7ldgHXHSiDAHFygc1VNJNCA
h4KLbKQuAHZAm4R99papY7mzX5JJIZ8O3chOYrI5KVCBY0fXNNv4lS5Tla3KQNLiadAXQEHBdtsj
1J2petQO1aG8h2TIx/ZUTgN/tOtSQLyWir3goZvtu9NEb/8Dv4oLeVN/U39F4Tx94DyD7p0gipYt
eS1DU5QRNVxdFmkGNKvhkdn3jrG2Jzg4rqbTzbMxdT13EMtDpGZVTTlhkzwDZVmQOyswrLFkiuUu
y9QZrvPKy7Xr2Lq/Z/KIklHdx6kRVDw/s0fZdM7Jc3ItBmP0wPDq3/aFnzrQ4dKuJ2gmfh26pHUv
vjlNzM0GFKF+mkdfqDwYbyPys5LZ/u6DzifwcubfaFlMe5HeTy+zNjbwr3SuWvGT1cp70M6c94FA
O2lpXuDWBkaep4S5SilUEH41frP87UchrBFQeqzWAQ4erZwwivn8TJ2onZfMiSRJzTZl2SJU3IUK
cXv1kUyPQFQQEbL/yjr4H7gBzwHe1x/ZZeOrhg1REple4H6sCB9772nQ3wJLu8fAwQdo8hHiAfYT
j27wyEj4a6WvcFI0/0u+Yqu4e9MrL0wOKvyMPxGnnHzU0+ErxrLfQm0F6wBGRf2BqIEptwWAPhPQ
UP49m5Do5Sa8nzcNgUx8Q/MHSBWbB/ElGkmMmOMUuLdYm/WTk5LkYMlWPxMCBXxN+WZsbCZG0w4X
by+4Ehag4v/4dGbUw3LR9vuhuhjTZvbM1HhNn0Ofur/0/LE/eH/CB8kthwqKVCa0bzBfV+fPCjif
KhW20SqFwTel+1hDUw1eKZgmf9tDTKqr3FqcDDUlwkV2bmeNLlqH5hhwwRUUpmU6AyMWKY5UUK7m
GINb/ls67APyCqRHkVFRMgq2PuXlslt9uJ2lrOWoK3fwzxrTc7d8N47t4pY7zUdzoUeiyyzn+dwn
p5AvCu5g/qoLR4LIwxL3UO18foYIftRBy3yMdxj9rjUt5fT6eOZkb1k7MjwX2ztfK8cdreCsCr5V
OWTZEiPN9PNFdO9Ohoa5yiu=