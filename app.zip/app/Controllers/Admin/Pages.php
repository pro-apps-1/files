<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoStSZCkgKO5D/Nd49bqWHct7DGVPr5bvkaoqbtsNmgnNMRsZk0nwjgji5/eZYt3THxigjCi
gqFY0AF2JP5l1TfD53gwfdP9Sf+AdIEtXLW70itDcSiC52DrnXw7CWsfq/sgnm7OZNEvUZ/elFMb
NMLv9Slm2hqQXVtMiGGupqsX0l2S9i7tJC7zodL2O+uEJAiDzSuhtmgNtRhsqE7a10Z9KkOrbgt0
7iXLMzLdQgU7tzDoKdnjJhMn5u2GgVij0DG/9QSJRT5A8qsaufIGbchEIKG0QogFd8hD+b9D1Hvn
hTggHlz2ksVkS0ec1CDcqmwr5XFdvQQrM+ggWUmJjCsQFduqA3OMTLAlYOFp9mMprHs5ititFxmS
D64Uy9x28mf460yn2ziaBG4gQY8TKIr83nh30yEdJNt6EhSOwXNlaqGMYg7mi+e0k8NbVbFHbjSk
i5UZ40RF4gT7273Ea/BDy7QVfaw9OqdpL8WArTwgniZyBGI/ztmS0mO2O/AfGg5lN3YTbDW31Xmw
2On+3WyOoDV2lz6z+lBJOc6rMHVRZepVxAUMoydnWgJTawvJ9sCJ524WkcpW+7xGjdpYAXO4z0/u
yWJKSkR9b1+MNl90cKu/6rDN4ggy5NiONjKVWF9o7R8L/ySoAeGZnGeUfkIUZBjYqSmpBb5Gsi56
Nz72veN8+jwgMvv8yY0bfYr+/zN57emo26rg9jhK5MHLGQ8WURUdLOpwnmVawNrfwyklH/QyHWjo
BXzepcpoSXYvqd/C4UgTT47bPkaL9i8HRdypld945932Yl1RMNPDi7hYG5cfWF6bPeJTmEZWI8Wx
xrZtSacCeirHI9BenY8zjElGPmn+d84F43MbkCz1RaqsBZT0TEJYeEwfJG3kUgP06qo4fSShJ484
2LPVrfKVesmf++dk1vigHl3X40lZ5kZYzVFbH7lvB16sKpt/uitLYR8IFghgzXLl1KQF2HnEldK9
6vkFBYB/Z4bXdkdwfQj1ew38hxlRRyfKJ67S0L6RaCJiG/ggbhS/9+toBi0Fa6zLa/Fqs+ysNWe0
fsk96XC1sRc8C0lZRAxgU7yq0CihgWyt5OYj64zrjGFThuZoOXHvuhV7LdCiycradWWUKmsTTrU7
+OHjdeEwJMgfJc2s6TVXtEq/sUvY5gqH1Ex6r0Ql+8RgYXSC3M08GSweClkuZM+uIN1vgUz/Osxh
3P6yfDGr+XBeFJ2j+gZeZVU80mznwbj20/oa+MRr2MnVR7OPSHnDpOMdqexKyqUvatQGsCKboVV9
z/kEM2aGumBdoitAQC0eW9E8fRpNa5Y7T52Kl2XUdSnQMLlYNu8x375rMNYuNR5x+QqUFy+13YLt
50GWoo3FAkSbMcMyY6j/odk6gqThz/qr4FL5WjXzTGkxk62kDB6ZaJjHVGmvO1/LENIBVi0hnTit
f+8LM5Le695m8LoAcQueer6PL/nOjoepxBK2Ynz7YAnbmWXKaa1mP6779lv04ljgl3+YSx6g8H0F
qanlgzDk2woUbY105sIKFuI8UVxSg2EsetSqQCofUE7THf9ax8zVzt1gTRFmO0/8uM3Fy0mIJMRV
zKj43jBFwvHzJKPgWyGqKqfJilwtC3eNlMspiKl4VA8eihrtk8TdhAukFyEOuDdIXLcLwYEl0yMN
DApr30q58G42IRXdlySpVCup07s5Xla6fhtMJ2msXEnm5ishLV28YOUaJhQtwV1+TQneECl3ke/K
r4dnHfKNu05RxSkIfOGxzCe+1s8WjMEUDGE/ToPwBm==