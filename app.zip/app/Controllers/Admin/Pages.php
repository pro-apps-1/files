<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxsmE56iB85cgNAjSgy3r8Swn0bA7A8fVvAur40a90HjprpcmLXLAilDRGVtedCYcFRlI/P+
sAf1+1YM2h1/UP2ZXzGeFKeI2KHKxA1IOEQPoq9qDq5XvO83rsBeOwh0OHWpG8D5mbhb3HaOdiTR
7mrbwRj70xX/ZtYLMx5N/Z5x3j75cE6Tfjxcs21z04qKe69p++ElCG0ULj3MLZ5xddwHjKgzN8FC
r6nFAp25ZJ5zmbQsugGWkytsPY9vH0yuu0ahbe2r2DXL8GlSdw9cbuGu5JPaX9AdVuy7tiIqHCkJ
bsfr/vEfQ4zic78UJE/nIrw8n8hueVoYgREWbPJlvWAFtkYmc7T6mroviri0mTCuwac2ODsv/j1P
YZ7krVi4UljOzDQih/3UBh3sFL6XO5UOkT1gi4K78VoWHpIioUTtjAK2kTstknFi4ryT4ITECclH
v1sHHtDW+0yYqOX7+eafsgqkPn29su6jt6oNqlmKEnQ1wwqrkdaVdxZ0vJ5/3t1FVL9PJm/7KiXX
n/tlSLjPA12U4rOKrCACOd/zif+TK/3MQ1do2NrY+nzDU/FDUlv0UJIIcAp0w7CGt24KZyRrsGBy
+3NULmCf+U+yEXD+pQzFD1/Ag42Vw/HxTUyVUSLzSdJ/0zSD+1Il+G+mEmhNSCJwI0b7R7CYNMW5
9RdGCKoiH9Ln9RZyPZhggY8faOYFQJlhy3qWsVXrFLy7+wgDnb/CSDVPS+KGhRx1kgQEzImeP3bX
/7/UO3KU+TvZRXI1kG9chkSm8w29xaaBE7EF9vEgX9AO2vI5/ft8Yh6YDSKTt7P2KU5B3HaLkFxW
jWwbQg0g1vEJNCR/M1CBRpJkX8kA9v42e7f5m5Qsnmpnn/3O7g/+eQnNST71Z4XA4ck6c9k+YTtB
7l+NxTbjQNgT7H4H+8Hm4coOqFQYGqHPCbRFC844BZfSH4pt9bYZqqzv0NWesmLYPOb2Ba5W0QVN
tj/o6HpSJoZ7kBnbEhpwpK0pjCdtl4+nSf7fJj0FRXAYcTSsQqOch0cYVHg5VUTWDXWoc9GeCD7u
qjbKwXOYGn/ZOaphWnA3zX7W9hTnsz/J3BY5KI5BFfVb3HD0OGm03eXyeZffqdAO5fuc9uvjYWu+
D0XI2sSB+02f1SvNIMfQB/vcjGvGDFI1cqlVcrR0bgzvTYz56zC/1d76XZVyqcdKtj1Pbj4lCEWM
ILZ94RijiEjatHzXt+pI5LrDfBLeIhuIZ9ULXIa+q7oTXJ0me79qRowJfzqYL1L0LRrut/gy3GRo
JvA96HFAHHYMBtMecIFFuroMf2PywgEJlBqIP0b3W0XqS+nWclqW/mRlMEjpV+RHgwlnAOLuZseb
IvicWH+pwjnfSayCMf+LJXHDaYGhYZAPK18g/Kl70rds//gq4iVvnYVng6Igf8CA/0yvor39cTHP
sIW8VBFAy5iFsR8M7D5IrAiJUcPsDDWgrDPiiwVgUX0YqHZ7GNy8FZ1x8h6lN1vcDUqKDEJXm2YE
ZdOTJYY5GfIdgeOIKI7n02+75cU8CFfCEJXw/1dmLBZNO9SYLgsPHBpuvZjs/fP2OJI971tCUpRT
QCwQrOIpOEqtNGJwpddYcg5xzp6GED7hSHrz8YxQomQdlYRAYT22SwUXLXBiXnCZHB05JFU5J01T
BKLDR4SRE39XHI0wJwmg78ymD7Qv4dOZ91/XRTIAMqiCmNw40crupsUXKVtt588gEYlKQcu3fC1M
4/D6hTC0O+d/DLYut833HmKTgUI/6h5o7Dr2