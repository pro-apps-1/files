<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+jafp/Fr1imbheo7CfiZErQvjC6VibvEjqq4PLmHOYsLPZTyekXqWUlm5NmDKNqB1CdhTrA
HcmGXBB/KJiwaGBucdMZ4jIZ+jpyIuHmdSSuZW/OVDzVAgEg8erna/9zt6QZliu4fhCbb0yjjMlM
uqNSu/A6RsQUgbuwWsqUaEh3mIVBxfM/yc6uIkzWhf05cHqKFIcoZYf8bNj046uO5m1/ysdnPFZB
+phrR+RnEavVEIPEBUp5PT6EoX7PLaItkt6s+EI+eC1wFN/A5vdpPPqqYK+azMvPzSTwrhN3Z9qp
XI8jAagE9qX7A4nK3PeGLwZEgLSxmoAKYGDpVpQ9hP2OIk+nxbwWEC0mJCuSUkxOdLvU0JZOm7oT
h9lILUCeJ+eC2BQqa2J1c8R/MnoMXMD/C60/6Yha7d3s/e836QZbXRkDgehfJLEWGW1JgWJuIMhQ
ZCAfpdEdENf8rK7L/K6an0dgE4RYibyVkhOnxDP5O7KaNOh48N2jNzsRYI8nRQcoatlegTJsYD9y
ivB+T+F08mygLvvilTYfw4xJCTNzw5qVj5G2mupXzTrSfEvUK8lXNt8Z8XQFTL9r3bTQoNpz2CUz
JX01hYNAkntcYROFiIbUecaWSKjyNXLsOavnnsUZs/UxVuF6PFyTvFk50DRHW86ocqfScwk9GED4
SKc7zqKp0/615lkVYAy3dpMkqBwbxwsBdoXKDjKDhanrerW/S+FMRyf6nm5WkKLe5Wrf/bevaqQo
wd9VRuxF9vDt+8mWnqGQBeidSOyVYLkcOeBlCLoRYT4hQ43/7fKQMTaJL7O1kQaCw0eBg5kLcEJa
fK7eWyB/GNOsRca9E/g/NkDAyQH9C9655+gjsf0wphtD/RSZHyCQ44uTCE6uO8wCPKijE7RQf6I6
xnalnBwx4Il7h1ROwCzb8RW8l7Pk41gOglmnXSdR5M7KzfV4k6rrH0sWhATRa2bFMU0xgTgvcRly
hFfBRzBwWzCWFRytdcp4UPfHl2SfeTJ+NIszpsVNnbOQEQKHXiFY/14N1yHguFIxeGe4dTlzm3Be
GLhzV1wsQ7GeEIDmq0+0X0x1mOF0s06BVu2iWehDGsqYTdcd+ZhsXqRV28LQi3Kt2tMpIlDe6DOz
fXtOf7BV8XhqpHQ2hgyX6kUQQ0aEzWVoo/0LrF1WKJ8oiBS5ReUnF/xQY3GgWTQyxuQ8XQUpFXIw
t5tWkhjG5XuXz1QvqOBlQBRtm+Ttvik/5vJC9SttCW7ZTgDnmMzJwAFNA8VamLtrekcKk+I7UCGH
K6fV+eVsbxcpDFSQcQMjRfeoRHEsRnAdc53hvBZHXKrDtZSusGsvK0DoaeJb+UHDz4hv4LrBMQAb
sLOkReXWq2TkOvezZVjaA3wYypYRmLYejJJgLWR2INY7urm0rnAVQl60QCcOobRwhhlv6/N7VTBz
vCEtH2CVGsswCM/c7lOYbr0Vm4GVJcsQlHFmOA/NTtfHDP5o/zBz50TJWuLhZ3T8N7ryOVv0bMZw
2+WUhtpSiKKHbO79alw31DfMWYvNP5o+KIytYJiFMizbjbgphtmFZ3hjiDVSuyI1O8HIgb9At95c
QyWLKOva4bHmP3AjdCWt8VhnJ5f5JUQBrIxEduCB836Q+k4c1YXkgjY4Raua1r0cu5DVO7r/uqNh
mBiBS+KryKNLjSOMfJfCPFyHGBjJVOpG8ZYhqZ9jq9bFZotX11vN5g40XVN5jfvKOv38MJL/yRlf
NqNrnUKAIuHj4GDEap24U7l+cilKpH5pZFjxsWN4t8mIQySQLGzBsvka6luXJTF4b6QsuTP9l5lT
NdzKkH1Sdu9nCsT6kQir/a3rMa/u2RmbqQVOBTUUUxMh+8bFm1m4hgPaPImOMTUwBiBVwhyWeywD
63/2pwzq4rVfEH4XzJwVoNIWguAQHqZvAD63IdDI4XOvoFVaekbfE1fAUTqRjjx5R3dK1jDq7lRf
Set2CXXn/WPksD5l9dHAVqyDb/M3BmA/9zpJYj/Az9tMz9nr9fqT4ViMFnOp5f1gwO7WFm9d4zpC
szHN1FlmFiAbhtkJU6nj/84bQYJ70VbtK7lq5Pw9MvPUUv85PcH1B/t3bF7ohqwShQI5PkUoQBEt
XqC2u6WEZh8iUvFFD6IwkpPje3M78XhHgN+Mb1p+5RPogW18GqJxdr+TPgnAXqO3tq5J8M7aN2EZ
xo1JNJ5QB/ZtU8mD9NhZyisSPMBhJUVi6x9CMNXgUkFf9TxiITnv33KE3nVNPNDwcK/PeMtROf1b
KH8zawLnsAVOcTqoY0mH0URSR260BNmsqSUIOLoO2J8k849rXJM0TQBnI9Et0h3j2q5nMZsQ0jcX
FdA61ehXE9rw+sWsKKrZ2XaTpu9HLNX8620ADdOUXvpH7DQJMbRcqW6GlCedAX7xbdlWNQJr1PHu
wojFY3kFCEixeULXvOV5ZzX8zkQs0X6AvCBKouegZABVOOvuaX21c0na9FEf7j1rZmSNN/IS0cOb
Clr8s/0WRy5aQsZ/X3vkbo2gj6YqwOIOCf5cYHdNa5IaI2YUu8zn2zbYq60SIFmWVZ6+cs4mUbdJ
LCW131iIk+wPgTPxUW7/uXqPKdBasUGLkenFIDrpIH59iwxXTWWZ1Br+64YNEwc8z6q2eH36n52u
DASGedbsphGmO6hBJ85RLWWHfEJuK8DwSWe5Ar2pJLIeUOgp9oZndvB8zwmaevxkrcS72daQnoSK
02z3qHU429LEEQRpWM1I1RICNEk2YiurjSXzj4edbSgkrpH7Q+nxcj3XDJCLglrc682jQi/MFtKH
jW1YGRvY2q3OAqg3TaXO+civK8Busypd7sNJhbUPCGyr1YGDJYXZKXY2p/rpnZdcCyo/9cRrZolm
PemhHRXEjMjnLaaiS5odzZ+r0Av9iTFMT6liIFypQWGLlakR00+He7tSMw8isED+H2eQENuu9Bhz
rNBYXvFp6jRuIK54uTuUB0HZU3w9renphfkuwgpvaakmXT4llgmuGWzOuks9NX31r1D1/LTLYzdv
Hdogc9cy/TsJmhR+MEDIjEPnHL9el6JHSkjbIf/YfJfB1D6METI+cH67S0==