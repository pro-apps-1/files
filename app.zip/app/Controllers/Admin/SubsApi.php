<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/KghTlqhXKSWVGu+ER2WfIcRbAk26FvHeou5nN8C5rhfCc/+qrr3yGNrsUc4E4XCb/a9OXZ
PQ7lYuRCEbtmFOQDK7LMcKCIRU11tdnAethtjtY2tqDXRjF/kXGlddTyZdYDgSBeC5EnrC5SxY2f
wpdTpDITuyI3NfHgqUtJOM2u65t6oT6TijvyX/evBXUWcAbjqNU0H96tIkAEXtY30VOeI28LZig2
3AwTxEIj7PEg1971SQSsTHP0m0Q4wVpo9Ac8GXwzETahMeqc6ktl13TsVILkepB4UeDaL1vEGm+W
CAjtJjp4xqTSrX/8JZA0xSLJHIS0gk4XHplz6ab4XTqEezs3NIPD1u0GedUqsL6XRxowx3D+4FmX
MM+wZbdAD2Kq7E3ds27HZT8rpTEisqBHmPVz6Lf0YGyjJh4QiRwuhULv4st9rwEWs9HyMc/GOFMJ
XgZICQmFsgK0hFIjVdyd4AKejTyNT2OPA/89TUQ+a+chhjPQzeFJffl6lXooN9CUmLlybhZDnaBV
ejbgtlEPJ5uvoA+oHGLfiK0HWkW7DIe/hOyAleigyJHxj3id6E2UP5tGSCHWxN6LlMEZ5mP/IqCw
mOsGXIvFQuQudlvu6zhGhftM7HujZvH90myzpLv8pXSNXg/dxaacc7OHSHqrYYr4AwwcuzS9CFS9
JCwMU2xj3mjfyDmQCgDCDAivYsjm3/cOnNU/SWcFHuK/ttqLPqiSLgIZg6KTJ0NNyv178awB+s3r
8UTRttR3uUTsNfyB8gORuZ23lpgQJL0JIcTv024TZ3L0pWCgQDA49pFDe3MVKaMbG9ty/+Z5cMVu
T0oQg713Q2lp8pW8C2NCHG9Nm9Qc8He+VoAS0uN9RElW9EDiYCf0YPWZ1a/rzwEMQDFXlNwXXICf
ZuXEfzcsG6w9maVdhkHLVa1SWd023zVPzg6jl0NLpe/7oAzjhhysrrgznpd1fPo0IETO0bRbgWHg
hFRHKphSYi9Gqnsy3CwUGhxVPMylO4rn+d1nb2QjdpXys6DR5KpIwe+7sZtTd+AtPrA7QugdFUSU
gCh9nsG518Rfen79osO/UID6B0hcxlWSYWnwZMz28OGMgGVkDVpQJQgkwLT3HjKMdQNDxba88ZbG
72m1eLEwPwXWEqj4IXrFrH7IIkBblT+L7l80o7PyOuDj4EZaZFupSF/TzlaNrF5fYtZw8lMZ1hTz
UdIEzNl/bxQp2PpzkuureDqVKR4cZkMmqiHtLBL+fdHeP+D5WlmCGFOIPnY89+/38MAIKHILLRtW
I+0PJTHQnlh37EYXZLwYnZA+oaNG7R6bwIM8q+GIkpKXNiCtef2kBshrSTeSQVzm/nUIamYjVJ6Z
YqK2e78GU/RTDks83VHVPVkxHKv2reJhk5tG4BLnGwS1YTVqdq5dyOib8q+F0c5hyUAgc8sWozBd
a8pMhf/aSdVDg42dbwYPaKba2rF+XXmh29xcISjN9kF8Qjdt5+ygHPbbhe3A+id7Z8Xd8TcaLUVE
cSw7ooJych4Ekpy+y5IeRe+75Q1sg9j56bvb1SgnyFiXeYmVyzZPyjTDQd0oB6LBY9eHsldmaF84
0ZzT/f3WJ5rPk7y6DknBgf3yl+QsbTKJcuIT3/fA6jmRQRHunQfl+yQTyXrLumjQoU8C2Biz+/0j
XrxTgywcUNJMO8tEYJ0w+Q/MTd4KMDlj1opmdz99q93r8qcuj+PdEN2Ht3RgPzW0Yxf/PW2WVT7A
WwMDEm8oLPsuQQr1UKruCiGaPFzG+eT/zrOSzaTRs6fXIXuQJ2Yp4rj5SGe9+aJDleos7nRaILsl
fyEpcwe1JqHL12KFEIX5fQwW9kVYUmegmlFinxgR0KxJuA9H3zl2JaTUVL57wkR1mFYLtM25N/cm
gskW6gBqYvBxJsZrNNXtL3dyI+nM6G0Lg9L6H9HuxGYlG3bDgbJuEmYMHwX+UcNZmKpR68xKhrL9
R92PL2SGcX6Fzfg8rUwk2D3W9Y5xPhBsY5K0KPWoUIvK2F2W2uINlcZWRLxpTSA3HDr4S/z8zhWS
04HdfSuGyHVCT7ZpJj2FEqdBnQmF+nTgpiDUHhiWt0ywOjLS09CXd26/es3lizk/utwa0jfzDH67
na/S4pP5RBpOc3f0q2qgpYJA0YDlchsErN2m/PmE4pu/kuraiBuULcjpWHVV2jVDDaLVN/gvE7jl
/KFKxnMmSWzC+fiEk3LJvEvwe4KGygjxy9/d/EqjJPYAHRFpatS3ziUrcni8iO1kD6ZcQbY04j/8
aLAh6xP6rZwNtlJliIroP4HvyPAFvpza9mD7JLAQg6i58xOPEtDNwmeHVkG8R1ju83CJh3Pgwwvd
Q/8BiLiuwQYJOsSPFjhWFXefQhfSuPi3/zUkeCr0YqUwIGvp1I0WRk/cKxuZ9p2C6DAsa/TYMFR6
OEaM01m+bESEez4OrYQfhoYf8J3N0nETNbJnxWz562Heyb4QQj5PKPx/kr1/i5CqgyvOG1ETuFQ7
WlCl9dSaOlAi+qmB5x6Xd7NvJmBjq8Qt34XYAav9VeghN+LhRiDtA3xUpsPAZkjxdWtVt8s1Rp//
pEmJzC2WtNyq12Ucwb7oYiw9MfhGs+5K6bw3cez4nhcg6NbDEAR9tU4QIcfPoIjbQ14U8p+p3+RR
XbwusfvA2DL1OZzB1BXxIbWsPNU9+AyCuYUtUQJ/guLMXqhMKCQyU5E+5xdYL7f1XS8u44//94QD
mIBAw5qoba19N+TAhgZprAVrf1KYHm6lH/e8Z3q1i+DHycdsZGb8QPUaX++KAGXKqwaLAEwNvik/
qmPoaMpB9pVXMsz1fCFCDjCVauYVkdkUAO1HHlDdyshiVx0otr3KLZMd40x7Akjjnql8+5svKUl8
8nEr1JNyiq2N+Fp9z8BfrUqhBkLv2s6Y/a2vtvPR7tcvvvHeJTNJMWX80Dsy3ZLVhdx5njQLFHVq
7RaTVcxwHGRKDDHLGTAi+QtnWOOzFHGLi8BhPV2tMl4/XXWnvLF9oLiPPn4wK3lpwHrU86DQxjHO
pEAwOLGvYdSTlsObn23KXR/QUQQPLKAX0HCd+2kD3nbkTT5M0Pt45emXcxvOkC0S7+W=