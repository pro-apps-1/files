<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoaqIVUFfx7uLkhSr5hoIoLASnsgqEdJlxMu9JRObkYfJcmXDNPBDQLoEw8IyRgtk/hxZ1Ng
YrLOKPilym2Qh5wf1cSxjUqMCTaZITO7ZVuFjEMauEXd4+x2Q1A8M+nVylJrHzDypD5NXbkfh3Cl
DvemgFl1YXrpbB7JSg8VygBV0sIFPjlBvQEK+jlWH4BCsz+7vENcC5zC/025fLM8LWVooH3GNMON
rKDWVWUCb44p/Spmc62SE5eMOHdP3aVUqk3P7vQgXq8KtuwtDIuffMsorKfmSjmXUuCZonmmPEwE
+Cj9/+ta6gbGqMyC/OBLOfLzEDzq92SeGXvk5XvgH34EseVQKfYZCcHzMJf3we0ubjHqNCgOsHHN
0t8hHDZuzC+xyBv3JPObVdD0XnUgR1hEBJwQn3OTowCuTqlkt+o//dL5jr+AmXcMmnw46PLEyJSp
eY7YSN+Nu/s6keB6eVRK/DquRF4NPDaGSxwrTC4AFr4j5/T0NSWsC1qPhVR/aotN9Q59GbqFSCz9
JGLHV+NKg2W6Z9xu2YiMMqIDL/3pKq3jotnp94tsE9MEgPF9a3GIRGYajsCUJanlR+Q9pWBO0Fb9
JjixBmjvsuuVacX88TMlziK525em30KjLh73GewdjWH7KMXImbyryqyEcsHFTlZDrz5jSDKsUsDd
nUd8F/HhX2Ehqhg6UBYNIBvTeMGZNCdWZPV0HVlZghL18LUrAGl2kvBEwi+Zolg4aLItT/XsycZW
0IIbWtu/gAQIpsM6h1srvPzXCk4ECt7rBEGUkNCUIg2/kIM9v33UpcDuACDBm+oPtdrGZ0LBpGTs
Q/OREaH0u/PcBd2WvsvebYhUVbMjI/6F2h1q4UbWlqhXrrh/AGJ2AxAvyp8TqfYb3m0vom4GsQjl
1fBL57HB9OplMMUsIcPN2/jzLoT/6rGf2/KJ+/RpWGnObjHpMP4nLMc4/Y/hlK+Je5D8gtZ4CpEa
ZlMFw5thOxwK62AVWoqjtm7AwLCLhdQDwx98KR96Txar+xZPoaYodtPiN9YGw6r2Nax0bBIrSMT2
w+BQQObdUzr+HZH1ZC2aFkT0IQaldljJvxIbYFFQYfwvqD3tkFfxh6deSrViaBjT/4ekdxOVSENl
26HMwwMLWGpKBH5XQiQ5Cnsg2zMlNATbtyoVCkuJcObC1xeogTWXOS2+qwKTPemAvluvumVBML+h
oDKsWJN0kMAe5Wm3tdZ5HxhhLOpZhPVZXEB4W/0hGE+2XjRHRA+UWME6gbvkc6dpuO4XgfTDBl7G
i9jKZ2i1bvlQ3vmGqw0EE/5zvr6ZWE7Ccd4LboRNd166EQswttyc/ziRamaTtUgaEanD5hHFpZ1G
f7GhG+YWo7t7pTWcvTJDWEVM9JDtGN7ZWhDXTigLSg2oCnAyqDJewB/mr85J+bkliACufRumzTjr
7ekT/XkO0uks3E1/SQJ+yn6nY8OripApvzzpHuBZDQILNDK4NuUNK1l3d3sU4RlRNLZhzGOHDuNE
ba2aRWGzzWhWYNnArvkZuxPuoKLJ/fBBmvfODn2q/9IkBoxEvJYzE4zONKz/YWtKcAzNS+Bc1mWl
fUD5Jnt519vdwxbn2mmV1R0RRNEEDBpQBsoFk9KVMimdxJM+rI9Pvvm6KJjhPYH5QJ301rON4/T/
oMvCJh8P5HUUE1sCENxI13tqAgt4mD5XOloMPvxyCr4xqUCBzgVPVKB31kFhZ6niaeXe7lV1uTrx
1CLzpEPRgwuCKidvbpZKW5bIg7FSGxxi2ThtoN5yfShopqKUZwDRFezgozAtc7PXTNQhVJzGCxOf
GaZryRP/7Q2NPPbdrYSYJNXn67K3Z6S+qeeraNQ0ok/y93xohJ6TbL1PocZJScOeb8BIXAT9Afwy
Cl94QEI9kAG2/JGZcYll/dm3QCj0wAKB5e+NSxW/0TTASeZ2BWgmiwVRvArcHqgOAhYI79cJpTws
DSzJQptHIWiZyECTP9VbUqIGt0GO2rgyIMQ0rlzPx5qz/8asyVdpCa/EJLN3HF9UBwhvFcgy3uDK
16nGoJXEbLeeax2uOonRng6SIpfDx0Hpb0IrHg53+WwJ/+YgpExvA4h2BVYJppSvO+p6IsnDDD99
G9MwjRT2S8A7cyHE+bTInLzDxUF4VtFrarhwsVqKiQa529QxQZZrQ/KnpV6F5cvagvX0B/qlcPP1
ELjfrZQH8Yj1yq/DfDJpLxbxNPMKS3rQJD7vPy+iGn9x+FN0r+d+gDFGsIt0S3RpDNvTSaFNJSj6
JZf1u/CGyo1/IPwWkk8iEdMhXo8kCVZO7bYLR1WzbGdZB+mL4wK/0fofX1POmS5JOYWRDTcixCVO
bg8J38GN6Wawq0DXSSsw5UYQbtG2d1SfEYB1a8cirqXkLf8TxdCSLadnymUadc++3goY32fhgK2I
Jkz/4B3zdiufdILqYDN1JjLjjKXppyFOjA294noWdWJO0vkFyKwFJGQ9y7hiZFdMIIaYjJEkIUAv
O7lkbIKFCx7mTMl/3L/3VZZ6W/uoePrAf+PimyRw7OjHk7/g09o2N8D6zQUF/Z6ygsE7B4EzcI9f
65RFT4OHN/yvD+Ga9wiN88MP0Xb6X1taXgF4sMYJSiolvjJHZTzCUeQdPqy22ha7tfdCkT52VFgw
sfvCsa+o89oq06BKVsXpnLlLp9mPQYD5TLI6wFenW16aJMABvQ4rozKwgd0XgzQ6kjOYzlGiHKRK
XdR/3c62CvszSIDlCGcPrqKt8k5ULn8W7fqXPSelQk1/35+tta6g0TwzQq43K6HPvNoA9kNtLLS8
oxBdR54AEx+qwZJDuUq9iV7S/qEOYCkpyqRUSPHoMUqTFgUfYpcwsfSE8teFn7JeiaRPjUwyySMO
o6xC8eOsYM4xx8PtD4LkUbVOQvqcYQoH8PehEqxeq8vwDztpFbQSJIddVzcdmlp68z2kHKxisPGR
FHJxsPpI3ymMobHutPacZJKXEuFVdJX2/N9yEgOEUUGOeU/X2rVTtVG+O24tYOuSKsU5NVxqXAZQ
3nT7BdOnkWQ8wRZpaACjc93gfQxHzzEu+yHfhU/U3WIweh4HiKOdiQK=