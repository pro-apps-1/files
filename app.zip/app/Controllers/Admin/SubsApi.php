<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv6eEZ/gA9ymytQl79oPRuZIGMMr9x8VyFa3xgqrzojUp3vPOSUkh5FCYs40zlxOgr8NZm09
uBPq5g6SQ6ZT6KMeGLjPNjFMa4ohr34PU+VMuXCrpfORK0wUIi7NBFVEwX9i9fTSu1m28huFKd46
Z91hqS4C0bDMGRZL2scUzGElG0gRKjDjBXNquCEPoIm9RLePQLEhe/P7f6AOrCKP5RQEfRteRbC4
wluOdHnjfVpFW3FYgrfRd64SuFFclxUiJ7jTMcFFnFpNQGqzzeZKqb1s7eEL4+OLQ+nAkCLjGPSD
kg6Rqs2h3lz9C1mYazPg6hPgkxQ8sLlFzzVWYm8cegm3PFEn6sKvsZXem2iGtsk0GvwPM98RZa9E
gkf6kUb41x3u/EmxJp42EMsB0LZJyQNStw4FUe+xrbRhQP5XKBCzpuA9wwz/dhMj9EHf1Q8Y1WVx
KKdXqashdn8D3kIG7ReJHcnqXtCUgMx8v2EkOlmqf5xh6QldQv2O8EE2MjgAa3f8h6NW4oR1c56j
4BqCZp92I/Tmqs8g5jGnYr3hfYedpYVNjEVUvAe2ktgSzZQLP3D/pK84w2oWjxlFi3stwUXSI9ys
PuZy+e52Bk4RL41dUDxBM5n9/9m7cBn7gkBJb1TjiOJ8AEaH//OFuQO0++BHOSNkHL2OItdt4nED
rNsAgB8s8pdx2yuwuZw4+13msb6XZWt2cv5rfUee1YdrxIl6rhK9WLkwOIoazd4CBpQbBq36aXxA
MrDXuaKpiTdyH1J9HADdDaMo96Bn6vfwBFuQ9360xPUPWu5Fr3fEC7bjX05Ymw0e/KqO7dWVTu19
XMKJQWlAcMtkghDJ/mYbwhyh3vFjBPoazf4f+R2lauLs5elpn+YoQpSpcvhG2AmS7w9jhmKE3cMb
PkTVLJuPU4F4/ZEOvO62T9WKzFgzi8h/M5zU+PdsnQFga0oyx5MgINy6C926kPTIXZ4SibMYXu7B
OBAUnbKaxnArgGfB82zCQEfFBhmvI1X0m5RTV/CFUxRe01HeDGtEA3abY0/Us+/cQAhc0YtSVn5d
O6sB4V1oVq3Ny9Nu1VrP72mRh4a1Ts8zyNhtD+Hcn+xJ6BhsPex43fy4/T7+q9ZvSCAgQMe40M6X
m3UtYqu2olXkhiHYIZ8EPp5s7/il6wsz0Lh24U5AeVCwOWgqYGWL7nIo7DCaWwWuPnuOr3besH/l
wycnVJHhNrdtkyhTWfTW9n51v99s2KbFDRZ6II/F+s3nhnG2OTVyS/aDDL+pQv9Y7T4xTTJVDtb2
cr4h5zrjGrJdgEUX+g9nlX7hA9KvAXJnEMLoNnuhlIaOH988ZsiJ5wnaIFbJ5+VnaeuY4y60MsOD
dxGUl24HcaoXpL1WEsZv3xIDq0pTpRrGNANuVRKGXmXayQ2iE9SBObgwgzFlMAYcTMDgK6M1+sPL
z/2nCx8tLupAxpA8ujpNG/XgplGQNUgcSWF8ShuERaDcOxfSqka9idMe2KwRb3e3HgVDVSif8trI
i8ICpslT2MZZrgmRiMf5xBuHPOxPEUnTMgzoSllXmZ873wYIRO3DcFdJbpTXKba8WSmjLyI5DwbJ
CW5oForWHb1ihG1Fnv310LlDKSv4pY/xsj5vQ6BN3/JDx2UshNedYN5ZYZqS1fxRyG0UeQbk0xks
IP09xLd7ANETuH49bPPyfv7B1exLgkH6dL0+UrU0OWDrlO5EAw2tWtfqUVAaN/0BbI8YxC9gTy3/
5B3erJLpABke/1PuPznk8Gr/ochiUNjr616Eu8vAALtYf2DQlg5uIaHlrM5e9uHiLay0HlEr9ezb
BHKYEhc7osgwOCnEy41nkxxC0llN9Jl03PrlG9d+AC32UB0oeBqilRpyCrX++I4zr7XofZOC4laF
9Yw44xJN7Qluoolvd11xLAGA/C7AXqmYtXFTcInmqMiJw6ABuP+c7oxGXJaNmChJtHCsPSpeG2ql
mnYLoAIZVrm91wfHh96VSRaCprIKzDD8SWGg7beJKIwaAceoSNfVymp4CPjo8G8M8niufL0Ec+Oi
u43ahkItI2lXD0fTg4m2SvBDnfMJ7YlPXqGN4TCIZJM9gk3M94KlFLEhxyu7hJI3FVYR77Z6jdSR
3LEUb6JkRTxalZJT2x07nr7nD3jcpf3nBflKbh7T4Q/HCQFJ/m1eXy3sTRfVkk7UewqGb2ZJg84R
FIp1mT5fGVUq+4TDj7Uf1MsFqqxEYrXvXU77xKQBoGJKR3gdjYNgG3wH9bTLE60O6YThamT3Oxac
gW7SfXAdyakXbUYlDNoSOQGQTZh8yMKsNYuxeOzq8ONdSwaow9yQzgHgT/979F8rOdoNiqf1KoQB
tlgS8eRK/wRrm59VHxu01Ku9G77KiU9EVe5djEs69F/0wZyXnMTtncfn3jnw8olkrwiXOgsBdgl2
PLlV8MFBnnLA29IiSwH11PvQfAcvhLH5lRIBtskqW5YkW2JuPNurJQogZLzEWyzJNpkujh3wniTX
ywDCqSJXUWzs4XsOzBlwZbcodrhjPv0P4b/YGmIdk+ScAvIUWjBjmnMU+J44X99oBP5b6tZYRpQh
NdddCPp5GJbOGcwQLqt3AlztxqHMW1b11wk/0b/Z097HFS2k3MJUisZK7MRpVogWAsQeN9MYsVWr
pRHAawT8vXfTA4M1l6X+lDW5K6l4AcB5/qddyFf1p2f+EG4hoozFcBpSICVElmcXIF/Kdm6SBHhc
7Tf/efus+ELgRYZFvUvG4ibTicM1qptiYEiLg2sWsu0G39Gxf/Our3fmR4/Gh/voySJyU2UoIXD4
QBDEdNCjSzP0uNtJL3lNHqBAhFpnsfrPs/0hHw238WOhYPwHGzvKVsEbRXCr3cosCH1KomGejE16
LV+JyffoWUR8UD6XJr4sfC0XcR0f3tRRGkGoEd+8W4mAk41l416S6S242p0fLCSqiTAw39yW9ros
Mf8wrm7NrMJRv3+3iI62LvNHcKR/w7FE+tTK+CZoXw5tNF7goD9d7zKwT3T0FQtkiqvK62Gas89l
8jlI9jmB+O+MJx17R7rHeyZOfNS0VgSKPxIM8Sibk5GYQNSRVu1+PArdAla0ZR4uCJ8oqwFZXrl5
9yuu2pETiXqGd7a=