<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvoGOHGOG5fSvKxqDrNrYJyqWjmcJXlr/gMuxhZ6/8PVCNpgwA6q/p0Nkmkc7H9l+sAcniIk
N5lHIDqSiVhqaqrbtAyjvflnM5rcrNFV6YFMTZWIxyDMmCujBUJcbb/3vPsyzFRbwoSvzD17da7Y
YsO5+Rpv722T7n4246sBL7ru0dTojHzkOuU7ugnNui3R/0j6OTdMccLcKKMnJ77sGwynW/I3ipsO
nAdxNX34R13cK7lIRxvgCcMisP8zrtH5zkMOAWetD6Fa59t1nE8I/Q3Fmurm/wXmhj3fbS83n+RI
WOegwNqSJqhIiC7NFJTgK02VUDF98PHriJ0DTeAvgupVWE5knHpH2stDV+MPuqLUyvY134bsN0nO
gPXlye0Hq4qpTVTebzbyVLukpZjeXkjX6T0njVmTfCKaIx7NNSNHwgicWB/mDtS0tZdLgOy5imFx
OQmtMEMGCB7sWurK0TEiwAwaPZLAf2w6LyGl0APK/IWOyYFnlciP4aC1+GcmBirMLfblPQFJ3vx8
6R8aLuk91Q6rildxKBfT/YJRgHsec7hKxqt+gskgQw49He6RUcNEwWXueI8iQ/T9KtlaRbZpBGRT
JhDjfGHgWLmCYjLo5RR1z7TPZBAvvtCewB4bDqtu0Exk95/xA8u3/wfMEiHlxNapfsJHuTPHHyzU
8utFm7bWdSwORVY6fxK7/TWUORuEvTiNTUGGtzskSUsYpU60fOu1cowXP/rE2vKsfUN+MFBFNRF4
/Lv5MXFHiOXWjrSeGvb6jzy5tqv3u58aWNCQjDyVs6R7VLiWnhmVkhskG+W01oZUoqN6opQ7bIS1
KwY4brTgPX2KAMWEMpPktnvK4Vf70qPM/Ki9OaGvnGBHP2Ioc4ioWw6DmcErwrkJQPCKUUhyduai
nyeCTnZQxXvPjkyM3KvWrMWNt1bdqr3fSV/2p+pHtCCKD65UtnM05L82UiG2N+CGIPAJ7FAu0L2A
V72VzpW3Z7Y0PdPhiUKYLLxM7jjMyW6n4cE3HzeGDCPXj67hPIb2ddvIsUxgc0fB8vmSdpfYm7K2
MCjsdZI8k0NWbaPrRV0XpUJDUPTi7TM1QP2UTjMA6yhFRnxPcG/0rRpeODftQcHJ95LdNp7GrmKT
CL+D8VxoTSqGwsEdp1v0XaL4Muo+O4IsKM3OcKJqyudrdk5MGtAU/qvpoVrz4eV2NlCcBgm87NnE
0R39Z2to1uI0A9DtzrSzXphc9wIkTGbj2aPgxZ09kZq0QHPtyuum2QR7lSc+jp5l/X6Yhs64Loai
eg5guQfyYhmL64kZd5TMikLo6xtvxW//9GUmW+Xs4Kt+A8/ANgVj7Uk/3wOl/umsDoGWzpjITfY6
zmRfnDVbQvztvbswuK+fr4U/b+7QwQdUdqsZa0HMCXi1t9xREbZ4WeN6yLFCxJlEw+/sNzgFCyIy
5aWp0GKn9AKFqObtjGYIdmDszSTzrkX0qX+NaKnpSJVz+aZb9LSMo6Nh+4ZnKSOrVUiVJrfov5Ev
ioCbVivohErdK7/FvRUGNEg0EPu5D4VvaM0kJND9mjyG80enI0dWZPx1x7F2kQ8WRA+ubMhW8n65
s7hSObBz9LBhPFL6QFDK43LV1pVCraYT0H/sHOyp70SI5D3qm60V9ut/3jFD9fIk+f71GbsPGP1M
3g3Dz9bhtxzk2muaQPEOvKN5K1dz6k0Z4Dt0t2L8ztiG+hxVDLf3Z5QBpKxf4D9kLDKbSyR4RPp2
OlMfDoTexUW1YHBlToPq3ATbG98MxycjxKBjqGyMRf41se8+JMqlKVxIS8NSMK5GaH17k6ea11ck
wRs3kE5+5hcxii88zEiM1VFDmiEw2JejH2EtXzOVr+iv6CtwVevbKiqOaMQmh3hsAWxr0v6XxJeF
bF0XQzvF8HSP3UgMNctQWodFCI05V9t4lODG/9DpIWbXQ+0rDoCr2dtS3cI5b68vXLI8JFb5THkt
yk5wbvPjSG3sh//sX5QuNv2NB79M+hk8FzvGmNCzZLYtJOFfFTtleUlpw4k/VBw92/zxgW3RjvVj
nxPgKGx5wKxFX2GG69wlnlIbRXrRX4Ob8JhUaOh43ITf+VMOpmCqr0stR4k1+HPPZZVq2B7fHBSl
6dOfK3S8YT3inxangEYLh7JrM/8t5uhQLzp6GbVs7DZWasb/649Kb0t7QmGgu3Kolzg7Ti0q3x9k
Jh3BopyaC5y76VFXHN2d+Tznwd1QSADZj4FmkYK/m2NR16ksgwyPGolRwXJudBKq8apmrk905a4W
me+e9Eqrh5ZhgxoVLol5JQHwJPSSGlBr6bF6ACh/6H2+K6jbQCCisOgD5yYW5516XC/lRYwDm1EP
W3gjI5E51kRBy8JAt/Z9pzxetBvtz8wRAdlzByvSt9cKNVx+UEZrAq2Cutn4+iTpbcbYbGPMGMR7
TbaVgW96R8ecqF+lQdtNqqzbS66OjNAwZqKA45rK+tSdZ5UngugmAg93ijmGEuAgwKFjTdPIEASm
w8HJqzbkULeF9d/Fk28+sfUyQxzeNqrD8pSVeAUpbEF2bql/0tnyrn2Lnj19dtD3XE6KtjINvs/o
YuieuUXd/NEnKHajzaCA5uLN7fH+iBAG88laYvAp9tIJSHpWmT9uqV8g4v/+cpiG6p9WPPDJltV3
LHj+CqFN0NphQ8ovIadtvASgDnInVZJPUbRppqvZdf3z9kF4KmgNm7eAcYaxgS/fTFkjqsp/XCHF
ZpkCq2J5YDIdjj5LvIJsDj3S1gDAlcvZjj3BHmlNwAlX0cla9P5ySM2DGb2RjOLFKf8P3vBmpuBi
Hw7eRxDVj1xDGxzIGEsv0NeKfPIK3LBQzww+poE6WG1N4KOnud8ueGwFoeaghB+wv/UhI0Lmfa7O
ybW9nEDhpXeETt/O0x1TdxUGbrxPRtdw59D482PeQ0cgmQ8lSCU9umntuc2+mkUwC1hnyGjxVKQF
mmMvxtVpesbZj7+vqf56FenJh1sOf/5K1vm2IVm1uo7bY0AG2I80yNEFgo8WYIGJC5hQijTlU6cy
t8hwcrce/qkhfian2N7F5XLISD1zCzSV7H38lZbDxRVyQ+yt/5x8INdte9SVurG=