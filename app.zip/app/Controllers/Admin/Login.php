<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwEQGSyNKhhWxa3Kx2KNqK1w3oLH4mNFuxMuZxAhHueCex6u5juuKuXKcco8+ucbchlK3OHZ
LgDNW1O7S0NA8MgWIiMY9WVSHT9Hm9Faxh5YscZO+nQWQZIHBlN+24XsYxdUdzXGoTSGiPb1J/s+
WhQ0N0HAYEuP6urTEvjsdtWQjpYNC25WTZYeiy3JIDXH/kmBp58w7GtccWP6GB/a/J8Lhtu+l+Cg
JgDwkO26uwyf0gSaw+O6docI9lVfRs9/IMvtnar0bIC/IiIrHvjcnscyWnbef2I50VtSiqFTM5oO
5wjD/wBk7GgMxT04/RUuMjg4w8O/WLBdtHydPMGMbVppfWInrF3iUsaazjR2yAVylBscV/6kMgMK
a2KSAYVOT+SPKc//GxhkbQZCeUylyDNqmRiT+htEmZYLUdKPS7AGn/sD/+rg0S9fV245ghSErO3R
DiIrZjoFP0g2cPsZmipoWsig4KVrnUk1ZIcofoKp6sWPsNwJfcdLaS/eAm1F6MEMD5R2QIzAmHgm
zycLbghSbnJckRfw+B6cPGLmW3QV4ZZ5caPzf3L4qAXELMlW3rvJKx/PgIXq+Ntq0FVVZ27ZVGQO
QTCXyFiXN5Q6oFj0tg4ssqV8t+mzRajNTfnsfsA2J6xOqT0vmopSK4pVKD4gxwIsYJqVWBSTDhH+
hcL8Rupb5h77bbM7hgdw9xCC8T1Z0hA6zKfGrjNbjmKi25U79D/B5Lktx/WESPbTe4W9NgxBiXqH
wSA1fBXf8kAgjnT0vCZDNQ/J/6j86n+Ao5MyIlD7xOShCeRuDBSKywaqmhHtvpULh6M/DJ3xUT6S
kRCcBUQ95b58x27wnFm1g3G1t2JtWZOH7kKPAX2MqYSXJqlkxuvV74uFA8B5zqIo5oZw5Ks1pgDB
xyI66e9us6XGgaOzgOAkoVs7paOGZjXO9ddxKESr4kJIHTn2HqZCGL74sAbwdwV3KVFvz4+9L/Ak
70BJ8F0lN//QKcKJGNezA2IhfRrL1LfbcyCapHHWngkvgaxISHeE23335xqYAwRNmI6z3IiaE9Mj
0CvZKqfdVdQEFqqh7H8s7yflWOeqs+wcPAvBcFWa58ZO1sFeiW/xdEdWz+aWLeM0mpevH/jGcR0a
RunRRlsV38cDlkUJIjOBXk0+Q6wi8hVAwgE02ywCFouxLYDw8FV35uJNV1m7+XgYBXlnzfx7NNCO
Qu/kgA5cYeVj94Vx32Yc6fWQgKxqh4kHmIQyu4oT7eiLylwNoiiu+mFlMxen4Zk6cUU7QbFHKKbi
6sD2WZkfrTDsUqc2JLHGdIO2hbVLUEKCScpqIrifRxB7tl0v/uvkldcKdSJu0dY1mAbibPBmDfnn
yLHAU86TdOadoeLrto16lJKvwPqLPz5y9CYVY7TXRAFK3NbGWIs3WylZL+kVnSUo3DM6n00jBKYx
NV4QH5oaNadeKie8Rg6LNKmAvE2Gvt0M3AcY/tO1b+cjV3TsI/Ieq0Au/BHJIljKyqR9BeXTYQpE
m6Au08AKi9BitQ5aIljnPUwb2Cmz5tI+Qze68fWN2AbCfacUfHAOWdlB2eA3YI/mK8im6oGCs0uw
NOJn97I627PqdrPfIPkwtVSDzdTZzV9ekqlUqitD2QPxNI14prcrA88SU24/quIMgENBECgq+kF/
MTuRbaZ20WL2k6ZT/QE6cQafnlsTZ8Dd9gVis34BSDIk4NDhrmL+A17meaW5vyED6TzwzEWTuaVK
wANBIjAZ5+Z/LrB+Q9F4lSYcXPumlERsdYOgtUgguVxVaTJatnocGeRUd/m9PNXVDZQCLmyBJ9NU
oJDgcLdTx6Cu+eJo1DkEiBPUlUsuIbX9CB1LS0xrqpudjHkk+7ixdv0hRMXnfR9fZa+wR/61mtzh
Tb9xAMTAGNyeS01GEhxzYeEQWeCj6smYHJS95BhWreTHGypTNY++RHyMDu0gHoVYGDivdU0QKV2p
N01Ic5s3ge7jaEP83PpuU4vimpeaNf/KM7kxc848xNxlV1v3wECIO1mi71/bVsO5hroY9DVmkg3Y
MbcKe4OL4x0kh3cwWDLouWbU8S22LodoZfazkEvSdykzTeIKEbjOMWCQtjX3WfTQ5tJEY0kpdh9d
i9ZSs84ftbn+Z73opNgTvZIOiCpDBQV42EaUmsne4S6MY5Bmny4iyjdA/z+qmEFNQtA5Taa6Snm3
tpbmYC9SB1Pv0z6XTcnUePHcs32/ePAkR+2CO3FZ6eRM5c8UAa8sNJQknXDR9LOP7HUjXluNav5Q
NQIutXoIPGnzbrbxfVblWBS7leLyZH8tUWkWKm4Lp4S5D+GqOdTVK2bH9SUl1+uoK6/zMU0MR2v7
nYQJ/3A/A4kXpkbFfCS6HYYfWSO/YcDOaDWvgMiqjOgtI5zmIeed9Bot57aG6x4QEPPqFT6Ir26M
keg4W+uAPVkEViMgus1SqseH3PfYfGkA+5P0TA66D7cuE2iBfzH9PQtiBdI4u/mNZ4tR8vgeAnRm
jBChlel9SdmhEe1sg9lHQkL64b+tSJMueG5LJIRUZ2elz65nhd1wcFZ9FK6HOUebWUhX1yH5dw5Z
m/Ds6071cT5XctYJfA/eOsJomRJ07FeedE2pld08KOn8eosbjE9tc+6an0hxURNHaRwhWcDpv+T0
7XdyWDEDgRnf8nf/XQWCAsXRso9m9IOdXy9/5dkVSoSKbxz/kispqf7DEnerJJHTqI0e3+se/R9O
Xzsf1aPkEzft44N+FSZwzh7HGKfCzJt8+vPjOcFuK+g6dpxQg0DQvdrBXeSfWuue37FVsnDjhmLm
YmP7Rtp23X4+f28eaMN4uKAupUjirqMS53Nyb6ODIZMM1NoWvD1J5eEfSiOqJYlNX4IXnpAaHvA2
rKRwMp2FJyQxyTyBUmflmQZmZuu+bDnydWDqwQfMupdpxI1QQTl2x1z75y0TetVZZS8D4UnhdFKQ
AFQxPIIfDp2/PUEGZKGeH1wDaJdKXHH7mi1iKqBW5fMdlhrTGGyXiUT3dQmPkBrG/90oWZgvkDzX
r8TpVL5TUYdV7BJSMU55EoEEukyfDOMalOUJ7F+H0Tj8YmUkJRPPnvlGzaHj777A14xU46UD5RuI
bdiTVbXGZVluwdKFnjbTgiEVqP+u33PCtmN1EyEy3lqJ7GmGnvyk8I0BRx5vCnZ+fSuoZLZen4n7
OtHkjq76TjniCTqjiDYBYHbv5JGu2dHB6u23veRYguvth+j/DvQSRZXZSXkZ+24tJexo3aaWjxjW
9a9zj5UtaVzyQxFRoOvKdPnv52Ad7868HOMMBJ1azEI2jQNgwF93TZb30swwZK3E5Azh4melfEgA
f+Pzu0MImoivfNjeeWjScPQG0fPgLQ+U3y8bXb69z3rtgAN9DzGnM+XhwepAx8d+tknWlPMDNEHE
/zkaBhaK+p0Gr3rVyJP4H+e2qczjmG/EqqrN858SVgfx2xdz8o2qNaT81whN6eQ49Usr0qqLgVuR
8db1y2Ae/ht2t1TSLmoQt6nbD9/D0IAzT8fhG0hg06wlnjf3NHCvlNGXzL2C9mSaLzG7E95mtqKc
XGOFSWacPNf9tTDEA+p30med2EDOd+0CUOGV3Pt22ohYQiJIDzfipzggUSlw0nYBQNNQoox9kPD5
R5wkXXZqjtKVE4/otEju+sgHqRiJNCp4zPJPt7mqOSCFU6tcQ55i1loXsfDaSXo4ZT9ueGl7AC03
lRCbHY3E+L02a6W/iple6eFIMBtfSNK/PF/kQNJ/4jWk16r0UuEfdj1zfu2240Tz8bnWOUcw5Z8/
2Wlap09my03tNNdCH9XzWVrP8ML0sMRw5mYojlw/IK+Xa8bxrYAFjh61CqkUiLl4TuISfSyzKBZg
cCNMBdRcTccycOM1N3+fQ9GsplQrPGm8sEumFaAz6XNabVbviK84RIcGjezd94TZ3J1C4MH324uH
HpxhhFyT2MoyxvxOktdY156gcMjYTG5jQYcn9P20Qi2X8zRrOQxf6Q7eoAVxNDDJsLitUUhO3zP2
R2HRuBg4TlAEOGsTlQCSmznCUGTstqmH1iFjBL8f6ltolqpmd9bd3asjav3uUp4sNDMvVOz+RTAw
S/P6W5zHL2Mp4iaPP0+zsq8l/1+jUqffbrcELZ9e/tW93Qe2TfqgVYmbd8BKzEz64zYDRA9Y01o8
EmHneWNRVSH0MkcTWJRLQNm8eKp/EElVwlHevWNNmgc+zn6tvkV5HJ5XsdjmjMdeEnuzQ0Gqhoya
5soYsEihs+Fhdh6jxke3BLzfLumDcpead7f0CslF9yAGvPWNBXnoHeCPA18I16ek4lPzdB6+vyMX
/jtSs4hp+jyGjJaqixBYqlD32u+Lt08PmYnhP/duiyjWor7B+SQhnfuzVn/PJE2+LefPZLNc2P0Q
7aIUNjzHIl6p/+1eD5fzlJT4tO6vH0lnaG==