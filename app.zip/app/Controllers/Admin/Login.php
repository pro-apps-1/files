<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy+JSyQiHKZggKdcvHLj0Vw8WKhOPQfT4F18uzWhwVuzJe3ZHLl4H4uZ/0Y/f1fh+kZEGnf6
3TgQCbGNZxyU1TzWvVkFGrl4ay/XoBhDc/ULDJSnA1Ce3hoTi9oPPKZRz/7ys0/i05sSBXwHJxYv
VBHbaGQ8Nqrxygm7aHiXwKn+ueE7d8ePJGDxdhL1zFO+m8QlqnPY6vCwzLrc8bW8SnnurtvTV1Bt
UIJv6i/redlBjA6jGibZImQzhVkzu5p3/5hhMMFsUn96SwyeGf9HXA/NtEnxYct/q7YkztdvHdaM
IFPL2d7VJ15kZYPO42g4TegwCVHMTOa0LmhwmAM2WBrfTfAY9b9F7ErqsrojhDcO833bnHU1LKXl
OJ2AJk0bSf3aH9Q12QKvNqr/iIdPhtXk8JCBvTXJgigMCn30HUG6g/sYOOEGXKYeos7rat904mNJ
uyKJAUDqDsWi+74b4wN9Znrnc7CjmKWhra5e31UpRr6hDO321isU3dBgRJFs9iFRGUQnno20Gtd5
RhvFKZvjay5BeC/VIU8JIHk2l9hivY4WisYnlcUwYyJKx6P3tcLfvMZx2AzwyF/1xeNhWF0Uqh+H
795DSn/MJ+/ebl8PjwCGtNoFoj2+UTLFmd1dDmO2CLNJ2RLhKAbmQ4jWaeihaGn4JR9KftkbmUnC
047iWPl9sLZyciQT/37itYBwD9M1iMFEKTNlZEyhYN3RfDudW6TsiOE5CXJgHnaEaghROp7gOMZE
cN7NP/WCJQ1i+/ZjJPTrqPaMI7dE03cWV14VOPzoZl331XkR5kLoCqXEfJZ12wVB9j0h9Koj1EFR
xbm1K2crotuvyCoiu1LbVHsoTieNNcLqI/gJuY8n8QSnFYV6a4LkLPoRbITcW3z17SdieIFGTEJI
v1eKGJrIumuxwfUV3yV3T65EVg9xLOqHA8LBomfDa1a6q+CVsszOuIA8Z31KT7wDokTn0KTvNNcs
KrcWeK7491BzcZ5R/tqPW8y90YCF7zfq96Uo3HR8GAvbDR618rtGuM3c3ucLyF86n3/6f0NFwOOh
VuOpKj3yTwosvvWeCbklOcxYTUXyOQ28AEBpjRrGcY9tfmx8v8xljN5lmnK417rB0/H1PqBfcNI8
P7KhlGD2Tm3tKiPo9ljS85abf9Z3194vDR6Hs08zlIlXFlbHSi8AAJjKHdr4W1Lkjyn3mzPDrP2s
+5FhJ7nLjYFROkysBhjXiG7Z2fH7yriVMq1WOMPmIjgyMmSddnQePeVW0xArttSikxAMBLjrn5Y9
JbFb6GR9MyHpC7LMVmyPFnkoxvmUCADOuYMx3BM5PaSqYvGaqMXww4Z/BU1t4Qva0756zzEWpqx6
6y59C9V89Gz8hBZA0JhPp9xAHCJOh7OmGYCR3KLoxDdfm2afUkUNDu6qC/cXzdzdJhtb3EBuXwW2
thp6cU/cHF9ExF3w7uvYTX1C2irXdX0JlfPI9R3e5432Qi2wLb5Wb7PkWZFLC9o734PMeJr0G4bo
y3kqo4BKQKWRPobqxoKmmAjdTPNqxqrmzXSDuXG5XH/x1g13FcSVa0CQQqN4419utB4DPsuN0USM
uW8emR0h+6V4ykCY/sRIvkmH+DCftEwCHFBXVyaS3jIQJWVse7Zpd7L6zUckT+Yr5+NsLuwBBB0K
25UZ4ChkR/LTPHfdI2cNJAfPusaM78XT0+1SfTT5vQ1Qu/1rjTUIC8Pw7oUfwsMr7K3hHIhHnuZ6
RTKF5fJu6KhjkiCPCDBvEDxLkqiAgftvDzDHJOCaWPVMbJUUw/mnnl8maOHPWnEqUyvseyQLv1Vk
En9f8TxQb034j7HQaDF5enO6C+A516oiQDUFNTaSZJ6fD6ZG8Ra4EUFKiUmErYLgR8hvB9Awl83z
yKw2D5JaW61iqB4oWz8DnZ1mOV7UcEKwN5pDOSALBModcjHZEYr4puPlKqsVmYNH/yvZ17mZmgNq
ZVSTEKl0lmmsNc/vLuQHIu5McK1yYRr04nFO/SmG+ZMMdmum6mEmOIiLu/0Z/p4x0yc2NPe0N9tC
tUx2Fhziw3uxXJA/fE8ibYHLrZt9j5twhMZMOmwMT1cT1+8zPt0s45+hsfmbhPQhTJ9zHHbn5s6T
n+c0pX/d0H3jOirQlyM7e2M2P6xdRA21hmExp4Ccbye9XAGNtAE+sBv9JJx2HtdNWULr+FaM9h00
dTj/4QdtNSzslrvC+e9zGCESID/Bf+svFMg+X6sx4B5k6GcJh38cuVkD+m0+XsQ5vt3/OdwpYFW/
5lfdFwNPv9S/mYI5fRExTwfVNAbAfPVxyjEb7NcVGMRZBjQKWTp14p5eFggkD8Lgvwomj5oxUg3n
vTwmiDOSarIGdnsGy2F98nq7r1SUw8o8cvtyM+ubs0mksgRrrKpGATt3eI2C5RDRyxXI+bf7V/sX
UlA5wJNM43zhveKo0mwiNEsv/2dfT8yCZiGrTdJKW0h5K1gTUaFUVWfqhhwVh5j/g6Cd+yR20DOe
qAVU+4pELYTBduEjfUaT3l7ifCrJSfBYmC8HluQbjefnxI1P8Kg6T9DIkXBQirafqdAnZr3cVAXM
SS3rVT+rGK4oGJ2pgAf7VXfPK0V5folLzIMWek2G4Y8bMiuL5mN1/M8OTB8waijcHhMr+6lEOiMh
q3vP/JXEyZgnN3hTumESkw43sYfX3LcHdhlfFn5ZMjrZV8ARJT06cuD8223RNpRPi8TJ08IXRdG/
Sa4bhKOQhitDBwHeaiUkBqOCIKm+vtrnBcReN/4k6PZ2j97YySkKXCeLhRc+ZaAozYpGwImYbuWh
zl1QXSpCeDFG89mIldPY8et0dan0TB0nQFPXsrpRQVO92KFs0gRZKGHjitEXJgAOkAC65Plggl/x
aHxsX7Rnhc6sZx5V0xA01n5w2ovumE1eAz35rtzpmd3q2wHeICNf7fqftO2bhxkflDauUn/CReno
8ZFnnqK7qVrAhLvQiNHnMgQPnYMHJaoRUcwkZyXZ4enbkQbEoD1fc/uQUHe7aaQNd6vr4RWdvO4b
AezyuBDnRlaGriVH/kh2+UCk/3Gj02PTWfydjt7hrB+NR5QkuRkq2BYRZjU8oBwJ+KFSTfXxYQl8
xAFMo/0fiBREQyMsRCmHpHO19nOpb0kCnqRzE16rB1XlwsrRtBdoSwqszWM3gUAHfU3d/IpUdJA4
em1W1QHWif6rNenj7ORfQGbPs/fP7YFVIQXY0nYB8W4AT0QNBopfFQSLoPLRoWX7j42rAf7Wk6+k
7vC7v/ifrgTnLTRLaaIN+qEGOk8JKk1Ta1ZCtBdfyON0+8+2MN5OduVl6XL/O2H3VKZKdEy9rBOb
CPzekf1cZx+Qj7mnUDSYWgfUBqWntMNVbhd9vhMylFrR9LUuPqgWlwvky3qA24OpgEPNGlaw7bFC
LWaIc1rOR9/WdwVx/n5qyTvVVes3vGLDDXK/Yv5hqKrGgJ5I7j8kulfmi3s/1gWOxNYiyyH9hHBi
fDPnmddNcwysmuNUm0OGFeabINDK2qOPONbt8CGV6PMQ51nggvqKD4OKQmyqV3ippRPCat4C4eja
Mi64iT1v5q60VreRc+Mf8sQladQ22M9OHx25hCdRYmrnMmEao9mhLBg1/5nZw7H7bJZ0u9EabByq
EtPSl1PcniVxzdHV0wg6nBATVaj6EInMG5gbo0QSqv6axpz78U2ZBHwgRqnCoZkvOFOBc6hfVAmF
O9It2m5cYw9g8f6Tx9h2lA9Nw1h51M4CQmYFC4Wu+Eo4ya1Y+ankHbj3qmKfy27baWKIpVB6MVMS
tpezWOtqtlzmBfjJKrak6z3aYxpksqxFGf2X7k2UAYyQa5Zx37Wh4e2bLY+A/DLktgKQW+xYJrgB
l6PBO48mIoCluLnQeF5D0KzTyVni14am+ZTVTsQ2vLZ/x++UCUrPQ5yU6jVBgULoPATAzjPta1Ys
jPmsy2AVCKH9tRcuywNWe4MUvBQ5t7j1mhDLs3NKsrARpXBsTrIh1hl3Cx51w+Tot9vslyPPIvwa
k5BmQ4YiSgFEExB3scY5D4yfkByZ0KnEZ6bm7UDuLZQTFvkEWZiRc7lFKtEpy5WgNeoovqvbG/CK
78c5LGwUQxqz+eWaYLAbykjz27rfpFSw1oY5NUpvvoODtMcylNJa6Jgc7HNerttA1whkKp+iFcIP
MPcYQUoF8x0ARKenKJrLIYKm3LbMQZBtnTfKKigaqlDdO6bAql2D9zpCL94vR3M1EXzb3jzqXENU
YcOosfv0i+Utl2xOdQiROjkPD899uAifRS71lt+F//UAmHRkTVz/lG1BMJCY7l3aaDVUQEYSOt5b
t7lVkEO+YiK5syx3qmKY9c1x6pLuda+SKgNyZiXfJwA0H6VKzTSVmqqgTZHCPFOfJRwJbWcbBpMJ
cvzYCYB0OVAdO1Kqs20VNh9MrqdVaqU3XYwrwsaqxImoYs5jWfYNsk8HCJUpUiSLjGFX9b/pM06Y
i4mWj9K=