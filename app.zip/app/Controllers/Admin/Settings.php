<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzK5dCZLXMNle0a9wxukjRgOghmC8YfBVFrSVucpm79dllv8NUgOHWO7H2RsMScQdCHmOVQy
rI7EN6QUAjCJo+GS6K43B7dvC5KslyzlozepQGEec/AFWnhgbZZy69IZQxBuPkmokSUOska+MSLj
nfzSSM7t8pB0EawedncuIADNo753E959RbhM9m/mogz5pQKalCfNzeUDt03PkyUrntfiFZecufh9
cs9oT003ttgYTE6T8A+OMN9ycaU3giXlA+FOKZIrEFPCywQ+/z1G38IBgI9bDsvffshMBnjODuVE
hkLDAYNzDoTzpJdAaCQOcF/gF+Vkpb+vh4nfWb4FJMJgUcVoApjz2zGnLpq6WdJrlgYizngVBXcd
+kyBJJ2Vtv2xcySL3qTfy3aub/KPNd9CLTQ1FL1CHU81l9isT6vqxOCfRj+oiQ3qYqanPvJgpBGQ
ppcZNsPY9ZGiBlnwnJ2vGJOUZo0/539GgYU7SN4Xlu8cYX8jj33vJ82yPwuDlv4RCDFj9anvKi7d
Zz7cB7wvHgzWYo7FdsjtCvngJ0UXC4ioeMJOiZgHrzNfZNpDIEslwJlVTFfDDG6SgXaCwL4nxyJJ
/QOT9xsYtHyiy39hlbhwpoIPg3Cnn/Aaqi0f4sO2ceNB905YG27lCxSeLeVaL5YPomQ3JzeRrO46
zfoBsuHshSeS7EJmrzs0qoVTQlt0Qcv71noeYzBPk+YmUSuerSNCn4oqBnBl2A3QK0Cp/o3/A4Vw
vXcpJDq2zFqE4LKZfVU2g5FaGVsn4UwRr0cxL53Nj5lL5Keesqd2xfJjMYY67TUMlj9Ut5B7zQBp
ZQfixFQ7ctMafwBviSsIBpMLpTYpwWgnLi4ZQutJjGMoNQg3UDMAjqXa8Z+D/YxTX7hx676Xg9xC
PaJ0M2+apkx/eIWHgFvc3zIDZzZYXyGVjhITvId1WgvUAbxRfQYrPQ38cAbEbzgh9RM66izituaL
HFjrX5LoLz7K5xDkNUBEeVbfx9jxEb21LzMzndAz7xFR2prOTjCNp2AvgH+kbstw4ZgX8+T2Z/j9
tNo3mjtcGyRY+FHb1Jak4roQN2n/vH6L7kLTCsUAjSLqMqU9xVxVxEHa1SbC/o8b/OvE32Fw5nwF
ngpoMXxsUfiN2aD2UqKdX8dgkwWKH/4TdnctSJPn4umP57tL3qBstVKq7tOMoVLbWG/W/KrmePvO
nfbpumvv7dDDTqlqmCMmACkkkfhAUGoDHI6tv6TXimxxVxLj7Wd7uG7PhcdiN73YuyreaF1zhPjA
nRNnsO5Pcw8Qse3ImstebhTqhEOrN8iFmk53T+0bWrUrc4DtEjKbeiXROAksxb//GomleW/D44LF
wEUzReKTg6X65WYto4vXC4fAuNW+ei02P3i3o+p/2nAT8/PyqN+830VY3K8aoYi3xlE5rs1wLCZd
E7blRY3obqIU5CJSKAyDiNBNcasawI51HN6oIF+RtOhFRaCvYzzYW4RbrbuYL4/6vL479HVOHSLK
Kq9N2TxXlMevIvmbJtXhfs0DU25NPZF9a58+y4YuvkXKaARODl7xJdHA3A4Vytm1DJDg3oc2pg58
+wXhuQCCPHE184FlbVObAiikSqdjXr3VUbVmtjM6OJO6HN3FQBwSUqufZk+c7R8n+0iI7L2TEI2u
nsb9HKufME67TwbMi1gxto9yBhvHkmA+Pva89vHdGlHsKAxfmbdtZiC6aQnV/PeAPkAYmeaV/V6m
f1o8YFzZ9oWKZ40DNVM1dP2SCM0U3wWaPICAaBBDHJ1/R+qvHp+gFsmn2aKVousmyYodQfSXGqDS
SfNt8ooZmrFCCwEUhGnpSSCj1gIqfOARHbVLv6PSK+J3fzb+oYnZUTOjVcoksQs808YxUTpMioQR
zBghaN/F50/k7HgA/ujxyLD3yMIng93JTsaKEJbLvJx+p29FTYSAZdj5G8BEPD9Phe2eyPt3a0mW
MeD2D2yCFdIceyskn9J6eNkN+iXhV8Iq2UjVeH6vGMOID+QeZ955iFvG+t4l5+vC5wmBPv0D43A8
vzWLVcIF1KeDAi5CWLRfWcFWQeObjTcf3l0sDUv8p1yq0LH1EFehq4I47yCoRTd9Onf3AcDwsa6x
UBuXSzP/vxV5it5qmJVwRbOD9AlkALb/UVJAJpS9HrM+pbk9KyvjC+MBAdENk7eA9B+a9BGwmxiF
WkGXkHR+UDEgyzBSS3AXGn404Ummodh+E5gk387bAnj6LJlwUhpfp38rUIeuxF8L2kjbC9cwpL1t
DApUG4x/1niIZLNvZCSOkgz+qUF9sBW1kdO1sAe02/FoEFIah2oXY78EU7f+spqWo9PvSepwcMBD
MSvF0oyoR2jCus1C22wXTrQ2lASdKRVaTWiAkq8SyQOkiYmL7OiHKz5wVr26Zt44jbGemCorqLqf
zOKmLNrBYGyvBrbXphyAp9tk65/LRYNfaCW/RiWqAba1iSOVRphfLkK+MJKXLH96f7pFg4G90gnf
ePCizPlk5J7SzEBG+9F796xb+NETy9AcjIrTpBSsk3tCKMOHdLFrYKuwymnd6xYlwXhjl2mUOTMV
jXGt9WLG9orD4TcFtFOfEwvIJZQ8H/tnLz366tUsxaGZZpbGtx117WQWT/1fck2WYr/lASF48aag
Yp3R6qyDd3aPB3FJpmR0HuKWXA+Z6PDi4I8/M51GOg92/O637T+7OUBuKKIj59S2JK2sl4etZmSg
bcQy6BREw57dXzrtURkeKwQwcK9sEUpSzVqmUBA7OUVjJby+ZjicHIZq2xxdSGxc6VcEwiyH/2Ry
Y3TaS+DuqVlyoIjEK/Ic16Cg5pIj4UWKdHmmeBP9mnZgrLDT1XjpryzcXfVTAKLDiqldjGpe2XBI
yRraXk+UgzJq2VYbq/CEtKu7Z7DDCamjKZDo6OPrG+JEq2pOODeLuoKzA0u+0ZOQ93f8pEHoTD7Y
186lWSlHy1gOnvIC1S8XPPYvSGB4w94a3qLwLO/YSeGd3Kp5gUbUtWrvirs++7SH+Iow0GZsR5q1
Yz9+8zZrXSICOFw3pis+b+fSYZ8Vf3jSihk9UbvLV0hM9bMeTW9sKNoS7XBHD14HGRu3dmTiXrqh
/DfW5rvpJbHHGk1tgc6eWT/CK1npLE6vDM+21gsObbr/05F4P/hf1nnd4tGY2q+I06YedckI5CCo
4/QWjaZ4nfRaDwrWrKkyK+z6lOUAwSm4TVpauCVRW4TNuEXnnusRVjtNlkk70mpyjj3nJzkFu607
0VT4I1CUx9cEB5noxtHvGiveHesQ1IjD6MDxBdbkl6jMPdO/1vqDHITl/QxbJpgKgt5wjDTcs9sB
DbEBvk9vyrUel6o2RqTECZSw/jw6jtI9tyGEfXyLGcEZVbMPLlaUOGPeL9ykK0lSZaWtEjS7VtER
aZdEVw2Cs2j4mdWrYKOacoONc6m3G42eOVCHFec2fM3teKIP/wbLQ/nD53hcU196NdapXlXwsl2n
+hiZlgkmNumsobydnp/RbFLfL4htgX0qY63jFmy5dem4u+G3xo8PPTO+eThq3ulO/DF1gaLgGjT8
wiYTKusUU1Fz+GenuttNUYbUn5k+vXX6YKUIguo+avkvlfxriNWqyb9IM3jcLUiQBzIYDHrNryk9
lN4FcWttHgl00fXE4yyeypjmbrB8VJN28BZJKDXILzVDg8MIbMsCvjUd8f1Nsl+VUlDmK3EsDNiB
PG4VNHq/BdgSiPaxi/mHW5Iit8RW4xjdAtFYXU6Uc5qIlOeeMRbypuZA7/VPba4fXj0ashdkTgKl
VZfhWQYxzijhNL4ebvrd6MoyeiBXosux67Ru2chS9QfZzt4fxTiURx4f67h8urqtozBjZt3shYjp
TK4XD/VLa6cGmpS2w1x5mEB2vMZUQ2IObl0+UlKneygrt1E6jnNhoyH6s4jw+ubft+onPhQ2YcfS
va4M/I8R6eH96vgXYMqHJ9qrkg0b2iLib4RMqsEbavQKvv96t87PELUcFirTq9FciSvKGLwCc+HB
a0kVlsbfpzBRpyr+UnOlJ6EDKXR/Ur09Qf9OtMAw7yYrGi2HHXmgHzCVBwc9ssV1dXhyKO/nZnpz
66tc4YZ8vCOtXfL6S9d1jcApc59Q5x8KV/zG/YY1VGh/ejoBCVQr14Erv8lQcOhDv5QDN0rkNhUG
o7daEStjcz/W3e9ERE2EAke50SL+VuLY9y1PExJrpKm0nFjmQ+DSHXgrDwOfazaJ+reqXgdOk8fx
kFYPIoZ37nrRU8Q48oEgw46yjveTQUJTu8A1UESf/+4JnpwyC78fBDhAU+X02pq8nB10yZJHYcMt
VkoJn3Vn3KOSa/zSB+A9yZ8jEgj6WUXcDW8ZiA9dmMj3oiVOdyRgOloREUiVufNo/engqw2HCGFo
aiYK0jDRLXbtraD/wwjM1pKqMRc8DA11M969odwWIzaIC6xdjfUZQKXBZtqXyFKAaJl3stvWTs1G
UydaBoOUMLeFZgvSL8rrg3yHQIvNNMt7OALWk+yuutdqgL8Bqsx22VVVgEwKLenSR++bTxk/QYYt
CfpMhS34CNPMKZ4lWbxbgOcGa1CzaYxQmeieGVF8wsBbXiIZaUQmy8qL1GDs7hPTHDYVm+Vqd8Zh
bcDAWBbeMA8PX/Gfkcjw2FAIpjwGDspxYzpU0p5ss8SuqH6G1mCocfcadjcW4GiO6FPx6IUZ6Nq6
uGK+c0bthqdst+mdDMq6ytVLBu/Jnt6FypDuOlsO9wJzHtl/2hI8yWikz2j0IfEolUlXJA1wYP+Y
GIK9k/3aFUBOha2Cg8YMX61EZDfbgk7rAWTKPrflyaLYjCKLdu+UVSy3beYfBuakuV1MhHqiBmMX
zPxkdMcvJj50x6zvrsSa16kfpLA4N//WIv/xHjJt2o3aVZE01ZjVkMRLvh8TJKS7ntVUxlXM5nEU
1gjorrg34NsSbNJFbwapq825nPN5EPi5ubMBfdesLEIJmkfMouIq+XdMYLeGRJ4jHD4C7x3n3n/u
KwPEx9mp1zR0jKU9cGeSuVos7R3fhBlZBln0wPbybcOLHcFjRde48wP8BYkedsUDvTPaY5dtQBMY
sYYIYWlAFvPC5RskvVq0/NszDN5a0k1Sq//aLBFdk6NTESS7g5z2xwFK6y2itlTmP9jsEuWqrBju
yCYfhpAJkNphkgh0NIXLXGEwztNsk3N+aVlT9gEnjm+ERQMndZfdf+gYhLBS3e8nGOJeM/GDjWIt
vXTL1qD/J8nI1AQdnl2vFpLwUdb0xjTvwfmTSUMc/j0rSU/6bgOCJxZPyDSa+T3uQj2r1eMSHlQJ
yvlucxdBgAd9CyKB4Yy0Xq5kmn8sawgxDeSe0YMjq8K3TsbMVr1f+FIlpf7aRHTWexkjK/Q/27jq
1nOvj50wqszzOFMxm/iBAUFDQKZVQhl45rtVldZSajzCHih15Rfuh/mIvlusOipXOJZ/bW4ILJBM
vhZoKo93bPCkKj4OBG8SlfpZBXCWuQGVrJyCsXhJwyZp0IbxX/+hVeptTijxNjjC+t164RLxdCH4
pYKGZBJSQhjYBc6cW8CQdYVBVfcgzL59cmff1MJXh245abZYsHOJXYRsX3+pTxFYpOfEHQvs7lyp
spi2e34UoXwXOMMegdIX5DhdceGx+ivso+Dt/ympgDZqeSRAwyEiva42wnIaqtVKQ605Yavg4oW5
cIFljwjPxiy+N9x7Nswi4KJ++iTYDJrorshOAAN4M59H5Se0iaylO7J0hxWu68Aekg7jUvzkAOYf
4/e7EujOoQcKh/GtlvkFALYh5FbwiNtWIt2yrLDHTTzZGm/HOZBld7IXY9ihrYzwOm2PV/UXJdj7
pngX1r2Veqc5Yv/aE0Fv7cf70JQ7Xc9YFou8Ql5cwTl12djbkNSBTjV4BqaEc/iY82qXXmSCBbow
aHUMJ2VkDyojBQJya54BZi8v8A2VmHqY2N1tKBajkrk/fLgyhzaN2rkK85CVIdXPE57ruWArDm7H
O5yutpq0oys2VGLDVeIaxiaitNmnu15Bq+UbNmGlZuANnmdoAjBHvVZvuNQ2697abqKuUJaT8AgG
V+M5nuy6b9XjOHFEDjYoiV+t/iGCZchOL5m6Z2FWSfg5SW4xYNhiAQEU0vyn6e37nLjBDu5ATVB+
l/7q47VJp9WrwI2sragWSe26skOPJFhhRf0v7pWt2nacKIhJx4c1NreGSXxW7RXzxuFnb7BCwocw
R3t/hjD9ZVOKXxOcswLcAcZCpvBoAizeUk0R29QEDxB9iJ4FKDp2bhC9yPNEc6i7g6JLYFioxpSt
drdo4EAkt0hTYZCTaYCRvVByt/jn2vhe9qyHZmIE7eyD+9LmRTg1YQcx4tAYZU0+xCa1XJPzN4n/
4evQpcT+QprEs/i33D43ei2fvyc/vlef04x4onuC+JM4xt8W0RtQhGrSKWGqlQrTpJ59GLM6EtOA
+sY6Hqc7XEh4L+5dB5Y4hICW+01IK/5rKhqpoNaPnHaIG3hYn12K6DTQQwAVlpftrV3Bao/PnjpV
h+Br/mfXPfWeHJr5FchoH//sWmLCBgSw4C2799BVN//2+Ns9g9RyGmFV/3J2j6JcjK0QtkZNdkm0
agjtDEP/uQZZjk3FEhM6AXtwSWzmM2sSwtHRTfC07j/Zi7SYGpZGTN/tI1s2mCDe2OpJQYQlq5vc
E8ic8ewYm3UpNqRFWrAHY13H14tNPRrLklQix3NzP5mIPQVKzHLxGe9B8BDaLU9jDsk/tgDk9mks
PBKXjyWCE2sQwUxtv6UC2ZD9HmdRd0tx7aqh4S4RRVnHUEcGqNHftKd1prF+U5e7fGg/zcxyJ/UH
xA+74FKhV885nU1C+IUnWQXxGsJz7wTOwWOar0i0OxmOOS12380mrvPmdCk5a3824G6i/sNE0GVz
xE9h/nYbFJ4Cn5KjMc2fnk/chcBxzjzqYCQZ7u1o+12jRhDQZkXW4DVVsv9LCdeW3QIaIjU/J71G
Uhnu4Ftx0cBOzRJHpFEcQDLnmTEMM5BQrS5VdhJg5X/MPxnLEM/b1ohmKNbJG0X0ZilSU/hPWjBT
wdfb7KhAWzaY6nZY2si3/E1IN1kc3c54YnZ8QGf9BCFDbfx9P3q+mKoV7nL8O46ILeMVx4d0X+4d
vMH2Y8TJlDwspdNkSlXEjD0x6RV12vPFTAmlaWkNAg0cW6u0OTWoKO6ZwSq760fps4dpXrEHK61y
PGnxLaRVMX7a8BCSNPVU85P6YrsTxylgXZaOp89h9aV/2OHDDI05zg+KJl9cv9nV3QiVHyT+SFF6
kUhEB6ZFRkr13er8naRakXY/iFHOdBLWKAG8Jb7VxCqlAC1E+kujVg2qmVKK9BcEeFVtbAkKbkRn
BgCq+xqRMqGTLL0ePax5D7RmWtzKxIHdtRTPGPjEGzI1n0OfhyHSkmToUqLBsK7S30yUO68wQ7L9
Wsrdn5z+gAS1UroMKq7v8v6UTqgdC41pJrxPw17zB0O+BnfAWOKVawcECK9hHoFlj0c9HFWGU+yo
4FkfLNf4OVH+H89LwkYs19f74vhfyAK2207OcWs3XthRmpWrP9ZiRxh+2v4zNUa2pLkpnJYES6YC
iuc3LYp4PXuvu1QNVm/t+3gUXFNGfZwjbLX+8eTRDvgazY/oFpeWInJox1Q2dgI9Z9PYAZwY8HID
XDgqgbwhv8l7qkwvaXlvpisnzYIt+7S0GhO4AJCrr+c/jrLt/bzNxjgj1GUIRhRXGzy2WmCBd7Di
G8fBS9FU2PRuibr3scKmytSdwWCtktWFs/B+doFn/9YybZjI1vUMp4i3AMVqaJqHLqhrucl8lrwD
D/m2WeDXW2Rfkh0ZD0o+KRZgIhtwP9FN1RBDTF8fCmS2jXU4vFXBusyBxq4ov73MXtjpdU3pyIxg
ePJF7vP4nVkCOsEAlB8DONbppibhsYDGs7vtENhNkPDymB9Vrz9T//i1c5c5O4A3rbJteY5X3Dcy
/WM4u6khPq4TZKl6ijC6SLZJ6hs4QPQIx0e4W5T6iLyQt8P474zx64NRtPEbnNGbeq3UfHJQ3lL/
nAABEDRnI7mK86jTwWvhxUZGRjzm3zl9MmsTAlJYhmVxmqb7/UijddkqxE5dYytVRB/ozac8R8Ug
6QWYA+5xks51avWHy+8mppjk2CUQ3gLYu4tmBJSMV3NCROdadU4cMhdJ30cgHcViixDk7szfCZ2O
UC2Iz6H+ak8KoMeTap87UFpOqtNBalofHcAPW5tlPUq0DiQP537dkWi+MPeJrvWf8pc8qx8QKrIe
3E/oAk1PzRwsctAqbp17/TUP8JHHbY0qLbF8OYVhaPuY4BMv6up8dkXmAGVKEBV0Z+Ti3pvgm7aJ
Wqaup2HmAe+6rsODeyWsloGxx3dfN3VohkpGEu4dWMXv/xQha9LpecnNju844AJmeMLe3wxzPw7M
HDZGixZkzmIiibW6qvC50ZVBOYANC9IJmIDFfVYleIJ39AI+izbGObXUZflKd1xnr20n3JvOt5OZ
9dvDEaoVJzPy6lK4t4UcwlmpFbRfafqYIhugsKUbwUnMpPHI6Go1nMfiFLqpWpMjbo32n7c4rgfx
0PsSyoYjRqvWEBlJJWxv0NRMQfqYQutlsHWtqFMI77zdLr8EOoiZNJdNVOqWWJNlvfuh5V67nhuY
RT79jPE9FeQZOqQBtDsIPJJhh/KBwpW72wcFC0mDtI6BP1o32w3AjAV37HqF64nLAOqjmWQTqzJG
Iq/MGwGMZKiVsWTMHMTHaua0DYdWkyBSrDzXYeYaG5xTKdjbIpLYxkkoCRo7sxXnxFqhi4CwEoTc
n2xNplywGGULbTn8tZATyMWYrRB5blLRD9N58jZ++iInTne00DCgxtRAiNE2st937JHSf8Zb2ax9
IwQ0rgO4mYJUU2uVrf7bZjgzOLPpbWLZt23S/Nqv2vdmsL4MJVdHBGUCtCFptveF6LLoKc0gVHkJ
lgIcSsPy6JhSYXdDVMtlUs+x7Z0fRj55FqoH2cqlk5mXIld4pWhLZ8tFvTes3lBB5xSPbz68L3Qg
zbYVCL1lHtftBYPCALDYYk84qB7RtwSrNY21ExD45kipQYyIQiWkT0cZZLICdVg/r6pV3nKESWuE
tyxWKcioQp4+pc5b6kzeyDi2YM1maE+R1jTyqbYhICJ5LLoQJFq4QWbJLbN+BbqqcO68y/KviCKA
Iw863YQmHvIBZoxIn20MRjc+L+ToFjyzjYVDmCCTw0fMcMdUlQvGwspH8gmcf5/D7m9+wXeOOiWx
X5KR01IpfjRIbLMGzvE3ct8qRpMknhB9OdkEO36cqfgLqvAtsaWk/cAnR7KUy6HcB9IYE0xdBO0i
JXdOnJEX+YK07nMdmhIrLCjRhgYQm/Q3ad0V/rM7QSvsJK5UNquUP+CNj6t9b347poV498nLRpLO
L/Cqm+BCHYZpUNBZIAz76olC4x2B1kj688zMaixbysOYvSG0BaDUMVPysvOjxHR+3cKet1a1pI0L
VCxkgIwCOYMO54Uw7llYAV4HxKf4O+OpLzyiJgUhM5r97ycHx9Y7XDBe9Na68147Y72DQ1nR643w
oLhpSf6IiX16eWnLaNJV8MImEOswE7ZnzBqtptkuLURiBofF/Y1lRYseSN4wcls5YsWkzLV6NHW8
ZYym5urLPEAJNuetv/vdj9qGi4Doazsvrp7JDoVz+/smAfLhPgfluZJ8p9XoE3IIIUzWO0ycAJuw
GrOMtXrDonbfaWwNN1YqKA5Xn9YxaGZYY1JAWYc8pPvCLBAgC9Lhq1SJs4T+ruDUxTq8l8I8Xqnn
t68RLS0adV3cs75bgTntXdXb5z+EkqHkGw9H4H4mBMoFP2MG+qe86q49qaOQvMQLEM8wgHlcHwIy
DHczcjXoAa+wUkTHEQjQyqvs/2dFt79xCTaJfB3skcCjwObDUWDC8ZJB9M9qlGy5XpNuMQbpDUaU
4vwSpNZyTv2e4zIdu6TUOm9gheoNV7i8c8f48gyx1IfopV18/Bog+5GsHwWg5ET9tt2PfoNwNH36
kxPlXQXU/oC1OMJvN4KPdlWrqDpC+ctc7+fqby/052TgqLQ1LJHd56NS6Nz9kfmF89DsPDpWe/vC
8yQXWB8vUfGOJXFJZkL0wRSpjwe8uS8WWBsSG6h9tojNE97FNiIPpZWpFJeaR7ndcdebumRDCT/b
ysCRPOPshWW4oY4hFGt2tGPlkuEHGtLdYaQS9yTSeQumvZgqj2P2PkGEBclbIWCe2Lx3/ckH8z6U
2ZUGNTE1d6HE63O0hRFYQmKfeDr0EF/y3GI212lxT67C5b8I5BAyQtSNqqroivnM8noeL+H2ihI6
BJNf6HYH/l4oJiDeSgsoaid+56DM7c3sJucLT0OGfZ5U1s7/bEov28CTWDz1tBwh1X3tMDLBRB35
fu9nISs+6OqSzbCU8zuHcnSlx592CRR4kjdbbU4V0w9W0FspSf+TA9+tOTe/oWVLMmnx5A/e1Dd+
4GtyJMkFtpIcBYymEhIWplsMGabP98NFWA+pCrBREnaso77BKLAM8nVW65p9P5WnwLaT9LQHV9gU
YcXOhKUgeBxJiRxGhr4Ugbfkt3Y0ZWjlQCSdKXmfvVGjQW1O+bdaOC8PtD2xU3xc6327U0EMx9tT
zbd30EaCXIeGeIjmM7ylOTsIsngBaopamvLS/JB+quTfWlZA2Y4nk1HAgWOZYhbf2fozD8sMcQcG
Y75uUmRMO/+DdyuQHLlKYg3hzIktpO9vgEd0ypCkNA36Y6RRzb+0/tOka0ziiRcff8DQoTx3Lxex
Fq3P3hc3UFZ15y3hdpznMjLJ/t/odcy39DS9ij5blql8SQOYvQwmv7VY4pKq9kZyEqJTGb1udl24
pRW0pTmo3NLrV57Cw1qLScuHSD5BpZVunp9ySZkHrNizaU355QxlIxbePBExpFpXMiM/mwvXWLf1
sDfXnCutAsBB3VKhCN4AgF2f7oPeB7KHZ4ftwCpYiQI7THAoAZawgjMC0Sxxjqz63Na9+R0frOpG
OAsJ/wcZj2TGnxN69qAM1768te4IV4q5yumVBtIqSV6ksSYXtxdN4nl74vUgtC1/tVQsVIfWuxuU
TBpfYw09AKzlDBV8dyGr8hfMPvpPdZF7LPKLxIXA5YptFqX+ogwqmQpVRRYFsEiUMRSWniLBJdB3
CvEvmOCLOIk5ApeTydEsniv5H61997YlahtvufMRUgZ4MQ3AkT/A2P1sfWCZgeZswTTdrk3zpxsA
rggVVoZ+S67aphaAOyzfL59wePtjOI/fy7QiAePqZaQE1GV6Z62iAvtkXUUEiLuascOQhG+eq7xw
dxjMKqTO0W/hDGXPhflwAnRvc4tNZn7KGKpiwiroMJIiayZmenlLYzfJ81qeNeZFSn2dZ+/M6IIj
+iGAFizidwGALe6JNEc+VS664//daB7tvPNa6aslCk44aK9LgBWsN17IEnBHOq//1cJpyVIszh6z
FQW1PSjzf/zHwsYBvGdkBT8fvD0fShicMih14xDOIA1Vev0O1FznLlzhRebwzwLFBuklboBZNK99
IbeHAqqlvEBgABLTnxiawW+2DhTgN+y4g7QhxG9diatcgEwg30EtvXp4r2UFmuiMH28aQGjBUT1E
JntVdt9jz9K1TmGeMddWXUsexKzhA6rTl9I8NWsDytS9+Ed1MrLjv0uqeKAkRdmnrL/vyJTt8yy/
vaV+E61PvfJmu6uMK8BcEM3nfwTwMuY18ML4pmuR5J1xk79JVZ33ZE0++bBAFU05/vsLQ9koEgId
zQC6bAFlZPbaWn75sGnP4v7hz6BniEz/sFhbQQqlhIHUxuE0cTbyb4ijHgqJi8jDU8/Z7tPThJqH
Q3vAeLKDcwSb5PwcAueubFHoheqVIWo7yLM/PAg5E/iZODyAR07+/FuEZoqkV8qz4BIM7d5bEzMU
H0NtsjklC4EyoXYbakbTA0k/JktTDmL/NNtpJIIrPiNb43Z/a1HONU9NkPF+lkLyGvka7r9VBdjH
rRJJODdIHVtdo+BH+SKqdh+MqYC2JmxwsM6cpEyhd2VuT5PNh6YPIhhoJZVyzp5C4gdmMu0A+MyZ
bfhAjEpNDyoUMSZfX1rE2x6Mirh/V95sBHRUbhZR5HeTpZD5elX9bsEMAAS6xHy7rpCB5IBQzop4
FrXRhWjG3MPHsocYjScgHedtVcxNH+G0mZ+vsv4iaVfKQZBUi4jiWGZWTuaRrwly8TpgrMhsWHOr
W7m5iWBg3TZEePRmbsSzvn4jpJS70gcm94Q3hM8KcfUdzS/wMGf3n5GtJ9pLSp4r539j966hBu5l
/LFOiCmlQaUExNrYONRS6ntt7xl6SB3HVayU9EFZQlojDy0Z9yospnjTM93uinVRDiVSOx9z6n8B
Cf52UBPaNC+luNUJGUXoaO4gQfX2IELgQLmAL3qSQwT++JL1FkWf9RYjRqa0QB+O8f4SbRBQr9zZ
YHI/eiad3lIQFT7Fer6TB2J+NlzyQc/Q3h5d/wywYDLICHY4Cq1iXrjYRFIYc9sfMK1Wspd8HD28
4x/tujwVusJWKmc+clZSh0nAuVLpceg2Vre6qEipoKaZ5b5vDB3wZIYUmXFimC0G8GwgaMQfdTlQ
s+EMIU4KgxwRNuIFQCJnGATGZre1VZR/WbPBRUx1uTDmmD9fQFnqO+1h3rW4vJciKRaXUd8rFewK
j0AY/JNPwe0zD0FakqyxAYPTQifaL4FHqGBPXdo7DqF4hH69gYjWJ+MxE45nJ5NYxDCi1csjKlV4
Rdd0mqksRkFb9LDtmf5KKuRMz0b5T0zm/r76dPH/jR4cYBt6wPLU2ZNy8sPput/aPy0JkuJTrTAn
FTgkU+zvxjzuNMQpUBsxjqLXrO2OBgYkbG1DAFI31/2UHe12OLF7yC+SrkX7JfOFZ1BuvL86wY1P
ujD0cz/fu2U5HhNF/4ANEMqcdHc+vTzJZ7LI4YBXe0t7SRcYZfWxUix+w2PrYww2IJrFbMIR9uFg
V9y2IheuO/1kAFAPJrObhVqduo4xx2borzwxuwGq14WeoVlu3Ef7m09zbV3DqxIqYXPnP7PdOrrf
nnQwPglMR114bUuJHiKFe/i2qpXrkpLdkPdSRT4LKz9I3Al6J+9XQEL2ZMsQcD3T/Y7XLMPlseR7
IZxU+DjHyhLOLKVmDmFXUkSNJn2/OJ1h7UU2kT1H9k5aP+tiIrzMe2G9uv9mOogAhFLWlvJXNNfT
m99+UAc6XS5HtE2OutI06Y2ajuOq3QOLamiV9IAwxT6p7k9ndHN++5/0w1BSWQfKOIRvXd9wZxl0
zirxKI4J+3kjdV8HSdCDt3kDclGLeGdXHdLTPGqrMXt2npqAncfQl8VR3DSIwHQ4XoQm5cMXN0fa
bFnYpXtM8d7sd5gg2x3l7JbzGkY6Mzs5FTjlO6EK3Hok7eYqkjUF5d5j3Gv1ozxEosnwj7E3j7OH
UCwaaKl/ZJznQpiH/PRM2wDJpmsIpOqZ83CbH/y31441N1LBmtR/QqafCIhtpwFRxwcndHLb4fs4
+RSX905YvC7jZYlUW4ac3Pt8I9t/FgbZ0oMJVbrQXdS98kIm3TianNm9GV2VKmtAk7qzKRWdmP8u
DrW5akTQ9ZOvZFVJGc4MFsyp5bRnr0xt6Y6vNkyr/d/iCTeR9lebB8y+byA1NN+g6h9pEku/X7Fr
XiXk+BCAxgxvzuGsoVdBBKXmEmxl+rycf1w96ntAVFMOhid7gXmULicbKVBk9bQ5BTsOHFDO4W9N
6outdASh5jkPRn4PNpMKkxzRMzw/K46Tb1lD4uPLtW4L5ZsMWwC5PhWUq+muiryVYpqjBN1bCaiR
+KII5EtdURd3Ik5egE9pkWz5lhAeEEANND2Bdf/TRS4jfjY1xVJ1Rzhl35oIisK2kLI6EqxQsJhK
odVlR0EO9T6tOpUu1PUfk61U5aTTPA9+vAzpEocZQ8cJYc0VSfhiFSN13ohnXnji9Y0IAQ/ONkyh
xuMopNxXKUM6DCvDrNFR393493ZecFAuPGe0rhwzj14zPgfDLh6VUv64Hzm2/vEpRhgs3IlCSmXy
9kwyp+x07wz2GTIcOlBP+l55/KfYef1YB5r+tUzbQsRUc0pWq8k1lxOvkjXzPn/H6vQZyAoX5qs3
fuUTUuv/sMjwvR0VNVFueewPAoQsR9lYH0N4GMRUpp/wtrgfdyYENwIl7x/acoCsJJdBsMJeQbRM
5ce5mvu4f7POghbOGzmTSIS4owfHdYGo0neqpL9ksqG0He0s8P4sPSc+fDCxuB5RqyMydwN3yU7A
lN1QQla7EXBARijOWU62ORXUh911YUvPvlFvzmoKZ/KCOPg6mLi8Jy6x8Pqh3U8c4Elip1y/Wr/9
HV9fc8x1k+6lwQA/fpcxt07j4NAxKIIUVRBq/BeKPK52bt1ggJ79Ml0OINpv8XwwijCDYH04/bsg
TRjUO6aXc9qSIWtgd4ncGmlRmOIGY6eMeWLKOdR+Fsg0Fy0g/LEseWLFbTO+cZk1eAgboIXVsPzp
3WIs5MdS7l+CmHA8gg99kqfo64dtQZZt4WvFy0NcaEHtvNc5OvA99tBnogLKcX/wdPFZ4+eRy8Bi
B0icOwoHs4wkBku5259NQaquN4lUT+FeEVk7zFqRgIEXtxmpc5b41v/1EuntX18lcE1V3ewLWjVU
HZxHkfESYXEjoGCBRCS82l9CGNGrQ7q9sHbx0bAgWMYxSFnQsGJfuvS6hFFa8mZ/QvCDhOtNPyqE
2HS4fkkFhWj+POziqqAb3DjLSmqRhibttcsSLIKzo8snzYWLDn8qIEHeFRjRvOG9/peptbSJ5nMx
1TLJIbzYFXlkZnXVMLUfcz/hal4upaYTwTVY7zEN0DvTe+OL/mCZ7X/59IFZKR3o4vagG4OQYLyC
DyiAm6tO8b79VIP4h7LreiT7D64CqR/dLUSwuhUoM7vtH0/r5zVWbpQOYB2msEoHTsEURw0GMB5t
awiaLkj9tWnTJb9NU4a2mqeZ2pZ53cCMMoy3A5gsMWDo4+elJ68efg+V3HzXjmcCrkt4USmrKJaJ
kYZcl2t/pglXcC/rECyBtiJ6WE6fA7+MzBCts0OGBc5Mb/nwGVXf5/bY81EYZoNO1QW0lDc8Qctu
O5xM1Rxw+xnkS5Polf+J+z/aY+Q67ZDJcuGvgX3jEMXeAVV8XjZahuDIoOWuwfUSRzyrGZ4swTUh
ZXiBU9cHeI1I0wQrjZ1odHnHcC07BMKfJp6BMg5kdPV6DTO7sivMCo001NTdsXxnRCwmTqamuAEC
50ufqYf+MsWj97CBcAi24IHouRFFKylhNFDQOqlTrusqBe0f7gQ6aH7KE4ZECPPPuvuZJVzvYtMW
b/AvBy7T4PnjEsrhb8M/nz3E/eYWX8CMpc1rpe7FENY30I6haJX9iJgkPDXqmein3Vzp/9FHfPWi
p8fUk1cD5OY93iE6eX1rYWybtjrSA+5Aoj1D2Vd10v5cZHKHD18ZzV05FZFuOEYUtrtb58NF2bMh
iPOA7eo1RFv+bk0hM2kRStP0b9kd5ug3RIKoWkdB4qrRdkL+1GTapoFU1Vz4wjiI+feZw7/MEdCH
ymLj/SUf8VuV+BJOGwVfK1MVc2b3qEe2V9nX0dNefWnn1AR8Nr5XdwRnxzPVq0q5j2RjpzUR7eH7
i7Uw0u53q+h58qSTD44pfQYyCbmqoSb7M+fcySw+P9CFtsZ++MdwpfPkdcLTxJd0VaWQhUFs9Jv5
WtTMDhIzHGnhQrQfiIr0KAyU79dWUJaTGicOyPTw9hX0jZ9HZVPTNNfqA9rbldFpG+sjGt70Ybwr
/3FVOPYwnxs2ZvAiok6wnr+zsC1SFMt7sDUZjh4xehHCMgbN5/x0Skq056bfjOBR1ToIR5M21OYj
JnubSVAMA0bu0Ck5rUOVOOnGjc7gtvJhBrJzQO0sInOF1SxIH+sRi59kB0tfGw4ONQ/6+T7mHwk/
h/fsSzvS0rv7HMZpTfzy5fkbEYUUl/hAme6rEtF1cRc4YZ19G6ynVIb5AXlYCYyB+qfoGExx+dAV
yJ5dgWec9O8kxfvTZiJ+m+NueGbn+gyE3zcpW3OigKeeNFgOPnrOAi9YPq2+YD77g1Dl6rXDhPFU
w5IVKNSaIosriZwa+PoM1SPsAgnVX+FMibxkbWrjX292f/7nVBQAOSN6n/K6GwnqQ95JPZNxqLgQ
ahXu2obp/J/i9+Ep9LvQ160qWQiW1NfIu/ZLE8KRrjPfkQonhL31udmKRTT1gqPnvGN/cySMtPlZ
APCwQwp9+7lQwAJwkf7seuXEPXnaneSP55YukmCIpUo/gIZnDsb9tx6Ey+VGtgNkZFkkmjpide1F
yGo/BBW5nSuHwNtQsKK9u+rizumvsUC9TJXFS1kaTHDWB4rs90MnpC9FNYIUFNfPT8J2LdTrblMI
gJ0tVeqn/rGT+UCSRvHWfMasCrr2uPXMnd6BCrWj2/W0Hbgyq8tEFWhPBN18lspBV2RWvaoWolaD
gP30SWPDIT6nH5ZmF/aNbl9WUHRcrNmqE5s0qfgg7Fq03c8VwjsJNAhTb0SAsGElGJ+1kTjSVdfj
Ghd0tLC/CI7N1g2g381NNj//3/yN0/yVrkZ8Cf6Nx9W42PLAhdlDI85kP/s49DCAASFPSiGGHDVt
Pqedzy74TQfVXM7glKMLlB49ovBNVz7oNou212276QeLWKDd6TQPe16JKVUELgmqsakhwmqujNGx
jdkIjguvow8w2ewPTnR+6+HK01K/vmCtCibEo0M6235szQ1fKR9iNlAKfJWZ9ntyoCwpmozu8AmJ
gcqq4GL4Rl/9gWsr9YdOwIXrNTCFDduoCvE+2DTgRQCI+oCQmT6V6E2nE9sOdrTVaWXcLHz/Z3Ps
VMBYQusBvE6WgnzlmrSkoAUPoT14kgOIgR1WjGpmBNtY4LO0Az38EL41hn1NltXw7O0a5f3ChSY0
t1gwVYjoG4A2ULsq5BQCc7k4pI3emTXoWwqJCzvLA05LqMo8TKaPkTfh7pfY3EeEhFU8cJ4OU15y
zJfdvMMhG0zLspGxqKdi5dgu+VnWVFSaxp0UX1D9Zc6H4RlFLyxYEXa/Doh2lU0zmMAkyaa754Tu
Ctw1kB2ZGr8Ro5DRlmfhaCXKYPZpoNTI9oSOWKKcYD8SlGM3ouSc2UOuNC1RHsB/KczJ4/yKS/JO
1UeUliGXd4MV1dr6Vxvu9bKq0PirutMEzZ/c/90jLbdv1IISqnhoHFBvMSZsyGtMTS3KRJD3ze3R
QVbOPs688PzGd7b83MQLAf1Nhbrxfw6AwJAaGMOLARs7G6UmajLDH3Eq7qUsiTNbsm0/LLqUxhUY
dph0gYJn09SUKI85OSufVExIq6Vx5WNDT5kJJ4jaQaFgEGJKyvM5dAYtaiwF2xKzIfsjdha8IiY9
kvgxz9lMchPMliovzBkwecK1P4bprXMVPmZFqtfukNfY9EnNyVp86qESpJqg1uJCxAzNmf+Ul4qG
TMx57RMVJH9cy7GIB5JUvbThztAICpqUPSjg0CWfwzL7b6J9MPlo5IxkTy7HA2CS7B+2dndldKS/
EsHsXh5W9MWPBqWCCldlCB+EyQP1GFf+fVbOcGBScv9dHzLo8Ups8YWHFP/u935wsnBa5U9gAFD0
3GbrQV/aE9yDErTw+A56zsYReJPu6nyR4JVhFXXMUj+hASnqg9XqyknnlQcY6mtEttDzeZSozmcw
186r6HDy2S567cK5MLw5UbU9VDIUMTuAlMD43J19uHAAPxgehY6mQAd2BqQbb2Vjki9MG61p59h/
yNPvwxNrT64qYQZvZhBysWRmlItdKXZVfsqcpwxmuZAnyXBzJB0rXPHMdAl9+IoWa2I0zJDgV8IF
HOrNMT1HLZhZ946AGYu2M0C4Dbl2oPR0d+GJhpSoS96N3PjJCoKV7O7HZVgSgsE4m6ZLz53ITYd5
9ianhEwsk7GamIB2yj0Y6z5tLPu4ZGZfwPUk923MfMC9XC2GaHFohfhj90TEWiVqTNPTPMxAZ9Pz
9y8M+0JwPb2hnkT5EyG7VRnPAM3i/g4UrAiqXESfbJqgd2qN9gpyb/vkvwy6ZD7hmYzDTHddEG4q
luu3WB/R5l64hsVltnffNuLbcnGKJg5Q4yhNDJ4rTcfhj6Ff7XP8NxflIOYzCLr7BVXkhOcNONgb
EOkLnSnpXFC8SFom1cgKh9P3vhYk/W4iZ2V+NIg4KzzPAHDVM2S5/nXSbt/THOM5mvRho6+s0kRg
u+VDReCj3v8LIgy6WTflM+k7sGjHQuAlzDLpAgBpH0iltZzo2kUxbpgduDLH8w69NczCcAvmPcD3
Gej3l1EtzXF//n71jkRcgYLSj2tUxaJon6w53f58MvbPzuB84N7e8jRd+PQXROD2fibnnHGVAf3x
4B9YMB59vya4pJ/fuD2XbTtIVBojM0Ut2uoRIqz8hLkHPoV3eT4aD+jX1ZFD9GcmJ4r9fi/JnEEH
WvF9SKiCXzYUA20T2HvtGHDduzo0oxPqKZ4FZOUzNH0B2KOgB4q/2SVIqyeL6v/Chut+r4oy6C3B
CkEe8kCc75JIw3ZB8IL3HS8K2BICBy76lgNmJryHPoOjFHSwI+cZk31poMOdWnjvb2CItpzBAGGj
Dfq5N/L691h6PN5y4pAZHet+jX178X1BSAVGvpE/ZyuUI5505MFy+GY6u4pLTBcxKoMCeiI/4aXu
qPP3mGixcUVX6xjY2d8Iq+QA4CQ0odrvujDhsBiCCj5BJMFiVR/ppeSRvtkFcPN5MhWh0R7GBDbP
EfbN3rvkoH1Bwk5xomIbDi6Mv6qWMH6zx/r0jm==