<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw1hsuNKwp+geRTEfg2XvP1JOQNeXP0uoPQugfrjyN1qucTSCxoVLAItk28P93Vr4UzEHfRF
VUaDTNoGQHusb49s7ugJ05uLpfdJjd9yJ1oki6UeHfo8MUTzma4K+I6btJ4jvfFxG4pZXpLuU3Nc
dTf8puVvNLCU80CoQVif5Q8HEtjFe+Q6tCaMki+gCiuTxYJU6cA2AL0GIpNQboWptBiq+z3/+tn2
S70UkKE78SSP7cuFPoIbOBrIyza/UE4V2lvJzsowS4aVoh7rC/Az7i6yuCLfN3x1r9teILYtv+z2
UNHQYwCsQbVVngkGzZ8NuEsFvfvREsfDE+sRc9KXrcR8H73YngsBuaN3AutXb4N/4EEIgenYNXbj
6JX3fP3ng6QeB8jF6Dz7JieAjb9frwVD/fMiBOp545AH+P2/Yu8eq2bCW84J6JacvgRxeOdmvByB
5DLeJWH+amlAfgRy74D/xXe+0M3k16FCuE7aJSsQrnPpGpJlVzmKZmi5JwCzHcJymQZi1ojzGnxw
R0nmechK17fr1YCao4y0TzLMZ8Ux097B0/vNQQWR4IituQQxq6px91M2t6yLrEZuQbPGg2Kz6Vff
kuCBQz/ZGCX1t0PjfQw1HYry1q/3Y+3rTOl/x/fVhWx3nYe4PeZbBehFApUIkjEuQZfTKmn8/eIj
QKMGna1FSQK8Wm5sXDx8xJ2DOWVuwax7Z4pZPTPehHqQi5ETn4b7FX54YvSDmjnUkUT5FsSGWqA0
8Prap2FCyswrq/3TEAaoWyFQMcRj78htAVuvRcqPTASfIkrqjPfw/pRQXHblm0u/DKAJ9EI5n4ex
NxgFacn8ulJLEnG+Elr5g5mN+6/RR3lwLaBHfRenvcvQp22kzfvK6vZ/55lws0/fG/raYrZd5qHu
UYZesFEE6QBPnlUJvVsS/VxgEeJIE9gKgBdpfEWMR2oSZ+xH3ialTlSmxp7rOoN7UpQxrU+InTTD
M4OK41muMt7B+ukR2rw2gOekIBrujb1lpGEzKG5da/ciHzBE5bxcjhznLhVI9U2i6VvHjyTKfHb7
vXBZWlN6map5iKfTsyHyIv22wmOkIJ2mgvJD99sdj+9Pkbh8eYkYZwp0Fwf6GSXFxflUYyKnNrxs
CJqWHTP06V+Egfx7ox6KHJsW25BXTnguCp8nmMLjS5ubgyuqk8w8/OtOuKUmpn+B/gfkTR/7qpB5
to6Hgh+VIc7YKQCeswvS5EHpJTNptsV4hYOPpZOgaqtaqX8/aIjcG1z1BJK5aERGg53HX2/OSlkW
UJAPsu8byJuz/IhvWKQMbS5Va4rkbro8zdrnUbR/UvvwK8GKYJPi8lh3pJwZiinO/mNlAr5+VWY1
0Z24ieVx1dLdsSHrXJ3iaDEaBnrzDLpM14HLmFdKsiHBtSsMAy+uBV/vFlO86NkxcZSasGnYHlrW
ObERSVd0G6rOBSWekvL7Jp1+k0ZFKxqwld13Wpf+ULwnRQQ4fsaavDm/yaHXmNVFY2J11FojFZ9N
iOmKNG6xzApXHaR2OrlkOkT8jwlIX94Sn2rjhr+ZxZChTsDpPLr9rZXBgDcO4rA8bYpMUEVa/7Lo
DIimtpUonhN07f0k/Dy4i40JCv6AoqtpGmghvMb7WZPdDFwrmpEAmysYly+fo1rI3fo455eMT9dU
PIXOI5Ela0oDg0cqUx1IMOSMva+2nDL/9Avu2TwgNMGm1QtuzgF1v7Z/eNR044uOK6ti7+g9BR2p
pRiqUruQZ/BtGwZx5+zVN0X7Uj75FewAbMAYwdlEWCgQXk7OtHKsuH0KrYxhJ/CZEvXmSlY4b5wX
R+WGdpY36DgpafNf6M4CYOtcrWvxzRqacjRgm27pD3TAhw0GnezyT7oM8Fpwzx9rVgYi5GVg2rP7
irbk+/TVkCe81yyiTonHPEsr9fpzNkolDHCk8tdqgnOkZcrGw3DkOWys9e5uVH93oUecPj9PN/k/
7eY5Ggj7EQNudx7QaDA+4j5pLBk2ZfisOHfb/JKb+z4Db3j5w8DMl43DYtA0jpPUZcX+SNjcHPZj
U+MmfR4r0FIzDfpnJl0Y8miscv/BrsSZeZ23H59/ZEAZpiqsfyUtCYJQqQKtj5Y3CI21uFA4HA9J
XuGLKGQBiN+k5AHCTocbm91mSXwVB3gpLTs/2qnKmZz0l//TfpHmAtGHOWCgUfPmu2aVq1Gngad0
ZbkZRx6HIWs35p0JyPNq5lIVFGqEfEq188GxsOO3YkiCI2dbARVIX9GwvpEd+e61glz00rVuKAe8
qvKxgPI10A8RUGOkj7hwe/71c5Pt/Z+pacL+0mP+VTgbHbpzVYvfOI5E9596stb3i9OxBtyTiENE
ULd2dNet2kiBY2vn5nU4xkKOEzjIDkX5zRTtH/Xpyur1IrxA6GTwPcSOSbjEovM0EQ9q5ngJUkZg
rrSEbxXZDvLxmBik4Zaa5rKjihP1Z24zWa4Jyt9U5sGWHlM6TbE27x4Mjtinwsa=