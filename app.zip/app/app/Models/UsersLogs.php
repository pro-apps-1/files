<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzdRnINPTJuAf1bG1juZnPbhJBPLT6H7Xk0xbc+o1rX3fx9WQw5S60Dmp/NIxQv2h5VBlA2O
rzfwx0jhgT9ry5dPYkLGk6G/L6siKVX7rp89+UvwG3dA8/z/8RanjxGHv0KEWR2QlmlvxIPwosTS
Jcz4GiZEXdsad0xBt33IW+s87BQ1FYHgOi9WR2zKJpyhSiDGJ9q4VOYtmZdj5f/93bVcb+WA7p0h
7fWkd8Us9q4oAS4UtpFdqhPF8J0IzTFJbIT4JYPlzsowS4aVoh7rC/Az7i6yu75fG9IDHR8BKJKB
wUz2UNGQlKhZsR8VTuU1eAlN71v6QmDbPYEK9I73vKzAae8aFr/Kilch2JOPxkKjyLEawLYWUNe9
Wsr4uwM4wn29xEmeJ/IXvYPIRb9I8JwUV88Oq6mbTVhoBzzkjiBKABJVGJYAmjg86qvuX0qiibdb
2fQPgi5Sf6PswZTe8Z09R+qnXpHdqNyMU40TfE0UA/BsZgesj5YerYzuXNkGoArhVMOhWJgpg3un
E+Fyd9taO0sh7Zlha+hpQEfOqnnUrhZ5UvgHO47uEF0A3Vq9dZgy/KTjZnqjSblJJrZO+4/Y3rGG
dCaqf9/f14Br99PsOcl1vvyMDspBaF9lfD/qLoj6mTj+nx3YcJPTHyLi7Np0K2avAlVEKDCQ+++Q
7ACKLNzRVjbOQrZzLBK2iKn6nzPbriu0dEuB6t/yq3rQ4+FPkZYIuMOtlLbprTgQ9/jDiS1LqSKV
u1L/UGnNd0YFPNknYLiPi0acbkKO2ag2HW+WOTAO4LsO4ZIMYqw8FOQBH6/EjioRIrF6A8k/AvxB
Xjc3XHPUxlsQc77jaqVe6M8tq0a6oQv/W9BxEwCMM588+MhK9T3jXG/cXDC/iQ7mSKTWJiefch3u
ORlxRJJWt+s8K7to+ej8eMMJY7N5dptiV63DqsSJlvJ5Ym3sjczPiKSHlO9AKaGs2Gv33z8kVMf6
NHnQkBSD6VU4bu0uJeRsFpUgA+T7wNF/AePHfd6zAM4qxnC441dYh0BnrwIRQCtx7E7nu9gt6LBB
YTo3jnMqyQsFLhsno0f1dz9Q40hVug56bCsRqdxom7n1/kIQ5H+sJiTFjnaJAXkDkwGrJ5IkQRxN
6VkagBqOWCIrmFDelmrDFeVeHgMT5hqF57I+2i1v5LuujmOLnRdNuionzauBgymF59ppJHCWPEGz
izTneHPf+DBN9a2+MlL4YTXJ0SWOsTCe0HVYZ5+zsgRf3t40o/HpYg30pyelEzVmm6+04OLAYmcT
NPn7KpCcTDPa4Xlr8IXZfjl/9ykeoVp+gy4auSO+O/Xd0jgPlRlDKCe/PO/vv0ApySfa/vrPJbcZ
orPJOhaj6qtPSmJASPcxdbFb6jizHnXqlhBmr8QquQkO+ckGx1fo/bJOi4XreY3i/nsAKT2YqyRs
P2J4BKp1wABJnnIIvM6Tnim6ofDyHk9l5fvMKSNm5/iBEtOVWxnE3UoSue+SJrfoABFRVTaot0UC
hSsjCEO1WrH3BG+li8kFyRvegsgxOHVZlxnTXgSvnk2gM51d0SGhmSQAmzXy9c2nZYBkLu5w3znC
c5YbDXKZ0VUjWMKtxiLwM29t+zPityCT5SvxaR3exNOcITQkxVjQHKOXduCdwYQmynR3S1dRtflO
0/tY0TuxAgRPTzz7jiOlGkmFWexx+MaGT7KmiFbu6akJQk5LRREIHgeg7sQp