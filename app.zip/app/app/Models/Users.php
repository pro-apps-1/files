<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmKJpbgqa3ATGVrRUOXSsw64Eb07DuscJCLghDH566c+cAE3ehhmYLIZJ5x+OgvahICawOM/
FTWbQ4qLu4VSGheH919eqY4ZZbmvDcFjYV5K6ryGIxaHLz6/e+7Pddd7zJWcoZWqgXlLeIhfEHKv
D7S9w53w4+RiWa0/Cdhx8HTmfB7GZR1DAXxp0LudKvgFZXFH0sdi+sAa+7P8t1BYR+sEAW1b/n4I
SUg/az33SgY1VQewQuIfqu2ICSxfcia2/qJppVTikd197ygnzJFolHx1lE2tQVyFvku1Ef/lQpJl
GdvqUJD3bN8QtFhI2yC2NtWLXGDCk9MzXAyOB5JcGU1x0B69Vyi84N4JVNRAu8qhphuGSZ96JJgP
w6mRVe5cCh1JFgEfmGqlZCkn5hfoCnyV4F7FCdD0ZBXNQmZ1VhlIwSItulTdno31wICGdV32YJtF
yuJXURXAeKKYc55whWExH4VrxO+8m3jE1lbn8qSR5f2A41fetuKrx6fH1gsEiECmu73l0N0GZNZq
Ws05rrkeXEsbvmFkDLjNonLGd2pIi05XsDIpbp1HGuD6nCdyFGOFjw/RTFd0tG8FPB3tx05xU+Hc
CjaJBDupMdYDIc+2LQfYGvv5/aVlRk4rTso6nPAgpyVTYLy4q3D8klf8lgYzQAneABpb6YDbOmuU
9onbze++HLbml1iVpTK7oZIq93QOcqbJcb0kZ9KUKD0bycl4WFhFXOYO5vUhuDyZOG2m9yVWYNtz
+ULRy6UGJ5DX3zYsDX+DxT5yjrj/Te837LXy39gQ3yn4wSkIXABcLataoGCjM8kurj60my25mv2e
TcgGIZvwOMSsFv8+i8SsyG7YN8bTirfoY+Rc4Upl7HerEbTgWZx1P0EU2QU6c/5ABmFRBgNtdjpF
+EF0V4A8QY90XTOP4Zg81POjemksSILicmY2Pb3rTmR8BMTh8lZb0DeOyBA6ymL6G5sDCpItfyaz
Qt9t7r3wshSmWyY3IcZSwmR/1lV9ynCYRyP/yK+/tkNhdUh4qoks2I1vYcyruazPWmUMAAu//mIA
sOa13mnYFxPt3IOuqfRan8jbJzs7fbyj+QDo1HH+Zv7oz6V7WcmmJSm+PknIYfSM6HPzqK7URYtn
FyYJKOY8gCqlmg+UmlTSvt33ofvmdqUTQtgNSOqVMnM3WK/A7r3XZV64WnpA2GDcjobYHjmPQQbf
2y1uDJTVC1Ox0ZTPGV8wroyVeBybUYpFNBHOB4uGx13+W2ag4OCN3Ny8HliB4+zD5AmMlbY669ES
l4rVeGFGtAFJ7UESVHROhpZrshDus9aPrGcxtmcT8Tjg7SI115d43Ztt6sHZT9JYXNVrkLjJs6S/
/epJ/2y3BzlJxokq/sSNqVTrilKTxd4qWygrIgg113zz7ca7O7V91WWDI8/+jgGTkQO+Tq/+KvlG
8y8JoP1ovKl+TSueTd2kdW/Fd6l0Tw0dwuhXEEzGw/aWE9ihH4Ru2ZGvfXJq+4k16JfnWS4cPQdN
I2RW0klK4lxagBL+PRlu2UEI3L/Kva7bbAySQWEtw7qXpRUHUy7GdC7rqXhMvk1FnLgZkVYUBDfY
uZE3kTs1uWRn4Xl+kRW/CtgNWiAXiYjC2KTd5bUoSwfnr0YUZ2oarf81ZV/6zosZnhfNcuGngCwg
sUDwVML1aTkfjY9KA5j36CIgxB9OTm1FvIj2Q2eUikUGT7Zkr7xZ/wnpC8TxR3xqdBNiarWbFZXk
FUFx1Z9VkiRlaOSqMhm4ullXIYMeVC8nDbgKdZO0grfM+gs98kyN/16CuaIIRcOL0vQ314SDi1az
uHBq91ldnzJBpb4CHA/ojt840jrR2HI2bfC+cAOLDeDICIuPmPfGE/szYUA0/EaD/STLVkIffap+
hopsgCo2T7j2zlLc9C1GYBXUWBBU+1h8CySfpPLPDL3WEDBRzpeVLVYQ53JE4SlTbGnAvO0a2GQ9
SBJkMe0b59dtFGhnLrP2ReHEomLj0FeSjHBVwvK5ZfmGWfldkdDCzVCXP32GCBJOvZ4rMMVhy0iH
giMv3X0Sjn3DNrjPKGovGPcBb6mAKkL57+PyaTeuMemb98iVlAHPGfh3aACdAFPHfGKTmldDVaAB
g+zu884zzB6R2wysmjp0fRA0yGZ1Gwp/a8XyVFI51i2gHjiWouKfmVxXDiZsSsQIKKB4oSNSOKHZ
EvZBAjD1dDQrWlVFRPKqWycJhLo1qNYYMHbjjdSd+rUskvQF1oWW43zXNt0R9oJv4L4NwxopXeZ6
1JqqX2qaLY+Kid5zvo82RA5MvF6FAe3bDlDhrlZAT49ibIhz2R9Uu/zBqqBbrY7THcRvBOrlIiLa
T2PPfwLJg5Svh0NdkBz/dOVIfhcn2twWjr5BoPsaGEsSH/mcFlyLwbPU0iHcfxewHSLD4mjBg/8N
st9ii2DwRAWLjUZ+pYTKJO0sIm2mY6Sei9DdoeArAvmVzzE+h8lkiq6rnIGKUkdmeVB7PW2Z1rQ6
dQ4+Yy6fwmEWNUXrvG/IXrmgUEFBrfEFimPQwOXgOQYmE2Mrn0knYYm+a6CX9uT4DXH7YLT0fOGZ
jEZY+dD1SU/DlmUe/cSbm2XnSw33JqFS0ptBdZhCV58a1o539tKEinpofYeSqb8oLl4eOvIQKazq
0uCosQO5ltDJ1bZfzKwW2v6liWp8SP1incRf7lO5fcBM4tdjhmY+8SK1VGO3Eg6J5Z8kdDEqVyDu
13jd5RFZPuXXBFo2xvDxXU7CGhtUaRYX3TAHIfQnN0lO2Ciomq8ShKHqC/cUhIoRVbX4eNHwWRq1
qgNGtC8nPn5Y+dXkIJQ69zSO4+O70Gz2425FfMu8jOaXQ3c2iiT16+YUNmoR8eA3NoopNlmD9pEa
ruqA9G3vOEGqDlBQV3OzwYBDDTh2ZY0G0YOTMXfbQI6sKp70d1GCaQU9TZvzy/raangVpqrpfYRj
HApMAv4v9xcapZsyIoJO1+8HremzGugt5n8cAAo6dXkZtBwPiKnW7pB+ZsJcZ1B4G/H3qA7QB6e7
GrEpbwXcRB7ohIr9fZL5ItwkwI1FZP26Af/L7/br85L83QMKhn34gN6NiWMMeMzlnWgjAAUy3G+U
id4FGpau1z80uD9E4P1Fk8B+piXA9QjEq3NzNK3WoD9JUYwYVy4DKbW2yeej7Uc5g3tEDTw3QpQy
+YtUFoSuIyiqYSYbJ+WaEC9KSripXkovCbUKfYusmqecm6t4Zo4HVeVVLdxWzH0n8y8hyocZVRH4
5oRO1Ogy4N9Cagbh/hXmEqjMm7Faif6dSG+Du5w7BQvGSTXzKk8kCmUHiGjN6gS/g+x7v0keRttU
QSCiu6iGMzwHXZ20LV2ZwvvImy8Bu+AlNY0SuBt82cFBeJs9P9r1FYDoRiqG3Wr/YSWAEO7nnSGE
BQrdxEx6Vq7YoB1bzcdX/SHGBJAvn/Rb69q26NXymsU+R7wQoaB2tOWXD71WiU5/J2Cn2opor0wX
BHoPQilKeL9EoRkCGuqPDHE0rmV0ATKV52oyd/xIjUCVLLddbQOwhYiW6Nduk2/7kzAAcNIm75FR
UTK51EbqLN1nTrKRBkmDerfirznOOqR7JLdaSYHqWzYoZ8hVUCi6PRsvhpPFtqGhhWyDGP1y+97S
Z1QzN3YemLLZ1+M1b4AS5DbHlz0fkKI4bLDEj2/JxCrp7MSV4F99/vYU/lk9tMijHZtC72GkUfdD
UtohrDYw2SGECbgavNaZ6+R0aMfqYSQNMwyZmj5mx5D+Pt8vUdUZLX6cfvfU2mc2/3ESJHE00a9U
9auiycctBfYLqOhSXRbf7+EvxKan2e+gQFmRJwMZBHZHYwJESMUodXfjs9WWDMeFwp84AMVrXa5e
gJZVfaMN+62mUoxKv9pmzHfKH1y7+0XLaTCnVoNS6nEEAEJDeAENzKalnchL9X8UFH5nq5KMYNZT
tXaX0GwrliWNQ9ORLjEp433yexsLB+m2i6ptKuz87ZliyCTByBkS1nAi3T43OKIZPiCoKSF2i6oq
LfbjjNEWDcKGIiEfmqpIAxl1WqhITpWur9mam2+Q1xqfbAGs/d52GV9pK+lWhEKNStdY9N/BxBLq
bMwso0fXwsDNcF+IOmXCQtb7Zr+w0TE7dnaFRirT47D6mk8tN2hs/fwgyykzKhO5DmGYLDl3ZtGr
8sPaNg39+AnfyK+v7D6qosT69eupEsMe3+ZwShclmePpA9ycSpq1UGJp/ChJv9Ck9RXVIG+iSHDE
itygfNDkdBSz+j+7jSLRlWgxUDkOHkPdY3Q3h8OZKnSfD2FXVysxy1/tcrSBaGVR09CwuSFBwNow
d+hP6wKmR9JiTOhuYx6cIkU2FmR5zV+b00aQUURqkqd8JL9x3WniWlAI9R4gBwh94E56DW/eCkWg
q2yXX79iQoYjMWPxsqN+0WJk0eSDr8+D0svNI/z+zcLjCQkRoRjT4SAfnfTuAXAWZKrnPEe2W6D1
7EkyUuRzKKGZEfcYAHRxJggoIvGa6rMzcpu4zblqYFvC0DqAtEiMZiLEalpYEEmnAfNO5p8z+IX5
65UZuQrUjua7Hi5Tm/AZA8xhG941Mr5NIbIdJ9sHqyqrV6+eqfQYMNW9GkhToGIKah6dKGkXGgT+
myY+ZAbHAVTtbr8apsZlYCm76qKpdFkG1oDcBB0gph3cflirK9gMrBIGEDvo39wRM4zetgx3a56K
4x5gEz9Bth6oYFfaWOWOSaGJcPJCHPPXIkKf3LO/Po70X0y1YEadKsNxnLTFX4DcTp+JmKuD4A0H
cRra5HAwcuEfSLHYa5rRGLJMOdAgFPADFqvHB0upYMeJP8ZhNU5w3K4I/pLACOI9hqOCHcupKYG2
wS2Ah6+chy+Z1YTeMozDo5dFeEClQfi/HXd/udxN7Pkd9JB7lrth9XqEeQuzH5qkfLQVIdzXW4hH
7j0sG1ubeGDW/NqwZlI3i490dxWD8B/zAP+TGjJTRlgONPJGE93IIAoGuNfb9QtlYhNJgI0b1FjN
zzSrYd2HkBTw0dzxSTGGr2KGT93HLXOkPZQ0LgcqNAnOVUQMn/40/F4hZ38m1ADUKOkdDst7nI+w
fj+nhGK9vIVmUYh6cxFFEYQC2JB1UcMlNSIsHUplbq50ic1zM//aLP/Db5AG2h+Kqbcqfmd2/+Dl
tz29fjdW6/nPxhCpNrh7fADHzqhZzp/A8qo+RRgnE2mI12kYk8erLx5IUCxDktr1/eoI8kMK/9iV
tAlLSvLDTGjItmj7E662LJCl4J7bqjOuFj+Wd1a95XzHMPIYw1aqnNmeRXjMxr0/g4B8HPHTyUcT
409w/a7BMe83qgTCAvfO+2LXCKq9khbClx4qHTqG7KlJezNtPNxZSY1hfMPBP/9qR1SunFpQJ+kD
XfDKDtgP3/+oicSWvorOgMqss26k6MEAlSfsVI2bN4gLctkM0xLVywI8Gvfj9pSXW4lwmx0r/kSn
ThxTl0qpONRyrUId9dCzmWZ3MWGOWBp4zuZmLA5/x6/bNpsHTUGwh7ox3lUU7ly8tt1DmQkVwlgT
I7nAgF/ZOWptRRrdO3WhiyXSuDnlIcIMyoP8eu1e7fzyikH1EogP5RX+TxJV+tWkXOjRBYB/1Zho
9G0WwxkhVWFIL2AA+T3CPMvIigDgMuF2/pRsCpSpXZjoc5IlwPiYl+G0EAOdzUZf3nv1bZbEjc2d
H47me81M1DbqWQmb0qV9ub0fi1EpE2inq9ULn/x7AtHEY+32sgzb/T13GiGpALBEADZvm70InIx/
v27qlyECiHn2nDfZRerrtQY85PJfJPu0XbQHQNqzfePdo9hz+rFvZ2LWY9THugE+vjha7PETKc3D
RoQPGwuDpG/YP+QxhRP6ajiSZckhgyGLqEjkpggpzgt7+y1pJePL+ju6WSWcs//ZwJY1DIknx7K7
nAGiybLTmIDE0TYnmm7dQsJ1zvsPKv1CFvJ1JGoiULU3xDYfiyWB/ow6A2kW68brUbgfp+sz4/Tk
Wwl1OhZDfnt+SPoVvT9ZHktQa/bnQUy8ybttY+xebb/Rhi4vDb9DDyEurcTMUL2SPGrmJSpAamP3
wVPXzMDNp2w1n45G/Itx1kRXFfJK6O1oGrLc0egDwSJjpDTHVnO1Jau5pMQtM/eZn+Xx3XmjdkZ0
KzKo2C+r7a/iGKU8FlFxRj1WkJirAGT9pNTSDAqDc8mla1+suYzmP6UGVvoiGvCpGsl/QTPIvdNl
2J+E/DUk2veIYND2LMkGYY0B7sc/zgkjOyRCmNbBdJJrjZ7gvXxavMaU6f16ubPZETYG3zbn1D5u
wUfG5bFoGN6Rx+ei5bv8dgJf7d49N5DhUkjyN9yxQh2vzW1fpWf7iFT/93OzKyoqg20+P1jlr8vO
L6+wp95nKHahkjW+63FPC1y64qcYVRAokzAKPNM+hAbeKAWH+RwK5VxhZs6AVMzDyflnr4obtz0B
gFmbhn+VJEV+Oa+Wo1xzZJA/xxDS3zy/Bd3skrsfPXzbhWL0t671NcleHogRib9P2qY89vmNMyQw
UWt3KTtKfj9GJPoZQQDj0UKu275UIF/YFrQHmZ3GHDutjgEZI+TOiu/mFk/l7jbcsNJ/e1zsMrvk
Q7wlc/xAxFK4EWrKwRjJYgJ9kUysQCLzzzqeHliUrWP2wEORS/r7gyEsljEwma70Hyi00zv5mxL6
0qbZkpFST/kID1acHf4BB5mw6NseBhJBEwgrMKpTJMZ/g6q9fCPScEWw8QaLnzHHORhFbYP8D1W5
njpPTX7sDxFLd1/WL59ARPQx1HbdL3eVyTHz84s6uy9Zs6jWduhaxuSxzHZl/GVSsSU2b5Fv8nn0
qY0E93Rwp9xR/+ZQwoYLq1DIefBaqPMQeEGU8rbz3m/m16w7roffegRBMmuWa4zWCS0f/nv1JLnD
GVl3b8u6AO+uxtGKbp15fmxvj0M5v53anzbeuYu7tT8zQUixIy7Va+e5RXlu8xg1RpJSe42PJPW5
ZZMqDaszCk1qXMaYP9V7WnLJrbnkZ/4YwDPldp0/ELI4jcSg7Mkh2e6bjLJr/Q3U4VV41d107WO7
pHzrQ87+WqWUnPP1w8xfUQ9jszOtJQqmnpA9s2cDdlaOQFqXs8xAe14fZNBwK9QmKRaKSJ7LW+Ge
eA+k0R3v6JNU7DGvmgSAyKOkohLqs1Nj0CWsTPBPmzmwsnnZMy6fydXAU0Wno8gNR541gxeEYS/G
zAaoAzXjmOp6zNZr9QZsXq9XrBO8G3OqSKq+kLYF80+zEBgCJvlcbYMU/6JHjHwqiT8mtPOqYNdu
iV4EVjZEfBaYUTcg3OGs6zgfivQPTChwqaYSXwZ+pBhtaqUUG4ECE0enURKJrftfbcZxsNdusBmA
VY7T+inXIeSOwIACP2Drqxia/IHVh1wqqYKWkgyr95MXYNpbcxiH48J8JDoezxUpo8NOGlvOZj8A
tvlxVbsdNxi2k/xdyNt/cMK0b++C38X/+/ivx9CS6HztOclyikp8sFxV/4FA2ESplZtust4v5KaG
Ln+ix9a8kG9TdneqBeMW1obGj0GX7043260GpoBfZHNR432SKquYHIKcptRao06v8IpR0kH/Qi9+
B2PLwuhIqDS7rGj/T6ZC22VUpqnVLC9RpFt3kI/t5KwbpXcfsY3LonhiJUQNJLzXrcPwI+fvIXxX
9ZCsYVSSUhp5nruR0uh8kOjnQGkRHo/RZqmZOB/CdX96m10BftkGjrabIyhzqvAIayAAT8Y12sOZ
60sgO604qBBEZOwKff3IJCOshssP11dXRM2lTjOvS0Q/ynnXYsWrP3htMhf4+nq1kSyAn5KgyvnJ
v8Kx39sRfWF0tgfAlabINvL7syZ6HOh/L3lZIZ019VDXqoCpNUbKrl7IzU6H6OGckc8sDj354H7c
0Ns6Sm7DVoBADa5GA594aIX49qzOxpLbd5WPZd01XM+sttb/uTI69r0LnF213/gHl9EG4dfz/jDh
fpEHvU5m3BYLEbqgZ3vJO3DESHBP8gibTZbQn9b7hzPeN3iRM1OtP/7t/jRRO4M7BWzkRZi/eWmu
fpAr3pdRBBOo6d1+w2GrXRC/txIwohJ1dHxSOfLQLAThZT7USd0icyyg7tp5H819YvVT//8X3h2z
wc2g7ePMC/19uRs+1wjQwM9AKctdC73eVrZAXk6DX8Ba88HiSgVP3NWorIAFSWv80448cbyMyK68
tlpR5LL1jNozx9WHubZqtFnZ1rSZYNZEaRFuOawMyBhrvIOgUjLBFQKmM0ECgXocVcDevnDcPFtV
0J79myOI6XjUXEAYkRHCM0iL3YVsjTMGsxBxj8wvClPJ5EIQqIgPGvOW3JSt+Iz5qxsqrOkEb0Ke
VAMP+6ZQ6cjvHdvqo9nqsXCCVr2wbJkHp/U3335n9OG6g0xYEljMeh3AM7aVQ8U6KoyjBA/K3I3F
YGXsCpPtCNK72yT5DHKm0hjFIVoXxSvU4MOTMjOve8F4XY6TcwxTvNHrX6AlFGpgxQI5q/zhPDBP
BCKC0a7zU/ee2/fdxkFQUUbLYzXegcZkXPu=