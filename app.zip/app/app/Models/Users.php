<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnkS8wqZBPY2Ed6sZaG0XCmKi4rF2bZdeugukjBHkCTyXd81nopWIRu9l9GONGcnzmucNPe8
uHG+uvBdajleS55rzJIKTcf+fOUvUeQl2iwr0vK11CVRFtacPgtVpUvzt0AyPT5VwOZYXtSaLSvv
1z0oRJHoGqtiik4qQcZ3CcPEvKIk+BLxvUt8kp8J+9JspCtyQI2Gr5bqAaXNOAL9OXDI4dnNK61S
67kg5wAHv8WiSZWdQ0/kBQ9+FTktoOZETtfkknJS/sNHyf4HzkDiCNITuwrfivoe6KzzQBQz13A1
nueh/r31UL+JyNZofOAhVGYo1XBDaXmQSl4RK87k5Yg0Jmv3RhBZjlh9JNud/SeP84XaPozHJf30
2iBMY9VHKFxa6rK5RQ0DABygFLPwLnDGQCkqZ2fCE+THmrq895zr7KnkVKByvHhlkmJQwUv8+Fob
b5m2IAumyzNfeFvuC7ViwpSW4O8MClE9EOCe7rCtUNh7LvMnHr3sL9b2sEr/pTSIyT/NQJNR1GBA
5BgyPRrSdI3jDMY0i0Ex9ymMkxMTGaaMIRUg+jvOuAQAgDOfEeP1vLhvAkx58/nhKMKWD+76UNMA
6ITR7V6RJ3LhVtMBd3g1BjaAnUL9XvsRKLKSQJ6ZtmZ/7ETnN6SlijL3hzcHBz/xlgRbZFSVleT0
xPqaXTaJEmQ/RHxhQkVoPy9amYA/et3vi5QTqtwHivK/SbtfafINHd302SHkKaDhxmwRWO2OhHUv
Q4NR0+jA4I3O/2vXmQicPyhrnhssabylrpxW62gX7jgoRaeQpUSVsBBCFOUGrkpT3Snft9ylabOZ
5AoEdrVDKQiQWMpkUox/Qfqcfa+Suz7G1MzUdLTbHiePLWLUf7PKThEgMsKeKyqHDBUSSagrBD6I
012lxeB3yfC5Znnk4uuke6OPFUe+v0u/n1ONIHzQOKFZjVG0pmLJneEjdNl1dipCsFiNaGSWAyCc
tdkC7V/OlA56WkdOmsmNzuaiTuYiIi78RR+9IKshp6JabaBG0zml0aah+aiRLLvGLx1iaR5zo8+U
H/h3OCh/bv1EqOSkoUIg50fb+S3LH6jVffVq4UfC8m1gRQ6GJ0nOkuLHVxzd2ftr31RZEvJPRxHU
4bafk6bJ/rqatujrq0zzdrz+W0wZ+F4ee+gIXmj8dPdLcVdZjyKv4YGAY2mKYf4KD0qdidxup618
/Dbl3O0sIVBEHbfvmFbzOK1P51gp/SGI4jJTqpSIJtHYesdqTeAFrBJUjwef/FDj6ma0IZfss5jj
nxOFpalY6/3PchdcNwYc+W9yhkPMLeb05xGsoYrLwziO/sUtGMsgdBO3S/TD8PxHFrUMshE3l27K
ikpQESFJBynP+NTTGILIp/M5/tVD6j6A8VxeMte4C73lcxFUjfMR9uK2+U34MGUcjGdtvoR7Fijf
VVqvw7ZFbxlz0MaxVGi0J6wiu3FOXnbxXAMdiEjUxfQZzCu7VmnFNNytnLLekLjc8kK5OAk9XyC6
Mj0NzJMTgUNGwHDQlhr0TUGjeAxwwqQKf/ofuTm7cL7N8U9XOnw0CStvwV/T6y5lGZK4PRF+Bgb1
NUE0ZQLuOf6go0aNTngTsw6CFWTcY/1MljdqkbDWhlsncrssfIbUWQ/UzsBDejqf4dn9lFb+w8lD
t15XrYjuK5jiz8WTCfYaCdOXEKHgaW7DgYhKdHvCrq2mSvgWcttyPOuJZuoGqT4N2bE6KOcOfYPa
ARCBqjHamKRmW6oKqeKp7JP6UV3c1Vi96CyOQlFsfjGwvexeEAzMSPsEEKlxNZDPCv3q43+GycnT
VzWg4L9waWW/ruzgYumOXZcoYNv+cEFtE611oFfujMMy8wO1vHuYJ9k60RemzAkAxizhd17lU0w3
xQM7nmlslV3PvRjXwg9AXgfTEjpEE3Uo5T6kbENa8DogfUBKLr5esxE1DAYDPw99MuTOnEqtO1+g
PGH4nTOttRysLxxdCdbqrOIcyEb8IrTatTTodoNiB5BvCyETArhNPZyVaPA15PSdP+i/49LmSZ0N
tn26eeArOwg88oc1vD0z133gIGF+LciOZnqq1jN1686SbMyuasHqIMNgHQwPKAOqzLB36mw9wGj1
uAPcd3sruWBUmCWGZiMBfpsaCR3Xr7cMru3CRGsv2czusD7ZAo3s0wbPxetYCPZCaxnEOHoHA88B
He/RK0FPLl0/uas+J0ldhzezyC6ENwkh+6u4WZsBC/fqxgIWVoWn5TC+XOpRYmpzKxMlBlkDblP0
CE4NzMW+Y0mYfUHf+vp2gsa+QMRHgQiBx0TsrUElZneJae6jhcvSrVX3AbwwXaqVYpKSjc+i8N3j
sKq9tT+DhsAvUiHQ/xV5EfxKEGugU4BPoBMht124dOxwD3BV/93ypYmMEjO5EvOYIG0ewTWxZWMi
LYwVsscu9REtIJ1QMTNuYm9YAX8QrtlSNhKgr21QBzg6WzJ7e33Vda1bONuV2W1kg76jn7q7oT1r
Qvt9Uz75n7eX++lrOTnyUA4AW5iFqVYFRU2cZowLX41Pko0TvbstvOvd+mgm+iCdajtSiPcHFKqQ
Lb9pUBbPJpN+KhBlk15oQfO71wfH9NckED6QL1IVJv04e+ZNKrHbjTyBMAiwzoB09bxR1AKmUtun
6ibMhskkisKpu6lxlXBHykCmhbFQOQZZULDvM5q4NTXZRvdUqKqhhm5S6E1LiiI0QY5ZvSN28hUO
mmwpud9pT/H4CDdorOSisbhuheIXqWDvON6sLPzR8bTXLo2ucNuABN4CCmYp3uz/dKLps0n7VVuC
pBcnf0YfQQhWBEJmkpGv1NRdy2+1GXThwjCKtFFCclfg4zIPpMkgVXQlzBwYGv1fD2IXP2RAtnEB
CdynVOG7lja1FQ/wUxTUwYPrHvETz5IJL6XpBOtte59AG937wWCXeLBEbNE4cuk+/z3j2DnKJj6q
R2z5G8tHWdSzJeZfeknevYoNFMOsNQiTKpTDny4T3zfCJY64lAkGPsLOHtanktGzBIurZmfAOPE6
zWkZCNrl6J/Af6ZaqnTJS4mF2OnPS7uZDqOaV6CtW2ZbeQlwknk+W1G/mD7cPGatxN6LNoXJrCVM
uFRbPzZlCqzHpxosZ07kUZf+84mwd+CppRyByCMZZOB9j+nh1mSuedMHx6l7nQP9LFhNq7nmJmEU
eh++OS/+lZQPok1iee72h7dSDTpHVK27DszhZ1p1uFPc5LhVXEAQyo2E83HeXObe9ITzTI+MkqVZ
nZZFngHLpeSxU6XS1NUzkLGLUyOv6NM0fdIHSW+m/OY5jpXA6bMOLANCavxV/2DPYSrcN6ZsG981
A9XA1FE+sR8jJ9fNMRwgR5+nZRGEGglendDpsd8Cl8kr3diC9IWNN+8KPOoIfWicrUTudT8D/uZT
KVpQcydTPHSH5gX/eQZH/DY4FirSFrhtacmK11aEp1emkBQH1LxqpJrYAsdPvWBPLpeVJkzxlq5o
B3BUfdN20gPGs+8g8H/9YJAH9d4CBlYmgn8g9TSGzaakTL1JancnRWljn2uZJOcivsHb1dY6avHy
Qs6nb4qS047JQCo00orNR+thXSjMNHa98MYLGrM+kZcLaFglyLp/rBWUBH4QZi939JFCttsNN+gN
oJUiFN525mZoyqDrVV3ekJ4CTw1pt/f75G+CZ59HcWhtXPkA46G/mxwhqpuoqnCgAf+3+0B03yjA
70wcaDcnccmFBIEb4dZSkF+TmVMoTiZSKrJsAHdcTwiQ6/LVRLKuO3D64RmziTcLcTGzmWgnPkFo
gxZ9jiBrRreSdSVyp/7aY9jxusL1u1nE3pfgA4WtUM/kCwi6y599uBtoFYMvE5nshCN6j2pHIo6n
SFz84Ns2hnORWnCxrs3Im9kUwFlaaCXeduHjeaTxOV7vQvLp0oN8CKTuMc+7a2M/XCV+1cfpsJjX
JCCeXHbU3YCiBWZnXwCV4ijeVwuhEzi6j120hLw6xB+OMjksOl2GyTJc4r44Rd7AILaAFq1dLTnk
NZCLqw2UqdZ8xZlEEkqVpVtDoO3sN1bs0LYKccjCERYFqpyrQpUxt7q83zQdbDr922LBiWqmjTug
Onw+qxr8VxkCnaZJqN/RJrJn8ME0rU9JkhX+piYl9cY30NrJRdB5cFGC6HWUnmvGA5XuZZV44Mxa
vpvzKgy5OtRH22GS0YHt6J4VoRnI+bTS6ujt8qOO34JTDtT/l7nFvErPdtBsjmaqYhFJUmmZePtl
i+b2/2oTOKsC+Fvernna/QY0lrq3KUn4Us8ASjkIrTtWMJJeYpUBaPmpL76bIHtqygWDuiBTQgIT
NI3dfn8GAEZ17P+3QHQ60TaRjl66NmzbPuK97K2uVBYIYU4KtcXvpzgK+QImL9ZFS6ZYOvfBRLLy
B+Lq+PElSf+LDN/4+J0YFQ3J/1qA96YkCyVZJj5djlpkP489/wyGZD1n74T5Y6TWpWsi/k3hSfBW
TF/ADpP2fffCd/Wgvus+lVvXYx2o67UI/4COmEwWgrqnPbJomKUXYSqBCCh4EjHZLFGsea9POCs3
UfZTorcm8YSKdkeenviY69DS3TOXvsM0dclhD6lPElW5gZanPzURrqE5paAfwV9DQNcf76JNiwaG
DWldd6Nvqc3QKq7gFgvDbN6mojj6kprNhhfyu3Up6rrtTe6ozH0t3Hifo3kH0B+ptt/jWPEV+fU2
hJUJuZwH+pL+G78lXrPUIOHmVof1eswjtOENC57vF+1LEP3F7mJKkJthj0+aElv2jmqdke2YLDaf
UDerv+ltcYF/PJcyyW0E/Z6huER2mXow7gWzjVzwamk07qr25lpAG8UGD8VDT+KBlyMn4yOxUFIq
0qEwSjUyLW+3DHq5G2+r5ti17I4P1OdQLrO9X+zSYC9+MqDNFa32MLyPXO7f3kDEdpiaZW33tCiw
PYxaTVZMG5+Mu29Pxm1SrMIvDC7nk7zSIeqcI1q+fw36BDRvpYTV2O9Hyn3momUckkU68i0kmEUY
tnJ+RThsa+knPzi8JUSpDrZnOzqO5SjY4a7pft3Gfp/iDiwCRn9XQ9Ab3verXGpbiuApI9I/pYg8
sSQsWrDTErnr56T76zjzBtIh+rprKURhRtkgBEFQIVMFl73vPa4CdQAIj3ahkEBcimls61yl4ESK
nzXpCRw+CVVRtwnbFWsizLFWZ73bg8H03A/AIhmVczN4bXeTRJSnzB2EYkZL58Pj0Kvn0FNunfgJ
tcil6OMn9e278vpdMxLyYxcOALXI4v9lI4Jfs9wBWw8i/bkj5MpDiI6YrrKvHBs2Jnu4cki3Aj4j
xgAhpg7OcnXjDbJTSTE1UZHV9kXoy4mGMy7OQ+ICMNRrrdME7rUqYh7mYroIgQbwrng4VXSJf3OX
oWyLogtbVWcWBQA2W+5BWIdzZ0rxK7NSlXyL9nlnM9ofyvOCs4mK1GfczzZcbCRehlMFIaDvUikK
N48En8DGyva9f1NcptcPL4rOLY5MMqoJIVYpZbvpNBRSOmZhSJPOfhXZZPVGqYEGYFUlygC0FHFs
axKVyMNLue0wtHbwNMm3CYP1NPMvYEqD6rpqdMSNp0pMMJjzSfhZpnsdSifKMQ2oc3H4dcVpcyQF
gkFzNZz72Mm3puErrlo6s3YxteWqe5qVaO9GLGy6rtCkwcU4KaGqEAcMr5LNOmhhlEUaEuTcjygF
+lPvYoAZNS0Fjs4WesDAaqK5mFmwPUZKgbvl7328hCnxIr8EaNOXzKZaG/+95pgBv9l4C9HXOqK5
0InYRhHJ6ugrVT3oSXqkjRLiLopMa4PC+LCqt1jdA3QTcKfdy3vAX38B2MPponGCsU/7KsR/zjtV
TWSYcP1GMjNFka5qKicY9hvHoJgpHGajM7TJKb29vxogb5Gptjbg+VSTHu8KmdtwTPr8aB/9rvUk
+DCeH8dTHiGhB6VTGgWGhDuL4ED4+Geb5gOD88YI2jVq1HnxYnoCbCyF2uMLPzcq9ODcOc59dsoI
lFsGYuMUjch1GlqZf9meYHyhlVDuyxSTfpyqX+vGy47lucueH1VUXgBSAdI9nM696dlw6zedzsS9
4QVmKuC1VitJDNKiafCilW8Jc6eg0kwISvU58I14TPrB/5eHAWAD78/Loy/fCuLNuCwINc0OGDTI
UA0qdPx7cKC1IestU+0UXwH6uXKRbwV82l+O1iqoR7jDwVDiU7Jb+l1HcciKstfZrT2DR1DnxN78
gKeppEiNtFjYG2rSqic3XL7IchHf7s9Hurxcehd7PapVqZG8BzzePNz2JQ1Rv9KY0oBmbuyRJy2p
ycb14bQVLxt2dT6Q8LBlYY6bN7fLn2Pdn08JA8hEbFjexwqOg8zVcVMovlg6zKTyadzCoqBMpuOQ
QjRJWfEkO4njH+Vo36uQBJYUjgb1bmIkxs2GaB+HcpRTBksNXi6/1amiHW4zvpTVE6TEWTvcnp1r
nW3QxujgE4R6Z3tacTgRU9acP6LY0IY24TZJo0hEM/abDgA/VsEHLxWzHJIMZD4fWD6emEzg/vee
LfFX0jpH1XsCHtbsd+Vlm1r7cwCqkeXLMh/OTNilirBG/P/Nyffln1kstKsN/9smzcUlzX8Av7E9
hRRqXANio46m3h9icK9k9hSDGDBmu8zWH9yT/5p8muHQfH84jfuNtgSXumgRDzD3uPjFA1dkZFRm
E0ZEl7ggJ44G6ROSDbxuOCbIPDae/EQTckoKX8OP2XOwoQTGlPkpC4qMZkDU17mvk6prruK7ZgLT
j/kyZWvBor5FePvX4TbMyIUpM2335x+5qB+vH905A6Ix3Y7kmBlGN3CQ2va5C4BdtXQDH7iMNT34
HzTc61NthcqU81XRE8G8LM3TsIlsfVfbvL3/Qj5E5fnDL5M7C5lS7DSIPwA0r0axl7X+vQkNcnkU
GqV9SuzGNSxkaBYqTwFwRLnH1TQTj7buTpg5b02/LY4k2zkYfgIzUtz8cIWPNDI0wbdPqyi1rj8H
oHwx/eai41LO4QEb1JHKbfUL224kBiFFIoxejrDj3HtoOdUHuEg2p6bZWaoxLDsw+3A4UE9DrIeD
UmXBE1WIYmkN6cjbp113bTutJ+IAx0t4tiTNVZjGhuT6cYKZ/Cg4PERRetiHhYaT+YqOHC8z11cE
tKk5GxRUUDVBz8YzYd8SKVjb82wUYHKpCuFCMGnwNj5UKap03uf0/2pRwEJ0S9JgURsZEcY2OveX
VQ/tZHIyL+dJE7zg0A5ksnYtXgihda8kXy98arhJq8K4LZ8r2aRoqncmX4S6Tq8OpA3guNYOqC9K
WLNEFT9IaHy/E0dMCsiF0oZY2qy//9BcykHP4CBemoCh8repyhYb2sDTL+vTsngfpiTw37NlhsZf
jD3MrxcKDDth6P5morKOcy/W0vRcAt/D9RR3MbkuLCyD+GaU73DXWyGmPDK+DTzLh/1Emk7XP0kz
XydOlt3kkvwBRs1qiDVX0KwV0fNq7jIexyhUaN79Z2kEIdUjlWlBYx/IpK9+8xBjqrRaPRKSiyfL
AE+zUT8L/aNXdl/1zzhkt71BMNnL2hrSKBxRbteOmxS3JLB+eDHydSxdRGkd9MFsdtaC90PfaeQh
Bvzjz8h5ktXPHLmNiLWrd7eX/3qdVu0Wo1ko8tXLV7iYrIv7ML/q5Y2EFX/wEkcv0daIDcue61k2
Jkpz+fzc/+agRejJXaYc+wZaeXRCnA1nxa7ENC7RxaOleSaM3fE+AojVqqbqDbJrTkqnB0nVzkwn
4qY3HKraE25q99NOHixsDf0sX7l2Ji1l4K8Z3k/RZYs7ZP6fRkNqyi9OAcbtflgUw5gadigIvPYl
CZizvjaNRJTegkxFX/JWtUSRB1GrHeybNTJ+FHUJ13P3tniHevHZL8S/HRBQFKrOAxpaBNkt4V0Q
Pwur4qF/gEkGZ2vdodeS6ELWb49f7tG8f7LC4e3p7LKkkeMOyXjdTLq2eioxAq2/2uXVmxCUPqVt
zQepliqg92SLh5CqVOaXmanj2CywZmYb/nJ0673/hEAR7ClTpC9O8KI7Jz4I7wxRkMAhDiombfWS
hBWMQxyFaQth9jPRPELyL5GEmKUKqmwcWBL3Nm7V0GUYz5Ij5qJcorYoXdpqV+tlUFYqfc5f5ZRB
P6HGhxBNo3MQ9nGYhkVp+59zdMxZU/z6oo4B0MUaVkLcXIi1B/GbFNl2FOVEiIIveZXThYo78tt+
WOz7JK4B/iiP3KO6wmMIrZ0brC57kZuHSG+RStlwfcOJEoRCrNY2TPNiW0jJCcQKlJ4UoaXvkiN/
xa0+8c0GVoe4Aa5uih90QvjDO17yv1pZ2ebZdEdFtqztVrrfYRYIkgRk