<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzzECRl0+OcydQMacEwWV0fCqdJyrBMf5uAu4NZdl/u0OjJfKbbPg3AMKTBv/xg4/+pX/bLB
W4PiToIGyjjAid9OzN9oLSG61v2P7PAiBEu77XOxbbb2JNAc2FarsWMNddhn0afKXxhkJM6llzR0
3wwyOSjD4SWwLlpOuSglRUQ5m4QmA9cyxnw61yp46flExLHFh2afVBdg4TNHuR+JQgEfZu8tJ0HH
eC0cE6bgYp/SCTCAC348B5Iu0x5Xm/h4WcLfknJS/sNHyf4HzkDiCNITupvlsUdMlsKX2YDH6ZA1
Qf+6jH+TrHOToZdOQA3wUGjabBB9xDahiAZALUqFuL8ikOhwEnagd81DK0NaD3yOR+tSEqFtZnRM
J3E6tQlPl+pCdmkLZ/RmZpwE3Fr7tKaAFu9rNsKPRFmkBlvGGP2Q1otVFOTcnHvBt+9r2If/dOik
e96SooZI0Ix4sCwAFfolVhAj3+2OhpDuL/UgBosXT9rIsSbmzFtGZM2IROlbg+Fiq9ylT61uqLGC
VDijon/G/8YGZM+AgRmmWz/yu06QmVnbLuX8VlZlvAgql0P9eDPdTcbS8srDzeHSMzBQtOT+btbo
pkv5bUAlrlSgIDqZbU9qEwMLCgWOvdawJ9Qk/6tb9RmihqH3/nJbhxnG9TwwJMgUGz/8qXl7W9gq
I4fbwcQBYfIpv7G/TEOUmTmLvo72jsRzjgSWf9lSUBw8nGvbxE4a3KEfH6KwHuHJvR4K6nMBmNVU
5lP0f6V6SvVWLWkJSYh7/ayi+vK3vKeSesz00JvX+FMw/mv1WUVbl3Mg4eGRQcT0oQOpoN8xnuh0
XoXyuDjWShIh+7HxqMMn6pwby5ymMJ+Xx9JNUzgms11N8BF+ZuHHvAqvKcYdhiWBSLQVRSqAHUJ3
bIfGEyTVW2eptp3Qn3an+co/FNaR/xSG3sGirhZ3nXePZSXn7njI5dvJ22PmY5vkmSOqbqJX5hzo
gSH5OAHQh3qB7XRI8bSj9TUCqUUTBNZpzmesSjD622xGjdHPv86Qumt5kXqkHSp+wvCLOBK4phij
XVUzs3Zkzlej1nkIxaSKlXPYi+TjHCqQlh1YzDYkyiink0upsCdMGkFayf3iwfzTKcjLbGGCrIs2
/rPokvZG35MfWh6t5x7UmHP/U/jnA/a/L9FX/Ll0i61Vx5BI7siaBZ9Z1RtFSLsRGOxbIJE2EmJU
tS77rImW9mJTZWcuEly81Q/NVp0ZzuNyCLUpM0toMAirHWLpXmXDMLrMjLyuwwia6NikIgLpMgOp
jcHAWmGWZY40a6mxbqUh537vI0XQVbi+w1oAA86flgnBtY8rycgZV/yw+8n+byebVWzJcpkevLJK
cl73JBYJnazA4w48UMmmXTxStf3/s/vXdl81/A875OY5haaz4AKnAi663/xQxM/22PHlS3dt2Sbs
QAnDc0Bc/WdN+re58h2jYT1EpVuhoUa9fG1BqviCKyARKH9B40wZxkyrlyZUbLMUsLdBwKocbvyl
vIuM52YsqpiGCPmjRaEllYE3QxgyXb/4sHkp2cWj8ktx5YXKEWujl4jtosdece2d1v5d6y2vAMpj
Oe5WphO34S0YgWQD25ujXyBdpB/R4uzLXE1QoVhy0R074RawNGQ1bkNbwwreqw1FvPtYZvED7LBJ
n6fzpY0qQvoPXOuh4IS8cF8KbuwXn2ZCV/4Q47nHYnySWiNHie/C7j/TG69vAsTbynrnXv3REJlh
WJv9WuB6ncXyPcRErGGDVH4wR/WTgfJujNHhpjcrqcy4M1IQ/rrxA4tYT835bLeFAep8t3HybDpw
kvYjgJNc0KLJ4MAUejqtPkt1o+/eVU/LtHh0+SxExahPRya/8/LYvYWjueix2zEVKtgSb45gG17Z
CjMZ5sw4HK/jOMzyKrvsfOgETSh1Ew4hNvjCPUBm4WivoSoyoJ3TpJfRT9mwOmlc/sbLQX3+3iuN
WkgBHZX4hJ5KcWaQrLWP7iA5875qNLbCucN9vmxFZPlW/h07x1fKsoaRPRtZC5WMx3Bvfq0hILsX
TFO3t+JNt5mj3QnYe9YM55IRyVzhs7e7mEaKDqlIHI0ftJEM+H9OG5Cc7SQF5Xvapnbb9Wi7kgJY
gT1VuSbhfkpKwePtKghGnIsRmE8x1fAZx5nm5+WUt0B2Zctg/Ia/DNtUC3AKL2uBXhNOuhOErXP2
b5IED2PH6tp+r8SQsEcqYGdYwPb88eJ4SD2KkiNNWr1fW3OHTS44Fm/bpzxkPOZ4B0SV4/VJK9lV
VUg5lA23gu3WiNDO+/miGxDBN0nS49n37PygvjIgXfb3DKUXq2Xv3gTm2O65o2PCrkcRJUBUp7I+
QgfmRh+kxeAARilfRZlVipTmhkojrH2SUeftiJ3j815EuE04nmES02OiPMrgAGSaI816RZRzMlq5
KFvzCtZQLKl5Yzr5nI9uDN4tolITYp5jPjEYkrpfyAL99T5pikxmApQcsM50Xbt5xX2EFMvqXq5a
fZ/3dAhoMD+ia43FqzTdoqMs1vr12+yI4vo15qwfuqjrQ9xFPToR+hOW8B7LrvgWwdeUAU5zkB2I
1PiJ09pHI2X/5VpTKzt6Un8Kx4aAYiFagQupEjTBiBntRFGDi/mqAjDlJqClps2CYg3aZRwBLN6E
rnX1XgFnZ4bJ+8t5dOCBbFlcUNPSj8nbVN2qmNbsR07OdkwBlSNK1sIIFcVmv129kHssZ51PVWfI
ERgrFQm6EkKmNrzI/ndlTNoM4D81y6JkeAkl2SidTSsyXFjceca70eE/FVy5fVFiZZB+G529E+oU
8XLIkTEsY1YjA4yM4NfIx2QIVQ/+Mg8nsbgwwWl2adiVDyoVk25WoqjKTompFwLdqLDkTZLchdW9
On8sZgzO57jYC2pHjOmd4wr8ssBrAHSE/KEiDXK9Bu9Orem4+bGA8SJkiOgWHhF0WWq/+IYbaSkQ
84LSSEgwZxLBMivQbE2oE1/F2pTYcKk+SwKQ8FsASD7GbKn7c2Mc8TpCOuu3nCi2Cz9laHrgjrjX
Plie4ekz4PI1DgdbTkDsuaKOVEx8HEAfCeq11AxCwSWd4KOkdUCXTKl/qp7RulbSx9TVKEbzSrhb
Rxxv7yjSfKLBuceVfucxpr2J+5u4o8ifaiwanxxXw/AqdVuL5Okxh+u+UaM2jLizc/G8xo9u4vUT
YU73DuBvR046K8NzFpecvm4oq0V8ugL4qU5kiQ5q6BuvakPbJv68wmNggVY0A0vpknYSxEMMGPRh
TB6w5pXd+S1zMYCvEbHG3fGX/kKViwgGwZ/xaq0WPRj6n+h1qikFZJAmnZdb8Wr70Mza0meeXDhF
6axjOb9J6eFoJx1kfjb4ozrspECe4+4U29i8GgbgVCM6iCztehYaApwiiZF+K1Yvi/rLktWInCpw
+z8baKcRq4Bd0WZSMVytbKVvhzhhveZHijOgVrp38xKvODDFho0Tcl4JtZMB5O/abPrlnWaf/iyd
gsQH0MXRv7M++ExkaMaNdNBvZfnOSEn529HWw8UvKHMngtE/OAUETPeJN7MN0M/DdKo+47K5beTk
3dQDwrNi4pQsRJxHYPAtEI+cS99cI8589Q63k59Yy1DpeldC+gKeuzkShF7yCry6Uc5GceuRxyhP
Xcpi2JQ0G1Wwmm1ttJ96bZ/S4qiShWYDTsbZTnJHk/hL+doKUhhPanvAE37K4SAgMJ5jXKmBmhzr
ab+J7bMR9jzcOM57NpI55oTzWVzVkj45y0enPREmBZlor2hi5UkNdX8puJkLuK+245SG8J2W20ET
cscZEEjzwHhGoD1xGPHqH6UOLMUHUP56BdK9CYRBvY0AVjDyrj4DlQMsWNNP3mSqJ5lHBgizQv37
+YOCnw2YEhSAp1Zkr+ZvKR6spRy0O9a1evxK9M/jvJkEIf1zSIMxVR1pK58ngCawzdB+tBh2LqBs
ujH4s6nz5vBWqEkQ0jsxl3iPRQ8two6QGKOBRtG2HlsRsdSMKzdIY6WmqKYiNlYOG4BnHyTH3aAb
WYRMJHsYVr5Zpd5dNddqwdllz4tEhXVWUhnsc0lIvRhndsW4aRprEfDr11qBM5RYFqFbFfo6Hl8l
u42Fy2DzSGked0uWvX10RIF/iRfi2ExVfxBpo6ZAn7VbwyzYUoKvKcLwywjCLvG6EHMXd4fAg1r0
2G7vNb6kz7t9BwTiVkGWbulR7invJxuWLagNuvXHhYGDLbWVZRPmlpAgZwMJWH0vZHKF2aaoCG5p
QejHValesTbmHvY2ow0aovCn1F21V2F+etvjQpwb4BFnvH2uyQzhV7yJItVKr7y4i6FTH/PtRL7q
UyHkFw7sklA/bdyJIKw2u8TRuJ14l/aBONV6uEw+pVvjoZJFki0GOa3TYmfU7tPFGC30Y2GltKm/
LILj6tznQiS8th1L3ntiqQ+ZlPRP70pc0ZGf4AOrL565Ie6SrFFquEzckJg4G3D1bBq8ZTBH/ivC
WEkSBwT6I7iC4THBFMxvLw+3h0NH/HFFBFrAKqH4O5o25YzrW9llqB20Hb3BIM+5d4a3Rwakhilq
EGLFPMVMFqm9YtkLBIGAjk99a93nh66xbq13eS1FNydVW80oXDqRtllS9jUrW1OWqbjW9bDE1IAU
E6VyZ61YVGjXp1QSp5wImdLE4YpRLOf/eAL/HUCIohMhnoX/jRYDFtEBuN+B00GaARmLxQX5nlPd
N/HVW/A+QpclzS0wj0UbClViVnIpdBw8tqCG+tor8z5JtzLdNRxT7A075rwa1/kv5qa2FG/hxnZf
5nRFdIiuZJ5z1OER01aTquj8hEfl1itpvOxj2e/6J1tAx5x6qeHmZCp3JE5ivefq1qG/n9TlaaDw
r+WfpOo51j2mHvLuum7sFpvNNU+iWmzhGvryM9gB+v3CUDN5EvqAEYxfadhZiMzSb3J4LUDZ8x1a
CY4EQ68GpIPG3Wa5A5nn+qDsuSC+jWyLCMBPU0KCtSEFLiFzf4vhuyb2Noy4l163MPi9lvCamtl9
0ZuxcTj1egr5UgXiUqhKUhbEiQtxAhu2bL8o60ALdN7wedvEMu8C6oJJQmzUhQclB5krYsi3X6/y
uKxIEg7hIifGkDwbkeWNN4YPdsiLePdylOwxg4DrOdNfuws/YSGI2Mkd5E2oXdrE2TSjlJcsHxq/
9JgCymDrqvw0+wBUWTuz9L6Nw83dH874Q530RfPHbjZNoQ+QgJq7MmJ6YF701sbgQJlg3O3W25dn
ZDozMiixRAXuDPqINQi7TTcbUVxKh7sc4a/qKhfojTcryYrXR7LCv5C1v8QNzUHbNUyfVGBBNqpu
PjFyJxGEPXP7utZxilCBbc4byDabbp/g8fJkeoQQgImWQfCkOCarQdjnBMxYQIld92gHaxVAnkNJ
ZtpjfQJjM12CDIKCv6gvMBmnsGnBeJaiXTySH6XRZPZgHlZ9g9QzQ+zyqXCkMn0f5H3CCcb1Yh6M
H2wfBeEkl0ghyMCDM8hfHaxHjCSuvGi0czgCmm/uyYQ3RmwoCT+4QBWid3uqB09rADzMkyNY8PjK
ZMuleSWd3rRQHHnw8um4aDHK8dKccciVLRCf6cpuCNAGgV1hdTUjtUiPYM9t0PebBa+zBIoPDIxx
EyocqOmsKwlA1K/LPkVApCqn3qOzT+HLPbFDPu7ydOxMUL8dRGhKPbjmYAmeaLP6EMhF8OZ5tBvA
hQQ+zb0nPAt4C2LwX1q7hBr95DWkGirGj81rsGQsESNpdgtYkCIe48KcmmByA8V1Gkdnq7oVYFuI
9JCuMDkJVrZbPwEh1QR3HXYYKVgyFYvhnu5uHOBIv/5KwQlRMzQIbnWWsXeERZiEgcPTKwd0adUg
5M2XboMOkuQvjpAMwBB3ckyV7Rxel1yKLLZSTOeZ+MgHaXxBeNMY8RcGCSz2IkTsdpTTHkchlfsz
EO6EXL8fVei5hbTO9EYsyg1u+TD7OgC2GAJlEUBUq0978akpBWAhx6Q5JMcA2gs8NF/4zEcrd4nb
xmKquYxGkMsTVLYQOPK2kZXZ/1gjLUaODJeXLO5erDRWA2cPPIu+r7rb1zt+YoxtTB4Eq4EmkZSK
kJR79WijKDn5p44/XjGVdc0DdKm9jEGhMnoRSjEeVTT3pHv5Qh7byVMM5squi6kp1ZhOShxlfAc2
yQgOzTIloPW+n/MiAdtIKoBVK3FY5i12gx2if/xY9NZFy2/YUHm+k4XZ2815+2Be/BipD5J/OMYd
msW9cFykFz3AsbFj5zM8p/BnSoZ4gSQA33Ie3865VYRLJOORZZ2srmroyPkpCuEPapfB8CTQ3+gr
koL/U7gMQCmzqRFGpcS2ohndcciQi8ZX/gA26hh/pdL04FnraTvL5b7vMhoLnMHzodwEaTAgW1AJ
i5lqWAOk47sgAQnEqRDILTQ4K04WULjlC2caMyqvvQ+0UBLCRU6EPAEsDYrXueaKojtgo2/IPrx0
OeH8X+qYVebH2sad51yU404D1gtkutjVIKL15pYRMveauZ2DCPXKTcZvJ4I6mFv/gwcDtNn4vKpC
gR+KHXclq7VeSgHdC3GUt8xDOAH/tslE0bTdFxkySBlzXepRBsYBtud0L0V6/7DtUpK4Y/qV/HjY
ngqreL/8c/m5VW+JFo16MqUGs24lNG4L2RqdVo3ytFdN3XePZiG1aZ2Nsr0N4+KwssX2hKob/zo2
edIdQH0haHEceKR0Gn2ruEoWIhTmQHQK85+jchynhO9Zthal+DFmGEHI7q4Kd5jr6PWFm7XpJ/ym
BKA3ooYx+Xl/fwSkHtBrcx10I3vNFHKGJMd7reD+P2i/FOsSvm5w1xhVsz+YR3rWhKIUqATXmdze
d9Qz280GujbvieBtsCmAINAvrJHc7/4XqKASJ9rAKxZjOO8I90zTGT1IGFV2UeG5nVXPWIOOW+fW
/o/8k0GOd0J88bbJIOVbnUIImMAeanfLA4rphNsDk/UMvaFrj6bREqzMgrIaZ2uGInsbnUXlMWm1
u+KFDj/ZxKi2w9ifndLL56xudWsHufg0U9AQGiy4MbVY+5PeiaE7bNU+EgRZZaLh0QPdqalGR45R
DWYHERnOUWXd3U3pEombkIoSqhfeW9LjQFtIJukWnIXwQkJ2DIgmfBWHCeXc6lzsbG41EAu4EBAV
nV2xeD72Jy8Xc0TeCi5HE728dgBrijmUThcX0P7TtsdWpt16gSB82AZNVWUJ2WxCjaDq51TuRUo1
Pc33OR0v1UTBszsu+Xfmdrd0NYzBgym5Xm14MocKck9RFP+eRkz7dypMYY0oebMSCTManHVKr94+
VupB2hn3hwJuaFzp4wSuti3xpdZsEDSCQaas2+EL6xnpMuNYGEoDHgZKlYetu3JTrXJAMPfwKQ5f
D5LzyNyaRG1Axy4kQt7TvqnEkKO8KkSLSohwz5Kfi0TcAqMevIslqNnbAmFNJn/JgGgbHGbu6vxI
uvjH15CCK8c/MchwT0FbfRtEyjO3LUf29n2z2NWMmQLcyFf6Kbjv/GOzFP+gLt0vJzSdVjq1udvO
BJu6z+fb4ulXt6BPxI44kdULQ/7uDXr4/wQ2mHWgF+DgHpcZo6LkU/9dRocl52EYaxm8SkzL1D/q
p7XOM/+JcCLqARPVxLTQFJu50MskD0LQ4jR4j3vPTx6Waq6jh5MrL2p+RbXYDD/b0b66LFo/gNsb
UKPNWFBY0ESLSWCTk045EfEQZpH9RdLXBr6r0pPGm3ToZ1VQD4ZWgyNIT2VdnSfn2jzv5XRU/7B3
Bqx0rGlXdNeIRgdtkRDOIBKid3B2uyqCTNcR5CurtATT8ZRxVP8Kvk6O5aTffGde5Pw7j3aw4aNb
6GuQqnHc/PMRg7h+EM8mruUBEiMJ+o0RRAkSheSMTs5vcS0wgTXwBqWN6ec+Alne1pa/DC6je7Gk
38eFGrS4M9WVidwNG5nRODHheatGPEI9wR7yqnQgP2CbBNb5PLXvzI4lWhxQd1whBPHolRpiGYsZ
6FtQbyEvh0+QnS8kVsf84llQtbogs8N18T6jkBFY8CFmf3iW/YjQfl9EHVvoQey3a2raezm/YDPz
pw1A/cTFxy9NAPAxAHXb2TX8yYpzYv7my9QV+sFsgN9qD8AGqJafPCE52VCPg19R3ja28dJPAci0
GYNtlUdpdSBz6VAKnadgcOikjPEzZi3G5h2QEjWoSq9hyQ7uwNbsNUR9wA00yVb89I72Z3eVJA7c
M4fx5L2oDt+PKvwh/VVrBpwCYWlo7EjuRnMiM2hEDoXOLS7XI/RHOGmtXlxukT8VZWrq6Nfu6aQb
czt2FzY34GOquRjGuSj9kXHNEz7vgOYFpD1M8f63DeGBCGrZuaIe50yHSuKkmNGMDQyjY+V6sfkW
dZM6TOPX2yfD9cAXJRzvNRHtuoPCSNnUwB+gsSeAYZLJ9C8/+Yb67Wp9UG7PGOY/U23MA25scQjZ
1FFWGm4eS7xVvLtaLV+bwV6xRV5SkHNtyoVm//K99iD18JM/zjM7tu95cvt8Md8QnskbfzKv5+nP
6LyHu6AYEjoTKpE91dxkTxE4C6CQ6HB7XtLNLuujkkLOqfjXlsqk0EgrVtu3fPWK2igOWdXf0uaE
mSwqI3eXwj5AcdhcJUAjYPqly4a7WnqA8uojzLc5vAHU3rgImvy8Fu0G0xOGzp4mcaSc/3PrVe6x
9UijtpHM0qFDWxpLeKDKRnRTj32Q6ltHnZPeOL1C/Uj/k1gswPuOHeJ1a0UoR3y1bn+TlGMmq+dw
RDi+al9DWvah09p7OerGlTnSnkIGEt78QzZ19sdUIZ3PgCCBYVE4+rXUxEUhWZFe1lfQl5jdtPzg
0dxAzcJIZm6wT5iBMhg0rUYkcXNakx2YTTYlKya6ybFTATbcWtCm3G36rMVCSUWPki9ajsEOGYPW
hMYsts6xUwxS4MPpTGURkCNxWMPXuCJEPDTaetI4iTHkRN+3c1IMdqTFB8JpbEu9vthjipslTHsZ
o8AETFTXkmGg32MTAMGjEFrkeAzTA7CIUSqEIL+DxulWg7VQExkcAFA+EGEuz+ZawN5oG/p6BNmw
NlA68lnAmeImg/EDSjOwZP9OnbmeiYEIb4VkyqWr7vxnkjaM1DJMEg0nqTP/mQSH6tBv85d5OJRh
PEED78iYYVWJnfdZM1H4nwlOtBkuKJfK4EU2qiN8GiRhzqcPudKE7Kc28//go/4Jmw4cz+OJuIh3
A8WwoQcHQI5Xgnh/PJtNhlaL2EnPJw5RYkv6obt+81MWw1NP4jKUkWutpeqgDCp0kBe3OR/S7erE
7x5lYym+g/pDlWpVgbJm/xIHTz0c2d+0KRLgtVwFbeDkUyryITgQLsdxDxteh4//KFyvHMXt7+u4
clS7vpfaH3S59HzqopcAGsLVvZfW37wV06/wUiK2b9jSmKETTnuidMtWEqMusZMj9BOvck5Bb/cL
d3uXmkdhWsmElHb7z39yiamTE/0tNSP8yFCV48YV4NjCaBkgdytGnasTiEGskiBAjju6x2e8DVr9
xH1W6BpCCMap6GyjDDP3DW7s/mEaqINh7G8wjnXhbOAORsfcmwRWl1UB+EfkGa8Fwvpkn2P5uwge
ZPvxs4KZQingUWUJVpSBTm5A7f2qQcOxypS1IjQpyJfbkBthhl2DHxe2XkkC2V08nGVfr2WAegT1
gxpgvDQpeluxvgmnj0a+ln2c6WDz7eQQwHf7feUfG3DRxtO8lITiM623r7wYewatBFGJLS0xtplh
peaQydGBmpt37jJI2LliNfTP4sSQT1PKUr8EgVTReHqCo2pCdibnM1QQV3OVGMoF/7wHJLxzPKnz
XPvkz1upmr099l/NKXqxvEKZIPOr79Fwi1VxYY9eTYKZVZjaDYAYA2r7G1FAz02y/9tJdRlQizXX
9zxHke0dsl3FahAVa0ttbYCgEg1figJSc/vNj6rRMqmoE/Z4B7g0I9VeMDp3fmqYITzixQqTaqpo
WnZkGBccgk0UuIACPdEZes2EzHL10Mj97SDuNcOGsgubB0R2YkPzOI2q2e1pEE69vhlpHNfHx38o
egvuk8Uf8lh4qRJ1TOyNRqywVWPWTz3njrraI2QzgEApNoHzUBRMLWI1KU/pnuxHHqYfOE8FpG7x
+Q6lb+1zv9gkntTTaCFRgfDXo6l7ynTQFT2JqKh9In4KQP4f9cOdrYNYDKYwr328z3+CAmzgn+Pw
WUlh0TGCqZG6OnBhS18vH5QUb2EYmLwsn0fFktWwQoBwBZHXqd+zJXwpave9pjKdOQSvYTm1