<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxRhmqUhcJXeiWLMPCsnE7MqCjf2AOMQKU2FaryHTBnr9JEXECI7O8EN9LEMhcquwaOUmsyu
RKh/gTcxvCs5/Rh3Tx5EhUERI98/I7ssJYCns4WDytAx5dj+bq4cAAkCexpJ5iPzMNzu+SQo77v6
vqFyb1PGis3PBTg1sAZuh+F4ZKcHXxdpaO2HgyxK2BbV2AU2fLja+pX7e2C249OrVhbNUk1gMd8E
g2I6A6hrIQqWH6rkjLIIZhnIkW7yC7F29WW15RiKtFzbqVAH4VRZR35qdUF5Qbblo5sFCh/ydnCo
WSIANIMAK44NPs1bctqOKBYMM9UdiTzfbuKRLwcroTFzTPLP7uJOvf4OdPaFsQo7K7ohSdHxMth4
rRP2xmWoKYOBSaa9H9MQd/oxUB562zhpcYowyHVhhZSmdF0o1bdxHd19RPO2qFH08sS9AVvp2o2o
4NqK/5R0wHl73MwlpK7D/wy2Q8fTNtOaNKfXeeKMERZA3f/sP7QBPQI4bkxf+oXD+XVyVNh/Kn/w
iLxyBXjVeZ+z8+x195jm2auA32ipy2T6LOfHWxhRgRhGi0IbksyMkwZw3iSFQlbSoHSRKxr3VvSx
Xj74I3a2fdx6RhCSmcIZXXGF784XQdwCycfbacUz2uRtvmG4YvfLmH4uaz6XGPwoedZP2616jJ4t
Nec5uTkv9FFgG+4+NoWuPM/MM9SdD/KWmCpJ+D3ELzQbxkRFD65ZShLdpi6ZbFUjbuzMFLlwW3rW
nmgfsZIyy2XChUpN/qdjKzOObgNxRRl8iunMSfPH+bE5PUHpQ8RU3uLT1dKRnfTr4l/gfBBWLI7a
b9TaI0A4gprpSZYHpYHaV9iAb1rRrwgYvxWjFcgYKytyVa8M+YHk8tZ+IqV1tr8ivIrgtI9sRm6H
INfDDV05bdnNa45FBODJzfnPtZj/u3xVMo0Z91JSE0BJIDNV17hIsbHejOxq6nTJZALZSJ5iGGsT
phgf20WFN35lUoJ/XTF56Anp222ryRFeN8XUwa6CyfRdEpFtFrQ3TU9fXEFUqtZCPLNHiQqH6f6L
WaC3lksoj/+rbwsLIhkpKbn/7/isHymFdq7xyOhznNabwiEprlv4YQiXe9sLFXsLlm13JsDSpJDp
O1I3dbqLFV/L8pFmW7p8/kpLHZcWtrJTREDBiG7XVVojlc5jio+a+PcP2+20z0z2MlRIIBj+WKIy
llerzFg96fM3HlUaXlYqJMMoiZR3dBvnC6cs3Xwg8B/GIycli8+raW015p++niwhMF4sdQ9D235p
Cb2mhwP583jSf0kcIQyn09Jxpin5HNKgpDf5HhYuJaVqkWrX2xabQl/LEdQCsTzUPJ9cIkzl3u3o
iMm+Bazmloq9QLMh67iGocHIIPSYfZLMin63g0jCqPGhGnsaV2Q0+FJod6hsJwLa0qtYcj4IGnmg
xlGa8SjS6lnwVQwyGc2xgQ42Y+qcLJb7MVWwAhM/QNmA36lOjoU10GoRHN+pMy6aHe7VlXS5Ggfr
q3vUlCPhSIAqlrw0/EuTrfd9Fw7aD1oih+fT7RKU9fYtM1JZ2VJoKU03oIAQ7dy9rlLBfZhx3vZD
39FNLXe0uNa8sKyR/luj+f7f/iR0uPUrCtoo+pPUStslkohKYNcgmOi/4R4euxQEJlrGE3vb9om3
wKAIc9WSU3Stf0fb/o27qym+RUAHKpVf4nkqZ0NDekBLNlWGJlH7oq6VM9eeKh6b5XVydIqYP2/l
Ayzr0c+BWmxrpNNGWJZyWi6LlctgT8pZuXpcTLVcYitigqV4wvcGjPvWsonVARBmzOJtXr46I75B
7pzRNQ6uNlmUoTXPCWe8yeSu5maTdFLIJdJhkeB/4Blz+aRxpheW9ULqVf9DI36dWMtDA10ZvgBA
2y04V1ALkXtw4OUnmU5vBLr7ZKLNhcySrHOOmBE5FJxGHJOZSGzzXilS5VD4Qv9yBLixNKEZ9cL9
l5aBJfL6e2B7WHpTlvnStawAaaSUhPwHPvHqcuH+MfTM0u2YkvYw0I/QLtICd5HY6E9vwddsSLYP
rG8c74eS2w68ziU4wtaDKRMKmW1SGMSHgdiDwdzCeNnwsC9oiBaIswo02P4q8vECJTE5DxPODDSv
n+cfgc/qOFfLP8y30YhRX8wkYSBTEbmGbA8bA4CENNhRgZbE/MXogOU9oQDYItqL6uE9XDJQweZi
SSiONjvXT5vvf0ice3M6NmnRnX9z6KsLUzdinmiZMZS+lLt9NKIAVJWE2i3AM4/cz/Yr6TN0arQm
gdgQSFt3wu9mrrU3T287fkBhpeoX0Vp5IW4+JSRuvJYFoMKax8F+zsbZQiahbF2a8NUYYMDBz4wo
jmWt9ISpAH7PESJ5isTz9VzfHav/PToMYScCaGmOd/5OZoFDLT2sn6GKnueFpjBh2x5hA1mvCvSx
5KnRlLW+BZY4XpdXjQJnp4AK76lMKQ3SS483OXzYK3rLmYScyjEuERkHuYwbt56KBJS1Iu1quA2l
9jcjCPu0dMsXLa9L17JZ5yLoXbBhHsaXjLbl/VwbRlglloUqiU/SxaDTPM35Fw42dySZ9AAQ9+Nf
02snY23fM+OE1ey7TzrWoXOGi5blsmxBufvWhPSm3K3ku/y6Lx6jrbF3UOncQTs8GoW7waRemZk7
YGuIPo4Av7vSH23D5X7J9VlP1guNje0iJWBW0cvbmW3TTKLHki4Tpy2DA5aHY1zQZNcWcQluA+zt
KOFZzwDcQBE72QI2aOvHVII06tlVEC6+6lnODrTi1VEoYUDQBBhhmcYTaMtoag32JNpr3+F7DQIW
JMf3cWuspQ03+1/I+/o/NY0StvhVeHJ3ZS9Yw8kjulYoefFyHkXx2QXEJRKOJEkOiLhl29GKxDpc
y7wbMRe1iDS8PpQH6Y1sosN79Qw0asojUQIMFsbjcAzOePX7xLm+PndBVBiUtQpp/9/cFMCKG2Uv
Vhn1rJ3YiyeWKl4F1Ck482GR7v00Zn4Cb0e+DASQPxBSDLLeyls7DcnlP/P4ycLp8mp8D+692F0K
FPxAMBywwXi80jATKbvWP++14YZHiPStczqd/OwO2N4vdI0dzV9SjNyaUFePa+aTVXq0B2SMz4oC
Dd3xz8mvyQHS94duKbagSJ2QWlyxib6wjEXOQYm8jtR2ZlN3mjeN4x/DZ2kQQW0J3w5fHEY1wPgI
A3TaO7pTrMGSrEiHG47ElDMkilQILnjSzEKruZtO9wx2jLFd5kDV4843t7VKdaVxocIVE4vnEL/K
2898QyNrHk/UGj2PLpCUt9g6UfV4eNwTEQuEl+s18/DLNmtJFxUxA5xy2piCgswB4IpRo5obhnRx
e668Q7uj3bb4zPYyDX44TfIFLpcQahV9yG0XHLYG57NNjO3Hf/lNsiJKs+SZaS8ocE9YT/vmeiCf
lhB2m69vZ16g2lXdnjByZNd6Yqv0xaEOf8A0edh5eNjeTOxoyc/P4qcsdEQyuMDwUU9qwbF1L6rv
Iz+eAIqlbR0Zj+/1nrjeKgZzAlf0hGNPY0Ea8HFBbZjKYruruWE3tLsGBvceLsrZ9bPQLa3SHBM2
t+Efcx5HiVjEDW8m90IwkcaEAY4WQDTsqm/E2eEbRAPeqqlv4RC61PkfwLTyvSTveSE50cDH0CFt
5MmfordlhP4zdnHbcuXK+XV2nYKHnwY94rZu46Xp6Hhxx9p/nL4BQxHfXnwVMzFxlmiFVG3CEY5D
ACVTUe6cM6w62Qp6EwlegWBql2AtgPVJKPst7wB5UE/qRvv3Rnqxv9Vsm7E7bRrTgwjG6MqWiT2x
v7shMG3vUIPA2+iue+biZNQJmJyDIQ2wKzSvdMwXmV9UcptPLFxAWb0BrYI1Y26p3Y+QpoTh2l0w
3RaQGukF6xJks4SfpkQeTSE0Fp8mstrXJP0HXyyae/UrprsyetWmz+I9rlxBokfQTMCUqLDb0YxX
iiHe/gkVSynlOhqhaP5fJFDtXoy/wQNsHQxJRAYy/6yYDpvvzJB8UoRszBgtRO7FJXMWoU2mVVfX
tSTTq/pGm+PhGV/T+qn1s3HtRC0/SkwxTJDI9RUUAZX3k7A9n5SK6071+omXJLbt0xYPBTmTNtfh
ysCpRf9vQt0jrnOX7F6SQGgzQyYQnzDKYiySXPIV61AcS4jsA+Cj5sZxIbRDZgrspnBtZfrkaft6
9bw8vLpIHh5cXoXXmw0hOMdifJRQStBXB714cBPm68mX8S+HsbtQayF/7K+QRdN3OQe1oeg7lvn4
a+umDr98u63lvRCkaBUh5ts6qxucaVYKZCxygkY5uf5FTJNAdD67np1t+952rET7lswSRFkzsIzh
XqsG8bDOOptQsZx8QuWHxoB0SGQNmldOyFQizEVl62aCMkeM0kz8VvlzMizZeSEOjBU2hxWDaG4i
5s4WEAPJ5vUeIr4r5MguW4Z1Zdk1mhl1SwdNw38X7xIY8F0vCLp/33sLHKMCnRyUakfY0jXsfyby
IB9zeBGO8NbbgIfr1RQg6hOfTaKnzQnFoOYpcv68Z3lbsMGrF+ARUlPw+vMdRmMqJAJ7zbaOylqu
MFGKNM7hYAkwi39jFd5C8SERwZ/F3mqjmMeIYw/cd0znLykk5FU+5TRfnT7C/KUYkgk2qMGHxDzM
zVpni+dr4pr9SnLL0+b89coNnG+NRZEHmzLvvrcpxhxPdL/4oX9+xT5psLm3oczOD6v2DZdu+F1+
I8/IQI2MJMs/Yv4swosDEjH/39WhT6rvx9fZRuBaGVeF91X43N/Xac5vgU6Li3zOz3Z3o4x/dfp7
FMoE4tDlKoap1gQ1hhcEbAcvhYdQm7kVuN941Im1gL5mg88SxOIMlQtnmS3HEK+HZ93SKoi/MbVZ
OmlyDfWXwrlMCE8X2QxXIcJ+rAYpJimMxX1Tz5gphyDP/67j7vww1dYi/bd8Z2lh2yxUcLBJ/L2u
iTzI2YAQlMAYT1Vk9+EYwgpU4sFMMgAiUKRj+K7vv/EKOZq5sfFNhT0Thg9uoCiAvACFFMxE2eFt
tn/ESvSpXlnYMBNPFvDeCLLg+rlbewWPuvCCbjAAPUgcf2zjKsF6Ot7aRaQVB9OQ5rJHtYGxDCJC
4Pt4RL270sgO18LgA9hkTOYKRzxgfzNVC8W940HTfLFehfiP3yQJ/yzY0Gw2v2IV4dsGQsjotprO
eTy8wY3gVP8wVzQtbVPT/RfSUsTzL81dK+d2CTsnI4R6YTwzSyBAAvqoIUjXCHgJUosCJNN2i8+X
7iJzA2nMaRvJd7LiHIjiNdotS/0mqr5cg7DG5wvmkWVhsFTyYFy+GFZYQASizXQjSCZpIq7i+C8H
Nfu5LI+bGnFU1jpJGgXqBSaBe5bb+ktWr/eVOHSh3QbaD9dPX2DyNGYTyhl/M/D3o1kOGCzTjTzc
9cY208nr2Jrq+gM0d38L0IrCrEEI29JJaCRgMranbjcUEs4/SCtcu+srVDfkMNyCD2T4rfIpqMTE
Ugem2NPu9PCB1w6WhyDGiXu/vZB/0ZCChFZDn+JcaAHS4F676H0GT17fqkYLh7o8dzGRaFzawAif
/eKEc9NZS3AZSyR09WyPJTJO2mcQ1Q5IA7vQ5ldpyz96GZygkKaaZKxY0A/qLcrLYulgr1eT+SZf
BTm7mFDIG7CK26TZnLR1FuKQ6qCoxIPMB5oWs8z1bVqcPxJKNBqrKb/i8MCv5bV59sIhw6VBZhL7
g2aNsz//CYYi7wc2CVl9qn29ErKKpLyVCg7w2BzzP/VjyPGUwzlVfuEOJFuU9JR9OL2nyIwiUgXV
drFZW+wOaOZL1+G8mLMc04cbX2zfOcTJZ7dbCXQDtSr+vGwAJ4Rl0hJARP8c2aGQBl/ZizS2v48d
kWaBPFpxxXq3Uj3ymVs7y5f4ci7bh0w5Mc26j+ivImVpAXBFBvtNxT6u6zjdqfEtFjS6uAdOcs3X
NgVRq79XOfPsZ0+jiLqKceI5sZcjIO1w88eiz+uAP9KR5Bo2yVOJKuvQbMV2f+o11wShGSvm5+2A
OAmRZdRCgj+/gTJZL0a96iEnJoO3NphkaRDbsZQt6HqmfolEPLc4MRJnGnX4xxtPKkmHM16Dn5Mm
vFe7w/CEI8MJDYoBH1r1IRRi3+3z/hCKz32+dWtvpkF3i2zaqpA/c67iXk+9iVsu2TH48LGdzzGt
7Prr0uXYgEZoNGGFngQRzDSONn1NDc+CV7+7xM/FpkNbXF17efjU7sBSQrm0eneaj1DXbo8Q3vnP
7OV2lrrYP50YYCRTEO6KObfJFvUXV9efFNlTMF5Uqf1ZGd514Kfm/7tYOB8Hs/dYeNOu6y1/vCPC
B3a1Tgvso3PMjKESIw96skGOD2bd8EHKLSDcVRSIku4fqu9K43Fh2rSOo0sOQkESaHsrfXQ3b4Gx
QK3zIFTzm4ugzaeNeSmf2MUFgd0Txs9KM76onM568IGPKclRvamRegTdzQsHmYuqjnnPGdM7yOtM
v4QBLbvbdEfIBVarba79algtB9SWqcYzvExNyKTZXSothGi4NbkcE0t77t/ODtRN48t7DZSIUch/
cn4c3BR2AI4JcnLOIkKmnqaV1dFeZ8ZWCOhTE2MNAauRMrC1ugo03b6IejrArjKvQrO8AeGuovIz
qsjJjU3X8LGf5CUe3kpa/lupdCS0+Y1I6R+uj2zqXSn0hKr8zP0R/9TXxXXRZksRfkVlCcKGCnYq
5GUh3JRp5CJWiMkq+t8Z6CrfqR9KwjA3/raxHv19hxR1yvgfaQNzQe3BIFuLVqEx66c839AnpynU
LXw/ONFBrAF+YDXW3+PtHiXINnlWDlx+7T14dBp0kk3E7pSR22HXC3stOqMNW4T/GSS+WbX5UiX8
0AlfkbtvsgkYiZAeqbYBCAA/N0H/xex2qyg510+DLgG4bYV5G2ADU2BlJdw4PGZlTF0q9T1cTMgH
QTPnQvF+eX7Cy9HdmpSndL1g0tllGTfnQA3EiDtTl2VpXs2iL/ZFGyMYyq4uoEC99VAcSHjvgWTf
++wLeETLXbk5r9umP8kGDRmB/wda2rdmGbnQePT+JChFZdkvA7jVrdbglH5BlbNaCet0TBB9kaZT
Ej4H1JW6ms31sIfu2cdsEdCNTOr/9/KWAAVbEGL7WUkmJMYl1yjLefj36o2B+741z5S6yFWW9Lbq
HmyWUios4RZSGR2m6yFT1LGAKR8j2fnlukLoKFjRPSkX6jNoMN92u4ntPIdkO773TOk4fFSTwwsS
Svu93w0PJKJf9v5WeWU8N+y8JObdCEzJHd6l3fezkVZ6HuFIX89ekOj/xc+x/BUn2qk6S4vVtpDA
b3KJUB/5bliGSrvMV9M4Ak7K3UQvTa/K+G9Qg4VNVXdFFT07j81khbZjC5dBXjQfPVqBdK8OSN6D
9XQqG6BzhzwVaa5NE5nuLbao3zXRrM/7EhRpZQk0+CSb4tgQVbFPJaiO4uxGWgWv0zYj7Oh4Txx/
hdx/LfKcK25tYl3ztmjMB1mXoRWIzvYmSEBEZKPCJXBu9sPGf4W/56Cd7xw98c8Nw4OmAH0qhvpS
F+Z0/W4kX3kmM5pwJy2xBWtW8iALvzGdpg6L2xSpvlafKYd/AP2tJhf6NV1AHRXGkURQJaMu1HCM
oi9Bbjdy6/DhGepaQjwiInRRkIoVb1vj3ZqLnJrSwIrHn2bgxwSU57LsVpSourYttRP8/MytWwwt
qr1YsSMT+f66kmlIEuDCMvVpfg45kEv1KQYJRpPn1HVdvGyTL+PBDah27SSfZBlo7Djzbf8Zg86C
95XnKw2atTKnOVUiDnNjtqdYGrATY3/RAj3x+BeeYeqJlOzcCdaaDkHktKd7onQ8j8+B9QmC4kRI
xe1URHSm4z1hUGi+vbQ8SzT1SC7LWuaiJjv5yeDmJ8CR6TCu5gpxfjB09rYAR3fe26hzird+al7W
Zq1zSJT3JF/BWL5xrvXYr3YKus7zxAl9STGg8uEAx6BXj3RYpa/dOv1Q34GRceUhydJUggIIqe+r
OR//vQ7RvLz1DmWRsz3XtwNy6dF4ChV2oL6IS7EwlWuWVVmvK5l8ccEoWAlloqCh9bb9FU/B2cpL
8+wlOnKI9F7u0RFyQO3mCE0lcI07s+h3CLW+3+YuB+JfK0+arPxEUdyFD5GtytbV9DiHYDGNwk/r
LomRZvVHSEFdrjYC5Lj0qc2StO/ArGrT1twQN87sJDerIkQsbqyI9fQLyDAwVK0F/ZbCmHtQ9kwS
DFObbG3y+tcoyf+zOreN9jby0llQTnfFO/V89b4BJ9CkW4qlmP2qu96WshCgb6I2C4VsMwIdVNMh
8LBAggM91MzK+e/zdYBTfhdO4yPpp7hfO1spGoWTaQ1qovxxcPrtfrS77A+z84t+GHabJYFsk2tX
/+yNPYV1/of8LFXy2P9RLiEVQLAkh2k3vgx/nwnBxHzQeclbCTNpNoCQBvzy7GfswRODbHqOwipd
pTdk4AHmJ2L8knfHSIPUcAtI1uaBhU2tMtoX43BdiPilcJbPgBysEaOurmDa1uOrIl190vtHmJGX
saIFqXizLFPXi9vdk2qOlEtSBp+SruhUYJLc8RFkD5FOD9befvxF+fRm09Hml1n4dJIxRjKxIzb7
jalvYoqqQZlDImKGdrDYdbz0xtwoJPdG92aRkBrYE62n