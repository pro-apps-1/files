<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz5ou4PWujXfVR1rPKh0GowivflEFgl+vDD+s+e8RIwj1hAGxqzrbwNBSOWe2BEaVfBYXuxU
NlNIgK7xmkec5IY8257BcKEVh9D75ZvnRUdgiMEpC5VZphYFGgx9u/+oj211IjcSg4U+1ecyV2Fm
14WXTks2gsygDCcmqdacghrZbtEDaBU//gdTRDqA8Qm8NYegD7v0QM8KhJbBWybIIq5z7BhBGgoi
wrCCirrKy4wIn9F7HZj/cvSu2yRMfyEixQYjllTikd197ygnzJFolHx1lE2jS2KD4VbkNUNrGFhl
GcfhB/z1XkAmzFC3/xqMo/7rnYCAxYFWxh4QCaNe0uH9D5H8xXNI/fJJw7GiBhx4+e5RJ4SA696q
QOZxGonigaydBtp+PgWOy3k0p6J2HRSfMCLTiacagswPsp9vhR+uUfONw6JrxK3cz7DEdfB3Vgrv
YKZeOMD4OFCDlcHMQC6kJ33bZWWM/NnDU1cJv3uQ6j9SMKPt2mrgVigTAmVAUredWw8vSr67s3kG
7O8Mn4+0u0rbALBH93NOSssMaaAdsZXPJ19eQssbxO7nwrfVRecZ6NSm4JdX/oT/Sgpa2iD6Zije
ZnKGdhjKDg5CoNFImxLu8nO81suCGJ2ptlllTpt/wVaeDTyQwV5ZL0SasJbKbsDSALQluI6gAdFE
HKbqaiwp/4BCDb6y5Rz1H97fJ2/4qSuqSB0jdovOY9uOWNU/iDxkA2jYYyA6I89lNRLDEP8S+SiE
D9tih0l6DlypRRVzTZ24hTecCp2QeIt3ui4fM5MNZpFMXRV5x82Bjijom2mLECeSYXKKaPNgKHUd
jNdHLDRIkTYjswP0XEabjCJh6gI0YgnwjbSF+Ht6RpT5EObcFoDS+oeHvNZ8l8Ws8vYHOaSpgrDv
m2WlDC3FhaEAUQ/L/LPOhxY6hCnF46uSIdbWjp6qEmPEFGNSe3VazTuaWXhIzNFKsyZnvbbitzRZ
Nd+KPEkZM/E9WJhLu9DmdO8KvWdKdX1GWu9ArscExWqg5dHhoCUUi6OEM9SsxLs8UlTnZBiaT0Iy
/0hnMmC/fTBxDLnBCSGzDluuQ7Rq1B1MeXbbUz+dFKtFRxSf0ILQd8oTJmP4dlEUR5ls76QuNGhO
1QLturCPZwMHT4ZNuCipAXKwEpByXZXlNzSFRcDzcJ/7w0qP3v/WAeyeYAN5n7MAnfPmeGATYGjP
Gb4byiHAWIUMaPffYrn2GHl/cRi45QXZvigvUbX86Pilsan2bJV5YQjYS/Gw2Z8CIKyiLAUOcbix
8K4iApbcdy69IixkcgDZcIpyHRiAw9+2rZ8zr8aa/Mx6kfj+5mND69pw49UvOW5BKZ4thGjx+WCL
V0PRWDetKXTY1idSaJX7CMHDcbofyWEDNLcLakP6LNnvGsc0v/t3SD7MaefwhStz0Sd4ZEx6iY9G
/LNmofuYvrP0B4RgKAWJWcTcjMQKaKw8CjgT/aVoFbWd06opksrh0uagbl9Qoia9xSl/2osGqLpC
HjjCCOogzM2bPSF1goj4TZlLxE7q1/O1lNKEsVwZUt859I2h79UisDjmZDmfJ048xiIuku4ZZK1A
qNqEeeogfst0FPwCZN/jnBFhz54m6Msi/dUB5LC197EVQ5tFp5hulV5FwLmmtQ9MgVhpzLS=