<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwgYRDOM5bKQxtpvzSSbwgL38P7ixyOPdQ+u1oH/OvJph7f17ZAQDtPABhwnoqi5TeSXY69X
OPqT7YcWJEOb/qoBU1+n50pd8aw43ggB09efEDyz+qeHMhWQL/gZbk++5tKozYN+PNyC+0frcznt
j34+k8WzQe4vhMXC+5rqdGzka6d3VeEji+jYQTWopg+M26blp7gZpe7lE+raiv+KSc450mfJXWXJ
YYaLK0nXD4Jsn/nButFhag5utFWOxGSHWlPZzsowS4aVoh7rC/Az7i6yu7Hc0IXtDaURgC8sX+/2
PMjG/z9o4qvHG7LRP6OKA1QjLug+1+xLoayrv46vYSPE/A/fYPTDRAx38SJf8PQwMEtwunMDA6u1
GymDYzRsdUbzaRKoMeO65Y1N49InP+33IH/DD5R6s/04zK5ou9luwIDFjIBRePHtj+FHRL2NgCOw
5uNwwZ7z03wx5OPAS4Ph5qy7DRM21ACcqcm828YlCwfj0SluJjgWbbb1OWZNZu8CN/d+BO/7tr/4
VFsM3QEdqgJgqJ/MGK7mYYFhGADN3oW42q2atRRESNcylGZ9lGBvegcnzaQLXXPzCaOQY2Wp9Z/Y
b0+mQJ8z6Z6K6BYE9z1AZIs0CCvEx0rGDiYf0ax4U3v9UGRnBbNLw4ckX5XSksA1UFhQYzkTCTHv
K8gyvSSBIfxKqHYRi8Vn0d2moqg6KPmfly32PNYU9m/rRVcj4RSH56Ukhkonoj/TY9uj7BKGWP9e
bviqHw/QShqL3FaH8cG+yUbYgzL+sAvJtzdo+e0rhIQpQ00NJFlgdpAH2MwPvlnGVqBvFY145HAN
eGKj+qs1CAYZ/FaVBiH5sRG3QRLcWq5H4e4Q5dx2nLVLjgqM8zh86hkzs7XP591rv+TzEuR61rTr
O2CYk9ShHQz7HVSUHEJmUw5491uvomu0Ch4CWPMLD6coyTUR6qNI1GElsA0c0T/bHsShsDqI1k50
VU/OxFkGAK3yL+hbc2vodK3G419LeR/iIpPAvWcvA6DN1aOYAEM/Buohib8uUE9troFW+RTgDD9L
d5KJnq3v/xieu3L2bWDBYIS/I82upTFQDkH2a9vqYSNNwr7n/WflDAxP/m1BgRM3P1EEYx7Etx7d
wgYEE32aywKVOQH60FzstqXmm8NIiAbpl2TVo2k/6NIJGf/R1dM3IAEN4E17B6ixMNLq6sDZEtAm
6SgMLx/1p1ckSpXXUzcn+50j2AhLQmadpgsN/CxHUaKUL3Jeakv7YFBwsOmghEEujwS+0nKvLo64
ws6wdFJ3bNhoMn0KMgeY68BArt6D0kcE3LKNQoqrShkSzBPgNRjtaz8t/rBp35QoJZb5F/hei6LB
0lLxUb/NEWZHMdX+vCbFUJ/OydvL7z4FSdILN0Bji1coiEfR4BUKac5r7rcYTgQSZktrSF5OnH2l
qk/T3IHwZg0HNhoLLQBkMo0QluXbSuEoVd5VufVJRTZ9aI+v9vlJi2bRAepSIFFZRhTQT3OFtKlD
m/cNQDF5T0sS2IMhlbJ+NVefA8s1Jcg8+Dc7mO0G5apSe7q6clDd9UOVce6pJnbzo7x+BfmAsw3U
zWVWzWw5DkYai9pkMylM5r/UI76+if+CPBc5Cx/pkMESBJQV7yATIuvc90rwHOeWTPBmn3uoUzs7
vWaX+NQJzrpSUmUaHMPwf2UPcr7FqbXnRHh1/xoA+qYtLBoJzzWSxPGtsjdxmnCcwrKGZd4pPg9X
sKNdAFu+yw63vBJKH67/x4mfYCQxYB49GGv/cRo13CZBnG0fRBqFylgUovas29xw2P55gjGeEtuC
AXy4mtytQ6bmD91GhFDzPCoDZlnDJBs6DYI4E/rqxwY6E2/9mgimtFhq6gZJJXGVb47Jf99k5L+v
rI2M603IeSYjUidqkK+HZtdo57XMwQdI8k8Q96FvMxyCnSlAw/wRnTtAYfCbefXrAXcr9iyDkYW3
qhGDYNf7N/MFtuVVBZvhe7v38NQFzYswpqid2+Bxl98qFdAdO8QUNy0AVAiuAly1QIrN3me3T0Ro
HDnWTtbsw7NSSl8tcVPi/lhpu+R0pM0dlRKe6s3Oivl0E7gZrrOBPlmeLZ3BC+OJN74fJdpa0oNl
0kdn8Qb48tAhz1XPlTOjWS1ieSdNync5oVw6FnZLI/sp2w+kgQMGrciO/0rlNPRgOSqC+6bnd08s
DThBSSBCciU0YilhU7kU3Ua4E3NvpOD+W/8P/QSr9V0VZI+0PgDvTQmaWES5WqjlqH41JzQSXeyr
Tr5wM5YzgdUg/62huAlsKMqIa4e2vYHt4xWxqxRrcqhIEYliDHcdLPTu1N/nu9vCoRnSYt45S4w4
qainvdagZ3KgPK8dUJtWSjrA//WK3svZCZXcUCkogrivD10kWy+cEFJ/nRIypu1y743wq4gdNzF0
QwKFcx89IhaIXsoYrYT5navr50MbRCIMZE4lmN8iVqpw7k4ER5HeixAQG8eWFbC3zx5dYV9Bj/Ih
5RBAE98+FpKZSV+/ngKzO5rUiDW9JYmBZt6BNMPukwEdXOIFeZIfndzHC/3Qyc673/ShrDbzLylb
90zxUdYnPOxwhYKXDpMVhXRDjQi081jFDJrwRMPBNYULqB1vnrQ43hOHlZu6DOVp36keh7b05CT4
DMYJasO901d0EC3nJOUePwsXbzYPcr26uYjuv6P3WSovBPVOOjb34l2dQ7MftaqNLp7s6ThCGn89
RW4mlyGaSWUNq38E1o2DpmXQ/nc4noG+b3q21UScJN6r/5Hq6ytWUFgFS8YuMKR7t/xMz38jdX6S
UL68xAoVgINCwkqEZHT2G85EtV5T8OYQ6C4qzKs+bnjEgSuotIvY8R7vNq9PJbf53ep0YFSeJ9oB
ouswa7lEIBCW7+KO0G9E6+i2U04TETCgkqZ1JQ4e130qf6Oo59gpV9yJjRlANM1IhXUJPPG+8WFD
Vzz81hTigc4RsEVLavKMvyk8rWW/PP+qIvrEw/mJV6qc1ZQcHVhR8G/P5zI/i4vgHk2R7Qq8Tkxn
pwRbfRh3YEQ5YWB8L65Y7KT/AHI9yijqK4YoKG6kh58Avru=