<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwggUNpVEa9qfcZiN/eWU8fHoGz8ndkC2Di7NEVWKg2Fyys9yONu8wzeqITGsTiHidyu71+c
5lnRr4iK4kqMpu9Pl4WVGbJEaI+Hz+G/O6EJWe5PDlEd8QT6+M2waM6Rkd1rE+tWT9Zt1kH/Dhjw
iuzIhIx6hxB1wDgtpEmrKbWBweuUFleeYymPGlPl2D6hYgK794NEhZiS/CRfmP8V8NPXTMXHSdFj
K+IoZOoD9j6RQvlQB93pCtbSoaUfY3vu4arWJgYx5Dp/PT7oaH7susmnT9tZVcvQiNzGrq9MqaEE
Ce6vYcB/K2qfSCK/jeETP01PyER4RK74gia/DaGYApTOsZOlj9x9uzFcvTa/0Azb0400mNAQS5dG
G2EEAT51hOycOPzu9u4eHlIgZUEUl9ZEn0Yxq6YTrLUk3E7Ghye6uRxaelZ1XK2LmOPEj0ixNuZk
2l79llDvuuEL5RfG5BbzAn68joUE/bl8EkstFZNwW817s0T30FMY/AK0ioXBvcG41uzkTw77eUB6
M0hDBr+GkkUhCUD/PjkEw3zUvaI9T2V5lohVrfwJ5YA3IIGONX5CAdnYuWg38fLG/eKkCdQXk2f5
2RRPVQHu54cHyV1DpCHzprH257/NcQcZa6Jf6XIOuVPmKs/QiNDMj8wwx43+3R4rtlqUG0uB6hb2
4jE1maHvlZxLE2YEj2Nb5Z7Ajie4lYUXb2eL6RGvotLICNBHeHzuR7IHuM99gqAVCnNDpC345kkF
pty379BXUsid7pXn9HHQYQNaPuMG0vaht+Y6ffpiLtEJA2gFmaqz7Kc98fbc08qOjoFKcharivBd
H1BUzdTx277KjIaW8HzuJTShnQDEPd4SrKLyiiHWBesr1wy7o4wQ9vKQRmXRGkcLgJWblHMo3ANj
RFNOpT2K0vSZIsG5pD578BXlYrFmdgPeSOysEtY+AmkntweDBErKoVyVPUZL1Pz+fkLPfMhGvlz4
U3sJrHqS7yn6ZB1CxN/0e0SSmdg6WGRbzEdXD0m8WYRVy1jTZhwxTHYLbO2drM6wtwjkT3UDJhW8
Bs3/uRegebzh+73MjaxpKO4XXf27R46Gy87MmDwnUITPoVny68gWtOdegSIq+9nOdvEsQoa2vxcG
gjtRK01ik/o9QJF1asAWpMHTYenk1dvN7uQwMuq/9L7UEtbDXcqbSX6v3e1Deuuf+Bb9RgIQH7tK
PY8Y7Qm3ztYZxrQgCXskqf7rl+ntmkrfEt6VBgjk4+nasP5D/uC9HNL9PpiW9xUtZzK8B28FKMTv
lO2Z+7dfGgx2pAnwxy7DzEXgs19wViRr2MpEZxBHsBRpmOmgaHRnPW4id+mi8Qv2muio+PHuTksm
wEpD6rrtxREktPR533JN/K83wGzVH+AZM7Br8621Hq3IrYdexjdH92oVuM19b5NJqrgXSfNP0RRg
k9p2a0E/xrPqI/tpmDzEJzLcRmRu+x4JLUnU/CBacEa4PcO2bqkyWO41N60WLv1G40MNMssz9MZK
Xz54bw1RRBUSvxx0zY2JkyMU5qkkolA55hFZfqtRpHnAbbN62h+Y4IAfBmA5uo5K7vS21lCfhhdV
ixHdKG3fmmVNGLjJdnCfKolloN2Npr4u5T/31b0P4mBwfOSrkVinQRs1cLSxUlfcIH+D/2Nb5oqC
hPrLTLMGXCCIi/B462KvMaPPf+6wcbuLKTMHVIkQaPGgdTOdqlXRq60Uguf3+JN4KUxWki2gbu6e
ixLkIyY6OIyILuwSmmFqDC+WV3QMvUY7x74a+Kh7gQGlfKm=