<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwqVVjOGiK8QxTthzTfoblm+Zmw+Cp+H+yHQWKccWN/VN4RLpkXb/OgbQ94rn1Fk4uSBLOnz
vG0Cg3aUUMt4gB050c8QgGXgxkgVTkJrSkRrKybdS6kPs5pHkkC7DbAlsSt2FkRz82IgHOKR4RxA
BxmU7n+yXLtNhISO147Fw6wnzDV6KZ7XlxeqzK8LLKrY8kYW1Ux/+wyNLkEUqnZQAuvSVIpscHNw
an5kaplTFnScOdxNs4set5Er2MtwYVXb8TCbnhiKtFzbqVAH4VRZR35qdUExRg6Vd5rrH4VhNtWo
WRwARdEGNs2B5Uom7NLJNqUmuwuU6d2HEAsJ/mIRNbYCeBlwIBnsYz8qbYaHFq7r80QPHNbQMR7G
7gCu71Z818CGjL0Tm57tgvqBwkLYqf0VwqJpmNk2C2/Gm3hpsOGR0PfPOtNHkftqXl/ukYnkq2KI
PsTH34KVZW0pGV5aOPEJ+euh1LJ7+84lMFyo0lGQCBY3uQH+CEmuNPmJaezHuX0fpsu4/f9BmHb9
DOpjnEyfB8ebk2FkygQ0Eg0zazXW14mwe8A05rH4qJ/cGggr9RTAPY6xeoUCNQaCak0bWKHOK/X4
5WKdHFPwOoWMhFE/O1B2jaTmYSxzX8aFJYpR3r2RIMLneFE0Yla2eujJ95Xz5O6AAWE3iyrnGNjy
rb7HP0cLMSOZWk/kVlA4qLDcIMuSiPC/HWVd6EAIFnYqXaa0G6ouETvlvoovoB7OBYPMnX5kko6H
TrfGvKXFdF9KSQ2dnoOKPtYIJ70JnG5vOSzm/bhsFjEi4/w0tz0nt5egAIU0FoPRRGK78BOUg3Y2
Wb0e1u4q/zs2vPUkm9Sd9HQhqhCgVcvJaDNB6hgJb5FfITSzmP/gIhOSzThXNVsdR+VxgORGHc4O
dlRZOo+yH4BV3Z85IzZZOcfZz1K8HDJDk8R+HZKOa9uww2dX3cPWGZuW3x134GpDTOGhjV1haUGD
swo46DiCLoWDFK/n+nLYqRxbDzdxujN3SmEBUy7AKSJPICwszQUVziNFIj/qBmOboaHvavO/dhCO
g8riEm/hcTB2+dWBgIIDqc8m8tZyLsEg10D3rJ9zVxBJSgTuo95Ef0PzFR18942XaMKWpIVWvidO
1la7y2VTnZFV+bLs3ATXtVmKgIOr+GKQfwPZhODfv4DxO0wmEmEzTnWvkL82GDZKBufz3eEXB4aI
JvhtcFaL6BYjLRhoSJlMjq+IFr3qtO6kowGstFdJsnH4E+RqG+OWOp5RWeusXp4E3yB604NIoe5e
vRtWOK6xNrEu77yqyb6LZ0K9APCGJhO5IVX1rrp4Egxi6NiXetyuhxiXTEJOMTHyEUU6VEM8+pAx
0VmdP6RDzaBkFW/01piXX5/moQNcC2wowacY7K4higMOlkg5M+BGSVdJX5hC7xQSIEXzHgMqSLWd
hpQ5EuaMYimYvwVzwI/D/xepq0GIwmjbBlolEsMfRYg+lW8fzN3FNZg2qOfV3qVOlC+4lmXCC76O
vCXCnCHo2CdCql8qGd1CrQdB76t/m7REuu2IT9+6Nez4UJdtJfM7XLpJzpD2o+EkvkoAXYh6Qxrf
en8OeHDfagsrqxWcqr1WcuZUCXqL8JRgpyX2xwFBdl6QWJygZlubLKOlL0NUvKcnef86T2Vnb51K
LKaEl4wNK0claEGclRSjQm9ezC/g+i6h4n6AYAdnxD5M68Ae3mfM70==