<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsSZOprtnLSp3ids7iJMPvOH3wdaH1C5eST0fW2pnweJ71e4IJaLZzxuX94Xf3HXUFjVW1TP
6Z2c8Kb3LFC4g59yHrB/PkE1UCNevVKp3sWV5JbjHDSoIwJh3SLLvElzS/Zl+KAuB0QaSvEODm95
BJZQCQuNZ4alrKSnkdrWNcRNddioldq3wvKdsbz+8ZlSePImM2OJq6T9DE16d3f24VfP0YCGNT8K
a7gc6/LvUn1x6AaXfqX1R4hXVVUIMo5QMOrbluBtRBfmIH/AiVKpyhqUmRpWGc7ML8CIAdA/dK8s
bnoAT6fzfFVk9gjGIqhIihCJ1tOOaHWmM5iJmKRELMKQfKnWTG944sLVjz1JBbqjl1Qv5pEO52cP
hWJvFVew4p4nGZqaysy6sUsqByWt4w3ne1N4rlMZcIm9KUvxtR0Fh0hARoUQ7D9GC0360uQlez6+
UMfiuHhnjTz+nrZTK5CtWkQAe5n2K+KKUm59/XfFx22h5EDINH22RY2nUmjXZKHbfAGAJ/rpd1oW
FogkukhNL9pxhaNY4RdIU4ij4jQYonkHhhGN8rljd5DeFY2+BVm3sHr6/L9ZtdjbJFt//DYmae/M
4woggIDiurlmIL/eAFIxCqUhDFa92YLQGUj9qV57ZzrWGgFd/LPjUF+iRV1eSc0eyef3W0MBfH07
uQLJJ6cW/uCjgBvaY3CluAVyk5KAwg5cm2usxc4PDIdMPBYvOcZ94u50UilXbBhDIwWCgAKreaPZ
46sQ/vRzxX/W37kYtOOeD12u/4JuipC+UcbctWOmwHdvDP5vonVt82TpE2ODoVUmqOrcCQ58c5At
KEoziJMo9SOVHduIl2LeXsGZNbgxveltc5TGwLjXwHlFKEKRa/djgc1ZFTp1iHuOacv6ESUkc1f9
Li3key3Mn9Xny8sba6fmp28jIkeIVL7IaDYBc/rWo3Vo8IwivV3DofDl6Gbb/CwIwCDVW9NzKYaE
tsIDids3siXSL34G6FmNBhoPPjGEbNBvHLzSy5qS5dUwny+Fi915JDA75tzjWu88v0zIEMQdzTV1
7uQO2tU9hXBr2q1JyBDxLRokwI73PKtCREGHeoC0Pnyncn/r6tTyxJZ3vlKUsyDHFYzQ13gNd6U/
tTLDkYNX1rfGxW94SIa6xmgrMFe+TcZFasI2pnPH9AkynnhCJyyN5mU0P5nma5H2uCw/jhQQBuH/
h8BcdbCfTbJcZcle9INeDJsIJ/LzIuDupTYvVb9W7D0aomiolSJdUXNld9ZUCkUMEitEKyYOWPuV
SaFgH9L0SMTw7Uy9N3yXEnn6Nwrj1isCQcOJ4Kqj5jkKXSaQ1CVf06vVDLy9MZR/NCdxgaXTqxN6
IbUR20FoXJW9cqsg8i6Q6YzzRdFQ85PU947ZJedvspMYlt9Wuts0IUdK0OMDo8qRwwdQqgMrHAV8
xeqXHClys25BtGeJ9PYhpNDjc9uC9QpZJgdvEttmilGzcc1qHvCPbqmVJlm1iIBbY5ds/B318lpU
Ucq3jfUp49gndhhzK9+5cVM1uzIInvdaqyhFEys/opQq/TbM6CZ+JhsG4rAGeNQpYvNL+yLXR5hk
UqHP5DLdJO7x+gb0o3zatE6whR3LG2oC3SS7Tk6SCrOcKC9gAtVjb40Mm7DEDl9QYGKaG1veQwpc
p2kk9o2e1SXqQfYsZ+OW5Dcd5XRCzcvLI+6MK7WiEnXf0kpOsbJqHXC6bka/w7DLIVBx+e3sbxfb
C1YVeBcYpRZjni3UHJhd6cEqZE5DK6oCL1ypVBgwOpd/2DNryLH1NKZ8G5gIQl/ZkG4xZjBaSl6K
zD9h7ndmP3fbHWKLnbJNCuuv70OURnFLJFWiPe7M7gK+uslz68RVgTnfJG017oFreAamjdjUTkll
d0Uf10HF8pxPOa7iC0yw8c9gI7fDWRRnUGry1LWvy+Kf5A6gEPNJl3EtjljlJjXzuIxjot8j0abe
M29TH6gWz+xkuhrLeMPKWYeg2o6cFk8w3td97tGv5zpwrman9A6CBrWf99AI7zRrSJad45Ee/n41
RYPHfQ2DTUg3mzs78IfAzGhqe9woQC5Z6ao6k1kHjv7ldqGqMf5FBRDkKrmROGInK5z+iaD9vgHd
a6V7YTjc3azA9+hdsifIMa6SwM/xh/0GkUWuG8Mq3jYAtt1kX7rjsPlpP6MegKWLw2v7QgM3fsZC
jfRp3Zr/fRvVWUTn2MKJQvm+YJgcbmA36SV1htmx/o78w6BQM9/XgaxDqtoCgsdA18XYDKPXl5xG
vCWxQVwhI+v/mjff0equD0jeN2QDxgE8Xmpj6KiBnX+GQKeqVXSL/zN00Gk5w9c2ZaTdBRblPLYY
0n/BamLv5FcRtVmup2NMR8jVjokU5EzHslYRaJ9wX2t/6el9i2FZYVQNOzZuQxchsPpZwBZ4lvCL
uEUs+QLDclG4umEcOCozDI6eXEoLzRQY31aNs9dNekG0AxE167VaXQBsjLk+zPKPI+hA7lq92zuH
jKHUBnHCvyTec53AH+UR3AOF/KUB5os4RF+3/UwETDbDaTpgMJPAJh1rWbc9z4CB90inhV3q9w3G
9ad0iKFXxsXujdbIpU5zjWhc66T/9kOJt0riurUQuMX0TLLOLM7hl+TDuBce1ZvSmMxgCS59UhF3
D+2vQThC9NdjgBO2CnDm9I/g0gUWaZIZEXplUXbuVhSJzM47KYycwTtPRsSzoQK3FnRP/Poc39DP
uTKrEFy+XOpc+P1kRHh3wtwN+tP1QcQ2+O3UH6Kui7m303jb6VJiQU90JFJ8hbmRhtZdNO0rl8Cj
HNeZovpJX8GqmsUpnvdAbohbTLlRlwrDxCuQ1N58u20F0ITbydM33TdDSpaxN/f3NGxpB4RqbcXH
aCUfdzhVqmKPAvGAD502arw5ul+C3qqkeINbqztwy/JlAsoZy665c2DkcM76PIDnkLsO9o6OYDbB
1wWu7spkl6AK5i3SBKN/s8G6NOkwKXDEMNw35Yzy9Ya5Y40Wd9Hjxl+EtQ4kmrPigO1xGeaJRJCp
MVtHf68nJ1byLEUik2DySgBPxfMYUqIwJnHo4DYPiXKw5c1ebVEmpGa54vTdxShdGirr8Onlnm6Q
523eSdHgB77F+dqArblnHonky7BsoZl2nzxmJ3z97fOCZwNt0uCeBeAGgHxa3074j6JCs4ohnXWe
C9xHN1HrfDSlbcjSEj59IXAi+asinD61QXIgRh9BZv+ZtK7Y0gnqwrwV0jDsrUWMv42TNBoX9T9+
YvIv5yKeSPCBMC4gDPVXZc4nMcWGBvLV87F631vq24ZNgSB9GonFWGHRsHNRxWvUtzCdASS4oPhI
k/92bGMccQk6Ns0f91Yg4FEmsscirAVJPryK54vC+obGfVR4K1G1+rr7WQG7PEARGx9XnuZx2ywu
2HXfv6bq0NV/3VF2PM6jqFBKO0Q7q9kLleUzr5qKFmRSO8QqY2CObvmcP/TMLhtjLqyB9VxM9KgK
J7lUR5IxI3MoCBHQ+XO0nxA1dM3xWYcoVsztalY4dSuG6gRD1P852PVvH/f2pyI6CAn0A0Cvh/QV
FHxkuR3jVScHzfbng0XY5A01oZz05kyczPy1vv3zoijnoW7n22kB8YR25fL1VhoKeay5jXQEJKhd
U7baOdpT2q8akl5pALItFfCLP4r4wFLE+w6eEKQYCWsSZDv7xOGz5wakzz2OhYMkhdkQEK1squJl
7Jc36CPGbHzvADZ7kOOLQVvedM5Xo8/z/LCVp3tsn9m4QpEBIKTtH8AXESsf2LmxlcB/s4j5chCq
ndCkRCg7wWz93Tl0g9AUCv/OdpxtTGfCYhMAp6ibQbcQ2LHTKlqGgH4gam/7+Ph18MFYVOd10oqS
+Od1yJvykqthTiDs1w2AS/LvgeLAvVQ8Su4NawlgLMY/PlKk7MyvrwRcpc+3A2O/HnSsrkE2XlJW
BGbh52Ozsictmmk8xikizHo1uLr9Fe2wpxsso7TOEEyLy7nySgoOniwaG4cc7A1o2saEkrkOXcap
FXcv0oVtsJYnNZkAoStIL+73yBCIaG6TJRyVeKVvkH6dGPb7nnSoCRZxDksKqbcw55/30yo2A09r
jVFfcANzasju2fm+aYJzyOmllTDwMlF5tcIA7APtawGTZsYM2Vq1uL0WtoGt9xgWl1RfoZYSO3Pl
Gz57X7Z7WsqExJRtMjU3G6pcV8hekYTHjKTOtrN+3duZdIe8bnx8GaEDV3+SnPPEROHDdQMPgvev
PJf18ycGOYcB2+/664+Xy7tjyqH00jMFAybu5hxqTTrffuPr9PEbn5RL01EGjXfV/1IJfdryvari
6t1mXPHm8UQpcQXQWPJMuUn6YNVgDaSct+oqt1M7LwtLpu74nBB+if0b8qUQIKwI3U9F1d9gA8Ki
i5NSKgKDz63tiWNYDTRQx6lF8UOHoGIHj+uTTKAGal+9oI2A2VTh1Oq0b/g8fU7NtU4oirhpYm3d
XME/ZNqppnvZmW52GBYMuBv5YyNVevmMQc4APzdMeFOPsUvuvzNiXWL3ESXcjWRovbXJI88xGnOd
qToRUdNxyL+E4v6tc50oqwfa7dJzVKfz3v839E+R45AS05USnTd4Km1O5Tg/vQhsuMLVRmmmxKUk
4VERxUOPpeNlFkYLplNk6pvFkqKIZF53yOIrDjgxthhopUt1g8EjK+UUEMzWFabgTKRY5LjIHaLV
oGzseG0BP/5c1yais61TVV3zcPIEpag3zGC/Ai97mBFug4fMnvcTiwFOjXVVBosuhUO5C/16SBId
Qmt/kN1OTpyuDqvgQzRaRW+CLlPeGM9g6ju0T/8Jmb+y82w3byeKuIB2jWfVhv3ZQLUvcI4qgsHP
znkusm1EgBzncowT/iCoMJeNOa8KHV0EW8rmq79yeF2IDj1xdVz3usm8Nh2cI3+eK7Ufy1BB55DD
orqhrdetkddt9LKj2gs52+9mhpWs/lLOLkOX3szOx/GgX8g8E3wGZAG0BGg8RdnIohkKiOH+10YJ
LEt+c/zFjN0wSR3d+1VPsS3IS8e+If8P3YABnbawlA2AfiGEojsind6WlTR/yoogKYV/e+SH7zJ9
HvhsW6hwBmhfWgQPipcwGReZEnhqzih0tOFU44c2ZjsfDPuGHwV5R6c/kkhL+oO2flSAztXuwSjJ
Ly/At64kmU9pk1C/IF/Q5IF5JeLYHk+MzR9EDNJL7Xnu6UQpuCA/+LXEBvOEJ7WXKAWI0ych3uhx
EiamskupxRKImsTZEWo2JZQnfYOqhlwqJ/WSZ5FR9yOwZ52ZS3MrilOl017ZGQ+k5P1S4vd1xji0
b63divJ/umIppyd1xUGQ/Ufb6x0jVegCCFSxCQuHZQyi0G1bIpwAYd1oPoWWvQhmqYfLwTzZ+URj
9nhkUeuslvoVsi+d04RSJNYtjKOcjCcJJoiKOIFMz839BYuDFSqjY5X6eckZpM+Bo3KnYqxVUEHq
Be3rmyIEVW+EMvEzFNwVAQfHXnXlSTbyDKUj2COeGT5Whnpwy3O8gXZoed0xVOjokOdTTennH7ik
kUOGyyml1Dywa1VZDB15fqyziu7K3wpj4+SXgfPNK1DfKqxqCvZckRIxhGrXXRu50Uw5Gp0CWwb7
wkxOI2L8lVNjaDyRjSMj5vK5Czf7cOJHOb8XYxrKAwQMYfkAUkWXX4Ns2IcM6TNbd83ck7BZnv/Q
Axi1kaEafdyBtC700aPbu5j3A8WSnt4G8kvUP8UxmOkwnwp+kM8wQTVoXpt0P/XLTvHgdb9B3YP9
VCSGxnetAwISFU/IfwdOtVnVE61rnJAWGm0Ovja1sEEkGwHo5IsLpcUCx4e4whtkJRVR9lQn0YBX
XXNqSK20xczTofraSKow0DUEk3dBAb4XkGyVzsqg9TzRcIcsp2/bFgkuf5vtZsM/ZJjgoRhgvrQw
bZ3ilxkmtqIxB64TGmcHMSIAJq/y0eHeis2fL+/Z518w62G7R8UCYu8R0fUKn3GCOD0m5/V+PdCe
LajU5510wSmZJymr6hWiVVhxrVXF1cmd+TTD9BsXOU3uM9pvwIwolGemOFl5YEQoX6xqODWjpgWz
hV5o/hQRn7/ac1u8dh28gplfXcdU77+AqmpEwqpd2y34cVbDkcanWNbsE8UCjY5pnzL27FpMQNT9
QEm6J1ewLeYtvrClmAPAZWJ1HzwtdE3u1oTj3rGSA6OIKtZOE7tmd7cSbkqY31kvTiWh636VyR/1
ErvRXQxktbIB8romMUcm4uIzZbWb+k8+3tkApUIC7lV5RohFqgf1YPBTCcRMa6Mt+MTYK1VQe8Y3
h5B8evjGKAvnRXCBZf3GbSSmWsfJ1nx72/iCPkBtPE3bV7oGd9w6IwFH2o4Rf43EU7mX0UTyVjSH
kEICiEQNNe//OkPmf3v1A70hRG0jpac8oJHPv1aLI2Jp+DRzP+e+ZL3VP+7P9lh/lZ7Oy2teRwgX
YjZ/dlkM/5LLe1/DNfhoxTKk2b9donhzbaU726+RIdu25HoSElTTa78QTM1OcIJTJfNpl4wVC5iD
iBbpRbnCc+YM3FeSw+VEl/B+71xbiQhDGSs9V9TnAVBASd8jedP9i8XlAMjLh5+BgBn2ER83nqrM
ooIoq7CqZwcmrjz5JuFatfFEk+2KWvA5L8ZQtRnOVVIS4FyrQ/UWCLmTRpFQGFHO4dyLXw5+ZLZw
tfC9ugKj1wXykAtmZzW7WoU9Qq2z1jBLHNmIW8q3/WhtTrgIEMaNPV67lGFzE9LdeqnXELmuOEwi
dCQvRTk94djqdmjNopTBMWtWwkMh1iJsl5gobvpkyZKSxQF/7MN6L4BYXkB6uq94r/QxFhnaVLpF
dyAhBdWnJf0r4lI5FsLFXVa8QV7AlzrL9UjygyPDOeK0stwmlBJ3UFALqmfgM5GHTlFGr1cEPnYH
/LP1vEpqyERMtpqF3kWS7VosjXsNn8t1PFj7ZyvkgkwPkCwOzmZq6xSbYLESIapRXMIs5HhFq2jB
FKCxZfscPTvHj+9MoCWHvpvIoAqT8A/yE57mdiPuEMpC18Q1lPpIfGr9cdgO23r8K8yp0ewOssx8
taNy8zB8m08nrmc0j8XU7Br+0fyxXOblGh12IA8Onj9OnVSPV7pSRPi8DdRo6hRNo+A5VrkM0A5z
eQynRjZMa2zUS3SteL26ROgFJ3xXU2KhVxd4AyD+Zf1IHNwnfUAa9K/chluhPzPeIePP9qDyKzMw
JEofN+Xbsx1HnZ4Dpr6Ohd1j8fv+sXKqoRFxHZ2KCSMpiLkrInEzy8Ml3cK6R5/ekE47EceGfUhW
bn7l2L6XbNdHkXXwdENMntsR2dJS/mrfYYmKZYBZ74E22S8m55lqe1GX20Coi01+i6CerLb4ac79
aSs1mihHmF3jyahRJRZf8qBO0X0lgZKteX7n+tpNHu8WDeAUVtEISUXvb9wUs9BJd/XgD4Nn6L+6
ixpCMyoVUPjImCb6YODS44u3KLXl1hMZG5RXPf5RRV9bBVeL/qcVWIbcOmgXux3cRDtSkG+HksB0
sfugr6NhYwA0xCCqVnZ5d6je4rvkbiPwhPBB4By4xcc2tRXqcuttAMh61sh3Fxxla/ls59/t9nP1
uMJNB3T+TwXKqiN5i14hSir9WMbMDlztZzsVfDMbGNzh3SybmOezFMRX6JuEcetSy1ca2Qk7u1wv
sMAwCQNlC1PRjcx6xqvDGThGYt5J6XS/qGq+paIgkkRqWGjWpGBCku55xIksiAyiyz9GAl+xb+mA
argsWxp/Bq5Yy1hYh7/5STGb0fVwmVQlLQTqZY/ZvQjRkvvmUHi9Iv2f1NXAbbwAnrzQOwM9LHyI
+aQrT8/mMwOB+xVcFTckjLDzpw3W8CK76RreMayNm8ML8Z3ym6sSOilvGW4gRFGhsT+OXhjxg79a
r00H/BBA8I0kPT1p+Zi50skkjlk8ZTq4KlVohXcxX09q3/N518kxhRbbO82cBgp8z4H1yE5pUAIZ
2f5K0ztHgmVi7CcvRXXEVexVOanQxWpq9E9q2BrtLR6K9DQKQEEInst4XdIazDi208OVG02it79A
uocq7/YOZCPS9DIcAtGSz5lpHrB/A8+tYG8NENiKfp6lKvmQ+beRqelbMzV9C8kkaAvFqyhD0mTq
QJsqLC44Qi2auSE1b1ketVT4Esb17YI4+OHFJHfdiCdDH1YVoV+ztB8Z3IDlxUTHxegvAzFsshkq
k39C4EfR1qXxMQ/YnQcYSmdZRJZ34rlFyJyACBujl0sJHa7YqsOssQRV9YsGwY9KybPenuD6bIYZ
yhpOD/ZVc87G7mwJHZY153wpZ7QgoYhrkJYCMw28PEY2wtmXR1HOWKPBejl9IDNDsw/uxzn1RXti
DFCLwlZ/URZ0ybIgmrO5Foeb6G5A1WRRnhzGTHFpjLo48gPY75Qge81mR7x8PQQCJcJM7dW0Lv0Q
cXt+MBL2Evx6QJxyGkYtBHYyRjZUmsMLbmX3R7K1BNiB2PtdUWgwZCE9APBiBNWI0Nc1kN6O03r6
f876HbG4NY9peAIecJkt91+VUdthNtx2FgmaybxTmAHBja+HeZH6YSArHdQe15apcciV+GlLRJyJ
M34vthXCs2fiKmO4fPt23ndGTUxDitUXvQ3QQ8Po+BNIq2KP4Cw6MvxlZsuP4TPfNqSeobn/QOKv
zFTw/lLRPCY4q7sotrXSQ66by+fOf0VxpcDPeHPpZ++yCVrE+pYM8c7NWkcNGfllX9WHPSZp3CBi
DIy+MYdN+61HLwW83NiSARbXpqOP/Ta7/gUZIj09wN8DPGKwP1vrPpF+nifPBDjX99HgXJbokwmf
H1Y9DAMLQfGgwue5MfMf+yeZ557JX3Gz8Vc6MlYFCxE2qHzR3XMFJ6hjutggFprmovL0y5U6irpP
+6uGeKTM6+9uGzFbpZtAprSNbjGeFenC7L2ZIKOFTzTq+wLHIeIf9JQk7XJrnURB+VjmaD4TASQJ
IXW4qIJDr+wdoiNGuAoq3GkOntkvkZJVJK1qdFcrnwXIR1cR8z9R/zKTfvMDvHFq2dHDzORZW94j
feF0MAycEVTvvzUIFJJLvD7xQEucLY4HrkFIj0PVAHtgGkqPizIbf7j9MNZ9UCBnEfGiMV+EosLA
irGzXIsfeiP670M3WaPzJkhHjZr2Zc0hwhRPpKiIXfkh+2/1R4U5LFKWvC6L/hgXRqGFQdbQnElY
/AlGgS8LPZf5bc+DXlkRF/k8HkqDJmBBTayJepxZbKd7EjvU6UbFmGKJMpdevmIKnAoETWu6FdtS
j9KzLmcE3qWBqGPyJL+o+EXdBIo3oFaitk69zKQV3zG2lLvz5AnvJ/e+clBAKt7UQ0Sb2vFUFuVd
o24dJlNASaxbw07/RBLQRVRoWnu4fEdi/Anlmcz6sgZW8Laa2AzagfZfu9JO8hnoDZBNT5zGtv25
Hd9NOOPB4EnZfuYJEu64Vz/b21JU6+ShTV+VLYesycIVlOZOmX73/7aPSbrBJ1Zim5bV4ROWJ59N
Goa8oDEA3yufUspCNKRkUkCCVkQH2bjdxYX2PtoetOm0usB+uyeslfiQBFBwDCFXh4AWDizW1J7p
aaLQm40+3h4DPLsCOg2rWeO3JEeaza3Ai0DC6zvHX7UDMrphP4SpG2MTtFUFUycqGyhPdgQH9faN
ACS+QXDFPOTK+BGH9CfKi83rR4HiUxwYhTXsGry6BMeHtsnq2dXVM6yBblkDngMGEq8Qo1dIOzl5
VsT0jaftL3dk83T/wkTZkBcNGjWS1HLoPpWZQUgsiqghMjeCYDTDPHRQ/AZ4g2AJUz0XMrglnm4o
Vi+g8a0AW8BEsjiDAPSjyCF+iA99A8rclosGXhiq7luARj0SSUMOGo8/W7q5KrSsLxyjHmwiYujL
44PhqsfLsrebLPBNc4QICUVuavQFg9b3e7K5r2gCEF6DGP5exko0n16FUz8ef4zSlvGkWEC=