<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu9LVJcYrqK/kxle6jSPFV5WdjqwI37dkljI5CTWgwgptXIgclyDZVA1YXIIACEpl1dFZ1L1
VxJbu/VznU1s9jGuWUDNoXRd2wN532PPGojM4FnXFZd/69P130q9xDugx3fzOtg/BCbrb8TVFzuG
fUXOqHDlsFC9ykils4R6tiGU4lOgQekIY3v9lL7Sj4l99tg4kJf5YIfBX/GMfodiXJKK4p5g0Blg
cIYgrlmoy/qBmo9M6XWzBMBqK8T/icBJkmPf3gpUzsowS4aVoh7rC/Az7i6yu9ThWqpJ8qKpO5mb
cPSSZNqT/xP7MN1VsyjQFsQOL16WqaELxDTF66FatBhnPo0j0uJFFZd4uM3m42ds9Rsq9t2pwK5W
EvcNVzha/Qs8ypRQlXULaccMyvD3MyLq3sha75F+E6ZSHebKJvR6a1uQsCvyv4nQto4x7UTJ33E5
5cYEGwwK7hI7XsKNwktgXK/wyNEKDA3gB0P45srZCicgEkP8h1AhJWbYD7u67RTw6fEC0n7u47R9
T4YrYjwAkYwsS7O4pIEZARA+DkTF7r89LkR5wAn8hbxhwpzyci5SVJzRbTFhiW+WuBsw2Q0UbDYe
dCSpS0vHqPN4Lq6ipkgsbILNRH9oFh6tuDO76h6n9Q9r1Xc0QgU9CvGY/Gjh8jm6Nqma4BZNkH3t
3BJk1AXq/40/lH3hlwPH37l3wVp4UCaZ4Hg7kQCCut85lh458084SKVzG2QETIL0IyPhuL7XrVzR
vhq/P2u5UPbD+pSKxXdDFbv1LchJoI3ZOzv1zhPXz3f0IZHqt5wnnsZJlb7AMj0FcT2PSKKIJwiQ
BPZbExzmpQYtQeHNTZN2XNeJEXR3tCd5j2YJVUqd6pFZgflvvEKUhyWBfTJx0vP0ctPjod7WEMNy
xlqqfc2JKxas9U9O87k2OQQ0iskJvHemY3LSq5XoVx9eed+Rl6/wYpkPAnjwywnL1Pwyrocp9oME
cv98BQ+K8KOkRia4v28B8+5J3tYmWru4vGtYinKJ3Lp7+QexT+zSzD2A/Cr+0jUB/ETnYKB53HO2
VMulCrwABQtu84Ebd7yKBVES8Icmv8NTXJhvHo1Dg3VFgUjUytrctrMkSapg4KYJb2NuR+EW+j9O
hS1cMelGmMPnvCPuURXQsrlunt9flC0uGkru1V2ziVjEmiL26h5W6Zc/N7TuP78erFaAUCx9+feU
d7hmA79mSPdAagHd8puGDydmD1VnSTSNaojfEsbs5hzGgKs5Ejy9KIbmSA5+VNLnbwRPudejsYX2
+RV8X0VmSunt8bcoj/w3Bb8TUqkBEk69jrTEr7ojmGvQ6+3e5jKxJvK89AuTZSfO/tZIaxkBBNZg
7IWLNREa79hM2K03TShsf4twCCcMFMRKHh2KP++B1FfQJyk/E8Tx00Lkz3r96J8DvHXtYry2DOrW
EF8fE8INKNNG8IzWAeMVAlgGFuwf/KFNEthjTTg8Ih+v5nbKQ+tZAe64ANk51NX4pbZo0KyeZW4p
uoIDQGADdWwFT0/MidDGSt8HnbX5AZh1lKtKfdv0TBaHYAXdX53TOCtbUhxn0JJjoH0+oMQZvzFz
97q8DO+Sk5I0pf8wvA0waByVj/L360cNe62h0AxgK6iOnHJ3stMxpj7GS++KekazZg3ifvtWGJF9
j5ZIk0XxR/1fLd4720WMMwSfI1Z/WeuXCw9bkRXiDTfvq1u93RhBN0LsD58dR9pJCKnGc33bJa0N
rpsaUmZm+EGqk1dPZJR67YtoYxjVy+Uat3NhktMKgd161uJoBER97lWQqNTzgxbObY/LdTE5JAD/
SNovb98Qp1iLEwEzO87mO40rkwW5zLmIlIFH/NHQ7LzcQxnq0xanul+65hjQk4egWJXitX0f51Av
Iqawd5GcOYq3XIZSVL0/VlKxDrpFMfUjcWPyg6XYa1KvmEcIxI8pHugQHJy6HPP6sMIQNz/fY/l0
pw/7trZUgUi6wMrOZzUNttxHPphjS8UL20yStBrN64Or/UjNfxHUagyVpWSeRw3qNhEGEOwegvAQ
c+fa6w0sy6fXTol9HuCPvqUAmPX59S5Bwo0Cup2u9OKVot+fSC0WyyUsTf5ZXFh7IplGmf4LC+Te
FdCcLxr9Al2J1XPwyK5m/1rgGtVVYAAelVMWTY06yriNb2qWtoOtjL2WbU4EkUKng5Sv1yaD2vCK
SO/xc5BqpGjosWJ/5x6wx9etM4gO9MyTM9cXbVdZUUCEgHEdJ381oyhJvMp/8OtVnN+DxHtYHLw6
efxhPai4r0eKiDwTIlNuTDy8eYrgdKuepIgKIo/HCB8IsiKBR3Pq2laiN1c1R4fCrFUnZ6g15Xc8
ab9LrEUUWQ1s8aXNomI7bby/oLIJHUnA0W2vYceD1ZV42Bc6FetERWOQvU35M7kEybZkr3/llteX
3h2e1Os/L7/hJJQXwtxhBDm9TaEvCrrZoAkrSZxTqrK5v4u5UqMeFYjllQx41x/YrIW5KZXDdGew
lc2SLMoqFYLff9WlLOXaJ0xXuGISwqsmg07mA3iXZoAcc/ye29PbhBtcxws2qtaWKruKw8nQaP7M
XEOUjl8kaUeIqHkywkpK1ZuDtXU+hu7RCNQuYP7lXRBDiNU3qBhWYcKVd8nLmvDIMVqcf+14rgyF
jeY7FdRJ3OvAWqiWQx7couiJoYy02DKo0kYA4L2dQqv4WtomNnhVZVc7WjRn/taaNXNw5bUjvVDG
nGnsKc0nekZbWwyReKss3yoRfQj94f5am+nBB0vfAijvTaRQYjrvaeeDnrSEslyYgGqXWFWV9u3I
Oyst19H+IlWYEzcRu6fRqRXk2d0dArScggQKvbXLJehiGIoDfBL04hUlFQm6eHuNHdjxCUxvQULC
5ZjoKyOofodwi9QAOALP94k4g9mCHKXWwQ2OBANBgzurI6AQpzqWZkgHn1nqNY2iGIbXJHrjfXxi
VbWQpacpgHYvahw21yQHchLuJ0UKeisvqmUXWZH7WXHx14Hu3ILoqidt7MNazrsV3cWg2bEAMxom
jvKZZg7XBuE6jgjISaYH/v8lfirJaZ5mwtk5p8kxT8HBRPHJH2qADZQYPzCGx7R3HBbkKGA0MV+q
Y2BZulOteMRMeMFyCDXxzU6VJMaZ5a+7e9s492TGt7iVpUyQ7gDVx9mqurwjunEX4MVq19t86aEv
n2Mw96VobU24s32BeY5vkrv/5rNE8PTSHMqw3619/0QPxgO0Jo+7d+YMouUczTCpc2OGXlk7hsI0
Q/03uv0z4ICJ1CW9avbGUKAg0gk0iygGiOwmi1euZuOuRqGSAnlvt7IFM2Smg9UKzKGIw+CauQn0
IctEnofOuUdF7KT1/oI7mMmoiZqQhTPo8yLKDz6cM7LN/aAxHPkaeNNPcIvpLq+l36wNn3hdzmlv
GKV0NLgaTBFemojIAtat/t1z8Xb7KeQmqS79FeaLa8/R/UAyC5ghKHqkLw+wtT+A9U1MYqrUB/0z
/jpkqNWmksi4ZpD6omCOxQeG/xK8L9meSqsHwGWqgXbZJSIOf9GKSQFQFYZDqnKecOv69cCo50nR
dD2bPqa+TJN/u/GjJibmSARJBBhY8c0cIM37M5HIIfYCsaL9/b6qJLNXDWtziWNdEp74gGmcJQDM
7uJJfBVZmCNGN2evGn/u76BhmCa1wxi+w9j949l4PkJWifMPv7NxmDeBPIc2TI6qMCcZDYIlliJz
IsuMJGYdJSQ6ubKbUs9UNF+NnHjLA5OMRAeLzjKJGTUDszSVYc27HbW7IJA7ZYsOm613bMsLqQK+
dOH8QF52oMJOwu9cVNcBjYyqS4sPuhoNj4XdctZ5GnQ6bDdCP/KKYDHorUZwGiR44NiuFl+ykTsE
gY6eY4iEdgVhXiDiJfoxLLEZ4g979/DlI1da/KZXC/Up5Ds6h7kgvNf4Lxp929jOWazZgM/+VPEy
cCnhoI+TnO0ZacbZTupiUGRLgxchnPPqtdBan4P6jgFOINhEijssuZjVHhGG5R05HvdIFQMMc2Ti
5nqrMomuvFBgtlyTrwGBB8xXn6wTqd6shi0eSiLQDmHMV/AglvlVEWnLselssdZSEPhSvJyXreCn
z1rDoeRkg+O2u4o7u+g14IjHFV+Uf9bHPmhsNlYSChu4vLlNZKKSgy9Go9Akr/0V8P23xjbVXXUa
HPR/qriTIbKHvhBqpXDOiRIAf6y39RjXKLXzeG1RcVm2y5Sef+DT0xw9SQv+6kngWePN4vos9wNS
E9ybXgQUt9GWi9gP4OVxuwIyyn/RzAx8ByYgf9Y/q1b6L1BsNZrUkW1RhtLEdkLL6jRlG4U7St3G
H2lsefgxcajMayo+qptkvaWdikho+1T+Fb5HygV2i6lAJnh9xqwP7rpxT7Isy7FAWWpkU7OOOlj1
JrrDTmBYDz/LbPDlzn9nfQ2tKABWPTjFUryGOJKkOguRjVDZcYcJhkxpWy/HFzOn48PYYMIIm+wE
6NcofBDca4UHjm/kPuxBtSgwlboSoi9NDRrqYu5C9Q0CqcQyg9LOTVOtMHxzh/tNd95QJ6k4NtCP
lkK+ggWByrLxsRH8Nz/yKHRqDTLj2NGwhtFDXQxtsZ/2x3FkXyhrgBmmXqr7BWjHZUs1EORPzce1
n3ydnlaukPRf7WovIxroidVany8QRND4AZ5pm/i7jI5VgV6qOQR1wb+Zaeg2OLfInuMqUksRu5pZ
KSFAKJgK5vpQnuZhsmp+83VIo0PWq5d1Q0zZuuvzdhQ4ZBQ2idSYx0qhvunvJzEsfz350R74XmWu
Ip1I9FXH3vdW4vAj1Oiw5gvZ7XNBA4F/uAuTuXJk26nhEKibp4w51GhDgPVNQDaNwL6tyWpOaH1v
9jEM3X+k9xg+d8Pt5zUsaabYs9rALhvxLqjohtd5pCTY5UG6Qgq1BfF8t4+QUHxlxA6iIJAliEx3
SAhRUptyxgSHe3TYZS2Ih15yvdt7DIqm539D2jHXsUzf5fpdg/3wAQScKnAWyy7W0Yh45612zkh4
QLGPRuACYXAPnyRKAHUk8iHQUkXC3uGFDUPLycesTcMF8lSY37kn+qF7dsAjMMPmEbtPhoC4heRw
UgOnV7glD7zRo9MwVB3ilMbQefZ6067GhjAWeEP6v8rY1pje4VzFdP1qksgoVgdsUhlb24kokVqv
yN8Y6h7ccFPyf0JcEs1tXOF+dFTqKyPyxGsP90nqOf7XKkjJWI605hxJzBv+D1W2cNUDI/qpCtAj
u7Qxcm3eQJlyo8dTvuk8Qti63AMCEt8ocqj4DZZnTsoQsfDQkXFh2n3pIAwI+kU9/8hZZULT8u1J
EorfrxwjUwzAL2dILecPXTpaHgcd62EMZeHhS7LWZL/Yv1XIgbW7fbQa3RV3pDLvRQj73TFIm7Dg
H2xj/rclCtegly0JKJ5LQBla2EVkW1ltsw6XhYVbsR5Ce9yFfuxVg+bPNKuEuFnuOpA2CzwhxJEN
08Xr+E36R9uGpMPGHDzcA/sW3OfJLlE6Op+xfv/49seA/zKTVb7wNv6UcSaU2ubA/8bIMm76qpdr
ePbpBAVdOZ71e0nFaLuEZ2ZbW8UZpPWbY6IAyGBleO0i+SMXujFSuMobFu5TfGd3TsyeQdOzeZI3
M5kJ7FrZ57wDoxdfuBxcceqSBUdwiZuiUZAM3KLuAATyMBe3IuCc09g7W/3BJDjCnQ2r9YXlCxiJ
6xLY8TFxR1TlpvaiRWdfkLLUSAeaVoCZknz9GwCNv0ED7kasEfGGnxSSqP5ze0n/P5UpxuKvacEn
+36wqkA8EJB70Fq9CKGTemiA1Ex0zc18CP/EXWz51APPKnsApBgXXCH9+dXiEerjqw16Zai98JKw
78c/JXmBOSlGAERhkmIqLSES4M+VyoeUY5Ao7Bd2riQJ15WnpEW7D5gry908UHO4S+sulFLRAR8l
KkAyXhNubGvwDQXcTfqLTWaAacIHS6/+NSUc7krGREdrX7gQKVbfNuFy/6vmzdceTjpMe2WWNmV3
xB+gk3Z8TFmJ05tAgWOUcUqXiQfvNPKzxprYCWg6ETVD5IzuRVufu7GXbypFKUU5PT4Kt60xDhp5
m1ABs/aNOPNgZz0IKs0KzVGn7JGF/4pv7jng0PCBRztSs35Vxh+ofLCtFO+q4zOawPgAbW6TN3xA
8MlvNhjTkJZfWxKNlqH5gtX4Ep7nY4TXbKaDLNrdmafUyyTiYMux1lz7ekhoVGYL82erCTKiU7rD
7ReCB8E53K2vubBjoqhYGYfic31PbEaJtsAO+FFOvbJPgZz9qunGv+tUP2Fv/J+gO220U4P8NtME
uZV5dhrPtPveZ2Uc6OdEFuCKTfsiXEfFAdlJFehGKYveztp3QyizIfQoDZklKzE2xk3lkX7/MTdn
6tDjE8xjr10bVKBHS6tXBWVp/MjymSW/B0K3KFGRvXqQYm3rutFbw2lfvBfJ1fWZ1KSh41muWMKK
laqmMbxFiRUMg6rY6enzA9ytMOTZHhDUUNv2kA9uq+iD5SQ9Y7HE+kpjA4TwaeWulQpPBO54ExQV
IqwdglqQgJiDdP1LghgHhLU7TkSR9i6z83vxZV5jFlnp080FfsaFOjKeqtWGk+qfEd0/3DYyS+9d
q7ScOlhYwxsyPfEv/s1JMJlzcesZBEyjD4UJjP1V2Cg5LE9PQhgGRsUYvOHfvyKjjP5jTDs/AnFI
FgVKKwYbWTeuVtnJ11TXWSSZWHgsr4WcY1U0hix+KW3gdagze3202M8XQ/GOD7U4a/knszmR8AP5
ULwVq9WjWO8rg5hfbM4QLEST2OjNKwk+JEtf6vnGeq3WVyNPXpiZqWYaoRYAOqsRSt4CmEtYvUg6
lYQV6jAOqo9F2drKL7zGtKF8fqKg1jEusYga2a++zIxUzOqKOM4Ifdmsxql/28648GUHEdb4o+Gm
kXjiJHNbTnVfpRHZd82GjQ8Uv1RovkQRHxFBUqM2tiqW3UdejtnIRXv7BC+ID1k/xZ74+KSqFner
Q9hJagtBpINgTqX9t9Y7JThfg6tZrVN+dJsoiZX6RrMt3VHbD7GAmNJCkvlDa1wAGWV7M1yjH7Mv
fFl/VQ8Fq3bqlegRpv4MOQz2dKsToB2lRy1VmRGMy/lbP/iX3ZaSMeOasy+84TQHRMXyk6qpJYVL
K+zuRpe8pAVISvqGS9ge5z/F34FFRY2FBvWz71UYalTmBucRySz/AYT7xyXXczAPQGKvuIlpKIJF
zgaPWGR1o+0Z4ZEWzwYo1cu9zmzMKyRS156Dw+/2Lyxb+eNW069Rz+pLObLYCOqulmJ03C8fQ5Yw
IRHQvfH8Y6UIWy66Li2ILKVMlXW2Kp2l94/Kdfq5ygd32bCuP71a/E3fd6Wu9w1p7zWwqNSTw4WQ
SoV6Ag1xfn0vWO1q+OPuCf1wLofxWC5UFMTyJMEVw+CK/0UuIVIdksoCjoIa6oMcBKd2fTknyIX/
ZRSdC0Kr39Q2cFygDRkM3E/0k26uRAYCVB/OnTCiSzaLjBTrFjgt4XXvz88jfJtQ7KDGNP+kLyfG
H32cu0+Ni/TBew9atu4VfMny5wS2IK3W5om+SN0ZoesDEAPTDfBJLxFCHl5EpuPNs/KlzUb5uuMD
LGAPbEfFHBA8U3DrHqEgzSaRPbGnLOFUIFQATuxQlXfKXGUqj39ejQ/v7klAlhLKXEutR/9SrStg
QZKOauPQ7MGuva9/NvwkIgUv2q17kl155jzvrxnHvXQK4vCvRX9sC6GZZPD7NT9XglSuMCVrivDc
fs/sEFeNW6cFg9qv8XlDBg6b7DHX6szUUWfZ45P/0SuL/oDZBFOB3ccEwzRTxMXHbWZGbTLwCg8s
MZwC50aB1ebHEQaYzPUkqHWVPiHKtiFHeNDS/kYTIe7VkWAzV54PjPTe0oFgqe9m1XlGLqqaojR6
Oscy62DQGSXNUOfWRq5KcRPBhPWqTGSkw4SjFSibs+pQ/Gg4K8G3utNz5sIA++zmnL0j61K+AbJA
sFL3EpIK3Sz3Od/S3OUD67rbXfoJ0c+OJ4stYdOMOP9vSdiCIZPfCf6qKJfCq2VkcRZtWIEwLJbS
+UKPaS/XiApz5hoKlwEPI0BZW7lKZ8Qsyb9Yv0UHLwBeP54MelkMPXIaKnPZqazpzI9+O8f7G/kq
j9LEheHyZlsYAYFTUvcyGiPjpH+lO6d8dtCbTfZFQb9tlo5GcdeJVLssvWdl9TfA9ygHS5kyWywR
deMe396DtEjy7vvpm2WHOCDs2PoEAhcgB/SmtL9Gly+kIfyLH4J0VapXt93X6xwXLreVEC5Ae6xc
KGdYnwUO0F8wgSMHM7iZaOvSLqgtORvP2W2TxllocTorwhTNKUwC7VwZpUj2pmDpre2ReMsr8nCs
rz2HANWYp3Nr41Z2O04vmrH5aNfcLDcgW/K4bMSvqySCm0OB2YK8kuB75uMw7oXLzv8pWLfKurkh
9Ri+EJzADxb9Me0EmeUY8TqUcLf27nijnHr0ch499uOOzg1pR8Zc8joX15qGbtQs5b6O6bHKJw/S
rsjaZJhyyJOkeV7rRxIsB/UVwYmDoG3uR8cA7saBcTHRn+dH1YbOXweEL8gXznjXtQlJVU143Gy2
fvTWZfTaFer4BXk3bKZPaTrCLarHOmfzvYLiIArssRuVrUltxjv00NgvcHyPFW==