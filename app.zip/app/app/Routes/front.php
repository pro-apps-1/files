<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmB6wAHGTz6BBHjzXsNCPIMJZH/j96Dqfh6utZWoef7NWh9jyg27atHTt0ihHvmhzngr22t3
wzDHh9Nrfbg+MKLydRwpoCW3l7jMVSOp8jz1r8NH/sRGuGQCMFOqtVVJqxUXNmRRlll6kxgyg0e3
WckgtBh93kuGLIR8Xc7RSGzZCvUJkrzqkqo1zQr3KrL5DAyVzCts80vaCEPmNd/vwBMAva6N/gcg
G/Ktbo5B6BfXIuggENy9YB26QJCIXJ4AE0owzsowS4aVoh7rC/Az7i6yuBvjLguPcwiksZz6zvSS
YNGtx0T4f7cDGawg3LK4sSxec8skjAT2qEQrkAMHYYKzpyKLgl+/CUfNedF0+wWEVdUuEMxTf8PX
z5VD/b5UIySUOVToKxKCNZ4gOwMAjrHm6wZaORdY1VhKnL2Z/rzLruyzv/S0zux43rGO2tL50UAa
87GLM/xaO4hg3A8nnjFJLxrM/SXzGp1+A74VV7UXfDz9t/eepCogEpAsukBR4o//rrtiPPPj4GjB
4itGDGnCls6cy/q63JAonCn8nB7yp/0pIhdq/qYu87Qd3r+BdCexA0Bjxdwux9iifHIN9GJSSc/B
Ti5t/9Zo0WtQHgcQbmXC4XKowbrtjbSGbECQsz4S8no16NN/NFWETKgvdFcqyM3kNnKSCWCQXZeJ
i67XOh5mcuJLaAQ8a2WnbGSr7HseNB+QZxQDHAPSjKPwlH9F7dJhIBXJmVnC5DUIEgyTZQwBMpq/
S5KGdQdoIM+NbsKDx4uCz8AVDXfGuI7KKra5W/lINIEP/k8q5o+xhcmtKftunIH2K8SPZnCfTahJ
B2lYrL7Gk67xP2UlUonqap4stHxiSD8MX+Xiqrze1OXhpKOJCRWhPDNVRuq5dRI54qo6cd+G3AFs
LZ2jyCBn5ZwgoIyLeF1Ls1M7w53QGGI55zLWT55Ku0DkEBKETOD3yTb2peI3x7V1Q/tr+NZv3Vfi
wgsIkN0LL50Q9UEAQ5fkBdlAaOqqBTyRYVZQcwZ/3cp6p301dH7Rle5Rtvg3UMzXvEuKsaQBWX9J
EGWX4r+uubizgFexSIOjPAfVLv/mT0EIU/A6MzhWh9HQ0gwFTkVjKxrFQlI5ZLlLS1EUjns1VfkI
ko9sQle6z3wd7X37LQMlKFkuC5novmri0spIDFA8zcChUcdL1GMyESXIHREQb7EMVfGv8conHEZP
q9hvktGpG9r1fIN+xlmF3lZCDbZlX0He2t4bY/HRjoqd7EjZmNViXz/IKPvdGV0qADqcVOfY/CMy
GKQRDXngLMvKQohQq0QQru3kidIQe82k8CwxwtFGbDL9GEQ/x7DXZ9eEvygZMDyolhsLBU+t9xz0
1kM8bqw4PcQtiJsuTz1JD453WVqEo6yoVUz4Q+ZQnOmQfDRlUefTPPqx/261QIEeB7HB3LZfufyk
gVtGZq6Txne2sX+LmjK7w37EZV3YRz+PUehQUZs//1tWEEpkY0+xAEoAHI/Cdj4l46gfYu1EKEHt
dEAkckuRfUE/WVTQ6GTjSGzrvjS1mWtpQLkyJMwNJb8WOCrIxs2QR6meFkZ8/mD1gb/osd9dKXxp
5McGgA2QlOcXBFO4OCdSSTbeUV68cn+z0OnxM0OZLkEGJSwOZ70eZ3sEwXr1qXMvob4Gpu80Aqp5
QPLaS0L+5EqVTlemd/Y0UHGLItbdC1WWgsP11MEGd9ITCiYMG5VmqvPmq22w+IlYiKelIE0aom2O
6rQNsccIC8Xz645IwygphF8kE2yNsm5BZmDi/AZQxbcTZ50GUWSbC6LnllIiXwchpwD7J9t1JmPw
zDmBhoSSHu/QliAKlqkn6Obc5Y9UW4bGAkpPJab8RbLZPE0m290GAoKdELK6j6nFwYav4NkaVVBg
13+R1/uexTKb9tL6Tixxa0f3oryhy6zizzWKRXGWBRPn9qo1m5bAd9RGJ4PJtNQmjPAKCLgE+1yo
Kd08hrRedh7ZbdZF1GEO61QXIWPPNOQB9RzgVq1LW17oePmWvrm1c1supqhg/GXK5kSJYX+iO8sx
H5DMDsg1Ch5hP1Q9S95vNUWMIUwebH1dH8PCehfyUsYuqhEntRAdT1MbhgTry44hbKtoXKhih04o
OYluIRd2LYo3GDm3h6bebxZrp47di/UyJW8uLuHL2uVZPbwK3kEJ14B0NT+3Ynj561fnnqrgATrV
Nst5L6xUj1ggVY8gyaRMSBpg+199OuEfndtNV6MVerY4x6Kv2TBWzwjt70AaJUQo2ucO4nqeNXyb
fDDBabBDCXA8S67DrhbgM9ljlUWj1BJZw0DM+TLtFLYhAXVyNI002RLcl8M06TG8MuHD8q+B8NGZ
MFIJFWfEc9nQijOL2v85AOtTy96Ay0hh4jI0r7gkLv5Tp3KkK2TnABMXlvrtKbDzY0Lgxu7itRji
1uB7h5AXlHL6fejxIwjSVAOEeKNypNsyXFjFG6w/gkIHKxjPlMBrxiVDuaCM5n5dAeJiDS5oML+n
LJP+ZaCgS52VnmAcCqzJDavtOreoM6QgAsw7WjJVJyMSgvhzn7mf1Y++ZsBbCW7drswLgs+Xy/h6
CmWo27NHj7z0ShDhVsQxANjHR4Td4ULyvDi0WCyEZ+tmGwIKhCiYuDEQsLJTMiyv1Ho4cjLXpjXj
CkmBguAABZ0zG3O7TXXSIccy4dNQutqEv8NTpxOwZpi688a7l6Gn9LeGY7bpouFlcS8+Jek1ze92
TPLcWOU2kbBT/2yDP7OiTPF1VOgrkdW1nDwo+YQ/h3AowAXRKVVTosqmtIzr5pbam1aNerfNBdMv
Ex6Mx4KEZ3eJv6VBk6vpp0h6+qo5UZG7eh5usySTABKXgjh1