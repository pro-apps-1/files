<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrtp+DZLOi4Ve31j+ucxjAvAncZ1za+IazPr8HARCCTojOz7dJxOXs4UVLmTcaeuG59A1RVi
OoN0UrNNG6i8lfNn2nsc23rQAx2ZapeLGixPEoDhvuFmE6YJY0dqDAgMGj6D8G7G4CBKYzK+8ruu
/lEakBvd7xD77lJTl98YgZ00Rk57RKITfmWw6eh8VldOh4Ah4xXEs94IM1YMcotfGSMHjNbMvKDk
69oqkW95tCYPT+9vZFI0PWSgGwmjtlXHelEEjxiKtFzbqVAH4VRZR35qdUEAQhL3QTIvBxOIw9Ko
WSIAC/+VXQkCR9kPpMY4QCR/6ywRWkFnaUX7JqQiwhX0m3hH4rbTxIaKm9MxfqQ2nw7RpZFokOGl
RQie+m7t6UeCHS6TB2Jwcb+pryq41Yt2G5jBfWw9/+e+7mw+82CCpvX9wXkSdBdd9ehdaUbkuA0s
9Fu71ZNW67NW8QEq8kAdpamuGaYQkfIxrhTHVqNJU4VqDRcb3pG1WzX4YHuDkp7ZZZSH2PnhHiWS
1wfy6BH2KINs3ZgUbOcEclvQIpvYtJECLKIPKQ8YJpyxmt500BebVpLVDcUFcVoFY0dVJ0Q3LdOR
IOv9nvOhsVzpPOtSYywOu2QnbhgqG9PUu5tNOro9qy9NZWXn3HAlUOQYUGgkeHexPPZjLKd3KLN6
fCq4kE9PFtJFYAebaSp0SS7fUrPC3hldvyqp/gh7/GRsyLj4gSaw96KCJVVZLQFEOUkwlISgvTF4
v92l+qxBq5C/8pT345ykvyadjiqv1n7tDNe3VfOGw4M3XecqKwqWHpv6RlLgk8x8OWhJE/G9Mjhk
otIVzaYNkJSFqN2Qut16JaxMddeMKqtTbpCPNXXum4EBo7Ihcg8GkjZ+5IVU44xkQvyOt+r+Fqeg
fPP7K3AmE46cBKMcWX8Nf+gx7oVP9GTpBzwgHdZaXxfw1m/vQGcMXgEHWgNcQe++cUgKGcE8E+mS
HyUotsepk26PDJ01m6HRNy0zFpgGt6cjBeLp3nZLp6tbJimnTH0VHX2gtUjp86YnaUOPh5Nwzafe
1AfFuD1tnBzkCd3QfP15ocXG2ita0/B+mDnvvOHQGUtv+LWFtRKoM+eWyt9AKQJd0eJq14QtzkC3
FN2kaWefKgv1qeThlUzTyYl+UgzWx3ijkHtE1/+wfjGP6BEZ3n+CSqQIZ2sQLuobN6Abby9mj2DZ
BAAxcBc8hGsiXB5hN1soav/nrY9kwFI+pfjJo+vYneH+mo/0UA+3psBCbwiqtW8jlszkfUyzjg1i
XwCNfXVxuIQNonlmvg6B6D8gqHgAiYHxykBWsYZ8AYOUlWqHuy/jJrYNUSUAybQV8wVB0pSoX+lp
RUtL64hPjSPtKXYQ+lJqlhaiLrERed6U6AT/FWXUS5eHYB9ONF62yPtGmwdnKH8/jvgHVINZQsL5
Rw6LeywzTiuLokXXaMG1f5SgqOeirQxRr/nO1Vsnc98twXEG9TqlzFj86bYJY0DD1YWmKVkF79AU
X4+ZVNq8se3nb0AQM606et2Yz0SBIH3l2dMVbWN1sre3ifERwxB0e45pYSdedOFg4rTvzd5Tv4PH
bMcvLOFllm/xjwAEIga6sWt047ViAxLRoyjoZZQ8MGWkkYwEeqbKnVCIdm7hUNCksgpslA2jivGD
sRLlIsn+NjKQ1oeUEIFtDxERGqZpUzi38/bscTv5S3zFM4vI94gDoR8DhWzUCXPV4KoiVMY2UCh3
GeGZWv1F5rBp6xaGusXGbcT8e++RnCf6DkrwsYPHZwP+JQwRtA8Qj1P8MxfskLn4oJOhn2nmIa38
bQQbADSRHa0kpmy1W4mfOaTE4kVt7rd39MdabR6dCe47Qr88AIX3wabm2RaCj+xskN27JzsSiTXF
AYG=