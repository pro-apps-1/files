<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyGmkb0nfXvdpEmlSpuI0ndPJg2KvX08hUs0y9q5WbWYwfEtwojwMi/yG/g8WW6pBuaJJFIh
wGl86bVCpxwhyrKaLxVfDPCMercR7ZBbzcOW0ZYXd4lmGLP9Vr2NUyFfJM3Xqhu72OfbSz5eRoXG
Z00pwnrSKCl90mhiKrPbaPBf6dkwqzV33E1sJHHszgTIu6+6lKOmhfOSpRspDvw3aabReQgDKk7M
KmK/vJufzThC/cDYr04GFqt/VZCpPBvwVNb+WVTikd197ygnzJFolHx1lE1FQOsW7ma/MXeNjbMN
7FsD52I7LICTi3CcGEu1IxMoma3edOzh8RU1cs4jvQd51b2O8zM0N4sKnaNC0bew2LlFtBmzrj90
Ck+lRMJJUnaJWgmoQko+1fvRX2iLvtLXIAU9T6tyDQrCObbPJxxzfwiOiPg23sKsUZYU6+OBTqAG
ie8BTgvgoGkjG+PQS57iYMXFfcy1JOksroUUTa8+dRO5Iw6whpUUBd75gXuzLsiUe2NpQqV1iQdh
y9OSMbFAko0OUH949H6IXjHpCDGnzkhHqiOiAi7k90JKdhuifU+Y58nkc5TDd6Y7jawd2XKAtX1c
4UGwhGvIcKCUkT88Or3va1y/Ex4gXGz73Q3ogcKQtZR7zwpaN1eO/+vC2dQm21m2ZZXj0TQHWOYr
Hi9NBa1SecF1QID8FsVztvsIO4ziifBv9YosdAnWhXfmag+FHqodGB7dRqEvvCikjr8lf8GnXhba
ix3UhV739D+5fk8bmcqmr7L9ZFQl4FCJiXKMJIEqgXsgi84fbBnfxUzlFZrBH17AidekFsy4qvyJ
XvI2QRyt6+cQsQQG9TDtf3TFuWb9BkWZIP5rW+nS84eFGTsTs3yq4xmJS3vyLmlgTCeRwIUg+Hh3
vw40MlVSU0vm94muT4NIbJBlh9JJsxcKisb5AwhLChkYTYaHaK3ksft8MrmINw9IzMU38XshJ/hD
RGLtqBHnc/uAJ0V/MkkK/DsWp+7ExhFztNUsRD57ObgPZgnjvyntbxeV7oIKoJE1NgPv218ljLQp
AUjKAD2Nwd7f784nNY2lANScMfZjPkUIvcy2+GW8lKW/fg0ipfDspVAEozHd7/hOggpW9MovHVwM
MI0oMFKFWra9hzh/9PdJUkH0CzoIpMdhiu2jT1NBz3qIcjWd69j9+ghAianC8nqE0PLhbF+rSshM
9Fz04cffFi3ptGXOHACLVtxxLL3yjvuhUax8iTkn1VWeS0vzVpVWIYDZgdGkO2jiYJc+QGJGaSH2
kKa1UxC544qA9x5ApbYGUxIztYN3YtRTkFbmhaTiKBBvcSf29vP9LpFwbvIfnqNv5TVuY9FvC80s
+Nr3S33bydWQScN1/acLabnxXolslTfGeLUwPyiqs4z58rMNd66YsMZl+qYFkKBAL9wf2lhETlhh
yPn7nxwkL5+fMFK/U9bXWAUp3oLMcGxJ+iz+yeDxwMSIjHXnpqJpmvqPFzMsgFpuzU+k1kZu7dzf
KMBGNSdi9WIfbjEuDqLm+gHyDwgjMSwq0R0e1cwiwjCAOzfh+b/XxmqVbARLDNERb4KP6hUTJjXo
FkUhA6F5hUVZxTHYTr1mtGI/cUCwlUSufcBj4dWOWQ4IA4MqBru9l16NJc1Wn8ZPKXtfpf8BBjCf
IPOVZufblDLGMtrJm4cQJ1vgIj7X2JRZD/4cEafqbds5iU9CSHvt6m/bz24xQaLUTDK8IGEdPwcf
/QzDwxOzlpAyJYE+QAoXM11jY2UewRalLa0Nz9Z5emiRfvmFYWfojD0lKtnttSDQ4FHlzKw40UTq
kf6G1ls38O9H/UEC4Tawe5gkI0MmVvZ43yFYN3ry7Itz9tkUmoXd1TfAZa6/MnW044CIDCzFQieb
2LBicF5ggCbUuwW9zjIOMHpmYOQ2oR8/dHtZUS8F7Fw/oHHIi7a+FRHCB0u4pUHzJEmsZTkim+i2
PM46+8c4P1U9hUN0Lj7/eBvlhFKMX78fXiX/NKktMPqTDNUxyo16+gaJ+L/dZk8kD7B/OJLfCTpl
EY3DYDCx5+HdXalmKPLS6FpXHgutW9YGenhnIQsuG/RDqZqa8KS55Lv1JYpsOUN67E6SSlM/7ETO
rm7HRgA7cYmI/k8IDO+BKNbWl3G0CYUQfqpKaLKluTZ2Z+E9IsZ3xzOHN4csMPqSJC0UXu98I98N
maTd0Jd7JaB1ARw3pI+Ojs/9FP/LuIh4GJNovLntCm53LM8fvNfq+iI+egyM76JdmTvIunf+vpOk
f6EmfbKf4Wzs2kNv1AbZDn9FVYVA5UODFrS7meZDy9ZLV7qz5BXbwI+dNyYcDt/v+dEgEHvrbGOe
zFMgqd+pzohrc/R60hCP47zj3HQVNKEXpgKtJfsbZAvvHZ4ndLoQff8GKO7JBdo1odKnbACE7zK7
Ii+opPoF46z0CwG1dmZv35Hm9ocB594RAgeBT7oJsnk/k5mUX2u=