<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvLK9ruV2voHvfUoVKPuSTouH1YPxs7NgxYuWaeHJiohMlziEeMM4meViPa3WXjCBS7eXfh4
z6IsZc6LCnHWm3yxf0/6b0SZ2Cz2zntaXpkiatjmaA7e0ghdrwSz4hHhMlvwYBwx52tyGPhmvkBU
4NwK0v2BuxKtqdsvDbcQKNQ7UIjB11Y7fWEGyVmEaxZNohAd9/7Zup+uKnt8kP94rca1eQxvc69Y
+FFcbmmqfCW+mocvsGulHogiC0NaLsYpVLAYzsowS4aVoh7rC/Az7i6yu2Phpklc8jt7fq0r2vSS
+urE/vsT9SyqhULPT6Ve6i/XkfI3RSFVBPHr/Ah2hkFIkFd4UnR775jTmULvKMdpQls5K/uqdrex
Z9Srq3/4ZwvBuchx8reqKK3hGQsPVdXqLvKq150MlRTBlTcsN8HW0uPbJA4SUKQmDcgf9vi5PCN+
wN9xwRjOiRiemtdwmlIcwlV+1qg3Ji3TwdQ2MMgHHCKMp6maPtPhNcC7+6S6SAu22LtU+jAH6mWj
WyzX2j7JIm+QarFubaK3MM2QmdRfGI1IEDZD6UAS6tu3AEp1ztxyIr/ZHqETn8x5VpKR/WVaKG3Q
SxH7GEvAw0VHcptpFWPdYxCAU0+GMhp7YZksh8+3uJhLhQ2DA8w/tdLIT6/aoZei8dsmv++Gv41U
DqiWVgUrCz2kVPFVEl4c1uTv8B4Akx49Bv+sVcVzbSh8dwQMMlnMpN7+n8skROVldb6B5o5nOaa2
7jURhBZC8vsY0fK4HmBkDDSq+6kkeuqg8DDntLf5iNc9/yqqN03JQhRH0QB/VpWTYtAuEnrZBBvk
EgPGHxv8JRhEeCGhnvjaAyXpbBs5UcP9TSuwEeQRbGxrvwWAPGlTHNCTf4ZO78ZV40v5Pv99B+pi
ZNlVSSh65vBxkxye5hKrwjbrcbvgAJJk4xf2vE/HXNHgSlM97QEiBB3Vr4Wno4RizjcBnXTQHkf0
YjKG7Q9vAX0iKA4Zmb8KrNg/pbVsFHKVYbDKMa9xkSVdcVWUHkTUBj/4wYlbx31vP7VjDyzNo7SD
zpP2Ne7R8GoZGIzUi0/2qCjvqCZ6UKgnEy/7VNWsKheXA/YLvgxhxYhloNK6YEJGVgJOLBep9hNy
FwcphvH98O8KEZaH+H9qY2NBgn+VRhHe+Zgx6YDfek0WvVtggj6cwqOGOcvYbCYEMaPvqah2yOnv
mIxi7sx6K9kvyOQ922ZjC16QNPMu+matcOfHve1P4gampH+/dlB77gNXjfMPEqrHRaa36Nw4vzjt
7mBywFlyl0iUfZPquwrdeUJJuj0Z7tGUWIuW4B5ohcmNv4IknOvHPhkAyrTw/qc3/VP6/mdeHEQ7
/QFtdcfcfh36ROauTjR2BHdWM94T7MniTpzRO57/+bpzqZRsPb9oymBlAXapDWcVn1z12LNdgBXX
p11EuC2NbtPu9cSqhsdgXZk1anKrFr71kAUDWfP5CQ2QDvIRpfI6PJg33Wh/BiFBRLin62RGHxrk
7jFAfCIvx6dtffCG2/h3H2q5GszMEvpu9WNHluXvXUFSBdMVXHmhVoduUZLvrxY2y7QzgWTLyElu
aGGGhsZIRaA9CpIGWTbRP4x05iWGEl1e3SuVnXU1QfC7sMZvB6XdFjswmTQ15kwrpkqhxkjs2wdq
8j85qpXJi2HszZgap0qe7WCMCkP8ogwn038qrhZ/KbDY4EeEEx0nneEA5UX0mcTLDFXhT7AumtHH
sZvWZPdvbkMEu9kGfI7u61UTvBFJPQBnTJbLh5vYuhF9FRmzSulXic2b+OTfWTsRsWIV1uSF51Xj
+4j6nrm2L5kJzvF/EiMPtQ24ogtrFijBXJgnmi+pELJF81dvIwsjafteS4cmp3W/ADUkukyhGAod
fuXyEfih3XV/huDxonZxZfg/mKPl1mgmca/BeBFTJNk0ZfUJttd1wCx8yrY4aQF5Plph0wJ38SDr
2rdaY5iK5DyJigiRWOXxpbcZjq1fWcamd8TNSgkKq7YJz59f8rS1eNcdMXY/1QB5QnmO9ytRT1Ip
ZfOOdl1laUqJAZBYA78T2sO/iU2hliwaHMi=