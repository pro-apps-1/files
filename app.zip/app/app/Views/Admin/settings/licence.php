<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsSX5t3GaUj7hVs2KtbO6JTRdb8HZKADPfsu9+g0r+d87CkNUtgAmfjmONFhyidDf8SoQQKH
M+QTrWgRr4wsu/ZzN4WNvvwRLg4Jsfk67O853CWXloknJhxRGMDbXxbS5TjgdMMZZ3QBxjGK6wyV
O+cTfUF2FzjMBYGzC6LjJXiri8HyVzymo9NXNAIuiPb9oZFiuBHMvAlCJ381u7vgdAfq4PSdHi6B
uMA9K5Vk8CZKeielsBlV46V5Wcu1Sbci2vkAknJS/sNHyf4HzkDiCNITuoLj77NDLwFAE7xNvZA1
Yw1o2vHcQ0Rp0QmZ+bA4afDmyvk/D6QGvxQjRI0m2FZul/okcdBXkWqk0g+8ld7Faqz5k4MxDuS6
9nrjMw5uohmtqMrYtpkZO/1/Oq8EuLHTceQchA5HBUqbyOoRdyR+KE44kBIsvpLSHp2pB6W0a8Xz
v92xyfylUY99eugXaKlIJKD6Kwe8iZhI4oHp7hBxkg/PY+QJhFQnn1u3oDAXPQe7pli6bDUcWJNJ
JmeQueq8z+OJuTGHlNlvclqTFt0TOM461CiJB3DbX5Hj9OXiVLz4CiS28tDILoWaN+a1CWHuVgij
6OCbX0AV4HmU6lqWG+MEyQpPouMgwT8Ce9ezvx87oh0adL5wch+iWU+gJ3tlCgZszEyCJkhTGcBU
CA870WXK0J8tqZ+tghRFmqkNaJ61BnfTm4cI59Vb29bs5VsaJSuk3tM8KmHCwa6gJExoED+hi1pb
ljwfYO4eP8rLhlXrTjhxESGfUEfTdBG4lmC+J0ikCPYUxQy54tVtBdya+QYHMpw4W7B6eawdLjcj
595Vjhgp7h6UjjG7cUBXnmv77Z+OJ6DiJPOS42pnppG+fhnIgTWZXgeK64Rh3WwMYxpjZGhfN+wg
pTQi5M9vyonBodVq1TW15Yp+qm0a+UGdUB4K0/0EUr8dUlyV31pWuyek35KQU5/mMQaT+CekfDzG
5onri/XoLzeA23UKEvh3JJOX/cbmwKC7rmMxFqV6BKx0KkjZ9U6n60BHAMF1J6CSv+6Oe3tNjiYm
tc3KMsFFtdS4Y5Ce8shBBCCY9qQMeTlL94YTstfl9l6zmxtGKJV2Dsc4WeERORdMY80dINKpwHKW
m6TKz8hqftdGsNDSnFIvyre5ikPBNRvgHenZVFGpZQyiz66M0SlXNz1XmdXozE156ewCzkjLlKij
aih6NjDywFF6fTc7bdCBra5gD/FtvugCQugJQrfDzTQSuJZ6P7szinIKLMfhsXFgvsNKj+nzWe1I
AVS6IpTvo6Tal23W3WCtORP43dNiw+PDt8dxzN7BdHFn8EmLxcV/+Hxl5+cWgaKErtyt/qWwx7kg
DL2E0cWd07Mk3fNM5lEgdAuEW+3SgN+kG8iDiISBvRHL0iar5Yak6NFzz6m1q8I6NAuVq29M2sPq
vJBrxG//472j7lPpWJN6qv7CpjLFPexdZZ/dIbFAUU0klEHbHc2PxQrXkpDXNE1YMSaoS4qsNpQt
qnd2umAa+ZD3UALaSgwtYDpMA+AlP4981SxUvmsOKddLI2Ls/gJFs5li/x5n36H3EFubyUomNAJi
3/d6taqBpGMqR18g2c+9w2BmjhMEv4GTyQztLCKgPQVH/7xO1nSFpF4M4n5UdmLL5Q4OscEqMsO+
zzpeVLbP14l5/8w6y2zH1HPnqvvQ/sadIFp/2EkY8gHJzT0JCj7MqnjMM2VQ06zr1LzsQow+itlI
4pKN4vtSYInzrsPep6P0wVV79+dMxwUq7eg9+In39WGUSDGwUPdijyafMJcwkqwpZatTVW7IiZh+
odJQf01iD6adQp1484mQpbCoFt4czHuPfmA3NmeluyH8AjhFjVa2vTxFkPT/whO00NiayHuXaaYN
/6ACGZKRjHwCtQ4sKwpvgP2msC09WBOKfeAWldBh5FqSGB4KVE+Kz1tv01DgGL6xMC316bVDQVuX
NshZdP/rNNWZ95nWPR1UegEAgxUKadK5l4j0o/m8ozD+9R5dR1sGjU4/jSLAQaz6BLc9Z1KiM7q5
S1mRSJGkWaH44Bds4OwVCna8xBD7dNXHGeSHutG14WC/6dFX2VjlwediLDR7fO7AerlxkHpxIkh0
9eCE1GqOUd6sGZSJh/V89KpeRcMCEElQWrNLRaX8K1LAz6GPOPHO7nVEIwv5/0XhpXVzTnjmfn/E
9T1GhN+LKdf1gAKQmYhF