<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmB014oJdFrZQW6HRoAFdko09oyoBaqJDFS1WgAsz2a4B+vsMZK4/Q7pzkPcr+k0xllTZXDM
JW5/R/sXxhFAcVrEjaTZrZNLTcVq4EYiHjsAjA6LIamvvxXnvF4AqbgXSr4XRDNgixY253al3SOm
xI7xBNVfjzPsKNEt1FOUP91EFj24MfDUot6gMu8JWgm0AEI4pl3B63i+vKqwYIlC2WPxI95RGTKV
Dc2s1kQZ5CcESSlZbUpdSKkevJDynKZflLYk3VTikd197ygnzJFolHx1lE2mR8SxPWvOxLvS9TsN
79XzD42yufhkpEg39+G4WbJrb3VE32k+PmaoLu+BuMt5MU0sW+RsKTC+wqIesy4urq3Y7DQH7nxV
IIB3piT6rPQz7cdCb3u1laPTNo1Mb9sCwGjtwpAAErHjIiqqcnnrLSwBHkpSQOCJ+C2OzBch+TJf
2pw+iTTMJE2Pe1wf7zYtlPGRXgYzmRp32OiLRv1SDiE/DDbdM1P7iBuJO8f5Wx1ANRT1SreLFpZz
C2ZVdxlUKoU3ZN0+bC7lAKc2DCl86a7cXGl7xJDNkOf7Ayb2JovgRSDQkNrj/SE4/Pt1KH8NW5IT
VBM8XQZE9guVjTpZs3wBmSUVu10QyuZrZD4IZE4N9n+GIQzm7f+nG7tSG4CNn6JAxyq9Vq+Uaw63
IjOz1fqUH932cf1POploFNyRoTgnm91FUqTxyCZLQPH4zLpcc+j3M7kl4YlZOv8riYPG9HTUYOqs
UZ0ILkmOBZNfnYyXz0YcTOD3HgHj2LlKfoprJAJ4V3L67M/MOxsex21gonMeP882TSmLAkC5gN9X
GUI6kSUvibmnxxJQsGr5McFZibsfZkc4l3cNuf8VxVEI6YhwV/HorTqbxTNQdnn2zGwnlDC0K51r
up+mtxUc00vuoCV/iWoTtxml/sBP8flONUWQ0wmChT9T3gfeypIv8qcYHWXPxVPLMXubeD6OHnl2
9NNu1vZln9vw31I4xNQzqoIef5AEsxfhBNdyBFdCRWcdmXXJxCDvi7RNn13moxzmsFbqhIDqFmqe
2MgKeT0PuW5PAqjg+tc2LlyN3PDet/T/8G8HLKXAkxIqYhOZglQvb1sGlOhPjV8Pt44wM8WcA8q4
Gw8PhWmRTXGw7ccdSqAbDTGzUBLWxBCOidrGn6FD1bDVhGcrFJkvrRhh7xwsHICpFbX/wFOqeY+2
GAw+nOlNNvhhlRqhL4Tzhy2aTfi2mIv8PJTQhXkUAneYbj115YXYmLi2E25EuPQv3HsDDa+OOp/b
fPY1CMugdtyWSiWSK8yXx+ukvpY+ydOYxZrwT2wxTN7A7DT/nPYDByl+1LVGEYFfLIOw+HjjIOIV
8WwaTvCoNz3x/kzrvzc1K1I9Cs332YhjrWg4NjpfxgPncgBs