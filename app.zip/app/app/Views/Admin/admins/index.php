<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsMEa4FaGsbqyKy5OEmxplwdzN6iSBI+YVr33+xKB0JwupsL3jxcPIXWnL1UXeKTyl0S7AgZ
g/TYRMYw1leElnp9EyiNSS6tu/B185AWzW9pwpMSxdyEdkQJrCYFO9DqQsi7wvs6zdJp2h3reF1h
MTeGDY23RQI2u188AidLb+x6NQd1TwDTGof8tMH9rD6s5GWdnVEzQy8+mY1152AN0o4DULtXkddx
WNyiVTpiVyP39VQMT4aZ2e31xdiApOGod1BbMBiKtFzbqVAH4VRZR35qdUFARcfTeL6K0GL7fp0o
0N2VOX6Y+HE/4RZfuRRd8Ji3et7UJ8AbLEru50iaHznnKknUlNsnhiK6Owez37mVraFO5twywZxv
2Y2LD4z1FpWTS0cIQYiQWJi1KGCfdu7S+K8AUVO6E/s/9nUO2kXu4gxWgyjeijVjLbsnt+W6yCjJ
vvV1LFtKC+4zKBbWnZPHNZeilegY4nwNzTWuZwxXyPVKf/SJzwZts6Pi1qdPIgaAjSd1hN2kHI2Z
5Ydk63lOuJbyYZbLugHhNhxEMG+QakQHB3urZsxPYFHCK0VqbGnBU0z1gTPkY8kVuzVaHIYjeRBw
akBCpMyG52j6MiIsrYrUe6s8TVI5X7d1Nub6z4dJAEMwSMvq6PehiTrxyJ26NXQzjI7A3FShv0eb
IAv72voK0qPh3Z/FhAW9Ued4IpFCA6r+zM+1HF/nzdOg6Bq76i1xLaPDIWAn/CEhSjcdK5aaRFKG
A7dv4Q/23Gdqkwx60IP8a+A9AllteU6CunKdmO3y6q3r/JUQzuthLorvywLqvKeWIJisO27lgqQ+
Rvg6u3b0ARl3NR96MjKIKVCQM5PNtVMc0V1dUJyO6KnNbrYaLZTK2R//kWUb0erPwsGVqgHH5kBU
gDq3XLpvNC/0/qTsbvdkAJYfWgrp7EOao8rfARybv04mdlwAnFvbCjJl8i8hhNBUpR6q6VnDnJjn
DXI4HWUsoPwZM2hZ/dv5a3E+RFei5YSz3EnDIyhmf+SsjQPwAizISnnDELKgktiJ+P9App4P4xqv
6bFyC57lo+nV01SAm4Swky6atR8TmLAozQEMUXXmxHyx/ULoyc49JQlMdAiqIrKmM3/Yp+eGBAg2
k993+aF1W6dsuYwZK9WqHZU2qOiXb63QAuGZyvvpvNUnTWdeBaHlmutPTVidQ0yg0VZqMyABvWrI
xCMSKB1pSGExpOGVHwmhvkgjGNJ5ELTO6Nj1zoMYyVkkgm+49gMxP7pI