<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxEAJUE4IhRKKLVOm3KGmWVa5NGI90G0VEaFlEpzjJguwyIikqJ0kiassK1o3cnvMZWuNTA+
tYMM3BLmYDCSuj8d37z6iEjxCtI/fUb9xERLGdRlQp3JKQQRNukijzbrmZdgPpOSUl+rt7swvI0p
1Lm/1nQpdNgYD7z8bT7LL0ZNFyt/jGZ5etVc3XgPmO96mP7loWyl4pgUkH5vdxIP/6OgVObW05yx
AkTX3kkH6jlfQ3txVmB/5iH6mPzO/aSL3nc/sMB1zsowS4aVoh7rC/Az7i6yuFnigrZ0kIp1oArf
aPSS/8qEYbnZIVGO9EvvzKMoqdux5OsovN7TsZfI82P3YQIJozhONQrHyNGa82LHKxLL+zj4TodX
shSmSUi97KKM9smwbQAsegQ1MmxrIocRej8dFbjTrLZB9bfIX+3bNdu6OTM33pcrE+szhWgr7Iyr
r4hQRt6/pdztU7VfMZE6m8mAiZqe3J3CgvbUwPXsPOv3U3FnlpwpdmR0SGFXn2UPIeUJjOkXWALK
jtc3Mova355RvrDlPC1F9bIeUu2mtb5TuzXLyBsOZsj03SgBEdJDEpg96Hg+COKP2x+cntZDU03P
k5D0oB9XS9OrUHQJIxsdJs4ddUQ3oc5ZN0Zrf8SmFaqpL7s2Yo5WRmxq0lsCj3UotZBmQAs+BfCK
ogoZCD5RMI1KL/HCV8CHNqswJkaDpbobhDp/4MKbuXcgsUPsk8bGViQE1qekb8TzRjPIar8JqRx+
H7Rhb1Mf3+umUYYdU0enDFz31RwdwT4UxnHZi0irea7Oe/5tB9MSML0ZBqBDqQK7CWcetkG+hAaF
dep15Gdboo44dnvP7MZjEpy1HulSmsy5gIhc7D3RNms13GyISrPzCF2eL+eWaSqCTITWZ+6W939B
wYvMrsuXMxwZqoaJHOl9ZdANV9XcyHO/7gXQa+LFH9/qdsJovwM4tZH7qCYXg2YQ9gWeATH3hxn1
guwY1GhD+Xj3+NcwTijp0ly4P9oWHIAyP1bblEXo4dVctvdWvKWdcUM+0VJbHG7q1WhLxjXFlQmz
UI/CddKVRsDq/kME0yXjc7yC2fHcQhz/6H/QCWWviGMm3DZjRSoeyAX7HqFb/obXatmoHIgVIpbF
cgqEFWPxlxndoK6PwwPiHgsJkPyXLY7vbVdNcTmWtWDcYcU9bB9W3b+wRITG99raNPv+581skdJS
zCLfFtsYiwCRE48sYounRdp9BKK4lURFpmFaaKA2LbuYRCqm/gGFQt3lTlsq5gfm7flg82w/MlCu
Eq5YfsVrflti5YG2NxnEYxHWSmQyNvQcJlOwW+8RZBM4+DNR7qHvCOlRJWeD/sRND5WZzlMl3E6b
xt/GTXaecaD63M6AEUCR+iaxGWOj7OrtXEiwfIbY2Uzuxk3UpeaXr/qzWxcfArWZxcmnNLNxrtKN
bLaYWhqvmlFqrWAUE6wc6/cRfZQgfs7Bk9bQtzJgi3j2VvF+G61roC564wVw20xgnu4ZkB8bD9Uk
pkemv0hwRKY9c3rAjE632s724aMB6oiu/1nhGPjw0KbTbwHfniw3C4xG1elPgTXnOouu7C4GWEXx
8kL68/gtXC4D9L4pp/rxzyhM6Gbetv7w1jrez1YUL6ogS6I3jl0vq8d2k2r0rNI/U+rSSkqzIr5S
/u0ms64nj6XkGWGHDIYteZZ/DUAB3ZxJ2V8WYMmZhA+XbKQPFz8KFkcrfK8lgjYRqIrAADdCKdAd
Nd++lgqcrmJ/5s8KQeJ+Ewv10lwh/bVsPvbpKSrxPtwerkrAvsxKmpjNqxvsAxvN/cvNAgKAEO1x
Pf7kcL/y+CpyefBDzwedZrThbQ0vFZW9A9otnJlIqDZO9wvvZXVC3RHvzxar35XEH1mKwsqwjXP6
5B9nKwIcoW2NC1KBEebpGvCOBlhA4HYWaNxOLPsw0oTmMO/vmgC5ZyCD7XeEO/us0RaHdTF37kZ+
xtg0rGuIoSFmDQWIpNDY9LK5oHCiDrkzUcYl3IIAosxEbA2505x601VnQ7HgNNJtPvgxR6B2v6g2
xutSMNIzonaT0A4vXKuABuvYX0QA1Fkkd357UabBiVgHHKfjhxgo+x2LkN/yZvNRzImhe105LbjL
HtWmLUyCjpDawbzDVu2VOiO4/mjuTJLdPlppwKbyrXB/xiQ78Jh3Z+RUs+5F/+Vep9sl95agXY9R
RNmht2GXacMywmvKE8GKh6v+KRReOVG06upKyYQ7rfvJCIo2r5F1x41VCq8PItFhmCchjaVCI1Ea
in15OFBPCh9VFm4MFb5FzTID6bFVmGH1WtiVP8Gt4p2Eg92R6Wf8P5g/QaUbj0CFjSa199UwLDj7
StS4hB2SB1q7hsUus7aHSpf5el4aLG0Xfp5/WiWHpXJ6YVVmnMAfvkIHxPrSDVbxLYgMFYXn3LQE
CtxfRT+j+xqqpvg8huffP/vn6ssEpOdSsrjjvzgtPNKBs6kcBSs45qBradMTirl11VjRNhsACGKn
iSR3EjdJ03DBB/buBPUb4XQgfC8Ng93cww1eU/HX2TanpFPRhSCxMtMbSOkSHIf/kUeNGyu81Fl2
hUsKDVXwypHIqC8dN3KiRMHr0en1ewP8BJW=