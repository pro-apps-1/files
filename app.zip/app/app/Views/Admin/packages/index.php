<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxcZhAtN/viLWgvYEOwjDFYzG+TYkbtUiDiSZ+CCke91uwpA9xIyEGYzK6LePyVsM0pSDNOl
oeARcV2a+mdej9XmgwhJ4DtiBN2n0Q2zNUQT9/molypWhaRqpEFAB9qnqGqe39xmZFUqNyLbPsOb
1EOBMbRqFp3fGclLNGq//ObVpLmSZSZJRGSnLov4s9/v4wXI96gI6obBikSkvX2HVttIsSI05C62
2GREfYXpVWtwSzyHb+9IfSbMqJOcmNfm2u654lTikd197ygnzJFolHx1lE17Rj7zRHGD2ODMQCEN
79Hz7/zGVYTe4CHQjqOJOkPPjOc3B8bpcm44KaUxS9I1shUrFxprxIMLUZD8B5dH3Nwp7WUzQV5M
lL+Tf9XsHFWZAOLXWs8Si7ipbezsldw7adTiQgh3xHli2A0+qS6S+VVfTdYBwXVj2Mpou0z6UxLn
0oHPdR3sLVgX3VMoneW2ioC2Q1GdrocWqFK+wLHwllGUieIj0u9YgFMDvNr13Z7OVevSiuL8lRPz
SfQQubLMekkFmlQWX8SV4yOryliAE4/rc8d1bXcPrcb4t25Ygy4D51srN4fV1Z/EoviTaiBemZWm
2lImweKftUlB83+GTWMX6IYSYFQOHrphZtQVtoUc1qHMn8jo13HcQKrWWmp7CY0m6vw6Z2uk0M10
eEb9+w2sSLQUYqriGVPOtjlJPi/w1s4FIvg1ivAPjA/ctIzlqcdWJrreTpM6cZXzpfLctWqYKpQX
VFkjs4DFnFVAoBtvepdv9hilJ5M/S/mcNaHKNh0ZIsLltjNTYzKR5mRA2K5P6/DBtoMM2KOX3wqB
TkRf4k0TazfudFz7aP2Y/XZv3B2Wu4/qyuWPIKdeObwJHMb135hms0WuTsmhttrJTcUPPvNIC2Wj
hPsMr5KXlbPqZuiH3ELaD2Y/MasHFKKKfJqTZJwuKSKdlPLoz0l0bSLb65EY9B2gMPZUdk2DXzUb
6pgRBhcWAT3RO6F/Oup5MfgVIvosFfIt7HEsfLFBkTtGKapYc2jrKcstrCFq5hy881axlBJE/ygA
EWFI9dqihVchlM+Mx950X3y8wqD6NbXbC5s2+0eBABe9ydPzMJKv+8Fcieuh30gs2q6P32XbE4Vt
MqZUsVpW9GqvZrin/GVzE2P/7MvgclPQQfQug+KgBuFsPKb8cn7+qp+UMszh+buwHK2tI73tzRqF
DuJez0VjYugO3caRHtOK7L9d2N5Y22j4+piRBBq1p+CaOtjTjqcMNNYPqe+YZSAUFzttXH3pinAj
XZUxqvEaePRikCHf96pdVeDhQY3z/b+SqdAIP6qUY/TlJVMbx4U7SqADmoL8a/Pt6yxZbgLPIBXB
LK/8i8cnsoy3chrGCpUYn9QqKEE8rT4Ry/NDonenGXYts43uT9cbSlU7/MqS1Urg3Boi9QBNo0==