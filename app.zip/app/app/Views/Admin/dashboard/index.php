<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPspUK8cddAcklWB5gj2bpxLWmSflK2aIWeounK1cvApt+lHDCoxBIAKq96/AVFsT6gPXKYvm
nRqtZM3PY5rFb5k9KcuTB0lZ5ERJkzlmMJHzGRB7ZiwjY9zlG2WZmelk+V1NXzC5XWTId1YqmZL2
5NyCGW+u31yVTiNF9tnS578tBN0/0maNw4K2abMSU0jPISfhd9SOyDhl9cpcJkffU1nEh/S+hpbZ
WDKQWpdj+Dxa8DBC/mgZD4IQHfYhMYziLK+VknJS/sNHyf4HzkDiCNITupjeu6wyx/ylCEvmLZ81
RvzHdoI2NXzEtJ73HFhIFZHeoznX/IkXXtceKCj/iMdIprQW8YoEgRdP8jPMCvrFlnuaYmB1kSPO
Nbca6tCl0C0RABFSU+VXygL7ZjM21hcH9n2TKuWV3mDm5G4x9tV59kuL0zlqi0Qng/rvZzqh+ZUA
wuB38KycsiKouWl8IqlzxFVGaWN5Vt5QSsr1eMq3wHTXjuR+T2F/wTRSRz+hkhykaP5gT0OLBrfF
eAwKbtWD7ql1653F79MPEdX+q9ZeH4fhln1+JR3NL9PWpuZsZLrkdiRa/snaQFmDyUggpmN8o5j+
dNBps991XtncLwRP/XiITFaA6iNxeNqJRrkStgh5TKAnwLxICAtxzXp/dL0apLhfnXXVikOrVb/E
rka4m9n7W0TDVkO5jIc9bBPpjm7W31u4CtRqb8UezTXPYFp8qUsZIk1zWxAyMz1UkFLmAkGgcGMx
ks9dOpO32OdF2bg2hVgqC8H7YlSLqLwRx9nad/lHie7FIevnkT6BqrY5iuLaIV+NWypq7yF2A8MO
21jGZTDC9Ukn/zNZV+OfsXIwqRjxbThDUO5GON+wvgRYkxWaUW4L7jIt0snu1iTpHSOzYiDvI+od
iprtcocTSqcjUBs9rMYvMssvel7flW0nv0vpgOj/foc/lFZ6lmL01WGRvqPhiXCslqPGPKWPO7vy
QiDdeubV6Na2l5AjBF+I4IcrrEVxymZVU5JTowJ04j5q017asyIs4X0rbBikEUnr/m63EA2IzS8W
3l0gAqOFBo+CdG6BIdxQ06xGgGEGHs9xeT0qQjRV5Re/kAThFuiPqtXl/lQUgVGbbirdrSu68hWV
g2uz+BafaoFaMWomldRkYTwp70kVKbhGdxVFzvlLtaqNqsT4ErvRakkymjvizziE5pfZAKW6dqws
nhANqaX0JQd9dxAcK9DgoihvdY71OXdKv64iB+F4PzIgI0Clbu1L+VOO6iuZcger9rJ46xb4eLw9
D08FM6lLeHOaSBb3cCTTQTcfQo5yccfdA/pUrm30bRsjCr0YDk6a/HPU/wa9JW1xjUevCJVCUr+s
pjBKYc18m5zkJDElLkd9Dm6TLe5aDyTgY7Je5zReP1ho+nL7ypXkmqRXLFU965l6Qfp3nLIg5StQ
dWciH4YsToHXCiShOlsGABq0wG/1hiaVLBvYosrwwKock7XputrylxyNnllvftATmWk9AaPIZraK
9vew2o55Pm62ZbqWemw4uygz5yFJunko5mAA8pTy/aUvJToW8WUvPV7syCKs2KwKcy5VgXgK3qVC
NFZA8FZQ6HLhV1rHkqX8dfJrm1wfIi85K7I30fZCIZOVGG8X2QM6MSCR5EC0PtYOZxFMsW4dD62e
23TZHm4YpvjLjRl4eLl/KcXsMPwIyBwv+80JJOFSt6BJrtcZDRD7/uciSHb2DG7c3F3VNFKL03iI
sIwyVvfZvu3n4lOqBYrKChobpVfGXirkWSEib/D6Sn0TieNK5vNyuKX7wUTYDcxwxeX9jTRyd/iS
21mT1VmZfnUnK0Tv0NL/k/CYeNooCa4QvF0F5r2pm8zjtT2cAA0GUe7IwekXuVskXgXQ1w+3uxGS
SY9TibB73MBA5hqPDK+X1unf+QdvLML2SFWig/8FznYbrwrHdx0L9T+h/ZcqyyoYJDqgy97JSpQI
MUgvy7g/JtXWrbiqTkWNY1HpK5161Nqf4Gt0ny31bSx6FJfKIoJuPyKGG86QfmwpI4/OV3Rx4c+3
xAZoBOaH4EycydqBRu9bJn78iSnEqldcnkEHk8TFkUhdT95rIYnWRK3NUo5n7CBTOs7R57vMoaby
xtxtDi2j66zRE9nqwxatnxoduZqRmR1u530t0Q262vsn+4iWYWLVcAg4AByM7jNKhSq85ZOpIK1W
w0g+eSmNpW==