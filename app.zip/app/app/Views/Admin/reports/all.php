<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoMpbuv+BMoX1t42hNcfmelCG/l3j4i0XhwuC1/8iP/DPu2jj9ECcQn2r95DMg4NDgUayh6K
s+gUoVUZOV8o7AIEqjpbjbN/vLt6dvVZM44LBCdJKrzOAq74OHNCyNKPobtOTjpreEJeX5Mc4dNS
nHEO+iTCAjv1fBr6M03tjI138tW0u1KYYq+wJxfTYB+1abDftmVUZxCsf3SYPrwv9qDeg1ggN4q6
VPMb1zhOZhzkPKGZp3zZUrS1ZtZPcbg9slBVknJS/sNHyf4HzkDiCNITutPkDW8tTyr5wi3CN381
T9z3f2EGoNjQAquW4DDdhmeZTWKNnYgWeDqrFiH4KhbatycraDpPbGRO/T22LQYy36avbdnAfkAF
ImpU3kWiBn1ULFgge1PT22byrjATBP3KlApff1Vl4DBi9ihvWBZQpCLLgU+hEM/7KLhkvKPiKKuP
OCMQhYqXdJ+6RF+RApCzdSTwBS0P9TOzSxQHofw8TQhHixPJPPR5cHyONwNbxmMleMjuUviPWmnt
MfMwK5dxjM0kKy4IlgsCj37InLI5fUbZUpbspgajhnmNh12neoKl+rZTna8NPbdLkHrmQvrokRAY
n+qWEIPlnNtPVSmfWopi0uytcPRcL5jzrUdlm6ac4G2Wfp8FcxHmweCsc67HqQ77OeuSac506gmj
cc0XsDsNPpj6EXFDHebA6PxRJfaIQScgW9D1dEQ7j8rDuTdBgn6gRJI4T3sw1DdjhIeXtoHFy+c6
+wWGirQfDQPXnvjzdGjNykZ7zcKQ+U1/xWYqBlnnvDr4JfNHizo2QoPF8H4xQt0LktqXpUBcQb+k
WZlQN0KhOSiRQ/UOP+xJWj8sJPycOFAfOHZFjXKuQzO6NRk46NxSXqhT8T0PP0McZHx62gm5/1CR
tCUX6sUsd6VSp2i5E86E83VpPUMDdZcC9IF7qhcUwozw6w8ADwY39spzScjLozoqdiimRnUyuz3F
A4eSkRP3aRkKZP6amr1LIF/AyOpEKX5y2OLXBWyWihN15noOQBzNX+tJpF6Mo1YemqTNba0isJEz
7aJyppP+d//ibgtl7Kj/n6aO2V/q2oyCySxdLgz3gSYmomrHv07SndTYoysLWADRnwyE87RoeQXJ
mLT5L7K1Icc4BlKuDM/wzrrP2NhSTACHbt2Vk1FcjChjf1yTxkN7UnijnWPPn0n/BTraEyCUqUhi
pq2M4ysoPXSK3O1SJ1U0BiYPdu6nGWQowY0642wrXJaCy0KgqvVOfPVaENX1xZBL46CvfwYIyA/C
/sUqx3RhOBtVZGqM55pweNF4FtiTWe4b5S2BvqCB3tGeMvei8V2ZYlQGNYvP/rqxOkaQ4AuMYPCs
+m34fKyrsF8TjTQZv8YehDHuPI5FB2Uk8GN07OBcaZVAUgjPOF4ugcykDEB2GMUNp1/p2Jdg7HY8
xTFgQ8n44PAd5x1CPysX0f2Mw4sO9vFiUXjWCUFLbUgebmaicvphNn16O6NXKB3AiQpCDwmPOZw+
fzUyGCDzScTjr4RFOO6MPlOhcALWrYKq9HQ2Urits+ebaSSfxl99J2zF8ah6xx5lDM+t5sOOqrUZ
hAuk2Y/pkdqozEs8mQcNTFqHLu5PAVlrjCR5m7Vj1yKIjCLHS4pttoIeHb5eJqljoHX4uPbM0f7X
INS9AMvakirrGmCxsPn6onmRoapJDFR9mKmOuORl5ZQ2WpuUHR1MXzJw1zL9dFa7K3TjtQDMYTfr
RtdbdWzQGN3JDGhxKPIKgedUXS1kwdu0EZY6oEynwHAnS8bR6pfPIvyIQPteTbaq8EuYrn7vTsYi
/OZtA5vpDF7FaVR0Uoy4hym+j/K=