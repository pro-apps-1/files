<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvK7xJBZtjK5+iHu4RofB9kcObIdZSTg88Iup3ba/NIfp0ReF/m84lv/T4u/gDU+hbEZTPk7
czszBZ1WNH5wubxjqzZH57ZEfnIlGAS7/lXgHYNl9FMvVs7ImKLBkOpsjJUX6NHIhLgka2lmNh9x
Zy58srE8jlxPVUD10SCtzSyfGpi6gulGBpt06d30qWMEYunbT7t/bf2x+r0txH9Z/C1sbdc5uMqt
EwTf291hT0wTx84S4slOOqZlg0r6D31mevQFknJS/sNHyf4HzkDiCNITutPkgFo3XBbaANQIdJ81
ZQ1S/tZEItrheQvE9fqQgzLypKXTaNAFELof09b9CohAjG3HLhIFwDdQAdRB1znrXgTTm36n9/40
4hsN9hmJ+XE52Z3Dhx8+iBWlHIMfWE04kl/PXpjxf0xgvXIWl4YIss6ngl/YYbGjQS5CQbE3sEba
t5+dZV9QhXCI/L2sNiADhemDf0hINiuWyrR4B+dQ62XA9oQN71zolRrpFZA6sMJcZNu/PbZ6/7A5
Qn5bJugq7jykJSc6lwIIw0Xw9f83TVhmCOKVCxMRfQZOFx6gXscUdct+mfRHHfSEyLQw9QWxqNB/
8fXPYT6CZ7tsDSQh2SxDAaaIvtYS++eCPtDcPx28NsH0ndkKVr2B3c4c+f2Xwr8ZgR6VhY+myzms
7RZAQ3ZQY7AyTYUlLaIfHv0emIVtDOuCGFiskkwNGmuEa8hH+dj8PeJIGRvu1q2ytbtDDux7dM7f
o7L+hbj/uXxfi8rw+9/nxeNHjOdMUC/jc1QwkWYUCcOjI3/5pjE/Pp+px1Nqk3BbQX8g0YuVWOaA
hTKTUZZ7LgkUkniFCmKs7l6ySyxR8mbBBY9uOcWZVnAkXbJJEIvNc96DNF4B4CfGVQbd16Z91QEy
/UDr1E1eXqckgZyV+2Uadmhf+REiVXQr1F2u/5tChjGlh7yTWF4D6Kf2DgKpVJAh8VziUK/17gH1
2JD8ltAMEV/tX+Yjor7t91+TNZY6gh2tyj0nKM69YA7nKnME0DTRub6Zut8zETF5nA9vr35gtmkY
oo8KrVUiMrkUJ1rLENRZo0nEAiAh7/bRgfqkgAx2WBxWXKzd6EaFHH/suUid9+vtwTl5jrtA3PzG
xp1bZCxE8AOehClhpAzUuGoNlRMKvy+qrBrZkHbi4ih/gaEgex135CNwMtUn2MWH6NqJ2QIiWWOH
1KCzbajsujTLNKt9TOUFWfhLA/aoIAKYJ7CqR0XRie3ixXJgt5FcVfv0O/UxiB9QbkGMlMBXA90x
7p+ZKb5Ofv3ojioCa5WOduWnVdk8EY3hOPcZNFhrM8EijzzG/obWX2HTRjfSwbuJ04Al/611iqCr
A4b1vF42RArxRlHud/wJY27QETI02zz9Gdetc88gyAgC+XbLieiAoZLvMeaW87Lin9IwAseREdxv
3AEJ+fC/QjZB5aRqAZO5lbvXpLcLPclSMvQrjVvKhS8abpwlFZyVYY0vE6F6U8tJ2T08CPtp25of
8Qkge+pH2ctF+dPVfRA/0y41S8hlxJ1wgNjjSTndlsvpqSG8mnDSaQ2jQ2kgOUXfW/H8emF7aLuH
/Yb6eOR5PFaSfHIIGvP9uHHBDXsqOxnACw8RRx/kiTXo3DKsOVEgbk2O2YpkBCxqaMsL9rPzerlN
ap4C2ZT+sXyiqcn9kGtHxHOkNHON4OWWS4kBSoVe+yfUcI/seRjMcwh45F5tGXk2wafSRf2VqK5Z
sJf6ggHa8jbgdGc0ImKVGko02w9r7UQ7edTCG3SVXGoap28aNcM8o3aAVO58g5nkgKkPcZRp0P9e
t07chjT4nH1jxHESZj+Wxj7XSQGvpvb8nzNj/xRFBjcg9s2yYlL84FTaWT50RhQ5CNS8z6CweEtC
tTA52aM54KP1u+jmaKBjRG2KYa89QZO/TytRFVf4rKun5GZ7dLQLMaxn+5OFesisx1m/yZXkpYaX
hpPRWOEfoeGEqR5ilSskJJIy12ApQWW33kRU9u+rjKrixwLDy2/A3TaoEoO4RHhr7dqaJwjrFJ5r
SxcQDKSUPY+PQKKqI6TsQvyEXe1P7+skKQwtaknf