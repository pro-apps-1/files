<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnV4RDsycLKJkGNv/cqP7xbfepFALkg+tyvIkExjeFJYR3tvypy/lt4ebTgjFaTJHRVM8WEM
c7zHeFplprj8TymF8ttOeq5wzmeYARvovgKWDtJyDOtSdGkvjEzPQilA95KQrjCKPtY5Dw5z4xjb
T5AIl4XZ0IYh60AtCiincqn6q3cRRez5KV5B4EP0LnAGUVgRH2JAaXlzG7dzED1rhJt9tSM1bxaP
ljDj+RpTgVkDTLLGFrd5SL/mal9SBKXNeX73WFTikd197ygnzJFolHx1lE2gRKv6L/HghC/2fbkN
d9PzGH5B0uA5sWaXDoZwLd+W6KLSYu6YP+q84m90s5ForKPwg9j7uSYbf5etZcjb8Xnf3YcohI/P
jj4Ys3u5sDNBPnzaYp2E/8xcN1wH+i6EDYGBzYuDwIGsLnPV76wzhPkrMOV3l3AVuu6O8PRzi2B1
1gfjq2oCwONIJs9Es8KJdq83sUyZN0yzYHoiAUvkSU1MAiY00qhFilkK6Io+uubr0tGAPnWHAVEV
7d1ZzE+iciIqhG50aWGZ+Jiz6ma4iuMWqX+2S52X6hvPnerbvtOBN+dMTVHlQk0Bh5vynW46pssK
rhd/VUg/ZYolYSzv8UvPY0gEmknN4V2MShz5YB531A5Pu8ilJqqY5RMYv7CYiHMgoWfT8zTB1x+y
ZZx0k5552AnX8a21suwage3OjKJjFzANBJdfZhaock7m/mlA+xbSKH/SdHD+/s9+la4a8t6ut62r
ADoFG4iqCUOiuPHGwK3DBcmBSozj26z9Pwks1uzTNZX6v9RPPhkO9VB2AA39TKD5Drrzq1U9DaOe
juldL7glweuX2UK0w4H2M/adQrhJrZcrcvP4SD3u3AH4iEQfgI6KfrJTAd6MbGVqTQGArv5zeGA9
f73M/MITSFkEjjVkAcWIPVzhES3aqsw6Wbk2799GfSfHXDtjs4F/GBzBlYJ2QB/vVI+6DE6QkolT
GNtE9mkhEafPVyfcG7jG4Rtp+sBvyoZ5Zzq5i0rCupyAcAdmrYrgAQxMEDF7SL8do7Ched482j7S
Yd13auwzgKTo/tddka0pnA9wPTaHNLkOLTH2EhkQsPJQHCbaFiURrGLoc7xziA2i7UCo95eZ0ddn
51h9A39YYHdUD+5ok4gJl/jV0w776S/UatkT9ufCzrUYotiZdGHRisKa0gAjKrkuz0NCQymdRmi9
J9T7Rnx01Y2Ey0M4lFfCen6eFKKoQ1Oxu0EunfVvP9bwrzqsIOzyfYo7XVK17NzHdxeBDywZizF+
CYnIcxImVGgQ4PX76M9mRjb8eRXmIVS=