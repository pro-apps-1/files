<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+4HyuEypCUqkT9ceA8fvN4rHmZLmXnFN9Iu1fh71CeRPg4OvSYylhAaXZWiooimdnA2w4g+
irkSj2bYquYqgLzg+u1PCVQn04gGrrykr7nU8PGuaId3iQrX4peRfQg6lwZpN8fVkDqja02LtJeQ
8DW2yJ1pGwK0s0Kg+/TQaqhLCJjO9MA4r/jm2wRKO9KR+JJD8Ao4m52sHuDChpDTIfQK9gX0d7zj
gvVuv4YLhsZ2fjFzuF+wdwSovT8niePfol5VknJS/sNHyf4HzkDiCNITumPkuHD3C2S5cp1Ga381
Svyh0m7kHejeMFj8On46mnIMyiB5kHPnedMpLyA7fv9yrxrGmXlSKxBuT7BnvBNu/q0vi3YzOtRW
ypTJNZvFDEMEp1nmrzaPr5hWhfZAgoMZTQOj47UN9YNPm2Fkkz1W0Wr/+fx0g4+sZd6g5tda7CP2
3GfPK4OdYD2JQntgDQv9puQMcQXM7uCUG5XwQKipTULkc/4rCsrumz5qAT/iHVQ18UwpaCZ6h7Gg
6bpoD7QiTfK6139s6//GBiqhESi6FbBJQcdtaqJGP5JZ/PRIn3KRi8QHkhI+myC6czPLZBU6bgKF
7Xvmp/tY8MOvfU/gHjAeHMF69GRx5gAhAxxIuxkI6IChZMcsg5GTexOs1MZ/krmFy0FYuYm4Ko9G
lHshuL41NizzTi4TgL1is6XrfJBfzmP9nWN39yZ79mC/IquRJ0vtnbvBR3C9n7rKEKwXGAnbTlSx
Ec6TTcaDjUQfbqyu3a/EaFGdIS7LZMEWZtMW95ahqMsUQdwjsy596dkQjlW1UPOfB0EqZdxxkVL/
DelKCxpgGaasirjsfvzFHaTe00m5FkPb9Lexz2ElmmFUE2nsf80FKplr7yQJv3c9p2D81S9Rhnfv
gk8koeVFoG1nHLaYwur+Yv3fIUwiT1QhD4d9fNIB1BTvhyTn4DvJGZ385Ew8J67f2dZ2IqNWd46H
H3QNL29fPhyAThg/ya7RwS/aGxD4LbtOtq54K6bzJ4OZdz3lXrs8ZJbC+n4GTgBdsBg2ng0vkYgs
49hLhhLeB4P8Ql4iJshH73z4gzFEhDgjo9ernroqRtrF0vCCBgctzw9z13Pl4mXXuWuSbB9R8/0w
yJA4yhzgSa+2MqacU9xEhhgkwjjtsLaQavYLevSWbYS1L9Ag0TNhPA9EsH9yr38pjOl0lWB6ls4N
+Z1mitWnMOvWZP5cX5EOYD6vBNOkCBENBp+M0sqqz3vU7Kro0O10+bc86tF3/1mQyz29YRiXOlop
7zkxzRrgbcEp1cd26uQyY+QORR3bzqsKaut+EW+JA6yV8LajBZq2trOQz+O70UE790gvem4jXCg6
yrflvN3DNGkSkmuUYuddHWHI2LkH0FqEaoFqP1d2Io+j/VXB6sOjCqZv8r/gFXLp11fGuv77hAI+
ZO3zu4Dqwe1fc/hmSqJyfnwgdiqj8KNoovZPRZNTg4+qRzYa8eZfRAfKa1ruh4wvFjRZARJxng4j
ehzcXmZlcnN+i1y+BdHJoQhQarklC2XVeQkRv2PTOrP8ns8qGVYw4CpjfLT10duiWx3Glcd2jEVx
vdafEXXUOb2AUNb3MQbIdlzHfZ6sBSFs8MWfD69CcXCrCVMtzB/vrZjajzVbNSfAiDrXe1bp8WGP
WQ+l+Di1VwTegg16Co5JGu6ZypU6dpJpkm+DHEaCAr+z7o5y48J9ilvuQaoCjxrP0dVpFnxznEdg
cu/0SJOTQfvK8LY4fatJw2K3mV1PkSbq+QleWud/szaiSzBb+aaF2MaB5Q7Y8K3K/JbeYrdJ8nNs
GkF1J+TVs6odPSlykPcawrQvX1e3/Xf0T+aFzmUCwIWRSqweqlt76Fjwn1hQbh/boobgbt4GWkI0
tdCb7E4tFJySOKIPN2/UunoimLelmuJjo+pqiklUAB0BtuiSZpAGPx9QpFlUER6wCS0hFVNpMYl1
yYgdTO7OQEeiETTUtM70RPADsjoS75P72IHr3bZIr/+1+oq5Ahfne+I08+C=