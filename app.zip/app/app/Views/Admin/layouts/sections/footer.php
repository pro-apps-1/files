<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPog3mUd+N3hEXq9Kolw/8voLHQ4MVFck9gUuTzDpHCFW30eacvEVU1W840HoQeMVpUteYbZz
fNuIbtuGZobP9xQU96UFHCnYDCN3DCj7T+5Py5lMENpJ9W1WhBkNMF9xdTvsusGUFSyHJW9ubdsa
GNmIkiO/h6OQHu2eRP5HbLobqZtubRv58KrH6neRbcUkN6oqQ9efOS+4oNOV4cI9m8LfD/LvQh++
5z25dYApPDBunokL0MsmxTWHfVcqXJKwpSQRknJS/sNHyf4HzkDiCNITutff7PFAK+O9U82noJA1
n8gTRK051SkdSo6055n1jgpM6PiShDNVYiq4DRtoicE74ws0El0FdENPYmHMuB477fLODkEXwqsi
J3gw/s8QMHAcwQ3fPjOl3wGv1pL3FrgSYYineJFkUGCUrMzXHC7MyCqzYcE6W1EQXWVabzESjWwx
q4PI1q976YO83y5r3zKVrRKkw8jiJ6oCf/8WE6z5sPX2I/h8+i4VnJ5LwAVwAnJf/x50rJHnmLKr
zBu461JoDTOz93DLuXwsuUYWVp6ldgOIIa+8otBvNm/F9Nhmla4+GNUIPHv4WoMEmpaAhMBILrbl
iY16+mYaMuVBxzZG0DMUpSUCBmyNpsMY8+ncd5OR4MyFHfiomihnQxq8Tr1dFPt8qTmCAo4uRqd7
DsMVPz1kCZgNrFiW5lBi8vfpeRECS5Idffhkiy/0K0N88XSYhki8ooeIGhdGom6EXps7gJl1XuRw
pj52pKggnnb+bGkSOKcLGtYsurMyZQSd2TvUq3X2nhxCaA5t7Lu8Qf15s23SvbvvwBvP0kUC6P2o
/p2DYsPhUYSLDMmWJnn96xoRUPitARn0faU2Xfy9iL1H63koKwJmTrPYPiLtjhz+e3Mb5IHA7ezy
OC3F++jBw4OrQ11zMadWBXl0I54RSKnr6NpzU44AVRV4eVe6KhRUfCza0mVyOArzRruKg7ACAwhp
T2a0LjUx8xfk5BYHFccid2p+T7LsO0N2oI0iQTuDvSJCGhVOK5NJUY/DZwriidK4n6eJoECcKR/L
JxNF0W/PgjwRg3IPVGA7Hetrvz9PR/8NNpX+hvKrIhymWVaZJhZe24o33kcTLGxWY4jl3/K6eEs8
+WGpDWu6dGJbbmLoU6JpQ17AalJBvK5vdPKNK6fPic2KHv0B0nbDNMVd4sPMJVNSYp4LVuTc52kW
P1RISIdU+COBXjt49GPAiUGmL1ThI4iS0Kz9dL2E+AsEBqXsTI/h+D3Rxq79oGkmsCeooHuGmQHe
ff1z5SvmsoDIbFTIiSJ9L4WxK2Sdje5fiu4=