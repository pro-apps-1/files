<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuQcdsxX56H1/7eAJIsasumlR0hEWrrrTRcuMBm/bNtKGVMnqzG/riF5c2+EKyaDL83obYHo
7MRvQW5M5tzlhLv3a3wBAsfiImtl7ndNgGr2ww4bxC9UAjPD1XLG8L39b/a1X/d2RuMzIgnbaXgZ
WEHNldquLOf5S57SGANxSkWemkk/9Li8fgSH8hLMlJeKUOhGY0Xj/kZyLrA/KHbWakl9/2g9xK9y
pI5YSf/1W0h0cAMF1RwBbQ+wswwV91Ri1KJnknJS/sNHyf4HzkDiCNITuybfLqoXp6mNuR5MaJ81
YQ1DURhQpIHUntjpvF32bMkQ0k6+Z8tKIqhUJ0LuQ7P6zxcAzu6/HwPkxgjxYmULxafuiw31tEfI
uaA+oQKw7MhlvR/RP94kcZ6vXgmG7pcHMJjCsv2QFxdmgOk3QeGMwSTolGkaU5a+EagbJaLlGrGM
dtw+yokiBTMOm42DMbHYf46pjkAHmerKUXsjDOQbvm4thFJ/o65EZsb5z8lCqpgxQU4skmO0BzCO
vzuKWmgYfxbEY7RsVc+VQapkAWm4KgIxyRbSbpHeusWNiEywHsyUUMBYm0N9TEFDn8aBPWZQi6AK
TniYeyDMcKT98JS23s/0x47mWB/mmiZVHfrdVRQu10ZL/zgzZ5HNXJ5RM39p524E4jnIalFgKpbd
QLLJf8W5mgvNU+6/eS+W/ChGGOxTFMYQg55rJJ3NVM8mvUG5vA8IeNX76HfzPOvUOUafOApfpEOp
oQPkoU833zSYFiAlb4zJfoFkIdJnSWqlN1ax2NgWpvqaZpK+WHJYOR8AOzhhvvBUSkF/WXsRbpCg
LxagAJyl7ruPgsZfQmCuCuEn7kxQv/Bkd83QmfijezAduxRqoOJzdEDM7oVahhEgG0rTV+6Hm2yo
XmKxydh12FBMWNWGSeJ34D/JrJR+6RA228H4m3ZzrLZEQu4ngAPwcoUiPxpNk0luKRInfz9vWWYu
0VXmTcIN38OuDRQy4F/MsYvy3NGk2sYK7U29w0QoH5T0soucgYOcgKN4pjNdAfzW9+fvX8R78BgD
7i6/oV2lc28UJx9khBDBhg5pjSbrC0tj0IGZwU0R6p5TXayu5MY2wvQMY/C+dTuOh0RULE8rAkpt
caV72TWZpc6zynfsoI6zrWBO42HkiVC7qMtSqAEEZD5DouQwmJt0jGml8EtNI4t6i/5TaCtli0bt
Nkr1DNWnnKEUq01gUpNBtnCQK85ZuThEeSvb1yREC9fNp2jM5y2uQtFr15LsPZ8O5paV7/Ci1pyZ
sIGdK5AQABdkYLGMUfOpBQxhyE0bos6o00wz15s9nyBJ0nRZZOJ3VzLX6YU+R3NdDn6qloAXlzkI
KECOICwTkp1aV6DMWLqlD5A/5HrsTZ5tcqOcGwYkjCvoFRQnWYfnPXosQa6K2GEjE02paFEm/sdu
Tc4VZUY7V3HceJUFjKYl+I3kWLfD+KvyvQm3yEddNbQbQ8lfS+6RdaToWGzapUS/GDRkYYSAal5g
2Kev8bZG3bT2rCgOvVGOQd9hEbbHrrKQYE7oepr4BOfT8Reg7mGOW3udpAccs/JbBXumLB8hsQVG
1IvA4TVYadoGW5awxh4w0He1LwnbeTFugwzAmxE2z7Qifc42EOygYFU7yAVMvhkTM9bNvVTfxleo
rXkzpEHCCaLYvXsEcqf+Qz31L3TCXvx6dfivAM862eCP9M5q0dWZ64RJh7ldGD+kI+Z/vWwY5XRr
lo0ZuIJtkFHBiVcZtfkGDLIkZtS6kna8lOF0r3wK7U6WSyCxX4KZpfSm7NMN6Dn3wzSGh+LN58Fc
FY7mnOXMJWOhkYEAknKbEWh003Vc3JT2okNuFzbds6Q6JZC8x/oEifblVWsT7m9kaDsE0wcL+yau
WZz4exYwSOB5UlO/BmNCqF3G0Bq/HWw2k2xOSwz5Uj3qKZdzJT86jmXxJgBjJCcTAZWxh6m5/kpj
vi339PaKQVT6G9BtpvsW47qUuc2YRRjdOhox9cN4hH+ft9PzSMGAv2+EO1XR55qbP0y9p4rq0HW/
ZoQkHyPk8xLcjUZA+0OZqdyu2CdcA4L+kiwJG7+uhbtrGTEDei1aFRHlauD5pV3gYcbFv/uhg8r0
LnlnnTW97MdFP9mxsNYCwp3ELqooAiJLW6bcInCfi0BhNm0JoxFt+nQQuvP7wFuTHu4L/OHOuPQR
++uUc93jBIyhBR1jrx48vBVU5k13rBZ6dT0MaXMXdwudRscLMCQ1pWJAeogCxwydv4PMwMqTRnhj
suinG3Uka/jW2XyVAo3Oi8mnhVwocupmG2DjvvC7HF80QB1lRXppcFkQbzVEo7e85ImHKwvQ+qyC
tfYp4f5PqITcpnBBZqE5WA1ZHn4ifcwZsNXcnVr/gMi7RfUreTzC1QVk4TYV