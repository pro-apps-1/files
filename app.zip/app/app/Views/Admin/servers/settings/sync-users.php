<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqxF0e8qWVUrmGsNeST91hFeKJkaZAPd+DOTYaTQwsMoZniKtHTqwowmw7vl3mLoumfTtwGE
d9+CcZKwFYepB5vlz6nRQlImJ1UgsdJvEERsQ/RywOOpEgLgcNjENtlh31MWbq6O3teExENaVudO
MdA44xqolBd/3c4sSBCxpPy1djhy8Yozg/qdWWUWAnuFp40jkTYPllnOUCfa9RS9G5FSPbBYHF3Y
EozQ5uIKNbr2vU9Jfw3qjoj0kaZU60/8KfXKQxiKtFzbqVAH4VRZR35qdUCIQkTGIh42GnpZ0K4o
WOYWO/+w+p6FWrN7vnQJMr1l4V4unSYw32xY3XTwE+fdi3fg0s7OdCUtW166+qhXlykzC+Iya7ev
oQ5seQ8S12Q9XJ9eMbmTKkXe/BrBiNZkvCeojcUNaUNqoP93QsgwizEm65s34JqMlCgam2NbD5+A
taY3Y/ZtzvLkDx/1izm8QbehwcFTCI4PQ8LVL7XShctYBTPFRnkEtBZLpM0JUE6XtIvoAQeJTRgS
hsoILjOBTO5tDCGekZFpebBjAyQnKoPCJ9Im5u8x6jd6CXtg4RffQ7JEd/WBFV3EGMvAbzpgCEuv
WlZy5iDjOMRQpwOb3lk1P7rrSkEp4dwagTjKvMteydPL/th/UkCijn3a1FmSQTcFZAtWBPrJ2Juw
vV+JdE+BIh8NwzSgOn1FA/ceMW7LuUUmV7fx1xAmR5CAI0D2GNbirKTX9DmlHNAD65P+cKi547NL
fvLB4O8LE6s7li1YMg6GhZls+V6/cdic03ItO/N1fEKAqHBg8eJtT4ve6ZPuYvKYP2vjkY7HYz/R
ZNKiEDW6oyWq56MYlds8IqldeywcYs/ii/cPUA+2eOTZRin9CFLjVXbq3z1FHHt5mDpLQArdgCW+
SaNBYkQ/pUduZMyIAXbuLhoAGJExfi8m7Xm/QFF2AsNZCJrFxAPifgBnN5+5ekz2PEEfc8+R9/AC
BECd3dwkMIcoWLSPZipocjU0jc4e0I1Svp5zUZQ7HWnEX12vfbOsfRlmmixpqBkDHL/dlQEY2bJk
OuzVUu0Agy0HpQPYrZ3ppC75RnXTEHLMmbUD8Nrm9orUl5/dBXtDB9tdY7HpNkwPO+l/kKZfanXt
NpNrnstTOpETxnTiI6RPP8TK4jcqm6RHx+unOGJcisZ4V8aomRCte4XbiUUGPSUbAhX7l4vHZZi4
Q3PAnSQjuG7idffNJllhjd1wQtxgKftML+DYhI8R5UapdIOEIQKP6qOak7pa0xmkk2/vKWyvOlud
yAPK2cRfpNyTFoFgi96rb32eLa1gsLDKcEjGTwO88pGjOvUn707jIP4CAoK53b5KXHfQZb7dSNNq
pbbcuc+Mw7tvhMj37uKcNFlWcRzq08aUa5FYdEgVpJH0VOq2/inZ+XpYaZLIn86zC34//Nw3FTH1
P5A9aGOfa3jdxZtUkzcyn1Eh9WvBBZ3Q1g0BUo2/xahtWzHVU1qe6b42NOLoee6VEpTRHnfPfY3O
u5NywoGwJS7cMcT9sEKEYMipDGXRTsV1S9TYQoCqGm/BWC/EMUnjodFddl4Qtj77qsjbqwy7TB1v
xoRP48ilvQu6VIJSVPw2k1NgX7C=