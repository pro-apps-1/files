<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwWa8mrUk9SY9+QsBdlbCoYqvV9eUCenkj5FPNvgK0bXWPqaA5ZSXDqSMeJI/H8AAgMEW4P5
Sqo4CP9UaDLFjTKcAk0vXUp2rr7eqfyKOY4tma3VPXPfA6XxesNe5zxrudDTwE8ltJ3/1iiWUgKb
ns29I8sk0qqNqQmY0e8FIeK2IpbHZVChkX8Ir4skHuWaLWWTdtbZVIWM4aAaPNuwUD3ymi6ImUxM
6UIUWhJjA80+Earm4Dw3jbohxoVu/TupCbRco3ltRBfmIH/AiVKpyhqUmRpWk6Q7Mt/q7sbppizw
bnoNVLf2s91Z75O5MpZ1Iq+damrVt1k5BfJWELcRZaAmURdj0QcNPk3/bgYIipzfTe0tH3B+hql5
8U2iFnDySAiPqPrDUXW8cgjHl30iuYvbnhAaHognC/3zG93BLpzO03QuxH2CguK60Eu1i0nVtIz/
+Bs1FI6RJr7/ZD9Y16F0HfWhGbRd2/M3RR3XrooU6nfIyGo/13kK3P+Zky4FAZ4ddAVO6JAjAHeB
FyTcq85T00utaajFpGZf4EN9lk/n4FfmSuOjLd8Yd4nJ4xxzgLtfiwpUkvuYyWOg30xhDsFbxeBp
0QXuzJqM29+i/dAvIyCxGh7Fczl73IRJc4jDruuu2M1yAHCI3WtM/4yvgRaYmX0aHQLgZaG2O1Lr
uPWOMuoFp5R+fmvwfgTEjx20qOwO9s3i44VuVnfoqbS/bTnSrT9PXE2XHhLqnZ+rFgkoTrZNCShP
PaSdptwQ6eN+C6wD7CVZTgu7Tnl3QaCcnsGTuuLg+EMA5pHsQeBuLv1Ln5xtjtFDaIZ+gUX8ocfn
HlJZsd9Zoo/afhZLkyKNlIKXmrNCHtqRCWYyO2eFuojTHK7gbfKdvqGaTup4sli8wMkwvv7jZRid
0lGL0ifGMjVy1L9dPg18m6apbjMpmjFEwWhVUjYqqCqae3CUyn5bbcMCg8BNbHKgky/PZCRFwzZb
Fj27BL/LwahYfzlgk4yBSvr5ZGMb+NNdK7cVgJ15UmQcmuKUVWHrBAxMv53EoqSp85a4nU6uPGuf
ReSbtRnYd2LZiWeUeTxIFpd9aDQ5DAV8/+T/ZcC2kLs+0bVizPIwm8gqWtKiPwk6OkrsVEpU1O5+
xM7PGWTiTJhdoDH+Y1RhagYBqNABGMF3zbCePlKNABuENPkZ+v26zo2/PIlLNBrBkFXrTbCQCo3Q
dSVYXKUmFKdvN6zMm8RZR6mgt9rbAWsZpGRRZcetVGVgJ+3Yc3eviwJM3lZF9uCQWNpCnZTCaHxO
UYID7zkHrgDZkGNkv0elZ0SAgtVGFJKvuGmfCj9LZdVQtwHYfdu4/IVFIwP+a5h3COa3C9KYlF8h
ILsW0+B7Mu4BG6JYqv69IE7lUzG0cHPDrLK7BPWQbg7feY3TIFNdLSEVpSHXNsIFyFsl/SV3cWpn
QZ6IMBgKLSNuy6kOpYS/KcZZ+Lmjt4Y0AgsNBE17X5g/XlV8RZFglB4SfXq8tVpV7KZYDPN/ju00
9Jawv5CfgLubZMH/YmsV5mqkVCvS3q+o8vyxHHZDIfxK/wRKk6LKVEmVtKBZ8B/0hvWeVL0wMN6d
oz3W2wU12kggc93W37tklvRgTc0=