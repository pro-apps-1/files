<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvy4j2PaoWm9STWX1UsVxYmCxb7KBXlwhR6uBOOlp7BOgX068wW4nEdNzL5dpV2TUa/ep/eY
gxlY+0s2N4WZHh0+swz52g1MInz2N4NpoVpVfNJuye5ghlOS/KiYuaINhKoly2P4RVU/SI2YqAGj
sxRdG20AMUuecOqj6Cp1D6Bu/s8bjGc8Gi/HSggRoE7iwTYTme8hMNQde3C6sPa2CVv3Fk07JFaJ
9hglD2Bm/CPMo4peJbbAFTcE1tC8fmd02AODknJS/sNHyf4HzkDiCNITux1iZv3bQIo5vD+q3J81
YQ1B/xYWxPb2s8LSJHSMTlhR2Q9y6ffAwGY1Duo31uhAc+XcR+4Ww6VW59f0BuxJ8MmiJ55SoQqG
2qOM6f0fNqKX4I5WH6EMO+LJaUyJTU6tQqKIkaoQD4n3q7/662f3ZT289d+x9x+4loPMQlP14q5m
JgWkfp1iO7k8zjbMXOFONgnRWZlRInjL8nhlcmm+z3VCd9gq/dC/O9ioLYxQynMoJk/o6SGuSvcv
+X4jdqY8pUPKiHUNrlar6IqYMSPkBlDGeMxUeExnVoCK2QH/EStmiRP8PdnB39Y5rGwYpJZ3Q8cP
1X9/ye0EngfAqZtToJUtUz/IFtogAaJyysGwRdZlaY3/acap9Xfrk03lmZKUUA9iPxC5lkfv5Uvs
hrSKMmdYszFu7NDCzsoVAt80yPX0G1b9iSV+uFOL+dhlQw4Hx2Wz480ep28Zl/hRvFIbqd6U2A1o
peyNAPTSD068mt2mC0PRNX6dS/FGZjdCkE19hzawYCdm7NDJRDZzaiw4L4KISOstkxyKn/2LqXkk
RpEAaoc7Yr9YiUG/wgfhTE+HI685EYl7R42px9lHVEJB7wAfYevB3yj82Z+kLUvyFjzlEH93Mo0l
5k5qrV+9Oz/Sqyd+bRGQD3O6z84Sz7DdOMRPHIUhHRc1MJyh+IkVtXqBTW032vdjMitq7ghrykTg
JsDgOUiFmJNHJ+5/jjoov8iZPzn6iEoti6KxYQDCKMYKOyND03OHWvs/eAszYk3yIhKZpdBsuEXL
ZxbRfYlS0+6kuipQLwgNgRCcR0+bXHj8d4U70uDVcZzFPq2dpfXLSIDxKCxajsyMIb9QFi8He/VE
J2nTkSjeAyx359CE8fHWeIsXDUZwFa54jYIrj/RUYcFpnhku4HKe+TYeGYrWggVCXbdrutqxJIiv
GwAaVPKmD8QVasKGq7SDYTM26d8cxyiOCrJ/3x6ufUo7tee6c61Fv/8gJimPh4RzjmKRi7VNCFe3
wtbJ8OaQf0z0hl3YWSPH4xC8VWgBQWZdVnRAoVEmCAoFOrzHAqAvf6TyXZxSuKJz1o18jrIkWzMa
gd5nlnfmaSfXRKDZRbhCf5caFwxoR4sHjtFJWD4Jld930gx/3qbys170nB4957dgGaoTLyLGyzjk
ffFBS6VfcToNJnMhA+es3VsLoDkPCjneXmCz/nFl3SY4bSgsdaLM6FeTZtLcFylmiuvMuEU81FIm
L2LWKDDKfDmVOetr8EGX/sWH00Say0VU/CmjC/waBvEQO2BusFjv5eFHPvYvJ31weLtqhntWu4Fr
EEzMCPJoV5oDQEodVWnGSGVw6flZgsgUj/yqfk3sfzuob7kR+OrNYJDEFfijGR2ODIZEXJK+9VK8
tnIes4+35VRSCMV/LfnVpVBvYQOVfJc+2J7zn5dkg6QlTsXPDrlR91LUoArbcNjDFRfArywv98Ml
WhF2q4Yu/Vm93ZtZbvENZLTF9spkzeaUIZvsR0F7TpR3Lo6m1G5bnK7LNmOhj5vUr70m9zfNtVqS
xeOarC8mrdNL7kiC+Xd236S/k+TmzcejBzrB8WTqLSkz2SDPJbIyNKoqBRM+n7ezbgOAyaXNSY8i
FseNdDhJqWzw8md1bYoaY7gde2Db0SS7dG4tBZIM0+QjxBdwc+qQdTdvN0gvWXP5dK5Y7ExnZXsC
pW4Hz2g/aHHs093lN1IN4anqRd3g3Gg9Au79HjTVcY0tFb+Vw4sk1QXdxSjZWaooBCkdM6ktBjbK
WHJReRGf0eO0JW9U8G4JC90xsBxd+nCqW1B/LOHpT6mYXVCdGTOth96PnWCVoSDOmzLZyxvON6Jp
8tPcR8E4k4Ytw3taiQu632ELuJ8AJb37sSAaIrECgcREb5jB2VYUCM6t5E6iTWSnpXjpukk+Hleo
ZflyP1rEP/nDEC3kP6+dog9RD8IL8wR/EwLQrk27lLgec1WOpjc/kDC7eW==