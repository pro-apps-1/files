<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvVncd7ZOdz6+Z0FKgpffuLhmvw/2Mp08S49QeqZQehaK7m0cwwz+N0FLHGsgvnquGEDVHSD
KpQqgCJQQcuSvgHv+wNvdFONabL7u49e/BifchXJ1O+wBbx3qxliyUx9VEMEpl960Twgb4c/suNr
a3l7T3I7QA4McL1yZo+BMKZNfPcmvMCTlwBjtlAVsk5o/EZ0X/Uwp/u3w5SlNfEd8NGn1/XTLG8l
KdWNAaXO/gicGmxIk0pdjFa/w2fmrwUTPasuT/Tikd197ygnzJFolHx1lE26SGvW+aHZXBOMm5MN
d9TzKFz62B3cY+e67Dbh6vXH95dtACAoIvvdRgQPqO22RMkM45sgRVyVBtyU4ff7g19tyNDTMKkl
rKRl8GWLv+Ck0p5cxK/laSiLduEP/7OTn3WQZai0BVVIeLQPVyjt/9ZqqXfWG9BLvxZdWlgXuTc0
Api+rG/kkuPWYuLN5fOUzy6HMJOeLEGadI6Vm+2PZDmclKyZeHyGq/IPX5d+sRPW7mX7vG5JoS7d
gdASS5xmrTo7C/DFpgwRg4scTuH/aMHQNov9+1kbL+IwvrpPpUL/hIJY71hJuat5oedC7UGgw+eu
ffVVyFZOB3Vy+4huPtrxe4kmzaOLw4Uzb+YPaUuISSSUcgpJOXFzkiKdijvatVA+Bu3OYrIaTWSf
rw09MsoJ/pjSYASX2lPkJODpTdq1vhPb2rmFiGD6Jbh0QseNm3KlN3HyYqqFVTmXKylmmEvWzMmi
0h9To4wBusUT3o+GLD0Pa0qHx25tNciiVy7GDLgF3b+lVRsjT//1fwYDibuUBgUFTaig0UtvEtT9
5j6GKKsb188fecEGb+eZsCsU5NramTt3utzpvZgHXUmkdDB/vFuxGE4cptVofD3j5mMjm6wyXo8d
VvT9DC+idSbCcLo3jpqcOx0JjpZDvtQ2M9t+7oDJrP7u+5lgDcI94jb2Pfgb+ZYJWOZG6a7TM9yN
tk+puvaQD7FZ97ezusAnM/BM5kPBIkcutxPIYe3h1uFu5TzT2Rw5RvtcvypiRrIB+u1T2oal1wBR
nOPB4drBpdFHS/d2JV7iyLRi8Fu/F+ySAeuH6sfLiDwwPQ6xUqppYWh5G6UPGgQlMswQ7vbgu/TD
ckOxShu0Lmr1mvJE0aqrR6eWK7pKxZl526iMPc8RD6CSzXqqQWyDkGqfG9Ng77v9NngMNpPiAzDU
lXcLVUaVClwqme4aJyNHrxtRSGiAKFDEd4e/a9FsuW7HKOsTFJ4ec1dT+9qxz0vTvSACw7n9vjVK
7YCPwCWkIg6JTNaRWu1+DUz4bNo4xzcU31IMt1zi2SXTGnL2WT+I4YnxUvqrHa0DIaSfYi6i1KTh
42l5TsQYWP9/7+qSyKnFE2FQtoeTqgElGjXVhhlPdCVY