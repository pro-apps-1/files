<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtLGHOq93xwYr9FGhjHf6ZWtAwaQEmBt6TqZRYRnQG+oUOSv4no+WjxwDBTtpm5hCcJw4Pzn
ffImT0Wd9lsIb4gMPRQG7CaTDKftJF+IthlrQg/FVJfFNnQGQpcqQgQ8Y7HP29SM3uiKDgvyUZQa
1PxVmYmZ66OCJEIUcBoxHaS9DINyd7wfY9Neip99csor/kxMKM85orHb/SkbwL6Uhh9cjhfXAqzb
OemNfSo+w9RimM4oJBarG2jBpf8FvLC49Bd0MRiKtFzbqVAH4VRZR35qdUD8Pd65WeZ1jFEhjAmo
0OwWFS7xB6L7mi2bQrTqPDMmpQadEwr9v01CYBl9BXD1K/v5mqF9Lxu+1duub8W7X4Xn+WgMN7kp
/Mznw/KbZF2teROhFxmebJJ/fZyIHyg8hTILGuz5uyrMswQBEXa5+HB9+LuLOGi5zw5iFgDVZzEq
hKszB9fCpfkpt+cdzeMoKd4sm0Yr+P0/yh1VIoIcPKoQ4adb+f8nGeprFaxFt4DOFr3yxbrfyvrA
TdImuVFpOEJfka+y6PE97WgKKStto5mhEnNHdKuzBlIOwElj7Q23y05mGFj0Nrp4qn7R76mxNXoE
k5QcFRFU/xwb8zu6vWlzWMQtyDETEneBDddsbp05JTHYCvAQ65a2f0b8/nugAmwfqLZX1O6Y05Q6
SHPhcXDCQfTz1Rkz3I33EfkPx0Rooo9JtN31YoFsWNCcXhE1gBZD8DehPMeBAB5XkeCSVgDBGYFs
acmTD3RmdWJ15Nvm0Y5CDlBdNicJbMcp3gZenef+L4FoJynxiLWg/xUvblhGBRnR45PcEH8g4mI3
L9x9KoBp4btlQWzM4G6GR1IgnGxPfOgCo7n/zEd/m3/iwdE00VAVjDTb7pyNc4Ty8XdHloug2xOY
f4X8YEGDrQt+78sZD8UNBZUpMyq/dtaxRINSoma4jFEpgef1u+B+3SkKIBLWFXXv4BEuWZTjFZJA
z86nlzPIi8te/NEC25TvgAe4I/qqTQsxt4Kv+DaEmzGK/pYLMH/SvOtxiYqoV0FWFev/KD+8erI3
jtsssTHEN5rnXj5TTPWWT2LLBYV/39SG/X09fxFI9wQ4wrOQlEEYzA4gK+DXRX13IRNsoqm0QdxJ
K/4vUJjtg+RtdYRLcfQRlWQcgfX/uPTfTXRcrapi1Hi7it+bcImPm8EJRDd/u+AJbh0pRfJsMkLk
x3dnQjW/1Xs9jDEOFuSPFI7whnPgksoqdfLDz3+HKo35zJdAYKNVT1oTkQRp0DlS3Piz6T2n6cVa
opWgQYRc6Ycj3HQwEpfTH+KQ+yH64LByw5VfDJV6CpPptmKVbxFLdqtVRHH/FVCgS/+oESLmDi0O
0Sdqc8ztZtVNGUINvGt2QER9R2hbKuyCC9nCoqBNNcBFrSduHRYpggfNzavRNobQahcV6ZgyRL6s
O1i+i4+qRz+T4XKGfx/VS/xQY6DH3PFuJp6PsQheR2d2wkfCr4jn9+wACCtTrYpZd8/dZ3KOe4iD
A9aO4pEZODiJKj6tR1IBPL4YrQTCTP6vTiyA5Dq7aH02wlHTPGz2HD8SuFkZRYchKPgAyRAQvfWq
f6TsWAiifZa3eAkg75YOdYQOiime/YXlBJHuI/XKekfiEbKwzLiSEhiql9e5ywCkdqZw+DEcgN7M
8sRTLaaxQWvPaa6nYPXy+Hl+Zq5lUfWO7cvv4vUcz/N/UDcDsbg3NZuvmAcBj/ujqpumaPvom2Ph
oonYy/843j+xi+4Vj/ZNNw+lQMHvfI1Zvcl/ufYMtrUPDzlAEh1zmnd9p4POPqP4NV/cppdAHqlB
95oOzPShMWG4nG4dnXDFmg3RxzZrN0vxf5sX5SEjZuSRSBuITgPZwSKxaUZ0AlTdColzQQdk5So2
/81HbdQ3NHzUqarB807eaCS0srMf9/0NHYXr4OMw1jH1pTpIAp0xQW8NbFC60zvobGCPexUdTGiD
v4hzG/muW+KP5kDJ/IqZie+hb9UV7nlxOE5MOQuotB6m4862JW==