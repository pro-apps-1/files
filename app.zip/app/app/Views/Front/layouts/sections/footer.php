<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPszVJzS6yBCOtvxQz3vSx5/3EDPFfvHRshsuCfZQUL3IE6Xjy7TXXxVW2sx3m5OTYItJcGBZ
4zF8ihjddOSHnbI/3gM+pquF7XbrHTQMCdHEboYtolLnukuI+0m7zhPtbByW8MQ64mR82P+wKDTc
Un1xfyts7EgwVl59BpCq2Uq6zTsq7pH+LJJ8Ts8LzqPgiFzyaF6JMyVJKQbA77HNTPugXx6rwkPn
+8i5SX0PHm86kRbbZpJ9AU/l//+IMtiAm5opknJS/sNHyf4HzkDiCNITuw5iy9TURGgD4TRAGp81
YA1my+rcNjFEMkzwn3L8u8tlPw+ZlS64mZ5bo0BnClgWEPsbwyVHr/bVabufrcQgdJx9iT6VPPGN
WvzclvdUfqsM9Po8+IgdKVbJ74SY2XuZ/2MkizeTjjI31opbyrOIOzWpg0bpmPax9avc4kvqrFY1
bfBiNp8shzAlfRuJhr9lQwrCEKVe7JMyLteqzWtjaymSDXi5NlaWZe9ommUvz1UPjNF0S1qzbERl
ouWs8I0I4DHumzqzPTIAn7EZvbuFB0h41VlCsbzQoLeLJFruW+L4Y5tD8Llb2Ql0PcaPnWImGsTK
eSlQvkuxxT2Vdn2EY9pKsWnmvP1zT0jyICSKQb0hXDlKo1ar9MFKzU/T5TV2NR17Ho9T77/bk4Oe
x4cuQZP0qdeJcMykU9jkmgU9Sxe1WWBuyNwHDQm1JNkP6H5CJjxBSf60kgRKeK04TcJS28mpHsIP
BvuwZdi5NMzfJAFInbKjQ+P388Rxg1u6k1bxZ27yCKU4lVhLclVKg7g3WKT6RQSsqWbLQW4U295T
9LMal+Qqvt1AHVIpJgWj/Qxy+7fU6XwNwCybgZ0e/wQLa+FYvgMJUOMl0FC3U915NDbKGbCSCS9h
5eDAgVLaTkypJpWbQU3I9u0iJJagMrCcqb9Cvz2sXSvR9cTjR2ykx8/PziYGDWzwp2Y+l5HTeHKa
J33vsNQ7sHTepFozv5q8LkDYlpRLi8UJeob+HNEUvGqZUT7BqVj22GINTVOeqBDF7hgg4nirI2zk
yKvR3KOOn7VXyLvU7kBcynm2yZukZZG6VS7G24UpliBZ+cSrmM/f4zByYIdTjlINlG/G6MRmh0lf
6pTTzMe0sCyY7rTy37Nf6/f1nl0mYxKQmPyJ6SLIPjOMgf265f8DYsInTVnhqjR1PG7DQiVf0qnd
LsYzqeYFBUcRkh84wtT/ZvmY/CaFmidlbBkumGjULTi5A+FUWnKHrr3hM0Q83G3p9s77TQkejGOq
el5U8cWcwkYlKEsLNpXDygt5UUM+