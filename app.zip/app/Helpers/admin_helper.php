<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuZhOLepPLgUoYdqUIFv58HFNYDQxdXDiOYuL0X0rb56y4BqcSRb99wqChuGnDF0Qc/zO1vn
zDc95rqfpTwlCUwM/6sbEGlYYdEwEtFKamdYNwrZDagHJCQVA9Uh3fatnRNeEnGPu+DGHQ0wO1ik
MsjT3wshXvuVshjBQwswMSZhr51hqB6VAzSPzl3C6GnFmSwb6j/MUIdtgdf/yvQ2GamadfLsDCT9
N1QRX1gx4hlMBLtNco1gbGSg7HGMSu+BVRoRhubOxymazG/Nz8XCYKvD87neEgrU+Q492uuslFwu
gOfZaHxFHD4Uvm9+70wtbq3w6uKnwhq2D7npJbszPvlvintazas8d6kKX8vMau1J/UIyp3yBTLOt
tWrutwje+lVUcjkNYvKVWWa5Rd3KZGZE3InUopHZgsBYSy66xdlBrVYUKeZqwXv5I47K2ENBYAn+
3kuAzwBbemOX6qT3hyOaExIIQP0hGtjjO1zDBUFFigWtrZI3c2jjFovjczTtBxHXEHXw1SQlGeEd
fpHHyzTATEJlrdkmYPprzo+2KO/FrvAoL/vJQU0rUyTR1y2mgM/DX9/xTLPj0kc/nLDDNxxEEtYF
qqMBx/WW6TJ9d86LWP9N7D1t8lYNeyW8jNfDUM8V3P/rumN/yGSxQY+OKQhMDBAk5uYp5h5T5y6h
ZNWPH/CeN6ILkWeHVh9ZWnZnZ/PAgjHN/YrQhtR/m7/ddOhBjZtIdmPukdlj07JX4Y1WRk6vwAXa
yJYYW+uCA4G3tuKs+z5PH+TQp/W3zKuHgJ07vFu8r+INIiNZfcKB6PNGyTygeHN4P7XAiQ86NRN9
DHP/3icMKdksZ++y/tr2p6E4Q+OJi1vG5+UAkZGDY1pKNUoS7LwlOV/gPjP6Cpdidz4lr6UIrcE5
BQkgUhVPuN7gdoXaK2NcsYKAFb2kMWdKLxKUtE4VwTqQrtmFYeGhhQ8uhFHyWntSNayD6AxzGl6y
dTQI9r+xPi+CkD1lCZMECVHepB5k71BE13vQCXtG5N/WNTpfuni+/DCLl6xSB4iw8L0V82NroieG
hOFGhsVdZ8uLqkOeA9b0NdpD9OO8NKbUd39lyPL2kWq81hBILazX1H9LIFhplvPC51IM0TOPHl8o
9THqLX1SN3TdKoMjRDlwrivWoQUXbY7rBAorM6q2uF6xnmQDsSg+CjbK6WPWfonHsQu5hxNTQoZL
VgqaBCvGgUY4k6daWwpd8plaqGh066IWju0/ruPAd9jDDSEWBSnS0Ca3i2c6ed4c3fsnJyXAHKN7
xesZccKow8T9KDjCNL+Z53WDgxDZvTmcQuK2tTkHeNK8m7rmt6A2mp8x/stXHPKeQ1m5E8gNZD5r
noMPlZJKABvWcjxPOPQpBbrmYfycPS6OTFbE3p4x6U0gbVLA7lrQjYbY6r5S5chpIPxetwoGoI3C
+yg4/qzaexucn9cdSh5SiONJ9oIROIkEcQmMNHNk/bF2BVvjU8y2iqJtyj4A/ZJFH+aYGEXJXZrj
sd6WCU/6YW/a6BXdr7EJ7HkjuosHnitR8FugBT6vhRmYImBte0t73aeYJIiFkZf6RiwCtOGmwfoU
xE98F+L3PmJC4zcUqVYkJ4+aTl7kWeKpICS3gYXtbmLDQwbFDPsLX6BPEzNjFgCHItj732IU9QkO
bFbPSI9A9M5bjoKv/WCInSulyZc7BF8uAhuC9q9ba13zew4Fnoa=