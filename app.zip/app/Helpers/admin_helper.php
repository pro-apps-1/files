<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyRmBwOLOPI9u2swXG9P3e+aGsmpuIi6UEr+v4DM8veWTL8aU2k+GgqOhrwoFMNEu5KTcW9v
6mu/as7WXI6rDQ+ZZe3kkRzwfkf45y39jbMYWrpuWlcVmxCluk6FkmE0yJFVfAMltocDnNm1w8I7
teNg5kQgDgKtZ8NM4xkFP5xW6euYFGFh9MXT3QphR8LFDzJVsqQIZNRkrGX6hesmd1UmNAWmYEwV
m+BZXeE+4u4uZbc5c4nZC2WPfF1qaWDxSt07eXgMWBK8s5KX2zoVecQNX3WLKsWsUSqNB2pf6aTb
ovESQXN/ykN8wJhf8jaAelmiwdttcuys0mEB6zCPsz+ykzMUanIAjjlOcdzbjjOWdEwjeRJcAb2r
lWKOyAkvEM8HHOG0JuYzO1S9czWXLcwpU4VVpAF4nYVqTud+XNpnGkesGvS9RW+1lAkAb5Og1HQN
ZpQRD+OvzD0Qpki3zuMwn4ZPO6Xp8ccm0gAQg2dx2QFz+T6x9GxYBokT7OOc8jZJEO6vWUBODgMd
g1WsadvvmxTW/IixQhTVIVqnPoF7jnEpXCupyCgzgO9zP6YgidMBXc0cQhfbs4ne1yq8YS7f2PU4
80npuhfNpAVYovA/23ixS/76OamVDmfZBKRJ+Gbte344Vmq1NC0Ljn6f9uqcR/HcdqDEySv2KeG2
DwcbdAEqjA+kBenPlgLDfpjDyGi1rCYhwkEnw0OO3h674sfSU8Wb7mgdFrXIBV+JjBDxD8RTwDP7
VTAFJuI/j+y2lzSgfBCQU2OhT2yKEooyPB/rGsYag4XrrRMWZJ+3gytUa6kqVXnO2d7J4KTzfvQA
Ziq+Wtdj6PYBhfSkCohMHzymfk8QS62u4lTEVH3cznfBrDnQXAy0JcWn/DncwZyt6e2bH+8AcEUI
fwX988Ib/GpJ1+4wwR1QS41wVpUOKv+iY/YJnA91I6LbdxUlnmnvH6BvvdiQ0X6h6EklrWi0lIuf
i3/1zoJBJMj9ZEGeYlKBq5AbknhhUZJC6S2CbAw3f9WVrkkn0ThP7ELj5ECVC1PXfxcTkOyARgSB
svz5m++bkZIdlADKQ368oDZ5hJ7RHP6iHxWhaEJwB+xzctjtjsEzK7XrS/uePWkJpK+6Gn4AAFF+
fzX8nwT10LlYdxvQ97l1CcwBPkVUlqYiMgr0YUGegRnPdW9fYSqcSXeDIMyMPxjHgO2u0QlcE2RG
o7rz8prQEdIVribX2Pvj7OmdP/VY879/LDKZpx5DixdMrqCouxaqrvn8YXbG3+O8FvCAv/vfvv/+
FKuWKXVD0Vzl3QAAi4n7qLKn6TCKpTPOjd9RiyHmHuMK0v9vjhwVcdmgyTrxyQEEdJxNPy1X7GnE
JoEbNfy/bJEpaQykcSH+c6AprX/kP1WgYGE2d2vOrDWcA/OphXu8ZTXwshZHJmQZ7MWepr1STWcd
jsXOIPlPyFNE7g2gn8+vxk7Ba2xuN0wKqH1ecyEU6XlrNP7SQvljzJHyg5mo9ykDWaUWMZ6+/OAR
5sPR/UKlS1IWpe1PyR7ViwJvClD420B5K+fcS3GKQivdpr4VQTHpikyef1eOl0y0kf+gatuVhr8U
iA5cY0A2ACeif8ZFZIWwdar9krUc81JF9vqgsodQSAJhuaSUgGPTP2c9LGP/XO0HsymnaYqn6qU8
lNp2FaRfnVDDyLJlKPf0LGuCfdwwyibK3gibi+k1tfMJDl122V/1EjXagtRMMyWX1dfTRFJSh3Tn
6b/tCkItEQ9TQITHVtMN9stphgqWM6lquNHWDrjkkQPCa+WvY+D/0/AaQQgq/urqkFpWbMrqseqM
9ZLGr8gFVSJC3g+kDXp1MgzF94apuiYUWPrLA3KfK0fZRlp85h2noBf3qhBl/QwSERfwErt+Oj26
EWV9QW3wxOfKKU9YUefrRLXyg8wqMYCTdi4gw0TvhnPNlWcw0MFWe1i7a80Ro7dNiQ0kM4qfwr08
6+reVdNnjTIKaQB7BtQ6TausuAJatV/s3N4ri+dfpdndCP1tuBCY55TNxOIsvC5FXSQ4kJBVvO9M
ExHn4LHoOtEhHAwZ7T9aMcLIWIeOM/FXXOYqsFgjliV7tpqt+ahvxdFLeDwLMciC/Ga0Dzu1KF0h
C0WhnkTAYHTdl8ZFYIHLfhQUIlNxQ8lOfPvpH+wf6GAqe5AVVYwn2fZ3KnBMw4dbOZbklWwm++OY
nLa+Vz/3G+/T0TgFC6Tv8G2ed0nmIe7azZaUBNj58Hwx2Bp5vlHt5ZHFyFA14xhK+0ELCk2zYsyk
2Ub6AidR9muArMxA44GFZXYe8zzMZrgUHyImLlrYa93WUci9Q1Lhha/7A12aJdlBpH36glvKNZZJ
ksHCpRP5SvlPla5nU6tfxkWjMhSFaHeQQoVzCoJDxN7gxcBufIgHmFgIw9Jj9N93y2IQcX/au9ES
K/2GHZ3oo3aol3JtwIK36pY3qTz+CzGAxxfUiePfk4md1diE/ffvorkdGMGUuvhZiHe0KJxTTp1O
yfIzhlVkc4BkRDOeRoSMxLq6ftmO8ARhPX7RCAOdbVf+0uzFxoAqq3O3B17zO/w8hzXyewTTnV2x
EDnVssMHd6kjmiyxpxf/LBFr6jCXSCTO+wqDrIesE4Iq9ph4ub8opF5Ff9cmiP8biLMKdWt98jZo
6occgXor5mvfhuzRX2UiiWfVyW0rVx0j7GxK2JCcHVvmmVi/3gVE2WI89xwRJZCAlPz1bGWlKGHD
tWXjaG591J8GfZdbYKW05kThj2FV13l6E96tE/AQwDi1/vq3H3c05pirI4vpPbXsQmW87oKToWrq
/kxGkaKpvRUphp1qo8i0PS6CQ0Z2+rGq9mJJZiBpMXmuoXilcbQchxMfSW==