<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmdY4NEtVUf4JY24KEQ0EPpO91qhY2dtAe+u29YsLMRNxrxiso2y2EtBrk78BFhOA94ffYbr
ipsVw2QhounTIZUd4goLFyQ+K9Mn90lbE1HnSm/5TTHJHuWvtuzMeg5YBavqTb7wu3z8unuIQF3l
VwbPCHu+CP3EA5iYMrQHrNPhZdDLeywneHEWp4MQGoQs6OAW84M3Z4iUR0lZMa/rxvOrwzxLJZuY
yPUvLLysOhBbjSZV92zAhvPDt3w2KjLY7pZcAWetD6Fa59t1nE8I/Q3FmvHch1UQoa4ccZ/Kb+PI
Xee86NYSFqyHkner1raTKsF+ZlyjnOSP3pha9bQ8/Ylbaj6htDNXz2SCrzQtCWFeL3jSJsTKDX1J
feMqHfB0kr+xwn+0l9J2BEvtI8r+qrXx5XT8afUJRiLUF/DmmE+29e0llpKdTr0qZUwQ4/EmlTRW
jQ4lKvEIKB8IngwA6y+0CcscccT96/O4FRyf1CegB/6Vqu2iFajvTqrbOcPhDpIpTFWsPMao/DZQ
tvU40pPn0G1fc44bSKq6yc34Ny0mJ7YfJrWUBE0BP3kPhVFaZJVJdDUAuhl/CEq5gWUOpFjV3JjG
ogKo4BJIsUTY25hmLCQCgIAWXcMw/v7TJ7034DCDeEFKUa4P9Rhwx1IdoFYPuGqU/HePwYtBMzCA
I3xpQu64KmJ9M04tazv1u2lhilDc0o0ON5rtIfepMB46w5FT5on/JocNiBuWMMBntnhfptqi3aCQ
8Cxc22yx+x2r60aDZwm4nqXm3wF0fNfZRypVr8Yuj7uecsqgqVQvf5RZNJC1YOV1yQ7uGCyF95Bo
hNpapRcD8P4mLWBy3kTEZOChdKOKJjpj5XauHO5kRG8mpcTIEqo/sw9oyl8El9rwXIpoHZQeD47R
rQmgJTFed0BkcW27GloxwdEoVT17tkTfEQwq9wRsrkRuUq3ZQyW5Hj8VHn59S+g2zxZFKBamSxSU
cgj7YwGMwL+0TyCEFsGR1k3KocVmvZjLL61dRkxLDH5xQi3PN2GaJ4zEGTSmbBktJdHG7+YXSzO9
+GCu+siVNImcxKBT5vdTsZ0ss0ezJDoD1JSc0R4u5CuczgYBunqd6ovvx3VsruQ4dsHhwlYDjVpG
doTtKEmKC1Eguz+mcelx2e8AgyJC+EzDKzzLAHo7oIEBO0Su52o0vr4EXdxRE1s/D0dEiB0sm3Wb
sxPVpH4jwCgC5Y2GseN418URBqOlxg2OOPSKbs0VIPgXtXtjUkDe5Xw6Kn8ipWwjNKJ9QRXV+V/+
B0p26SXAB4cTGLSj8KpD4DDahV+wpSsuKuYbblL1HDd5oFjYjnUhCPgFLGAVvw1rJACz18DnzCWl
21feqzb3AIsPtsHf+BTCXJGoMJ5FT/23u3hRRAiLKZkwTb+Q2OYbrnhgafE9friYb0f9Cyc8vAVl
wnNmXDiFsM2bB0ML10Sk5JUSxqiw0Nj5LQv6mvqLQVJy7VxUUg43sDwfaaYaDrW0s7h8jkNeWrGn
GtpX6OVKPOC6RWvrJTQKp0MTxZu5W0krlFNcYLmnBtQG9ta3bIVq3Bje5jQslbbT8TNuYCJo/t1y
w/paSESTlB4HvyybxNWcNB2+1fYQNsHH5Xx4JhTwFzsq3c4rG6iI4hCgRxxF3yv8gHty2fJ0wSCM
p8bBDFMeLAQ6x+yNa4NPTRrbg+2po/UXuc83rQy/gYK4RIK=