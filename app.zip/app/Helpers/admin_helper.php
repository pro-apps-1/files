<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPod1OAU9dbc9L0FrX7i/vyOjNjNqoTJVygcuqgcrE80Xiv2eDxf32zDJc/F09rZ2BToX6P5e
mj9d2GurJeJ1P9b2kdpd3XeKEB8/wud6Zp/LC4DhPOq1nYIkBNZegAEM5ZglyrnIdHamxj68jCzs
lbBo2KPIBYZQIFHwKAxInDAGPpP0cwPUZpkT020FMJddxAjbzoVYSkrqhpCOU598bOVx6xB2QKm2
hNBaiE2ckgCm2cTS9fapVaKTs3i9kx1qpvmUfnDjqKeZJQJYb92MQiv9H01elkq/9PZelzGDAt6j
twfTMx12H08MZ3lTUkS9/XVZozxQQx/tG37z2b1GNCKe2nuMVRl6j2zH0l064UQyNe9z9IX0v1us
3s7OPKVy5JVaZPVgJ3a15G8CoGxTf5PxPkwI0ldU1Xsor13vFt2Tivsp6e7voLtzzejW3oUOhftf
SLkYV9LVmjd3tnZ5GcAJmaGW+VI0KGzmS0MiVOlIWCa3dBPQhqYKnhgJGBc/rwZm1h0nXN3bwr33
nylnlA0AaVu7dkIVDMP+ztoPib5MKrAaKEul/7iqTG7WNBhSQeRLjf85DNQLHjuE4apb/0q7ZgS2
kYYQwYaWf0NF1RZRbgpbJgn4VvFuvd+bf3vCbf5GkWeuDarBxp14duMjw5OYPRQ/bI3n8tNXO/D5
BvYwzTttoQ1nfg8GPGJDg8UMgVQ8Z+A5gRyUkNg+ysJ2fx54dT73l6sxgEJPEjnrA8AXN1NlbU14
+S71RAFlMH/8MNpVuxApTg1nm0OwX29r+BrD9USEPKflzBPj7mGxRbHbDHRxjuBpu6EPYEkZUcGc
AfQG2yrhrGk5c323OYnRgTJ3tTLc3qGf6bxEu8Gq5HP2anLONbnGhG6ofGM6pphS4F/XACdebSWI
I7j9CVLnRojNxAJP/oeuSm+jdpcSERb9WxQuKt3HTGj0/W6esIlpLHbi6EMcjPD4P67Oio1R066V
2TMgbAhtfF0sSAN6IiNHd2R/KMK1K4YN2TCCOk3uNPeY/Gdx78daAw+xDXTpWBN3dpZWHgXtG7ns
SuPFWKZtHmnmNHN1wF4feq3L7CY0sM2DCTN/j2FNhqgJ7Zu5EY5VhnjCK8dTFsAd2nvhrIdIuygt
q4O/QigVNUwUSuwfbGM7m/ZD2kUeJOHHBpPF/Pwc7TC62RvjTw0FOgGbvnwExkIJm21meiIOB9ZD
al4JaTI4WkgzCzSGXmoiuMapPbvBWJuJFqAyFcSXwHACWztfk+UZ0A7kiTjHZo/rRFYE//femG4Y
phl4sItWZ7rhyAJUY7lBOqicy+7w2E+Te91uYkN+J01l9jqgXv6rLx0DdAM1ZGyz/Sp0g8i3fKNO
yalAEs5iXvA+BUTNcRAQCV6hQX2lKHUwh4t6Qp9bCTuf6ntysIIHuBQObXhSAoGpq9pARSZQfdY1
KvnXm5kYeohTzjw41j0hhtTabHZw7CmY8FaId/7d4lxAPjry+aOR2RsOKtCvHqJhEukpA1nBu71K
eGePhknsyMkV5c14qdUhgYDLx5DfBqCWKSrgEhD5xURZv6baCgVnvxn3v3th3qiB/miX/sriVi5E
tqJtgfHIJigJ1IFXz4UlC4vk0WktdzVReNAf4S7iAJTELsTaLaUJ0LhqIKO8P8LNzAk5L/L0vDj2
aDukhHGciUv6SpthuLiW8XoTJMiJZMVR4cUqV03q4mvumy6VUv//SRvN6kYS