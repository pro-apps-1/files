<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuAXidmZFmTpEcCdNwN7O5kR14o1X3HTlT6dUuQGYJq1jOjpiPFqYgWZ5hcNU+SzCiuUkAJP
//3BhUbRne17+ID+i0vYjMWmcf7NhbGf84U+0h1TZaObjt2soCAP3GwcLYONFkmpt7+SKU9np8NP
uxNwF/zaFkd/4rH7+Ks2lcWlvAaRO/7f10fxKAcJR7nrZrtsSSPEgWiUQee8GzsO40FvnSrHHYHn
11vNGyzPqgueYlEYYMAfC0WbhmwD1SrSNToC42eADpHZv1ITmSJY4lsWpyEPPa/I5DrjiE1m3gxc
KeYA16nzcqMH1G7ctTPXVQ55gLB4DjTApBSonCNuSNJ4McVrDzTqM0hG+3uFbcxcrnJaWxOaPFXj
PBEIRoA02IPoeUdvXYmcASrr2Vlmvs48Sx5oyE4pI6gCd0xkx9vrrc6NgI9BfDUNuc5sXLHrA8M4
jpIIfu6Jr4hM6nPljqOVIq4+blrFoWt4bAjwG45lM0+RVJxWGdIwPi4Y/OIjSZL2yuLmX30SUjYU
Y4GwS0iO5yMAiK/7bu3c8zafiGMJfOeByu6sCKFOuA4VJ4z8NxMUor6ENVUYuXFNcPWRv5gWqWyR
2/icL+uB5QEYordWBN6TLGf9g/Uv6DXey0FBWKsFZvEOmqbGwYWZXKITpcIG4dOoy2XtZkhaccsP
I3hDVYRPVknvt5IcEVtzUlCroaEtuFezJH+6eAX1kYGK026Aum+vEZIVoOIFx5jOQm36INE8lug5
EA7m0rz92iVp/ELTSsbCS/iUtgfkBCTYsOkbqUq46nikQB8o2dmDLvv2br1peKSxTyuq1in5B6NN
frSgRoxuVI5KYX+2L8FpsrQecSUIwdsCPPQgyvoJHiPPg/Fpz/hrc9cITb1sv6NWvqY24wGUq6g8
HjsyU8l2YW745wqhdq0jTZrps/q8rrgpvqCPwQ7/3YWLz88I2tFNyguki90aNHIWuDjyDg9qdIgZ
zPFVK9HudShZVpajAct7bmfDFMHwy+JyhcuidgLTuz4DW9dk8/YRBESRcajyfEg+ZFJj+AiHC0+E
cTWXqLl9CqpvwGBKhnOifVMJnL8jyGynol3QQ7eTyK5KU4u7rVmbzjtkeCzBqhlJMV3VW82wKe5r
8JVUPY96vB3AnXaMuaJNErEpf6Y18aYEwlS1vm5LOkP2rSy9+qJbUuFVAHvH6XfXXAvSqH2a+hEK
5Gsa0hTMaef1OKJ7nRrJH/ACxbNpVJyv+07u5EDIlI7q5+LCiNo6B3Hhrw/lO8+0AmBs2EWuTQCW
z8k8X9nxLojgQseOLHcyNwk8yktjeqBcHplfl7NMe+A8bYeopiWQGqYJ4Dpq1fczb5K99r/0k0SJ
Wiy55dpnvJVekr+5SD97GtOUtlllfqYV43Jr8AHS3KWizR/fURcxMPzSxrwEpnNra/ljrHMh8FBG
tV2Atw80wWnO9zI7LrkAJy2etxDhKrtIDZ1yYjexbuje3s4hzxz+C095kSEaXSsCft5v/oAiAmrA
byisw3+bUdFVoz35uv9q+43ZiAunfrgWWQ+OQ39ltXRqz46BAb6BNJJBUPSzs+8+oQflxNXF0Bwh
tPuKcpkYRBi5UZFw6pXGBApqGgxJ1W2CRm0P6gCoIa7CujvvjMB+7J4=