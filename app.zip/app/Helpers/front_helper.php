<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwG4SV12s4du6yRaq/zB3bE4Hk8b4EvbjFD7CsglcY1ZoZKJKalhshAvKciHOK0Oejt1D4iZ
NQf2uXNdjvXbbniKaahJog4oL8AqHFiCY+sKvOpbUwzAS+Z1c2cjMM4RlegFS2QN7xIXgkILiKPJ
xW64sWdycvQeeNgR5L1RQx3P1kQL9/ITUt8g4fL46ZVr60K6mkK/gFCagF/jKPj7TBLMLYkeiyw6
TVU/bTUbcdtPh/Cj/JqXgx3qUohE9T5f59zkODn2WgoPKlaAU/XlrUmuabQmR4mY0PG5bi4JCaDR
Y6qgBIlUSOmqMoJPUKvUHYZSTkbT3BBCrxpNEpZdsM4qBp9zUPSqz71GqXMQ1LodZK8vqnA311bp
nYOYlBLN01ObFrD6evj+yxZ4Emyz0RMkofokMDEbA1gG+DYN9gnA8vZZLlkJZZZ4gmOfuJRrAfa2
gEFV8VIVB1Bc2g+FYv4n0Lq7/F6uautV4KTtE75IKAx07wUuloRBaYR137rre7HOSvj6ilQTL1C6
6fw8mJNIYVzr086HWNMTjOPvlZWZsFRnZIV0WvUJ3KRes7C/MWQyZCrn1xnPq94tT+H+fcasQ3wD
O0Jpe0VH4mOUMEshW32plDeLIgsZ9tdISpCu9hMGA76hsMK5/rvEybgdY5Co3WrlXepLJ0P08qfW
LJCA6Wf3HQFNo99tXE43rUgde0v/iWT3YJJ/OQhEWzDNI/KDIr151xCNaJgWrg6EjXogh/ePR/yz
v8TMs5AeodtTLMZsCPwK3BBYXdQjnXblTxesIitILIqTzVqax9MgeR6gmzKLdJ6uXT2VFieaCzzf
RrJkl6p4mPjLJSSRW6+IKOWlDz32XLvGiCwL0o4qo39yD5bNmqiDnsRfkdKLsm3o4X2XK6anM0/B
z8c9qS3CNgjzAv5WSjSrYZ0OWip4151RZHGgCteElbkhnx60EkJAsq0QZ3lKH6YVkngRbFrHhIFB
yCZ1YPIyNWZ/vCFi8aOXf/Hewe8EtgyPjP4x1rpYpwAn1wIU4CvbIwO3bwfp9KUKxQNbmzgdrvO2
1XrCgCI/FgweROs1gizEBNL83z6eNXZtx0Wu3B2XOk4OHvL2WWX9lZk08SkJzqJb5DxfWHsaGA1I
WiwnY2xg28QYXsX1lE3kLHj2nQIZ7pvHn4ccrU32Gfvn8qv5pCe4vee5QAKN5DQGpy3CRQV3iALV
LK0VKg5EjHCtybuOPO35Veb2Teo0dj+jTplOpiCvqYghR+k4P0d0cVr60EkkIbH/YtHrOY6vCexk
lz807/O+huWxC+BiGlPNbQqIzI7ZDq/pe32zrNqC4U10qEr45G9LGPNhVDTTbJ6MnL1S6gFed9wX
RtNGaZ4wleZqAyRvZXD7NEfLnBwDpG8ODgM2u+fzauBy/RjCO/yCiwqeZK/g71/xWwAxgW8ag8Y4
1jP/vQl3ROKHqbF57dhN4/Y2bHz9fXgnjjtTIGZZQeK10AiPLOX+BfF+mAVuCa5EdKdHurs6vdLB
SxjHIELw+ESGWY5+yardCGfTZyau4IKdZsillojQxGkKDAPjKd4aVSYJwZVTPv+FIWe7VdqCWXug
di0KpygBuMU+syPwGyiEhDhlxgE7eTTFEH7isbysthZKwe6U