<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+9W+9IO/ox0ssMYRRU9i3lRtklA9fznJV55L6UgHLPg2ywzOZWsAdWYSVsPjmeXGCzszf4S
hQ9iA7K1Our++ndY+8VLlO1bKtXb7FiD7Ohrh4ratqwqJjkr87L/949NhtAfUjD/dyK4dslIE63t
/DW6uXkekP4vngdU9lh129XaEb592fVsjVoZY2VJGv/kXKA983l6rSCxpXjH4ztWI7qKPM5RICDD
62hy0+gd9CrgUWXVZqDwclMY0ef8WW901117QNOKAnTu21puFx0CpmxcZilcPZtemjR99T0ZbVBy
OSjAHV+iz99P65OKTzPX/fAgX+eKIpt+vHWw1B36U8rfvNlzTkmv1ZM3eq3mrzebiHzxMdmqdhW5
Rc7W5kikFI1aPH0blCcOOS4MZapMurw+N/JWjxghsl85+kexgJY4hnNQfEa+NeE08nJGaCwIWo1a
4LwOK3w1K5eawy5Antpe21BmFK2P74jRKjmsDgcm/6dP7G4TJYlP3EKWgKf95GXzG9Rb380qfff0
L12z3cArqR88ObMrtTnEvSCJEHhYmH5vUM7XDey3p1ZSXz2GFhYdLx0F7KxOh3SsdT+tYH00nTss
fGESAGgv9cjU7ZkC/ox6wNNhLefShwfXboUXnP1CiOTV/rh8NXEHaIV5I/9Y7bxIHcCBAQYzCniO
klEYnM/hFsvJ7GSnvj/gepkbqonXThcbb/AS2E2tOAZPgsfXOpYvG6Iky+sV803uUKXOCzaS3y5C
Duhnafts9Cz+YzrpnyPVTI6/bqLt3tuWiKpgYFzsXeGa73ZgWLTX1P7U4VzZn99d3uxuQv+RH0II
0/17DjS4gEZC9hKvuc3ioioK8l4w5RELuX91MvtvtYqAmAVZxryks7qE9j3+8x8A5SDS5O0VXpBZ
XErkpjhIBEKcfxNWBl02sGHX186xHbxrTUaRgnc+okNfnXhprIakkvlelu87QEeLNI28WGvR1+6X
oPAjAKN/6q9FVgfeLfvV7mqr6pQyQ3aqg4i+8YYvs0gg0P8Lq84faNFp5cavH17Uh9J/vzKIJ/vb
PLPV2MTtHhrpoNRMsby+an6o1mN0XVINomXo+9RtsaRHob2Ey/Yi/HNrLMwiG8HPsPMXXETtSPrw
GexCWbiEfJTcaXr+c2rg75Z6Zm/TulVid89DqWFbSuB5PS7aqoD85/m7X7zRTL2VY/FwO3iQW+mo
dFrXO0tjXUSzWFMJzo2PSeN6OpgZfIq7B2Inoc1p8Ois6M6XbMbWwaJaFUNDnFo+fTgmhh1scbhO
TxHykk6kqOOp8/kl1PQxEPG7vnyCljCZx2BcRboCDBo0TDWjDnNeSb13wcAe6Qy+fyatLSzIp8a6
Wq8CriKnyFac07Oj0WJ4+VkAt1y3+o2YrOTI/u7lva6tQ+P6+5UmzWgzHIQ2xtBMN/xazx9ThQiO
Ya3uU4sRgwMRNcbyj1Zz8J1seID9hhGtOUdSoCJOjPoYtMo6EQyN2wvuUhsupTCEvKDizo09zbZ3
uRvz9b3oSBGgYqGLRmhzhW5Zsn7/vWBUn46xCHaYT9M03CqgUN6Lc1XT3zHHJ4ecTZNbGU0Zv805
S+Ut839N5p492t4a/X11eUS6loYLdRQgTkltC0==