<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvtc1EP7Vlt97YIHnG3upTy/oh2+9bAcbeUu3mkySbtWi5RGBDTpIwi1ZBYwYNmEy6kdNmF2
afMLZKBwjyR0by7EzO2F0rZUB3UiD3Z7r8BeCm+l+XsHbn38cyfcQ0DQ+4/gy4NglP0cg8HqyNbN
cZ5KXV6BQYdcl5pY6ncLlrnEJXGmTLE44goTUcFn1Gihp2U0k/849K93dYK/OlaAIbuOW24AgwyR
cVMaPCihSRPkib+BCLL//qsyasvdPQkCT7WLhubOxymazG/Nz8XCYKvD851eceanM/Eo9tUe8Vwu
gufCc8iiWQxBXEKCKBGh5NkJgPQqpspWP4AO0dkh2qKTyFJca0DfjxfXErACymZq091rXpLkilfJ
VddgR9H2p+etJHV6M+PxXO/1DJ91lorTH/dkXwdc5ztPMMS0VFKz3YCk+8v9NXgfXXarpMxuf+ge
fAqAlqKb7cEYk/9dYXZSU45p9rPmiU+7xwFtzSrtXqmKHXaqc6YeDs7tZ0HIPgJAureY7rsm5/Ys
v7PtMmfK2B80+H+RGmGCeybN9BJ9jE9Vpe6g0Uom5egAZEZmGw6VjZwuXXUP5W1xHj7P/fmfXKg8
3/VuxGg5wsSAHrzEIcuzQgLMi9MqjJGmaTam2yK24sjlGWLgo2OGfwctMlFmkLzTTdvonUnalh9K
P70WISFIaKjNDLN3efKMuqYsyfhzBcRKh9J3OhqJ5VCeaEisIN178UAEVutbSxCaARvhBc993n0o
6z3piVQc6IBx9eDDKefAyem3HHgVDxLJfv++D8Kb1PJmwHm1wFm2sjoVDzIyPgfkh98c0xrDB/5w
wDMrXSjiLvU5YSSsJ9KOJ4EhlaVbSXRUtw1g8WoqMS3jZVTC0lTH8Z2xJ9HynAA4v9h52cqCOA+L
RtIlCbD8ItPPoYkhPsYMKKH+p7tCNvFANuX/lKG4c4yuAN8ULuwIqRzxB+3+Jc8paX/CYAnkDpxI
BkngIsV+nzRSFl/1+jQykaw1eIlC/XJlGllbpZ0dVyt28NnbUnvA0rpBDOgC2gvx/wG88zDMWzFW
3dgRHWzdjWrj9hJatMn7VQXG3GnygF3Yp84/7CVVsmLK1PxbzKCJHe6koNQcRf4Gdf0Fnbn85TQj
mDI3+2rw4zG/uI6THljwS68mvm8Sj4Obopx19c+R1Dh+Lv8TVmXcYyCAf4ov5PEJ74eIjsaLCoKr
e6an8qZtjjm9EE9Ejp6ZmrGdUip/Xo7MJU5ehadDArVx6rMME/ftKkiX4jYP6JYfTi0CRiSskPSI
gVAWSP2kWC+DjqrvK4oH8YVUPGwCuiS5PZ/HTMf4232ZOEjX2XbxIDfhusN03GLxLFNxJTZRNeo1
1w4AFkHLpItyDA1Oih1dozHUac9ul6yXyJbYhu5lCF4W/fBA2eHdlAvhnc/RIHiU0puEmmThLPkw
7OjdvU6gpS/jb1e+YqwAekl3VhMVaPBJKlaYU/cN6YxOxYf4e0MFWNgS43QIfC75iIeaSMHGBDwy
gqtj6A3e0+50jkMmWF5o1ETjGgAIYv8HJYUBbOkmvmYJ9pBm93ejGzFExN0EhTzxeFcDCiTQJZ0V
0lXdMCOFgrF+hgzH47EgSO74WDiVKS2/d4UGjstdUQa=