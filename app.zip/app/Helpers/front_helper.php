<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpPU4D6gzkZcivo5ycKmXNpW/CIfcBB2ceMuqvIQnCKVY+LiUX+OQB3rDBuLp5WqS5GUO2el
Nq5j5idBSGKtUHqCg7/FaIoNysXjZgUT1fd41v02mGtqqgDasVcSARWYG1IUdwG8FXxI5Hw3Bk1s
psbs+YIbYxIghqlbe7cMpOC5DoxrLMQF3kdhNIFaxB1knGOAqI0Duh1x7tk8YhNMFohU8vvwzGDr
wgCetQSbfTxer4d8JkjQ0uggBT43m5Me6JRyz64dw5ckNa472QqPOhgG+mzgeetMbCydtCYYShA1
iOfL//Q8yjkPwWVwHtxIJayolRquSwFFNonF+cIaDWAtMIjmNeWPL20zgHGRQK4OgxL+wBiOFaW6
ZJ7r7i/WLDXEJ24cnNXfcJR06SFM8Wkzxe/Timuw558CxLLX4dnQLqyxa/77CcS50Vc9vFdL0lcz
gtkWWNQyJLkyEnnftm480FMqWiq2jOeJTrcR3XOdkQBFK1nV5C7wwXkUXcG34b45mxnlHShgoTVq
BPnG0qI/j98XDlXt9H2UYlxSgLFW2hIs0+MMVYj/4y0kLf0EfJs9xiJO2LN1qBCiHhyRJSTyiey8
mX3sZC08o4eYyXliyLXEejjFsyz3brjd+5X17LjIkaF/sfFK2GQvB7UAuX1v2TV1clMFoDFFaYCn
cYemA2sPaFuj/k6h48ZxEbqpwbRDyQiv4Gb8rfeapFNKK5RQXRK/GeCHFw3gYUm95SvpISlCf7+w
ghoRY6i71RZtnsp7/HSA7P9ayyyLiP7u0YAbwNKjyS8nkMXoV5Z0Fq0dWm9lWONS3zFToxcxBMIT
w3WtZ6L9GqHhWBGrge2tGubyYwKLp7eBCroUg9GYnkICwBiJLnCh6op1lr6Gg+V5wN+uHm6kgzL9
jmF61XUAKaR+iBA8jtqANj6u8GOI3JxDipPO3enTQrgFCakbrarLLT6oJ8HYYHCr1GWZt35m+50q
cMb+3yX3mdpy38X/XZHKX7+Lekgvemc082tyhs4zE02rRtnpXUKwSdzKCNaPDrAeUBmlC+cha03+
JR/BoWIqx6mPrY2uufQtQQ02FXR4Ah7lV1m2mlxu/aOrVbnmGMnFwLsBjHjzstkK5vse50tSYlsq
IHi7T1FEtNDNdssH7vbal8qXUqJVjzIdoMTdgIVVYaQ4AENe3GKbVNWGZYqk6gtBjS+c5p9jc/KI
xUyrmyzV4l6omxdIHNC2VXIGuGXuekbNSlpcU+uJGbL1LezeGGCcYDU1nKOoqN8DdUTl/05sAFPq
ZG6RDlclxHsNDPNEY4XoI6Tv/CAFAXT+kNci40Fg5QhY/QyQpiSJrPZApyfbGuvC3XMYgm5Ut3XM
34wncDOBbpPkGcFAb/3pTb1YoHOV47tgYy3wIb9Xg5ZeSYzIpZATXvHquTFg1y0tyVnzolJ/Je8j
eRgEHnvOC5u+DtEw1oB3rVvLoPY7uDCxYk5P26KCkK8AyoMVOkfM0+WOp5Ik74IT2WVSUF6IBqBC
SX3bG64RE0DfQ2zuIzsWRlxNxrJI6dMPt0oLdvbrb0UMaxebsn7k9bPOe7vFrCt3l5SB0WWt6Rsl
TZJ81bMaW9xhIlKfTEobZ+1N8yjNKLOsLRPatyDj