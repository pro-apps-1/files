<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzM+g9DX5X6aV7mziEpzKqsRAz+3+ioDqzSxDhcM8deba52beBXk8+H71i2a6QEFfT4GkgAl
fbBZEvnQDMFBBTOdPw5gjSlvPSR7KPwNnKzhf5GWX5gCV50UUBNEpWQENRohy5IZ4hOJ6reCu/6b
f2CjkwiaJQtSb+uDHGjI6aBlZargdgtQwWScHZ/Q5EK8H1Lo86gNtAEGB9aRVfb5aneHonAhAwvU
8KuZU4oZuV+K31b6UZvCXEqpvRLyExxfqBMcao6+HKDwlyc45f7akKnv7pQhPflAWKzQP39pzkx1
YGAhHDZKAjylyjPHFXh8vw05Z+HTCdZuZWavHNcU+9c3X6hEQykntawZtIgBT4cwrffWlbKQFzDr
2k21/mzYIREnOzf5a7qqV6jXHZsilntyVyyQrlDL9yuJ+4axWa9a3+U23c974zqpgIOT9p8gQiu2
s92wvet9eOm+sVgErvHv97kKtQoSY6YxeV7rKfWp2xCLJwYqOSHd4VS8z+qN2d1WPV1AAd5rwf3K
baBia7MhsOvTsrfs/HVbZhKgZDLpN6D1mdSkTZc6NIPetf4qeHiTvVyHu0qZO38aEHI4RpacDWK2
l++0S8qepQ3Y+dpks0Y0iEXxHEZ68aAAbncHnp+EjOOntyeG1yX5RtAMpdwG9s3OqY1+HYAt3IrQ
A/0IErNPBm5glrgIPZ9VOf8zTDZ1Y6tsN/hpize5T6KCWKza3RAJtscRXyV4XyA9jRlb1OiajvqI
IQ34hju/q76mLS0j90ooT3l1xasvnxdmcSqYLeuD/Y1U51PeIdE9O0lFwB62g9o1aYr2Zrx4edeZ
swO2r2jC74kA/vuw3S4jZy5c5/76/67mNyAcN10V5GIxBwVAozAFo/6oaoPLZ/Bv9v4/75WEVJLK
TPS4dFodDnmCCFa9ZlLZc/B3Q3w4jf504sivxnbosm25jrliW8OC7jur0g+TUnQpQku0k8AjlzUU
u7qD1BGiYtx1nogZS8lpMlw8+235nwk0MqfXZGeJRoTlZwHRYormV40x48QYDnJJawaBtWncj1xV
3keNPytixu+hNdkP29VYnL1WWggGxxY6R67p4v4gyYLBNPS931CWFG7CULLdJ+9ORzvtwOp2FJ3U
IiuE0berIPUbXyC+/eyu2YS//wtDTUHmN5qjxowph7lCWjXJc+lTi+aq50KMPu9HkdlfSy6Ho1cS
IDakrKn6lQ+uVvBys90aM7dMAgQVTAyEprJ4sA5v4tM2I/BEHn3vaqIHh5fANUOigFeO6EjoiZy0
yTqAvJJPb53z4PeCU0iv0+XuzlvHqq2Atq5lVxWtL7A0H61CIM0HlgLHrYxiTIncQ003yMsiKonV
aETTRJBFquoBo206gZEofsu74I0tG8gmz/S6YWUkgKGuJXxBDjrO+Ox0xEI0K+hkt+Sr0lFoeT36
VdwG7cmdcz5SbX8Oc1LpphhOITbfu40cKatoToDkNUEp+WSbhvnm9AElolNIkxnB5hIPPN+QHK3y
m/i6+fy6r97L85FU7GmAZ3Zyis3ctJxibUPV365+5P2Fv1qZbMZ3PAR1p8jPdSSXR4pGB5zjf12+
xdcJc9w4AiFoVyWY71OfMexVR0vZUO1XUDrqGhuZgHzmMpiw1V++MUZCnCMjzW1q9g/Vj/sxOlZr
tW==