<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPm6Ph3AcDnK5lriv4SeGNZ0v4OVO4MS7QVmPryYpIOfG3KXBvksNbcA6l4UVZBn4yww5XPQU
zTgfUuksuqlpNa4zBogkhAFuWbM55Z+Ke2sutLqO0wEzv9CkDT4TEytnCr4wNfLwX37HS8BVjbod
gMPYNdYqMu7N5d8V1o3gP/s7N7A1LJridAcVZNZI5ftxWRKu3YVxniz6H0mhWCQj9gYWss19svrI
/o76vwMIlqQL7pDiEtqUSEL/0Rd3PvB4U7Kwd83yFzgvkwkOjFcu9tAV5diTQDUm3qLJeReOGEah
InEh5Fz7x0WiwWL6T32b7MVbQbHOa64BAonsKXfae6FLC1NrYUf80fzpmzfR4E1ACZ5LBh1uEb3M
jlz+C/G0Gnixe8/Yp2jOnfM7GoXY7djuWPmR0dd0CfHP9brde5OpCDncC3KHZW9bUvlvQx1LTEXr
8OrQU4xZS9hTLojxtpEVWU8k8TDwDLRh2e3T5RTtP6Rb4nHdM3bG61yI1x61ISuigA3M3sQ1ZxIF
CMQukLATbiMVCZdOYUaWrzODkTcVir1ekARaeBQw6xzg/mgSof1Dy0ZMwgTZJodI88zoFtODXedr
VLpy+3NWX35JP3ETbOrXE+bfpifokh0YYgJ05MPRIrjx/+tNDMdP0L5r7oTQhqNVwxBZkBeTvhLn
39FMKJzTsbPwNN/i2nH5d2GDo0xSjo2eGXGo2EPTxcV0JZTuUd/Sxewo+MAsVyHtRPU+DSg1p/E4
VyujfdQNZD/PJWPxqGeI9yJ7uuwBsTRrgku+zfzQO2gEzayCtGBybbN7SSQHJ1nHe+ogkkQ5hWWT
LU0XdU6LI1uQXiBSHB9d0jvNByzBQyEGmAcm+WTXqLWXyoYkk1E/o9OBrqYHesnWnzpOuFFGoVZb
P6GwpnqcObZH/bknZjlWGv2k+IOhko3YvtML0MM/W0HmORxVtOfvigd37+TMxDELgZENA49qtRI3
hVCw20y7joa2qFWbbuz+GhQlOwQdLztMYtib1qwalCCXZ6heIJfTSXWHImhk/9ntAYFNdnYyPmpC
0w8HZu6wvIACH5QET0bibWIjfkZc1CpQwHE8grDyw6sH8aqJG8NCa6h7WVFK2POz3Q6PC8mmKoWi
lXwtxNjxrBSK7C8p26j8TbrK+6S4SBo/M2+abDSN0RaeQkKgQUR1dH1mlBWm+buUsLC2SrhRkpXH
YRCL/5Fs6yTUfb6oZ0Scw3CFT+2hbOaP6RuUR8B3U43E3vNYV1a6HnzL2zErPrvvHsMixeRCPIVf
+VfanbCUss/8lvGhRO5XKxdDp4fcQXSaJ6wjYSUq66/NbtAsXs8iKDdVjxVW3iUbIq/g4eAtyVb1
c/6r9iYRQJ/wUPdJIJPWA5VZ4aaoy5jkPFm0Jd1b+4VMAgDWAbBFC8R3vZgMonsyCm+ch/Y8+jMA
XlvqnuaPdGPwze2lmfWxhrvcm0QUTdiE3w4MmlCI8hu8dqH8vB8HCtxRIc29GYSuWauSPsz6Rk3+
2bWZrYJoTK4Ma4nnXCv5mOYnxylktH6OCNhwgzW1dgmmO+xQzfpofg/nTQnJSTxMx9LXGn1a7lUM
Ox/8D+gjDDUUHLkDxO2F9TZn3ygRLYTbj7P+Lhdhlfllyiu=