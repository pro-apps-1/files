<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPurcWwLp/dUA2gGMXY6Wm048Qfx4eEKpEyTqM4RgWUuoVcTDmCmCvQeF5Bxqrv73gpJdL2Oo
HLmnd8gfdY67VXA/CNllD0M1flNdC3UTjcWgcPxu5J+LRMtUJcazZV+tQ+e7GJiJI9umETauAXuS
Ffk3Naj0NYkomioP0XY6PgwQ5WEvG5TLE6vfMu1jKGYBGvhyUssKmhoSy/n4L7nHj9fGbqRd4QDs
YocjbXV59pGWCtpNOKi8f1IDdB3fxYKVpCfbq9Q0jGZOLI4Bt9+YPfU4E1N2OQZhf3avXj0frsVB
avvgJB6WAD2RN9Y0h1y7mhIYwjJjulgWx/9/orXVcGXWLLNRe4DZo4e/SlNNXwTFVBviqYsGkeI1
gTAfn+n1tlh2zwJlY8HpydeYGXJ3phZ3XHW4hf2BDdvjddpJWEhmMDqjlqcmHQSZlz+94rNFzPMT
GvXsJn4QdB4Zu/V9Tcb4W8Ic0fI4/E1zQoEcMHh/bVnixw7Puihwd4u41IDxfaZ5pC8dHQVMVzv5
bePLBp2hT5OOiagCB4fDKoWrFerjB0xJZRK1s7WtYlzaV05lw+3ctmLzWm9w4vbSDACBEGGGeIs4
XKyU5X9fbDhi4gKLPQwReORexX8JLz1OEo/gRaFUWp5dD/OH/uXAL0YiDFh04TRV2/Rj2UOWgFOn
sFd/5V1L71sA+pZH3g69hVELkkoA0kJvE+rg975G6PDPvKspayP2HRpG5eWKXDGiT7A9Km+GdlLg
loGx6iB+F/8vVLpdLiISBBgdvR+3Um4tdjR8DusHZYJ2gMCdN5+QxrKcpLFY8WOzGR+4pt3krEhr
/8OaEBgLj12/m2zFN7l0yzhBYfpKsLpwG6uTcbXav+MYeMZt8v5vLH1av/cP3DLClJjZbCsiOivA
200/I1KiSuq/HnwMRvw/cehRPEP6VdKgP/kU7PV/Z033mH9id/I5DoGG2WiWffYV/EnESBYUMreR
jgJcPU87vWzUPMn56I7zQxwBPwclaTxcH/sGU7g+E1v8rrjIaY0FDLQ7lDrID2HQ1Lx09QmlulvH
XTM+XvxFhT4vn0xi1S9YbTlmQ84MLQlWq+Dy8MSBnYACcNUBE0tPOZHoac3hx8+RH9LDMJOjkpUZ
5YfjXs8XZaOnCLmFjeSq66J+pGdLTCixgiEED5UFHPErbGba/pMbXj28/uZSR80+sVJSAwMVMSU6
Zwshrxrkkcaucy8QPGSYmiIQT4Y2XvvW5Vbq9Z3/5PYL+lRwPYxcxYmYH5qS5KA8/si03r31SNdl
+oIUBiDKMvHKW4l/0sJHv5TigGJe0o7twWnt5OG63mgc/N5wcKmLAraj6iyYI0d4jK9Mi1NxKsTD
mOLnC1s0ULBW3h+ChVx5WmNcsBkl5aCMuHiE11/DpGQ1a0sosCiz0p9UxxlHMyBQIA8sZmMlmT3n
xYWE2gZvB46o5aSagN+IOssRalQd7XwG1Tu0pwUYw3T2dtIN/NsBzrDTaUHYfyOD/896KESKXhGA
wdTqO3TnNjDhiwn4qhqP6pL6BMq9smrD7L2mCeAKAO7NP+PHKBR+61q2i0OnoKN0j2vVpIhmJbrc
izM7ZNk5f+5F8hl1dxSMs0MN3PUjZMsinEgFvW==