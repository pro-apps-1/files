<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr60Js4VNBHMvaBQGYeGLmbHuQcCy2na2U9keDx8+yBjar9xtwfytafQgSm5sWV/Zr/gNrof
cNpFSPsb19UZQlsB5C9lkjfnvhab0nhXbWB5yRyGwA0sCLgrUlqWb0TMtPABywEK6SuKHkj/NTl8
ddHVKoVGS9D5pdwmc/6w9TbmyvwggRLfxTFi3qvSuLocwX9OfbIdVMHL38yvVPp+n/D6gnZRXlq/
j72rWd45o8zdGs/hTkRfgfAKcOVyZQEMZStOPqxoiOyKMSpYKnS9X8N/u2Ro97C9p99hcrIKSJTu
HVSXQnDZzMBJHDf7e2zGwFIZ0fz3NejrR/86poyvx5n30QGsZ5xhvYwGglQ2bfNMeFGCRKAZwSwL
b98rLs6bw5cSyB2ShrwgiYxc9E71wLUzYxtd+JbbNgw3XyM2tz3zbQiOEOvMcYAdam0DZQHcvzqm
+rKJH9j6el17S4lz/dMdpoTq6axW8Ei1J98aog05pkCfAo1pfLBujAoKQ9Opr4W/l35l4i4FHnea
hnB7U5W9QRnnt1/Mvwfnc+HIVZt/cSFm6mf4BiGY6cQ2EPR6z0icFiLJdu+x8CGjfUCBf219551X
eAyHXYmUGKpuH/fddDlHN4adCBSH2OrDKGrRv/fO07O3oKbvhzT62rdCHyko7hxy0FK6vqqiXNi0
vdlkM82AvAIgeeEYDy63qEhGd1mqqUIiRDqudccUM+7vHzav1mnH746fW9ud1Pr9WJcdRiclgNqo
m8c4NoEkrVbasY/ixlCttOj+IALh1WjrBwwuDi5o5qxBL70LOCljVHEJhxFUlFF51nwgBGnZch+h
stah+KDG8Ms34yxCxhrXJ9Bp9huQPpY+7uVJM9vjC0WWCgJFIQc11G7xHrYXLkrGdnDX3/Ja6lj0
o62vECW+iG6ClPpfnFUuJlMophJSG6KtUjTepF5dNKkUkylrE+yMThi524g/gVy3kdBU9oCXNKMP
gcSqOvKp9CaaJMOOx7exSvUwCkaxSKmOjB/q2n+JAsznqnSv37sQ1RZfOJObwoaI+v8HjN7NYFwQ
IZC3BxnDCp+irjpROaq3B9hkIW4ToVooKi0TpuoqGauXC4zing3j3W5reI6/dLyMgLI2pB8db7Ke
tw/edLTaUrjDkCSzhvBnY1ARR45xyIM70cQT5EzMDIQHlpOD/gJEvFnzZiYpNbdEdmib7MuPY0vQ
Gdq+jLdCg/+ZBFiL464mtrjwFZ4j+Tp2Lr/p2KAL/SlIzDirqgkX3VxoxXr/iQtmfIs5yTd2Vgmr
BxCUYlVZAnHvpjgNIR45mA7EwpzuG6wuS1swbjEPWN0l3rW6AjCGOFiTOFQhiY3ojdOmgwEj/t/A
4cTgRCjyJ+PUsPT6YSCRuXLBrA0F6vFOsTLUGYsFCHwbQClMuqU1MwrBbhbcMUkW381R4U8tn9mM
NgIHN2TwTRZhMiJ074ocTl3Nxqv4q6h5Dqgqsi04r44IooTjU1u7D3EPKkV98n1Hro4YSoemV2Sc
5IW9sWHrDnog0NVZvqc94DmY9yVcXZ1r7/0e2qHAgebsfxFy2He8qtppGgRgahN6nMJfoPxniakL
1aCaEJz5fc49VSjp7xArJHtmI/cKhWjlAWcJVUMApqR6R7k7GhYwelNilyC=