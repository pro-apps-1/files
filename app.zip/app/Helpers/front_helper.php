<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPm5+NzkzrgCSkBpA+EfnNqUCdmkMH1LzxfcuN3CQAEDnbn7nz7EOBinWSUEgOpSY4kgfOOpr
wqgUk7eAcPcsGa316lUub3xRrF+RQfDI22rhqaeNVa1F7Gy5s7xfP9l0S73aIIOUzZL0Wnf1IjBv
IGX3NEbhS3QMY9x/AeepLI7UuIOKYN6GVgCQ3scxHN4ZkRd1ZgvdZ9nlrD/aHDVl2kGXZ/COTpWA
xLFCrrETo+7T1L84s04hnFuLZNZUxSFqPo1QRjHLK0sFFSqLpROcz/6WCl9e+3Tjc8Vf8fHAk8A2
SYeRPdEibm4f3cSBkSQ7Q9fZoD7V3yPAw8QlL8iLMWdSdMbgd0+GdAoYg5PLyvl8VAg0MC12ZKLV
3zde08EkWAUreee0AbEEVjQEao0w+89y8A3N/WAq1F2CNwOdWZIWdIlW9HS84u0/H9ltSoOlPOuk
tlA+XvrdcDcj+0odmIrQlTQ35+gifBGoUEb+u7mChBfpM9F1AnIGZzJ4FK5T00yDHu1FWZgfWfU4
wui7FLp3hM/clH4V9qgYhKgmRPEq4djOiII7mXhAL2643z+Pd9e1xobr1aKmaGIvOYKuzHrgi8CC
GAgUzpx2XQSuYu9Vp20GePbI9FsGyNJyyKCa4KQ18/qDQNTMfWkogLSnc7U+qEEKsW+s8DwymKj5
FxQOQdGX+MkCgOWaNy2s0KrTbuUe/u6TqrrDV375/3y/VPTk6Cs5AacumreLD3xvu5xcVhBa04Fg
fs3IfEhwQpW/fpAmkiVFZUot1XtkTf/n2+DdPQwXBNasZEPeTDtaU2NnpaRIp57gG7willQ3gxVO
SIPD2wt8M2zSsbZWCaq0vMeXfdMEERs7WaY126v0OmK7UE3Xew+qBpw8VLWU+K3j8X4EjBXgK1uA
hNToWPr9f/Da72/C7WqBi+W6fCDex/6EGHCLp4M2fPmBi4iV0mnoEaEj9CHoTwtGFNrHvlRTo7MN
6RSQVwi9V4wD0cIidvn6QF/YjVHhyI5vVhoQj4cNtMCVm6n4e3jcVhDByDDP0fgNtd47gauCZbQS
e7R8S6KTN8DXS4peHAafm7yiMfxB7b02Z5QH8OrsnSNqAFw05BqMN8XheZhQcsR7fzSxxaJBJHcZ
/F+nFy0zot1jVBvs1pUDqFk3DhtVE79+hcWCOyoq1HvJRkziGfPqlGXWpr42yJHPmuHxSdIcyT1i
WmeRZZX4m54cITDobxD5tS7U1mT++XJXb5scMMh+sICmOHlTsigqsEnwqyJFMDslnlvvA2nK54LV
eEmDCFouKsyBevyFruuBL139h8DCGzf5o3DJolACK/0aAEnLwlHhiqbikWjhsrOR/dFbUlbj7QjR
/7uRPf/MOOJfj7V2a+AKUNSqfKyT8u57en5VvaffBEAB/2hhdDmg5cwV4mAoT6y+7SQKWbfOIPJw
hpbO5DypGdunyXXF4rLjsI8/FiUz9eZzYBoHXayTVFcfdrKI0RmEZMNiwuYTzFqp+JL1OfvZHA9G
rS9CGa2vPngiI1+Vhr3bV4XqWxU//N9mle7bS8r62qQKusIiq+UvPDPr83f2uE+jRShrQGvYU4LN
dnf20UMuuM7hED+BAiGmeNog38qCT5UQ9vbdpWxHoe0VB7ZC5wqexG16