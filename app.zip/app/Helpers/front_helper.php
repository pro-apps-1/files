<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtdA2BKCcl6woGYTblP4QIwyrngo+wmnwOAuC5njhrZRYWXQpWfNj4ZfBgZT4kbKqaUe8VGb
QGSvQsgP3uajlFJaTOKD6Oz8d1/MdwslBBv910PqraU+e8iLLBiA7YY58SuR7qhFCBTgHViqnR7A
wD8Pc/5uOdViWkaLt26lZkothMZ2jbolNAuI0FdiHbd6fGF6ErG4QLQUwbT0AKnfrwfm0bi1d5+y
SXhkVKf1PCbSIIc/qI/BbX2XIGmzvxrjLU3uuTwEsDRsN/vT7QbbsKtlWPTehNUPHdnTIyELFFdO
vyjXqnKVpOw5jlqiwLQ16A7ONOcI8DLIYDswu6H3GIrXNe7NPff08dHrlIaX3q+5eIx1BwmxRtZQ
AoYSd9O0p4qZEjWo/niWYBT+rpO5jlZ9hvhBbKOm0JKNGPChD3VJ614+b6R+Nmhhurf0RBMmOgKR
utnhyEe1eVvv5e9oVVSNhSa4SZkWhQVh3U3RMhxKlt9GQC2Dy/j/flhkjASqQr9khmwNkjcLioQI
/sil0VpGaA3Z2gTZ4AYvmAYD7JCepx8HGHbnOWHJzxbInbxBjX6blTLOrlI16Gmhb17MjLCffrXR
C1jWNw2paeBaFUVVA6DjxuWSCVf6K1oZkqeEu5uPstT1yIShSox5kAlEvrqNebKbSPhYJGRH+K/K
muo66aNNNYqLnkMd+ZVy78Uu9iTOtOTVI0dCW8ffn8JdAkA8hXve4AQzBMivYUudyZ0YT72qg9YN
WnU1QStFcIpvl/5D2IOmnNyALNXzXtzETK3JvyNHVkgsXH+YWimqMRMLyokIS1hRTUuI7k6g930F
PU0/EdiqHBtrYvjo4WCchI7HVFMJGakktyBDv6UUAd5WVqmEdLbdhbWODCq3Obzz7QYM97zs61vC
Mw6SYORF5+cVYj5Ek42EDbKu+LOa0mz4iVQ2bkTId9+keASSkcXAuGlSqzZPXq4kfzjfpI9Ehbeq
8T2j2GEqqlrjuE5/IStlCT8i9Ge+mf0kk283mKY/M1AOB5Y0jjqCmPeVv9DQCTbkYklBeET2msjb
Zmq3ExrJgy7/I3Hcj09/xGHSoT7unhWTvQR6APs65mnBcdtPSVgcKyMdmGzevBAiCDT952BHNSt1
Nv9VECbkb/PNuvP83bvjla+d9GNLcyvQU2NN4cqIlyOCGLRDzTi56+a/EjZX6T29ALH9tzNUpOGZ
KdEU402lPiXguQmisTXE3E5Dj7tSaadc8GWVXJqO/YOvHSmwzkhFc8iePW5dLZXl1aY1TjZ4AM+H
MZyiPNz7iv1FdeOtKKobbT1ClaL7jKEweBP7glDGny8dRyG1Nea+gm4x3gMxM59Atsn0M7q2S6ry
gFLHloZ4zMpCANp0BitFuH4j3MtGjWkEdSAzQ7MmdG2ZkCLyVESbaz5x2ztuqA9Ut1vKwAe4AEdn
+O5Oad1jSciZW21jh3qOYtOSgGlYjQVFhBSTr9wbu0KJRXqEMjZGomVAO4G9TD1QArrF51e+2eVW
K3AVNMOzknBjUtZQ7LXuYO0JphhmI/Oiir/aq2zHSDdB3f8qyjjN30Hed1Bc5IbF1AtfRGp+S2iY
8lFFr8Fe9SDw2tjAvpiv/xe3SDC/mf2tvvAOB1tYtolER1ghfx8N2XSRiMksUEnVsW==