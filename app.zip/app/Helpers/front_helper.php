<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoIXaKp3FsfZccC4RvUmedEFuqO3BlzhezvcVv05sUopBsBOl6ubNnLrS+hPifU5bsxUSxBj
iOepmGEeKed/FonnYbJOVkgIJ8flcrkVi1g9DD+Bpgr6P/+txADM7ssdLLshOWkKN5KHh1JBY+Ou
2Drn5ObegvqPYdp4cl2HovfOc55zkRp/rZw3cBTXx20LFwR0OYj7zN1E7NO1syn3ilbnttguCa9x
GamKdfMukMb2tMU4sOPX7TnQvq0cjU5nLSjTveMbi2AXEY+NIVLnj/1LIwegR4+U2WOOuKoiqH9S
pDrg8lydaFA7GNZgHb5qcnzvxyBGqwfnx/Aq4YBDQrHVScdD/snGrpwgE3CFY7bc6Veh4vxCGut+
5bg+qvbEtR3jvQeNpcwrNWlz3F7NhH5zbHYlgKWOHYdPtIPktBy9XonHcIsmuaRcuS6W9qLIg0qa
BUYHuOisfsKcUGNrM8V08t5rMIMohMATJtAyJic4OBdS1cxd4/U7fimPe2WjY3fA9qXBwg7S07GL
2n27l43WsPj1Q02F+e5y6uD0fLm4V9zkCaSitn8GOmZlrsBJd/Udgegb3Yi1MHfswGL+TDoPBil5
seyD17BWfLh6T4/F1pkd8f2DwiH6ut9CMHV65GLRuFHLqIMgi7oI8Iwq7LrSvSTphbXaIOB7OIzL
CaYDZe/3IAgc9E0x6ZQ41U46iKUZeqTmpD9z61QNsmKgiPLcS53rxeCwQGmQlpgdJqLeU1kq8YM0
T+G4DNNDexLKe9+11gh/6AvDzIJfofYvCi+gldvOjjHh/yeT8SXBdNmKGBy1AX8/mmAl/KIXzNoo
D/1tl1Cl113kEgkdZJPslEtinGiR5mgE9hVcUclqEF2YwNtPM+8Xpu3nytrAQcoJENnJ3RGOUDFn
v7McRk/Bx1ODdrTfgVFCbT1qBSgp7VVllGaScpAy2+QfpO7w/PQeEEATfO6hNb/JzYrIqdlAU15d
K15MA+zlmLWUlOwOhYpOV8DP1HjUKP8a9oPzlRuWUMdc3tfaPm4cc2ui5CjyiTlv4vhCdukVoLBn
/Wogo9m6Z7GMourrg8HVTaT+ud0GocT0/IB19jfxTNuPLc6aZqINKIF9AObIH1Xwm5SGRWybp3C1
ISBDEB/z+iE7xTJ1t30PbJ/hT8Jc9m5XYPD0nK+Y+4ogCFIfoAretr1Gm3MQ+yXDVe9Y30J+1hrm
BI1fvfOas6bs/xbczTZV0YFnFRdFfsqTn0J91T3alkRqX2pcy5qq+l2NxaMYeLwvyH41rw5tPOfw
blQ6vHISAGUsN7GbVkvUWKsPok4W/MbPtQE2+47YJwIhsKgpR7MrYfOIImgbqef8ETB8u/SVYpGs
iT5UICZ+uXiNJoCjGu3g+fcmgdmvFgN2ZipGlIAnpI1Yv46Yc4MQA11u1RV6fCspl36Qgsfe7POb
RDUnER+KPHYur+cIOCb0zi4MozH4n0M3wnjDsFito4eOzxXVn3jbflcYR0/U2WQYcYi5b4rwY2dj
fpZmtJjhmnJs9vyBbct88mWgFW2yKhluFnSotRUusNcBYKUfW45zYQxF+l2IdS9wdVtZtxdPPp+M
sozfpGsj0PPJ8nFq0GtaGlXRpAJgQ8DLvmzRd3rLfzpo9uS=