<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/RkpLc8OJQULInOUXcJHopsIaQySyFOrvYuIMJFbzLg47hld65/BhnHd4qfqfCkksPYhq9k
iXrLlSEwP3CtIJ+wCN13OMCiQ6931SBhEUTvE4jBoj1JwSTuajV8HYvF/plfWwfg/XSgKOtp5TIG
+hFkVrX4UGV0PQA5azu5CYAmfItTmxM7SSAug9q5FKKAgsc/X56yLrApBLDRvGoTN/s1AOgKWdpi
x1tBp8EGnIRemYgCtRpISJrOcQ1u+FOneNIugTMs0bR9yaI/G9MPSJsk0a9hBMOOMt+5dqBvyrw+
G8i03qvc+H7Lfa6FtbaAYxhMZu1N605Yc8X5xHmxckVjMt/Ly0X5rCY2jCcMBczM6ZYiA5ImaIkB
A9dDBc+flPF6ilTxqGD84GcXloVnfcziUK9nueVa+GpZWm8e/uiszvER3ncJxFP9MG80ECuWaDfr
IlcrVw/YxwdDJI0TbkIPsDVz5+TLrnf6TX9FYm722D13PY83RG29+C3PqQx2l2PeqMHBQU2i9MbA
ltR+s4AtEo9tLVxPtqGVYNNy3VU4X6P4PGg1V2A4QzxQaHL86Zff0q/qaxvSqI5+B6I5+t1XeM66
u9Lc3ZFBKIQlakagRy1p2IQLPVSxpX3Xq7jzSeDlA656NQ3pccjWOvxgz+IN27zoTd51Io7Ogdit
ZdjTxTLYUVdITY/pvRXqBeKQUdC25C37y5vNebqNvW3nBLMW1PWrXHUfGTRNXSiTG+y+C24JVI5E
PVqspAKVPga1cifxzFOkG7M3Gdr2YuWTddFBPWOp8W4Sabal6glcuRifCUftlkMTXxCn6lz7efW6
h2k6kW+WUFezq23q0u1pzS+u0WgthdvSVSlIDN254Cf/dIGQvkRJLNnRjbaSZEfK2j0up5YDISfQ
2IEdvrSvBk8psCco4Q51/qMSk6xTeXtuuOTaGFTtRWOsXUccz+m9ucWAPo7Q+7IxD1mfzwe+PJ4A
3Ox34nFc/ifh5tyZFXFeHDAqcr1aLVc/5EMKBQMaV2QkdkrYhfs9FXIZei6O15rKtHvMfIpskMmp
ePIiHgDw3iDVpVoQ6do5KN45sRCXN5jcy/KW1tp/IzJ31XnSxbg4piK5ue4eNdVUzCpF4tuOB3Mh
OwkMWcDvuMvbUmg6VzQf8RSRIFXo9d8+AJA6YM9NXL970TlVP+7D9wbuoS+3XhewCYocDc+OgHY7
XwS70A0lyUitEtFEUr2m3Wwa/bBVc4XxWyW9c7ZdxI26ecHala/P8eAeJZlyOiSxgsk+u4Y9cEKF
mA26U7iMuJyx6AUlKbF3fw8LfqKB+SGQReGmVnbU7wZLYzhdB1oVqozzb2hPinW1G1tifDA2Vk72
EBv9SysN4bvEu1g39Tgoqbglo3imOahGkKgjFxy445DYw5TMrIlrxY8wdJr60elsMHUQAy4sn3Ho
4ABXMQ1Hj5qW/4abq3MMmKmIMckw5rBVio9DpEAIJ3QMYxl4lilEOR3nbZ6FA0NTIEGkBow3Tt3X
IYcP1gfnHmwPYyBBYlnYIk6Eo5e2kyPtHfzfJMQDCVIPzqt5E06QQLuevSRDHt5tPaDY2I09RFoW
BxelkeWn8G/31NUqqAK82TeiL+Z1x265kFFFYLFt7uM2OxxiV4GnY1avL18x9gytGJJ5Ae3DjICi
nCYb4F6LUm==