<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx2sQorEBb035tJ+3WD75nap39PZjb0suF1n5dX4ZIus2P6fueHJ2rvM3GQZ5eGzQqIDXvF4
6cuiQNu6nljYd+azI/ClkZWX2qlDUGxOuLKRCRv1sib9OVq5l67TZyFSevJYVnTSS+NXPOn2tWju
gA9/rtQ6AOhFWAPTS6magUT7wJq6m90HUnp/i9ckHfLkOEMc2aN9j5vEMXKumqUiavKQPsEht5CE
Y01G6ibkBtYHooHNSEb/zo3NEBXm8XbfapUzNCPDG9KZFqh4jKURPiTfl8FBNrqc8BdnVuIGdsvS
c1shTVzI2NyUecFFiRlYwysTeA8wTWKXZU0WA99J0PIdE/QGdrDZq9IsawIgREIADu9xzS2Lx6vK
1BAlLpDr9vIPTl8ZciHlrExxKwGYJu7KtEAq94MivEqmmm/qIUcIYb4gkX3iXu2K1QgGYcXu960Y
vWUXKdkaRCyBnCtKQmFuqd9ETv8nnPNNYK8577kgyzaHOOOrOwScNa7WrwkGGAfs8xsWSemNGgBH
37eWRQTtRWjCSMZSJL/wcP3ag1kaSwH3oJ+kNy3Q1HA3eG7T7/32Y0BBMB6DdrCXWc/0iFQn99Ix
Cvd514y3PdlB0JLbvIpOGewOk/Y+fNZQ1qpGnjazigi4/+krvmX0P51b5xzrOAPK8H/snu+ADHR2
ep3k5G+xIc25hfp9A8EUlkr3TPaGsBRR5kBLNLaqDY1797acyeGZzWdDKvTdxfjYEKUCgu2yRFN+
ciurXEclZeQ7XtK0GAHJo6wXEMpWRD42w0f+rr3Rc1TtzYwDiOjpkYfwRtY7YWy0PiBQedKzgm2o
Dk3T/gbUxgV2zW0z+ON5xa2zbDESjMdrcWetXRiq6xAzbdOaKhka9lnx8QTtjEG/LJfcM8jz3P/d
Ri3j+0FBr6TiB1lkDCT74MNL8lOtkidH+K71zUVyHWJ/2+OK3Mp2berdn2B9JJPwkFrmPFkRP/Em
bc6ZNLbNgaIxBAX2LVG7ermfss70fJUh9it8VAIsUxSBx09hvf4XjoUA9AOW2utLOSWmB5+IR/2t
iDe6+77tg2D+K71JfQKmDWhu0tHaG60mABmYEemp5hFnXef8cUXmVl8KfIAjVUEDHqV2XwCE0AI8
8sLVffTaPQbDQ1L4UKaYJXjrT3DrK/UMzhHwmiX3gtMG06grQ+OtuxJztxSd8W+Z56A2jWZzTLHA
bNuSqmH4JfjvLJ7IWrxxHVkMU8Hw5aiE4TDDtoQAAkis4ypc/Yc8r6RnaOkNLpkUMnWl791G2oXb
KvnUpL42AHIwzYDc1y3b0lyXOvT+4yTH71oCWf8D0j/YRCK6zWiKSPBlNpi2vMjLk1R9rpDxrKi1
XepTf2EiQ7KiIEExcyz9bIjMEO5cS9fey8dyfzFzWyLVqHUgu4WJY9zxLkYi/YVC3ycT4Kde/udE
6wSJbPUbLVSNhYJpc96X/rKW/UPOUNw2y16NZjwHKFA7xg2Pc0k7yFSG1I2FPQbYxodom2CWQL7z
cCoKl3OCn7QAEnpBh8eXN965Cq2XeuLMeR5aKaV6YgIvH21UMiCpCwwmBv2k8RTPAFSMEfOA51rY
PKESoP4WxdanJL62YCoUPCRK3Wy/v5PBHWytasjl3wE5Z6CNCMwCZHVlGojbeOzN1GLDNLMZBgz3
zZCV