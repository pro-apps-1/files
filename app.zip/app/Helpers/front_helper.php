<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr/t2qSUQV1evpMUP3aAuTHiR45EAnG5B/W5OcGJ1m6kieWCQZjfxYB74ZSQhJLXaOdAV93e
M61x+mJYMD7iiiBgUQ/jqXqbrF+h6kfyPirWodXAGeSA2DR1PRANZ6zBmtagR2Y0uAXIMvKELtk6
GZF+XYezOcDEEqsOcj13rUfIkfSUDkIJW9uUaIhRchFFQNT54SyiFgAHlhYrZmA4W9oaWvrnIsSm
kwfSz7mOMfKR5q3Osz8jiFm3EcJAZ5lq7yGDJJ4PjaQ6z5CMnktgZlZfx5KBPjt6ATlkORfGKhr9
WiPgH//0A1MoxqS6PdYyakWN4yVBcdCAXYaL/Ld6+tOPBVasXbbwqVRyyfg9cegvW7OxAPF6zzSZ
NMq/BZUApfDDejVLA655kThHPz3zs3zFvBLoCdi6hFWxKJXeUbjDkxrer3sxAmwROFmhkbK8IxzR
5eUsbz+tEY4FIyJfIGWD0veVHQ+idPmWxeVG63FKhCi5q6DQzMMCuzARikQqfZMpP7hIhdjYOip2
koTLrm5P08ncWAgla/F/ASeJ4mutrncsSja85pDyD7KWcHeF/1BJwv2dJ6hqkTXNHre/szXhNCDi
kt1/zzy2ONDeUMpLysZk3fY2s6z2pvClqosgh1TcsybQ/ufdlAmtb1WWOKX9YVYYpJ9m3DMIVIFN
a9s5JC3E/jdsqgFgmC0K2iCfzuOiQtWYfGdNndIxSOb4zlpQ2EqwFb6c/LHUB+AFKCNB1XLM8VMR
/uSLVv6bHxjdnfJMj8XP2vcHc+4jnHH4kJt3Mgkt6NYJo2utqDz0A8HIqFnXBfC88uYi8+Kv0XIe
jwAwpXyfsySMh4JPVW2cN4IOxE+8RAG/HPy598Jdtx3ZVZcN7RXpTHj/5tWJFoUCNt3CAAb+RAjx
y+7N3a5V8JlNzVYiFfgyVsF0FvVZ2KWlTJ7Iu+RZAy0O6d7e24/R1J2IG5IK24RVA89PPv5w8aDw
MFpzl7u/0vnq8qKZ+4M9lJl5O6KfivfZN7pfU9E7h7C0uCGFmEd9G4QCY9fN4eoe5Kma6PuILzK4
g60rfAXj+hd5N4+1diHlloSRd/hFL0zO8YGDwn6s/NyjCdpgDdxOU3HpScuPCRD1B9lqv8fNObJw
2nJof4BfW+1Kx9rJYGIs175yW3dztm0LMcLxqb2hs/M3TBX1yW5bl4cy1QJA60uwglfDtnuu6+b3
htr7dPOsut5kxz6ZqFZ1l/zb9TKwu5DA4h0bcu/Pws9D/VUtMq9pq1S/JB8E8dVeT/lFaLDHvvRE
ns3VLEpP2thP847MBDqpbrETs8fEKqaOCEbsUExOhTXLRylVD+9aMdKIgCYAcDltG0pDCkrffK6Z
uCCSTsWQlX6r3uLX+cSXoq1sJuwxx4PYEAkIdwaK2IL7pE6LQGRt1c9rAc3qd0120Y7B9vWuCRnd
oY3eHZ+VpuxUNE2N4MAJr3+aG5ut771i3PExP5kjk7wgRuG5WgXRvuH6adBqS1ZAoQpkrgluQTlE
o+h4KpOTGbazC2DXiUPtUEp6+O9CZ3K/5m1/j2xF7m3HflbopQoY/eGEUDAXbV1JFozhN74fKVc1
tWjMmvqhQ4NMA5AE+sX0usM3XzojAhGrKXXITyYsPQAyGXuRheBpPty=