<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmS/WhYcaNQ/l/qNcuKf/5as1Fe0StpFgf2uuosM1CJAJQEezeUNs+lr1ITNEK+b3HHhCF42
KzwZiG8ODbLi8JSBn6q3pjgSuGhCVrCstG1X7iwWGQSmY8fmNLbOANEyLDTNTYCJHmcI4Nrd2Atc
NtFlli3+NzuvdwurK70KWfNgUXsFD6RWGtvfGHTvPHChvTOtZNys1d2UdKnPZgFxX7MXdzxhOOws
R2fjQFohc7MvAd4/U4o+mWqgK09/9YAxZaeUB25t6JBBuRV5iQSE4ED60rzWMegl3xwvsPjlaAxf
92iTHBKB9L60GDlvKQak9KzL0kIRJ6/4tHaG8g+JgHX69XftnJydZdjSsNcQhYTc258JfS0t78HP
mAeAWroSHMul3XXPJzQPdHS4SpfnwzK0Io/UQpien18MV/7cErd88CDr4j/7fj7XJXzLkuCWLLjL
lMNRmOA8EPVWFvqRe3cMGtcy8St7aIP+rQEhVAGLqDOldg8llN9nkr8nzwE3toBpzv53JfJN6U0k
NKgUJrBRU0ccToeZNw36o7JCDXw4PNCcHyKZE84G0Vx8lsymI8Lj8Yr80HqeL6YgfK1a37PS4MXE
NbgjsKsJcamVaIE/D67opRHf6ShWgjtOhZtaX1zw3rofxb/aW7TgoM//Fywfk+PhYsjkojW+LBQF
ZUumYkFKaiLb8fyvJRGh1/ZnOyTriCwirz8h1PiVrXBtX3JhKgD7V/GvPqcrQuI2uabPgqEelEyo
lYfVgPTfTN8SLC/RtjrIfy7rYLa7McFCTyCrM46WDbQwiKjIPprduKMHiq2kW19YeYfsZlVZYkwF
pGOrGfz8C8itt3ZprOYVdMO/GBfEo0IurwiaVcmSNAHoxfizHEOC/Hm7d4u1As/PLX9gKC2bhmKM
yzAVKtPZ7jgnUdWWbwfBY/3i7T0glU5sQB4cS8AMl+KY/3jiXTT4M/AxN659cq+UtYOD5e+sBe1c
CLDSFNFtOd2Nl7hR2LzwseV+SWWjCV9xOj5YjerpnBsdAp/X7RUF8VQTvrIWs/EqPB9sDfMlB696
pgElsHfX+vJ8mlJXAqAtlZWx41faFt88rcMM6g6qy+7CYffer/zpcrw9gdajRozd/byYMea/R9yZ
OeIJDWFgZYC17KBGvdF5g9T5z3+/JWJGLpSGw0ddpTktu8nP+T3p3MEfw0wB6s0m04sVT5oTBymf
0hpoAov5EfVWST9AyP+cAi3ah91PLMnfZdF4J56NWUTMzmYkFWhTWWUpNpJCRQzcR3ziHM9f2pFr
75AAHXzIq3wwBUgmz8tzXJcpG/aplp5ZFXClPkxcVX7F5tPdlqik03VKKofhsYPhMIRD1hgnEzS8
q3riSROx6bJg2SOuof3SZ9MEHPtG+oN/KxEZ8mK53b+JmfhfsFYaINto005MDn8bh/B9gY8DWaex
tq6y4oqbwC69l4x3Fxu+KraXkzvgm9OZNtBakqtLaNTB4drFl+GUezZFgBduVMU28xJ69Ctg//ec
jCUv0dLISeZkzV2XKD/Dftk7A+wkwlaF9RHvIxY1pZSEd/Emjg1EMjEsYhPzLrguDd15HLVLPRoz
WXzKl2GnS8fsSTLX7pxFcKfMpnXvjaH0ZVuolWa5KlsYted+e9/gEja=