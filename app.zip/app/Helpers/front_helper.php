<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPruxOASHbLY9xFdrX4guvsq+1JLjT6JV/hIu1jAisgcJ0EsWffjwYOW4yuABRWjlnwXw5kFd
paYjuOfX4k52/BtX6Em2/UKNeF9+tWbKuznDrOmcqgKEoINQfhWzNROZOBnRlY6UB4tn6E7pd2sF
AF+1dpXMeoIEqi2HBWaMpVFJtFp1HvXixXvdsiC4h4PugwirIhl2MuGDK4LMjSIeXLaQXtLn+1JX
5CwsTr8SdMgKJD9f+NVhbCFnkmkfCICrkzTpLlQDKD5JiWCuRryR8iCogkDj7sewQO8wWKZQtq6P
b2f3cPDd1IyJsPz2U5h1h585S2GzDb69RwRSzl6cJ5IB6Nr4bIB6/mNiSRNWlGdydmrg0teiLEAR
P+TignZaSEzyp3V7kiMrTK/j/PLVxJiUy9nIgkdkyjRYUYufn8Fqmm1dGTbd8jVv3rd0L+a2CAz8
B/fT0bEB8hn0/Y/tg+x1Ansl7igOikzscDbvG6BvfEL9xyzamegtioqU8uFbE6M8ZR15OiWJrMKv
N4WJK/WXKbPnL8ZsIog4lyjt7h/wPNU8EUbAv3CaorupjlZvJOgJsxFNqaBa2uVbMdH9til6u48U
n5iwLQzkmQ8XOnX/L7ekUkY1YsSDuGHJqB4nPUfSaYiJf0l/Nb3ppGVS0rZaRavGqaymbfQFN/uI
AyqWXWsde/kceXllS5LZpwbSheBhW2/4Z0TSh2ijkjSnzrACfETTbGMSH/pXL4+dVP8+QmwtISbP
0p+3K+rmUOf7Pm24uuT6peill9opYYc+qYMO7r6EUdmwWGefrzHVZ+0apThyLJbyZnmITx0kbEmh
O5lqscJf8xsHKbAY825Dsf/O9JPzBypyZZe/72soZJ2UQB7q083bp6x18u7ZiGU7Ev4959E/opO6
PHx7g4hpCBTUfbaJGSqH6e9sGTMxZL/UrChCb7ZNc7gmMO5FTCF46L896Pjgkf/j9c7vjJLtB+rd
x7vzay7DRHXdTCsIGqFMunSRVg4pNcu1dWjejE0rOtgD8nQMKPJ7yBQRCS2zjQWDXCZLlx7QnOpa
H2XfywQzdLFBcUMuhYqcR4eHQ+Cag/gIOE0uCGon6zKf/xJ0UxjRKDjSGn0Fo+4xajc6su5EWWs5
JQDslJaU5ef0RF/O9/0WIWmm/QWFeizeLdzYZ24X5pdXFLkIRJT5KRilQZ2srh6SCOCDUNUwSOst
9+mB0LWgwW9sUgSpkC1jbeLIJymXyPBfCtANsAIWHB2wEfWo9njv599vNhc6pehHPb10GG6ORb5K
5tiEiFV3FpgliQoFmh2zTWD3bZ8kGcSm84ylAyvFAcN4JG1FMi/d3M0lIfeeX8bk14GSo8D3m9Ud
p5ZoXOGpL5+NpIz0nji7UGcvRoRvewL9dEwn3ofg68d6aMkVEHUYCpwBCs0REKc/D1UYzgt6XJue
KYqvZoLrb4JLkROUGvkSbPNzwEsf4QtLRJiUdu1nwgqbqsfdDdNbOgXYfdDIGC47rmsYsMm53lvJ
038TkgRB+6tfpcYYqsrzQZO0nBd6AQt/VZQdtODrSaErM9LgHNrxPMHAptewHHLx41T/GnJG/t6U
O9MMfv/ZA7fSV2WMGiKreR4eB184H+Xldhpeblc2IhJnl2pe1zeC+9wk2Ulz/yK=