<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsr9KVWE1wh/OTUBnDkGpch1kvXPLEKPz/ONNKo+w8iIZPG3t9WWUj8E19GnWICvdeVINwjz
7Rv1ZZ4pNGQ3lGnXMtoRvIuWtqTWFau8r2hA2FEAJEtgc1C0CCizY2MF3YabMd+wpiw38BxKbdQM
JDV98Mp8RGjr4HqDvixP3b4bGp/PtWnz9eJAu63rn7z0P0KSi40hC+FCggCPrj3gbrrH5xhd0rEe
LfYZOMqpJYuOqLNjpq9dJDGsKvgfLVLLBKhoHt3hwMaNNktOwC5KGvGCzMozLsMOlyStiWL/hwi0
s9QCAtPAhr8Z3dkQ9CHIKQKaNk5GbOC9x7EUq8ZJ5E4GI0wfYv1ug6Qw7suKejMeW5dgOcc8ZYAg
iWxWMHmYtv9amM6woU0+EPJv5IDSKIUMCLAbypqGYWuRQ1Chpq84A9i7zoydiSe6NbLw12gNfDCn
M3LiuVgjJPS1WgKdkkI6xZHnqYy59t1B8ZA+mgkfhLLuM1/tp5RnOP82M0RZKbXwbWyrvynSTCXz
9Ko3BBg+1Ab+FggUDGAclE4a4t5mGSDah/zaSLFf0PxWgO7Zpf+RKqooDReW0fiKZ48UXo5DgDkN
7ORUMqh8oUejAgmfUrrijN0uEBslacWz3ePjrr8xM912OpcS8IzMC//fgo+4I7arZgizzuD61RBR
THiNh5VvdCYsshGtAL/ERTLy4PN7yfj/oel+5PXokx/Adq/bBfHOEfLT8NpgviW0sFlJsYXBBz9r
lrYFYRhb/vCMcTHmIMyVGtwtMbncckjio2dVTr4UsZML2y7nGCW0be1xRNlNWbcOCcU8b463bd4X
RwBeKxSWWfY9T1ohriyFz5ZE9Ya13iNRsLmZsGPsv3UVrVZmcoZCSaTTQQAlgEacOSlkWQwhOsoM
l+3aaHDoNmsUGkUgYZj7sUsdYne4uB0EqsN6kLKdKQHyJaAG6kLzb30h3bxSuvwEAHhgu9ovjr6H
TPmKRSBVFTbcAxvOc1H7Sy6eSIPWrgSr8Xlq8DsS8XJlKLPOlnDt/Gc4c50mJX6jxAvhBn1QTFme
R74YiisGmbLIJshKAjNDKcrNBCd7gRZfyCCtsVmmTPVGRJrgWFghXWy21u8E5eaampiHlwRqzr1f
Al+PtAtMKlqWaxVev8H0SkD0vcdbEMWvSqxT4QUrYBilodot4wQJQwbasbmiiizwNK8nc4nDPY1E
n9IZ0zwZRIbjYOkYfeBKlJId/51i8kmFGNbLyfK5THsIhTVy7NrNNsdaKpK1YHK8TIDxR0RTHkK0
FZMHbHVkVGrJ6aQjERYh4hHtJshbgYWU5Uw6njLqjddaEwPCGfzjH11ZOXVP5BtLTxibXuYLuW8Z
sN2ZorC2wJJSMeYsd+jLReVixNL6hGYo0bcH5lBLrWK3AR6lD2cWX1D4+LKLAf0mxXCY8m605ZUe
qxX/Q/DB/Kbn5xkAHCXNWtLUuF/WOepuAMqK4qu3H8asl8/f5EjI5gdDnqrv+1xvae9cnJSxMu3D
iIqn2Q+NSipDNs1hXTmtI3yh/HQHAEgMi6YHJOU6KiKclGGCSCMyjwjHDIgyJsSJGJTRBfWBA/Ym
vsztZCVie8G9K2gQSPh6ABNqi70N0z9yVi//p/FFO0Yb+xqNuXh9