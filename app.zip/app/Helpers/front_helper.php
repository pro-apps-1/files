<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoNF2aRTWOzfc0sVPG9/X62o46fiIC6xQD5LsvwrxCTJuEVBEPwgtiBXTDPbpA41GqmPw05s
eH+Di175jQec3z/aqjhxmgVqoxg+YJW8tPTT+fdhlbGcsTPGceORCy0dOTVFIyGssN6FUmvzM6qZ
/8rYH6PgXB5J4y65uMvP+JK1tSbaxZslY7q/wbyTJcFfqr4lddM+r3E22hN/+kfLEW0YtZ4CNf2m
mfPJFe7cFnN0MqDNzHj+K/Ctage+28J5r7esXddcw3OBYl06iL2goSIbkbc0ROdsG2TUcUHzZy2S
AwrgPafQt/MBk4Kxx60iFVBYlwKF5r0GdKeqMVA1L2JBT1mYPkO2CuUUfNDtIptlqadqskh/2QjA
U+sQ1RLIMoYbUkXcIBdVkidaljrez8Q33BIP+moZRrz9DfgNz6IrYZHks/y4SOk88SpiwQQnwkqf
B3yDq94TJFiMFu1aoe7oFt2zaJjLvCNgeAy8DxUH4HpVozq5rWNEv333hQ5XdeKJN2BAjETirn44
ScOu8otecCzTAynJB49VOtzsgrrcn3lFvcuCchRuwiWpRKZxPLKY2V94WuItdpNbeFqq1DuiQgt+
mCgeTd4hloZDsFgvqBRVFoVhuhSPuaBWFZwfxBvkGyunbMXm2Ga2UjXj87CpZv0Y4lLc4n8Bpiyq
quUJKD3hvhQDpbTtnFHj2Ysfhr/c+DWeLc5NTxrY0YZ/jqg/7H8iRN/U1e0rEj8gou1bKwLtWDPT
HqP/XYCC6CIvGsq1vJ1SySMOc1pSetlECiWkrZ0zM79IPk0Y+8mpEZRgB01y4Z3eG3NygMbeKIQF
Ib26sXYntIId9tgWcLYjPg+SzXVtfTSjcc7/ak4KprZY6a2kgb9QVIxZRM+Q9qj74Fbm1E2T5sUA
Yfhnr6hJ+JdknuoyHouSUnj4i8TCTF+NOsxP47sY/2NMpSH37K/oRve20//7LPcp6tE0i2kzqcoJ
OJyEmz3GchG0+1lR5m3uEUvIxSf0KB/w5EwyOHQP4f2FfqWW9CzKDwVWScmlg2TPz4rOHY6By+5J
w/2CmOn7c4sHpGC3C7lc2YHlGwXwztSE+cgpjW6Quu5RDE4CpKApl0qX5u1T0wg/q2kg0Z4fx7UE
3FjQ3b13O7Tq86rDcJwNHeTt1yHjhD16Kv9mkH+b5+GDQmbOBmZk/1es1Wquo+gZC0h7p+id2Sop
3+DwxkrnTWldZfnOsgNKb+iF1d/9QuA6FR6Df5YMFR7z/ocOVj6Rq/Ui0IXy+zczgHL/5AkZxg4i
CQZLcxLe8+WktK2Zm7YmcRMPXTxSULkw13+G6lrZYt1yM/FYDbaAbuKLc3bsTMcEywLEcvQQL8+/
JvHq0HQW8FcxAKlzCZ+YiENFJMTkZDVZ3lEhJvf+arKMEC70P4xvT9JX4upxAC3MX6Wc3aTYXgJ0
/ldHlYtho4JG82fuhIR5NVOZy6hGHlnOCQMxKiMMFmkqmOTKbztbEXrYiV+sjlIQyfR4ELxkMQfg
xZR6zYPNiRNlBQ0oyacMnZeup/fM72pRod/CZ1hB8+9IS7BTqR6DNzzh6EbPLpfVgnRImMMqsMse
5TKty+In50nZ5neNbRrOs620wEvUl8ib7x6qS9xym5dBkAlvgIK=