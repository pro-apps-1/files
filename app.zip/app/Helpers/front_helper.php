<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnj2ZwdP4dIEf80QYeQ4SzLBWksCk9MTtTjir6j8dMpsfaKDlvm5DNIKnoRWU+5YetT5vb4Z
quoecjkpUbzAe2d5t/rkj24txlGRhknt+Ux6sSjs7V01kFo4lWS6TbShCrAlf/8Df2cIH3IsGRFJ
iIwro2QxQ303BbUfHoW8lLYnVKFHxPzsZaksy8mR1HAGKSAlsrcuGOsUiMUK4VAkJT+LQEHRAeki
cEvdv1pFLDfLQGZWd0ZdbhibFfzENdOY9WP+Rn+MgeT25D+EjpKkAQLjijNLQagADhYLRXEtvwFk
3lpB8BUfawCi/Fipb05Thz0bI7Mt7ha1pdWjVK753qLGjh6iEAGH9NZ86a2acxSY4TjkhW15do75
Ogy02nLXcBb/B882YPrrK2F0r5cK9WRgm8hVaTzibuFDvQdyIs8D10ABsT9foUhivguN61vwNyOo
03kd/XY0O2rMEIG/KM3tmf0eMoOweEoOKvsbDEYQSSGQ/UY+f5C16YHlH+0PBRDQshx3GyZzxfaA
yzseUs6MwP7hgqtNfez2p8U0TmL76TCOMM2gJ+c/FHom8ZQYcw2ZRvMwMrjC5pWu1YdD04zxA+xP
LKZXk+MEBXxZxtFD9Bj+w4vKw1ymvyxzIDtOe1LrpJbAZJrz/uu1WcjkRA55mMstSxdHLWj34kj2
fgzHIQ/75uCYThk7bmpgL2S/1ji2MmYUd6C2nAskfIJflzigxstWOvWMYJJRQDJEvfEU2DMy0zeY
8MMGGsZ2lObtEaCXRtWpVpcfx4Mpx3TgLWPUl0cdCl8K3tZ7CtwdH25oDCWcEOX1w64v8nrbR/1N
wojphrTen4Z6+jkxcF4uoNMelsMIvDuTmjXPOEyPyIQpVfmwLoCNuLz9tsw3kWS7Fz6F0MsXyiC5
/68nhJjgnEVERjBfmAIjUn27B6Bl+QSZ1KwwdWb7Jz3bFhDrvdf+MYV2shQRoPLtbhw3phSJExAn
gw8Jn+2oNa//52anmkNTrM8zO4hC/HVgrXRUQVleDyS0GvnACxS7XPWjuuAf4ZQQxTgD3hSxSqsd
Cv6tTElK+8t/HpdioNxUa9OB3Jy9gVDTYDz9SH5A97EI8UaM/a0RIfYOLoUVivw+E9rFZaqmDfXw
uyv4qLhGCv+Rba0G3e/HeQNoLjU5KYfk8nHstNZQBfa/n42V2+iq+bv9oG6sAKhrp0CUgR46saql
Td3P9Z7jpkI8++WwM9qiRtTf1TAcbkh/iZ9bNQ8OQR75Zq7sb3y8GLCgEQz3SGOIxsMs9ykmMwKF
vNgeoW2smxbecBabH25MFuEVHEijTP9S4jLaBXOYKQ66RHQJ8Dqkh+VG1oWf46/CHAWxsogDf4uY
/IcbzqQ0sRkvwOasxrmSVvLcobACCzRm0JUQfKzgTHkwUhzhVuzlnksON2/5M8craCFIboqOCX2m
KDX35G4qSpvGRe5V8Ep1ef988wmWNiOStY1v2OcoiXU0dsSzcMUbFpPLGRNIG61G1nnl84vU48mT
w9cTYxxY+0oDtQaC+vtEWHW/3SKHYCDRbz6zHDDmtD3QYRYWLqGITp0n283f5E4usHlRKYFq6qMY
KV58j3UbMcPcs0bk/ykNOMoHGhwLHVEEalStKtUmQwUZv70R