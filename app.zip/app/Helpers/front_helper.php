<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnJljFl8OGtybIqXsB6jN+By6H1QvwPSWjL6Se5jooCxETefm/lYePOGp3Fb2JrtQ2b/OkIz
/aUSyA4b84/EtPaVySotpS/422y1CYnXYs2W31+udGS2qstrl7grnklF18bnv0edkbSXdBdaz26U
Exas1dtHJZXSK7/J6NXz+He2UZz6OTponbyPCp/MOGv/q41HPm32Jo55YwH++VAKzy/K8dAoyWmT
AUJwI1Aku/mgNhH+xrOErYU7h3J3o6V6f1RN/yPY0ghcZFD7ml34C3RvuA1sR9jM6sObGfxhUPgG
N2uhQ/zz6SAhh7FblPD5v8ygc6+rJ3Zg3MyMFWdiENal8TqTjfVmcqCV6jx9MCB4QIprTyd2vh4N
61copLnx7hAx3U7ryFBqtTWHsLLpQe8kvuEtrVLuYXVe0UpmvjFzwewwgZ+/My35VheiCRFQw6hP
nMdKuQfstVFKM7A28rsMpUfMyl8x++MqEm7GfKsHVrkDg8vD1btVXKzoEIsYsvfms70bgJe95oy7
gkfVUd5qcW0qAj+9Wx+zwCrqCQ6uICdjxqmWnJDq8+Z4SPTzrkmuvQzxhmjXnfSMq/5D5fJE9/N5
fotCHnOFm1OrNcwIK6F+c6O8M4SFtldIPFH2qwT4NLy3/+yE3JxmZoQNn61uO5dtA4XVV3kLJXg/
9uPyGpEEGU4mWuprXmzdwKgAzxgjwbebW99lBD3t4e9mbZBejEL/RQ+irfxG4Z1rztWYO9swwsAO
c7gqyAb7S9vsMtkdh34SLYdE5Tsa1ETk60kc6N6/XjaO16LRns06ADZkN1jhwA1q4/BaMKNKCN7d
ub5y2dGnD1381IhZhdmBexpAKwAFpdQX0PSe9xBa0Bh4XwuHOBpbRKJ9QYiAc+PUG1aguW+5yXhz
PWWHjxKsn5bnavuAFTR4knRzeK0RQfjN6JNx3A+tOnd1SnvgmGWNwMxb2aXC6P14m3DNm7ydK0wP
kw2DKbN/ohr0U3ENkZyl4/Acfi5MzDxOiXTR1ITia2VcDZLr6mbAGLOzZohcxtvQwAnC66YoRqCZ
KE6RLT0ERROP4RS6GCVkyvlJB61eStRfCPzZmNvkBlLK10nXlMMKduXFRQbXWdaUGRvyQZbduBAs
5xEWpSAer4aeUk+tvBAqe+kPV9yAAnjpqfrHHgt/arJRoxh/Jqf3SBh9EU+u6dJVfvJIMYeZ12zZ
3EjOtK3IxrjQzxpiGMDdCudBA+8iRnQYZ550HWAg1GFbeHCgHjcvjsD2SBQi0dAePvYaK1h2aBdm
SKHiVwDSZuoLgifKZoAxR9JOnvQ2Q8ygSiNT9MAH1fUfPDujV9atymwHXj6f1O+F5dC2vP0B3bli
erShUnCsfDkMphjbKWeQ1dg10z2k/757vviFzCAgi4PyugYPACmBZVlrKrfBZ/NmdPGFrtK0kSJj
oycKhVxk1NFO6ABqvzcQHEHP+QbFcMI+m+YpNPX2rqhKf7qk0cNurAfVzYAYl9FQf7YjSOvdksLs
he6cfUASB9vRJ6kdh93apLj0BIzyzAhAiJz7R5rdYdsDNqcgOarHlB00Z/LVALp2bC+vPmfig9ws
s0CG0UkMkb8CvHJeAWOq3e/Y+42Zhq7uQfU779sv9lVglm==