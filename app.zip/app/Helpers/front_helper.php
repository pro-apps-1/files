<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+UJjtMNJ0nwRb4YLhnDNUbFsgQsvLtKDQsuvHedfar4m623B1OYVCw7OzspO0Qo+WVZ7J9v
oAX48N6HNTl4GnWIcvOsipWT3cYNJj81dCXe7LK7KesMe9bVBx3b/fPPeVPDh+kduhzzbYek/ShF
6pS95AGjS6d+b7y6V4RodzBRM+4KQS4mrJ1aULRbAxRSbJwN4JDB1+0oN65smuJm9kdSgqAnQjc3
q7VLdgeDPFV3vRF0OILAMdOusprpNLqsLm65lg30UZr/oXUPysMTD8bFf7Td1pSn3G+ab9gVjuMY
CofxASKM3OioHs8hE4OsX7jIRCo2T9gGJJWiguGvf21y1fzOS1vVTT9hrjPMcvXjrLmU5vUu5oW9
HZUkhggGaHPrsXWpeXg8nPJoZ/0/UCC/tP4VG3tSdvsUMMLtpTbd6uxnRB5xDWxakKH3gBmz0D8c
gqrhWBuURT5zBFypw+4pbJIIKoblFku94BtGVXgGQUeOYN6Vh3r4s16UCUCjbb7XHx0XdNO1r6kh
b3d0y42426p65CH9q1kevdN0qW0ql/3YCnyXAJlZXCY19PJUcP3oPRDLelZJzD2af06jik8BIQKd
qmYOX9pRUjH2D/GaNWDoUdeSjFtP9vQQG9ZAGn35VGZgG3F/W42x+7joNSdnNofxR5OlSlO2iEez
VroXf86kNkHGFfGuMrXBNcD94cTdy/LTbJFuTULR8AktQ55qPOJBnwIYoWdRRxGoUQScoHmtXAdf
dUGo+D8AHy+hJrCDlGIOjJcoUVMBOI+S7MrUvdaFZC7eq05MLkRkzvfpDvpotUvMBDM/eddjLKwl
FeOsexhj2wu33AZb6/aCoWxQQDUhCgBXRNX9cYDduDUX4mmrByeEvXkjSLqPSRIK/6QVAT8jrJZH
jdqSQFPwaFfZ4oJ4oYW+/f3HV5RKMJT48POiCSZGgQUMkp5C4yt+3ewSUMAQLfZjb+P54bD668O2
uHQngJaPRF+HfV5KiP1I9M13lztiv6S9oifJxENDpMVCFysiLx5HCQbHOug14m8xBPvI7eagr7wI
Czyt8S6IhrDP9MFLW+p2tYLDdO1WU2s62vOpif3CUMaBmZs7iqESQ4odxMZye9NgHOwMmo8nQgc6
FGkjk7gR37lxWdT4a7NeTv5OnaLvSCm0ZffYRtlhTF3BWdOlSHyOQNulh15bb4DmmInbaPRCabJK
DqxsytD4CybH5zEPXhnajLs3DENSNAOI5uYJYb+DCapZmeLIMemjU237YpDT/5u0PEubMKkp3X0K
TMfvrPfd5EOGwxCIE73dg7aab1YCUtwA0b9LwnVwn13hsCi64ZZRAv8742NMEEc2zQwTPPoEuORP
9Nt1vD3nVYDa7AxDgjObnAnm5ZfZcQ4byOiRGv9Er8+jL1GtYLZQ5pwp9ta7E+H9xwPLqg8c1CvT
qhkM329ctJV7t4hYaFuG7sCIUbeLLlvs4p0DMvEgqbcF7CFxFseKeRGbO5x/m0FiYKyKNMv1ZBDN
4nym0qFzA27Uql9hROKpOprQY71YG3k8cw4IWN6KwAIvHxP7Im3xMWLJCgCEGHyvc1kYQLIMCGSo
CG9DDUPoJ0rLl+V4IcUKQfAW2bx0k+VP4V0=