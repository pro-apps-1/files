<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuVoeiGaOXVhCJ0tvpv1diAnxWiGDxDRSR+u7RgOKFPEhTz7ej2rdRK8sVg2fL+/LQu3ZG3B
zWMoz8BmH4M94Jq37WyTsB75LsN5DHoDevuZFmZ53VoDyc9r8HzM94dd97ZxYZMiVeGJPhncO+f6
k9X6A7mBYoTxcS1XVbBbEDLdboVoMPtfN3a1aUkeS6kJK8UlMc9p5y6d5rv+oCVn1/HzhXNHjUHP
yWAX6l7BJVjxizjv7Xo71yY27gsmkNUiy3daXGmX8x4qZZJMw1YKFlZa7LjdJLUJbnDREJ8PaqNh
Q6jsVDzw8LQ4lfX722aHSPQyc63r6WPpL19+M8c/hSaCtbC0wuiHU6/eddL1O2gpPSMLrRWtq+hk
jmaOVwRdsH8XSY7lpOLlJ/R6zw/5N6MmkCBJ+FgwYQ1dFlt5JC5ZSe8vc32X+aLHA2PjSNojBcM2
Rq3GkZvvnbEl80rC5JQMXJ62UGhTAe4lhGUIeZbtWSPWf1LcCp4Qnnr90OtG4qjgpkpci/1+3D7n
NSulI/N6/O2j4hnXhlVABJiKUg8o1Tx8fdFsd4ED7soBoHgWI/BrUgSo/S3w6L/Wml9LaXZ1nLhQ
OqrZ5T5nqsAA2eg7E+oH2JSABJH559A84qWQ/REBk52NRnw7WEHN58syevryuk6DVz01Grsgc5ER
U3NC3U92Mtwib9/8BUZWn9KwSbvsNULfeFEQeuAfRYroD/mCExLStXTQtoMuUYfSB2jFusf9+Byw
1zVLIoh7Houziza5MoKBv5O5QXhsdmVNB/+o6cUqrwxNNGV3Q+bSt9y0fJYCq7zbePxYrs+ZSTEO
dZLmG2YEfeyFMYZaHQ4KRvzaUDXAKI1NatDHOeGwmKG92fZccg3ceUibglF0fEYsCbzoImXpt6HU
sHkLWfNNLM5eLukGbqOskHivmGmFqMfYtqIbEpLhD251BKrEWplf+sh8KHx8KqGhUcBFLL2enY6b
ALimCpi+7GXBAze3EjL55DWGytRh7geGwnogUvEkRY1CSjVShajn1DSLoXW4jKGGUt+O69tWjTG5
/zMahGG7XVdoGvgQy7QtW4seaY6M4piKwijZWhfSbV3vQg2hvu7/vRsnKvpO9ETqyDlECocO9G8p
0G21EufyPMJlB74hP87uIZJiXGrBzWPRYe6qggHFms5em8jci9Qy0sQcOKibu4Q+tA9MJh7W27u3
bq7ViofPHU/SNLw3gq2EIHNMpnq29SkvPMXB6myEcZDrkuHyLB3gueFT++Dw/vA/IvMdHBX4iXEQ
nJ8fiMP6OMjSnXjHv4YuH0NE/MKPW3FinMTnFl0Vo7EtljLFCCGMz/Yh22yFi7qWVMFUKihYCIiC
uClU1kc2HLPsf53mnqDusFvcdl0h+HI37nbgCqUGn9S39zQI+sH8OIedKCS8LDwFMJ5XvJxYFvjg
RdS/iQcZPTDlQzceIPN8NyI3E0eiedcgvMssFgEPGLKCBmiUedycCgKiJCOKhPb5RI1xU6zAvtyD
KpX6zQXcf4zo0fono4rgoBZ93tYtu9sOdvVW8dYbYHAYxmJoXjxEZYjP33f0PgGqeESWZ/COA6wK
J3Iexd0dcQc5TnI8vdWgyz5TuOhH08hCqJMVi+O4/yH8aMEklf2ig+dvVW==