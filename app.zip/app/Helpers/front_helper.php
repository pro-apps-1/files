<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwzh+WL0vTug7Qbl9jASZId+uGCVEDYD2FoPlDsvEcENXJT3+Qw0Z0lZQ+eXqu4jl1o7FIFi
dAKsNJDwUcj3z4jBl8PuOVufFImz18ib3qEoYvl9w16xbLA6VrXL9F5Qkm9RA027EnF4PYRwbsxb
2AvpyBNdtW/4q5CqhHVnkYdpwnzeDxbSvGvWwkeT0Dm7vWuY0bd3VE4mMR8jNa3Dae1QPcX0vLrz
WtfFC/x6HE9tqRhBdnxZJ14YlELo9SxuJ0PeA15yXavASODAXtEDfJjwW1JzOpaBnmHhy3PwFKqD
RyxBIs7HqbzHG4zzwTAUVgistIY8sfPpXqe6QhTk1hS40MFpWJ3UofLEVnnnGE7HBPJofsxpEPcm
Ol63qkjqSXkaawG65Q4F0eYLeTUMXYyEmleVsVHwszoYhrCq3CTJzBhpCOlFYm1MVFpkUySFaNNU
N0vcfn0Ib+07OVu+WS0f56G8kUVsuNPOZxfFsIM18yR+QAXJ6gV6els082/NB8uopwlSCfX3JNOd
3xyh11/EoUHr6+KDSxOx88RE5MhjJa+GZL1YY/TojprQRZv4WPdMULppQHH3taX7KUDoTo6nDDZf
Y7sMwdSW7w+7AT1R0HsGbjGArT9SpvnIvuw6z4y8ml4cyMy1fyLJ/xoeet48bujpQVRe+TWhbir4
KjNY6cS538azo6gnFVLPdpFHSFOFARniInvtlysueyQSmRDCcdruc1+pZP04ikZuisKk0pTt4sxB
IAP2C7MjL8iQOxeNiGiJ04OahkHwtQ8TYp5+Okp8lRgdEibKGyqMtHsrYWo6E+QPspGz0HMH3QCx
44OtQrurmV69WT09fQsv9H20pBADNNoi3QEEASaeIGpkTK8Aomj7w7D68p2sjjPO0Erz97IBze/q
P9Xp5i8UzZ1QzWkLlsc6IDzvo74v5AH5CXTLLx7peI0YFOZozLTqMmmXpUPsEUMIi+6S3nQfk4op
e+gwCKwA4uxN+7Oss+jwH/hDMcX3t/DQu9+W56MJhAyqYiJbiDSlkzeEtvqi0MXMMqmEulQHh8qH
dNyjyHMnVdb0beH/oCEjNf046pJUubSXIp6GxYaolo0vuP3OfSzeUQ0O0JGnZZFeTcL2kyQJpAjO
UyhGngPZzIOA9JVaak3/2uAGDLovRBJGFV+2vou2K75QdywMSQ5rqCIkELBZ4M9euydroA0+OWwS
B9+DhqcS2Ozk7kxJDbubBF5R0NEZvcJ3LJ95gSGMOedqDlpzGsOpN/4OOUfmpbhSCgos4QsOZON+
63q1RNwVuw4oL4dg6dn26V47uk/3KFIpTp2vgNC5ZwsgUj1uKkkuRSPrP+BHxyTsdDzPtRKRgZXa
P6s4ZGeRYKoy+STiT03IhaAK5KSk6S1i1CtMGjzhSUKWvTkdGLSYL6ghKK5WFXm7rxJFATS96zdH
lp18tHxSo5Phx3MXOZfYZ/535VZlKzzlyHhixll9en/lT/APaG8vbOVM7why+ONV2K3nl+AsMhfi
FXssjXrkQa7QyArCyHiHbjs8I2WbXQ9pP7WXIgMl4u2KhjHIXTb1Itsbx60lRsJjmYT2/N0D0Wr5
pPf9aY5X3EEY4N92idKUeCkgXXEbJm4MloR0iUHCuK2JGbAzS0Ucx1ENhL/rmtG=