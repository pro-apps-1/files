<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmqgHVpskhtpZ+ZGtpXnR7zX4cV9nPTEh8+uaRcppbPge8g/A/1z/aax67l6Y8w7ti1Ag+tv
oB3dd6Uid9Srwo9y9fmCdcejSHBD55L9+/PkNud03LdjL1/QSUrd1+IMpAU/yoLJAc7txwpqsgYk
dhQV95SpjrZvmyJ7YbpTlvPa847iaDior4OQ3kc5kQUirFmjhFcXgejsAwEkErNRtlsffkmQc//A
7jSVKSIBc9z3vGR0c+bMFtOK3faMj0k4LsSUGXwzETahMeqc6ktl13TsVHHnn5nxwP54k8HGL0yW
CwjT/+CCMV99dC/T90GbtHkRSzQRVoIurSW59/8Zm11EE8ZFKoeQ6al9PVmalHHtMFLbg0G0vVMi
5lknqX+RDFzLcZ6kC/qGfAiWzn3rIuYpadNavFf1D3BCoIg3QBw6uUL1/jVVwGr3QlVNWmKNRJ3i
ixjlnLs7vrbpnpN3Dgf+6s7iDR/g18jRLuWdPZysZhVI7UDwWpLJ/r/VhRtbknyWcTPrAPN7/pw2
kCrMrKNlX34hYU7cy11pJYP5lJG9EZNSgSqJNbwzbCuMltRllF08i/F+y8K1nDHv5JYZ4dPHMsGc
rPlENz2ljquNGEZWGQqayT9B6gy9j3SwmAQ6q/XK7Ip/jpQnM/SYBm6bSU77vZ0YkQn53D6sps8E
JM1+d4wh2tSWOxlEf+JVdhFwzQ2oqEnV99GbLyCSfgnlLetQlpicU+FbZiO92E3uWGX+KZ8vBz+R
f/FjfaApOcN369JGgxUBOQbeJGvwO+/A0mz+pw3c/INPDC7NbL4NIw16vLjBtRXQWZt2Zm7seg1s
ky8D/SJlX39bgAQgv7qibkDT7QAyc61si0pmfwtDhKQJWX6EbIiLapMNkNAA4y2yAlI1p0W/5h+h
j77ulZR/P8G0HCunhHvKgN5be8Hj562OCy7Ai1MXKP0VNT1cWy6/Kg/QGySQktWi19tx082AxE/m
l2lGHlzGyxZvHmQTkiBbkEd5H7Vh5qP5Zg5hqtHM5vP2N/SI0km+0ESSNnQksKC2Wm1eD2lgagYb
sUgE5KGABT8OVxh9iiv3arqFEMgnavQnAeZHJBLg3Qq9N9mFhM6ztsJXSqdq/1nclHldnZ9JQ5be
/0tlwx+nN8+22+52+ltK10DzR7Jtt6kAh40KyryYrqON+ZUv5qTcWCucqH1gOIHnQmpAwbe03A3S
Kpkv8M1b11zLXSszIBfSr4oYbMK7W+fizi1pINut1oN+mO8uqm5MoHh21LKqu4rPG/9KWm3LInwa
k6diMOjNDbTWTVuBnDxRyTy6ojQ+Cc7E+sBDhG8hiZjwt1RmJ7xxqeEMSWCHoQ7xszfTrqZPoqdT
N0dxQxtN3xp6muK0EvDD1ttoWCXVueRXrZGJ6khdNSCenb2LSl1nRmMGOcaK45klw4byzwG5qF9Z
Plz7Rr7vUoPSUrm472hvP3vbcau2csSksBn6uJ9TJLwfKpE3vLdGDqv83ObgC/WjW3GlS0Wz8BwM
JYHUj+WiqH1qoJB5KH6vrxBJFRsl5VFmPzoK88/H2k3+jUbdagG/r479H+c/1iEbdq+2ARabg0UI
LL9wjNzhnDnlD3zWqRlfSZuliULubAB85p+iV/OUr0==