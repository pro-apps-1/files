<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz8hIjvcfKuIV+dV/LvETRO73MO+xoAWSgQuMAxol+ViRCFP1Er4j3W6oJaMl8Nabf1Mpv0c
SS1Gih0BEFCpMkrxdMgjdez3AAulzwaoBGeHs8MF5VgYOPecVzEkWdJWmC+EYPItWrQw+7E4T/vf
x8m+7tVwWohls1FjSoX/Q9qe7/7HIQjajX+eB4FBJlqCMcV5R1+bHqXV0YI1/E6M8pT6kK6CRAnu
cOPrAANKJbypBdh0Yg4zQjGMjHeBPIlI+t7yGFk7vgmggRGTeFMWIDFai9ThI8bBOTlqWRWMXVrI
ZsiM3OJI57NSzde3J6cu5AQMxGlENbejuyHxqfjqJ+PPNUouE26V7lTVs+DqgLw6+o0RMRciOG3R
rAFf2FCfE6DaPgu4XH5WU8jlcB2Dp8mENPPRMg5dP8tY+eXOSIKvt/QA58fBONNVTei0K0c7mKyS
5eVvmh7yEj7u32ihpukcn2EmDmgeGzVXyg1dz8TbRZEOxkUKYK41CYRhClTVemLfumZbow5xMMyF
YCTDKeSNjh/DRY5+khN0G26Aip5hgDbOAQZ79nmru6P2Ul4h3UGzUYRUK+0UHPri1YInAYhvhg2B
52iQCWdKNASpjBOZryQ4kqsKHQSa5TEc3wG7SSsBs0O74QBVuJW2vWYDRgF4b97RpUZRG3dY+8rC
rIwHfddsHx6JKHx7h3EtX9Pg4gvegvszDWkUtwO+/4HqE37I7NebnYluHzegzO8OIkkfcG3jQyco
GG4fgQIvp+B9R9jXekzm51w+JMk7yZe3ow1K3jv7p9QgeEEMtkwR8dCCE/2o+se0dk2pFmARN1tY
kYyN7x+Hx6duTLowYFGgSNuuz5ntmrRSugpjze4eubm05QKu6apyLTIHBjFnggjlc55bfu7ubwXu
looOPxGldkieRrsWKiaZfKytkh7uZpEtQqxuVQZy6bpSTSjQRi1no8sFJzGT79n0lhOvpkhs+ZSm
3JCZrul3bgg3gL7ieTcWMALAu0qoLkiE+JOhGeEebMrxrbiETqHxityIWKdc93axqCbbfYmw75lG
2sPnesuY8CHWI+benau5VaNzr1E0ap2ZqSrvg8in2pcGezNaHE/ChkU499r7squv99O33NvggQ4z
B69BqHKoYsoXTPScZD/O3YmM0IOewHAFGObvEq6fliUZ+OF+wtEEKToJIFx8knlaHN3wdDxBl6C5
qq2Cgx38qSfemA+OTPnrR30PybXSmklu6cfN5ztPb0MATpDxJyxJ9KH/p1tx5sPxaLJVZjeVjdiE
ebBBygRakOsCfLCdA94lDbM8tLEFPuxiX+OjgguGBaQd+Fr5My1KoX1muL70nVBV+8Go3I8KAM4Q
Ay/X/qrgDX/q7YZDaIVuos6F3Gp0c0cS0yEwbcz7ZRa4OYGB8q5AYxgZ7tjvKl9rHHj53NFjR4rW
fY3UwSpxRuzA0q7DhYNY57F1/nhanKsVaYPi7GED85O1759ttClReFUTsMVMGMiiUANrDHxxD4ux
P1wFuHnBNKaEKh/ZcE8YTwsmX0zrLF3og4hh55gcOgyBTA0WvjjF0u+kHGwffFcPRNC6tRat0Efo
awaO+s446uXoOhZO1WJgPI5inGA11QbAKo7AgBNiW7jLoJ0cFUoA7Pigy5Tg1751eQ+SzAIq