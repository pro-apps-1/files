<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmfOIYNIz4uBgvhV1iTChnr9voTPHCerhUYdxuQcAxhkibBEcHALpeOlfNDmD5zIYniADiGK
kJDBl5zxIrfjzj/XCVhsPK/L02oixvYV9rveotiBnO6q4MoIONb0uy5HYcsHd/6GIwuuOjnIiOiq
wmG81x03hyDQzWc1CCC3VFihX47FG4ndjBmRUJxWvrmRaaJRI6nBZHCIDUVRXoJbcqfkBr2Zsm3s
q1D9IXh14v+g+bk8d4Nw0s+hSenNl1rCPTIo4Dfc3gKi+VXMPDuvxUuHG9ErPNqWpVymerYeim+a
aQvACLce6xc7BNNaqOwupy206XHw9QXdxZKSHn7kGTI34jEUzUGZXTwEzw+OfPG/P7x/CmUeHrI+
DtVE3BJVvWVs1OIGk+M+kRyjFlEM1BL9xcEEvaIUgZG8ACE++96xVZKk4j2B7f6psu7jPlZDnEWx
E2Ca42h/Ehwg5A9DY/Z16Lhgp+dqmSHCs0MvrQCVQCtYJb9wz9vvDGbft2/aO4lnKvkLIdbbxJ/U
nQJjG1cMOZh4mgzcKV0dLQVmVqwTq+Kvzot8R78luLNlJk+6at/1T68HtvcRh7tJdwh/EsJs5EWb
K/UspXV/rFhMKJ6zQ0ZPXSSamvpFDNGJdDNsBmIKDd3MrcXXqufzftTsMd33si5xY8Wse1IZ3ce3
DgZ4BdyIOtkFAWXTodTem6wtHERA6+/zoyKQ+u+3WPgmLRB8Gvb/LxmXo1qojW5egOhXSyhKGhJZ
WRtQUSGJAkaIsPWklSnu5g0biPRZPmN+sPRHhuV79Hq7nwqw1O7xO3MG6sTI3sX7zlUi0egZtxIu
cK2PwOKC581PuAN1rhseGEJMHDn2zImCQZDN1dG0ppe4Nw86uD5GLlk6Cv5sp9hNOm0Vc4S/0vb1
38GruOiKaXvptODtQa/L+lr/WrUgqrtccdVkn4nt0hoOC9MQliVbturECYwuYRKOGTIHTx/q196X
W7WQmkjvTkBXtj302d+KkKqeFmxdD6EIC65odmHyin6A8F8uKaXcnAugdATNMUv54saAATJRtsBb
eS/S6ZcZPCu8+k1RKBVl81D42pg1YpLYgd8avW7SKmy4/Xeo9cgxCIrJI305HBnWGR3Sk9LZS910
956yqPuBetLMa0Dd0H4ZYzg85VISkjS3ikRUiZ4On7ibpECb+1Pv0lEXqU8Io8Fjo1wSDaTFzy23
+J5iCGzFNie9j8PH0vt2RxxFg53Z6V1eE8TehmqAbVBVWYy6/GXHmoLI6/0dfscUxMQAftOc18tL
N6V080qvI4Tzzbc2m4AFt6+pYL8msvOCxbwYqZLSR2wMfIS2bqWgx4pWCwWXBdYt4z59/NmtOEc/
JbuRrFT5mwA9kS0YGQt8+snRX3QZCPTeZhl7g/CQYUfknniZEteVXET1fzWzMzC1PxNhn9Rqy5o1
CqGjtTUUjex6EaqJIzb//ie3Q5nxEdDrw+bV9lJ/P0Khy3gxwiU7J7Q5tmGNyCZNB+YaVxf+97R9
GZPFlV8HduH6gyVWyi3s3XNB632L3ZMJN5wPzFviifST1rGCBzXxVRsWixqWJvkgXybmbJ3T7yQs
1AiV+p/2NouaxhG1BBIfIYpbgzKH2ik+PghOGuY+9ti9OI7+ofXIa8XypP6VFtobntUP231g8yNs
PRmzohec1qu5