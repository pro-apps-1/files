<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtE0rzSwN2mOmq92zDZwGRw7WaUlpnhN6CIN7n6lSLFvzutvJDIwCiezvy+plpSxUuMvKIHV
1k5nbAM1YHt8n0+YEEN9KNqRvILmeNcXPxfpkB/bdWLZqm3QJjeCGD7IvebKpcwmR8L3iTsHTNfd
yASUAAZc/iSNEQppMibWJLLk/X01Npss7pOBHGieYLt/yM/ruw/3p/MphCcvPFuYCxsoFcIH2biO
5mPRFOBK1t4h7eiWWXx9N9ktKSmKlojbYRZZpNjCcMQxLMV/zya8jBPrB3vfQrzdz78z6qhKJTfW
vCRBHNfnkxqUL5pZ0J5hq13LU/gGxvwIJdD0ma9Tb9+ZbMKOqgovcP/D2F433E2har1rU90bu5xa
FnVXd91cfdf6UDlWg8K6sObQsI69wBlhfAu/faiozN4UHaH8+l2zNH4nNsJZS3XKPgOfX1qHWeMt
BxVJxFkNKizeh+DQJuLTOeHmjnqT4uEejqXwl3Lc4xYlSgDPhz6zhWx9t9xlbeU3dloJNs1jXBKC
ckuD20PM309egaXiIApNpAv5oeSFUaRsUZkR3np3btmV9KU2X6ur2ljBSfeHuZVSiOMVVz3LvmQd
aqWojiavoR2jfI+cuFMcygu4ONDHP0vPAz7fJXu8Fx5Cb0iMhgPmNbZXjO/h26kY+NbKICOjrUqX
ssmEalP67AoM1Xxht2TravZnAxsen5nzOsxsV5TrSpeGWgWuqhTAwbdGPM34ErNsNa7j1XQ4HNt6
39Qx8bfAasn6n3IcHDBntdCJDurqDwaNjjMM6dRCYfxN/iL9XpMfHpSvhqQys0nm7FYy+kjW9fHb
w8XC1OjmZUuR0CT+92EWVfD/CCP7L6T+nSqsn1+Dg6Kus/BnHeWwkfOzP53ivfU4Dz+dOt5DrAHU
IFVP3RqHSde2UtUrfUd87B9oNiJ+/EW5CPRIB0VLs9MsFufjpvRXUX6b9We0oAKp5srH4uIiqxim
2cs2P4xE2xG8oHS1e9TVIVrMPWCYvYXUzFtp8Zh4/lVC3bDWhMIb3FNiXAM5nM04H1Y27Llhh9v8
Q3FbN9zQ/F809D+1A04j2swijNO/xCiM04bBTxb6pEq+XKGz//DGgXhOyUCKcKg7YSy25tCAdR5+
Ki+LhUj0SJtMVCKuyHdiT5mLenmcsIjeRG8kTJqYCiEwTqEKHVQ0itsZQkT+/gHi2rij6E09j5pH
YQr97ztarKn7NuW8y6LhEWQBQHv2UH/E3W0YL1baEhnNc2G6sLQkbsVxixpsP4Prl8ihwcM5KWvB
4vXpyJiMyfV8mctVQ6Pk2n9zQ6IXx+kDoL4MfNAh5Dav4NX2TGwEgKxJ01CcDtyjUWUCH1qCewjB
MzrAogqjW4KkCLSIa8csJ5RUKrVzpcg8uUeiaS/qhdgXAdURe0h5aQmeHOKmGP9MhUPpqDPbQo6d
FlkE+qjKjw7Imh6OIGFZHNV+jTtZW2WOWtjPE2VXsgO+EvtGce3ChCZhYnS1tQ4txg3ShkOfydoS
IpxxYFG7XijJRnStaJjmUTxe0eWMeI/0T9KvDeYUVzzOYv8KG294B2woKsMXaqHx4fmm9i/S4b69
k0VEBtalwF9fyWEiPtmp11chdK5+Sr40iPnvO9qJ77Q51u661Pv2CszBwYIy6EZ8gG==