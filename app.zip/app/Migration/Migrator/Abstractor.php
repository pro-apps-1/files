<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsNt9Xl+QPjSXpMpE5h1dL9BlG0W3M3bgQsuzk/ObYrIfaC9QogHJpO4fUxk7C0i0Nymb85g
Kj2iPhuKiFugza+jFuDeh6Jh1PT+kqR6cAMMHZunoBYO5MKw0TVo4zao9EQFZCVcS7jMVGIPPAR4
I133XJDb7gWc7uJGGSJqzKPebB+govDA0JWdmtF+Rl1mO3BMP+m1VEPPdMoCAWAnW2k2vqNYAlTV
76nNlVasLGVsN90CUREFB4noBCfjIBiH84i7t4A2h9bI+Gfx+6/Lx3YILljaEh2KZizO3+z9U5k8
T2eSktEVkUx/jJvu8JuVqIBfm217dUM7qY4YYdiC3KP6s/dqhI2hcpDrXfsiCiGV4jfis71SkKzg
Ebm46E17Q2K3GHjCz3kG4VoQU/mvGyyskafIcTX18M7aROmXQiKNthAuernJhHWTzk7dpejhqZ5L
S6juv504RnJzWO5NYYT4oy2Y7hrGyAEib9/lvUv2HFOI8o9DmvAxRV38TDx02vcPu6umnXWvwDw4
oYIdPPB1q0Uhx5YHUKVcQKIhL2YSPWb3Uf/m/xAyvsHB2MG9r3qd3LRmTfEGlc7JrtEu6eBiyn5z
IAatJNF5Nh3KU89MPDIpbopJMro2sa1V2er7ZKsSDxtK02dIstT2zk/FUToc37M8td0WyNniFQ8x
3IC7Se/TyqRasd0+fgX+82Tk9TCSGMQcCUhSqlV4NfyQHIF+9kGIWFS6BzkRhjSprlW8ytr68PNu
wZNZ9F/OgDntZoKnICGMIPztIpyjxROhplybJkbjdvZYngPBj782E7H/UWtZD8o2A+Tof/9shEtQ
NNkGdush9UT/pSF020gkbYr9CxTY8TCds6rKaTLk8XDqD1vO1DBZ8GsYqhagsVeSdN3YbUruBpip
l6fkf0UT3fRNlmqoGfWVmNdyYS8MB3B05gR+slE8oiWzyfS4p78z3prukU1mtzXvLJk7m1IvTmr3
DXhZkaFSBiBr7YFmIHxvJw+qsQtoaeBiLhD4um1HGxqcMrTFVrPv7QzLByDJfPwyMzjQ8+dYbPsi
AVYvhh5s4oovV4HcyodWlZrW+FCwxVCEkNvQahEfAGuc1dr4Rl1wgdbB7ZWR4JeIcx9U6GeuO5w2
wqEce7QhIz1P1D5pjMshh7EzTVr4ENlNnquqk7E1HyuQcNO1IsnN0mIm8XgSFYmUAfecFdhuxnhu
09kygx1U/l3785zoSybGwAbDmRkpa1r0OHtydfxMoEyd3xNBsNPJf+3JFuKXYAxyrW3qg4mPYXug
xhFYbAMs7dVG6gdXosfso5BiolG34NVnPLbPhrhN6soNpw/83NQDwo8Dc1+h7XmzbnBFyt6ns073
gd1yov6eO+zugfFz1NXObjRMRjOVrIFyJN+/rXiGs5AIMTGC5f7gOiZEW+3gHOjx8/TX0H8tHNiF
Ol2Z6HbkIx0ST6K2XQ7/bzQp578GKNUFMkdbKgv8abuspt3GXctOxneMESLCXczr6qRIQZQWlF6V
oKPU4gsLYjDXO9x8qpevAqSMF/t2JFvtZKag5sg9QyxOyLn/KtWNUj1bn6Xaup82/g4He7NVqee=