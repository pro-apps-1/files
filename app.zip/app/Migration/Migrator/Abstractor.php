<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPseBO43SnLXecSdrOzRMPaHoh5pLiDkoovwuSNZBhj2bbWMxRaks77kqox5xBqm7wUiKWy2R
gWg2DGpHK0jPwqjtatkXssyQ0bhgcTSlMW+lJ+gZa++UdooGw1rhxIG8rgrbVZlPOdW9xa77fPNB
2zRctu88jzHUSCMkRwFZZ4U7nlz21TwRuOlTJyjKuJW7y3L1Fo4UB4pfodw+HzzKnNvXnsThfVhu
Q4OZadH2QGPLy2jmL+s3L97oFIgdQP7gPX1q7nWRo2Rxs85Hakb8U5GQApPh47PLEvWH3IUG5C8z
X6eU/tGeXVclg6hq3fHI2Y73AXJn6ZeSTE1rCskVbz6rrqeQkXcSAyMsGhUjO08OEXb73LUZ0YjZ
CU54pMHMrI3rEM/TMq/k8GQKpdu2TQjBUwp5fxEQ41EIz1E3uzF1LBrPDaOPtxxg/tKNh37R+Tdz
tu6L+ju0ZdBBM+06XPTxI/ViMVensmTotZrpQmR+ChVpvNztmnzZIW0PzaG/ZwKNVWVyt7KUrFJ2
JeLC9OF2YUG/+HZe42pNnZ9xn4bov8w0MO2BjnIxJN6G0iMKC5w79oAmUJP4T5XKo6SnJ22stfpr
tNiderUX7f7P6WHMwiNcYTw0S12P0ojSKsxM1jm17m9uaDktXIpiYrk4zMFzZuFcDaf8h7a1YhiB
Cao1LD8VS437JlRno68ZQEX6JwkX7qQpOKNGEbzlkGJaVdefj0nIaT8msMC03UkfkunrrUt9Loed
/K78zOp2xcyWx568oSMTPp165btglnB9vXgPnOkQrOLO56bD0EWqWieqXZHjvqB5Ry0gfCckludS
OZunjxW1+FC7CtjKjo0mtp/BgpbAzlmOqMlBEpQIIPjWJ5ZRZQ/RpnY6/BOQM9kqI6xcnw2pWjee
6EnZ6NV6OqyKussfj7VukrKwz2nCd/bzOIG86pcT2wHrfEbzJMV5TZjBHzLvvxQ+D/QivfhAaZlE
rY3DlEezCua75YHpUNiQNxI8xeY8ioyoEN5/etl0e0HiwrZbmI9Y9WmKawaJ0HWXGoKXULkpC85X
O/M2pOxfgezoCwreDY03SYoVj3Y7+XTTCqLFVagGqWWE7lJjXd7SV/HwIBPb7TJYJhTLezYu/JE5
dKzjwbhPncRNwgfxQU3SNK8qMZ+OFMkaz6AJR6JF6fDLE7LIXeaY0OOeJZDlBAK6M3SnOrCqjynV
3iR1AvmjIcYW6Q1OBUvDGF8PYWdB+g64gwmsHLSw80CGenmd41qMjfjQ8VT5risSy0s+NvbUr9Ya
CvAcvRJCqIH7fKAZp9YKHcepX7QWvjqoSMaob+VZQaI+npyNn79Ofv7nOzrTR/Uy9lixnRMutjed
wWz4YvC461DumZG+FHu3PiwbljOK+sOhm3eQ6wU4vuNLnBeJk+CdbggaG9R1zilph7snNjNdO7Yf
agjBdsjIj+6bl8z1zjstbObuTymX0y556ttYk0UEeO8CPQrZ+5wJQ+25IJ6L2AEDT5CNTR4rZR1P
XpR/b2QWM9e/03s8jdeQiJvvvPYeWPiNXGgMdW9zDqpJ9zXfkjhEOuu=