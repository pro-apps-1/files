<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrbWAKdG/95khQAyQg5eRwMzT3epda7f9SC2ExQzjMEM5wUg4AOa/7xjU9MhGJujbsuwzd2r
IR/QM4Ql1LnLQvWOb0tyvyhIAnKNiAJjfR6o/ipQ/IQBrMPRNCFutoWxDC+TrwUdM59Sc7XIzn6e
mlXQH0aSq2XbwsC7VgoKMfAx+ScWoYJNCIjY++2c9+OrB8OQiabs91S0xJe0+0DqEK/lVUjlvKg7
nmmjBl4abF1z+jSzVjMesDqzPzoRKGfo0swvsg+9ME/C9FKFr/I8J8bEJI0SR2JJVOCYD2Wgacl+
kAkAGl/Jymkcde/y+0fJO/v69dfH3zMVdygihXFTtymNTZ8h3ELiwsYQw8msnKmUnV3cnZ5/Oy98
pYbLI7fJod/AC1tNjQd0whOS1u4trdh9p0aEc/5W5u9MYGmLwLkA6W99AA8TFqqXAv1k5vixu5o9
mgndPnMwCyWZaEz9WKeu+4JBeQ9DZOel7FX71hTHyM2VWZApn4QCK2/CdoQUpKU80HdllQd72/oh
Yi+1WH41sYOvZSYsrZJ6DhDJiFzCcwYhyHTGFmh2D7K9v8SF6+Mk7E1TJbcXh3LhhE8hfP+7QxC0
5JEe4ngioxn5OCrrEO8rkm3l7rpaTf/hB27zQ1D/3ZKbcJePnryh/NxqBHRoe7SXnCRTSNtYR+h1
nIXhq9fExhf3+BsmqhrjlOFOBIdjJWMIpmsCAnSlKGSiKAni9XyuloGqe+z1MLuLzsOebcX2c8AA
j7Bejg47SRuTLUoS1QghGAdRLAcGTx5n+uAGL1utlCkUOqTOAcRLV7y+SjqdmpZJ7kFVrRWRHcN6
7LQ18UJVHyh/KnzN5WEEMuKvH6NXGn0XWH+1z0Uugik44wnY/3e2baM9sjApRrsCWf+EAsbcEB+v
JJ/+xTIxjIlQdrHvY/VwAiH+Dv6qTYj3uf7iOTFR+q3LCpWQnhuYtfr1ne0p3JbG4xomH/hpi33o
WzG4GyGAtI3/FfNP3Vq6Apl5dM+m9NCk8eO3763jq3delCb+sIbj6ghT1bWnmoNVY2KDyzpDTQAG
1oqXSvw8PEHvWLnE1LAFM85WyITpJV8xs7l0YNMa9zL6UVmonmQKkO1/WSTsuharCYqIXTCo5iHQ
lgMdChDWGh5LUFYSxtAfz99u2mglXwspnLWnrMxkJlrquuLTto94XS2BgT9wXSZPQTFX0RDwri/t
bt1erEwVJoWYeW0F/E/tCdqVnJ5EjvmrH3RS94EAaAj/116lMl8RQQy7EnOJ0qc+McTcJlD7JSeb
++ur7p8hOux6Z2wV8NMhWM/S9WcMlfKrQD570t4BnTLirgczBQO25u//GmXKdaRVFwMHX6kL143R
QVc5oYESeb5798x6ldI1nJFND0Mk4ZTlab834d9zeLbfuz8p89EuucB2OioutFNroJSzS3Lih13D
u2/VvfXL6RJ7nFIbvcdJSVvZ5V9trN5NR4WnBZz2cBeJBUB2K6HINTaip8h4uHNPs1ekAZMe3RKi
5ljxCXS9OQHXEB1uh0ixc1vxcbD9qaNlcDqp1Graxdb2gsZAfC8=