<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrdsZVJJRdRxgZGOrsPSw4zFIFTPrQFb8UTb/aJmK9pziZWdWVSF/mH/zY25teNY5mC3CNMC
wZdJiE5k3StNAmC4LbNMg2SwWI+HNSBSCpDH8QK9Jop858Wfy4QwPN/ISyk47N3WU1NUiNQAzrhm
kzkSBuGWEUDC8+Idd2E3nE+lKl7G7TZXLX+YFgRcGHWVoZ2s3bYp94TioDJXTE98jLyOvaJBP6bu
9ozZsfugykcudX344Yr1UuBajan6Tt3FT6dmWeKC8IEnD8uqrkWOb3xuv1qPQht17YUK43ITJvf5
wxAC0V/dIAMBNua1+Et5EzV5tbzC8CAYHARrurlbhyHk/MiMQMFnXPIR3ZMzNqVjgZyojlpOCMcQ
py8X/yL/t/2nFrJV911TIQfLUgK8TBjuZmsHwpyxUeQmdaLacTnyTvc3NeEnoiUnuDWt5L/HZE8T
QDrRvAQruLSkM0jgUDUGWsccRTW0zLpbjHvJvOYU+lyBmEZ6XG7eTyr9hsvN2CaSJyBmBBgqt5Gv
CtXzAMQXjwuVd8FhgMRR8LscnwibejRkkv6+B5++KLZWazN1GwV66Dbyh9HnyJEcrJALTtbF4wnK
5cuf8yjdgMFMnokB92c/Zt3zFVvB5xDMI4HrPti7Nebq7OCcCVvlA3JoMn3m/wYAd8ouNR0jdldy
U/DScJLAb7CQZic3xYmS/SdpdbeEH5o6kRf2L9dWhjRhRCGumb2ZFwKTQr+n3DbZc5hNWwrxHjsV
oqr5VudN8xyFoYO+J7h3GiNpwTGD+s5m5YDYPFG6FnM/bEQpHDKDdagJ7BomCgVGgIEi1dCvBWy+
r6OCFhlLjNNErEI6RK6Fv1Y+OtBOVcvLijdxoMrWAO9VI3xroA+QWXDIxV4km+EFLyGFLkHjlWOk
mFeciKlusMwzjEUTUJOuV90aHek3eEwohTf38QbHkkEtAgYWa3dtPY2C2RFggKf7jE4npgLiY9c6
6dIZRplLlzxZKslceW92Z4h9xTeZYYs0zx0q2U0dlkUfinNR7Iyfkg9HqJ1CGVQE5iefU+6ZwYA4
NoAMZAVqvUbBXWTtdyXZGR8f6zj4xa0xNZCtcL2Xhp9FmuaM4sNR2/t68dH3My+EhRlGXSwbgrMN
SLar8m6Xo+nrgv2DOhpGIT1RNoYBLv0gUc6KvlJRVFN7ebRLXxzpMrgEVS/uxsBmRzSSdnRSOIn/
h/xCWJEL17YmlVAdpnM4g5Cel+EAUEBPGCWlva5GyaCEtCzNPYw508fVlfycif+IG+DkVSDXt1EZ
ehvv+ZhGv1hPIXdEeloB2qOO8U1hJHTQGNzAeizCKmM2szQ4kM3gfceS3QDfIdTO7r1OwOtTnJca
sQcu9ERaSS2b81qANN+XkVhuoZx6lnaWkL6Tg/CqvoUMarKZoo9GRv3LnB7POhxYlUM1oVrVLYUS
wBG+NbRmJfpgSSFrczPMjzO0psr7IjS60NXEqmw7/3bpY62W3QrOe7R+xXee/tMnP4jvyKTzFzDb
xKspj1DIUit9pCeYura1J5o2cgaSeVeg2olSXjGBz+xPRCcXgRRkcrW=