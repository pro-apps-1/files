<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmSoqGKKeYaguV149l0tswZ3dcMcN9A1QCoVE/DXX039kqsJIGmXeiuRBggSinhdDFFPNaqI
dIcEZoBa1S/7PHQscP00E7oKmYf4HbabhjcQZPAtwEQ5kp13MegoOuxPbomaze7jHm3vprW7CRBB
SazMpwAzXJgJ/94F35I33l01qSW4ssczS7uC0p6VwNkXElgf7zceY14xrjolujSmyB9psgNJzYXx
Dz9nry1gkcKTgIYAsifpLyRysmH5AWabZnFsiI5vvkWs2uhm1h5Ggid4fRfPiceFA+qhrIgodeO9
d2kqQbTCcUMjxox188IDbFWcNaHNhLNUdpZvCpXM/A1burILL1hwr6vlfMp7Q5L9RG6qgXs9bu/m
j97GtoU/L/VvoNU2hhoWLMEJmyZ2B96nSvSeFxB00tGBW4ziukpMNRQnMuKSxOueD5ZMKx0YLyjb
nRFrMkQkBkjny5QjnbmaIzmtDBixLuyEbB1sAwG+kdnMiLwB4ya6OWYUuyAuMWBrwiocuMTjzX3q
KPuApQW5yyiP08g4oeiNfcps2UmUM7QJWSiRHVnFvfto7E6Fr2dOuLbFuTecVoGp+ITJXK9u9XkU
6wtgGUAWmruFCm2oaNxu0kqiQAWfqj5sU6pJ6ArnK/jcLGrV7F+Und9A8BCmTaIX8bXckUPnjAhC
hUi3unGEbr96+mp9xmOWxIixyYETFe15GP7f36onm5CL95PpgEoIIjf8rXainpIZn/rZO15liBzz
ED2iGGunnWMcMyQu5G1lVU+2yEcescMpePmOFMAblcQf+yPFKFVEha3K0+BMUJ0SS4j13V5BPPX2
jqShAVMGyt1GmN8IAWc1M9yWP09n7zioDAyx0YfUJhEs7WIPDGvZ440b0SATCM1zc7fADyleGCJC
swbNlwqbkqbSkm5j/v98Y12V+I8MUfsO+/btrrhPZCX5ZH1THBL4XamHYWTXYa9GiCFKPNQb7m1U
yJ5Si5tkxy5XKpypP3vhqW7AvxoJnUdAtUMRWiIEY2M8/EYI3BF0XA1n2AJUrCLV1Rv8zCGIBc2p
TKJnhYwd5Pc5qUTI4QkCZVf2mcJg6kTvnO7ttAaW438MSE98WVr/gvK13SHUZ7GAMCa4WKnUaB06
w7Gmcm0iXZ1kFWg9SDbVsxys1qkGyZ2HSEcizNXxxHrqeZxCNVC80jgUJMDM4DYJJlxsQ9HcFwEE
Z1hTKGfdaOB+jQh6i4icEdCl9kgGI7j4XBt/ZOkEP2xBkWWrC+cKhsi6vB+F3tnjT7kCc6uXV0zv
lh8WOS+UT3FlTMElQo/MzKptkc5XWbdAtqH+xbL0cW52uw3/vOOFOGQ6tplisIKm3x5NTtYiUDa+
gFG1XkJQ6ONaxGcs7b385kxi7uVnReHDbSCqj2F9pyCJ4sejWDVtIj87DHFKtNCzf9DTQLNxLB+O
XhBZwZ3hid4x2bjZFsNpgLnBeGHvgHsta866xX3xnWwvPhHCfqdAdj9PvBvpVAMdTnpepo3fg4yD
8afUbRc6kMqcu1XXypCwoHyN0kWng97MwOqPUHEE/R16Eh2R0z+cRvnjKTJg6Nog8jnQ8G==