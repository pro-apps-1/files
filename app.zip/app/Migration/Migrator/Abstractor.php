<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmxZ1LaRVVwUuY6GUZlPahlU2hsdEAhc6k2dBEMujtX9tnoFFmKVFQ0zhdZ53VhWZ29EzkKS
63BaRv/NAlgEbbORFsA8mxL7sNX0z8CiUQYhN9dspXAg2M5btcCWHq72zTe6ww9SqDXA4P/rwP7r
XjnW9AnLS9AMPvmRbMMixX9sHyCVV/l3YiuCj3Zvi6zF4id6YhSS350WdsbvpCt3WDG3CRbNM5Xj
zmT2BzyOulyI9kIQq6dDUr7iE6JpMB5Ju8o84CPDG9KZFqh4jKURPiTfl8DxQtQO2HOz0/hC47nS
6BopL//AyMIJrAvb+EcgC0r4SPaw8bAa188MEuH1A6XlNGdDUcFS6VhXKmbTOohIDCU1wM98Z0LQ
6I6u9jh9stOPYSaSnd9Ep0rwWTqK6GPmuJeOWzi0inoFYgIP+LvTfImnGSDTzkLWap+a+yaB/r67
2AdTmsv04Eejv1W+cWFbnCpf80M9YzW3Cwp749QBUv6w2lQhm6tFgQTXXfX9yBM9E4wkcRJlxKYW
xOGDyIbXPlq9z616vJ1ifa7oBIWTcflqB8riWcGV75PHT/EodT26BV9dSco/VU6fj95VpsjjOUfK
w34GygCaVkVziSWmNXmd3z0Yz3DDYnK42CbmuEyFysv1/pQ79bNEBn+0L3gwhvHXXheFjCr55EKH
dKCR3utUCQdEHgyCW6eM59Ft1c1OvOsXA7KfluiBkDrcBBTqdYXRW1+0mHuxVut796aYjAbG6HMS
TxcQEaYPoDTvWvsg+WHMURIw6C13k6e0mKHW5VuNUYFo7lN4qvpXGv46KxBSLcnghntFgGhIfzLO
26RVd3rLHbzqJBm31eG10MEn3mwE0qohdGh5FkVTPcuEJ8Rt9MHfy3YHttV5N/7YJRYj44fnx+IQ
jyJpFr97tk6eof3cbnj8ZcHO0aXpURPvGineW1/gYiwru/UKnj2bYT4ayDIdtaBgtwFqekAqV+R5
CbS+2KXyb1dexXWHBjeHqXLTgqXwujlx4mFcSdeF2kvb7+TCC5WXAGpkug42vBJG99EI+BnLKlfA
SIzaU1WUHDHy/ETS2xuWozsNAoAEf91JRl5B5QgewigxH9//Xhle9jfs145mUboPCpMsSSHpDW6h
2OuIsnUTvRmna6msiNHLNOXO3e8w6YxP2PA2dzg8W5Ny/BoTwh1+4Me/IOiA8HQF/VCVCamTk/aT
+ZNOIkpZAE7IVIWF19ph/ubLd5Gbm+bj2QNfVw7Gn5Xe9nnNeNtERpSEVZDLBQxNndCgQ0W8taKT
Q5pnqXR3IXRwJWV8jeVlL5Wst46P9P/4dIfLirj8ovRJwLxD8ZNiSwVEFVO3XTBpo8KFyTBqa0jr
hUbqw3HrHF2w14PkZMtH9yoLoRlWe9bOGwFFbj+kQpTSC88TDXDE4yFjGn3CdEb7Ir7yw3zraHzg
bbTBNXumRacwffsR17gqOi3kINSTPFiUOVpinGOoSCMEACdBozo56dOhrB4oy50FgAOQSJOINkqx
6XPgLNxYWxUIqWEMSdu2vQOPfK3pqgtKAj8sYPA2+D0gFN2ZGFORZngmwDBYb0==