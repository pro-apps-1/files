<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnXHjYRc3mi9/pAJ8mKSZUEUeFRPXShtmV8FSC92YmQVMAvMTL2fVQ0qYwXjKCraf96yj6yc
8KmiW3+LZOaK1Wfi7bFY6tuqZEPy9eU6yWeJR2d5vNeVvcYjlh3iXlomV2ckER1uAmQQo4TRuGbq
ph8b92ORZ99Md+JNv+5n5VdiCvdewbhd6msdynpr8R7y2iCwKmvDiqYhk9SBeXhIcy3MW6snn6vR
ku3JsS9i2tymkYTgHupKLOE+m/nRWDbNrMa4kVpNQGqzzeZKqb1s7eEL4+PqQIGetzzzZ06Ey+ER
qsYhHLJa33YSlJ9fXe/xFi/gfAws4h2NjMQfJ5SvPrElyChY4emjaVgC2kcBAafXa5GXCTNDt7E1
MHbtQbohwKzdfAgo1JaD2UrvSXNbIhiOOWLxosOK53k5jXDsCIdU786pamj7KxkfbFq8xCwYuXnx
22+uz2rqA568DKkbYz/HkfFj4DkEv5AhhRhjBvy/33l3XS8ZsxiMQX5yjGvDMLNsrNKod90WPBFN
f2saOoaeloVC687j03NTrKpyN4I3KzTPSVW33PcS3gG5525mzu2NTvDI0XLzBv94W9ywA1BKXRIJ
aoHUGYbBfe22650TGNJtMliF4HORpsIMkICXQT1ttK+qiWXSbI1R3aixiltlW0GYFfsWgwxuSCrz
jgDo1rrlXycYK5oNxK4sPyZ1Aa3LHftD/uLmXe1oAk7oVZsiM0pVCqgNMAbBH9YS+cDpxueblX7V
5L0YzzazgwEYp+1EFdA0sooX9IRZFJE3shuzQxA9FyULyw3pyNxPWNmMhZIBfcAROyPkC2P7asQ2
ncoEZZWF82sl9ZP7+G9ASx/12YTXaddnSvPEwWZxqHhMjt5NTfMJ+/AX6bsmKWWU1cgRjtCe6s2u
m5JxSKhMfnsiw1XjCeXc19pqHbLPNFV8Y4CIsUEFqfQcRt/xuPFaNYCsCBy1ff4lavR5c/6rXp/0
OyqHgID0Tujh8t8cTPN250P5T2d/yHQOclMVYS4K2jOTvUbQUKOvU5a8LqX9ff3W3tihOZMUSDsY
bKGxJ/aQ7aN3DdZ4ikL2oQdSL6l3aptyxuoLFzd9Z/lDpiAHOCEkCPfFZKa+24DzRoNZ6rVWMZ5K
i3E6/dtt7GAYC4jIQ2qZ5yYuErL1/RFPv0qeJAmgR/uecnCeQu7mtGFaBL+lsdTeUgJDlt2kztm1
+yNfnL0Cc7uGrSZngdC0b0tk7HQZ3dtNSbQjCXM5L5KPAdjXkzKZ9kaMt9BkhuAscN9nhgFFOW8l
EFeWxO3brZih5FEbm+8b3Rakud03thZH/48zSpKokfjkGvzdHZuDexVQNJ5E8NKMIwcwrpBrB2LW
B1JviDJKS32NjBCzcgmX6qEAqHrjN9oFQTRXNqn6sxGm/ZF6Nizs8tdUvq2kbCch76vXzny47Tok
pUOp9085y/uA5Zu5aLV1LSTadqyIbl3oJGnM21PM4l1GiKXvz4zCcAyrvr3EvUi/vYw5BFxeIqI6
U2FE02WaIybYNe8qaemu3B1bugSv1JiePQ5OgLm75ib1+YiG8osBcIJ+f0GwtcwFk+/8Rmi=