<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvNbR35gUrK7SoVv4jBNS7p4nhO58qlt9e2uT34sDjdqiOSqRHhdiumdWW/fND2RQZDq7Rjh
5igE0sv64fTL+tBbjYNRZ5GB8OGSAekoRCUfCsNFC2lYRGityELFqzXYXr9ReEDJyGW1eB2cAL4w
WHMjJcYAlLeh1XtG62Xed7s9AtRE2nIXhB27NEtP8al9j03xShkNhL2tq6BXh4Oklm69rgCESXNy
mSQ067CAN3KYRgtRg4jv952M+D49xdzVJAg6lg30UZr/oXUPysMTD8bFf0jauwWj4ohbtuB6QOMY
CoeqfUlCv64g2R9bKj2Q0Ki5EiY4gigmrA7lEuJM1JdRfLvuixkYLtO47E25j+1FjAAygjgyMb+C
+TVOpZqu3CNNRq37HC0/W1ZBZQA/OYY1ituYJ1zCXOp5aeutZjbOZXNa/E1h9q4llAVE9OF6V+s4
GHKRqhIonYVHYBZ9KUFHtvZ0esz2DfajMhnW3A/lPXj980KCoz6UbLk8ynH8rcb6LobtzNDpvvJ/
3bdh13tqlOsUBmmW3OUG8TQd30zLyD2zz+aCLgh7IP0vGvvUmP9H6VH6EP3R3c123I9LuZwo62Im
1dumhFmj7P3uEoHca6h7s/RlCxrQ0LKirXNBWLdslA1vUXd/wRxXu58h4De3CKO0koiIYPZpc0/b
zOqx+x2NkEsQRorF66yG1wgSa4gl2jIAyGAipYKZD+2BoT7RIcYEzGRXWVyrLuNhy8LZvuQMig10
fcEb23umjF4OO44I/BcDRaZSkryNwkWLB4yIVmp3jrS94I8FuOomCosT99w2mKb8cZ7rWsnX4TSA
U0GAYqKQvy+djB/k1shKWpIpCmZf+qPOe8ufRyh+M9dagqCIVmVUOySir6or0yHLh8Lsi3R9I3ic
EOlgYIuGaAMzBzaP7pU0Ni5daH3Xn9FhNGxlm7PSEdsTpj1g0RTOyIJ7P//hTuvZYrWZnH/F6jRU
aIKnGI2R2jVH5Tfpedf1dBitSF61sd6tv+SUWRhjINKTN/c3QWXtmym1dQ4mbAgKJTYn1tpGbug0
/ex7lTrnKIBz+2AwxSKqGm5zNUY4I5T/2SGOy0QCqKTHtNuHQ9mZ24rigqxw08lQGAPCCyGixbQD
XCPQACfdBbltOLIPNxq4pBeUIzCbgv7kDA7xPOSJm0JgGAQofMJ+NAB/XZeRsv9K3Lsgx4w/QMu/
5HslU3bWGb3KluH60OZHRSCbEwOsVagYSVp65QUDBcpSykYvKAm5lTaXxW8lsuovIuLvO8gDNIT5
9nJ3cmWa3faHci4o0OuFNSeQfPYdNwH1RddWZWMcPoSSMKb4CyXaJkMmn5EgoYA9H+M9RccmSCAm
GONElMZom6gF9gqDpqtDDv1ZTgmCQhTfPEH3lMgKFV9W8SIQGaUhyb4VewOemzNFbWN3hKfHzINL
oVvkceJQO1PsA1dLgHwRguIZ/sN+NqCQUNatbbG9W4OPD81Fu0qeDKK5kXzFx6q4uTSeNq2E1ABy
BUvwYt3U9pt3Z6+GxrwqfajOMkNct9k2ZOihEN2P/aO8sGUA8POkvUI6X4G2NW2ipjGXE0==