<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPybqcsvMw7z1BxOEJK9m8TRdlIb+WfuE7Qgu+RYtBhzPUdv4m8JV6tRo55jijP/+vKFIDpSd
n5dw1Ox2OHrwX7krhcmqnTi4byEPE2PWloPfX9ZxHiAFLeZOHks4o8J6eezffvS+CephvsgvsACV
GlKtdx9CRH4sre+pCiemesZTyQXAVSt4OghOCLTIxLcIf6zBxnMuXF8P1tHFaAONJ6h8Vx3uhzIx
0ZbHeGcEAQoIQqqj4Fo5tTN+2pYsYVP9MU1S7vQgXq8KtuwtDIuffMsorLnha5jElW7krPQtO+wE
fkX5/qQe5ZfDMRItBjopr6u6Rha6hsaNwFIkq3RNrR+DwxwylqXJgL6ihD3JpfxXGiqwh5NuWelA
TpkkcTqqWcU3JSrUnmyDl6qOB6LQiLgrsGVueSiUNsm5o03vYgDWmct8cTNKsturGW1x1j0g46M2
znTPij8c/tf2enECG/C2BLB2mwNcdLtAI1xmwLkCYnTuh3s7n5nENNlB9S32eIZfyr9bIKvcy2eW
vcMMePwzn7CUJhPJdtfLyGlHkV4wCNBz/yUdzD5bJBgotEYAQOuzRtR4ty9QdHjxiNBFwJtqqVSY
MFN/CBLLNM6luUkY4ZZqh6+n/BL+yGaZ5KR6tepsEXsatovPpnGvARST+bh0w7tw51c406NTC0DU
HR48D5GQX4zvFibtZCzaQi96tOrDI473dFDv1JGj4GpYI44l8P7W7yt/Ju34NE/7pdGI8FTX5Fbe
1WzxiSYbakt9E43hU7cv1AVq6p9UkvwE+t3iNGg4jRqOikTRSgCNxkPTBhAVyHuVhH91pGW6P0dT
a4bdwpP3jTa2f5/YPkqNuKwZyENdWgXBK52TAonQlTM30c3un9zV86oA5m3CjQJ/gORNXd2xr6Yc
0JvY4zFmUoLpq8T4SbtUnS7HhkaHlUmeloCCi5vPQlaGicMmnoCa0W+Xq17dA/43S4r2PMjwVp/4
0XXOzzwECwvat3daDNvxQyXQ0mCAtwo6dqbOXmTgIyIVg+q83Zyi/OJ00jnIyO+Nl/YO17DHEWQ3
484ecelDQE2DMLP8ScntP3fQdm4tacpnsfySeZ7MRsJChIA4bPJV8QjDgNLB8eevY3hJGdw1uz9d
orQ2EYFYiAnuKHRofCbaPZ+EXEc2mnEAVwuhWBpUEqfwgX2vnaEwlzjYBV1WQpEdAPzdXXtyP7Qs
8R3wASryhOXER9UJatSjMFD7+cNcbUnNaTm5NKGvxkY8pJNF8J0E6kKKZMRkzE4FEgeHzuNZtZrP
DUWCbnfh71uH52/gk+EV/HFnhwm/VGT0O9y/0jog6aVTx8kBy0W5IPQOJtvBZ+r7ZpcONCZjxf7k
jj4n9GyC7xM6NxNfi9rgeH6YPygVu9zAtNexy0a2ulP0ZXjhfRolHc1FI3x6o9th4ldUrvW0iL+5
ZgrMCMQZn3JIu7mr9gtuFaVcQ3eBxhMJTTlAg+TidCpXCztxcvYYkCHHBfGKzyEgW7TeQ9Jknap6
YJX/sndmr9rAYNr2wIUkG679Yuiv6SD1SrrRHooEzPt9nsRuufgicMZANO22JvIXI+S+vG==