<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsZKOW/2Y5SXcnRtB6E3QSJbyaiPdL6sZw2ujbG2qJdUAEFRdl35YzvsBayGLjO3Sh+52mbc
/cT4mNu0PbgN6V5aFGGUOXapI72lZikKIiz3/xXx3HVh2EsLCmXx21rfxCPUKxvao2WHe9ingXIh
IKPvyXcft97UTJfE7L8FdlgDoJwphUzy/HTrh4vuWZR4VseteoYB834fHImRERF0dhRGaQv9mlFH
dD0I2JbPb+zzTztIRMBOAhAqSBrYNiLwmDAQcGvBj2YX+IbYrpdhsNBPbRjcFZFWy4uxdXFA3FbZ
hOmJ+q3wgbOwevzGNFuTYWH946fGDiHvfp8MDlLNw44Sxb3OnQiCR8jBKkLs7UUIJtHgihRbj+Ew
IlWDK2JtcfZu/yQZBr+f53K0yjlLBP3/BNlFT+X8+J+c3yiZd8sCgrrCcniHOexKq73EastJ+if+
HtaTPAA9Sqm9WdNszWvZTRU/oRzymeek/mgeJToEhpuF47pZZST6nHGHzOvxVL721lFmMMExhPUj
CrLcZcptz0cTX+LlV3tGM768NAX+WEL0ZQp37MJRl3ZRKRbjfCajCYgblLK5wt5teqdJzsiHy/t8
nBeEUVpz80jSzXVmJh9zSf5oyKUNqanC92w4awi00y0Vitp/0CzJqZFR4L/6kBZDUX9GkBZf26Ti
EwrGW0cg8AwfX97qMQInwBzJLw73tcsUC3a/GPPfGe6rHeMC2dIWr1sxFLOSzW030XQ4WQPmBnz0
k+bVMg0oJKuhqgwYlEZsA5CxFf8r/tI8Mj4Lprr1pfj4ocfXXE5eYwjmcVvJ64/c8aapXMtU8++1
Ms4Euizf403FwESSdb4dEclqLyuI3tt1TVG41Une2bx5cSS7jvw7l1ecUdtDmYXvRHvCq9LbJaku
NHNjUfwAnZfc2LVe4RDGkBDtgVtYlCQ2r5/WRlp+apgNByABDsV1E/YYi8v0tlGSzA4iHBl/KrR5
91xa0GJhM1aayx8fw1pOxMICEAC+l7tQjkuz0OAwZvPqc9U6bq95tf3MhYAE/KVewiAfb7iTM5GI
BCnd7I/O7gZ4ZIFDCTHAvYQvez4UQ+BJCAkm7A3rOZQzjHtabO0IfhXYCnl3TJQqaMOdWjWadW3R
6u8CZAMRPBy73TbBJeWoj9os1Ol2j8PHnHAO8fVtUyCfseVcCTtbKpd4GL0l0X/xcGnURIucQHSj
2gxwrY9KZte+o+9hHUV4MO7et+XSvFPjg4Ch5fUjnwPRMRUMWfIleIcGNs4frltgCHg4hL+EUrcK
zruWNhOJD5AGXnyOZr8x/lhaj91W8oiSnHIAZ16Rzteo//dHHOJGRvrEQgCkPFKMIjdEA/2TRrqG
npdd10wYh72gse1JTi/p+4X6CWuw2YH3J843wxm04IBI16uAiV1VIlpAZKGVu8u1Oy/2ts1yldUN
7M2XwlCjab8Bv8cJOh1B6wvRMiMP6IrQBVDuChPJClgSpcHaG8BAtQtUOMlXaq+Zb+9wBXm9NZNw
/PSJDfDhewQ328tTRYzkrqcHqFX66WaW88oy6Bxl00bqRXdajpFMTdm=