<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/BLlp59YmG651Sg4k0wPwKvWQRg6kjQZETU/PimtPqU6wHnS4DSm7Bvnb6trhFp6CrqjDfR
tT+ja4UWZo9OdnzjHUTIAWR0lVeiBwYWo/5XrH3pfWdOB0ot4xpaZPnBLeo/pjFt+JAdLg1IC/sD
NFTopxPPMyn5mfbPx6fbyUJFDIuCGDZsfm3mLZ7yaeylkGGd4wKujGxAQQ3+diX7i54HmtbsAid6
R4kUcK7/WXm31paU4EtvVEIDDgjALCkwRvZr+2poY3b7mRaD5DgPUrjRXWKKR0uHwrQsESNtmgWU
zxUOTD4RlVRt3aEhXiOAYHwyRGWwinT/8/z6EcwVVVls6JNmwzZGb3+wtGRDT0aLuq784F9JJMkj
BG8ntwu06aDDXG9E8ZudeZ2WxOkzfR1lki0xN/f3xlqoT41lavTWNCWjaIaIuMiFg/ahN3OCPFGd
6rOxkKEWb7vnyPw4Ub+8wemxCVhUArDTHmFNR05oKVaJpw6lfSpUZKNlPQebk11FAao/2zwfrpFs
QDligjp8/c7IQW5W0n9Evztf6hKAP0Gc5015qIqublh57tDABD2rWLqfs9JeGoqOkB/Vs/DII1qm
T7MMj10fvBlfHOLUnlhQecx39bBQ4AlBhNP3X14uGZQyVwr5cj8hcluJE9brp8/ESBkZknFmahyB
wRx3UtaWWLoqwrs+5j0RD1eG8IezbnFoxtJ+KRznaM5X+J5RNqdgAFhzmF/HeQ0BnDE2dOvazml+
ebuPfeGiOQCQyiLqm4vfjqlUAwCdylqxU5zGXhR5D3iDA1y8tPcjvq+0yH+Y9aYF32RTCBWjio1n
XeCBr8aiAEup56BEhEEdPO+LBa6542HacpWzXhRL1pI4GkV8x9iGNlEDFLquFqcB3D0vn9B1/Ubr
T7m4frHTzC8J3F65p6Epap/xZNvCvIkr1y8hQWyUqZGlpFObVkR5AXCX/PVhY3Oq20tirkVVDFJp
6xabr2sOfGShbtyFXOaBJkPfcoSvqAjI7qFhdzmuA+iQYeIYBEDhp6l6s5NlXi28AqSSjLFkcJx+
9zur+P92hO8Mirb9FhbOFYAOypHbsDzoW7WpJtkNhPoVrizVAVNImG8GXEOtiO5xAkguht64Tq+p
85EsuJgPh3kKADM3+IewjouUGN7fWSac6yNmxV45Pt9WOj5CK1pkQQrkHlYIjdVmL4ccIVpb+j1f
cAQ1lVnib6EKa3rEcixzt9jFxjJz91Pl8XkGBJi4QL+JNzKGPs6EYfJi9zUgMRTeyK03uFLe0+fv
l1MyQ7ja/uQ+91ocav7L2mPlNBwgaTEfMXq+JSaHjh8AdIa03cF0ilcxXRTQmi033eeXFqGCm9iX
q12I6oSLVu+DDtv7cZ4/CBkeb+9ruCEx74fD5qdKN62uvwhfvIKK1hoyG4C7nMBKOgUtYCeFZYZd
PaHf0lVIyvzpH3sxlNCPGFfD2RaIw9usA+Bt7Ws5GIlLxN80wr8CJ0jpLPw7aLUSQavKygQuJbHr
qtvHYBYZlegRkKszugdHX2uF77Y93yxMxAmLcJ4h550rUd/vMRIUocHVSRgsUBYftjN3YG==