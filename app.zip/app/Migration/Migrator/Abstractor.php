<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyjvIevVrqwY9hlVhIVETkY/7X7W2v0zCfouMocHkcy/3gJTgCbhR9x8yRVPQn4J6CVaLEXx
4ecPbLux3UOCU7UhRi6jbbZMPGWRQ9GteLw54YYxdDGcf6npbKF1psN1DpPg/6xtmpJKi8TdV2Hd
4VPep8Vlli1n8zH/F/KwBGJx6T+ooMZGHGNiQnnP+3QPJoLaHSMgMS9ZcNQzaUEAaOApY6yG4qdr
yadECHJl14G1IdKRG1gOKAkrcvJO6pxcRoX1AWetD6Fa59t1nE8I/Q3Fmofdqn9z737r2OxB+UPI
Y8fipGaTaw/j4j8JrUv8wsHV/riM4Vn0rTnY6nJvUsHq4epRuAde/O+VtK3fZNkBwXwyGP1yRjzx
yZqluhX9MgrtNPjv4eQQNh8RVmxCH8y9fcufsGlTZlyH7CATIbKzZ//ZlvLnZz2TTih5Nb/HfQS+
cND1HenYSRdHRiWBnfMzkU5z4pU2CSw1uvepQ+vfMVADh453bDWIzaGrMMOMDAtlSyOFtyoc1VKI
QLN3gKcNxDr9L8U+hz1SdH6S77ihkm+t2PLXjrktOKBA/HnB8vcCKNG6WKtb+Scib3j31CrgCJ+3
jrmboHFrh4ZA/5VBxbxWav3+OdkACjxuykjd3PBM1MHdxFqxfiqbnY9eW9KGmM30EaolWkAV8e8u
1eBCOMVGCJBXJpBaKjKgxlgwzLyc9YvJpdvSLXhavHnqtbY630qUHKdvMf/Eyosj0Mg9aATAGkDE
TFQsvfjJPQ/+X0wa5z+NRarp+lhOI9x0nFQAhhuYbvg2PNUMcqi6RV0E4aZP5IZiUa2RLyqHUno/
7MPFiEfUlcb9tPbq7pgS3naRV/PUUOnU4ejI3xqOD+IWC5oC8PK4jVZ8W88t+Z9XjH3/dDcXTS5C
n/nVXWi1vuU6eyaIWeh9tMQHmBbHLtdgQ7/s/FlsvqL5tln5btSXoPHlOGNH10UduFbn2Uv48a3y
TnCn4nVxb+rZKEiC/MboQqOD7QW0iA30WTDBkO5EFits7bjAXaCYZC/tR7AENk3rwmJ/qZJc9vUX
kdCwld+IXOspQvt6aJZSkfC78MkaZyUfL/DFxJC8Y/KKkADc+LLd4+BAdZPC3SMjiUnEFmM72Gew
12vFwhAuWgrtele7MupzGtJHyG7wY96+RBkq3UMKwNLaVECmthwJ24uUywc/0rDYT6XB+lRr93P1
+Iqrts5z1Khnp+9V7a8J00clkH9d8dIieyPNeTUp6KfqSAtwq7VZJyYtPWHypQyXaeajladgPGyP
1eKSnCcmX9RtEzG5EE3NjvoWbCUdFLI1n7pTXZEGZVNI5r46+RcivFaJk8yDv2GXfARv8xYSEvsd
YFrAHlAPWmy37ghPTf8spWU9LYNpRC8WtV03I1bjigTimVXguwc2fL1pQrYlwOmJMEryzc7PzNkM
/vggpwOwsonAq9fpnWA5plBJHoDVAQ5PDpwiSMK7ZKfOJd8UDQPgG/DTwPum5jmWlK9S81EZ8ISi
wEv+zjWudF4bkwvAG08IczX1OYs1T+QiLj9OCtblDtdWtjZVI6ytKmAtjRRZ3XS=