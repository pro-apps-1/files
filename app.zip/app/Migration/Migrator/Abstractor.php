<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsQFEzZzGO0V+4sk+oQqPc17Rd1picM7jRUuZprbIikBJna0zgmQ9EgbSI5UXlfsSJU4XUgl
kOZYfLq4ejI3E8DPDR8lhw/i8eFtPXRTtN51v1gOsa6+TPat7SrmQzE8KgyXyHG1gqFE0fKO3l+q
R0wvNOrVuo3LyTm3ZodKr2EEe5+MRLx1v0XiUitd5GrS//U5vNWIaA5IHQhfwVKSijZjqJggu7Bx
DZ75yq7sZCdFWqWt+aT1PVI+skVwpEKuEGGBSg1YcngZVFhp9aQ/7plPf49kDctByIT4dZ2SmZHs
f8ftG0kSjPzaMVAR65gkgZshYAux9yu29JhpEDzbygyQJkJ/oF87Zy7s4z6dSPqgNuhC6V/T5PRO
EXBtpReOPKbgKrAN8WUD7uPaE9gvKSDj7c5Dy38FmbKfzpI14UwRtSnxElt7ECZzew/Uluf4ncPs
cn5txHFlbceiQ1rX9z8fM7eC3Nv0JAfEsloDkGVkHVEouRlDa1f9bHK1bZ/TN3ffSZ4MLNMndJhc
TV4QAGWe7bDtdvEwRnqdgkIx2s4bY34zrUmtOXbSyLlSeGkF3QsoKkwUXtnlC7P+965epExm2EQv
B0x4/zEMUs3MMA7+Ka/xj5cKTU8l9pMUEQCgtwF4pT30gyI5AICgOlRpftoyqeX498Y7f3zY8wVP
Pu3mN9wmGNgdlMKoW4g8XZGkEuycivnWWqPHrCWFAjYR4XjQIBePrelzqzfT468u7z95t13IAMcl
wfW12HiiHQtaVhJAon2LLgfx1HOV9+JomIHik1BfZHEWCwOLF/NP5qCGzsS8+h0792RSjIIroFt6
UASuf60slx2dPB8qIB1/Iplag+9Cw6NDdz5BVIpJWf5RM4T1mzZuhbaOnfL4y4WOaJgpGgsKZC4I
OTWJUuyi1aTrRVt8PJwdQgBm6cwcsnADtdXjWXmeeZlr9JZPuoDNUBQayoxpiK8XN8A7G9o9Rxfb
4Uw8vUryMdc1nuHf7J8csZLdLohFgK0MDQ6E7O4YDHz7S2LXT+F1VAuwKBoFAraT+wmlJL9py1Vw
DVv9l0ONHfrL3d3b9EECjJD/a3MzMwWCfgdlmRfcmyvVifRYKO1MivyUE+WnDw7syVxu+aoYcZtd
mlvJnbN9dN4JGJwq21tvnu41eGG9ZPUG3KSnWzJYKjY/KBrisZ2l/lcNt/vRTbGSFIcSv7pDnOVc
11FP+4TDW8KKZiKJMpD1YzNUqXJKica++clFSUfoz9MNYz/crKO0GB7LwbgXfKTuDbXGkRYIOhxq
RBU/JWPEdMujutFnBrWrnk8eAxLdBu5PC3UlNCbSloijksv8KupU/VsXBol/WbOhiUD6cI1NQiB1
Po5sZFJIBP2ciXgiIkyOU39Ses2urXoaeaWRAF9fi2YSH6Zvwd9UCdVgbKrbmGlxcAdU7Qzjj/Aq
T2mhELjr/f6piAhrzH4fOtjXyLKJEpBarDA0WG/azGB25UTGosEfo4NJRv+IdJ6DWQc4LNVVzA8e
n7bwnBS7uiK1QiCZG0vz1RrGWNGOCGGQU/TUJF+JvRWrT+MzOf1xJH3UbBeetefkSKSpR3ApEQTj
tzvZ