<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnEWEblX//gVdFnYhtX2QkWf36IWNqQuJOkuyaOXkPpmUIt3R1/3Tt8b8R7+09zDyVWtVEnX
5Q3O16/cm0BqjMltMm4bsHk8DBz2zIfNdWx/PqA3Qev9+S3xUsMB2ruazEflLGErH2v5LlOPyjJx
R4TBL4iEOHj12kGNCbvgk/k0kTLVqCUh18fNjS3PhrxXS6+7gg4qR8qztcs1YJv8AEWSsxPaUlRo
83tFbi/RTZttt7VkCHF6JtO2LOR0tNlSS+SszdiIHdElA4AIKOIlrzpiUtrhbD6TB6KSWCH4daXs
A1W3BViDn47Cnejs5jImDXPG4VJyRRkIlyb5G64125mgUdR+83+ThnX0Bd9x9vLxReDwC9sszE9S
7XqQDyKTkwew/BWfxn7BWnd25RCB89clE+kym9fScWb5fepBsT6VDnW7VxnebZYyc5Eae7/nd3Q8
k82JL6NE84YbXPe99xRDermHWCnXFi7ru+4UIt9RyRxfZKxvOSY5Ky86DqiiHPmDOpBnHe2rqKpM
nzSZFQ8sHvFsYw62+09g8sBhihk5r9T2BBf9PIOKyTyf0HPV/6S/a2GkCuNO9QlsIqgj/hnHWqxe
Wjfs2258kxdpjiHjz3KGbASBrwu4kwenZqwDE0QqbsmOx5l4qdZ/jvLeslb1sAvlP+Z2hoRG2h1W
qZlnvWyX+wqTYd0sljs0LOxGQjhd7ohSz2d3Y0fK3trxpLF+vtUbyfTsg4UmL4E6mCSCGNtRhv+0
B8KBK8Mli8t+CZqdasm2FqXrKyTI+4RjRDvC/HUmpY0Zrbj2CY4xx+fm28O4qTTZoMsEyRMznB1g
YqDe3ZiWA/C1UsXpUQKhELiVmxGYBaJCnaCt7ODOnAUR5nSVpvybC3u04tBoHAQtExxQD3hdAHi/
U6seG+xidYMtLvUtCBoXHu3K7umEomZ1x5lLtYAwIme2MY/ugLmSINWLq4i2sw7CDHRAdWpLxgwN
n2kMAe/Dbk3aLABjFOyfVO2O/OxjtMkD9ZGrTnFGDY73aNrK0J+G7SkqnmsHfIiUlF+2Y+Ce5jdp
KnrV3PIOlojeYHXCvcnLaPer0gpOLJq0AMQLKxVyWrHK2FFOt5ecJFyiBiShG5nAjBkbQP0jqeKi
XrDtgBqR49r/rMMlGvqJYSinVOxRHaYYYC9b8oGx0Fl+FQZHgndu2Nd1g7ON7JKxMXQ1NwKegFkH
36wKf2vSBgNYO1p3hRMm2Uw/Lp95sUr7X0c/QbxCMl2FpZwUzozQV611v5msQ4/pusveNXdWGw0k
dr6XGfugUAX7n4XzpHFCirzNSSoJVR50OcsAnr7UIDrO15BS7B6/CVuZ4MKmXHwIUV8xg89jNOnC
i8W9W+bTarvM9wWBSL5/osw8xmV6VbVfovCBBS7tkCJu5jQrSSzau7DBrocHrydQNM1/K+GgL5fr
X3OJbF4UTo82UoI4IaqJpKdOOyzHHTboM1XyQdE06/T7mEt39LKW65eviP1KZc4Xjq1x9optUXnE
39f2IU7QrnlnUnZ3GGXHPDpvzmb7D6+q6L3oH+ul7vqnTlNfPxmsyhxXoHEc