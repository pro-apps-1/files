<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzVilM+DOmP0I2ueJFkdcnL0pBpSOcL5QSw4TBZe5fcSaspHwMgx6tr32h76i8B2fRdA3TnU
sZ0gfHUjK0Uj9PHn4uWuO184hWLZTYslCdpEnOmsXPx2eG9Lr+x/AjUhWaXV8bIM8ISKMEDsPcbm
N8oOeNX+LKlWneu1cF5+9vDHPL4zB0dERVBjOsbtSvKoc1AzTV5in6RfY56YlhzwjZCCiV5bpkeU
m8IYqxAkO1FQGkJRHBJURieTn0ZZ+UNvyy5cfUlfQHTUxTZemLH3b0prRBs/R6lp8M+8MC61vBJO
bYT8ATqJPNxylvk0Vd1rbFqC/ayw0Jgjb1cW27cKHlT+ei4xOpQHeD5gTkwwCE8OAI25OVLYRG2p
zypsrESaX3WMqeLoZt1Ltl7JWG2USXnav8wXkjfZY1+AWURQmCnfDcl8WveJU70EEiPy8xJsg95H
b+FMbzStlHgDYpeLBXGWjeil3VBgWeVh8n4t7KgJ4LCcH10c/Usy3NJrzVy20wIb1KfHGi+Q5F3+
raRY0+aHInKTpqLdfwCwyGZ1OBEY41MSwjdMlFQgAFkGIaLjolriVn2WHO5WRlszlbQgjwNtB8av
7GqSgCWELMATTx8SJDJzdLXr4tyipC82HZYsTmoNIvvjTKbalUaouSjr5g0p8WtIfShaRdqjMpZ/
ZXkXyLZHbRzanYHhmWuPU+bJ8GDZtzNngBw5VFU2OMw0CB1aUUxRBzg0+XB0ckEp74yJOl5GRO6r
libohe2wyt0VqmA+eXdslT6GLpQw9ggYoXXAg+D4hMIwoLkmORxqJlPSFbIlY+gWzsmDVzjwSJes
sUl6rHsI5j7XzRH48qKO+iXzNfUfH2vkxK1rhPl13Iae3y4m6mT+I4Fma/rcuNBUZmP6EqWaeFlO
9JzwoGEiRWWDnCDb+TLip9U16uWnBMGfGgx73bNO9tw3fS2Pf9BqFXstdIYeNmIteIqYQrZelbou
a1uoJXCjT7fAwIxoE17/CdSoMbwQXwlNGradjQJYac5DQLbt2ZEw+VU/jpghlRUeUHEzXkVLQQvl
S7tUxBh7V94NTRPZ2clKLqbnRB0MGJsZx2N88lD3HyjlRt07L3h6UfM7klmYuIV7fI7Z0qVzuYmU
MlKEHh8erqJa2vXnDxVAcx+kta+57NitZf2loCGOZng4+9I6uIwV9HXxDF/mpxd2Sg+j3GIzduOJ
WetKDHYrOiqbQXIUhHikwsyVgmwzFXkAIDMQedWTYc1P8ot54wRWe+wxXJk3TSLVU3xogmFMP1xs
bsAFK5Rj05cwsJFnlYqzqbBqOPwVslIz96yCMYzVRWn/jTZF0iLc/WCk6nxqOyGzO/vBmSGGFWb/
ih+dxH6/kwP1STPnKus+8xMRVdfMPx6qk1gxWXtbcA54VR4JW1ruI6DiFoWQeip0Ym+pVCDbZc9+
kC9/neVxas1xP5bCoxONcZJO8cmWwMjnq7Opa3csji2aK64zUg0HWhRq7V5T6OKShCQQo2092zhs
07T1eX5vWBKl1ksbcZajRu+46YJqRv1Bfz1VcLOlM+0OBl2Y2IBh69nHFZNi8PUuu3+TiClVU3su
JTsGVm==