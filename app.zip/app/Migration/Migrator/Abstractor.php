<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+X9RQ9q1rQM0OluWSH3gEn8hXEgka2pWA+ujVXIkiCwya6vRhxR/Tq0ym3P+YsHAwCV/iht
sksvBZJV/XjIB42BVCJt/KINGdbl16YO6xe+fw0Q7xuTAc7b86keg90TcsUglltZ3lZCcJ4vlAdD
x+ueiirb6CRVkh1nLOFXiKZLRwrl5vfpqfVRBFwEwBa2iv/dJjoyUDnibgN/KopqYNDlpyzVjcPT
WH/WuyuMMeI0pDi2etXZS20IHuS8D83cspaQ4No6JafnWqg7SusbEtg059PlDNVNWd4CJ1fiIsrX
cj0HAN/Wvg3OsdLuBeLHkl/KdvxyIsNJwFpSsSQkqkNpn3HU+38KvIhX0WXmaL1sjVOgGIxpQ7ft
3y4OmZKz4wr9zraCM6JITk25nRAholJU+C+juoMsxYl729ZTJZIdGXKwZqAuwl9m0IfJO7oZYBZi
c23Mwr9PxHxrCT7+GDhoQfB50G5+jcV6XaS7Ujt3uiY2eNmkEo1p9DUXCblsk5Y9z/oB3+/Nfax6
t0U8QXt+E9pVtTc7eMacH5o9JTxmZ01fV0+fvP4/3Do3x1MWJiiboBFG9svviOr0e6aEJgZqoPPZ
d7oMPGaV61v/EcJqnyKXCjnGxqdEXThuA5IlCZ2enEG1m7NClqN/ShVaypWEVlHZ/p85y6PAllNe
8hjvmbdN2MBzqH4rmoLkDbns7rnCmVPjEyxaN8+LEYLkkOnxr9w/4K3sHYS+kBiPtAC5T5SoWAsX
KBL0yaE341RdIhc9ZpZO3y3gpBUmnpLCJpG/3/IeDF4xJdQ3OZ66CqJXesTe4I4gJKIcLBxwLbS2
3KWG3q7TYUAvzhHXrLRjEXrNbgkzgIdP2szJvz3EHLrM3VZOLBzrADSHVzGIrHG6aRv8+SxI62su
AGruyWHbsPj2+DHmhxH2ZTUDh1FKEwME0EeX9FkekzKZtcNiA4qS6XFRVOHqUjwGvONOVhAi2fCF
3YBVPaLWUTsmAmJaSBl9YuC5+ft9BbJ2pG1ot8L3wh8d4A9D1vMtpIE/kAd/7sF1UQiHGM4NmSOe
W1yZlnmnmwyXRaI1agsOxaJrszSsZB5nTQ9PzC67pws8AN+j/tLyrd9YKuEi+9ppVQYel7e+ZqpK
n3Yukw4Sb7el5/VsRU06DL6tt4+UV9920gTsIKUG3JQUf26ET82HcZXJ8HC+TF6DSNHGvvOY6ncZ
+WLVxlQSwuBaTv0ma6BclyiWUI6d6CIT9VRa32/a43xLxkagJZzfcDfaqsw9NvZNe64eSnG7rIdl
8YX9AjQRWJIFdCF3Hj6c0NkypTcmpzLCB+/jltnqUDa16EdI0oW9W1ba2syuUUJTUws4fTldX29/
O89S5sMUCkT6nQd8T6WX9JzfAeiBNcC7lBTEqYnylHYqaqNAcRmDc8OPSHhwSjd90O7jDvOsiHI6
KZc5ptLiZA3NbNDvC0ZPXMOtPmlzznHag2y8aw7e5Vedf9pEaoTYdP+BFJlfosQ96/wkdLzahR+k
kPqdRMo1q/Q0ckA87McPW7eH1+T30JrAFqAeT34OZrGD+1IOuVwMyCaihocy4hCfuXkD