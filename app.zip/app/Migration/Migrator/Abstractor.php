<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqdnHdFGRxj4hJFJK7Z6QEozWH4BYtj8lAMuwBpJ6zSvMGufVcEG5SEe+LDH7j1LeY7Eym0D
E/mQkd8LA8b71LE2AuH/hP7cMu6be66h2rj8cnIDQxmo+aL45/VCd2o/Zhxro7Pn3louhnn5LtRe
5lkC46OaHgvnQIFMOaF6Je703gZHhk2yzCHhagVR6oYv6LiNvbHsq4H2E6YTAdc57E3GAu6kjXi8
KIspcA/LYqxNk9/84a/RX1j33mTfHkLIABrMTXGh5tW87FW/i0pF3kQEouPZn+Xv8aS+SrmyUVnX
qaeA/syvlxeOi62flRzw5Axq00O1O/T05it9G5C89uf2PUI2Rdt7C6LTcg5GC4xb805d0YEcuHC+
ervTZI4dwr89tgxqc19ZHJQSp75uSHb+Fi1W4NqoWefNGc+D1xW35T2ASz8wXbS+g8PJrBqzGCMM
ym0XEkvAW4a6l8N4oW5ro2tP4V0hfqIVjc0Xt0K13EseXZquNCEXpHhf/4Ei71lJ5fbBj9dzS2f2
MJt9NZeZvp91HKbkOR4u5YvXAuhJoFndvyOL5Z80KNB9yy6BY/S2iH+6uYLFYA/fL9UbzxIpeKsu
NDep+yDO4KQhtCeWenJvqG+AhsQ6mee8KvjzfHLsmmJPIvXpyAp3EbH+f25n7tqc5ZHwu2YgjBse
6mj4HLg/g4DE+iKZ/Kz/DLP5CkrNgkV09dKYKZ5pmvXHR25oonjALEPfMCbi4fKfgKq1gwPO1Zx1
NSWXV1APVL9EC8skTb6kEshqDCDLQhjXSiR1OUOuFb7QHD4/iWi/PbzCDeyTFQbJ17SQfGolKEKS
6WceLoZJWu4SfD/LFubr5qY2zesSwiWs5Pe9gFOEQJ9LTNr0UTviQnbQYTYD8s/6UrJs30LX3V4j
OP3xnZ1rdruasqLDD+h9gQi0khZdPeJUJ2N5VrBJdlOKljJBLJziCC4nyt821rW6UwS/w+CFiapW
BBt3QQQNIFzBWSEJ0ShXG+uHtlNLW6xkTJJGtjJn3fpgHLMcaf6eP0OL0hjfGm9sAS72e8kDyVVP
9s0BZZ5Rq5LpHdjARpjz7QKo/FXzufzMdc0BnNeRBJLIkbnktvJ9HMBmnpUNyIAIP5nswjII5P3d
bV1hwJb6D+L0oaR9v5Vi/10UCj1pHz8I1dg7sN5ahvNWzLqfKRiJ7mvoce6sCrWJhryasbEQ0Rvf
f5K+Ks3ZS7SBOYFD2m2CICgGUBE/ceurG2IP8rYE1hdqZSkwkxuaj1JsJyryk8tWj61ZUticGufa
CuWOb9YrIc50nY0IxGJp+B+y3IN+x1lTjlePPlW5/q2qlSmJjmO5YjvDUBzkE0VNhGjVqdzFqhME
neyCkBymIJMIYKd5sR/y3lc+quc0YYjFXwSSWg9V4wtXPnYbeEW/mu2MIgSiZgeaK5czRrhjtatp
b/lQcbzvhOvoL977+sFFDq+nL2BMnGRBpffKr7cII4fpSJNJYoVzV9eGPDzl0kbN06AWfVA8fmwm
Z4AKm03vCz0ve2VdLkprr7YJ4497nRzOk9OM0VBEhg6HvOnB7/lCDyMdaxtqbuCSOBBFpg1F