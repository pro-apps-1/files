<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxFVZlz1W71py5qT6zndHPpYfIDJMeuaXkUPmWwJqJHWmDb/ySNBvKg20UBADlRBoz4wD+Zz
KGZcEenjcMtM4nkxtHkXZujPA77LyFWCOPbZUaJXlaBEQ5/JUck3zuFWKYJABpVdm2q/iqVQmNLY
KtLw1zspqzLKviRjdHW4bF7z1M6o/EOgMlZ6zH6/ti+L1N8R5ebCe6oGpdpxRlOZxxmZhpRFAzrs
+bF/1xwkkHD4cd6fkXvxtqVsRzPiKEgqwujiAsuJVXenY732XzMz19LBSfcVSHc1WbB2TL91Ee17
cdlGPlzbwVF/D+k1XvWnVcB7BETHbBMlFTtWJCEOf6E07AaUCggN2grYp0Q2E8aBIwLeraXsdBV8
IerdYZvdOdvxiRO4/3OGDQB2Gshv8v78nOens2PH2hb5t8UuE8GO61Cz+urqrfwwFmO0hMCikmqI
KGPz81wCnhfTxg4Xgqy0vU5MWR2T3PnxSRPjAfHggW/qXfxC4PkyptZiIqEgn0bhL3LZIkEaRO2q
b23EQLL1SjQej5GgqprUgsI6LrEzHQ8JXvwp2FofubNh3wqmjLZXpTF+cwB12mweopWYEwe5pigD
UoJcb2a27zdyX4UXfMBnK6q8SOyG8ZNQsjcNhN1ZuLTJ/pxbHn9cT0ecpZ4qEYmu7Xk+2UCNT9a4
dRc93FFh0+jy4r78jvU3lj7MQXQhxg8qBHqQX5cUE58VhnSw9SIIXrtUhV8J4GpNHCu4TDzn71wt
iRFXbALOOeVK9mfkjQO5mJuuLeu25XPHkRobHoyq9hf9OGLwQj0tnsR5/052ffonZJIqw3qwdXkv
4MiBquaebT4uMlgtA4Kjz/Sb1l93M2SN8VXmxD241Wpnc4d+BFU7wjs8Mi1lm8y+Q/iotS+pf+C7
JIf1Ql6znhOnHnrgsVy6Y+0hpwcgYOLUX2vFK/1ldPaZBw5U8Ahu/Cqc750nwcFO8YHkT0oZ6fVy
hhq98bp/GsIOoMntV+OxjXoVsMRxgsm7fqpEWox4PyuxhFU/9UU6KI+xpVNZdtV1wsnEGptr4/O+
dUKh0k/U9XZQA8NcMLYGbk86ybMa4HMPnB3Lphwgxu6EyH7YrDodV0DNzUAJBBZ5Wke0PH+ZT7+H
rWnU/a0fsqB2iw0ZbbJV3VqUin8xu7JonvwebM5G/xTGxsrbB0s3DN7IaHbxq3kpMWXX23jLe0ry
eO4hghFDmCWt+5qAlI13KZ+0hqfPgyAVsK+4Rl9fWP7IAR+b+3se7d6T9UMTooo7KCEk/dJLYbNN
pqAVXHEfgaV+UDngTcCbvDls8augyJzyXrou7Dt5mIJFHZdbE79yJdmKuH5BXvglq4wrrZROf4L6
MD/rjHN3Z0TKgfpIT7Uv6EQ/kdtrCr2+kebz90FE5VaBJL26z2joNKcUdW4HoS+QZYxWoEDBUCgi
nAYNylKhN4r7z9OQ9JSAD9DMTRDmwbLPqQWZzY9t5s9L2+FOdxorvb3G9HT9wjan7UJXCB775f5o
YY+Qog9UEdHL78ErPw+RryfkNY1gFgCXb2sPj9722h9miTXJNYDyjSpL+ZK=