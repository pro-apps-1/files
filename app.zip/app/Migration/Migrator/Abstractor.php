<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmNq5Q0JQEwNwZQ0Wx1//zJfYcgDWJ589u+u5Lsk2rBfYGDO+7n9I4x4n+egL2tbCk0Zyojs
Hr4U9spy1Pxr1dQ7bZgn75lk7uShoeAJzOuGHL0EoOFszsVlGAq7STM1WH8Z8K70/9ws5p0z/UHI
aYvU0iOIqIzQ/NJtxwVqYqjttWT2rV6CMpAJNtKWIvX2e3+dtafGj71XJnw76bt8FXbcGcu1uqjq
ae07fp2K4AJclvr1XMZN6YEimZKXDZuW5gTK8Rv5Gtg/oOGMaUIvJ7aVDczX+LgxcjHdxhyljy69
pxXxYLekDxL4mc+QttLeNckyQ7POVXm3AWoXiyzff3GUq1FJw44DRSEvNNyFiMmkRBeYTDNyLzzr
5w9w07IV+IriCmtA41FfuD+1KKSwEF3qj2/S88y+JrkopDZR+XnPwazmYQrINYTCNozVCMPoHUb5
XkFjOPcXkjUrkwhsP0zHXaBSW5tasSAM6eCMc/OdTJ2cpYPMfPqmYksf4RGECIxDwCFRyNfGKodf
+Br6SCY268aTLkFo//ysVlrPRGoxOM2PG8q53AoxXtisqiEiKjNd+fsfQFRXJciXEIQ00oemQX3e
gE/jxLdW2mHLdkckE1DGd5lolEjGHXYszk86XqujP6zVGpl/EeUycUVIw0t4c63fMCfyNTxv8swh
qhzN+fSz5A4NyMfyEiFNMIAoqvhRTWTo7ZhSU4jO8OiSbE9mUhAri6D7+xwdZtUbcIHn5YHXkQUK
qAWzYJYcsJIyQfcmZskl+/wbiIueUORPPR+0K1knluSLxEJuu2sdbO3XBnqubX/KPYUgcVHolrr4
QXyiMrz+gHMoBDu4kArJWnJZ6aFhrPjYsGKT+Ffd/DIGHIm4IOKalQWMYoPABVjrJz2Muom3crMx
SwVKki/yopzfS30+tEPR0UFBSFX6dynoIe17brE2Pd5OlnCSjyUu2Wx6ZeV5AcRoExsKPBdM5FXX
ta5RJvneC6+Xz0y1e0zen0rZH5nL1bjwWzdBYHQFP9BYpoKnotYA/UCrmV2a94ceb6haurT7hCJA
k73ZBdMOTACZL0Cg7CCBLq8CV1zOte7vrOj3u3adLPL9VeaU1Qx1X18r8yfVaeZTk5gsmhJz0T2v
oIDHlTgGJ6EFanRnp+OGJmlSKku+jyWvgV2Ed/ssqES3zFe6AxbFQFvT5uyhPZbQjs5uqwksA34w
T6Jt7vwTXfX8QQI5+YUlREYYfx33uD2d3vZiUyZcqMe+Q9AE2kPb0nBXpidD9wgI0rM4GWq8K6Qu
IAaWa89CgO2idjKuOiuFVtimTUD8W8r6wG2LVCbJFfVZisajqlD4AlsZAjHYvl/E9eji4fzDA682
JOTuMJtoJ3LWYHJX3E4aGPuCrCqOe/25GOIa4tqRyXzPxFJyOM6jtUf/+thEuDt0K26vWWmvt3fq
nE0v80LIvhzuYhhBvza+x+f4p3q1SRfDXV4M6Yo+rvIuZwfyGpE5Zu8v0AXJ0thmP5AUSHTPwI6j
yHqdf25SAxTS84c1fW7+HTmw3D6WGx8dVaRKQSUpfzm2xnJcXjKLGBGvtHDX