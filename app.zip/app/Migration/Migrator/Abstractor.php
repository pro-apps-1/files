<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqlMapZUZcW/fnG66mvespYYbLBG5DR5xDAK0BhcV2aQjmoFz2SpBY7gs9M4/psAUSi/Y3vp
M5Xno86GcJav+UI/b5yKxPjnJPLD9Rgp/as/+33woGezcuiWAw3p0Bt/gE+nGT3bydYT5uy0h+Dn
VIbU15SpAb1NBy+tKKjOz/xC0DozBKHHRHcMIo1N6I66ve4FtoG3w0/YjZ4jzzaPuS0cINJZKxvT
x6rc8WPEPx8Z7PcG2BRflBwknxtN5gbxhd4fR34PjaQ6z5CMnktgZlZfx5NuQ2Nxcp0dt0H+g919
WfDu35mzh0rAiJ+r4NP3Yx9pK2WznQf3rx42ZqUR89OLZ1dAmCn840wVepPLIsK2X/NLjnasJvIO
JGrBhACD3HcDyZMQ3THJ88qVgTAjTCzIZOQ6hSCrPVy7LG6EVCagYenRTA9dnAcJyOVCGy84HBET
vNLsGbajvv6Q3UCq6nSuQe8huS1LnZbbfLOI4+QvenM+NBlBwkRTL9/ZvOxIa7mEQgQSamoHsX3s
Nk5uiVbze+dD4KTDWDQsmuIjEag7LSUnru/pihcKidPIn/fNiQi8M391CagCyrIT8Rfpu8OCV1W8
spe/4Q/A/Dkaof3SlVv5BrCKlDax/Yy6S2X9aqGDgAv2CDKEQsbu8QgmQF1E/qd4nogRC5rTZxH+
wnOis1T4G1qc4/YbqX+KqU4jo9gYU0bqPHe5+MeCpLq9ZadEGwqaeOtW8cAEr312eQCrpDNUscjR
CBBr1mh0YaEHuNdnT3rfDJdOl2k44+SbKjfmvzOXZgmN4RWERN7QyaY+N9SXHC/JaFopb+TBJRgM
PHc+pO9e5hKISAOQCcemqwVMoLFgSUwzB05vBOX+2fip1ZYDrVYkKcER6oFef2dKasSqThQbFwwc
gSSCmyee80lzwdSt5QCN+6bSYwG/BWQP6qDA3+eYIynwS32ANq7jSu4OAUZKtcgNhJGhrqsUd4TK
4ye82tq3YDtYZV6VpIW4tt5l13D0MmsqSBwuxFH+X2mm9xRS+LO+oJlnFQQfG5TOgl9dzo32Hqlk
znku29tNeQ0VhtSJamDCdDHh1Ime9CQ03lsh1vC2KhxB0VMbZSrAV2gPqO1DrwGRGUUiJVgqkQIT
109IW9V/Tnz8J8bLgTU4o1SQ0zXx6goyHmSzPe9/uKi+jIArJHFbJRfBWx+VCiI5gP0G5PZ280j9
22v7cdyf/wUxhS/3Vo6eugV7Px9neVioMswtD5HFGJiZv3z34SlmaOWD69wBOI5cWg7sVecWGXO8
rC9Yravtj2xn4rZtME2ijmALV6d30b1qYX1+Hd1j5joZ9APL99tuUQRO0lNaZExvoFf8Rf/dQprY
K+1A9hlpocp6WQ3fbkSZ2i0aQY3SC17zXLl+1J2jFXwKvHv7l++JMXU0m8Fq1temyLKnNesZLN9H
VItxjNFWeTTXRNf89fpNs4HLBu+BdWG07gc1y1PsFeCRUZzxWFFRpuIFM+2Yd5d57lBlZP7SAqVb
dP2vxWNtuRRFdT2C+CEQVU7VHjhtyAZxqShh45ccymz1s/5/vgsde2AlfjJZs0==