<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoouobC25CzastfVSF6tmEUtBDxrIEvMIlj7xa6tR82W6WeE9/6vK00MAAeVFYSUdYxBWHWo
0HgGmCPoOo/ilmKj7HtABYWTNEge3+4ZUNVcfpvtjaQ1dFsQlFhqn3WjA+ha91AGTB8oWX2iQYhh
ApfcJNAABeJMBoykDFUx4b+HmTxFcbsMEuLBVNbwLhDVOU+GxRn91JrnzhwLyVkHxW69DenHfUGn
53+Akm9SBRx+bKKTWCLPdN17a91kt1kOAjNCvml6OWAgveppHyBmn30s+U2WLMTXc4yD26b2NX3X
a5ngJ1R/VOjgEh2VSRMgH2Nmazfs6ztveDYdwSEFiH1Y0VT93hCl6AaPwsLTtngAANow4U1WxEwP
wKY9MmJpeY6M0TiJZAYA4m0tiAeraUIKKUkOfVW2SMPgc7ik3484kN/xZFM8+imCp2m9Bkj4LLqn
8G1DDObM2K14mwHtUcOxukfcjvTWnkg3j10MOy3V3cGhqT4t5YEflpINbDC1au5QkeJJk6RviK32
QNyxn/Zx03A58AIwSA8Axh/fOfO/ASnW67/iGYaH4KOxxB4Fhk5DzJBHpn03nP2SmOwKaSDHMQGJ
8Mwd+RRbhB8p0fAACaSYjwiQm2y/OD+TIqIbtnmvici4OVzpUpvu79EwQ+ih1C3X864o5Nm4XQ7i
tXzGXQKUMr9KgoT8qW3Zvi2lSpEp6QKL9uVor4XCrvHuUgsWAIKE/hK5QZC7jnMkCR+Y93VXhJWe
YFDYGt/22Y9M+7rhmplEVFt+xm5faNlfi3PzrtSj6SFCzz/2gqNXbicJCKLXg0eA03BGQW1rMGP7
ri9YYItZIJz/l+bo0cpCEXhA6Di1H3Rse8g/L3fpHnQIIlBiUmlFYkjCjgNwOnHQRxtCpz7Bu0N5
Zru99qz96quKxq0OrpASp58+aGhPD/ycVQdn1PzUw4IzgFVPQ1cWXNmClgtr80bq0A/NMRm4iPYG
ppbqKfml1LLeyaAzZwjeICERDv6jsdnJXOYzvWpZ9zAutZFqVznDTTmnJoEqZiAbR286TxIvSVcx
9NE+cNRsrimvuRpZn0TGFT5US0TSYgQ7tU3cy7UtiuYUAR2jfPuW4IAjAsrceA4GvNCI2F4x8wNe
w6vmLVlCnByPEuQkIgG2FXO3z97t+b9ICONVzKx7Xeh8hq3MqRMpfrZQ+BMZlD91mTqp5/RhnZqH
G/k/+B75J7FUASCRDZ82CMbnUgWuXSXkEmMPLeiRO3DCathjHE29kfWtx44TxoxeH9MeCDb/T6oA
PXo9GIZPBMStuCroAve+UCdyGSZun3esZeE+ZSRU7bkuKoUtKGz2E6+XvKDtp2Xx/F9Em0T73WkC
Pj2KVQA3qRMltd4HmzQ6PcHz6eb9YbsIPwyKOTPSh54rA06cyW5ZWgKEXSrWDO0VoBSpW9wOEt/F
tA//Ku1SWrUy0Jh8If7OhuJbsX9KEnDP+8on0FiKI4DAwKHW6yho5j9DKvSSBVKgGawRYDFevdi2
PSvaAt11RvEwPLnTREWGq6iMFgjJV6KNbZh8SMGd7F+qmis1qW==