<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPojopx4IuZE6wx1QaciCL1wV3DAjUq5W4gwu3nHDHQW+3fhFe66piSbO0HKq+bb25alDR9ia
cVBSr9mbKfr2qQEefXH821eFT9ClPwUiLRGj9lWeD2k43LcQsegabrHJnRqFBiTIXJvteveheuN1
CrI1vkjidv2Ch0YP/k/bLHKKJNzLxJXwTBJiEgLBjs5AeiAJnJbsXBjUHzwBl2Fc+WC4yuDL0XPn
2uGZsiZz10kfpV0tKnIsGHkijUbhEA54etVlXQMm8g4wBvT9zN6ty5LBggfZXkVOz2SdvYymUbpC
uMft0YtabqqA/1dfCphcpbPQXHQ7qPRQ8Z7o9N27JS3C8RzZPFlsT05WDQC/qcqF8FLRBABexfb1
oOf8zPA2lTGDG7lDPZK8qHCsrkIU3TPZwJ4XmlflvLLcNAn/pt8w+kzwoHFLvsM/TmoJ9hsQX4Ns
Ojt+C/k6l9jVmMSe5n5jod5N3oF+/FV7j+jlKfiOYRWJneT5+CyPEgsJC0hG6YytH1Axo+Coki0p
tBpQxSw33EecEfQ43ztNhqe4tdkWVaBM+2fsMlTWuYDlfnxzwkwUnTeiZIR4gepPDUNdbxDJuCO+
I+WuDeM4n5M4mpcpTjXvzZTJUpvYnaveqEbUmWvD0Z5dXZKY17x9d6tLMmGDYrv6wCA6/hG49WLR
Drb0hnpyFnwbXicDifKMIzp6PKPMwnJsToRLaTibbZ2nZA7KUH9ntF0pxY90jYcPwO4NGtovMdYS
+ARF0ZGGcZ6XotK4BXFmwNhueLc3x7VcAExloXbHlXNSYLkRgSH0mZM/aJzG2Vy83sFkHOfr0ZZv
Y+zrYsH6pSdJ9apT3/argX3pOAmungdWe0RMG8YuN6OzHdispi0Uq4CkMSERkIeQk5NnoeC6Y/fC
bOHtwCl9LNGHxJV8xgpp0jUoaFipoetwaUN/RASug/iPkA9VzMktcy6yQWWOs7FufrHQvRPxLYHS
o4TUh2yx5p/LHd1smPPZTkOwbQ5vbf1ZqApHhpXg8SkYAWS48XUNDBHVnDp7H1FeK+y9rHC11NjO
I2oYAGQVGwSVtRItRnT+Xz2Wi8czI/vnp/D8/T2eZ6ldkhyaEgio2IbfgkYPE4zDUGhoMlmDRyS3
HYaom9TnKuu0Xg4fZjZM1PFGsGT6lE9XZCulG3W4zvmKPJ9ELss1AO97dQ+1cVa5DVq1QcmomSyp
R3W9ZQiw/l0rIkplWnpPSCyU3pdUgGIXr/W3PKptxoypkMdj/PFBJ/PQ1NdrnabYjj7TxW7QmNZW
adhL8V4TgJRin1dqN6KSZ167LGYoZP0HtygDl1t6KtZ9Y8DDxfunXk1VbS0NI/iMPAobduLaaqOS
S0vuVUzrU/lExURSiubf4Ul7w3W+RwpenJGst+b98v092xNtCChGwhXAEQXvemlrY3tnQfxRDxZB
iuFK8Xh+5I/t5vmrG/Q6WIxlvZTZRrzWzScPwkWZonzQJSE4qSYquT9PDWqu1juBHh22+IZ+DKPn
YWQU6vKqNtNb9x9Ow3rS69sdHItyhnBQXmm=