<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw4d5RIwkEsxG+M0b/1EcmMLgOndaqa1w8su9iyvLgvNLLVNUbJw56bHiVN9GRUYxPqwy/KC
c8h3P9sUyc9w5JOpPe8i/yzG1SotniHgAQjFHjCqBHJpf7j5iXLozY9rQofD01e6QCMm5ZNm2aLD
2wR7Cox6fGbkiuLST3Z8FphGn1B+acL5UvQ8PEz44ny3PrAOTpcMg6v7abSZ0kMjBVPcNcLP+TNp
yByiY1SWTqzpMLTeGWR9vsQ2Ew5w+gJXkKOZ1wkSve3f/SmM5W9QCEVAiZTb0bmF57vd07huB4hF
gnf4H3Ii4orBaJWLtZsmgCI5CVGmGm8wXWojYRhHpDrjMw9LrOIhhXKnNFkh0ZSLMX6WVUtbcD/9
YGhXnV3kWrxIi5m2f/C5X69MkcQrysdoxgVpakub87uUvvF1yb/jBN9qziyYa2eXCGuuLftRZY94
+yFydHrzSvjMucK7FPRqqJ6GoD1f5BPVe+2Bzy01jGHkFGXDe6PMCOACOT8UUoa6mf85gGQnvR50
LQIwrPNBB/N5iK2+fUqwWjUUHhmZbO0Jx899DgnWOgqcEL5CgaeG2jfMFWrym6nfEyE54B5owLYZ
cZVl4BBGIvSUaBRfm8NV1x3piXX6aMt91FVmcjb1Nx+cUWWNtsPP85LiAkD826YIcGq+mUUhqoJf
GD68hq8QBsqNQUIacFDLFR0VKac0pYwIafqqcQyVtt22MGYcO1n2cXrndfBAotgIgIocUbrWswp3
ceXf3x9FE10atVyNr8CBa2xr2HsU5nTryvmoMITGpMNZACuPY2sH5a9DeD0U5TtrB3Xnnx+NQhBH
QUdzetZvLl+rHLiQurHr1OYDCa0wypvNY3grB5K73adaQm+Jd7xiK88GrLmkl2PwbHs8Usjjldfj
gsopaREkWVdNtHcVQX1l6COO7sd0kivz8k/nBma/cuWSRIKSBxabiSSuKsPDrAy6Q1Zd/mWfBHLK
8gg5OtDjpBJI7EIAsDWwNmlMoc3EooWVIdDWyv+qHFFzCmFaQROnp3jtVmnvOYUxPLg8hmclPv3W
92Vq0u8mDaMy8lzSHG6GDHWYQOJyRm24hrsyOl98nJQVN2+M6uNvW64FfWS85qqAr0XoMSFW0PgB
+x6MQc050zC/6XBw/rdsA7fODnDupnEk0CyEztT3FJ7AQJ/B7PIqUJSCtDEFMZ61Qhqf3kObsILe
7Doo63T1qk5h5I9/NeH3qy0NOqTxt7895dN6RNBiikS3qjBU0AFvvKsHDVqCOqr6v4O5nXmD/n1C
4p+Cc9/kJXtv9GY1BKmcVS6R5znnJgk+fgxYaAs46LW+Wm4x3wrwnmteaB4kfSGKdbZwu77iq416
/nN5lUNg9smVh6BE0JeSL3ATMPSIJ90n3WR3bGL2yZ5Zsn5avub8ckfLIOJOpWwVAB0jYS/SaE1V
z7LkXY5ywuPuYDskjemurGDIDMS5OoM30t2OR3U84HEjWYy9f7fcvbb1YW9JFlUpkTSWzgXEAXEg
wZ3rBHMytzrh6v0JGQkw4sHgdA4a3oDAxIkAKfOH0EjJiUyGbDaA2/lE5t967PnRM3zMik72ZnG=