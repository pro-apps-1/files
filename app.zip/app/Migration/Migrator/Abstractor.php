<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxasMAgSgQ2DMVJDYPg4Z55ZAF0w0mbaMS0KXg5E2IjqM2J7I4OFrfj6ZGXckIhOVj91ruhX
cHOlq/sL7UtNofDsu+OL5vy+8KdIhNQ2t5kvJOZgvcEhzX5pQqq8w+cCrNBswMj8doWgt5xBdUlQ
jhnwRA9yAFLhnDc/uwzUnesxvD7uIUUT4kLzHrgWDrY4+W2Zkdw/4/qc8WXHsuW/mEg8mIBqGK9y
jTm+OeKkxAKaIMqACqtJ0FTO4JU5MaT+i2BHdQwd4stHIYDDfEAKa9Pgpab4pcplPkyhLdctpLh4
SQtXgWDV0kojYjYAlPIF/BrCQf/02Dui5KY9OMC6clskkD/92QybeVf+DDKrtkwJwKmIwZIuVGCT
krLIRdbt+KlTx9og3Sk+RQGTP4XPM+GqOVsvk4iFwaaS/SAH+UTNReH334c3UNmHVZ0jrlUQRMVU
/oIcVUCfq/QSe0a/SG64aZ4uxMMMGFYR0beju3h3D6J5pPtCT5v65KUNWc6/6hxQ3CJqjUDwqQaF
ZbIuwQxiHvSnqUdEmZbQaQO7YHuiJVrfCzbmb0Ha22ZUh2yMGKTl2+2UY/Rnt1oaz4uIP4GuE9Kd
6ISi3F4/Vmm371nJChb6v7AwejjDzyX5820qOn6U8ZyKzCgpl4JKz8C8NBHHIjHFg63mqUpnBVo8
Tvs1jBfakl+cIktSfrvRNl0h9IZ2UPTjGE8spNA+Z+tcd89AO+n5kehfpxVbT/anBp06V0ntbpTS
nY/Oqlprg+nLwFB1JeMladKcibWae21t69fojcD77TVtfrZmHGg/qYxAgrpIYZVOLd66VdLR3AoG
8+PrPa+/cfFSCNw2TI2JmjZLwYOBDv4o+WeCu8qFj/nQw4o0BUkFiqRY/4pJaTJPQpH5gY6SdJHA
yXNvjaA1g7S/DMSlBpviB76O+AXBskv9z3YEAOOpVxyQl0Bfwg7Bu7AgTt+Xsh9gRcXzAZG9ebZ9
ndb8IYaGU+LRzMwuI2ZtFxKj/pbLmS6vbVIjQcuN1YIF2MGf7pGiGHVi12XVvOdKR0IUKFaXfXdP
KT6H4Xro6wnl/IA0qa+e1Jwykq33pIPvmPSe0t16sMm1gc60e9rp9v3FRS4vQvMdBDdZjeDmSy5l
ACR3yF+fMqldlScvlEMK+UavJFvKQGhw0lHUx23SvbVQNOzZ8B720x+iAPDm7koT+puCc/gDlg+m
ZnhNmY7hq6QNiTH3G3wGKVsYvrrXOSINz60xikIHOHkJdUuAFuKMtR7y9qbQeTF3YP3MRENEGvB1
PX+PGihizv7LFR1xFqEf/casRyAIHJNizOlirHdQlcYdDr/iPSAZGI8LAbbO2nwmnurbCtmlngEB
xERrS8mARkg32wnTWFfSzVlqj/pr5hMpQFQRLiQImS7X1KSdgExarkJb9lcWnbB3Mb+eGcV5IVsC
rgTq8UMcbaECr94z7aKhV60HXzUkbY6Nk8T6MkkpInrG1QbSjw4ad9maeo2qM70dwDJfHyKu8LGY
CuFTyHXfFgfIX/eOYIF0A0/ypAT64M2t8cXzrOlB99b+IYteP8aNqZapQz19FZWpz47+rnsfC+o9
/G==