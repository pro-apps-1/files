<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn399xiKXvoyuGkoc0GkDRCKjqJGx3S1/UWPVPYSzbLTLKEySMtQVco8r23JlJQToZ+78ggU
lh90UMGSznHamMP4LVbSwqBBb5GdlkegJAQYbJVAKXH15jBiq9cL2mxowRBIIQMoADLE0LgbWFE5
7d4qRWxD75PRH5fwYrA7WolgzQpNopJPmBoGjyOwAQ7PCtS/wZu/rnjb6eWxuZ3bxY8rZXDLmBx1
YyXxFwVxeKft9tp1jfscSQaQu/YBeqE3VjoV95RsZL3HKx83E6zV6oB3Cgf6QQfcXHo4U70mXXj1
6JCpJ+6/RZvwjYl2MC4MCcSYNR2Cx3DpTdjBeWWlNZHLGokgPJE5fq/SKtO0/kukyGcVpbs1tkV/
YF/AYp6L0Npg6ql10KbK0CT3s7b9TaaWueNtafsZl97NmX8sYSRJn3fdF+LcNgMPY0+hLqoMuFg9
7Ii76fQD47IPO9PUDNrXSPeqCPmS4lJPEjnvOlIFo6EH9XLTax2LPBdeTN5wTOxWO0ac72cnPJqd
ypQu5EyzfSf+911Ub4yTVOo8CFnHgrgszS5hWPUpq5SGyAZTNBmnBq+VN0gkCum1dKdIW6LfMFuR
cDMFH14T4xQQPm827AoWsVChHnrNO0UucZlU/EAtaz+4W+b4/qcSh2Kg0g7nJySngqCT8NDcnicd
h5GuejTDUhF2Bu7fE93AUMZ1xQVM8Nvk+4aObwFJBY5s7REAaLiT28Nm9jUu4/iH/PU1keB+6sg2
5sw4dMdPh7Ur9WPt7XTCchrrVuyiyvXODkS3XaUrGX88FZBlCRxK+wa5XBRiH4VrRjF1M1+moZzt
KTFUWWoaz5VbL+yVocuOkpBzLHYliPFXUoRWUz+Fd5d9QSDs8Q4TmnkzKS9ux3KfQx+O2nZR2uQ2
4YoSpq0ok5wde73/rLE5POEKngRS1qNQH9Yxh0UDyNC7wOihGhTse5I7Lm/rxU9P4znK8frLScPl
clVV288obLd/CgxMeHcuh2jS/N+xFMrCThImwoM3q8MRZNtZ1xejgNXEK3llT1E5Q9gSn+decsWJ
0OwLdGHj8Q2TBTdZkYoWaFjF2hvakPF7KJlsxL6Cql2MeqJX1rYjaaRBTly0RkXCp1yAymvisdYZ
Tzhqz3rX1+LS89mVLx7IbtyjpR4RdIixQ9LYmw2MkXXAkrRXBM8WdH8fdWZKllFq6iyUCMoI0TNy
Ko+hRNM48p22zNrsFzfutdPuck3tdV9j3i3PzmvGhZbwHvA9p0zaCOLjyOgIX+fkaBass3l0ZvZk
n8P3fxBP0A7ar4yBnETN8IH8vkRqovm4vvXsgT6oYKbme67rFs34dznOm/TnNdH/umC+wejr0s+p
c1xy4wANIuE++rbo1u/7203zMyunhdb7oAsTwTwMxw9WnegDhLlYLOTVNsrGfrvh9aXKAas/oS5b
vNBk1jGhbm9Zo6NwZoPCQf4vM32V+dL7yDncPNyhgSMhSCG1HfKu/CwVJEQmVeuFYFHRaAPp3+LS
8dI+nOLi+oMeWg/h+m9XHlUuQPdLm6PWC5IE8ImduE1LevjfVD+zdDncXW==