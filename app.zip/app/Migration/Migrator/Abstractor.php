<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoginY0083iNtMvJ0tWwneHnyyVwTtlHx+XsH6WH89CBxKkrik5O2nAg4zkYyBQMDFO7JtbJ
MJknwJMv/656jROOr/ndnBPENVlPVdPcC1n5p/0kPymJu2i0CswlKZ9/fRHPA1uYCzy2/L3GsdwA
Z+ZclrZc7f2lgc3aG290XIpcX97/LFISMAEe37R1yMImhOn1qLtMZmgC/4MJnJkKVo/D7PqJOQPd
Z69K+4zzMcCKlvNikH3lBYNcTrr3K5GN9pbyJVAnZnHPpE9J5mc4XV/W9lAcQBz2cQkIrLJhEgT5
zoXh9MZGt9PdxKPZb91rd+nqvXucKQnORtKMLKQ/9I8Ih1jVTzACCUt+sdeQFyVL6ye1+hO1p/VV
xaKXsvlN64L/2mpn0hHg3V5DBHuleBREumYriQNR5ODxbyyBV/5tu7f6BMAAsduYoQiQJ8LxHPRd
giyGuu8RYYqYN0VIxrKGksR8CW9nVdomkBJ+lfoUMY5XwZdwEFGdhCwEgBjUw7ebiVkipvg8DkI2
UuGvkF6krP1pk4OmkHQPUyuk6mqbjKs49V6JA1FHOdKT3q9yd/+Kv8faI3zgPIAJSyzT/goT89bw
tdrFIHU4VlSEIKvR7NMpvh3q0vUskwyF9XceduMXpOFK+uupaffUhv3MHatS0fZ8Rhp7wczEJBFp
m75t2RjjpUUgPreSIk7Uyt4ggX4K7qC/88WUTT3CrJkpPMIRhSpQUtzjphZWsFyxTpIXr5M/KOco
bmr/k8G99kxvab7xnUCNWvCq9+yKzVt540cbNzrI+hJJb62AY8ggH9xjsZKqdSduOTYuQQ29odPs
UeqUGUK925DsDdqjao1SRCmDK6UTeLQk0FzwsWps0sVg8EyoovCxR7OcyrHz1046QY1CXjOsKAHI
oRMQf7wUKCJi4hx9jGk1+xdAC1vhV6N/LK2XBSTk94t+KqYFNdLX4XLUMiWHLTkc6ZS/TJYR4kud
TmjSwWusAsh8ArhqCkkLkllBy65CSnXMLUITqTriRQQxmkLT+Cgl5HQ5DuWOVafKWE/g+vG9eP9+
2ExdoDDRlAynTndG2hG+urkVZVuXHRPko/RHLMHR229xpdt60KBb+T0RpwOI5ANN7jeXaeFzIIA2
XSoJOtGVQA6Okp89GNAVI0HdzoqP5QL4R5xX2pjVa39eRw/stmH0xkugpiSOzaIgGovOP7n6qrzW
5zMRj2XBgdHX5zsD57JR7Uj7fFGK1ZXFO1oH8EG6GGao4ujYGUZhvNKCnx562gaIKc8VDz641TvT
zyO6z8Mp+iZwWty335qTXV3bSjpURi0WOYxSuvfgDGh/eFFSIGtLMy3CRN7Q201YF/uUDNCWlpGQ
lNoi87FSC1ro2sFu5LCJMcWke/PlpB3nTCFEpXw7nrnotm0om5YZ1evCGD9O7sonwR+NgIhoTKqv
O0A+ez69nPkCjKHomEERaq1SG6OB7M/SA3TULYTx8UxK7TC4LvAhQDPZlOr+HohRxX8aUKGgwsm0
NLR1yKeFUloA728cfKd0/C+IlWhFmD0IbCYU7ZGGkq+vBywwo0==