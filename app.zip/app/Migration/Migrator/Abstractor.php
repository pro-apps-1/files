<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnL6ge7s7Y+sZuG/eZIvVv7uPpOzbO0w09YuI+A9n5eA0E0QP7OzosB4HWpG1SlO8M2yaf8J
w51jYblBcZQse/dvTO5mfj7+XviEgKInGTOStgwiQk2msYMkPM7ZxHMK53VOaD5TtMc+OaFpA9km
Gu+fwr3CWqWTZ0fN/GhEGyXc9OCD4GyS3eOGsAYJdySIeVXUvTnEWNLQGRoNF/pAeGl4mxLZoljc
Qj6b49gTu9jJHL/z3V5H2AHtvSIqPWxEgfKSyLvyD5SgexbHR420sM8EOf9fcq88jRllvWr4tEq3
MYe/Naprb5ioJPcT+OzKw6SrHO47d7XHD7vG/bma+i1haFK3GvmhfIqscMWGlwCPjHv4YGbP4rcC
RAQIblv6csPjTSEaeZuTGKA2BJHMd7FXUkJ3NTuxwM7sn9WZm+CUtloVytKNgG5E6ZxfzGCDxEOV
s20aytr32wkpuqwLnIY87mc7GHLOTAbIfPe3Xl6kMVXjhB406gN+an+l3S3n2TDuXg/bljJeRg4B
5Ky3HtRqz+S50rphtY1V38o/31DGQeLkLS4agUepp/EMfjWEVD25J/hiKDUe70+kwLJzOcNsb3ZJ
mwmHqsIWnMe1Tnz+CleUUOD2vcZ2W8X+gl8440S5SkLA0E9BTa55dK+ctkidVUxJHKLCdxIS3Oom
BLDQ88N7AcJfoo5ELai/kERCVAIpB3GUnuCRu2zbd+BeUbNP41rn4NHfiqTfOsUanW2pWSfvkVNK
dwiI7xewCbBxJ+wu9+nnuoaMViTNjTTJQ93J93RujFMZ90OFVxEMipzhEPDhocwrsg2hGYaZCtC8
mF3vgXs0OL9tvI5vAfD/iNEmVkrwqXRS6B4iamimH/Z+NaJUPx0szpg9gFrg+TOJvKUuqgrkSziW
RCzFqYHtwIACeLtwDeQrTywg/L8AZj4NKLajsj0lr+1Qy7gh6dW9h/M61CzzGJFB1FYv5WHhvSeZ
O8oDN/XIBToEUJ6QQV/MQ6lAWfhVGlZk04acF+oSueNnjbiM3eS9DpWctcDY/9dYjCmaKXlHxxxv
UNIMf4UWyb59Z5oOVEBmuLy8f1wrCM9rukZ2TgJzzluhO7vFSKl35OIQ1L1Qan3xhJ3EwWsBzImN
gU9QJyzF86MGKipoUBHfQki+X9domU5Xv5kdCdd8UTksZr/kRn40ooiSjvwoXwa4woVN4lvW7Of5
COwxiveEN7kzzCaFG535PHiKFclrnftSsGl1zGHbPgntYdrDNj+cssz7A7D3/kaJbjEA5H54OUl/
TJCWSDJBmrxWBongwl9zYtapBoiHqAgVM61qYr1vADwPd3SvwQjN5XC3DK5WbIKWA0BaF+NHTB/m
NHL7B1b0Bn/1L2K3NzrG2U/vCs0MZc+zn7j72TgwOi8Z2M+av/0JWyDlWbxt8ggFoju8gCM2KzhX
rVuK0zDl0djzAihObyER6FXi4MAp5VCj9mVa+zSCyougIvXIxovk3ChQ+TcGYYQtJpcOsOYlS+r8
FR4bniwUdpLRBKIEmJaBNEGj1TdB1pTgrtlKZVAUny3YH0cjWz5kE2PCCWnRtYcLlycg0scPaQ6P
Dj2qxE5RjW==