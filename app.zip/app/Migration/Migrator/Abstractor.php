<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxNTvlcFSjl+LXzpsfJ7p3LV3DCU3qPcZEqxpP6dTz63ZEibMKhSkFtCGfsH+AsN0OEb+qSs
fZbbk2bTgFttCh3No0m89KAJ5SmpcD1j5Xacd7Ca2FE0VFKp3oKFLh1AyGn968XrPoVGkiKnHXWJ
1cAlzNZCiYC2uKb2OT0Qc2ATnzphmbNUBNCoDM+NGjFEhizhWnKAzwGbN/bliYN4vpOJAP2dnYjF
X6/K1Gap7orvpiJmx7UMTMxtnPPKoNttH50n6gIuw5Uteh406+EjATiE/PEhQ7dxQYNVRKcfI0GO
VeOA35LoXmZ5cowZ8zIYDO83PTy9U60oJRIYZ6KIUJH+q0H9yRQ3K7lySB6YeMvdJNrUULWRlZfd
5V5vV7FFDS7NkbqNKVKaJddEYy/Zrf2uUVuxJKNMSS4sZCvIeJwwBkv9eROju84bPueVDBkP0weT
Q3G9zZiXPpLVDHjzsEvsQ5Q+dm155zTTZ7o5VYhDCC/fI/G8SaYtoP8opVjxK+2FUS4xLyE0Fcw8
bsjSUyOkxFbs8cSssdrSaCYY9zfGhAy+ek9Pg2qox4Mv523eR8sdHcQNn1kuX15YASXzGRGhmT30
QUrblk1DQt4P+nMqljMk1YpXfTCYV0oa7TLRai9i1xx+ANX0+V1o3dIk9JBMHzti9dTJy+oAaaSg
y49rBp6rNy0XykGBGe87RnZFDG0pf6ysZGppGQfjfnnrNW4RNPnR//+op7UpXCUJAXGBP/GpSx0k
zbPeNrsnpTVJHq+JxZ/ZU7LJGBC5s6uMZIQCqFJpyA3YkiHWdTegnh4PSx69cgN3JxV96H5py+Is
7uEXY2rHJZ0p+F2ZvCd46nzF7qu+j8SYPvVW37CxIDY5g6U7ADPh47Vv7h3P6ZdI2teNZur20yUf
uiE0PUcKd+0riEMCilvKwrDGYomgxv37Gub4+T/qCQDg0HlzdcAO3cUdWoMT1D6CPdjLV509vw2V
0oqGemolxAMVtO83QInCWEvlZatJZPOx3uDc91gOxw63Ch6jjf1mqRRlBqhmwpAuxbGHiRwiq16R
ah4HaFHWAUGrMYLFwpqQ0y0ST7yZwnl/YNCoNsZ0Z3tBhup68WNF5sLWWu81QwpcSNwZLRDobk88
lptB+Pv1n9t9NQw4Nvvo6415FfoTOfOFGQAXxb4AUcS/VxGmvYkBUQsUXJ86u/7r15RS2WxS5JL6
1E9IrzJhyU7RV8Y675KXp3d+5XG10sgMX0Vo+hBdegBb0NVQLVgQjbgFdmHioDKmow9D/DskgtJL
E0wl20rZrCvszxsfyc+KyvNUAXkvxkFxfSAE1cU5rjfOmi7tcIq0tA7DiLAUVTfgAQs/tGyWDVRq
zRZfkkeNl9GP8ez2Vxs4NZHjfhuL0QZ12Ta0MthYvFQDPeRG/i7p58922Amph0q3cDHZI65iSamO
uC8NcejEyfdQDF2PI30eVlOlGT6UydgPxdj7qDNvoPX24Yqxzx6cG3K4UCAz9ifCDO0JvXeW1GlB
U42uopDxAj0aldnXzPSg/53NfKYhBG3QwjoSipUhf59qXMA3/rJLg89MtXw0QoZ/EoIkixt5uHRb
