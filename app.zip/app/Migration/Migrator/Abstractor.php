<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxhEYdHOXWzx9GmVLxm2uhk4naaIu3FwlwUuOMsdcLSoWF0tNbAtGIr/CNWbmvUHtlsHOKWc
p8Sord6BC7zIhey8MR0/GF8C5sJg5Jl09VAQPNY0Q1RbMrovVdB9VPH4YCdMUOaNIVZeNynV7tED
I5DB+l7R2RGGhBx0nNN5nekrxRC2/aH3qk9GZL319Tz9rNxjOh8Pck4vNu3H5jUZFht5NtbVGM4k
oRXI8tlHqNv+012tzKCMx36+v7Yk6BvspM41SkkF2qtch+LXWRBBi0u7RgffqyNsePSfWHeEmlIV
HsXQM6EIYGDDWDi+CJ6qA+fJcOqRrX39ZPVHNAHNbFnPkmDEodWF4GXIs/WY0pMgm3VkHf8vDj6G
dWWu6D3aiNxaUil7NeMKaUa0HbVIKg3Ty0CvMSFQmDvyqPIQtW8PNY+R79ja/h/sIgUseAb2pVGZ
RPX75grwDu9OKob/Eqa3fhnIkfmwAyUfU0vAjPgeitP7+v44SCwUZMp3viGbhvbStwelcvC7KcA3
HCJKYmsDGiQRiURLhezvAd03vNxCeiLR+CgO+exYw23I97G7aCpaflMY2By4Ewqu7KZnGR3BdOhr
nnzJKcFSLFBIrFE2pdL8StLk9JubtaTkR8ioCtxHBSgeEu8Bx6ZDV6GZ7/l5KcIIwkvUZPRrn8Gj
8LcKXSma/71jp45hE3HonzzkBm64oYi9xEm7AyKs5TnMYuD+EojUDt09+AFL3x27y8VgsUw1Onf8
30u5ufh0HNr6dzVkVQBcTXUfi67+zSAUamh/YCrqsbA088KWKfvVS04Ua7nObE//G2ukkgEi1JT5
WGrrrXLU4/2D9aG0nAhSKmYpEAvCQhkVuKFy65jIhQW9hWBxqmG8ofoW+0AeB9jHheIdpLhp7cmA
2KO4H9tk6aOu2QWfOxGxHmE16UB44S36Lxf5lHl8JNKnCq0b8nmCFRGl2R6iU1+ZaIeXLpy4LcHL
ztUFkkNME10B8f+RCpwd+/p8VgyGRKe8kzlyLnoL2yBykum5mBoHiOnp0sHOn45stCN+mlIt5/Ik
L9zIQbm0eRtyxBu6up3q33XVjpEANE2wp7huD8ILexqV7/SSFsKJYqNL/RzpiUZu58VqlIHgU7II
gxzkcZYYzFMc8ed65zGkVY+U6yhc0pGe0bE6j3+lC+cGEzSvUUjVeFMtjHJPHM12DGzme0X5aELi
8MRKBBAe/8zzW79ejRvCglXIrJGn6qkutI2067niCKtX8w84VWsDWuk8onr3IqamsryhP0cAIPrJ
IP/Cr802stoz0dhseYsYWZsKuz7hNNRIkBLh3IvSJI1EnUR80VJcPv5aY0UNtvgDptEkK/eCP3gg
mwfS6FUuy/NekTrEjW0zIeWFoFz4MWD4QroPiq+zXonvkz1RS/9G9hODLLu6pY1P24erWQc5AQmn
TeZa0RKxBizEn3zd/oQhzBHmgmQ2SSK0aK6KZWOUVQ96SWcxBMzZ1fZAE+5uBPx6Q5+B06jWMvH/
jaGSJdOedj3upLQOr/OqSjjyMMgaQfnh+xWTMowEZ2onXc/kEpNvNzgBP7ZbFX25vtYU0LR+pros
yjVJcG==