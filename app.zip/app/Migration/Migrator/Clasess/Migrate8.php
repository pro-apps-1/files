<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyrl7dFbwE94yBQBK3FJKzc8PbTd+CYdySuCm/lObyqAUl8mD6fHYAli6BhpklQIHKWKREAC
FX2PxZcQccNI/n5uBgXrNUTJ4jHY8lVq9074U9ZxG0FeGkwySlSVYV44lwRputqxMg27QG2Nk/I9
Kj74e+6intFc5bQZ+WvLibLcNjjjCA5aURFJkwc5wI8zQKinRLqXsH3w9T8H5trsNRmwrubKzFku
HviY2K5AVdIYOB2zIMOzlUXwaxm4Q51yPhoioH+w5Id7ys/xh1blMYJasqKeRws4GoW6PNVZnv/i
8pvJBj1RtjRF9dTBEGg4IdJB7VZBccW5OfpRZXtT75fos4UMEzYedBG0Cm4mLn0Aiadt36/vXe1M
CKHDQOJsDPo8PCVaDHz8w1bph79lc+ElW35h2q74RkQaX/8J6sE6EdMNOsV2CQYU/9UYBzN94AhE
xyfNR2RvkDEmXbDnwPg7IZ4uStDmGkqabegcU+pCQgKmzXhrhtA0KnxFR0jU6s5aG2Zi8pCNOcJn
rQdtgph560IfFHJxLXJ9FUUH0NApv5i0OOLz+KRAE+UjrCqokqVC0Te0ZgzhBjHuvV4D/QY3+SnP
fFipdlIcT/k5try/RM7KTjZ98D34DCgVvISux7IEKX+6P/eCJVp89555C0kOGAIgjxM1Qy77DmJc
/fPmI6b/X7VqSyEh2deO7fLifOnKkG7mmdtcuxql7Akhygnapuy3E2wCfk764ZF7Rlmvs8+Sf8QJ
ZFSBAYbK4fMY9o9r/0BSwbARJVHZs3/U2EyFz1C4g2uKz5rTPiukYw+KhKBjt8l558OrtNFTq1Lz
ZN8kCybNf6PUTxcCXuP1bBgNyCw87HEA/Ku6GnpmvlYQH0/SDlrwyoaIukgfDzlkV2H58KcrNNwP
sJAfe1zIabI/+nJzv3Wh/03M+26bX4//vk3spc+ePNpPBKniuAUs7wJEKSS203IXw9d6nQ51fLI1
+LChNQsW9aPN5DS+E5ebGqYeOUoNSdgddS4RbOAIH9w7xokSdB0fIAgcQ9V/pqmWusMb4vgSSe9V
D/8V2J/BCrxdQYw8cQ9nCMWTpTtcjT0snBXMCxWmoRctgBowkTcMwVXeQM5DvQxQIsRRfOeoCsI7
J8Y8NWwbO/VqWXRb/Dehpk+JsTH6n2+APexKam+tnJ08mbKRmGGOeZrALp+4GTCzRxPetOh6rS76
bSzDscZZbLUSC9Z49BUeakePLWFp9RlZS5Zx6WznGAGsuHAElbcMYT4+cN+vccx9xTx8jjfK4cty
dHE1TaJ0ZBs09b9z2GkX5jhWzCPSXmhxQO4vcivoc3wlPzU1z967rJPmNL+8ELO5P7vowEX6sQXW
EDABpGOBZWmbho35jU+ioBkNWWckzTS7cnlPyH5waUfZnoARSpGdNTqEWjK5Xsw1gzxIYnm0LO+h
7cGKDrJwuArsd0qtSw46cH4Y/ewMSdCpDIsSiT2olikhFvU7YwxBr7hdwGF46oubJAYMN0L0BfdE
o2gVH024IGw0iNzywumVhOuF8j6UYzERqgSmKpZ0SsitlW0obi/QxMLqKSQMT77eXqmm4IGzZAcA
xgwSjEa9Q4p+9FhbVPwhD8WVASRMhO0zEK29HpU1hw0cqcmIq0fdqz5WRehLfZZFvTyPQo6zLGkZ
Hv/9YZv/a4tw0ZAdW7GLoTwljBpeZYTQ/rANKw8bh6qbj3Bao2UN44zX7bhirs0JA9+WdhJBBJ8F
U2+q2LD8NAuwVBeZTF5FeUPIyrW/Une+pIu8sXovVqpZBew5THAvQDQhl3RCqcfFEj/0KZNLvhS1
A6HKq6I4IYm5oQ77WGipraGZs1wMeXTxQ0NFGEGnJXZlcLq3bIlYImoSS52FawB/lX3VTnNzQZBA
kpHp6dF5mcHBRaSLBx9T78OGXr5GM21wNQNeBh5dPFGDOYZojHGGA5XsoAJt3i4zl+8VMW5fBfj9
jqV38n+8QQGiEjuCByDC79Qd57oJUJQgAo6xM8KnJP6Mak/6JVcw/EqjWYusOyBC2sVEFoB/2p+z
d26wfpeFsjSY7aM1AB7yb/lgoifyX5rYgsSwTNZ11aoq9RERXihjylo6hbWWC62AOnkW/Kg9pv/e
eJvj7pj/ql2x9Bp0eZtfB8RMUqrTxa8AU3eBN+qPa32UwaRRjoZO7ZvVzri3GqIVBHvzBLwoS+N1
bW4KBi9hicTTtXNSmIkEDyAaB5I1J/kYN3CPy+qXst3uTrdiqjCZ7b4jXk/wPxcsvBBUK5hIDBYN
ovAzBcDQzPR9RDWj950WIvAMZCRCcDTKc7TIZfV/nPda7Pg3ghaIpY2HC9ZN5IMdlvGw6iW+CwTy
3YBZYKJoZJWzRiJJnFLQ/NSHr6Z4YrqS0nlCJaaQZoxgAd+CIG1tYXCoWrcRGaXjpBoSpng3EdzE
2ipCArM9m5KiHiRTASGbbEKbaG+KjFMoljw1ZEPmc+W7+f0cCicWpadWZ2RdW0ka6q5fkCJuylC7
oWuHd9w6HtArsdLC4G1cPLYTFNTbdxy+AgZdhLoO2iTnXCKm5bK2D+apuCiI921B7CAz2edRq2Kq
pO8EIkhNWhbm8vuWV6a7ezoMtQu90Wcmghn5rZOIUXf6PwYKNG1tk3ZMfBoMH1xoYyZZIR5jfV12
46jMZgIbGvwmdoB0tVHVixXmZ4sBoXeebQxk4mAJbT+pODNPSoXCAryEa0AhxeXKKG2r4ozs8Bvo
LfPRhWb7/tmzb/XAlqa6eXIZy/ScBObFgyWcgmo3Kw2DsMLo0zF4RVsQHJegkwr24E7K1l6JjqQO
4SbaS88BurCQr/P6We4usMqkm2VB+L7s3XskDyrEQhQjI4DNYFtVseK/asn0Ol/PoUCnYPS1ZrLY
5cltHflZfLtTpsRetJV6HO5qcd9unW0XNpIbm6JfKu11dK5jATvqxY//zEyJLJ3fOtsADoaSIvrY
r8ha8MIAnmsxybrJecY6+jY8VeqPR07NQXHL/CMhYcds8mmsRJ1AKi3tXF7/z8MoxAhHj7pVah3Z
3q61pop1OymhXQtLh493j1dFu2kMxK+Sehy5xKQUcOGJyNQ1tkw1CXsNDw1AtnOqvReid6iUxYN7
nNU0ChHotaSJQ4LxjADAaIvf0879fvyITScPWEJuTqTUucBlpy7nGUj0I8ZjPvadDHSeHinrpmRy
VLnB1lGcYhylSdq+5BRmoXej28fVLwmTvEInGTkQbLvVaJXEcXfcn+/lwkpU9Lc0vWahbb0CC107
2nyKsq5k5dtq+cZRH6cPrtpV38kAYgLMd4pCgQYbAaxSJJr/6XbP8958heDuWemG2aptrUzpennz
jQBmcl/m6ChwAnMWJYWPFcS/8/vIlnw95rU4Mg1K1aWfk69pMuTTS26lG8R+1woyzgXwJsVnhqhY
H8je3Ns6ucX0otpNClzxPA9afAxp3PLNzc3Enc3XXUQdcRH167hw/eCT9XNMJ8s9hZ61bwJGYtFk
72PoPruz7ZYSjAkUg8jtqaWTfK1VTk+cypFY7hSPXVHhv3GhXBxwQWQuyes8daMKpd5JrIhTV+i8
Xtzg5sdXDNGJfuXJ6cmqNVQbfoSRuEIDhxzLy7o/xGREVs9Ni5EfCFM/JwX1od1h2wOjwdbrTZk4
vOeTzwqbXYEhnwik4NWvVB5IhFpr4RHggZWVIOvNvh1KJjSz77EewxT+XK0rWl5adCtJPt3lnUX4
8CKmeBiTCufUuGP0Hs40bIp/QZ9TKQ4Gyz8gVrVZ1otTAG4+XmDkQaej6mV1na/5EaU0mXDnfOs6
hiFZR4rZx85K64K9weq1CUDbEwtwydko1fYuKabvSko+Uai05oJCZUCR7kic05pcKRA0DAhLDfaE
PA1ZYgq01dh0UW7mZ0lCc8aToEvvQepVizET0kTMDuibGVn1v8WjJLMW4qQbWG5vW4iEvlq2mglI
QTagm99pnr5eHoRhpg7IIsIGgTHa5wP8fZcykIoEZWQ/oLyXMY5P8A/9Zd+mDUwZg7lH1/JU3Glk
62RApRyxIzOJcyIRUsaZPzQ5e8JkWBtVWoC2XP9hKOTD6zNYsORZFkVTbIgJxgGXLyh6FOSLAlOb
KevqB6EIpIdbqhi9fmG+va8sW5Y/2TKg6efifwResvb9eA5wpVGjUYxQ00FWCjstBisw22l+WwqJ
WNcg7nYNWvYZA/R5pwcFg/6ck1O=