<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvWWduqcmMEYFyqAhhYo8CVIzWI6oTDJ4eMuE8jDgpMIBnGHE9MhjdM2AtpqeRcjoT4OcgE9
87tnrqxztmVtPC3/OR8Dw+rHjSY2yZ8qX6O8R6VqdnZCprhoYff1SPRMOETE/BxttSx/52Za1WeY
sQDsUuHmr5CwRC+7rdYOUMlaXfngO4utjo3XcoIZVBXZPgs59zVjDbC/gCYY7Hk/bM3ZKt6d2gGl
l9CtaeyIwA/P3qimZudGQ6k33YutN4c7GKI3CEF1x2Mp38X0OBGOBrINoQ5gWa/ocvihRss7vV51
htnzuiMPWrBNNhCV9HqxT0PYS0dwGNnrN3ChqefY9pWouzScEitIJ7bB4tLnN5CaAbup6S9Shdud
5GBZCvoy/0aBgU0nP1P5C+l3YklzlqwvkIye5ZK7RDpZsiD0hVnYVSbmgEhEZ34M548mvhogmEqN
OYvBtbMLksBtKd5UYArCNjA1W78YBDOhMFccGAsUuF/fpo1Y6K70PwXQNZTf+LebwgNMsmvVxIs+
lRcE924CW1+7YVOW7rPOuQD3Ic+ZX9sBow0ltFlEi3c0u1FE6SpEIS3fMGlqXB4DV7MvC6qcpeVo
aaUTBNyS2gRBNPgZDzyq3GK8Y0g6Yo/pH2rioShH6RniHqWvEE+8bz6eU3cRugaq/hkQd6GIESdj
wWmnsU3tvFsbIDgJBBdUCR0/bSKkJa+0886MlO6J/gadyeI1YEbLXrIvW98vwlzsLies23NX9zgA
jhvTpM20lz8xunjX18tbK/QwPHIVVo+xk9P7tzDNsrOs38U/EsJohHwbpRab++yRTf1AOvYXUCQP
J40KpXpTombFbAteLu3GVVVwZeuk5o5hCjviVLbfZCH8txWH+ftdjyvBucF1Tf8UBCvfYkU6e9Mo
l7bPRfMePIaP68EwpbSYjSf3Fo4FRoXGcFgw5mp2j7ZruDXk9PgVh22koSApEsSWDOKsH1DYgTYA
3we3itroi7peP9grjv4f7SMbxm8spjc02gP7xnV4+UuPpCoSMSAZXt0EMyuLoy8JwxwVC7dsZP8B
nqjQRTbTbyEDdGkqEXNvPHMgEOH5s8rU7IjQyHYtwu6MI8MPeCyNBsrKPDcfTbcYhknED38+FJ4R
10CfS2kYJi3c94jlHce+F/Wj7tjtE+LJ1r+bhEu1FlbWogYojl12ZJbR0z8ogcNBxB82qTXilhem
XvklpiKCtHJkWoWCjOLcDxwWU2c/xNjym2fXhGL1X4x5oTX7k6kQjQRRpPqBL3aKdF8gK9QQpN/s
BgZjKZzz9g7qe8C3J11Yd0qEDeI4AJfZq0mPW6XALyj+vHx9CCPzR+C1g64+lWDgp2lmEEOeVlNB
0nATP6TK7iIVdk9GBhHBupKmwYfQ08GOscQ/KVYvUK7CH/bHRQSkDrO/HqRJ9ZtkEfi6xukx26jn
ztsQxpCWWHpOyC8CIqYMyjKSV6HOR+diKqioKSiYsA1ieqKH+QcgvqMgN233X4ycx31Yj6xrMTun
uCj+hu53+hVS4uBb4AtCxeE7j23QIEXqm2vpT6zaWYrn/kviY8lY1hsUhScpdGBpELMlniGn98w+
xeVE6OxbSNQUZAa2ZnWUEBzlEO/kinPceufsPJ9EETLBKru67/w/1WtN7p/QPXF0Xf8TP4oil8/X
Xx6ThUisKYpZSwtrt6Mh/ubF4EPKgLKxmj4+TMwxjjp/41/fDFZav32KTBhyiW/V8CWX6wzvAcVh
PwKElI7bXpHbmo+JyVfQrp/yVOpN3OuP9OsL4t4SqQ4PjVioawXxcq4/v0q6UHvZIMyVz9PHpTXb
z96L2HWjp3J+GdeJmRJbb8shIC8WtB8KwuYZRR+99dE5wNs0MfbH0YKzNMjJcQCM6Esp0sfSHq0i
e7vv18bByPuuW/Nmv+ILjFhUAGZ6yGViureM2rgJ/l9Dt8ZiISk2+VivGi3ObiQckuZnu1xGy3Er
+yvhbTLJUaom52X9qLrwGqIoJIdcNSCaQ0ATZmbsAIWA8TxY8RLtPka7CmmIU80qmlu+6fE36WTE
dYlSKqrKDnvQb2+22TnpL/yaVBtsmkPgMALZfLjUIRqXNAofkwsNx4WxwHJ8gwucWOMVImydPp7a
EgRcz4NmMH1MqwOVpuAtSB2nulJFKjPerZ8EO4k/qbDSyqW3esrJVFTEGGk8xGHfyvZcbRD536pC
h/BqlVC5B9L1ri+Rd4uIl/Krumyiau1sHwq1JApTazHUucfn0yxexdfAjRGhhwP6PM/CP3hCeFbu
r4MXrQ1aDSyq/bNI/3k5qbs5apPt9gN7ReKr9s6j8g8dopX4kjBvXA9vEeRq89k+WvJ2KIHbMhKd
BCN2Mq5Au+S6dDCJ+9UoAU+LYL8Uzu4ojelyu/YnCfXw8dgYPnzsHvQsDVaas00UGa+o0+puBtt7
Ua6Tt+IzoddK3n9bNZXMHmo+QPwSmIZ/1YXom4f8laCHVlyA0f3yJ21B2XUkZwrAdxMSx7BslXwc
72fzC7xqOIHB3rUXLAev0g7szp5N+iD4swvJ1TTLSKpuhGWUiSQz6Fko4URSoZGt+DI0yiIaiK7s
4MhwO7oEeRf4QcD6J8+JyS0KtwG+g+eMhGFkqF9MWYkUfZqeQxbZeovWi3QLACtup+p8Oae7UYPY
r2mAE8pYJwA2hdFWXOdFY2J4p7yeww13H1SVbx7SMMSUYOHg72RFy0M4JrTsn0s+D5Ep2GDKLc5Q
lIudqGnbRTAmxP4ub0RyP2ir50tCi6o1Nhho3eIWxR8nXEf0K4oqbMzPBYkU/QvQs1teuCDd5APa
v3JnKCccq62a7S57+5HIqHOKw0U3zBIZRukEOm+qI1xlyYRujBqjWWYinD1dQF9aYapvaaWiVwMo
hgiHLX1LBEpgOC74rgkgtH9XtUsLlBd9x16JtMM8InAId5uziLsvZAGduUbTQQ7yHFL0HVywXMCx
OYWkZNN7x6JG3BsLY0u0wvGFQFij3jbuetNJ7h7BTKnULo03xBzHFrReIFbVjd4HFT6atXr3ZMKK
CXo7zX4+r9Ish4ntM7ZhRYcFkcfQqVc8sKnEgC3wb26M1wuCRwO8r8HaAOopMzHuiifG5Fy/uLzc
jr/SrvycpFTd1qKZxcNvl6eQ3e9omcmsTW1kB3aOa4C0tvH0I2es3bPZWhgL1o/aPIMemRGXh3eS
zy3OdqBIP7rEQgfFVBqcBid7DdJJz+x5LeHfiJDZYZxVswG0K9sko/ZF6NcIqvEQFUbZx1i1nOmO
zkNwsbdDujMYoWroGH3G1YR2V7K5jJ2Nm+tRctfhxMbGRUh4ss5je4EHjiPTnWKRit0HBn+nilGv
isKRy3Ww14aKDKGPoZW/wln8QmLHkXl5gRGNbrMQjyPDLxyWw5z84MGxplEHB+9suKjmRgBOqHBS
ZbsHUKvsLAcT+dtVsuU8dygOuJCzA6KbAozPnO5GAdnvxVF8VJyX/AwXLQjYXpev7BzWb/Mwp94x
Kujs73aH2WMcZjg5uMxJD/GQT9AM7DqQegqz1qA1PT36p78FPGSLfWXKKt0TIufAhMrg07JIPR+q
NHrO43kMfP7kTHRNZaP0J5qPe4OsgobeJo7SJTzoFXu9LjcQECc0QQaTduZwFJ40A8UMoZIwT/0q
Cz69I948k3Wh4ANafhKNJVPWy6w0m9teVV8uka4lwMmND0nHMCr93PUzW2H0ev7jMv+v30jUU91h
xzP6Y5BZ6YjpN/jqmayIunXQEITZnR4Yj3uMFJPrrfIE4PZ6BlTPJibbzI9a3CM0PDu9I3B4Roi/
0ik4V0slcLZlNth+ozExS6CYp5Ahmo9K/F1fAG5xyptaKN0h8obI+A3gPtkUY4khTNXEOYK3e8a+
KceQR/mfYv8glr8Q7sev/VjlRrzBBT4Of+JxHu7uCfiQhgeWDWtANnShxv3Kxi13KFuKiqsjFGM/
q9v54rAaiBlI1nE6xvMISbDh7AeSdNnUtZ1Q2BAEvUIHE1rqKCNcwCg+usKwBU6e9faAUSfC2WoH
vQ4wX003xjZ9Ls0inRD+hgYa1kqc1Xf0zBzdpLcXdjyPbNn0K/JM4zSdUHImIL2QqjHhgddYKfho
9mGcSxmoe8K/o94Gh6dkoTt6iH9zy7lDVeeuDo5pTxOly+pccbYUoU5nRIY/L1qqSnr7HNvlKBSK
ZF1GLrAX2Z127mYWXA4TPh2gYVIIAU3np7huXQGEaan1B/+2c7deGU7O74N5t5gz9MuzcjCIQzty
QhZ+WEdlGaeiwftm5X/JPSKbglbiUDPwVn++3jnUxeHTmUDgeQ8TORE0EfzyvHmIZBuzHMsEJxNU
4e/Cwl9zsUVXp0XwC6GeEqfjefqbfOzrXX+bGI0AS1j9qQH5DPOLwLRhX9VUJ4Xt8+5jxKKNn1Tz
RiFChNbjwUhEUm9eyPH3KbCdMmjrvaOe1L8c2XSlM4ovucRdseq8D192uQC7mFFW/yn7Xe4KHCpz
8/PXjLXAf7gCj+5IUdVvmpi8hLZWwpyqDwvWPhY7kfZsbIpPBGsWzJiV43hDJnbMGGG1dg5H7Iu0
exqWjUz4M/PI6ehf1VZoC6sBheLrQU8eHOkCWaAsBRnNxPMuR7LtDIuw5/JquZ6hqL9zo12JvbIP
+uKbqfIbMOlWNZ1RuLv4uOoJhNYYfyG9BRNDazRJOCeBHuj4MRiI2QwdHXaGuYRJG1CFW6TMLYet
YhnBMjxTloDj77VxxHK9ZYlltRcvCSWxUUqe5BWe2a7Q3tJKXgSezJVjzGtGgBJocO918FXAngDE
J7QhhIqXlH4puCg9tiPglXztaYVA4V3qeZ/WazhDZ9i0cXUM/ZcpCX6w/rEm6bAmqWy7nWI+M5rC
N3qqTo/pz/uAgdxEurV5rc88+HxU31fLAm/kQviX/1mPOElezLhVeiv0Ray17RQyYceanQPyOu6Y
CPXvJJFfhZjtWLMc9ciLd9uTzsKFiwHoe/1zzc43UdTafFW23a+bEiNArMTjMwkcil+t66FRt+t0
Hvj/UwGiz0F2aJyd6xsNpGnv3+3maMnUiTMYVrnMZST0E4t21ku/GPqFBt8kfgkP9cuUaB9APHg0
niRfkqYOtmeB5SeqHjpNmom5pr4KwEOAZY1XBB9b6BfvAKd3HnJNsV2R4XIWZS+yAE9hTr/R7su6
dxVjwBDdYmOgPMT5i98t325GZw7+6P2sUOpS4Qi8g3eSgOHbNJrU/1F3akDvr2FMINQCts5nW3U+
01VJrSYai2b16i0OghMlaCUwg8lUsO8Zn+Xs3WXusZ8NmAiiv0tNUUBfBn1XlNMshDBOzYQZmkCg
9ZVTsPPmzqVTf1+HIJ/SvKD3uMVNJjEwJSRNcFDh6E24QKxlSdpZ53s5C15UqpNqaLmdMfs1rGXh
dHoHr73sxvt1F/UR4i9gJFHwXNjzCUc5yiQ+z6ZLU/HhFhnv3ER5NUbf5MRV3GT61KZhEbkDIDjO
Q5C7saUY7LqkruVXDWClh78PJ/eUpBjPSaPVf+EupoE2Kpvn2awrKNt+d0Lv5jV1pTrxhC47rL2i
b8miifp80mfojAQKeDhlJvNvXaIR57XG4GYabZEcAHIaNJAHtNEWpXoL15cyHMYIkG1Ssutdw0m4
AFzJOQhZXcopti0ASFl4zx9oqY+z0Yj58esXz2CgckJ1TR++N/p9iH7Gj1t5p77xu/ud8azxlVqx
LxVofzpczLYU09Mf3XzBDARKsSSZfB9mA24evRkk1ewOViQT3/fW4AnIGBoB8lBPGmD1Eb2Ra2j1
VMiX3+zzUlNhE5//N4pVoIVfubOUt4D0mSNHSbDYI3jWG8NGK8WXuhpijX2U6yDTvPbsvhtlKAPe
VoZfqmYi/yQBSaSGA4+MZ46/VewZ9TZ5dkvPuMt/LyhpXjawfraggUAsMml7tBPnWRfnzbSZUUsE
rkQ51ia4oURUHJOAsFEJB3LVBkE/TDdNi39tTov3XRLE08HYE2Id2X4+uDW2Ys03Gcek3SWJajN1
0E3JOM5wxnJ8e3OuKo/a42PxH3z8UGaHLeT2aL/6mnnR2rrDojOoeHmm81D6EjpI0kWKABUdVcmk
MuGo7Whruvdl50JVqAVh8fFlGA1ugjwWa9miyUudbHHMNUGwgCB25x2mnjq9SFSBQAUqR5TpdaZQ
Q4KCe8tYTzESAwCjEUKU1p/DjrSX8ORjE4w5Fl38HvUDMnuGnA8uaFDyXd70w6XR9zYY5O2cNYC3
Ul+hrCkQOLiYIxnHiY3s++KPcjSxujsFxjkmyMTdyqTohgxaoecl7HVpFanUlLN2rBViOPgqQ2V0
If6Y6cHUhWoWc2qqL8JY/BcKudMdhUAaWUNjK3aaWRkTDgdkZNZTnSwekQeXDFTIB/ngAZMcxCv+
qq3FbwIF1wW0RHIH8jfAt6kBd4WaAVVq2ESx4crYkjihM8ofNrOvgt1mAHOehwp6Y6gn3iUboPdx
Vy/+nqtzBm2c+VQEVqom/NZ/hXI3qRIOse85rIxbHRGdlzUPzByC3GDD953Zyjvg5fMC93e+1Uao
5BYmQVNxayrgFjnydXFHIhrPWIZCkoGSivPaYS5LQkLONV6v0n31zHCMizLeW+r1Ps6CALc1K4JK
bsNVZmLNs39z+1NQE6nCestt+e9/qk4rCHlvq2fp3+a7u/7YoJK3543lkpC8qVf9KzhoOsfx8WHD
Qjb9XM/IdNyf+FczU9ceZfp6jhIEjbELNW0c3YH9+jxyv8CbQOiPgl9LujjK8ClaoYJCDUmouyzL
ceB2auWPSis0pH0/fUn6wzOk8Y7BSLQJdN1f7UpLYPyY3mZ6zifrIZ/pGOo9JwMF1Y8axJGGstt/
SnSx5qSjSE0jeyqCFqjPEtPKa1nsBRo8QG9lQmKjlzqNgCq2RK/n+m9pfbLaNTvif9VAvLgHVmYa
IogVzzrQc43L/JABm/VZq7Y37H3iEfJhA5LhSxP9RDdwekl4Plb4QjOMs6LnspTuVwnukkxvdy4s
JXgO4trfBlmNYnUVEjmVjnZiCM+Iuk3Hq0Yb1ahDLIYcFtlpAvJRCxyJtOCsduml6J/EfZq/xiRd
O1D1E7derKFzI5y1L8ShOh2GmcHUFwVJZ9arCaxwmeGsPP9UAvBJLNFXG42pDf9zDrZ7fdei1mzJ
IhVO65MzkS7eIuPXFHqxr6td4B+zxbrlsxoxGIDbaNrsStwwJkGSrEr6vl/S082MEa0cJqYa2o48
z5fMDZvM1eApw7kW9YLeoBsHU+HPDns1wnwmTqeA5pv32UgAwbt/kIdd6iy94Y3Rj0oqoEgyLItU
nb/SEyaY0HqZHjGNNKW+M2wdl7peS3uj5PNSc1pE4LihVReMQ/Hv+s90TGBq8IbP1bYp8dh+5UYx
1XkktaKbcBQixEvOLqlZqjgHpxlLOQvNaXBPromjHNAMaHfN6LolSYuzazEoK5T38VKQvYtqhn3l
8c457PLFDbpY/sj3c5vTK/jgXsXzU8xZbIKgbsDEiSOb3yOqVW3BKH2buSjkiJ5QCsU0o7pTsiRz
KKKFWQQ4sX3UdJKayEgc2R6FsIr0vvUQWtOlCWBqgqrKRW97e/itdqK1QPIr7a2Bgeu/Y1ORocEk
Vvf9a0P5RGtKpD55BonLPa5R/rPnqGkIJ01K1AWiOHQUgPrxzNUWJECzDClMc2r1l2HkOobDwZ5a
6zLDjVh0VYqXINS2XHq1415WwSD6zMbUGrxonElfIikNoNoCAXWZHAdWIZwLaf3eDyVk+c7O4XoY
PeDViwlwr9CtYIVHp5Trt7S1LNNMK8/uq9GhX/dj7sYE7h0OiTLzxoIwADxalPSJ6evpkR9yveF0
CqK55d6Xfc6fM79JjMqjnfWmFQaG/kDvZLvpBjGPmKa0u26ol8N6a1lYzZ843ALfvu6XEiZrYzMS
dQrkUHwC27cSKTWXaP0fBPQXdMGarArO3fnTFKCcEK1L1OJrnzewec4U/S+a3makdvJy/WCLh4f4
LWPHga+UJiC2xQZ6+Q3Mz7ai5s8RO5NmQR4dyPVk+KZePIYo78aR4LKuykMo33OIvyn7BgGSjt8X
vkQnHAah+PBYUMHZhKmUIIq4on23qvhzOW60gVX1Mx1V4zBwRkgDjUTN8oz3BpR3xBxAZO3XXatd
83aSwerBoa1QAx+RaVfZ0TcbC65bMW==