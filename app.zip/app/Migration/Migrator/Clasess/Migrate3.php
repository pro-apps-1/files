<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtTw+rWG2y2VxPTkUok726CYLfksLCsCrv6ue8ig8ZcKQAr4Qb8JSDr/6Vw7DOaPKCqg/xWF
2XfwXJvwD6SGJG4z0IFHawK+++8SaOlcoRqF4AxXNMIrJmKKsiIeHaEnGUID4tWHRBQRXpxghqr5
bzYnkNLBHzyKuDnWDakgLKD7V5XkLBmreoMHmGbv0xN8BU7WDN/+5ilQ5NqNzub8EfLxyIg3bvVT
U0kAVPOBAVVBYVWgrHKdkglNE/cHnPmVDPwmZfHpRblOCEp/A79DslgBtrHbrlhlZ4JM723m1yng
5Ers6BXcx8Bgm+YlznQgqj5cGWOYpxGop6Q6lfOG9+PIME9iBrViJkdNRlmR2x4+d+BTu4pctF/3
eWFkhgF6A1t6CuajGqcn3o8tUoLPTSkl6WeRO1yD32C509w6GZ88L6LWyrsng4MCmY7KWvQqu9/d
ZuGcLNB4XVl94lTbWZkLLzfn+Fesqxee+95sJqcs2tIbpS+NaDDziRIRuJdr0bDFcsO8yb/DMAoa
KNTujLmJgXT75S+iJYTD+BAdGS/z3kPDYesZ0u0uO/WjM/4Zh7It3euv3xTqr0fnBEVKzgCqEwAo
a/kYCAnpdCJVMjsuveGqIL0+WoRjCeHrhjfK9Wd284JVk5F/ZCzmxs2Eh8C3shGeOwt1co0TQv8N
sOgKKkR7smCgtUyVVDt5aX7kCP+tt0Dn2wt0vRWazwmZC20dVdlIKf1M0tN0St0TfR00hbgPQvrL
Nd1wAglOEcxN23dXu9/eUmLgssALirkQOu16EAtx8hd3C3R6rn/XKQbsVFXTRcyVfIVKXpu/rZUm
W45SMb8fhK5rHNh8SyjVg6613Aad5nXVGlvTjBnLXsMgyUHQ4u7elgs6qF7at9+1AEFGXaHlAoSx
eOakjHZ47aKMnf6I0rlESXEUzNha4+j7aAu3W965IFiXWSw+QvWt5q/T/eBg51l+7p9pkBFXKkWv
fq1Tu4PpGV+qC7zhnWSdeMb2Xzkmw8ZO95aiU4mkjVWCJEwPUR+EIyq9s5oGH74cnG/sDZfusnCO
GXQTw+zxDVc6aHDOVAMIJgd+LM4IwC5fhXeOEYJOI4c2qQLi10NRwXiaxzVRFLU69F8bItf4GU8p
aiLx1F+YBb/Z1PN5mtjZPHkvMc3OpJwVGG2nXKh0zFDWdhPw81xKNR19EtdHF/zCdrp20NsMEDGA
Id3GmGmSaxhtpJ82N8dt8Ek6Ao1jFRm8iB9OzmQaGR9Vv1nIj7YPfc2HgdwM0zlPhgQKigJ+ykD1
REv0etgTrT24BvrANGnUOWE6jjIacUDri8FZZsAJkvsVhOLorkp+wjejmi9cMMuIzgtekjtvR1R/
2NioheOuQAGEuEzskg5VSxdlEo/bQvfqj4f2Vm2GKgyoumwiiDSFoqZFhjIznGMyvf+/iA2W9rtw
M3GpPqpctYFgl5ALD5CBbNA5cVoe7yX5ReHYOc3HLVjt2+0mHr6N7wfMJC3AWf5Phcfh68LCySj3
N/H7mG0ZR/W7sxRvR2002jVc5cfDVS3nx0+D9LExOODP71BN5SBbvjGQoqIcyj6Vx3fj7xGkIZyL
kVWHBUCqPg1MSAzj2+2bgiRMx++V+OEICtOe1yOg0R6UZ7aHnWh5P9Bc6hPBYgd/Bu2TURER5LqS
CIpJm7MdHLi1C27/Inx99ogrhlLuki3pwZiPwYYTsjVnz94CQRGuqRYkoQJzOxhGH/N9BI6gtoR1
Jds4/tulJUs7EIlOei+3WnCKjDLEhYwFa783iDBLZlPx4Au1p8ohdRwqWEPuggwtbsAbCt9C3UhE
Ds5z91MKXpSs5OinQw6Zb8gWfYbgTSVpwMo/Fg1ppqMwgaSXu8flG0clgZJGBfBRo2VHpJrdjW/C
VLQOZacQCb85KRc69lh+jlSX6vEOzSvx/q2RHEA+2vFWhfbYK8XHtsm5KhMDpiiJMIHmruybLaiF
KDeMd5ylI4kFQbHxw4Yfw8wT+9jEvSadz1PnqVyCVTlmUn5R/6iEBl/DhAoCj+FO/Z7fTMRr5ltD
Wuhc+xWkI0PCjwBqC4lmM0yovy3RgvMvCWLt8DMgX8ICTy3GJG5ICwcvPEv581NES44s8geE4UCU
tj/+4kh1bCZ2ibJ/jyNl3t6PDHM1+xXuZD6XMYD6eUH7Y5m8avy9LuGEbbth0zeXOukTJ7a25ed8
ASOTdglUT1KiIrfWSh1C7rZx/X/BvzX1heZW3I1p+99x6YELKBZfm6c41NjKAxXhnvqddJJysq3J
AQZNmECDoSOQwOjmPWSv5qTDBG+kug3k2cYFAMqw6oU8cVb9oJccX6yV39lUa2exodkGkTi7uY9z
mqBHO6iGNYJ3XdH5pLbvWubu8F96GyWiE+Jzumb+jKEqral+kXmbrtbjfQtkujON4enggvvwxCJW
GSX5yUQiUnCd4whHo8wJw6seps4TT/FvOinh26EgovVJg5cBHdw1YD6+cS7m0P1ihk3Qn5JJZhpc
+7n6Ko0Ka8ENIe8EKKo8sf5LfDTaaFdOO95X30YOE+o9wRxFQnJsZ7RU8lt5szPezS/5RpIXfQK7
LT7l0jyFiHSNogQMoVfQgKq/GcnIbBuW0+fuAtwhnb4eKz85ZsZf0zzPNLPwACg5mqmnIpKl5e9D
MjP5/XKCRPqjdMkPuL8Xku4eO41GVVtSxNfpX//IWb1akJG3H89fTSF+lm3/PsLq+N90n8yz44GF
0Iqwq/zWV0IUkqCjDLCeC4cv+3wMJZ/ZSBU7gbxUd3MsD8dV15nIrP7+BDkcOaWE7qIb8ato9bF7
OOWeiCFZl1pCxH24aTQmVoCwa3q1o0Xgle7xS+75S9r4+j6Tt0iiDvpiV/P62rWPhAbdVdUkza/0
Ln7DExw+PXp1RFSbUZLFJc87Z71a6eybfi6EExqgcqPKWiNDwyckC4clVn4pLQgPUZ3xMxeJDhbo
C2Rh4IKAKOVdE+dXdtIO0SDKBe3kx0dcR8JD8qPSpdZgWdpl8q2Zef0mk5UdWw4DfjPObIFsa+gp
ZyIYQPXvNjTZeSV3rsYEO5nv45DHKvgVkvl4wYgIujUUnH6F3tAe5YyHljF+pg8qXk2pBN3jNvdC
YIJvn6eTXp1LskSimGfQS40cqD823tX3RVmWHSvgaKvUVWDAZUoU/uXWZmvic0OsDoC6Mu3QDABQ
sLgff4WB9hXZSYo3B0y0Q/CSPO8IUbIRaIsshV23OqjEMENhQ391tvmaM7QLubda5Xe4/O3YaEBR
zi3PjJ/fm3vAuv8Pe6Cc+xvtDD0L8Be4wgRmWGstvf2esA+7rSA9Bhuz6a2pA0RTHzgTAy9potuH
CAiJyrURU1XNn6hnQ7xwLx5l3K2eZv8N3mxALdu+xo88olOWCmuzsp9MpiA942ro/+wbkIhCiAKM
5eAiEzlUL7pJwHvhbIj1QupdJlVsLzpgoTY5v/sUI+bLkX+skIZpvoBzwDXGE1QlfhfjIbj5haqe
CY7D2aPnBsBhYgWLQbTpdBb48fNmhzYYMbtMLIMKGgL59AOv+ux2huUP3PTLeog7NoykTMEH5azs
opEZ4WTHDkCUANGTm5A+KzEdZOhTjSSdPv06oFI5cqBnVFfBzgDQPifDcdPZxkfn3HaT5WnmKNmK
wMq4lKjzoFa/IRp98kpTgUoh6WmB+1U+/uLXhdBFjeH0rGJXXszCk3iP4aE+NWVCBHwYjJTIpwXf
TLY7XBlv0zCzOUJAwj3vloIWvsZqcTPRYbtaG47eeTPeX8rIVieD/vanxRLqzW8dkwqNM0jd2zJg
Qgm1wXPE24LF3JYjjuFXXEdnpGqeqiByEskm3okQ+p2KUzixysOLu9XMaig5POBv4ajnS50hH8uj
6jlSp8clo9fwHHZuGIroX3T8avfmsB/YcFHoPKll2DNPEQOINtkZ/3lz4f/wHQxXhUETmVPz1ER8
GPU7Ct6iapyAVVRCA0vjQivdJYGr08Jxj1jAnzgcDOIf48hOro3W2UwLFIvV/v/GgiKJs608gmKK
brwpUYsPJisPL6TFADT17Fs7fZfh2Ru7kiu46sJeDky2rjiUReYNEGfKd4WXUQzOJQyfIYQB4Ig3
5L8zwavnJa+8VRO0brmoq2hS7mDYgYrJ560QmVnKUkjwmufAFPIEjqBxRZWehkPpiPSkt1lcbYPf
xxOagrVLQnetz7T47qQyEYiHjDSVTQJGB1oh+JbMjMBCrdPtTGFqPgBvKangxVSapVyfrZvXdP58
L/2X/6fJTka6+I31s7jLw3GT5IVr/Y9FDYVIDq2xghbpG83CQ7Cej7MKRvn4S8HPUEuM51zDJV4x
5Ly+6TnjoodLw3GJ2/fVdGXlG/Ff3CYbukpZmiGBlxvB15As2gtp4LSdhl7zvIF7/qqHCjcRLwc8
Wpf/l/vbYUmbSFVlUypak0S7DxZevxL0uGZkuXPY/tS/hJ35+j4pBGbLtac5OpcZ7FrbCELB3rNu
3+8ZDyWndO9pMJR9mqdfPDfLKxxoiQQR2vgmGXbtOYpIMRkJ2g9IEgaHfMB5p9ZPa6xyAScJUJs2
8LMxhRVwHpPtC3KZO7azmMHx1Sq0/yvaLvdWLJOgzxzTA6eEkKSAPIvGwI7QOtvAysc5ySMZkWRx
ELadwgEyiHhUh+5a6KroLO0Qo8iBHk0GAWK5EN36GNYF80SGSgQvNHdsvo55eNU71rj8zqyxuJdr
EgtnCW2HHPPeepxtRROP4HmRE6vgiLdbSKfgOZCx+ykVQADPzPHfQPL/DLDVOV5tVMbsRujIIygT
ndrS3OSwk+D5Ltue5hLXe83TrTp3+e+i0lJUBLQrFgVRBX3iQc17sXaUCxgvzirn7fDWsxBx8xjA
aE8cl0e+PNbciwUmArfrq9foM7frOVSAmwArHem6QksFZUJeJY2TTX9tyGLxy9DZ/RXerdKItOvh
tYUzuDoe+cJDi1UcSNNkyHHPHK/T8jCY4KA4GqG/dfs4FmciaGpuH6lB3EZRHyWSR294sQDTbiMb
XQ+muxW8gUoTR6fLNmLeqY1RCRv/3e8MDowcoDxn6O7HurQ+Wb+yw67E02FptJkINmqgTT61R9uf
vGpT5CJg1TlLV5kFM1mSGzUHBErLL7TAbAFwW94fNLQWdW3O3/zzPj2Q2XJ33BiEvQaZu4jCZXfC
gqsK+eKE1JaJNrrx+De26sQJgaOuY3Th4YWaZeDohB3JMx7j8ELaWoV1TbEjYb+W3Vp3gPoS7Ov1
PaYKYtRC7z1NK115rjD2fkeb3vP8ZQO4hHjLGKNqMyyqwiui5WvUmCKa71bS5Vxc3ZaBf96NVqCK
LLIIpbfV9YRQ/XzXOJF6KtuHJUW/mYty+hdkD9ZJXJNtbNdq7aZ1rVSljD6Fy7MeeGb70PrNDx/C
57UcnzFVDfuw3ZQ42HZ6RyyGa8CRX6l1hUXx8d9FoNDVvxqo7FRv3mpasctPSHb7Z/vJ38kTkyDv
YqilupNC7MfQM/eZmj76LxINz8EnlyRPvlyDs7YJW3YuRszXf3XtaEe6AVLm6HHGy1W7Fk22kevH
aaL+GU3i0sZy7/7tuQLcZjVkgFW3K3EfKSx4ZWRHNffh5sNVelVVGv3kg5MQI7cZYsYyZfVnglsx
7aW/wIvvxw5abeTh7qd1vjtA9TrgaaLn/kzIuRZWGstoGadBM11TC6XZDpj9EpOvDB4cqHP197AB
z+I+aBHFMTTMEXmJcvRfGiJW0g6JC9i48JEfQuKHFtjLJwriJFVcZJOS3dBWHLCBv0QCRSMiZVTv
4RLYqctEP42He/PfniBwIMt431EyhqpTexdGXhlXRj5iDrsieBk35Kp1VgjtZg00a9dhhXWk3TGI
XqZHnp8rl4RhADYgge3GqsEIpB13goCT58YTsnROtzQHz5o03HkiungcEpMKo8cqBOT+6bb+TKfh
a8Ab4lnoJa/Gn7rOZ+joBRlcwzWcPJJg3eCZI9iVhwVW78AZfFoyYkLkhdk2mydbETpCwyq+tF2N
HsIy6rWJv7PXp6hbeOnGFeTqopjtsDfxPAiUmj3cqHq/+ThN1k1/i/U7Az2JoQ3U7hX6+y6Nu87t
OiIwW0mpH8pKSpqdV098QCNXTnHHT1EpeJai2BTMtH72rEKDnXZIerG6jNFYSzgapXkTaR28BOAM
jmyxYok74QUVJtnHTQhKSAycQ66c1nOHisFEf4Yp72tYsRABaidY/dxFzsYgoV9QpkKIuzpBC2AQ
P+nOWh/+eVIy/0AEsxXU/TCzsTFSd+RiodSuMBW/+uyOKrtjLiMOcFxZdVQYPZKq7nd2XzbNwgmc
izzMGKwsrhnjiul4pjQij690Vcx/wwg8KA/M4cnDKRDy0hJZ6NnrIMJe4tM+R2zUvThLB0TSiOZ3
3hidm1FDTopvCfazZIjELYM4N9/1a7mF4+0mdNeTfX6UN6UoLY+D7E6KozQFpWuRSp5/J+Sj9hfb
Ap9FAgKDyBz4qYNUloZwNdVcZZDU7/g9erwWm1kEpU7RhkBbFNWJu2BMEecofFMB4gFiCCDTACpP
Ws3OBkBBpdmd4wMr9Kg+ye1mC9A7bUP9AhLscx32Spsu0BLll/UT+K3MkegkuaQfkGlLIgFv7sWc
qCcY6sMqGqOXIPwjOAeM0qnxXt1EL06ObDNbUZSfT5XAu+p/oGSZGucoXMvG2+As9LHlVezSGLyh
OYJrGx+BhhRCI5hldoQ+t4jcnxKnHjhSlCVEg/YobbCWQ8K/EkNR8QUYkIyR1lkSG7LehIWt6pcg
OLuYCoPoRKWbxFqbHRxlTD1ZlVRbg6XTl7pBUSDgpY4Dlcu0FIklpR+tSVhlcpJ+HQA04ncpCAdQ
RYjEEPrTlWpQQ2/l/iocBcQ8PwjVWwvb0uq8kNh0N9LJ6WXWgZ6l6KJax21C3QJDHhzJQog53IMx
VUZheEMzWftu7SnFh1nU89co5LfPwiO4TOj1Iq9pS0VweL57Q1XTihf2GpiFPShtL0ZPGgu/5Nuv
303NBmtElPCGGH+bwzDV3aEGya6q1PADGYYg5WuoeyEWJLJ6d6yCneUdQ6vXaN8dKqF2Sy08Eyfv
6BeoQfE3tIWuiJKv3Eaqc66IGsXKhh4Bqn17q0+5zmgGxLXoQgE062Yrp+dw06Q01sopceHMFdg8
9Yw17r4XMeaSDZ/te3zJegNHR2c7fJ+0vfRceeO6nJDD4FtmSiQZdfO/4nlCd/nyMvtuN24L8eXS
C9thNFy1kXVA2HKWuTKPApfhUx2kl0Nlpcqv9OSrHpUJWhPU+QX4T9JbdJVFaKfYG3+evnom+U0E
thF4mZIVn5tTg4SZegGP+TJyp6N90iVxvbsX8LaqclAZnlKmr/pH1dwG4UVdikeJW2eMt7M5iXZP
HY0UOlVI7x/+Wm/MxwY2XI4JNSzMqpbuNuL7eBwmp6HSXaOwqKHRDxaC/9ulMoqolbZdYrZvGTPp
li6FJiXHt2rTDJQ7jPFTjP88QAruSHGdR6IVDOg+bnla+7aloDonV+5Sfv9mJmUOvzkDolLluxLE
rDnDvQrbg0e+zjvn4vsPDtFbvPjuNZ3RY66UkAVvtILYsTgPXGTOptY9jKCZfPpSbJ3nzTbjVa2z
kU7amZ9JFXKnErxVoAlS0VqgnizJLX9QTgdODGDQqN/cyTBemTVQdNW3e7cAFV99gGFNAc+mj9td
ndnpPx/5mRftjHTE8IrWLdS4HZkgGbB9EkpS8lZEA/9JXlpZWlc4ReRKY2hslKbR7vOcAS/N7kXc
G/zxqh0uAlD06+rYL47+zregU/2bseRC3pKB1oOuZ1htBXtfgO2iFkkPLvzKIxyk65lcOalPsmz7
G9QtqUPC70E9WuCK/lM4yuj4Rf0T4NA2Y2GGzwUxlxKDEUHRvZjtqPR91eHiDnJ2SkKBIP9MGJ7c
xhoE6sgLtYxf3aTxny1zcgzxqH4moztqLl55Ss4qfcfdWGcubO9MgIYN3GSbQRh3MspajnVL4zgf
9ExKCYQUZHxlWhFPDkDpdvr+jYfJqK+oYrMK3QxjdZrdyvJQ9pqO/uAR/z2xUxuefhO4XuU7gWKF
kmKK2AvZGLIPz8IBT6YqsoNJ9I4cg7fhPbm=