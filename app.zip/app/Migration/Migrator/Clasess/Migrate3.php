<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvHPD1ZJ4erVge2XEzDT5JDCzPpLixlPCFA8cHHuvNDheDEJz4aV31TlzHSDsJZPb2UayGyx
JlkkiWFtKeOk6YhP6ZsWW/qnGWnxMNoXgNeU/0YIO4V8kMsgRElNAkeVaC5aAroDl+zpR3sFPPat
lLtD83Hak/iG2cOjqsf5ococgryE3OHry+dA8a788o7NkeKk0o1iqwYYfLYuu+kRgiNg5vqlccsS
+t1teDvRFnewQrcc6rI08hCKhXRYsQIKI2ksxSPDG9KZFqh4jKURPiTfl8FHPjrA6u7t4yCwVZ9S
6BYpE3r5mPs6vHzNjJtu+zrZShveykHYIcEDK/R3CRtVYBpAhmNT/1odxRz9kUFviz47k3IDJvSs
+vk+8nkNLu4bc2e4mJvssMglzqsqEeyA2fZUNyXC+NygYLn+RbQu71Wk/QHKQ/1BBh0Nuh5zTWWB
DVeHqmKWKQ9nvTiC1kj5nQKNIIK8KaRRfYGCAdy7HGtxU52YdYC8hTjuKIx4vrEiK9Jxxr9kq0wf
t0Mw2FvuqYTa2illJVI2jggo39QTE30LXE82qvcgThlxIwr63jGed0xDctKGKlJ94uUDy41Idiba
8uCUWY0MUQpEwx08qdJR/Ymp7csdSqHXP9XA3ltA82v/BHSF/pOT8VrmXEAnQADPqws5GwaEnlAa
dtV5uTs1AF8f3xjD/xiVH/MpKyd6niykJK/5zQ1JxOsQNLwSiuU7lIiLNbgagexeZZhXG9/CvPdA
nTU38R9tZAb9f/4UJaztmyLopV1UvXwOXCWqP4rwP9VEZt0Y9q3HDUlPjPGC/3WsAWdtw1xK1qqe
V6vkOWGJf4cslZLBXTePL04tWCJeb1boPR7IRBmJXGAb7CtRNQ78CcezlA1YBjPHLUB+pOvXDuLq
LmVwsx7L+kD8sQmB5GW3npCci77YjaHzdUqV706vzAd11fK9L9qLehmTcmvqhf8/OFVzsWLvM8bd
fPSeHnA5LpJ/Qq625dQSWF2g3Hl37CkOGZslky+qHyhwI0Ht0qG865vHq36PHGDKugEH+tIeA73j
6KP0cfnncgXGNb2ImYx5XG/z0esy/mLoQUKcUmnn/kYnfnfC7KiobI3Oe4FNG8prVypq/4fImpgW
T19GpVy4PO60118H2IOD9GHmFRN0gWyYS839xAksv9tDMuk00udxbEP+/Hd2g+VV31H3KRcYCDLl
P7c731bNDuT3OiqPfKkxw+wwyBkYdzFFefQ8O9UwwJSO4iT+2L/0PJxGuKoR7mlkoXXkI7NAwRkw
sL/SYCW1D2bCsdZuid6rwH1Iyj8lPzinEIa1Ej9HbYeH+GN2THYX6RYVF//xHHNlOL0iFuYcSuRB
vZHDAiULVYtS/jX5xw5bCVVrZ83JG1AmC73Z14o+FbmCEzH1wMJMlUCNJ5rezSkpcHrRfxhEOJxK
ZRfvX70AVKbegckXIPFnWMjuM+vfV4FGulTcg4NDs5enmIJSJE5oOhaZ+tZtkiz80kkij3aY1yTl
jTKOggiM+hm8AHwIAXtYM+96poBPsOU4hchw360iJ8N1dqm6vJBbWgoop/Q8+ZeGseOFi+u6Fu7F
nMXXB94aaXyNLCwq0O9y6uYsMQb8nR17I5uxXenE0SMMEFjRsheMDY+W5AetzeQ4jVzMX/MUdisk
zesTLmcgOihT4+B1eUDI49/+/TcXqrZ8zbnFz4rfX+MI33Fkc+nTCWrQr2VW4kviDm0epEBhmSsM
jHVy0Y6eW3uCB8t2jP+aZPRaUArKXg/aIV1O9Xn9vdJjymUbR3xd4Pdvjn0fzVgpr294N20ujZVs
yohvdDn/7j+H3jjS4OE9HVOfen65m2Q25PPAjblzgSdMrewmJkmRAmhtFtK+veRgdLb1vcqcTH0G
yPe+y5UWN7Xv8VlSQ2QA4y560X06Q8xkoTFodFaWT9jPrlPUzF0T7TRl4RbQAlASs8Sv2GLM7GMb
HFPTK5FwVbOFOOkyiuL/7xb43tEl8HUSYOSwD+L5Ruo7/RpNKUInitRfhvuZOJidZ5rOebPpW/C0
7YkPydNBVXln3NYwqoTC8h5wiR+dJNbO2tfMKsiZcq99FoF0Y7sEpEAwWr/A/lhHomTgWYF8ECaH
8/Ww6RQPXy0BSNslcmnpkU3yp3SP+XLr8FXnGZ+9p+VSNJUY+AsGC8dsGWr/5dylPhclFmpOA7sa
WaWwFU8MAkjpgfqIqb3mVkW7Tbx7CESYRLQXMyFa1VaKp1bd96sDsrs23h93FN6vav9kPIqNqDxx
FaKVDz7O9ZwQq3HBObW3mE2VIPzWKqoMLz9yoVLy98h/fUePsPeFeotd1nkqlI4RmOaZ2tHEi2Df
5SCQKJDQlMV5Qi++aV0b8RsdMCqRhOAkKY1t+1ny31ENatUUh1l/wPH/CfwgYN67HiLNZAWEwteT
7OBufa53a+dPCWUoOuPBZSzf35rtRXHUncmVj+cwI3AT4z25UZ4bTfsEBqouRRi0QwgMt1dd91eP
ABsHHsSke5J1eR9/tBj6Gu1rW3/lR2eHjj9h+rPUMj06ilCDqnjs46iXu/eiFxenBLschTBlyksm
cTrQ0xDldUR3HrtTmg9htwMP6rTDzuER5OITpfCfhyWWu27APlTYp9IPkOuT2oalburN6tE7mNIW
KE2gqxRrpseekx/04y2kN+0hJLYXWz3YAwKm7p+E8oMgHAccOJOcnAC5fTQUV/zCHgDlaedkae16
mj2/gP9g/seoiQmOROuglAz1xI2/4J3XNP2wmtI7cPHwRlAV4MnJTCqLjXjQg6p/Een59Vxgb7IL
BVWXt54eAUdoAcZhUqrJ2JHvKN1Sb4DgOIT6yljSscILCbUoOWPko1wNkzlCsg2m5b3tN5YDnJzz
pyMGNkNOLhKuH/PPP1AElnlx5RQT5sew4n3yYGqAvMzUlpv/B0/c4nImaStPFfFtwWSuH6hPbacN
GF1NW06SqNOMujWiJwnd25UWdnMTydxC+TQDV5WXoHyl2So4W7SWDuydojuj1f7BZ3TLDjcPGcIM
PggV6rQxRrsRCACPILi4nFgFT5reygDNBWluqdYadFE8O2WaJ5Lf7sMZobBBeuZGXBo+41J8VLL7
pdSbihLAtT6DLVidPBwWY4XHoYE2siSPumEEJad16su3HnrPhYqnqPqaQRU0Jy1/CNAmMyGkDAP9
vUC1GX0JIikL/HcnVUkOU4llp0vBlVMJ6j4qcGSeUi6IY7wNLR9vachSvtOH6xiAYD9ql+2s10Gq
w6r146wtWVJwyNzouSZv0nxhrW50sZIsdzedfayU7WPFEvZJsqklAiGTn/lgO0BPLR4W2trMoW0o
4XegdmJMYOY97PkiuYELDDwSniNbg1XNVEMqnORc0yqE1ON1KqXHfzlOY7+xBoBgHPQH6sWF9ofv
5jm03Nql/J/tsJCwHVzEeyiCZAGPAPGzsA2N/BXdaiadbTnvqU36JIKGEfhhu0kcbfvYNynaoaII
piZ4XkOJ1xl8cnbogJyZ/eVe244oomefY/EkcO7KLAzNgW75d5NzEVlOgWEVHl8U22ccbdyQy+I/
SWShob8tnBk5Gj0lrSssemmOU+zRUkV+fBUjje6UaDQO2NoV0gn83oUYzEeLTWBop0ZzUvVaSnLa
K0zdzT6E7SLY4X3wEnncEgzDuAAWIvH+uNCxxyMXPlY03elxywCJ2M3axkuQEn72QsTXqvJAD+HP
gRQGUz7RcPTzcgqe07KJzBoYuGWZZXZJLCkA35ENLERisjCaWF1Uu7P4/s49hPCBnewcjbiBzwnP
Kw1MJSLQe3XW3pGcIDvG1FvMKtHhCmW3Y9TbE8YzRUepdz2a63XJYuqJuxXIdkjqmvYRsDh3qntu
PVI8tVtVVVES+TYilIpK11OlScyVQIamE/bvZVHLdnXLPJqZ3X48oE5ObHI9StxbN3I+Z4AnVaEf
I+nO70zQ/eo7bjkSWnFwmN3Q4SGgobgF6Oo7px/wnnF3oZcCjsKBctu5Ljn0/r0I37AqxZ6x4VZE
umoJCMU4OGuaBYdtu8VluJdRI0byXsMMuaVD+1LXkvmrHj/7gwAr3ornJjX5BYULwfXzjgEBpFX3
NbJd7OqXgTSB97QnuJKscTfL9CttqRm+iHB4Oi7wBORg+d7cDvEHZcdFDKdCRoHDUCu2CpkbX8B2
M0rwXQQ4PVclIEQTk4EfIZy=