<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw1Z9l+oHW2RCn+Ein/8H9wIbjs5ykbe6V4Td8pbaQsNwBxcuNL41b9n3RfMvfJVzuwt4Ffe
6np8Cnpqm783+Y0mj0jGUDuHNQ2Ij9zUljEXcgUshbDTHv682Ig2y3Cg/k+u4iVFsYj3pYQhf91c
uZ/0SQ2RSZUORw4M15Sn3FOjm3YvQjiz1SPHyyhq+jH+pKGxlYSBpmr1YoUfMjhL1lXCtu8H0GSA
fZTIspL1jdrUEunMaWtcGF0c1+xV30/YEQNNcmFfVR3196W5LuFriLLpNEMrc6bxx7zQwkVDZ8gX
1thArG2/Ock0Zncy6D2ugCNnShf6dz9Q1/CL0E3p1oKkIIdDDSK274GrBJh9gnKUbUzd/H7sWOUL
h+Z+AP9azP/4C43i8VRAZXG+FtRomBcSg6GgnNAciUkwW+PgVPmRLENM6bGsJuQiRgUoAsrtFyr5
0aTXrhol9h+5GxxOQrkz+wbafnarUrvhgI5uhnsKq9kKhcSUlHg0b9iI8SVD3sNX7GKZITUFL1pG
dpsFC3yDORx725MlVw2IijyxepjVakGrjNE0MNO/TGrAhCLPqUrCISC5TPUt6KDV1feIQOxrQoeG
72UWy+LenaZaMEtqlnWnu5f6FKcf1jw+B7g8ZDyWOpg4PVqQTJk3VB3yBdrlPcEsTj9Ntb+GIE1T
23Rfp4EbKimEFPVz3flH9CC/TUtX6kCPZpjj8lTSlnnYcOMGarhLo4a11ed55ZBAi3VCJmwPzRr1
sb14wO5p7dXkvWMmx0NLQ3OvmqyLRQ4neNlvKl99uZzEoLKOkF+nlfOlGOKadPuhCMq2xmYT4g8p
09S9x5eFrl+rJyCwi4TmGgQNlCuBZI+REvJqvk3NpioSBG0JGGIA1s173oJnIHnU28YR4Z+U7cPO
xEDYL9r4u7RQs2NNkTqtpL7uxMNW/fO+LtVm0qBtuz3gDq8VZrqLchb5gENlZOsfXcfkASG6wUeZ
YNXXyu2tWKGK2S9D3EvIMFh62mX01quN6Ah7I8n4iJBXqLL/nZbn99cv8OmNUrCFpguubSBQiLQN
8bnlIGFP91dNhW7QESxIals5IroEH6BtAhC5MOYKIRxOI2G2mkj/RCQjOOCdCvYCGUmeoAzbzCKr
S+Entt598S9KKpUWtIRerJhqy8k8YKMGS2bsOfbbK16CAxK0iJZzWv1YY627q6wKM9zjZOCqfkJ1
vvI9aWxg269JK2ddf75BdTT2+8q37ai1w/EkAfWUi7GK2VNMUWYlH4OFd0bD+nXBbhd2GwU7r9lF
VpHbsjaUNo1g2Hh5Ws3Lp/1D+y04TMyCgDe9QY+z6RwQE6V6EU6V63WRhjt/zerQIqOLJWiYnI+I
sCuYW10GFuxUQx72tqdWlBlIhJ++iYPmv2x27g6DEcnOA7BpckPZwGEYttm6I0DVjUXTsKwU5Qz2
S/V0jP9RdY2cIkZZzxz2zegl6AfGVcQNyehoL/lTrvj9HSKvPShtSGD63NM1YaiNolPywmunBiId
zg/byCRIQFC5B1guy75w+OjCVOVs95tqy2P1Iz6UQVanipLxOItZKOc1zoSb6MXwU36i1fn9hj/D
skTo0bEVXo/8y9q6ccFh7SQBM5X1EndTEw1CNs0bxnw5rzk7pMwal8buhyCzqxskVEv2hfs0VPY2
UZ8O9FqDLA9K8uudd+c1bTxpeWtJpTrS2eXfs6nn/wzjMTqY+gSfdAthLmQPzM8SHyC+juFOIVB8
6/CLkrW8Rz7pOXRyzKTnMZWuTFEGGEtpP8tfoHoznNU2qCPynslSkb6+ZVSxH2BPsIpUwjiw/eP/
8diPCuBKaGcPHu+5AenO36PxtsSF2PDPlmIDu2RotNlOjc7bOQaSkzif9CaM4+SIeqxYSpvlEyUX
uc6uH8hmFHAMuMRnIuWlNqB0o4dnWFI2FYU/w8nKVqYSZ6eBPpSXf+ELsUetNjWbc7hIdRkYz+5N
fh+872/RvTjhL5nSCdhgZW//9ve3M+M/GUZlbYxvJI2eFjmthzAzps2Awn8MBQiDGJ5AryDejs9Z
kNJ/wPYMpfgbj6xX9er2TOs4x5t0NBENx0eG1IvgAQZ3c/vQlNOn/yAPMtpRgmgpfiW6lwMLbkm9
IhNtrv7lJjwLOxHnxyaHEcBOY0IkUw9h7BJmWlB5Ju2UDoLFM1/6dB3iIYTeLU58ivyD/5ID/pk/
Tg+ZgXNzQzkG3TfAWj+wKFfUikTYGd3GSvRyTfy20DE2nfNu6tIjgwYpPpCLztz8OgZPIiJixhA8
IlXqUDDvNO6vXyLqAAUrqcKcgKCDEYrsHjrQhkKZQNRawd/XgNIraaWkZvv8XDXtjblEqvdueMMZ
QNhOvvZCwynzNW8v0+DYnflM0PR9vuok9718ov6GRbpfoGU6Ukzx0c/w4CANPlww7+GmDgd4hpNY
McuBKk2/ovgrwuImmPpWfIla9UImsjU04z/Hkd+XpjfoDfPoFS3zHYLuwvJkuVPhGeFDnJ1Ww0d9
0KaHYRN1wAuXduv4TKWg+OtPIPegKc0x/5LpClus8MJRkLOWjF8iMqq07lfZ06zjelRaH1Xgf8cH
P3tBWwRA8/fenAXDn3N2Zd7bjbmZSBVCTcxvFfQLN08L2XMnPQvZvyomOJ/GVfDheKHfzbkUWdq0
G+AQK7BJsrfB/3Q12ObxFuAgjh/dNP4/yWuEb/5pO3hYg+SsP3RooFIW9yWhuEbeALCH1q6lgzUQ
mxHb7g0d6MI48umj/xz2c2nLhITsDBjQZ61et/li6+s93T0c9NGols6J1pZscNp2eSHaouakBXTE
IN6Wuj+T9rffyFlma2YOwHq3AKbgeHKNhZaFdfI+lx7dd9vhR9/izanh5EvpLI1G0VoCvKP3Zmsp
40YUUq6MBrar64I4YdBg8nX1b4D1r/YRdhZPeegF3Po0qQ/SEalxLBerlsjpAowt6xXwjyhXiA6Z
2L3qZLtYZtBsKXtLJlpq6ym7Dr9IT3EZkOpgNO2/X8h1BxQLQVPNn2V0uhgea8Vya6PxCoAsbyQ0
rv00Z2hEocXLMFuxj0g1YqFOw5H63lKF218Nt85kisvEDv3MrQQ9oaB/DZEf8XZ6V5UWCyXpm2iP
lHmjZIPxcR1x77MLA6eVuZfdxZU/W0wnoXqfM0KiCqOtrb3DRL+qS1lCIVrqvmwdmFt5n7r//ZHt
0kHH22Z31ohRmBuGVy+nlEf/mwXPFWjQ/VUKqlKvXPCSOsGrJBydU2gtLiq1H4cPVkh5U8fOVk0a
iR6r5VqKv9/NIG67xvF+YYlHqgCEiK0row9XBhnaTrWTwY4T684vvZNJNH7jmCWSLgnYG3tQ1+uz
yElBPDZjVL1Hm/bSxLW+ZgeECYTEZYDBeF6kcs11a74xj8HWBcfyRqkF5DugfvrosIG+IW5YmnF/
reK4B5ikwNryXqt4K39R5Uw507ES1ooLv9gPGKvw7KeE3lag0fQDXk31eGHrO4/TOnUfKRjKqRlu
JPyqsNiCGP39CSmVPKZ6un7lOF5/+NddNBYw3p9VOR8bVm+LUfm4QEGViHLsI1QBgHOSAYJEnkbo
jyc0BmlnUbGhgEJ1EbiDgNGD9GnY46oYZvOGIdb6ePTMtu1krCCiG8w+h5+GSwgQZljqnut0EaGM
ZdQZ+lQntQGrLQgn6qduP6d1rLb0CaquISGtL5mvQNN2WvSwqM8Qc4ANgXODjYLs8cv0hLhx2NQs
rggzo7C//5gsdqn9sXbX3xOARjIiagmCv+qrB8FS5pw1Be6ay/b8h8PxAVWHobmZEVOahnXKPtRq
8qq6lyvmxDzhP+9rtIOKPH7XsHhbX8ykllDQGHSA0HXhvhwKHM0OgJOQLUPW+peQDwgdB7+R7w2j
M96P/7eoLjj+3z3CbtKJf3sALCS2oatT7zCF7KW/a23fO7n+LNuUuQiUKHMhQB9dyvkZlqJbwAEP
E14iq+2JcXC/U+DNnWe+wdW0gIbcWpOZNR4efRUb8Nn3CVoitFVm4t+UjunNFZXzbGZk7bvrh35u
6VT/dmwIN0BM993z7Pv0gVg4+SUHm7qq/r2BCeDT/FFBv33b26FpDkJJ7cfxxweEeU4h3X2A6x+T
JPBattMV75M0eFsdEtUjBTYwPayXhYabgUV5Lu4GdhQCkmb3wR7o6h+ODsUmQ4Nq9qb51i+hZuKw
tULQGZT8Kzs2ghxDbF4iGhnEKy56EfnnotRmA1xgqZWh6QJYBMFL2yD5cR3wsbckpNmQLJYO+auU
RYv+7ZcG0v0qDg2IPQWuPa6TABZLlg3NiSuGM9GnZ6ru14lPzwVwsOuwyB8VUNDKB5ii37pX0VA5
FGrbB2USXMDkMSY4p2H1N8VL7GtPnmhDTkGHfscyvHN3V2aeqrWw5EERozOfodD9nBwj0dscVs6t
L1N7nvtqd4JbEmtS/IguAbBGLWFCDpiBvvMB5z3QXeEy7vZBax0meN6ESpXwYlgdgu7x55tbulXP
fokxv6QlTITinMcv3UNAE8JF3j40/lIbwt0MOOt0O4tYZWGb0lx2rwHi1c4kCDst9ox697324TY+
xrlpAv55U5Gi/HFOPvUQgSmHVcla5AHWZcYl04d+DC6K97uEqaKGwWLOQ+LinLKflNoUtM0R1H7/
OTdXbql5DMT2zhlDyrojnzezXzMFSswYW55gTZOUMYUXnVIsPJQDgeHIJnuKyq95b1J2xwXmbpzS
JcryVzPvVlgICR9m2wlscuI/vXfKbGt/WN90eAx51OLrt4NVo1dO7ksFgCbPXXCnxE1dTogcE9T1
OqZxD5IUQxBV1Ji6S/FMEtk9zAkJ4+eWIeK6XLqPhtaFYAG9CJIfrd7ZIfPyUTqrCmAHdCLCMQWg
8PixeXCfLLhIsZys5OHHomkm13DEyyvCSkilFgU1S8VSdQW3+eC5qStTXOlrX+F0/oioLSSU4PDL
Znb6vLOGWiaUYNPTVdua1aUS4JrXv90mfLdqioQb2w1LWMnD3DLGaZ8XKPurr6hqs8mcezi8BD+F
drzsZ4xW3aQRznbcA/2unmWvevlF/DOJEn1/MaPe/snOOpWf0r26LTR0W7caOl1oRK1olsZg6VGw
XLDD2QisxHyAyQkoxZ+mmbgY884d9ngmEiysFx/qdMWsPxFweTeai68lw2VVWZLTOQpEsGwuGc3C
nuLXTi2MkZh/VwiF5gmEqjBi8z2r/WuYxVONhhqmIXN1RK+/kSCv5EkJBgcPDaMYyUobiTjq/o6t
xvgBH1VejO4vyt9U36AuwlI/0InEd2I0ofTdpuH6r3cK98h0TFsuFW07zeqXZCFTFjpekNZDmJKc
QQqPnj1dI4/MVd5DwjjVQsz4AzIN5FVuRD0TccOmv16rtiLa+HmldOoR51ZGG70rdz3azWM1omKP
CIrNM4UhTfQbO1IinT7u9kbbQ4NrtUTXT3wU3egFRZfAbcQRBC+++PxFWVk5vQEqypVBYb3V2t5c
bYlS3qoWZkzdAW4fWVVc2MVvJXlLlDs1EF1cAJtWqZyD7sV7LKHRgHH8mRc469KwtqAWWxDYjxHR
tLqcXd2I1r6/gzuNnOmB68AhrHz3v1zLxxVxyOhnHHPzc3WcCnvXJjt9Zc6M0040zvMTLBhEfTwu
ty62+/QuMx7fpFR6E5gGjey39blOm8/ziQHn5eomJV7P9JTs+1ddVa+o7P5UUwx5hF9/4jXsRMAX
c21y7SZeQ9X/LXPSP+9OqCQNImZFvXBXaF6LEssmLxVpzotCuaAFhnVT9l9kuqNoIkAjkOl04Tos
Tz4OV4//bjusj63x1Ziju7AfRDx4PdmRRH2xYQQUhD2A9d+WGnCzov8L5fLTDomly9lklWMIzuZ7
vZvauvqB4jS2rnil/rjuI3hoarhWKzhZpwkamaRP11IsqOw1QLe7N+Gb8SmE3gVHlA1aKIg1bj4/
L35Fj4eQNCeWNKjhdYS8aPa2dMZbUv7/J5Jrru5GsCbvSKbNoHOFEoN6u7wDbCVaAIMjoBQzcMOC
pjM4JZhkcToRvj4l6eSpnCMwqSW2DdnOVmjX+YtGMn7lygOMHRRBhwUntnrL1T85sXF3/peSuwl+
JyronCCKceIZuokHM9NTewXvtWS9gyu06xiktUcS7VQ7wTOi97kWBtQXbx6sRAh+iBMihWezq0hz
sYoqiqa6YyHPMNrm0moY8oSMxYSmg5WnrRpALyZOlIZtZCuXyS5Ll3sGY2zaJ4Yk3D0KfshtdcU5
s4d9ub6UDMn6vs4He5vsp7yPJlHxtfXevrCzOX8Fl3ViBa/TUWevSRrzmPq7zT9omu5LT67OGCBs
S5GuMKWRp6Hp5/D6/cEIHS7XihaFSXk6AcrJmpcJxO01ODSz3FY67Gf7rKfBd3ORr+Zo0ufuUnL0
eK5WuvvwZcmE8DL7Vv5edHnYRa33yoypunZPmGZm3KJMbq7KTMEnmaM5fw7yoKQ5R4MsMc6m5Ggy
fuZzBG1P8l0FWEnHT20HbmVGxRM8dEtWBZhJC2m4UQUOQ5X/euUYOgpqrV5xgtV4OWNNIZW8XdKh
lIJl1904Doq/J2VGs8SjDFyfiJ0f4cKoTIbS82fiV22kdTM7unm5I7ZeffwCM4n6t7hCthkHEAXK
drv7/gycUc2TpFSaUbDs/7IQ1IkUnO+uCP2Ym92iJdTrOcBbo0u/t05xrSVWD/nl64IR5F/ck/3q
lkav3weq2xypxZ49kFmhkPJBnM9KqM27NNrS9Axomw8YzJYk4ksGGmWMWeBejgd4yEhxZkEbaG4I
i3i4jiX/kpHDeiy6wmd3aIS6rTwVrAuasBTKKfoFNyWoG8G9sEh43U9fPwCsinKNJECkYILrNU+K
N3sxy1g3Udmgykzruun0lju3DXdyuei3V11eK5BjDxI6Fw0aftPkFf7JzPS4WNdFKBppI2UtRD1f
n/Kj6hyQhNCXGnf1iv8VqBo5ZLjZ8/DvKusOrjPnDM191oWfduTmRkvajr7jaHyaHr7Q35kihg5b
sQGJr6KwlX9E2+Eh6WDlKIZWip8h+9pGHOCIvPN8yQGhviVD6uLczjThRTbzef51zBd1vgCQbUaW
AH1S+8Hd3Zj6S2Bk/nyg7OrQVFGj7SdsDhrNhtqOiMtxLe3HQejxUCCndLRqY4qSvsMaln+m9w9J
kKOHOgdzk9zEEeu/Q464snWd3P48z1bUvntfQQYSMFt1VN/7KAwz9o7hHUbXLOAkfhi9LWzUhl6t
4RiBzmGamitBCQNrsSSPlTv1M5RaOcWZdrsEWGW23smpAyXnl/5rOQUn3HiJSJu7VcpiXx+4Il8L
i7I8cLUNMdgif4sgWYvTUhglgpRlLrxzVKqdwhUm+DWHORKRcEZz/Z3SBIXwhPRuzheA2ndyJ53F
YgnZnIIn266ZxKhHVXHSg8EY3gajpfSvdOf320+FvQM5Os3cDGOOs7mA4+2HnQ7vCAX4wJKMmnoB
pvI9vVWAcokfxOM2iGMALr+c3n+Rxym0SN5l3EeH30qg2G0KZUlmqSfgh9STFqE7nm3oxsB34aJ0
1uVEXyeB9HrHsZSrEhSluiNAMm1snVCLiEgvogbTcWx7PRmn8jpHyj2uHmV2miy45YrLm/VK25O4
0K2S9fg7YHRzM0cB0iyiTcS3vEDXpmN5dLLwSsPS3cciqvUYj6HpJ5R84DsYEaqXGPTiKJzM5CGe
swspaXBbdyZsWPuplf7jCTWwim8RztjcBz+fws9ChaK+O8xqOWr+9gPjYUL4RMGZe+n8ANutM5TR
evZbfQMap4jgeLc5XA8VsyeL11I2zRyYWzgOT83A2UQRAOy3IH6cvefFAVKP+aL3ZRS9kBUz6oCx
aqq7WvvojWVv3dGanY1yZcVl6fkW/QGtfS54kM0ehD1jv4Lzb3Z0qwBoJ14eeOJx2G+7ukhC8hf0
KExESJ5DtDk5s5ohbfdxwY95qI0SuMe/uw8gAcaO89y0WWiXqR+kOaPn+Z2xTT8rs6onXfaxEWjm
/7UYNGXZQrE9HJu1FoNZ1PW0CgQLhGMggmB4HsKfzoy5WtvU++PKVCsBQMABwmv+peUi/WE6LwFv
Az8j+bbnW/0gPF3KmMdTZ7xbbdfYE/gieKIRHvYUAiz/YzW6zWr9+i9V1QXiDOv7h7gra6HbD0==