<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmQRy2BxACaLWdPb0GV9LEq0jZ/1sHzVqFmwdVrcgRdM41tUOioJEDM0ZMdvimVkN8Xa1jAn
ny4v8BlQewBROpd96Ldz1dmHgS1/p8sOGo8ph4FcNAjzrK46nQZmC7uT530HXQjhLbrUYRbjdex3
BiLBKoBr0egFAGvEg9X0S92sjuG8fx4olKA6SRgVR+Rgt4XGn09LjGUKNNOM2Iw5TJEzRZWoH7XW
GGGgZn3vB/Z4WMXDouA8SogS/lHWgztMBZS4Rk7UZjZMzb/+NHsfPTbDxu79PrpNqXbt4fHxK3Jv
MDJLDV/S8b0ERRpy8+T+6gBLwxe/xCl/UCcKOb076tCAdOsdKZ4tA6fbMuyCvyD4ZzTcJ3GqhQvU
7uv6GBu/RKYEd661Ltn1YQSpG7pkUJNc9FuoxvqL9QDz3i0LHWdv33YCFHxbZlfXdTJfgTqJe2Ms
DXEUm2y63dKcJMIoWRwBQBbCjqXKzFZo87lWedBudyUEIyY3Q639k7tO+HgxMgpjxwzrnBDeKGfD
INRsbT3T8OnZx2xQmrCnrCEuuz0oZmDFF/5NS+zxm7Eo5CszEGjEvxCYh79ntuihN0Xfyl9GWRIU
D2x8xS7eaS7dlEGeUAtJgOsR42zMKEyGe8ZUw+yhaIXp/x8kWF0n8DMVz8qe4Rki3IveIQP/r1a6
jYeGMfXSYxFWM9InU79zf7bA2gRiXFMojVhF6aKnzi9l1oxN5PGOqQCj3YTYVyQ3lLyYlL1Pa7eH
i5fHoZJA9ngIAKKS1q2t0uL9S8C93P/4fGjG7fUo+KOqYSiNhG6nl3JP4Fr2bolThBQfukspjl9x
hmQiBEDU6ea/1zgm+5yE5r8+McvDEnOIaSJbvusFuf05hdhlICs6PVacxOmGzC9esw5Xws0bk7ie
5yJ7A2PTeZGmauCi+IDolGdNKa+52CyVlnLaPMx2Ns1s9CmSTyCwmYGYDFv1GjpQDUzYrDKgYAXU
Q/5S7MV/6WWM+RUEUPPLlVvGSi/N9MZxBO2r/UIfmjoPOuPiEkKIRTbT5qlHhfKZ4yhAXhvCimPh
JT+1Ryc7nSTkWPb9cJRwk9AnfhqWk5bL3ImWrWWn3V2EYA0tMEfnwgZrNMVFGwD9cPyWRRqNSM0U
3c0pClHOToYywlXjJFMr6wtfV1AOVCjRqyr86T9HYgqFcXdqRHMxU2m3l7z0mTU89mGgi8Y69bu3
8z63vDDzq4LuTzO6vAcbzxPY62qoXPWKfiNIHXuqfNKJVyLT8xBU/fc4et22HER3gvGD3obyDKCI
7LALha4tKr0rbJYMPxKqag6UE7jMYK1fgDc+zepDIcmJT//VhDI/iO9O6Om7R95X6Y2QYQRaqz4u
SkrFYPXmu3Ngj09p9jTABiYA9+mh/rjXMc4rDpHhHWFNQeSfaN75y8qqi+Cm+/5sXR+C+aq/mQ4e
CWexa6+hCNLfLO1DUUbmMhmFWWZ1nQlE/0FqKDD1HgEJO6DqYlimDzRPe3wO2JePZUTNvYWKwBwU
/7Mudnjcf0ZWIS45ua3QUYgYOEulcGOLyW9Qv3rPcA5avMfFiRIq7/cOjbzodBYLfcfz5uMS74B9
Vu/kiz/sr64o8AjqQS3BV6BWMvN1s4jxMTAJn2NlTGod+JQht3BYIKliuwbT5SPxFbOoyXbD3bbo
PdX+nA5e9x5n+4rkltIr72m3D2l+uyg9VOF8FPgtk9lHYfyCFgADP5OZimo8W8ZQ0MChG3ILlsuZ
LujTedtQne4z2SMr9M6cEWlWivPhv118Azq4XXLNET6adTNnQrm3MwDFVuTgqWfnep8EGc9iYBY+
hHVXJ1FjklOslktkW05hIqTAm5ncBnC4j3zqSpw0SXm6iVU1z4bpWuemL0QUtIR13AARLbBe4Q5T
i4uXy2JjShqlXkFNhkHCnaZ38a7rf+Un9rn3sFXB3adR+W3PbxIAfhisxlDliXoU0DnrzOVg8+WZ
5zC9YH/aWcFlR0n3jfB5r59XutOM7ZJCmXOoiOSlEBfUArcWlVZBTbqqJqf9HXbLmw2am5Z5L5pv
svk7Ln9OvBq8go4nVSwyidG9cNw3J/HZD9kEkf2hU49G8Nr1iPr6L6KOy4t8UhP1iM3gP+ksfpjV
UDjKRYcOvLwTOp9oSndbL1aN0KdSyti9Xy/SULxL2uxl4Y1We6UmGgfAgsepB4JblWFYS5QFeqiq
AwMbUrYSQ4kAaxtQUpHtmTqhFV5r7dlD8ihQGvImSsGYwnmGO0vOjAJJ6z2mWfVMQMplwVBOX98h
zx9r7QvvIx1HMFsncIK7qswwh9+/JuvnMVRk4ejJzk5ka9w2kLEugpe6exvhEh6X/eBYO6mbVYGX
3gFI9Jgry+3/Wx/j+D+JEAi5Cl/JQH7esYNSIJSJpn0pEoj6BPwebFe8urYcnRNlv01cqz+4N74a
+G2JY4ZycVqJqT+9Bf36vkJ3iwA5XT3OioUTDF7W1WyTU3K/NbSkEvgON7GACK+8+01G1auBdbRZ
z3kUvGbgiEZePlFgMXcdhFQdhRvFZMAAtTxm5cTpYZtQGxHg4noe5z9341QGoOweUUmHgtBP7KJ6
Aj8MhcAPr7NTiDEoUhzh/eMpw7Zv5Wq7j3TtxBDqzHUAshzdcyOSY0ABdpXCT7BJVJcbzV6ZEvKD
Dyk/xoT0+mTGebVUuxoE8mxm/KaxTOhdkjS/5JQzQZHvFRq8aW0l8lcv71PdZUbF/s0Az0pSrlm6
AL2VVouD7IRZYL2uNeWk0/M/qgUaAFFJL8DxEOEE+JXkzQkC/erfnVwdZQ9Oh9S1C0DJdMojbxuk
VOsrTbrzgShjOJa8BXG87l3ZQ2Nj3bRFO0tGaeKLH+pku2HWhyTwOE7dH9txYez4UWEkUIiTacYb
SZf/BPU6nQXKrs1VUEG1oWGUAq7wfpKTKedayIB2zZBb/O9jzjeDBFDWROD+JCn1PBYbv1c2/mbC
za4SCDIi6MshSt8abNEUtN1zW/hQlN70e0F0xdeR/5jqwPExUxe+AyhzLU6dRh50dhPYkcP6fAg0
UjJHj+4NzjTnaWaox5GK5oiTtteHL9CvBBFJx+XvzmsbL5+MxfIQRslj2CGWKqe5qcpAgIVGTwZG
PKntKa7HJGxj4u/ump6toc2+B26l5KN+Wu4BbZU2fnaEDpOm47yuluw1bZHiLxyOraiN4NE7pDW1
yAtNMeSKFRPKeaHUjtQM5ss/bMHPeNaPs1+hFT1gVEsEtzHghkXjUlSeXnRmi2/o473FkrGoHO0f
/vkGDAE9Jg1F76tx0CKbaY/Sg0WGsUNZa+OIBTvQa4lZlW3tleBPKrPBrxEKBJWR8qiOk76t9Bu7
AuYL1VMEKT3u1hOa4s5Na434v5GJ0xEZxDwMZ/vhiHvPLb0fp7BqIfGEF+zxcXLjubPpFV/4PZJo
qWw6tXj9rnqCy/t8BY8d21ax1amKJVOk+MFZO+ZfvMoc+4fsZZjfq7w+8TCxhjI17Rolv7aWBSd3
EOQe6ds77Xnem6JSL7eAIYYm4UGtHwL3zbBKWtSmh10V1DXi2i+0BgCe5cDPza8dOkSjsfAvWFEL
HsGqMPrrykWrq3Cj4Ga769D8VgdN//FPcAslZED9vojHhVt7luhyDfzfepjcBOplsM3N9aa+wX8A
glvC1h1Tjughgr/rhqTnhVyTsqxnahU0mqggOF2iq+n3IVkTf+AFBa1/vwGSLlI0xpc498G5NhqK
GMfhQRemgSJoVafctG9mEQFlop3TS8TN1hV1GjSZGfT19p0I6MTRzCtX+dq+yptfHPdPlwf+nEnx
DdtYPlTrf9hHBTwDSbuhCSRhr9wfT+nImW+75LYa8AVsXxYL9AIUUOIf/lUcUIspKzRV57dOeRye
WbaCQQhP0zjc/1UCqfo2nhJegQTzozmqJ2XF1zP2GOJNKU26yL6V7BF2IS8C+RISRZCDntbck1CL
RdGwzBabC41yGoBvu7MoDoxNu3EWNcci/JYJ9zelMujG7BFFtkqFN7H4l1hkzEQjqS4kcj45EZZb
y8lmqpdKHLEAGCDmiqBtBufZuzsDLTgO74iYIjZ8v2OFu6EwLe/RQYMXSQB1KBzRvh3+HjuqIQt+
saGa0Ih/hG4VBgMZergtjKmXY3j5+Dys5A31ypJOBDqr0LY77BWhqPrZ6NIPYWgHuHvYhhGVx8zz
EB61XnhJBtpdANrCmWt1+pG4BX4xbCcOp4w/XPhNW4KbHoaJUNkat7nEnLy0uzsTuAvaMaaUQLnu
s80R+EhO+QUMnSP7HyblsML6fL+awvYezQaqAgwNjFamt4sT/JW1BxjyDZPa9R7dpjs8WldquUvp
BWST8v6/Itdnj2ZcrWx1dwv37rxZ1EjdKnFdsD1MSDjkk7JCXDL696LdP6ZXpm8qHLizR7HMpRl0
Txu8fHu4heTqKdRkCOQBTrh6cboz8aNDafEDQWghsy287Inqw2jHq6stTxe/Ux9Q36ZR2elyate7
P7Ytufv/bk8NTBndygHvydYMptJP1fr/Qj9JZgooiBuc7tB/cwxJXQatgDTtOUe9Uzlcth2wjEZ6
JeNlPlzGzzWRi2qCKjzVxb0jxlxanGvjIxWLYO0smrkCp/GOvKeirBPOhbIBNUgNpZ28jv9ngsDv
FarldB/r/s17GULAO7X7swujVvFT2Za+Il+UR70VhWcP8f9c1s2FtotWxUDrd1brcktRcjtGbWvu
0v26wXzsvHVXWYzHLuaqFgdce/yNPWLgzbMIyy8/bFMd56qaELAWMW/ZOacdq64I0Y93l7hk1fZ9
MoU+veKuB5mH/rpzv6V7mLZZMoIS+sj9xwMWO6rv7XwbLck/ncBKTbuKwXuMtn3xefpoZFD02c/V
3H3YkMpDr5T0bSvWwjtSgRQ/D70b04YJfbm3X2JRepW7WwDc5mpI1HR/us5cFTqY2BwhkV8VLPyE
FL+nfXWYn8yZhMChdMVCUms9H2sJGvMQGUqP2o9XghpMeXW27LRbOtiZqg6pTWqOyaCjRvvtgnD8
5vNaN0AI3rNMWWxtQA1FVRJWTvj8xePKAYd39Y183YMUOPyLhR3ted9QuB3fW7vu3X7a7n3BuDSV
9kEQFg0bkyDWulZ+gnCofVBSnx9YSTbel1GeV8c7pHPJ9mm3o2JbmKjh65TSB1Jj2G7vxrbeSQ+I
xGk09laSeQk3NQ64vLFr6TGurnp5fhWiZ4UfnvGeNmOUphz1NHuM4/sIASFzl7bRnSZWK82H3iir
XITDTHXS8TzO2MLfqNs3A87YEjNtDg19DH6aoeCkK5t7bGXgBJj49quPDbpXIm1z8FaaeY3Oco5b
nSeRRx5/ufh+IKTK+3W/OFUvr0k2vZO8IoQRCuWMJjNhExH75K5+qhlMHfeUTZVlkEI5pGKE1zwy
T0qYdR2e3aHAyacBWF2e9QBADmvTsLySpVZcEbKS/Dglvmw9rs5RTeJIC1a+EynSqv0UZNF9Tz58
iUlg3f/x+BKq69lc9lywONj7UiE3WJZD9bNRtaTFTg9JW0IE8SdIe0PgFkVM/TfH1CAnkYbVg41w
4M+j0lAqMJBFtq7MNE5AaegTLub8MoZx4nzircqEHeOz4Mr7AkJ1ubodQ47s05MYh4BpKcv8ySKD
8cFPiS/YFoM90jkVHQXl0C4wgXEIa+Hhk2LLpWQZrAKDoD2hgJJmwBmOjxDV4suVGLc5xkFSe+oP
tLGL7n0QKkyxQ6+VjrKndZOeg2VVI9rSHchBjfUQ6zTmbZLBkaVrBXBNyFILg9To8Ulg1cjI5ofY
N6zOZeNjwYndOTJ93uVvWKDQDftBoS6nBEzUSQ/DlySkBPpFDwurlFyqQcYiuO1tW5bKs2wI8IE5
x96Gyptbn8BNWtI77snW6LzyMJh1NBlfUIzd6IlBt72zTNQ17ghNPScFjeI2iqBI71p5BbmX78yU
sRjMWjasbXAmM3kvXXgax1Dlvb+Vft4PJDR8eVyqzbeCdjwKcdS1JvUEA8byu3JH4/OGyyVGlZAK
Vg2aPdq4AjtATIEMGHy95M8wHfB3xMvQMAd2/loP0t/Cr0xSJDW/4SnRwY081EjEj7yaL4api9It
jGxrNofXthXUkyJPy0Zrn2rc50+JYc4ZH+oTKvAGfRY0p9sB8hSqWx2YoA/XRWSfcaRU5rVnXz04
RuTv8GlVGGG1HeYC1WXHwdvX2OJ4EHYRDvbG2XBcWomMBEw2bpDIeVfd+UGCJF6+bWpgCrVxdz6b
UEC/peRL7Q5InakOXTslaARy1RbFZc+lhI0+wRo/sIuKefX6qfMjJgg4AyDgvSH3t/RPCnHeG7hM
UokN0urkHMxm1JKG6msy8wZDm0PoK+jJVYaZ+k5gakq5d0SiBi6Hi5pz1IPPciq4/Gqt+wKmT8Jn
Qqj8QGQzpUgOSGmJp8PhUpOtKimatk+NiPFCx/WjOOpzOpTukH5uWls0zu4nUkIUaur4N9VhikY4
+C9HmrSK6SvPY7HtfYL/kGxraA0PMWUnzCV5Qtx8URkIWzOc5mEZnk0k6gV4tJIfh6R2jbwWzGLu
iL0OGV+rPQE26etoeowZ5Cv43BY2qj/xBNuAxXY19SBunyjrq6FTXHrDkJkXLhsY4TFmLNnl9GuK
emRap7Dd5h0Zgi5+KSbFZL2l+cXz1Ucst4lhrkLGaw5zUqq7n/4NIXBQRhBshSMWJVt6fzfqx0i5
XPREIhtK0mbabMzRWhpkw1n6UQZkPilOfMbcNaBw/rQtakiRURgD+uIJTwa+p0N6Mx8YIb/mu6sj
o5JM62hlvApPwHbinMCITkzbvNiaWUG8vZh7VRHDrHURWgX1CK8B/fN2blU9yTK6mowRyDaapulm
5h1Zv6JKyIpaUL5DIgG7RjR+GvDfayL48NBXHXY0aBGJEhCfmnG6V20ezGg1Byjs1boIfNtLzlF9
P0nNA7PT6p7ateWE6kQvR+9B/cmnbx+Vt5dOZ5XlpKfXE6MJgMothklLGa7d3YsJgFGcSK77vPVB
fHu7rMHdzUAEhq5+raY1nYzJe4Qw9gd4IWL1fNOMmSlEpng2ZDx2cV7x0kWbHYYG46nGRaBCQwb7
BFT66u1l4f2/PtW6ofEDUh83Q8Xh+lHf0WcnxzBO2YqfDkNKDUQ7eaOqluZzm4hRsMAeFYqm3iis
UDfcgAIaf7LU41yzvWKLJ791ZAKIfwi19tcLgutQyu07T9lw1P6vSFd22p03q+2uej3EZ2CK378C
bDdRAaK6VsM+K0V/ijv4wQlGRPt0eVtRkP0FNLzqpx3Mv4Y4aR6aHPhJFUKozmd4QwTSelMLVe7Y
KE8ZmtPMSMuL+wZqVeg6oH64BHf+53DDcK82GnADRbg6is56qg2r1NB0MIuUD5p4iKWxdC/LfdUM
ltW5ivxvRCPd/Ytu/ryHs5lbc5vfFhiqLSDdUqubrUdQV/apJ32Idp48aYYRLVSbWJGC1R5VBXIb
/6Xj4ZNtVaSmM+Js9aY0jb0YRY83LZEj5K39gXwKKo5/g973971g9ANJE0VOfIrgmJ2mtV0U+MzI
20zptF0rZ+QqBnf0OFJA5VmO5cRmhEf3sM9G/ekT06XuzYbWNwLh37x7UHSPsU1pkGQEadvATGvq
QFnvKTm4f7K4fNUjdB/OJDRlSHkOE7kXIa1Zt022zvG3HW5JG3OxxdFwZdy+3ShUqoLKK+WFl8pX
pmw23r+n+AiA2AXj4y4nSC8lgD0FZ0fLIADYVRs3XGWabGe6XuoxRHpZtnZJXee90pksA2sCMGng
rNn+S/Ty5ajSvIuqJV7LLa2iKXoWiOfuOmwZCn4NUsBaA1ZI0vd+IcNDlfXLRxq3bsdzYW7b6rub
8MX7bo6HP3fmXRN1iM28ExJqbtmWHcejzO2hotse5gOO+O8RDT474YnRSAUaMKgKlupVVXN33wH7
5y/R6kaX6KA9RIYDeDgVc3Ka0a73X3XEX6CxdWRmSa8/mWbimeABEsKn2Duu38FztbyPyWMHd4XO
APws2oRy+IoESp8l+eXiHI2VXiAwxZwFLWq7uDU99L89FyDI0fpgWMsvZJ49N/NOCe76gWCXknUj
UhUD8BNKX2Fn52Bhpi8KagLW2DMxiCUtARoho/ddUDk22NHBOjkX5cO0PhksMNEL