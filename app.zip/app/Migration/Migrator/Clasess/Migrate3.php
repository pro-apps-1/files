<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/vASlkE+aRzLwVds3+2CjDRAfvUIGnnaSLd8fnMupdK8Ksp/r47koQUzVH7sy2h6Q122rog
HbUNWBhlHjPqwkhspyB8uvFb+noLfD8rMcFrAAUrg+qs1ME2Xp0ltHR8Gc0rxkyoceXTR7DmCCo2
nIk0BdZaaa7n74UNFLzzOk4SNyyXy+6BXQDWVrHY+zyB9q0xIi1nT8z3UY9MZXfWz9BgCtH9lYvc
nJKqdC5XPEB+FepFjQpNm1aKeN97QC2U2tM4gZ4Vbgg7GXJVZhSrBYcbRRBL6MohPkBE37fFX0BJ
xewew6/fgq0Sb4v1zdHIZv82ky4O25KRrT9igJ5xXNbyI+Hdu4MV9syCN3OsWd6uc4X3BChAsRgC
X1AfT9KPn5xmYRfeUOROxph/IZSg42jhOERiXDKo1lLvFzLDEdSBFl28DvQX77AI35TIxfwznCv5
Y4R45VGLtXN3k1jwg9E/aTOK+n66t1PwKxDSII0JHqn7DJeL0ZRNXxN7r5ue9fE9CGToaW+g9nxC
ruvQcitMUymEfI3hoEqUMBCxskyREe4uR5IFTnI5qzPAW/jPlM4UDXNh06kpmh/13pAv81OToPy4
KalzfD6Bc6gZ3MQFJKqLJVB7ZEQmZrRdU9rvYMM6zbVYpq1QFja8ikd6FvKj67gHWmlC1X1q9o1d
fN91XL4J9+gZta8mExhR26MzSIvlpX2+ImaG2qde99zEAOYv6XI23HjK+JhUz+mh6XsLohXdLRAE
NpV5KVgW0xL6tu/+/AMN7pH1aJqGRUdjNNnCJ1zd+1/k+Oiri8/Aj9a/EaPJg08jZPlkixRjEgRO
BhroaeZ/HjtsKjlfk0rdKCBrDbnvaw70/o9VrdQDlb/gjcI+Q5lARKadUHUGZmP6ilqZ76uc5Rd4
i2iT4PJeYO2LX/Ym7zdiwxpnuq1H7h8uIQUedXKc9M0GKM2iX8FdnsSn9ugPwY4Isbh+XWq0xzb1
6vI0nzB3Yi5ZI8nd/yIxGj1TjVCn0G/gqRSl9GMbY/nf+9n86ZVzRFmDEQap4u0E+xzDDcgx8dZS
MUNGc3RZJfM2Cbgbuj2BEmEHS8id0XKhH4LAPkDA4A8e7FCxXT+pBv5uH96Axq9jf2xT2jNAP4HY
xQKuVZau2ZJr5r8IpZbi8D4wvvt/00ZidCHb7pq9KDoFm4lm+bF52Vc80wpvugPuTYDmDnLzGjOu
Pia8V6WSzNRJN40l8Qyj4v2z7Q4DnK3GZMUUfjzzlSbObEIl9/YCpdqgQMLTtFD9PgYzDaWRHmkl
5Qneo3+/YD8LPDhanvq2sgHqaE3gCpTJs/kwKyGOjM2JK6D0qQ82dMx/bA0uxfNhQq+Y+AdeNtst
s9pjKUe0dniutE4SksSUtqJQaa4UinS4r2ylCrrtAtisFuxGJt9jJWJJB7wF6I3EAiTCa4248V+P
C2oxZtW1z7eDcXbacQWttDdtswL9wyGk/Ez3sS19XyL5gL0d5In7jy2HP5cFjGGKQNbXr/gaI7sN
+pW+hQOMibUF4woLgdRUA4gdXOk3iafI6tZaNmZRVwWoPBs5FkKixvskNWlNjQbfBzUIY7EABBrl
enrFSRTK3NhAAtbY2XEJPWgsnjNnySi3/fEBY3bvlCFc/ZT/q/BB/SlyUG7QRoOetMjGjrm5rGt7
ox2Pz5j4bu233deRTG5MbMvgMTARYWjlV8UGBxceqFNiqrWJFlfKkt6/V+DwRI8jMxJ+/AP76R7N
VLC9TNn1Xk9OqJCO1VlwwQpx7wpMQf3opyqUZaCHt59Emgj5XdidghUrM4cmRjccEjJCYcONerXN
9ZTL8R62w8wKhCzfMx+7Ld2v8OPXeihlaGYJBQ7F6kgCkYib4g0dPq0CVXg4iyM5k7bIdsIRknrS
ZrD83fe7/3SM4yZ2gg1o8gQafAfMjmbpJ4fqxAW72QXv+20j1u+62hAfnllrTmnbS766Op1i2hx6
IBib0H4ZtuHMI9v2RMZ6OyZLWLi8sU00mbmrXzz0sxCVm1zNTRTG9YWEyiNqgHGBgqiHU+kyv114
rv0GibGVSyR4EypQuSnadLy0KI+JbZ4gsg94cby/lXha2IDnenGPDcTVxIkcLBmCrdI/bHxYJah9
evDW3GB2vjeqOc6ntdtnYW7IE9oeNrfMm7W28M+0a1E8vkTO9SJ0OZvlsJ9GO4lQkQRXidVFZiAa
yh4Gs5YUiPe+ZEngncund7vpX403nT/FrFrcHgpZzNdCtAGSSyEmDE8BRSKnVyy/eOi+J5D95Ik+
OUxFKAWLxiodQh9Y/J+C+FLHf3EmKXNdtwqryJzoIwosX/HvD23bAUDtAqUknl6YCpXFzKm+MJN0
ZU/R0009TeKEXPYaeDA/Qsk4N72a2aSNz9xzBpUSuugFz4m/Itzjg0DkWlDI7CY7gHtdjyr0wlA2
yu6oRbfRd05+WjpqZyvY2IlKbjurvIGFpYiElAZlMIyxns/9NI5urrKxyjXTSuDYW5GWwFddA34M
S7M4I11tHFnOBoTpz1QWwIoJI4aSzVUwrqMk1MXgRDms+KIp7Ikh2dPImCz+kc0KjG2XO17irlIN
wqqGK4vz1E1jRMy3ussv6rjdIb7ZGUEkGi85y/SAXLIXWDA5DNPMIPHJAEIRlWLfKuEO1zPVD+gc
EBRgGiFX+93CU89r2unGOeVTjjGsN94hSbXDol2w93Apq+JiGH1RXEIIbkXYbC24k5Si7ycXA+oF
SCcopz4+vEr91RvR+vhOx/K1XAUhUrnkzVYTZ39J47qrHEpnb4fnFOop0ufQc7LToL9W8eXCU6D5
CMmwXbVmek11XPhYUMCTAPqkItS7dwL1LNC+yn6Rrb6ptov84AX61TD9MbZUC3bPpS1EDik5rInP
faozoSNSvjP4ttXoCm3K5HqZ+G8O1cWzk50pq1JiAdYfwSwtx6F39SSxTP4rXLEtOYNWpY/FfWqK
fbV2TGbMXN30XlJ6msnw1qhHADvScFL6iCLL5hJwYs2TZluf5aOxTv5zaf1IoZ1AG67mdu9dZLUL
7RH8iTmwXuie9H97CLmRzCLz0TTxFpGsZ97eUyWX4K5VkZMv0ILpciO5EY2GvbhGWIbj8cacBAoQ
oeDJuKhLYidhQcTdxJ+8OLgmbOL7i+Xx+hNnayUDe1LMNSTg2fxCZ1a9MVJ9L1yOtzrW7dSsTcQ+
ulr+jdyJe/alrXskYPhTP8V8/DnBX+gYr9xV6dIMW3P6AvSJitP4z05mgfbuZv1oDhrL8XYPjIeV
JybHaM+L1tTdIO2lGfolSdzXWVCqilm9lA+iLyzLg5JRGb0F4E0gQVP2ll4jqQfULyeCFOwCWWEf
zrvCN7xCeAcHr1BOZcNsB3WPczLwZoVXTdCvwsy9vbVB5pBztzfAI3ghdMm2V719Qln4bBtksPVS
TmkO9N/Uy+ZRPYUSknJ/E1v+zL2Ah4qFWDpOIpgwf4/L9BpKR6IhR6rk10bTBeqSYGyW5yURjmKj
TrWOa5acpF4bOTYm57z3mcb6aShgUh5L+aA/dThEtzuu/756ZlV3cYFV69+l0Oy8UV7yVvbE9D9D
uYMnQ/bV+PX5od1z7Anh9snVfTEvlTi5P5azlw3dkH38u8A8uhEx57xcCQEK/CEY38/PIBJfNqSF
RruwbhME6QlMkA7m/CO4+eNPmOj7LWZk88zmGB/5OSNiIheF068SCouw4PUyUdCAP8/nyR7QtAit
OV15VxJFuYkVxw9jDeKRuBaSB97W6U1704y34Ou26reZ8hJLODBopCTj1bJhOhF2vt5JSfqFkaGT
iQDLwQLwzqeFBnB+YTzftjnojPdCHKIkD/dvd+uOeyg+xM9sAyCH3GMDtXwcLfF4lNyYE2PbY6ID
dtL9Jd+LYMKdsegtlPQ6GGO5vkvgNi263oYaafi6iERqiB3/C4H2eXaVEG5CJJ4xYTBAfW3bEGs1
4CJ/j4IqwB3aEIwr4rwJsf0wol6ZgOIo1yeMUgqxKmIo4td92s7x+xGrxoeBcsdIGcFF7hrviwTM
kRX+HJV+4jkmqCwyBoYAAujDpkh84oFMTXx+Rt44hSwE+O+huSkZe20SpYoKBRDWi9rnBNqQUZzz
An1Zq9PJmTFYhGa7kooA767EULSP/wBEXBgllANdypci5rycBJrd/jsvw7jAbuGQ59twsoAaypDa
YUX7kWcWwyKuayPy02qDG5CmAf1o4l9sRRiuExbaCS63/XkvKCtmo4a1raVCwRhF4MVvDoe0O9+E
4eyliPCp85Pzqkun7GaNbMZSeRDomES4RbhXJQZUgzjBDmNiJs9yYugOJy1kbWsnbAElqtqBsVNE
7cdClPbBZLi2CD/WPkVwTDGV9NHaBqSJcTo52EazFca8V0TWWTejVcfppFhYn0Qq7BGkIfDopiN6
AvxOD19jEogmkQjrwt42e9Mhdt5mJKizyvQWDmlbwkKsh2q1sPOOZYteQWQxwUMLb7MwfwTDYtQ5
hlQTpfcGTFqa0Mnybkc59lPZIoXey6CiKnFcV776YaDZ5ykOoPSa2gdhDkdkuAWr0lgbt3OSWw9w
SbKJKn71gTR5y+9yj6CYTodYAAMWYJY4bZLgOQUjN/2sxsLvN3GCghZdFls8W5H3/1ItZPOfKVTK
qS4nRodJHCveSMftM4KNs2Vb6GQPbnSJM1H4BtjSAxUidU4vI1jgDmyMP1gr7YY9hQqdSlwvKH4S
VWnBl1h4lHx6bUDtCkhSNcXvYP7Uc6l7fNl928XDONUaxdoNn+SRwz7jfy7Zj4XK/umIJbT0MrNI
n/ZtQRGfb+rc4JZ35xmf+r96QfY2TZ5gWGPZ3XmHvkWC1eQx06NaTVzBuhJhCXvpmW2rfS0iZnNe
ZXuVGMfURMVJLd0AFfy/w917fOA0CfRItAeZEGUSPezw92RInoDhGp0emLT7zUWXlDLgVqUNSKKt
2+VFZLtUOvrFMstXdnaUeCU9iRQz9NfEwe5VMiZ5xQFx0CVA7knjnpWDcIRI4rfrlF6VJjtdqYod
rnWSclFKh2901HLFJs4ciltsyN7l6Q85al0fPIHIa3++bvbsGpSGoFAbst5fgXfj1sqvwzbhnNb1
81f/ny9uAWK47TS7FkmIHR2eSj28/S6dZ/CSr973s6Ob+JQt/FXCX0KbsyfVufyE8SZ4bDxoPiOF
FYMTw2quW0fDFwQ8EPybzNcJoukI7CebNT12QvJ2QYX0wt0muRs5oodClccjwGhhAio888iOX05+
dj2riNBZz+sxc1hMrv/TYPoqVaSRcfnIyvvqJ9GB0h0I26vsHUFgxFHey4BBzPwU2s/LWoLKfkel
2+01p048tetQNDPyhwtc9aARf8pHc9HI6ywI+kTxaeraGuIWV2pmZo7BQ21aj2qUHssSl9AabAGQ
OJ2IkZMjTCo4aBNOPJhbuoWsOY48QCn4/tc0Vxjrjt51GIbj115NYRgcxzq8NjB/wlMYijzGQhir
CZUP9yJF5hG55p0rXBQNOWkDnNo/ZckWX25fu2SVZ8WiavrrP73ZzG5+3gUDaMIArD3Gl1L934ho
dWjd1DkrnDU7Mcth8wmGxt/b1jNRT7cRolgBHRuqvwWn3KU3qfNOw3hfPwYJ0co4c3D/RwJoJko8
Mbjx/tuisJBjfadmIXZwVqkwyNkaQ+rbdYmYcauUbqEsLwiPx0K39AHzcTXYray8CBl5D0kR+2im
sfodfv2b9p9WGvt1ZboTMlzVP9X/4geYryjgNCFQ9b224pPw3S6Ajtl5eu1JQgP6GENjTBHW0NtW
nUDs+92Ms2JsevXPKVtW1tda9bACuyy8ibRH2IQqyeme/99r3mLKLyo7aUYDkNn2LkYDYxr7kmj9
H0xr45HJSAAdCkxcN9nb7kPHddt/bIH8pFJRsxU4CkXPlUpH79c5VO3O8fWWpntOdDnVmPI2n5wZ
PY5h1jy7RYkYrE9/uaIjAuU7Ll0kdL9hr22wt5MVXOdXf73+EODAD0JhnLXgmrL7Y1l/140X+fET
zERSbISOT+Bi1md1EUf9KSTmEsRn1uV2n1RXTn2fRi55PvCqiHhsIHq9vfx+TwZOvG1xhg2il/rF
+Wt7oGGvCbp7OlBDtxmz1VRt8TbR3JFhNoNpW69j44GbRHbcVZK3kvlE8CeDEa95JhviLoUqZn/b
3nHiQJXLpQg2kgfhf4pwTawUKkYS9imgKfpLHJipDyml+m5StkEZBbFyVMMXHIWCCGgsBaH/d0RM
b6Q2aM5MQ/jLIktlQxbQjtXvYQESFniMPXY6QtSS7emdRbBQ8XEroM4bbC3DPzEcdJ0Xa17O0J51
K3LUO4iq/TzN698P663nJhav+RPVSLpXGsZQqhJFQbA1BvU6RObso5MiNBu4qmM2mKuxIq6kqpzU
bbPSYCY8/u69cTymqaauMwqTpYlpZFxpiGz+tGqOh2h+ZGrgsRFesupUH5wHaSh70lQImIkkG047
NmQemmlWFUjOsUolCJ7kQdZy9hGm21O4Amct5Cw7lXWO3RJZeQUNIFRFB4vOmQKNTSlF3Z0qWUkh
IZ3ayjjm0nrce+UC0SKNzuVeJLtkK2qOfb9YKqhanOIY/pKi+0WjveiUUyilbGsANE61a8+kWFVk
anZ8JvHd3w3lL1yZJMrNGCmrI38N74azv4/WMrK+bKuaAYexRFYMfLFBbXzBezCZp3PIltx2WiCv
gpHD+ykIrOrpIfcER6eLN4NYDwMsufelV+7u2K6wXOfxz5FBOcZhhd6Z92te4uaY9TMctcnq38QJ
tev1UZ0Piw/mVgoRBDFtPgqQI4S89rl06XnEMpRosJbhr+yYnDpx3VmcsPgN+9/ariAolYvjrAyM
zBTI8/k/IHsGLp4cAcOXMfS35tbF5nPSyYYT/goYkuNn2E65Zf/OKhKW10qEe6I4ixSJo+pe+7Oj
KLmN3EXcC8cZbtjfBXigHlP1iiBnWsKN4AMSOGhMGy53KpDi6+/9Ii7ldsJ8DcFvdzwnSOYitDO8
ClsrmyVuCOIzW6SXZ9wKbe/+INiUJgSutuW+ZY6j/Gfhhqm8S0xWiChhYxK0i4BGDS9dEk975sk3
XH7iQRvACIqhxTbqGGg01TDqS/V3DvcrqglZS+Juj36LO9M36BT4nNbfp3ZIRqcwlusaBxEtY3c2
0riJ8lhMmf/djTv45x5elrf6Eo0rMko04iIc7DTPciGfTTpxObcqey3u0uFvupAF9DJq1N17j2Vs
4fdDGLpjuJ3r1UyJiRMWo8geRH2ronBg7jyopRaAslWkxIobClz64hI++SlJh8ORmi87tNFMP3/x
LKCBXLPAoFLbNEygg2EXGLl3hPn00b3I6tGPRIGYJtgJM4GE+9izwU3tVfzvOcs5ZvpcjutvKUMz
HZIXhSvhG5NixZIwY62y16Ss1MJSbqrVD7L3iUUAWoEqroVei/1ns5cFpRjvasQJ0O4P/W1D6ijr
mYOAl8VYof4bwMmY5g1oRcm+1HGXJo/R8AgkYKXR+0qGRJ94qMz+KqGZo4OhbnSaidAAYLWzetsx
ruDAVsAlGEwHLTHVX5GwWZJawFRymB9+4tQ/Zy6ZOe5n98fVoPBsOlyc5EV+9FoQU6nbw7sXnGAK
TWfSYpbWLC16l0c1nPP7BoRHNowatpsQ82nNIvtEEPQek1uSJXcIXojSpmFsYDaOP1OgZidqDW1z
PMRQkQyjJ9ply5cMAPa1rF6xIFOBJdqhN99nkykopHcrkeDZcGEXEUyiG7IlqHRq8J9FeApHufhL
i31FYn1vCNDWQjXqRD6nPdh6cKYNAhgd7s+xosCHSytVyH4gDulx3bfFOVlDu0apqzNLpmitWoyp
gMVhHWb4gbxgp67RxqcuQsQ7Cmfp9bCXso+0XaCTGlDhnNXpqSJUjIjXKhgZrqMKmY7YDWLWNp3K
Fsgrp+jk88X2nRX+QSQQxo0+iJGYehyL85lWjIjb/c+89aP42qX+xZwGrhfCfPXHwH/GfwizUpXr
py93xVKAfP8Dhmsf9P/cZL2dvw887SNNNHBQnTNFZ0jssx3rJ23bug7FSaq480LQNq+CUhZlLLEH
YxWWsFdp6T2Fmk6IIiMgPw1ZqJVIlGHMMchHtpNrEn2iP6R9TtRCbnjqPzamUrbZOI4YwkIhwgBu
E587uq+d8B+8jCbmc+u2esXa0sC=