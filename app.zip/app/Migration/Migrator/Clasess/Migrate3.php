<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy+eGcTfMRT8T4NNH6wo8S32qE8mYQuuXCi32ua2YBHHsPXbLVTH9KjQxs4BCrGfy/TC8IF9
yF+PAIHgOEPFBR1cfl88MIiuEV62wmawm/f9rc3x/JLY4HiGsQxX+28/oB0L39WljOXVPcMkP3YP
e1V4N97YzuA4HJ8hHj09tEd7hKke2Q1Qye7+W1SXp4PPNQ+P79525fw4oUcySb9MYSbwVObNcMOM
0nvXgIN0/ZUzt2gNcVEcUtqPsbT59wiwNse4FtBhZmjDvg/bOO6oox0E1swsPIuvGR9ntQIQH3lq
dqbeO2T48q0Ax6mrX4KlQoH7Xkxxe61V9iDCFeVduInCeyHrDAtlTcllrUU0dL5WJn6ujn6HGdH6
CIJILJyizn2JkX6KmfWUhK6GSnxHY9zHabmbsxD8xZK5mvvK5U098TIhRBc7PPYgQLzmfoLHmN3O
i2/lvxrFdChOGGJsX5KombOJj6t/AfT1ByRLnMoNaNeLQQ/ltO/beMvnvl4EcIjfwCaMjSc07y6h
Mgrb+W8BSr/Z4rQkb39DUG9+dr2N6bNMtm7AuBs7nTZrSb6UAit9wRgoW3IcEH0z0lJsYreSjsqT
0kQxbeazpKwN7igOeRJRXv7gx2ok8dEn4PKQGmmfIMeKJB1BvNzQm1Hi/tfHfmLFayJcJ9oSZBUl
S66LFTgksbNvKkx6u/yYpzduilF/+5ELjkRQZddB/Cckq2Ikw9Gw20ZVlK8gE0CwGM1YuEdIKcXE
SYfoX6zPGi26k2lWlYJYrPOFsjPS5pHqRXyw5mBiwfRNa2e6YRjFaUV95BjmK4lPl+23nUOQIsBQ
QZvXeVlN0k6KehpCrReVxCSCzuede1w8/Una/FCViFzZSKDYCvYGKSTW59VnZz0Wx5uQUJyeWouS
cvCuuxlY3l8Xo1/f0qNeCglv92QFrgv+Bmt9Cvl7JGsuTN3TYTy5OO3VbKTcdn7vzf1yM9bTSVbf
6x99fep1B5DRkQww9HR/6+6qFTebXDUCwwwIMRq3/kbgkaNjvuz+8OEldFo6VNgFi6UBDHSSRkXz
wwtvBMpW4jxnGRnCTnXendx29oZvJN6eX3OmgWAu79KVp6D/cvSjleL9SfqVFWd7rkZAWlaG2J/Z
JaziSJDyOHeLvSL4tFOIqCq1+7z3W6LrJObtJuMw6iuXljcQZU3xp/AfXkJEWitz9198jVFwK8sj
Dk5rRCRX2W6ajgi9m+yXiAZDXRUBh3fWosiT1+vvoLJLoelrmuVdfGjmgeFmsiuC86+7GQZ3aZPY
ksWzLY9FmDBQ8mr50h0fZCQxvwYzIpeokeq9CeSsq/k6Zyf7SvpRiTR2O5oMLaKpb0dFObGFVlhq
nNHH5kTr7snVObPacYpGBAmAifNflLDf31A6W3usVknUBDAHSeIxsk7xCZzgWdq9ylpzWXpLzURs
bws1FN56lMPfhn48QH57se+9OhWYou3CGXpQx371eaoHhShn4Z0+cFbCuhojaUT/2xjfaivxWj89
XR8J51cwXuAcDj0Nquc55brKk7IR2X68TufEREhylEmkDfrrXlcoGHD7LqoFI7gNoi+v661DJlIa
x9h1Q1wtvJ/tQNRJNLczetBYRUu6an4f4KfOxBFUdDh/qP4Eu9+AjjOeG4JtxaUTsrzsd7EYXZ8v
esmpvBtu6i98jJy7KkcwTY3Q1PDx/rvvR0tpaEU8vZ26d3+c8/JO+PdIqYztiZDLbQGQoCEdDbvP
shAdpVxilMyMVFyq4RwS1XD0lQ6VrmehbQ/pZgHbEvZRfn2WjdkPXff9mkf/Gn0hqLYFk0oxIA6O
U5pW62wPj3BjkNWXKvziceKr2JxQ9khb1NUbbW0exsozixB7SJl2apvKbu+bN2t2WAicSECijIJq
uYug/gCQbTG0rOR84JeSiH0bqWByd7kjjoMtSTcag2X+rdMLR5YcOAXnVpHR0yZT6fk4BSawS+N6
BXxjWpjDB9xkVn977lWlKTTIdC4KsrnCp+D42dCPH2KktKfPZ8m8Vp/bxsNTLJ1j/WF6lqWfi9D4
qxEA7MS0m/poqIIS9JIgg9LRjo4gZxFI0GvTwXm+rw3t+z5ZaKcnq5HRLPCzkK4Mi9TPDENEBxiO
YF9ZmWbxXt62Ez4eZ/cP9mo+1mVrr1U1+hpv+SyQpKOsDEWgA9ZRUdl3QKKGhkvtGaka/AqZDI4q
OYp4QdnIHPiaMHwsWsmW2iPGpOGUx+H74p1NbLQy+cxMYWvIxU8h2ngIL7Vr81g7BdNrIM01Qvvg
iXXBhvyfKRrYWYAIvpjSeMXqWd90Wsas6vnfM/IRWlmQB+uxTmRJgkjMn1SaTBfO50VTb9OdUHm1
B+dknrj29QWhI00dJ14Qi5X6tR3X88LRB5ErOIkftAQ6HBMniFA6MMfFeRXsp8WKZNcs+7zeCRWJ
lkcFexs9bcOT3TbudsCbWGLrqpyQ9HlI6m5Pxk1+AfxDPT9SwiSwsoYyLS/ZKTpR2kgOSPpuTrpf
7W4KFXf05zm/tHcmgRtMWGmDZzZ3/68LwD8DwbHR8fCmNvmepMmUm5pAgrLM/8cDVQfh0shjOnZD
3fKpIHvDnL/4emDY71JCQPRmMl/3+8+sURZvEZzNahdP3DuXWRxgY/FrWuCgHczs/IE30vPOMs82
Bna6f+lMg6ak30rVK+lFyx3CuGcZuhW0MzK4ZR2fhPytV2Q1mfpDRs9iX//5EsW5j56mxI9dZjPY
YKqbzAxMHh60vTPy6nwUDqWIBAFfQwCPLloNPGOWyw95Qnn4gRY1hi4wGF1QJWVs8EU30QeVjeoF
y5UMpb8gm34G/5ZwYY2YaGDCUPoA88wenZYH9hN8g7Bgdz3pX7UA0oyThQQOvzuM3EkJQ4t1Gttg
DF1L0XH2Ug5gQ1PWCftA4b1V2GrL11rEqbhQDETiNGMQ8uXQAFvoON4Fb5L7xTnkdBcSnHyFClxL
7hV8mVTjQ6yAy7+QaRN8H68/nrdb45WT5Pigsz6cffeaMlEZg4bSG0QbyoTFbqm2w2ml+RYWV1Au
7thaMjo33xCh3FCQJO21PBygXZA5YGWAQkM3XB4qPvlHQq/WVTFhSvU52jyO+wkF2de0mZsG5LD8
SFaEceX4quUjKiWEBsr9YdkMDjNiHdK4a4GeASVdgHAiee8gBSefJXmNUYN641w0GcEn37H+XkPK
RSNYf8Bitfsc2lRtaOp02/r82JYwr7VP+EZT4HYeXDI+Np02/JeRhsnLffB1MmhAumbwSZ5DoW57
VUbRoU3U3Tt91V4FCKW6Vwrj5wA6i1503Bj2FGBC7DhijAsT0sWpJTBtG4F2Vz8jGH18XLW8OoWJ
kpywyNvWTNeInNJKD/vTFPeQc20xqJ+Hw8LSotyUDyAF6s81TuAJ01oIVwFEkoRUAstfDhIeD4bR
NB9fWg0Eoqvne/td0hsxcUxP0l1Z2PXdfDHzrJkmG1jR9AR4h1aryRe9X7idetqMAI1ogO5iwzEJ
yI8J6YAcyAJCaRwYDeqD292Xd1hE8g+Sqv3z0q5eqpKGs4Rce9SoPbN0NCcnvqAZsnwEjpAjCOJP
EbnmpNVJEydxtR1AwaW9N9tZnVtJbZ0XwcPU4WTt/tojJ+BMg9SKJFY26rqAfsx1vzJ9Keet3HLG
yhIcsWsE510RCsucIeL66dgx7iYWgmg5/7ngEEsnmxI2h6z1HvfdqxLT9p0FB4RjxTWSGvrLeoGF
fltz9ywyzfDc/FE3vhCzjHq0dcnJkiSbkN8YDPhnaAa+XjRcd4qo6NbHM7zf/mD3LT1VE5fKpbnf
oGqMxud6ngVQP5+iRs1E3WGqJdkKHLizuypdtl2Kr7soHngXPcZ7stVbFTKkxIfiAmE25u/G2oc2
6WcuY6wO3OlMV4P1NOk5HS5DTsftID+eYMnubjdEbrSOXUlmvTaiRrVo+uQO+rIW7lJ2CgkRTX5K
Fh8CY4j3HnOnTlHPDL5t3c5fSzPkPQ+/wNJXdPhoSzB1n/WjrWFmwdddjxEPUaEPMXQd0P7ttFJZ
7wvbobZeZsO6aAyK64Yt81PnyGfOObqaLp9tmW5auf8WUtLD/jPRKqFCu5VJpSqF4ulN7SCzzyDz
yAohQ8Kv2I3mtiHOi9ZUi4x/Nzmv8CUQZh08GMJrIdRQjRcpA6ZQdb8ft/3GQtaEsgI+RJACHkVK
A4QRdK8ePCTVPLofkbm3cqZSWm6WgtXUX4vybyLhvhDOzV4+AfC09lzfm35QrjmKLVNdN8ClsolH
AAsprAwcACseYr1A3sUzym31ZtaTSxG/rZ+rX1SQ8iuTYv4uk7J2hhnmT0xS38woaJqJh6OdgWbl
yGPUz771p6lu849QGq8wPuE3W3ChanUHeTQgkP0Gkv0RvFzjlPyO2cx5iqhCVCq1hQcKnlNbejxN
HaXjei4t/8A9xduxzkl2DmwsGVn1gEEfWj+AtvmsQjuP9Yl3OkRVXY/7vrSrM7eqUFHP/w0cSLhH
U2b0DajgCWefxNLkKZHyh6yuZ9RP6I8CR2Q5mc530S30fusEq6MOvbTFvAzCYDy6NvWLpJQXlDT+
Fx/ZzLlJvk6yD9BbPfMr9Jz7o2cok1NHzxl5sVvffaRaWtNfSGHFnYT9X4fd3uH/U1QLgseiAPYr
RuHYUeCKE9M6TvdT9lqx9vHwTMiJIKtP4ISTwX6eUdS/ETW0hIV5Ysl3zOSl5aoxj+pSmBXLQA6V
FNdFGXbhQP2jSBpTvMqeU3rVpbkwg7YzVGdflxVosyJo2baqvkJ+c7ijlHcgS5bGB4VZNnM7W0Kv
aXHS/r1YMQgvHoG5LY9UWxcKPdHO/mrWCaSNHeDwTHxKqZ6PquJV6p1LoXMnke3cHUp4UYFQ9NPL
GSXKLOuKZElGbtZte1GiEnc1qHt4ao3XHA6NRnc0gwmASq2Hr3GwQkdVu4D/5T6mBEqNx8l+vsOT
39YDDhIQsUtugiGGhIk5biVtIAU0Gt/PXjg1WvYeODxT5p96w3lEuqFoetmG/PMvUbaVaPNVN0Ra
nZsCTwQWKGk5eZVfOLuIshfBm3I2cSYD2ElbqYGieFb7eQfD9DsG6Sb3zrIS87R8Ze4l7PevWfsu
onmYiIfJnX7q5V+hHho7huYv2E7XmfPNDmSv06QhJzIBVHTWFteqOLPYP4jiyDqNpbvriwVPtq6Q
sxIZbVrF+om2p6f9ZvIYGHzv7R2scSSCGfWSwrJIp5Q84TE0/AYWxdmhIgUeUETAfrxbzxXq/+ZK
2A5suP/ZUc+hl6HA9ByNPokBZhsIvZT8n9BdoWPZykpCEC548Pdtz9IyM0rDYKv/iBDDdm0xdfa+
Szg4Fym3CbuX/klvQsNjxzw4UlLSGlXdCBcUkjaeoGe3oXUCTzXeS5MQOC+aukDcnF5ao7g9m2Fe
Pjax1/A19Gu92EGR7ez63b5ZtYHJNmiR/HgYFRrfKoOij2hVzYJQmoIZLnP4+UCUxYFaE5l4IXL5
Wk2UqL4Lh1GkYxlI5GPf8fbkDnBo97+K0wWDBhA3PVChIgWn61xXBMb9aRxjBldR80UvDzmGDd6b
sInFX3d35L6cXbRBBYEty6hWeFz0+TC939V+RL4kTW253qEdkBz7YGMRAyg1Fm5ehAY9djeITVZO
5mjozFN0I4Isz4pAaw1XCGbQnZzkbxryr5CED0JmwxwshMZflXAUv+A6H1UkBMY5I2sEFGQGj4ZM
8Cf1DflR5ToFSmXwcT0cSDq1WwpBzM/jt1eu20YsigWQ3yShZd4lJ5F3HGLy65whv+Dn2WGiEpbV
aJyZzI/4wEKwevOK6uPujcXfvtYpGxAUYXJRAbTBvjsCL5DzEw1zeAbv0yV67bXGDmP4Oq5qjD/Y
mKGk/pf4kMnhWnTqVmf8qn73+GlBn5y47j0G2wlgfG6HD2611Q8SFb9Z2NOPiGRnESOD21R5tVGE
bxKOxXYr4gA+ihmjMTWX+pazDhaUGsgwHbKb17cInLI90AkPpLc4GCgqBNqxJ9TwVldjGCs4eyzL
gY+d09t2SdU7G4xhG2wQVPnDW8dusFfk8nE5sNXbfCB5RVxKKwr97MrwfRfiLrjOZ+M2b1PkXW0R
vkzeieCYLmEAVZkaNJlf7AhZZUe01Ad145qioBF1wLx27M9OGzENPjC4uhEy7rHslrILEyLZEEwC
O5SE3ROnOzdcJE/wyyJm8jGPPRWK4enjp2dipxx62ql/J07nYIEODoOCKjlF+zsE2yepWeYUz+Cn
IWduFUtpmcHCA4uSb9w6uG96Vu0FdFdaXqkK9Lm8HOj0LVsNA85OshQx7A8MHBV+sCfiDDVADCw7
LtlZTJY7lwi3d4E+XBUoBFzoFvrXpRGcd/MvGIbf9197vPm29inBi/drOlYVCL9VTmSbBkVOKyhc
11Ebxy3I92ikDXjygB0m5KMY8AuVgXJuAZd/77ye9H51U6HgwWFZZ8+CseSjyAtKOlIz2fy6tpbx
oijKNyteJi1STVhW7RiUQ+iV5OAzODY2W55N7YyZJuVMCzG2fF8UBpuDVb4Ewk2h3okYIlz8a1u3
fbZAM4vTzmlGzG4fWLy2kD1P9Ferzo3WTYOVa4ruV/lsrRfD/l37r/sbSwuJ5U97Uif2TtWRA9Fx
P5F9m9E9kXmP6MtTWTcKSCuJT3Rb/vJ775MOvMMmnSzaF+Pl8Fdn9q8/HGcdyrvIwTMfPLO2J46e
n577aIQavEBnKjUY9dXjfKr0ue9BZZlA+5oal+sBKqdKEI3XvU8r/na3nS4iADPBG1QEveuEcsVX
QLP63gtvSGlfOXff4kt/6pzkT6GwUk0ivg0N/KAG92CG2akjX1PSQhrQXuiU0T91SI1iKc0NRN2J
TEIAlHngxnnqQW0pPv7QAW5FqSwUBIei66Q6FtNawlMW+nH3//DOwRLwlGKIEZ+ZnlwtS7xH8UGX
e0VcIcLrm4PVtrlrRhtProEw4xXeBUWCTSgeCw1vJvRotx+enFtvJqxKBFo+cVwsBVpN7FyC7uC7
yIhFP970csO8TFbEbgwDFoQ+qJHKHmUuKk7Chbo0Mi8lXcRbXW3zVxJWgz19eoWH3Etd+kYyuHpj
Uz8PYHzMKK7a1RfA7JBzbz7yEtd0MOSxY8pszYpgO3/lIb8HShdB39AQPy9R/eYWGjs4fwNxKcS7
sKxpt/8aqdq8kzpqyFoNc5aQvM5h7DQsWgCpoeMFlYtRLr/3Vah2li0bgS7WzhHq0dd686jj2P8U
TcE6z98e6Z7/W+kDs8PgWty2hjrtxZRu04kuVcFSXlNpHhHxIWbaCQJzfVajFb0qlZ29cMnzmbBa
5Oglh4AhHm9XtOBrLDuDXUSrKm7eJv1zBYmzPqH8zxNtbPn7IM5EWAxEqapd6isPcM+SolhX3baE
nB4RbT53q5Cehu58aTccML91Vq2m5W3lampdNgYW59hs3KX0je380C02vHLUlElceeX0Lq9SEtR0
8hTjKHn+5T1A1CiCI5VQq3JjJN7MoT10czcG9UjwDK3wIwzaGzR1NEDwhnxR0+UXwBfE735FL7z3
H9H3NbVkmWbtTCBW1106OFOg3QDn1FA6SUGIq8pAlmBPd/c6JS2UJedwIKfAwQjEduYbYwKVPY6H
6L/wvvT++Tn8iTvAuQNDyveVFbccJSJd2mHQ9jTVG5DK282FDVZKg9ho+7wOc93gepwkXuM8ifWl
Ge6w8EIHqmQW0FogjI7n6ykUFLpdmrqJSwcTmapcjfESFpus+Rqo4qPIIwCI5C1SHdE/MrIiPFpz
zpO1OqscGHg4Sbiqbc8BnP4tUlLliKLypzxqYh0VBP/oE7NAMmOUMP4Fe1SpjXlynTuNdXGrzjoK
7RID4Xq+f9APNbikj4f0BXLou6wuZFGHd51DsXgM9B9j2cU2DPCi/kkDdkS6LKquOAvSEzR9nm4T
BV38CvQMItQpYO8oIy+HFI98dU1cmUhDKPrtRs9zgGF3UWK4BRMyjs1sh1LGCrnWm4R3RcA4EogW
ck+KG5iYQBEtjtsCIsnzFwZHUBdtmj4+cm9krXonbPBxCqoKxWtrT4vVRPGtKp75O8swx4tDXYA4
m9RZgDrNUn+mSmhA/baTSXwSsOywAMwMjrNpuZdi/KsOfJ8OnS8JYsBQLC/l4X0umsBJl8uJgEfV
jDa=