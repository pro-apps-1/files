<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPucgEkYk9v/Fjsklo+aZFMWGzsLVlsLk2SsLyP3E3gzQS5vkg9NWcT0g6rKqKew8DPwymEu7
hhMuR/FBVn+aaQ7EPc1Pgf1CwH9N94rSyTjsd7i+R2Npmw8YM6mL3sXPVLx2IH8hb7/R6sokQf33
ZcCvO5FWnOKLos/8KowP3KIY2dhR/99VUiZkOx/sO4Hfd3yDqh5SUKU3cIOlwmYloS1w2jPShNQ4
9LQrps2KTDh54EsKVGcNHZPX7c+l0nMc1ZEw4RkrEFPCywQ+/z1G38IBgI9bWcWMLeLXcCl19af/
hcLLAdv5CfFxcNKmmQQp1My3JIge9NiIX46Ciz/JWE1qEmSTX8CZnHrzBuOkYWHtvWchClybwuJI
ue0YrZIvsHx1uGdK0au0C5pada0zG5CwiyxUBWjDvCH04DAt0m9kgWqf6M1LLUoaBSJzTVB/WA3J
JQqc+xznERUYgyH2NbxCc/z6y+tQXQslxm6tuecTfXbcwLLodMgwns/WTmnmz+ssnrq38lyqrCQZ
0wSnSLwrJJIt+6f5HL53vhyem8IZ2tRwgtihu3iT+ux649wULmMkK3xZFWljpfogerfZKKXjBp+V
1Hm5aaehv58OBI3LNE31AcleuRh/cO0N4GUw02+b/acSxXUOZ8a6nubb4lWX9G1lwfwKEvgwmmWG
mRT1G6gPUtzVdli7suPUO8MENGWA1oNhChKtHLEPvT1vPXraA+0A4pgm4S3n2pE7eD9V1rguoVID
NWYilDOHgQkCiEKFbh0cNkvi82+QmbAOKC4DBV5rpRO44QnpCdlhhaaXfkRb4hcGuznsVioq2rTm
QG/T1gM2lD69cFy2KL5MwH3LOBYnLET3WvAC+EEsmmgSht2d6pZpQP5J/3/dAF6IfCtp1t0uWs5k
9wlmDdQfPMtJbWVuqQqN3waoS67Jy2z7gGhULHSCYnTHekiPqL16UmJd1keZCRPY2XhhcMdRNMr3
qo45dgfDWP82K0QhWh0f/DCC5TV3ziPD1ncCaurQUAJJlpzYoN17/um+1UdDHtUocz9BA5vGuTbA
stdlaVlHYM6sUjV8bv0JfzMlgd6F7xNW05BI2cZmKF3QHMOs1vpsHvO1s46LscP7RVYkFoJCju9t
px682jh9Ovhjedw2tc1C1Fd3Z8MyEBQ07yoBB4PFb1KFG903UX/TwYc7DFlei764/RDuGgEhodR0
o6H5LwSjzrlVrU1zvd5zmuaPtMJEqFs509vTkoXOkv31sDaLDuYPOAoMgPq9ifUoeYxMgmDzmMZV
WK0rlinvd4jWvi6qfIJO291/OqFKO9Rwm1kwpAaIBvI9ieYbVytvdn75ElbciVo/V6DFMb9zG3Zd
K4uxexPNm8fQWrLgeGizjBizY3x8rkn6UiS2Qp80yK6//vifRxuAoz3F2TlljU+CAl9QAh4JUmnD
BGsANvVelhYnySZxWmKeWg/4iWta