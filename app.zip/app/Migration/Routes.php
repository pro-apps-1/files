<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsSLFgk0oOACNTIhYAdAu1g7of2mM1f3FRMuXoyoOJZWJhR58ABijCN0xakavzGlfio0WgEK
3sTZ/30fL8t9Z2ora6utmqPayXs9IjesZfaJgnutBjm4d/Ud0IPLsp2JawtjfpZzavYUj04hSa5E
UHu4bz6hw1ylJD8uBfyQtycDaxyAlXUXvY/DCgOk2ePemyg4V1ooJ2Fr7a+dWQmthWBe+nyIoWNp
lr5WqUk6eDrHayNFfDF03tKriLW4Q/MmgFApnc82gkQCyqV2yCGmDldWeDThMfIp5bh2bDi/6f3S
Qam//uYyDBWs/lTBGd4dgN+Wp30pfuJUxc+vOFJez+IBjlUyN2CiqWzI2IM60WCc0gWDJb1fHTVQ
UYF9nEjaJajf4RcZKmKzolV/3PcXESIlEygTn5FjeSIrqce37WBBVGIHXdNM8WYPE67/bagFEjj3
tElhOxofRWCOAC9aDVJAdsuRLKErvHHoN7rZC5jTvVWii0M8jGIW5DHNtjKaTIK1+MJe42YeRx/8
fyg7L0vTjiYPy8DnLO1avI4xNXEGWKm5O6RkPREJ6HZE4qN6/Rpf6DtLN7JEQjFh98pEwVQStQ+D
MngwHkOXhD8JTjyEfxUs56oAnFqalUS/GLduOGCnY62W7RnNa0nfOxb8sbStilQGID65xv384o4W
J+tbH13eVUELCYdAbKBQs0IKLCvnAe6LebfSdMUg/HY3Fdq8bPFhhA72NFLdbuOfd3/Gg+XCHawb
hHMzS0g7ezwkHhC+RyR2AOmDuTHcIBeQVznbfnMwnEtKDKzCyRTWFeDvE/htNGR08ic8sgGr0mzY
OVv5KflYeegRKjYFO1qrb0HyDjmqYO25FGUkOrYh4yNDdRyPLkyAEKKbVc0NciYO3Fo2Osiu0LcX
lxUVADcHKK9Lo0hJMVl+fQ6P53VlCieYL+Iw4ot/6p7U5anJp+MjkN+jpiUDOFbnl7WwCsQZDr6u
zaGl0XEx5SRQAiXFjP9hpzjVVaQsPLBlOgvuK4eQmz9Z9+MpLZATHp7EWx9+d6SQR2MXiukspcpt
l/VZ6zeaw2h3p0xvGnAsPhNl9FoJXipPXfnXdCEHo0NjE43EP1cR6QvR5I03RQ64DK867loNlubJ
AwRfWwX9RF0x5mPGao4xhZDObL0qPlRgn4+njwMvqVHkc/WB2VA1EvLl2+lkQDn9VBHpgEXfrhcx
EtgmyCahA8FYHsbPUkMUMGHmvT2Bxi/xr2jWqma0euQ+btsIac2tnugc60AJkvZgFJE8GwmVgsJL
gEeapr8d9TIJEBidbMF+i7EaDYfxTTkimubS41UqkIsAllwCmcBC0GdQje0RMDRsA8WIGE8NGgev
u8c5e2YPDGf93GDDu4OJR4vsBtpu1Mf3ox+atLd5HP+FaZ5yukGmmuV1BowOf6zKrpv4h64rSWTB
CvmZsscmWUqiuA0C3j9mqzca7/AdYRH8QW==