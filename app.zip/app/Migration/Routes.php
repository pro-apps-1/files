<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn7DpH93XZOb6WnOCKTlt1dlfu4oV50k2zk8Ok3rQGliKvu0UbMzZUeGiMwYalmMJGnVM5bS
GPqiTPcdnYPnE5+LE+aNqqw2eliFukJvWPUjvDcrWSrbycjDWpatlx+3hGRbwcryqjstfL5oXC7/
h5hPizxOFLqkxLmmSjBeOOMLQM1IQR5cKWfrv02W6kEGKc6DMtQeI/bkfu26iZRuMBwS488luO99
H/KH+nFOSn4NFxo0SwOUtNThG19P8Y1kIqsEvIeADpHZv1ITmSJY4lsWpyC0QDUPit7OhUqMnupc
qegANFzWXIfAljWiN0BNhi/IRbVsopGNTUA9/q/xn9wzf8eYJybFu83YRD3DQAjhauC5VtT/6KhY
kD6VxFqQgxohlschqk1bDQ+R6sHpXsnZH462Ch8PtT2SKPkva6HwuCNDPQTt7WYi5Oav9RZ+Ev1s
IoAwhmUhF+QaJom9aj3fWDIKBShH2e85nikIZA5MltOwymg1oC1h0gZ4LzxMZqPmL4RdgsbbaHC2
vGXdSojyG7So6A2MYN9YejYQ7GJ/w9nNoAEUgupQjai0CgLwKCoDUkw0gksJiVwLozFDf5pItcbo
GnBQ7hcp19buX2mIrOTpDyPFm6TsYW2CJimFXl6k5+5D/m7lGIiNKZdXPD2hTHBoVOuuotZChmU8
JawvH6UrOtgtQKWrDGITpyhX5OfXkQBW5A6N7PhaqbWTrKOAEQOUhtN5B7lLtGsYoAJDvwoE2htA
tf2gWHe8dKz/nYNPp/+bwQYXKnuRBR1QnXCI2Q5UaVDa2A764q5kLvok75BY61HHJ5C5/pMFtOpH
6yrBo/TmUSZT6A9Os3zF2jxnkF5JkO/9Ab6s+UpO/qAPuXZNksGQTxQWpRos1zEXqVv7GMuiy4m9
VzadoZlLJQP1kLCSaV1DtB9h6bB5J00zE7b9P7DSplttBIIK0tcV3P3M0ma/6lt7zjilbxGKSEsD
1wrs4rJ/YzWZWvPnWOYNgIaYdMxYbEaux/ZlH3esGBExtvEVrpzY2kYSAG4owxxuRmSuViiI/FpV
MlFs9aiFmHUtp0anVH8xp9nPLB4bpfsIIIn8AnnglQfUf5hoZb0anrRVqStF3gBnaLXQKeHWTX19
FaTN7wHEB3FxiH1XD7mp7rB4hkQL7v8EgVbe0qJnAafBC0wyJdgu10qjFfzdCxZNB+IDYoeFUs3Q
kAC/gHu0/OnjkQy/giWEmyn1V4qsHIvhmN7G7fKuqqBcHmsjQk7Mu4wde7gtg+DKpJI+qBVt2Bmh
8MM3b0IoCm/o9aqLrudML+00281q4pItWTRThLLzGYxnD4AUyIhX0TDytLubdTiFP54+z2T/EEBj
7tbbv14WITuNYr3OSnKOZUWatsSlH2mxa9s100PayoeSmQ4wcLaYO7Vw5UcK+tOEeVbYR46VoMk1
hRIkMYsldgZl8W==