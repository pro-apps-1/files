<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpHFGh8k0BU5DuxNaGjBIEOCe7WojYeRhjWcYoZe2t7HGceRr6TDndEXoXIQ376wlt6lg9Uj
Xn5UO6jpKurYG8cnaIUZf4AAgARqT8Q3oLWhz4561BljR0Sjt1hQ+F502gXGDjnRXRKIkpW34kuV
AtTAWgAdHelpJce0z2B72M2oRjKYrNREDRwugTU2EMyWRnapfhZatWs1GlO3TNTf6RnE+Fsw8HCN
OB008oZg0LAej9PlIhZIvUcS5C1AV6QWVxJT3J3ZmUmbimo8G62q62zKbyaaO+fMjHHRVVkv4Cdn
mQry3VzjwkwceYmtWIWRup5Y0ySVwE3Yp4TsXbxBRuK8FoB5J1TCUMdXTDKJIEzaIb2cylXmF+xJ
gFGnHT3wF/5gJIzJtrlDVKlFYostGgnaa2nXI2bhg1zaO8MHqnmqCiK33V7PnuVgFf09Yb8w8wS0
7wiuDbMOcFnqbmma9lM9tL6PnYjgH8/8gVf9Hv942oc0hXTM1D9uZ5IWHaGfCWw506Pd1hYjBsds
fzukINLUIHKMVXBbQZ/icbJ1DO7ieUjZagekdbLXL45SmWQBkukkb+tv2qGpN3DRai3mxIp8cR43
CR+N8ZP7usbyqLqIN2gw60fz6CufbH0N4i0i0KPS6S0b56X6nQL7jel9ffwwl3eYFuh1GLs2XPO+
wkE23EvrspINcP/makmZzIXNt+yAVWGZR9Umlp+14j+wWDdNHUKNqLSorywIViLeyDiDlClNvksi
jfEX1WzoNFPSin9AurwwmxjIiqqIbWQcxRku2mcmhiXNugizwruYiQvBN6RDHFNQlFahunpo63dx
dwwQ8mmZpxdBhZGR8BoDUeE9ki/YWYF0SkPmSEXgOxS2JxDtwAucYe6rswrA25dh7nWFujDbuuUY
DfcLAOfjXRwllsTNy7+Y+XAHe6T10hn4pkbFG/uz0StJ1B5fzC5OLLWL+D2nkRChEQe0X0cGa4iG
iOd1uXII01V/c5v0OCBAagr4dbjPxZ0vj0ArPm81/llzENXdYb0964//oxTkaZGEKHyp+2B0+tfS
XBlE5Phof8S8r4jtCn+FRd8W5jZqcpzDE1zYIifYDGLd7CnoqPC4wQNQPK1s2psRvTnTgAG7X90i
HNUrh4ROl7dg+F94Mbqb1mIKxzwgg6M1+zwGHizAywFyBZcBbTMQpiT6EnivquJagsqLKlDl6m/q
iJDZ6rX5SdeXl3dS0zFWapUK+BHw7cHaOUf5wNsyj2uZnlU1Dgnq8x2JZyX8dthdrUF2JKkoySW2
re/qwHy3S6QmwvA6Kb8meviqSQg3PPrgHyaolJVavTSrTWBX6LbunKCRzxB3m8ZXbp6vriSmv0yT
9eOz5/U2nj7W5N6mhugqNapELIiGUO4jIkADJvc2W6ZRgA9FCsc3hvjI2AdbKNjcU3kpXtOfOXjU
+oZhFI+1gXkhlN/UHw4bghMl