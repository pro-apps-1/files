<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp5D83uh1fanCeor7LmrkidScRx2bOduwvUum1peENqJ9h3wZlCkkX2CA2rsXb9xYMKvDqmp
yzfK2uFYWJ1j+VjA+EuxOcp88OXir76bZVebwIvo9pu8El52Fah+tMpXE9pxKIb4/Fmhnh91RQJM
hmcsBvYPp7uKmtTTX1pmBeApDGi3bC7tHyl/fRUslLSmy5OoTnhfKhthPEJTtdwi2KxzZMNCftK8
kCUpB0NdL8Y3jUKY/Os9qc68Y47N4eO3GQPZz64dw5ckNa472QqPOhgG+nfgAXpiracUdY+gih81
j8ei1jxmJ7ygTOmKLFZlN6bctTqYNi9PlD3miy9b+qftrfKlE454gqNKngF4+myVJghaajpD00Hs
TS61cNrscsw9pI8636cfeg94o9cU9drSryO4oz4CeupxUP3pwq8zNez8jb2FKC0CkjDXlc2hqfOC
vZ2yi0O8mDumH3FK4kOBulkuaAFjbtLnLjRd3mi21VHZT4VHQNLA7+7ELlOhwPrLQL2Qf826YQlR
XOCcnTfNuSblr66F3rnHyMfCa6JqiQp95yWrJkCR8D3DiH8w70/d6Jj/NnbO1KK7iYRUeTdvGQZs
oYVanL8xeyzaS8ozWCvNu8UoYjlMX8siO6YEv4vqyzuiTrGOHi2CzKdnV7xmX5ElcB+RBPCcvMNw
QEhOb6W9vTAINJiggjKzohqKHr2k8lfqOlcxUBYb1G7VQcwZCbckRewLnYgeKf+l6cNHpWBQUotI
mBVaMbDRaQnS6UcabKa3NXx6CcmJjk9n1te3GLMJVFOk4Hc9+Cd0mGGVJEdW51eYFrX0b5I4lJtY
CN+ZszbPSZd4rR0sJ+8NT7qzx2xYQQghONquV5ccAfLyZJuVKhThklsbpt2exZil5Ol7qq56/Iuf
tzcZlp18KxWkFNXiBshL7l79qav1zwM+iV8CazH04gG146j8CCjDzNE3X1afIDNBq9ZZvPv26qR/
yvNTScMhShg996xbEgRksF8w5cjBXVPo5HEWIkM7MqKmied7lsoQ/shCCUmbjg+0V4n0Tb0gMGZp
tr47ztWpmJiCCfSHPTrOjRcuCXFnXmCmOfKlQy6LaxTdB69nV06kk+jZByUlKMSzgWOqTk6ZZJaK
VQFJtIyNO80eqU3huPnCNPX6wZrMXomDjC1GixBTOu19p/74U5Xv/MpehUiEkwRGaFpqZUwf1Ft8
q2R+ftOHlUM7shkkqK02t5j+KaX2sMwnMIYWjRcyt2tlc09Cji3TwITDg6JExm6M4xUMQMyAD+SZ
eTS3s7CMXb88LQso7uvoNHa7m554kRFejaKjxvosW3K7N+bRoI1BwDK0RbDElcwP5t/m7NDiU2dU
ow5EXLA1XCTKeI+GUM0PKKPO6oDpQFT/8UvBEprQWKmK1w1BZlJUi6Uww5kbR4ZAD1j4ux7kPy8C
4nw42L9SGCHyt74DUAYZinv4