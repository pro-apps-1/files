<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+O60f0Ss/QdsSUNimTWfmT6SdvjfX6mIfku2IeqA15gyww0OCRAKBzg1Hfsn52nLvX5u3aV
yerAQuFOkGw1iQpjcRYQQzjPW6pze1hVBk99PAp9ESD0XGs8ED8GoWExvmar0VIvNNpsV3gnK7db
aQqILd1w2LPMeXRFfwbkhrJtw3lBIkYrtmF60DFCOISRVSaCnaAA++5NvU+FO0mUDTPI1bDNaaG2
+1r4OvKtiA0ljuO5ojotWW2sj4rnJMCUh2L+Sg1YcngZVFhp9aQ/7plPf05c/JRMphmPSxMh6ZJs
f8fT/tIQQOMAmi43SVEBENDfadrGR0hyZC+kufkDuOB+urU0i2fg5XLpstdlB/0tBDTqqak13eMi
UV8/ZF6L7PYkCMfyf+F2MbmwDBhK5MVUsWG61VE6CYtzOLHns51yBM+WbNgISsBda84OOYKumBVl
sHwTRn5/pg3vGJ7xjw5Cca8KpVUn/fLYgag+D7YslK1+XygGQZQcU8zX44jdmEmY1lrqpGxq4cvK
MBN8e5w2si7DEgBBO84Uxo0LLRQQ2AoXAQEshvEwfAQpy8s8rB94Ou1nu1MMfqLVFp7s2M3JWvaG
irFFBxDvWRnY5UpEroVWuxBs0o5cTQY1elD1zmfs1a5/+Gq6Vns/4U7MLayvxl/YuOYnGkuwRcLF
4bshZDTMwm/uysP53JWBjixr7nRFIMWngtX96AZ8RmOrbxVNQH7A0WTrdlm6Cyxn1Tej9UxRw6UP
J3u9pLxdEnpUYJRVULLImtidOv3pcNGwCsNpG8HchAqIvbEp86U45ETwr1zyju5r57/nRmbCjMqE
dhoYub8Ab4ESq8yBu/jd8xhuTBQZLLd3J1CA57CcsxmlCpIpxyxxkm2MXCinu9i3GHAm/4QyQYJ/
faiUdrJrngFWbQy1QJldXEp65DEAlRtVw3KfnG4NWlfIyweVXho20oj6c4A+K9luppZWU6wjpAz/
0h/rhO0b8eK0cQFKEN/Rf8iQGpAsqkbTAQoeIswbplKPJnRiL/t2avdlGoR/h0rCRoTBRQt5nSMv
uoBxUNCvTdFfFYeBQdMn40goqdvK9yTWayg3wonp5+dybNsVRbRJlBzOmBr1S9T2hQAx6AkUJDC3
5vZZZwAlnvL2tYa5qETp/0XYOt74HF+Re7UoWWrlUOCG470na1Z6KqQIOOcXZiZtnjmskWTlhsy9
4kyJXcBenKeSH0pJNVgG+Ml6vm4rws7glXGPblvy7UeoCJtMRd6Kww+wyC7pTeve5wYrHPHnkv8X
eqIrIciDn5NilHzEu3EZQmhk2cqpq4n4d8Fd6kWGNBMbjnyGHa9vMrNu+GSJe0t1m0JD8TB4btGq
hKyr1oSF3U6zo+n1j69AY6G2XBTAi/GcgZJ/Uq+H5SU3CwfHDnWp2TekAp7xgkgZEbAHJ/LbaRYr
gJV9Natgb3fyc1cQ0QHO/JwfKxIbhG==