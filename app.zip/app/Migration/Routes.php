<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzNRt0aKT2KkuHf9AiK5QZku7J8/QoalMy8kNstv+x4veGNSrRBNOdGm6+ZLWt6G8mhNf5EP
ufokLHRQCCFcYznWOx4eHliIEAQ91nUBw4tDc/lXeSqvdsIZFhFih1z6RkycJkm9PFr1rL8KrC04
b/ZP5ytMwA/TbymcJGcxVvebyvgo6MCzoznecd6e2jEo4EN6laxd4ud68s4xu6wf19wu9ws9YVmW
0Ih94lmZXFTgzc6AQv5mr4C1eMDnosVcsKrCI7OKAnTu21puFx0CpmxcZilNQ9qztPoT02OZitZy
uT9AC6w/dx25p6rEA3dCTwHMYcohViJ0AR4L8hnMfA2bNsParTa3NPkM7wGQuY1x0uhKAQUgZ54r
Cm75j+GWG/aQMcKDyH2R75DDDKm4YMKSg/SV0rtCfDtJ1PhPeCEUPzvzy0CHubOAesc/MztGzZju
zf0UGW73WZ9cZe1ntB/ULg6HstBx8V7tWTy7SLq+qRA9Wk0XZM2bG/4tdGkI/ItqhEamxidQVEDk
8UgkNQ0e2iCxOb78UWdpyD9Oy+e6txGGHVVp+2Xh1gsHHpy9hpTB6UFgWBjXfzsnluf0eF0G3lQk
8CuixXEgQFXGFWt/hk2iqgsBMisEmojL21b9gYGBTDd5ETsVzkj2//pTBxMWBwvfNMk06r++zt4k
WNXM1GzuyfGg/aSblVD+jOo9pfhLrPfjDyqN2qGMas9V3vttlZ5rhDX0edbyYosMxzifV20D0DdE
qUn6w5EqThni8LNF+zvn2pcyWCvOXV8MEGTBuQAkd8VFlqB+T0MwSKLxek+Lght9YyofSvP40lkQ
TGcLHmR1Qu+N6hQphg8bg5hAmZQH4ezDufRnpYUjFWJ0RGWT3A8FPwCgptJqRAHqw4UOheckikrZ
xLhaGnJuN10QJB6EBkZXyOz4bniMiZdVjJOr79O8gMJsRX7m17N9WNphRdEaacxpu627jxkEemWj
1STH8CzEiE1a35F/rNWJdcYMvPaEnJXgFypiopI1NLzsZ4vTXa+cSlkFZAXmVPtXzmOphXK1yGD8
l/Jh9cAOLerwieUmly598wO4gb5Br/7vj35N1FdSTSz7QIEufZZRjFqjnUyPPmIauctptakLTCIM
D8uqxFeHZYhWkk6+GJvgnf5kkxu3ivUhSlIg6fm/Zwf1BQIUXgiB5w0fc1vhWw6DDQGRSJ3Mc1G0
dFm/EAKLWQ/miEmTlsfaUxhW9iSWUjU2y2XCqYuucuf7dkrPAC/tN84HMnukx5M3GdU8l0no2HnR
u4uw8GjNd5AEdALOoTwjFNatbMQCu833LK+/ZrE3n9nStD2vPKRZNMDD5jnwrlAmSgwlNiGNpKxj
vlUUSwsETe29XY3dGYAsx5fllOlRkVd3qUEiyCxEJG9aeCXVL23FjrYdtBKuCYAZIMnt8ozRu4gl
XhDMkXspYomHe/anL6uIcqNR3cX0qR2O27gxKB/O80==