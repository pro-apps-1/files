<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/6vo9xkAZ7HztXTlMbsw5bCMG8fiDTS/vQuJmQmTDzfu4FZg6oQjvlRzvMlo1cF9mq5a4eQ
2YNr44NRQTZAcsmwWYnQOxvdXCiRP0IBjf2rq5svjgLIqZVXNea2Z9ftjUdVbMYojSWkoNeexFsX
k2cn0PLF+zbcklL6upOiZUJTfE3QoRD/HN0OcVuwnJlDjbQscHtfiyiui2g3TruAUObuE/NLkOzF
zg2zCtf5R+i5aXKXzTx3Yc/CEraiO+MVsjvtXGmX8x4qZZJMw1YKFlZa7TLl+d9uWOMMt+PGbaLh
iumS/u+j/cB/XGdC/OVIV8Way6PrY88znkKr48X9hfmS2z9xUVLBNO4G16RqrbgPldTB5OFLaykq
m+eK2/eB9mpaoLR/mBoQ60Zf02dAyiIkOXVjnPF3CznoOnvTnIkQMcV6nKlgUhQqYUNPEmIJSJMc
2m7jQVJdHC3Q0NXx3vIOXKDj5nM6sUjGvRe88DiDGTMaQFuNN99rwjJip6pdnMJ6vpjqjyk8OzCa
j2vvwJgtI1MmuJ5AZrMdr6On73KDcWFkn/tZAiSjkHrnTptgaw2MqncRmzGJA80XC3fz/6XqzZbt
TW3Yk7vEsL6w0XOqvdRgYLU3xK6wYGbMKSAHr6Cc+Ml/iUmrk1ii/QjkRRQqXmtBUAjTeygyvi3+
h9lcbhA8e7Q56J/ZmV7xhce866JP5i27RWfJKEY7CpQnDJ1ugCESU+iTfUPHMrlts6jt/BhdRRad
zE/uJnfruDm4uuN1/MbYsIhSGi3Yx+hBCcgVAdvw/S0YALlRF+L7JTo1WVrcjH71975HxP2P58w0
JtQeRzzYDNN5jQCWcG6zl7fNnaW7iy/Esp0eg0/S0VFFWAJrsH6OYX0qrrEReK2R8f16eFzpChkV
r+m1sSImxy90qTDaAeTQz2+GbJ6+dCXBlHOV1OuWwQeRVBe7xIPnmIpWigsL8m4dR0D/JPtPkkp0
AbajQAYVgT4PpOrNdphAy96i6OZM2IZHAKUrKjzWE/2m6c2nDBg2TmcVi/hQl+Cg94OQ8uL7esd5
eCc5NcJan8Ee8YPrUc+jsQe05dMjV6wc69mGHn5rLPDOA39OjR4M9an2R+nFP8Xj9LcScxBsdIHJ
rlduiPnnszm9bOm2T3a9W6ize42PsLWQmkOOg/BP0AO2XGKPggpyYQ4lIVaayFY36JcW9oi4AVsF
sKc8IavMXHXyz+kU6B5v25Jzt5kVk/y5Mtu9LjWV7Lk5T91vaczGrVjx4M6DuP8RrxxeR7C0keyf
iSYbXVQY+byioTBAaslqcu93LLgByJIn6ZAFz6qzitcg4lCjLUv0CNSXc1Jafy52PfA+7z/JoRDr
HvCg1ZAahskgeI88SX1Rvh8nVGMen8mm5Z7uDED3B52BKpeYQAZjAZxrZmpRpw8GUYowU2eOgbHd
7GzOI+lymMMbHBH8bG==