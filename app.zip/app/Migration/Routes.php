<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyv9v5dl6jsUzeXnUZxfzO4J1QdmvoP5SSmEMDpQvXZhHjL9eiS5HQ+VgRpIcHMJeQvVdjCt
aMf5sYDFt3S/a2tr1FrB1fnZhEmFDEJi8LKXJYISw1ZilDhYGtldUNYjxW3vhvUk+SP2nufeWVwI
eif1b4gEALrUL7bgtvOvb1JeNYmkLE0kIlP86piXbJY6Tpi+qCssjFOf+V6dKl6EyOVeVfWatbAV
Yx1rMaT+7RExDEhi0J2NafV82uprXT2GvA8uVYpoY3b7mRaD5DgPUrjRXWLURi1hJ/hFlgVBVTCU
TxYO28EYXiAJ1b/cECyeftKpmRRMZ65Gi3jCgwClJEvUCYa0vw7kKijQrjwZz++1ZIH/8PleY6oY
mpsGoCW9/YJxUmFMY3kfR3dKWHWVlZa0piWntd1ANS/q50gWvqVIuDQu7nl9qJyg/gpLJV/uQ6Xe
qqxnlkrgqfVy06pxWgzw2Xxj6H5kFeYzKtlTKqtopRWbT4alluMk36kGvbJQobJEqrLpoN7ddMUp
WWH4HBTDE7VAhjU8SpYNesz0wukPS18ZWSCsGyDqB56AQoplhHpg8clI2Tr6hR9euhxDmXy7mtiT
YSGlvMRoMF3iIGkMx6Ndr7oJ3Ljsg/U67deaPwZiDfdr8kve/wRFpPfzgoTbK8MxX+REgMqUiBoj
sSMhXC4955yFTmVyaO1LR8Y7XGO6s3xc3zA0Q52hGf+iAcmzkzGzswCQf5q0shYGZy70EvSAvy1x
yA/RRCw+RbVY9wNomtjKqoWfRQ0bj0oZM0ubHo9Jq5cht2zCcQWdATObe7MfsoqJdIohc2+CzgWA
fsk0m7p43pFfB6g6WNcvmgWLYW2GM+Jwe4qX1A+6HEfW5eWIv7fFZdT/gLxDlYNZLDSZe0IFBMZn
nbIzONjWd1uC+ydQxriCztyeOuZJrWNrQTcm7v/I+UvcyckXVhYPxg4q0eNBw3ddT4MT+wnppNC3
QBJSbeD/l4XifOQyH0O8K8ASBrf1EV1VfoolN4vBWN/hCLkfyl6dbWQMaJVI6fqib8aJmVplSisr
pRAc7xEkSOSPqEFlbz4zFbrjf/endKckNgZ8j2RLPH9Y334fXPzGmXya7/IzY7kFqr8zTYhFLuNC
NDVDY1DgFfLamaWx2amXvaCEepUCX3dV7DBwGzgaPcFIsXPd5x1cuW2chRkrQRC/xErtPx/FrmYx
MbkiaxFME8qx7EubYhTl2jviqe8niIpOLpsFb398G8sd+Hmt9IQmPjvDQacgr7h5isBr46JZMEuG
blY3aCrYTgFQD27Jh95ZT0LbKjfE46KipFeYEi5VWRLrVaTSh6o1OQMBfeYLUZTWfLY3Z8+i3rS/
IbiHpBA3ZKh0b2tyjZgXpXb4j9NRkEW9H/cTbs+YKf1Qs3CPmEfPbiMNlXUdchyf7WAorQbes7jU
vjDo6bRu1+rfyjeJ1mZx2NUPY6af7RqSlKBQ