<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmtZTC8bV4tsC2BXuRuW0yQW/qLiLPhUhgQuNVgZya71Fzbx8AX10+rW5HEXHIQiFacuMXMZ
cy4AD1eVWH4gTILRAGst/30NgEiR3OZa2VCuOYyoDTzInrqxgZfaa89G/UGwcxXmKZ/qzPM2OJ7N
cZy/vWFOwcK3uZGc0W88j5hMCrdiIsP0kQVRgIejr1850MOBXdmtuC0AU0wtBQr9Z7RAtTN3w+l0
z6Ue77xo/g7NWZ/QxQAskwkdVvwLLQskzFtZRXD+6Z68SCA7rRq4bKjocSbcnAtTAwZZOPNkYqSQ
VD1hdpPZHDwl7oP3ovDCoVFpoabfVnoMq2RNIB7nlx+P2ebngkvx1ngusml0lJx8bY6ytBc92irq
v7566IPSe3ki0FTJxgEetsQh4vOr0KoCljY+fgYk8T7ygSEc+O7HTXhM3emJOFraw7FrNLMlPC52
jphvBSx5Dkn72cTSY4DiRFmWEeb8B+E3aVaOpTgkOlK1jpE3EqmPjco24J0VEef68ej43I3S3Qix
t2RHHrOxS9doAC83TwzAo7Dd43KSv3CQkKtclutp1ZvcCnp7urEsXMvMJ9kiuJO2eS7NE/KHnP38
bIsq+mGVin91wPjbuNyhy5Ij21d1lExj5UyO/3C0TDye8AX+lqZ/pEzb3jMvjx+q+glrDTBQ77go
0KD+dydXw+p3Gj1m7+kQcuOLgp5IzaknP1bfTqmKE5Id+kP+flXayo3i5uXJO6hOqYC6A5cANnn9
tCblzwP2/1X9StEJ2TzDyWOJ2WXXCT6mFl2dIoTMvr1wHvPTyDa3iXBadkUzdIHsQzDSdPbdCPS1
f5S4WQvfLCU7lWgGyK09OvBHdLxMOqk2hau+3SLSG6EZmy9WO+FNNp4pTy3okFkyWqn8Kr2tXFHn
y7lKtFdtkSRPkKa4ZqlF67MqGF8K/S8r8fYo91MWMXI0MruI8P3rY0PH3V8nxIPoIDQDaH0jwrUJ
uymzzth0B0isFlzsy/cITA/oP2LtzkWeLhpq3ouKhvJbexvt7TONoQGw4GWbfwGZaYf4S/Ja4p6a
z2AuL9salxqRMccBlB/qMESDbOJvMvCmsvsiyPOHIXhxO609XmdGMoo/Y7JB0mgGzepODpLfJK8n
tre3VG4XqGSgyo7WlxTXWKzh49sg3/ZyMFBv5sX3glmCL0AjlzlPSO/Dmr3qlMywpjJU5UXv2n9L
5kXo1Frb5g/99vekhqJwWPXjNdsi1kqflbHa0bY3v8ttbTNGi/pvTVluUmQJXpQqORMa5Oqqfg1q
lCYfaPyVLxa3zemMeKjZ0MgCHWhsExI01ThzSTHBGOFv87+1XHrPLCLiwVPsWZtgd/Dxfn5m7YKP
zKuOuHX/PMvFiRYxmhscofmUIYUKJYYOOZL0SaqQjF5U7W/wpkxI2qy9F/n+hQ9DKQNR06Gu+bXC
GjF23orcrJ2jJPd5UGKUP8+7DwqJicwO