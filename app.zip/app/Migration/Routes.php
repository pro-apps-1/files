<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+oI0ByxJ/cmmbELd2oMo9n987pRxfnvL9ou4DC0puk9a2P2drNDpOUIRm70afC/Vj7hhC6i
ewzRvTEu2uuPFQGdXyiTDbWV+ty9fos6I3RggkYnRuht4OZnZpsNN6uPwOFrkdPoA4WoCyKRfxAc
yLOhipINi4fOTbB/jQ03oP/6WX4dgJuO4JRuxThKRt2DV6OHRvD3gVEgRsMOVKCOX2n5H5Sno1c9
iuSRIE7tIspCL2vUBLofMikDv30f5sMtnon5t4A2h9bI+Gfx+6/Lx3YILd9eW/y+OxLbb0u865i8
TIfWNGEnIF891/NVJLnTW5o1IBbkfa4v/r2dQMnkiUdOGL6YAJroLH15o3ydeFsx2UuFeDbeogHd
na0fTGn3b7B9jlSIhNfFka/yqW6ufQsJOULjquAO7ryJGGYB4zgsdu1lFw4qdPJ6OGM4/ccaegZX
vF1dOC0tcMyxkmFmb7fqaiIH+0xLv2sJzAQMysSKTzQm5Eki9vXc78mcBf/SLmRzZru7kku4e6bT
IaxgKxIICX2yUlnNgTl0cAsSDqIbaV0BQNQ/lWsOKVv+D1ylnl0mjb4w4TqIWaBpBUdOSCpHzOGh
+GYToH0dtay8WidcZ/uCSrvXtpN4qfallE14rPpI3V5PCbywGfjMMuAidGQ+mG8NaOHN7a91IIAP
m9AdeH5iahOBNw7Hio0or3aaABCdzQDmRtu05TQ6iOW0ULI0nPzyU85k2eQeAdFot6BqfVxst+r8
P+uNtfyd0xSAz15RE9NF3LULIlIpi4jsvEsjq/oJfP0mOFrFOu6JCGhtHW6rwwvolLOVQsf2T4i9
kywJxJDlufQES56ifaBRfTWfPVDczfV801ru1vwddJUxndQb1zhA+kNtYG85llzkxnDsSEUjwxMO
tsj2s21ar/DXMwFIBujPI8PI95mGCzP6+O1LJjgyKhSoCtakozpAy9/QeiqVh9SQNRYPyg9ZdcfO
vQ9C2HFzT+6qmS5IGSzP6LbvsY7BP1Y1HPCir3imYv6lcGvfeqbp0IH/bVr5OEXfBDWUd+FfpW+E
hwP51xnchAyVgo+UvbfFC3DzYRELg3/6dQfnPSJaT+qPHecLSgs0zzSxirKlyr9wkytuO7XYlmJg
sLJV7PpnCmGlO2N1VGYMxY8pVK3RHT+b31cRgRzLJ/TW+426otKJIliUY1xwDueOfWd8ShRXOtHZ
y7KeYqf14Soj5X4MkPGfLZZKoXkORGHvwkKuE/OZePmOWcaK1SvP3PMYe3IdBBAeRFU1ZsaloQJF
4Lk81+d35Uy8vIDz1AbQBgeVVbuGUw4vSW6sfS1DBz5oNoTTb9bAMWXK11bsP6/eNYJf4zwVZ6uR
2PakHau0Rxw+dX76EUr116Kn8PYjj9orHu/uwISbhqBmmLEHGCQXdP/xqITcTYBUrmGe5DLFk73s
8UVztgeUTZAHl6dVCvmNhX/mcWh4YLag1WmYcqVAhIEukhGKwG==