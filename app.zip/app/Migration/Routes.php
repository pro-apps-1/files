<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPutcCYZ+UuSFXoUd2mKbUJzPoLsVc7+BTPQu1pufA3bWu9NL4BIZg5CwSmMhPsSB4xx2Yl13
xeGQdMNpIKLLnw4+0E34w5j2bPgln5tZn6vlLL1v3z6M5vx+BBJzJgH8Tz3JcHAzCF1jz+XTYPxG
eZ20asAhMHshxpg9QGSHFoPxLqgphf0B4knRs9AhuJ+dP5dmAdEGWqA0Bb2F0AlZ03035XM3VdhL
mspVntVGvgGYoQgb6y1BIQWm6qC5ddAXUOOMZfHpRblOCEp/A79DslgBtuzb61aki8n+YfQn6Spg
4kqo/oVx1mFgANGES2jUc0RX6b6DrTgRyz+EfOAqRj9u/EauoccLHwW/1g/n/G2+rDRfzukmUbqM
6rDmzKCaeFjjd2JWDUCRuFPQX9XfaIvgntqoJ9JY0ULhtWD4XwDA2e4SQWS8ltIdWTQPW1MljGEw
cjOd8LYIikUdSZz29Yhk0nA5zqbtkUK04U+iC75udhxPLdhwN1mbKDCe/olv/2Iu7X/c+ng6v8HM
Mm/xhfk7ULJxGjYRwQ+BdAn1DkugSQoSD1Y/SP3aqUavRquY3Z2/t1b9eH4sUeO3kVdSVXkY+rig
8Sx5HBnFI0CQvVb4ul1rI14S+7hgvuJ/YS99QN8PR5F/HUsPyEwidrU6cra8Y6liyEKn0Xt3SGXM
eBVVwLf62GET/Wu3pLat2ncY3Y9UucvtPKki9Ab6jd5Lw16V59QT8YFtu4O86JwDMUL908zQv4Ia
Yissk5BEFp+mooKUocAdOBsfUJXNWhiqvLxLfoNmfsj/HOXNlP36nfqUbAMUq5nGB+OYsSsTwXdr
dUbz79RPWWH2NoaC52XtAgqe6XlJ1tmNdQ3TcSy8Bd3cyh2GQjxqpfgYQaXGJ8tInqWoeJLEMn/2
yLiU6bbop+ALjbb4kYL+d5CLoX/CKQGpRy/KHYitK0Z5YfkV0GUSinRIHwcBSTBuUSCHz9If9BvB
7xh681YCj+OMhBeqcn7vw17LAuQAx9K4KAQ7GTM0htJcMbZPVPW3xYomsz+qsAqKigjSpuUgyrLt
WNMPPfw1YQCfDtgC444JGAHI6dKz+z0Cw9jubptCOf+dLjqQUj4RhnARAT40z4hv4z4LVh7k1KEe
Pu9qFHxwislO2MGzTeRO487HZYzilKL0tg8i77iE7vL8uMIcB6Y6la+QznFR2gP6NokK1Y8VSqtU
LVrurVelvIpn/qSlt44dmWkkRoCJtjQdW0uWLJTePmsJwY4jMaOKkIEYKQh6Td0iJ5PwK1yWMazd
z6zjH0MPa9dpIUjLWRmbdhF7sutTK1kYCTwIrdws9mpQjd1rKODuhmxDrL4TSeYxngDEXP4e/+O/
X+W/uY2eEkyz+/8rbPq1O5V28nAaTceo75c4aKNgicw3SyTAJu2xv6MWj2bxz5HRQPVhxrnALr3c
X2/G2xj1etwI