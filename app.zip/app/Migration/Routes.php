<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn6Gyd0YJST7Er5dKvDO91AObDM4TCiseR6uXcbc8mMOt0kCITJZZQ7iEtrQYIWesdtNt0x5
ob9ZYXY4J4Q5HLbgC0x/M6h+HLKLx03Yb202BqGTtnV/pg9+cVfh6EI9kdz+qKjWyZeGO8vJQ0Lr
2Mvim5Pe3wsA1+StpWlcRN3qzeojZciRUdzPq7cnjMj1yPzxrsugznIpUxS2/XThDIcuKEM7txiP
Zwnrl/xxWrAt6o2pDSdDQpArh3P8tq6xhzXtscOEfIpv+5PatZdjxX50aq5dnFdf4p2TOt0W8AIH
J5CWh14skOdWTSNqGkrKt+rcO9Trx13DpSZwgUrl38JaT/l3Afr4rSbhUw7vnY6+ASIPk7wR+jjC
/R19f2ge2QZ9+E1ncc9zuuHAGunTOLkcCkPUB0773GCrfUNBiDJFC5tSkcBZ515AP/kDYVMGixG4
T8Ixx7sgoKk8Z+7l+Mlb0xzjyvwimYLXO6FbAg6H3eqnZZfDf33o85yoJBEALtvwusIfegqPra6I
EhnzGpQ01ofIZaOVC26Q045FEFap6ziekO0N8hSZM0JqTn0WIM1os44FKqkWxG0cOQdFXE8/CaUs
2SrOETknGEobo+kHq58E3rpdx/yqDt9EBtJ2n2SM/S11nKd/FvlOkMW+9UqVa8WvSlZPi1+/VA89
hkv6VcDMv3DlGMqd6tRv/gmi9aWTmqigJDwAMOrk14OcvMQNKpdYCv3ceuAYJ2QmRtwkxS2cpKip
uwssqmDcE8dJqwbhw0JFEYgfsQViG1LYByH/MNqGVqddRjJzskpcVsfBFqgce4XZSkDqz6zcrsnL
E4Qk5gc8aiq/FRDDMeiC33NpsOARk16YQ+wPJFDS3LyW4rc9ad0HKZzNOIhmZ8e9gWoxwesziXkw
4iIYo9PUaq87ggcjZoJlYiq21w3/xi8eZ6BtD29+HI15sK3ssaFW9dwUpSNPxX3NUxPzyzu9gQ/z
AAvryfS/71ImmbPD425AnfYl0fkER0L5rgKBM9pa5X948IJPkmPiBJIXtySh2LBWr2EMcczbHqPq
AsooDXF82IbPU48gRIm3qMOuGbx6kVcYaCdpY2TJM3BxvvgzUKAYZRsAsNtAnmaihAHueI/2SxLZ
BdixqRLcmn3MxJNGLXzugkL9aqQaeP1koducu8oOL/zVTwKJA9O3rkUFBXnlcqP2iAQ05Mzlu76V
MNgMwThHxU4XPS1JnVeSq6KBjfuzvdRmUWxwZEfGyccGcgJNFyiTp4csLaxFL88Y0KeDmz4r40P0
9rxuUDQk9dfpjUDCHpc4UTB33EXwCQgS2Mi2XHsNkoyEM/q0+3H0QZjkd2a00RWPPP/VwVGNAYTm
8ynht2prD+z3BvNsH8cAG8mRc9K7gTBDEniZ3zscrAiAahqFXu2nEytdbh9ebjpYcCVwIOhyPmkN
KYfYSvqCvNyKuFANahOEH7+/XaaeELtOYsnQBD9AUyK4LpxJiGgtMJW=