<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/pZNViqVARymIB8s7IvBK/bhxVwcR0Z48AuDNL4mk7zNvHEyGSm2t3ykezIco/6QyyfmIRR
wPOwI99iQy7EpZTW8bJhjsxIdor6EuUWHZJuT5LKypETxenHp9cE1cvOnGw3LGAqV490IXxAonzO
pfZWTRR3233R9K0EydLHmoXdV5TxaVW+uX5mM8GJtBPy9Fz66vqQCw+7hpgWga3Fa1HxaZdWsU9g
eXo1CRNns9/AUeaEQmRAiRGGUro1zkbtqVJnGv2yD9MuVnh1EjhBxNnaxEHit/cJ4Y5YV6+U+Oes
UxjOGJatpxK+zKqhMuOzntiBXayYb9Ht6nZLFjK1kX1Xm5BO/UVESbnueR1teamFV1AAAHI3eTCV
VZ6pjXuCIK5GmeQpcEHOlMcc0MhtprUIwDmoQper3a1RY0n8OKjkdvy/fWqiWf4zxAxi5b5yhEOD
nianbl+6D8mg5T1cEyNhuXtHiH6qw++wyQgRvt1AwSNrbifchrihdy4Hx9KkpJunOW+SGP65HK3r
MhQXOOP3w8gWFfM+GvqoB3hGd81EuosvFfG10W2xCjziUwd6/eRDJjX8gv9EBvXyHSTAEpJprbHy
pmTW3hXAnJzcHdqjK4NLNaHCwV0DQj2cuBGX1y18GEW22sg6RUqBRJIww0unGzaCrk1xEr5Mw167
9+sP8O2G1WbaLHtQwAVy/EO2KKkegBUmPRKr+DRvcrbakolzsv21YFnWJeuKfRjQawquL6/C+PGp
+PXIbOT1N/7DRo/OdIzX7j2Kvb2JYAcYVbGNGK8jp646w84KdK03Au7hr8T5iylJlFxQoWtvcDIA
4ca8d4ItQAMY8Uw9nWXl9xTmsnwTspwkDHmD8UgkKZbA5tIW2M1Ty2yR0n5n8knpgf8M69VzDqro
kE6EiBtMgZPR6Ofao29Mi7BZTyb7kE0f3bUTY77aMDIJqRlje7wNXpTb0Ow24xeEyzViJe1CeDRY
RT6IRvgvTJx+eh3eIxkuLoiVn62GRe2o+ANj8b0MnXHXybj3cKBNZ2yQmaajtbo8PYz5CU/G5DF6
IS9+AWC9pBOotWhkAWAr/8YB3JJS7Ps1/JlCVlvBvUMfuKHZqFdZi3geBSCTvjJqaajv5BmlImdc
OsTNTnMUruX8XClUwRz6dQ7p0f20X+IqdeZL7FrzGN43hryc8EcYdBqsWOswAdHckVz+Ux3dFt54
4dshyxbbGGqtG8w5vxhACWy4d2eeYwPcKzHv6OTbYsnkGqA78HeNNk6M9YA+TOn2bO+knIqrnPc3
+5ghIOl2/vUbtqKYyAlm1wzNt34lDK9YB8vsf8lzzoep93vqxUnVA9QWeoaALr5BJOKR060ITkgB
xWeg3/flhGmkocdPL2Y2FHwoB4zsEkMjPHbfChYj+dcaBfDjnp1X/FKbFxzXbL1ddWBHTJB0Qwj2
dYlqfMdnHFJz4qZxfelYa5DfcRr4hGrM