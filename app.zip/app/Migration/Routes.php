<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPquNhEUsonJ8JzOvn9FJibYWwgqkJwUKJ+Gzm4nEGNh5UYgM42NrquzOppZAr49IA+pSmOYu
7RL7vvUaVnUf+qYzKXnCwN4RFc6mLfiVKvfjygsBBUFjmSeKVCNp92X6W+iuTFrtuTIRHnN/DV69
PGsUW/2jH+e5vrhO2RcHo75b+L7fEP7iTBIf9/oCpd75dFl/2x/G4AFCiSuAtyUjUnSdzir6EVP6
RpIVsDVW12DFwC+Fj7F/Xt2jOHcwP8cONdbaY/ofrRO2LidoHBz0bPbnFQu2sNA3Rmw3jihcFh1z
NZxNamrekLP5LgFYY7hlNOXcWwRKqq860ze4zhjqkWKNshmeQcFi0k3oPNUFeg9GMXgMn1tcdGmN
4Y2k6y149/ZwqUrz2od619tjg/eYH/eLDnEqkrhhX4Q5UdT6eika0RmaQmaKyhx3qMW0mj+D+4Gx
aDq5OVB8LD5V/KItf/Q7GM9B97gKbTl6o0szwG7NCOMXFHBbqT8O0OouKXxRVhIr2HRVXGVKX6gk
oRA4JbLQO3ASi/gBrqkH+8ACMhpMaCnlUw8l1g/svLb4+CFE8BkYrBmo4EdiJyXD772Ls0aDT93I
oXEwiXcEOh7ncJf68LIN+utuvxE7g+MHuQa0iH2vYnKD4g4rCKKjM/y4Icwg4r6c07sgLKRXiDsn
ASC6elxVGEsdvgqPWjGMq8c4saEQjkQX5TtVFgv1Q8UUSj/sqsKKLSzCOZDbI5iPutNiIycVlGSL
CUxpyj+yJMj9eLYxKFFw+TqSuh5N/b4XgHiS/feLqPPKk/mn0is1H1fT8S6OUOjCc4BpjuwcRsvp
kVQw4Tj4BhF0AXWoYG6eU2s/7+lRbsKmpvjz+VsojSf2X81ApwjTesjGN8ZiGwngvzmbkwLXYY9r
EtsQxGgYVzo3fax3QVv1lScUz0AREoPp690PwR6sQh+Cwyf0pMDwmvZkRz+aZ+J/teSxAnciKPy7
7rO2cIHRWEaORXGM/nGE3GxXHdTp5BqxxrqVSbSFe3OYKhd92ePlFq5TGVBhzzj/OnxVqnmVeKBb
Q+wXujlaaZ4LoZuFArhxXzcwshMZhIL7BQOiNoZSWLPASKp1xxGWlIGZnwqZZ4J7agOueZdTu0JJ
EsaGaFVvb1grfFse55J0QVp0Ar2RginMQJ+ICcW6oS25g/1p3CeYak8zn+ZL4/k9r6KL4OWpjQJz
NLjH9+zJLFg5UAsy5A2XrbAaYba7k6VY8Vwst1RdT9ziOOOefQ02Oe47WRmWLk5zhyDoY0u12P5h
zVumUyhVsMiMfASqyHv/nRx1lJulMoHmdqAxh7pCORobk0puewi+Y4rNykKveZ+VyRWKfVYXtLMf
VkZlvaUv9lUluxLaH9vfuEmkasKnXGwKN9gNZ4flgfljcf0rDP8wU9QvHRhMsOJp62DSbnpB8Aex
SwOksip2y9atZzpPBvRkfmE/vgO=