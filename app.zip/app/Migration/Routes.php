<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn4f5RnNkkspBkY0d/g2VfbHdmXbCux8mAMuOPOvcZy2ZIyM9xi/spIZAjCh5VpbbjGOn9hE
HkiIEAj5G30zgf2jWy9y9Nvy6AqnxDCoUZP2/IBhOZgq+VyKbFVitUdclsE4tpMXS1gTKjO4HCv+
8Dzw0F6ZOB+1bRP6UHhOhux1iDmXcJFZKfBc6PvRYitPVCqn8rlUS7Bfms6l7syZmS6bK+bw46AQ
oNZG5WK4LER39rWVnaX9vPyRVcZI4BDfj0yVzdiIHdElA4AIKOIlrzpiUxnfx88mCOvWT88RL4Zs
A1WaqH8jOT5e4Z3cD1kFixStKa7J89d77DIePKQRsWEOB4oRe1DV7hlZBCPtXHrXsdCSTSOR0ZOl
DeKi1r3I1dEQZy/IohNznsk5JlENjlH5lDqSqA/N2om12KW4QUzFm7JKrH2+8CcXhLvc+D9S9pj5
fhSOT7MLQlPTMrxtDIfxRRUJDmsOXaVTt2/X9CGo95u0+vqWVUMcvGXgiLZJRzlSXvqDLMyxJ/zo
a1zt7FrkeeCPdOavGOcnJk/qFTJo2i3uPFsMqZy9bh60YuENC0yoxNrcX1eQBPZuLwhNQ/XAY9Q9
foRKeBw7yz8of6x4dkX+7ZDFvFaMDOOzMG2Im0u28vvwxbhdScvPP9knXLGm7a0ZbYM+xftMP1f8
MQbTP6SsNXae1Ei5S76N2Q9PB3TG2vMIz83lOYhV+HVnl7O6vvu1Pxm3/mFntS+fCdSDLVIU+6p1
zSBXk201QWlg9PILTbnUFHAUnVMbIdHeIVSwZfoME4x/CMx6fMVwqJvp3zCYEPzz8S2YSHlF+EGs
+Jz6gTsD8G4CWr/aOsUs6ggM5S6u65pOSiP4EWsUZBNRAuTequJi4nVEdgjX0KG6KddP0/oYfu+i
4gP8O0lfgANFfrNJ3mqzUjMCud9uUsMBYCpKwn3on3wAqfCaBZfrcb0g5u+c7yupVi5YgXX2Pbcr
HdoDWSHjYhEAFe8GtMU49CUrVnkndZSF5hYgXKo3EHo7vvorw0j5hcvoiuyDftgvDoCsNwFfL/ch
dtWWkFVv0WCavDPg85DU8rbSHl+PuiHWphfBcNjp0gvO3UdLi5k/5UqKtK66ZCLFxXarr+/DIKlc
fQhKgoAtWkXFgjEDDDk7RMm9VrrUJaNBLAWEdgj+V7XPW6ld3ZVxhFXARM3mjfoZYN0bqhVNFnuE
Ap95uFKQIYDJY8a4Te9cTZRNlf+7ci+i/Av12CHtpoHjoUwXpnQeCrAzsS+io9y9Gz9ytMnQUwmr
35Jr9NJiNSt519MrJR+BQu0uUraCo7onWfIV3r655It5M/7XcT8/ntmXM5EfT8jlX0M20OjeEG7F
fbJe4j8gSBvh5djyMmn0AtyHGRer6lQJd+telSKllMWxISBkiI5ZWh8Z/0g+sL1wwErQvROblRAX
vFOYQ4jO9n0S5UfqYWGu4aIrLQSEbG==