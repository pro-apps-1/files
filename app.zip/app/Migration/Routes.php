<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtu5SKEusKbrHSJaO1R8DIHFWwiZhVDuTCe1ekSJESApw5YQCCtnz5en4qxOw0tYHl0QTkYB
yL//teT0UwIqb/xy5KUmIDHMqiTJeDRSQupzwIf+hfvbmDVgsVLvZAodSoQtoEINpP6TIy4Hs7Zg
rt3SvhWtmYk9hijotuq/8H4QFIi2VX08PuxgazKZ+Pex+MkzZClQwKUt+Erh3cnxKGucEw2RAHD2
zMM08IuJaldGcSmJAh8JCgEnXni58mgcSgzN4QLvxlpNQGqzzeZKqb1s7eEL4+PpS9wXAlf2E3O4
ZGMRKukmVV+xJcrAXOV0ocBqeGfKsEmoze9HkIhGp9fLUjZl3Vxz/zooFWVPD9+pI195I1lJ9Omm
hGijb9YoGacWEQMf7bpboe4ciIEJC8n+Wg4afRjis+m8t+eubR0mm8XFBODeSwNnvT3RtY4POcul
hmbWOn4VgJuVV9kCAv3yQpMhOiM2j4+ES0qP/nYTx1eqUo8aIifEAJrFuJBiIxUF2rRdA8QkpJjJ
C8ZI5dWuXMNfAYFhVbVSy6pb8G32on9Q52eYOKAnfeAS+/icWNgYi+YtODc/3XdfQOXavkT8rMnb
u5n8JTOSGZOqydCLeiuDwzY5/bEWUJbwDnaBI+r/v4nhoMr+//lETBScgXhzTV81ZHgSCiccutLz
8TtzbZMlAHMVWZ/KldfFZ86VWyny/KEJ0xqO4h3xuuruKdlHWeaPGmyUdCroKZkmcDRiHjaEFyUH
SKCuXVOJckNBuG+K6XzjUFc06//jZG4JRrTntxONnmkgImmH0PBM+CpTglFIh1oDeEJaWXyjTtNC
CdB0ESTgvBVtDsyn4SFT4SNr/8LdAavOOo7Z08PBJM6gzM2DIIf+w1plgS+BJbRKkS8UsDZu9J0N
OAiUweFKXmgIi0tIEElMbdHZX3hLGixRKipx1sma37Jn4Ck5w0/xGRa73O4pv7RHmoJEIaCeITfA
aoJopw8Fgqx/UxSGONKNfiYL2bapg6617dzNl8n9xlKZqbPhActh6IfaK0Lr5Eyt/4nyn3TKCx2u
MutbHoPD65Xdo+K9+qx/UTZIOxXWO8ItkCU7Hw/jqvRQdAw95YLUwET9X69rk/IgbVlnXi85bi6V
hYTFAKk6kKqWkJEGoPIhis/5zrPf734YDuEyaXhvAVHEtRcBSlXM1D7IsPBNgpPhpWwIjRtaKXwo
Ih5LmTu541G6dqYnBgvlePC2kSazcJY3HQ3LCBy+5bZDWfsG8oBcabmJfYYaou87+89k+nWM3IiG
gvXAL/ETJOwyU3u1TM80TYujy2QlL5HdVwPqKtt5gUMyTuvL8Z7fqVv7uOgi3dJnrwAKZRn+GBDS
j/GEyIKPyMUpiCczxm42ph6v2YMHRpNo9y/jMDlHWfv8B1WlvYQqueNyPowzf88Y7ONhopP3ExRD
rm67cF1MsVJ5bKlzN64h6T+KgD5kfr2rh1G=