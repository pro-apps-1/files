<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrZ/1/i489t0Apq1RYU0zofJjY5NtRsmRhsuqwlOfkQHHoKImeMBla5WtaCPSYSTUvAFkCjO
YrJk2LP9XzVPFNwY08XDE5bM2A+8Aa/VGan6t7mtQAx1zfNGDybN4+0HnqzNd3t+R4BtkxijIBOP
CAanudXsl2uZX8u5VQVUw1TznbpOEei02aKA7ieJIsaM6D7B/HQkDkHoE4t8jiAt8V1CzJl0Wj0T
XMWctgkYnIadtUsBQogFLjiJ4EACrOb2kjd7Sg1YcngZVFhp9aQ/7plPf05cPJrKL4X3wY3maJHs
W9yE5Z3fOUBtfsfz5wgEeKbFeto4hxKdNiME8mK6q+hQM9nsXQ0S7oJtooKc9Mi6yh+UE+q6XGV2
l34FAmpwcNMCPf1iFkkSgrl1V0mR4LiiLHjbQwTHakwG3AMrJJQXSctz2HzWZoxZEeVMWtoEuhqE
0tiggRh6OClJnadyqlrucqq2vTzhqzFpXQ+TnVwIbPchSwtxRTsYWXXHv5A7LTBlw0/9Iu67W+q1
RD4IjvYw9i3XTLUBwM7PdjJ6CFIJgIGdyQ+KCQfrqHrih7R1pJLBcS8SYWm3yMg8vICTgVxSQfsX
mprlOF/fpLa6YeReX2DAEjVD9+4uBiO+54ASsjzfU4AAZ2CsPAvZUJMdYPj1YgGaCzd7/RtM+m4h
zpyTqQ6j8KktABAYpxWef85U0bTfHi046KlMo8uM9Tws2LX3uK5TDVmt0YalJO3/xbD3cnxg6Ogg
uLLVPymgU99saig4tXcGwBbCbaJX6J4ITA6PRd+LCS02OpGopEbQbjEDw23XiE8SH4inpYlgWXim
sHnoglK78e5/h2EZ2SB+dZ5CvgSZnXAkpywErzyTYlDsOFXV10ALop1MLP2RULDBNyw5C1vKTn0M
M0bMXwyb4ihB6BsQ28c+yunzBN5wgnqc64yCUI5aAt/EzrN9AGe887s3QwLGBy33OU8BYO54yRz3
SeT77o+X1jDuYvq6aMoGBYd/u5tKuFL3B8pdEprVS3P235AIVvC8ZScwZKehvF3AjbtXLFIbkW6z
U1jOR2GsdwooQR/0X7W152LHC7ikXiW8EXHWf0iWgSjfzCFmCorXs9dX9n8CYuOto24WiO1FWQgB
3xV5TAPPqaBJZXYTD9ZUP0Uvbzd72WdFIdTQVr+pSvJh97vl4nrDYgJlA1JrXE6OxeMGXsVcXdQ5
OcVOK/yxGrgeN/CsfIDQxzle0gZxn/tQgtX3HrJCOlBt6GSARwvP1F6AMRY07/pn0Uh7m2yIKB5N
YWjPaT4uvIjG0rhmAqCLZV3ezuXLjva5iUY82O+sz1fAAAysD9BGnziZp7D9B9/e4RndSFn1IDHi
LmCaToe5EidpQSjZg3WAk2RQvUyDLtgvAh6F7tRj32vlCm8z11uXjgv+clZ8WCuLUCfr+KHGEUdt
dPyXwMxA948+oG20s4z/HEWR3wQYVSHpqdE1dv3YrR1osZV01Yvt5F4Jo4BoXMj35P5+r19HSqjs
sL8n1QIfBGopK6yeoqJtW01OQyqBJWO8ViBHciVHwvUywhkCB11VqLjL8G9WqshjB+5OPc/MhiIK
sLh5rIWkraNUBnD1iZx/99rZWQKKk7nTORQaBfwy8zBg/HSix5bJzeUsxjHGj2zwnWpGO1TRGuTK
9UNT+3Xpu0w6Qbq220DJh0snkejF/mhW3k52DFfT7HfNrpTJNY1pUzcv1+BDu1SW1QYjNhxHUxBV
HgfWYMqVsk7mqQy3nT6rH1rkB8MxUx/tpoBVZFXH1S/Qc6c7QRhetTk4emHszlNeg1pLEpkCkFtP
hZfvk/6DvdVra8XWnBDGq9BQSln6n3a2UfvmJFfpAqsqUcMxz0UfSqqpo4SBKUU5VQ0o+GHqq0CG
pf95yGv+w1EfwD+rMzDmHhLF4lMk/Iv05YPdRbEy2eSOfA6CwRwT4awu1Gm2LMDff28iBzTtiPlS
tGnRbICEESuUmAR/15Uk+R9MkGEo3gILGSNTj2zxwb0Ee4m/M6KchWXvuGcLG99D8N1z01MglyS/
w7ZNpa6UGonh4lnJ+xiG7JKzidIYWL3cMwIdllL0+YLTkLX58H1s5viv47XbDiF4HGbThmZQy5gx
ZnWnLwwii1IkejDajlZw3OVMlx9eEwlC9cR7Zz2Sc62RFyf/Ic2KBsLnFJDQbT4+kwN6l+5U5JUL
rgJuyqkGH4eNNXb07/KOyOwM2AqvGnZLhHtDNQegbbEAHZDf2fAiFfAKeqTXSSyhw4nDr6rEgnrH
rgT/Ehi1NuKExHffXdON0lNUBSu0wZ0rebeDg9eei0z1kk2JFwVtuwGRupSgs/+GPod0B0eLQCid
8NBLyhK4CXBMBYlLtEA7v4uwV2Re3VWVU58PCSn0U5NnfMBB9txn+8pSE9iNQGeHZHLNO4MWeuQ0
xgDKiOXK/nD4EMbBjWybIJ8zHz+uoHYKJZNCs9o3rzsxZ7AhtzHLx3iB5CeStY3/l+/d72GBq6KO
1yjP8MQbGQRJkYzHOecz1nNdyLd96w9bXIfybTLlrj2CTB1R5t+/SGB9miXMItx1CTjtHVQBde4z
TtcTr8qMHarJzc3Kx7qxWZZQBvHHZbQICi/ww9zz5eqXwOsk9ST8lU7gO4kmuiYErarH6BKQAhnN
y7LmFmEH4dmksvjmOGkcevBOxCUDeBbZrtVyQngzKT3P/4fmO5oMRMkn8jxMtA+z6QJlh5m4KfnX
UmCaPLzgTaHFrBket8T9JGq1VjY99cknCO5wJizNq4pvwsjYLFfVYHbTAj3HyG0xnVSUV8oer4JZ
HeF4R2KYHeI0jC5frHjb20kF+3WICK278RqX/lZHOMNuU5jeb99la7eMZ1jCSSmLVNXQEU1vArCd
BqCnRXWiWp8dM0UAc7Y8qq8z0Mi257Dd082C1dENUSoIGisRijBaqVTMa4lVKCQuiu+oN8FJtfH6
rV+9fn8duvZvkrk703XrDSKLO9PsLr/cisrVU2l6GpMMD3zS/TItlqCdinuW1JheEhHnVMg5iO8R
4l2ZBpGWvIkzp12uazsiHceK7hAZYNaEvvbf7ranoWRr5hqABqF/lJc7PZvHNtQSLP2yr8H7vAV3
hDmvdEY8w7XDcqXxIa8pwmwUv6Ti3C59c1nSIiiR6qiJuTd3af4FDCn2QC70GZU9LGlfxRou8SUc
Z5QEfQnippSIkiUXN5aJAetQDjwz1BBn2LdgocRcPRchBAHjqGWqGKiEDfsGvIdmzJ1jMIeRpnOc
Rl1vScDpI+21lCn2P1pWYUwLW0pQVy3wIn80QSDJNavm3Ponc6oA5vNJRsNVoL8EIRE90IMs8lGG
ibYj2COFEaj5DrmnHIo7hno6/ox1HLCgltfET8E3odN/ELow+4fpgZcazv6rCIBsY1FclqBld1pz
6BhdCPv0yavZUF+axbaQse9PxdMGCXfYPBc6PXu/Ygsufo4bE/kZV1nrOqI4xMfazctoSN6bL+Hq
Nct5o1m+qqUQbqbgXB07zLZiCRg+7c9tRFfn6eRN/MvpPiYA8RFi0h87CVUp6IDQFi4e/KQbzidr
/nV6TIKHHRq+VcKbDHHkaa1YsfJoTEx5oL1QJUhSye3tFjdMRRnW7gtAQVbG2oZTNc7l7ClBcksU
1nyaMc600su8Nx3Q/L+tmyZ0PV8CdOqmQb6Eczr9jEGQE9tin+udi2fLqmCqPhC0CX8/78HEUSnT
rce9ixo2z8LcyKgr+E4bhOTRYKWVkLcUNpHGjMbxPU8eaV43Bb0e/nq0eTBHZG58z8I7MU/Toki3
NYmZIjT47hxvsdhFzj9Gu9bSfB0vCvsb/oPM73DEkefTg0ctQ0PH67H5eeaFC2BjLswPkufYxD3G
ajqMFuAlLmN+I/CrqpP5LbHx6BH6ZYFskacOstCZzn/4U//sWtZZfzlGVqdL7eo+yLDYTJsju9zG
Hk5R2Z84c7JJddY6yQJujfxZvmfzcYq3iTsLTZkk+8zwMxCOMcZeMy/wsJRJ3TfjLkw5OdwbP54d
y86tpf7WhFseO1m2wdOXgK9j1QCpJQcFby7V1Y1JlxNupnNeqR2930NYx/WefZxajj2l2lZ2WHC4
Azgb4bUwlislN2NF4lRx0lbwDfqk+nQ90nWbfFsNv7woCSZHKV6m5BKwLvulEzfMe4nd2etnLDOw
Ch8IKbN9PHc/8TJ4XLSZBL00VHeS+N2DXIedC6oYxcgdpbsFLpcKbCSNGT/Bfc1mkpExUITzwwx3
YQgazpwxiwtAzTTDFpDOT52qw+oH6GCRvjmF7b/QhNK2vqpWXukPbUbu6uddMgaEQ3ttdja90Tbw
kwexMEwS/oBNBl+uuL5AVzonBHEwbFSxoJJ94/dQhywV2Ghs9aZp44GgnWHYJjgOXVXOBws1jaOe
+i+niMBgGIdfk6idqCAFLa27Q8+zb+vJzi3tQ17uIBd2XcP31ZXGtbYrR/+vaOB/nrua9ciDNYbz
fJFbaV31OfqOuJ4dHPPJ0NkwUfChVnRd8gplRnXGIFnZRSJL4Cj/xjYX318iClCQZeZlmu5W5YsH
dCqRKiNy9tqZyafo6g+p5vzeatTebvkVmrt/bS6CC9I/x78VmfL7CzDXufS+xsdsleU3El/ioQuQ
PCSkQx58pHwA01fbv8pjr14ht1YxAZtR56muR6kTS67WvdsgXVyYx+u6AQRW5aRqtofK/fJooeOG
/gc6GvYvhDo+vzgDLy76k/pqn9tKea0Wr1BwMBEIm5wkq5jyFp3Sjzrz14nrsfBwikPvWUskxVBc
wsyafSWHMSjioE9v5Wz3/yYxJYil6BMkNgQG5PjnHNOWJX8Lm98o+VvMNwSajRpkqMnwa59ve2CQ
Q2V/g2YCTNYDFO5Xb94ryb3Tdcu0XvXiVG4eQEQliz4ZyD7AxDJ6A/OZXhsqr9s7comaDx+jxNex
jJtNjQzs8WBF9Rmq+B/ZpKiHl77EKpfoMWtaRNhVNqsYkmwt0aW9glA5IYqfLlmY23L745hQjJR1
xM+YU/caL5Ifb3yHv8yl688tIUpCEhD5Dqxloyq1awXyopk9utjOp118TEzlFsm1HM3XnRKz7UrR
8lBt6Ly2bLZNOeeS9mIseyprRf7zgZ6vrnHqsFlZvWi+xij+lxzzDRuGAKLvWGEhdCiItToHbpXr
jE+ngYtlskxhhSLM8nDrnPvzdOxoaojcmh9RpXfKBAlbYvD/k/xm0lW8KCPnM0/iswRuRErzrSnR
HT+/24RpmmHceLZ4Lhadi+6sKtY3OGxXRWL3WNL6i07sRNACc3PQtq8BAWQEhlqJ+/614eKc7uKt
d7fMT8VWOC5nLIUb1DLYl2O7we0LZblzek9XfeiwDtCkyH94nCYtIXbh+F/b8X+EPqKrquk9s63y
ERy/afg01/s+SL3unIyLMqm1Z4bOgqu2DuzJH9vnY8AC7U1Tt8FXIT56HtqSMnSe6+1TZTM3zE+B
ttqRmzCfPvIWIVuzH3dRyQIv3lzpNjNB6RXVEr9rXtFwg0V8HyAWh1hahifl8nAU9FqbVcAUUejU
KxEIOYxUaPsZbSOpnWDegTrB6qYKUBFCZlyR2f2D4EAS4ncEsMK25uUFaGxFtSItaD5Xvrm6JgpS
Vt1kJ6fCq9HT0VxOeswB8EvEDUhihRvmUNcdKnyxIEsXZ8fD1ykCeZry2DETDf8liuPw/UT+e0fs
BRnXeQH0MuztxDtGhZCl6yv9wJkjBojJB7+XNFKVUEpTW8MlIN5HfUPGdOLKMAE6Z7KsARZog1rs
QqABtQ8Ws3r3gyvVldKRKYq2u30tMTD0Ld6Nlce1o05TrfNEFhWxOmOKAZ/wfijpsjfk4MAhkpk0
0P5WtNorVN+122nVLAtS38Pe7IJ6xYabJWpn+MD8xbhuInOzZVyloOk2ZSPVdveToK+C2Xv36sYs
8x+UsqLqIGSJGSx7X9TC37l0Wqa7oqiGCjd1rCERP4YrmXSwuIHesedqdIRpkw+jxGEWLDR5kmEd
J0TaszaDqf+YdzFNhPLir7TDicKREsjEl74icV8nDdIuMBPZSPBcS0L6JMgx1xrinBsUzNmMu2R1
kcESRiW6KrraRxi1qrjubQKRLWI9g+rOkoh/E0YEHN2UsLv0woKea/4o97dNx36vQP8ffvyzuVwH
zTuf/ya7BKJtAzBgNXLK8/Dpbw82iHmJTufAQvPS+R7aWBBrTELeou1zSPpvVcwrjmNMhZhm+jKH
JxGaKbn4jL7pa8El4GaZHQKPsrwFlcLy9knfQqKLc1AfT4ttQtOr4elCW0qr8Pd7u3Xf5XW8I4Xw
mjeWj37wpS50DtVTiPbY592yE6+qCoxATU59ECaMqjU6BQ45RO8c63YhPfxKMtpjYhPMq1vCEunq
EhEuPojMnm0ZbCt9ZrcVyrHhk0/GMjVqNplmlHdSDxrSj5KY6vtI0il5HQxcddHGGMyeN6zq/vbd
i+KfCn+IY2Ld9VRVImboTtFr6LMO6l4LoDSk8nWeqyv7jc5vBWDpmlp0kOknpo3DxFiDQyZgJR6Y
QVyHbiiKg2V9nsO0PO62yH3kMxS49u0VqLK1gz2PJQcpFnHN4uu5TR98whTLacdhxKIg24rZq1Q9
wRj0JByUwBxy7NiftRU6hLdEsBtrHjADgvDMTY29mep/QVP76PyYNEC9cG5pGFVcOnSOlgthA+SX
Mu3ZLavt5T8nzBDapGb5Wbc6rSIrp1NM8imXmvsXgGnjBfvaJ3S4t8rXZV2FH8xp/Xza680z/jDl
U8HXdsGB8ny+rkW2k2RMBHnAju0+FIP3fMJHsp9jgB8xJS7CmZR4iyHXnOeq9M2TMqe8vF5ZXNOZ
U/2lhQm6S8jvhx2Ht8nZlSOTS1EA03wCOT02ez0F3AknpeWkhhmCPrvMXezrTV8sC8DoCyajUW+R
syAzew5/iAnqiZb3c3BX2UXZDg7MvcUxutGl6PIf65SP3lLctxTxhx3X0TyXT5xqRclQYHtWU3sq
XeqrfGCrzHpEIR41TrcutKuGb0sr98Y3L5VTLaxdXRfaAsnsPj4P0fGnrMgywx8Es6iRyAOV8U6E
2BQ2O8K2+GOVBXy/sNXtj5gTScfl0QM/iJ4sTsOqqZkW1On9iaKRS6HQozCOo8NQnldJf+x+2PjU
u1F4clluWFAj7AW0xVZHo58907jGOkv8+R/voj4Scpg5BRrD3VirQsW/nR6+oGqLuFrd4gSfnj3q
K/beCYi3tQRXYqC9+vtmyVf3x1JWRV8Gc+QO88kuUCcMm395BmmdcnZVry08Rx8DlHmH3uV2UWdF
W6a2EHODSjZfU4ngj3AAkOe3yMbcog+mQbjW/d0PtGTU6rAdfARY/rVmI1BzlBZXwYnhtc0dOlyZ
7I+FQTTbcUqHhoI9SYw3WjzbAbsaNSypZw63ipNt94GQH0lt1eviCh7WCDTKt78QXpJBFWywPWig
NfPLb5L13OrMnOWtWXhgNE+jYwFRP4c3um4YfdnHFvrb4jILy6W7us7Hnz1YRkJ9qqDeICWfagxV
13DCNDANOf4B+/objLWwc+0gy4aERudx4CSqyz/thFsjYv7FT//3PbQVj2FkaS0lchLxiJRlwH/f
inlNubdmDFeWDRaN9r3A3QbBgqpIDfN0n58WjP6mVSRZ9smu0o9COb59BpBK2/gR/0/0su1FMLGw
rOnZev2Z/eukuY3QZCqkK+xUCDZa9Lr/29lRFf7GjfHkevRn1Q4vnPRphJ9v6ukH4yFTjcqc1cIG
XsChpIRGmqEFdgOq/GoU6raKGGMpJcuJdzPSAy9d86koCZeXTjFn+fbH90hPtqgumTtvRueS+nhN
7ztZmr2PGX2A5ReNPFyw8Xe61sY0OWfgEYJGovHCXeFXcD0Q+T9/gp6uHcxqdbmNvXTH5ZOxcB6c
U1/Ciq0XC+8l/x1RPVNeeD2J6rvMTyfC3LHwNPp+8dd0iY8u9gPgdtXRzqjMkz+KL6Nsvw+XDJio
O8DXPvh+ZLhD+estWCe0kfcUCudMXEDCqX8LM5PYhBPsEeTuUfzcqWWe7i0tau5B3+n5UUd7ycEK
WJ0Q5/IVXWj8Yp3NpWSChpBqdUKGsT+3Ooil4GmHunQNpUXmI2rDm/2YycTvw2EkTNVMN3xeo6az
wu1LVf+T4cmzhJOCS2yowfTyzZFOMEheXj26Q90OxehDaeOmW8bcr7p3IwrXjnBK0JH3+Prh85IN
sATxbWqjmS1deGbYZWiwzEaDoB9daEvLRK0QxdfT8uW0d6q9vnW1KvWEDlqdtIRG8CIQWVwgpcsC
YRysFmi3gvP+d+m8Zoc8xOZ4wry+NSNX4BrjvYNPvc5brZ6OTqtV9oSBhw6lhh9LaQ+lePuc0+uv
jXbufjpsoMIrTt+uMIBhSMEN8utMFelOvNd/NpKiY3lC4OCBQrgmg458MqZcjmj6bqKGOuS8ys75
Yedtzn6empPwL0749612hxxUExMgIrwTKUytI5G/n3Ly+JXlPwHvCoF2hYxabXjl3v1u65aEEphv
LM/aaxLhY+L9gzmkjrnZXJrMJhr/z956/akhEMmZh2ijHNZSb4AQ0DjxLb/eR62gyCHCu98Jwre1
VfcOKgIGYynpQ5cHU7+2ra4VAxp4aYj7BtCTYvSGFRtlaEqXC3DuOVMvsPE9RcvsSE/OnAzZV7U7
K4Kob5WQaATTaW3pnI/xN5o/HceONXA6Q16gL2AB0UJTRLfRUBJoGI76npkAo4pE/YCK2r1CG2SM
x2OCRLt8937dMNJPXkIDPW2RakgZiqtmOjEFc1mNVrhhks7j1d7Y8lELc2MtO2MJLZP+Kk+MCg6F
wYI9yGcAW016Rcovj7B5Y/nJAUPo0PCse00MEj2Au56Y7Ozq2EArCMb5sAsexSraC5Hp9ypu4i8n
tPakFaWHNJa6fPnYUjYFMcWSESPIXrMYTEO71CWashO6Ct5gUNOPJZHALSqF/qk7QAeq7bksdLsW
Ow09U4qD4WRSwguh7GlAPBPD8/+Ynnsffr5NPTicjWlbKNpTiBjWwkQ7n82p1vUg9bJ55UNJs78C
//PspsGwmJg2eTJ50b7UUbf8/XFOO98otoAQQr92OUAWHTfgqYVegM6kII0iauGRkxSzO7vJ9L7D
0yakuDuMXkrGiwAR7DuH8ZuKu1VL1RiYhXXGNukL7K+Wyyv+Z1pwm8/llMOvhGTA/pGjT84JPl7A
9DuKlJIQx/zZG2dJnwCLaXKKqa4FRoJy1GPHp2daNV++9OpswuslL0FewzCuRLgGY3JggETU+3XO
5AaWaa7cFY7Mg7hqi3JeKK3P+fE1k6xliAF7PUDCqJcPCfrXH1xKrVt9mZtWg2mREFBmNtGYOGuz
BlMNb+rdshP1d3AhO3/W3yEoVCMtBT6RW5sws9t3/wdw+0Pr1gNzDHau6/Ufgw7voVPYBv6a/lRE
224Gvl1s8GTQfXCEv8ZuQ8QY6M6GEUD2DysBZbdYEJ2x6CJQOK98OIIlHXcLi1wqw/+fjCMdVnRq
xeJ7Tmag+MO0ha4AWZD6ecUTw7ddHk876GKCAZ2cDBIlrkEtyAQ0Z+aLwwDrftbsXOuO/NFqX8NO
6TSTNPcPie1522KXs016vOnhQSvfRwGIGQuAT9u8jKyrT9uusgThPT84bht9yJD7G//o+Dbd828h
XOq5zV7OpqYX3kXSdA6XZ9njG3bwzzPoaqb78aFLyeB3VY43POXAEY9g4SJBCiYgophQAPPKXRJo
1Wo29p82fbKbSW1c6mRcKzzfw2b+J8GJgwpHcyWXWitY2rHeMA+1Xoq+7Pe7vwBDYHGmUzivfsv/
akAhiEDp6geveHBsDkdpllwsGXmWiBHtXuMshHCDJ9mOx4Yfgmuvhb0n/fmOnEjVZ/azvrbOQYP1
cuXT0we7a0xCt350C0AcySZ6xDZrfLatMsATxChVZVu3BPEnNT4WLIQSB/qiKuVOg5PmxN22GubL
zFWEFSRfxdBU//mCtICc4nvZoU1F7hqKqtmBLQcqf5KUTBTfudZTH40XaUHM0IlGAHWK8uy+JxtR
Bm8/i8bPIWvAyM5UBNUatQbiK60mInZbGdvxR2zvT/rO+xa1dYQytJGNKWGKmCkDccjyEzhVQ2LZ
jsdb5FNsKqJwKevPus6kPsItRPWvCLE4KAa9jYZEHLDLD+IPSdl3LcuZtQqOfBri6S6TEUHRDGDM
ZBnjOmM9s7P/E3dc7tcdSq5Ube0PT7WB5MqE41Rmwgjnbpclff4kWw/iSm6VFgfZ5L1cQcAc5Xjb
HcFWDaas4BPdbEzcB8VMY1cFfXOYxF41+O2Q2rwb+HJpRmne9W6X9sPWXGiPJHYvGohHvrAYn6F2
7/J7+Mgtsdwz/8dJY1BKfolfWyIyplaM+At4dz3LmctjCU3ym0PupPSOr3wj9p04Zyn2RJRJNsWd
i27zLSsro0YGjeNOwviUZk84XjwKuNucbsorBCzvf7XsMJ5mwGS+KXgMLfVG0d7I2jJBQsLQXGv0
P35VV/xr3bKp8nBdhvdTKQMo8aiOUNjW/7Jt5i+3xZzyQbq3dawe3d0C6Do/HPebinpeQbDDkEWR
X+NjmMUvLcDzLPYRwWVJei7Hd67TJIg3bdOHMbDI2QBphqdiH7CPCsSd9UwMZ2WgDM9SSMrRYNiA
r3vBhULHmVj42VwdlEIjCaAQghZTFRWXd9Kzud3mZ6bQV/zlEMQWIifVZxa1lNArGMUsx/oTQiyH
vnvf81oECOY0aOGuUbRqKo7Es8SMIiL8DFb1TpQ8RzvDoNTmE7aSHyOD8v/8iFuHI3qFDps4ehLG
iErMXihGq6PvL9DYlFhy52KAhqTLdGQm2BWcrwT31sGB0EYwx9LN1xMDdfSNvEYPHATbrntKoxGM
S+KeADYuefMjCXCqVL5WsKX2FdQpRekR1T6A6pl/cHsPef9UiaAvw0sZu2DKJBOF9mdg+69XYtGo
s1qTo0jfkf9YgDXAUORY4M/svJf972jmakjP50w+RMdhnkWbFP0ikRgZnS341AMf3LKBcf4VFXia
4kgwX5cgCdgddsd/bVi3hc2q3edVYUjlBoGt7UKZA0V6KoR0rvUByTNqOtzh+lE4eoN77Du19TH8
coihwITK0Xkoj/cRyb71m+BQ1gCwtZJj2O0ko6IH5Vi+vsPRtmYEE+F56ZuLpMdcM6vBwd1rZPAe
etGQP00/+Ydw3k8tJsCB8SyYLIB5cvGw5o4G+pfsDYSMZXkfQSyQneH49eYF7EJd0R1AxeN+P140
TjFlbiYvvsaFuh+tGqyVcLZtOTlG6La0SRs9N8aAWJQ9eFm1sJ0cYpgTfXemOOd6gx9rXRUPmTp9
T9eBXH2Qpj9atKsiqv7vY9euykBony8fGIoqTY/u0F8i8W3/OCNLLVy6baczdLKcZsEXkItpzkXC
O4NtPz2qmpA3mI8kSMFPQtYuOdeCR2gT4dy0OxrJl5moTUaWkfHyej7bP43bwXw7/yKwWFh2VoVu
Xc6hYdCoy8kXk/bNvY3yzkUQ9EN9GaUQeJg2LnNsxXrReq6KzN32mt4whoEiSQFhV/fEj3RKjPsl
sUBuMQFlmG5WabezO/KOsUFvVw1k5Vo3nAuzqKusifpSMKCTDblCyB56BvNFsSta7leu+Kg9R9/3
2oSQiwcMMlewS1Jpv4cXet/b5vjCnfwg6IzqMEvBghaOOYTAxQKU1alBqirB7Ky7YLTcGk5upCpv
ifjhpz0JQvgku6q64vvdDY255xN204o/sry6MUH77Dg6/M4xxu8WeJqHLgpstMnWB9cYBh3Xn5VI
VpW0/mm7oKUl5KwjGU5TvNFUO7DLjKl1FjQoW06D1Kumr+rYaLPl0RYFppXUO9WrIVtuMv+pLcNT
ySDoTe6UCBe6edc1YE0NC+Lj6fQzx+Z9InhyJTaSggGnOpSeK/cStjFFBbCJJQD46Mu9dPd+tvI7
13bwtBLKa4n41Nj5FWjAnOigslOuLBCJyfYN7KzpOKF0YjK/1YO5efPaylVBqR0vsA6hD7w024C0
mCuD3jJ6Of0gWOj4TN9D4rSxw0IpQ7JQcB7gct2eRjJoPthZ7qVA9osfUU3KLKTOFN432F+473W9
nuGJjykBwjDqaQ23QOlCdHtnBhaAluefoZ8W2SVCiS/qcbtKPVn6QYXFijOTK0ek/9+I6X0O3l0E
PNyalAaM1oNs1F1Aq7dqBqzRO6jmmfEC6mPhiiD46qGZrAivBOnKVe63v5nNG2q34i14+BDCUTTH
tUEraFulB/GZMgwumzump0S/ChlOTdKGCCgz1MkPe7eTzASV1Rh+WZW3Lar4cArXi0uEp8bhhzYz
8CKumNP0DUBCwXO6RmaMRifmWXP8TAMt86SR4goLzQ1SH9Uq+ndKT5V784PHfQuO13DtryM6bUoH
hdc/CTiv+wTiHyspoMucBrTD0e/FcB0Q9vSnDZavRr5FuyIJhMmW6Tny+Ve2VOnyhgJD46SpbhrW
twu8CG+3dPfPKTUmakMLvI7SRz25VzWajyLNWLgbUrJH3DCcqdkYRujZUoPY9j0sauY6V/KwQu1V
eudw98bPy2JB2GWUnbk9/tOFKKv2duTiNR9K8kQqs+aOGJ/t0y32FIJmwlUlbRb9C7kmKUpbT5fq
PrgzJoE8LWG+DQcyrm6FE9DGqeuPWd05o9VXo9s+HmxuE42cVBWU2VDT5YAE+Gi1Ouv2VZvj5JTb
lTPUpfiY6CNFnEjJYAzbQRb2AGGJ2wTwffQQtzHT8RlTNATdS2CJsoixhgemYBP6JMV898jyHtV/
si4z+RBGhshfUpq1o2IB+iwctKNXNDD7t+5ejRFKs4koC/o6MSskqgUrFjFNnLCFjZxQ7ffcx8vJ
4qFCBeISWhut/i4nryU3f16YU+mFhY8q6v2TESI74J9mFPUszeHs2Vxm6//gs2poqsaG1Vcca8Kk
HDIBZEsz4wqxUTsgvuBe/tp24FrjXTF9qY/6zyWE7n324rgMxCaBdCr33odMuvXhVyk3SnoM8yh2
ENFYPgqcX6RQBWTeRSdEzng5Th9mkKZ2ygiAvk5q+IPjLj1LZuFKgzKcpPojIy4oiyexZYYaZkyK
S2IFmTv7/wmvMdyq7et1KvgBDXn05hV4NLvRRNbTHDWhHMEVaL1mj7BhVDdBw6e3WG/m92Mv4CH2
zoFmd/t4H/s6sGnJXOHVsSOG8puv1UcifDWxC9qvy1XNgANWJljyJV8BUfKbvFRLe3A1C/PjhdG+
A2LM7QBcJkovJjybFs9XHenMYYY9mV+Jv1MV4YhFmxCDDed3ZPTKXVE5xAOAkuVmM9gYD0+wBSGS
814EVIzCQXJv9+lLLhF6wJNdx4xMbP40ea62xzKwmM3aABoKrIJt9eQVlzsVrB8IG9K2MzXG5OFc
2wO3F+WiSxG9iXNB42gqYZzZXW7KrB3FoJLWM5i7mCDd5qnNd6in337A/0irhMQVEu0mn2+sMOJR
Tm13VS3e6meFoCj0qwmVfxmW3PRZ8Kb2P6wV4FF3Q8DlHQP7npdAKzxhBa6dg7HYtTt4XIB58SaJ
6ObYnBdeDTo7LWmrn4bA1dK3TIS/mgBsE9QruWz110MVa2Dz2gj/Ym2xyOf9gjXnI93HG3GjpnoC
4FmXKCHky4gZH2FLh1ESWt5qN6+Ag9kDxK72j9QGRp4Pg4zHe664nrUwH9chHaeXwA6lONhfQPSw
qHbps25lxRsKWqWlCumagZ+qyMzsg9oF20FnUqGhTp7A2qOX/sAf1RXmn8MqodAsFIfAWzFkbFmR
9CN5PQc0OmGWIlhf7TWi92T+HvHruPvodQ+H4RypxHnxCdXrGHOZMeS9Emu77ZKet5C8Ur72upOl
0wb5XtYjtFy9y61lwnbu2GsMA72BeBYeYe2s9MmWtT0WRN8Tjzk9GGYYLu6HowuC2aowt5CoQ22P
W6HO1el61PmKmaBgOR0oYywOpCzgUpTpx8ybXfes/Jy+Dx3RO03rioLEr5EvxctmC6qdBDaOch/M
AMtjsq2vGdO3FLuw80VnqnyWIne7ZgPN1IjIMKD0UO/L+X4w2xXUd6UeuIA6Vgl+pkyJ