<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPraaOIRen5aAzShq1G99/tNXqdcgiDa4XOIuTpZIqBn11IpOlwq3RJqpN86cGhU4Efbu2HkQ
53uIhVFEQQQrE12z0YiIO9Xpa9MqT3633lckahjKu2NMG5EOsxQpLCgsVZ+FVTQUd9JEAIapxn4Z
79uo5zCAALyksewMtQmSKh0P5p0ijqWBHk3b7uhEmbQuw2FqLYBLCOgjWh7DrYAv5voJIgf4yHN8
qZizi3MlCb2lrhOFXZVgUQZjgfvzX/O/0CmLzdiIHdElA4AIKOIlrzpiUo9cNMZ1aRL+H14N64Xs
CHXA/xkumjrtHCZQuMG+UnTTKMpoQphppGm+h+xJWALDroAkJiMWdfDmsoIC97LEltSWtHDvb3Rd
LMbgiQHO7I8qj1bsz5RYAwBCOFRVpcu+lX4FtLUixpXjzxebo2utgExH/c4mX7ukOpN74P+2xEUt
JaZiTQRjGoPGH5UF2YbPNdp27C7b8qohuR3l86KCh8LJ8Jr3TM+Zj5JATqkOVA40fMQ2/iUmOu9T
3PT8jCE+PrxknTzs4K+a+bzwk/20/vJs387J80FFX4uvDVlNNWRcs+afFdAuFaYpdO1P6h5Vx5Jv
Q3YxxUnO0mkeBKaHB8L2eCj1ILTfxvM9bniBfmyeicPXCgdC+EWc9lIGeyFSOvKuq+YUTRGY+Wx8
iKz+K5ftQFRDnec23ijqVwTEKJkxSv0LcwfMnpL9bFVK/dITHPFwcqICwvVDu5qx4uxvPTrwDs3H
u7rlrjrV4GbsuBqHkIPmbeOU1Psi1aW3OYcysNAXsK+nUakHGf/Pl7zgyiA24SZKT2USCLFmDkkG
WbmeNgh64lu/nJZekzJwM/tBT7j1FZhTAzoO4A16fJaqHoBDQxc83AfFoKtSEMkDMGzCwgS4CMjA
2ZOcZiwKNN0FHkfQgPQPCCAFTu3YT8UCIxQoiqIOstS2mujChPjCzNLc7RXbRBOL/reK73Q30WNY
XFqfsOv0HF/XDC2ZuAJCkTmlfrEDWNTU17HMgu+uJw8FxvaJJ6UAROevMR75Hi/SFHorJVu8UROE
vXB1cTebahWIckq3oY9RZnMmN45huhsSeORKntFKB5yaYXVz4l868J9G7/3PL5AcxjnVxvNITi5v
Ank5p2Y9OvceVHGBs2wX2GSNvCCbgkxKonDJiXokrCltG0zejAhMG5zCK969J1z21wNU681wfoKf
8MuSpE1f8OpFsaaOeunXunEqwN2a8jz+yKEDQ4awEbioFvxSSR53+5yGm/Yi02+toVRl5aM9K2Ul
AzhIQVHQXVqo8NgpGA9Iv9rHNrW+S7vHAn9YB71O6LkmfQ49/pOXgyVSyKbamCYpaglc4+jnI7xF
Ivw/5T5U1MwS783XPRHOpBFcR2+ubHks4wAVX1CzRMn+1ZBNRetl7MLYjIU535yeod/HwSA3m7rr
RRXwxU9FrUpFanHR8tELTj/T4TIGhtlZGM6Ey2LFNczbtqwfIZlMDgPsEWvtYEDqxCfx5ke6lkOv
ljzh8eYSfsg2oshoEESIB56zf5yKyWvKDby6aEVng4CqHiKQt6zTkXMQ+nZKd3UqxPeP4KAsVzYe
E2hYIU++RzSGH2SsTf7WHRPFKExnJaAQYovoT3YrJP6WgC4xDMtwl4Tklob16yvpn2yQ9BaCMBpK
SaX9hDFLyaLKYFwB0y3y3zQQWKngLxcubOFcRDOzqBkNlSzijJiRufxD4Eye0DYlawTHnXbE8TPB
A+TdzxZ7coD4RoHVG5Gs1jEZQmomfwCGKVw79axKSaSoz9urXPn5FLMG8zmmNGueEnLQ3lWDocUI
7k5m4u25c6dfw/ShMvRqT8in+KC844X81VLVQw4VvzfVWRv6fcZ3UQhi3sg5i1LiZYLPrC5bXA8t
fVyPdmyZCEdbbXYa25yDteq12b8r5cjDgSeMpec/+3z1jTzfd6hDZ3lQXVIrixF+VbrBd4W6ZzhT
Q3yhdzOs3UUiY4TuIa0s+KWTqRf7YvHSBjyCfCbw3K9lDdLwYjfilvNWQnzNZA92iBqJmjN81BhS
TkRmgAsmlzpsGe6xdDxFAfIBYtentnbWkIXX+oAucfakdFZvj3K0Db8P7p7uaKRyr9R3AdjxOsvA
lR2/pu/PFuRYQdTfHQFJuqbgEflzbgqcJb00AAu6MrUZb4boi34wtDHM5QPLg0neUrv/55BF2tfG
Yh/bBRp8cO93fnpMUP+a6jYZBnyWVQ5Bc6+hn613vVEM4ELRJ/CANI1f7oQPC7bd8LJpq1o7wy1i
UzI+yh6aDvQk5NykaNiIXS2d+gEq+BTJuparYWfSU2NqIJAaSwoQDkcwzcPg8KSk8TfdqzEiO4lV
cM48PK9kvzYo6AMsGSu/K/DA/mjbk/fOrXiHMJamC28ekIhpuBc2ouENw2u3Yf0BpA+VG+mN+44v
aWkqp4RBZRB4GN0lNE/Q1Qvwz9yLZC0xTXZ3aRLHCLAcxm0HzZ6ASocZHn3KTXyAA0f7baAa4oAO
W9wINeA8A2OrfUJ/KMTeDUtvWVcn4+44fs9mLDUCLJgCmAW033Fu0dnWJJZYT0khjJrkgFk7Nnxf
ig+OOdmCJ5hvmVr34CYmYd6G4sNEXwgXzVPdYxc3VD6J3TR8LzQm4u98S9K6zim4o2SfzeM13IvU
2QfWza1xqjxUFHSjD4HirEJukDU20EqIa6DNewBONJAexbXJjf9y5pxmfRjCMXABhcl/sOc6lTnO
lWUkfDSBDhOs/C4FYWZgXfv72osiso62S8QJSsQpCCHiTdNYSysLtvsKVGpLWhb1tzLY74bRXAh5
Jr0K3/DhSQ3CNdwS1ZCsvNPqHdbyfzUlUWBDRBGXB5VbKjr16Adwc+XrDGMzsu0HrHYdBM6cWZxo
ylYwjP71Ca25riWfOJto198d7oMS5RMnTczqp8uTbpLQMziSsZseUbvKM4d+NjBBMkC9fQTFtTrQ
doap2QcNIqR7IvUoavCKTowMmbvLPTLnNgvemt5z3LkMaM11GdTptRgJ/mhrNBXx30+3wuqZOJEH
JkMB8TTpbvDK503rN6TpkC3SToq3hfosy2PnD3YobcCgdqoYfQOehDmnGiA5ts7OG5eVtDuSZLNa
HVV+wLaKy6+47rCu8q3DZmor6VHUKe/koAzY/3CGANWqIhbQ8xxf7c0LnpJCANWLuKL/Yr8evubW
tserK4CmQbFpRPOBNjxywlZCmCzF9PYg3IMblfHh2w09Ive7JVWDLqwJ8ytKMEIZkzzwWvyv5w6P
ObEHxwPnZIIvn+bPmEkI6d49G1bDbefMLqxkM2AOdfFcDTtPn9m6vhhSrPX9mzkP1mgpew3hNBZ0
WKdbJEfOEGEOVw2n9pz2EEQcFLO2jdj9gNZNU2oDpgLDWra1bG5we0JdXMKtcQYNFbWFOx7EbtM9
6/Q1Spk/Z+MRJpr97xgjR2xjmtEGxRnq7j8l4sPOrPI/LHRnt8CrG09yYMcMA5BdQWXSBlC9FuMl
GoFXKpLZngn4JB2vDLNHZw8umSAYswBUgq5JyFxDK3ToFn/aDNGKm5aF1H7oHzJMs4wEa/H9wOfz
d1UKIbThpK78mbWspcyZUOVd59lQkaYf0/q+wkJGbw+CziL7PvaqGaeIBedIZY+971Exs7r9IxK6
khU57M3OPCextxfjl9yVcGuODT0LsVs7jHAGYWKn/CmGc8eJ4tw3IIH3hCscvExFU/iRbwWOa+oz
HwQIamy+zRfig3q2QH5DmXdhIZanVE9iTHvLKjNAMfbZuaut/K8L14X/S7G6/RN2RUfuf+rFHGWQ
+0So0jJJJ1ushS+4i0hrjPTugTtuvC0rtoYbX99xMOdtSTZsWKU5VydFa11nB6uPRzTPaiaMPDfm
DPJ+0ZuClpqSRL1KSzMe+feKEkrcbyOBfe9sz21XJFcoVbm0fBTp1kAV/s91hnOvK5eUdnA+gcdF
mPaX+LFJjXWb3ywemHsDzU84UxYX61bTPP+qXWaJvZan59QACTwCs3lhtNEWtyuNOVvANRM2X6jC
PMjCXltWXyXovR4wRrSZ8nhPJLtYjvVi6IIiNMjk82dwRVYUFlCFqgcTL3bO6vn+AGYfxlSnCqVQ
YWcSQ2CqQLeleyGBFhAo9EDG06VYEev78A4uHos5H2zhdhMsvkwBmXGKo4zGUS75Ax/0Sb4LJHCq
RajPOpxM4LUT53+bi6Mo42GeZ2BSSJtHMogbp1jPVfDnP4Ens+i3hsM0dIuw2Dd/rGtem9u7fXLk
B/kL3GhTPV6UKtx9IU293fRq6MWp7/PfOupmA9iLQH3F7FY4ZdFSZpGzwd1KvV2qlsaId3TLgwBE
4PFuW7pearEbJXWmk4rs8LeCki0DCruhYF6QonR7WEgaOk16tvuDeQADDHOq9TC01SP1df16nJGE
RV8itv/aNUqCCcSYPu9hFrWNPOTRC1nFAkMZp70c5igUATvCLPnp8U8mxGA1+D15Uhx7PV+IzqfH
NqTQTzB+YQbADazxSJHG9DkTyLW3+VGvIgdI79rvNn2yfayHDeUGyv05bdCdku5dNq2B6e/cVSzi
OprQV8fAwvKzDxK9ezuhd13WmsAoBrZVsIRG0dn8SJWq2xTGGfqL3quAmASQw0JcJxNQWjx4qSST
MO9ZdoHF5jev7Uz7sMgPGq27we6KJ2SVhXwRdX20EE2pJutAgkr+sNZfzV3iiTPV6YzHgFzKkGA0
af7a8xeWMf7rHiBr6edXPz9XDGc0ldKhA8lRfpYRs5xnGPUEx5FhsZsNn/Nwv9VcIXJBkkj0HQDN
D6ZDtxMDys5G/jB0k0GDhBfXWv6RdWSM/vIj42mwjk6TrxsYdxH04/fJ2VfRNk8MgIogal1p4slL
Pee3mQJhCwCVMc82+s7KxQFhYmdndU8uB0nGJS3y6vakCHGqirtk8xAaVnop1G2cds176NjdyIOq
PlRbm47XhTgIRmaw1EEwIqNnsVECSuJb4LPWIKcmNR1R6j48RdFmeJuBBjUWSQ68pim76GZ/YjK9
IUMaE73U41Ylwy+85ibCnAD+5tY7VX/DHd3T6E/tesxbhJ6povLM3N7VNuJCneAll8QiGVn3pO4F
mJLXuOH8c7WqyVeoIQyVi2ApsT/c44Be5ba29JBLE25SfZv8WqC07UWfHQXjksPMbzrffZl/YR03
MQw9VWYsMyzhSg3tRGGGD1pMU6L0LeP/47BtbdQKGfZNWE+rhCqHnVnjrPXWlSRNXaFe4F1EC1Vf
Aa2K/vBSkdtyQJlPtK02SsIp3uRjkzsJHR/TPKAn3yD5qImju2PN6qaQCMZwScamj24USUJP6NbR
VdNErg/sh+ZwbtMCek0/bh2SIjnAxXjTiEKCKyu5LT02wpHTHfefp5cGayyUaKJzBYSlvrp427yP
JhxU5+1QUr2MHzrAFcZ3SRQ5bzPnXGJqr8Jbm4kqyW/iov5jcz2m1miNTPkGR8XX1DoTAlwZ0uxI
8EpITpst9rWgYzJ4EizWMquvBYYoRum5Ml/wqI4Ke3fH6ptwyW/EKxGQW+9DoArE8IdxixBxlDYk
y3SWQCOaeL4NS49m9nwx4mRP6O3ijAde/pYcTaD6Y5ReuSvoP2aYKRqbAwafLwiavv5whsvDZALH
7bQzSrDNaahQ2qmpYM7vuXOEayHkI18N6HJj4LoR5wBmdHyReqqwLZWYHWNGsD9bf4Lwr+atkOY+
9LaC+UYgLfE+Stc+5JGEcheiHjaGpPO670yoxIg0zD31g6K2EDGAKLYqoI9soYPAm3Y26m+laYLc
RK3dGX1ELzTY3PGiCOrJqh+cmOViXJLYiuTSgG0UDp52hAWICx08WXcQukRMj1WAYMys+LcB6HHU
BGffVrJIXuWaOkMkvVslsOIX6k/CW9G0ND6AARzlW9WwY+NrjegMCmyqxMiGLzxGkCnU7r53xSxJ
sGPwiHY8ve0nQtKXwweroFIyetm+bXOaM2U99wI2IOy+fJ1ZtfIDFP++hjSnHGYLKyUb7oMvK9Fo
xWp8AnbHa1aNDcuKK/2JxWBpLv0FU0IKAlyxP4vORWEgfrLjPuFOA4IqGoa2EFAcv1bNzU/0dNs5
CRPtwbKtsLTlkC2bAEI7Olv2vXD9zgYsRfFAp8zgxdtXVjL+HBy4s+vb2EcA/rmaH4faQtbeM8zQ
hmD+JxzM8xuSrx0lydbvc3ueiQnHDGkXCZ3LWYX3/n5+dc4O9rEVTcHP2hqANm93dEshyiiUwFAJ
xzq0KAxtsfvCWJeRzVMS+GfvriDNFHAIMbr8Kd8mknBD49yVYK8wX7v21ZNCQ7f6q5vbzNnTdXjA
GoIBXura25ROjm6seglZf7ad9u5ZUMTFD1pNvQ28VOYPhsPsJ3MYyBW4jw+3EtmuCTBSYWAKk1SR
xzQbpZYRhrxQ4H8QMv+FmAU2hMwDnk3VfYsxcrWLE+TWBaVUrdS+0yK60vr9bREaelNDLwb/B1NU
azx3D7LzhaA3AOmhQ9iqZF9ihPWfJiwpLOFPU02+8Arc0y3JOL5I0r8tdD1sUwqDK8Xbs/Pq+fGE
RMl/GeerAq9LCMChyVtcYgU7A+RtH6RzCOrgkypwusxe3lDxOeE5hrgnMpw07KhRK269/DTwdRrz
tj1eGaiJmChzsgokOxYuzML4QDPyp+ZuVC7pJW70BYXeuUAE2ImRDM5tRTPSRbNzSCwXKWEy1OV0
b7vHlRrgt8XYC5cjwwtbdzcGbYcqguTyrnUXn7C6zCbJua0DpJ5cECVdKwORBNCfj2qofxDRjL62
hpySa8ghDJrQuIUA+rvGpB++N+CWUP7d1IFhDueAcO55vn9XlacnPIAET8TJxs3GiE4EC/g44eE0
UpxWIE82fzUo2+m8IsbZYX1xTe3IiSNDSBV3t0Vp6/yRHOSf56lFDciAZhQYM3vAd9b1cQS7qs3K
/I7bhIJYvQoPoBQlok++mkEZxH8Px7Nn2PZbFYPspY2ryEqt9jAZ7BvwNew84kfGIM6VhMlF7apL
Drp1Sddf+cX5cOuxxLqaPLLtsN2NtTPyl/LmSNOFiUQX6G8kFzNAyQj0HOn2n1E4Orov/BldO0HA
BFnWQEJLJaUWwqgu7EZ9zoGdDa66SBDm0+D5pGNpvpeXEryqeQYbAsO86Y8o8HtznT25TGaD5aCN
6dz93ib0gFT0OdKD8YdG97YCRJlXHNQXwI/+p7W4S8qnoW5LQXYE0dBIjd5KbWD0c3BXDUr0QfMz
aXqw/ovzs0YoZploSMmAjA7MpCSmQEOh79ikulNplj41mRbKf+9k2jGqjPinhfzAsvCh4dvPE2sa
fJdKvsqvP7qtqTq9Z2LbF/rq5gm4Ivi7BTzxBerBUWjVfG5PAjIJfStKyPc+UqXw74k9LjYuwVvG
kHRk8h/EYTNbHTrXwgrlVfFF/ZZKprzSK4Xz5KmpD12mpknflzX9IXzal2OMpMopD9ZPQMDVTcZJ
S5a4LVpY79LdVriBt9Km0kp6g0eqUZSNkqbJ/bU6bapWcov0J/OzqhO2hzOQcyJgpFkDFrL9pzJ3
W9v4agt6HoLlhi0jBG0Zqz85+VgN4dTisPKIV8o5k27/L747CNp+VjP3UV02yn85b4EJXA7mJWQf
xnozqdaLLvMULj/I0oyjpl9hZsBAHp608kDNHqEqA9Y9t3WjLGftOwlZLbatnRUsBK3zQ3Q6M+p1
oQMs8yA5WdrKefsUEClGeXw7HjtkwUju20o8OkqcN06/WD386gDN+za4u+Asvyti4kh+v2qWjRTv
Jx0nI213Ennw8UTky6IW8zKlkY17mT3NGKciTQkF+TrLuW1WbzOgiGYsdygKHgHhPFg1eo68KExs
TcfO37qWyWs/sWeG3scEbYFSyCTtYviqs86pIqXu1Z9NPEcbu7u2aggWflsa9vqQGU+c3F3mgaaA
c+Wo9C8cSRKmo7H5J2LdvCADSrxqxel3rkvqE4GvRMSKLRPHUZLNQ+p7j5NL5FOM/OFTUuTXKGR+
RihVJY+tFvSjEm2vzev383FRdR/OWf6crCZ82xPDJMv7n4uGlI6EEtB1d09JfEgLZG5ndRu99849
ozg+8gziZG9Nk3uKDy/NHOVa0EO2R/Iz75sonMOHw3Qde7FpvYXW3cJLEbJ8hSAZ8xShjvJGTw7b
O0Kvu/FQ3lnYjTwRZR1s5rxHcAU5rlGPRFKkJeID2pk/ieS78rrMUwOFb5ZfAPhlydFeW3ZaUJFj
W6+TlFe3us39GMi5Jlhe4IZwqnNQai6UeHqZJ7kSJ9pmobu1bWUgTRKepCyaatF7zTG+uv0oY9w5
z0kuP0LSnJ53WCJLMuKDf1M36ki1Sk0woaYKEx64v8qu4wHXItQ+hTZKCyI7wprJQ3fAfX5XW0Rz
CQwXmZBc3vF3rcwDqpeZ2BlITBiu1LtJQD9IHnSGZoW8fvEU5EmG49bfdofufoCetYi+jOCzyGNq
wDdbXZ/UHi6K2xTHgWsUnO3JMUQrsxKpooy2Ugz1yeRmaVSr5jUvzD30cm==