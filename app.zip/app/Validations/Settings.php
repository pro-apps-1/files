<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr0w4kHnpkRB3DI7n/nTjNqdo9uRmiLCyfAuAw1saKlyke+70NQ+f14SMbGS1Nyj/OMntNhb
zgrEV4p8+yR0nO2z/AmsIL85bnlo6nih9Swe5Z2ZElW63c9o8MdzU9PxuV+fao8kusQg9L8Jt9iV
hW0BzYEjVpboL7MfMvk7EU44REviOvP69sSciUWd90XjVtnlGWLZa4veIuom2dG7Hk1TOupyNSv5
eaCMxtbhmXC1jJRH5s3/cHEP6+YlG7vodlKh7xeLASVpR/ki6MzQ9EJRHJPa+gMR/vUkC3lyhEmZ
fbj4EUgr1jGmxFZAx4/r4SF6KDMXD1/oqgVyJaBZUrxRIOF2sx4U92mfVcl5AQ3VUrnwiM7s7Ulb
yVGCpuHnEpzP9qkPIgsmOHjgpfh4rCiQzkIRuL36zAlRvO9bfeGKBt4ezocIhQtciZ0xIPpK85SX
Cl02VsvNX7GvoG2Ic/+RZK25iVEWLqO3JSuNZeIgHiTCTuttTW2M0imbqn6ySGuPbump94P7edrI
wQ1ExgTUDAescEAQ/ZL3kX/JNyAtmtyoD1eh2+k2IzZrluySVzewN/ZBjgDA5EwXNAlBIlMBWI5w
RtY2FJTJVAVezQXN5gR4PdRaacnVMjU0bT/gx5xLU2QyEFGEfpHVsnXnAxg35SNWJObnP+1FEzj1
0QwHKdSiq4i7Fk+KWLmhpcbHdXbZ4ICpG9CUtjJrhkjL7HVyB7FTZ1rz2UcpA+p8DXT4nq8LZ/MS
tIVj01TisGpRmsulsM9cVTzR1MQKRYo9sehQf8NbLNTW7CrW4HOcm93fwdIB25wElVMCZMqmNoQt
Ts8MC3DpytE2lVy9S9l0QYk5Kx4WBTlKkjmop4ZtW0MjJ1dpnNLDRgMnO4Twbf/39TrlbUGKJmAA
yqvDXJd8luQcj2zueQ9cCc77zYwCoBG2EE6u2PUY0nHh5HfAQxLx7he/soFBlp6CEIqApjiAYcCN
aon+OeqVMGhzHD1wRPcGkIksDl/RUD+qrt4CnhidJXa8eqpBrVu6BKe6nWOQnMnjKWDriVrtft0b
yQA4WunzFTupE9QNy13C8ry5EuGQGLIUX3iAfFCR3doy8/ZkneFOvB7cFomwLvUjX8JdNn03ZY5U
NEKlUNwlclE8dBVtxLIuZv5nslZsWiKJCgkUBHP8hdHSl+fRuiA+jqDbTLpkaXkw2CVgGU9Ctj5j
LLkcgH9L2MzHMOhNeJKghl7YDrDLC6sKhb+Zefj6qaxh5spo/sySnPkQY2qBcjIWXitMu/kWNN7F
RSVN6I3qKyV8+0Q1Wnx4Ec701w9ab4/1hH9zihX9ocTQlM6a/K3OALomLuikqMup/mxdhiVR8VHA
ddNx/g+YmZJXobet9b3KS4rD6ifrBVPhMnJqld+XmzWU4PaEpMe6suoUSbLS/q+pBY3fGC3zzuik
U3d9DSvKSoX+tURaz1ja2z1X0ITkyVdDoDKTT0yHinm7b4Fi289zO0tldZiOJkCmPCeRp5q5q3jA
ymJrePik/N2czcQHtpHeTLvU4HH4JbTJKa3oNm0xzgvB3a622wPbxeqlP71A6iBK9Krkfr2WcpD+
CU5wI6kVTCRAsB2hibiKA24xrboi/zywrt4h/Sl1aZuryVJc1nF4SLEs5akA2TkJzCGAKNOjCHtQ
mCs8GDyOjLrhnm6CdYR2EEU1Ep3/8ilM+nCzrTjrHDAWpOg0xVMdZg0YhyOaFtrNn//lDNVInfOt
cBYvYqWJ++4Pq4yRiBeipzOdbgRIsFVWTQjRgi1WBCRjp5kgsUG7PmH2y4anOybUrTanweXBuJE6
hGH1TIpBNgPpWQ5y2rmzMcR+PGqchKUTNDj1ld916eoyqGI5Peuq+qcILh8A2DFiEz2Ci9maM4/i
6j/XDAC/TovoVIpHqetjwiuK5vzjQBpkULApO3rZgXUQOgvmmOiR7afDg4S6Cyp+qKVMe6EJ2pI/
rlR8LdVAaU8g+fIOhRn0/midjTe1CbSOIsKtuTrprOPsgG0jZIcj5dn6qO3uV7uO6b6a/koFGvOP
d9+STeA6491eJOd0X/BzPUMD+Krot5biZ1LTw5LR/QNSaTnziSRS4wPNT5Kx8i1/ot4q3orWgpfx
Lz/SDaAbtiUvf6w2FrbhBQkQgbPkswD+PHZHWnFPAvgh6neSxJcMUQMSJcpZLjJFQaoFoZ/TwRKQ
dObJ918lmmrF2eAac4JK6brQ/5y3KnfpOLXPBeQOrLZF/CbflV4oH/bmEM4SYVI9knzt4ZLd02pK
CAcKYUVqrLvYLs7ACCnzEJEM/K4+qIJOTHhybQYNFfXy2uurrxZfmq5NPvYJdajl+zQeSkrkEW51
7xEnE0VrJ2RY6y1qk3CdGwOvOMEGh4ij/3y24sTyy4P3WVh2WkPte1EMTf4P1g62v6LC0Qrd7E+Q
3+pwI7weEE8g/0pefcUDKEB4BicpWyBNLQaas9ZQSUuIpomGI14phivok9QuArH8OheMneU/7eD4
87xNxfIDuIHb/JEEAeM2SPvoXrH8aW5v5AcTpA4bOV8PvBpQdlgh6oTUOILBEtcm0Fm9OwRnnivI
h58bpQD2PCaaeHmtIElOTHVPxdgzfTXTCJIZRN1hE/UI8cgC6AGFBm5cLHAdR0q2Y6FcH/G/bnCP
auNnOfQWPdhG7Nfg+Mfs2x1d2KPqxZvgAvbTCNyf23WkVaTykOru7OXgb7ZXXE+krWXSFTWYD6/w
ik8Czp3/h/0Zzu8tslUUUWJ41BuL7hyWiyoae5qGa8eIXoKxNUr5KUxG28U95+LaU/SZy1lOlbpT
gLyjq4amCoZA/HNUrEFCVvc/jDgw03GwQEi+snm0hVprvL9FUQud9K+oD+pJzEspoWL68ZcESbSO
xfENzdImtZjB1U0Hw2F+y5poG8VWfFvjkkPCicpmkZ+30udvAXLE8qIAx27CJBjFH0QkbOMYP7aP
9Ex7BjpELR8CXSOwLsh7EHtKfURmsJDF8AqOE9M7dxqm51wxvcO5say3A9FxU99Fd0fNI6WngW+i
WmI/8MdqzB70xPi2e3kv5XH9DXnJ9nzGsYHa3wVsqAX5AScYm0UK3Ab03UEpeSxcSt2ax2c51mFD
NPsNzsKgdGfQTF39ndr6X6mrA2imLVFZQTwn5IDgNijVf3z5UFuVH7JUC4xothcGfnpPRNsjtNE0
aBPKq/Yj2gRj+jEs5EFxpMJkj6zyEkqtlwLXp1LuHz1aMRmNdwEs7LCIqSQZ9hggBO4rlICKkUJZ
v6zaN5zhcqR2BKUv68Aos/xMgK3Ad1PbSO+a1b171cXLsgTacbVy1e52YbMhJNYCu5I5Imwq46rt
cdkT/Ioj2mE9DYarE4KRLZXkInTcd8W2GbYjiJeEP+8C/wtcxdEMqyyBNjbMD4K4QsO6YorM59Ia
EtUoZq6nluaO/uQ2KJVbEa8Zm/F3SU9Xe3lEySLpXClTD7x/HJrVAxcaUBs1Z5RKQR70MYSRLimS
nUO1VP4HlAhhov3JsC7AakoLCq5pTGaVsf+7Y/n1Rb5B3wmgw1Q5W+qxte8XMX39oqj74aLtyi4s
rL4bNaIaP5dYqeDP+oi+H6oWgnHXh9LmxSbbXtHisTbxR+ZcOsyq/Y9EJTFHhjEd5DGFUviJDndN
Qp96gYD8i9ntkNPoqQbTiGpaQ/B7IkUR9/RjLL/FVBKzZFAqg5iieDH5mH8vhsF5Blskka6ehrGu
SvuHOGopPnts3x5VQYogfOJ9te4Q0bced7tmSNv0C6PgueBBwcH3bCgk6xFKNpAl4GMoCvNcGmHe
TitwPjiEIHlSEbzaLrUOqjzL5uxNxW7N412pCXJmV6AsxQVIxrq1yF3OfLDXao5xq8JBIRjKRZ4l
7DN+QMPIVUgsOLeIfLBLG9UeZP8mZl2tOB+G7q71kVkgDu9uvH79S8sQteNjYJC2Q7xSC6c3DTst
0yVUEcadYJZU0yqYYvI7f823SoQ7quiK2/rxPNy9ZzlWxsiDXNxOWgU6NhVAyAMPwctoiyh+pTLY
RDoEYVE9iuaO3v7HhA9lBE6aCnBnaBB8uDA2A6aMm1o+We2kQypYJs8Tc0bXIj0sCLMasfiLTrL4
hW2vV/3hTE4FOEZcOV+7ftu127p7R3aYlZwCNa887Wu+o8ZdeHBl5rpBXlNgm0sYtcfsL0wyYCMP
goFY2IicyDKlgpfhvcAOcIdGUjdmuX5Jd4OEbatY0vhWZNSt1Y0PMTKv2AQPCfJ+OA6HEtVz7jiA
1MxjvSPqROMj5dkKaLcz4rRLtcEGcFfBhjqBDUMY4unxacJjknbyxZsQbRXTajshN09l97Lko1YK
aMf4DVYa5+dWr8PQaKCHplwx0i/KQ2EVc91s9GELxGXgs86G19eYYrVsbvZ8iiwkakeijyRgpSuW
gWZ7CGGlqD2LITzd02VRQNZd7xfl3FFvlB8CKtx6GsTydG4H0P/RMEiSdxjwAid5TW6xTa9SHa2y
p4WfDmKEUGQmJmq5eh0ObQlJi/eGZubr9MKGzup4u01KMxgudw1DMoi4XunGU1L9Cc/aTU4KpQtK
sV3Px8lfv35Q3m0/u0CPATx90kHePZqIeUso9tvYNa6KUm/mfG+wyz/M+IXvQ53pNmtZYCZ5iwso
dNZyTnHcKWkM6ICpT0Nf5nuUdX7+uXr/DTbGzTo/f9npEbzyzZlWmNcyZtxPc5C5YwNTJl2eS+qH
BH2vjgHcJFyh7c3aJjNxVp16idqqDYfqf4uZrSCLLK3nUWuvAksZABejA9v5N46cywLLmkZS+yQF
1mOGfZAdPX/S0kHbuiWrVmPVSLdN77uMmepFaN+9pUy5LNXLfZUop41rn33auPumET7RLoUcS3sR
YEwU7aI61mkLmuYvM9iuLinbQLm88zMaLOZw7tdpvPnRumFCH9gqDv6u6zRwQzH/2vnlBAnrBAo6
r3YVtBGZYg0OSJ+2/+zkiAUFvRWtvJgnpDrO9ZLXDMIBOrn6syglKs0EWxvzZ29e9llieQp7WHQU
CmVknKJXNDDIgs7kkbXx0sgkY/Iub6zId3U3W/cwd1m3lc0hnBMYlwBSls6KJcdEgk44XBNduwbR
/hvE4/18bWr7sTdS+VIB4ge0Yw98A2C/k3Leo0Wmy74Sn0mgxvYqSDcsm8VF6RmOHFz4NCDYnpQF
OgeOUVDQcc/l8WxL4025YLosiMzwSGa2zWfHwk9cupUPus/ehBXoHjWmo71uqmAqHJ9R5sK3H7l3
dq2OOG8RoQpFVNPxyrmNcSndB6M9pcYfTT03PB+e/6Ctdkm1RoM4ZRM/I8cVJtWVM7yP0sLeZwL9
mHgzLF2rqaMPA195GWt3lxJI7dEZ6/Va18jmE/HRzojKehF94W2aJ7Tw4wHAk7z9KG4RC18e2TFL
vp3Udt3BT31MRB9gj3K21J8B6HxF33N+B2K3l1BA5W4WitPaTtSJXEIWkNVgjNkcxjk2jNn8FRgS
eslHWanCLs5eAkxxwfC4E5EYkELGa/HD79jSAlHCMOCaCTDYEqy4YHX/j0m0BJSnhVqcsGBRQ55Z
9g46cT8SMF0t1f7EldmDw67y3GFKDTwB5f50VpuRkp1NfLe/R6xvez20yHx/XJUu9Ww3fyPKOk6Z
SevVIbo1A41kfZBrTOUxQjBSCM26V4EROtyXAKIx+zkGGDTkTQM1qJ6EIjW796FGCgnXIPZY690Q
96kOnFf4kLoiFzDw81MvtQpu1TtflWMdggf0TgjAPo5wWTRM6azplXJQd31lsKeJVxGnql4xKmf7
n8mE6pEPVZWIZO+gxnHJH7JTgf0Dby1GoCUAHjXZN4Vs5oAvmiwvYtkQkHsJpSPbzDvK3N1tkpUU
94ZpQeBiTd1gLZA60yZR/pcSrYpfs+V5uryPJa35/IzbLOjBCRzSMADeY1oFYF6ls97dEWSDGD8t
k7vOSj79vugToyU6ANmMlVH/9aQP4WiExZt0bIaHXtqbp0Gflpz+dGPaBTFQ4spLo7JE7Zxwcg9w
JXgG7rg7Mp6ls0QHBf28CWX57a7cwMhke2C6EjnEsd/edaMWsvlxIr6Zp5RoauNVdTBZf4Znwrn8
CNlLw1qhZtiXwqlVECYB+UL0eOz4xkDL7NPVUVIbAfCRhjRYeQnc1xrJ4TgVD/Q6W6Cuu5QqV45o
FWGrZmwL53Xzrl+LJdbZUvE5CqjF+vVdGQAmL65bIpZPUbTFtUBB+oHeiE4zX5nsaMFW2YtUgR/p
JjU9xvpk5XEIPsKJi6uB/j7etxuSs8jrAFoNO3ufSxnr22J1pWlbMYooaCQxMkvsyWHhulb0TvU5
rBT0rbZgeF70Ua6Fb7PidOWxPrJVk8g2vsEqS5pVodOCaPlL2zbBy7qTnKS/ywWglexHNJQz2An7
dipKoOS8wpFrIWQbCEADA1heFj3r8DZtPpI8Vsv0DHzzDiifgyUYvlvAT0zq88MWtOid0A64l/1w
57NJvG+5urUtbRU77OlCZRhC3tiXeuHcqumkMD21PIOHrgnBpzfS+MEkAPWoY/2KqrSNAwR7xKiI
J7Te/t2AQTHy9Z56gqDXmMHAQJ+tDuZqvGJGFHq7QBduJxANJkbuvsU2cwWeAiVkkQHqL685vvjo
pL+yfczJnm32T/nqZTTJTNcLpM0/Xm56irVrQTvq9npbddAiasIdILxX5q1668YLV8tyyusydCF8
LdXVOVXH6K2OK65EyM29zaxSQntAnr8bCasJwGFaQuOcTUERAL6qilvEeuWkYJYP5rYiE37oq0or
UOBlvA8lXJguTM+kN6LU0ujJcTr83DxGKOVIHLTTfy5Hl/VDNRZOMUICIAQgcevBFyyz1rtMOMkb
+Lu/fKQ1rYmGTQwVAIrgEh9MrLMaHoq7L2D85LuI86n8y4lkoiMnIyaLwoxINBQBlFQaDOw2AZKh
3vn4uGd3jETMj1FJsYckqm7FXMDkFLgp3LHQKeY+Ufpc3WbPpQrValESiHlrGxC0Z4DVJux19fIV
B1S23CUFXKqk/PE7INCWo3fnBIyva2pYiP9Ik0oBf8ydWMc4lp0CzlagGi9uJB4PwaLcn2sB2Lc4
FJbZZ0jwnjkwIC5ut8qcvkMV4p1cKfeCZSmX2YUG0Q6kmgo5sGSfzFlAwvVQ6Kk9TBkl2HRaW1Lu
9BSmHhtAsEB1jJLdW4MQxEaA7f5o7sndI5uSV8q8/FhMF+ozCmYiEMlIvsL8GUlDYA/7buOuHjM/
iLjQ8ECMLA087NoeZTNg41aDgsmbzuM+qdAotKPZjq+gI52OvskD1W9KbNe4g8z8JCgWTpB8DUhB
qYHfJ5ApsPXPU7A8Z8ezaRqiNr+PrHzy6C4BFKYvCW1qSfDkn6FHHPVBoKwLmAcGiTZy3VzAhDGt
FVQhm9ELVheKtJOLBQNHZpi3ldGxdRP3WfbWX/nlkZ8c+Kg+0i8m6oRDbme34sKY4Ou5B51Ws+Ho
YrncGLTG7lTn+Ot50laxVmF73Iahrt7IUVqM6Rxe44FjCUL1J/Zm2FrLx4DT1RX7q6MXpEy5nZNB
U75r8D53in4dvLgTpnwce21VsoACfAG53wK0lNtT4VKCW04nIoLvmI9SqjbJuk7sR/U8mFgmD42k
9C6Zk58jT8EHb31alx2tLp9VoECmyB0JWKhJ+hE5/QPJSlt+c2swmyH943O8+skXYDLmYafI1dvY
ls7r9GnWjk8LYb9O7EsS8+dJRyLk1mMZG7ANz4DTzxmSZ/6l862QOHugZPR8HUnxFYSC11ZpO2+z
sIS6ulEA/zOrerJyLdyOA0aZm4GSMg4zEU6v/uFoq7D43SvB/aOlHl6PIzHfkp56OI3a1ZvvzLCO
z6eW2UaGKBMcEa1zJpdZc1N2a5sWeam4Avos2YnQATNsAR1k5auT6nq3drQGQ+NyUN8SH6htxU3o
fPllZDJwD0Pt1+bMyYULfMbQn0DWaJkk+E1TPCPkXqBh8ASdNuLTx0MZvK1cKWfZXNs/IZ/s1SYg
mEP3VnGrIPqnOfIo6mr5VXBSQrS6TB7+4mykejA4zXr8G9S5NPnEw3vORKyuqL7O5U/YYL9mfEHP
nWnOHPriX6Vy3YtxC+/SwqcNOCV4RzCqNUG66uDq48IADtiZVyzmYOiGxkNumQZAtCpyEjy/op3i
RuUCLTQ33rHpesnhdLo6sKkfU6lnemYewerGvPjDbdrSuyJos0mWvcPHNqKT4+yubIYj60olE6NS
mRwuAFeSaIesTh1NxtuwwkR9tDAuMOSnKeo0+1y1M6jEpQs7ZS+oyRAFBIsumPfC6wydI+WzBKcN
2UGZ1ULtiUpPgcx9xxxE3iGH3E3asVMQufMtB3MpU0veG5OwuDdOFzzcppIzKHnHXk7Wn+xA/gdj
6OVFPjqfADyBMPdxH4eLPyGBZdss32DgsjorVwIOlROUCRt1p0lIvK3ekTM+2jL93h+3Hlr21yDb
+71R4EinW47rM7OMejrYLAtZbdpi1zO2oApCZE8eqxGMpMqUbmsUAipCFa8tun3SGe+IijqAedNg
vD0=