<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+p6eeRNUXUfhYWtfLU4f9z0wY17gGHqt8YuECZQg//lDB4t6ycPn4pBkYO8/XB0nVHJ+6Cr
eLWFNAMrI6v5ckXKwv4GlKB0T/RRWFCAhL8L1Zzj/bL370HSOpxQeR9c8PXmDo67SFWUcMTHm0hL
xMRoRlrNNp0N6pUcJUfQmIAGQec1oaz92wwe9GpBejHMcit1e+gQA6pE2I8agV54z6l6sdxQdNqa
elCWb/EAChFgxJc88apaWQ1Ia51FHGG5eC9PtLI+K6eOota74/8WrF47JgTeZFfm0kITjrkqtA6A
QbXC/wdQ+6WaPvfFvmUeYcOzQDeJoDPNiI+vRx6uQHkz+oJzV3JkEgrCo5BH3kwTntT+uYdZl8pA
gj+nbpC+b4p0QQ5zohv2UdTvaa5yzp9DoaRyMQpfmRc3Axw71O8zX5IDjgbCv04J3J1PE6NWGIPU
ic5mAY8HP8BlWk0NNnGX/GplgxpyYFKukUEHsxaAi8XIj6uG7LUj5h+cB0/YhLQXB0x0boy0gOXw
WRnDADog2Yd2luUa3KmtwgjflIMFDTSWNCAZPUv9eBJVXirQwN4PuePOTFfCg4k1N2+IVYa43mrN
0zNKYAxEmadqRel28+okbOv52J5tJ5H5xz+K8XTB3mALvaill3TVzxs5+4iASXV8M8MEPKuAz5aN
6M2JrhHMKm5gzEiCIG7FmFXcnKKDJ0tikDNatWkteCNku2BIe+YlTHGpL4PMdp3dLHIYuzO6HYMs
jH7tHOKkN6u8sSIk0Gm8ImPqsxZwn612oMs4bom7/Y9ALUDrOGfhkzGlVEG693e0vP8QANHWVF3Z
BFDkIB2WcnzwHJI2KNvfWWtytzjPHXalu5owuDYPTXPt7LD7nsPRtUSOnRmwoVt9ejO8SbXn9CZs
QdOk0N819Y+fMJdpyMEBdrgoUbcExgb0yLdkVjs8wc2q6swkWKqgls+0P1DiS+dH3QylpvZrAhcW
HRbladLYDYIjB0+4r5bpwAQymZR0VcNq47KYqS5s2UVJgl7tXsNrWEEYqOkMY6z3bN4Fi4R7nBEq
znmR+vmwcl1RbfzEYsE6SSHP9xr6Orm/HxgAyhLhOAo/P0CcWr6O+FQ8epBIS7kQM8ZyTfZXvWkg
uO+BIHA1PYGqHzSojfghMN9Jtl0RUzQ9Q763XJRpHVXs9+XbeMz5v4BI1M9DwOd7Sw2msomVpyns
mtWAjHC2ZK0JWl8YkttyccsR8zz8vlWe2bumy/fQMOj88m527I9AnM44J3/B5WMeBZhSl1rRPhIP
3RftqrQVGLgN/FLC2DI7YViVxYw8zkRf+GELc9B4vKv6We7cJyleLAKrq1DZ/t1C1/Q+QNxTEXg7
xSN9HPYO/91I8phcwwUPGhnxW8lquYzbei5Wm5KXUdfur4plPJKiUMB1Tc3Fpq5DgILglFXMivk9
0CHon+gRSlnEqUQJ0W2zwdESwB+BskEBfYuYHk3tpmikjFDN4JdcmYJISLAGvZ3bA59vRfBTyxiC
iTIoflFrmMnk29axcVx5xB2PyVEiBxWVR96UpHqqVjCnIOMC7ovMqakiTZ9hnfBvuQOgDyTY8klp
B+pXdw+rvJikAFR22XpkM73NcLMimuI7hhL7uh+qwptItBUL6iiwE4Sq2/mCpRdx/PIcLj8lVbeu
45JmNkT9Yxsl4w7OrXfcFK6spM0YujoiuI6JP1pnhe7gP58Q0xerDgUIUK5PFQH6YLZDmCiEq7WQ
JLj+omZ2LffZ8y4b9ThBQLbBsT5BJT6a7TJ39X5k93ibkvmU6AFmGK6QN8LXkciVjIvW10YuGMmV
s4WDtv/XcNRXrFSG+HxLi8NrvybVzM6VyA3fZUZYNepz1XaSKiTYbcaVOxvq9eCeu9sEANgfNAwq
3bgpYfEHgKcu4/8mn+MQps/lMhDpGVlESfVa5CU19Gr8ARBeVl8VsXfrCN20j0mCIjdSzCBh6dn5
KJW+ZmWqxLkndb5ff8RSPenX9UyPUbMJGtVAWix0XhE+budU8EGnSBawaQBVv4pK1ANa3Rrc0Bnb
Kv3xuur/CMPiMThfHJc74m75SzBuQI6fXdj+YZxxxqopssKE5E19FZMET238MNYtl9+C5XqQChSa
j4UxHHh8hG9UaiWMuZel4mmSCK+/mZ3iFy/UTBna0/QJZNl/kFT7WhbAXCLDOQrTkh94nhVDNK76
FTWJ0E2zG69fuuV+iRjNTD5SP16+CLnf4/jt1vV1KE16SKVTD4kTzPNPuwQ4rpWIRLeeRU3zT+Rn
x3+zkHjY2ODhc25NHZLts/P0TAaxyGzwgdgDoouUQqoLuMSZ1NOqST5kLb3drzAHOzpWjDyqbiws
I46vtJVEPv6zcBAm5a0Uf1a8urF5cwbkqIb1DsyhvwVbzDo1SgF/D8MV7KnEtWLHqUW9pVGCEluU
55qFZ4XUrR17ICJ9GXRRG7ZVH+omTAo9jFw1is4/GAxmKxuU06r3rRMbA/6St/88Hrfzs+3SDFhI
vKzOcihKuHSMDpJ/Sw1UJoZKC+zaQDzQsfrVhwYkneaMvsciWQ039e39vWIGGDWQvRBcd0LHvm4K
DxUtXKK0e+H4e2//8wGJOAn5d1WkWvmeO4MUe7UsOCfPKw/rzty4El8OcU6mcN1Uhk3Tg8cJViXU
0AjMsXf1qkAaWtbwZ9NBQ0kau9eh8lqDOcX3OYM/8xbh0BMhn/3ZPmrDtrIR00xuqtjzuF5Y5ISs
b7xbkMSlMYaJKkHSHfqIwna+EilxiewLN2rqhOc0JYDKRVAW0oeOInD0AZ0kJsgJNJXFYxnrKbPz
WYVwGL2huMaS88wc3vKppIT9WkVXlrbK7/6ALUYR+irgPaygT8vCmR1rB/n9DPYHG4z8qKbG7wnL
0Rq0xepVZ5RyzUPRQVAH1h3mU7iTkr2q0xtj8UJiIm8xiT2w+FWx5BRdulB2IbdlD+BGd8RvuhC3
l8kw8dfB+iuBpiE2OLRRJ5dQ6XDLVmpDjgpwpSDiGkO237pKef9b5wFc0Xg+vixlsu/G2Z4xPqWT
C/AiFbUIozIay/Bf8e9AM4OiFmJGDVHCkKz/5KvL6jE08ZKkxWrFJfUSjDHNLudhCYACDPoF77r6
skz/l0hWI0I45RPpbs4/PeoGRImgQUaqHL+EwycY4Kb8Z0hTKiK5OZ+t8snlu/y91e62SYnWRQYW
vDWHEK/IjgsnjFU2TIQKgunpGVtLkwi1ZCwCSoApVTfC0Gq+CXbwQmnxn2loLwwbVjq5waBNPSlW
p+XkM6914Sd4R3eakvTcR2aDPpSEWuZMXbz1XO/172DO5yYWsk/q59zER5Z5HRdHoyj9sm+gSOk8
U8ou4ajidzjM/+dGe0qcfG/Ai9SiD7hCfj/i6PPTGIWOBoOTiD2Oys935ZINtM1YEAyg+sEzVRf3
n3kmh5s9BtJDLwka1ueDlSJc88CClpK7poyScrgQK6gAK0Q1WAzRfVrvHAwI8l8+TtbAIe6lK12T
0/Kjt8r8tBNfTQSRfdAEUMdQhH1MmLXB2TzGD6CRusz7KEJXcg1xfmow8k80J9PRXRcOHw8x6r8t
Xxn838vO72BPXHyLne/r7n2yBaIPwJNupUOa3jGZsRru3eulW2T7crIx1umHdg9TuzbObvebBnne
ufah2QhMNTOvXwm4QEaP85CciC4duKTa5LtuzZEeVe61ZpwwxpksVN+xWJ29MrcpVrMoK7R3TK05
fg78oOVETI/kIE0nysrCyC59aeIVS6gflgqHPzIscDhmelL3ChG068mJRms2CeeKRUUeDBpkQaR/
vmQ4I7WKByXkRrmqSMv2f69eSYiOsc5PIkDRhEUB5krh1Rjlan5o5Fk6SXr4v30hpW26WNz7cqnC
j3JrSSaflk6PY+2kPEITWImjOt36YXPnwUb1fSniwmzq+RoxjXVumpxI7i0T4OKpdeSMPpj4tSie
kSR/V1USQ/RuyPgM7uUgWoHSpHvey06s+4R9fO89qDTC/7MT8FLtJqPNlC8r+Nshfr0SXs5Tvb+3
dRBCyn71B75muErc4p69utCzGzf7O7Anc2289Q9S1RyEEllHbXvJfPkpD34BFJ/HpdKN54UDNl22
RKoTZn1qEpu1Ykr5phaNpkr6wvSkZ+7JHuCFBb+XGGVJS3IIOGqjWzIRnr7Gwvo9x/ums+m50at9
0ktcsh7noo8xgBGvRRMJwhGdNvkDIn8MTgKKC9wXPAjaG8EKafxIw0rrOwtpoPuYGIwTk99XY+X+
rkYt3cvI1heTzevM0fy4878MlSWZqlnl36Gjeam24FVDsnOMSSZa3ozr4D2Z2WCCrMca8evBtP9E
vrFwXKhVNPIQQIUn8hAnAhqknxpcbn15GaIS6QS/Ts0DfPwzRbQVxDliGtR313BXM/5nf2F9rX5r
307WNC7OtQCu3BmqceUeqhKrXInq5l+Dr5UyjyvHLG/uAu41WUcRihfpMaLa4ojbHFCzYQ1PA/QT
kIvy53hmjtiEduXRWqZs4rafxu6EWlAgd6TxVtEUGbdhOdxZsOWZFPi73WSQ7xy6Ow7GDApVWPPK
0AQ6Pk8jjZjnyKOt0oItgNW5YboMfTvbdT90wCFC+Q95Na9iv6xnPb8Gbkdy15YLhK3uiztwWtSu
xz/MnYmUxGrrZOpzwMGtFJVqIdUAt4YyOLpw8hK4oLpZEdTAjJu74bIRd1jgGXpdAcJ4A62LuPLW
36OHPQL4iZ1y+Bi08vUldX+3h26RSt1kt54TB5EQ+RH9XjkXjHlNv9VT+SeA9U2CdXddGyff+LWc
nvwzH3h79Tut6dLe6C+xfrDUpE/awocfr4et5rfubbJf2IWznc9C2Syxw0nWBGfQUGxUFtHgQDKf
qwPy+nd1D/e7V947nn6yRbVJeFAP9Bcu6ungSy3aHVv144+qjfNf8atlB/iCU2bXY8IhWQaPJv2s
fOAm9x8kl7/w+JjmeFA2OnRcdVckMIO0Uou1Ipz+ohtNrv5POoBg/YkMv9TPkBCbgeQl6y5VHrEp
/76o+biAYTIBxhLyhb3Uuhry2XPzo8qX4i5d6Zk6EKSNX8m1B8aWYiXoQAnLV5IZ7Bdg8xjY0urE
cdQTqtQKEtdu8XjoIzmGMW7HFgqrm0ppnMF+zttZ/0zRVb/NYMg+OWFMWdhlZtRlKrHDQD0Jm2/M
Kdsi3HA27Mwx5J+7R7/hkuVRTekoQfoBxcLmW8djm4X91HIdBwiYpBJGQXtx8IROA/etse7jyfUB
EWWIyudQNY1BdOwaHP/Im45z41lkKDnt2A5bWp8g4sDfvWxzcsDTYIWZHff2eTpRmPuSVSDdqP0m
29/weTgQbuI61QfHJvj1Zq0aU9ATHmNG0HiqZ4v4VwyWnbOEfuV5rmxzaVFwprPCFl90kQtOeQ5x
u9Jsl5kJv/s43N7jPfH0Z+RpuDuiol4exPpWt4IqIzJILAQOJ6oj4xovc8VWmDTG6gS89d0k2I9D
rQSFFG89CmlGjK+HXB66Y/48xmT9WVhMrDalugdYD6zlIvmVexb+DjgIUWHO/p2HwL34Evb7/6S2
OflCWpckW7nxDT+7mXnpNFoZ+8eGBPdzp4aqaNXtNl2NpFGYr4RFpY7vBX+ReW1r1zJIMyJlW/tr
3gIWwXBwgDfjEtu7q/suDMU6JUAsI49LVHqkESog7lSzK2zFn+2OIGPXPZd0u9ua5Qepc6lg4lN5
FbxgDmyfez5yMgfZuGSgC0mFEhAYnqixmLHG/0Bh4F/aRjMpO9foXWqdvFT3Wig/iY0llCNMAFqY
8u2f85YLzyOHpgVfbZIuJuALHpOk3888vFGqYpL86RzWm+j7+qZY7WkC+0RHvDVH/kRRJRCFy4xD
v56ZZGbTj4fyvmTa6nW5jJW1jvZdO/scgYMlU+/AdwEpKxq/Wl6LqmPki6iEMv1U2n+bt9v9b6tY
k4h3brbE60GqQQchdNZDJxtct38aKB6kjvMcUvQGDaguEsd7whJibmXupFOhJnq5yLfGBdHDbcRE
MxfXtp9eNQnQ0KvQglUKDaqUAFPltNRCkatvlxaTM3j7QSSsB5/LhscLQl+flJ9I8D4doFpY9k00
K2tfbalKcLi/746ASDRriX8JAezfzlniKdMgvwkkxzp6nq41os6HLHeF3AOX5/YkAdE9fftZhH9r
rmhaARIkkcJBMGLNkV/fFbpNI88TyWn6bPQ9lef2ggUd0WcuhgyDOUlswRac75eF1p0gCstnhDRD
XsrXm8x4Q89MyVblb9Ct/fSFAir2ZeE2HWzMCz4d65kSbAhgAFisZn27SMhEe1YMic8Jsdi3uGGE
JOxK3xBcN+hUD2oXTCv8UhhxxnWx8zYAlLnLav/1QESr0eRw3tJ+JNDBzCtmSPJ297B/3WWJveNa
8jdQp7L1dcqub1F1YDyDcd4V/S7nlS2yiiXw3jvQo5XUu+ZAOrCDwKm7JI7zT2aKGpypBIj5SrsV
jpgcbB1Xq20VHnk3RBtRDCyFkbabRJljshq5XiwN2U9xD8VZNL7FBsINCaTR+vOkTKhM8BMB7Woq
DRMLLqJ+qhaate+sfVQEG8GYe0UV4SbCM1muVWU/Tu+lnpSxOaF9ZtZ/3YPnD91Og0KnioeJs/MY
drX1rYGFWTIQV4CGb8o4rni0yP/cPmPJkCYRXgeb0pc7Inlbi4RTqEQqlmDN269aasFc/CgxLnwC
KbqgWXp+pBUsU0FRDPfDHjEBPEyKM66gVI6QyzmgQ5FCzYdldtv4hCuiL1TJdHWjU/Wm8aZqQiyM
CO3QyOO5FJvfqBSC2XS70+V29PbsfKTwbAzNX6dpsipXntmF3j4nevNDdt4RYTOqE5b3xPJ5JKkT
Skq2XveiSs7eDCeNR6IYa6GbG18X+7psB4vnLixHaUnDfWiI1cO4Q91F6G5rkvF2gb7XNWZKcyc/
Ac//USaEjoFQZ3b41fBWuiu8afuHPHz7r6dHOyvU17KgUye8kjfvcZN0qP3VqF+3fDDJoI0u1b+J
8X829794rK8z8UU1nZch669LXWZIpNXBf+3/uIt5NCkd7L3taofg+u5G8QnQSvxbLOKX2B2r1vQ9
tcoVfcnuvKcO3XgOzwaEXSihjjk/EjGFmkli9lZI1aWJd91WPAZr1U8OXNNoZjJGf11rzaY7PC7z
XVa8z6DRQ1AFPP+ODmE4RKtXK4HYPsEb53UxIAs5SK21rFuJ6OdjH5W3XCncABYIiU8cMhJ0LjcX
A8p6dJF7gJljsWfKV4d+aVusoZTH3/Q9XzU7YiV2BRo5ATysYnsTXp4qwxyNqTc6jbGm29Kjud74
0JbYanjgUo7ZxWETXpxh7DFDOQPJZaCj3/MZuFfWPzmpM/gQR36C630wC3WObjeK1FACnJgzg838
PaBKad9F2XpXeszqx/mrPdhFwo+13Ht9MleiPYSgBam3aGtrWaj5bmKqAOHdH9W3Itm24JSCoEtf
dUmv9JiHxGcU9XgZ7O01GFc+DmnpFuLzHC4k+qqv6Cn450YMouNvyW8NnIX2sseoXutdUK8EQLnp
OtCYLeo+OSKAHoLWhLissywRkI4o7aDkj0MDdg3ugQcEPo/tsp+rnk500Gnv03ftwvpg6j5SrLC1
srW895vI6xjnnE68K/N2GChhze0AUVB/2ImQsInoRxJzHv9DKatF6OOL0BIPK6/bIDoieN9TgXd4
lFMZyutOq7bPbJSRq+Yo8tF6kEGE85pFHalootAQFVC419skd0t3q+byQ+A/7ZN1PqEs5donSQfS
QPAvHfLRYYbxG+tzon+9mm+6COSw42tjkXKkWBrydSHKDu7ybBfxMrmPe5XoxAd2LxaaOouVXZy9
DAtKErkUenETK3kQf7YxC2mxxIiBq8zCJVYw2OPg38I+O9vt/bTybQQTMVaBC32ha+6ODYrd6tuF
cspFMBcaTBXCGmfdXnAEsLoxdnQyCfdbqspAiXGzp4EUgrLgRd04J6F/FalejVEjekJAnNLcHbsP
RvPW9qv3a7NbtTosKG2ghq81zq5HB5f0YRhE4Tjia9M1ltvFscvwUiZXbb5VeydLOMJwOb0EmNzK
iN19+MNnZCbHpumATAKPvaGCrj9Ks4WQs5FEir6ofTEkfoOf5JEBQfVcgi+O1lrCe4xTCVBbKiS3
Zsm8N+lkDi1qjsyTiHf9cwfF8u9vJ8he35j4OD8CFR5zTRshMCgCaI/GLaAeCXyWedF6ktR4h9iW
xmcjxHLTSyUPiT1ocCRYn6SCRAINEv91XSDk3OXx89oDpV4iRCfpCENgbXVbroommzrCzwIp3j36
NnUlRJCJazOE1iMp4xGRUZUInjNfbM+nbgv8pcUS2FJzBbxCQNr9fxTRXr1YTnmRHT19P9rz5lQ3
yu74W/BPoaSBgiijbK7DqYur1DaPnQj+xmsqkYRzjT/Uh7K3tS7gVq7FhcyilXDgy1CCFT21I84E
v/NEYPf3008x0GSlh1rcdeJV0k6KmstffL+uxxH7djUeHhMAEB23++UEXDTWRjF06alzxQlygqET
mXMsUDZZC5SEncglvMbpCZTpdjjxUc6tf/dsf0==