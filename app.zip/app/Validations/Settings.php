<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtehTrTksKkPTyNYT7gBzEzsc1IB3PMP8RIuQ7goCmKBOz08SgyESsGiIvwYV1RUHEgY05bk
RsECPdnt95iEp3A1t5HecToAKPx/GbUphtxmH+esS/WC52UYR6ABWwXqLvV0cPRFiOBWxK5XxmhT
IDsOi4DPmqwbGGsVhNZfw1hXiS6Oer3xzoKpvKNAv3ERvjk6MQcI5nUy0q+BE7FgXQyxHvS6iKmo
wdeRB9tvABR8cYp6rzk7czLPlG5ZzIxji1IOcGvBj2YX+IbYrpdhsNBPbUXgizlyYKhQgwyna/dZ
AdTBN7GBnzg0hW6ud+5qfCbpwwZmiHj9Emfu81+tQDeDCZuN7uM9wwuW3QOPMny+QjpH7zdU9OIs
2RPgO0TYKWJQ4fvmsAtzcQZzQAv3QDCLFUwX3H8KlWywZEDH+6rZY+n1ekCHMzig2opiVqjJQHIt
9EPaU+1FnA8tw/yKleRWJyuQfBNBPcUL+OpSSpf0YhWpvJRGXFlQkGiBTC0Qvr+larLAtKAO0A6Y
7ZsJ4Kp2YjO2v/z9pvy/q9VP75LPfSZ4tYQIrmGzB1AkMO4I4yhU+wbSsGddDyjoo+cKFPJeC/PX
inh6Jp+XdxJf8wW1TmToqWZ0zWTl8jNMCnfwwdiKEeB0q2x///SAapdh3WtbXohT5dl6Jq8XhoQd
ugrLer6JCVSSlFxApRlgV/IG8eGIRHmsetBYYhNrf74ikYlWGPvEaPYw/th8YU4CPK4s6KVaWfze
Wot6xLpVn7hn/Y0S0FdfTaD9g9mQoE0j3ZaR1A2WW/QKcCTFWjlscCJE3ew8XVttKeENHBz1ADyL
/I9h6jfjEaeZaWpJoqlvrw7bxEV73Q/FCNhiB2FDJxnvP4Ozr0HgZQRr27Ep8YSYUpcVA7kjQyir
aQ6W0xyaoryjsUtZswYCdE9upel/kXrqX0cVVrsufyFBaV4iG2NZQmth34n6ScGrreSoOT15/CFo
hI8pyvSjF+7vMacjt8mGMPUFjTbibfFfEUvu3gxVRAK3YgXdxa6fYMSFDnZMnzFLoc+33A6KeQnW
Zc54Zoi2xX47/onUIrBpJVg8EWFeEJWdik/LS9oOnb9BBeH/Ag4bUTx1uwIS4ruXGHyIPzWaxxpz
z0O3YH6XErmm0NARqX+YVx9pFOr8NtBnwPSKuChyBxyhdqXDxx8jxinK73tqgl3P3Ubx1/FpNln1
KYw3erzJ7QpBYwsg4sPYzevh7L7qgJCbn9WLsoFtTuMjEG1kpXTB5sgCLfUwRK7ZPRNI8REFbQYT
jx9shlMVTZqTTA4o2oG4qj8DmU5ghcCF733C/Ul6wmiFKCvkKIDZ/+oe2NXQgkQfwqbhbzmV5WJm
Q6vASvdj8iz8IJVCiQbdMybkfEMdgBsa1zedOvzgESDqqqnu+UNfQq8X05Z751G/13jYX1E/IMSe
GsTJQOZtcN3k58xewexmmMKAEauorwUFiwmnDjvJPyNMZ0FmuIjwIcze1Z5qxZPU5zWccwJDyNR3
3gORFR41dBeZxR3brHBqMFVjhTQmvb5lunrWvoCX9AMrMDM1I9ylruUHUp71ohVpReVKDMq9NtkL
mWZaRt+oCMR8Wu6VeXBNZlzeBg8PNBbCCKTkbgPaGyQ7HzemLvavpu3l+ZXqvDZP5f4CNx3GS59w
yKd9CLykY47sw3zM9QwQjmuhXgBE7P4GhvcH2slycnQ6YGlyOmxThF7h28etYD0QaeJ7NsZh9/4l
3vfctVd+PbcUeFSXwZi0ALT+XC+jsT6ZQV1hoFPmwpW0dCXNrxTBXnQVYagedlu34AV1Y1ZSABVX
vKNm7yQ11jLkAbIyAdWmx4aTK5xdrg78cj8lofD9zBNTmFwyOBT4HH5YHfBiB2jZXTlNJa7zWMHS
jB5G4pPsC7KlxjsaTEp76YR9VsL+JLu7fDvdrvYxZ7crpUmsNUjWA1LjiOFGtLjwlIeZdPSwOPyU
duhxnNVxtKh817pW9YPOLv7p5KnaYZGMknRLBhpdsGny1VjCJQ/hc1hFQFySE/RwoJCgOupl0iGl
WTB+jWwSTKcK/lR3BBSGbC+UQQBVZF0DTQ+/b2Q40+qG0zF7zQi5ryki8PEqvy410/dUzerUEOJ2
CQIXxODyKoRj7g+T+3Afae9XnjN35Y/h1JdXG+P6G/HeChzdi86SU76z+4Ww7qvM1bygWUM1rNAe
CqZcLLZxiqqjD0VG1GrrLinnccissfcMLQ6UETKxZpycaOcfK5SNmgJc5RskHSgwR31PDA+wuPbM
niEVEy9iEhro0bBqXSaaQm60yJz4c8ePB3Kg3tX+IrbsoAKALceYja/9D4NPutlBKxL3X6SsXrU7
5/GHRwjDRCWlUO4Mfh1O4oHPXg5jB53DtlsqPnP0o8AerR6Ob4thl88GWWeEGTWPzI9Mm5T1ClEa
OsH6p4EX3w0swyFo3wvqWYMdA7CxvL9yfSDTM8e+Z8teMkEe/yQlmbW9+ViCyLavELdGAtkNUrMt
rb7vDyszXQfQNh6Pnfv4Dl+K5RkyW6HdlQqcwHzEMgG+lzx67W2ZbewukpFTv7xHphidlniIjUFp
/K9mL+l4wABcz+4MYySV3qSvtm6JVtecAn7aJV3s9furKadxpIMhXYFdbUSRwA6FVOlJjrVxIMYx
sXtyBEO/1slVB6S1h3ezNsL5j5V3zaU1onzL3jLR2FZ13jMPKSHozITZoYNvxqF/MmELH7Z8RVpT
REks/pwPigs4U4Shc1TACns/2Du3Gl+sQuPBoMh88+7eeaaYS1mFxEw49pU/vRXxRujSet4X7R8M
hyrviv00O7Y45hp+3I/n5Gca856PhkSgD9oRLePr0bhM+sNZa8ClfEKIdKeEZIcCUR7xa8z1eZ/R
kmbfcce7lrtTjd8UmDPYz27mqrpCts7U3HDQC9z03hUbK+ZNyPed+8OEA95n40BeGRpAcgHjt4rP
y6X+4YJr8A3nO5ZjYuU5xCking+IKxJ8ZCXcDgI/DXxy6ZNVp/Bu4r2F/eTUq1oCtIL1DUGUC98B
suQOA1ZTaAc7TyZ+DrO/Eqb3Fa2h95DJ9755ohod/qLfqjkxtp99v9zTYh75TXQ4saZnGGx6MMp0
Y0MTjaksny8OYR49rlpj7VUXmuv9Njmiaxt1dWLNHXP3W2jgWauxtc4Du49QSpaSf9NoYIYMamsD
r4owd7yf6znRpqoTuFYmCfOgz4CNARtE54OVKn9AJLUhzydHBWE4baMP072Nk09tpFZCI3xF1wm5
0L+hOZWDNNQ5FzG0Ya73pcvTvQ4cPnGoAajI9/jjz2hRuVpKb3w0AbB8gAlsRyX4+eK+XhozyI8V
L+j3UHwDeyrz8cp4U8Lh/1zvLceQgQhAFn1JqnV/bWuGcdCOh2cM1HbWhwG1zAHeDe4DXsiu/oOC
v3RXNmCATbkyhtNXuf9ptrRMy4zlOVcFRIGgXusGR66v0Y1+wvh+xsevCaUufBDpMs+EI1UOZzyL
GqPHKG+7JoBewnMHHqvhRuneDAYfc4IwHZkswOQGNboXB7TwUpY4gaZP/5WU0SpwVZXotPaxTghH
HUeIHMS4UxW9klx2qt/m8ANVr9i6GWO1iVsTpAKNxo4+J4a+9MRwLv4mKbanesHogbEoB6iIDFzL
eITPCflPcXXeU/58791oLIIgLmXyMc+dUvdPJQIFlHg+PLivwDBnHa8s/eU5kw0+olzKlt/xvABj
0S7pSdXdHaCr+DZew+sRPJxBpg1jXH8mSMT27/VOGtns07AcxZHS0zhgaDZWHRb3hTxB9iLceSM2
NSs2dAjd5G1y8dM1ba+Iuauqxfqb4GzguOSVkkPmLTuiNe+tXyapl7VTGp5BJjswVk/ElZ44MEvM
U4YzMsDRVtCYl/FxOv1ULhuQKAdXgTfmmWespJW6qm5/8G5zdLyVEh8BzmiZMqS727U94h65+4Cc
i21Z8ohxmAmJHOLW+Z2KI55MN/czcWOK9isUM+LT2Mrb7ZcZ2jWZeIXVNQnNyfC5hi830pusAKuo
JWAfhY5LyoarUduvE/ILS604772S5UVZdw27pCyFrtB6mg46iOVJ6TkCiQqXz7xnIWRweCv9/WPg
5Bm/O8shQmb4gyZ4iXN/2yvcBREKjK9dUBlTTelf5QAV8adx5nskx6BBJqQb5qJix1R3oqhPgIPB
cZHxRodye/FE5v80/+zasRgUFJZszB/c43I3HiBIP1QD9YyFQwsGMgGFSZ2bHfSJure8h6apaeiV
Sr4VtH7zfm1fSMX2kY1vxZr0+KHvbg1glUzgHotWoNLnATXhgMKwKzwjv7dEnQqO4WlewxNJdg9U
05z3EgIkVI3T8Xsau0udNOXm3fIHPXcES/prAjxRFMphBHzP7OaPpGn1tz6UtbUCXXfiAEk3oq0H
JvUTU72VYW09OPPIkhe1/2tgEnFpe656iOfq8npS+cXYDk9VGIDBNxR9DM1sBljqtFOwEvrH8Jc+
KZ99DjblGwY/AjWsA+NXf5FMooAqNI9Kqkz6yZTUnCTOy42lJ7TqWAHDDC27dx4VlJup88Yx5ODj
XSC13GJ0uKBId020s9aVhX2sBdICxcAC4stKFJL+Sdm+3OuKk4ajBW/Z9uxi2GM2LaVbU51sHmKA
5F4Ii/5CwGP1G3eZii+m9IZRQMlz1V3CEgqPLtRrsEWXsuswPKXVuqpByCaGc8w47zf+LtL9ouo4
QjLHKOtA1u5M3lPOsL5Lkd7nZ5ELB/9/YKq/WlzgRThEFuhBIt5l1BrOrpQ3nrYrYXdvvOUime+U
5hyucRd3HaU+bpd/KFVTqhuFmrVbkF1xCpKqmsMRcT2BzZZLez+j8HBULLzDchpAgiOF2e5FnSef
VYPcinKmDhdJVLlnWhlVkON/fxUhFINZL7jBWH5V3QhYcYt1hCbFTmvVl26uBFAT5x6IqtfibSCT
pGUdxfRcBKowvo/sX25GxKKdtEZIR9IvwRwPr3UCt38ghOECN4mBqoE5UmnDP9zw9Qf4fdfV1/Dt
J6BwLKtutq4wa761elQzOlzLzeN6cVmaE1TKIdSuZt2q++09m0cy9BjXzv47IyN/NNDUWpRmDA52
f0s6eOjkjrPgDrRcenEdcKsauPBLEUrhRKRqk69ueVGWsQVtBetVO/+4p42Vis1RIq8QfBIS3pgy
ZS4InA1woUtw28zTGuKCiQ+E6XGwfPAKnPdrlPMX1bbcUwfQoiQCeG8gjGWSq2EOfPR4DHvwzYen
5aPtbwWBw4WJDJDubobgjiz2Pidg3yM9bKWZEb8ODqhbn5kX5q/GWVT5DOHT9IRqChvQhBdWcBgb
mICCcVFPV8bgSdexuD9Ri+zg41u0EE4l4epZIJxwIAQ16qH7PewXPwM576ptK3Crp/2TwwyeXfNR
8KLv0rLpWxegHyaNCMP8jkGUzWE4ZTaB8XdBqahKmwpQ83Bkb5bIQu+4ng+cLrabbz5rihRUvWpY
lPUsRSLbSAan8Eu1/+CIm5jU2hDP5PFJSm7i1GcRzy86tmfxq8xTxB4vLv7YjD6FVuw8RFqguJLu
RIxISeA/jdMLqEapXNQLf5gaNaVAGjI4EBc2ROPF0+YPikZ+nKFITnEG5AvlqvhSg2Pa7zvPxc1W
SBmivpj2350/ZgOV2KeEo/IXTRBYfwX1PS9/SdZyBrJ6U7V4PlWM/Q2qmZwgP+i7O4p1IoBVyQit
mSKpi32nQo6DDR+uCAu+x9a7AS8ZckwICNRgoIq3smmDOeTyQCGlLLIYMETRm8ocdaMxmfgoxYq5
1NYKCDs5GJSEcE0eg6kxzXhfsxY4+x6Vu/KLjnet3BxW0TMVQJsD37zkzMrtVrWzFbLeLJ4wzV+h
b9sk4ORfS+eHQMLP5biNOgTBONvNWV6/2esEcLSwB7sF0WQbM57JNCVDeynTY+8DuV5HvIuAzlo4
TuelfiwMKRaUElFW72+UhidszDbWe5/eJF5FwPtNVp36p/g5HUQVwGMGpq/2WK5iCPxvnoBLCgmG
K2bKG1dEHQY3YjWe2qUdA/73c+JkkK7z+4zcmDpQRRbK/2ttWy8bhxeCHneDOikr+ZlHlJXnPmve
MCjNtqtO6L+XCfKNPyZxsni6BYBoIQM45SDTnVY76gqjsduLa58AftGiCDaxB2OLTgrzl1xEdrzY
8wCx0CawZ/jRWWueIvEU7CdZ5TvDZAbTDMkJ+g1W0F8b8C/zx2ChxcER2UDJlFqUuckxnEAMTis0
jnGHQytPxUlV2kfe7EEHvnNYKrCR+oW8zBMQ44reL2QK7Fx6yXl/Ui+MjDyKmEskyy1LvEqbJMcS
Euh1TwXf5URKlum85uizO/EwWJa3IROem9CNYefbZ4Ya/EMlzgrpwM4Rz9KOLTXvVwryRu0ss2LM
UQfLO98fGHxH+LFtiQ5r/GRHOlQF0Eo5PzVDXKWjLejqlljx05BW6BvPHQepBzUSVaKrvLOTtauW
IdKnh8/NZFJy/cMj6KLfCs+7m9y4xXdLKV+44rZj0oTDdi+XUkZAzTmP9JTTwNz3/t1W2k7W93aH
eV80XAP6NLKcOTrwAwJJw1XFIjQfaq97p6hc1ltOx9QrnvwklIDhl48sQWQorcHHdbQoBsYtwJi/
LeMRQ9jSk/HbsL5678ieAL/VnrZpqSdmbDO/dM7gsEmZ1NhI18F5DGFFdZ4AIITUGfcRX4cPkeKv
fC2kYhq7oM3z027XNmKPIjYZy4XcZGS5I/vgs2chICyMNhcXkvW1LZjW7l846JhPN6DKVkkUH/cS
r1IjBkqS7hI+gPYliyC44okTrhf1g4IZVkBdWRS5iACNjEyk4u0k/AmUsj3gJvGlstRkRkOQ33Bv
T/EJLsa/V+mJ2IASE8G+y89SYoOOJkkXOkUSwawol5uUT/PKvP5wI2K0aJIYXkOkveJRblogNPGz
NIj/BIBSy9PThilh0vQ7dDPrSfcNgkatEFf1hI2cUYBDyD+lMs998/eT55YrWw01ifSN2lJ3+g/l
VHCkf+LVn/8e1BJ37FX89bGUapPAoKHR0wNdXDSsDDoKf0tZu/ou03Yo1s8lL0dXshvxyOScWhsX
WIixxLqX7uyGgtrCR6oabanbP3+enZ4kUOocHHqFOLD/YUF8U/7Pnk0g+tqx4aVUctBn+kCGXWOY
ZK2hABRwPca5P6/Llf4H3KB67k1k3Ysft7X7q2sJp/drxyYD2Su++Jd0GIM266GQ5u80Ol9zo1QM
VEvDoZZmkx8A9/koM3RQrwTQnVghkhAqvVHM+QNz0NUev4qu48xIeln1WHYFb58UcU60HylwID5I
LYLUoYybi8NAjQIL/sVbKVx/1DLmkpM3c5FBqCdD5TWMK6x8dQiuNLeZIWlJcScL0ak7dgNeoNOX
QEOEdom+5MNNgsjI8adv0zoVGqY9oRr3MnAimEi9iWMbw/NDAF7Vh35bkgV8mpgGKkNwUYLj5m8u
lTmnQskh8QAtzJQUzgOAqF12CqJYLoMePtTJbGDeFw8+WEyf6a/jYjzSitZE2KuidDMHXRy2Gkpc
bIZUu2l5aCGzL88NR0o+3iiXsy9P3iaYQ+GZfP5lmdZwrDjHm7ova0QLwb+PcX+KZdo8brx8TIkE
V2dWM0K8KEUr+YmWMf0bGPqwU/z2x8z2/s5DgL6r8PhT36/NUY5X7bpvNsosP3atbxGQceBe3oXG
8zy67EQIi5uhX9uBE/AE+Cbe52imi2oqYXYPC5vTqm6lV6dYU1bdp1BVzSCnZ/cEeWrJMS/QS52I
VbJBpAJIAWuPW/ZIH8M72Yb4iwzIXeFXP5bnk7Pq60gLAjFE2qlLCfTO+01h7rk2jA1GynV/sAuh
j2BAmwqI6nqW3jadpqNl5K/IJ65Jhor8w8nGrs/unOp8cTMrq13GIZI9RhJenVgURIUpGONtXoP9
x6XaGznmzNG1chsICzJXeStzdWMwPnXtduvmNGMxtvrAn97r3OCwdH7YJVrEO/fRDJq4kcrSYUv3
tzJlEv5e6KvtGO+xeOID47jcYsTVXFVMxFNd1Ucznb/TRcwDQ9CYfq8r2guefeYyTveSg2dJiGFb
n9N4EwqMvnZbVBMgUeoL9G2B2uBqKpRsrCDYqikmbE9i72YVtFjDrwtR0BC9jGiB+OTrg1q28QmV
CnZT/9wgx9g0AXNakegq9VXOVe998LKJYssC6+NwvEwLNg4+HtEOVmOpkBRkmbIOfOAyPFLEREqc
J9j3ccqO5dkYkyongVxLnuaBh7iG7O1KohIztVi6rvfIUGSdNE7iM4f+cLb9DLbd+6yrgKzep0VK
kFzEpA031w0flg5gp0TM5N3Z/kVXLgrBv3BUkWPbMa5yCWM/Bsb1iRTGYTKPXc1hfesmL7g4AnAv
0arg44MP5A5tAmnszrxV05mYGbxRanxM9WXog5/X/w/dgbnRSLqQrzb32+NwZNVm0Y3jIecteMr5
rLi0lVxXfsr9qriHdrwt/md3gpwVOROeJChxvszJQ5AiYOUnbDnKeZ0gOAzFY1Nx4MrpN1rJ8XhS
dOHKa2JuycsrcRSHEhyit2ryk+5WSTOYNMkEN/JPoGrwqIEEOgQ134C+WaTOoOT2ekmz8f3kdA85
DgiNULFYbm2oH8iMtV8n1Iw3oScMf3ucVY4=