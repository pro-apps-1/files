<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpqTIuzDhq+X2FFUhC6j1VjcjNonZ73qjf+u7Hsa/Drhnj0x08B2zcnkmDAnEoAysIu/Buep
SYiE+4flQH7sNgg/wU5TjX7Rdq4VEYezeJPa1kvmzm61z4jGz4KGSU5sS+XAQOmGlzEmIo0qYJwQ
KMVqGQ7hwkvDAZrd53AeZHxzw7IxNWnA04F58ieivOxDJ4Z4jZvdhsaivdo/EBP+7KI1nEuNQBBi
pm1eA7gxROJ0mTkNQtQOFg2lusI4nzbhKvbX/DTf3JtsYDJIK7OUWvKJva1gROM6d7dzKJ09D9lJ
bh1o1sXYnxeK4lsIFa3ftywHrRF4KpKJNA4Y8fEWIm6mEi+PRU9jiN/BajI8l1il2EInot2CgJ18
z1b7rNQS+Tc9vLSN0ElluJPIrkPVpp7ZX4y1LvzvQIrF3wKbE7/crxqLxEOj5YPtj/uCA9zK50H7
1rln7hJ+OWeVQu8iKduNVtmA1kv0HGUVIBpzENE4ZYgz7hT1lJkHT9sKRABqdSFcAh06qPdk55BH
yx2A8BSROfq9byr8jkR2HsWcSaXlcESztIKl2TpUNGrXJkLAYLz85qqMOz6V8lsAyn03sB92Fhrq
4+3mepR9kLQC73tVjhX0HEhjW2I0iJ4DPRNdphEDsMjdcyv861l/kgqvrzOJ6dxV7/6BmcUaVUrb
u/3bMoRTZNL6biT3Q5+Y5gx4Pf7NQFxuOrfx9ohNJeRkoD8j6A9lOUeAI3hoet++2PNqZBzK3JkC
j4fs5GHZZMpRIv4TegSiKvefRWrb40/Hl39OYaLzwz47LtXZMFDzWnYu0KZ+iImgm7BhTDYFWkn/
pHQptRy1XGEi7opJ/k5Hns7V4ltl0+7llQG4EnDhsz1D+gBiYQchZSJtr3BWz6rVnPW7x23/gmYh
KbbR7rjvxPtvOKpX5thcyQb8otarIT31na+OZa9htTj9/OugYv9BKey3hqjRfJgzw70d7ZrjGuGK
7421XP9FHbaZ7OzqdYhgez0tbxmxAuRAW+NAjS5q/nFhYUozp7SqarBk7ITNxMvc5idSZPvtmOqO
uxEf1U6k5ouoMbNmBag6OLexlr4KhXKXamJG8wBrJ9xJR1vRfJU+lFtI1qaTs/2ecfdcKDrEjn8U
ndmg7OtY1/sPqDZLW8qUKcy3WX56MT5IMAY+Q/XHeujV+VlOEMPNKfqq96yfTVSJInhVR3teZkfO
ICVea/DGZDMC6eUh3K5TOshKuKiSbdxw4iDuLzLtuVMw1ipsQBOTnsUjq/CIuEEep2O2djt/Qu00
dgeJteYtx/aUvxRuUDb3oHNKuhF1Csdk8I9lXV60PaVLdlUvzhVBW/1I/oouV0A0YmM2l8pLT8M+
uvQQezkqBr/zG0nS3yJl2nIbIHxzZfaJNwDB6HJdzL3SnqOveLYpSEhrVi2fJLGUlJG2Rvucte5C
kBGdNTNK8bzOFcSl4f58zoG5vgskJvZM04K0FgPkZkXMBOpTiBB6Qy95QBfe95bhVghAkTu4j7aw
3M0VqlGlyEJxQrYVaFam1pkFSakzdeh4v44C2TZQVe3fI+fPteKznUzojW1dL2uUmmX+sT5tRWcf
Ym52YmK0JvfjZ0UAftSpgQavT1l3StXpUmAnX+9tcV3eDVbCwfXoXp9XXPnRqHqrmXm+k0dlkN8N
wUSwZOdaT5/X+vNZpmCpMsbo1+Xhok81RozklHPj4cZIuSx+A9Yk0q2tXrTANzOcbZktyy1Z0cgP
vfdxFgnAQ8QxWpy4oxncTJ2Gl8Dqmo5PIFuxLk7cqH899ELkb+V6c1Oe1X6c+zCbi0BAkqyih9R4
3MsYiJ39OMZo4WkjY4bDEzAiLoJ+A6MNCEk7+t27X+KSzVRoYLs2VKVhn2IL0JaqTjq3he6UUeqc
HzzoR2OBiQS1dG2723djWPzLxBlI/H6/kmO9qRsZOfpbJqXY2XCNS1j8hxoYua/FjEz035GBm/p3
S0kz7y6T+ge+ZkY+Q8XEfOpEZ77+N1UhvPOwTnWYXm+3UwVm1GClDGn1UMBmJrusK9LAO480YpxM
WEjG6x27v7lcRoag8jZqbH8/vsX+8aqwZZGa36Jag/fuRg9VaOBKBd8myshrMXvBdjuJ2PyPw8lV
xrVOf9EZuOtnT0mKXSnFFYeo1sN/SGFYbwhsZ+8EeBJ/dT9h4QUtBqvVz4szfBWhuiUmsYHanxdX
vG+F4wUYnbItikyL0J0ZHqbdtVn1hwOsC3FylZVHLlJOLU74mo2HT/rgrBcAsQbOrMICMZamq6DP
C9RrLlPFSjIQqZlSwARI8FbjPeLJitutbZ+zhy/3Ko9wE2nF22hpydSS4OGClmejs5j4uCsEaRp2
dYDXYvwqArdSBLiXa97k9lGhMJvUQAB9mhgc12f00Sw7AeQkKHipmZv0P5ywhOhdGgNB3chBrwLZ
CN7/icm3HGwics2sHDkXnqa84jbdVCykk0/nzv/PHFhyn3YFXVcclk6TQOry1krsRRWYuTQCvMI5
zzEfne63gO9kD5o2ddKG47qUneaSerDVHNGd6FPTDt+G8s9Qru+aXiXdxUepc5gq3crJIECb4wsJ
hEike2ZocGE3rzcZEGejvL9YzyTjy82BYI1yaPKldkBcZhHHMSEovA7c/7WVWK6DJSpSI3YNwuEg
mJOtC1fvlWwyDFHMWYzE3Kpgx2yDfy+v4o2g4bsEhYuSJ5FI8jAyfkUb5sIqgXw93B4S0PPLgcBo
aitoimd/1p6yOeUE1iCJTUHal5gsaW0kDSYHr+3rXFUsTV8XGiZKtNHRYlsgjEEyeelGmZfP6HMG
dnktjLU9Pd0szyoz8D6fBJ1SX0XvNIsgMWDSxm3LWTOE+n+K2ttijc8HKmboB0OvT6CXdlThfhKx
fMk4Lti3PyTcEM0muyb3KsJWo6n5WiyTgSRzdSc+4S6yWvuZQwxmoSuIdxuUjj7Mai11ZVoTOOi9
q1dX6EGdS58prXlx6PIEVo2SDE9MGolNT9zNfVxAWNxB1l+AIRdIbEOF9yQTbyPwjdWU/LVC1RpK
tTVeUrIPPQo6tmEEsfkAtGpFsWzPYLToEThOXhRE7t2N8BOARl78TKJbswJcTgL8OdGi76Hl/UUl
jbrwlAFgYw2DHSKiLoPFuJBb5qs71NGvdVFQ4tmJ81tn0ezQ+giLLTHcBegiyPvgH8JaDe4hUOtS
/Lcu9g8QV/D7Q8Vk52mr+jAOf9TeRTqMu7dlrtW23xYVPXHiKq/eQkN6sJLF2BbiovlmvsQud9nY
h4HPxpA/dGmC/6o35DkJsHAePxxCr41Hn6jzwoBxiSV50UsgynqRNK0hzHz0Hu1UP0QAigWjMzI4
XNL1tXNXFa+xn+mkJXXrU2OjtqwP25urxyXcP6MB+Y6oGacCNWLZetcNieFbsHf+QaDsNWi+D8P8
NG/xDbd8w8LoVFja/te+1bOWWFP2mO2MRZvl6nuPrpqROdbQaUtqNKF1qPgMQAtENC3AS1dLIrbR
pyUSYrIGSLOrrAujgIYrCSTt9NpXyf5/IDeGrPP+pUCZqhqQLcmW4TcOe4W3NXqvUkZE3/DNhS5y
Po7IkKRY5J06Uxr8AIHUepHtb9ESkmKBp/aKZytuedjB9F02WS++BIiRsRwhQ4DV/RaWRJfuFNtu
eIGjwYYOhHeJt3tRg9o1V34ZK0u5V6+fYGHW5eqbUl6yeC9W2JAA7RqmXXWqcAsgz2wiWp8KN0rt
TECHhZBEeXjW4zZCGrj9cUdyL6QIek+s1jnElWabLcMbx1Dl285eQM4Qx2j0xzDYuionFcOR9Pmb
kpkLhhKeVn4pmAY1J0Lju0kPaTaWLzwZLfES/1KTRhPq1y4168utaeh2TkYzY8ybDiw8MQJBGbXp
fPUnyAx1NqyKxCry7M38G0uHTsiYeMUWg16121i2MZrpdcF7RiM+kqg5IaNb/Fd7T+mkspHXIEHC
7htoohnJsBUZQ8Nb0HDZ2lftHktjLW4GJMMomwVg0KfjWK49OeGFP8a8OjWVecpm9fHyWDh8tNFy
y3dPtoN8HPcjo6BP6kQersTxI9HtwAVoi2wOW4WMYuggIhprCqjNzEDa+oQtUEbj5bimW4tGIh+H
QY1KvUdXDo9AnSgnsNBBzqORqLtlTF+s2s1Swe2UA22x/22CVlMGSNL/kNVAHclyMizIrnRZPI9/
d1Ab1HKOZnWfH2SGvFaCpYQa9zQozXAjHjvqvkkgkZREHTea4mHiLE4IfeiABnP1GFMR+KmR/Q2p
oWznVBw+Z30iQx8huh6v9GerB5I+kbhT3p66IkIXDqEpwI3KJJBEjxQaB6GQ4V/QHQN9rEzfUzCf
sw18Ky7wXw7uPG7KrkuDH7/n4eJRVgYw4ObqEXnK7BcYFfouUY3caURVkzAl0yhdAXIw480wHbqH
1aRjV79eQnTljm8htCNRLJOYf0Lak5HpjtbCC6zb6zbO4Dx+V+8WY0KaeYxIeEfoMXyR/nnt5Wgs
N790HYTX3Z5Nx8QAZq5H03EpNnSOlQYFQ6Ng2oTS/WSZlPts9mmU7UClhlx5wK3jEKqo1/RghK2O
QU5kduCnJK9EKzPr0oxfr7PBi4LPzLw8TCtCIjPC8kneXKe9RZ6wST/O7Sfn07ydhOvhNwYDWnz0
us3ODCQFJ+/cg/AArvJ02ga3+zu+HyUYdXUo4RYBT0lAV4Letulih76DRoDYlNDr8PArr5iadEpn
6xVliYMmRW/AZ6W7WtRvsB/ZlvpNxFL3C7HLY1H49Nxo0o3dTjv2Inxao7WsuOj9TipsCbie3IKY
bShC/YJrI2TQvogaBDJMn6ejS2Gom7Z/RMhcMaKli9YBHA4EQeYz0CCCFRdg1D4bgItZjOVL79Kg
GOhz+ZDWUkQSoNBJkyoM8yV7dQ+UqSAaVfETfp4EUz7BA0xVm/LbhCG6oKASvKBs/MpQMa5hYJTF
WByjwKQxJ0ys2OrgQG6J3Mj7DdEThgTuNTzVaWztu34IKQVDuOTLTi2/hd5h643dTsGkhFC8YS0W
BCf6mqHFju2a/RVDbQKJWCEByxVVUXMRXH1hXqeHEQMyLAwVH1Tl5gwhCl6Gqh0n5RfAxNA4Hlnx
Bu585lfULiXijzEeoseaIhv1sWjHzVGki6oDvvJ6gtmxrNE25FFJv54cxDESKeqMlE2QDuKOa0iR
0qP5W9u1G704Ta/9TGeV4L5ZoxmOOaC1tMTi1rvGxioXfF0H0ringkPyCDSzE8iaVpRAH/MRfi2u
ENFZ1Ocp8BQf1+rsJoHQam+6oV/p/epu9yApBI8rOTieyMTbfsj+0tOC2+T6UW9SZwBn8IHDqQgU
4AaBSIDzLdBHdmGJVcw2bq5SUO0FlM0qhWdrMpdt+CQ0AGeUPXDXApinBu8U+vKt/fJWfeXVmPgd
LwuUR8dr6Bzrq63NpGAcLyxDcKBWiVIQxM86OOFFL8AFHKKHQItc3rvIV8IJYU7LBWK8hCJFC4na
cBQYxAUJKMzwSrqYOAn4IxM8BXl0ANk9ReDQ/miVLxh1tLUHpJWE3okSjmtIXCaw++6M5/v6nGA8
OkG+ZmlrM1g1m8ecseS0S9QAAvZUoE+3a0uSy206u/IIKHe0KvY7cOaVwxIwr/YcpJtOcwkAuHFp
PjEpdKPUrOobAbeRvwqCqa9f2TIJbuhfVqHShbd7/NW9s4VjhQjVUJtX2qVz6oS1wGK8RSy588eO
wICOaakenGMC5HFM+8RmNmjyA5XYk5l0XfDZsOFYPgCWcJKGit3w0dplYI2EWI2kmp4c4a/1gJbv
h+0fJcVlaEyQyn8KuToVWPhUlWck4j9u0O1lbfbr29mP3aE9u4ub0lanhFI1W5OaR/17DTqB4Kp/
sUjtzGOzCqBGzJEXQok+g8Oe2z+FhgqmlKWZjmf/Y/l5WaAD0BX42LWp93jO4mc303GwNW128hIk
8ZUg8iDj3svFH5/lwEX6G/VvTsjyzKtw4IlKvyYcIRrn5TgqplCozXZouOYJ+oJrVhkPVXcjCQq7
MrDCBEPH9iNrhFeHNNMoHLaFZ5F2w0sgYtUrIoeogatAbUJ8W3vBdnW+KLk1+WFEuSum+m21x49s
ehmkFK2q1kigCWf61qazzPV3d7LSAREaZQIPBbuVTxcuLL7LES1SvXntGfBb0IBdrttTwEEm9g6b
BpBphN39Oj7nvqVwmEIH+niBy4qtsZYqai8O0V++5quuED7A/ffNm2SqX2ZuH5nlG1TRs/Bm8ZfC
ywljiv9dmKw4AO1GgRQrqjiLhCk1xl/VQmNHSWvuDwlPaRbxh/OZRpk9ygC+NKvqFvwzisRZvuJo
+x5sVQ1Ed2cU5t8obshYzMlLneB3Yhj2OkS/+hwpozmE4bNWZE5NAaUtqbQJDz201MeLkxCoO353
xEmmgKP+XB3YuPP0+PTlOmO5zHLKWdLoeagowzv08zUniTWttQJpc66cJr1YnNTodMrv0z+l/rmL
fMbIeQKmBh6QRGmbiUdfUa6Dz6gwqPcV7aoW0BoWkRJnPfKP2MF42Hp5AW/5sUEAw3Tozpqs7Pju
73DF7+3BrZP2VnmZ2tfrNgsMr/FhM7A1xPuN/HMOM3vhQ2dCLYVx/w/QbdfSef1cX1/6DwnFq/H7
R2owCU69SzJzVPDC4ZVl6Rp6vjoLeRfVM2JoafBicltnYU7hre1esQPuAGd33oAXbzJbzTM+x34L
HGsjZgFDTWBfRSv9SxfR2IZtks89X4TZO8sUdWXoJ0VoWkBPVNnfsnEARxaKWHCVfndf+krwD4UI
/OuaZl/DVV7jwj7ImXF7UzdVB5L+PLZ6wc2lKJNy0THAqKMDTprbIArCD2nPKaLnI3iLfM6W7i9u
3kRX/WVTiSpn0RvhZFSAfAoQpN4ww4Yifpc0OiTKY1bS0w4fV0UKYY4ojkBPYZVkna7+qSUMKL7G
nmIvpCLuk9ZjEtQwxYOx4QA42wA89rBYWNQK8pg30Ic5bLE3UpljsrG6IICwkwbFwFnTTIIBx3lC
ViGIqpAkpA2Sq4QsgalKhwoM7DQlLIMX3JMHNzvTIEBUf4+pt+MpIfB9oTSfWtgJxfzQoCb6+MG1
0W7lZm+XfkA0em9jYWf4XeURG6e1lU+IPwwQ1txwouNF5gLW4MGBlAqjMnfk16PBpcXoNWDB4MNi
YJt2hckuZEWWjaI5d0cRTuEx/ywrpLudST1y/OGmdlSYo3NNmok+1KQPST435PVyhkTtC4lQ83s2
HUxMgaSMVMvYZaihUVzmKcsZaaIpJoAeo2ZrOu0SZLkpbW8qgclw1k4/9zNsTNiGAIsD3855JNub
Dn8IyL6+xO/Ia52bpoPRbG4+4hsaXhTIkPYf4xRD49ratCnWM9rS295XWIA+1NU23Ka9Iy5zBVeT
7wZ7LBbnFbHclu/HII/DAn3ojcYDOlO+1r2dUM/vaBbFFkhiffppc8NSDeTd7GPicXxFmjFJe9KO
KXD6jqy4Y0L7RlfQpT0KoDcXmNHb7tYEbDD4EruMk2FMP5xAHR7s6/auKG3ceUQOthEGxxByqPEn
STb4yZiTVlPb4F6Io1AnP4RtqDL1gY6bCZIIMdVDoYbf6P/9HZOPGxH71g3Nf7na98VF1VYjX/kj
Q5yBY8VQyTViasfp/12BI+0EMluOkAlc/bvcbSm+9/cYW4BwO41Pw6d3LCFMnaKwiLf1mdlsbJit
nAce0qRQv6dcR5ZwRxVd305PXYgrx3S5Yh0IQMNKNTYuBcQfCIIgiJljC1K4SUPZHT+QAwFeOHBY
yiBjgzTi8Mn0b9VXNF/Bx3aaTZHKrbZbpQCQFQcPmQ1LdmD/KjFfseidpxbpUhJC26iiwowbk/Xh
tPryPF36fHamgho4JKxKczv6cyw45ou3iDTa70iuenmZITJOmiNwVFS8nqSgYSLrLFN/mzW/gS2l
7PRjSP1+CYHkDViaSHJLi2F/scheLtX/QivOb411BKCLte82AS37q5jQ51JBV45AZDxVs+8exda5
gAXGFS/8FJLD1aJ7dXJ3C2LHFgcH7oEfaYaB1vrvX8nZyuHL58bDpjsOtFI+uV1BtM/umOb5LPlj
QIVElzD3IND5o8qNhrv8HhWRJw5fKWnBHFLYXPQsGP86qh1U7Byu/K5opMkEL0e5pWJXXbKQCQwq
t29GkMxMAAiEviYDJKnIuztMH0sIMQLQg3R0oh2vtc4n/OTVhF20HgUeGv4hkKfaBc/MQNFwkKCP
3JuYFuUxqESFAPon07XpNaUjg5WWZq4Zu0NJQ066u14m5S9WZM9f/bi4ICujUCd0UpZ+R/hNEwXt
HT5iqxkbsZyPYUzADY2bn9+Zs3hE4W5cvn9cgG3fmtk1dctPip8Co0lR6dl1Nha9qo/evM5BA5ly
Z+4OAKqd6xFRhTFbkdNf1RmuQXxunPpOPpSBRGEdc5ELr4DfhtKme107pIz01GG/lDSk0LBgr5g+
Eumecu0z+NfUtc0QvfD3bO6IkURjj5FA7wLOUEpLQw2ILYn5pV+T9lzis/76KPTXDGwY1bUkIya2
6SG+Nyr/01byoP4C85On07qH5LwOPKKrKU+j4jT3f7Jd7JeHGyPBX7Q7jV1aKQzD/GmO883x2meG
sk4Y+9HU/An5XT5hFzzQYKRzhHmr5+XtIrOopQ5JCd2r7S18bxyKNl4UwtmDg0WcEjq=