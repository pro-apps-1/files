<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvzceOl06XgidOWqg4R1dZJzBioPkD10Ah6uHB9EzVXYD5TCoWLV10M07/OhAKiq1VPdG+/2
htS3zU18dA6TiYgU9XV7zv0Cp/2Spj6GU/5yagOADQXjc3R3a1OR2zelIc3OslyCRXqbwA7OVKkM
mRmdt1bECv8zFKQqQAtMEGZGjQBUC1PAe37SfWKoEU+XcKJfjZD0d40jeAvGW3bAhfXT6sdXwD2W
uodNXMEw+Hivc6pizdPgIrLMK5+uN/3DW9L4ZfHpRblOCEp/A79DslgBttvfhfSmPZVijWNvYCpg
ZzT82FTxoSquc9u1Y6O4zhJsN05mag2NSfrqAHV0nw7QlvVkfX2GNz52uAl99kLFj8iBnzki2nUv
OoIOZiu5cRdNaLGZYlkhLn39gSXVytuPQZqZhHF8x6QDxu7EGFVtAjV7TuL8KUKZQyqLLernJu/J
yYjCL5Yfydn43V+DWMsdc/VtMcdUcMocCtS3JkMd10atUc+RI/ELTY5oZnWmeuFeocc8fefEhZ6n
lG1W7wXQVuw3EE+K/Ge6bwyIkoZUmSHFn3/pbJejhovu/dZSPIq2LCNYd0v5AQnB/czwqoYPQNVy
usAx2a14pk+/hjb367jfXomz25QwFzLav2/KA0agUaLXLbp/D7hjOeam8W+TinHWlvLdmBoTvFlY
CXmcMR9IhO3GpBSzSqjgFMWSAIKj941aqLylPkhfVIEeNRchAuZE/b40FodR1YMwbTceOcjwYd1A
OIK5J6s+qsB4tAWfxk6B0qpUSln1zGIvwRkZ//eoBELn78uFgnT/HTn7mr5/M/wGE9zY2VRTs6Pc
UsyI810V0Tn8MJNnTEtL0e1g0gyPRK6eyDcS9mUDOKvx8LA8bLmjFwAl4kCjhOjLUNv3K/7c9NQ8
poqAf8CHcm2aD2s3cViqquZgM7dHddAL25GfTtwu5TlMV4WWOrHYoAgs2OAhlHhK+CQ39fwuabcw
AThFyM2zFVyFbxHKt6k0JyK5UcgFVOGN0Pgd2XQBfTrLYehx7kHHRttuT3qpq+r7HHKQsBVQ5uq/
5FzI36VY8M5ag07jzsH+Cnn0R0J6K7vjZ+QYmEjOdDudnPYSrCtqoUPPWyL6t7iKSSdVp70iM0Sp
jnKi7TzphBqdwXwmtAdNcUV0TT+WZgLjZoNFjFsfPUzEg/pkbiplTgZ21LRrKy8RX372ZKu8z6io
dhUbMWFpxQ0w7usYdZg1EBsnQTmldqfZa8dkHiRnm+h9P7swoduzCYK2i2CsKWSSDbnVzEzReUPh
QX7Tz2DpYE/1zGUYW7dtsZ09ZjsINHEuQO9jMoPQ5mC+U8nV/qyFQtC4/O3gX1hjuzlr22ldX0ky
ytAxBigPh35vNRLjEkKTw6SCpDCInwB3E7oQADLPuNlQIqJ+ePwRsgO+A1TEBDiGGxZtTqlFB0a+
MyYUl/NSCxIllx/IGmprUryMeqDxcZgOYffrasAQytWYbmTIOlQiTAewS6el0hYxOAPgF/3JZKRu
NniGG0w9auaQtbHCDjCxJSfe61NRM9NfdAQ5/heDOSdDPJVXqQ46Z7SbsVME65AAfj74HquugWdQ
1eZ6LlyVo9SXJALMAIau0W3ch2qsREpvLvPQPziDJfaKgdET3x6FJiKrPI2sI8sAaOgnb8epbfKB
lIUK46y14ad8yR3HdxFNu9Lp8BT6usS95LyNrfZ/gdXzqVRXXi8PiTUZNP13K3fd1aerxVVe9L7e
C9p9N3DlIyYZsbQla+iMOBFlFdIyC9mqMJXcbULt8z3tsBlsj5vRIEZmXEgDr93jkyT7XZcpENsB
8zUDrIbeAtm1w3hue5RRlASWkVRchspeStlVWj/3BI5YVEJCnVUjfryn6BoHl9woQqri6nu7CD+W
MLSG2/VnHjv/x4/TPPU+IHfJyMaL1QqfRHAvz3yLLPc8KnAMNgQ9wJafH6j9iNsQFhbv4Geuk5te
+uwO0NxLR5K+7G12ZwcBj5KbSwR75yVz3wsPbcaCC8yJMuvkvKlh2AxJ7xjGp9IQ4peCM0snc2xF
3D1vTabA0lZr7vQan6ldouufqo2NDtAVmNmtCXO4Junku4bjI8GCAFVyZE+jNwpuhHpjRitUh9yE
RfsUey1JpNVU8NaVmjDYfDbK6m42AqVB9LzldjDIeG3H7Bu0VGb/0jFAk2BPV9YcgRKoNycbGkpk
0IfByJd4UFsDaFlCRFtIjVxYTuxB9fPioY807wBUeD1ssdl38kH1zCbQD1Qc96Spnjqu2jh+LR7E
p5Q+dxi4G/icMK7t5VFqtlw5u7pIwnikfTNURLAMMRKFDOkCXQnhZsmsgR/DTZGVdaV3fGojMlwp
Gn1bXS3/Brz/FxyMVlU0U40gtXMZBrvdHC4zhxWoWSCOivy7jNBrWa8F2GuQNziAgEwL7E/ejybO
oC8oZkgVAstGy+rSas8FQG61kN00ICHjv6V/1AS5bsciHSbirJ1/HS7j0F0rvPpGs1JBIkFyVX2Q
5v4YMFhZlJl9f0tO5hK4CIODj7Fec/f+xqX6NMMW4SKqOtyt9XCqBDA5Y/7DprwzLYc0YwhiG1z4
30lsvoIBBnkIEhik//lJ9FMmXzVzbYyQGuNfD59gXWt2Eg6UWSA697JC9Gu9fdFjhirihci+smTK
fYq3cKMwo6QUrqePcOh4QY0T2kv7tW/7SAwUWDDczZAN/fL6gnKYwNfw0HNMmgsoZXTs7d58409M
0izzZX1cRgzmMEjWuZqmjCdWunRqmbwUKOgPM1CJ4w+EJzA1qm3QzmviMTDbJuBvhQYMxQ/JE89Q
I8sj7fyTzblH2GV9xlIEgv0+mdwwV/fhtFBhBe0/n3asvg3ExthzySsnjjivEgixneWZHDqEQ9TH
NuYYPUChuvPA/+k4o4lae7QKGARMgj+I8l/JMoROfrvJ1V+Jkx+LrB34nK4XWEpR1BJL2iXR9ctG
IR8Uzndzmy4eqmzKYoDtTKaxxrp9zgo4Qarmlj0xW7CUmKzM/LE9YHCwhWPWtgbuQX7qGbViO5F2
n65gb51uwkXyYJSqyzczCT09/pK/LFCu8Y1+dEin4KdQkc0reR0cz89O0pcjOLcOoNVyd5bJfZ4l
OuBd8zwgvO4nfsruducNW7bfZM/77Sz+VhLRtY5QOlnnDuF35aez82nyAy+BVgZK6twFDw3Zpj8d
mKBW4FuA1nbAZKtRg3NITDkz1Lc51GaFjswLBC/s5ZqN/3EZe9hR+TQY5UNY2aXK2CLCt0IzE5ci
UnAehdcqjLK07J2yjcQ+NlQzbU9L5BlN3VLVvbu3O6qiTbaiHeU5lR9ckeYVLDvjlOhShNFOx/yH
jIH8dn9tiGS/q9h4OSQAwrQRnVzinLtWN4sfq0Yt0zwGgT3n1d1mUVCiHAPrVykt1ngSMAT7+DaR
w9WEnZFNJ6r0FSAwzdbdv4cpPyePPLS3sp28HiRXwUhpjqM6YzeE1aUWrQLBL7ImvAQs8171Vj8o
BBKCsbEBNv2u8bCqn8oE3QZW1GZnWuDVAPLlfw/KS0LqQNDqnix9PnajuQA6BG3yxLS66PeMSHbq
T2GAHgg+K5qxGBOp8wOAjqjPN1x8FnZjQFHy/HdsiLYT2t4eG9aXdEJRHAdy5hO+pRWm0EFSUYZM
TXPm24d7yIVaHNsTb5bwCU9kqvehr+vPRFB1WGq/vbIKo3igvF0VbTz8KZ553oQXl0kZTP/YD6eo
83dlG1MROq4FS0HY0sUxRZc9nvCg9dd+WPfD1aGXcoGEqqR/pgx3tl/fxvptw2E1smZOR60QMqbA
Yu7nQfBdZGKKAZa1umxbJG8RdfQVPfqvNFic3wQXibvhvXbhmRpiTyi93TEDtoFlGT4nbuQAd6Qt
tuJGizdB9Q8P7ViTNr8iciftNI+ZQsdzRPQ5MWsgY6bvi2dBu5IixRXxgskeoZUAkaE+GqAy7JrH
+sA+Fck7+EWzouBvDvyBfCfNAhsVa1vNH4mRN0r6SEjJlpTf61CfcaXDeKE54sYUA0qwWRr0zBV/
SgIW6TNSXbYv4on45Oyo1JiDTZfK9mOgY9rcwSHXPRZzM7BdsXTOUw8TSgJw/HlagMbh3zGvCKsd
ZBcCUFRnJndirWkdtwFrRysyeUYbrZdJgB93VesRm0cPZyingS56KYlIu9gFiysGLEKAT/iBIJsH
kAwifcW2KPNYGdb56CIetXEC1njugCDevbAhNFZv4DHzOp7KQifvUO+UK8zoDmuTvBGMqVklgLKz
i+nYz8AB6YRFKtto3qJWMKG2kSaWvqck1Zj05I3SlN38IIZoYQ1RbTU29JRtPT/OyrVjZnEUqDGz
Mnl5IfBJ6+UpNnEKyfob87iASDPWeTSPh+OHz8ktSGy4jRAHA74xYsmGBR0kghpNhbJlK8kULVs5
IS8LirJT7+QI+yNVZQOUiQ/QSxDOkBVGbISxcyHYE/bmZoz1Q8eERHLwKU4k9NvBRzBX0JrApSvJ
qe14QDJDlYxIlA0ifB2FxT96vdWJYERLL+W6wbI1mwyNQTVJP+3ncqb3SMkwO5Krmv8KV51tuIyu
BI6GzYl4Atguk9fhNArz5wF2YuEwlDWJt4kpEL5GY3daKl+FVzqGdg4m8hXuBSq8TAi0OKjZ6JB5
mc6W+2pZmzRKZRMLOuIqYGxKhuGiPjqI5PwWi3J3tZVYz5qqx4ZEsRkPFMAJZlYQBHmW2ZNbV04a
LVgtkf3QU9gm2yNfLiu06MthMbXTydmoGp7l9DJsaRG01XqEdtOaqtmMwQnXMZqxB1biyatXMPFX
cHirk2vOUvKo5sxY972KyboIrXxzILIysOlMprWXFSjFxT40KuYCx8mqARAVoyhT5q8YNU8d535G
Ra52qlyOW2DsZTQBB1gg5JwYg24xsw/bEcZTkHe8Hi8776JpL8oWyw1BsFqdoCghkOacOAJhNp6D
fG2w/RDAnlfjV3L9Ue4xtjsWTx4H1a6EzEKS+Jv3wk2XrRq8cVrpPNsUcYVrwj1guMgSC41iXrsE
gMPBwq6ZhnQT4XcpBxoPP4Dc1pEG1x6MXeif++BEIT5iSD4LL21kua4GlMTeoWUgB3X7gf+g9QZf
QxK/uNYNOcviM5CJ+4Nb5k64TF2F6r3vRgrkM6EV58RvTHFtr3ivuo2Ebmw0pHlp8pBGOlvP3GYK
hLKzXov2mGfHkvk/MYBQ0MyqyhnmD4hkCW48I2RUn7XtQO6yR3TwJdlDLeCvBCpQTfUvxjR55OeY
mw+njvqm5bxUDu+YwIiSJGvWhlUfTSX519PYvW90p931ytetfBXigQHc7G6391xrfMNKi+mX0kBT
IfhuogwJaKrkxXscTONkTDX+lN6MVAAJ8W1DARdHu7s5mKRVdGCsKjhiirWK66Yz3Gacr5/eqsD3
JktIQxgTpEpJ/ye3eVBCDB8CtI9cJXgX8LJitxOd4dnU0v3wHBPNorPP3pqs2zk4YLQwsWzpeSCx
B1l5ra27x7m39Wf3NMChyGJ58ASdyoud3ZKQrmlg9UJtnAqBmol/X/KQy4wPtDY8uZeAnAHHtf8q
+PLWi2tdbr3FJsoV/RRzzhI6sTnEksk1r1kskis/KaTgNjHovcdEydjtajihr/LWoxYbAwnSJzfl
EMgCkw7Sq5MU4HGadJhCZtb5OQnjuKqu29KnmZbh2hMnMI9tqGn6aXMfl5X6teBqSrG6zNsbo1ag
UJDgPwgM8FqRRL+V4ZL3A5MlkCGShVFKf0XeQhaHQlh7evdLv86xxSfEZCHZm3i+Rml5HFks0dEc
z5V2yo5tLPVjgpTBuzh7X5fW5nTBBTR5dk1ETeeDM4a1LME+BkTn664hf3FjMMoqs8Z6meC6HHF/
M59rAtJQrPkA4C+szen8y7Ze5IpM4U234YHuB66XOy5evKRpjqy0RiMb+MmfiTxD19akxKeP7Gmd
mfwempgK7acgMedn9V/uz6mRn5XBedBIHYvBHLtINHopQwm3fuSBiK2XGJELoSrtaB3AAJAUzhoG
yhr2nxQQO2nUBMkTZW++q4d/OsC1qC421qJbQuv+tRY8VjymHnWcc+MvkSKg2UCLgFBsGqBSYsDV
v4/ZTqm0deO2XLTjeGgtesjsgy5jWEoMM/0L4GRCG2F3x6AQnBJLkvbud2Qxi4HGv9hwf2XmOEtH
V0rNd0kjJl6GV/4dJOvBmY0i2QxqB6oOXgyb4Pw1HP/3m52Cd3/r8zsYK2o5ir6VXh3xtpJOkt9n
26f+ULuh6fdX32C3d+C3XYEQLYHrZkkN3R/AVVpNmcHBzxSuPToD+3lLGxuHIbK6KIeu3mxmGhaB
0n8Oke0BCWlLjvCRQgF/BhNmyC3LiYmzEXfN6SnqQQTrck/80euaWJtidDcqFqo2fAFZNstwFuDv
7NdORmZWdAWfxToz1VrHiP7vCc1Gn9qwK7DqHy0x643tbJgbkuPIeheWThZQe0xIR50S5y0BGRwn
qSazYQRBuw7ZOmmkihkupQ1wuZaMc0bKvi+fg4Y2UKhxuRaosgIHICBpdnIotsVSWsbYWt7wB4+/
I1fk/w1rP13MLuPe+nVhWaVNyTx0iwGO2y21D3NkBoM67wWrOKcVgBhPaAmxxKAqo+K4ZsMh91lX
e4gebSDB66XCGrN4vQyUhQbdRH/v//P26foBexYYEn5xmCIL36gA6wTUKHakCi8MLjYEDSorwH2f
weur6/AGjrx9gAAIljpwk9I8yoPi+SyIXhAwoZVbsRMh09NBVwDX99AcNzWqRxQtXthcRW+qaHtM
2AKBzsU3olDaTZlMLgVRyy9qKiuooeVPWj/gd9Mx+zHN1Lt0wD01HTfnnHVnN0NnMsPoxS9/npzl
WjsQvudfiRXcZcv0/PcY9L1hN6nqG7uNavXoaW5w8Zvhk15SNJ2uF/s5TGOG3sfZhoN+CSTIDB+e
OptdR1c4wYfS+J+0Ra0ApQ1vXN6uLbwCc5cE+OTvQupndtz1PLGaVFKc4zkv+CbK6fNoSCqhBuvR
GcL1EyGTgEkfKTk076gErQY/GVfqI7B/GA2Uu0gJQ2vqtIKuSIz3U+itLnY+hPcBT46/UCst3r78
qYdg/CHeIPZuQx6Vchi4X5RC/SOsPYLBTcqPV2qK2FdGBekogiDvxacZbpXqD190GfKUYCNbK0bS
Z+bqndN4FQvD5OGzo0CJUMGwR99DWAOCCH7fzEKaaRrJbQABEfZh/wI63XhbwEhrHFWveZTlSiy1
zobttFWl8GCU9I+1zYTDkFku3lghEt8HO/7r9dR7HxC/d/ZVYXCSoA9XqBjpYzGsYc8ItkA2XJ3/
EoFCVf2L61/k29ul1nics48smsWtbttfoXLIIlKla1RJUsw7PoQjO5hePTsyM/z/L4+IPwrch8QB
uF7fvmxcPyo9DIenib9/QfmWw02fadc5z6LYIDses+GvfOj51ouONBNzsNj4ryAw9sVU53JhkBjh
1YxflER6QiKIySYTQd7ubt7mpgkBop2sWAoEBp4XT7Djelz5BlyAaHazM3ffby86atKBhegoQCw9
SInG6CNUVxGDhu7Xrz149+UVnIkbrGiupnDJG4oXfZd+FjDDHXjQdbyliJd/WInHjbL7h992GMi4
DAC7NxJGCDanj570ynh6C9bsqbcb7ocWkE0f8ut0m6oVY9Rb9yqvLh5MDS4R6tf5xylzSfMlUO7G
BCSpsVOgDK5kJcL6wJyOlDg6LE8bGGkiMUPfK09kGVAE2o4nhK9i39BbJ+tEB/4t3EHKA0sfZaqI
gfXK1jt/xdcyriBSfa/pzi/4YiRcdhqn5N7HRqYzLbrnq2Zk4+SFLT3VFssFwA+sfezGQKsghARW
yto4le0KuoCScytLvH3jqNt5sM31SQQyTy0zWs17/7kFSa2MrNc5CrnqlVoSRgXs00kpzlkAKG+j
raSgl5HzaOY9gjCpT5deXsB/lRkVczZLVbJWDQ9JrC6f32VgPUDw9pbIhcVyOM2dQn0wSSkxGB+h
ekrKHukOVLO4vypBWERDJFTFN1SW3Tnw9i+QCZ0iJ1pvoN9VTyt25agHsMs+cbW9h/oz85IZ713W
X/iDs3dmWceIJbDZNLT41o7csvc8D7bbomkhs1zn8HbCx5xMlpWlV8Cvdjx0fYXxqJiG4mXCBHfc
X+1Q3Rj9r/e0a3Ze8c0C3hod+HqzU7vRN7BaqpcjfUY7TZSwsBPGREYVkMvTYSgHXR2eCHsRm4Zq
3UxpC2Hmi2Ulc3AsI4eMDLEuJb4BH6/PxvAV/yBDLn9D0rjvcv3CX7UvcyuOIl+lchRTwhpBCt0A
Pgz/Bklfxh0PYLWzNj98V/2bOpVFj48LVvpcVNFgvdS+LsM+lkSTDzbyovbZGdk3gezS8gRwo8v0
QBslitRM6XdJArVD6kZ27KVNQg52wDTHM0xYaLma5LS4jzB8xK1GiJqce0xKIkFdmy5NkyBAdXq/
u3IxCS84D9qeQHZKpqUyieE/+N7BG7RPnIAdK9zP72/1CEQM3b1T05o9t+k80q/Cu1BsnJ5I7yYS
x/lLcFLFfn7U7KcVhTwmXx6FaU84OG6ZN5bge2pK4EWBdWfELCdin+d8wntLOwo6CJdIUtn0AMuM
9lpmpNA+8dmpx9GOOQlOPdaq2xshI9a+UxAQqqBsgKSw4bO=