<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwNvNERJYwN9gXV9nIysQBqiQWq/xOHexSEI2/mPbC0MaB/hRxopX1rG83Da5pKCVoUaChRn
Kw+uf6j4dMQssDokjEFRvqjn7svgFNm7mvflOroW4c2C3sscwngACmjIbR070nGlI93l5rDbmyHy
WaQzmWKJkwXGuNEoHbnLj3cfvHL7CQhQNJanUvqPZ7LpmrnMHvkom8539HB57lJWAUFbsWDmOnN2
X4zeiLYF9M/+FKwmvZYAIX70MQwedLJD850t8X5yXavASODAXtEDfJjwW1JIOWTfSJWq6k2+hVbL
tgZd0Cw99h7Ovyz8508Ouvf+dajv/UfHflGgyjBUwGlvAG0OA2tFsjqC7zL35ciRGBJsswTunGNs
qxxRNcjVOAaZr7IyXLwOpMLjhAQ17TDoqALUsg2kiWqcXnGxI81wmU8bbuvXEhgW9Er3gX1OeVr/
eWn81m1JDQt+dIQi9zMrttGfAo8XeDwz5LaorfZDCba9kXkzL/nd3pM+OvlAfKc1u4LIdMGl/2tH
xZzMQExcXwzmC98ZCqmJebXGSRg2zw5te4ITd70AW6g538ZZMC6Ca813532VTs44YgFP64ZKHHcK
NSBz+IswhyjiVsA6k19h2POYLb93BMYcxvfXadVSO6JDGXiG7Zu7625K6353Ikqm9pT4h3RRBPTV
39rB67krYul1wf329k2TBVGgcx+FSOwr4/MuPD/aONeaAfdsX/ns1PJEzt7Ut8VjEbEJQAXCOUcX
HQAdTHTwL0d06mSi866fbS0S824+mpJENoIp7hbQNFIRmrvZtrRIISWP058+Ey6WmnMd2NdOZ4Uu
Kp75Omz5CYI0bBAIdCdoz4v7zYDg2f+j2319wXbSnnrsAebW7F5mRNQKTX/rPK6nVSpyeA/R5KvD
GBMDWBYHcZaaUXxEaJwGcPhmH/hsO/ruvPH6GSn9U5GYsYnDBCvGtcXx8mDX/7ur3UflcL3LRFXa
jvnwyyclwd1JQdq4kterT9si2W7KYXa6+3fQS62Bq1cQfoo+Kecb/7085z7hAtrzl6r2ns2VplzG
OM1gCi82Tz/Gs9xHPDxwJCxbqtoF2CGQetuq5rE93IS+pc/I0tknHmBqtQeIFdLuJYactb8lu5iS
aF/3lSwdgtXxkKuVQV6WlOEQ9RPlxhctCCtq9ZeTiT1m7dymFJcBBaAzdqWTIjYXz0ZN50SL3+Y6
rWdiNUtmuPWz2kV3QFsA0G5wDKb7pJj6EaJfdauD1veU2PyCdFYJWMwm0oLQ00CKRRivtWUucObx
d0PMUjvr8kvxr/3PnJxQeam+P1wtWVUrXv2Trw2Kol8Ilfts/VP2DKlqRHP/5/yUwdavzv0+BkH0
CPYBkXOTkVIzleRSL5xs4aeSVHko0jy6U4V5kmcyZLO4+Y06O8w4KTbTwzQibyX70fuq5L83TzYY
f2TbBweQbYL8T49TndFLxGb1zJ0MKLTY6+e64VjQaM+LSTllhTaAffgq6WR1XYga0FtSazTHEbIu
WDzkor2hqhjZQLgisG47maKPYs+FsUAYKM+41b6+NSGoCMTzBEcQYogxfnG+SVuVQBCQA7ho153h
pfLvd42fDCPTqCcKftcZaMB5OaNzkwxjEjhJAWscO3+SSRvYVNW35gqcTAXChEOOJXAYNzeIcv8/
iK44E5dLSvgo/mCwsQoDUaOWiwMUiGfEUKrnYkXSCJazjyihxTVi9fPFa5TbPQpmZj/ANygcMpwu
u1k6q8PipibU4oFwHGXd86N4f/KwwyJQ2mAPFU3wsuML23xoYZXN5hss9Z0An6rj59bP77m+Vmd/
p7y6UYpApJrK6LLD9bnoEMIosIy9QYaHZGTOChNnQ8AZLmEyK63okZHCao/ZXQbFmzCLlu1pmH1n
DPtgVwu6jXyPISIUVJ+0uPnKyAGxHWDB3JA9W05GIrCDNDVgmA8DONsDTMQDSWm/o8zRUbW1kGbz
4+cc6OBNL5DeU/ILYsRb8Jt4ZNh0qOUmAo+tM7KVRMKI8Lddd9PmUFjQXUdqO/fVCnqCIjUk83Et
NqZk2gsTdO4v5jSfjwg7+nJ+1aI5JJkLIK1tR4yBdsIPE63RzamVkc4MIRIPgIgrypG1p8NUT1ap
uo3LqPv50HwmrOlQqiU9xc2SjnurMP/+X8Trwh+0MUUAKv8LoYN+IFFGv+JmDk4TZ+mCSKl6H27l
mk+Y6p4pNjeDKT0xhIHgReCnmBWAPLyTY0LftcRseWVw8B9/x1NTi6P/A1Tu9o+zq54IV+uSZhS5
maVFh4dQKG7kPAyYBZE6oeF/8uezfqmrq1/kiMK2L3BMy1PtOkpxlze14Kr7/TpRWcfvr1fslpv4
MtasNPAKL9oSom6vsff7ffoa8ye58H2g5lWFL6pNSk9QYAGvvwpqwuCz4wlzLahxDHL4ScgWFfzm
U5qK5pDP2f1gvPk/rCVwE9e5Bwp9b6abB/3FmviV5J/yR7UkoAlIPBpm2eLrTe4/Ehy6Gjlfsr2Y
fkziTHdolfDsOO4nz0qlEu95JVYGbmkK7I6IfYuAzsvEGbWDBjBhX4FvZ6uisVcdleHXxuRy0Qqw
rmuq+OBBtojdtP+hu718iy0KIQXpe/3LffHDvMjAzRaWySzOPZSNZpdWJDuJWXpmJmLoHVcI5ROI
wP5ATbk2Y+CiAXFhh+1DA0Y2iJ/NYe5w4trRAVJ1O6TNaNXahSxUjF+NEeTZCZ5zJiyB7FKvIj9Y
LIKNLbgq3mndTkNfATUfjJzyHK0NnX0sKhinVDW9p4eARjioTw/GOFFeHszGNF5ND2hPAidfcslV
wiLLl809CPR4M8vNQt318Mc6WlE+MjJ5poSY9Fgx1j0tbxWAgDG2dCUlgkgrx337XotTUCJOt7zu
lG0jALxoBNh5KV5MdJeiKJBcrdI20TnCvYk1A/kQs6ZpNlOJT0z2vAzVhdddhyrcL1zeh8NiAGVX
w/95MAZguTHHerjpjDpqykMpZo2rLjvGBAbu/abT+8dNd1ieVCsbAJSiril/lAXvm19wicCXuuR4
00Jk05c2o2xfl0HEMR0m4iJOXwr9zKGml9MOMAlPxWWNrpt/mAe10JYyPFkeRBUs16T7UfFDkybq
mEnx8cMd6hJm7J0IxCHquvrNrVyuiF5lnqDt7yHo+BGa1gtYxF+w3kWvmcpp2AVdV1/csZ4HmGOe
nvBVS+BJO8OwmTuSL33mdH48uf9AL/QtUmT1b9Z/STri+1kwEHJn2zoxXDeH/fJCi7uDlVluZoTQ
goFyPdpEbsEAaT4J9+mX0mltpxoE8R/bV9xzrMLmUZP3rgroRDPayI7n2WugLG0Rxt9tAjP9w9E8
BXafODyNgHkIszlLfhYHBIsRv85b8svTbxVKMlLRP9DIG9bu7/m9guue9Tgztr10lqdgsQPWOdTt
va1M4Kq+QKevfxvUcXHAWc+X1EXL6Mk8vI2hemRrWkD0eXQA7ixU3w8NomxfOqcUNwVJ3CIjTh4M
Vly+rxOWnNKBmJzFcfiwaqWQy6QUzukPtOb22cyHleHNbK3xSi/Olkktwl4tbmzj8WeHXiXHwZBi
h7fEqnFUFn/0Dd/b6RQlGqdEnE57dwg0MHBvRec7EiKIXoauLGAuW6526WbsaO0wHblTqNz0evXm
4V63qbhTGxePaQOxxpuCKQoLiVA5XZaAGvwA4NmU9U8wgV0pDzimBU43i/WuwRNXroySuAlbjfzr
Ekj4dC5U64MYaDvmStdtnOgU1PLIb2KExIQVUTwvTPvd6WoYMIz4LLneeUCzuVWS/uovCfWhjyWu
jkz/gI/vs304UnxkHOxRU0IrC4F2gTy+z6ytgxLzyYEqHs11BUvgQXt0od87H/MT4Vj0Bsmwrihw
L2zlgUjKSuNwju3L1E7MAn7g9MBMVUs59bcPJrlCYv/pbp3Y1g6ve8mcbGrqqn73i7YHC/T7r6sD
F+5TAjsuwU0QVt8vhrkNqjur5KVE3mbYzQoDQlAhXz3JzPVkvQK/mbbU4bShZIAWms7J5QU0yy+h
kjxJFTVEuDW9kCTehCZSpRVNUMHGWge4BV9HbWAz+xMUcd0vwPI93jj8jdeT0AaGYg08ObZf6A5A
8DZ1jF7oLfBW0IZii+9kS06DApR/m3fcawtV74xzYmNv/ItNU+aZ+0/2AOHh6P67drmTTDhX1e7K
8oF6/vv9YnqqqEaK2Icrry97r0w10LJDmXBts3rhnQIw5dClKyJ4RAEhIYME8+VEe082sNB8LTY1
PFK/GslrZKNjwKR9mrXjDqXgmM0/s6fbFGrl06/6+2k138eIxfyqAydKSPEibZuf0rKk6abnEO0Y
SdG/D5o1bXvopHRupVMZV6SJuyDjYhFPJAHmZXs3yvsy/95mOi7wv5D2EDgKkOJ19UusUDkBJZCG
1/8L2TlP4W7dXy0SmdfY4cGOsPPRncp/GxDdVm2Oge7BDnmc6l/fwGfNFgis9w5qHqUacOdgqh9K
6o7nKfjOFMmlkgAbVk5luM6ZFLj16DSisGLk0DSu77AY1Lp3UGdJS/hY0sQT91QpKjM29G7LqMNz
Sw+aTshyYOVsHhSw6x6tgmUG1DuDLkwY8v5y/mnI/QQOb0QMgP6S5G6tu1DzJn3wkL4bsRQ6sOej
DDr5zoGt0xY8ZXFmo4aiMHg13+NcrExleLWY6U+vCmjhb3ZEXZeMhgkbg6arUojSJNfH1Il3/Uic
ZDqtAeJABXjpcx/AdwH66CPnLN2mlJXmQIbR8C1wRIwDwQD0ajm5lIUIGFiYFxLIhw2kAhbIKOwK
j+HbD5pdCYWqOnxSSuOE60mFu9qt6kyS/n7ntx+mUEgWdV9mzUQIo8+A7uz0mMHomR4Af+UfZHUt
Eu5PV+oRrNOxXcqxhgTHshbTVzP9+AZfxVHQ1sKXbumGw19wOI1/nxL+WYcZxtLyCmkIBTHzCBSF
xf0OYFVY7INmx0hvDs3RENxoyl/i/JqNaYaG/vCEmsp3zhNmvpvDGODlCUbvM6jUbqkTBob1pQIw
MGRoZMHrTchtci+s+2O7ZO5NeWzQI9f19wSvHE4WcJkkh5dHyLMUhl71QeqFnxzX0BO5UmVldDAP
SElMYUlq3UsC20fA0rQ6DGl0U80n8b1YjGvv94gOEhkGK/e2rIQPcivzJsgCSY3pW2FzZ3yqQix1
YxGJycdlJyu14Za6wgW819bekYdCq32ZgX2UIlz6zPr7DtBzdYCLbGg222KnvtRrCf/oMdTnW21y
TGBRxG51c4RDfb8+kemFmNsA/0BpIe8RW0+PCcLF2J4UHV09P0A7cGDHiE54SbOp8BV5Eebcxli3
v9zvoTgwlAkOxb5jXHVp5b5XbEQXolVAEJGlp/PRch94seLHX6ydY3KS6b4xMuYKkhtMAJWT5Gsp
7veePbAer0v8NXlrnmjcxL6g6E+TlAPppW106SHsIouBazIyNkg6M3PUERgSYpafsa+7csNUyspu
0jg1rrRHL781A0ktU95x+WNJxzN1HrV2ruS9+EyEMF/1Y92Ai/MF4+DdrsQ4NqryUNzBcSSRQwAd
BKbmbbqhYtqz27eWTmpXGbsmAtnAKY6qD8Pdrg+3EmrZyZQK0yucycts/rIv07fWiBAECpr3SgQi
Y6mfYRNcTdX22xS2y8PRwgRyjCoDXKJQkoo5ms9vmLKYluKrvYtR4BBGJ3x4SyY/oBm0D4NYBToD
jWVQsTs+yTPwiMEPtaELaS6uSkgf3jXkYWn9w3EiGEMp5rFPaDGnWExebOSj5TNFhqqUY0pSuT1R
LjVvbR7YMRDzL8ygq58OlmqFCsQVZCfa2aaiJK/AUcVaD0jEqDt9D2QjThgvxmkvgb72VcSxofQc
MxemPiWN4UbiFzH5f8ZtPV5p3qVHBfok7dye9WAOMdkY/ymWieXKLjWcNOLSUBcKA4cpNFFbwCIX
TwtnKJUAPT4GFn8RD0FI+l97oGPCgD6OL7Wf0fjGPu4mrs94fvokK/9PMnAVq5qbpP04IPY2wLMS
2xlH0xun4X+Dx2kBIQKvTv4h/H59imCRMBVliNoNyRiCHmE9bDWoeE1zySI8pm+XQuGp3kP5hNK9
WXoxFQJMVolkqfnv083/RVYPb30bptHozRl+A4hSLvURDmer1k6am6Hk8OkxFave91mDIKv/xTin
qAhWcSLMMou1wvsBMupq3QfqQg+aE+KpSLAlzlFf4ZvnWIN/bv+7drNNAckMl5OniJTMx1UzLVGC
vHWp5OZPsH7MzSIdlqF+s0nXfGYkb9e1DbghmwzgpwkUusB/pN7YD3cLKqszOq+thkq2GfrgW0pE
iOhTxC7D2oZDafTJT1XWxoQF2tYiWA5KmXk1dQd6hGvb+ytKNOgFeBSXr4gvu3daNZAzLGg5ZII1
5BN8uqlnFu8wApHJwT/2WsRNs8K5frvip+aYXsnFzafvzOS6blM9K3rM1A+pIyHddM9VcFiTFfG/
UqpZ9wEb2oWKu2GWa4e6tzM4m5hRoWlGK4Wxb5Nv8rn5xv8poMioTbTpv7QWEI5EGnEzk/bIO75i
vayOQj2VOVylzEtv/iYZqE94XxZL8mNc1qq/Sb6KvIz4/yzNzt4Xqehqt3N0y2a3TwV1Dazdzxfx
45iUui0Kn160WtnsIHC9oAjrdg2kVXL41BDzytUgji8vwThFEJ/GAIo9/5h3UTP+JTkvOPjpGeH5
HwHzSVUugRuHSWz+3bSj92A70ySf5g34jrHghkm03oqmf+Kg5wRRonxr1qHAaDP0ywnNZjp6Dwex
/zsxuCyoS1MI4qghfPfJnrM9L37c4Yn5Xwf+b99bldxAuiXV4utEKogcFNFr/tYamp78O3qflHvF
qViNCNrMpa3rqFMW42XLvV5MgPZtNdY724g8UKYGXXsqMVz7EdtOjnGwrgp0kUAThgSzFrVp4PBL
md92MJ1ej5dFBGgvjZaCMO3GFd2wnwjQY7ZVf0CbZXvt+SdZ+B67KI74NBaGrU+pD4K0SRjZKT/7
2K/pEIb7gQvJezcxEPgr/hCFyBv0ELaMfoxrxrpxZ+a6fN8CJgMqb3FQ5KuiHehrrexhNNb6idLM
aCTcZrKiS3PsY558vlwPtK8kR5Lqfiaxas4SvejADyaOrSvVa3ByY9N0VByiRyN3ZvuNGOhg3VhZ
8eghueWeTNUv9NTo31TceBwDPyeoyMwN6GKo+b8ocajCUcFtSEkc/XPCvRwuA+Dka2pOR1HKfwJO
0BVlZG0X39xssnR/65ntdYhsd1DZ/PdxFT44j5DJ3d+vU6LhSFGAowqm7O1RatKURGcW1T9OkW2m
Gy2a2XBt80KJK5pY1PsbVel/XxIhmnZp9N9rP3/+bzs58gUeG8kJEQVGf0lRr8FCoCR89qL+btRg
/TnZJ35hhN2cTfLSXh6aGwpPJnmYLSQPZ7BLu0PNfglLm60h+pOYWo9w1g4lP+NjztErxdwWgEhf
wGIqEPxod+h4FUqN1mJqXTv3HXJ4Qfv9VbhHWIwGnp4kP4ahk8aFZD8AxZFhK1gVQf5nU0Xrx2Ir
nfg91t596WB/i8ke9vMTkeDi7r+ghggQQRFdWJ2jYoKloGXFaKrdG8MaIwXuw4ZXiVSToIfWjQby
czUDl4u1aXi9+HZBUVrbEr95J5yKqG/kubkbnTFOuKOJwAJ7NlHpAMAJly01ZrenmPx513icyDFP
2dHzCLQZdkMS+01UqKok6+3ydfP6c3sMh92Mug2fJVDecLda7BkvVKxT8RAXoEd2y7NR37J0xFiN
7YPwWFPiUUQZ5JK4KiQrQleUNHruyb3vCALuMrYTsyU/z31KDbOmzsFDyMpSRmYrEebr35mZbAps
1SiiyN2jwTW009lKywk+P4/yFgAC/3TxGtD2g7ITromR02etVZlXasFKEz95b5dKhmVKBuY/LimG
79t6iJt7I/IzvUJAutq466itJCpYylt5Q0CR5W8mq1uksRJLaMX+2eJFH+HDyGd3khYyl9BevxX9
oggLRGgdqmYUkAoVt9oHogXR8Ff6w9/7g1zoAkJ4fQNO7e1PTmCOQfAmuDpPlbGrrMdZIphatD9A
DcuwmaDLQZhF2kacRT9GiDibqLOxtoFzbTQggJa8Q5i+eij8xqPEEZuFLtbk9uxInTp6KdoAtrtr
C/Ze8r+KpU/lvJ+aX/U5kuz45uY6ncaN9foDkziD5eUnL3/YuWFsPXC6lAIsmCyZ0aqfpZgx2/JL
ZnaaKxpMk0Q/TuL7THxyjKC3oAbQpOYPnLYQg/36h2/HBTARJzYcwCjzrHA7Msu1wcy+Q8L4ftRn
wi4gUzZJ3baWYisY3NdHDD+QmII5dSX61cT/GN1tDBIK+Gca/iVRSWEJj3N5YAUfGJILYRc9wfUF
bdV0DSnqvIfRZ1THaAbo4KqV6IvHTFX8ReSXhm0hK2mA47fmv1KOM3sc37CYa0QktgFMCNaUuGBf
dcjkDQwL4Rk2u4GmmPK6J8YhHPOv2/CgFeARFgALlwshKLbLuMcLw/6Yl90kq58VyPIN2aGwLUWZ
+dFYr5o4enR1lKJuCvR8w5oCbtygl2OHhZMjAIF1XzA1sMgGTbQTCwMuU6uP7MKehWqjUDI0A9Ec
59XthJD9oSxTM3BxPPXdMgtRBvXOwp7O