<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPttfGogNchWDRWVM2QC3Yf6wpcFLLqLumPwuJKmHQ+aIs2wh/l7416RqwJdIl9RU8FqO4qAg
Po8kUKiv800h2fg562dEVLBcPzDRDkqwTGvG5hKMm0xM975o/iRoQCvViFF00GiYb0vKqu0WkkJN
cmEgt5PqJR1IQfXyIM7DMk6EiBTlj7Slp32LdJbdGcQhalLGDMMzd62T3St8c9M53Ke/3DhNfW07
qVPi23sgAq3zbgfbWjnWOendSkO0dl6Dv5b7GFk7vgmggRGTeFMWIDFai7XdRc5pILwQ5aWn3FtI
TuXVxyrYQkJrT7xuHiHC3sKeYSCMmu7HOZK91o+T+ZU3HEDJgEJN3OQi467XxNRLoTxqL8re84gN
EJzN3+9nYvFWbnQOBho8yJkS+bOXz8f9iurfiEx6mASTirDldoP1IQQZ9rHeCHwGkfJu15zn1BL5
KUue88G5g6L8dn68E4RHTVDKhr9GXg4xCAQaA5A4dhkfwlYY3/+FYo21wCppYodpUUN34kaf+/F7
4wPdQfRavWQo3Z8IGLT5aekY5brxU0LgsiY0s7UjZz4ca/8qSgKMRptPvEzcX9D7QWrH+hVEaSku
4VqUngLu+lYYjBRuUjTQdwab3x3ebOKhYQPgAw0IUCIGstZgob3cfhDGbJ3yUU2lsXnXFLW4hnQL
PlXFQCMA8nqpmnTtBnMcwU4oTM6/f6amVeoa9kPNqyM1+HQ++N0vBKbR0n+E0CETHCgFemxPfggW
cqQQDk03AiaEluMkPASLfhRYstKGB1OKB9/GXGJhdfm8a8tPwnjdSICzfvQIePx0viq45tsJu0jM
/ZShk/BkYd2vjajZ1JZtCqcA1o0Ain0KRi8SzYy9dqZZHMCDavR0TlWJii9sUiZE0WTA9AbNjauX
5T3zOG8NqOGGjonyIBtEPCtktcp579aVyxjrNJZwq3h0tCBUjrtP/AUxc1zM58jj3cc0cke1YCrH
xhQdpHhG9gYw5F+xL3DdNBCCQBG7HtpYsZKcugCJoqlHj7VI4KBOUplLrYIHrLhyZEGrXwOT4A5R
i/Gw/MhB/iQbfUimvNLlnHAeG4TknmkJH9JlZ0ySPEkQfGXzoXJd79SgWt8EEjop83EEV98rSChi
JmWFdKf0aSv9E2lBdmJV8ZEznQeeZkVInSvgY8LErC8DAkYXzZ3ecxrRlGuwqXOFUmSWwQBvaphv
pKV8gajvhkMC8GCof40npJ4kGN4dWfB+XcrgJV3edoTq+4k95RJTzd8u79s+MeTWLkdhG50Bv746
G4kLqQkCPZrFkOnDZFqILtDUwnW3gTc7l6VEFqiq1uXSYHqWoWLO/mjVxHvkuN2MuqC+JjRqze9y
nuHr47J0+wLOHoFGYrdrrKhdoqmArbqjQF022nu1rJTu7GkN9ZkL8hhRXTsqqTWsD8EUYuvLisuV
QBogutklKX3PayGkufN0tQS52Ujk0XjH/6D0SdZYGHhExkLjRRVsUoTrBhs5N06xib0MMfPuYC9l
oGPc5KKzRYfBQDggS5oOEp1lj4mjzalHEWz9eOnzjq6Cuyo2enWOYd6Dgt7Mok+DPvb4VSL11TvY
xUxoN50mapqxXUr9rWrfmNpU7DPPuUQ5WFBbJwiHZIN/YwKgbxeQc/CZkaU6SN1+LRvQtKnDHCtu
ibHPlLc91W8dn6B/DX4N4Q7pSKMZG0X5B4xAw8C0KwJho98ZbDg4m7VdODzNwD9a3XF0j2xDVCHJ
FZPuUxH4Ln949Cq9/Or45q6Uir44p52IuDE3h40WXZ0zPcXGAzkVnwPtr/AIL4cm2eohWEr4Q4/f
+8++Hfpd6W7HzXk5mXEVP9u7Ezo1NJYZdwCXtEMrlgJjTdvOsCCQ4LByZP1jeF9/nyi4yOboL3hc
r5M1pqrmp58IKam6rshgeuXSeJIijA5wBRWUlRWhSW0XXep0ZM3U/vJu/QHPsDHoI2uOnUSpbBti
uLAtAAf1lFPzMSoXkAgrvwneqpUn7QUYRtgK7lJRGyA0UUIyZRmQQebneAKvvsZvhcTHQpUOsDvP
T5qiBa3vu7uvXasY4nEQgawIlYpSUIMz7Ew6wLjjFNTTurrbcz4QRScxCoBJCeInB8ompzAimLPo
AXdrp8F6W++mKU/FCdDRaElrLynGak3M3bcqS28u0oDmmLzqfWG2dhEyJaFxlz+hFwtQp7punRud
V1m8rsyXYeeU2tNEdnDkaTFKfw/PwdLScpsaPJt7dcsu2chAJHfzExY03ymu7XJ+jF2ryIjQWn+M
KUrn7TgAIIR/hPvfU9e6Dj6SR6EpxakVhYMVR3akPSH/bXj70FxaYrIreFafSWp17KXt4fWELwIX
59UcDGDR5TEtawxBQdrCPlCBld9ELjgI8Y0wOBGguqi0bvTci0YkNaeQqNrSe+HFw9iz25o7RZB1
v5uQaCgzJDo2sG5dmaUxHJqxIZa4bFMdGKwuc2Codk8fCmMR6SsKZ797imwQXOnLcxanFG5wTStO
P0SYaumT1eciFLNEKAhNSnU8saXbMsAg+kkbJrcmMuQ8uRcicybwbM+1hyuRwThe80pxN3MIuyom
o9WJ10v2C3DwXSrkUQSj5fD6xBs1emPEh93pAb1PxgL+5wDgj7EzV8fdnWI5r7XP4Hz2lSa+A46N
AQrgXwi1P13d2ryrjHH+H1eIYlOXh2QmumAIOBYhG8Og40v5cNuPoX/aKN3g7whX0cvMa54nl+5l
vz97d57WqTJ5WnoW5c2NocY4ounCLXokW1hiDl07rjGhmTmwgEsuO3VMmC46Kl+BRtyheXLGhY2f
3FlzzCaz52Fz74LPPBDJ73a5Gk3gWnEEmc5/W4KDwXIHERb2Tj2jQVwHdEOKkxp93uXs4Vb3QBsO
LIPpaZxb6R+u58aUSpk9BJNnwXfE4814cLengu36BTx0OypEbVLhvy3rVVIasb0Hi8Kt7QGTKyTi
rVxiAVUHe+Vs8Hpoo5MbWXx3IDkYltCY5r8WlcpN+5ZJSnEB/Legcu7qKIYfzUHf9cRb/KWOJF9i
G25YxMGMt9gl7YpcQf7ejkSK+UoNGpKABeHM1F/l17n1DKu7ipEHzROWRp/gvTPoSwb4bwRicRGN
qdXaD6YHb8rY+h/LriFPV4cjo1PPNROK8eODI8tqFi7YLkNUh5O670duAljAEzUKT53vmQSamk4I
un65ojhR/oZbC6pgDooikeAeDvo6nSqULmgth9NrDdCXopKZemd0l7JGSIXqeS0qz/RjzWLdo/3C
t2yMdk4piJ0iUh/aqJclqq0RcPpso5gBdsuSpEMA0ASeOtvkLaVYwhYGqSQHql3j+0FEARdxp814
2fba6xcTfaKOqiEFFiomnTuoxDj+fdYNBGuXSdb9FegikfOQwaNvDQD0xcHnPOh4uDDI6zHLU4LL
inBJu/qwkqyKdwOUvfu/kDOFC7929/w6E6YoOflI3zEOe2GamHaz3pHbeqc0tB49RcMG2PWcs6GB
dvS0PziBT00vMBD03Sblhumn28K0e/K+LgETgaJDI8U+uzUK0gsjjks5ZdyI8XXexbAAwd4igi4q
TpqJOpgQJ1Lvk6t9T0Bg53Ex0rL5XeFtyQ7+4uq5r7buYx6ygi3TvOw1Xv6OWCsfGWdtUMnxEOeE
btNyRS7Y/qhzbGGuIvs72QQ+NDwhyO6C3AL58Vf1YZlEGpIfbUB+Em8ftjl/YPQslkJcgI/ERDNs
u7uD1/E7BirqcjRpAW1rlBhzU9j9hZG2o9WFkpQbHZd/UKHWrKkVCIT2EA6bT0sh/9WYCDw5StVk
k3ZcEYrAXYJroAdOpm8gdXAen1PO7q6P4iCoJiSBK8TYQOC2mKma4q6Ei9g/Wck7FxcM0iWrZNLR
JK3WunoGqjJog21WP7x+RXkPoFrSTvKKNHRfwkPfxXLxBA3CYQsU6UYE8cRs8/qZslffwLwqj1uO
WIwZ6EYoTZruS29yHXyo7q8kpEf1MKW/3WUCgFvxDx8Alatc/Dhkvd+7B0zA7ArIHVAvwOBwisMH
SFPDpQ0Tpz0rVkh0z/MJh4CJL6yvGABp8jUfy2DtL+O5Z+J3w6hUBORFYFL5gnLeoDo12on8mxGv
tLRpBMJrV0kMigx2Tgta1a2ktINt2SHcB4r+V+djzZRXpSj5P+6dsk7Q/r+MLdjll14kAhpW82Mc
Y9FRZNZ7YRc73/GRWPz9qUmhCnjixu4x3pT2joDUNtz6o79V+2EFm7bSRz3cZmG1ZKDyOJAReak9
mKs5sMXZvqrivISdLNcYofYTrLEPQObGKDBbwvRpcXzxcqc6fOzCYJwvvp1YTFa7gKv7iW3m/5AE
otvKEm3BO0yGZFWYMX7u9/8f/EQShS/tmsrwcXfD9AYc8a6SKGeuNbtAPRTlmpGBGXIjX2HHHjiX
W4r5H8gLavq9n4DgJmg5fftPVfaA8QFh35kPH6hZ64saiKHDc7ypTX3QlhVxVFSi8jAaKlFAqQVH
2OmEjXqGb1bOXDHcPtCNdwn7PfSOvFEdZRtZReCRWl4VchV0aEkUXiHqlBAshEPTXIJZ2s3fsCx5
e+d8Atc37yRAXNom3qivdVJNCyC3Hujj79EmyE8oKqYy8AZzLi5vk2VpEZsJIYPuhSeR7aFUOepL
MeaGylYX2byiCO7pxs8RqI+bWDFX/BZDNJiEHJKwR+/emnoJk6ZnSzVGxM0dkmZPLj4DQcYtI14S
47YS6pTee9RYx+mwKvU6a8SBNeZwztiMX7Fv65S7nVqNPYQMtvHgqMC0Un22D5LAKATjwtUUXdC8
0Ic8J2uDEYG6+dm0n/lvvPgfOcqVHaD3VkMMiIoQj5+MkI5ZrRWfJzwSOh7jIQoQjwCgler+7Wbt
oVsP8y4lURMUGbfvKwnGHt/bd7ZL71+qdTVcygAtXQgqulwR83jB16SgGbD434w3TT6Eqg8ODza8
9wKU681/d12RblwRoMggcU1xDG5xeADJbBcDcOkTFnRZsTXeD29UEmjr+BwyQ3SeOWowxqaMw8CH
L8HhHa7P5teqcTBGiktz5NQ8ZfhjTo/nVOzpgGgPnvZiPINK9NyfGu5mI13G4p6VU0Xg/SYcBDn9
Qxs8EhHQP3LMrPvXD9UbOIkdqKugKH9GcEt1tZ33DNHA/Xc9Nh+U9qsvxbnaT8N6B1hQ16+5vlsz
aZZZLJg/KMk3Ue6KKpOJmQNmjNNqIEMCtUv9c37x9/pfJAxs0MLf5XtfXm5sZhhu0ofC3K5NBQMA
1v0M3mmKbTjzC0Nmcja5zb8/dBVQHZhNedogXFqCX3DcO66j1wc6LFCu4Mt/snv7wz90B9iEx0Oj
2fqN7vFphgIRp2rrUx6rD0OMdZhZ3MHXn5pTrTDOnVlD7wOZkwB2ItVjJif3K1SEdtcKQMhAOlj9
txtLYp/ooDhlrISC6KHFnL3MeRuz6v1HLyvvWXa0yXuEwNOfouWYViv5JYk+i0vOdR3GjqfSTefj
PnHPupOwbUj2ZCCBAt9s+E6s9p/XPA+CU7pK7qBFIY/4plil8XSb1W4Ns5RlnOM76q/Y+/Y032j6
4f1d7/YnVv0BIVN+xLBZw6ScEAnbp6Mujj/bt4wqT6WHgLngD4SWNvKuEWwd4PjfrD/uq9MiywRt
VdTAPcexXUt9InyWrZtFcrbdgDphhA6FZnh/h6JkeGFotyGs6QILzYNUvu8RovH6Z0KfW2erYkIu
i6oZHsPtZ2eo5L00AgVDiq201RPPpiaIcGtPLelv3+79m52hCIojZ+UuQCZWBTlFByxwckjl0pBm
HzYuXqglj+9XzSSh/LoGLqgWO4RijiaaId0N1vcgn6YFLgEekRap6GtlSjDwiRuTq2xqf6EOwZZl
Dt0Oy5XEu9G0tidG/l6zMp//4JdiKZ2cXVmtM1HkIDIIfD8MIYa93fER/b8oN+/QwT3TKxA6ydhB
rgPLwkuRRUh5DAw1X5UDEqdHI8OV0FzGcvEU/q8ajJ20pq3xs0sMGqXZLiek2s/ozPAq5Zum1h5W
xmmWhi+QOTiPt7YjBieZdDb8jyib3K2BaKzPWWTLV10g46HW68Yd2Qw0ysqGAjzUW/tGLN5ZXLEU
Hs4bXu9pLUK7KjL1Y1oQzIwL15k3AkilNIMRD9+i+5/ty6CKypwz6Patj8CFlYtEGWz4a0OTySXV
8PhFzq6cEigpFmFm2I7HsOr1gYiXzadrOFraQEigfc3lMDDS+/mPrNRk3ITjTNWzNNqmy+lSPm76
0SAo+8qfTUr0tqu/sD025RFPJScqP3Z7ARZmHiTaqgr5RNmWZFYN6vwNbu0C5j9T+TgCqopfsW5S
KSTi0G2xwpqnz13r9pdDSH7mb9QfuhdcTORcU+CxlRsY4siJJPaVGfvso+NYdKOHMq+gACgLrJA6
K5/OpQlgvaIQGtoJg4igZzjnL2m9A1FmJhNgfEWo6tY93C8kR+hQV2vWm5TDnU8renU5NNYIeVhU
5EEXfK/rNDHnDE8DckZjeTMI2U7upasunCTDtSondeQQbCctycG6BudYgEKYi15FFhsb1yYjNAae
YmjRuaHdjUQlc3cjS2mR/1SxGQ9P/y4Jl2xuL+XVnHyxExNqTiGh4pNFcG5oKQXoZQDa/1OvIXZo
UCEuy/7CyGKVt/JZ8uXqZ4S/x0Qs6WVnEQMtZhl+pv9gbdJfOe8juA9p69FHbMqrlPKNLq5RUodS
NUAtgtpscTtWTXYIYb4bFmT/oD7w3dO28+CmcQjk9AfOa/PbyEzYDEavSSbDGR9pZVMe4dXr05vo
+MdwHxYG+vpaxLPUewQu30mDs1jadyfjAm+RWpavJ8e4RP0Ql9T8KW8PdSG881nPkOtOn/sghiBO
KrprKvqofL0SPQQLYDgHoEpeRyjx4URDIptfyPOuNX7ia9ikiK7TWHPVafG3wDVSUtN/p6OVMUap
cSewsnlGYcpKXE/1xPjOHrYh3ql0U8Zx86KE+KDoK3KLIYCh9vlEupxSaohMe5kaGALcyDrV4NBa
sa9rsoOCSXPlHERB6HCQ/fDEaARZZQHWm89oBikwrpNQgZ0sk7ZBydjLQdKKXVu6hgvCsMYZa89H
568wx0TBruXw3CZreCQyUwht+0Am9tVQ+0BRTWG1pfRUcF3bgXc6dvNC6fII0ztjgAF+4SXT5Zs1
nm26jRqZN14o01fOWlU5GgMU4LZhsjNxCvpRh1tWSKlR44e9qk5ip4Htxc4bRx36eE0of4d5aE/Q
X/zFk0x8ELA9SVNWvdR5Pvy54ua4Mb9dAiq1gZKB0IDQvWlUlO6Y3ocDt9AJHHASgQjW+NuA8wam
jA0p8WlZ512DbEXiylWMKXtYMoTA+z9KeqM2N0r5Of7Gp4dElnozxfzgfyRayqfdcYjbhE8GXY9r
lC8tfKqra3QuCsPSMHlGC5QPznFl/dZwJL8CUj3Q4VEmAkNYGrGp9lSBpVi7XSysF/s9vtWKDsTy
JBSoKyj6zOKmc3BxLWW+30/1c1n5BdbPtGA7yl/GluC3g5IqQpGimZS3hU732QvmvPnvbF1O0wfx
Jke1AXIz/4lzEnY6ioJVdF+hqZkkeULZw2Fm9G6xLwpJd0UNy10+xoSTJ12SIgx4c/IYevf+xDHO
TDPdkY28cvHzd1Zqqapa/IhyKiO3k4LPhQ0X46aRKg2H5PRuL5BwEjoSi7wWsx4KGSPCQmqSjwO6
jzdQJdtLJWGO4u1IyCOrRf7e3v/ioC0dH0DCK0wHpjQEo4nK/n1XUyPUQ1iZmf1UbcjCWeAeyjne
d/qVFVdj6rztBq/x9HpyJlThmJc8AJrbsTgLqkuXvJewMIRPTnhpN0m3D/NyIU2yOU8w6yJP0s7H
09X56DMAzQ1fkQIhX7imCWhKOwMaXkNN8S75POgfi48C2Lmz+HZOoA/W7orXwqkI3OMPNDECMkRF
WKXKOtp8dbvg4kUMDbh3HyaqNo4ffftjDpKY72V/poG/uHVQzLRULLKCTNth3e3J3DWeIONKQP21
Wz8Lys7NbrFPnuvA96wudIsWyNNnSbLlBuAbN1VXJZGtwkpx/kvCrMd+U8lLc0HDRQ2XDje94de1
LkqIBnXQCEU0VObT2r4RGD4+IGX3rPn3lFuWrk3m5vPyB2pf9TULXN2IgMbFy1xOD+T9gnc7AKy+
eRNroRoX3gXZoN565OFWgxAE+W7HBziNEUrYxs//s02PE+QO1nZEbqJVSfd2OxOSCLbyjsgwXDVP
Fn/M/bMzDV+lvW9KPUXtn0TXORtUzTRGL1O9PtcfzVEme3AHkrKRjbKq9dRa36KbBE2KLlf/SwCE
SjS7paSAc19pVh5ptW0TkKRMbCBkOP2MHwr+GKhvuQFp8DhMc9d6XPPeH4kX2CNG94/XiBWVOGmD
d+2YJMJys5h+6AVhHIs/0/EKcYfSvQIftSiGDzEoaIN+HH3/mmCeFmXk3wAhCaA1YThjMFdv0WJc
fHiVKctnOFp3OB1oEiN7+TeskXZ4RttwDE/9wOa2L4nA0IBVi+m2GbuOWOpPXVG+yiX+QUzad7LH
IYP49EYal7iTU7Q+ywIsSkG4kswIV5LL+Fy4iae54PautVT8MG807qdFFzUIUP8CT1R3oAvsnVKm
48D7ZoedZXzaHHcqsjaGkPSliNa=