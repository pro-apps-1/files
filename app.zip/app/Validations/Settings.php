<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy2JKZEG4AS4RNt741Pi5NVpc8mVzxChFe+uQoeP6A8GDGERyVNNcAAJD2qp9mcZbRt5z5qq
40J6ylsgrOoHMYja+Ws10UNYpMR6s/nN1S3yxNVCIitv3jYbk4y8R5IXd1mguZqxh/UvnQz3ZFPd
D/mgUNNUJuIN/u5iq74jecBhYuN+4XNPD82dphGb4auYnSENrvnYvaLhgFFc9iGdu3adt0YISMZh
9dE4KNDoVk3uMwr1nlCvUuYE+XMt9rJfy1Hf9+6KJ9tsl3a8lfHDjYU7lh1hYZ+7IAZZqeoDJexp
MEPgY2obD7KBeccIwX/v5n1na9v4JhlNlWp5KDO3NLJ+9sQW1rbE83JAfFq31NEu9H1q8OcvxxV8
tKYqcqjZujloRwhNRiSRnh8bNO+J2HMhPs0+KgW30bwubZ+536hIm6TmT94r41O2zourmlpKdXNM
QVx6nChyx4cZRwBF9JR89eUeTLGN9DzKLMgA53vs9rqIGIzazbGWX6OVdVgJlQNPJ5r8RZJVLx/p
5yik5IYb1tX2CJqf3vRKica44jH5W874moXzMyUUBV9PU5Ox12/r9tOD1nA5xk1NgcHmPO6K5nRB
5Bpimpqg0GaDCz02ZBeclovVOFB/Gxfu6EQuzzqVgMycFdh/pGoUbY/GwFesmmUfAa/irS9WEPC5
v+0f/M36bYoyGgUqeVcbych8fnsG/h9t2BQdBjA+xksFEJHbKbkxPka7fA6OYDAjaCSprJKI0wBE
YF5KwUo7nZJuDRI4TYGkziQxu+Cic6F0pAKHpAXbpPDUZAfXtFWE2PzAsEZE4oOhOQ4H5CKrMNMf
+YpYRWq0L0qomTERIvF94eGK+TUDF/tomkw+5W9Gtj1NhL06aPiaGA8KjHAayJUXgtaiMcwdoJX8
CRAYIqwgr4B+QDaeXUUhAq+tlcaAYBJXCqlAW1n9rGK2BFsnJfl8rEGFpcOgJVWCOjDHnSZJH7x7
anxjdNvsKIT57vmOSDcmUcm+DVUYucfG5PlLW0tvJt+cX/upQWMl3va5QI2dtYUH1d3N4gAqg9QJ
PgzytES7wBkMMoOmBWcCjS6KUUDEidPsO1FFetEosvuf+SC2NLw5fE6RFaA3COPMbbRZ4XITKZTo
AkUDt92G+THMH4u0GV6/RX4SnO+zseYu6mx6dBQGEyirgzlss5w8+FiDC5BGla9SfMQV22Suu15T
ZrwJlQWJxE7EUdRA0bdEdNsaU8VCMunlzpAwRHaeDQIUc/QRZG9hk3tfQ9JsfTO/CXC1OoguGoLy
v7KvolNVeS5wUFdHqzWVpw5jCJADGf0pK561s0Pjohrqzu7w0lfI/uEi0x2nmNChTpUx0Km8pCYA
fDVYWFoEXQCVSkJVcp/ger282CWHQdzUyLRZ74DtpySKr5bJ3BLjXhIRf19XBvZhLAaCD/56NfZf
ktzNOdsC9oYQvjHt5RxqHXE7Tbl/N9fDBhSUVL/vawjQd3CgADMd7eYF91PaLjSwFKQI6SjILU7p
YBpN5jUhyyzp4FNtpcP79+ZQ9CQ3/kYDhPxtjcyfbt75MeuDLDsy3YWMAWVXGKBqYQHoTdCgLmar
pAigtHFD8MFW1O8IzHzgwN0F2ZkaIcOYrJu29CjnAuK91L313siP901iaG76Gn/Wdgu9cb1pta8D
e7+mw7bFlLZeR4YB45n5zD2X/MN0R7sc7GEX+gI/6VGvLvAXHKLjGHjSpv8Kw9KzR/c0LRoPJpXY
ye8GTuVXeFgh5ZiHpWccsJAngYZ7lM75mv9K3uJGNj4LQwEwvpOA532wFiLjNmxnVHNcm1GqIJSZ
W0nWlJDfSTgT9WrHMg2r++J+/LFeHU2ogxxUiSgysQOQRpup0OW03oESQYKTgtIAucCaTUlBaWsM
FbXd79ZHhA3lE/ydvyEe1FJO4e/2Q2FTfSlSPJfHNhDgHSRLDzaG5UiVNMcK/zSW1Uuil0Rk75g9
AuY3R2iXJ09daIPJcFaRMNJNZKnyo9FmIOSC1cqjoampO0u0CnXkpHOwlFRYh6HXUGwSqGoUAqmL
EsR5bZ53o9c6EmURHyyqT9Zkc/yRwB9i/6L+0NwgNI5EItTvnGT1gxRyA499YHnoSi4Va7j5GLE5
jIZGKb+B8rHu3Z8tw5jTqTnGujdK0hu9pxP32l5mceMiczx8Agvj/cTT4VKF0n3Hn2MsQeVE33q/
P6608ZSNuc9oGcU9H//LCTSXIp2aNKK+ciDKPah0cozoCS9UDcaJqa41B01YT9CwG3B5HBu1P4g0
/omLMGsKatzl+TAjVAQU494GPmSCZ9dkia8mDNqoA35W2b39sLyd9gTFZWME2UaiZP5nft7QKdbk
wVoUIFrK19bz0BWMXyX+CiIRKafl24hkOHP92IZmC9oLAVai7eakKFL+4Nk8z1V7+6xbq7vusspJ
IbSMtai88JLO2akaqm8P3X23H5I0rbrB0EzU+H9piqu5jVWtZA9CB4tZXAx/qBUOPFqAzkCd3O1v
a8iKZ2L3ZrKvQX0kMphDDK9my6/OMY4QiR3wBuB40VZApcoglKAVxZBLU5wuBnVkrIBDhmkqGT6z
6jNIXWqdxy8LI5+AwW9SvP84blAiQbPPUMfifWcFi7vVx4A5rpAMi2owwHHqtYGjJf3uGrxb6xqM
HfCAILr1jgDdC5a6bDgZmOcH7VZsVXDDWeEFXlOgrgkOT3TIY6pRvsNnnlZn1enuLmKg8M++MWj1
UaCVf+jyDpVHNKlWGyAMuusREdGCoP/XQS67B9gvsj8FWuCTV17G/uW7t+nmzmDl0u9Kmc0l5fnP
ISrca2M/afJZOaqQQ4DnnuwdTw/kaB8gJAc3ZxgaL/EtuAS6pwTyhNaVPLanIPe5zydrlp69GPWQ
BPYLq8y6HueErEaQ+HladUiUZbCzcrqj5d41STB5BYr3Yx69D/2X/tfWReoGb3F796Y+MnMx9qZm
Wze3pkVkfsCJ9dtyNFWSgmvXZp5ODsN98/O0mZHSjgyXrFA0sfLVlauK9ZvV76fhFIKPNMHLmC5W
5VX0M4lGnT8eLHi1rZjOSCIh4Pq35nXS3R8zvotL0Ob5AZaPGVC7e7lDumjhte7ulQH01c79mzd0
oicb3WY5k737Icc93Y8eeQmWjDat/Ktg+c64TnoLZtfUEIOivccXLdGwvbAK+neYo+3NkJPeGuna
bdi53u0RzEqSn17qDwz/cS+NHL9RTeygAcYPw0rxPu0Sul2vfvresF2vjneT+myVESsSBKHxoZXf
v+y7yfDi2YJ9q68gjaKC3G5iAXBDaWlYicYJXzCaAbVZKzB/+DqiEOv/V3AigCHj/0JF0lfuu2Ji
ZCkZYLytU83BVVaC5l6Hqwe4Cqm95EFSmK3Sb4aluznXNHoA1sJM8P4uAF/b7/EgR8mIrU6193GB
a1PxyjaQqtgTJ9yB/+dzX+dcWgh1M1RiPSG3rGlXzgw5hn+1keQRk1QFnmr3taaqZNdcb05cwBCG
IfORtz+NBAx3jIhi+mSz10Wmqu4w5ZTazx9m6xFo4g1Qu8lgeelZ5q5iER3pXDsRh187CLxdlo92
PfO7yO0nP23VV1FAi7ZXXWroSvnLlZik9sCtwrzlYtqiPoCos3SANLZ3IwgrPDHkWwFgfpbccQ0q
a5FB/beB0cZQ1E9B8VUcq/6LVJPY1bihbbXCpaN2pdTjarRa7/pzPs5/1JMm2E+pm/XVAU+de9vf
IvotJJkjAjkNU67f4eFSBCNsaLZf5bBnFj5AO29dd60Aids+UeIivcF/FNaVgNNHMy+4sVevgMTd
xHUcFwLMEhlDwW1InDvyemh2UixiPGjHneFf9uDC7WKEB0hZ0K+nyv2X7F9e0PSRH1LXVgFjwC6B
figfiF45MBMqH+MBmg/SE0cvi8RRkQ5GHvbJQv/lx2DBuFCOUC4lvIZ7sZLYge4VVag3gkMGLtJT
WMKdY+kjSQ6IN/H6LuV8WOr/A+Wjhn6F8sn3NEhCzZG5+XisZOlhc2zv63Nwb9VPnFUyyC4rvAlm
0wMO3cTV+dbsHJOrXkRUCecb++PeILG4eu4nVq9qbGVdTZOvqEGJoQwEYJN0MgXp4Bz18QCbcj/L
Zn5dOS6DYFswlTDgPXRpOStE1KWZZc1TqSOBUsTL3wx4TMNLXl8DSojZGoQVtnTlkuw/NhASNgDS
xH138U2pRTsewEwf/b35SAicc713R+ZoYbtke0lOa4IxSx3zhQsigArNBCMoPGSX3d/mmMxCPFA2
imuJ8hPp0fPF8zJz2f5eO8pR3aT4R2I9o2ER0ITVrtMwEhgtHHXirS6DedfUxeN3qGBc7jbI1Hzw
MKyVtXr4rZ5xO6juBXEJoJYw31BsFZvrC5KuYVwKDvQa6v76QAqq1/aThDQdfWYXi7+Ysm3ClTgt
6RQek0KdjoHo6wrxi7A35sUCDkkIaSEI/9gpMnKmGsHcjElxkjtb8ftdoR7kCWaeUVOIJWj2hPZp
y+RnIIleWIpUG7VkAWfNM6Sbk0iW+gmW6VuEHwYlvXmHrsAxAcNb+hHZUdV/5SnXnOXHansZu1yr
++dzyOCtLBZd1fogdjy77vBwFh2/p5b0CBusCSa3AT0RsqVQczFHglKkEoC4kJSNWMmAp5QKACd9
S4NHRVibvwdpNkGCafvu+DwXAi3r7wPZ7ACRhH/qa+rCox3yq+c/+jWEQqe9LetzNvpMMwAyGX9a
geiJzHxrXSLaOeU1L3448sMp7c3PBSGMx9Crtyy/xVkGJORRgCDszXIxTPBBj2F3aJ8aXz189xI0
ITGWxOqlKTaHOdflEHOzaW5Vk50sDtYoHcTNDO37VFVZhjV0Hf6jZcIKVGoFQu9u+yv4ev7CKEWM
JCA3Capal/aVIqhoDj3E+bQD/Vwza+mxBHzHvYssLNU4BMGrZu8U1/VcAwJVis9qB3yBv+SWSC49
XwvwfzGnHLW0L15YPd6+fUCdAF3YPhz6c1dPlRKg0KCN94SzE9/Moccr6TwUDu9W2kx5CqEv3V1F
zLrFjwKoiwq50RCVnXcBSbeWYOX8Ii460/RO2DvbwxCjbrO+fKq1kDeotTglIBubulwxxIA4lK2b
RJbufsLFyOn0ghJtkA7euvQQEzQOjdYT3ueLB4oPBw3tcy5fc2Pi+80LTuKesh2cbAl5d0eM6LRq
9FyDNQiafTwsbb4AXCCnh+C6w32B94y/cF+KaXQDEKEz+OOVA3zJBoez3W5E1NkRDkeX0VFNP/XM
B+rtGuWEgTvR0U+H2MWtE/rIOIQgJNJ75rimH/WmbCA3w1ep3IAJmtMokgtojNYNmwfwWLerWFZK
gcXio++j6o+9fhJlTpLsqw9R4e4redBVG0C6l0Xc3DGkCyCsT59tBZ8xGc+023Yl9TaqZ6XiwAPO
5Gdx3M+kwY1xEBxn1spITZfF7selTh1HVEjNQ7GkB6N46MGc7bWkrixQj0jzzBzcNBbLLDI15cBV
CVs5j3iUnVVv253g3FgiB64Xe7BgPjjQFIH3uxbw//4JAF2fHWrrD0GSd/gf5rMRGfn1NNIfM5VA
nFQmv1BxDY5CSD0U/C3ZdFQTCH/BO4Hq0JKYEaZXrO0C/8FR01G/YmRpdSJ6Rx8JyNPOxQxu+kUt
oM55CG7l12YKbize2b3L2YIS+U3ARN5q4In8cvHbvlv5YxBJ+95MxPV07JbJkOR2DSBZvWB7rw1k
knYeAMVTHCqSB2tmausFkhn3hkLpfTLAXjAIECWcwLmvAt+c5TQKU1kMmDi+MG72OKEH7LL3CtiO
2BJeEfThD6DreTm6StR8L5/PGW4sUqJrC7VIKrVOAe5EGucKsbeGzf4Rn/3RlnKTGDI5YLstrMRW
72t/+ZAbSHWhL+/08nsyL5HWOkc4H5WZhXuYrrg4wb0qUOYIpkZv6ycOt/xQ8ewdzkmgDyrgkTe/
eukwNCQdl8kX9NLQxiTd9Sw2QwGtyDYICZcwUbKzgGXCmMiPWuq1xZc67/YB7MVHE4zq2mZumUoz
e5Pn6/c8eSJihgo2dfX2rr0V6SzKrbiKPadQfs+BIDCgry9v4jMZ166IKXwb6gU2YsM4kAk+jZ+D
mlTH/7Mpjovq3VwdcRdFOQS/6bsKd4LUVAKqhcxkqqWXuPNX2NaxWLKX+mneCCi1k2FphslsysT1
BIHKgQ1X9EeRoCxW3d3HNuL+xePs7+lNIZ6UH14vFV/LrNxBzTnvI8pqXnhUJQXajjktpiIxzNkn
mZFVuqwI80RC//FpZ5ZTdUWA9cILOFvQ+f2+IsCdeZg12KY1tXcBoYu81Jzc0/ZLlSqJO2WKwzB1
qZ28KS/HktPAyPkT6a0Cw1bPjKnecvtJ+/VsMqJAwXMY8is9+QuAYzVQ0EICrUx77a0pEO9JwIYn
4cYM0zq0bAk2aq6X3xM+/w9Sk4S58RGo6IfirYgk+d6KwOk5YNYXjHracJf+G3579rW/CVjQxoSt
mVxVFRfopCPMv7zEkOjLBQzln8QsehGMecjfGGUZf8V7eDz+VSb9C77BZxKvKnj/NIVmsxnQqHJD
9trYPWFQX0E6tf9S7Tid1ziFkbDCzQFSfVMaZK56QSgOkE+lTqCCY/izAOfivdi8ecrCp4hvps5j
323BVNU8rdpQppvOe9lV9jv9xQEGeVReAXKk4o6xJh6Bw8VVzCt5f48k0YALo+mwEu9m2vXRuxFX
/DXLWZYABzydHyDdsR9Ivld7JT+RTAWzXHhQi8eBrw4n8pqVXYfkYRL3u3uOBdR1+Rdzvm2I1qXw
xFzDPaRN1BJDQGLTQXXbRQePH8mZbwGAZtvDd7sqWXMMdXJZvQ0GMLWnltKdLeEbCpCvIXIbPhVb
tje4P59mbp00xlGSjMCL2qgtLSmaMyPm4AUdL1+Fx8ZE7LiVdsm+rrN0g/IsIXIvop8MseCjSzGH
iXPR/KROct4+/viNMTzuwBdgjAXQKMFJ3ZRktWDpHkuZZqnI+AFqHKi6SINguWkcBy5RhvwtewTQ
0JJs6pvQuQamqBlQokdD1MtKNeCzYaLDmwFXzfbBaodn29YRiDd77l9xHztaWQdzpRg7Kqhyq+2w
xHIvsLZhkbBCW0SfN47zX6D5bZNlV/pmZxBEL5l9xw22qovKdW0kaD0qhoU99XCxT4lfr5zhGu//
d3QlOxK2zAC6JFDx81m2GEzlGQR8Y2ZOXovlWpfQqSwfrxBSbIaH8ObJzP8RsX531mTV8kSELzCJ
ixBwqH1Od8JaPV/vI92i6vQ5pqcTD4RxIpziuOvrmSOOIYKpT3VVYT8GPBtqSKBfWXQXcfRtRayn
sZjWLPyIL22mw5gVrmqcYReO3BCH26fgfyVp+c7CdvXdHl+2HmTB3h8EKW/pEL3QZ5+45wB0Hb0o
3nB9reM+aAdAZPZAfrqbt6A2ghpLS3VXKHQ7qIjiy9IprqzyG3Tvu5Zdlp9QL8lEJzbjTCRpGYIn
YgJbbcjL4GI8EZ2ozk08LXvMBfdDjd7SSjOk0dEWB8+e2+nVPk1EpyVsopHNm8F8aHyIdotUBTIV
0ICmic/g6Gm9W5rLeoBjqU/TEwxb2BiP6RpKwnzQnlJ4/G9KQe4Y//MjmwJsQNfM2S/xg1wn4/FM
NNl4nMRDNtOLjKIbrvChs37Tmd0Rx4T5Qf/xOahQhKsTJR8gxY+j0wYVl5NGoIRozAoNfGg+q4v8
EATOPRxyILImSox86X6qDdiB7Iq0unlzPb10gAq/LzTgTPLIvkTbQkAU2MmD/wpbKndRgPPx0/TL
/wVLMKZR9Ygg1UNfycbe2+Vej/2uG1Rt6ZOuhKFwOYQrTFNcETAt1eH9UsW4IUoZPf3NA//aH75Q
eOmqeX0V+vBZfc3RikdH+PMZEbtfiG9ZnL2rk7XP6KoRXq6u8inmG/imXtVsVP2J0SpUVWgu6knG
FOPJapl4fqAVJ37/kFFpeD3nUTcoezRXRLvjGSDLw7ILVDpVYJshqWXIl1PK78o7Ce7LihJMj0Pu
o6fj/mK1c0K4KBbHJC1qARnboaqlXLlMC2+aJ6CIOD1Ekmigk6h4Xd6liF1zPjtl3RN2XZeLoV1C
Nd3noq8Ike6/KuhSoiH3peNwL+MwBnMFy54S45aVgjAWufFf91wlVy/exBpQR+39D7xGcSL6SVIr
m8aiGaIRtzkek0JX7pRv9298OxHNwQgOhi30vpE8AL8AN5SjBysyRbTSDambdTw4xkGlAaWM88Za
DbSaC2HiQsPWdKXT7uVqNPj8QaiK58Iu1pNgxXiYb36/Dr+9aDck1Ach9i2d1qDQcE/zG4UfOGJ7
8fBlT8Ad3aeBEI1Z0eqB497X3ZdlIk9RMqMkV4F6pLGUQG+mqfU5br0fUTLku68Mpjodg3qRtaup
AoZQUtIBS0jiX0F95HPR5TBmQzKcG8x5rmYPy4m6VvbXLYP2BjVrCg7R0YJl2t2D/rcvgO7b/H/R
+gp6DChe9ya78qJeKhD/ZkiJpiTuvevz3NJeIddq1/sgfaPFFwX0iKBJy6C=