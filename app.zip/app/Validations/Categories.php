<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpyCf2kspXmCJzCn2ELAIgRVKen334gjDPguqIke/zR4FMbQBTVneFaHNX7TKucWnmU9vDEy
9OBTvc4uEgCOCc486BdGkWjQS9TTB88uJlz53+p5KXvZ1IJJedYkxznxNLscS7/ubrP6jVYlLxkm
0G5c59IjEQsyY52b03sF5jzMdWS2qus1GRXp9On5/oKdfv5oq9l4M7M3A+OuaILhfC9s9bHUA/U8
QRq0jNDTA1NqOSxrmlCG3CbmCjrYe0NzPo2KfBZeLxUYiG0Ruwqfsmxza/1anV7aBZwI0fs34HZ+
7HDz/rJKphsG/j0YGVowxbMMAeLrHKqxBtI2dZ1Ajr6aG0dyok9e82iXYbyWAyL1b7H3GIpZqLB5
xihaH8Pdq4BuGMOI1ZvQaPZ0Epg/uwLCnkEfkEo4N7pXDOsg9bqauRa3pMem87K67hD5Z+wICCcv
nmGdQtiQvg6hOPTLi7IIvI8x7WRT9UYdzVzVkv9y1ibXvlLqUcewu3lC1b78UI6cQ7aMvZjuMYUc
DQ4fgqv4nwXGVdvc87UyLwf9gW9mLUXY7z7UiTKufViJ1hW9fVw3RdP2f29s2+txYdnAz18RiDCF
mZG20ZHj1w7MkyuUOc+RUgMLKEfET1z+O+37T41ZzqwSSYX+1sc1c6+U2NaCmB0NiOkTfHs/5yPu
uUDDSar65HafwsN/5E10TQ7QYuuluU1r9h97L9hGuqsSX0IyD8/Cf659oxdNsK7yQUWuqqc4pQrQ
ieZaIKTjlVJftEhb4NZOeBxZrHxwxstlvSBfal4UIEUb2Sp0VT4qBNm2HwvPzeOd9iG1K/BNfpWM
w92A58gehSjuhwMlWpt7PGWaZf5rJBWJYbw1UAXMzIBOpdSvdRjUHYLNnMwd+JUwIomjilrsGN12
iNb6za3LBZifnrt1KgsklmqMvvJX5RbECUc7Onm6iLgsc21ALWPh8LILy7uLYRKItu/ggVcu/mOW
JrZjptvG+Q0HQbub1Y9iOagXHhl4YSV7r2pRJRoN3qZD8Be3SpuKldIIuq2atLiBUkyW/nc35tVE
Qd/eKwCSjYqp0Uhiz/vnQuFMTkgLvxiCrRyvSNugFfKK900Fzej928ZYd9mj4KpoYlCQe6N/M4D/
zMhZspPUz9uiwXP/pi1tlq7e7ZbZz5fgOH3D5kZrCD4K8YkGnqYCrkMEzVsWs+/IWymVvXY4lxNu
ALuGb4zXks/l8bc0Yigionr4ntM84xKvZCSV8rcuiY2o7DsLWvJsxllJmIgSU/PH1ho4W3gpfw/T
4DxQWr9v3s85mHT2XYfBZolmUwotERoXO1meOpvZv80uxzJMhRzF3aep/rQOrhA+WIerV0j1h/pw
8gPW9oVAfMJxsJP8qrZ+efw33pBF+0yB/1EsqTo6QiifY5pDy4gSjTbZ8QIM3fmsJbVGl9kOaqgG
WHi38ZsO0Vjb5Pn7DoHssJFozShdM+0onA1B1MLjCX9WyCT2bQD3lwjW622eYzkLjbJ6UFFpKNLe
xTwLK/TE7X43bMUHZG2Oovx95tVXM9Tgn4ANQ+nN8QAuON5EpY3bmN9kKGeDIX+udxi2vKUBA/FH
DIhbT2ho3jFdCf3z/4YnRm9g9G6ruf3Jv5SCh4j7Uq52MS8k8oioGVNdDxVyO5JCZy64DOw59DFr
5SUAA16KVjWwXTwXUpMPkVfj1l27oT9D5dPBHbFEE6DPxGIV9cZ6actyMOwdcF10xbmBa/+pWIce
k0EKYfi5dJV+2INNjHk/wcswQ7tlzAIu9MzOzKroHyOmBPfxQ3MqE8dk8yRegCGAowIa+T5snRCh
KLHDM5V3uVgQjMY4U4AzaJEd7Im/FeJRrF+fczf4/sR6ohPz4CGxlb805367C6dDa97Lv82gbQyk
PHezfN0S8aZu/0n+A4DrruN8QFb1lRk2duZRJMmHfiIPfUtmHwPGEd0JBTKkVXZNpupbm0mko1uw
/yZzRpLFSrRpiTXSa/mr6G0qWa+uckv6OgChWahoErOz36NIJfM6iMOHJ1SQ6w5YQFzR4raesRUc
UGC30PWarPpYKPj0OuB0KmHlNb3uaUnnjX73gNHcBbU9t7g619t8tf5OXg/PE7E82zF6g5YNpz7d
aStfP6gOc50OG3eac+7GwrE7JdMy7ou3R9Anz9i4tU+NLM5WvVXpse+RgKnetRN6gmofXtYNlLB8
Pg8qk6/WRHsU7vr6WF5fzKj2k8B3Kq0o64GgJwE1/Wfz3g/ElvltOHliomA7bhK44en/srHS5vv8
KXyYJt8aau68llE1/pf1avXXVuw/Ldw55CNXf7Qoy2Qp9br4m91/4S1MNYXUunrepuCbnYqOejca
/7U1vthee7gYcKfjGLwaoMFrAnotpU4V/+gHneIPsH5aDTAj5htbtccYcaAMITxMARpAn/hJAmVm
wOgXftFWO/5DkbkBf65wimBMAaJyLG0CIUh6I5f0sgcFhYdcTjq5Ofwe09nMUzHmGZeIun4KSwvA
t0VViA41pcPcrWwq4MkfZ9pH189S98ApxQ3kBfOqKRxJPndtNNXKvJtVCyo+bWvIXEojPWt1t8Jj
YoUj7RVh9Pv2bFC8Np3DsaVuIThyMWor6BDEvsGenmWQ0lZlvTH/MLe01zxHT0DcK/bOeN4zWSvQ
u/8N0bOPl9k3p5qZtfXBz2bTnc/jOspotDl8y43O9qO5f/ofa6ISxgnNj+7PnW9G4u2brG+jq3xc
1Auzr9rSHXAgd5N6AiZlQODw5cS9M6zeLgyCSflzz6l4Pq4WMEQS4xvxQQDz4DQInY4hjw1VtsdE
fs7gv2v0NAgJOV1qv2uiPBwAVea8YS/2ceuHQNF9hNFtAri19RwK7/Med368iSrjoRi06yQo9PjZ
K0bKTlbEtaNGL7OtnqqDD+Lcfo6w0UjR9VDCZwLtUFNFndnXDAP1eiZUxiTiQudMgpKeV0OJf26F
gmLHsGoMaYjrbuqI0Qa2w2shHD3785Xn6hUaYnxDGEwMtJJkyaGqqdNplWHJV15imJDGarxHkr2O
45UV+FNZ6hxcmIdDESqRNWXnZkeMlrPQ3A6uVFyMeyd5K5+KryOz3SlVktHn6inusy/0s5a54TXK
+5E/sYDbjuF89u9IMXFEUapq3U8rAvKY31ANtCIFpn8Mr1SllUF7eaX/qOMmMMROSCrzPtusyFCB
pDsIUZSYlJr+oItOwSJWZhcBJhcRRfV8SnTvsfADRXWs9FClVtKgpc1/azaZ2ejJwNIFFW30YSvs
eiITNvCeyw+Afkr5v+tTcjhDVlaK7A0B6UJouP4hPE1NeT/Etkr7uZdBKLw8qz/A01sw63WavayG
yeHktSAMoIBJsJX68hBwraK0CKphqvFJ5INHi1taUFCciA4FRhIoARdftHmrI5YP9KsrDFm9lnSi
4uoa45T4jlGsplphesZCbiWkYp2ajAThrm==