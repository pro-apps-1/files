<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz1uim2drmStlhic8my/wdFULJgCq3sKK8surrlmqau2nVknFbHrZJZV9noXb2YOr0TBrD6E
6jXVYzhD1x5yQQKVwbAWiTpmTDzEFfdWmPEgiTDSdkACylH5VYUQwAXG26yUYK87lwCUXepkWEjf
2l0eCiG4dch2LMaSxFmGAMvLczGHiJDyFwXIdB2h/yk0itFDVg5n+43CABxS2RT6kBjbsPZ+WJsb
xpFs2tYTZ1vjmHQUQG/5aTKQZuZrRLUD+errt4A2h9bI+Gfx+6/Lx3YILgTkSlA4Z4iOoIkJeri8
JZqs/mlQhCSJ1o8Ev1CRFJujpqNFWqGYupvKyEFaLrYyUuuMq7CvLUg5dyssSnGB+cQdWkOtK6VG
ovsoCoFqHwL40F1CBIFIfSLM++M5BExt/KjHQPS6CD0ZqfjK5v/a5DbQ0NBLIB/lrn2/stxGhmBh
JM29MMwynrH6IQp306vC3VlrPyRMZfrEZ8O07P1yCF8mjbK/5FJIOsXD89JuFS/Sm2VulQG6Car8
wI62EJSB+zGBosPyBbBOp4IBenp6t3d33MmpzqsouLsePU95YRbTZdtaNrYcoDCuoQLrtKUag2Jr
gtnnxiM6XKrhGUsnCHC8en23VDM5006oTn/MFh2M55+uU1UwxlrN7cfC3ZaNVD/u4ntFDb71rQ+7
vV07WFe0uZwzLE9jfWJNR6rfb1aToVoc92gp7oLwMddyemgUIbL6P3D2zHgniIEeN0aZGCqjPHlt
3j4dY2w7O+J61xB+60a6Tn7Tq3ipyJkfnSwzc0Hn192Zfwk6f01FRy3VlOiLDQEF1QaR7/FsTNqT
UHapFZN4Hq/uTQXEl0Qfo0WHfCWz0F8MeEHyLgSqmNwLn85CAiLvkDT88wiMM9y3BaPQBcWhcYNH
dSpJ8SpyoQ7KP3w+n16yJXCpSuaJ/A2lLWbHQK5rxe2pJ5GSEKzE6kBoKDW07gqShDW35HxczOk8
ENB6WME6MJEKm2CbjCGreN8q7qJM11Uh6rR/x547T3xT0iFmcOz+cxLs7HoDGfFFjR1ag2iQ3MaN
7RkPGt8RyE4wXlK60wxOw65DxUe2a45Lo9Ce76dLs5MBadu4SUZB702ePQx6OCV7rywL2CApzBeT
gCRymip4Y+f8UNTWkxxOTEXIj+Jw/iBbiBGLc23w3QR0kOZeG8q0MzwG7eGE3dGv8BXz9Asq2alb
7o0WB20Tofffi++nsPyvX+GKwU9ojVMaINGV09u+5d2CKQ16X3feFHp6tbtsKUGRg8/bnELOT5iR
aXHaV4tOFhu3Lsr7rWvhr+WrHoo6FcyXxS+pdZYgrs16n+A3AbRbwU2smHv6ahUnfuDZxWSkux6F
WNjZpM5gHaf3esGQudz7CyVbw3tgm1YdzKDBgh3IACTqh9mT7B4YpqcfQt1kiGGKpINAH/rhDzET
98ZG4L9NTKaMAb4JDXBD54ZY9FRCQKf2b7iO0CRPrTzr/ARfH2Qev3Rt15YNYx9bhxfDcVG8N1OY
j+e0W+ubYhkr+7RII2QtgGpBk057XkWa2WlnL+wAv4YVcO+4yNnN1/m02Ry9JTc1dnE+Pf+/e1oG
fRu8M8bCfXNqJHgCM7n0Obi0buzINqaa1LZZ/pftnwKbDzrDPxeWyKnD0SrVgtxLOdwpfnSByrFy
y+u4hQMfpYMOFVG7dEKf2IN/fpGn8LYtFMjSS8bEhv++eou+ihVPWnNDMBH3XkSOs8bX+XZmA1N/
nbFaPGS6LdUGjeZmVpu6MY7kGyRUHrOLapxo4+GdAYGkphg/bLpje2MTxnDn8symOaCFX2WZ5McQ
IR/hyNYB/d0AhIzr8fTWLjXrNv1uB5uPy4EqhzuqQHAxpGAu38ED7O0MQy1zAn2TQyNp4a8Y9fGI
2MLpO7ChyVdQbJtjz4wEBHSoEzxYEKM43Agu5oVLBgdNaXRgnyg4IR6Kv0BglSsHFjmhNuKqfvyz
WDbwZ6iBE657a6n7SFW00xED5spAonqeMkGLb5c6xigvTN/opkWvEMEel41+J0QPJE6Ifrdd0cNz
21NLvhs8JH3i72wI2vHtFO1OziqoGGJneUk2nSq=