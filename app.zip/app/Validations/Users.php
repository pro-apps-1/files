<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvTfMrKAvB+QqwhETe8Ipitdx7av4XmW2e+uI6kbMqPbcNvwWvRORZfyUL5hRXb7P7lrMLy1
KXXWmHyXW49qwU0qPymCiSbGWd/NmNt7WNUOP4nsYjaxQrBmsPpAiJS+IyIdbrQrXqOiC8dKHFLV
VulTVDi4Su2vL1Fmd/YYf3TnQB1YiXU+LDtc73YWZamPRZ6y1SdJpyEaSaEbxXWXoqds4dpwk4TM
uJY1XoLcYxtOfMrvtO/AdjsaQIdB5VK2lgOu1wkSve3f/SmM5W9QCEVAiWLgOQG73NIFoUG6/KhF
MHj8GO/T0jLLJWg7efkVs0c5IUloSjU2LuhPqu6LkXWV+U3ifxsI/blmppHkaJJuIwna8G82PoXE
dsOxKuIia0PnCIPfY4SLlL8jQz7z2FiLI4kUah9w53jm6jDokuwBhgnAhd5w3oQtFJMZpjeX2Fse
4CMeQhx9MyBpm4DLPPwvbdRISOdmJD9FkCa//TB+Pjr0vtkhKYaWxo/7OEq91ztfYs8d4nm82UpT
BtiP/TdYEbRan6CuCINrimBOeF6aI2q2bFqLzklAArY5NZcrFUCP/x4vh+lc2urohfJAZnU9C36O
6eWbq50jJcbxD2DuRuLfzoLfgBTOnX7qa4xubeeIgiweH3N/wD+Am0lhGxSitIoB7yulZ0ZMhBwo
2SZEmr2Ua4qDh4YixnQXH0yBBPGhHEeaQF0qhDu4foknBCK7YvijHHG4ugvOTyfMe2Qxj1jb1b7+
ztJt/m3DLkgl5es4oWaf299x1MTBRFhfWtbfm+UOI6A38gddxTznxasBfnDX7tJuSuaqanuz+fdN
fGil5gl8JTQodAxaVSzk82WZwl5pQj+l0u5kc5/5YVJqQPebEV5CtovAEHuzmJZsyyc/6AsmxY+j
I7pYg2AeP7PyUYuYzC4YKB/6iDAS+rsZaG34/Kq0pmg66MGkotEQeZHgwWl0PCLghWMHhI+wyXGI
5NxsOWUeC9cvuL1m58gZ0itsiGXev1xpr54UOrX6XPF7EPQfq1iq41QLx4yYNH2zxyRzXFBua8/w
bigLV+xCUe3/MHtMpT8d0MjE+k6CkaVVkO27UO+F0uJw37AaBqMGatqJ7seEnx5Hn/zh3p90BDVo
M4KAuCYx+gy7tH/FNZE7r5it5jQj2mcO+pMniHNvrE42I/WheYVXXmBV+OjmHHQGdmPbfLkPP3yH
+J2/HyxsRh3KbvXXIZJDmYqeWhC+6obwRRp8RONvMVSpF/8H+7UIsg6rz+6QjzK3c9K8VzeYZdE9
AHxiV6C5tLvgmU59IfvnCaUqgjs83vq0QSTdRGYL6w3+QJHUCQzwA0tNLxQynK7GBekoYTkBi+HL
puHGP41mgmv4jBGezx1m6Q+eJAwRZDIQ4p08/lSJ+IP7nH+GQHck151A6HyYrKHbizY9huVT1axq
JkJkmwwTOyZ/4OrfoXjpb7hZPXLsautsQ9+zP3uf9Sq+HtsuSdVelOxn7KPDaL+KuxQTvTVwvZaA
fMw+E48ElED9Sx/ilxkZ3rKqLlFNlk05TzfIYtdKYbYjG3FleoMnjcUOwyKn0jAQYj4uapGD2r+3
eqFJJKIVZEOOHB5MOmCxQb3eB8bKoTuCaLdUqRiGqos98/6eWjeMwrzzcOmD7d35pEGVQEQUEIVl
W6Bk1juFcFtlrg8Dl10027C5GoZLLkUvkWkLEN1WZJZ8PnwSMI3oYn7QLnwPdO0j2jpIStsw7EcN
JgbNhLEvwjkOxWcuvNCKBMXjIcigM1PiYVkyfqEtDNMKWS1n1fFx/b3d/iXENMZGiRFRmvvcwEyD
Wl3uZcd7E6Vu/bDoTnt1z3VStl0Aq7nEYZqKKV9o9pOcW1GIsUy983XkgUd+fMv55wqONGI5rs5U
0jYvevb4cHxb7x2j3/UA+H9HIkFj7ir2R2NDniZEZQf8X0PvHp3HyES7vj1nfWo5yWXEc9gLHaJu
fN9xKkSJYF4IANF8Uqw0TPI7qF37zSeQPJAzZogLotost5qG+yltwFCnpsf0sEgxR9GD3mP71KuI
76YyePIFpW==