<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPukLeCuTI1dXs5OrxU0V4VQbWsBs8Q/VwQguidXthi8rKALxAjEDEBm7CNUyOnLMq5ibVBzq
o0MLlGRhDxj0U1SJ8VEfOmicvfa+4crKPnthlg9kqU0srtKsEZ0ljfdJbCPztNPAu0TPYLxPFnKY
BZxlCUfWRXLY2s3ompyaQESx2gQFJhZr5FvqpnJv71W7527m5NHtYcvZnpcqON4RlH/aYnO9aDQ1
73gAtraV0ZyzYjcHfzEAzonVrCgfPRdqf0Erq6Wd/76Lpb7MaO8rknKwRrPa+wwP6UqVlaUART3Q
IZrm/uYzx4x7Uubac6TnhwNi0Psk0LoI3iFUW2mT9GQKUOqFy4hFk3Jr2FuhJvd2ztNh83KxZY1F
gGCHp9zHKF1AOjqAI4L9jD48/+TGeWI8HQFLYoE56wPaIgaPEb6tg0B12W8WnZ5n2TiCakmRd81O
YKJcfAJlB67EIH3sEMOsgyuVfKh5eeRh2ksYNRc0XzSYiqjOlTwMd4SI5fv0sQ3Dx3MuhJ4oeT88
+CEMA1pQImdc7QzWtUEAjrmTmxBreR1BieSHLWa5QwLeKKQaNMbuNYXm/8LarOvHnVFlhF85z8eT
/pfO/eUsULE2LiGG3BGYrRUR7naOzUx9fonZqrRLcJZ/y3FFrweerPShRbEfAa5tSBTD1AOZaGIj
qB0NQNS2jtJojRmeEniJAow+GJg6yrRZC5BEXjAtp4egbeHZBuGk+hr+PhaTpTrzjoi+sicsM+s0
Qd/u0LvS6OCx9FXVJWZcH2/MZbpWbPwC7i3WQnveUoCUXQ7dRqIkZ/p/zM+E1GBgGrQP6WFQxWa6
/k3nfrRFbWa5xI3A88o5jVZdQroQOOIgA68P0Mbg1nSG0jxTchD7GQQAnp1F5nJFOHzRSVXAVAlL
FaVNTTpNplV/ELt6fzDhol41jfXDR69SBurSKRsj+00ZscTI6EO3axgatK9uTECory3Y/xJkyfNx
yh9MGFys9WgJSEKGry+WMBkji9HtzBDwX8PE0+p4n+xhAoT8EDFxtWNBHd+dBEFPyQtk5GaH3rSj
9IT8uS7hlfbA5nIeMkBdfl8/yuYfn/fhVVzHvUq/ZQ+SCWFuRjE22rrebE0JkWxmQwp7RNT1BFLC
KuTbJS9b52xashd8s1oLy2aZE0hFKQSvAMklyZ2PSUDZ2OzjFrBXlg58T1qdIHmRbbTTrYfM5pvl
utbuOsfAcApO8VudQrmNI274zgVMkA0JqK0lDQ9ryWU3jfCTff+nY4DNPykkaWNrP0LteT1M0VVg
bvW2GPME2hQHoi7xuwtb0G0m1k8mc8hbQFMAseGrBce1/nwwsC+msrSiGHMdnF0LIhxRir59NIl4
mNt+34ehLeBo81fYp8dBdfJ8tWCRxpeAg66AZIalASby8j88D4VIL/qkXxnKnv7/q19TBGw31wFj
WVrycZR5zhpFgJT/Xdo/61vACJyLs9pCCfhokLwzD3Bv2gIkO5WtJUGcet+eYZ3FdSeznRa/stLL
Tyife9FuzfuBivp35EkdZe4Ouk3V4ZKMEQz2n4x4pijftEoA764nB6yqcmKL9zB/2pUrx1XLGx7d
PwPSs/p7D/y/+Ffj4JPExN+vVZXzwloz75bLf96+FT3ydw62bA4FchR8t1plHRd8+FIPAQB3sh8T
NLM6Y0lttDpfc/5HSCnZRMXooPW3uR+YZpwXlcFVnDIoQuzQDmNGzxFvzxYV4turIQYwOxxPqAix
jDWLXk02ZS/gSVD3gcvhhXj1uR7cV8QVB6AkDGHUsXp6JawnWCuvNC6U6khAaX3YhO7tyojr/4tS
ao9E/wCkk/rzg/49RyWGweuqcRv0dVmgK5Or+jOFsoRSYD14NNHFFleKrks2cSd6Lp9J9m3p7GVn
c7/JtRNyqrpeROyafYcEQTHrMsb49Em8LCH2Vv1MV+JyDMrY5GvC/fLc1sMFM90oHPoP5G8akXJ1
0fAEsstk/ZtO7reDt0Dwr5fzhRD2MQsOiukANGS8EcZrjEX340Z/pAHLa+wrwA2ba/Cd