<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvFpPlpiOblqwJ3ptoBwQL6oKOCDC1VK+fYuT6yZMuQKgQXrKX5iZ24Nvz8a7qWdvQi51fwt
6O7dXtEKtlejmwSievuOeyJA62bT3qZ6mXIU2lz8ykxmDM8RTQ4RY2PP/GWwDtdlm4/JpzQ2Mvps
Y80DWpcg765FsfokgoQwrE0W0G7+nTwa8zWIocqPl2C50dBgUZ4eLR1VWw0psr1SaUO3n2T73Mux
FeMOzuxMioV/7+wNAFQ0hP7Az6nI/Ra1uagb7vQgXq8KtuwtDIuffMsorNves5Ufru9zEmrHBEwE
i+WxEy6QUmG14bLSWswu0hdTW41alaYB8rK1Mpdao4f0fddrwxCU49Kuf4WQMq0ZrCUfbBpunYjK
ltAw/K91ct0JmysEZdEJZ8Am/IirloawGvKkFrepdyNJXBTDoRDVfZ9oghA7Fg5O96lirD6ASyRM
zQUCEphs+TS6GFeI9pxGVq5SSJXtb3xOvgw6fEHMXu6IpHSpNmprSv4PvzxHPBufBmBktSnuQ0Tt
WbM7NqSG2ZPKOuR1pMz4oa3F4+V+66OuungqObdeQ0KElFX9xF1IuBj5rWO39r6Yb5l5jH6tNiLp
UXwRXHXD8vtA6dxmLEMN0vPF/hkMYK/v4qlEZtffnTpNgGG94DkSER3+dSgmX0aIBuPpU1ga/ENC
osfQV51hK5xNcFYETGAoJq0adawOWWivmxj7rd6COb9I02a+sga7aifKFLI5406ujG34yJHi7Mpm
4VwVWfKYxEVUn+uH3B2cJBPCGm4ZcZxJa8WFDWV/dUY5cllrx1yjWK96OLlHZ8sK7Gu7tQzNz54G
O8uj9W7OXdnxVNUfNxvGvkXDS3CXfn2kdvf7j38Zj7FcBdTyKbXPmfy3N71yqtiitYPGXZSSVxo6
qcJ/kMdDclFvq6TpW+zgyKo7zFNNWTnNbpEzVO4QgGg7qa+WhTm+Wv14pr88KP8F1Do25p1NjD0v
gyJa9Z08K80UyedOIMY9I+xJQdEJ1//gKWIjHbqaXh70kG9bdAcZfUXhKSolbTh3VQacWFeudxmA
FHG+hOQJm6oxuy93Fh7U0mAEEgCSyuFxSXmP5ZQcBapk3fmEQHtGg8QR+pNE1r308wnjbOrc4ewG
rkHslWDdq0bTlbetyOIzbP94ULPkSr+43v3XKO77T1pDEY2yRxpgyTF72LF1qMuRnDWr7d3b3cZL
9Ijw2Y19P4giKcbBgvbsmt/ZhmxdLxxuCAQ/XhygQz5uLLSbyYrrirjZ/v5SdoXqYn+cUyThJLTl
cXzuwG+gq+Q4r/JShbBH+wmmvZH879JLeO26pHs4NX5tE5epKEy+WXJlkd6KWcoeBZaL/sF+E/Ml
mD5HLymzhZtjCZ8OD6GXtvaU8mMxach0ybUztFeJvMxTgsNfm9MnUyBCQndYQQ52HddMzwS9WlEw
+Oke8r8uzhOfqFqsJUvai0OEBc8hleJBTeKkpA9wr8sOOkFrEBdSrtgLQUflX7wY1STNUSBJjYs0
SgZtb1Bou1n/GpZKZZ1sgP9lBsLekO2dJ6BVHDo6+j/MxHIF2LuU98992rGloqDl9wTJWn+Ufjiu
+VutX8yZ4nwKKOlBzeY2iXsE0IeO6cDYyH/DmYuGzU0VHZXGDkRGzSGqrRJRRafIaHYgL8fDIw6V
LEPoOasOQXS+xyi5zfAHnmCFc/194L4qrk+oFqHpt+jN8r2sICVkvMyBRFDDnWzWXDrt/ZYk7zmo
gEmYt3SiJImjEWIRPW6ABNfgwP784CfbRjfUut7RL3W5UwFp1KnNw+RtQzylLymKxu2p+3W9HYv9
Y2geiYlXr9msbF0zN6Fnj+AzAU/nE82Qr31/KOWXhWrHeu9PdgLzL6hRk3R/uo0jq93+9cz8val9
KxcGcpgans4ls7NsxbJykhGFMaxWTUPbFoMFWhakfm9rbS+aB1ZGuR7ewPCnvPuoSxUKyuvUjVTv
biz0FwiB8knvdbDKh9nA/o7jE9twYbqDm9D+K/uKX5c3hAn9a7eXBy5tlG38JbUJr9RRhOhoK0sY
ymtA0x0bd9lQzgC2eYMKRQq=