<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsJs/QbAQSQE4pLeYeUdYeXVkt4JIDERWkG5g8XrB4sdikltRMUYSfN/C2JLpZMbA6PHyUd4
nl7NKrYfCxJKJ4BlJFkjGD59L+a9+Y+GJyA8iP/dxeHz4j0/qo2fW27TGVcJUhfgJxCHQZkjoDhb
nsef2hnoGYI3q2tLMrASZcs1Vdte8JW6ygq3ogNBjexKOmLqeLJnNluMTBmrNi7YjTYUqfDQxyyp
TFsWIKgSpy0sqfI9uP1Jhs5g8q/9koYgZtvCqAHmtXrmAIhk8KcRH1+1U5gARrVvxJ6d30a4ALBn
hXAy507Yb5PXKpVT/2AnOBRwp68uuQzDzq2jXTarzEyLeQaI0V0hDAgYhgQT6UVpfxghkOgXJ2fm
j8VaoBXUfvC7mFRerL68NiTmxfMKdVABjtZi9LHq1Z1lJBuuWT9+gT3Xabco2SmhlUYeG2c87WJR
rLktx783bKPe1LVcqUVOOQdcn6YqGRJK9bS3gtFSgYButncnc6t27+AOE5lvQ6E/xtYR72xb01Ku
MdrhIuczTEBfrGhhPW6m9IB5+lZbmzBeTsYS7d4lRdI+dYD16fWfD/PIVe/F8StdR0XVCnIAKrE6
+jqKjGXSw/zwOxzxlFE8u/ATNExecpx/GUW57J8aHHnyHP/NE9rk//2QUUrxGxmRLU84b4cJRXnj
hbpdw+ZwRjJ+b8hnxV1rdWYu9TIEVJ3/Nb2ZeiHCyxq8rXGeLeC1KcDwK4/tvJI6Ck/1wxcvG+mg
YEjK9fovthNa7Em0Cl9aC+p9xGM7W40APyAXYc4Y3IJc3Zh6Az2tHxf8Pml0n9psqh0jQ8m1LT0g
7nkBnjkmR9JnkzuITFpWR641h8aPymkWlNH/UFZj3x2vRf3Ht1Nnuk0UEjKmlOOGEveFJ9GhnUo/
f4WkJmJyAc2Kj8G/sDV9G7jeZR8mKMjMgCkEJQZnJjfFQtHYqYP+2Q6NnLm9lASJvgHpBgEXRdC3
4wwPJxXJpXyLJ5eqE99+k5Kk0pba0dhV8MaUA9IErgSV7K8s9i0BDkZns0pxZZ1h7qJ5t3GRBcHJ
KjGQ+Pkje9hGMOItIexxuykfy+0Yy5R1vrQZ3XITZLNnPBZvqMV54E6/P2ug0F604tF2v6iTOdjg
B9xoE+RG4HSnYBrZ5vXkdWiJGAg9RaZFUS6BlxF/erS8otS/NFyt8Hb+iDr84O/ua4xlVQzgi/8U
Pp+t58hpP+SGRvTezpOeEYsKYVaYzdSsDyzcEkUP8X55a0/2nBbDMkZKiq6MQNduwzBlhaclwqSC
DLj9EWZWVGlVIJW7XP3DalIp9kZa4yt0Kym38xRO80tOeRcj3g9bLpQ80Ol8HhKjY61XHQzN/4nF
5tUE/f4rA/Qllpa4Z+jF0a62xDdNAuFbtyV33xFbLiV8TGW7jOJl+lMuuQDAiL1i1Sun1mONekz7
HEroC52Ou8zFbc0lFp1KKiq2gHHAYYREHUsSObytJatm8VhFWrwbESJsh09oICVpOiVDSndqGhPn
hLGQwqw+muDM0k7EBO7vtPiEhn/G4rqMfMIHImGqSPKTe3faRjJi6q6CA8DtkXYnp2dAoPudWuUD
XjbhINoM+WzbpzpA/r37tnjPfXM44k14NSVhVFWRBpH8J9voMiz+2aY2eNjfGn4LiXbpGIEswXcW
qWtxnbg9J24vq579RT8ZmgRfn+r/+AeqbrKhQXJ/VB7WX5fLm8kqI8DQFQEN+zN6iRCjCNvA3ESj
efweNnElE30DHwusLPKPcKIrwTn2SROX7SWd9yDMfQwtdOFsCTCNAiuUErs12tihq0v8EXsuViMK
CAUkkKUWHs4swQvNeCJEKVOcz92BtK3LHSU8bl4FrjjsrTV6Oc4YmMgoXS9FSMRIIKQMEIYLe8We
MbhZqF0lGFKP8Fz36IMCiKG8buNOsgFt7iAYTbDNdJ7L+UTD/MZT0cQmSURWOF1VG52luLD/A2jD
tYaiixktvntUvfzZOzAy/FaaR4iU2U6NuFQl4lWo4Y8iE56ibDFDvf24dnKs1YJCwU46rtWJqABE
xeX5skmoijBqGtUqma0V6wyfd/zlPG==