<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyGvN4YgbAHli/h9QrVF1LPm1Ef9ARiCxPIuqgr7ZGv3FkekkPUvmCwtgJZScC90iRwaz8XE
4SqY4p+Vxl/8mci8NKKUpx+LcqQoYweBweQAiNJUuBbvDJhyxMOUaLDuz+r36pu50xs/oOjcSWMn
42LjZT9o5C0XDNmvMfonMnBEqbO7q5Oh0iZg8um3a9bVBiSJLdMAqiasQwWVAdezvi02HvJ/b5ZV
xPIX6NRQ2Wi1PHcNbFBGH/Tn9cAmxzSoiVHlGXwzETahMeqc6ktl13TsVIbd5hiSKU2QOc9E4WyW
7RqUZMeWD4s0X5JNZr4z6kY1mitWgLAq3pq1gTX/ZXO4NhA5QqylkA+cXLWIrTjbv00zvqqT7aPt
ciPaDjS9ZsxtkSdqH79zfHFYeGQAFYsZtrwMR3rqhmpgFYaq2zLfN7hvEIi2CRudVbTun+xwJUDH
fPjV66daQXCYBOQpP4kIrHfko01UjF4YuhPSnvllE9xnG0uKmpIFJLopOfRTY1eGV80xDGuc9gcA
XXbnS0q0N6KpFvN0ObEp4L4dnX4/Sbi/BzgDZqcKfidiI0J4Rup+TS7OSXDbMzg9pEtiVHWhxw2F
qv7wsOjAU8ahsqV793dcTOv23XN2i+ELulB9js94lSBiTpxCu9kQ+43/LjWxAhEpRc8cO+xQ73hD
Vin3lT744ku5mpRjGydI/z2XCOERVGuksEScy8qJLCfqKK+W0AVbeHtl+Wrn6BweoZU9iKiZzdNC
TEuNDfDe8iBquOWTzmkW+cR/brRXyYlIqj32Adh+IVEGszhNcRrA6rtQsIZH+MtwJJF72dsi0HJL
ik/TfJriRvxUn1fWJdoHV4KS/32paPANIaIJhSu2bNnh2m2vas92gbVrP0DvnIBSYftwo+gKK7R3
bfRoV1cPRwQ9zPNj85fP4D5hUmCNQ4LNpZa9+7f1uxIUa7mOCQ/NMb/OJLQWv5poZo2+FHeWO6HM
Jw2KRnF1LTwiKoRDHWHsaEQiXY1g5zSBp/CUtHyaUGzDPg/CDgbCb3De/D2uYfecucwuCE+i00e+
8oiufBDgdbfMbgySQ0p8cejjrHYJ0FzufZerO0VHqHqpJdg0Oo470JJ1a/y7spSCK5ZYrPTLO7M+
CgAEakDrz13D1l/wM/+EakxW+NVJFuDRH90RcmkWsUtAINjVw+ocJ9dgafB3rBlYGVjOvpksepzE
Y5kD1I9wBGbk6XpdkvKM8OfuPWNTjABiQtY1NfslGPmH0JryAl8SGazOSzYxXLfO8SGT84HZJfd+
92/JiUCrN0x/bW/jGGIoNB5wj8kmxcFYaBDodIdzFihMAaKhlFy0A/MSzRdjRevg/+tKlEKQmZrK
173JIAA0oMkHxgi1M1EfUteFFYcoIMdFYOIRZMD3+Hcod+clFf9H1vZc/PDHtnNX/z85ymRno1sx
UiQddREelbcSMlbsH2G63LGLIknPhHk9vJbWbjq0iUBub9pE4/mHIre4CqVBiYjREiAYOm7ubhUv
T+I8z1x4vx7PCc4t8uDD+IFuydZJhi9+PBWSEeVG6vUaFTKToC0AzNrUawUW/T8xpUZcGvMKrz5S
Odj0WrQ1klXZyoEJkYX1mH//s3i8HMhktuXvbOvBH5pSmrKJIDxModNZdI9Xvl7CqDl0MYIITR6N
kasCx3r2iIL6wMu5Jp3s+s61A1y/B1Tmp0poja8KnfmNZLJmH0P0P6XWG27rThcdiJvwR/a9egSO
ctmqP480PmrHBSZphxm1nw80AwgaMARokr3Rd/SOl+FuvfrKvquYGOZs/jtJpef9m77yLDvsbxS6
O7s5h/+UXg0CyoUpkHi4xyQfDbz66jO1EVAhPgCkkBeY1OyeUiUfPIdDRHFa7DnF4RR6uYUYi8Xo
8lxQnSEeKKodYk1Rb0C73GCMNcvatgYLtiLf9EJczZc0U/W8GK95cwD9LVKNs4GTSycqgensXd5P
W9RTtXwi9+sRzNk4S4tudqamZQI3ZOCCf0j6G+nvJCVMVLFf5art66GXLWsOnwVRurjd21K6reV7
pr26xmwyEBU1m7mFsIw4g5shlPffX0==