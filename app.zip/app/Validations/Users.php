<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnCuJto3bhDpMllQNml/0IS/973ekOquXiAEuwnrZStj1MW7FXCmkI72f6gD3xGe6RKIf2OP
4YlCRwEdvvUOeDG7SyTimjbFpupnv6ud6LD/g5FCZU700zFFLYFT4b3/tuizgQZZCmE6sAE5e4Nw
0oM2jXdP/SRtIcnKgTqMYNbiodca5zlpO0u6At0t15ujJZNAYMWPTf8qR872ZVkOM7O2mYUM8AnK
8AmfUVSRT5v/IuQxe5YpKM9QLuciQqXM9df7E7jCcMQxLMV/zya8jBPrB3vSP343H5LuvRPh8KbW
vFxS8/zgMLCc6AKxh+tT6CroPwr/bPRfSQCpyjgeLNBFEUQ8KOWcwge5VyYKtWioWP6my6sOdTtw
Sfdr5J9Ji5XG+H2YvvvvpEBZEgXgucNdQb2jI3X10HAbXi2kpDGVKMrpIfFUSFkxVQtLK64iMNQD
KV852nNnIK4MhbjQ0oDDEXXv2O6juBxtMzzeDZ72iSnhPCdaeLzw/xNPJneTETIykJhdECbkHYGe
19pXOehd2/WEbSWTJVJwvc2t8jSBI4Ir/DXEYyMaO8uxx8a2b9xQke093ui7NXkyB1gwsPXndREa
bMVsAxeZBDQ/yPvuR69hJBB5kMalVni8DeOQOU6wKQmP/v44sIWsrerRRfZ27hPCgdnt/OO/mBPA
x9rOr6FirPO536mtOW9wj/Pk78bO2kujt4v9JuXJq0VZ+fXYdyLlqfcxiL5VjxCM1zQcJZE004Xd
yx9g+C4a+BOVcPYtmcDEnsOrU7RBKl4jccoNVZjOnIdAQJ+6jr0OulVuh8Mz6MFwfEB7oiMWC7Sa
EZ5DbqAmCCm6ZhChsSHL7pU6TzoX7m3+0qWuBySXkUCd4CV/IJwLC/mt6wmmmdhUUGOoc5Ea/Vty
B8aFMzA6TjQty3WMgtzpSyzg742DcJCXJwIPKOKcfIvlSbu9YrXrNK2tm+Vxti4TNg8t6tXPHh//
m8vge5Unfk1EG999o+wp58yMrp23eohYkZkT3TFFs+7OPh5DS1pALBf/jMvtidbNlLSIOQ9Z7Wog
E4fju0NLnloIUXkdvDq/XcOhcRyAg9BODQuFJsnGWYUpmWVr5zK3apxnT3yGDbPiTwRVTOaJ+rJ9
eavaSD4jcYLHw1jW4M62iCExl3eHri8U+r5CNsxV4E7lBPVxCT9v6eBlN5DA7dcZlMMc3iwpz2mB
zM3lQbuKC2ZNXoXtb+erJVHwrw1yCq9ntZ+bPaCJi3ASqtU3nemr6dRSpnyZuDo8RKDrK6wUfzaR
udA7fsufQeWNsEoxuYXW+ubqEpaluQX14FoeYJEE5TQMbY3eJmJhTTVSZzSmqurE2R7BvwGbKmnB
AYAn2znxaKGWB1eMcUD1+8vc5xQkOPKxyYihkteOfiA08IsrjNW3xi0/lQXbZGIsUbbLCAygPaEI
blYQFHpcGhnTgM+jixO58oxTkI23kM10kU5AI+Gnt6u/Si/7efCE5IUS8nAQK9m6PJgDibhOtJ3h
YhTMEt9XajNFiDPH4dRJD+06ACk5MqQPsNjNB2Lfg+fHbK/v2tVMfp8QB3B0coc80xogPeSz+1A1
ZQrMUEkcinKP4BQi1mCH7n8nrpfsg63CNw9qPaQGsW4cMgGKJa/yeta0ffaAyU6zSpQ6S4WowblI
GzhNONQbj7N+HDko8KHN/zFtugWPXG9AdoO4WIzGsfr3X4xiBd7/T12hzoS8hhM3/UfgHzdBSjx1
Jj2knTjb4hYtQvU5ptkBtTTm2bOKR9ewhi2ob1iMOjbKHrjDVhiJYOD+5KvLze5ZQFjrYvP7Nbjg
ScgkujHtoKpbXTdboJbwKOiX3IV48jpQuPRzor2fA32faOYxSp1Kq+IDnrE1Vr2LZJ4jtcd4RsdR
WeHstWjILuH5Tc1ScWspRsUXcWUc0mcWE7jO1Por1SlME42RmbxoxkUzjYZEQC0OglRWTCpJpnKF
AetG56gCq7ow/F78pXLAEcRU94doyEK8qnRPPf0Ek9tTikVUTFJ0GPJhW78BdVOWthasURsTFsgz
fueIH0==