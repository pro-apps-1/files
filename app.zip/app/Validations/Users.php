<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmk2sWvhNJyXSa5FBV+qr5Qnnm+MyE8a+wwuemvngKODsT6E6yko7S8QYVyRf0cWXzn7h+4O
eDgsRU5zXWDRAK/6h42e9U3kE66w4OKelmF2yhLpLYhmDa7Lt/hMcZ18WnyP63I45jL8ije9R5ZF
+VHEapxw9SLEwFuH5CZz+4K/AnuDJcp5kLtrIfqTHeGE73DbS1E8UG7AKle/ACmOGiBZ0MNZyZ5R
CabZTNt2SlhuMqm8xTck9Q4W982PDOpV1Mrc8Rv5Gtg/oOGMaUIvJ7aVDffaUr3TGMKcH+8luy49
sRXS/yR8Cjr/zkrIXhXu2CZgLiaAduj9g/UMm0qIjTnlSahevJ889FOcidXLM+daU2ACIKPAeJZx
DYpwITNDU9KxhxS8BSWZga9p+l78lk1IJWgl2wJefTTOG3A+u1fR/IRcS4D7Dm+JsUhI2CcoetZL
LUYn1Hf7MdrYnEJ73kRRFssiELfDGYT/kvDxTODi6HAiXfoBX3bJFW331x5QugARQGgCkkL8aoNb
NGlsknM5uhVTPBWFPgbcpWlhicx3vJdvxdwYrBql8vHOivZgBOw7dYpEgA+qqTOE9MbNz1VJFj1M
UX5dXRsOKmTBvmEezGOGT0eVMV4wFisnMlkjbbRmvpvxHJkT2q8U71j92Fa1JYXxn/NrjHCQ+hb6
Dh2kPohDIiX7Brl5gvr7iNYI+n6JLorKVZifmgoTDifpZkOiQJImadx2tETlcRQ2i4cOnra5sFZF
2hSGFfbRGb4zjBVIfo15+QVaaha+iQa0zBzQ0hh65Ed129lf+0pR6KoEdX5sWxQrDSPUq8kwG2Br
l/wVX0RwLQolFQCMZAoVKUWKmjhN0BXkCzrrymHpIFm/IUf+vXoePB5n2SAk7TWzOPk10/SgNm/Z
xI7uLsuHoLDt1tzhKlywNCaCBobMRrcQtYlYeMnSRWuZmjmftM2fPT5hyKQNBDaUvBlHzYLCrQkO
ECCxmhh630SPQJ8rCzQNZ34Q1gUn5rcnDPeaBYJ/KZrcgtrNELSffGDT8QRL2DnrY66L+6x4MwPS
8DsFOOnOUe2EUXL2Zieue3y/Of3QAkdH8nyj88avtsZLlGd63LYi7tFmkE3+oZ08WExwEODVXq5Q
AxbyBzn1mqECU8ciOvcyocnX458cbQOtY3Oj53dGz7H4SNqphNL3x1zKub5SJv1V4v07kUkTuG30
69NoOaDtZqhpSFthzTXtRHtcMotGGMPycmf8LscRRQQhzHkbmWGf/P8YrzzOocPfnOHF7AqIiWer
KVg1/24LBv6R8BVPAfj1ogjIG50iQkEaCU/huqGJdOwvYKA2aBwqS5KlbBLSXi0o8pQ+qefuBMSX
QzN0CRI9KQQximlWRsxqFYkWSCGuzDn+bq1zabPpaNMX733RRJJKqeuxLxkW44J1AVlt5ekX5/ZQ
kDCZV3gJe/GpuiUV528ZS5tgbhuKeAoALfBO8W4F82iVXGJznWdVG6yvItUEi9HwSH9oBMzQe1tI
Cs+4qv3sjAKuDQnudCRRDADemcv1O93t9UDGudFEG10/BAA13nzClcjgEWXuMiu9Y+Vg0sWsr5CQ
u/v+HhIJfLj9q1/8Rc0KnTNDd+2CDBYfraxvTbGMzPVFAjhkqx4ODlEH+N5AWjSdXIMRs0jxg1F0
Fj0HaZ1z0rBwDZWHDxdpudtleD88u5e/NYh/amcUTDQLkc5/PnLvXA/qrh2kBGD2Jcr/s+nnK9oc
LKzgU82Z9fEiED93Iu3xx0F18ytkiTyM6GBrOKgdQySYRa7CuxVpgn1VzM/QAmlVGXLbNRIQupRc
38AfrYRcUpHr6nUy+P42CX6aU4DOHzKThcQjSwZwpp6NJziDrM+uKcP8AEytPgul4Opbb5uGTul3
2IA27RkL52c6UV6DxQsfebcH0+luWOnnDtgVBCnD3pfbZ4H5WmUmGFAo434XbEDkwuNu6IJwdRy5
ln+XjsWHI9rtnsj8cQVBsFaBnhRhw9V5jvv4YvVuDfT/vx3ALXzOUS/DEkx6eBU2OKN0zCnMVH33
1kCn2Vv7FJavPJO5zl4jlRkEFMy=