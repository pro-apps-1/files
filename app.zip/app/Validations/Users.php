<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmnk6FfluU3zTgsDsNhSyK+BLfVTUE8INkGvbh4Flq/u4bj73jPj92NOJiEH0KM2QpuBJ8h5
5S9YMLH1tLOrEI6QEejVk6fsGCqT7XtbcaHd5R+Ujdwu4ttOTpRu33MqineayUf7HI9+0veTrFSc
T1+y9PDpdegjMjutIHt/wcJAHMJPZBL8SyN9cCcz9627ZBCbuvXrNg45x0DvBcWSvx2MtjkUutdF
dYMUDhXEZb98O62CyxJ4WW/81Gs+Fl0FeGSA9pJLRuDc1MUs9o04TxIsCjyzP2SNKifZVZNVmz/L
DOYVUsmQFhKI5crwcH0WofUWxpLQrOIz7koo1JMnPgDw0QHHgrD9jr7Y7M2T1JHXtGtcWdeGjFrs
VOHlxE8K8BLa3VLwrQzWnqQtFSCftx4rM+NJUt66ybNw4LakajK677wfZbHFzDzkzWzpmbjnWrgR
vnuB5JGBT1Ejjt6d3axUUng6U5EO+lYnTdidOI2Pk83O5+qX13kmc8E+g6jBiTJiXV6PfPe957jH
dqQwzrUUq5wd3Lj/UzKdTi68jchV5XEafj4XhU/TyCLXIF+gOf/5DVUCIFh6Ehf9KYdrysuDIf+C
cwGC/tO4fQ4eC6gO86kqtiGnba9ot2Lqio+KJMtZHeP6TXdWABbP/yYQXMHcLDRSnL5gDGoDgmtW
pQTrXn8wd7BiDYM5Vn8w20fmN0zi+8mPb3NGOs2MYNJJeHh0PIl1tiN7+E02HWEsMwM7qORan73Y
O6hbrMRdLvkF/VMYjvmldKsSmyCR1Hlm/P4Ojk3pvHt7L7PshbshWA8Z6rf2PgVHzKLIZ3BdikPt
QopH3eP5r4ASigJ5irEcEcLt9nShJcioRR/x7xTFKf6XumEbfHGn7Cq/Ozgh2pPJE9/AT/ALaSWK
FZ06xDBuOrrfTeKGpizYh0SUGWogyS3HLWjn0BwgwNzKqxP8w2Rgc/7u9LLa45J1ipGM6+8cQJLe
Kni8LI5+v5DQDNySJu7uckh60Wtb1AHf1iqkhBZx51CmFKAiNU2/evy4IzFsrEEvvU1m2Mj8w7Wj
mxtS9iWnqU13qDhnuEjFSa8tkqsFJN7bNgxQjSsuV+PYOO+fEbS+/Mgp8WigsECF4DMdwlqJeehw
HWlhjPaGWNtug3M0sG6UmGeTXnMeAhGno9uSVNy/zMszBMaMHaJBivsf7qT/XYPoUBFE7RJQJ+BJ
LSs/5W+G8IGVO0EJEZK5/dWi9ajQy841jRMN26WLoO5YyJWLztv5SMPmctHBMbxEGWlfmGId8l1N
pqUDX+sj/8EizEB/379tZcyq0ftB+5YbWwaoYymz3fmk9obzqh0D4ekSZ8jCNbWbSJz4wnC3B7Bc
8UQ26CYkb6EBmAXOi4Wjn/VvC47argkIdrKXPyXLwswPYgUDrnMGFwjm7whBvfRPsXIN3aLe6o4P
uVGv0C6QxJt+jrocGH8GMvQCcNYhdjvmfeIseJ+ecvd9jX56Js+UcyIuEzphNuY9ehV1gC60d77i
MxmhDt/988jfTigeMhpO6zQNcmfoFMALS2Y8Rng15Y91cvK+aylfHb8FYOULuIQthSY5UtTyW3u/
IkMd2adMNi2can8XrdfQOwX6K7ih1qkNT/BCtKFjfuv1eK7jF+TZh4Li1metXohRfKb4DZYoL9f/
mBhYJTb97fkjk/loQxLgGe66BKmIxyM/auCzt0aYB1Zk7oEBVpcjGW55OmnyzTM3v6dlQP8KCw02
bFheK1PhZ4y0mcseZPssMDHzzoVzq3AqidMdfz5zcpXsW4e2l0yOP52RrRdc2l4/jVCMzabZxtFc
N6sTk8uHM8Tz3uN4hPCi0NUJKtnXp8RTA/Spx+FZ2rpykYkoRXYO0k+3iHxtTyEFBOlC39IGnReS
ljC0C4GK5BqvKnk5qU2SjzhJRPvH4Nod2vhCi1gcYGSqaUPnGq7F5ne4n0NL4fLjTOKLvIvzB6Id
MLwNYeWKpgPcpDkRtgBr9gc8oxwU5kV+sbfGLsn0d/YUajTf3sDB+rqQxzmtw91jMxrTH2aFGF3Q
5t+TJxTI7BK321VJkSYB5Dq=