<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+8f8Q7Af9cMa+gqWkvXm1Nqga1r4QSg5EOflN5s2kMlTCAFuYXarEaaScYFPYU6VgKltdkC
2y1JCgEwi9J4/Aw7T1YUZeUMO0v9fxl93cZea65ZWtKj7B3agsIZNIgD0UpIVyQPdfxPTk95s4Rv
99LYfTET9H1G7aaO12gE+PJJHdrJecztgeGtgdv35j8Uz5m8vCb+e1uiM99N9TVMSxcaj1RYeelL
CHQZdE60O98oK8t89g72g4Q/nNpNBXB4jUo1WhwWm7ezVyeNcVDbdJI9JwJUQmJ1exy27lt0sMY5
ea0tF/yG3O3b45Gw8i3Fog0upqGT0e/olBjRqEBuN2pjvskunBjZTkxIafBccNQrX1lwWW9syw1g
HUB9itN6NNhqs9pcC7JQhg9ENRgYIuKKKnn0m9AJHyK+9I21fuhzSLgB8/8P+f0jTk5FcuExWlct
bQUyNUAG1+0p6qtrGipAs5CL2E81+mx95oPluT+OxDtkO3szYPfui/Y7OzHHvlfviWiSN3BxVP2d
jV6PZjGSKqqgFy8DTRTA+MM+V3L9GVYl4+/h5LYymttyaObEkmLnPOIZ7HvgjXbZjYDL2q3YtINJ
qbKlAxiSsNMJinvcjgbxjT17eyp4msDue2nPRNyX5ZG6LVFsvxBWm+xRz96Yi/IeYR9NK3UExuVu
S45LN5SrPKGeowPFxe7JRsz2eOXSxdrHw5SWGpMdBdpfsA3DQJBfplVnqnEc3T2o85l0c5nZmdMo
cIgBUuU6RNm2oHQSW3+cTeCrYutlWUv6R5NZ7bZR+ZAN+0p4ICs3JYqqhqGofXRqAd9rX4SJC0E5
kdzTL/brwCDZa+K8l1RI/WR5fQADqNQ9W6NUvqOh1T4LQtDT4nND1Us5rgUh57KBa/T+zKKNXAFX
8DFG+PxDvCIF3k0VB2EmWzeEOMrpzE7DLyiZHu/FpEp+KpkLZXMB49yjFQ1MAejmMBzb56ent186
HaAQn82C87DGINS/csQW8aOf9RzQQdOlZq+/LJi+NIIU9jKtGEd7pL3r8n6Ypx/NRJ6mmq8+8zGg
1x++u5Wkb7mHnaCJyidb6Gjtbt17akhlnyULk1qdYLYKi0mC/wkNXwpuG+LI1kMWEFccD40p6H+A
yVaTfkTpd+FacAEa2YlvXxd8aQGLGabaE95dEHVZlqVJxnY8nV8PBngQYgbQHozais7xeBP8/iS7
J9OvuCdMb+dpuzxp9is16bJB6WXpkBVXup0NbEFdztVv1iAYzc2EHsWLSBBMPIatLqY+G7O/X/U0
zs87FzERNVzpwO9m9IFWW4egjWSfIA98+ufWkE+HCkxTwxjzVqr9fBSgdQil5BL2DWk8mqdthtcI
feZvZK264V612M+yu2oxhtoliCBNW/OrlmTEQxYiUzjzD3Fka5lV5y8g7ktFnciVHz/G5M2ZfhUU
iniIscQlmlz5/WCTQaNCnX+zNlvZGiUjfnlltmWWiz8Oh4arTN4vQvabxv6IE6NZzLcEaOawq25G
5btQCrYSc/4tBBtxCTOF58luANPhaY2v1bdbPqeiX5NNZZU9KyYn35EcUE/g/PLjjtEr3MWxQpLb
IuIQiIDMcCvmYfe3a1bm6nduaIhAG9VeG7VS6a2lH3cSwSBnhSIu25wM92+n734Z8JDXXonEXUiL
rEBXqq68SAQDEuuZMy8pfrYubBCbFuVKHsg81XSKc4+3ihpWIeF+H9aFhWjjP/sMrT2dBNEy1o1w
6F57sNq7rVmdW8iaebTUUBkVAgXjo198U+f/aDCur+dV1Epw/puEn/zVBn4YITiKwjcZrGC2Ohzm
dLnoMAcL0Wq/wDni45t08v95XqeGN8Z0jBAuUduQwUokOXIXynZddKZ5Vv4Fy3xCP5K6kOB5M5Dl
lXJlDv70MRVS5tNsSNhUftmRfwd6ERwvvAech8Gq28+vWYf0IQZimVpt0wFFNa1UdSwBb3khwMZf
a34A1uo/T89tURAAeXCepbhEGnhN8QFg8p9kWZtgtfh+h32Cp5RN5NZiVsrpxvFKYa0gdl/XY9FN
KmPXtL3xPO9l3SCCG0hkk3GJBI8g9dkmKA42BG==