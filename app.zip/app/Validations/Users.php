<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpUo1vDaBVoaSN6Ii8RihYjhAr20cZiZuj0cqlCaioSInfeZJezAix0ULsRYNPRPvucNJSHW
J9Mx4ykQ2zHkMQ3rC1GavL7Csg8UmZPubpBBLvhLVfc7nr7HtIy5DvTUd7PU3zt/3Gqp7Pk8CIjk
Goz9l8XWakhT0Hz8IpQBCOEwvq8U4scbvx3kYHc47YFE7SxIJcJuMTNDe/7TK43A54as7k5HP262
+SlblnJB32CedoDSeDtmbLccGf8rUfdJIuhVEgDoe6AR6gDy+lCcHhyVEzca9sSGfQ3a+o+6rSVN
DFPydnKoDrlz1/Dq4TKEhTKDSvu9Bj5Ic3+vpGRB+zP4no+C7ObwEa6rBOtblNU4q+w8vYgPUl6L
RYqGTnQBw78DBKScnIMoIF4KVergR1CUBvvhdv23d40UPWrC4erNdWCsZ4GLfwYOdkJvrmhtTOQJ
jko1Jx9guNvmhmmMuEvPlgtAJyBlNWL0Sck7vs0xvm/N2pXclnyJp1b2NWuMJ3T5/e+Ao06OhhT1
hCpikFITECVeBMoBbIgF8TAPIgcgiZLJYcwxfTJuh8KkSwGpKNXMUg47rPQlguAh4wBM7Ka7cjSa
puYn/v528yA8vE98my23jR/hD5qukpcyL1etKJ2tFTFTGLt3yBAjvfum5VyfIYEaxQ9Dk9KeW3Nj
UcrHKb3oaT8sO0vJNTvC/okBc2+ZfqA1iQ28r73/XwoHuIKrnk1C9yrPGrH7CzKbRGo+GjQEyuSR
wvtMX+qw+2fuZ7R6x9xcGbsSmXZkJHk8oJFb3LjKjTAZ8yieqtmxHdHyBH7KlQcrIJXVIsJGK+ah
Nz/8Le3h6AISpkmHxusvqvJFwGM9WOdSp31dTxKr1h3mgMb8k3KTbwZyLmx/vk6Htd59UXxxtEyf
pjkhOwkqzrXY73zWzbPrGmWHDZTpm/v6EM8nr6EGEPMbt4dTWYVKVbRazPzcUIULgYS8tvaBd97w
XNTkplhLVE/nbmNJK8jN/yhvyn2zqL60+bSeYUl+vW98vhLFnoPwjrwjDAIz96LMqmSLTOOQRCAG
E6siNY7eko8GKS+QbxbKFlmTyDTY5AwJf+yZfZvFS1qNJuT0pMXhYcbGdkTtkT2Vpvr+XfJJlZ7F
sK9hg/7vp19zRRJ7P78os6pXhIrx7gYAVJWaCO/2gz9eFOni7h/y6ilehewq2+Pa4ecY0wfOcStR
iMJGZ1jC3YH7tyx98cmw4I34gjRGiiC60MzL8EgmFeRtU2ZcwJPCMjmJoJXMcwZAq6iqM7VQpP3G
Pe2wy1cdjBTF+r9z8vcMjZd8/+C6q6QoC5qX/lSqjC/2KCnWHNOOpqqePb7/Twzi4ZRuw8YxqSDY
FbpYnTlg903uD8DhR3kQdrVDnLL1IYFlSz2eKOt2PbT+an+pVDV3KqA1hDrBDQa41HKgGD8nCtFT
d9/SWHzshJc2IWOem8oSLVakr5+c7mmHnQ9F2BVwiGwyuvX8nWRp4LSB8KSxZO5M6SRBs4CWfV1K
fFZS9lh6SgL5B1wk5wi40lPvg1QkfVf1r1lwUT5I3HjYweDgzQhUVROI39MhMYHBzeV5u+hg2aH8
KJ6WlHbHc+y/t7rHiQY5YMByjbEWGijNQeWh62T4pU52Iw1DYm+LpKRq+CPxQuKVogenx0BM5D0G
c/Lor6jra7bH+UXwmjZ8HZ/DLmRZQ47nVV13br9iOJVogDIFZLtQQWnhl2M87I+YLv6ZYmeCQFgW
tbPO1fDhUDL1CZ1644LNiNAmlbX6nyE6mt2/hBnvN2//AcdOcn1OZ94pYjHca0stOOMX+W0hO0iG
NiFY+0fAQ5S5FYQqlJh0hB7e17FzV1eEHgCnRlrr8i57st4U4apknQbuoBs87onblV65UskAjeSd
SoQosD6oECMkUWBuS44m/4Vl7NP5HKMSrS6Smi9VYb7Bn3qs9GkVlHG40y2PDzfn1Lw+k5ueJOfB
g0ccDU/SNqwXKMt1AhQRLliL8sjfJ8c2imdVrJRoMku93H/VLcSu7pCs1dwS2CKr2FgpxzHRRdvh
k3QEwP8=