<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoj5fBA96ns5L8OnaKK+y/lMZWG3soNHsVjmR0r56QHmQ9YXAGOonM5HUmgXjmhhbgiaj7zC
UIVHCBwkHgyKbILx0yPH53qEqKPMwDP5ayOY2so2HdoWSOnjO52jGgzHVMoqSVQxeCtgVTAzRsq/
FLVo0jim2hrS7EFVtC3bq0+X0lU0BQz6PymjTvb7OJaAEA2TlwWtW4wyNapeuwWjBkLuJ8ro28Qs
AAT2SF9TkxVia9FI/ivOSIzZaUwm0v8ADtRXnE7UZjZMzb/+NHsfPTbDxu5sQ0/dnm9sDUySoP/v
sDRLMl+JPlSgoc80fLHXMfupnqrZXR1JGND2aDH9t3V2txR6RoTH3g7x6w9jHjjsRCwOGY46UZ0o
Xs0vcxCwcqc0s246JCjDXKR9zf8u3dwS0FClw4xQ3eRzbEkjdAq+kWbvyeW1YDie8DS/Z53cVRxY
nBz8YGHpsLmxNekfxR4Dfap/1DqYPfWM0rE7IGpZ8qWWvt3z8WSeI/7e2Nbl/Y4TkWzgq862yxsm
0T1knevFVTCQW9rkJ/+lifbJ/A+GNpBN3m7FQiW0lVCPOQrGsptojXiHxnSW6TbvwjsuKhImNvLS
ufOnYg5tE01B6hHJSRAaRlv25amzGTB+1ub3gy0VKaWOcfgeNrFbQYSsajeSHHioIVhPjn3vOZOs
T02gFhUNWc+ys+DFj1MgYUz5djZAhu2iIlh5jZhjLZ7cryNydsFGvdOcYUMoJ+lcifzTRSI+Rqud
ebY8JqzvsekNbdAFOXWzIiE5+d9pzGMUdYsgKke0I8JE/BJMoD+OD5o4N7ZL9ZWZI6ZPxPLwpLik
nq3B5yVN210DFRxxObPivgkOb7etO7X9TayphkhNRV4qkfQuqu40LhF+GuqtGLJLQlUFGuJ08s36
yXvnwqcPJcOWy6NJIalgPTi2ZvgJB2o7LN52t+y9ICysO+Ybr9vO/h6WKaovGC6D7z/V+cbxLM/V
q6A6Bn63ni3sM17/0mIZC5EIitpPeRw2goKNiHksM02xQQ2+nwnoaLeDCYWFEQTnK52jYV8q2lkz
o7YmjL/mE9EbVRIwIOM5FYCx5Eq/kUKX8hu3ZT1JhqLBHc9jDF/GCLPtr71B8pL2KAPu8apN8Vzj
19QKbLdIZ02glXMFJYe1xfJf0Ek26Gzrd4Hv07wR1kodBOU/Q17Ak86r8SfJT8xkmFPcbu6D02yi
HpLOasV8gcT8by4C/QWe0NQlW+jGXRisjorjUll8MueI2/yJkIxaPNs3ixYbkWOhhaVk9sx6dX2E
eqpj8zQICpd6tBu9ss6ISkpGlPQSciLIJIn6nc/0gXH3LI+mEsNL3Jiuef326Abltovw6oODkdJi
nw3Wuxm0x5Hybd9F6eiWTa++khJuwkkcLxm0qV8F+ZUMdPgVB/y5r33pOpO119QtQy9+Zsi9eRMf
gL6okoWCGdz+eRXnLt/6bPimiHGtNE/kvvBAxwH46EXOP/gkbIrw5mCd7bxiYP5J0P5ApQ2uyljy
IBo+P4USfkKE3k1KHASWPw8Yx/RKqw1PshawdkH3Zo3XNXrFD6uMQaU5iz6QAU84DycJoYsbpEnr
WhjchSHJSa8V8ZHUTAd01LuvSa6ix8kKnFljoNhPjrz4jHXUJCDbLu1xzfkCSSkkoW+2NZMrBDc5
RsrZ+3V3SM0HJJkEIqWCKmKn47SxEDTb3lsn0mP+y3xUVbMljo7y0zz20CGAZjZgGQVzbiF2oDTq
+Lh2L/rC0fNqkOLJ9CrI6CkricOrV2iO1MKiuZSE5y8lNbwPz1zRFTWGrgKtTbZG4Mo3KFx91B5V
tvKHJzVVrecqIAsJTQLPd9TDay0nWB90aV9FY841Zi0dL75l2NarIc7QS93h9ZE1XlMkFqgOQt2i
9DPolJaJx9XbVuBZUcrjecp9p7t80jD9swwhr6mhEkMawYTDkn2rSoCDv+PP16CgBbPNQr12yiVq
C4Bo8uqBtEG8327F9w8iGFYeqmOxPaAori6QI+1kH2SUgkM6e7S9vWYdEFUY1RpnIn3zdG5lPaoA
DZRDEBkUk07keVI93aG=