<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpNMx2HXYTKBV1Lv1mf60Y7kpf7FOPwSgTC1hVrD/dCKvf2evn3+8G7QQCizfJeXoP4ETO0O
0D0ZQuqtO3WlzQsddApcrQyl1o3aLcmRRHZbO938hzWhmiZz+VYUpbNE57w68Hm8ZPHxBmtg9+Bd
DqGewUkiaOFlvLzMjYu2V12RaU5dXjtP6hVYSt7bQJqbOnstuRP0AhLUGrCbdwoNWh/CWpQvW57u
Jy8pvXUNs4ItkNu8k0DzipPjRUAyMnzjzkP3REGEyh6F55dCubCN2OI5/+0cyWDhbU8lklfZWd89
K4LtvN9bLcQURrfIorr4ZQb4MaW1l1pFJ2nZgUyQWviYRnNF8ExtZwvdIfSlwncA42CAL2HL+4z3
3e3vl5JjIhJWXSb/+W5H7URh49i9OHGA3N6QmkXLjn/9pQW4XVmAg64D8XN3Udmje8EjL1Mhoq3f
Kb9l/76wWlHRho0TBs2JCLdPGu2Sd28UtjE47xZQar7qiTMKTWELJ+eTO7ClM+5L2Jh5HNyS/9mr
Uoyg3QroNNrSaPtqtLxPco56UpSZkeXbrt10e9NZWvX8cyXU8J1WK8I/OGBKjPwt9XLy5/KR66lF
eqS5rACdyIkZKZTl9M1fg1YDb/R9PEnk5brw6dP9g0iQ99tE8518VkMAKEsKKCmOxWVsvK6ZC4s4
GpR1AIfK2LRnhNjAgUvHopHvpRTftsyZg725Gylu4ogVvZHjxarrTCY44/ApDsKQ/c0thCMZa2HL
jdNgtfRcJE/JCJkUToGxhwmNFWk3KZHV/j9deXQT+mHqgOGvS5FKu813RBh2wvU+wZxo/+aIJ+gO
n+EDAymtFHeJkZV0suHZGuyFlj98BYyi5L/BMD2AbwapLwn84smHjnZGJcJvN0s1hbyLlA57/Owq
VyG865l7BDTVapdL7N+6w56ANal+I+fDEpaLVE5SHCexBY9I/gE8Bo7a0UaN1Cofh+HZgtjWImTc
rH0KEhNu2minGfCrPVzXCKF8AjsP69zqREBwN2Q+uO11LgdLv7U3sOpl9HStQjJmcqaTsVK5bN2N
kEXznfuKNpbCVTOwkFV2plytbsX0tIxjXwlxl7iQIN/LolRsBykuroSi3boMYWfNq5cYFLPqfzkt
4JRY84hlnBGEs85/iO5kkmhYNDc6SDX8uPEN2W7AO2xiJxddLhv0h3kmTRZutZ0swgl84BI4F+0c
hjHuRorI7kudqfsO1ejaTQFO5jlPLa+nqh7aK5ATDA7vy8KHEza65gv4qmjfAwuAJkYLixoN5dnq
sLRjuKnKkb2ja/lzXT8bTTeqEGKFXI5KcwkQm3vGgkiRNFePDPNdhT0iFlh63CpPPsyu7F9goG4a
QDMkJhtxWr90xwNRv99ocHIVmS2Y+URTRaB4+s11M4WJCHxxcKh6wguTVmeesUUJZFLzmA7mfV0V
vvWb3anE6e2wl7R/1FL1DSTd+oriIcCTiD9vP5NKSm4GiB/Vsb6lnxn2mxN7nvfeM5IEOwawZl28
zFqJfb3dL/LsUvLvGIf1QIgf+5Lj8ZNb2ZCfhtZQ6/XlDLSB1c2MsTPA2dZC96etpbMFFWvbuSzD
l17Xa70UPLpziwqKWeZcDtMLN49Z43t3XMOoLQADmlGHy28ucgkBGpQvN2y5NR/TJUGTqs6/6Ks9
kBa++wl/cl6kdC0hYBLdSp/j+2mr+i50vk8U9gixi5uET08lYgL9mdAxv1ut79KzX+hO5/e2X1/Y
bpFNEcZZWi9WaTDogeIngcpqlpadG+w/Lc7+JJiu1yAKwAO4ByDyI/OkXq9GSJkSU3hvF+2hrU2H
GaQ9cZPCVfVj37e7OeUj/klnE2ZerKc0VB8ZURgaE/1eoYxlyUS0DX7tgxRaKjycuBNJ4qhGzcoR
mE/ifgYPucJbCnydiecZsxc1C1PYMlG1eCa+70rANP/ZJrEMIU0PkvUxylyowI3kNbLqXRKOBUhP
8oTIpv61fm5Qw0cDVcKLAqNnqLqRaNC1LaLXd/Su4RqGXka5NJKJR81O/T1n+XYp5GQHVmrEwQ6o
LeR01W==