<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqXSjHmgymrJCvyWFyLLKe1kPAgpuIAP9xYuniIOpjBzFeGuA/w35zbz5L1FkL1YE+25xaMC
pDT8j7x+cObNY3z+dEufjQe1Vdvbu19tRi14Ib+5hIHvrX4PSkSu8hEActclWFheACWMOq86YgR8
xyX4Cca1LhW/xx1jcSfb9GOe2brClJMbsz0GfGV20lV6HLAIKkhHVLgus8lucV9mHfPxPOSVpFhl
aSiYGfuNAFNKupRFCDgP7kQnCVDwhSkK8PP84No6JafnWqg7SusbEtg054nePS5WQ3c0e9dQPaLY
fz1Rc5CLojHBo2o3q2zK2TFNnYrBeqSfmnS7joSavOL0LRy9kom+rYq8zfPQApqPe/+JQISI/XpD
SC1FNoBG6m5C1Ku/prODFzt8l063wfWYKEVLryHulWiTIgYPFwKdXDc9HAqxTkC/pucMW98lDJRt
+WHgcyXjViLXmk6BD7bM4+eTqMbsTqebmBY730fxRXVjYIvrqQGlG95Qc+z72soI+DFx83XNCf66
XrKeMfTPTEANZDaQOCF4reCQGaFJVnYdJkczOQjd5X8aOesRji9eQHW/NIZF/Q4wo47/b25IZ1ec
uDyDYiyc3z4LPIm2tcvXuenQQrMxwfG3z2Phe9zqjLbCe60fWr7/kx/6k/yI2i4hvZFGP+EVlLZ1
/sh8ABYNpY33SHMLRkzi+Z4FaF3kzwNFNZHVAT4t2/npPeJ8tR8LKTj+hgUrguqmghPzbpDPnsYS
ylR2PSzw/uEt4A1jj2wV1F2IV6EFt+a/R91N6S/yDlKjWtxwgmWt9eO6mABvLx2pzQgBqRWRuQEi
oF1GQJv+iLlaffU/g2HzaJhL6kRLLR4nEFIvPTNf0ksp4mVt7fWDGRvxamj51moaZm2HJt5dY3G6
3f55pu26876rtuVCicAj734/a+J2Y7SOgzwG6eSLtzZ+qsbm1Bu9Z/Ik+7W6NYXfZT/Jo2Y2cM0V
ZJXsmKjyGYyJ1NVwuT0NaC53AyqEHRXfhJS2Q3aDcHCgxkUUbW/W7gR7jIhYHlyCUkPkagqrFu5q
2zj3uZzj5aRwbeDxFY9+4Z39xxK/YGB8bx7s2HyYAC94vLLkqEnry9bQ3nNJbgLqlkTPhHD17SwL
dYrO2vEj2LhpwC+OsqhlD8NRB3N2rFZ1HcQTIguC5QLPR+Ssj4iwtyb2zR/rQM4KwghBR6h0Cir1
6HnpMvVhdbs1nlkwh3R3EOolC56zkqr1Qqv0DAd2+sCZ0Exkw0IlsZc4zSEwORXcBKM5evbpQB9o
5M8FsX505jc3kLSHn+GkmRBRwuWmdiib56r2sJk0anqueVZHh+keVfggmIWIEVC1V8n2JmdB2ZxA
c2NJ+osponJNkItPrdG+DY23npCr+krd6sVvZWiIoKyqn4M1qAS26cDKvOs4+99DAPI2ijClhGjS
Vi/+dfvVRThV1guTD05D8osLphbl5jPBCKpa83MJ7gYmjQfli0u8wbnUDa3BZtBHEQhZblJNezK+
6ohxXlso/V/FmKfNueKlSXXL3BN3JO1svVXtSGgtVHbndtS2bw+emXkiNNIu/n+tJ9SPo1cT6GBQ
i2KEJM8axSaBM2gEk6bmnQpYDIerhFRXYBbSYSClCCmRwVNOfl1ZxSg7Ce0SAZ1DVDR4BNGIBmsX
RtXGSZUzPkCjIBeTAL0bJ5Uz6/TqDpvasUt5AhthU4bolz95LhT0+QmSotq2S00rTb/G8nGiEnx0
n1JI4ToLSwdY1FUP9ZbJdAxZyJK5lfdQUVRJZyocpYttOzuexnVGbgYxt2vPq++6oHcZJlOvzLuX
4WgzdXNl+yUdqfxvAPeY+a5fBFEhfLzTOOvQQfxvwyiWbwvCIio4c8UjxzuOv87RWgPEbtakz3aR
1JU8eTfyC+sHRcGUxYSb1zkS2xvMBqRC8p3l5hv2SaSz0JlugzIHEYhxZc1SlKCz8eCuwbyhAu9F
O3NxeXDKUaxQy6c3kAOfRPhbi2//w5nxNrmNkEBMU+OnKf3SQUZ7C7jvrTKRXf4xpnXcQUQdLmcS
r2yQRZujWUcN/cy1nxQIZsqE