<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPskDsPv7G2BH7avClVb5rDblTb9yRUXZJFjLJjOYnTAgYkL3LjROaHBnMLKWrgbfdj9gnnVF
dSyfmtIX9+nvZcGwikmJllMZV8iIdKojPVTd4qr2Qlf02SnQ/uo57aTR7wXDxRuTriCTP9q70iYd
mgTYgcAPHTbq9tYkhrUoR5et3sRwXvg1+Ao8SCQFfrh3q8kDwuwEB7RNnoWhEQ9bi7Kv1OpIWSZ8
DMyOP4AVUIX391gmynicsyxwWFMEYXbx5+e2FNOKAnTu21puFx0CpmxcZiizQMy7J1NF6bM1Pkdy
OMjSMoiBzMurdb7hyXVSTYSMe7GP5CeVJlFSIprX+vWR5XWKipBB2Da43gMAVExFcnDyf9YdcDR5
VjS3uxWFgV3joNdbkHj5AJi1IWHZW6WZYbOJaL4BnrbdE6hs7sCJrfD7DTVkKviRCQTrlhcR1BZo
f1dNfro3NkEiW57G4B13eOG0tRjJvP+tzZH5A77g55BRlfbvGQR5aGz7dsRK9YRkV6KquwhKv3HV
dhM2CQifdvdeH++uIofsUUW/OMhsQ5KI1XWu9CMoRjJcG+zRygVbhiq0rzIOd7X5BWGmLIfNvp1t
70Goe6++g6R6Zf+ZmXLYrsjzv+ObunZnZJ0JsR8sMGr/f3yHsjGz1HD6VbSOdL1+ra9kFT3PYewC
ApjgCyePky1cpnCzBccDmzijaBi+4Sn15fpXv3936Eo9ccd5/m+uVhrrceYPuI5jNNCzQWtbconS
xK8jKHEii03DNVbRT0VLOR4gv2Gbc6pmeFnSrk54YXN6rrT0gsA2H+7t2fTatL4otarinfIozCzf
NgyiXp9GyN5XtNs9PIkTZGNbmKvt0nsU9dtuUfjEUVhhcB/aQeut8FMz4WW29WD0O3JFzWOd72sH
8gKeAmCb21wfC2bRL2Ed9808OKOUxTsmH4qNXS+goUIjbtcUbJiY/qqazZ/fkAJHsmKr1N3rCFRU
3k2+3dgJM4CRw1/vTc0Y50sJHLu+ZjHAivgUpSy2vzufbfIVmJ9U30d+Angc3GFgrCaQqV0RUPzT
WKjoyX6Tfh8+dgHBDLiWGBMXNKhl9/O7SzQN8W/568doRr9YtwMD+bI85TdOO5Dtb07L6k3f2azc
z23zRU5CORbrHckAD0ARuPGVZ9ZeYQ4M6peZqcN9SdRai0DEOEz0WjU5IJ2OyHrWqfh/ZQLcQ+vn
ubybswwj6GcPktf3x9+FLP+u+McEiE1ShLpDtDTxSJMryuaF4y/TvrFKR6R2sVjAO8OBTr/QBLRQ
I/Tc1gIfJA4YRVDtnWBgFewN531w1yENGDiQgj9HHLK6d26ieJRnzZL8ox6cpZjc2MgvEhip5xHX
kvOkItaz08GMPMEf6dc8ijIiRRAwq08Om5hN/tWZZu0LuDmxkQFI/zkA7hEF94j2/Alu+IttSV3o
k3t2ReM+mBmg4neKDwg/LETPUGEipAAk/Ep3YUwn+RDv/d3O+JjOr1UKYMal0q7MDe+dG92dD+rZ
UyZm7OwIZt13IZ4nq+NGwnXiRDj4vPcQkm6gw2ICXbxn2wc6rRhuBV1ZaBHhvDx0gh2ijWhiTQxi
/kckIvy8VeEkTr6XSCvOVgPL+pNTzBH1qOZJHt4zP5u8Ga5t99RzeRHfisg7tSADGlh33JTN62lV
Z7VPD0wG5U/j/cpv6NpjQS29z2LbuYudzy5x0YhscreUKnNopHhXIrCNrCUUsvaHpStIqz6LJjv2
qIgyVYWdUPVQeNzPGdTQfqIkWIKh1uo6jGjSWI0VNzQyga3bCPVyuQufTLN3jGomGAZwXXKeSFWw
K711dl1JgBCSqaV3+P3cIxDK806sChDklnQg0NC79qYHRef6xTralsCcmfwXCjZ0G4cKIsEAefm7
YlD72+8Sy7kUrlgiWft36N6k6YX4se6cGzZhFPB/tkgtVc/eNkwKQ9kRLF4d/jfbDqP1JnGewuvh
AzWa6k6LVAQAjsQ5acszmcUGGJgR5n+8YKSIg+jdrpIT0Sy61i/P72k4WalbmsdfpxOnw/xMYGVf
fogg4JGDhEH8rjMiI0T9DbsERx0vbZQ6