<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxumkyqqhn/YmVCkxc0tfV6AzGsBoKtB+wMulODpIipnNZqTPUF6TIQSWXxA6hZ+8ZDbv7Mn
/TV0b1Vw+1wCz2Mjn+zbpRyi5BS7vJuT0JBjnJVBevrz7V7g4wq1iIrjr+JFB7zzb08ItwVTqJSd
yq9Dj4RPdgRmDuxvVF3THMZxL+V+oigQOUp022oXtz/oHaPyO+32J4qwk0c35ZFq8R5RlsqgMk+c
Yg4eI9MFl9k6z9Ok5y1WQ4ouNL2t3vAUWKJWscOEfIpv+5PatZdjxX50asrnjBE1JVxTJwnzBQIH
jrjN/yFQmqvALZb/2e2wsbh8pXJ0C9NKvifhcnHSrhHYDCI02d35zoCDmiR/6719s12DFgzd2kG6
2I8Yy2vbWoX7Bj4+oAZih8fShlnsjOiw6JLbp3SmbZ1TziT7R7mIxsAx+xZ8/ux3P3vPOV8Edu/X
LluY6G69rCfk9QqwnQpSEiMRqcUTqvh3LC7azbhB+g69dObiUZjaohgckUr7Ha2K4l/3yMB5otuC
ZwrVC0gzPGdRFUMxJYEtmeNLU6hNO8qeklfwhKFE+9VmbWLQef74T9sFk2gzorHjw/2CUq73hcAm
Q9HSIjpcD9iYPOO8wD+At9diJHrpVhC7DcMpl0EtkLXlROGw25lhCAlkIWkZUCpCQavIVFOfzzuV
/s3Cfm/lhFF/gndtm8uQWSbnln1da2/vX4tUS68rsa2akg29HFyTr5M1RNsCw8MASXGtbPo/GT3E
EWOBdWBr8fFnEL546EmoSIAz1dWd5xWECt+wAeOrc6m16nSjoVmnqLOSaLLVVyifjhHjorNr9TeH
HhwoeO4QGqLoleKjxKWEeTSaJRuJMGcOftVoIdOhGycFTdn/P9+Li5dFUwTmMoALaJeIyYXyJafy
QiyU4Z4lEaNgNr0OrOqr6C0SEsg3Fs0OoLMXGsP78F72j85mxYcUMs1gDZkC3cmJWBeO59sF8HFx
y0USJ8ZbrCfRBfzGUTdSCM7kMH8v8/XxUjUlsj8KlWyxev1BUHbeBhO2jGyqVALMutYLDfKYepV1
hGF9JY4h87s8pbAxCIrts002XDZSiNvFaSA+xHMwolTeEJIYbo2WaqWSQIMCS/zUvOlXOYpy0Z1U
aNOhGFjFkEN5TSALd3auxfkKPYf221xmsGlMaB2loZ3wGFbndZtyCV58mhmKrWCSb4yvhBtxOtId
kz4wgSttZ1vxQH2BDmPJ9Y0oY0jh3P0A5IrzlMtpZFFAWrDM90EjN9DghXkH8LyTfJ1wGa98E9r8
3F7ZHO0pNUFLzVcdy0brlz2+vQzHzAV9yjr1Hnu8q6TMXxRpjncbmT+6QNS8g4e0Z5Vmn7Ke/uNd
MF7wZl2dEbhcPbJhgbTShVAvzTEDAsGI/Z2ZhmPO90cOZeIMfn++J9lFBY/uRn77etO7gUWf9euk
XEqpqGHF4vISbJexksclBuOAlH3hSR8EpCkQWxZgXDUCwP0mmKef2sc3+1DZGcCBRIreXTox3hVS
kOC0Ao9jiib8okf2Br6ITIu9ZtNYcO17aoLDlo26LwJvEOvgo/HdWULCbkqjZX/IhwGf/cTvR5SJ
H2HKA9POq1y0RwHdNpggfa5OaSwFERTgOWuXzepcFeXF7IrdK4hoHy04N+KJz0PltsaEY9gReyW2
KoMr7jXvzn53T+s2u/clUfBqb7BcEu4IwLR/9IxVq4xQ0oXG9ILNnXbcm37HRbhNwEkcnTvtJyTL
4e58ByyGhxMpD0o5M4aG6XL6jyW+VCi8Cufxe1h6S7WDBlNwE2s6OD1xgrIpzGoWMmlta+7BWxc4
yhVmJ+Wa3rU7xxpU1VlCGkIDbEZYS0BdHv+1rU/WdLEQtKUpRAliY8GuuSuey8TAdzWrBtIYl5aj
giVlUZItRU/erxQS8j4jANlIQiRpGee3fjoN0zkXNfKgRWgAkgx4x9VjtYmtbEmB1GgplfjfJgeT
JLhdMbu90KtLa3JKTcLx955tAKYqWBb6JghJPB7JHFbz9IpwAGy4ERqV11k01HTne2CbgXEn2Gfv
C+uIXSKHyDRnlGA8Sna=