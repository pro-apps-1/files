<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw+hw2m0Ej43tMXz3uHpJSyHNzxWCmPV9PUunGPnnDyk4ol8vyQK+bPTqY3b3x/zkQ+6qbvU
pb38HtxbmdteESrFmyPoLhM1GHUY7SPodad0/ZKHz+UY/y1d6oIhsH8FlHr5Qz902N8nVO6mRI3d
1sM81VXxYE3/3BrFwkwdkIiFkjD/eDyCzwhaPy95o/lrtAR8dHdaauA3rcM+q7lch1xyimFX+PWb
SjDiL8hQh860sgaN5Y7vrf2+sMKKxRzQKoh7IdpduDuQEICruOA6s+HRjLHnKLaamhOu/vJWvi6j
nhrw7/rqVDs6i9XoSJ8sY7EVSqMai9vWBXanx/WQG6ZGk6YQQLdVUHruuozLla3jPYMwXcErFgui
/839kptdf94wd8w7juy9FPsEIkZaVxyhSpb8nCO7zoxjmZcjwKfyDpSakoZhpiMiT+9OHrInxRBO
6DpfdVXvwFgpOq22OQR6nEYS6qCDfCDsO/hN1lwuV9IbydiGVZNcGT4ebiaElQJAHAibJUfCdivw
HKW1jt3mN8xNZw9dXfyYLVeO5enuv490MCzpmbG03ZhT1O4Xh3MXJgtvz4Eq+0umtpLHm0uwwMmw
6T4zsEdZwLd6/qJ2rH7FrGwqmcRkE8RkM6K8BatObwq67Z/u6oZtd9KV8ctXP42GEcfVwoRLGZy3
TEKE0XY6DCYFYmAu85HC4IsEXv3oXFi9B/XLY9z+lmNjRbaBypinCdEh/4Lc0UVGW48DNkB1+EMO
+Cue4dmuBwV5pCtrQdx3615wi/bMjZ1IL/cR0e1PB/RRrbRci+VMk77gYAi+T6xnPOHyMNaW/+tw
tEGDz+Lt1DadpfgrIxr/2LOem8Y2WfpIvEULmolWqmAggyT+2RTwu9OwRMETNA5C4yxydwKQ1rfJ
2l12uCIysPeFfU2KYShyljoDWe1xBjZGCtlKFYVonC1nhGts5RUtbIoJuL4mV0VJk6ZGWTjFIc2V
w206adXhOieTAD59PAgMZ/k1JEwWMfg1UdKbwVGj+XHC/uISGAwAVXo/WBkx7EJm7I4TQLUh2097
2T51Zhm09+3GgLQc/ANMKs75Hi2xqoQ5GdZrmc+iXglGC0ks7TWS/lH6yYxK1as7KCk4n29TzOUq
k9jcQ5cOfNAiF+JZMr8+k0Noj52+WB3a5mb2Afxe9stwKLgJXF4k4YQCVr8ZzAZ25Mn4kjTjIith
z8X2fTaiI/uNVVOVACEMKUs8sFjLokcGXfRj0PYcOwfIyUIiHinjAZ+thtqhO1LyquYEEGrSBnsA
8Ws7T9PwL8XycOqJ7r2QW5Z0Zme50rhfhlqj9iqPAHfsOap7CA/hAJ0jx5fEBnt39P5rKanA3jdx
3ZQuNhcCHnJHBDdECCqjrt5IAWBk3Bdl8+eZIM09VJTenI3HZl8Cf4KnXbLAkVt81505aUFon9xM
tmTSLv3K5GHe1l09n2IsPFHh9rtEgAwFQCv211NvddNR9DBmqBbyuLrFabASW9UlI+4V2RBzoUji
oLL4+AL+9NwjT1+VZ6X7ddwFU+qzPbe3Rd/KAUpzhwxEYoRmZ/enNz/q+8tUebCY6fFGXpNOhML9
1udFyqUTbVQEnR5CnA0CHUPZiIwuRX9z9kGsDyz66bUkZ8rf3gceJfXF4mNO7GqzQ+kCYMCG6pXR
fATSxupuZIn067hHhWmAIDM0gT87ZNbfZsuP3oSVj6eMNbGet80XpmRbJGvC3sAJta9yi8v9HI54
hQGz5fiSE1uByWufnfLTF/tDoxfzYBWZiEhNwECSN12550l3nXvgFJQgRG5eLMB2N+p6pcwhcDrl
4MS0X+dQ2eg5QWk6VqqJGWDfsItdKbUWQ93GXzXlS7S9q7WpVoHH8dhAb3VfGNl6QnDz2nlIULqd
MamNLmLVbjXGtRjCTkl6pYgCIiQEMkGq8h2MJBcYUxczNKIur5IfR/8pn+556ZZNX21LRVwXiEVV
tHRiPhKfK5Ud0wfszYhRowAtbXZVOlppBPw+W+ZnR5X1a6o81T18ddHmbU0TE/7MfgaRU0Cd5qfk
Smu6OW/dx/IHQnRhNHLUb6Ftbvox59U9QG==