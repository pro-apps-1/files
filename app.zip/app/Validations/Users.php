<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpP/kzPbrXyPSBmkzTHNEHiYqqTDdPrDI8Quw2wdOq9Zhdw4cuSnzUrk9pUlp/Kgob6/ym5f
KvcgbQqaD3QfAmbAtiP0sBXkmMlVUe9FYOnJy8F0EflfoIVIAjZUbcrWavmxEzvJbGwwLMeKi15z
krWGLadGPNFCstJIV4lS1SvnfDVPQrEkLyNhWRcJ4nyXVIxleWXGg8bKfd6nnfwNE5h1uJ6MJ88S
yk2camO8Q5TcslhoUVUbCY9ojv1PMiK2nvnSbe2r2DXL8GlSdw9cbuGu5JjfutraZYzi7hp3zSiJ
RNXg4OMzo33s0RXx4PXE0G4z8s6jYaXy7pR9G7cqBiQZv9vsG31BgwT+Jocpw6phb/o9i992wSMS
E5gxB0X3RCmmfnUbHk9nBwJuZkr65x7uccPxxmwldzWshtuSXwOdYiRUo8oKXBuebs0Yc8UKiHsU
ET7qFItI1t1yHwRMYfL4KJDD9oO8kB3xY4DU5wnwkWVx9OmDvUvSH802PngqSoiG4Q6DEko1uoVh
cQBhHnDyPcJSq4NPaWif7zJUodDXeJFo7LQ3RGsa/C5xEzD9Uhq+omdS/L5Oi1X+OAaR34Z4Yvdu
YYiVsVqartG667UDAdLuD0EkWPhZOH4M6rVS70+WRPWvKaoyjvrEN1fUBR1bxBupvW6kmLtoj5Gi
2hosmzvCtK8vPuGQ0Tn1cs0PgfkcgBArulWwrdxg3yjghtbMMhLg5jbdc8CKO2KbR7vG0k16Cqz7
wktSeVpME/vEqDY/jgHE366jUaLJgPfqSaxP1cEfwU4nKblBqrIHovT5hC/XuCfk4+SZamNNOJs7
EjGcrBTzLlKmHVPWQo55ltgjbNAB8YuBh7GJRdyoL4vgZgYlb31P61uxY7Ib5j+Ib1XHxtp4Fef8
UrwdoaSO3triLpNr6b2SFyAJ/N9Pj0DlwyCfdm7iSr74Xu5YH2fg2A3GbtzNHm33uEUo7Yo9a+p+
Vnk6gcIBCFEf/tNVMlggzACnLi0TVz2UbMYQa7qAJjfqBV9/BX7wYYpLgdF9LBVkEoRY6WwJaQlp
Ta2nWJzoRxOvYAJhbBAnIEInVFqJ2GofNO0m2IGSJeNs6DxLQUQGOXiVXvJ0iSss063o5W7PFtwy
hrT40rGHRaz+n1Plh2S4qS4LA52M+OFvKzq9sXiceJkG2wUZRQ8HFmmY4rpoPoYeTQcDlEe0wrHT
V4UkmL6oNsKU+hvi94NISWxeEBEFZ+6ggfgDm6yfo+Xf6Lrjs1PXdhcMaNG+9G6gv5cDsUWkTYKW
y3uVNoonwiwbiD/Iug50fZO0FMCa8bemeO2IT7JvA0Bd0i/sqq4odE+Y8Y4hpSX5NbKv/tVKkLC9
V1l0ywdh5TwvDUnZbYj0uKHLBYdzpjSsIuNdmmdp37LXeHmmnmzPRGLX5LNup9mqfiERv96u62Kv
NxAM3itnhlYTFiG5wgTyRoJskR+PqoMmtEtf8f1QnioAjjdMdWSTpx8gN6s7YZe8RwTqSwzOSwsx
SgYNhPPSIxtXPop6VN70jIXko3X+e2mkBSAMVOsamBzHtJXGSCEgdd5sMv6jfGxYl9GHLvnKQLJN
SwlUj/AlY1Xxx8OzswzxUEAlVKjnUED3T68oTaC7EC0rXDYZrM/npR1ARMv1w1mk1z2uOtnmefzQ
YbAkUlYL4v/VqPfxGw9MOQI8Z5hmP4Z/p3dHitBPO+6whytjJI+9QdGdK0js7Wm54upKVMAZ1kDv
YrxSpW9oeeUBbwNGSDr9Cr0pW+KFLzTArp5OyHsoo2zqBXYoqyXSC41BGLOr3NB10UyDkFbMkETN
XlMSiYm8QSsNg0RSnlqFQEKkFk0AqtABcBaLnuS8H0kSJyjwgnKdnlPnkZ1jvOvBOvQiMXfaaAzq
u0KIghHWEFV6d9N9FJwUIi9eurBtXUSaQvOAuYQqZBGw3+05bijo8qlSY+yDQMwyu2OtBDsNeEE1
2a8/44t+tS+Gmj1zdBGkrK9MqfSv0v2h1pMneYsLsLw6eF2FYjn/2KopW09VLTKMToQyTWIfAgZT
eOs3hAa=