<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwyWVHmxlqLKmkFeFsBeH6AcjdbSDLUHWTzdhu55r3dmTRaQKBl+UR6Yb4eH8KYL4qPXvbeH
aAYnM+88VLVNEEgTpLO9OYvanx4ARdBb6zNpDmT+k4H8oSWQ3Nm1ZOTHbQ/9/1ieFwE9gr03vOM3
LQj3Us4xAdu/eEuj62GSmQbkrDm+45q5+NSYtT2XnletwjiAudc7u94ZNFL/lilqgAnZC8ijzdOX
Ijru9e6FnYpN+dWVL4xNO8pARtM4Kx8nCKEC4JlyrsaDFVQ8rD9GTXw3bHFcYcUDgndQWjAaNKfs
czEKi0EFhIxT9dWLs0XXP0r3nrRehfrBecde9Xriah7bNsXLRRp8szA2V5oYrrF0P2sjiGvVJkF/
l/A8TMD2B0m2wF4iwXIC+PPeoVVXXkGVxwD5hZCSe42xDb4YHUxkqqK1qRu3TFcNEDCv54MFy7ei
2v/w2DMDAGYF8VMkFITuJr+A6iy2HDi1wMAoqkPhKMewIc+32r54lH08OvIFrZ9IoM9dntG4PrsM
4TeWg/UJkCe+iecfDyoOaUOx/aRXzBeitu+ZbR6eaouv70chkWCc3621BbYEem5POZ6HpKiE5RDi
JgqzZarq/DrXuPgBMLeRkj/qa2EdfHipvQofhFb7EY98/pFZleG7Jo5IA0obDqFoY1aHHTsob8o8
453olgZDxTlsKZCVT8jdNWLCwfTixWxqRuoV+enhcjcEQuXDsRfrHDA1gnQ/oaVqOQdXMc56GC6B
i30s7YB/7xyAuum9ZBuwuq9Afq6MTTx/RWb+TQN8N4/XjQ+uONDewjtUxja1YGPo2ELKjdcSV+2W
Zebzs/BasrObNtdEvR6a8H2ls1Q5Bp24eqCBOsIUKAwjuWDETXXszryD3MoTYqlaUc/nYADGG1hM
bdu0JhtrI5H1GrXXxZZ8kDlVLgAZuN3D43PbjpYawdjkBtdYVjMkUJjddHijH/3CmdmavxhQC2Pb
7bFqHrnXfnzdhQZyyK8xa6zeSxedk3Me5xZS2yJ4rgx//D8DXvG/mB7KoL5F2UU7ewEphVnofKr8
ozAOR+kiGCmo8cYIIJsxRgtACFV4g5oiw3DnwBhj5VizwmGj01uiypNfld6QXvf/YizJnSuVfxqt
S77Zxob2B7uAq2JxOrsPKX+w6Bw8R2CU+aSlcdOW9sgXhs06CEpknMB7Va3Y2w3LoTNzhaP+Wxq2
5mSVSjg/eaLYbtopKk7COhdB4pRhswAAWgnQL5OtcVamjcm3pdr+sj9+ZA+9WQLY6J+UoRahoy6U
e6UK+aK+AvxyvnzXoXkTXfaULbO9vbvoWy7BZe2JkFil+hH9YpgE9ii6Om72Y4wYa2yO0RbeKaCA
93ipKO27I3DpMOCnIrdv0+3/sPVLHEFZti1STebGhVnbf7wj/A7RuvD0Hoi+qcAiZ96rayTQyThD
URVM4OtVP+YHoDsH8mlVBLaAmYBJwbb92Cl5ZPr1QkC1C4VBgy+XJL1VZ41S98lAFvfCll8wzFvN
kqrZdTPEComIopRx5lng3I4bGg6VLK6uwe3eoHJFtqWld/ZZUucTmFlyKOhMfdzR6x+krv9Se16a
v1LyGiik5NJ85WbA/LrllvSr3mwK6hatHrIUkQjKY8AOT0yoBTOEItr5R1a44GxO74PpaDXxqgIL
tB0ibNNqT7WUPGw/gmuR9UOznl9pLt2p90BeSz1cHj53A5wlbn7b5ro/6MZVGrXetBagQ26gS+mH
W9O+PKYF3qYI0YnFp406k1gc11P1Q2NZ7t8DOmHc2PMdQ87jTX6iaJtlkoySxqUD8WkX/ZVlId+J
FtYLNrOcNIS2TDFALlb5Y8roB6a3RUk1Q+oNvxsWYvig5gjOij0nnxvgjb6DwnnLjtw9m9FZDXKN
BDCs0BbRaeWHSyEsrue6nHMHv55pFkc14qvex0cwNGqKQC9kC22RXhAuEYup3C6452zeumvAVgwl
jc9XBTtgUNW2wXRQx7qcAtFXnJ63YbfpnYK8XaQSPt3OOhxlVRHgvBoow2ZyPjVn5IT14PncmVlM
c68Gau+Na0IjZa4q3csvK0XtXgyrJ+Pt+/OlenwH2IW=