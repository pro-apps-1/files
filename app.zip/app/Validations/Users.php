<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqj6GBye6RcmDONLdDqjj9cjZdkQAja7UlOIcbo5rXSWhtEU7UDn0ebkf9C2cgKdmvvvaGxk
VoO2cTWqBnDOumjm50HK0cXDwea+POC2tzZnVUGeJgtVvKIZVq5yKEdiwmhZMG2IkP5hbrwMGjXE
Br0xS2HNi+CvLtdSrxMkiJYpiIoziQqGggDD3R6i9TdIBAWWLckrqYZ5UDgujHgDfCtebNeMEzhO
H+FHN3bqLYxcDjYT9qu82Ul5VwWGIvvFE1e8A/HX9+XPhbv11mcj6MAwaFkSPA6Q0Ami58PVOzAo
WRwND+8h/FA0CoVeW92M9LiB6V80xryUhTUlmtLLW3e+ynaKxPMyL4wLDwDEsMERAlGjYMpjTq0i
rTcwzuhTf302qpOGoFpF/kuD5+rQalwh0FZsVFVXk4ZCbtoNVVECkQ8JdOKkXnL+964ZxtlMsiRE
cW9Vf72CdgqdYeRWN3rqtrx7TAiB4DN5gVG6IF/tFl4RnSdtBvcmr7WdLb2rPLTklt/PAA3Sdkx1
prs+qahFwj2WQ5ZNs5iN7M+lc+tw//mLB9cpJZbaNByHKO6/b65TSzUiYNF88xmOsKtuEqpdi8oz
bhBPbw5N78Sraq0LhcIfqnASk46XpQpE+nSzrirnwXtTJEfw5x9A4I/KmB85El/3qxhJtk6ywGmE
WRuJcbnSvqYEpEGkhyr10/wjxVZMzQiUbNsW77/GmrTVjS5nylrqd98zC88/5AzmW8GIZjOEnya3
/jVZNOCcTMJgT8WNw77/aEkzvgm8yJzdzSG0n0b0jBomsXPmmlFqYTFghfRydRYGDvyjfEzhpldJ
7kkv4+I0o1NfQM0tFZcAe1Pv5h0oZ0vayzcMrK2MjUtZI9O0UrOSUvHKKJZlSW9gADAaAb+VOUK9
hxzmujvmucQvp1LNjyiIVM0S2r5bjNCj/iepnBI2/TQ8s+4FANxegzCevGJh841mlCWu/t1A8hmR
sxA68Uv6dvytr4g9NTw9f9O6AG3UVhsAB08NseIzIh0kuHdeEDz0mPQtl0eBGMb78MKkiTtx3IxV
22vD4cZ21ApyNBGQ4ZqIhdHwEaFoGmLiqgsAWj47O1dZpXQvEZwTfVYxuV7dlldwEICYwzkix/Nm
R7AskA31LERy7C2zzVqpg3gduIps6AFiMUBb98BcgNGwK5YAQXyU0QYknDM+KqFFm+gYOrwef0xp
xGUn5Ma/PbfmmHsbdsOV4cyjdNwqkoFzgRtQYz65+n0kJP+CL4ErKLCwvH52LVVUecxUN3lc0uRc
0WVHJs4f8Rxof2UpXx4bzlxZSg+BjqAvH2B6vu868ZXu7Avp2SMblNDmhkK6dbVwSf6eG2RSeeIS
YIbZTkFmTqo/8aIqwhYGfag3NE4KR9NSwx2u1a5quUReTR1FglHYTaxdtCCDxj16K5oDOJ92qBzH
IgZlEpNGMJwWUS3ex3jND5zs06i/xcdYUMtLr+CxkJOWMYuFW8wdqqZxuDCNERK80Pf0BWyiwsgF
PDyJkPn5vUV4If4BiUCIKwD8n/qEBPywagmhRRCqjw4+NmEMStVrcLF0fMa7gMZYrcXg6mIdGuUU
9KWYOW1orrwqawnvt4veyH4WgSHkUzSWxSgjPYAYHSMq674OqgV/qRNVv6AXRULJvp5rM08h78Ok
gYSLda8tVEOV6XZvXDbOewLLh2wf5h50MrMfN9PjvFrxo7GeTKo7hxK3lMMMaXy58QHG06QNSpvg
ugW0UK0G7OLTumUE5BsGVLK22zRmnOrXtt5dEyEhm05d7dQyap7Qxxv/QrRPdousRLgw2/H7FpV3
Xkc0Jt+ZnMdroo+CmPaOi9zwUfVaW0NOiCCPMkj1aL4uU19nfCxjYLdiaRXUqhADxDBwbWExXSc0
AIlt2krOo3NImx7SDCTt31dqb0SAPdAMcYWqhl0tNO3mbhQ0MYpscCmWefbzBW7r81k7vIftUCao
OwQ6DvHrefGFBjuXo3f3Lz2ZPyqwOP67WI5hmrjbrYBSnEPVC+nNxx3ewtucuDONWcPylwrKI6K8
dFY1tC9cvRYwygbdjm==