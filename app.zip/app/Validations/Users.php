<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu6gmjSE9JSOrsbNz5fvigVsOU4o0qhUjgoubs30hGHrQfGvMfdRuahOC4x34Psph+dlq9ZF
mMklicw6vP+byTPRpXYvf9ryyGf5Qzubo+exNgAjZ2tlV1cN1I8OBawUrfqNXWyH1W/BMRuhXSL6
JVQs4YL9bOK7P0mW02GuOd5Jy0OegEHVbfSSumIOyivKVBy9HAXxTEOIDbD6xKJH6qaUBxaV4yrF
2WlG0A/cE4Nw9ZEdx02nbVr8JwxnHHPG6Ttx9+6KJ9tsl3a8lfHDjYU7lk5acINoS660TFwoIOvp
MUPGZusmunep8jinjJk4A8IgP9S77mOfJxh/mVP4AmHicadwNjHlUyhtVD8pKBofI5A3evhaRRiG
5AcCXvXd8EavX3Bkc13WNv9TexCADAg+8REyeyPo7/ld3cHG9MNyGhM5295NuPx4J8Qfn5BOMT40
ZYnDFhBABb1w/ggu/K5M0r+ZaXhSnoWbpqPMw44QvxA5a6mWRy5h/eGxKERXPUD8kV3Nu/yC+1MK
O4sj6whauez7i5ogLKeLiIN/+AhZRZu/wK9Zc1Vjw+rZQ93CGMpk0/w4UCMz5WWJk9DUGwDen+st
EVUITXrfIpjX/ooyt8qhdhVaxsOz42RcyDCtzIOitvEX2ozJwdGtyR0L3yL8aYpBvvAoG2rIQZWJ
GIJdlnm9dtZkcOtt9+izHadjiQI6hZq7veWPvkZofOx5JWuqzFi+WgTD9jfQw+C40ibXYnWf+mnx
oPWPZpMFQrE3lPCI8l8ERjdtyMJOg8Oimj2HIKDKlevw84aFnDUsi5jsHCEfjKOCGirgXsawSon4
bUDl4ZKF2ZPmrL0siOBK/WMnlmHv/qDTijaRG8bFUyoYQnzOQn8iPPgqn4xskXHsHu8Eor+C4LnV
7cihZEy8qqHmiQp5uGzknOiwl1m3m0TqpgwJ3rWaHI2E/Mo7wX3VyIjH/8n+h2QcMje+74Rl2DhG
QIxip1g6VLxuc7Ci0iE+7l/YdgzSv4GcAQ/KzdPudXxgL+IW5jMtzoY7UxCc9vzP/MsvpzK9PImn
6Ae3iRXVz4I4Pp/D0eBfUgTQf7AKuSmYDpjefTbm0UUrM7sEH6hn+lodrDx6+p52KQOrQB+Oe/nW
yhnKlbMiJgHYxdsBDdbG6OUQEljXiF2/0vEdlDGOkD8doKW+u/EC6Ui4uwgDnSh5Cvrtt1EBGuVH
QDc6LL6X+f1ZhBUMFa1LJ5S4jJcVmGSHkd5Ap8u0B7m75ZNm/y6mw8ZbHXSeH0OubQInWskKBfI8
WdSEZujJabXLI0rjmtwbdMYBQVHPSM2T9Hhfuz5ps81CAgUtaHH7fKUJsi0W/uxP02WYKh+fVsSl
LsAOBvgOcYdRi8Xw/HHo+Cu3ia/yfsQZj4vJc5lgsNBeOelurEwYYk1y16GckYHkR2DEP8bU/p50
0+8mXAwEyhL+jscP3YjffxB2cqoMXYsqqQVbLAwpSrzFaa2yZknlz9HIhGGrqtCP+qohGYEv4NME
ORkg4nghQXuRmHX93TzUeqqwGU/H1Z4o6PEpUhzsDK/criNZKs5OAoUN1Pk3iyHi0Va/hr3Zfe3C
k8dy0p50YJWopVe9XxXEfxRg6PHCyxLAUk0zq/TeKG87+ZHIREzolz7ELXD8gMNMdxhcOrY57peW
JIGIBfV45jp3LOIKqqEDx9Z81lvGDSoaPxietDzuLWILrxZfMI7Y5iiCakaocqZSdjiKN7hE9rcQ
BuCdWKZA1aaaNoOToHi3k6jDmRid95g53dATJIfU40Ltx+lv59lblXSLcOSvSboxOLEzv+Uk9hTJ
7PPXu52rtSZ+u05+FfkPqEvH/ovXZ3eTja5iT9VxAHLuGv2KoTQZBtscZZxLyDHgS3BUAvNi9ACr
4ouVzzgxeJVCimFAfUDHRKehmaz3hk+BNxhRRE3Vuc97jc0G0d+r9PuUorYO7iiL+88ujUJxaZ/n
cFVJJnhrVDG3JHIyA8R1Kc1lgo0DwQ4TFj4MSiJx7xc+RTjfLqLmthF6Trwka0==