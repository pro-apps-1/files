<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxTKYmBZ2t0r+fSU8SryG9IE/kk3z3Sgzz0l5bVcB++Z3pUTgiD0Xx8QBEszpXfxY+Q1ApOr
TbP4McVO9kM0Ka8xBlVWeZ4cWZFNJOMSyyTX/NKa4if01nlGkKB8o3yYY5GuCLit44RWyEvIWd0a
x9LjqHqRI9PPzi9cZg/fEv7OdvgbKeME9TAZAU2jB55hoC1snNWMypRKepfeVp70YycCgFnRMkM0
nUjNm2svzZhbioisOArCyk3hmTQf5+KSw6BHTN4g2ZSqO+GKdS74uXBzeC/3rMoYh50HC+wjUYJP
vbALbqFb6MnGrk0Xd7ZyytI81TaSAXcmcYylsO9FYt7q98OOqw1rNJZfVX48T/fv2hF1DRU6C1rn
pFhbtQkADNabP0oqOu6B5yLqAwl+uLWLOfIWk3zcCUPSYzV2FOvFx5Nv7civBGgpUMn7Fd2r/HtF
zzoTGT1gxGEPzzhO+wpTtXPEl1l+D7HgEYHwEqkD/plKUHp290bPaj1UNlTO9JW/1aBVk7HjyRpg
CYlhLSsQrCIFISOktDwUNCCNfIa6hxRw30whOqk2wK0gTQeJuTIq9Ue4AoYwWMbHBgbUA7RfvneG
yYaByCziJ8EOI1d33WC8qxlMzpE0GzVyJ712Z+9GKFaYEAu3VFzzfMMxjUbz4dSQKHxH8MhFiwFv
CaLBWwc+u6vItwJ600R3aE6DPd4X/5iD6UigLNbXzKStYmFNiqN4rSCtesQljtytG+U0hZDI26Lm
cDP08Nh0U2f2e4N2Kcg8s5TuUl37hDEHqGOnweerhsUf/m/1KF5i0lYkj7SVlT9fCPxSiUEkeNrD
IUe/pKb6NgclJQZ7xYPJpHNCyxuRw6SmeW6EVfYrc0N1jzk9KOfyxo9/oJFA2XmF7tumTRcAvKR6
67Hf0tm8TW9wub8zilTeM9Xhh6omkcia+W6J+G08lBNfaTcBqxxrSLySxP4p2iLXOmj4mNOk/h4K
vV7VgfjbeF9qdz8x9vQp1WujITuqJrJ95fdJx30gJD+NovteHYeUkHM1mpMtUwjNg78BBH5Jxt+8
5Ir1kjT2LM8uoXmnPyIFM2wNQFjrRvT6E11QvWu/+z6DY1YW36Jbr5D8xfMc8zpgzNgngF7pynJl
Oq4/2oQ59Vv7SgwFvDz1SsF3yGU4BZXXFerxdHvL02Kwyl+cSmICjFFzeRqG0zOSiSvvpFfM8PHW
HLyBIcJLzIRARj/3dbPSqV8FPj4rV2d8XXWNeJ6iypdxxyuiFKdpsthNInVYPvbgqfPH3YM6LpXJ
qcxQc0bxG5OB0bmMcTK0E/VwuFmMxc42rFLusMKLIwDBKOQ5tmVMfbh/b89Peeyz8In/MYSBl0PO
4zloaCkVCMCichJXmgQyMzM8U8Zrdaw68xx2FVYfvXPrr+p+5aSGCJt0+bqHbYNZGE7/AiBzrS6S
UKHfFaZKIscvxgYQFNmvEPEbyYrWAR0FakvE+QSS8CC0Gm6n31Z7yNeKKDiJh0fjsRRofO/cREKf
02eMXBqxlUU6Uw8+uuqJbSogZeEO4ZlG9n19jNOjokMhv+4tsXjCfxZcANMDGid5qyMPUf5YpF+G
ZIpaLqFF2xQmCAa2A+e1SrlxMx662lDK8c4A6V+vqX/axcEefiEUcyI7jITZoyYHHABKURRSIy41
LJEi4qItIElLE7IQ3//ABZ6qezbNxEde5sX4tezCfPU25cdS0HilRvrxuqEMk5jNvWJdIvEGUvaK
s2hutsnLbeIzYgC0i1xLBkoHz+b3s5FmSKbjMX7/NQF1SRLFuO5Z3v5oZxpWg3Zw++pHkTRVLR5I
5TYkjh7xwAjnmWU/LXq9YDOrTzig7kqHxTvg94pps42UZCxcbYq0IyoX9QXDTwGMWACWB33rEFKI
yRGtmMwwx1PmjopmeT4vltdvSc6Gar/hxjGopmqBfgKBxwGuWZ15C+Xjla1QQBGb30xl88rIZF/7
7TRuxdvohMzpLXR3TVC/q5WmgVQh85h4k7XWcHCAjlaGAYzMCXz/MYvi2GoVq+Qpa/kgPx3eZ+Hz
