<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy1c6dN/QGR/U7g6Z8zMkU5Bj0O18GTJbj0pcn/bCci0qYvnP3+/v4ChjLmmXk3+vtHo20Tu
bScdAHj3kx/RNk19URL+WdpUZAbHs4ZQtrHGOlM3L/Io1c8XZB9r/Lk2XL615fH6FY0eBhh0CLnH
MfbummtJ8Rxy7UmIvqVkMLnPITW67is3LAAAteoJTEPS4Gzn9pxpd/EuHkhZAFgUY7dv3soMBpHx
pIITKEQZ0R852VRVzjPkEb8QzfKZvpxhhzm+epWHV8PEId63IeTpZQKxUe0KtsPUgznOzt/n6/Ih
XUIbq1cKZHLFg/lP6VuAcC9wx/esv2mB6rZ/wLMEGY4NN01/A/j7OKSstvEHDmqPp1bW7xqr+tfy
7Lrld3Xq46dvVqDGAFw+bbUjv06pDVfhGfbprq/88x5pWTpJfaL4kqB/WZRE+DpCpC4p/IBlHNPj
EgvJIjBmoifW+By7sQy9NGlNLyzoAav9oLtfZHNSK2gYZtnvMviHKfbcIMgBE9A59nX2ayv5iObC
NCHNYtGizspt8TM7zlfPKgjS/O31VaHiIsHcW5AZq/cbQaNOXikwejKC6hPJw4JEh38BtND2ZDTz
NhBQj9ngDQ9LSxJXYXFjUal72/5PuM/jrqZ8zIq43NhnNqGS7ic+QLn1VsXWHMJMVUAlXrT4ytGB
h1CXFsa8xV6Bw+v0sbIZ0FgQwoixxP98xfMO0oM1HiUk0IfYD8XOXU/1cMsgpOlOlU/Zx1z8QDlV
VB2e+Y6eXU5xOGUbSzu9d76OQyin24zHpNfuytnHW8doykBax2z8WrbU7fmM2AY26wNMhPUOys2n
/ljzzvgOEgCLleq7JNBa7edGYCG1lJd6tsdtkK4PJegCcKi/aGbct0TlwU61A6hT0vqWaVZZCiem
AOe2Fg17Y5YGQ2AUmaerY3rhXMq3b/r9tdnr0fckirImEwTZgMNRTze0wn74+BTHUaPFd9cVZbpi
4GYWHQuzqKrgY4zF/wCUJ4huYmj2GvAjIVt5UVeh9AajWKURvR5nh8bbYegDLxmMC1J9JJH8sR/5
1ZAFnzALcHi4o+66SFLKfvENYfNspDUSKWPGQYyp8WHGfuAR4cgmvHFxVdMAtIkCwoCFvvgZ25qW
ziqdPtSDOEApOyJ1alWARZNAA3FxBMuk3uOXXhCiTBU/pLBoi0Bb5Zr6vCMdJMl2oc5W6eblS2er
MFLI9Jf+1MVOlsxvZUqqC2utwBfTKiQ9UFz9eh8t++YQzhaJuIIQm6Jjjpl2zChp929siXUMjab5
MmfuPXb9syu6tQe+88AZbcU8X9So/CLdmlaja5M6SZ15JoLyoGlCfXB/bFEg5MAphxiEx/NsTMvO
kEUQ5QpoVF0avaCjUrotXKX7IWYZ1iJbHpUkpTejLEtzePo2IuFNCQUrWTq1aLzokAfxTegKa9Am
UoD7ne9+55QTVZOd1e8qJMeY19dmzN3XIyXKODOTxpwgf+0esiT9McJeqNKhW9DnTX9xhRuJIYBB
xUFeRb3h6mHw4ZSTuXN1NXe+FGSHQEUW/UYnwkfsbx+CWYX9S3OVE3gwcNtgvvVSghTfWYIJE1gk
VKRSvTknaQn0vyBDcKzIV6/CCCWtXAD2qO/DDMnYIlML/dlAkbIfNoolKPB+n8k4ASWmBB5frvxo
RCzjW3U4kBCIZ0SpCAbBo4q/+at7CWiHjC1ZR8ChSc+4a9oJ8l3qTlg58CgbbguPd5gm5FxPuQnb
njSzKEyUUdQVahfdnjdNkD9REG9kFN5uTBePz+u2jW8+xw9GPIHWif6uG63AzvljExc+xx8ALeh4
SYy71cyZWcH6mH5S1IKkBXJi0hPYy16T7bg7nlYv4QBTc1517FAoP9SBvE0UOqX2mW2mZHSp10Lb
zb5xDclpJHZGpmLCa2zELTag5k1R5EIVM7MbwRGpE0ixXM0Dz6UC1PLfg38xV1UuS1OmUkkXzQ/X
GZ0/xrxrAt8NT7arInRZoiaqkqStDO4toLD0QjqmcKc0/0Ke/0ba/iTA3GDETOxfJYI7NHTlWzE9
GXAC8rJb03Oq7Q9TY6HP+0PzmoowEB7bxu9GfVdsvR3s/syTTBX5yEGbVjDtDzV6vZGbrvVw3KIO
qrKJhBV1jn1UI5kHddYX/cKOe5zRQf588WodR/0XM3gP7lw2bxwzma/4OkaQ394zCOuwN5X6O7/Z
VGR/lSr5PcQDz9lk+rKt2glh10YJoe0f1Gpa7aoU7Gw2x1tam0nXuKP2fWCX6bWVC3sPPKvtzl/F
gOztES7xY9GDt7jZWkXj3Bu9Jx5xti3ytuFgd0mSC1z/zsLDk2f+84NF6C6ugnfeloAY8u1MjTBP
OIbtVKIRlPQ2Ed3jxqt7u1SMeIPHFJaCsHB7Bj6Zj6VbDTcPcOHLygd1v1odBpKTwjf8/cSE+1Ei
tTREiNKtgM7zH8LG0LScA9P465JliNiYRu8Tcu5lHYP598yxnlIiydJssdUrQeBBdE33pNdlpi0f
VI6u1GSsp+yxTjBl6Qnm+XxrsrURKwO2DUXOFWdx43khHoXDFuL2xEmcXkqMJgbaX+wMtjnhAo9h
Kiq2CnjyOSaYlz0D0FwoiI/fSjJqK0JPmTj/Xeg2cDuUB5GuvS5MZ2zkWzAgTWnyKNTvzIcdz2OX
lODRj08KrOLiHHQe3UTjJt+OwDREfEg5x6ImkrbSl09xj5oIQupboR5n4uFau+q79xHOHn7YH/kF
wfqr2yxHcBPOwz543An5hwlOtvsC/UMpWqJs9KzvdSaFQo8c4Ej03gZRQlpBbwrLJSzgff8kLngS
N6V0XYxQetmhtgWEDQ4q9tk6HJ/p61cBd4mjutY5Nzc//kLgJqJ5dy7z3p5ybef5YgHcBE2aRZzl
zw3Zw5nG2TDVP65IvfWaSourPBbMxTwE6Hb8tcRpdp3OiEp/59WBldMX/vLTcpMjq6RTipsv4NnU
QGiqM0OHsmVv2aXyMX+z6s6lPMof9vSoCphW8ZuRz91B2EmGVEoNjFMsZ1dzJCxdUMqQ42ZaGZlv
1o/Vz6hQ/acr6ZVzuR2Lf2KHhs6vl8TH1mC0H1an/x37UekvvvuvoDJcrzd5khEmj9+kGbcwB2C2
pNW2kj44lzo1UHnEFrPRuKMMniqIB+H3yXfW4Lnte7+P/mvdglcCtZrOWAX20Dlinom0L+iQJaWX
AxeizmIHAqT1M2xal1HdVwBEIfL5QXapz8YaULvubaoZMekUrqGVY6FQp8UemY1ui3vU4PItw2e3
E9bP5ANkvDeWd451Jrh0jHBh6cUaaL7EyTDjspW65eSH/8aOeZrDL9lGb7apuF43QRQTKrLiOQ4I
5bX+U60lZyrZFH9OtKfGzWges5jg5flH5r3fFXfwKXXE+/bZqbgLWSE0BRqCVDWKs+HIYj7cY1mO
fr3/kVjpILNO4EvxB7MWfcXAmF5IW/ClQtjplr7kw1OVKagwJhW8w1w8xn7eBIaRCjRMK+94wfO7
N0pcoxhdUnJUB/HuJTf4cjE2PMt8loY7tOYnYGasxu6piKXpA/zrWyaDRUk5niuqatub6GVvBdDZ
AF7zusaMk7vq5xAoPF/FMb8J5/h7dvm9Rh28bM/JQCcpHPuX4Vzf/HW4hUhISORo4kCl1FJag06e
8XhxTv1BIVa2zG8YrKdoXUoELV3pwEfHFxt7UjMrpheu9wk2/+eF+CqcfBNrhKkYl4e2XC7AWqRw
XsB854/T8Vp0XWJ33nXK1BxJej+BlhPXWr0KOiOAJ/yh3OeRLy3hb/j6AAVe0lsX5yB344uGD/a9
E/1l15ESMbplgV+tSTc/qbPgVfXgjAAHXYH0oquckUTeWeqlAf1CrpVERMLV1IpTpWrXcw5rVOOQ
ZPLwi6fksc9SDtXtRGcuYn1veecTH1js3hkXtUclGiM0yC1d4a6JD4ercjY0Yucy7id2rsaNSdSr
bbNr2rfbdh07SWpT+qv4Geprc+QLKIFm4hoO6EjwqN/L9YWLkHettOl1q9Mz01I73cZ9JmLICQxB
d/dckQLngC2WJUWIKvj62zln7D7khjF7BGnxRFsPbFYnSMF31cInw/dvxDTOkAe5jQI+BrUDzBRz
K9SC5cOXTmkKR1u7NCsGkqAlfED30aUMTGQCR4Ne8OfOs61hhQk3JbG/LdFFQzrn5HFjlVjWh/4H
NwtWTX55Dr9UD3M7EQhQTyk6/y8npPyAxFoWe1G5blkTmzqzRGMS+hMhgD4FWbkIkCHF1YBqDPiK
ohmYv0CZO66udgR/WhLR0LSwo0i2KvIvI/pAc8ejgQBJVNQ5c2jJnbbniL+cnsDJoVVzKJ5nkJ/r
slkBdzcXsbEns9ijmlvsOtCiSKKHtEJbNCXkyeVplFz1MXzawQSEaR4L/cqcy9+VEuxSqApfrXxr
hPHTKmRXhBrYDDHv1u5u/YPCqndcnT/Vrf9KiKq6JauWOHl/uzRkk6M94vqPvLrTsuBD5vpQeVcv
b2vsRvkI/6d5wi9Yc56zubriW5fppb4G0jg5SMYw4+kOL+YucWGlxo8OS13QP3vIM3vTGpJR7y0c
TdI+wUXyr5UN3T/qIN6H6F4zu1kQvPy8hFX1ixvhfILJ0ma2BbanWjLhCf8++GTGSBWN/dsPEZqD
ezjA14OTvGdMvTsTh+H210DpIDi6t0TuvV7uIcv8xA8UlXUaYj4cl36ZMlciCDwrBh9A6FWhNLGR
3dDsz3E225VViinjG5FO56+KUsGSucZFdjSeBSsv9VqMMo3qt5RfaQOSMeAlOEs1LVEYZtt595H0
jN1dgAADFeBgjeiM1W4/+zASxrsIpisE1z7VbBmp1kaYMAIhjVODINhEhKbdnI9eJHn6t4LP4lEv
QVTHB178MFVwg0coraJvLNgEKpkM7cj1KsObjD/sUAnHX3kE+O6EUUBEa2+4Ieu8R7/9qYk1fzIp
Pt1WFUgqvS2mS1CWsY/LO2OkWqvCYNR6dZKeV9zMZo6EOoeSCriFdbhNHsOKONEyXoMvZhOUws3R
GMOt5SKL/s5t0zxFkr0K+HQ0/18b5GcbaCgri9po2cKbujOnvMrqUSPc+iN4cFONdANSumeowv5h
MjINHASEDHxyFfpJHjGkrCAxesmbL0BtloJqNxjKAsco1X/d8pawYJ3XZiR4TuJEZ4Gh8QjywueY
/ln5LYUDU1fe3dIZF+Ii5hpa/WecaY4/f85MJxbVV1fO+/Zbn6pOFiAKAU0M3zYEO+P0RtMR7Gp2
3lzuX9BLPCt9k47DPfyYUhXcCc0aDxqS+/8qkJRXLJ3lw4JCNFAdvi4cadU7kIa5Cq/xc7VZbHL6
EfV6HbXmcc5zTUWDinJC/L50auP0sA49TPWwOvo4XOInNaKQmRFHuQLqbO8jlFxjrnfI6i5c3cG/
l5zhYJYm2CJcKFMW2KpEUtxI37KRKqgk4A0GZrzbwlNteNBekwRoWm+BaWc4P27yJF2of8WTfhPF
80K5X04EkbwvenwVs6CZL2UktC5BPxCPeFBj2VJzqlxtBakPJmV3Pr0hJD0MyKKpp8k3BNVRVwLV
a1nN9kqVNcJ86z0iGAhpqrw7UWdaOFZ5SxXrROMEHCCT2fUSIXYaHpgI6NPUslcKI9UYNnHWWWBV
fXrVCqEP82RZ+CLFyQm6IIlx1MqFB+87XkyOis/8MsuAHor2yeEN4X2bWMFuROZiHTLzBjrNxQxi
uYPvq3P2Xxb/NDoxSTacnOLS0bvjv5vssQeeGkjJabPmat1A8ZQ8jNhPUdGCYwZPgFDdLDnt5dBN
GpGZRL7WuiUAwgrP0g2gwfkZXX22yVsG6SSgOwdOe6MHRxP+ICzAsVjsphKeGsEe39niKm7feq8c
7dhwtFSn93JiqGQKt2f22ePknIXz5DF/aIyARDqlXnHAohRQZKJl1egEpkbgzYEH6My9EMi1jO3P
Fi8tYA/brVemLioWDHgsXycGcxRI9Skm9DlI275vXlw3R6IRNl7cRO6fm80nlKNNFjljAPKPTu3U
SM21iTdURhWSfwYDsOAZThEn51u+0PPSLoCdSlxXM8da4Hxu7rzXkWhxSpMKAxQxjl1Ip0BXSTT/
ctpXUIcn9bhKnGYtb/mcRJuH86bHD2nyCKvnX6DlcLGALqmvaHvvSixivlpxvAJzQV3PBpeKAJRD
NDeln2iX2OnaQGBZfo9WtLxmOevX2FFhzty9Jn+yWN9Ee0cb0GMF6U6850gVep7Ilme8C+7IUaW+
mMkArBPSadmQEKtQwe6mYv7fClpmzi+e3UvagBLkPktTzWnXCzJHie+i5hwMdNMA7oA1rMpsBohP
gtB682R7BIoJgi8CXBQarB67McNC0JyEOIms3/VuBFq9QezG8Vl1yH75MHtrI1DalL61a+zcMy2n
Nr8LyvqLcb9fHGRsOPSmUZUtTXL+7G6EfoTLfA+qN1jP59P0EMFCndZgynNjo0o/sksTGxRQM6Cw
YnYwvSFuDMaR3l0F02F+Wo10l9b4AXUdBY+xX6LUXuo9/ame3jOqt0JH4iD12Eno8vb4Ev58XtCx
Jtpinmjk80T+XjZtpzKlI1uQKdbj5QFNG/Ci3Lija8Nh+3U6nPcOcHSWs21UY2p60aPqEvxrkysP
hLEJqpHWKaS6FLeU9PODpVsZHH3sPNY6JoDiI/9XJJF+ZT4pVKXEFX5xco7TelqIQ1tHnqPFi0nN
KoUDJ1A06cO1C+QKd9pNMOITQrq89mOZZisLsozLqWG6xD9nqmAZJ1FeLJBBb217OkCEYx9UydNr
LOLw7BkGefBu5t7CqtG7JTiI5NDYiaSithNsOBAMYb87MsJ5zo0cQsJaArxwbmrpqtmwXMRayQBt
7YB4SzlBlodE3YV5qV3QLO3Iuldj5xc49KZi6Bagjy01UJS7mS1IxvgbjwAaZRarkjjnLrNNsXv8
EPqAKaky/glyYikGqp8iAFX7UaAddCNi0uG6ANYVgAcYcT4BnmzFO0xer3rcXiYhjl2CA31na6tq
wn0teoy/6TKsspb9iZfRZ/1+ZnPOjyX7iiZ46h2snFh8FOJRAoGO837RgvhJ3eycaiTHafmjGsPR
Z4XDcLjcMfKrjwLyIpkxaCAJg5NEr684fPXNYtQXSGk42tcB0H+rkC4T3CjHvT2w59E3lxlAGEwQ
Rb7fZjFSPqoyAg6sxVkyiJcb+ki+nxYazAxf2m4FNGzOU7ZSCOgYVd5G7Nl8dvje3Voxw37HFoE9
PWRerjWvYKqx8fwffKqFqVS2OTDcVMzyQsEfflVdNpzaN6lwmzdC9g+ZIu2RYb7SRbbmPjDVhr5B
EMU2CsZOFIMN4LqMPHANKLD17Y76tYV+vzmhlaBaJabPDNYYVxHg0qQgYGIppLhSopZHG4kUW8+3
f6nyEvNHQDjMkehvy++oaea6Wdfr6IaEqLvCDuV03St5yOSfBObq3J18bIe8AoELAp53UBlUOkj7
wxwCbvtVFT6cNazIR4bs1gwb0+AU4WHzg2n8uk0g0T5RK4Nkot69clW4GT+KiaDpa5JT5pPDglBX
VttaDTdKl1rR9ltFasrZicKNMw6L9+Fu6ZMedI8uI9tHSjb6E9ieMb3Hygtr6L5zTuE1a2Xg/x/q
dmwZL8K64m/eC9xZ6+VMH1KTwermkSe/Q8Q06xGwMGc17fSGvrCgDwlzHmWHd6rRXUdxzdT+iPSv
G17jBqxFiR/YS0knvVIKie4ZbxwSkGPlpercoygyAuQxbuJHqnGkAux31WmoWL48Bbi1VLjMVWnM
UGlf3SR4pC9aA1o/ctNxO387EmxGuzjZD30AAQ25h5YfPSEKndyP258oXc3d0s/pUV2MCQWVw0i8
q3kDrIzCxx77Ut5O3TtSKueiMIa4x5EGqm8jRldxoSQs/QmBfCk+/5voT5UCKtg0M9E7fLAzbLx8
4tswQLSF/x/1f3R+XWb28PFh6X8IYx5C6j7R34eKNRwcHIkJ0+zZJfq4dlVPQhLHJGSPBcDIZhWh
Qr7SzzoozbqR6rErDLk9J0iF+hlqQB6NJ+aoAV+1gobnhjeZS6Bi8n+f0Wl0+mi1tPMQNzNFIh6T
J3yNZeuzKVBxLjOPu17ZSwAugNAzm176DqfDIttsM/HUrzoitsBBbXEHMQdCrAS9Ihs1hLO7nrf2
OAWbCvQuC6EbawA+xgDdhn2oKxfRHHQXsCE3bn9RPPs/5Fgyr6Z46Gdp53gBVY5fxWu/SkEvJ/n/
f7k79aOiMsxBlq5JlFhIZw+Jz2A+QdJWhAnHD26leLGbCWusX1c/EvwJI/jwUHe06GOY8bGHPpRE
f1yPbLBKr9RxCH8mCpFwsW59ycfay/xK7BWefXk2ZZ+z+C/FasuHDqlGpm7FZuEctH9IFwU58UcH
8LTe1oPnLT1tlgtNNJiuM5z+83uH+wj+HZvNC0ndWRbY/CWnNafnzcUwKaDfIJRPg+XuuRQToOmQ
9KoYgsIOqTBENq2zhb73vxCKNyND2Cqki/fgYMhy374e/p+KhYCj6bWJnU2twAKLectXKEJWKNdY
xICdl2R0EC5yT6OsdF8exkhGzal1RVEN0/uIHHaEIocuHeh20Mzv9GfEMVMCHx+ThuRednWC7gvz
4QaQnn8Q5oBA5d4+QydRIgXUpbS3UC3ysl/RU4Z/9ulnk1QHOEQ7aei+xvjgiv90KXfr4qcvjIV+
+4LDJ8XSeFTsNr9gLj6BShJt84lDso9sWCtgoJv3xsqpMD7l8jo8PO4z5Ce1rhemlc9G8wZGAyEL
3+/cznc9VtxybIual6aUMxqwpa05TsfC0uJeE5U4v11LJ+iFd6p7Vccnew/6dSsp8SSLvv7RCeMz
qFNFCmclqdYMsDaF/OLIZurOmENI+xjV5feYQDdJ82fP+wg3cLomm704ZDhAAvzHTefz8cBlaF7q
nftHDPRikTYwuCLtoVBjRZBdgb4fDiLwowveXljEeDUdajlJ4SXcemwBuTofHqkT9+kULWzIUkbH
CfrWSQdefG3YiWuqfe9/3p7Qzf0mq6RVf9g5V5t2RxyMcm/db8umcrXJhurTVpyh8Ki+nVRf5zTr
B837Q16zPUNoLSyjjjv7s5/ArR+FqUGMRnH9D+SIGGqq3WDD70FcjrsSCF0FV/kd2IjtFnGl9Io7
4FrQFpgSMleGbHynRJyxbGtNika0Q2DigTj+C1REeG2jZRr1G0DkpvuzoVv/aeeZOKyqAPnpimVb
b5DwywnS22bF0N/SPgjlSs+8W81AriO3QnDUlZjRiV9Q08II5ruILTAhcxHazfFAahmNrLQenoLQ
rW/bkFzKwRaCsJPDDqwGjCO+57TxjIgP7dB0HOkCqoKI8dZ/8kIW8AnBbDtSstm5JOxaodfgcDKa
rnCDxvRO3X+eGSEIVtxS5dY5qSTKbaLnm19dzVQAM8axtgmOAKU3HZ6F9RsmimO5prBW0JFgUf+a
+rn19J0MCoyGph5l3jBSfSkJwjIEpL1/jJ24jNbeCaSUTKxMdyT8zaaTZkeQFucPMEM9DIuFgR/N
vDgatVnUrp2fwlMYD1ToP3V11R1/uMAgYNAQtI99Qtjo/h/38XhHmIWjDaz6E6NH+54uPdj+HOeQ
XC6yOHaf46y6PAWmGe9IDENWUHLArHxTEzmABXt5h9cAuX32qRzW3wd8FQRJgj5OnfMrbjEGTdEI
WE6zn9qOlsEpXg4eN04ZxaU0/wJ7LrFXleAGP3T//VM+1b6/+CqGhIWY2Q1F5HmRaxGtj6Oo9l4m
DMMTJA+7XlRpPbUOhAPD6fzw2L6sIR5KpbgheY2qrAyKeROwPxSjqZ1SwiOMTYrt0W4o9Fwq8yrQ
/GclHChFxDizxXDc4O8WmkMsMadfRwpe/pvtrwRX4+TDtuASyrWNtr1TXLh6tZBQ9KVO3eUUK7Jg
QhIqgvRdV46J5Gdw0LnzTUMelExHom==