<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxKnrOa1josktDj0gbxz1HElUjmilp9DGP6ubWmGhq/aEVnq5in1MYaKR7nFKNIicsi0R6da
qfFgURD4yOxLqzC/LmQ9eTIHRSyohZw7Ln2BNN5kXjykzgOVfC5dLSYUMuFzp7eSI1aeyZg2Lrsj
sxY+9NXWWu6L4qO3ec1w+YvT15uj0jBtArA2XDYEOPvYf7731FtGwbzuwoTLvsIdZ+8iGnujU/M1
GaASeh2AgD9sClg82BOKWZ0/THUzJoN04ecunar0bIC/IiIrHvjcnscyWwvbrIOCWcIeZ7teMLoO
fRaq98jgkBzNDNu8hjAEfscgbNsKoK1vCGB0uMWgFsiCsiZlaJbo69IGRRk9tco7WYhRMz5rGsYg
xPLe2UCmUpi/5QYesHr0UGPPX2JQffszQUldf3+9oO0ITb5SeSZ1Cgp+TMNQUMOuIe0hiUu4qD+W
qD6+EGhJSpY9fptzBxhfakjPfBwnmqfhjwEAFSHNm0vMrzBJZlhWPcDXOMnAjJgJ0LiLQFLs8+le
DFFi7oN/67CTqn8DzQxbUpPoZShJTdgIQVpt5oO51iDzMvFAQDwzNe6k71WMbA8KWz51j2CjiJcp
AlGFZOPI7c4IGbi7CXLXbzj2qqG5jotUELRwt88jf3kZt4txXJt/2L7Lyk9iNKDFWv/YyaN2iVeG
uOwvCPkH74ksuAN7Ns3esFDniPES6JuXOh2i7I6LvrYv75wVC6KKKgYQ4BniiQ40Vk8RRNhVMcB2
4X0QzIWWOXWoXLtIuAoUSFFBGd2lwhRHb3sERpvCdX7IV4/Mhhq+HAYLtFlp0MnE616MbWoficPT
y8pdlC8whh+zJEz2IJ9ebmRS4z916l7RkiRTxhzvcwTsrvCLr5wpLfLUR/OLwChPLTt0sYWwh1P9
C0qt8ZkmZPn7ZXU+O6+Xcb3GqL7c6BYPn2rWBEan75NdIru+nkMmenBOFwHegber5nhntGeCAGDk
OE+a7L3uS2PvKqlwoVdxdnvb+GxKjxn1f2/3dkFI8nx43a4d24uN7rl07PUiVIwHobWXSs28OWob
aahz79WAZtN0p1U+qZji0ByZraOW3GkEq9syB06JnGopjKTABKfhgv0pfDYaiKwXI9Aqyxff2Epw
dneAkn4uiCf+IFBFGiJgkxuoWs33ZPDXvXrUM6fLckaJO58/IgWlc1QR5elZ1s7f8dQWWRj+xtPC
BU0Mx3KMSv8bnBGtbygB/kXg0iHuUKehfDxsRcO9QdnnwjOnXHe+hRYaQYSTD9nX5v5bVwNwKGyS
0+EpVYB3wgYPQRsz3zZLqPVUd5NELOXd1c3r0EGKCAFq4qcnv336izb+WEVqhbuD0kwdfTEQ6zOg
wdUux47d52kns1RYUH0FEWStgX1gHAz9f0G2b1oEnNu3dQc85oh0lnog411ye2o93wgBRIy321KS
hDNtIuEhmZDy+A477HTnjXpyoRrITgQ3KA9E96eTHqXKwCIzoZtDmL1+wjXnxEhvDyg7fjKWeQ3S
dX8IVdOUCMEjsNfrvKnwKT3RoxI0nwM4QVTART8VJXZopvoR09aayX63kdz2b+oKf32kf2dvARY2
p5zGiXFWWqwcD8rq3LF+nR0Mk7abnE9+zGUavw1TyhuN1HjXKTAOkinLvyxG5IW2QWP+XXiYvuRZ
dHG3KW4AryADrwEyPf8UxJt/dYo4DVHrE/Ja3KfFBXLkNWkBNaTSVInnYfAfJ+tc3iVD704iD++4
KYLNee6b7bqXPm65JnI2EtT5MQ16Pf5rSgY29LUWmrtQCSLZDBaOm+X4a5lYHviwMlv2B0p9J8nv
WWoqpHe68kv3MDg27EgjWcvgYkds4AQdilWhutS//tgBN7B65en1hNzbPdOawQYi0yee++uBuDj2
ogByIvEtPf0mKY6MdtxIix9AlptSHJGh6bfPtJU3EpVqzbBde5wsIFVARShn64BaPKmSD6+KIjcD
Aql973a8RnuEwrP06LVc02oQQG56T9adB7UMbGw4yjC/OQTvw3CGTCTZ10DcLV/QyjcIg+6G+kh/
jQfzMloatg8plzT+RgMa3s3GTFWEGXo/nGnsNHYWMeGFMz5ZS0uxLGNSiJabJ5kcXnT8RwQd5Gvp
xqiX5phQ1VJFnyywE5mFCAHDy0Bda0k/L0YjVKvoMWCMpyBR0l4phJUF+UDDgxmCoKqnIlOrGClu
fVkUhMaJlMl6RaM8MUVZUa6WpkpbY/sA2CckYjk4W2BTOfJRn2MpqDdSIBuCZEZhFKpEMk/SDuGp
VSj062lfkX0khxoVbSOarl/bmbj4ndbSvti1STBb4Zj4LvD3CvwTgdgKyGSfT+x65GCX6eghHUVM
VECtTHCUJFQr04mn5WWGw3W1/xds4hsfRrKT9zV2rh3ePsMR71XxDts9O8LLTpxugfp/cYMyhTJG
Mx6FbGDOzCf6Y1Lwd9YTWobLSB2IuEpGdEBvS6R6xQrnuCj5dDPA0NN4biyTHCrOPGh5DJ3hDCIi
UMgL8huWNCyXdEhD0COzeYWL7Ta8lGqq1zh6/0c8+iGMq4jdh4GbXFJUaus2KyPf57cjopBxYu/f
VN9SOkiM53wI/7/vlsBQ4BFMx+LpnZZiJB4N+Z3q+ceL9nd54iSLgLDf6UhMD2yup6DBxeckRmox
aaZ5KrKUITzTuDFs7ETf52ebYk2fTqsIDK3bf1fRa0uu9oo/3fX6N1mRzgwsMnV/KPg5Nmct4/pM
+8s0aDU8BB/mUCXSoLNLqStplgEp7VEI1Pk9EplMxVg3zeFiQNICypXn+6GiWlxkxiDfu9J2hAxM
ez/5C+OeBcJZJRj5QBuYhOLJJwoo9XY1JWFIqKPkMt9Z6slRCsrDq2FG9ZlSVDJykgxHEcCk01s1
GLMRWmoLcMSTvAYCtN2E7RQIWPSPZoQ5QL7jDztmgKdsXveDTLr5i10WiwDGtL1BAI8r/+FZ0pEr
bUe5X9sLYLOu6G+uMizW7MwSX4BXMxFiEAfUJGCJ5L1ldVArBCsDG11v7du3hZvOZhNji1G3Cjsy
tAPP1WXoR+6QOhir8WaTgz1/A8jY1NaKM5NMpPGFkDmzOpsRRGC5H+TMQCc/7svLul3BkIrridyC
kJKPSBVH8942gD5UaiMRhoYHr089U7u2PCirdeWb+3x1MGFXsL3z1MoplovFE4poIiA5864VfqaL
sZ1jx+rv+VNjaYAkmqVMM8OO7g38i3vA1bWa29/7A8eYjM83a8AGPJShqwUrY64TSzbCPME5J3j6
DWkARY6BSm5BOj0+TscGAW2Cumco+IWU1IxUU1A6zwpuZQbozIzyB0Aw8tN1RABBcZrEHbi1BKUj
Ru0cgBoKNJBscVO5eEszb684Klq36DYce+qD+C9aOh0WdVxXwQoV3j/sVKiNo7nO4gzUpPQvHub2
gzy6GKSKxP/7Ug+O8yA3GXXlTRgbN90S7LQvlg7WunukaJB8bZ93arkmS34zyXYlxfc2pypB38a/
VrpE6N0Yof/rXsVfNLO5l07uBUe5m1u4j0c9rnoy+E0WT/cZHBHEOb5VG4SrW03sgsc3reZQBxKs
05SBUvJeJkQF0NUt3Fw41NTacvhVwBAVR3HQxwrZzKdrWhMStB7uWteMZYZWJIJB0j0YPuaZicVN
Eb25diTjbkKW3vHWLxpCH5UOZZQ3bUpA0clqZGwU9WunmJ8OJV8fhwthVA/+EUrsKYZzE0SmUobS
NXUe0+DK+sne9vTt9/HsX1U6qKZ+Su3XGHF/1VO1qZSeKN0VoOvOE/YzIB1v/eYHeLQsOIvJ7Ei0
7A4Dw3j8+jIg0eYQaFrZUoRMUwlA4rIsnfkkhHPrJkQ+QswXymjwCssRhDg94bl491eG2dpSIGOZ
2AYeuKUHhUpg0JZazIuBcw5TSSzJFzQko+/5bb6mHhnm9IakodHNbBNdMs+UBDvsQixv4a7p4CgP
jQGQk/BY3VTakOknnEQGOFzNXyJmIrMxZZEiof17k5yGUERJaZTd5eaUr7cWUcEQpoNLJt7cREG5
wy+uxZydTGyE2Gf6q7eRd16rg1q0YmXpg2NN1/k3EMAouZeWPxcTC0CKgM0lAeBWu9YoFVFcOF+W
bEmiYQbyKuNiDxTkCcf6cu8zUZsX1Du2EDun+3xqN3ydZxhu7vLq77bFTTSve2K7aVMNpVuYhTkz
9zT1Yfo2FZuPL/se8xTOmWX2SpN0I4dmxRHqLY2I5piuDB4KPt15gwn60ARTYkupUMUoDyaS0RNf
I7GIywqdLMtnaw7UWBrjNqI+nA+YIWYc0sxGBcYLwfnbR7pfArgnDeoVfaEyS3829K48i9qXgSiX
Zpas7jAoThitLodsWUYeCCSqEVMzXKCQkaRdP0HEUxQgLH77Azl0Dn9eR+z2pMEvENc2f7LKCJg+
CGI/e3WAXiUnw4ZXBF3EMH0G3lkx4OqCJaCS/s3P7SrCDX9iG3ZPx4lMnE0WU8CIUDMkllT8CQIw
gn41TKugeOCU+eGB1WLb1IuPcWfuUUd9Xc7Go1lvVGGIMToYs8qdB1VIg6w5EHxQOIex3frVbXTD
aPrjtOLJa5Bg89d3Z+odyynK/3IN7rSmPur7miMb8pcEvDNc/XPmbhLBhWHzLywU5/pC5RPvY+rx
xFcVPshfWdTG7tklTtaA55okdecoOX2LqiI0mdMPMqItIkquxT3UiZBn3oTt7/TKeMcPV0VI9AYm
2REz/okWDdvgnB8Zbm5o9HSqtfdKpJwl4Wp6/5T/HCEYuDXYMxIX+sAaG6CzI7W9Pxnp1TP1zqxS
3n/GScJNvUZd3Fj05oV747yMRaXf9xMx9nSI4IQKdsQI0YJmWfSDRkiGMFtinbB/BK6hYbPvm9dv
2YpJLuj4El17yh4UdjAKGDY9TBd3D2u52suM8Sa0/s9q+OR4TuHiaSPTcNiR9cS0gtMz2LTLDuQr
kGc1hKrhLdlD1GKeMq/ndTrONaYXy2WIWpWDomeFcL4S2NsJpMrvsFMjPq12i+OuZHVTVnmWrSj2
a/lK0y4ht+uWj0XqWtyuSNXyRxG1XvaKtNaP+JftdkCGew0NigizZ9iS8FMiCUREgOxUDYAl6VE7
3cZrK3J4riPex02wp8jiEhhsLW+pPS7F84DF6BCxPV++enrv+PlMjydUUPtqH8swbPopH75fY7NM
HJ3jeJfOGkHh+IoOwyDeDNKzshUO8L5XZ4r1JNBXhes85ESTNb+ZSxPrFlwvySu0u7121b34EDgh
OwyXOI9h+ug3B3V+oDpRrTOtydv5w0CGAmCFFLKeGUCT69wWNTzXQ+iDo6/T1nNPvk4wGEReTePP
OCXZ209NNRHnM/1UnF4IryLfoAWv7l09D+CL2xeSenkK+mMhv9XA/PzwyaPNGF+1RtEFPSsjbtuE
tL4P1Xypeb6Xy+GZRiIStFQaOZA5d1NkLXXDlHkKqJOTKjWib7mUGhvmGwmA7o3YHIf3B2d+AgG4
7yiBPPy+yDzRNRh6gynXRGJeRGqTcE5rZRQ+3GX+ED9nb6kcqZ+GpN2rFWgiRiBKFRa22Rd9V9oO
0Iu3O/+ONNPpsoGwxarOGMxp9x2oKRQBTMR9I1dQMmihI6FqJXdJUy8sGXKte6+PYyKYTx8kv1d0
Atf3v1hHJoyRxgNXbm7wdGMahw6UBkbFPIgRqUhGl/SiKuVbKG0rz9sZdRoqWMfHW50oPgdOhRoX
LgOjWUf9YrReyZ/ba3HpWenU92gJSUIn9cjQ+tIH34C920MjSLh87Nh3Oo6b7EtwwBVetQ8JsrcF
WlnI8KwRoPFlAMOfARA5poMhIu/GEAdS588jzk26Qnvo/FAZVK7olGAn9xE92vQWFWx0zJxI1qUr
6N04OMq9VoqfNE3HNTAiLjCBz82wxI5I0iBncU03SQk2EA89iBwQueNryjx3snxTVRx6kbsEUB0F
m+ZmQx4TD3SP08f7ivuHETU2Dub5xjr37X3XgFlohaI7PSAy09M5cP66AqqNBiyJ1m7TbKDhEX3J
N0mZgab1Vty38VWf/69qJKXxy1rCYZNo5HIXnQhpfVb+MTkxUO6I/mEA+J9oTbk6NOa206Y5dTy9
Vp0kl4YWcT1b3d7Yd58LusNBKmOZMW9+PwKXYLTWjsfYaKKWFyq3nH0oAqtz85qRamYRvoo1uK85
LwaMqhc2ZLK6JzQG6SnR3a7cxSzhszzYEBkfiAodNfX6FQr7I8Wu9eL4o7yKQeCRjv5h5wAeRa68
HoSF7iZweGPa6OkXsJIrGmsm6+LGUpT8pux5Mu979pdygVheX5NWOFA3X/08HflZmojM8A1BDKKx
sUKFuQMZD6fOaW5xQJIo+1Q7d6xE8M3d5WynWCx8xzGsu2O991v2YCoeyVLeWTfq+ZUZoCzLloGM
HMlDPXZEBLRrW5KlwOENKQLY3ZGwK+iDZWT8aOCbE92++oKEsdcdsnCQ9hl1cwOaEeu9bYkRC//u
55zjNalWl4wwDeKX/qtDOkaXdzhAqVUJhN21T/+7L2cy++jhSccVifYmV5OfPuvCo3OXEcWCaBxy
SPSY55ci00fIoAxmA+fiejrNpwc7KI2yy7Z+veJCiHiBOUQ9mtNJe0gRUgYVI7Rz+RcPy0k1XMo3
RQ7XVUmbSZk2mg9A32S+ccjNgtreXBRpK4rIbu5+BD0cSfr/h/Z+FtvGRMqOkkNgYiTrJWddxbXT
lL1jwAXkpr9KjHGBh4YR+djLoJlepO9jJtN1nBG0S9yRv/Sl50rtzS76hdDs22M0yXigZvGtDdWo
gxcD7AivLKpSzyirOSFf0hQCa2T0IqQRLTaqK4LctK2DQymXK0+PFPqRDThYAb1tyZXyksIflBLq
NixSyFqfQjjh2njdXObMPf2EQOQNiHqLNMREd1RKdTKKZqC6dL29eYWGnxB+5qFhY0HYDKkxmSRu
0mPnte+jkuPnhSZPTpOxG1a4in0mLtpzHMqzLRe7G5WPpzKUnnAALxlFxT0+FSsby8V/dio/WpDa
TjVRPKnj6ftD+T8GiZ/we7ig6OHqwOw9wtnYz2wtCxiLsObX/xBJgSWmzhVQ59lWJapDMcGhLBYL
fXx0mijEa7XkkMWGRZwNKn1bLxXi1p98RSNPRKzGsaKnz27qaeAFDjxJXsUW8PeWmk030BDGBbrv
ZZg5jdNgOC4IxWrOUJgMb14gZoAIFNW6DLzCNRcYE5NNo9xE8YDJO7gmx97BluOJlsdVrUP9BqEe
yrLFHsL6bNqDrhFEsg5D5CPBouBLzlzItwAc91Q9EHYhxEVXz+tXizZV9PUTD90R7knFUlFdZ2R8
FcnLG9a8fN7foeBiWXSJniyZ/RDYEr5dBJwWHCmXZBUGaHBNoBugXzKxVnK/h+Lc88V2HunsaRIr
SS4WwYu1wBu1/xvwG206FgBs/kF5D3WpaTm+ZTKOOp0HuoYkDm6nhi2l5gxOt6AhhTmwkYMWHH21
voVY4EyQKwNZWQDfFc3mDk+9Y8Z/37XCg+VtCPUJGVQS6zQf0bVOneBXWuEssx+P4i3Pnoomxy0T
Dg/D8+ixJr/pDBPYvN5nzsYeCw9F88Sx3GpjST7tk4cpjjDPCxTo//0UK9/8JX6IPKvA7X0uP0F+
uKRDXRbZxPFm+BVfzFO48hSQUMxOB1SpUhfsnCu33/qXB2k+9+pmIG6zSKTkm0gD/fM1JLjuoP+T
55xPyTbHjkl9sTysCICCnCOg7bG9iLrPlx0++5F/p1Onzt1hD6vNMZDLn05ykEs8MBrBusLTO3au
B3MsuJhiakiWuBT8STrO2J6VFa7LhEl5GlK1iAi8NVuflz8nmvsiHpWZl2R6u7aQwIqqubifTZE9
moF8omBJBMfyHA5OzhWRhCb5AQCANvtLkg+7zbkkBVZtGEFAq3JMBrR3BfLnpfok7cq+D6sEY+If
qsCdISHCt+fho4dqTwRoRRSC+nLVqWNYCgawSdzoO0hD0Sre3WSF/rk3ghYWaGVd5ZzlqQmL3u3y
DZGaQTwBCs+8rb/DUg1VSJQXUf/qo6bTuzYyqDRNTvzsZPlB5hJhDhYoM8vadwooUkDiIF6SXxQD
xeNobuLeLuk7kMZQvthoPYnHv6ucdKE2LjCqC2UZIbxJ2iL6HQJkcPh6zpd0csE+X+FfcMUsf3eq
EMw0cXQYfc7/muvjYuakeQEhlcy8BgZRLDXHWsqBw2CMSc2qrW5vdORaSi7D+x0DbE32f74jqflx
TWB357KHgKFiiFJH3sHy/0te6iemE2R+L/aEjuaK3mgElb5fWCz50R9J7lya7iibm/uwWnqhvC51
N3S+XUhrkSabditZOPum/t7wraQCUQHXJcNiwADZZfpHkfIETPDJjeZHjkQ09kJfBclhZzGXeW6W
r0LJIvrt8d6jwx76xBtitVdtefxpqCZYaKlQLTMwX4YqS9Dn7s89X2fox7pdQV3eo/x9Y4W/iIqa
RKcsCeb0bbsB0toHNBgNTlF8Bkp/Y5Me1w6/VZet4NFF34yLYaG8RgX3QsX7358jwY6UqsNWEbku
NOb7L7SVMC75I8phRczpQQI6eV3uG1dJjakHVqcPrxEM0bWnQHYHCLP44G+JL0D5Rg/24jh4HjSM
vGatGOkX99zlw8Gp97WJBNoxlQf0KaCTCEK0xYG+cbEBDrKSnv7jD3+W2/cGauhgLfXQbVxScxrV
Izbs8vFPQD5kczyK7RFkslDN0w70NMCUVZWL6vmAdxJ4HCvUJUCtRZz0qdzFap/5oHnnePfJWgpE
jyjXSbiFxVBFOhhenPO0tmEy7dMAQDemiZg1VlDGrCFMr03SJCRyriM1ItzFYigeKqWghiHaLeXM
/0MaKy9MNHvrylPbbrUiP9iPrITUgSwGKLM6V3B5mZfazgUWpffocopFoVymAeF2LRFq+cMnt159
C9eV/5rmb5UJr2W+toGP+h27j2p+pGghI3THjE+V3ItJR7GIVJsp8I3egIl534p/vHC+0rdES+Mr
72GvZXYlG51UR2gnNMrazKdxxCGwM43HnakzH1sJJ2y+4AmsqadtqYlxz5bYu6/V17ep19VbmnFO
KZRlMqm3YTz+h9bpdUBgU7UuB7KRaF4xNIpJM2pSx4tirvmp810cb1ksDoZ3IjSr8Kn7z9UkCV0v
ImpzOb3+7aLfb8CoVh1DWZ6gPFtv0BmL3V227sdmtN8WeMiAyRLvzAeVCTO/EofEiQseJkM5ayVx
kwlW2tWNOBiaZ+Uclc7eHIv/39+agc626444Pk05faHs4oLC7tNIh1xcLURQAhIbu5YOmtQK451C
7ow3nMXzdMhXjit/SdyCoDoy9VywhGEyTcSjOc8eBOoXU9q2qws/7F44mMsYnK53hhNa04sEdOwM
3FBf9q+e+zAHkQWE1/658pgNrBi6ELnlDhs0KgideEHEM57qGgapb3dFLdYR11qLNXI3P3zyZT3h
LB+FRdB6GrdDrAfsKuX3JV9QuQuqNOsGUsMKTIubxevrtw7tjcce8gTfEwTSJ+jt3GQsvTrsD+3c
QD7p5AoU6IPMSXFUDPthBRqiZbStOF1NyZLtsdYKiwqV4YS+eFIqFOJuyLlT5hjvKzMwIVdHnsIH
33kqbTdLDyu8uHS5r8wRRnXQmw49pCkoE0G5E+LeY0Z9fqAqvJMmK4arD2cappqEurDdZcvh749m
iWZETSWWWbblSyqw2LEYNPzz8XPm/ohdQ9lmysddjyLn5F5rVDtoIX3t8aC5CcIOXqEluR44GDbh
sxVDKDlGXcz/61r1XMxZ66/Idw8eDrWiyCRPI8VI5X/l4Wquk7zHfe9HZSJW3XQo+4qaXLb1RiIr
DZ/WAJT3vyNTiBuY/WGp4527bNr+iMHYIYHZ2do8uBLV01rhWMg6jIBIAWiUizlIvsxJHC9Od3Qb
cZtnjEvBvx+elECMXGPs66BySf/ROARVGeRN2Vq/3RKgEN1lUUk97AF5Bu9zOCtMhHNg2A8=