<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqARTUbrBKxF077Woc9huFeqMgrvAvQLguMuQgPKtDXA1nC/HT9VbJ8mrH6/CX2ZGlGIiRyR
qPDaI5Z/gwxtJGEgcvcg+5IHEFe7BfiRhljN7b8zT0DB/2zizCuQ4UYy4ZqdNNPg6kanAjk/QIOd
WKfQ3Ez9XXSN5SwS0moIkuBuFNmjQifToJaPyCHFLwrQCgcH7dKZfD70hoKf++qzJRgUALEKQ7Nz
0pgsBlvPN7p+rW3OxFXDHKGcYOi9CpTVkmSdbe2r2DXL8GlSdw9cbuGu5VHWISslOQFhQfZqcCkJ
QNWTlFcD65a2lMXzIjJveDaBmy9wHofoWK2+1PwhygFZvw/1z+tOvU3t64uxP3bO0QcWO+Z6vpEr
xfM7X4wtwTZeU5NBeTfiqirr6NsdzyQ9TC1TrOYJbV0GYXtkuJCoiIsopymlile6ZHuqnBhVBL4I
+aYqNi6TNjKHchxC1r0uVkrONHJs26gy0ooMkQF4+Mi8trXqd1CQx369qvmeYNWA4R38VeQpErHu
Pg2RSNC8q+ztXZlUUSaTkTdLM3eQdKDpGeLDrpzVl020MqEudi9Vzy4B7GMPtzmG7D22Wk9H1eWL
2DaF7YdnIRseaqsY95ydvveQ0BOxriVgL1WE62oklctI0NZFJIqub335+FuKZZ7cBaaKX8FchBUl
nZd5JOoExXfZh/HttAYCtUyQq5yJkLJkFz8Y4p0IfTZVkZT0K56YBlh2neAY/+xzSt+I3FXDkdUL
+RbIcCBEWPunmc67fj1OU3Dt/eLfHNl9ZSl4buH1LcWz0hjEsg/hQ/tqUM5/ZvvR8Ocb+zn5/boz
zPNQjOOD9Kpjbp3eclOzg44GdALcl2UnQtOoJZTjKfUwI5jYYm4zA8g2HV3essDHQgHWOP74aKx4
6dZGjsewtjmpk580E9Ssc8OqB/iLZBcC/D9xaY1mc1wg0MFO76Kcm7L0VxUrDoOjTlg7WSxcRJNJ
jJAVhGBhozn7M4KvpcG2nt9sH3iXuwlW24TepLUvBrQR+A7QbpGMTz1OrUTYreHbDn/qMRUXFann
H5OPzwOUxAgAdYRrWfn47zeUFsQQAN6OCZkv1Rzw9ywH1Q9YizlcNw6KyyUA7u7yFQSSdgEydgX+
aMphrDAvukz0pNwZJu9S9EEUW7xr5iKoE/I4uY1Vf8rOmNpgqlw+CH3aanxIZq+lcVQUfrOq8U1+
ZBnkZ7YPM2kO6GdqS6fuZyXh4G8m629j1z4QCFYh3XBrpHMgYuCpzFhTfxgjJPNyYOyUDgp0eoHj
/5BP4Y9tYdL48q59eAK9bS9QDOeopf4kaEuAHNkk6DGSBImQD5ZWPXD18KB+B4WZFI5fLqB79cC/
//H2IMFKfK9aKdf810oJLgE5ue7FA1a6+7rMbVY0YRYO5UfcK9yT+5/b9OE8xE/lY94mmyDmxFQg
XjpIdW1e3Fbh6JuWU3UHhjZYfVGqdKne95HXjRAAvBChspVxW1BqA7/BE/MGKMwUIZdT8R3eSNum
TndixoYBUVKCKtkDcFj5dTsSzvA8r19i0PK9VRv3Ul5symXiMS65w++JZv1G/ByCJh+S0B37jciV
EFGEcbIjM/ilP3FmDpriZjIuQ1tC47gDRmGA1r4LUox7xe2wHUbiP1nTLMGt+pZWX/kY1ISBD2Zn
iQlrfGvbEgu1mHkprIEeqg1m2I1uz5GuZ1sk7cV6lwDJLEw1v+poTSNXezkunT2gkVshLnIEavP0
5hFR2DlRddJyHeHRos/PxfGaxb9XqJkaB9/mIGen7IQObDWJkUkOAEqulBMlyg6H4ZvdDMv8xCuG
btnDapcJWrcYHLxSzYC/8bjgyaKc3zIuTDMBWAjLXgo+XSJlXa8YD/kcIODWjBe1pghd217sxsVr
INFd4YUAiFvP14guIBAdeQYFr0sHmsGHQM7l6dc/kqC955C9+BNKu8CurV5r6z6sQE5sgifueOp7
d8YzwzmKcdp0JuWd1Ve8dPfU4pLEU4CigD4eOxDIsfHm8eo4PWvNNPvXZDDepwrcpQUZH/yduRPE
1lWhyaR04DDGeW9VBv1u4dZNZBt29eTfs7u5nWXe41vJHCv8KsehW2m17i2mmkIFD41OlxSkpXZK
hW2u4o9AX3OxggFuZqxgYK9le6F1dLn0NL2ff+Vhx1jdAxXNbBkFvK/eebqmtyCExSvjDLk+6d/u
9b+ru1Qh7M03YaCvGc4DRGByD1rNtEB0kuOcPQRstLzXuRlxxQNJBzJeJNMUYyB6wN3/AsO7tTzy
IjjY7+EwfHjHRbAYCExUDIBqYc9382MhPj5C0QDMxVW0J/gQJDBz/8QENKquK8JaQrDaaTagk0H5
nf1x0Tts3j2S65237DhTgTx1vNnyPl109JxL0YeA6jaCfNkEjD84uaRb/bY7v6ZHa0XXCOm5t0lJ
HIQF0io0m2lPYmqj2dkL0ModP7yVXkUYVBRgag8LaDjOFycuPxQEb7VqJe7FijGnTPNXVAoMZRVH
ZO07/GN/CZX6pSTE/T7eAMSVi7BncRS80r+jW3L9CPjlpsea7/qF8iRGGDTRKoCeaKcWVsh9YLFH
ghqYIYi8Q1bRVgVjAe2WMXtI4q6GMpvzTIaXUruT/cdd0tILCZFqRFx0qV+t4z7g1i9l3V+bZ9nD
r8orrzSzoxuFQnOLRkP16tJyioJQFQSM4F1kDo34ZZBeaH9zG0HzsZcdohptX5w4dD3oz4ZfD0jc
GiRWYGyjcS2QjFGAJxhR0o3kUl2uZ7IMowTO0jR1wnkzyefPvv6Zb9zZkwxijMv5VqEiYffKU0Je
EoVkbA5n4TjjgRCXmNJCJekms5F0nfKIpqzoRFZLq8JQYyDb8ybuAaXmaXNOYzPB49SzmyQTiFT2
ZBKrDOPJFK2Bi3A7EEwnCq7MQlrgBVFzUJZknoMlYQ72vheXNUepvvidKPv1wEtSw6QdJ5IDMx/m
WAcTpy10GsC+Wq3QyZWMWBFl2O5psYdvGGKoFUgZMG74sFJDwu5Y+2PvCsWK+j+DmaHDlV1xa95L
W8NpWIUhhmoA9ITQFbF0Xml7RXDgkqhga30wYA0b3Wmo1IEnh+R84WMmIzLuD/dEg9VwXGdPhhZ/
pmBE9Q+QKt99qAshhuKdHN5s3OptMC11cPLKpV9ZOa6O0l4Br/ECsduTymWDvW45wtoyAzDVds1I
wBr+Pzk14NV66LzJ8/AgHRFATs02hj2JYJUccLnr0IjoDVcO3TRLwZk3Qa6I97a8G0WXpSBIl/58
XUOwATvMRLaDW0H9XFzVLON/R6cb3HgWyK5CJIxrBkUmUJNq5ATBX/BTZnNxOQPlZoD6eQkpmOGm
67HWWFympmaQnQzg9zZ1y7sgIPO1Vnf5RIeIYJDyYTpA7qOFW2AqvddrOV8ilbFa+U6HHHIWHTVa
izylqYHDgrIU8leiKFqtOdJTNOUgucLsvxTXJowK3s8nN2lv1XTOEwyQwuT6XNIhyK234Ff8byc2
PjzPKIpPa8EaFMVrzNxeobSTW4aLNzPlJqLbTzuaHfBp5KX4Z3OChb2woO+gShyF36shMulJahao
JFFPcphn6Pvr7m88jk+heUBz5vc7qMUEnAoqxBMOhIRUoXgRrYmXC2rLMsinKN6oI+88QNELyPPo
GQqgCTbFGLwFKVgpcbxkcd0FhATIUmJd9XbQl7wWssxb4uhyVZgwFdpCVPu+LBj6fCwTDDzAa6HJ
9arcZbDQ4LH4Y8VbUe4HIQ3dFHRgKbOpKQrctbzuWhrTxnRyPFwXVLB4sKcZLFQBeHG2IMkd8cMr
S23jxyMA6B9rOcJycQkSOdsWeSjHAYTCfy48eMAVx4hgXE7YEgnxOk2riaARGRu1s8OJoe78I+IM
X31BiSi24K+nW5mUeD54M9gdu/owvdLuJX4H6t/nI13OqkmjIobdf9jut/8Cahhx6M2sz/axXSFJ
qzpSjpXvn7WJAyQ3mPpF9YL2qIp+Htl2kXUfCJ0DZC6/ZRJ7q8dtRWYvWiFUU7QFauxsO5AZrZq/
Sl6Q+w7AhvD4yHI5rc4siL8iRPmBczhwfp3Hr7PBJB1OB4aIgPPNLdNspUzwCM3DlNE/iszGiegT
hwALIMzTYIYXj8x4nCs2V3ZaaahdRIt2b/xjUubMTqRKRb4fiE3OzpiQRsDB8jAgsLYpujcZPuvM
nw/+DE1JethAOIADULZAt96jDro3EImeSOLhJuKrOsTQyeu0pXGp148Kdm6LiKl2a38qB2w6kPO0
MgT066S90ERLGNgepqq5VC3yvCWUntUY8OHCSDHPC6MNeQ7duKJK9z7Icte+WGTu1a1I6owUUyeU
NxLEJ7e4eoabHkuPDr2WXCiRsrgzkawssd22BlHxVFr+iAysPSlTV0ndX/uXZdLCxaMMVFrNZicl
/LIHpzYqB4BTfGQ9Ix46sdK2fzYxb180MjHrliDjmbc6azrA5Or+NSxNMNMd2PYyTWOXz41lkyqH
/wWiDjFPpdxqE3Md6u0dVHg2jNka3MsBxQh7q8ddHe7md8WGgdApFPvz/kGMuZ5QqWHNiU3fg3Yk
dKNJGR0Dcs+bIriWSD4HLfXAt2dxE/v3U8X0Mu7bMSsMZYcNyOpoPlUDYpwVkO7r7sJZSeH3QNdw
OTV9ALVyEvjNjPlDE5zfN5IhT0Lc/1SRyxb2D5bhkfX8hwNZYmKGJY8sJ+KezNgr61zJkHy6n0n3
kAuqLfZj/rTdge/cJBD7vmR0v0T/Ik6Wn1WIE0nFl7DH0QClCORhikmGL2DGyqgwDF+Dr2i57IOU
larb9UfTj4jFt4QEGN01B8iTXYTw1DGuYniSO5rf/26bojdNmpMlOw7SoYZNwxizoGHHwkhg4Cgm
xJ7jfN1m8Ms1EOcm2gMCNcqbWyu0ohJOjzgrHfW0gkjVeSZXdwA2PoWkPnOLahTR2x63Tx6QOTz3
QmcO0gPUOC1byQxuExtkPL8rDlPcdUnCDIT967RrFmBT/70PbvyPu9LUJtiR7Ob4p2dFww05c0PM
4s9Vh3aHlQNejGcuSCvQ/yXgUZSsZ1PLNqLN4aV6PW8ehjU68unPBmxOVwvpOzfWwWW7nLPiIt3N
FSRp1Kb2rgMp2k8b+JAjz345V50ENMuVqr9Lxt4vm8d+d0H2HiOGDPaEKZasKwjFbZ2vToAHqmba
8esIED9gHkP8k9p/uL+mWHxo11fiMYU26Ry43T7A2Cn3S9pbcXjDlXumf9IRJ+1hSnUItZQHLQiR
VvDGq8x/8RCqnJ3x5feG++byNxfn/mIbMJ1hp7ty++sryMYNKvJ1lRZ5IexHjF42qi6hiUxpFL3c
XGYRRNY48aOqqa+Gx6wFOwW3BuYAqXFAP8ZxWbJthVFUMkVTQmw3nHk4VsdQnwtWfBaYbkZ/Vy31
tw2Mo7xr5FoXPRCwAS1fcL4sFyF1TejWYU0pkmpEvJy5pg1jUHBM5Io2GjFuTK4CVy/XtFjnrEFa
OnLmfE4zMsymcOO6IWp7vrgkRYgbKp4jo2wAC1KBBryeY6fsuDZIONC5/qsxl7dZIsDwtEmmcfX5
olhoD2SS/iRSyABJBQP/kMJWbwqu9CzEhFDpZf3rc54jNd9dbbyh0eb2JU87Ow7aaTp9KNOFw21S
S1ipQxt/NLMhcNm+tZDDHMBTtL/GahkjM5Q0LdYYyKyWoQuEbrMC9QjMFwwCX0VEPcjSQ9JV89gl
qRa4aR55/ifyUllTq/IxljmJzjV0qzPQRUu4bYPPTqT2af2yRgnt/+C3cWPHe9jo4FXOk+Hap4cR
qhppWqqfHrOhGVIfwYp0ZOa4VVwKxlr8FiEMlhum6Q866GanVRmkjmN4qJAxJbqcINZ/km1uzB5K
VpSrqzJ1XQIS5vmPv5yEx0s5xGvkkcpr0I+fM3UVv7XX7krbUlbyUOzxfB1DOmdtnhWYSbgM+2EZ
SuVB+fjQovB14Ai07wJC8bXoS24HwoYiWSofbVkCwCEjovlC1jLanhpRMo/Pxez2+/5vlUtIdtxK
mTCa+436Be0zoxQWVNdhnvWCHqNH6J/DEN5tjVtH5GNSigsgMHUKiANk8HSctGI3YxOwRcfoOtIf
jYGi6gW/SVIQjRXlcPldO5YmFuZxblCgYdtVncQ0yW+7UJL8DnpQyXAcvxNO4CVMlQ9WcAcRMwuu
JflNfHjMhh9so18nOC6E2sx+L9WcH88Nogg1PHrVARui4vEg/TZW7A5W+vacVjHOouJc7KPI8TsW
CeqNe1eAiLxkxxdmU1JiYMPVfi11yAm35WW3VHZv91fQ8UeuBUoJmeTlYmN69dsVEgM9Gkn6vEyu
tpP7vocG8TkydSL279IJdlzF5PFcE9K4Js8hnc5bLmcu5M0cQPHVwQQ2B5uDKxyAWhFHm4DKdNFT
wPvuK8sRNInHJVp37Yd4m6K/xcIn+bnWxY27Zz1kvXyJ/DuaegybcymrsdF2BpLkZIh9Oa/oghsZ
SViji5I8+feRQ3frcjinESabbTUdHnfUtvvFc1DRdGffAKDwkPUywttjzhSLL2i/EDd4D54cToK5
caQoKfY5M8JdFKx206Hn2uZRbFri5X0uQzx30LjzlxbU6VV2UJDtbEk6Mr0nIEyUCHHFfDCTSskJ
WC3UUqtbB0X9j5zoHeJDOhHl+KYxJsgVD1APbrEjkrN/7nQir97ceVsJL1n7+NtYXu7KmaTOgl+L
qImDFTxvX65h1G4z25gbPa3xr/ApYm5rO7xjqChP6ZXM3ny+xn596fiZv4E1JogPBhE90sZi7Ldr
pAK24Q8giepzxyESNM5D8ZXq+i+Rl+lNjiJTN6juIUcvX1nTE4/hKgufM0ty4dKZvmdIxh8K9+Jj
dVod2NF/dgkz+CSfWUGq3T8jytds17UyEQlISlH9oYDp7vfVaWHOggyOMYRhFX5o7PLXXcs2OtPM
FTib8/+CKIn8kDUz+q3cRSY8WvxNiKirc/HEGsHjv3hnPen1XBZaWN8VKBbQHEuEQ6/SRJjNQz3T
/7sRGSlwxtNIUDOS5kN/ERbFwaIagvvTZ9DKX/sJP38YYfhNDhdgMOz5/wLYtDnTsXQC4VhXhUjX
v4+IYTvxB3y8zRgVFLPBSt2r1Yb0wrLbyfXN2qwhvc9gUKjABK81BsFy0OYLgraxklytcA8H77pn
ylUW0IQfFupN0AqYg31VLoBXiYgofP1/jW1wzHFfxcZDKB511r1HUTtlM9q7L2lA8PJHFouNjcnN
b9k3gOiLouJTNpcFcjSot85u1J/cSq54D4K57BUni2WY02nken+39LTXAKGk/0qkAQYcCMs7g91g
b5lWWTe+tfwtCOFkA+VrzjFScji70JYQ+JeUXyl1Uv+Xt5uiN2nhiR2XiAbIP71vb+qf9yg42ua4
0ovst2FMuOrocCrG9cc4HBbTYnshZBe1Fvl2AHgYGGpbRAcTObaeP9Z7BIsA80l1WwH9CL74vyEp
bgXnXoOJND1W1dfiQSADteV+B0FoUMKvf1A+lqN9mz6b34BAJRpf0vXOjUA92tTPniypJiTAeQwZ
QHBtHaSnUN3sL18YO8obQvEsjF6qQxbnagMqXUpXEBchUiIaGf4PEM6uIt89jfpzNzrPhiAbK/gQ
dMgAvlc0DNsDzzOZPWLbB1MgbzWXZ4zjsfIGwRDgf55TAQYrXuSxRN5bnpIfw62hub6wYd0gZqBq
TH+ZNN9vdVU89MGX7OpRn7cyEDicf9J8Ftufy9dOqGNMfATaIHjRSQAjHmSrtpPzIx/zSq61OXxV
SZvBboPQeGo0bwhS7TdQH5LrVX8h9HdZ11dmSDSSGS/pUcIz+EOriWTVP6tsAc26O/vtqq2VOFq6
s2WsXz7ajB3CL5SAmVOHn5e75Z/3XkA+1b5DmIlsqrOOchWVoy9DnxqA9+xJJmOG8lQhia0YN4b+
Pjvh5ch8BLLyDCb648IJZVbS93vyvRrJqGWFjLwkO+qm91sgc/4mDwbDrZlZaY320fLLfF1Pgal/
aOjJv9/VVd3xTEgulwmd7RrQ34hvr1wGZSg2kDePEGqBmQUoXBh84/TTEL7ej0FjE7VO8nLDzDtw
WNkH3dDEPpdm3TLmVRhjOyLSt45klN4sT37+7IJkEpw0fjlYstp2UAuWxSC+81qSZv+uJHdshng9
HTlUCEjkLWmoOXyO/nvdr/zh89Zdfkt7cav2PpPamyaZrR9BnhVLci37jQnkRnnpkFlwAEIzbVdd
crtFtqIUYiuY9CXRGRfFzFbocTeI0ebtJg5Dtbi3y68MjRvpC5BS7NWveLmJsWWJRMk5IsGRAvYJ
Gxgaq8y2fLHNNZz29NBhEYpdh9c4KIumTgbC4SFUEvsHNB/G91HkGJ2oDPI0OHoyjZRWpOHOw/V6
qYqbeqSC+Fi6uKwU2Bgg+GA1t2fAVFeW+ICSFkSDuHzuzPpb2VKmUPQrqF1g1yHml3s0+/TChA6N
XTkkf66DAQyueY7G6/bS17Ununf4hjzZiUFptyMFXv/wa6XJxjZiY0Qwzp3Sx0cNTwIZU/K851g7
cgCz3gd3kDEiFwA068p/4rLN+ibaZg1ruKdiKCfbxAd70gI02WdY7FGTinS32RMK6U/dA8cHx10x
MWma+73TNRqJui73dmBGCKx6pM3np0CKksVa9GMPHpIfUOe1lg564DtnnOQZzmrU+OFgQ7qtTrCJ
6iCGU9Y6zthFM5gNdtVVYg3DjJN47bb8pxyrMLdZ/LGFa+etGpBISv44OOFlsTHcQL5g4Y5GdpQJ
bHZjLpK/8XDqAcYA9HIKe4yk0B4SQK7PQ04PhBU+6URSZZcnVmA0He9v/udkU+FBl8u1gu6e6Us1
lpvzzAgO59/6dP3uM8RZKC85r2gy2EO7VhQAnuTURdASlKBnHRLLdV0lqIFVJnyxFj9yXNCQVhRK
qtsQX9OqIRYPdXn4pTo7B6lD3ncvny/ywfeoA8+i0H+K3Yz/lJ0kRE+nI6+wwXs7IoCXox1u7UEE
93DhtYFjY/TtTiZDFUMVdbAfJHuvy/yxg6/gxAu1Vost4al/GjyvpQMGR09tua3OCmMNqV843vpc
kUHURx02CjHJzeEWcMMo8uATtflm+z7QnLddAfC75XGcNilYR2zkEP1c1+ULlylUOAe8PSakPTLJ
Sr2aYdwYmIZPz0atl5eNwpLyeq8pqHHEY1Al0nV8CNn8PMcbwM1g6LhHG+FCsz1y3Kdjf8od/Zky
/6uK2crG9aZkCUaQzg5BzCxfoynKvXgDRLz8zt2ez5tK7D3IpSdAbiZbDoPg+YDWvB6hILAmqwVU
bdVPPBXHYEEOWchHjxq6jg+2xsT5c90Sz+OjbfOLvSpA0vCKK64zblHDhM+o7mX+dvTSg8qP3UTG
s2EVf587BlyZhcE4WIzMdaN/+3suz3sx0THdM806JoMARW4HGvhuE1E4ldfutvNYyWawyUFx8PZv
RbLh5U7+6XdbIu65PoANa8DeRuHBw6zg3d7negoLM+YRqxVKwSxUdHMmx5qjhS6eradJ6zHO1WD7
KIqTCDmlUGqzKvGI3kgBnYaNUo2n3tVhcL6gPAzOnIp8MPhyHAMZQA6NIKAx/oLdAvY3acyhXuJl
f8641Cz+B3zzfl4CI+iJazWaLItFCoUu8sRmQvklHD0f2L5tJYRZEKpdx3Wx/sCa3+9cDLy4+02t
LN2Mmibc5RbCHUcmO4iz8mVOs0xEN24+kqbc9r7rZUXOtQ5ectD+zzjlHXDON8JnsbV7EY0jrD9Y
VxeuKXt4RdadxICDQWJC1gNI1mf8n+YtrOCg8d+ns1tz60Br9XqjwVgaYQXJqQ5a5iiOjtNoPz/0
BVSKAX3UxQssnmgqjcJvostkm6mTSfChgcMnXLtJR8BMpPQuqigIkV2pvOd+OGP9N35zcOG4CHJ4
bGw0ppcjDy9c1H/e5cgw1Ejj8+JTgbWX9Jy=