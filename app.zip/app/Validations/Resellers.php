<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/+6n2fQlcEldKSkltcnTqJTb4XjBFQUkkmp3GIIrsYjbkn5TVUX5NKYYnt7rA0X5AgZx5g3
nKXNVmtegfbaB1aJ5QgJ8SerSgy1yLHDmIzMPY0Sq0G+I+GN1c1PwWWmHSBCeEPkyNl+451YCwg/
tju6mN4fr8XbOwGQ8zpI7gHKZWa12FQdlbakkSxxg5uU2DvbjssayY56BjFi3fv91NtK8HDZQXNG
VSpOH0bcEBaLykPkG5Tn5mXolCjeU8dweDW/BipyrsaDFVQ8rD9GTXw3bHFcc6NuGewcQOfn9e30
crEJi4hyHiq77UNERTvEN+lEUH6m/hhd5oad7zJV9Jf9QtcaOFFFf9QrjxzEtW4+uAKG4KyjuN2L
2mIDpFzep7diWnd3VohJt3sMNnYPJRYYWfZKzK8at0U7hAcJr6ByJ/bdxpcCymalgVTCMWWj9LrL
eCIinnWw48tNLsTewVCe3/j6IE1Gc5lEUNTd95cWuJhfIagT7/f7xRvcEwVY7X4YOeRD/1ZRvB4H
JnakDMsykoGFmh5HZaXNsrES2D4+XFd8j67t3HTeM+tMeiecqjd5Hez4gQvqQKRYNKjQTum5kFDG
2aOq5pxnreAIb4bEOggT8KoJPIdOgHJsH4JIOqa/YZP/0WuPCjMVIYj2rT4irpOoGXe/M/cPrRb5
Gq3rl6anW/Nl1Pd9h7Okc1xyTm5lCzhHWN/AWu7g1XvSCPVWsUCMhdfQBec3UKYc3Iusa1g22w/B
KYEWk0FdV+4UZp8wq4Gs3IJ4BMx8VbBE2KwxHzT5pCWKdGNVD+LBYkSrcz5YqTlNaXwyHQv6OmbM
6BHQzLroTbyaOstjRp942wTWBZxemqXRQU6xSUBXsCly6udKXrAiEHgHbBrLkfr8VWVMOEVxkSi1
cAGg55F0UTEnb+r7tyY5cl0sgFCof6EIGYCf9g6iAEsD3hmwJ2XfmLgX2sygETHAuG5TWG3FKJQN
W1vjOobM0ifx6AHs/sf0uW47eMNgELnbV/TltGjA/y8sCKYDsQO/7X469CBFoXouQqIC+lNi5Yj8
8Vg49moBHLHZAB20A69tTh4A7R/D5hSS0WTBubpT2q2NTK0dqqIaPc+AliFhkb+1m1Dk98O/EZLa
ll4pv2r2d1BTj0jANofxY42GZRWGsrnYiPpL4d2cxhraCYYd2GN6ZhxnjH/PvQTFXI1aZbzL91M8
qNPc07eYVJ/JwNJFVOKhC5WjH4O2d7R51Ung5UD5NvkNSNCc++m9Z/z3RL9OwO2b3CRv6x7cYaZ9
LIAB03dypctINreVSsb5aXBG5Wgx4QHa6bLEfH7Jql2Cn5z+Nq4Um6x/2LfYKw08Cxprsmr2BUxu
xj0Fjo72Rho/XP7ZOtdXgyWZX9WSymeiAOrt8Vm7CVS9GILxidd7huY4IaQC+Rgv7C+aOezVApVm
GI+EmPKSrvHka0s8jOMvnAiGUC4+lg1LlSORbSmKtSHB1lROMvZuTtoM4JFN/dyJGig6nl3L0yMc
vw4OonzlxyDnIscK07rZEtmsxXasgNRx/F2WIiTE9tCksT8ljYeBsn1tMFdHndBiHUbkE02Sk35x
Qus7wGFYRb/WASjTVHr8ql/rrHo0ubgFxxx0JPqh/eLv5wr8CWuNo2UslqtO7LA+C7WzVqtXNGio
LVp/9rUMvy7CT1NV824uVLIC869dB2yewdJ24IjUqZPllbXsnhvswgtYh9w2Nas0GZaFPfV82PLb
8cAnp9t5HT+2cKeSjdj24QH4FgLV63dPVFmbH9nVfu2Ezsuneus+y8NxsZOzsViUJdMPCmBduCXJ
EtB0Q2BygBVSPnMjiKNKMpCeE+yiGdUXwCRBZ4cQL5Pt1mUkG39hIbM9gN2eiTJLHlUyrkSSIl7d
O9mbmcugR1LwiTKeLUW8wm0HHDzwkUOnSA4RpmichwMo9Akl945cWoeDvF6Kw/vhwGec6t4TewNF
3hVnoM0UzTT4mDdRnCQhAcQs+uN9oRcYd5r45cdWRvptA6bAffVOtxcxLCH5HMxPus10/n7m5Qru
Y9RRZPrNaxg5E/LcBAf5RQzVAfvS0scLbvHYjmmRj9odjU4iE+NxwotEVGx1y99Bog7F76CZU8N2
NoQZz9NGyPy0z2yBxMAQ6b7RseeZJk3zQdbb5OdAZXY2MypNp8feTsNDx5rH0PnOQApKvUM3RZRs
b8+cvLk9AHmKgNYVKRmsKhzV+1ipoK8UuSLHo/WY2KNWWOc1NvXi+/aQAreJXLcT151uYCHx55D+
oUHjY94eKhMD5g5JNes9706HGA4I1RAHQtNj3gvFoxFMQyBJUMQBLuSSwzNIK81B7E4bzTxBbJ0R
jIfDpwjsbuiQasl7pMwgWx+nAdAHwaVvI/o5o9QY5z50ABeqFUiB+0UQOojkluMMmsq3p7zqKH9q
k7aJ1j52uTw2LSGG5MKQvlyiMhlTG8Oz2oircdcYreiJPKBNj0LzxRSEUCy/e38+Bdf9ALhrYwGj
3P/JOjc8LY3lp9F15v0wZrKzy2ySP2qMU8CnqWPAhR1sG9+aNDX9XZJFQk/B12s+CPhvCFxd7tqM
DXeA4w1LkLpYZzVuPTxIg3bsZ7zaxO39gRE78swbnx4F/6iUmfV7lw7C8ZsAxvQiLIO6rsVpdZUV
F/aYhmKU/u0cZ4aiKucnt/ygsnZvvwnv3+ta4Yie0DnlCPGSxpPBQPPjwM0VXrb/1RWg2wf0BGDD
NT6Dcc50JACJHY42TQhdTCTVz3YeQrPQdKOGmz2xxSHh5mV58loMrysvdFoD1ZDfeXrr+H658B5Q
R3IPdqJiE+RvdkptD85T5BfLd/3nXRAKJO0XlXlKqyjTHWMyE/rTGYuBllHRqr7n6ok4IDH6NYhX
BfDpHydAdbhF3CkF/JGEHaQXChtd9ZDiSxzUxJEhKx2un1eO1rMfPxKOwxU8k2oQKXhyGsVhsxEf
6Qe+hPx4hr8azHlNswr0gbj8ll0rQCOUSBEWY7CFpoKcEuMLvb/V89m7YleMOWJyxSU2wPdVfsoW
vfax4AF3dMs1dh/zGH8J/MG42r92E/PNFadFgUg3UNPI/mYYMu8nGWHesgckZOMFM5SRClc2tcQp
vvGND+fP72GLsIbnUsaMy2QUL+Kq/4+Kq8vD9dGMDc7T2orG7xBQtPgHWgpeq1q85X/k+kmm5oTW
2HSCHiT+xX5NMRHekfYj2IN/u124yMgA01Gnp2TW8ocVARoidAOkNfLyALdjSnFTH+rJv/meMAFJ
5nM6R+0WDNTfXuFz4tjuTA3h4FVfCoknbmlDmUToDnf5QjBM3l74QLHj8xhqULZsqeCRJ3YCDpS+
VbNIVjLVzrDtrDqLN0atfZaHrTT5aRmthYtSMZGW6d3hT/cdYV4HeyPqJSA4sr57RLuPS5dbqKOb
ID73QYHLhQhZFNtZniPIVTzq+Rf6Yeh8X0jsZXClfIT20tdBx+GrEhrN0LVttsa714xkRGAJOple
Uq9yv8936Bp4swWus3Ah1E1vMyZ+vdZTHyYTcDPcJuwe1OGh0Y9GKnvhR1TPk0RZbmpb9Au52JOa
CGL1ItFbqr0LgTIkAoytWW82Xa9ZhLFVuP44EVqneKaD6uiUPQfBhCQrTe04dGcMorJs/YMQAY+V
14UacqqbAeq25GQ/CIct5JaFOTajK0sa/2cvs8FcsN8sPOa93QcVqpLnP66uMlXEXDCQTmko3JbQ
9gLddqR22kexhUH3CX83Gb7lJ9uPBeWoUVrL4MQsNYivVPkSGptJLF+PzwmXZjSddEhBifmNxiht
BlzZbURS2k6xV9FPALsa1ezbXZJMj7rgw6urRosMCcIzJsw1dVOhrraIliy473wjNAPh/KKnygpP
KVHhiM7PNEwaTZ7wuVXwER985nbBMNkrj2ph/AsMLlXRUvVwHBzICmCfIoLejedGe8mKUSoILK6I
p+NaYmZSMABopetExUZLKRne4vMEvhV/mEcPWPSco5Ra8LJgmoOd/Gfneu3KidamwHZRQUgLSHHH
BUO/P4ifpnTpMaEI3dAfdU27rNdbOKt5dZyHpZLxvcKioJlabfuNsqOlayS0ClE+kgAMPGWAif4P
rCBB2olbEKZOl/e3/zHdr8MaCQLloVKVkU42dv+J545aL6ddluJpeG2Rih1EtSewDXCTMfJKBJ2G
f/KHEL0udY4qR6/tawrSEWuwwBsoSFqMZD5MoB71OqAuSwpnkvuOESTnKbjhRaKNT9ManxH7Qm/s
ESAYBd0SeBdPtyMNrHb36/P26tRMHstDzhzjNpc0TkFeAfm25RY4MXjvdtHs9C26+KhzdUQ5Djej
FqUmd3jYQoZOqNkRsQl8mKstUn2KQaAc7L/k6T6UVwwHVBiAjLvbuqJ6Fp6/5jSORQExDeUvDciQ
IFxJoD87jU4/LZVZviCHNPIGppfsm2TyXuM6NKjbJ8InbrWWcMASlo9TkrQfkmKYgy0qJwri4Ku6
3SP7QPbNtnEvKy2sMvCzXw03Bvv9wsSjXfxkPuQo/dQDJik+P/lIkMEzbiHTiSP99PvOjrNtEuYY
ugWDdl/XChcfrU5B3WzJMLJR42DVWXir1Om1NVcJbLDHcq6vM6qvT8BviXjDSduGzFbzT1v8uYdh
d275GEAL92uHrVlmOk8zUgljhar3sT0xcbe9ifPky9eRN564SWGOxpjQ7FXhclMKWnxKkzTYpyjo
4f1z7TujBEoGpJ+4gCXytzEcUJvNE5Jdk+P3C4UhVIpl/1Hy9JfwUJuV6el4ZvLqvCrDEkapTrQD
KkoCUsYCdC01NeLgmkJO/IMT13fp58b82f5BHIqRmjnoUXlg84kF5PhJRBADtbJpKbPb3VdF0sxJ
A2YgfE3m2NqXjLEkaLldq82WwkGIX74o9YTy8j9RX/NRZb45AuK1I11VgWBG65T/4eFPp+9dn77e
Kg8D4zTdafDu2g12xaG+OAiZxYoOYXoIYJC5kTk/72VYVXM+UYOU7iUMamIfypLm/XKBDjErtrEB
nGuTxUBiCq2xQ3UnJfaYWqFse6FnrQyQ2Bf0AulwBCQC9RdJ/pXn8aUT7WoJHWe3YuhNynctm8hV
kyZ8E3WOOzhfRvt2JyeIMS1Ru4pP8PIGl7ehFRX0ictfEQ2xqkmTxqQuh7K5nkhuXjg1lkCpbfKN
Q7KhnuMTtA27D7dXMk1mKdelMkAdO8UAZDqftRngrPXrWzBvbOClZXPGEf0kDiwPfkGjEUW3JK7i
Q8uDN90Oev15UJBu4gVx2Vqetw7sPTTyFxRBxTiWHjatYXf/+bI6TtvBXectgfY/bySGbZNtVTqO
nKmkrSc/Y6M3mdWmMHc2uKx3H9ZktNnghpRdUIoBIesERorMl5kEudknfTFXQ0MheYITcnWO25/x
M1AUIMdYbP2QsZK1t823Xxjc4h8zzKcVk0X9OzZBQkoNvj08mcyW2w1rB1wws8UPo3PRPfIn0INz
FfLaTbwu5h/MAmAv78T4p4SLELTWw4Ab/HRoCzPQRpeV7FzkKsW1FQXGyDxOj3X0mjO8s9P+Ck6I
1pSIa+7xMveMKz/kzKt95SFrUgaJggmcZPnq3ZZ9aEGK4Gw8xn8ZsPYXaNDnTGvRYAfP2T9Qekrd
SFATHAWWAzZZ9qDOQUpaoaKXzZRXgTaJrSzys+XshMEDAsokfzrofmVWOsZ2XOyePmMhLjqhZ8fa
z7EmonGSIrEwN7txzXSfhaMpkI5apTidvpzL/8qCq1rMc87+3b5E48YyH2CBxg3CdCI5wixR8JRR
KL6cSK9Fe3BX7eVtzhdU8bCcwQeivztQUhHMDFyM1gkT774QB5XpokQLeYH8J6rEPib2xV85wMm+
6v0He/Ih7//BYBHjznXEJsCw7j27+LMJg8a0lQI3eEcweeiulw2kDapdpj29Dn8saapbcVD34TWe
Y7CL39Kfo/ro1mUgt09UjDnonEIlhzpgM8i0OELSlhULYbasfTx5+gjrPSGcNhRB8E/LaGmLpc7w
PiGg60POi8gMyTiaehgfPib6S9xEOuN8eWZNQDSDUGJRQpQWe9eofm0ze5wRQIhdXGbtL0pGIi8M
e/JlB2invAK6/HtLqh1SE8cJT2rG6iXRZkX81jWPzaXTPL/qcjl6DnAAtT91THu7/MzXD7RcFh0T
TVzdvgd/rTf1YDZjD4g34cRyxZD4IcQ1PucI0axj2eQgHXH0SiDe4k3g5qn2++kqbfUVznA1qgFc
xof61tNVhx5PGaehwrk7vLsXAPgkwPsY6s89tu8l3mc56Mvj3hEBMJO4LWgTKN01D+DzMyxdkPgW
+O+najdoA2RZHVVK7ge+vgImS2l8yDgwoCJ3kBXYtMr92LINre3lDepazleoCe+xV6PRagSBytyZ
0LXWXmFuSojHdP1UuV04OaqAVFAFP17qsOMTaAgzI/frTRb/uwDIFa5kMg6ZGx2TW1siLCbkiVSw
pK2BWeLjVNsEjIr5jdnoNEqiox3l+hGVlvAN68PS7Hz+mdMrXutRlZH0q9z6/mFr06IxB3O6RlOR
tzWTgfa2mfQ78N//wRaUU4oq12JYUhzMaOyQMjhxrV6Wgu+YVSuP7e8PBhmJVC4BNfgYDYbEYALq
nox8tW+0/PUjR7FtkxgpR+aifvDPIdLIIruVB5V6Gu3dOrXGMy2scwlY7QFJAXQlA10YeWypDJdW
UxGQBprClxIRhyuT8w5IqQZxtIUSFH2iyf6zY67dr7IghymgRffMqwCV6Q9jlE6Wi55qap6jV1Lw
LxFOq0q/uQSPeR2lcZFRlcH9uUnGIdNLgL/ei5rUMgE06HTsyJLbBE/S6+XeAXLAUkRZjqDikiCi
viqdjsiGwm0ab6GR086uGHHiUKDBFepSc5dj3xGGuVLE9gA4IwYqP/yWoX43ynF8qdWJ8X9PTfD+
3/hYhnuSAkaa+/1P5ZhQ00OGLAdcBfmIqCRYH2rPPjAIYfsfORgfl8cwrEgO+T0CMIIndN8RC7gd
ybF7yRHK+Hffb9roA5YQcc+FOl9CmSg+EDOAYmnMvMB0H2E6eN6YBf4OI4UrmdT/8UygU+WahsU5
U2YveJ1bRtZBTl7/AWhhYFIB4UV2rUVErR2oKXSiu7VJ2OKAqyzRwClW3jKdPcCIolmwa5+oD0G9
3tI2QYO4yYHbgoHtfsK8PhtsX4CVpFJqDbd5iVi6Ivq5E7hAfyyN9VAyTuTLUREaNeKQ1B/HGb4f
VMGjLKT9zJtq4CvV/pWD0pCvsaYnDuK8/6COnQhSE+l5YX/hq1Zf6Yp0aXQ2eTIDmMCfvQM+73zS
c4OAclnoXsuO6o0C3aukl1H8ZtfMDww9wMGnz5TMX0+wg7/mNg21fFQ/mkK4/5AzBzRmSANPeFO1
917+kxxDQ0ahZWVMPCg9rspMT/b0ZxDvTS+Bpa7sl2OYpUpg/A+JDyHlMgy+ROJip4d/ndeeadDR
WgM/kMlleC2Fx7pPK9vy1EirYzhNf1s1J0AAxX6SJ8+iWhv15TRDIQkjHoV8Kj6fybKtSQQndzvt
0dVR8CFtKAeElpyPa1/tKXH+9sgVIOn+PwSQopg1/6HC0m61aY45U2HbvN4+uwCWAo5Y9aCDhWYY
WrfYw7ms9jnRCsi7stdd/Hh/cTJBYGwclIn3n6I/BRq84E+YwxlWrX383gkvVKyAgY6M1KCILOiw
Uq77pj0TPAfkbPNy+q6gBBV6L1qhftA8DCTsAOg4MGAPj9fnlmLPJQ2QyL+kd47bEwHY13cU3hKj
ui3OAaREmvDZm29P9XtBLkN6wTA68mPQJHQRWXC4v1+SARoJXszOjzaOaYMtMt9j/mFbKIitdAtj
A+9Dl0NMEXrMnwHb2b5DOjmXXUSpDZzOyv6RdgnwDkiX47Y0+vxUEzCnI0miXbeacTN6aSEcVtXg
GqUcB828K+b7mXfroEcMUV+h66hB9QZukPs7+uP+aBPToURNYfCsP5x2lhjpkS/1bWRWTB9bRzMJ
Bz5wHxfT5O7EmaLA0cWFGqJL+iHB6tijYQHna64LbOZadElO8CkxtgAwfgjcqzJYP3OxwY+xcOCh
d7+StYTp0yea1EeiU2sv2A06XCwTqpGeAF8HstLhs974PGt6cUpjT1ggef4zebZN6dnPsZVP+edJ
kfqgQNA6Zp8YiDo7WORfWNE4yTs0eONoNSTY2SNyld59a20DyxQa426EuTc3GA5IeZS0GxWf5qJI
HwvugJuNgns7xi54nuKBaKsSC3FGIjQuUqn0q7MtMI1QXHPLoc/T9+ae2XbEzJvZ8BkNu4NZwNIu
wSjsFHu4vTUAicE6fa8QkGVckU+SUHoxYfrq9jZc09llsYg0pimZm5a2rOL0/2iMy7ZA/kIu3I6o
lSuv4KBJtWhIzlKlml8elNOVz8e20D3FMj4WZPxLXo9r2inoYtwJtjrzsCaXHyNxgtlHGp7L7rii
qtgw4Vp11BVLJBMPNBTbbyKbjT5xEyIYPohJRP6U8CcwHTolAnO26XB0MADJ5F+HEYTBVQ9pVkok
7T49o+oq2pyt5fvOPgq1KdoMM6GXXxwvgqxhE4NDEKxX9czRNc81nKAq1oh2xZu7sEk45Kb+ZJxT
bWGr0jfXZaX02HURG/Cd96w7X0h/2aFSVfBK82tbxiz6fneZo1IqhCi5KAE/jbafBLjOc6lMstu0
lsUuqCn9SMh1wKk3iZ0GB/eoOcamwnYp4Zv5rds8QyPttbShufBzZLF1RLm5V5uW3zAHSExzUhCP
e6G+SvhplaiXs10BjSyUejgNDqBGcddrJGv4COVgXUarh/IUduBSd+7klID5qSTvgrKoeba7pdZr
vVUtv4KKybYfKzu/sGU6tc0rY0faAnKuIBxPr/I9iw2c3w3TWfjhyOODtE1rjGGz+cUyYZ4F2Vav
Obtynk5ZBxf4g+m3r7ZKhx+Aa4ywX50vQtSQ0O2hPAW7xXy+IO2xPb6E4CkDbS9V5rb6OHNXeKjI
6enSM6V7E0xxNcRz2eBcL/XWnOZ8rcp53kyO8dZfhaZKnVHlFatyMAhEkjJvepYHkASCzeCHPssK
z1FmIuwQpuALwmURXroAQDo4NAOgFqtoUPSZH5LBaiIUsftuSM8/okC/Zt2iw3krHOa6mWG/LCFe
tieE2srF0OU/tXkJ3mKSuxSk2TfpQbx48qHmK4r6xodDBIJmbHMH1zavQcvxKKUI9AKjON00QQvn
X4TMJo+Ff6TpRMSHU/YbAvYS6/fgGNnJugn9sw2KylUw6gM6pmJL++aaMENtxlaTUozW0b+8kPa5
ffX7+2eES3l3qFCCj+z4OxAhhkOQYlDb8PjiV/pkiRnIJEIz2n34Bbrujjd1DC3sDypODqYaCEpk
X/P8ow+OGAetD2+IICNwfD1rb0CrpeLKqixvmEZXDLBMZS7DD8mg5JuBZLwAYK6hyRzMZjmTuXSM
Cbnsc/wz9TSSyThjb36XYtQi5ToLylowOP59OtYiaM+mW0JttFTU7lECh0D7QnfLGewmPPsnCmL3
tvA1isHCAGL9xijGyBsp3ZCEDLkQcP8BqHe8EG4Ao0LIurcMQ9UpDPb518NY8wE+dHu5D7lcMI3Q
jdQ3hd8t0ZIrPv0DNwnw/0uggs5S//eBLyFTMDFndzKQoyk9r4uxybw4p7fAlcHqoxPDWQLhpJxi
6yVz1XkK54OA9AGLEV+o6gkC7O4NFnSNFlcwxsy15Lz7GWaM054DTQw+5qoA1L22xkrsl99CxP/O
0AdoISJk5pETSVmsUDS9XJq35q97L0Va2QEDLdWh5lgxIy7eNYCV1Z5/BvOJVPHNrLcrqqOxnXQm
rylcZHsFM+JE6QVl/RzO0qvD7A/ecR9MeQ6vRqa4zRM5w/5g8xcIvvl44IlZRKxH3oh9B59/q+X4
GLUEWwhO26XavXlOtL1ArKHLjjAS4wsZoopbc9b5kZFh8Gu=