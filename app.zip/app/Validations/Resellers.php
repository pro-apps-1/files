<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpKZgpYmn2y/JSa+6wbLwbVHLLaGOH0bQRouAKpAHfrALBou/lX5OUpXb6WmUg7puU4Q+q5W
uzBaexV9BwE/pLQzL8+3N4Uua9OtXyMOjidIFPf1hLldDQEPIbvVLogpNi4USRmFpQdoCY/gsqL5
kwIhz4eFMND/V1txXs6DDxJ1c1GFH+FuR2ZWPuY4k/5cRuaCVectGpf7iopdpiKHSLV9+hcx/haC
d8BXSY1zI/ZfxHrsENWn7e/t0heYIAkls8arfnDjqKeZJQJYb92MQiv9HDrh1N9qGPG6fO9+hN6j
Ey9FPJZVgo7PBG5nXkIJVhO43RGdzTg78kWBKwjrJx81A8bZxLXpdaMSr5AaCijSy27btqz3B3xa
Bsj4vKpeYSeAOywat2gUSIiG0yjDUywUtWieEGJGtuobXH8Xn6+EHkFD44s/frarZpr6MFfGYd+x
xLDPA6auDCFcwWtaoq14bsXpsJKkaiixpBuUBOkzUCH+NZesPpeIQsyGexrrKDgHQXdujOyHM1ej
eYd7CUaLhC1j+UX4iAAg65fczCuYr8B9ApY6Ds8pK7+nLsf5gGYWgcHT+eSheQ3kZrLeULrrreSI
MfuJBCYhxhFeLzs5+rDupRUmCewqcYuRWaGw33rbb7noMSMkXYSO8dK9dwr5mPWQXqa4bUSDEmoC
aGCWbw4oLpPkRNzLCWdiMJh5OG4gxrDogGKQb8Pcwzi2jGIvoGSgPn/FSYmqU74Wsd7nhLCVabVF
ZK0XkHwCPvPTbRIjOH36Ue78m7wI5vnUEoZhefJzaV7gqS0TCpJBKVCIoHWAlJbpkB9UhpOYvxup
7P7j7EPD5mOJOaSPMAWKImbeCICnFzK4n5BRCU61Ue1BTaSKq39D9mD48BHiPnB4cqBg0/DAikoy
FUtk4DtqX1AIBZksxOFrHMSTyND2UCbMsnUWB9II9GkeJBspV20ECEZbz8whrzg6d3iz9u8lVT/2
r6vhp/kBWouHx1d4ECn2OjdJHlyDMsDtEQoJyn5VfDG9iR6LPU3EdlwLo88II8HEaTuObsbEqOo+
bt84NK5sTywTSiuEpJ3oKT+CwGTk804vog0Abnno69LAn4E7kMLRkOOIBHBGIzIZTmpnMTGhDXGc
uuWOPdv9txlTHnrfMT8mSZwLi0hHgSYhLBW2FxIWXId/WvxcgAyhA5ovwfxFxte+UKrlp2fgxoky
+kwr04fQFn8gov4X6q2gUEtw759y2IkzWHNbmi17kAfOUgC5foI/vLuGR4IMBkxy9kwiXeNSRKnt
BEHdo86y3FAvCu9D/OhlcfCJbcM3Yz6CKv+oAeUbiDXaBQHUA013Ha18QZwM6q4m4U/uBxxIpaxp
sg9MVXBjMci3aDmuxSYAApdYieQv7DsdOdzr6OXdq0taMKPE9W8Y/ve3d8pfEESrsbOAsSYTdCpB
nGMZngaiftWjfRe4uCoMDPOxyhBx1S78G3wkc3HQmIpqVeHMwWQCDbz4xTpbWosdqXHMe1Ztjrws
gI0oZHpOfbRfo5o0AfXqVRjk2avaWozYU9rISyyxKMpolY2mUUDG9PoIFScVdAIzs4oedXmKG6k3
rXZjdS0HyziaddNKn+ZzGdfm4GfK2LYB7BZPmjMxCmBbusEi5kkeiVUT0Uap0VH/afF/M2FCQU+G
xTw3USPVwfFfDRT80WE4W7rA0i7yNKZ/mdjqOzxuMEyRrGXrez7Q0M169qYEm/JbFKqIieIcBB+y
J5bXDG2NTG8VwHcd/jqsB0IlWtIIJU9SKHHngm90oaGrK9p7324KI0ovvtwmk2qohLlW/TN3ihlH
oBoogJkswKgAPGXieXtVY5rDJfBIfIm7kKOJVQUujQc5JJaoTrwhPkxBUE7QpnV+6S8uPVTFDaIk
V4Hog/yxaLiIgT+uFQjJ118iUDjifH9XOGU0M5TOB0xcuQyjDyGGmS9Romj0Zz4gJgMbaWmkQyCw
QRhUDaGUPeB+AvGTIe13pqJoSTvZRNRNKCJ6rP6yyoUtI1TijWRud+jyRS79M4rwzJ/V6YGZbq9a
0ensqODEleMSbTuCHCv2LyubAoGxkBWUd3u3Tn9Ctz6Q3b7Qy6+8NQOOXmLQRiJJqZbxvX7rhXhH
e1RyHNavjuHB5dXmGmfl+G8Qq6iIrmG8RwXXFkdO8LtHey7BvyEMf5K/h6lDf7pGfx8dWKyDKMzC
PEiQUvonePQdNhIDeQBnf+SurUlzK9hOJN8+lmiTeIHczLy7kSzfCJ86Ju7hqxY++AZcc/1BM2Bi
LzEKfl9zNdjAfO6014U/rqcJdGrzWsL3DUo9gvazxxuNUDOC/N+EJR6ozaBY4CXKXz9QPLm97qkO
Wdr/npJzea4gXJrYxoVVc1J+rSiB6CCjCUOO/tOgQgNWfgghSHnu87ZsME8IWwR1V23URTCODiXO
d44v9ea5zegGL2af+GpVUP8kFi5lv+kXLW06h4j8F+1KlGyg4f0zNf6DMOyom55er88qVtm1/AzE
JT5av7PMw1/C4F6uhqrm7vRDndOJQ+MrKqUHc+l7vkhXje7xTG6n6OGpKSBjPj8GurmpYPSfqwW3
ZOW8Cgs50kRRsTWMXh77rU6X/VbksRv7XQ5bOf99QVorsDTidNGtE2pQfN6EraATnQHgWYKaw/oX
Yhx8xcY5LrQPilGVpdyKgf4ss1hqrmCRGLCAt/RqltGilPHQN6XPQEskNC+lvYCrDhstpeXUApzN
8HIqBw50gEbxBdhnteekDGKOs2WUDu6+YqTVcja3hhlUwXNr/Gec1PM1m5aelOTsxoleZV+MT+4t
lJ+cGvDCELqN2HFWn56X04ScL7lCkxCGrKrg344Mdp01SU2Cn7fC00JmBs2sNoiKxj2CS31im4ZQ
o2o8nSM1sHs1BqCC7wBFDpzozWWRVmAGnYGTnCUk8KSQn10qds3A+bB5kMJ7EZ5srlnXlgoKQq3C
2EL/qJ94KShh7SgbSypfLZJPSsmrnHvYXvgHDZUpTTQbWMy+DScG6l68IOGSOyR8HLQdv5iPHI6q
Ti1zr3gMlivPmdQ4fx/Mj0hHkeiKfnU1XmvzYNP7LewkI//9TEeczKR3j0vidvAE9T19359+6Cvq
XL5/XX+MV6sDlTAd2E/yZRYHQmoPfkGM+iAVG/FQOi9dSZ64Y8FaXtKNxFcGLqSlCjHuZ/YrhyJ4
MTautQuVYzRYk2dNFgj/KE2jRxxQxiY1Fu40j6NUt3BKE8ENvxOKayG6nv6YUFHovy7xoMFPwiyK
UdV0lkYUB+Fzc2/FeEstcacVc/9vbsLXxTV49Qf9CIpq14kBMo3Pj94X5JV/XUK5nMEH2lVoGTj4
fVzX9mQjy2IfOHi9vSFV7zhOH5uQM7HN9sXYW6Xg6phN2S4K/ohqbI3UFMRjXMl0VjI7Wi+/SVeZ
6OIp6a47/r2WXHaNkBZaBiQD7sQHjOI8uGiMb4haj37WI+0/ffZROMUPh+jq4lx72dJl5bwUrNRm
97GoXyBm0kQvlKUJbXQS0RpHtTHylmkwA8XVJOH1flMYdWHNlHC4VU0dlwvhT8aPiKfWwOz/MXAA
6LeMb12M8Hn+6gR1twxfWP0YbkGnG+MyzrIBQvoHfH6vKQphdUVRpsvVbo110a13y/x4/aCl5z4S
hMCYxRg0ZHTFIYoK/a4Arlpy/ZzIY162SzYqLv1gY65hveAjDAFQm7/SYLNWc5w3xz2B/dGDBz7K
bByDaQlVrXCTa+6UjSZH9Mc5XQXDB6ESXhYu9YzlQdjH1JyGlE8CV2pnVE72d3yTKnSKrP+N9xVA
xm1YV30Ywf6heUcX+FB1pO3icjglpyHRpc/DAJFQx/bQkjGgQxIgnZ+ITHlf4Ay8KEKiDrnPfNVD
BWEoemajhhZOhXG2GbkFsQwHlo2JX79+wKCR0uC/VHFvLETWYVe3ECT4+ZPvx8QrBX18KuODhcKk
55WnS/NIvYA/4cYFhZOkO/Ncb4Kb1CVHcrm4YGXlQwFAIPfghi8FO/60fC+lIG0q+hc4Bq9jCWwE
l4A9sY12C5CPQ4M7WnysMbTJA2KS8Dm7yu4fLJQhFsRi9bLGxUoAwfjtMTsm0mMBsiNpZIXBKoL5
Tl/Loxh2HHiBW4D6TlyHhABx62q04osyEDorRzYZPesaRagW/WTy11GwPYHj+4EEfsKEJHaV8hL4
aMxY9gaoeYkodQdctpRE7qT78s9NH/R9GRq9DOSZC9HYFYMaDIZ/ccsrrilF7s2WVttwEa9cpBX9
y973wxhmIBzm8Lsz+9zDpiuFVuG8blQvmHoKUjK+9EtyoO42RwqW77tC92Vpm3A4AJQrjOEEeOqW
t/kZfl5Lf3vPPq8WVNRZdEZvD2LFDExw/WdNeEu2BSpcIq56lz7J8VIXYypXDy5WGnu2OVoPugeD
G6C7Gvuvr/eO1LrxMGCzIy2+GUIWZsb2NBy6Z/5mvYku/t55G4+PNLiW//cdWXorZb3/GkbS4DxT
aouOfNvNWv+gp0QhBa4AeaE4vYU8h/b4YyVtlJOnvFghyT09voDLdwWU83wqAXJAt0c2qhP/obVg
8ZFtTPirqV7l9sNJqEF+TFgsrQXWQu8glNHzvK+sxk11scF5leH4nmL4VQsBs8aqBWGg/HAe+csg
8yvXCosec1sPbtPWCRemfHX3G0GMAjKGl3O7H1w7nAxi9JURGaEufKhAqP/m5jHm2nTakoA7ngPG
IBz5HdkLijAMlE1V0eKL0nNr2Fek5JJzzVAxVl0vNmpmsZu5wGZ0rcBpDoY9Bu+hgkac/Dlp+4sE
vOEZYITXY0n1/ZHtDKOjJsFvfuQh1aRFbLBXNWdPAnE19CTjHtkqTmMeFJ4ZJX2di8W+lMKB1KVk
wUx5XfvkqRIn0Tt/tuKXkRe/tp5K8Z0nX9HSfQpiSIZZpYOGTG2ApM7Yj/Rc/A1rH6c10gsYjAZK
KyOnog9FdyFEmVMFBW1PwFx7r9+X1ntk1JXTqoZeWgDPwAYNb2iRl1kzML6Zt5ecufJK2Wetm377
ccGbBm5M2DAlvrBOc+whoijwej/uEkhIFWjJ4U5zvQj6Mu3QeDdJTHyt12oKb2TPGhK0JlcU1K2Z
dD6Beoib6Wa+Axq6X+xbXxzWCGWHWs2Dcla9j1NyxvcuX7o2wGiODlisJEXDJF/gCPC7ObQY7IgB
E9uIe1pA9MJgzSTrLtQR8l8dqsFDxTjpv5spuo7ElmBwdSYre6BHIA6wHmzWvQQF++AGhUI7yFVz
lcEV1lF+ybMlkDPjEcVK2p18e0eJBDUyhAandOgjroW5ZVcLXpxu7MnR/qsedhd2fC1YsVUY/hN/
IykkTrMYCR9HTs1XYjmtLKrqgTxBT2O1PIMJTqW5R50h4VSWVB33eZat9a1IgHoTOYSDYOxXRa+k
N8Y2RuBkmMGIeRToDE6KKuyvXHaZM7AUgrPPdBswYX90R1cLcQ15k6oX5Burx92icjqpOcGVX7of
mX2MKrozWrRX7xVWzbZKSkHuqkRzJnNNaNQxdy5wHPvtdjQFQ7Gbi4cnw/gD30IefPU1/L4vmgSZ
4ExecQy4SxAz9LXtN1hOxmrStbSiJ/Cn/2fNzhcUa7DsBhD/uvJDE6uEEc4ZikPYMiaiQGVCYD6Y
CcoK+uTjfFe1cIl3qgyRCGsZ1e2c2D75VqGAFUEzllmlMDwwsU2Rs7VXbdJbelXeqE+Yh/UUVbNd
3F0LIUzNzA1qIdSw7RIXtv3EFJeeNDo9Oc+SxZv48HB39mP9pAnBGONsCRkD52Plor3y4IMrp5L0
DPWEI2oKUcEGWwmjK1AMuHIOijYMGDdP4Knx1TTNhnb1oqWO3c6LwHBDEyqhimGFkNX6Weup9YHw
kTCRqDRPTcwYUvZh3hdn3t/ysm/t++wIooa55DxtrFsFFS1JxYIEurm7+IqxCbNtOufH3HO4r3KA
izUoQ0dF+9YmRRZZtoZSCOZ6E00Gqjp3TSqNhB9Pg25SJQM/Top+Ci7f0seuZi1W9D4BGx0hdaDS
i31VQDzI2o7k/QLQ9+vXNl4LU2k+OboMueAZvDZltKW8fkOk+i1PrZNDs3JEN3Us/SMzkJ/SfE+Q
Qr1cWWbTkk63qfc4fJIthMSBMKMuKE9rYhdYEnm0yaI2RkkQOGITvU7NWmL+J1Hviwu64LnMhXbF
SSqLm6Evw5UaiEhgxCrUgsqgepWw0eetLs2eQIq7m0Suqp5o9MyicknvWYBttpUSA+wGPKfYe9w3
qslyuN4AyUKXyPv3fySQeYGlRAt3XkPAC4RjHJbVzJfDVJGY9qVFVWpdopDBLuJmwpWoKbNOKyx8
CkqFhC0gFG2NlosUc3BYgMuaL5/755EYutwK4H23KRiiQ3AA0nueCraljQ3OJZjBqRigyS1d/YTP
7qupeKLsoBSD4aWuko8NLSxNyuTtJT1BpnX4LFMBxGVWdKIrwI9w9IPvfDlOcbjCfshei2sOoPi2
tAWkqAyE5YYq0616CDDI1I0vyAoiR+nInVzyTAOoxRYlsKU2nHF+HQwsrV4Tk+JniPMq5osSf/HF
E7VY36ycKEQEo6jgZXAw28DenRQa2Tj1IQRcAvG1DtwzZ1C7Pqn0NTyBmmngz5PmG7oyCCoQ9Gjy
ZxLC1r23wj0/8egCr3WZZecS2jhldiBUoTXCteJm2U5JzLnLhdSiRCJyyk+ngr13N6+OcKUQpux4
3+oHO6rvNyM42D/dnBxFkpQeX0yGr87Tz2jtik6iyFba7i/zkNn/5gB9t4ySNAzwOufdFX+Uq94m
XD47LBbKu6Uf7kfd2788K0XwusAg2knL/yPmqK7o6En/Zg24w2CgKKii1pyGD/wmKqTcBf2he8cE
Q0mhpaKm6iKCMe+dlaT3onk3upzg2p3GducIlBdgJVo1KFnk5X9Dwh0eqV1JDICMLNTwXNkKe7TR
eX/afmVxiInKKZkyUeDSmJV3XUonZhG7EJHoEXp9SD+j5JJTvlM9JKpfjs/j7zJ3AdbXhFkoUmSg
O9EIVH91+Et1apyblwjbwUx0lnO0VU3wRz4MFpQLGI5GKFZ7ZIDfeECqaNfBqO4oG6S0riPW+tVo
HA3D9qjfItPdznDUpIoIFnWsXnPz1g7zgyAl2gUK4D4L6+LwUxR98D181WGTILQkykJ72up5G4R3
yUrEYU0h9kdiYUiuj4iNcCH6E9F3DvSNZmt4bzar8V83epaXSz6fkOV+SGsmqG5SZGVXGvDNX7l+
y00x+ojnkzgZz/zUWUapkitE7MjkohBgt8fka2zoTSq0aBl8i17D2nUDByqfrGLj79oOYzusgo/q
ihEQXIjZgHW3QElWWaCq5PXNjjB2nVt5Ee9SaRdPNm3iRT7HHZc12p4g/sp1a0k/usKxyQImlC0H
7jcm6W/thjDLQg+LdfqHO0/xsDhoglekxClX/S9IB3g0dIKYlzThZNs/1vwsr0UHpRgJpyAebFo2
E5oB4Trc6vDgDoKMD8KVNM1FowcAwWm17FLA7cwcmzTD96OaxTU+woLak8tSmvk9dfUpROnQLugu
uuUllNwlhmXXoPD+5WAlkdxBdqWExPniyqhUNraKZptvx3G8A0edFTd2XekPzpPDU4+BYY33Od1Q
/sO6VJCxJqzd9tEdT8k8RFDgsOHOrqq+wLHfjfnvKXYCjMD06nhkFrhUecCd3SKI9lCIqevvbDm6
Mymqe5jEiVXd+RXuKFtnXMu/7h18aX4IKO/B54HvCDWocaN8yXOeVWwLtUQiw/dAhhgDD8r5ugaC
g57oiVGwXnCvKwuPeVMgNCDrf8JNBY3f1I0ii3KJ0oDowHNBeDh+ar/U37k5TVF5VObPPNeGqDUZ
ar+h4cCH5cItnxIxM+pQt0vQZZdM3uDxFM1o0Iqhqs0ZczrMMsTiOqInsJOd0u7Qdnc/n6dOODih
5W2bsf9ekjrLVDDF7jkuUmoDt1K6Pvt3cUcWH0J/mJ3LDyUYKNvpLJYB9zbh6VD9YvUKpuh5OGx5
0pT7i7SsZ/RV43s9eYgcVqxNfALxZQ+e2PH98//iY2fgvCKgPCpgg80OCtthHWEFVJ7+sIG8ogmY
8NGMEfkA2U4kRfstliB9b+kwpADTH3BMXN8eKUAQHfiTmEszYFHCBBeMh+Rd8P9UUzjuksgvU9jf
fZ14eQQlkL4jzEMyqRnECzxqDNO1upycgfbyXCO4aXZ2qZza0SJx6tlOSe6XDw3jTC0o6ReaVQ3c
DFdFdnmRfQfKckhHdX5dkVmFYzRt0U3/PR4+eOvBo5EHq+vX7hNbAHN420ou7fwPHkqHK+Wd2nkI
3mVvSWH7lr3gZzy2xOkusyWlAcSNCVjBGLxh62aO5fsRgFXVzorKT2HQR13fdD3tzpYtnxyPdGmX
cRGBJBekGPgy3bIfgA+EJKABGYkGFlackyba3NhyrZyt6KEPZWCjGo8LuF2m10ztQJqEtaZjOfkE
1CdmyBD98GK2S5KxJb5Xm2YrTqpX6SiYOlh/M6NlOP53uAd3J94/w8X4AR1w+18D638Bvn1NN2+f
mZy57PfeVwVIjD7UBaptncIO6OZGEfGRkTSjQbb2yvlHfgukVZXf1ryQiVy8/9Q3HCImD5DVJ0Ah
PmMiTxc8EX4AdBEMPWsNJtwXW3XbsuBvRmddtmn8AaGkYYewvcdqSKuDJDRgq7+8po7ziie0SBBE
0yJEpmDf09adNVcbB0KuBC0AwVIWsPypJv75SzwCdQOmRhuEhKTaN/P7hb2xi3Z3DUCg//qdrw70
KrLcZs7BQzcbzu0pVdTfn37LmUZZ/4LiPBLYMMPQZCdQWZ57P/LHjuVn3Hxx0rKxcn6scpwWqpBR
KILKA46wSzTrs5ph9JZmiZZt8ljz1BvSodkB/fBcoVc+IPllMpuZEdjuT/UwpEXa7XC8QRjMPTRA
ogio+T2mG/OFZRvE71HeS4OKhDSWbNUQfdEpKTAr/rMGf0iP0mkRcdmi6DSEam65aFw3NoSEpu2K
92evCLlMfKnK62xQke36Er+t1Je518bo5/qHKUcH/Vp3qVxIqg7iLW1Rg3KG24bIVYJq3SU/9lYq
XY6rSJVcd/fSuXgFUPOmWPQShM67mMHOfwp/94ukt+6medr07PsY9hsJZH5ReG9pVbfwXJFL57cp
EUC1ZU0SVuvub0ouQkbKlgauiw/IgVG0CXfCd2Ld8ZhwSvgVPYBROgpje7sTbRXfY2IqpAFcar0f
yedtnPKL1MqNs4CAMGYUAvTkB+3nuDvflN0YvgQzsL7o/PKiL7k6bEmeijKntxe1E2Ta3Ykp2Abj
RWgEl7aa+HJjHpDKbhuKRxWt+RMq3S0pPn+OrvxuCtftHAgsS2mFBmA5KCpt/jXdOjGjxaeO23BV
JHzERj7AZdJNr53ATECfQR2f2UE+DsOfeH+ns1CLOshpELm9o+I6waCX6dWNfj4ahgsi5MrNaYQI
piUcMCZe87xxmAMCVdFORdLkEjHBmuBRPAkQtQUZ2upNE877R/fFoPQSt/OBxZVoMjXQ5uESL0pc
QKfO+3KjkkLomkUk+KwTQOcR+U6Of70k0aN4dKJhhmkEvr2oyAxs8+UoXTB/hmvAvKCKbDNLhA3k
DBVdwIw38kOvst2sFvJytwTlZcEGJaOohlptvj0WQk87MiNr1vdHxm+ETbX/yPx/8qUaFGtgcOiG
DnRHrNAVhVLv3lj+6hBrZKPQjvReW6Q02c1QKmsobbO1QqUMbAAJERhk68KwhjSHfIrK0cj3ajfq
JEGaOZv+9qpOAqd236ekwdNuZ87ZVYnHOi9tdgHwfBKYRJQtceIBJL/nlmZLXvboZMdR/AWDdlfi
eS2IqwCL9aAQdR5z+EWt+mpl7nVGrF2qOUGZ45UyRa1diz8J04Iy/uskSpNq/RMXKouv3zkNruMn
g8uFKtF2Xr5Zh6EnvCArHNnIEAiwyAA8M6ZjZAnrlgVk2S/+