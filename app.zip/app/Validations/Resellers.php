<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs1GisjFr0TC5hecIDFc/PPWVK+Dpd50ff2uE8eqx+gpgJWa89uBnW/MvTQ4oAYDe9VT7/c/
zJcx84z3Jn64u8AVeAdB0ECA+IQT37BeD702Gy0wNSRSgeEYV3H6CWshaAE3FVlAd8suvouZSXvG
AVaGfclxR3z/ePF1XyxuQLh4EljXiU0E/sbu/wD+kJWBYjjV8JHC0EvCk26tHiNELZ5WJE8BqJwE
FvKNR9SecfAceHbQe2QZG5NcqV7eY2u2vfR1q6Wd/76Lpb7MaO8rknKwRybfwyRwiMfZmLImgD1Q
IJrU/vMLclRxEk04/52R3viMb1E96G1JdMNMSQSqxGdfm6uKHizF/g9DBuj90C/WnKu9kVUFgR6a
5RdOmCx1+RXXYCkHLVFCa9SCGSVCSmQ2x8lNoYigtI5+jyN/s+8Otlj9a3b5n+yUBhtCa54DmSs0
wYT8QGcY376O7svTNT4uwaJ+vsah7aNam4cO9wuzlMunTWPk0yaLP11iwvxQH3D+tHwEFTlUtYBz
hMngBrHySTOkInTWTZeMyr9j5SHuBvGk1/2is1L7NdlZ87YowR9ZN0gBZrQXwuSqUStOmoAFGobH
5Y081w3crlt3f9RR79Cx3mJ2i3qDpmDm//T2siN1mYl/aYosPFRzK6fP7GTMwyiMSXZhIH7Rv5ZG
Cj9fJjydDy8puAERETDo8KDrybTv3RNXyMHooMj+0YmfK8R0VlIuVSyA+rUx600D6ciYrAPA3qPc
DWPH9UKDBbIOVxb6dgw3Co/YJ0ZY8/4oZAX+0dXLNh/e8uGFerytRZ6Ks6yOs47lZahp9K+hdMlb
OPyWMw5gAjQCby1GdlqoVi4D5uCFRcvIywrNgEUoHk0BxsFFuMY82AgIoJqcpOZRmwqqpgeXs/KP
oH4n6a12p5uj2dg6G6/n8iXLFRH/54uLw/nNYdnDLRM3IaJ5PsHty4iDnMYZMckfpTMa3o7ypBY3
RYJg1SsQq1+p1AJp1//egEXDX4hyhEeNxYgZBsPCefcsdxxepwo4JzJ4s2fL5KgHXlV2gwbLw0Ao
BpYVjaNenF15VR/rGuOm0Bv84ShbdPNvGT+bvw90ApK1wHvE2xjStNWbFiksYSybRjT1R6O8R19w
iItDc6zf2w50SKbhMnMRDEh6DVfqg3eDfYCGeitaNzszmoFvAH6MJFzBr1lnERp0q/9o232J3wfg
NuVMrAy2EY5cBzLB0KJxzlVdyTDYyaELeyFFi0ctk3qmqOJsU6yzXHS3CPh859Pq7s0EFscxf66O
nrgCX3NOD06//is3QujY5YVyEwhrgl/vKvLDeXSo8kivHies/txLUsW4qeFZuc1f4VbLoG+mN1Ly
qlbPXtBXwCEh/Abb3tq380R9ZZRdLKSv2k/DnYDrYbMj9qMfe19WbqVt8iMbezIAxynGJivPx6/e
9r6L0OakzrzvMf+c0DxnOBpM0raF570LF+uAOR9fkMpLuHpCZddxrdDt1BoE+vxtf32l+Oej+46N
mqrxGU9mqNvpbYz4pITIzLx/YzYyxlGF/c5sVNbS0eD4dFCifOnkesEb3PqZ6XcEjcwv0cSbOW4j
bwN4VocIxdUzhAy1do/R9yjDqvFuZRX3aaYHw37BwDBkLlTYtfJkRp//k/sbIY7Sz5XbpZcI/cc8
MPAibEPUf0xBXregfP5S704K4nMjHTDwqkHPCa2yhrMVSNbYYMbvLsa+0upmb7EdQPHSGra5uCXj
QKu3bEubZNKi+INO0WF8tgPbPKwWJMSH/UmjnXBn1ztGsjNi5Bv6cgAiwjcPRvUHv1ZC2Yf8E2Gm
Nk9xYKv1XIGumLXIp+WedtKsNpRxiJDxpOyL2XD3FcPFtoIJxXD+1COKcDpo3fEwsWjFLGcxq5bA
2aPLiWMZrOcF8tTq7UXkWhKt5X9uR0+IQ6vRwQ5M+etC9nWBrfsHGaUElcWpeuPkmM5W1QCLryWK
MXeQkYCpWEsLVW2L0itTl3XzlQ+y1gpC+YjdwPeYXbEzparrV/D0Jlyw+RijtAKumLbELxu4XdfG
/SqFrdHqszRNdPLdJaCsM5ROolOaJB5fDPp7gAbXE1APh98DN3z9jpQ0lhTHg3eUZIF9V9rksOwl
tES/ewzAaMB8NWv6yZlspCAn7XSvZF6I3WgXEBqDDTqPnCN9b1jbBxyd8UrurAOfP8Veynjj/b21
3NGY08hjHOojNBi7yAawoQSz6TDVageVoVA93gotyKa6hZukp50XfE658VN6ofJxsQ/B6LhhAa86
93fw776AW+3DvGjX/KadzSO9pQzw9/VOGQiPTqFkgVR16U5rRDSWEtIcGGa6JVzmEZEzap1Zu1l1
cEkfTKCU22E3PlGG/oReCW3eII5b6yPci7ejelfbRhiRPxBhbDeb9Xl+3rDXmESMvAkpC+qFp6JW
gISkiHXoiz2PBlCIjH9hpk6wphCEFZttk4/78v2ZrCzdVntAXLIUEGNXiGK9ivfLV267SVYUpUpR
9L7bTMJOzDOPUUltAbbCMW/02H2KFuC8tAPr3xClY9JRUlkjsFlhuDWhdQ2etGeDZA/bDjaEXrq2
kSJcWQQcckibA11sD6K5ndBbENcJSPiAqON+vr6ia7pCZi+w57l5ShCHKipqtfgT5nJih3y2gG5v
queqviHKEUR1VNVm8c1j9WWaKD7H5owGqCweflxORXFRTvj575yeS1h/w53+NyXdp1GCqJ43mjFJ
aD97Z4JtS/LNHCjJj+aCmYPcWTu1MDTELDCCEn6SUkOrUOfuOs9GaABSs5DVJ+dqg2q+w21/c0aV
R+2Q/8JNNn5VcvkrACIF5X7cBDDiW9GwdM1LpaJCN1H0MtFf3wT0jFK2tAbb0G3SXyway0nsZCxn
lvNfzROB38tlGl5cIaTN8fPfnRQxbwn/jCH9ldh12XvlB4E0ES/fFgtHSEhOv9Zxyw14/N0ihNPf
f68tVZ61Z4rgxOgkiKK1oPm2LZXYbo0xgqXSTtI99bjAPNftHS4eVw7RIdfmybhTIfH0G+rtMCrs
7xd1+6Ia4UHPLN57KXuPkbxIA5FCCgRd2HOtidvVI7UF0usztKYfolYWE0YI566pHXQ/BQO9VKNl
hPkV6eBBVVqs3t1d7BkyDwFEUafG3FLFlk4EcMY2OENhfq6gqvj7twbfp3ReUAQ3yb8ApCqLHv5w
kYbIBp3hmZjomhoanbbCQI2krZ1SPyNSnDoWW3W0NuSakb1lkUHGjlkmLutVUKefDLv+q8BattxR
n3uRVBG1X+kTkAmOKOVZwNCJzO2MiQu05CW/uC6YYUgAbcwywo1MOlE9OnrAgHXr20f/cNdz8LQ1
O6KiKgkGXcP0qtNTmIVAvbE/Bh3x83iVP/HwOz6dg89Uh6xLgUuYKNZgSPxUHwG+/qfCgaCraEME
h3NovSwqnrRxtqyCE2P41yd7Ym1JQ+mMq/6BHKi2PL0P82cYgxDLTDOrkYXQ02ImsADLzBbIWh1G
8MZKGIPV2HZrWFi7P0S0dXq92j2umd3mD+p/1Glf5RxTYgU1p9ZXUDXtd1uuLu0lbH8CfRYt0m0M
YGxWo1haKdvCj+4H9GUxkFL1+MygTpgCMJWsLZUrdXkPTyztSg5ed0I9dhRcxEG8R6zenXZtj0ON
IbKdZeW9lfu2c+vHjUpZN8pFz/ygG5l+j2JDDeUZuhS08LYM9NPFi2b3s6gbAxYPxv9A6qE1OWSx
sdpWHH4MED8pcztGsfC4NKNbr5F/CRhDYxbcTRSYOt19wRIS3VCgrYQVjS4HZcpOVndphl/FIm1n
cfbuo0P4EqHC7qyVfR9PtiyKism5ftOkfdc/SYPam164VX5ir7UMXJHtEuiqJ8TWe1lsCIAEPjRr
yFpnlHsp/c83VzCHpRopVJbFS/n2TvULI/39FRdSiiEsCnaN+SD1mHnMFHGfbicXAqJjoCuLCFZ5
o1+lS4hT3EIBdJQzbhRD9V8qksgas0mgNAq2br/2yS4rzqTGz+69/dFjctY1Stb8HJtWKBVm9mgC
+Hgp00DLqNGVJ8iw6xarLf5zv/k/6N9ZhsgIlcUOjDspfRS0ZRUeYT1cmYgzifA3VqCb59uoKnXG
t4IWnpNokAEW0QYIXbMaoVxhzyauW883qndyvtHE2B6KcNysM67umt2f0LzfpnD+xqW7m/59HGnv
9t6EdvzekrKBlPU8kqE+1fhG9BURBNMNxQxsU7eg5ZNb7a61rSuhQEkpqduN//L+gelIu7dO2pgZ
EHzmjvNxp794Oj1bcGgVvqX2yERTMaZ6XRAOnT/xNQ7yj1+FMD6qIs5gXXqMorKgBh8o6Zw9z5N8
wcKE2+9USEhL1al5cu0xoov/dKgGQfisyFehdH8xI6nc7AEXt/WM3c2V7lLLzxSer8uweLu7fWRa
4fQqSwVoq7BR4SgTnO83NzMoDy9s1DXz/+l8xekvqYpNDvQqYy5aKEMaZ/f7Szeq3WcdgDQR+Ue7
ptdcVhWcr1R2182V63Qo7Wt6cx+HCa0TOLht6+eujG0deviUo0oLE14HBA6FCOC8cJRtcX8bJzm6
hyS6h3W6LTEK8X/+hJP2uqkYZhp0zFGuuwSDqj6m0vUsAjhT84dAhBnRtbTtNKiNQElzHglFI8yw
iZ14hFg3rGYbwUA8kf9LadWhz1aDaojk83LNmam9Bpu++jrfyyve+zTDmeKSzpCZAGsEdlx+bLLL
Sh8gD7e1Skvdy3hXEkKFJVAgcvbjQ0mFz/V6gvnd+OvfxOnec7mgAArHbPiV7Qdvzwxnb5p/1JA5
gEDZkDrKw0/BbXSKd0eghe9veOXkkiqfxt04G7OBHngOdspM8qoiGYj+jfpUK9LyzDuE9ygqDu7s
0ZAHEqOF2C6yPA0Z9PMIBGUktrx/HO9lbCBDUIU1IDPduhtvXiojLXaD7kostjZJ1BCU6rg4KWNF
gLbWlejjVFpiLla1LD3wX1OaQk2HHpFwl85w3U+aI9gB2knoNPzohXXA6TPpRnznQZ7EgjhNaqVJ
SCOUnCQY9xLqhesvPd8Sad2JDlXaE52Aq8oi1IswKD0KKW1RzGm5sFY30GfThju8ZXc9DEQqGq8I
HOKm+r+2P91ANfB6HzoqcQWqn/kODeVNJZuMxuUTp6e8BxHK0TbBrhtFhjNWBZ6iKYbqYS8nJTMW
D4K1PJ5l67HGeeSHmi8zK06Nf7sEC0ujZM8NVK9BO8uVOwEmK5GBZh3yb7RVBkjOngGSNpgO4Dil
YelRGi8FXVkNV4HritFl8iCgP41ZoUEj3cqvlx8TRo/EJZUA3TBr4YJxcOoft/sNBiFCtBIpfZyw
4WEOgQ6r265hdOx01Vml7l9oy4Zku8aR+iiPnRKJ5dIWIJltFZU0DWvb1fgdNJeNjgMuF+LEn91L
oUlYiMgjoA5aYRFcpF55uHtysdCC2WRkzqiKWqn976q7SNaGRontzMqs7QiafiHYekHXcjPN1VtR
NiCK4bdRYvHmZCcioWi/X5OGTjSuAfHDCtWwDP5zhSpbih3T47Hx44CYwN8bVLg3VDPTsC5i8Nez
yQBrEN9QC3QgExtcnG+x0Pq8XGVefH4ZhsNp3abnrikkH3/iL3aZ1ARGuo03WVIRD4w1zoY1TgOu
2/Ces7z4IkbGi9/XM7XRjiDi+MOuaefpIysqVJQk9SYJ+Wfm8cGK6RIElysrKjbhUY0TIKOZX2WT
ffe0w1yf1ph0ZANt/UyuQYBJoaOfhSsANl0SgnRNQWP2kzIDYCsgXzk82uQFBKwhrua5h2GIlUY+
tASMv2d5wrspmRkhKArEQr/CSyHTVBqergOC7oYGE6Md2uecLGAVvs85Y3x5hiU2eZQviMc5+Jb1
Z4Lmmrj+q8Jpam/pknJkLKI9Vb0+3oVREDUp3LDrs5VC+8M/Y8Z5P89HgO4l77Kj+vTA5eykPkXs
hrleH4ESb08Btwpc+RNQwrUsxOfT46wp3rXQ/dOZc58TXAyPBH0nT8IHTVNafZITu+XRLhgtN7UV
2qM3Fq0J9QMEaLx1TjQbhBYRutAbSs/zy/PDWt+Z3MB67x+zWmK0x8sfPVhc3jMreolH017YBb6f
GBpBkEJOw02MZLm/XwVPWVqDCN6j9RJLpP2z8oqPi9I5FxjWFKIEzhvQnaT+FLfSTXXXwV4LqEXf
p+NyoZB1WqU8/MsuVPyC5nqb50QQn/2jddQKobgI4wSpoJ/NoBEGbL0ST1nEljuQp8FzzklAEl7p
LSG+P6k2TYtDVKqGSGfoNKIg2MuB0C3tGUOX9BBDV65rsFL/+HaZWrpy/zlIx786qpPeaeGg1WYX
QLYkXvI/RFe9jFWQb8DvqVu3yqzskgeWMePyup0PyXW6Tn+288U4CaxKfNvbXTIS/gTw4bjH01ai
0XVVVEsQFZrT3x/NWD9OzhxkUWB3XeJyYGXylVlGYbOL6N4jYHu/tAZprNYD/aeawI7JIPEhILCc
7d7JjjVUSnbdGSLXD8dcETxGpNwcHFEA/W+KNREVWnqflUYByN4Itx8/3gmLdPX71smX5UqeWyKU
gFfxMorOQu6qT/gyKxI9H05HraxCEBBV1nWIgSRNw1GOSP7hG+LU7LH02g0ArQFDNH9u/1AMNhbk
Zp0hVlLs+tWlZWQX9uyBonom5lXuG2WETJ6glJ8XqSvie3VR1DLemzSo14MnrPjcvhVpEAjc8uvY
UEjHPl9rNg1MRAfLLl5mcgRX4CNwweSJjibC71BPxfH46B6rI5mtELynrhaJ3hhoM/psyxEqJvwG
GrQRpVcvMvI913OBr0RTwvc7Trr+gHMzMjGXQclyVi8/QPY/j3G5Miyqn5IJ3C0a0DL9JUB5VENR
zw+G6FsBdXQARjzMNrsFhw52LDXgyd4kv3sZJ+smOJqihrTuW/RVg2X/fVFLPov00n7/WObmKpXv
pzBxco07/s3EL8SKFH2NsPdWaDAT01/IdUUiUrb3FkWBYWDkxj8a8jfIemHwlb9GFa+MLzDVsc0i
GgCiDV6ru93Vw0PSsQ68s3UcGHHyO4JOq0+KfesjGqXCkse2k42iQI8OvCzie2CeVu3RDRjWrmIU
xXIIHUxSlOUROgpm54VOdu7hdb9Icri3+kZ+pUCw4CjK9DVUGWOdkisdM1NyGQFnBu5U4IHPG3az
hW7qARyDyQaBcPlbrE8lQNxtn8R19U7hLgjrgF8OlYjy1AAfvMYIdzflsjKrQ8s6kV5ic0eE+re0
UtmN4eHSH/zfNuo9arGwnLNdaQ69x/JgH8tbPheD4ZEWlK2ZJJg+LYRQnK+ak47jjQy1fCrzM0rR
CB3aA2thVDal4yfGQRmSO7vVkts+EFPkVVm6j55OhQJcp1qnCQBv1tfnFvvvbYH5BJ7HxxLx0wJm
iBIkIzquVNuRy/K7SSgkHhlXbEoyzonjCLrIqz9SwWX1NXd5HbdClof2lzkmQcYgI/pqHF+qBu0I
3DJxmCUTrrGrQSHEPOpEKr75nXOzdyv+EGRYS/ZrBq0iIiMKNfuVRPxWUVWshM+wWcoU45aXsslR
iOp+L7UtAMg7zaGs9b6kZ1Iwj3h+gtGuq1wrawVO5ml2ryD//p5i3TGWTr8OUXgluwIu5EgLJ05C
/WTFi0pTMl5NmxpyAYLWjcKFcQzYBtRhifc8p31TPg8P5bmVVwLCymHsWLmbwYluiKSq/TlA5OI3
EpkRl427JSwYlzzVLEFH0zetp4mIlKBtP7sazG5Z+OE+cTgxIA3glsE/B691oMbhORAbg/WB0Vmn
09cbYgbACjnJXaXostbnwckt+2loemNP89rJBqHyUJrBJEDrJinyZrbWgxnVnXr9wE5J695c99oz
dFXkantUVS4MJGfrgoA90G4WQzjqJWXxo2QL3Sl1v+LR4ir6q+wBeBf7l/DMSYJ3RTr2SC1RXHJ3
plEhycbV07tVeCDNoJOF+5t9BN2qHZhfG2JrTq697CL/tsy6ei5xTkZK/sEDDVpS9BzJ+sa1GSSw
3XRSr6xYZD5QDxtoJHQEeWXQKZ453Q8r35B+dNFdgkkIeC4WN4/IPUGiobloFRIOKipsl/1SvVei
hKj7K0V1dVHDFZNQcPLlkEBP0VQayPWWTIjToI3neNg6xn7QBZbyskDtcks0HB3JZE8PC1zQPIM0
Z7+ex4HGbSqY6DtPESTpJCvDQw+P856ULogyUduq/s3k+nSCo4Tui110nJ9W5WfietSwNNAU/gUk
4vGnlvrX6H/dAEJKthgLCRwR+3tnC0xJ8a4SVXs5dhR8LpCG3xew7pBQnvGgsoqK1qVUa6mKO3rh
dHbBTR007r5/HxMCpRJC+aSXccHQ0sbuLL4F62XcW/uGofykIynjQ4Zq+878LLWlbFXR+39kH4w8
n4o0asAjmkcyjWslxlKwJEA5F+FgK8lul1NID5ruh/c+zazyxI0xyGUifycp39nVwRx4+KYabMyE
kdXnxNrnmRN19BNeXdBJAEDpeVdvutly08mbOo5/pZLb6PROV/4NVXBFks/iLwVTV0i6VcQnrr96
HhSLnJEpEhPr+fS1RlfxZcQ9II3YGs991BKG3bmj1RlwyoLm4VQf4XTf4BOhsPSGTH9/eW6a/LmW
Q3Ytym6Lab0AXnmBTkmPrb4ZRk1MRy2H2TKpw6BAXl0rRODBbeLzQPy3nZjDEZ4QL4qlwlcnFmBj
+AZRlMWnPnlWC8L0yOvcRK18ik/n0HgkjfcHqcJ3oYGsxxPPLBt60nFz6eKw8HZ71fdYo3UMi15h
35Xld+sUjDXgHYwYj4iOwsUmTQoWrIXhzKE0QSiCv5pf4jxfS3gNcNYyTTQyJDGCyVYGjR7LoBQ1
U80Pv/nhVd9teDkp1dG7WEih5h5fuOk+vVfmNKPAyhxRmOlOEMtHkkCgDbyoO54vjRMhbuTEKuIA
0dMPrJqeh8L3IWNM8U0J2duzU5J4WFczR8pixywnU0SH7143Pc9QyhrT3agKBrjwVIomMlzgaXgr
mklfJJV+1v6FTBiYDkLYoOlcYPaIrQRFjw2+rXPGpPfgZNPTcDfSna/9K7n7i3igxPShc9Ai1mG4
NHTUtDkT2Do3GHmq8UEHlWLdNprAyIz4z+5gIFENJzugZ7Z9Zr/aDP6YymyftLOY94wFJpj7BPkR
GXrQINKlC5lhZZhjS92cgi3onQFCi8C9mSR7DVoWVV9qeP2CcaOV6Vn55U6301jNBaQAds5k8V0g
dbBjPTeBwEHds1j0vv2QIJAUa0xX5qFX7nFW2miUlORDetKddPD85byCTeECavppO+p0Ra4FAZ+Z
i6zj3g68VJiITaURayfhjif06wUBok6SfBeuEijZgYg3Fi276BV6HxWqep8Wdk5X4Rq1IBUyAAGx
Fdaefq6zjC083MLX0ZP4NboK/bTROi60jyNtoWY43wzIIjCESRDL78DFfj+cnMS/tRF3NMozP5pt
1HDBXrix9JgZMiMWYSmSku/tCaARv2dtOYPZwpEgpNu4eUdA/Ubs5QvzdlrGJxOY7j0dqmvV1W0o
uTNCEKMQ5LWwO+IzkyAk3eoNKVdkDdqaLX7ULF4zkXt2e5B0sQWPppEu7lHU4Oc3ggibykOCX4GL
EyrwLveXHJEOUJFUkZI3IuaNTO6bwVYmuiopfJz8OWgql6UUPhtNvbvh7A95ut4SQ20gKHDCj4Jw
WxSJXiXiZe3yHXiICwr16xBjWgBoSm+pN0jrEtDnxtctRf6QbYaLa5l3b4YUld1ofW39nd5ZveAC
zjH3EWDKSZdt1W/nHit6EUuVO9KIwCIuq+u8sTx9J4KGrZ6Mk9DiT/XjahoM//LLCJKF4VGTY30s
C39WacMPvbjjtlIDNa4QouIbilrEavBJa/uMFffm882yUK4hWlRNfkETb6nr/UAVsIbRbPn2YDg5
3iA3ERDxlH8VjKTqN8PT6prPtnl/DFHoS9t/aHjFFuCii7C4nCW=