<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvS4PN8Ve5r6vkxmKTYF4P8UI9zbVIR+q9UuU5HiMHI28odLBk7767HlxplpE60Z5VycwHF1
tFvfACPz16h3YrFbV8DiyzGtdhSNUX64UMQPh1UR/uFbDZw5iVolDMkDt1/llqSN8e4/VUXHFW9w
L567gZBU9PYbA5JNBJrC/6/CflWhlndhfanui+PRX7VKuFZOJZM0CebpAKVfE6lmZW7zoru8pLjj
A0XQStIX0RDrbxY+ygAoVN8AMHHPbtKUmWQqIdpduDuQEICruOA6s+HRjTLd38/LlE8bxhlW/S6j
oxrX/xdeZo+7aa9XO/a/9hlKdVBEWnsPJAdwy3kN6doHE+axoINh8rUVI7/6imccVyOtb349B0zd
2pvCnNTKbbAdu2bfKDh7WgnLD3lB5DxOgrde9nvnIKx0qFhw90hXcHeihSEdVSyYfeBGNRCMglOI
/VGUyElwlydPXmP0bSiJFqon1UN2ONEbY3jdCIdPt/kpjXVVyq3u31bB1DrPK0hqlkfHDnnzA+nE
Wd1uCeTOW3RxwaHKsysas7NY3qY4wUKhamRBBGWFDhuLJbvCR8j0AkwP5D/0S1xCS2nHoSQ850Rt
ik1Lu792Tm0jYNhPihh/YhMzFyhQ1xk52OeCmt9DB664nHrq3pRhRBxKUpThvhL1fYjR/3i3TKI0
dOb/mj5BL4UA2cO8NF8kZ6KZj1qnUcaNBtAx4bD1TWAQH83YOrH913kS/Sbr6QEsfEF9ms3DFzYI
ORsYle7M1sWVzqZtmGqIl+BSwYXQD7W5uQcz9MuBMCXqORsTR5xcehXQ2NeJMEIFDy/CWTeY4WzV
bmKIn2ueJ1y7mJYTgqfbfOBqQMVOPxl5KAVTEW643EqwDZbAkUJ+kHuSSuKRmowAZLo+5BQH2+P8
4cAYsmrz/wgkZIiUFHcNE3TVPFCalsM6za3hDeo5xZ4jZB4CTH2LLW7gbFdK1x6WeN6FPiHJ0UYd
TudFzTOfOQXtBKaUvvhmozR0dGVqB+SNqHJDonF7fRKhZAjm/d73hIXCTS1Sk6+Z8Mr9zfUaKj6A
ULz6aBMfyQWPQ0RdtnvSSs6DJKd+TEl+O37JZQKIjLBMS00mJxhkrNuK7q3AfDWhnv5nsdiXfE6E
xbUftwlPUpVa1xd5aGRfcsE/jGH9a5xiDMslI7T4dFPzhIPKoGToNZ/DWxlkLeGScSOiIztP2cIQ
56Vois7ydsKbGRdpuyFxP3Ja8rfyxLD7leP/sr7k8LpM5ftmz1x6SSnKNyntJidcKnMCKj9LLpal
EmZQ6PkAFXoiALFhgLufV1+r7G4WhhuuRLtqycAAlJY6M2/fHKB45O8/hMa9sdHoL5eGLdU/4PDC
yi/jIrhpj88gt9LDuKYDRf/14znLDFatecHqJDlNMfVgkglujBcVxeV5p4doQ93AmwMQ/8nZApkm
0AQyW0GxZ52/1me3za5g7ixmesPbznVQgSxKKnytMRjmHcIwdB+uetp2CosUx99o8ZTJZaG5j5YA
DBxoHC3G1DEWZsS7zmylUAbHajqSl7SGbKOQn51cK6DFh+qrsWRIo0vHlt+fduGiKMCAvia8igIh
/rEmBAJYCqVDOhKt4k9UAy1+BsMRJOMJyT4KxPiBjqJqEHiTOvTNOmO7bD/IaI43VjUQlecrG/vb
0TnEvsrf3XGucyXcKoH7rYMNq/B4+SEzoITYjwCkIQwJtZWZ/x//6rSVzcfhuvqKiedkrqFr46JH
tkdILxjTNtt7SRt94oMygTxybRq+Lfo5Pssgfjf7aa1rSAveOHCHCaaPhQ1xtWU6E6o9UCy2BC5K
e+MxlW8sbx5Kh5ilSHX7htrC6x8MMSQPut0bJsTrxgtFDvvx4g2KCfIctguaD5rWp+gNQmhPlOLI
B6S8swhKbkJHEPXHwjQxtr5kJOfApTvegV4wm2asldyEncVqBh/PEH1/v/FAn5cP7tPfu0ZihU6H
U2diwngkMyzq+G190zD8pb9iDJihNFa95zvVnHPNlUZj2/y8GwJeW4s5znr3bUX6Al+7Y0QAMSGg
0Z726uyLLABOqls4R7jOi3S2zoGuGPvZ+tEx5N2nB/MXXNM3dyi/hBn07a/Tj6tGuDvDQOqNGbcb
8Cx9KL8Yfb1vr/c8BjgTayt/NIjQLE4mA/LgJW0S3Bx8ff8Z/YZFyr8aPlaNHRtmz8tylB6teJXC
T7CgQb1OUcyNqIeB+80VlkkcZoy8MNape8xgb+ZMIvKNGGlwV+YsOI4sCnB8bBDpJeQTFNAuQZBM
XUAUIxzLtXKCzU642tosGuzk0EY6hgrCpcHmyrDByUJTaUQ7868LccPXZo/QXRrs0DBOs30nkKBp
OU+JEDb06LUE/uPXfRYqneQIfhzCFRssGUsDxAGwYmRI8bxHQWIGG577b0i4A4mE9oYnhzo/vZ/u
V3CkmZXe6sw8yaNbeBT/Tu02gnnuHODjwMECj1Hg5Uwvql/jEvOdKTwvO/nr9jK0mqKKCVE5uo5i
vapO5bCloCwZHmSmLXZfcnb7Y+oMFvYFnvZngaalwIzSeP31I1wzWudi+B82wmw89GjGETH6WNhS
LivUv1VAplFqfrakJYzcG6wKwuCUUPJCLLOfCgeBzrSmhyll/lVVy3bKqySHt2TgPGuFc7+ENhA5
gNtvy4KTU0lKQqE7S+Gqih3QkEG6lv8hkLuHikP5WI5acqrtQZlXGv+nhw9i4ck9Y+DuwbfRlnB6
FsWKcHsfyK95rGgQf+CXbVyiQtHogcnMgv+AicyNeWbBqRQ4AnDmvpCGrZYquaUsWCRqeWzzbzW1
7PoRQQGEq2nJWTvpLgR2mKW65VhRxE4kgZfXRYaMLiTu8gKw/zHc4v1Tr0SMWf9k3hH3P2cqZ1ZC
YEZqmWGa/vYjagPqXGMs6KClPEaxCaRIR+3EnPn3OsCNCFet7K7MT2l3XMOgPkTo3SoIOl77/uy6
1dvIIY/ocufHT5z8YGJnRau4rR3bhQ+ES6y+aZKUEBZRBTOGCMKLzJJ0JVrus3I+ezZGvc3x1jps
j1s3u0odPexKSnE9jisBMWAz4rOwpuPhs1jtgQOP3V+WS9FilNYyA3WAKkB8tK3jIqSG3MrGBrVy
0uktGlIUJL+CAFkZNru0GeYvp46KPnPYzrCNIHzRp6IPPbfjpSAxoKD47h9+3TOG9hapvTt4Gk7w
f8syKWvbEPdmBEo9/cZIVoI+zyjqluzKTBaZoqHxaULFc0cOx6EHE29N3mGRlQnjfz22X0MEJ3gU
2V5sjdDmZH6O+X+3eCEmmbGGSawP5GAmppuLnScqSbGpHz0/q1FT+zC6AMnGGL1ReXYcK7W4dVaX
n9b5anxWkGW0JU/YTgRZPiO546EMD99AwmcYKhEevM0LCacvXpQ2pSNBawNUvV+uj/onMJD9lznL
gcjd5AgwjQ3/wkjeJnLi5i00+YIaJE3TXrePha8jgGr1bS/3CuQUDP5IFNhuVyAhEeCrQkwniknJ
22MixxKqDApykGtlbCSsnGuluxr3uCRSXTKc+Xv3UfCKcb+OyvZclHxNBkoJ17EFrDY9MzCiMix8
2ggTuUzSKXYHyg6dNnLZP9CLybJ2jSUJqisddLLQd5hQtaEs9MNd8eL4u18pdwT0wU0GNz909Aeo
xyiS8OQJKHMPOOWjJkdIZsc3iilw+4zDS7I8Xuday9cJAJjczJk+4cwznMml8oYof0I/Joc2dsVQ
bSLYXm9nW7W5ygaY1jiUw8bIEi5PHECQqUvqg1XnAfaMZgWREr//6yPk/g25YMSgcpGuDU/8Omdq
8D3MQkdidjXQ/BYL61KUhlq2wUbU66gvo2nNlU2lfUqxttoiitpvE2etwOdwhus6/8Xg3/CDyCbP
1XjNbK3F2XcO7BEc22QsTd4qmEihecB2UyAzN8f5DShjLGsxeqV/On+8HOADeZluOykiYLzVaHtb
gmhyi1qIoG21ARDkilnaehOR5dMc7mGgR5i+OOhSEaEML4Hisxrkvqe7baCKXCPwMXlP0uz34rHn
5dxaPAhjSqLEGj6T61PX0eniSCgL3mn9TEbFf60pQ9cvCxU8B3+9uoWkjK8BWpLtfCRj5WMBny2R
3jLTtHcB6jEZOFzpSggCIopFpF5o0mCnuxHFQlFx4yoBv50rDpuuxw1U698zZB6ETp54DYEAAmKQ
9FHliKxs+xmDX5lwQYz5613Qoo0XWbxhlKwjKEos+7zRUDWdOG4rEOQGRCs/XWFjtfjdBVksLPgq
XaPFxJyUmdk2tCVoh3RCaxgxx5dB02IKqk9xbg3RHa7wpOgVLW1DsolSlF6GleSpZY1KQdMJLHf9
+8vF8ZQEFRsCk63F//XRyFh9zGiPLEzCePYjjmUwfaTQNcMlUayzsTMtEyCjmbJyQ3E1HugTgR5V
JGz84eu0QuYUc0KteNr7VZghukYSMsQLatb7NKV+nod4b8YN9jLf/+aWfS815ExJejn8C+PNKi+Z
so9MxCNI4OmSlXY5l0DruFnVFNzjgxpxWYKD5NHyFsAnCrJnBrVjYknjX+gMQU6L+2xsZztDJqyR
qxqW28uMOfI8G/Z9VX8NRCmeMCeG1uTJKPfPeQ31N22lcv+P1VUwjpBEPlmsUm6AsqYQ2bJ4H1mb
HdvgvRBFv8aWto3gNvA2KCdBC0QF7V3zDDbCIKdVrj2Dw1Asfp6mynpwXIIZLbUHiCvUpiDjyo7v
DChJ0AHQ5DH6LFxoh5za5+Qeedn70l7iRjJ+A4zvYfPcrMVbqQVjcqEBopHWcG1TAJ02aCBm5vNd
eD0+/Vt/fZVeZ6y7Qskezevh98+xElVs6bjNNZFzY57BI3JBddne3YiwvJMG8gJaM87nPkwl+wF2
2v99tsVZRosaFg8UdLl8pmt7t9MPPQ7EtEsUwG//0HUwzRpBwZ4gAyitc7KTnDJz3k8B5geQXe4O
kkDK00ffmFbtfmxhM1JBR1rHXBu2Psn6NGUZbiBYTlJYZvhhtKl1KPIDaO8PjslDXZiJcjicLtHP
wB7F+lbbgO0H0vOzXoopLQ1c6XNZ1omYdPkGzwrox1cLJ2ET8Zy65OUZ1r+Nk01+nq8c5veX95AX
AO5eXn7f2oVz3Ca9bcazlcEtRhX0XVfU/TZTcFmeQQMNgUCk8XrYXwewKF/84u/0EJuFdZDdGt8x
relp/Yb9P+2SIVhW8kK0lPAj796QB4q31J9mR5O0EXWp2fZcLPzWtR89NwdGxsd9vpdArwHdhOyw
puDD7mN31FaoHiUVLgMBjtkd2wuzG+iClWUnXzPlH5UVEAcr49sWSFdMR5heKCP3lx/946z2pEWZ
9I+d5flpMBC1DhokRc+YwpvoLSsJFjjE6iqgO0E0l6rFWZxzdARhzMFsT8keYSky4OjdKMjeNLyo
7WD2bEezBk8IwiOBa4JeGWcV5eHObQDUjbCZ8IxD1HPNA6LvjdI79aJb+ojrZPLNNuyLJKZrxoLL
E/ZFVaVBf4vwFPbfWb45ZRuwuEtuBGYawe+rf/t2IsebPgYU0g1p9fJhuP3e/OJnYJv07bvXO22a
aCZUEr9n5fVFFX5ZuecbB65MKLImNhraX4cBRBajS0vCqVrMEzxifIFuXrJFS9JsBq4VCJRimkD6
X5wnQRwTKVzr/Gdyd/bUJN5YWqWOwmwrhXiN6owlay6XGHeDKOz1CKkNa8MeLt51xvwlDnkNZGl4
bCAbQfA5BZVrxgYedxU3UF5s2C4QcKyFJuU1d5FLg2IeF/D4jcaIzXvhbTPy+IVj+Y6AsmmDmhtp
YMWayxPbbzWncslMXqQBxw7CH0vZikRN+bJBIysGCOUN/W3UNZgmLLOSVqEOlan0sDPf+jb/B796
ad46u/EoUE85mR6aMwjWAgql2NDf4SH/335IoxRIBqoZfwiNl3V846fOIMy5VO2YZvoXw/GBY8nF
GdUwgwkXP7PP+lIB2M1sdv1M+E3yjl7p/DsGYL/JOqoho3CvTWn39KZAFhMJYoMFl1yui3Z2fC0u
S9Osbp2SoGWxyjbJpY7I8z/OixoWHBzOqqPkAFXXyELy3kxbZ3B57qQQin99Vm6DP5kU8K2ZCDxr
BHoOEUyKfe8hVaOKdOR/6H2J3bYjWk6QqTSpplF4uXF3/f9m+kr+4hlc9wQ8wtT0fg4sujx8w3rV
TCor+UMpkoyih2gAagkNtHi9dnOwrpa+MrGdyd/z662d8RT62fiRat/wLWolgr2iGD/+0dgk+C1/
ST2NrKLrqRiJcSY5Iflg6yq47ksmWbD6ZPj4RyvJekiv6cVp/ysP/Mh533cHUn1EY5xR8FQRst6g
PdgLEbAfIvWVD0+Kpa2BggEqE0wL2du2w1/46EVUpYH6Gp/bH2kDyjNB0g40GeadTI9Sm/9ZZ1Vt
fHaBqqJNtmkBfyYfIQcBVr5QKBxpZvVlAoxrrzTA7e4Br5cqXkzcsyF5278o0zaR43VZ6v1EnxBy
r82Fz9wj11uCQ19C66BEINl6gk2D17x5PiCVa0UJxwxsG+321sqgR2aHWq1MYga4OJdlrpxZhAiE
qxIvHQ1ubInnk7e0a8G01i+WuCpHgY4klDn+AUUnhC2dJJjJrYKDsQT3sC7UWRds39cDaUefDNPg
mrY9dy7F/J3HhjjNsiJfaf+AQhuavn+Vf92FeKvXqFZ5xl7sONPkDQ/BlelAfTmk0ItQnTk96jns
CrxzEJNg//MgXeZg4cRvI9spOTJIFuDaFuoImdu7eP692yPAvtAhQ4cg4C3/zbukWmJPkZV/Uz0M
ywfR6w4M/PUHwL90kmhv3KXjaOkt0I2D2JVNl1giZo6AVBcylaAp96oEEX86YUOL0pCNafi46Zgp
vGn67CnOzs+YmxI4eMos9I95YD6Zyz0mX6n82VMHHIKZ/EZEO1e9TcuraGdGBRw/cYC2zQvYvzpP
T8XQJjLJndriUTgx5ZkxN/CMpipIKsKffMe1CoCWCFO7surwj8ytqlAoC/obkjmlpu63CjHIr5Ma
9UgK9Owue+Fl2CwCIfgif9Mpb6ng7fEOatv6fDJX4J5ImdT+Cv+98noZwVPlN9IOG8fwRgs2m64K
flsQAumauGYomRo3KKIiUBy6vdRAIldoCYSVMHSwCbKfPNhZd8thYLJdiBK4Ef+KiimkNs+G/KES
l2SeZGA6OYrWZIVCuNYzCoriIR0JNHtzqL1/mbZ98nGgZYB0oENKGYlLD7pUI1mRtmPLwcZi8NfO
yRNftdFEdUjBWRtyE/+pywtgJXBm0dyrETZxlGvDdTi3FKlscnLOnT5k4p70Duy7kUHsfxk4LXCV
duuebrLclez4qWE6sQosHrIv3Zd9KYB9SWrI8fUIimH6lv3m4jv6cMS4Mkvz+Amf4t7lpTBHNBLZ
z7teTjD5b6NpJQRLhsVGULIsSq3uKqaA9MqTQGFKRc7XMqbhsVHlBribJesF52R2hGlfEDYPpBTs
CSP2B0yuVxx8rJgUUOdgp7P0VhCapu2WHWSGX1ULfc7lWXqAo4pSVNhhu4TtJ24oJ5+kiGGLDWAs
3h2wb59CsTNUl9LIQK5Gb9VPg9ybmiFDlroIC+xLSwI8q5IeEwquiYXsOLP7IaGJd/HPSbk7kLuo
WbePhKjFfJ2QZooLqEsqS6/MoVOjy8ZenG10n+KlktZF9My71GePvdOol5HxqhiUJrLtczMTZAv/
Z+G+qr/3xpI9/EBqufpzYs1S2udB+FfIZCwMDm6T+H74OLBUFeLS3Nz47Rrhe3kSbRu7DpjFfwHK
tmVxhBk/AMZdzuzgd/Qsu/e6Fu9n2DQYR0sGNjJ9ZZtWAJGCRwcyNnbnmyxnecTuWpN7hEC6cO8G
Vps1EtG6s7bwPCZCu+xF+bhbv1rgU3RkA67XyMIilQsOpTe92WG7ZaPJHw2CGO6xsyjEvBP1IYa/
SBaK6gYk0c05FZ2oLhk6P4d/GL5aI2lOo/k2R7X2xFS25zGEmRor9sSQX+8LKyKSvFkIi5qCJUA4
bPcVra4ue7u7UEVrjw+vc8w3sC0uQSMZcL0hxhLJ6mXn7O226ZY3QlhWL+fG/2ZNBoRi4wHarlho
SPbnP9t7b45LOrKTy4TY2+nOg0O15LqUD5oY84VE/YewECdcJ14NeNeqyFBaSbLiU3VKdTmCjd68
vUA2KVrx2XtJDInMJZ/emceHQF3UBV4piqngR2jFLTK+OTmviO6e8WFODCXgdxedghGogtfa5IYC
ncix2+W1Oqbf2A/sUzGbvLtst6aRHUbcGXugqNz7MChCX1yifHvI+Wm2Bh9H83OY2QT8s+GnqXu9
VMo5Og/SnwLLOqi3HXxpVFOFZ3r0Jqqc7AiIc4PzKy4Ao4ZhY69enBBUXU20HXPikhsRqkhIQgJg
kupzHlrcikHh3cG6MEly/fXVkYqZd9S+f9WpN3U45JMPB48tPsWaiWjq36m/OAWeCI5hJmv+r/Pt
GSO/ng+1P8iJG9KHdEUAKqoR1ljPMiXV5DO32c22iaIXY+5MrjBBBwMEbW8DCtuM/UFOXxW4MF5r
1QDCaUABJNwwCf2A/wwz6sALABaOit+HToEPQNoaAu3PzWuxecLaeerYOYLswkEWjrO1PvOVpCDk
EP959RMbb6B2jGJgPhFePmnV+w5zAhI1WWrM0Hf5dr0/UHx9rF5b+Itsl4VrCmLIHaRVufwJgi1E
zEUkaoF1lvHmipzk46K99ftnBK9EWL7uffZKtAnxXnYwIVBht9+x8STzoi14uM8tCAYh380KaEai
DlwJjAQ9t5bl4CqiWi3kh0bJbunx6ddNEf8w2JHvmkAm/d4HewOZ7jBQfND2wGWVOdnb/JaDK+1J
OPjwlVonPDH9+wEB23WxAvEL6OMuR50FBiG/d8Fq0L5BwVMGq3xYNWJbytLxFT0LQVFa5/J659EA
ImlByRPd2/QKV8jx3Xis8roNlPNOT/3qxaKhimgYtOR8yCY3C2W+C83YWmwzuuoqE0xAdNsWnzgm
oU8kh01stql/gr+GzdHwQXmBNJb2fW3blRRdMQQzA9IbTHWZbZ6bq/OReDqfGGNjkyaqoouR0N8q
hI81Gvd/Ivi2jyY1law9Fh8eEaSmU4eQbSu/CMnOcRMvsG4URrQFCElqXIFj8qO0GPQYyLMadtm7
leJVi9xpQjQDn/c0xjmIKQHI28XSqRuOBGv1f9clKKA1xJ2aAduhnfcmyrpjyyPQK1Kl6VTkREM0
GVXTxNvuJTuH0ca+P9V6GPiCbcroFvyHXMUXwxIWHY8rF+xlPKmhPnK7rmsgu+tFdwKxmaoEsEBM
6tN7NSGdZlmCbLRozdmGL3I+piU2zO2Hx3htY12ggWmWfwKN3GP3jYTWIFwDS13u/X3DxD7Z+Wpr
PaAkH9qi5HiJYfPRAQCgNgs40UUyRcxuT8V7lgJRxJMcewOnoivMS4M2J+cYNKctRZYBD8VNvhSs
IIWgpbmcwe3zdNavMm2E3dru03fljeq7x0lYATZ+NvWoRsZNw91N5elzDz7uA9FEIpJtBReqUZK0
ueskGYUNJxIKdHLYK9UznQZYlGfcfRDpattpz8By+flTbjYAK5vM9qZzaUQ66joly13OmA7+M1Y3
mk6aUq1nzmamBEUpvQiF+94C2r10BfP9f7FKHYSmIqy2ljnXcd8kRHSUlN4NDpx9K2YwRrBvZCav
f52qqKGoIxru+A8FFycMe37NYbqiFVqhS7RU0FIyYL1pxHjgiIbJJsNRe3XPZckJr6IBoy6+a+pw
b6oHhOBX8LUd4md8fFzdj8QP1O+o9OFDXc2VQfF+4Ffv59hQZydUhvw5hBSe0PRcIGz0uNJxG3KM
aaTWjkUS9FjHVuMygyeA1LUeH2YAsSr3h9mvPOrjOyp+RwVnRBCZEOBDk0Ikvf15YsA6vSusi1xX
aPMuDhsCQd5+ZPXdLl4YjuY0C8yCKdPpHFkX3QhnDqaTrTC1MJNl0hsS4Pw8