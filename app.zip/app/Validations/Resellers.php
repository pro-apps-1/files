<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvLzR/lZ2rJz+fVws3ckyoNWpuQsadH2dOouihuiGSL2NPQgUS48mVDlpPqQ1/svlXVDtMNi
zO6wpus4vFlfmi22/+qCV+BXFOr+ItAGQ81z/Lbd9HGBRCZ145G0+1Pdb5sy04NdH367TYyBUWot
2Ev+JJAvjoy1dYh+2naO8hWlEKfUwohsiHugMKMkktOCZZzh/1vArk9QlCO8pDJj4QKfWG6xQqW8
0jHtt48glxkgkufxQr2ezAqL0qVv5kwgzNkWRjHLK0sFFSqLpROcz/6WCXfhzpWS0rONUjfZFe82
DJXr/p4GvBG7Hexb0zPIn/Nr3uYNa1wC6mgXoK+Gc4A74jARewytygmflbudE1bja9Ol67LHH5j/
PKteMAVdCfwooDt2XmKmz7eF+Hec6+nuBVGBy5C8oMUGi/HNbFpwmNvWQf8EbzW0LK8A6/8N9yMl
jlnSZEtIW8cpJIPnL7N04xmeTWHj/9jL+bMVzmK+/MwR5GBGN99k376sqJVRpRg083aFh67ihc5O
oiAlAXySyLZC6torV3NoeexyV/S1Bn/HWGQgOiAXajO9SDLRImXhhxgAosmzjCwXRSbKtqB9MQHc
dR/TyBrGt/abQqq7D5wPDE6hollq5FoKj5usrLGqf2B/FvAi57FBS+okSe3dcDCa0Miwo1UJqbkB
nStABzas9RVqCjnoudJ4wjVCVrD9VyS/aIKQHPLsWuTT3fa0IQf8pHgBSzl1Zd54GJ86uap4qI2j
GV8xC5DirvNs1PT9xKNZ/EIe3zJ7+UZY/WHNETakbnkKF/O7WUlT6eL3Zighv62T/KK4SfglMVTj
suid4frt5nD5NKE3lqY0Ct76cyDyVth1j6j0qBi+6gQdwh/Ww+Y3+mYBMdym4ylkumGrmSJtQy4J
LaeJmVpyN/XxoM6wqkM85h0stXt8BI2pUaZMUzUNDZqdGNfaVCw+T2cg66Yv8o1mLwWmnpBek4W0
PQD5M6RgsrVVkvqh7yVyvhVWingRFVWPGFPSobd088K9skMWhnPctNkrGUim5KAB5RWHnsXlA1ho
tlQUstpRMm1LOhPFHh5xKHLuSRJh366hdhByR3OvBPWOwrFWV3I3L+olLW89RP6/C0YOBL+OSwkp
3t37LUynUlVg1sVLXJhaS/SKxCR4lfmvwS2wzPVRwiCb5e2xkkDgLBi/crU8qp6E6mtqcxGlQv9U
TvfADYfrdRgRhxm5E3g6Djyt1XdiFQN48dyXxftwE6T+dJ3GBohwhs1X2d8d26oNjpBPXSLMy1B0
7cEMrDHIYyf/yDnKy09fTNfTaJsEe4xAP4aEvs94s8FNGObfOZ3UI4sA4kE58wCwIH6PaIgrUAKd
fvTeTkq75L1fMHgRYfIN757tcfYtkGqCNnlGCLBrytMA1jb5AHtDIwGDOfjf9JhWsixJjRq59GyQ
xojAUODayzQqWbWflUzcHCuaU11SYJ9F4fQEnkRx2H3hL0WbAHwaqKsJ7eyeDrBUwPmAwTn8Ujkx
ASphy0nOcwPgSWpustPM5wQflk3tHEKtl6ZbMKAgzEOVH5SibkPpeMAd0F4OuPkhXl4IuIy6FNpI
TWsEcBBU4/qqPkT51snvbogCAZGrbuoBENb5hnugfN/7IlEmHPkq/aMekGV24ga4MenSMQcMSIfR
ow7y8L0qrwcOpyIIR+9bbXXVl4MqAEwPr8SAoV5+UQ58HLuCT+mE3x/BP8H5aepDY9jv2eRtICEf
vYXzmkMBvqN7q69xyeRA2FmiHzn5dYsHFT/sYeCopriwsn3zBM58iAm4+VBb550ki1aSTpOnSfzQ
cDgB3jSJMUwxUm6+g20P1KNML72PcwvJCvzAo7Hsf+LmlI452H9uCCo4rzvcLt32jocaeTXHdTn6
665sNvOOVhRIMj/8v8MKWc0onvzF9aeK9VnvsKeZod/euAfwdvzkGffat5rYK8Q1aLxj98KHL21N
9FUoT9GELW8QV+iUUf9P/VkKONogDiTpiKGa0FTcp0mZZczGd6LBwjOVjQtOnCl+HaN/EqPYEAtq
V7wHcaxQ3h1oSOG77dq7t+7UujgvmK2bE7Fg1hbU16knpJXLXsIJXF1sjRPOBCzQMrYV/sX2V5hC
dAxGoZDb0gGFgVSESSq1ZzD/1tJPhnHb84sD8q3Q0sPs1EbZ6NLgH1rr5rFawrlD+s6N/4KZtys7
oqProjngajXnGZhoKJDw65iT8cS5EdwgFtA3YmfVnnbLAF6DG6HUS3G2yJiBSZ+AbgJ6X8t2o0o/
JHMkVN+ljiRb/tPEDdzmOQMqDnEa5Dt6iSJDS/NYMVTELd0o7wV3M9zAcXR9uUEI2pe+GfkgfNph
1HFtWg5P9nwgnkhwQcUrkoG1NNB5Mfzrj9UB+v/6l5q9g0w03Uk6oIsCBiVzSrr9GyiEtcD4kgdx
bGGOZePdIHx6k7s3sx8SOZbTPhguzBfxgHxxT+Ods0ilRM6Rt4OB58Y0dwM5CvIjEDIENvYvCOFz
YhDWpjpUZCc08Ep7rQCA39X+OlE8l2uQqgJ7hdkn5Qee9qy54eSunpACjKgtxWBUQmJwEe2oUIUW
NkV9X1rNhi7ujqsQTXa7hUsuFPsuwvci65TuQcUHou2TJ4EnItWaJ4+EeYF1tQ60CTWMjhJy23YJ
exzAjBUufQOGq5zH+S7klpGZni07Pgj/A/J+9EE8CdMnQdZqXpVqRULT8EHXlYR2URxRUq4zP9Oq
/qfBuzfXzApqf4iif+bWuT69887SXUvjBeaSgY7cnrQlQMttMob+tBHVAaSK5VwdHmlH/+EtkR8M
fGh0hy+tf7YLEgrLVV57Vz13ipw2/KOcP2Cc2OBhFQPnJW6dpfnicdK7RL6humXo6PgUy1+5NCPZ
oToxDbP6AIEBlMOVhnmraryBiCRFdH6W8PmoveGTbI+8c7QtsR/UYRskLdL+djghQCygWf7pt3I9
oJ6KPJ0fnvksBuIIBT77zJbO3jul1lwOhwjYs9Tm9tob7sa25CBecGWC++yVSPJxm3Rz4MSHwTBk
G8VkwgQxRGmF+bxZhHKhFyVj6M9RZxwL9nYRsWp7kl2MFccRfErOPbr2ephNIuW7d5INhBDR0v1n
gjGEOaaqibXEVCdkLP2OIQdxPW3UlLhy93eDD4Q2vucSdAEWvXgRUMUcs2UQVGjhPbaHRqwfvTGT
ckVHnYNdOXTs5uzQ73fXtcIDgQqAYU4FFWSjWTo9u1Fz9uA4D/+n1y+xqdcbqxFu933YHix6ORAg
7BUzC9KSUCOVfH7KFOnET5f1goKgakpa+SIuc6GrO1pU74AbiOQiKN+mG2sDYpPlHKTeG/ktRXvC
4eoG73TYTN9Zw3I8+xeJNyd80T5pYChhhuDXg1bPCNPJ3DXFbO7Wq+e2R6RoMnKipox73pACMckJ
q9ZoH//qtkemhHoD+TBZtRl1xKiMEfTvkKv8tQGjxaoJLV68HKDtHxaDRFcedh5sz+8GyYckjJWb
a6M5z0Lj5BtNTPlTqV0ayB4NOVvsvNBN283SRFSPYXwcvuYGnur1PJtK9nlx9axKgz8nIO5fqpw6
LgVImnuB+EOg4N+cPBjivXxGtl07yBErKeL/L9jt98A7JLxcPO2w0WaRZyeI28614nStquy6IG6G
Jt2s01m8QPea0vDwTVUReYhwvRlIb4PXbNAU8i4KokEtDVXIrjiXZFbMr0eFvwezzB6ixWc/0Cll
zJh2fLed3LpYLU6GJzjfIUv+qMRJVQqZ2PiuV+D9m1HCj5S2TyPz7pzatehMiSZjOkQlTm9sddR2
8iNQbfiUNl9G7V4Na4KE9CEfZ+XQxeARnpeAae3CX/QJavgoZFMEYDAt7wGPC4lP0vLfUmgnfJXQ
aRiswixYrt0911ll0hlUnN4FFdooxmFQgyZnHmlwZsSxquyiEWBuPb1eKcTCpnVM6vSNjjLhf+n/
5LvIxwBNTsCMZ2TS24DWkevOE59eZ8mrEKFnaI1HRwezkT47qOIB/lXyYOmiO4hzE3/xc/QCHec3
HqyIoOKQPYSdEsOirw8Na2C/YJNhWSg5XojeO1pM6y6S+MXBwtv3sqc7iMxKZw559tlVV7PilsUM
CJxHXhRjDsgJOaUHm421Lk7l57kNX8JhzFRmOrxNltrP9dRlp8BKSZ2gHDHDkA0mlBWTQb2QaefB
K1av2ZlnN7oBR4r12+RHfKORZ3JXmC0ud72jyibShyVJGBVeGkxhXQSeTJVBLIgjxXcgtkeEjCEv
KQZroFt/rflwmWCAJImfaFhMEEUTeZdxoaytrmDd+/SmDR7SaBVO6ZU7YlblE05vLguJSzZQG43t
kSUlgg6JFyhoN1ye9VBjwegFgSO0wZ0DGTsm123oLX7J2Kl9C5hZmCoSkOIbZqPqCX5z2dXQZm/X
IyywsUutDwJbQ+9hvWcPMZuGEt5ZkIxN3gOHcRanYOiMsQq4pRBNKZMDVF+cw0kebC8MRMaaJ3Es
2zV/NElvh6h/MDMSX1zENvcw4c7ZMB2rGl7To8Qr2eubnZXHuSSRDiKOOI0hT+nQTVNRwxkpB6s1
Kjzy0441d0dN5NInn56GrwYwkEoUMdUxdpPczoAqCEYNg0Cd8lVCxeIHHKuLxJjUE4vkd8wfRtaW
Km3KGECjP8wo9PM2CIY6poGmq2sciu4HoJSBNcjyvSdPOSPD+2UM1H9nzLapkdXqtXwS1DRbEXQ7
Qu7xJps7hKyhQX3OD3qrmYWKpXqeQ5gSJpdjcp9BFcUyH/4ZqjAbNClLN8u8WcPNZCjp08gg1dJR
dlFNafEmDk4uAAj8SoqI//K1UHzdqmmgWaPuZyx2JqbHYt9J1toBS6ifMFo/7oJBWMPtL5sKjg4N
n8haFQHR0CDWTdcXzP4tYYoTNGn/GELMR4oXhZVS9dPHVOHeDXSsK3QZhEx+MRrNTctscJO3wgj0
ew4NMd31KKBVUo42vQPnvVl9Gbas0zqIuFi+Wb2w3AAHBgE2t3Tiz4BlKJBhr3Bn12WYt+Lwgn+g
oBW+IcxFOIcu3Fha23W2REjTteOsQHwFlNtBpNd8Cd5Nik82rRiL2xjNMLlEFJGqPLR4fABI9kIx
xDxBEQdcOLnyMn/XTwYpi3yC1VXB7vJB5F5V4t22D+/i9zqOxiOcAdpEQ1p/o26251ntL41SxQvT
1nKRBX0u2DRmBlrSRtw5BknMq/rzqlUb6FAyT+8no/ZjXuw8MWff1WM28rapYA0Gq0hxAC457kEe
ERn3KlhC6wVd/BFQzK/6D8fNlCwwtVSV3j8sTSHAHsYj0fQXBQUHGyvS21s3EJ6aTy8tauwEt7K+
TlGi850DikW4WfZjNcPZ2vngqX8ioSuZWo0kXfGLMRhVcX+3pWjtwl83Xp4EnIoYkpi+yG4MgyoB
QhDP2a2mkE0th/Ogj83r2RVVKXMAJOhspI8wOFHLvW7yT7O5mSbY2Tpn5QU4jTau6JUHniePMHLO
QyAn1Wj/NgNDVgdVuHSK0TndBi5fvc12Rtle1/ptMHM0OnirO/cNBzzdo78T8q2CXwY6rGtWeFtH
JcB/6iQOsunUJ+33KRmPuarESj91kVVDLNAcVVrfgZ+gAvUXl+XsZqqDY4VLtD2OlSK4Mvhrd/f9
8nhawyqkV7wJj8Zq6Aoty19xwWvX7ihBbNa1ANb8keNVHRLf7YW5wfti94zhT7jZ8/Qk4875KGUk
ZzIVh6qPYcFDgzzpufaDFRdN9woySaw4eWY3MUa1Nu4Yz0MDow1qTv2mKEMCcP82wWwJL77pg/PI
/N9f+tqP7Vt4WT1e8cqDelLeAKk6MGM6JqZmrG1XKpMkzArtFrCFs7SUUejGYWHx1wWoXzxJ6ZwR
O6sY69b3qpPP9YYVFXwKlQeJ52UsO+1LtoHghCZ1qPGBzfdcLEGvkYSE2hRPbOixPrSlL9pV+zpu
9C/HR65bufV02KZG3ssi06LScTEvhoEqz4pIQUDImefQlJ7itZuuMiynRRU1ukBsqtoRTJauJk3c
Fi9spLyQbuAWah7oHFhHd2LpG4MF85Okk0I0SH9cDocKCWi85Fz2OCXD9MwUUGFVxcDiZPWA1Kvb
LLALYiKKJlevu16QQU06Mu099wgnRYRINCkGXSidqN7xbuV+yFN68iSCdKzsAXfQ4re+/vShK5Bm
awmBLuXj0GOoE8DKTl1kFZwd2Z4MbBM8P5cbf0uFxnOxKd9z1bvFDzukq0m6ZbipW8i8FzI0aak4
0TkZkY+ABQ+h5Xc5RNRyAumfsAH0oX2abTQPMQbKcQp3WxpwehoNUqEzf86Uv4p2YblF77bctSSG
9z/U7uQ4AIwefMy5e8tUqIMwr/rymnGl2Gogj50z5eyCqsLqjGyOr/3nf0Ild4/1pUh/3AFtNMz5
6IlkKfQxaqG1ReyfhGuCskU2Nwr0nGS63E5CCMvQhMP8b8gphTbkXVQneHG9NYu/ZIT92Qm5E/Md
PMHNQQeayAs1fv12M0YqobSpwvtWzFOkbaWG/kVxkktOusz2Jx45esUcZ1NDv/I03VNag+IJV7hQ
q8yS9h3gMv2Pc/nrDlnHSF7YAQYhfCej7dmGPR4KlHchAK5kwNo9ekHBxDE5qWchAly0wulin3E0
1RCsY2N2wBdcVrjfhDe+qrOWgy1StJ6HKO1LEuCb+FR84Ty7H3QwEq9+vc89HtQ6sH0/jYmw42Ia
grHI003OXw7X9jUZbN6eGpcFJiim1SZY0oNzid2/n4hEaPPU2kgRFKzOxmrDywhZWseF92jXVTi6
BEwXT4gv0FyLmf7L4Eq7h3uZwMWgBkOTgXSUymqO3+nvv8b2uHqey41iPWOKNnc/1aFuE68ENuFI
M84h4gTmJ64gvDz8Jn7Km8/uNXLan3OljTwdD2JFAJ2xbk1A2OpYMcqTgYDkU/tf9yJShK+JUPJR
MHOkxsJo7u1hQd9ZhvIXDOJEw7SGm2mVGwqxWS2B1Nlq18eHm+ozuuZoMepZQr6dpymzbdqLehZk
vR/C0MrhAf/zn7wAOxF9cYxW1c06FHCwlzkoj+Iprsc7yuE1tuVC00HMmuyuewdI39u92dTEh8ed
l3RV+0bc2ffHYK2p1dfnXSYXFLLPZLVR3BuZEh3JEAfwzTNzMuz+vLgZdGiELC3FbBw9YlEketCo
70ugJ25exV44ST3oxcMKZLxeDaEqZUiPaJ6Lds72aDfhDhKcuPOBrUNgRw8HTTnJ8Q//A6CL1LNE
l2FydssdxlqchX+eJAUAbam7L393UYuOkem87SU2ZQQkb4XaBTsY+e0tIXUxR/6aqPX0QOzZh6Ey
ARpH9pvtxzNzYjD9USnhxeeuYp4ll+ebbeht9HrERq3K9G4Zf6AEX5T2Zes+I9h3/FcbatKOYE8h
KC/ET+yK2CME7oBSyqbQmQDfqyiByfwIXX1gs7/L1TqSbjcZsgcjJtCt96Rkv2KGhOdrxGPaQ4CD
JbUdYc6fe8yAu+xrETY+R5Z/Fs6PEyMzcy8m39K+03hu/wv2f8DjoyPdXRrn3iNELD+NqTi9ZZGD
dUPDBs0DCC7RNCgmrh4ZdkL1qEgoOicNvf/DBNZKYlZU+LRAkf0AIccvOUe/OMcvpKCJOVzJW+0P
WnKT4EplXNlmwf5ztWo4IO730CmfopWEpOj9I3/+q1WINkL/xL8KwdkHVU3vgXXL4bLaOU9Tnjfc
jNBnTNFOiFE1Rsue781eFffZT4uwp727R1WMRmamCAryMhgo+qtUJlcLz42u6X9CWXV6VKANut+t
Hk1ZS9gfKotuNxI6WlTU9sNk2qkAQ/F+0e1VDvvQMpR0WnTQYvlemPnnuyjT1v9cimXC/He6jvuP
kXGntVjywR6b2XfbpCbG2/5J6tb57v9Y7TEV6PYDle63hcsbt0+FtPIRpshbozrLOEAwbxzrjlB2
nZMVdLa5JyycqVWWxfPIbeORzZSnRfvm/yjFtaENY1xIAls/w7LzJGwgKQCrwJibX33yxx18owo4
rADbfjUrH/2m8Gz0pRH5uVhOyNHIR+MxTY3MyCfEy6XKXq2kUOyeU8lfcU8qOc9y6PsBb3T6C+zQ
Ykx8dY1YtUiT3gIBD0v/4QaCsUd1/YXFNgVwHkLidMGjzxyMzgZPImQyD50XT14zEmc4AacxHLVd
r9QJErLTdy6dzWvHQltWgAcXuPruR8/WpxAp+oDtbAMLHtY5FvOgB6BGHXBzluEGK4nYX1Z4c7rl
P8Cwf4PpMXCiDbdBj+sNHfhOsFGDvy5aJLaf974Qja5sAXJVDJyC/vYcBU9H+4ZFfV26pmj0KH+i
LhwsDboxTTcTL55YVNvFRfcZczmeZTg8/AAkZx9xEvgZAdSLq7XWluv/5FGct+ZXbzHZXnTT2DFg
kMxAfOl89hvTZ+cxVWtaFu+ySih8zccLVOg0VEPH1MM+vNE/cZyBVSA6+eVUBBkgOQxt5cPzzzmw
hCHk4EbQHsCscQQkl9BcHs5SiFnHLfosoxIsBkHzP5/dfa+eyvDCeXH6mPQePufK92GsBlyVcpMY
ir88mTlNKUDZgLIEU5YLccCJvMS+h08Cj9TGEFx431UEpTJv+kWD+j5HMUzkB4wLSo0L2wzOMrcQ
2DDCT4SzfsX1xkD1xIkhAz5hr7O6olJ7L9piFRKPyEgJopvwbuwZgkcdVJKTEjhBR9jiYwn1KE58
UmTsZLSpndUDinKN2sH2MbqEf4HymiqQvIfJAlGuZn2AbBwDTRtcSqUkg1OJdNdAB5mG+3UZ8T3G
wbB+76F0slO48tOBioJansMcD1ZdTspt2CTHo8LzQzK1Q4iz3qxXm3PTYys23T8tpK/rzZKun8lo
lH3igMJYDV8wHGZ019Vp2UpX/lJqsVjEZCnFxj9IvdZLg+mQ/T49dNXXIT+80fO5EBQxhGdaOBk7
KSGEg1AuGJcoke5xNxNpNUUdGfXOzS/S0XfSNmZe7ZRpNLCtjXRWfQWlq2+aUBIXdtX8PH8rk0dV
FQu7ghzHoR2yS9b7RFVVHjLh6QJjmIF1PuDW9rZNsTjt5P323GqxXMZGPmh3dC2fsDadSzS9kTM6
4jBzP70S+6ZYyYsxQBz6uiE4lYhTkS2UGh5Ybvjz2fK5zmFHOR1M59Q5Fu/DxlvofSlngDDl1Bvj
Ah+Gk3kyQMB3SFwh3LqGBBKCUA+bgHeHK5IFqdKHUjAUpd3cwD9pLKB3+iAE+wI9ZugHZ8hKjY3v
4aNKXxKB7c6vRT+k9GTM8fMMvD7GmJiVheWW3usqbvQGXk1pDejSI3Lsf4pZ7+02gYNOiO2V1xIl
MKt2fhTTziKdcuu2fkdCNvUBIr9LuH+fUXH5fb+Vp4cO6AqZWWd/6S2zPAITZXc7yRHk9bCiKFaq
49DXiry2JaJ2kbI3dU8rVj//NVAFeLis5CwI6Dpo7D3pc6vw5+WnXM6I2LHJRoyIorQDUeyOmNkT
6JKSaPL2q2gBH3IJ+2aLhbATVSgMoIZdMZ7rWVQH5UArPvVLROb3ABwr/C9SEKFARYMjSr45yh33
yw7UtyVgDCtIR4XMMOw3HqJIocdnM41Vu3GdHsfXni22qJEVvcctgK4Eki8LLb/xAcACIZYDXU9A
lQP2TeuWOtn2Glh6YWM0rcCjuyEcDlExHE+4J33vbcRdq5ua8yhluh2xwRzZGyHeadPVBkIU3Wx1
CUQJpQsNWKb2JygX7utwicJeq+A3Sk8myt8Wrraei9GZWOfmAahnJT2HUnsepVVb/WlOsrBTE6nW
uTQU34Jnw+CYJ6V0VqHA9Zyuj6/xvINAJd87+4ciENkyB1jv+0KvMn06IvJCDzHg5Iym/+ZkXgG2
A0cMzQcvhz0bGJh6K4Ti7inJ6nT9AmYB7F0z1FJ/GKIXEWHDkJRQggdYAMTD+dZ2BQdhEwU5Lc8z
QPLlcqUEvhc7rsGFUBqKGK0PNexugLhllfR9UK6+V8cQ8oxJ/a1ZOw4bgHOZpwa=