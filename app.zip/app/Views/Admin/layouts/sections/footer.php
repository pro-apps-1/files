<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqqtbwlcg6kC/sRs0eXa/tfup3POfiZdWQEuV0z04AOTKGA0l2oacFvQND4wO27w/HPV/MHA
4gI5zlklunSY4QsMz3qOTng8VF2/GjKPjFF5Ah6jZMkGhzKjYdEj18DXrQOOpyWx7RgCGcLPoafW
8OvXib0ouc8erzuYuo+ppJ0Bq+qdS6mRr/yd1jBKkB3dNWd3KMXK0GNo8rUWkgY/fFeaijAZZh+F
Od8PW7c8DLlMhOaaAe21dB4SE5J4Wmz1SEnnscOEfIpv+5PatZdjxX50axjfNm1zjnrhzPT2IQIH
kbje/nddbOTe8ilRvCo3PHk34IHETxzEhtwXABOJgAnTX5wMRUIb0lRAqO8Idj2L5hxJo8atAJIU
qgpp7pJGY7G91bvIYeCR573pWbF+0bRDB3dQNY82jhpDhjo76XkSs1PdUxlPc8t2VHlYpQ/7YUER
BnEe0OlFWmvILvTTPJkDpFcVxhDyqxALwz46x0VXWwdgROH8vZM5umxJIUdT7cCcYnt0TTHWIv45
uUoaaY+lPq1SPWiMMAfjoEOzskT2ufhHCvlHOHR2Nt2O2UmlibLxblvpgOG2/nhiQjeAnauhP+V7
W4DtO376fG41+pPYTwMYmG4Y2ncap8n3pwsnl7kc3bXlb2j0MddqBc5i85PfRWBoeAR34OAAUifT
L3jvVzDT9MF2ecHsmXWQiWfu7Rg1nmhndVS/9rxwkgsAz59uHHjzfajVz6UQBZTzquMBeDoPEphU
DnFeqwjmqPKXYAzJXh4WL/L9jwWwUFWAsZF6UE0WcD0FTsjRK1pR5Pf0aE26aqLrn3b3jcUnrL+p
Ikab0ShNsLEv3N1p93/w6abJ/zw7vJs+Jz2VPajlyBtha5e+0Yhz9nOoaN46Vx6NclhypkBpS0sN
fqKpJZzcZfnodLqROmaOkvswnjxJ94sHsMwg8oPokOE5y1DR8lGKZs9D5obOiX11dff8cEdJuexn
f9JTvWlwFrdzJ+ScRPVubt/gbl2M3wOKy4k4F+fOGL+ucilY/P4bKkjUkPFt4hE5iRs/MpCDfeJd
kPWiNLptGT7G5uPSOVcH4Xd87Mt5OJlvi0SD2xr47FDjc+3gL7pMoXjcMkydG1EuNNPI5KZZ9t97
LiTdxGW2htwKeMaAEoQEAcwykr3tJO8Qxm4E3D2wyghf2Q+sktTYTETx7QptVJ6I2gUSRsWDAOMl
KxbBI0BCm1IpF+VhpctoGkrk6uhsVwqLQJSs1yh4tk26oTcvr6UwDK9OBI5bOHipDAD1qJTfl5KJ
FWj+c0mKQadZ4q07jFslh7J7L0==