<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnZBUq2eX41ejGhkOo72EADJu5DwOkZRbEn8AtVi6SGVnddy/4aHI5O89xzJ4MgdqQn2dLTE
5lUr8kDJlBm9TbKrsWZTvsRAtuE6L36RCzkU1WBfhcQv+HnRnh8pB+OlbuYReMyIcpVqtWQgHvhZ
VST3kxZBoObmqPSmfzBZV1GpGhWeGor8Cms5YGyC2JNQc5F5oJbZqzr6PQ5ThqWkUxhUG/YxY2qs
fdDktcCxsJPL1o1QSgv3c0GXdqeMOCFGLco26zrKlb1g6Cjv1nFo8DJn1qvLP3UYPEv/TpF703gX
2dvb9G+KXvzyJfT8QVmXYoWhRmw50a3lU+NHJzeKjrdn27N4PI+3Lom81eo7Hc8V/bcpYLYzZt3k
3qeWuOygApKBGXh5nxMX+DD7q27LZFTmQaEMNWWitbZQXMGUDxOsWMB0ZTWQTfDm5iPWYzLclgog
Yth+RirlGf1uuYQri1nJvUhF/LvWidzbH0qbluTLTOqcMw5IUeWDks5SyrIwOM2wz/yQ02o9EPY+
AgThqPPB/hKDN40c2+Ti7Tj/NqVrA5PnUMvB4We3966zoSdiqqyrhl/Ll21hBTejSkWSb9uqapUb
5y085DeQgqUGbLDwUnnAM+nfkILKxqTBBJ9oROjB9em9qA9YCBOdyApG/Ev3tO7a0YYBK6cOqcv2
Dih5HU0UpYVIRNdHUKdaJm/8tBFfIdFR39fx6OAa3yxQVanLIan9s4dUpHM+1vCu+kKha3lHtGOm
IhVi4sokKj+uueH9BrtXbr4VSNiftp8hm1LwNDu1OsefZeiFVq62Xf8xQjzqeFEhROLGzR7sLDby
k8+5doVoDBDXlSX09Sz8r2GofVKR1rC3J1UzrhcHog8K1xCZLIeiaUYwX3yAnhbfyuYvGOk2/fN2
ZsW+H2sUCwVz2DMtmIUWfVjHekRxcwg+a3aoEUu4dsMrFubCLRWmddLmLmuHQRzzIHFiM6GIoQ5A
heZhJStmvi4WkKHVH9UUQO3tH0Ogu4qXOXQaYZZbTbGNgLh1cgLcOl9CCYXp0pP6EJBYicizvsES
IzpfQAWtpEEL02W2L3PGS772JfeQzUUnI8xbFd6SxVUWTrsB/EmFJb35UQaQv1Ktl8g4EdaLyVZh
bih6bKogiSJlAZW8UVb8HVbMcLCDSN01xliWg1Q1oehH7ePYxB/do1zyKuEI+qmDzRVYeHLNNT4S
gr77iWhwvrr2U7VX62tpjROBIQVZ9Ho2gGEnCpMb3FuH8wwfrNug7/6ahcheyRLfu4EK6SgB6/b0
xzhF7chDJTAI9kVtCEGFr7J7ohuSju9qT88=