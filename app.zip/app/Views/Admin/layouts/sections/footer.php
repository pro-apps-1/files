<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuYdol8hEC/5CcPVqNux/xNE07QKqfjZ8kCG3pCtJDH7fy680ZFgGHgjgOodx+y+AE5j9s58
wq+raAXKbMjq0o855wzGny75bE99OMHGu+FnZBrseKevTRcBOjVsi66qVFcHWBfeOSORp/b2cmxD
k5dDLONig3T652q60GcfyusUzLHCQXfEKbJ6S6PHHo7XpH82Sj1RS+/u+nINqloQEU1hW1Bf+tm7
RlDfBbB93XmDYxNkbSzQIu5dDYch0AR+AotmGXyO6yWc+zY1KPBfI7XK6YlyPp03ZM7wtHB0IR/2
lLP/PXxUhAk4A3ORSJYkkwHdephud9i4M54lxiKilFM/b6I6tqN0OzjZ6OAo1faD2FvfrX84UJl5
JkUjmilcgRb8flfPpN3kGMCAibGk1A83sJK1XK1Hc1C4bgqw9NsFPqY4Isz1AtHQgOpcD0AOHvgF
J3+JszTTvxjodG7OSmtXM5X3L8glZBmbygcsJebmNGrDRkxMdOBGZnUaAZuEH9c0JRizMABCHXnf
0BZk3zjRqgXuimmpjYfnXnckQJj3Thwccl9Y1iNaWcR69/Q63OADl2zANzZc64ZaBRTUFkYQsP7I
70ZdXJbG7so9oR48saQADSw5Sd/xeaGpHKvoc9zSHpa5uqjKanj1IFcpBM0VlIXPSjp6gjgOi1uN
DNVTJDmXluCgi6Svx+KQxAecVkjCZGi5ogV1Nrp+NL5JBK61H6v4f9eibJOdOvenHto2WmOTmO5c
HRQdLBDt/VTytY1tbzYpal2P5WJDRP9bbKMkduVRVr/RNhxMW97Qcgdo0eUUBySwWOYzPxXfINc9
tk0/D/xETeIIHx/vjkspGuMeKTAtV92k1+lR540KxbAtjQMpAdCD8kRnWoB09rIMbGV1jedZT2Jr
iyuDC9HmOdFZe50LStICiBB5tuBk09RYWQCjX0eBgk1LMC1C3DZmM7iVlLh7ga2iCW4ivonQ4ILO
cxFzRUvrHC7L3qwKYbNR9luppcJtNwsYZnJH9W9aGdGWCneh/orK2cdhphez0xG8CSVwnnqGGBMQ
vffrX6hwuQgRZwE8OIhWRX+8HdcU2JhB1r0ca22xGXzIXcOwef08od7CtrxuVSAy8AdGS9h8aLp+
K8OgWg9iG8FWli9/4lkCnEVM6T1ZYFBsrQRHq7wYfj7ojv9g19t6skZB2GSCTLtoWbeu8YysbPUv
Q+p/M2NlFG1XZScBjijMyPmzFyJKa4XG7XK1KLVegrRnLfCZkhSHa39V2WBq429XvpvmqJVBQKdz
7pfnY1klkuLjsZq=