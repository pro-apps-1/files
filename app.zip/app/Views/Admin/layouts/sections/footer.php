<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt/6KrS+cwYOnmV6TAIjkXfmIfn2jDq7ywQu1+aORFWTOP+Uf0fEx7OM/2RWormOi304Sw4P
6IJIOUw3lINrwqOpBPq49m36AtOYflCe/c9B6kzzkF7KlllNVOGm8jwhGkMnRoDhiTVB/A8U7CGQ
m/uHZXjjYHtBdvWCuOWYOif+l0gAZ9LHt91SYqshsYtY0Vv+L4sq3IwFQkWmWmQeakCKYMxbzp99
+6UCKJPIyQbhRorMBZA46tq45Z3jmeqVCV4dIdpduDuQEICruOA6s+HRjUTcVBnCxXX93EzGRy6j
nBqX/z2y6pKMUenWqWMX+usbjyjVyj98MqFBZId43Hk9lswD+OQoW2egEq4op+4FwCOHFtOdUQQ9
/Fw0no65vW117AAnvnTPr8I7TLtRjB2vsZeAm24QCRzaruRPlopN6K4QY4hyq1WDrQBqCHXDZY1K
av2kJ7iAsEsk/RkjYTYTNzRpx2k6/xMfvUh1qljKRtSf+j03fFj/fTjWPHK6b2K1vk4PaV84M5eH
qS1X+pU6uLBqsL6pJjW8zqFiUM/QZ0DKvxzNww/MLGImFyLo9gcPMgbFb7YuUEAf28+2AYVhyV31
jal6Uv0dCG51U7T/yzODHcqDz2T5BWQTeGyGdhVcxKJ4T3iQcVPVFI8Z8hwupuy5gtJGJXkmhUck
fQP2csqBSSt5zBKALuZ8DG5s+iuxpmJ0Hd+d1e6hQoD/eb65pgTp5Ofpk8qjovkOqnZK9/NMjWil
zyawgZzwJAE97cqKCuHCHbz0vIdk869j319wHg2De/I8HuoMq6ZsU2M5DVvpJBqupD2JU7uY6G0f
UPVJslRdZF1hdu80/0+Xhg5/zJVP2HvpQmAkWeeC9q+ImHCIQV8jrBgSjCsOVjeb2lbJgH3d8XBn
QOJ/SXpg5FHFd9u8es4YvE7nshFeGo9jP5soEGih+MrYal8W7NYh6gIT/gP1+cL+GQ0FKXZQNYJA
cTG0tQDNdPbh4+7jLE2ekBNj9ML7ZQsGhfQfVpgVfJPJ9Xo2fUGQrcXgW2nekLBV8KMkAKHLV5cE
mmK7hjF/+iZQVJRfuQd+lGAkd4WngT6nCs25mywVp8g+r2NTHWf9zJ5EEEA51pHBBFdVhPYmxt9f
XPSlP+ivtKyvwyeFWiQTJWOEXeWH9iYyXUwiiKKAFwICU2Uew5dchLuaMMty5vO1BwtYOvIjQrcG
TXDHWECPQ1qWRcNAk2WKZ4xo+6Fh+o3MJGVhXgPBdn+52P1H1IlN81QcH9bw4BeEZn8RhT8JpzFB
5dVWdrNM40MpZ7NfRG==