<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPthrCPGDRehRo3IajzUHH0k20O1qVMlc5ym3EBlmbxHL/HsmLSJmqeJOKQ+kMQp9+gcQ1kIG
WRbHvqGfeZOpGcU93HUpmqCav4l3S0c6jJlQ3YZQQGKQBa/vgIbd0yz718DiEKkLIpNmefQvzhw0
EVoPlmW5404VP/tQLJVba3JQsxAsBFWSDuoxL+qTf0hGcaGVQbLLQkPLRvA3paIEHVfVVL7ZE2TL
wpKhAAYSH0D3BysT2fp7XP7auCU4C2CbwgQJRiPDG9KZFqh4jKURPiTfl8FxPU3AVICK7uaCh6rS
6AkvFKv57xZGJFMVeAHBgIl12Ks3BdwITHWXqfhsntSn3aZIBSsI0yUyMTQI4BJanzE0J/kdyvGY
5CkPecA2rl9DurpM+HDU8uGgqPGNMY+k5FAThZSb3UlLPDiZQC9KOZC5nd2MbgINiuUzVPI4iHwa
xevuPR6aLfDCYvSsO8gcQSlmgpc4s4mfGrfSj0GeHrpGe24oN8fyiD/4TBV2N9UnGjKwEy4bwnHE
2/BpMdU5/98UNjdFOCxWfmgJCVOBvNA1/qqhHIgEw20/ngHj4MXhaQKjFIxgL6WEs+JG+iArTPsX
uGs4fssW33fSH1NEwX7Ae8sAnTYEJhF1bSXCaUOrLW2oqTiMyCGpx2WJcXCaUakwIa9d1p4ZNqpd
R8t4N4UsR6l7Ld24U0uGeS2LHbBe+z4iT1DIjtJP4wULy2yCkuRdarKcpeu2UcOGsyy9xkd1Nnyw
yEtXfgEyXEsRaSHLSG6fkG/ka7lqytBbHZO4VV5ljEJKxkTmOounbmWlVrLjgLPshXFarqsD7WEj
WU44PGEHkQKCrHiBOfROQCrKzcM9jN64uw7GSRdP1e7JSnefdhM/bWvGoLqSdAppmJKPUV2LL9rz
sYnZcVSdkUfiZCugKnVFt5Ns0uE7CjLXiJvhDdcjDek1mgRpxvn/PvT0cXdGOKsWazDQ4ZIM4IyC
iEuO1wzr8TwCgzE8vMb2Wn8wN3IW9Mvpukhi5nmvMiWKZQNT0eqp8r8BiPjTLfIMaRohzBsQje4T
8jEhEiA8N9FZc3a7AIpDI1Dib0SL563PYRfJdQ2vcY4dOL2uu/baJjBWPXdArvbm99jwruGk0Lom
5/0whIIGl8T49tIEdDQ9tWt9AfUaz9WGs+717C17/Xte+ZNlxQfY5pM0d6qJySka8gQRxFjYR9lB
dqies7QcTQnavyhKg8xm6Ovcm/qEcF4ez1GK+7vpO7NJMcarwMBmguf1hxJiDykwd1c7xZaI/SkK
2rCZuf6lntSi5DvLezEx1Ns6p0==