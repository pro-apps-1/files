<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmgb6lUhFlzw+B9aZzI9iuysy/Ocodod6fAulCU+jr6ZD1U/oMb1bMiDyu7HNd7VXv10ZJqA
s+gx1e+2bTykOuagAyZQKlYEKxEXfYLPJSElawchNXyw/U4Yx3EkRXP05CHVjx4j0LKTLrUm+S7Z
kN2NoSA6NAmoXAEI8EOeju5V5InmmgaSN9azfosWuGapp7tmujjOVuHFFeGbO1EqfJu/yUMOsYLa
Wi7LVj1yjKaxgcIS5f12ooXV9i6luw+2mKahRjHLK0sFFSqLpROcz/6WCeXhDpfIbD9eOhrJMeA2
+aO7MSLaetY4MZN7sRhYrdcNiRVfYqkf1Nsy6TpaAjzErjzNto1ZTA8ToTpNaDw9lo7KnqPBaeQx
gAkxQOxXI73oZ3+yTFmSlHARhOkNXo3Wj7G2x5IYSUPYEv6IXnbtfSENZbai9YICYcdIjBccGfiz
Mw+WU/bDemrprq3tbbVgNQwKi8GmLHzP3Jx5isf1HbpPj+m5tLOvQ2rE5HBDnfgy2j4dfYeJhA1n
jW6fW+wC1hZsWABH+fwWJZAdwam9cuMGhJEQae0ad2vLf2kxsZWJd1J/YBf6nNgWdV7hwUgK+5Li
duWvEEerHdSiYov3dO7h+qpArAWkExl+8txGlZFGTtDetHG8p2UoC4Leum6K2agZyHHEaXbLIYrP
fOwNyXFnDpMCRBGaqszfkb8ntTp/o4//A4pjfvl4+9HuTlITfYpLq6aZOrJ2gDGjveGKcJLjr94R
C722j8mLOlWQqn8M69zVDIVhsKTImXuPXvJwMC+ZEEIxmCX+qTPtiWHnFsdWkacDz0jT94Nn8u72
3+gXntswnkN3+kR1Pe+L/T1Q9u5NVKnWROLOD749Dipob/zwHoenWuf87JYpGSGDrmxZgl5lzLDb
IQ7XpdPMl3AIOkt0hYx4hhdRXhhcuja3ZGevfgqc9CxCPb8km1ub8AO/uvq7RXd0Q6z2/1gFGSKr
E/Z8MUe7/Aj4w3gehNwpHjjHdtzgjwTkPG09NFR/mcneY1yls8k/tfVIJKrzHg78ADbNtpvTa7J+
ee0tuctPDL/IN7eozJ60ApwNPf1yj138CqbuojYW883vROzw/+PwlFGNCAzzDUGaxuhCVJ8FNbRu
89nFeEMbXGFnwNotE08XCVjMFYKVPtKeyrq/jvwb3L4UenQYTqyFUE0tvt1OSELNbGsvDt7OiHnT
ur9vAa/eULj6mMqSlhHuRMS3kxF+b1Zl/yjapZ3ZFqIgewTHU94QQzHGnbNooBdxLcpqZ0AKwNn1
KN2lQk+gpTA/y7/vyG==