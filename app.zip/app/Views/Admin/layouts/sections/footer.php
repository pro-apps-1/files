<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqiCFNxgmOLnyyseNVv9DC13uZeoBikikT6FBeahXfX9k+gswToLlUjvjcuJ/eUJCuDzlBEp
m2YnqYNNRuoqgQ57fItNH1IvJMaWJxmX6/qo4mPH/pSzNucIu+dApVifvXiN0WJPdKUxh6Nt99H7
f2oaKG/gCEncn17O0Msc2krxn4KFSaQFUUnqpbaQ8WnqzWzq70Q3biIBRQuAVUGe5+GrdZ6+hDXR
ttEtA1Lj/EQh2KohCurIWFPo69gc8y0RVsZ2A8Mbi2AXEY+NIVLnj/1LIwftQ4A1pFNQVrIAh/5S
pAbuAXJih8b5aJYRVh5R9NWNTeGu3zdfsOeBPkgYBJG4MfgVe4U0dvRAN3CMPCJqBYnlnI9hLtHw
wsdTJrFcwK8uNokvFT/hcQ1E2K8OuNfcYLWl48GtMfYJ25Xkz1FuosPZVt8Wzzk2VBk42DwGZjk3
BWcRUX83F/YQO7uJ/YKkK8AJJ/AHRK3rPzMSk/LvOvt2QfWHp5iUt6gY5Pd2vgHhrn+eZJqrbkur
bVq3nPVDkvpewgMKqDLPgx8ESTe0ZiK6uzRDuCVA5y903a2r9tIuaG6Ha0lAMAoIZVnzHivDeUi/
pT9gT6meCg6AGnki556RZWpXufvHPvDP67i1dKk8nTkhwzWOEQFGknP9/D3lkTULY9xz1dKJZ8M2
gQVM7wXSCMPMhcwqG0DNX5VyxmGgf9U5VAC336xL3q1ILYWXbfZq21VE1UQMksQWq9z6MVTBrBcN
N021ICeDheYJ56rtMpD/GLT8FxxfDHpiMtX2jUSEHHwq0+Y6wHgjQz+isKpEhFqFl6Zh+ca1dtk1
hRvdlwHoNGiigVSYWUzop6t6wlPgPLMEtDRSUCgd/Hg/FeVk/mIHaDyLprtjNEzzcEBxs0xbLVtH
C57hL0krbEy0Fncr4sjZCZzOEry1nvkyJ44WV89TRSKFchmgkZ1Hi7bsgnmVFM4a65CgSjX8gTj/
R3ss7aDGuM5HXIvdy4gRSpZQbbRrAffIJLgnFkja2iIEs8BPsDAN2lXqyZxro8FqBo8x0gA7WyLy
KGHYZoICtLzJ9X2EaWJ4o1FgyWeCiKXwdgddV47rI3IdXMRltEk1eOT9Rno63s87I8N6kemscCVl
6ungN/Z9PxaNRGVoVbZebiPJslvsAWJYfBXEB/Iil/Qc43iiethtjhR5Gh7tLgdv4EwmU1JE86Jk
pBaQGF/OOv12PcqYUOhw+/jFYUO0cIb/on53hTKes5z0t/Dm1gXDFTtoUwcBTQf5JeOkrle0QamL
Rf+k6dgqhioj6NSwxG==