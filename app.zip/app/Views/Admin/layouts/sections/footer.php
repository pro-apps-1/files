<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/c++hXy4z+/UNzlcqDsoNY37OlrH5l77vYua05aNmyMUOJJnHRluAEyI84MD+AOrkkvO4k3
uoEaNIzkXsR8Hd1DIwD+cIIgOzMqj4ls//b8mNvJ9Q7yMWIvNZs8PrPE7VeUru/yL17HJLEzOMue
UdGKGOVANmThMj5hecw0ZQARAvUty6qo8n80cEQDZuo55UVz39znYJbDGwRj6vPu3qv+n2CvC7OG
YquzLCt3RsYWne1zzbKfCmAnbPkci8qghZAeUUReDWkAy0QnKAh9nAMwMOXdwtvr+pkvfadIGPoh
YdrK/mAJKSk4hJkmlRUkOYE+6c2rfwO60KjFUGmD2QcQ9bDNtmb8sEhquaaLMofMuHkMpTTK+s9I
nUVonDXagdEEs8LEu8bLabfua06RpW1Qrwpqv5Dzg71A77fRu4Q89Ei76dsOdSTA2EDW7vcwnxT2
YJlSJBiTk2mNTJKUrM1kLdgK9Ew4dfIOV1P8DKWDg+lY+ZAUFs9PPedO6APO4wInb0yUxaj7Rx7d
WmZdENQpAE4uhf4HUu/ahAaZgysSuV2c2IeJC6SJyCvOjyC9R0FuTYm9tnC8HKkURBIjG7VPeuQp
o+mXYzaf6CDA6jAnj7/ZtYU1BrnhDN4WXwXyO1+FsoqGMRBqgb3aMlRoblsVLImTkOqP5kvVsr44
t2pzBye6crCT/8xzbokGGZMWD1TBV1L8tdIwrkPubswePvpJaD7Kr72t6rAAiWt+jXmBH4I72+3y
ewKBAJxlzC8zgJQvc4bxhYqmsVMVQcFJ8q8JSvYpPg1UGEYRidteI/ceydNKLBNqldbIPqlZ12T6
nm3qgtdlMGoHpHcHwqwMyk+8lZ+jqzSi0x+FbwWFdMvgeqr2/35/iXP/zW71w1NJ4FFVZLokjQq2
jFRhv3UcpeamsDjYiWMEuqnstGZ4mRiiPgRzOln1/QZHP/M/n3aQJUBj+M6mGwVKmsLl9/XdyDvA
zzq++jo5MjnX1MO4Q3K9kZHwFiunLLhObnHnxsb5w6w3BHbq0pyLdllqSAimy/p1QNShLXCtHdyM
3xygU3EoUkvUmkcwVy05pUVk0Dz7lR0JQ84/dP6VGp8ovjeBwGqLcG9wlOFkPP7KNpN5CzonKf/S
xh84GXerQDtSdeCWEDcZOmUjv+aLcgHbAWQ+iVqzha6AtBZZl0lgJCVYUoICwXp2l1+rlGsRJ1g9
ivXRRsIDXmAeAmeB6GgwiBKMK0I2D/N78sGiKwyJHqPZzqPE2Vj5uhH294IcE16sFWT0Kj6ImqZ3
kyDm1uy=