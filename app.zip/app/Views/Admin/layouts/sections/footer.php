<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/scLYMDEgiAI6V31YYrMDi9LTdandOtnO2usl9U9mioqnVBJouHATAaw8lC29izKS6A7dYI
IKhhiQcmDyWj28ZiFJlhO/XIaPKn7AHBe+/Puf5f9teleNPhORy0sqQGA2ug9lsvTCBnH+ket+NV
Yglp0wEUHzrnLBB6mkf+MnvDU+iOvnof2LS0KylurVB9vij2AopXj5206e50aRKVwfX3Av4i1nhK
aBBPQ1IGN7fwBYdKekA6V6lkiCUsp8tNU1B9t4A2h9bI+Gfx+6/Lx3YILibhfKRgPTtjrANgmLk8
IprqOkKS5tbn+XXsT5wxhvV48+0quYJCjOxHTQ4o5qto51G0A/mErzkNVD2BqMhdaLORrBSb12hz
idathaXw5qNGSPLwC11mE2dMbfz3EqlaOt19uQGH8wBzjRIJRf4i57Hr/W82b49xUntKG4HehIG4
k+eV6UDmK+7hRcxcVW4SaztcGKji1G19vEEs+CfxBokfWufOsAC/a4OLLdHHmrxI+3SO/9nsJmFJ
f8m1zr8K126AxlCKY3L+Ciozs3xe/jcclZ8PQjOM7tYmrh/kPgAwXx9JxdCM8KAdi9NBrWUPc2of
zPldM223OOYsXBJ8w9WCzv/ur5mjzk/aovWVdz2FxdXGse5lzI/V0+N003PX2enBKjThDPSgBUn0
pTIE2BK9mBkozqgrkAIf68+hBhw4R6UFyBvWhAiR+AIXj5ri/bZ260Z2ayGk1Dj8p+3YQ4Y2fGtY
QxSlsAnPWOrk+BQjHcPXAiJrRPfo63+2TV625p06qqjgPTwc6CLQBnyJ+xVIAT0S//R98yIz31N9
P8LHG5jmozTwEUYeD2BEikDP1dNYXgxcmjV294ajcEWegz+5SNz2q+B9nWoziTc040Lf4KBL0TM8
kTBjQUm2FyVrS/MFUxaPe74iYrmrX0H+eKCIgbfeZDaAvOydBn/ExFsgZ2LSKVYs2XMpTuxE2+jT
x8nXNIRHS425rRdVQEESFG3dtrZPDeYHyQ7Nh5IUO5xAqefMkWR+9zwIhHxFA7nvymLqVxqb6Vfl
9/cXbkwjmOI4k/JlLK0JejJdB82uZ6lB0tSM1c5fOHWXDVkho4+H9E2zbNEJaJIMXWLIwG5j4MxP
ogqdwVlcGKd5GzG/D7MUS9yMTRnG3sBXZl/3GwK28be3CDDIO71avC5pHX9nrc7XnpOIWaE6oNSo
1+Ia2ZdnyP/lsUXdXqCZX/BPMWgg2sE67bF0Xqer4jpfoKglyqjbTsJ3T2ixKo2MIQpCjJfnNQTd
PHIGXuRAiESuJLhO+BllV9ns