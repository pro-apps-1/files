<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt2AFfaDHuFUo4khkc5TqyPn+Upq3Ut11SPnIx/s2j2aeazmo51PsnpnzcHuSTsQLV1v84q+
/uy/MoK2+N5ImJq++rJv/BTYW2FZwaDnVfRghz+OiDyK9rmh8/mUgB8xeV4aHkzlh44b8o577EwJ
OCQAAxfRfpS35Oo62NrTxkZtl67Aj1nfEHG7LOgSHb0OiLL4dAEcpg5LxvaWSnzjWjO4snOMDyl4
zkeNinlqmAd5hJjmZc4X4+fJlQXtpNtawGsP51+MgeT25D+EjpKkAQLjijL+QiGrEE+6oTegRIlk
3gRTCYn4wcdnhaiwqCez1VlgpLo7QPTDRN7BMkfEmPizJ0uRCsv7oxds8Oqo2ujrxf943AubWa4D
Touul70TiDIFSq1LPfbw0IlVbu6gU25AEaEZ7fuWdaK8RShbhJ5vC1eOk/vAIWElZtigJK59FLlu
XXCORUbqo6PsQhD2eEq2vaRAFGsTzaPiYWS+g7YvhdvAgpG6SRQID5lHQ7KmS+SwVuHo4co7Doqa
JXeoDCMKevq+tWJSS4zjjH2IMgpAlCKSg4lrtYxCUWReZMQg6fPL9esmYUa8ftNE2iMhjevSLpwC
OZCZgLIJLRT1qNfyyUOSm4nOtLZBj9VGakcKl6JET9cSd0JFDhLm/m+rs6jHs80GM+EOtKNKjeWX
j+VLw/bTnAGC0fCNKrBQuAqwq7xkjjpgSnRNwYonKz7xFVFTVf+y+luMjBB5p0AqcaMNdhwhqqaw
3EaL8i9gbxnIL5HcIaD6p5un+kG1m6gSQItkLSbiEkzIrDVvzfaxaJvIis2apOUptI4lEkysnjQ0
oefSgT/pgEnDa8x7CVeJ3F1LE8IRehpP5t/OK8M7noj04tWvrxr7aKaR4YPSf76R7M90PKWn3c/h
LKm0gRVELn/NTaNsGKBwlVufhl8nshw2CTjVqaQ+rfJ7mIoCH9fzUCFdPSysd7g5gQobenFNTSVI
0fZyPh5NNMf0YH7WzPBLB14Mba0g63ssAX8V2rwUhlV5phvYvKtY7VOCgRVcShfy0yC+NvErjAn4
v9mBtuwWlMS94xUvN/GJIx4cQofXCxy2ykR4AMohNk6bT/ZuxwUHAXVUvwZewN96EPItdZqCEVz+
wssI0LidzboBkAabnIR9KoZuelYD/Utd+1YEm87C31X2fIF6Z14EZtpwBwkuPqOL5DW1mjyFHG/R
xc9uZ51s603M/0vYi4zukbECLuSA2S8RoL8LQlKJ/92+exMp55aAhse1zC4FcCJ1VvDQyqBEV+fc
Zbzi5DYKin6sxdK8FW==