<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy5eywXkvSUFTwbcYzF7Lgx7bsi6NTkKBPsurXRLMlEvVYqpknzV/66lyqMVIO+sos8uuarP
rutbwIU79C4rcrb159czaGhWE6XfI9P1AvMHHqFeyT11seQDr65GQK8vbTbFgDONS7E7uUP1kgM+
jmAwIYydY++hzEGB1ONy/voonBMOVYrlzJIkvD6NdRH0zYpVh8hV+XPrqOWgSvnIVo3P3RodEFCI
NqxaYcQET8JcqUC9bni4KECn0QeuFaFtCwa2f73U7N0fAkuXIPj47u5uMgTim9ZeVxfQbH4UKV6k
5Rm9/uRY7j7SjLDG1CiL+6Bd5ImN6F+b8DJxfMVoCjuCPNJ5BCjhYtrM1KFiUDn38MXcoig9YNbx
VB7HSqIIaKAU7bGmTxZll0XAUSzqANuhJI8J6kfa5FQJzf+4oCvxNknTHYqjGnKPSRlH7RnmHGx2
uQL8c4n5U9GzHmZbWKWCWKsuj/guNgHIx5l56CCHEQ3JhKWWe/7dBWPggvrSnbac2SqkpFB+BiED
pWrqe2j/Au7DGKJSw3TsLwESX9//5WGz+Co+DyA+PXTi1wK6VMqlRS6Q5Lkd6WsWykcMTmyX04Gp
KaNujcViw2rqCYV+dpTZsk2/Ypfyjql5wD1FP1Dpo324wOVGHJwDIWd9LIpkPrdSKhMAkr3K0JU2
8RzYTTW8jw9QXUNmql4v74AakNgiurqCTw1qo9wQGj6JlgOR709VPKK0VcXA+LC4ytR4LFjeRlVk
42MR+UFxsRYUv4RUSxzAc33us2NVbwfRgDOHVdTcv5qmA8rh+dSfIzidcIl7QwtzLd+NaCHeHsuR
EN++ab0E15AizKw1e/d7I5beFJyEn4K3/jRnVXuGn3CIrO7F3B2vmNJYKM7f4FxvTFEoSr2TVntg
7tbltVfrrze1ldsXY3Wu7xVE7NyxFscbHzJq9NSPmMesy0tO0KdITyf/TxIQKPoOjq8ITs34KRD1
yICrcyawesvrBFAXS+20ynqdNdb7ftdla+0srTd2HKzohUL6Sc3fbtf0xgkSz2XPBuGJeGZjs/5w
ez/61VdxiBeGLKrtQLn0RjJvcUWCm2FTraN6WL05bD9a3L94nNiIXz9xuTarOHlK0jvIqnmIYzFz
NZyok9CtfIrYqVSz5oQ4cGA6JlFYc5isNxJCd/FXy0ucoxNJNKJRJvwUc5aasRTEvM0k2vX09k90
fVvkRS8I8/NPAdmg5TjznxlgATlrKogy9tpjbBKbsVsHl/PlOSGesOHI2KEO5DTHwRyNBqof1MnW
Z+kKL2JyHf7WMBr4UAHz