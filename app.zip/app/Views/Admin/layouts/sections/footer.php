<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxNnvH9qOjub0J1mCUItfEZ1Aqktn5nrUCu627wuBrF/Zh6GWgqJFv/KUTZJR3i/dmhpWjHJ
QBw2xCLcmWFS+Gg8O8kWEISPc/sN10MqHjlohWkuoQOEWYiKKBfYtI6tgda6Np5iYq2b+ZMwbzut
7ws0WEMzL6inLTbReqiTUuZs4cXqe4ACuM1eOT0Tsorb0gtHx8hG/Zw4JBeZxGX491jIQgPkVIcN
yoVXAPkpbw788r9WdnM0jkRWZZARXjrTXQKPfdAWOfiQetpwyoP6lnyxsQGPQOkgXkYDAyC9+Naq
TdoVMCvekMWlwy7nf4dTO+wMi/AWsL8UWl1bUC8eY+iIkl8iCGsMp4roLcqLsHXr77P8LYX0Yo1P
aT925I7kuHAvTSY6qPLXMHO07dSNaANQvfwOgq2oIEAgzuDI2jRhVesFptHb9GHTYqB2M0QQmPAZ
mGymrlae/dIBLg8hiQAB1PEek35AHa2mhR/LNxhIIna5OGnMnXEV+eIiEZG1xaYIucFJKvNIcOz2
bRfl8+2M/vEsyDWXpfRKJotahYoTXhlRwFb/R0B8sgm5qOh29BUoI9YQA30/P7ijWbEQxawztbC8
YZ/fjuDo4wrPjmThjZ5do3QwRPlz5nscZ0aknc7YQQtEjuK8/PNuBrMxrkx2GSAjf5CSs1y3hgmJ
IYR9EH/2vTj+qqULv9ynGTtd7n5oaJe/HnQ45LIeUnqV95jYU+SxByHl6C8YIDjWZltnB1guRsSX
VzZMXLaboIPRRs6oZwZ5hP1mbD8TnCbnV/R3R9EEfBb1t7mztMDWyn4HOsqG9h7LRmbqWWPVs6a1
VAHRcTJ2QTnLlHZ/4dcB87BDskTKc0skX1jj1wIUwpSlB6E6SkkFPByMiIqBpvykZRD1enXhhpP1
9INuetXroL4qYNQIxx2I/AUeqX+6qa267GYxSZverWQHFhw8VzQm6Nad3svuzCM3Hirtjka+DEoJ
Mls+zM+8MXq1AWmMW6RJY4uv6kFewTWZAhOWlHo1hFXVceoW8ihTji2iK6+1jbSErHu8zzoWq+6f
4z+k/jJuXJ/Ml9Pumz6GO0AFzTt0ozOOeejgdYMmVwy3XpY2ilMVk1Z2eQU6Y08IOYeT5Kv2MxIO
LfWeYwkbSp3rkdiJ7Mok+2NWGgrwCas62vryv2HYnESXH42AzEL5jZyktZqHK4Y40mt5YHO55/Rm
FxjrvCAf85DZX4SAXnHTcAnozNTyUVFmKA9AA7nPHiSITpqjGJRk632Ulx//lR36EpqYuwDX4SPL
ZmrQ4K0gOjqIRxcre6roEgS=