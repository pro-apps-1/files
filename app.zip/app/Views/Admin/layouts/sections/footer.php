<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnH7istL60X2e8OcJfcONvzGCEXy8qyu3E04R9ekcVX2aPhIvBvznc1TCdVH4vi1A2UuWkpO
0S3TVg+EUMUJMYk0nuBl+jdugfwmzBanyLdq8gECsEALsEpzqVGfHJ8BfFi4i73g2CJ6zMKOKYDR
qJizDpHBiMqLq3l3oqE5gDMTgITOcLYvGOfHjvObEtZTPsYJZBtnJr+yuNr+RkwgKTZ1eXlytwDs
IvTahQCx36RzN3frIReEC0F62GTuWykdSTSFK9dfVR3196W5LuFriLLpNEMrE6o3l5T7Cost7NuM
1tgNvnF/8AIZklEMaAHmRHFhtbinJTZacFUnjIiV8yleAA28WXYHB82S/yvqvBAnyLLPVHFHuN5k
dtI49GLh4TLV4uibkV3IIXkOhnflUltEH1xX7uugf8NNd/xDS1Gzb+0Kj0lGUYhFzOUlDetKHi8V
lPz2VHZaKAudVccJskM5funlLsovmjMWNixqksT6Kr4KnPwq7YlNlkVo+8YcfSoiBZFk1mljJhu2
KYTm6129sKnAT1JcnaAVW+UQlLJEgQWJW3Gl42SJhThtlrdKDdGKRzqu9MElEt+coL50tjaTdUET
ET5OLmiTOa+Wg4nl+TbXRA8BD3QJouaEtr0sYbQhdnqhAa+hpf/rs3NkqAdrLapmGq0rK6n1UwZm
VDZq+wY2v/TrWJM4J9VyGytu+l9TS3HCPbWHx7bXu/dLgMoMRwdX62cPY+BGHDjId23/6yqjGmHs
Yh01IZLzPtsav85sWnNi+6I9o7EqsfDEzlQBuEr4lj+s1Dm3NRfY4qsktJ23TzNpa3t8wuwqUJMV
PuEPvnfczzxaTJTLFPeOd/njR4YyWTbjP9KZjWS899G/3Rztw8Wp2Kx1Q6Whp/BgY7PPUWS2ErjE
3YydZrHqdygoAIlnW1rZ0KFdxBxJrtIvkBhJO/awgRvGOAdvfQnSkZs+wo0rpaWjAsJNyG9FzyFk
dvMv6u2kjvFfPba5OtZOK2AnuNvfDFOMDtBwu1ysRBaT2gvXI3P4VilGXAbcenvBApxkCWvxg4gw
YWks3Epf9tEL+oSFGwFnfUmu17W2xQJcDsGcZ8+AVGoDwpJlJ7vLCg7iVNa/wxe6Pg54NCA3p8Kv
Ddm9WdWqtUMOM0u+sRITcJe5zP4R5Mm35SyApa/akTbgXmkk0MyCwLWqH0pLy15KEn3MijElw4Jf
js+Cj8OPoxqH7MK3Mj5kGY/KBjCDCz5X15agKUTqeCT8p4t/lPi25LbDrQ9yfLpVTkbH1fC8hWbC
wSRD77JH9WgNXXB5kM1t8e4=