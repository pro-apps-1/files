<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/yZQJ8xiEM6/xbDgASOG3b8KEquyKeWvhUupeUwAV9KzpN5Fj16M12h+JfI5oZiuFztg4Lc
0zT7a3RwnoMo8hR1pNbKcW6jb8oCFNzpgavSVCaEXTyjxCKYf7M+cgQwVjapd77QhUzx52QIx75L
zde2QmqFzvd4E3rImkxeiccxzICNBhp6Uwq7ZQ2r32HDt/CdobIRHNMJsoUzFLKZDO86wg0tulgq
66Zownf9cMbNWWYdIQ6MLLj/OyNcFUPlLcimzdiIHdElA4AIKOIlrzpiUzjgfdTfXxIyq8GaM4Zs
H2KR/qv0x6Ig5V3UvxveSjX9JOWVZI7dxaB7Nnf2d/e45bPQB/hxX2ky67+SVBYAGy0l5XzDS7dR
WU9Oq/mDwXcN6k2QT6idAsfBQ7mu1Bsln7cHUkFhJGxYo2yNwPHzWAs5waAV9VOF+9mrJWmORSWm
cM/RXlpGgrp31QisfEn8kHrbfOXBFsXcp+j5PEwGrmBU2/r+TzZuVCJB3yKbd/H3MbAHeaGYhP4B
XItzyP0W56GurOpF1xCEeMTAdIjXR5umHLzra+cssmQh/oJNhqCZ5ByttOa6h2Obv99gCK4rJGTG
te54MTZGv/gk22kPQ+gBz6XX8O1cTykMX8Tv9LhAHNEb/lQfnwJmO+SBM+NDXUAv8wLbYRfM2x8r
eChKxyjcw7rvXLrEtbfDinWwJbtfzL12LMQTsu1f8ncSc+ERDlaX/joma7cPTomD8DW7+HSBKji/
cGguHS+F+eWSa7gHUVYh+Gzpvabld0LjM9onmJZT/jtQ71Omx5uJuaw42T9vFeb+qwXKr33WRBim
mOufmXhZDWqA7Bt4j56vEzXcznv5ZkgXDYjOa/eUMMllcys/4NvJlI2z6w8XcfaHZiRg18T8+bT4
DcQeDcl5zeo+m0yA8xE1l+PXjh3id/jstP8rarKmN+YJKdKxjlptO5on28NTvTkWUT5+AisU/Vqi
kPRHngMR8mB3iuE9VqhmzvITtCqZHgXQB8STeyJiIzUVLoufa3P2AvswkRq5tvoQ294hhcu6aRw3
vrgNpU4anfhlRYHqkDDvVweEHQOuh/F6aMWgAc5veP+NUPQcTOCfQMmcmPplKjHEOrnAw9tB2U9i
gpu+jqJMoWby4QF/1luSAszxhkwfsglzeRYMZ2pDl8pIneZN9O8jmQ7bZXJwTR0+vK6IEVYCsJWS
/Su00AeP0dVIvGXrksxLKz9b/UavuEWGChKBe5JzpEpIFeaBrHE/X5UWURDpFjd28/KnTA8fFVEy
8sKpmsTppzQNOX9jQn6za8BSZ0==