<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuWZtbzRl2AG8k9BV45esd5QPQBhp0nMdj8SgCbVEibB0rJrScafM+Gu5A1fdBcc8Myt7Si5
+U4QI3x+xfwH2FjtmvLLIUMODBWFFuAMXCSweh+fWEOK4tCOA9jsuQPeLSQS92ogrs30NQkYxyba
L6wWeU8ceAXgdFmxNZe4+f62cLURlosuVeomHK0Oi/vGoLl5IarI0NWZXAX06OkvXjEjWeEUKBQi
xqpOhI6soHlBLghvOAdfAbYI1Th+dIhs6h4CKvZqOIVeMQvUGGS9hHbYkf3xmsbpVsekpp24hAa3
iW6ybpbYqvk3fMr9P7fcXClQoj9Jq0fQxfcBt3iMbDI98j2n4wpFCizs8ui0ZTB207QQTsQpLvYd
sCG0wQav8UN3knpbR5nn11gf56PTBInU4bmxcIezrTJZki5861I9o6RJTZ/auG2PHYYEQkH5cWCl
Usg2rqTsZGlYq6ZkNNPcX2newbaBIZF8qiWXkM3YhVVjPzX72Voznli828ekkONAU8xQ8j/x7PRD
UZSi6g7GeyUKOGKai0pGkyLsFrLeK2kGI7VnYS36aLA+xUKEWqvOXeOuTceSjbveZ2FG8QC7d3XI
deUr0dcWeMrqiQlbx5PT1DtLQ4Son8XjVmsP5fNr0t93uXHfOdj6PHUAsbjSgxZ3VSimb8AM2mGa
lW8V4fX7rOLtHUTZ+td2pVDXosL37dxIjLgHT8AORHKqNbgqiagvBYlU3k2S92X3tZQ/BS6RcK0h
7v/YUx3j65wpYc+Swh+iOwFwHTHYn5Ivw97ctj5G9JhL5Q91kk0YPnKLET3Z6YygNjQ+CQlTpgNj
0Dkp8TU99UhOGEfRwfD50XMRZuDguKCGgv2ZLYTvTxKGKzh89UJFZxhIW2YylQictSp2RNEXUYfl
7BBLw7A22ZkMqfFIgrrQ1ZUWcgFzY7KPtalSJgcKLlJmgN7WSir/WJLoj75wzoJtaa9fJlqDYgYa
Zkv9axAt1uV/zcyl05i98PLU2S74CVJLVj5nQIiV0aSjwVLtIcfSlpHHSx1yuuLuWudF1YhbnH9e
p0tbxLqUn0/lzRLDDA7hPaoXxfqAGFdgqq/c5x4vKe+gwQa60Xc6Usa3X8InYGyCaDyres+pVEX9
Pb7VnXu4Bi2msxiQTQGw9iuj/YG9+isHYfPZrB3ARBUOiEMNRn8rc9Oz0EUsHn7/n7aaHv1vfWDi
xKgcZaYxAA8n9K9btmBkajSeLN3KmF66Qx2+3ztK1v+Hx1nCFyvYIeU7xwhiHuJNHnC+oPANYsbP
Q9h/4zILH5O6UvkaXcSc/X8Idz64lBJoU+gt