<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv8r1mCtgFiqplQI8CrtdvpLYx8CyjT8mBQuNy5kS63m953rIBMZHjNGk4xo71fR0l503T8l
e9bswTbGnlTT9VrGyny62cbx73AmU15MzptvbLYqdw852AGLtQr5yzYXOtu41/x7UIIaczKp6pcJ
l9fnGUkgc1W25vHDIxAxSDZNnSDxmeFCTkm+io75fV7q1rlOfDzVmnAaHb/5z6e7X0zArJ1M5lth
cYF8aUF5HOUAhCKVSAivO4Atxuc0JvYEjNKqRjHLK0sFFSqLpROcz/6WChfhvrD3+vAl7MjCO8A2
/4P4//QZ94lpReq2zFGa2i7O3wdNH+6/utMmMaJB5Ed4NB4UbohgzxlTzBAqFz96MDJ0P26uMvQ7
KnZ7UNoF+qRiIIEGwbNubaJOrepLlUtSPit9dWczZCAqAjA7fhInFGdzYvv6x+FVNuJ+gdH0v8X1
0yrlLxHadnToBMgfe50L3aSIyH7vqtM1h3IQ9wWT/pYQ4Fw6fZhOte75enphaK1MN9WlMxfA9UNO
y3CLHjF6TgsJL6r/UVfXR2np4Yv9Zfjd9sTgelRY25PZfmg8CvYkYhs3pQx4bPSuzQfRFo0EqYAo
6w65k/e5Tqf2fGCZco+2YGsptA52l0SjphmHYgxuIdN/WJeEgn2XVz0U/olPSDBUnM2y/uLMIhLT
Py1R5N0WBrpHlsqT74cJ1Ey+puVi3cjqBevKVLTCpZCEt1CQgZZSvNIQl1hK6bJfn3hW4DV0vH99
/Mu0T1PzUNCR0slmVtS1a7ZJMuqW2JJ+k3yYIx8PELBWN0BX3Ql1Ai8beBdS2lqzWM80ZzjWHqz+
WATwyRaKr6r5yC+yRjVjDSEIA+fN0Hm1VUq9oLn5zm7tPNHmDO/0LNhfuXRaPYOAMS//PEzft20z
+/abVQo73JCBwLndz4jdg9hdELyOe7WTC7Ja4u8aVSBf3HfG5O1guFtdpcB+U3G21OXGL8qalHLH
MTvYM3HvYKJlEEp++FYHyWB5Y6dGIgzH2bxwMpauyYghY8LK2PFxeo7xizWdKEGIRcMdt2Gpas5a
cD1IDskS7tkCJyBJzJEDGWhJu/EGdo9rVgD3kIWPTKZKXXBtaeUXOuVIScP8PEgJUvOB2UbhwbMf
/AYIKJfB7i+aPnCrurr0hgniXxGsNfLoHsQ2dHN9bc3uR7bCC5btJzLaSiB3q11yR0TSmDLSQVsX
WOHFlGKYDBNySMub2Ncb/wSdh8TWEzZXcbCcHk4HbG7cW1MiIeaQk7bXiMtJjUS97nd1wqOgzAaU
1mi0/06Vd+TdF+JMU7GDzP1/qv0ZWNzkcT5UQGUJ87vNpnQy2MO8UtGwFkXZk6ou3KLIUWPzajyP
HsgvmCmVPMOVcs+I6j7Zd3A0KZivcNLlC162cE8LG4rZUwpMpM5GWdhAWk6+oczLcWKgm8koHtH8
8z/Tzpe9LetcWEpS7W3oUzUg/2C+FfkBaUa3DWGZ55zI6bawZ4a3PVAAJnc5V2e0AZCa2B163276
S0JpW8ksA/lb8a0r6SB7D2HqHjK2rNbkzBZBm1KJ40CUp5GgePusAV9pMwnNlGFfeg1tSlQlK6/c
lZFIdnNFdNC6paKprqtRqhppjQGdHOQlppPzeCZj9xiprhvL0qFgtetVDSXhEbPazIhhWEWDk7NK
R2YpN3z1b8uUdG4EUcvyr2GpNaNnGCpFrbKhtLtwpYpW8xccGZcho2amKEmseJaYhLWHy47CXNn/
hG/AaksC0HXLm5Y1X05Hli1qVv4CKY/4suAmmOXj6MMvqkhKhTcUsWFMJy48XbAi2iI4v72jyjio
O8qJ9DI2KAum78yAxg/xlxC6MyRZN9CaxeS9QfXGFKcrsBC5KP7Bq05k72wt/30oLlzaY49tC8Iq
//7qy7O0sta3ybB6voI86z0uvb3N7UDsJzDtmOLEDdALwkBy6fimrsFKQhviPRn+SWtPSoCuqIbX
PQ7nPX+HZkzgr1663LmHHAOvSQlzSNgEsNBF09cOZGwBYJQh67Sj90==