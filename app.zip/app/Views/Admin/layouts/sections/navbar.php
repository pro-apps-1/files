<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpYXl7sNFmLoRc8fNgOUGurHIRDRlGks/OUujykRBL6QtdMfp8QB5iUtHPItIRo1ITfSVaKC
t18FoO+9q28EmnWa6fXGP386KQE5AS/switxKHYQOuc4eRDITcvnUqoE+ru7w5AjA0pbZLxfAwqi
CySckcL6bq1EEpW6Dt90iV2wp2uegbH5WwvQxRRrSGYrjXmpBTYIBrY4QquQBmbBol0qXqK2Ne+X
uc59iR5UK2yBbiSIrh9bN+IFufoQcVmWgPLTyLvyD5SgexbHR420sM8EOYPYAeIK63eGDJePQUq3
+3jv/o3R1k9dLKYnULz4DHBfne1ouzJeujGRhddzUK9y9mwekvk0r+me/dqtFhY1UBdIzTR9wgJ7
s3SNbDohbj2a/M2ZCvr/v3DT0qfRpoldi8Q1d4cCaVquWCP7L64T3WK1S82zjFRJ+j2V0L8EYo9W
LydpA4fwApwUOwKXrYebTjxRSDJkVmlhkqW4T/6LXaxs2psEH3HTdLfj21FkgUm7dy+F3role+DZ
CphjUqB4CtyJ5JM3pnyTni+OeaPZM1I6l3wQ8GPlogHAg3q7jyyqEDLdl0CYq0mQ2dx2vkN+rfKQ
D8rQz6Cf3Sb61wqMTXWNedsrdtWFDSWZLMFJPaB6m41mdRYF8RRAZh7DQo0Gqyx6yEDZFbbbKtTp
2Ox0Lt80QmhRAwkj1sWVBKVE75XPuGOE/WFE5cJYG5pCNv+DiMS+fI8+KQA/nvtSKeADoRorAlZK
eL/vX7Uf1pJyQu2Toggs5OzsLXTl7xRDrdCBtUpZqO1GQuwFwuoJ76JQRYYny7cZrtBc6jMqGgk8
Pvj/lxG74MtQmiZlxyISVUCjntPWQ2/sbZFabsODXCATJ1cEcPR0kvKF/vLPYCRYrPvOEuiB0SkD
xBwq5bT3DEAy7xxZ50jw7Z569H0E4UOQIlvPf64L0FH4+o1mdqh0seG95aaauzV+VjB6E8TG/Fhe
6M0SHv7CLUHOXv+eis7AjyNxGph7lN5VBvUN7pIk6nwbM2T1fbewUvrhlo8BUCLft5lusDRCZfNx
DMbo/2eAP7mxhxDuk8QNR0cPOillbiKU6vfhf2ZHFwEXZKIqnt1Bf+L8+eeekXJEUNhQd1zKIRf6
OUQfBx8/1N57WXvUQm/j6dY8iarKjFNEk1KQ8uVzOtdJx6zFt7z1RRXLvAkOOzxzi8jTn2rAADKI
CiwIrPjzeXj7UF5EWbywT4hvtAB/BkRlHB5hlMPyYmgCrK0tBJLDFvOdfQ58OZO0sZV8dTrish+f
FcES/PajsbALBqGQLQ2HaIE/UhSadCKQBuH/+RTnKUefxt9Q/cOX7WOV7Olk7NeASwfxvInwqX1W
yRQeYhS8s2xo/m9Cau6LUY1sbyFoil/ORoI8m4fjsHphRA08Gp11v6BdnBB70D+58PgvUrifu4Bw
XBwWd8obCgkdrW2n27TMN5eCDrWag03Z1JgbSs8RuXBrwaEuxPDCHBE1+pj5BsFNPx9aPEEvNjte
Lw7jB8xLaDFyzOaqZxktD4ccxyRYysI1dkc3eWf0ctyA85Js5n9QXGKS4VOLqCktJPk3nbtmTkRK
IMA8/q5ZlgmFYj4jAUWUGuh+Q6qApHCZiBBGo1pDnDRJ7jQbtQ5dy+OzVMBDWBW1y0M+/jNfZVWH
6ECLJoadOC3iLE+FWZV3wTfcGmE1DAKpyIpo69K38cieE3aWLauDoVLCfRVScqfQFJxBRXkikWtU
q+UN67QWXM6AzGfRSJJaDVDtH7/uPhvMfdFCYkiwIYj4NJbF+DbXt7MB2X2so1kvQTposHpWWeWD
yK7Zuw7XFw9t/IvCsuuS4KF1YxnYe0pegkZShwSRfljBMSL7tJAatLcsBE1gZA4n2nq0IUcpk93A
PSL+Qspglk6eo9qJrbUa1KzgStxSwP6Q//5rof6EtW5aB2FjfLMueIqt5RvKm/McJT+ZOwf25x6q
mtXmPxdFwbRPqduZOrXe6+uONCBA/jJz61iEY4bO6bQ4a4PwPZ4VwCo/MeqhEG==