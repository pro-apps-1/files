<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzCrpzpvg3CJXFPQ/nNy+nEl8/UG74D/4+bR1MRCqYF6bz37qpPFyDvM+mMy0OgYHulM7MdR
8AY2Z0V/7AErrrrQrhp/Y6GsgXJRjOfRIMeVraToDEa8+SgEftBqQo9ais3OiNcjN2ylucZVi/0f
K3TaMIKrH9fSBrVMATdlLzApnZGY5GjT9Mb3Kwyzdmr23Vh2DQ4VpKBWy0YeTh15MYRKhsZu43BR
xZ8cNonR7T4/slXMkLtcE16fabXQIR39J1jIJJJLRuDc1MUs9o04TxIsCj/EPiYcWXvxdeKB4uxL
DOsVMHdoc3eJg+QxU3ZQEV9iRjaOcBV6WDRaKpvucLam5BsqMzpbXvXKcaDbEF0p00A7MmB6aCoO
p3/FPXPaUvNTpSjcQ/Xs5paf2xXJyoE4B84w1YIyHPEPla16/jG3JrNDPpC/Hua1hidzii/WfC8/
vLwkVMQ0noyUxuDVhp6N+Shr3D9lK/KulOLZG5vMTPfXFGCpr25ABt6DJth/pwZX8BrxtItysrXK
XT4+qPJEdkLagB0WexIkJoIS7lmBqsfFBmVnyA4CmCcgs+jTpW//lmRXTqdI2FPwchSqNfSOl/On
3lob/InY3lSvIq1+Eboo6F8SiROkrEV6iiQ2juCH/9JxbW/K6BiHJF+8x1NCPP/o66Byd0RXreN4
Nm5neQ8GRFRD5C5XdogI/Z0sRok/P22N6Oca8JCfYBiB2zXVPjmFIZZeTAJ2AThpBVeEo+oQn4GC
+NvJ/QcWu+VUqk6pNCKg75h4kUjAfEo+Agy38OMRHoUbem0V3tgaufEJYYQB5Gkj+rw5Hl30E9YB
J7/tPR56RT8b9Pifoc1hnr8FBoOVCkrBHzvPQ0mSgFN4ShLRWb5TYUzhtZ8m+DMW5Xz+Cp9+WFw7
6yiuvF9n5X59QtwREtmcDX1clPKFQvFaHSSKpYgCqKEmzDEenG7m1wnOf0AtOXgGuatCgubnPMk0
n1tidw0YNhVb5PqCElTj87T0BBvnR9wo+BWmcflFL62QlqWCWzGp44tUzDibNF5YFi0zSekuu2iD
KfZV7Pe811yuc4bV7UoCtsZ4P6wEz/h9QMSWGi7ixPm8lC2owYOWeGCv4yIL0mtPxDkdNduLajLI
DxIjGyDPFzP2LYBsCpx2+ELhp4Fqab15nva+e/9vFPkvhdYnHhtv/GckIHOm54CvL5vWFGz5NN9e
suuNRfMwypJdLDNOMnWOI+BkUzKZ7b0s4IA8Q9KUjTo3N3fw3X7JWYsgeHtrjEkVJ9KfdsKWF/ol
CKX/OZg/2Qv/r7FY9QOI2bxVg4vKnPKiRUEbK+YKJs58Dl0nxSu76E90CLXCoiU3yJ2QW+LfDlk/
ejn5fyX2B1OL98mZwYNs+JEfb+JSd/ZtMJcJ9aW5DU9BEkAvWo1yjHhJzLbPvVJO0XNWIZu8M19H
IWmGw9jqlPZU6hAHBJPXQUzTJg44/UTL5D3RNT7R72YZrarljt4u5cmt8vBCpyAbFghhZlMnVRT+
SYeYLvNYHuYXtlx4XW2QJVRYfqwXz6mR6toRU2lJgP0g/wUR2DEKeg8Law+4t5FpQbmwb4U+FwhC
EcctLhEnBA/ygpyg4As+nn0M+XaF4VGTfpEacxCThYWH4Ft5dDTeKXboa/AZkeMbGcrGvMxbUYwf
dd2rJksBTiIpO24b90rpn4RI6cZEQYjDv85NjAfK7jjoThUduxVOEXFJT6JJwUvQmva6JdEdrVCo
3Z7ckm8mljJ8qrVjcp7tkZiK6EEVNwaQVjBaZL5o6QuqCb9QsdUVvX9qmwn/FNoLL0S6VJfTg6rr
U6dcD/8jqo/BG9g9ROxEN6UGid4nB36IXjLRDRzQDD97hMJgSzjbwCSv3aIOuQvQA4ge4hKAkiBi
Z375/geIpZag+jfRjE7Wq4O5xVomZR549GJ0QmErQENNotW4GuQoIftYc2MuKM0h1tOsrHRlraMK
JLDVn814NinnUtqVw0a7mz5WqJJ6f7PEAufJvKy43s0TsbMQokgajBt3eaM4K+W=