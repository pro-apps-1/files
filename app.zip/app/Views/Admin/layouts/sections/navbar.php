<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+mUJXcdiR9UljtREbHyPZ/HoLOONi6krAUu9sd+2qsbdJgtjtmE1hMnkhURVoo6AxJa/7FG
g/F65tgPf82Lrg1zhLGvhqLRYkwiDPOLSblETsiXexK0KKj2bNFQ2XbqacNtq0OHAfrNuYNWIs9r
w9MpVumtR6On6L5tBsiATNKmXJy4u9KlozFn8StrDE3j7C84E+MWFaSgX4k0cJzq9NxBEBhpyS5I
RD5yljYYGXzLbCW5au+jM19bgqoN1kNJ7PIlt4A2h9bI+Gfx+6/Lx3YILh5eEc0vBJJkI/CY6ri8
Kpr6/zNg/5ZnGPMUSr05YSRtIYT5FtBhMdM560lmH5caZ4igjdpuRlAxwaan9u3iU5p1DXlQYSlK
adHba6YraCxMaa6fwPx9/cmMQ+fNHoX6+T9k+uzFgcVJ1MAjnudu7NxbOWMeHfhYMUYEo3XXrZXY
R7YLkOe/fxSAtzq++Mw66Dnam0pGqxL45x1pmz6nsbdTHQtpQuqq5LVdOBhWaAXhXaagf+I/xM2B
cUi7GoKG2TlE0aZ44LeMJgY1hIiTEQUbzNrtdAxV/WT3zVkGO8J9Mwg2eKF96/2PPmjwpacHeqpU
K9owXgwWvcgtUH4VJF0h4Bm+aDrGAdxj0tlo69FMKayF+U2hgv/jHunrD0dtyN64ZwqUX7LNNaPV
R9fV2pq26GtIoRYeuiOO5azKbZ7SFTKSUvAhjswkEg4DaHh1b3wJo38xtT+bBzroS7uj6sDOZIuW
opLkvsh+EWv4LetiqcapwcNVykQtjtIpUVGRjwqxDd6flN5DW2RykczZmmJcvu647bbEaUbh35nZ
r5b6qP4bLV91z8TSYfv6BMh9Xy1H+6G9Szl0XrFpPB1XzUVOa5ptTnxEe9aSxZKNz3s6gLXSm/po
MlbFb7dT3GkLR6iNYXvJhf4UfX+MJOti2cK7+pgLRhVrXWDHnQpU6bqg2rcvShCRwT3KjwStenZs
1h9gYqSJtoArNXjLmmV6V2oxzQjtIqOqXMILv/ttwIaBM+9HsDQULKeINjnAqLfpLdET6tW8owoV
6ASgYhfZq4efD/pWILrw/hMTAIuAc9h6Pa2LDo3wz6t9M9l3ZgGz3xjdsh4JDNqDgyhQSCpl5AAq
zOSJCLa179Iaao3dyYFRQMAgqqhcnB6Fc6eGm8NbvSEW2MbSWvBlC/L1siwAAnO+Ua4rhjsKsKfW
Iwq4Bukd0aS3fZx2VQpaLku7EfKr/VoV+5c28rcWkmgM9owri06z+2hPV9ypuWUFIR/WJmDlP5PN
N999rBtxIuI5j/vFIeGDAbpBNjfS9zOqrUEwEk2VqHLxkQGq4vosFLRXhSfjArTWrXd4MoVCPkFu
pBqB5pffBtJpfbTZvDysPNyrmtVSTlFz3qAOtmnP8MgD2XLdu5VHDjh0lmlX8QJlw9qrneSZNQoE
CKAfceuwlaNoil7EdRg6N33RLqvJJllkZLWIyYA/QvasMHSI9mAncsJda3RR4ZaEDp7nrm81O3lH
Vp0qT8L3DuFq/Y2Z9Uz+SlxQdo4vsuqsk9LPEsjroSiuL8QxUEv8ySt4SsH3AxwAoU8AlWzWjIpp
hfsdcfJYoTyPRlyl7en2ZVR2Fm6/8WnJ4P1aG1JiLxm8BUyIxPCSR6Te0soXVA2lJt2F3BqDkRV1
YNixzzaffHorUMTXCnD4/leVw1ZZwWTsj1JC0Gc3l/0sGnuCtUnSwV0jhqPUg8djrCtUcQhaqtPo
HMS0lC6O4hUV3Y+TCsGW0KtO3FKG/+VvMm6bkhKVG9QfTtmnKbZJB2n7/iyVF+xzXp73QRfMJBdR
keYVazWL8ye51nmsEwKo02sRzbclKOUE5r+lseSwLt/sZ7FGw/IEi497BE8niGqFmWmdmkHWZX5v
9AIVY216vP+KgTG7yErj/R8PhSMxoHbXaTR5HljB9RyQDqX5q19oS0A4XOkqjqnZkk12+c1iR9LC
bd34diOhCAjyhHjZv739Ekw0WTHM961CSRZn0nPg5HMrgcGE6ozaGkJgx3BRiJMALbq=