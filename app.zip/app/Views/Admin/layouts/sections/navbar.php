<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPskZumWpCjWloc1sApbjU2LOqCG3zfqqGwwuyifTjylCKbyp9kvxL3Pvgkln3Z7ApF8dRUdM
XeiDIGhtBJfBWOn8tVNsfI9ygRPEM/MiX4WcYUc16hnrgz7uGTDHT6YbeRUKFNMVsJ0aEJzURTPL
UJGgyuaJd4PGBwY0nZcJHiyfm+/fuUgphze/xrF0mD9vEE+xNxjQVZGXQfxB/cWteMfDz2moUFNf
xLNF1ZcnTDjfrvFFso2EavkusuawOB2cvvsxWFm/shcxgvYq+RWdSfyMUvbmKRrUDohQKAzJkYjB
dST5A/U7qQV3Za+/2EUW0GKe9m2K//zsDDk+GtB6Uu5dWqEa404pn6O2hKP2gSQ5HpJJ77x4uhnp
Zpuf2SX8xnmHrHgiVlvW3092esvavN2UI1LuqMIiPcpQuNE7lIL/RHhDzsPZHKWlqOfAUF05YuEf
X/AQbImjBF8BmEnthhbp0VAaEe0mTnpFRNygtHfhR5vfIFDonKLKnI/NDTeAM9gMEbEoDDY8vP/J
WQq5S8zQjvTSXU9VM3Moy1QJ6UW4mFA60P/Jon1aGPO7+RTpqQ8vzs4VAH054G+k4Ux4wBkzQT1v
7QbSXcbpr0ymqXTd5MOzz41Hkpw9lLEI6UYlQ9Md9TS+FM6XyZBi+0paa71h3pgfMU5g4KTo+L0a
d0s99w3dt38RNBk7m4X6c/dnDUTAHecBfdU3h1bz0n55InqvdVr0ODwe3O8tUc/qa30pMK/PxsEo
pqCDMUs6yD90j51Gk277cis8xYuLfBp0i5HtnWhtUZJIkxiEaUnzhD4GzjGZA+KM+vL6Us5Apn/p
KZRvV2D8dVV4+6gIu4G1HuvMThZVSiZpeW61Pm1TnGLk3QvCCgi8cm9BtC9LVf37eez6lRYFVBp/
xUDTCzazOJXZGTBSSgy9A/OEIizAbbU6whHqGFKhyIBT86/gTIXky+vzuUhaBIwqCbKZjICDHjum
b5T2/iEK6caB0XLzfV1qoAdvULXkpg/QU5cK4ITOJcM25MhfNCs1bJ9XxGUTu0gTjVWEzR+JaUdm
1Kdxpdw3+FNGhmXZ3CxQO7M5vOo1NVTgB1hiozOMiPT6w3O2Er2+RJs2211e2U4MRI+TnGFH04NP
VryDEjIAoZ6sJkczhtq+aYRf6aah6MBYqmQWBtc2tz171VwBmiN9KNV1XFkK5rf0KL+albp/8Kxw
L9vNQvV5+WtwZdF1NKvOPWCGN3Pb4t/QfCrQbUf5amYqVsgNxiMTFf9b+2HQs/mJq9JeKIanoi3G
3EEnuSiBHC0mobnUPiGg+qsuePsx/5eN5jFN4vDf+i+GeIuk4T3GYivT/+svcVwQE+ImLq2+gdOQ
IjMe8RZ3Abpm3Snzn7FF/jmFIjIaWxsn3YoehC3JvIYvUCuTbIU3gklV/CPhbmm2xDDZcSQKQsR7
iYoq0bYjghFMSf0JdGXwPnm6p8iLZBixGW9yAVTvxYp7kGDwEWc7K7m167utuOo1RjKSSkedsqC2
aBlDp9DJomj8oxsDw75UBtSjKQsXEur1uya0KiFNJY6lUBqhUh2fgozVi0Th7Y1V5JCxw0NJm+HU
u/JJ8ltDaF9B/lxG3p1vr/tPivmja0PkMdTiYPMj2FVba6+TFMhu/MFcwD3e+8ARaEsMSTXCC4ak
a5GQZ7pYa0igQKeN/Y3qxjTDFphCJX/iWTDFs2koMSuta+quKrdWoeluWKWgtJCEo0D1N8STMgn/
93PRhV0DoLcU//M10iPURc9nInM4wxjZyYAacF/EUHeoGP/VzK31o4EC8KTNVMoXdwpl9OMblnU9
jFkutU345rq5Pj/qZm0jqxvCfZjHHswHMtbULxB99tzY+DEreWWT+1TxwhVZVAsOceFmB2Ewcic4
dJD6aS2ww6LQBizdeLnJw2I5YdLv99X9eeRWOrwgmhfHDaDXUM3e/YcXUMBwJPXc8Rp2GQ65h7Q5
avTBRH4bVFgHy70khEHTXBvW2rGbpLrGrO9gIuQMWRRNXLh/UW==