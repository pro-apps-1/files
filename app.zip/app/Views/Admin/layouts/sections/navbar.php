<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+5V+IQzzi49k9ni1RojNBaBYysrw2JgjQYuP/DOTAXeKKw52yp11rTYmmfo3JWfADd9WG8s
q4ZWe5rJZ5RZNFn21sjr9aVNHf9gAEgHFecWDjpmg/wxlfXXoO4LVc1AW4xKdKM+Gj9zuSqS+OId
i7ZPAENNDsjCubNk6+bAUH/WJwJpNrpkVT61DdBW7n1wMJCbd64YENcA1/97XqTR/4OBs4Hidonp
MD2AB7gl54/Og9u2EfkDo0lH6ZWrpGifQatGjJZsJFEcll/GK0o4YwaYPHnemEMbOBraCdvJ/Qvb
OpT5YBT8JsW9skr0esQQq9MienDrvAlyTG/0RkQ1grr+vEa53RB4zpJxE5L00hMnfzpoQiZ96gYp
hRf9foW7UIQt7W50ImJIDerRLVyR9IM4WgJQ7QPJo3r2bB1pdgl6HEUt7xcfFf/lhWzwvA3EKfGz
Qp6msonTTwLkgXHVmyhJn6uiVmtQ3x6Nb/Y5HYrsDrXH8dbGgj0ES82F3p1NX2B3yPIT1sV6204i
bJS0ESrG9cJ8CE5AlHOZCHJ5Pd4blDRmAkQNSp5FcCZCQhH8Q6JW26mSRB4IHXNE0XsOnnIdatyN
SZV2GZaBJa3NBwHhY5pqanwcadQtvQS8l87DZLiM5cqoUMAgHnMxwF/PcsRGhMxVE6sr7Kx4HcR6
ALmKZcguJg7LZqtVnHLjVhPH8h5xR/bRyFJD3jOSPcD2FOpLuwzW8euxVFHHy6su4GmFcmKl7i89
eEG0wi97HWHx3xseUVqukweH5Y4Bp3ElJ8IXpRlOWWncItAVrmKjPgk0KjRkzouARJlfFIfrEzi3
Q2Xe+oflEktPpELJESVBQSkk9mY63ryszzpZxvTeAjt3Ou+2oLTKGzEmGnWMWKWj9Dp2IOjCyu89
RmhDeo2r+GAvypxxNInStKJXWwgv6F/CzSLBD3tR4nSBUiPOVWiO2ADjTWq1nsuHtf/nSmUUSdly
2TmjRUbflhAR5ZK1hEni+evMSu1LGsjoSTefisp7uBRptPvkxImgqV+xuey5VTgOosJyuQtU7kfw
zCdHbXIf3fRuNidwkOUhnufazW5qGypye3hKmNyTU3tSKwf9tKwozshyyFerqNSGeaboLtP9L+C5
5qqej7DaWkS53q/hiI6gV6Blte2732UXqHQZn/5VjStjUk2IVtyYcbFWMJvHtEahtChIuyCdXkGV
Vmx9/3g7NevUxYCZUcLTa847o3/C4WKKGBOELBLpQpBsHwYnhQKxbDcRJXStPvrg2FYMPZJ9MZjN
BjBrrxDtcMJIVNN3xgT2j/hQCAFNe/kIVS2Rwt8AJi/ELIp2dGgxgufV3J37GVtnk67YbbfuMKkV
CtDu/MWh8od3pOfIj7962VYf1ITGGabILtu3RaOo7nBDvNF7+lfLx/Acq4ELYPTofwMUOsEQqbkU
IdXP19QXQfS4hpPKKCKCA/7zLHpq/6xyPKENvYcV0n1tWiBq1oXDwKWTcaJkVy+YJZZfEW6XQmsd
1xqzZPgh0RJoazWJU5ByEWH920NZ2Pwbf7FIgxWFPFePzyBR6GEuVck8kYeI1OR/J6za94EASXUe
hn4EjDx0tTZYGg/3QlO5O+HzaujguqQ4da6hx9cEswIdWcNyPAmIiIy/cIClTmFKfMDPBVlcsQaB
i8vWl4Ia5VmACxY23R49vxbsCHpFjtzcdnj6mCnohayksQE4zxwrdxPQ7avod5DD+yTL0h7ra6Om
oXRsnnx5AT4dD2hkKtKV+ngryEG06UzVwFRXlTh1yDbx7ma9OrZjKuByIFlGyGk01+LsBQIk3g+H
1jbhiNegH/Gt3WtOyWlgJafJOcHoR3IDiQycK6GwwCP9Zb5Bcw3v+qhoNknjUXMj8P+AimCMaz/n
TJQSyg/n08BJou7mXrYwePc8l5ySY6WbQsSgM22nemSHPJQb/hwNp4yIdhHvrXMQP5sMl4vd2WWC
d4T68+h0fjPxMaDUXxmnlI5bC+xXSmr8zzSLezzb6BCVlChbP2N4hx20/vNv