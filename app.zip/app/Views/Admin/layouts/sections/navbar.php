<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPprs7XEPwE8aPBMBCFIWl7m0/KOKljvtvuMunomPimpQTMsLTtz+m+RzqWski3z2ZECE2wu/
feEB/Rp8ROW2PzIIYS/FEbzi4ELkMEy//axvXt9+Umb7QsGuFuUOfLk4NhNGlQVkxP28CpHtHYKp
VwvovUKwLQnxe2gQxpBTBYyM4o+qA8iXVI43br2A6/lHVvYiprjNsyXM3QHye0rMJviCtxEqgAHc
b0felHzf6BTRNYXayT/d1PCPP36ChyRL6TXKfnDjqKeZJQJYb92MQiv9H8TdFPVRTYC7Qumj+76j
Gi9A/yRqO56ovizYCU1ONwEQiO6Z7w656PFKp8Z1+fa1ivf3O3vqZ4xnR0OaUgQ3CIZaG9yKtKlH
bN5CAg6VZLLlEcg4soS4vN+vbWcReMLjAHYBkyPlPzN8ieuW4vGwCgM9vyx9ZI+2TdoLdINpMGoI
cipeQysHcTblGUITKcqUfLTFHWBU/YwgsLgvdTOPCmvuCBxumTSOn4ilzTJaPHhuJ6zG5GTOtocM
L9GTqAofxi1M9nShL5BszChSadRI/thn3pGTBRLisY6rAZvmfegLu1seaZOGeNshED4KXwPr+QjV
0iAHxCfxtzlZd/oZ5CRz+zd3nFStTx3qEe8NA9HZIYuIOcQulNMFlYqZeUsFK2H885FLZWGYxBYy
cFBjWwXQfYSTu1tcez/xA9lxXaWVhdv47Q8gSA7v5Z67My5sAfiC+RDEvSGbRUXg1BYxH1OcUKTx
jZw8gnlGD3dnCO65RZB+w+evHixlRYVsifqbufSuDkcKgI8s821B5FEKG+5g0UzFmWDK4Xzm7xRH
K+Wj7VF1ClHdZpZVqyCGyKUPpJvPZ5QFO3DpdWlF2a/hA7Gh8y45b+05/zVfaon9gkAobcyNhpre
zv/B+AAoTSOkA1mm469asSEbV/WUaC4XVZ5A5EWVp9GgHp46ppicatuWnmA08oI8kfwwKgboXKza
6nIlgjPs4vBmCCh3i5/9ydOnk6ZAW3+vdPwbEzv+T/nOCFrMNwHUPgPh9IOC7MoXf99Hzk2WtDkH
5VarP3e39cn3krY6Rj2xrSTLezkswqID6VVbkJDRM0Z+5ZPV7nhiw6r5lxByCD1QDDd8Nr3p1TnQ
BioksLl/ascItxl6omeFD8qRwQVO8KNqzCjyxXjTdFafHTurEH6vQfCPOXtV7oEQezT99fkZzii5
/XOBxea86jmPQ3ax2FOpMu8wU4viSRZyBbcZDPXzY2LwXnVs2K+OZ8HQPe9ReORyq/9N6F2Xr8Rj
nFjvtpM5tUMKUWJs3BXcDTtei88wBDkHpQnx7CmIX9ooNXGpqzD1KhyX/q37zkRX8eTDtCIx9ZBF
/Ph29TAYtfXT52Zu0ODiC/C4t07YTX4LlGmQXzAbqgfrmX3hV8aSsosDo0YNyRtco4ptgg4KoKtA
K+jGDwSqQbzusODmzMyISajiMAixn/6lVNUYqBkxsVvmZxVyAAYHAb37sBftVSh0rkdZ76uk6dM0
Q7CnKuFS87rnI56zSO7bS7ao2A55wkydiI4sfZ4fc/JkVgIPUTWSkRzbtJK1b/n2HkRa2GtJgne2
wvoHDewpZO4gwgwQP9z3XB9ws4AsSBW+riYZp4tvbPCd9z1u4gpKdUIyX+ktVjqi9BH3dK9ruOq6
f8usv2gIp459ZuZCarVz4y041EKzzErsy4gRl7Q1160iVXFdpgnwnUeLZ0OBXdoUcK4ZKFY6nKrq
QwrjfczbMtiJN4RHqHs9NOE13+78E432u2tWyT3NPdlgKOVY41W/DagmhvlgUoNEWG0qIDZ6iMHI
XZD6JKAINreqyna/q1gQk3+OxWbeucNrQ2m8xkPE5a1hLu58KKympRbaLDRTDgM5HFJqWc1eS8Io
rFto+YKcnP/EpalIJH949Mi5PLoe2MkvFONncj/N1QLJYg1vMXd5fW4108ucN1BDS8sdWvbVHyy6
S2OanGJyCCbEE1KMHZGdW0niIy27vkqn3QF8PMh7U7IVQllK7MIJXw6JYSeM