<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvMRuKm3IjfZsbXqRoPDkUQJ7VFF7ZKNNEyNtFBF+h519wibWvWXU4fBOluhoNBgNlQce098
Cg/gcNxPd6zPpa1bl/hO4kDhspVVPKd8CFCXZufLC5XzElex+kFgYLuLD9U6W1K+oy5vtg5/rtwr
U9mjpXTXOjIhowiFJ8CJGgFFZISr2qrHphSf1xWfbJ1KOccWOSm6jRro7YwSFlcrbMajb4SbIOGT
/68emgDKqksLe8fyAv8CBPWBHd6dqYBc4R02Ow+9ME/C9FKFr/I8J8bEJI1pP/i6lYefmVhX/z3+
k0oYJcTOM0CIhbrHb/KLvhV6RQTRAf+osO3VGlEg1QUg3opo9CkgDZI20zAwnVZqgKGtz7KBjb/0
JE/bK64qNIvg0+oh1zjhyIV0A32032Gjej8SRr+07A4YAXjwC3QsHKA9H5tzWnlRzqgTZlvHV2sI
TVtdPZNnnmKJB348piFoDHo4OvkAihy2T3NqxiDMdLtuOdvnLfbu6Ahm3w9Z6peAEsjM+Tm6rvGc
r0NTM8DoO3jqWKfDukxKGvSqFu6F3cuhHbaYwHkKmIQ08whsAsbtVhvZsv+coiQOXjFWXtfCQ1OC
f5oJ8F8Fu5sH9r0QlyGbfxvRGhuJzEC7BYvv/7vS43XQzl73IqrT/n6zCE7kGG08xLc3JqL14uuz
7Z5XwG29/GmrKDHtMI+oJb5AOWWqVg8Wno0hjVZzelBHRuSo+VStP5NJy5S4kUzduSwrlAMpiviZ
H6nsn5JhzXe2hUp1QIhrvNxcOEEa5i+G21lMOlGXp5MkNA8iScPUGoQ6g9PAJgJvYfJffebeqGVM
C7c3ckFelcujsdohbrw/3x4UPVONJpKHgoNUuam1Z5/cfnD+0FvNDUB6yS5dvuVjK6OFKNn1kA0J
ogcrKgReeNHrprmGb9fAF+GwQdNRGKWDqY5H+PO8Lx5Fsfokd+ZN4h9c/r3MDbLgB9IWIEU29Pmq
cnnPrAf3eHvQ+GKDZ7AImIKkltmJaLsjl8NaTl5iGgx/ZlsOvMIAWvHYDSQ9xvdJkZ104wrXxhxH
U9ek7Z09xsbILfwRWcuNz4j3O5Xnp28FOkOFafqsLEiNBs5ZmIrGkz5CpTOKtIRCbvzlHfb29Gi1
zTLJNixeLc3zVHylV+SbXrGx1tZ5PqCLzFSEuNn2aZWwu/swK9to4a2/aKOJGSOa8pQLk1mb9Di0
7rBRpS05tCPovI2DUqvS3SBKalqCMyjgtma72IdSY6aFmOHwyeAafdL6PXcUWjjBvJrEwkjdaDlR
o81GYUNcFjHgTJ1c22OEa7TJmtYIqVehajzHjp1YRNDjI47QB79TeQn9B12/k9QOBJDTtlvnUY7q
+5pWZ5CIlw8mizh8BX7K21Ej/xP+EH0TdA/Y5ME2T5sv0Smk/BHYRt2Z9NbY80imgc0/6bzfc+nU
tAD9dZMa8XkNaQzuGGDX5Dphkn+X1DG1GFTwOozTzw3lfmapHpZ5oRjxnqtCEyA5/htwvSgtBEb6
9wYmlmhZxI0KR1GzyyH/wasHmv88D9863TBUUyJHgJM5QIh5WdazRZMBgc+mTcDYyZdR60KbwSfD
ZJqk/wu184aEXNPPShIdcyVnJa+2A9QaFwAOabCbBaORKxJJy9RTdKTWgKrYlbaCdkqzM1TE1p5j
cW1CxsMGZiLdG2/QlQPJeo8gm8Sp9lLvmugSt0gECGc08wJK4Cgz9/Rfn5cC0zL3pIPg4bewmCnW
ZScsanW/FwzbSwFlf+4B4/48dzvKG2/rnKVW/TutmC1X3975awZ7H1Z/NqjTuOdZI+3UB2h+iakt
iadytVqUM292Y5ENRfyRPfZd8THLtq9FS5Oqm1uKcYY6wngZ0G6xeun9FvUI3/HLNOQuElyAdyeV
G2QNpALC5UDh1c7cRY/FXXws96QOP3kz91jIpjrqjueQMaQAntMEsi2/1+AAdHrDbiDcjyppDK77
kKyeAg/CoR3NK1A+Mq+LOf2NHt0oV2FqFpvAr5fkQwuutgRkQv1MjLSFSP57QzNtpRoezAkuyG==