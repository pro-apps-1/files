<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqsrZ4bSA7Lk6NOPQWAnnJ7K0bAvdQKsffYu2KumE6PA5Xk7gNWXaiqGX0eq3n2YlxMiVcV5
6REzgGZ/9D4vdC/fGWnf4pxbhjy0q6g3fD9FARwK6HweIOlBeUjNaFw5ZPDgbVuYxDwA/vhY9cuz
Buv0+pXKohtymmdoL1y2hio1JKQn+Zi7Du7WlrY/N5S6NTwIDgdvryM8hUa3oAXn5+pit+oBGc3I
ch/GszW/8YqG4ulc5jfxLcUnBTPTbnYaWxBcq6Wd/76Lpb7MaO8rknKwRvTeYWJ5cGCqf0S9Cz3Q
JpqV/sPy8G/8n/lVOQBPgEEs0W8nQpGPfxSL068HfpdSKHbriPNIIcsX8BKk6qsdqxrn7u4dXnTF
OKdtJ3AAkb1Ad2UlQOSNsPbMxSCeu3Tsjb+JgVpmMkc5o9rPKjXzqZOCvdcbWfdUPhNpTVfnzq53
Bng7Co/MjYMtz4HsuGNqeMNQWhONvGtq6mttxaNaabhCH/5x7koQFqBClQgaqVDGsL4rHjA2DNgY
0EcAekcnKlxxgAWgVs3PKshdy8/pDsAuLpy0yWDKmwJS8S+S2ucJ45FpYyGorRxjyilpU2BJ7mQ6
gr00b+qWNyG7f4mhSzlRztxION/1Q56lxjDs4jW0Wc4L5ejQL5NTXSN2uD+wr9Js60TG2X+eWLXg
iMAD+X5bvCSTFGXjB39X9UGZ3D8pb2ILVDJIB7gUXWSvxNlLthbdfk4AkuhELudV5qBc5UbEIHBb
1GeBUKCtDR88uxxdJ8YMw2SFS/l7KYu+IGEx2+HPgDoPXV32qzItgHIwm4kFJHilM43EdhqYBSgB
P1/oHd0E1WzYFt8eY6OKgVpL2Wyt5+uBHK7TIOnGX94nf3KnUiFWlgdKZpeEXxbTvzSzW8hm5MBN
uOw23COzL8hQAJVOEV3JgLNVTYHpFsfA+RAHC/B8LxdHqbBu+/YlY3aRS+fKi5W5m77I2ql9mHRj
E0QwXfCBxCfl8mMDEfhDaOEMVVdxXg7gB0rzDS7HuEM+TvNFzcWwaPGvBPeWNXJ4dKShWqydscX4
GIFUJE0lGSS2JuxhVreQ6A5VHdBWKyeraJr8NScPuEoHZNSrRs2BdvkKGlTUraoF6SzefidiUwjT
xL7lekxYi6Ue/4vaeosmD8sy6SiZjzVIwgsJiosZKiH3BS1Lfo64yjM68zKa2F6F/AT9OnFXQzRf
rjdNqTvxtq/wMHKWP42RYCnk/JMM0B+T1bEoQ3ZrUu5Saw8VrZkxPItNtMLPB4bYO+OEyh9YVIjd
M8d75BC2pHFJK7qnj1/X/spMOI0tkNzVCCQXABHNNZemgEG1RHs9Vp4GD30sDsITGAGcVrTS/zbn
nQwZCDrJbHoFBXKDEj9rivc9WUuLFmlRGFw1v9nADxvrv0xVh8+GeGDrzolFhYucZ7iTQuT90C6L
8iNVR7NOcQeQ/f9CzagfNLd5rSOzACS4QerPXzOlDMZ8CEVS0b68yJwaE4Zy2mZRGnRRAzrc866V
tajQ4H+FtClC92aA5LCZ3BOzYMHZwQWlgT+WC/14gwzh0UwlQ9vy7rjedGAaWwOI2nDy82AMB5jO
W5GGaZSkI0lQQ5ugy4k/wRM9ZhF4yx/+1Ou7WvGGTGxg0sqsoenHC+zGU/SFxY0IcMzXosaAgAjS
EaprgXm2tI30KwrX1sOIp1DSOg+187TIEwJImVkd/xnMmyohirWExPcL6aTbatUCyv3N1ECkk6Hm
Om0LCtjVsoyG0kOxtabROwFDdn1o9i/bb+ryIwSlQKTEM2DBtCgDHRRYgdpI1Ne0UfTJ7w4HlrNB
yqeXsMRiHkcFe5hzssgt7mGT9xgQ6PMokwy6TxE/Y0jvP6OANWdCHb2IdusJIzzP3ZEvpWsYOrXn
n+dvcJ5dGylcQ1aW9nDAsGwLVS0e/GVdB+FNEnnN6fVorrqRIaGqjBOVshWVdCKlB1N+ttIpv6ie
TRluMpYGEqQiMscN3AURNhdQ/4eJ0Vu4hjyLx1S8tmvlIG0h8uOBhjaYPxzrUAMS