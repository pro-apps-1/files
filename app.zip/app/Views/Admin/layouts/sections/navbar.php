<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy9OLz79zwlcb9l2yjD5ov3dfn1z3f2zp/4eBEmpH0WvuXkiJVr4j/FTVX+fGI9yYaK5Xrwp
31vDWToeBzkhaB17pA+FFHgjBmcJ8yI4hhOoAyAwsAteasRAJ0QE4w8ZD4zukmryRWjfx4XVWCuV
wVZ5HUvCTFrxEoBxQpq3PxJtmFlCOlUbf0A7FYwho2ADwgU0rmYWNtvrKaLl4Add1o89JJHfEjuX
OmouajyFuQrIuEe06NsTGtD8FyeD6w8zEbR7Atdcw3OBYl06iL2goSIbkba8QD1xLa6PTWmVMewS
Av9zDV+HJTt7Q3+Ws5yvpJ7DrK8DPDoOI8JnOscig2CbhTyHOa3rfX5dS7bQM4Sjy7gDjg/u7OPm
bFzpEci4PYx1KFtk/F7+P7AAMjxKKWheSDnO2+AQyFw9Uc9w9oYypGEl7Z3oEN9XUeOU7SDXU6Ed
svXzkmGmDAWEmguxeaRyAnmWIXYn2Go5UoFex2oxiztnONRzKkIwyGB3y1EvhBFjy+cl+7DADMGG
UpQgAe9fKP2M+w2fwYe6r6plAsF5ysbhw3th8pcEB0Oo4EJ1LhYtEywzuXcedgpKLGAd24RngmBS
I8J+qjv31gyhhlAFRlzE1Lc0QQymxRIQRVSNgPgtNQnS21+v4ACcv9ycd10Mzfm4QLqmf8BO6hlC
pamS9zhKYX1SQDiM7KnUpKEve0tugcJuJcQom5r3MctVWdJ/NegWJJ2pqh31/+CxE7aJkjQD7gU+
bXPf9pUWNxOBJ5++wjnD2LmjAslQej8KgQ/YBoHJeS3Hw9k6IVtF7Y6PAlQAhGnUQqxKnoUUMVsd
tDsPsE7JgBLFSRWQYCUh+5d9Vw8HEAmUsZ8w7lZI8ouCDz35SRJrfUO9KFi3aVTpIDJVoOeY4tUX
mkuEQC95KrXEbbm0f/rK+e9kboxs3lHVyTm5cA9gWRkL0ZR208l3nQpfJq2DO0gV7LGLdytrKmJJ
Ca4ChDRD24IXRKXtqbPzdem+0bsOyFLTLWSe+PFaBeP92WiHVC2hG62Prx1WbU0nwULfGOoH7hDe
uaApXr3Nb47BFGIM9TqpT9gLisdZWGxoMc0ga6UlWpGCAYitZoLGEdyXll0j4YkcQSAxArBzLvmW
LIahOOCd9HxilsGQyFlilyF9Zaj1fOiSU9jPBWor6FBpNb48BqpBqUDejYIpkBpAezMMws8+C4M4
ONzTCeixlp3YBIM+f6ToEJ2GZMw7/QwSTpgNU8PVy1Kt8nYPy9HXdgzATRBG5S86i14Zl2Jc9uJQ
MZeS3X6vGmTEWwbKJ5fIPRgzyoxqNqr3+BHt5LIMqCuoAXhfbbu0OXxILEepTMfWTDitKXciZuo9
HNH5EuFtW94D5rW0dck2yoVW6dmSUy5QJ2BlbT1qlmpLc2zbdn3hLzJrVp/7VUvTwh1ntho1FlEB
ZScgiwYBKaFEq5aBamvUkSJsHKNKvErjXaxk3j9Gl8YTb1HynSntc86thG3Kwfvwh/dILGXZi+t7
wK7YcctSjzYIirtHb/HEJRjuMDvdODc8O1OdKz9AIn43Ly7tPC0EJ0mt+3qUPIWOyMQGbg+m4tO+
DS76Som0eIRTPu1J/1shK5g5s6IpcfLRjrAs4HHTa/yHgUTPf4s35ndK5kKwkF6a10rAPv+hTzND
eVQ1umuMzMY27ZU1Mx8R6jec59pDsmViOnTkrcREMuyD8n94MJ8RsTP9c/SMBkQbVJKthSB5jg5r
TY+QBuKfsdG59Ik9p5CVgKYvFcdJrK0GYDfRW5MPFLRi8NwMD3+jHZyv2peSv3NCOnxKFVfn4MeV
vhG1bg+8ckyn0JNQo1Y5NTnFJyvTpM9NR32tSlQuYTGCa0BMsHES8WBMUB06bNP6mm0VzP+mjBJ+
Lcn84aq7oR2ZcoB4IZlwxlXXG5dsaC3OxHDUkJHMAB+H9sARHfPPLqsauA6GxZ2Q38I6iBbmEroB
Ue8L9uueVp+hj2vZR7QJzEavDz83wmdXBB8Ozg//wL8EhvTrefaEy1UsO7k95G==