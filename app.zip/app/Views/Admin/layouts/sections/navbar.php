<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr63Kp5oKgW62q364XYZLhinoLaI67D1vCTrE49Tin9GUJbvMdpwg6mlXPyhogvgxlfju2fi
uHpu4vNgXXT25r3K4ve/2E+CQdy3v1BHzTlex5jfxrlwbRd2vJ1kEB3r6LYo0tMv0adMCkFEf1xg
U+8MFk/IVy1f648b8lIACycm7yQdavi3Mn8KxXfOkmodiq8oG/53N11nUn/6v7RqPqVUqodh2IP2
zxfWWoENohXp985qzXO+5ElGi3Zce/tTFJUL4opoY3b7mRaD5DgPUrjRXWNkP1GafXYTsIq8ameU
TzQbKq08GZSCPddal+nsSYjjdsJ/+A57v6hZeOZEeHmKJT9Gld5JaL2+jWwR+yzGV5YAHLLb6h+u
E2Lh6Y1iRfghrg2ramfFfp+yKiVNfn/TwOv5J9wH0zC39M9eZrg8KP4pZ1M690mrwg2LVnFM8aV+
n0U+uwNtwjT566yQ1gKFHBflmOTWXtLj5sadWl2wzcEPzpahwRgm7WR04NlEoaDRbUb7Iz+VZciL
DUlWPkg3vICM8c4RpfAd0zLBaYFlql+ICWnL5MtHqJi9JGjvb0PQyAprWdNcxKiqQDa0OHVFdJqj
ULcaxJyG1PlLWwMNZtKF5ebaHAndVckkzYvDxfee1FFRiUiS+u9S/mrAIWEBOi+OYkPgJKNHz8oH
MYA2fbd2sjLj+1G0pEcBgUXSJ8fc+I4Soq9lOgtlTCB7JABKzEBDlkexRbaUDqtN0kVKz/GKRDbY
R+NUkewPbL1whbQr6ELoQ390MtxOK+Sf0ocY70j8GvAmkybgdjbtFg2L8OCCbSQIijxnhNuBcseb
M4x2wBlpjC5f1hRdvVOEuImKxnnKj+TLoNHcFlgDkl/CpL+7AykyrywxHEjv6zX6as+BHABZn4pJ
MNtiiEAdW6Wsqge3AH1edqBGgvHz/cMpe8aJf44bihpPEgvsbS3ZndphKMu1HneNw25xHqchT6gv
0J+1DBSCg0qM9N9lSBCb5sCVGqQySqttMy093I22BRx6pYUXd3grFM7+9p8Cyb56kwZWwbAFMqam
MkeTgQTMIUQ/l2qNx88pAgXfskRBDoyjpHZSHKiAk4JTNlQhUv+kCBmfsTCOJGd9OfmHyOl5+X7o
EKRahAPeYJVMacP+ZxxT34aBjTjTFgpbHcBtutfGoQNnSLnFbJ6O+OvK7hdYQechh1DR/GmJWqRt
1Azu7xD7UmCVRkmCC+n2uWx05PWgTMm+J95gPK7BGwbJeaxO6i+gSo7aPIrnxmnrgc1Z5ANvVsFO
eRKUfdtWW5m99789hI1CeGiKWQXM/bSbG02QKxxEHiUxtd9rBL54aXmV6/yfsYeIDmcYXR/QT1XX
vaavcD9rbFm+EcOX2Yrt/1ITHjQ27NvzgDJVcA1EqJinWyRfTCqJWqAaQ8/IWCsxkgjKOd/T/2XV
Qh2nIm5I2rNaC4pyaKyICNCE7OMMod7XoYOF2wno8tHMoErsk8L2ugnFSAyIfRsLTa5LHWKJp7ed
7JYfXotUy37Nj/nCX1v1PiMVSj+WzJFoGIywYTX/2/dJHoB9dkQXEJgr+3QEG2x34uFeKq8D6qs9
eHP8Gdu+eWOr+WLKrDsk12rzNHzU9rYlikm62veppb1Ns2Bw257ZgLjb8e6tmmBTGYn6FW0eb9EH
8Kci8/vJS6Se2d+mKcPtToNlyLnn3LTrAuBbh0sBUl5eip3SFS8eyfrCYmRA5hY1yvZC6Eqz9es9
SbHn2HIpwCr34+/uv/dO7DYl0SPREpDDBfQRBvKlMAkAHBFQZh/oe7QuHQ7QMXZJ7lWOSr1umaVI
wbdDgrZC9kqQa+JgTJkRlrXIEgFfbzSlVcfajGu2Qyl7mTibH4nd6U7V6YCX+g2zm8nWq6mUuWPR
/F1p4ZgdFLozMXui2LFfgEJ6rlRzUTOOKIgjquopRlf4GJWs8bV9MmqF2NV6rojsd2kBsNuuFzXZ
EfYRn/4l9RNpd1gmtQf1mQB+WAYwIeV1sz4jeWfzx8oHRrdOsw0sTy4d