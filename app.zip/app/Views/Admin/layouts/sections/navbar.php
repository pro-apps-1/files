<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwAzPrrw45oJ0txoVZKWPmwlwbmzFvglVgMu7NCluSpzN+IpSf/OXriE9v6bWb8av2aBzMV2
dCg1vzoRTeFMrQHYsItdB2CRilf7HjN/q/EGLSzA6mZGLBhXiTWoLDeDMpJlXRGppIQuOuNwQlXK
BRbKDhcE0Js12jPXxs2wiWZQ4Z0vRd58Aq39Cn0v5KaO9iRyde6iZcvDYMabQPhZjWJMbwzLs7sE
P10uCTqd2FHbJBpUbHrZeTgoGdmvCQ6JU5WXIdpduDuQEICruOA6s+HRjOHdLqNgBn0ei8UWXi4j
qhrq/rfR+Itr5V8gMoR0r4wiAajQVp36Qtfc1g/3wEd2cZb6dgBMcAfGL3CsjiVf/fCZKhtFWQAo
jM0jrDE+wBnh8+youTRufkUMviiihUk1rqHMvSsqh/59pfL2xmsBA/e2ZWVidNBsQ32rUZUqq07m
RgD1tjvlN8w7WKIeiWJ1lnuKlYYUZWMUXTfkj7P0fXZRXN6AnyczYAu3Qzql55J8TO2J2qK90C7O
BTU3isFKASlPMtttGhH7cJ4WYjbwD4BtupI131ybqIVRV3N2aN3VAPR+hyvfEPMfo8oobjCVm1Ve
sDlHuwbShNM10Td4zIggEjv11UbPqMFG3+aq+9kfcpx/CpcVq7TgPbVNch7ouvWHOFfvToPEvvqf
ucYpq+rbl3UzxCWa0BE3yZ69kNAa5UBUetFfFOVY2eorVqj4XkMOeDn6g5KHtfwauNaDq6P32TqA
Iin7h4q1BGEPtKr1zdswnUHhpFZ6UgSvbzm6EmBp1oFpy97WwdVgR6Rk8+t+PS+qBepacoqnC7YV
2yDA1mCmRaZ+hPegWzB/ErtzNLhmIm+TMjv1lyD4PdViors9Pu32rkJPloHsNPBW7tlf4Y3v4F/7
wJVwe+aZqlFvu34tc35aZLrsQDfZNdEwVi0dkrDsUfNMXyynDkUDTFE3dXFuAkBE9zsjZXcDKBmo
w/YfPUuRUBl6vPNsqIrXyoSBsyFrfvHbUYlpoqiQTCwmkrO5ZlKLDn0lsyrnpDAyoBGWqHELQtzF
32HmYXTBId9NyVM9Gpe/ystrjGnhuDH0faQhQoE+n9WmOJJjeIez6BjfXn8pWvsdVFe0WXSkmN3S
mbFfxYvSViH0IkC9U2VOXRsylzCLptbOlK3D5Vy9jZVubtKnki6irlPoWcbPw+J5vK2T2qjPhlTI
wM1QCR/h3gjWTy0hJ35fT+uXoy+ha/D23mMPhM1KwVBG7h2jsFwHqBkQRfA2U6HeXoxxcGH3giFJ
zmi3PNaGvy7k/12oEvVyXLbZ4A+CTYxlu+wMOAiQl06Vblqn/ou+JfLV86RZzcJ+a1dfJB9qZJ5W
yAZMmgsDpJXzS3zZD+Crot6u4Qs0oaPkB5/2nQffGT+EZkjMnyN+yN/615UtTUVVAKWF6PLNw/xM
u6nrAjGkGVkVuImDG6uGnZwDSxloHahT2vMqcx2fQZt4KtwBUtp6mI1gIRAz6F8FBhDG2H2jI0SK
pKF/v/a81TGXKHwmt5xuLiSHzpZWD8OOxcGYlrIfWNjhy1rouX2e61bGKkx46mzNislgDjpjV7ac
yD/UBN8+kSTrh+5/R94l8kmCnGKwFr+2KiycrAHUjEkuwC5kITnS7dg8vWDGclYSe7O/3PSWWlk7
At2mI9xiennn07Ltplska3/GGt10aAdK2xFmAairy67q6Xq4jHlbzEz1uAunBxGAIvYL2FV26BBY
bfG3RkRqD51j+FiVp14xUwgurwBuc4k51MPR+mFbXb1dLILKu+NHA3Oxi1hjM3DAgOlItezXsw/J
HhfoKkLwpEkS4MmMCqg5YOKhCt/0gROEoO5mIENzi8EqueptN6ngzHKAXT59ZevR427NE1/rS3zN
7cerqjvA8Dw0LNczS3l/cbLGyUVU5rFFUPjGLlJKhcG77t7wG2122wux3nM3mcCdZYO8HFcXD+qG
0vZLeB1U9lrrXbLjcN6NWdTrv7TsDJOUyCdEdfsHPD2y5vvgJG==