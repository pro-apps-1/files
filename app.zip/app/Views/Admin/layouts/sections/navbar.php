<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxa7kyJltX/hziGkvmFw6IvqVFNXHVq8XzMLk5Yf6IYOJ1IucgFuXhwD318OZ8Yn3H6soGWI
1ae3e1keXuGU/tXF8ovifkUiC37TRQTKJHoZS+Dw5SVJmARD6UDY6P2crpSNtSQS9Dexw1ulNqxn
RxvaBFe9YQxFG+yWoV8/ecnAKSXuLzsD06KDalPL7bHm9MWPSjNez34Q6Fs6iImqlD61SQonbCSK
2mYszVIEekMk8gDiKfBKbzIlwpsO7WGFupgPy48UlJdPArgD9XhjxmGtTdrBPs8UuGJkvISNVh0F
82cz04uXNvElZ0G4BFviTVNAcJKLO7YGrmmlQ6dkKtqlbYc364zm2tMwzhGPjXMJkJUf2JFRnEvu
QItPrQCzI2i8+7cXlCrPHAVQb9UID33s5eY0YN5HR8lCJtm30NZqmwdSeLNa73/g2ACmeRBU8QRT
1cE50zJsbi1UOH5ZfK/ORphVBMD+muWO6iDaDVa38bh2Ze3JDaNHxGCCCUCsvdLwYdNHh2ngaR4X
JOLO2MQBFRCRXpNGck6H4x4fSbh7J7xKiG6CWZSuE03hMyw9/SFgEkQihtDh7vt4xKyQAkrxW6mr
1fiun6atHeU6P1IqWGV0+rmIH/NBWV0D4E1CT+TlN2xJ9DrpXa/0u0jhR43jB/RScQlXzXymougV
p0e8mJAiQoLRrjV5Gvgb3AAGqpKVfrHYZc8VSiiJduzYuV7x3n4RPMOwep+mG4bmdNTMm8vjo2zC
JMSqLAxROufH+pOilmf4G2tYdz5ms/40dFLSln1N73Js3HKVu8kEEHuv6vDzzOsvwOOHr+m8Tf0X
TfvTLnlN2emvnV7D+2IPKrfFmd2OLMa8PcQWsKnrTCmPmBeZlR9AO7CEs0CjBzLQZilhlgQvEtuc
j9BGTDREVYYz5aIp+T+vGUXSo//nXOAjdUimClAjxLICoApSk5ckOPeTA2CEey8bKhtqbpsEQu72
kiWFJ8cd8cyP/nFv6ooy1YnzdYlZs0J/88M6iCgv6aLW1iWVWoyBz2FsM99y85d+S4WpWz3U20Kh
9x/1Cxc7Oi5g/B1G0uV/IbVCAdivZwaF0f8VGhCRr/cwSsqgsvHfZAHZekVi8j9mmhlR0pJlyThL
aSGIAjShXCs6z2nJLYBdL8OFu18V8Dk0gCeJyR8IV9q/XO+kQ6sUtWCEvHeSDGgUuWWHFucnvE6d
OET0bkI7qscU2tT/mAByGlOJVy3zmwLr8xaxDh7iSAru7pV5hsL/TrLHcu3YLwsQM91l0EM+PE6r
YDwzDKKafQ+CDTFHv1vmzgqWyW29doHSdrd75r2JraaL8py1Ye5usAddkTwpFQFUlfnp5RyA3MXJ
FSoo+fHLoalHxUG1IOhPpE1fj0o9sdCe15kkjXJuqbKp7jtFHGj7YxOEWg6+BhPqOdtxgQbz31ye
NF5CNgaSqJzSX6OPUqVWrpOhj8OJkfhj7f9/H52p/fEtr7SrXwg/11dhwD91VoR6hH/3r3EwZ2nf
YUSluInWqsWoXiQQsop0ssI3k0ya7ryJ5lZbhiEBxtnGskHDAX89seegpgwYnE9370oi9G61VgdI
JAfpEQIP4Mtehdc8JRLL/vNaAp+fv3+sbmkdd4vAN3AhegOWxqbwKbyira8+5cZotRXRElvWiwbW
33yR/0u1hVUYZHKA9M+N4FU3WXZyCqzoaoem3G5YZM6Er/1tHWrS4qoGxplfngfXnTy5SrRFB36u
uzZV8Qml/Td8o2GAqnIKUuvngFeiawHn1bbrFu+gtQcQHuKbB49VLNYv0l0DG5E6LcyOpUgZslCB
LJi/DPvXvM25WkDxqIvdQMwW9Z/y6VmNpvLxVfsI4w9UuIIl6ffzeUszC5P5pTaPpKi71glXaiPI
5dSc9fcMi+TkC+CBrtBZ9n8Da+QvsoO3D9zWSNLoma+TVeXJCHnkW0zvBz7Kv9iYHE+aqxO8sFpG
I3lOfuCjv9hXoiidjd2ODg5Ga/VSKkZNvqVhWX85AXO6gh8lmICRkzXFOW9oiG9xU4+mtNki80==