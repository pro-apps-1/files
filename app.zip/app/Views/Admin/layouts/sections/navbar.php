<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrNLIBPsYB6v3nRTbH/vcxpUMo6puOdf4TcZGBWilWuR0ZVfYXC7EsLTps6lmfVW85wKjjTM
gaCopP1NE9ZPJ011Wji6DdhCVUy48aIPLAj19hrKo1nNsKywuNjegDVoj8IZL9gWlwfS/h0YVUq1
6CuFfTSbxMzz2PPSYTw6CbE3TpF+QvK64e+VVrmJqGT8JfX5s/fNfKZHHJNUhEAcI2N/ImLPmC6R
Gkwyrjwpt6Mw94YR8tSBPXRtykHNB9aKDMrzs9Q0jGZOLI4Bt9+YPfU4E1KcPyVXZ13vhdNOYiVB
at1u4coHV8vlmR3/NsUBuSVq7EIEc1qu2qugePruyWrJqxLAfoNH1j02ae0uiqnVECuTOY7eA+oX
27Zd1FEbJsfu9eXC5upySX3bMHeEZ4z/FpFl9a9iiLgy3R2MrNZAg81aIe83mFaFDpDlINRGhI6I
inAI2sePJIdCh/YJ2zly7j/iBCdxClogsRhX9i6NN9uh7Z5LX15rseBmZCE/TT3mVBk4BjKSBQKR
dYXgiK/lGGbzvZdyrvPJNhm0mjiWqZ0ETzTYC/E6ck0dnrS/MF0tW4qgg4xJcYHuJEzG0eF7z9te
4q1qeU0vPhzj82CMYA0/+CndyaHqe5uoQ7k5LBgJ7gyrMlTC39wLryBlAUnd+xHRNinx3KK6vzQ9
TH2iru0wATsL5oO/I/Zab9kcAvmqCeUc+Z9LkGMxgYZypGgDLZTw3ScpEeuvgNJpI8ys5LmxDbEy
7oX2JxrSC6UDRMki6WJbd9ik9aJImKnDU5CCNdM1NZSRCIr9rH2nbVV3rgDgthP+RVJcTOIzD0KC
MKlp1avUdaW5ec3WpCinJTfRxX9f0Z2m/HavjKm/Q/cut0Esod29kR9mJQRvQe9k7hiLAvbtWSyO
MzjYrMv+khAyeq2EDnbACyJDUHJs53FgGtmAhNbR5HT2n42mC/lmF+2Rd9dyI2p6oERnSXOKYh53
V9BmC+WxAWFEmwPH8baMtKdXLk8aDzdzfcKuD6reyr4b+Tvl09dKOuzuIBcmKLGbGwq9st+hZTif
FRHw/bsymnuqCSGx6CxMUFnmDKia6QWovpuJiTTl9Ws5SjgHlhqdcWZFbin28Q4N4V44xDT82YyH
K1QgEMTYi2Dy/54kZbMI3TA8kZZHQ6spyeo5KNHCMnz+KuEy8FJIkQonEaNNpFLQhaySPBZO4BSq
cLAGCzFNKdC62aAJ5OD78bYGMTyfuPg81+6dQKR0q2rzWKwOfNyreGRQz88OMPmKuOraBk3DDuOp
B8mgNoTIVp4YDbolEkeNE3k0JOiaiCfEob4RNL1cbwOOjVCs4fRXWAQVWWe/HK+8VbT4VXfyOkxr
BD0h5u+o9Nf8yOdc/HyoUG8rIK/o+n6yDya/iFU5Bj4r3S7Jz9VxLy2u70tbx+7cJStt5Eohbv5C
f+ADxs+NLsZ2vaIxurTaD+j+QCwDSkcUdp2dDqvc9NByjBSLCtIEZYUvA8QCwz8Y/iWxNMQHcVXc
pI6/KTtohbXR3x5VSi5XsK3DMyBNgievHgLMN3tZPaJJ4r3Q6x9jiXBLYXpAaxWe0VBWtcMAJxYw
GK3Hdxm0rrkxJDQXo77qj7eUsaocMP6SsWjCQEDEMVa/VQh66CfXJnw/uHnhMW5EEJ9NWsuUxZ1Q
BT2UaUEdehQapQ6fZ6MSiUEK9KoK0YaCXsLO23yrk0DKa2aAUJFTS1azXUpC7B+vhoQwyJdww9Zc
IE6yniimVX3FjbtVaRQ4lfXLH7Tb4eEZSZN6kJ8oTQNbWKlQQuRcXXi04Q18ZSUWNwA3QJ638UHA
lu0vKFump4yiVPGXzmwGCquc5GYuBvtoCXe0ayatPPlP0PRlSAxC1jigdcDrd8nDB6M1KjG5h1CG
bcC4BQtvmKz+cBvnTibpNl1ITulLJ4qBeLRnlkTjrteS5yG2Cm4E91cGPHf+rcL8CPKM6jEwqyC6
dHNHZsHTVhGuX4NlI36EKPZ/S98v0SsS2HnIgZg5CEG8NLT6zBE6Qn6H