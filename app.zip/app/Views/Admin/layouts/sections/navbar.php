<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu81fIy0t1q0tS8m3AyKSLA7zXx8DtgyheQu/kY3o5QrQH4rrrVdGmpeJma7wH+ga9LW4Lmw
fl1duhudCQykIQMBrvgYl1n7nBbTuUoTv3RlkNyeG14Pxq+nYom/hkio91zWMYlqbnLSl31FqGp3
AQuHVy8Zqz7skxi86GvaJv0sDEMBw6qCah5fRWJwAbmE2fF5Rugg+2eJ1VtDH9vE6lGdgMX3MYk/
Nw8m+rhEmWsCXEziRP3+hx+ZNBfYoOMAthjv7nWRo2Rxs85Hakb8U5GQAwLaiWCKARBATG9kJCAz
ONyS/uYP//kf5VvJ1XSgSpSqNM31vJqtmoyBpE+U7CHBjoc3p5LxCK7tOqByX/+t30/VVtO39cpo
RbbNB2Pce+qigyxr95ksZgalSsgfILzaDzampPZ5iPE1UFA//uVFWECFNY3ch4NLb3M5Wx26MVlC
Pb0WIIyerNxhUQl1VIxwM5Sb8aNoubc5trYR+3sneB8+EeP+RTNd6RO0zo/bosD2oKA7YdbICIkh
kuHBmbqoZ8rQzuaqf1PG+Iz+Y3RwjBr1r73m3BiEL4znJ7t2CLt2j8V4VcU41ZcIqc1Gp0fGK22k
ePMoWcie9f7rhfv7CkxPgf+JfopG/3agiczhIWQFz0t/jSRwGW+Z9ldRLzcW4Ya8pJPOgyHKV4fw
mgJyMbiod+qtpgcZYR8uEW+0db7lZs99pkyhe+hQRcNFWCTEPxGUdtaGvN95XGGYbPWaownOn3ix
DP+htcCqfHjmswRrZAwvhaTDQ3X92kB8ltBqwtDLPfFrSS07Zlo3H3enSIzR4oCuilc75chJrWrS
5tQVEv8KJiTSDMe86LGZKh4TbxPabSstlZPV/XlRBg6nyqUfCT66Z7nL0ngK19YWSS6e4u6vyZlT
5ANwqPgd2VWADtSEt4YWJwB4G56+kI0t58/fBEe0ybaFivAghtPVOIny7mxkOQssCOZu3ooWbLDY
KamXB1mimOQJj/IXd/oIrJ3nhSUOyMwSOqV4LxpD7s3SZ4vTuhjYPX8Hxc93r5s2L49T/eO0+iaD
Q5hBa1bNM2rEy5Sqd21R98QQjInKgtxLBa/1tsxKwPhXYFdEWxFZ0T7WEy/HKLZBQo4kxXrfz2RV
jLrk8VaQlFDVKtPMoCiL16vMn+J/giKHv9dmK8XplDFodQyX4Vrfa7wopW+iDSIxAdzx+nG667Zj
rsr31dgcKA7NVflPc5rfY91pnrvF9GClJYgX+TF9HipENR0o5JMqE4YaTF1QHCJHH5DK9rRj6gFL
gcxlL0Mn2RH7xwb5bXwxiWLPuVbrAC0nhwqIuau4fJWDSHnL/zKuo86ybNfDVfPdPeZT2r6LUV8q
vT5OtJKjHGt1ZkG3J+1GT0/dO0Bh89SL+qZW2moIsAfxNB/d3yH/bSUVN41CkUZ+FGRbRK4EZoBf
WYTrkRMDkOFKVIagVLH2X1OmRo4fju6BMrLqEUVANib7OvZYobepQe4UOEc3XCcCVw3NxU8Bq3Sk
Jhj7P9dCNZbdXc0MipJy8dwK5iushhOUY9lbYPV0rtobfm7R5nl1L7pq+RIsibceC9xivZQnOKr6
cocp+S7VzPpN41a0Wr1XDtA2QV6vpjF19SXXPezWnsUWOCjDhEIGmu/vZ3WBYOtaitUWmLMceNfV
wp1Z6jwT/WSVgz4s4cyrE2eembFqsFTw9ed76B2kvvIw4s4jIctaf8SwDWaYPhhhCDLatp2Mvqze
qqB5hSiBx84cyWNRFmmtFiaKgHiqAzvx06QClI552jr4yuZ/yVysnyRNVxYjm9hsHZf6QFwbZgEO
IMDTCv+seaeKHjp60TxDZRk9JAjplbzrxV35uA+/VBtQv/Tces336bmzcHQ7QooF6XasrXK2glF9
71iDTx9IAqGlEnlzufW5iO7913cOZT0KQWYrkSJJ56Kwf+GKgS+GaNs43xokGhencOTv8iWzl+o0
emD9JNCkH3vrqfb71hhlKzl57K4z++0zWlb19VgP/sS1mQm6WpG2