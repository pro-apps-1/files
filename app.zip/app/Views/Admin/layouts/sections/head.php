<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyURztn0MCnp7KPYNzrU/T0YqUSiJuqhFgguTTuEADgcNBxO1il8zDlNcehuNyMdd71shNzZ
brGlSmxetS0Cd3NcdxguO4UWrk3+7JbbgumY68ndbCfFgxdqn0onuSgscv0lVhyUnfEAyWnYFj3d
G71FTtnaXsOXwC+Pc1y+4SzF6hDZf1PjMUBGLhgFeJKqjK96xG9n3nEJDtED6w019tWjrGeWErm+
tXtZtII9pa7FwrhtT73xDN134pC4ixv+QIneCHcsHeRqKnR6xUgE+EdiLMTgKrNuqQafZ59eoKc2
huKv/pAV8YOJLiEipTIK/Rehu5ozoHfq+eynAsmKsuydwvVlhZBHk0gLBqOX8sy2TBtsoTEjv8c5
UZ+qQCvn0iCIUW4EkgIEZg3h67MGRaolRjv+GJL8hbVlGJigqMgbWxDyD0mOJxZdB0rIGRusWlnH
r4W39PuwchwClw+uYlJgEx9dHP/ntMrG3sxf38faLQXneB8K2hHqOjEzrooVl6cwTYtXhW4Ds3G0
nqq69W/kQnPqlZZZN/Um0Rp1FPCUys5AD/19jUnofcQXxtZ2bFlHuuNkuIc7gRxGT/r2Qoa1K5zC
Cydsp8u51dIARLBX/LSZr+SENNBH0Iqj8LFWsAx/M2xksls1FsIili55tybpGuUn4BDWGAikn6Zy
cfr5lJzwhR1WG/dKa9Chi0MTChFC74evaHC9+Jcpo+jpyZq0lMbDnpZV2WvI6Ty8VGlxsvm0oFnt
S4Q7xZZO1EbwAUpvNa0620M9RBG7+2sIDBZmJhqtQgatLfu5Q3KiYJQHZqOq7OzSytEiNq0txK+w
DcFwtu7ytCTzWGsgCn9ynuK63IwZ5eouIQJ3r4WlhuCCCnp23wHC1d+oxOYQjuNosK+Cll3jFmwm
ZLDjoEQ9Ku6aVFjlwLeMy+aX3BZT2iSLmfpLKamtYJGphP86Q0JFDDh5i8wK5H3y1YxPIkOYEfha
NPkrIscV6/z7ONllaTgmer7SepK0vRHc5PL9OQ7Sz/hr35aZLU+ENUkevQi2yaKkwN2epWz3fLYB
5Ql9MoVdVeRn3l7fCXZlQBGzv4slm+FMZXfvSNETf+skN/mfSKAgZCkqwEaaVwU6qdjDQOuuuv/L
ejENTiMwiaR9wZQvl1rhgCLVK73KaRSfJk1jDLYs+Cn7qKCYR30YOWoN3cmgj7C8MWGLSgIdk5eP
ci6oSMmnLTP7Iu5pibWzqpAtvxF3YRg+pwrrtB1iZjZY5+UOA+xKR2oU3WXUXWAnOuUOJ0stJe/M
9uucu6wTcMO7BUJT9dGIdoQPlOH4vogdYBuoKRnYUYjFhoHmQ8GowBBn4cNWE/PL4um6IDDZbz/m
iNsnbpyDGhAIqNat3rHWpwrQmlnGKHYnT4SHwgszvTPtq6ObqQL3y05OWdACfr8KAeVfYhS9TwoX
uGa4Td5mW+5sIBkBObeoIGEwcmYxUeZPs+/jaBHDbkKEPeqY6hh2CsvPilGTBs/zgDS76JaBGmQP
noP/duh6EQuYqoTu3kK6xG4lQM7XneUi0+GpS/P9DfxzDClsqYhxhCig8Xe8wSbYw8yJV0tWogaS
rMnXuQO3fDtAhXj/9OwT5SL6GAvi+WU3B3Lzb3811tFsthPCbMc0XX8laZ9bWhU/vBxRsPuoLamk
RPkUn9zeh3loFNVdg6VzeQgmlwJTosOIsRd/hYUDD4NOmbiTZOfrFyoOh9gWgUo0GOKYe98SBQPP
+t3IYnLKm0YoDJsKdYElKL7Nht71yLGM8U1///u1FYiC7KFOf6rxFpbNgep87EiZHvQSp04SJ8gi
k02KEW7j0Kcsa4fWXwVJabki4f5h3oTZQu5eOtI9Z+/qR+WiajqiOhxfbNNcsmbV1CETClEzWJN8
zsXegjbfcK0ftF2KSLVavkhiGPKIRnWTgyc2hFv55lOO+RbJvOFXo2P88ilW0ioOWiRFKpMNjDod
n+hpFghJuhxg6FCB66g4bzv95oic/NRRd1V+z2I/u79zCHycjjPKmqYsJFyk8voTkbI4hwc89utK
anBfNxpItGsLVT+dSNRsocojdZ8P4octOd7HLiKH9bujmCqZS1xS+7iatXDL/s3lgcOrsjp7QZTK
uSdyAU9i7d+hwelG92J7Fqss2+XsxqsIq5sqM15/m6sGVvBp5guZve9HsuhtqZ9DK8ssOFyguo0e
OUs26L0xweo3XXhluIeiqJ4P2Da81XUNN769t5WVc/d384CgstTQjcqqOmnlLQnlYtE47f7J/CVe
AjgvDr/Vr3Zbp3ehkLA95M7b/QzOY5g/EAZdc+HAn9EZX4nelV1gvzydHp4k9UN6SlWE8DMT7Ckw
ljxXIrUhs9U2QMGR5Uif2RKb/TZPrPqEZecODsLgq9EC2E49/yNkPD2yyOYK5bqIUaAaMumii9Fz
0WO78WZbPzfP7LVaPRkoz1pWhNbPo74RdMRHmFxDx7OElNaXrEAZTWEK9i47R/l8vieCaI2aBHX/
P3qllcR0CcMiPyIzu3DUz9VS4m8v0QmMJDHX