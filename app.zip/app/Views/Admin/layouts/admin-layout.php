<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+7bNJqTQgOos3Z87WkMBKAE2UTmWbpQs/WfVskvBhaa4qkgvG2elaQSUUNf4MCdyOOcM333
v5A11t0oezJW2TGvCq76UB42dkA7klA7AhJaEC5Yw1ZASsJDvF/VTp6+T+/SOdx1BvUb+PaPAPB1
cwyuE1/+X0BB3LyZMUC/SWy88yjLeQP6Y/hTbxY9UIxoWoonicmBsdchRKqP6TvIZrJOx3TEkKan
/z8AYuFR3tbmSecYP9raGrD/1JFNofmLsggu5PT27hqvsIjQZIOQxUy4DtPzwMSfqC4FPodvfS1z
3o0glJJ/PYNotGJyn96y8bagqD4S20OOjKnZO0OG4EVmVcSl6dB6o6NCywRfSvd6p9S8V+ZAp5dr
NZXqrWCo8u64h6zWu0E3aYLNARUmCWp5V8dDBkW2o5Q0Z3gEtT/d+90K/RTxDC/euHmzV3K3iBf7
HYXJYhvnSQ+QmArcvzvByk77KlztA8IxcvTeujy7rUQxCM0jW4OPteXwJ0YF6lEIp+x8a3Ztmq0s
PgShZ8+28Dua1pfXhDrF2QtfXMVZQDhm1vbxcGvAZ0NedMX+pKpuydK5qZY6XNU/GWCYtaKUX4mH
i2nMaQ7PLFZtHnC2VDtsSah9/rMz2zDJ3w1tP5FSh1oSUlyxUyw0eDvEn2ikGOkaIeNRDjgAxAs/
dm/v/taG9jIlNI6QxXoA8YLX/xfv8dU+GuLPTB7vaWqFKZ6NNitFs3IYRH+U7pkMY5UqvTubRPsJ
LWVxELREOUROaDwjUXg0+viKxs/jd/FceefwelCN8NEraHtzZwZvpVve96qFqVDzFlKrFLyroXij
EA+tIhQOdoy+grQ3RD+SVUznoBvStPd7aV6PbM0c9DnaVHArCSgQfY5RoEF/PgxpnMND3lXdZnki
f+fzYZJjWW0e1NLYyq9D5x1iHiYGINXKnVyzawtReybevIifvPx9WGSamc+3199d/sK1sgwKGYuM
N1X2hLC8vaC1SJBSBVuh43EgcIEiqaEAf4EYeQAUWtdl5B0rqop7HLZnvrzxNhsUeNbiferU5rqj
HxrxiplXaLEK9FhZAVtkKEEJdCT84Hc2+ewXjQi2A5HiStX0wmEPQdUgb4hoWmLO7jCiyez6n/3p
5vzqjyxeVh0jNMyJAnuzdMPeRywikOKIrgzNykdprrvT4sMPgg0v+rWjjdVnT9s5mpdyg2tUNT15
HLoKdLm9L4LbDSG2ew7CJliauLQa/XPc6Azuxb9Ear9V8iGUPjCHOwMoVyYAqCnhqicuNKKoqjoV
Xnyuv24sbIlfY14F6C9ej/jAUPb3PSHyfScgG2fgu8Lt8VtI26hDz8R8jrrJ0jTzAdMXeftEZbSJ
+/5YngMXJIh9sIMBRwYtshsKCMgyUmec5iaOiFouH70cicH5mrYjNQrCnfc9Sou878tMq4+oSlNq
xsVN3grON2aIsWFZa+1KiYpdMchcYuYFhFBZlG4N65olODJk63+8IRUejCSB8y5hO/UeNbPQiB2n
GgHintJpNQnCOMGVALo9H26+SsOXfc8g8Dv0RLY5e98mWy9rpqDq0ABZS+S+xN+uJuPIbkmtZj/V
M1TxLbrj5azRwVLF7ZrGDeeq5p6j5R8/15cUi1YN+rwu59i0R6kwr+C1Dy2AUlvFCJ+3VrT/54LG
FkAhFW8mETvyGQ4C7D+sJ1LdyuDo5f8IPFxl3k+rUprSk7VfMxoSBNSdb9YOhZdjX+lw2DQzP3zk
4gCCb18bGi5xZLcFTuWIjUhIvTIVfq6ioZhIQdZOXegLWeMHNX/os6nJLkU6tYE6mIRSK2qj2q9F
O4tFIgXXSE3hq8p4ck/0ulpn179aKRTwT/sxwZVf8R+OOIoPTiZkkwHQyfOr73VlH1rKoO26JVc1
Kj+MEkIYIH2VkKtm16c8//tQTkmVxCAZuVG/gMvs1/zdScdVC7wcY16ZqouKstl9FLeL2nS7+B1Z
eoCos/uc8EBld4v57+XM/pADRdkmXPnZbLDixj03y1j5QV15cLzvmWUfTHvqAu7ObQ+ACTjuyHS2
hywq8c/J0gOBmHGs1Gj1SJG1g1+szKfnCzhvr8xhrZkKQY/JaAn8UD6zVEiMWFJVG0Xw4Qq/X9Jp
XZQJyqMJ7zXnUJvtL+kKa39VA9okU4fL73Jm3P1v/3DOiPK9QC7MmU67yXwKh2Qk+3z6UK/8NaNz
N2l4qleJABtCvyuTcM8x3R09cKIE1+5Bwj7bWQJ4dlOqxY4Lb1phC1UslSsjIQXQeTb7DF7PST+y
BUg7Kkci5fkagM1hAE0Q4uBvxYZBE3cTAgvnD7TrEwoxiGJi1h/h+PYtJNId2B9Cc9WgyCR74Tpt
W9aI8qxn6viadeFdg44B6zBTxqyY0//6oDcHpXcHYlqrKiZxITkKaP8ARuI8iUxxM/MFnG6/QOz+
3vz+J2gq25QEcS4hOEfHN/BUZz9nvUE4j4R94z1unDE21VsjrwN3jIOTs1s97pGqrN9rMJi4X8HT
Ow7oNTiCNUA5BFbvlwmLLwUPQqRg0tqof5x+9vLI4NKYKpbNWCWh043cUj5bC4mVXbv9p21nEZF5
1oeTs7pMgJqKLWAxyVMWSyZm1eyXrZ7hfjeJmxPmCgByi9sEJ5ZgqmOhPX99zyMFh6uxz3kZIzIS
5NocawWPcfOJsgvwlf8uEHQLrsu+ZSZq2wRmqlw2MkQShyQTHiEsyHNnHYpb7w1Ql5FJZmDC0G8T
JJhItxV3XJjcGK3zz3xMsKeOZ4+SvVx0/3OvaxFQQOy06GxAloOPaXp1QLiMakVDWPv1dS7kHRQt
pPLPv6s6dclt+I5F9p3wLTOTaOA1eBF1eNO=