<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoeSG85StRYs6S7Lejm4E6J9iM9ohfi9fRQufiTkqaw5Tvd4sAWP1ykrh2CxX6W4zJZIEeQ9
Qc0ABOlCY7aFKZGcK4bDBvchEQwS9ebfLa55HPsxqOiWFSbIWbP9x3CxbFB0P3YrqWohGvmSCi6g
BmP0hUV895QddVpvR1Dpr4ojQ+XFjoyBzQRFc5KPrvtl4jBUiUwt2uPA55JQeeT1JsmT28yj4W22
lhOokaBeZVJMWpe6+V8rpvGXmAv8QO83T3TFf73U7N0fAkuXIPj47u5uMbPZvt7RVy0s/OJJaF4k
6hn26iBPOsJBAzUcIpbeb26IhF/R32C+P3agnRGlWe4e0/NIk8Y9VU0LiFQJxhArF+67JPGIhEru
fMgYW2dscByKd9iv6Q2mJHLWokolj9haHxCPm0EPxx7Kp036Zcds2lYlJG0DCnxrfa/RAKzH4gK2
d1F87Z7Ld/8Scn9/9wYiVFdV+d+eW+gxauVvh7hNN8di3JsQXbN7sQsRSeJWTqJtMeheWCP0tTeh
XHGsz7k29NZRYtqNkBgJvbDR2sMqgoNC2Am04RfQs9HzEjWSXqwKs9SOvKMwHuxlWVV5rOgpsqPR
/beiWvHB3cBiYzhAuDLiNwe8DvLGV/D4yrpx0Rezxc1jTD/FZLJ/AwmMGruuU46RrTkrVu1z4D6k
PWNimw5AOV32Lt/frXp7EjnYdW3mjiEGTjMI1bpTAxyq59CsewrQHS1SqO9G/pN9wuOVD6vb/cN8
wbkQhobc1hRJytZIiUFEB17MhiKgD7vdbvtva4QvPzdzE44luGO+lcttX89p46Bklcjet2KWrF5a
MKea+XBIsHTpsHAD3MUqmiL7Sm7kQcEjEHHSv+xMXRAeHaednUSKGsV1e/JntYA5wuKR7d8PyL0Q
4a49J8mwsAagejOtBuzwZqDMYd8Ykb6LNW9B424LjqQADUty5MTOixSd6vcSozyaNFNXr/FC8lVC
lwszjnOmT8o8CF/Wrfv01Sp6PPP03D2Cb4j28ZfOuFbgSU6PVImSX0B3WARego8dVxnpu2TRXuKp
rOsbNl7xayGMXhyRH9RN3lMj9IlIWakU4K2rkOE/omVd8Pk17TqfayaYHpQEb/pHTGls+4WPf42u
HMD5EzG5NzHLureb3xoZp6hcuhS5PHtw1avXoLDPNcRi3NwCSigFUNOFSkbcIBhXO6Hp7uHau2Jt
OfRqBQXvXhrKl+WdmzzooOG7+GQPitwS7aCO4q9lFs44m1MMY+wpJJZH23lj1DL8aq72tyu9RMvl
RzlD5Nm0I734fk68WiklDmmg9Q3jxlrkoc4DFUCOgwXJXMFOQC5I3nfu3diD5uQU7FSutnn8A98r
HfnS9dHV5rgJ/W/jufnv/s2S6OgGEXT94XEzJTW1P/dIPjBQk/e7o5BHYK9bj7hB+rwTqUadx/3r
3bqPsyzhg2Fdt2RGl9rYEGmbPT4SEUIMkmb8AVtkTSWb5usycHHwV9gdyksV9S7RSfb2v2qMjzDl
KNVsc/ylVy36IBZXOZVy202BzXrVXiHPMbmzV4RYBq96q/sykn8OhB1JXWo6wYjI71WRjrBpeYZg
oH2eO1WqKHGDL+1EUcyM5pyu8DzP/KNr0PpyeZjqawclqXC0VlPOuwKCiNS9mtqwgeF/BrwoMWGP
l2PsW048uL5xGYtqVHbgwNqdHwPhbQU1XtL6atVhi2vhv3OlMQUzrl2s5CVf8zoqmQzgAaCf+q9U
dO4j2sJEMVsZa0/k2igkZVP8XFZgWaY2LRsB4TMaxWNS15DvnK6wYG4INXGpIk8Try6Zw70i0uIa
8DNh2vrPUsYxjYlZyrk2GWeJZW6lXGYQOyzAZg7Sm6n3SLf/5QHg7pPsCwMJlZKgVKQsj4/LQhnu
6/cnyFMHttVefZetNsEBv8zFES2dMZFJQNT2tMRZIpwdp8LjvOZ2PaQ8JyXiMpsWyYmxDcccQ2ZK
xLW9KfPfOSEYIVWvj6Cswo6AZpUgPDRXpudo0Ijl76yiwYvARXVpjdNn+vI2kEQ/9kp8hEc9Sm/3
hwGuy++BBlM+WzbaRNYJRaNlEAUeWv0B47S/oj4qEzVXzruu0TYt8m4uU5GJvA3EMQDN95/yGE72
G+qNVOhzfnGQkEF2sToY9IrSvOXDw+4w3u/z2H/gAIkI/iibx14q3izhHZjpauq0erYvIYTb886Y
+WlxhFLeg8ljNZuW+XXwEkp+YV0nexeJi5JgfqR28Qvyd0Vj4MLIknykRZaPV/pOk68hqk0HXDp7
mlrShN72vrDw+BhnFuT5DUZKEmJ/MXeqCTZYPRK8kN75qcX+eJ9B3Y51Bm4qysPC4tEg9Z77ol89
U06cs/Cc2vW1uy9YxgesK7PbHtQ3xzrmcQgz1qiz/pfpQFWNApKaUi/E1QLD18kP63X9KYxWWyxl
jFnFBVRBVSp1coU3j2VcEVmPJHCxsSnenip11vjXRQq5wzK8KyGby+pN3f9daGNQlooRwn96K6oU
UIW2BamJySg9Rx2xVc47tw9XsdrJVLlmw3a8Pw4xLInG2ThEVouqisod5YN6eromO2IEfOkOPiEA
hOG3qikhv0/8vwnnKl5qgL4z9lfonUT5UnBQFwDOFlPPHwNI1vnKw0W4PTUU78CvhC9qM4KafrdV
7ybFKMc6CymS1eTxBM9qwl/zoQmCp7THVDOszqDSXPqYLzeW8tq8bZ99TwrwAavnE1R6iMWmEpZF
ZdTHSEwU9M4ORAmNaccD9UCTgJLtEzms0c3YzMHK3XhBKQuHiufsarmviVVsuouD0biozyfg6wJz
WGB6DCFFHagBiPpz0TBFvhuGyNAokMjy2B7ukFcqisG=