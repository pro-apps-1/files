<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpVVFe91d8Er70AheN370I6G4zFjQW/XwRMueSR9TMYvrhexixW5ypugWhmGh998dVp1HQ2W
LyexOpkszgnbAbLvWAwMGioxZKbkbderCL8xdfrhC+NMd4iats7vKhaja2MS+yC9TMDgnGSh5zJ/
b/QjlYRUFHhpD/H8XBTCUB0ael0w6UvHIVPspi7drQk8SwNqz+QV0Wbz2ZglHhVd+VGlb51FS0FE
Hv0SPGF1WqSzmMU4JVPCdOsPIfe7DwtQ7oZKq6Wd/76Lpb7MaO8rknKwRmLhuNl/3U/onx1SEj3Q
K3rY/r+/mi2ySSyEYEpq/ii0vsYVswx1UeUOzk40bViCYi/4PXD3GUYrjVJ89LNyOCzsZzIGzI9o
0Cqbc2W8UtugULeVMSOCRUVhT5gGgehFC7zxc0asodrgyL3SqHei3KzGYE9bC7Asu62FSw4i4+zQ
0DcxeFurxaNWPksYqvbUpJTLPLLT5f9TtKiwK29Yj/chW5mVs3zG3taCt9RqVHWftqVr2plRYRr0
Cm1x8xTGOOEP/0vMKm9iZAGOwEW2voCGNZ5pDLFBKbzx1Mma0ErEQ7gmv5ydPkNquSbjtIvC0u0M
zkDE8S652MOKKrRX3fbee1kTh4GekR7fc6+YDy82CKl/Yl7ueCNRBCqUuF00xa51KTQeRMY30O/U
wWc6QhkFV6riwVJsOtYbHp0FT+Qv0gNE52/TQIdYw+D5OEaSv83PiuJutfMu3W2x2um5MlNz7SH4
g9/pDb1h14WlkVhYovc5AsCD6gsYoscVmI5PhmMjgTmz8rDixYnOyC/SauEmqh0tiCwwBf7tSpa8
U4KNHwDFcH5REOcE8uNs4673HQeETKwJTqFkAAXJ6zWFL+Qf9oFrOx66vMPpKiwu2U+bJ4WpX2fX
1yo03LM5ZrWS9+qCh09K/SRPzev/glCSBLqnO8HtKKfMepiBuDGRkBUBtO7WtQl3VMBu71vZ/bzH
+nnUL0HB+x8Mb0iZee2TNFDadBlL/1dwXVBGj/WI+1G9WqKPVq1BFb3c1uYTdhx5qLb7q8/n/Ad8
xeKvfpOpqgYmx25I4OXLijejTC196VVDMO9z3A077uMLhzgyFyYaV3Fkxj9OAmOzg5g4tlhUNoRU
VuyrL2QlFWBOxk27lV2tSDDQKFJWxW5Y+QsaM29wCHZgujJiDp0K3xuTZDv5BofYCgwONOnSXE0T
mm09CODu2Wat2hw2bR9Jh+2APsHD8ba6mNoN1PNhthAI0rfSUlawLd0iNOjmbVLd8P9R0E6XOjHl
VmfuHW7+9z05ZFlvt7WBhqby6yoJmgOBvC828F1w+GBTFnMkqE5KDC0nOK9X5fe6ztwVunj55UiQ
dEEj11ZRVrNUsKqeeLAEqG5KYUYlDBtXl1XA8sl+d0fFDPDRsPdVKx3D3vNtWN5PHTFhH+pvuvnK
LHMx7F9Vb9xIpc6dpFeV/946BTvdYuBpJcIHCJ2Ti1gM54OqbwqqKsPNKVObagyOWWYe7gj2XsX/
DAFkJ+4NBkaay2FdVQwLHvecuYZJ1whSeErei3qP+DgjzzbctMgzcQKquqgJ7clxbZ+tnEjTFyF/
AXjuw1sDP6fOrki7ij82TFCidHmr5y6Vw+In/UqJ/82mctaTKMe0JeoR9K4GB+4iV57QYyyx0m8T
2YCHfVlQkxcZmtNfXI/ih2h/00Qi03FOU3II3altigAvAVBACssgy9EifmKC0WY5cGH/jueeY6Dc
bqQAErDfZvStfNKb7MyT15l//q5HgzI81VAhTxlYyfML3jq5yBCOWybv49t0Fs2atq+ZceSct06r
5Ef8gCowSjCnE2+EVrXAXyFfuAAigKnWldS4LnNxmEM60GrfCRR66qpUx3/GyfXjrdFI3GCqHU49
/EIqjahM9MLivOQSbEEMHlZ9TcRw0uBG6eXtDGZyyTynKTsUHYHwPkF0hGDXiVlWJ6QYDp+N9xYQ
L8balCwDm7/P4zlwohbgCwRBRmYytNfGVBpKWKyzRI1udY/qMQ+Lfhc3UDAeB1H7O/yNcBi0iHg5
CeotQCtcQBrJxOpQ7+ggySPaM+XFeDGcZIoxAUdUGfwlAb0Vhli34yVvN97L5EUj7GyUUDE4HMiw
yFtQFJ1GKMsqCA5gvxpErjmT4IVpJXr7jXOxEBs0IiTiLfl12CFQggOU97aV0WLoZePTieR79NNn
vOBfQ5jNim3kYL9xvO7VAvZ1nTJeLoNf0gscVf9Sgzd/G6qKjHjB5f166UBroYo2ejb6qFR/gfeV
38d6pZihxh9FjrcKbmv6Cp8k4FUcc0OqPRft76sralYGIB1L/iEW4TMkreS91AVNu4Xex6tKELw9
SHFVa8IK21MsDcZWZxIrlvktKqPQd8P4/g8MfwBuoujio186a865VFESy7r+Lwg4G+egOUKTC8K+
8AQfellNl1XIMzXAs96gW0g/HHEwy5W31OPwKRTlBfZ20EW8USM0p1yr8CVlDz6P6pOHivbbP5UE
r0JVDqVBAoGxUUUcx7CX/fj30pPOBqbKJPpY/7oM564JdELYDKZWVNigrhULrtBTEDr7HDomCXJ2
Kt+i2vVcHfgN6LMjUATDN8poFSs8cH+XsUz7BGwQb9HBtLM+maZJrFo4y6eO31JppCKC4pfDER6d
5WdNG1fQgJSSHfSSbMNixNpTvfHGrqpw8KGM41hQoahm97bjeY9XcTT732JQNrGbGPOICDvMIMrS
v2Xw+Ei4I4gWlXoDulDsnd7x25+k+cCs8/djl+W7EPGpArIVVTY0dTJfYnjwCngCeItlRMAa4JAA
JuqOByV0cJPSFWC+pcyvUD8cHRIHAF5ElzBRbXwk1owT0n2feBRJKW==