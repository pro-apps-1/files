<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvS4gXO1jIvPtDa/DMBHPK9jutVpEaWWiO+u9pJRJhNujg7TjNC8JFyo50jzTDrfvXZYqfsU
EtndSTwBPfN9NsMlCoUGl+4MW2WY5b7g6L7xiLl1ypaCQJddnsbDFgwnJUQuDPo0D4BZai6JQcN5
WRxuevUh1hGgwtTprnAHrq+a8rQld4reTJCbj6ih9OEpiHVrBF9inq07SmGc1mLkIpfTGF0ghglp
HKwjWjQDoYQ/TkZAfxYhrEMn2/QVtsG4Wq2GSkkF2qtch+LXWRBBi0u7Rarek6zTu5v00dcutVIV
JLLeGg+abjV8E3+vDyeP7kiFQGV1zjV0bu8QXNNyw4eZH5qIl8C14PUf/obKv7U5W81SDwt8Wc6f
y/1cjfVNE2+Y5G8TwuZuAuy5YxGCmMqx1nMLsmvMd/KTcLa/Fu0L1gfr4zx54cv8hzDa8a6q2vum
DUtoWHp8W/HKG8hBZJM3f9C7K9U5Q1tLjNqp5oiWKg5izsjZ3ktZzgHdYCzq8RlB9SuV9uKUmZHn
meYTc77aqqFPZJR/yzDu6LMhXI3aiqmGQoMIlub4RbFG+LHRKPtTMLWHzkwas8lhAIpVd8ilKyY9
TYwNHAp6giYFu69ufkQ7XnIEyvcAx+WWEkRjlpyamKWp1iSn4aaGAet3O+zAftwpV1oJwceg1Obw
F+vK4t0bu/dRn0nFoWPB3edKGMIaNnNe20ZwCZy44HJNGm9aVYFLV1fbDT5SX7ZkaG2KTW9frhMh
7dHaP7b1qDXz/VcJbTUcAWaoJwIwEqC+8dbkRDuAocELy8Uf4bKcjJ3qpjqhSDaWFRIcqSIPr9g5
0gp35GCTv73ZFvr8IE4bvPNdstyKCHuLNad10GgfRFO/WxppMtbACBYsy9lvfumRFdvpv1IHvVsK
gvFdItnW/8/NpGAXD4S0bn56DozqcSg9C53UciZ/U846kWQudrp3cMlZoO3naVMg/KC3Ez0R7mKL
Vo5fJQlSYNe8fhcm0XQnwMCg+UW8yhKd+DCavRIfQw1cKruzWh0Iw11ag/Q+M3FU/zeNeZLgYVcC
NXHjWPoD6a8Jqq9GUfjO2cvasvTVMBp1KE798GUzC1L6/Y7jNJ1XCAEQFw/3lLTtf4cYaf7BnCwf
rda1aSU0S6gPQIXorbAF/Rm3TUKc5TFvIAJfBcJ2jPzyB+J/9aCjzmpGGmYrra4+OoH5trNDUNmr
E64XdjzF0QsqKXU8C60liI12XES8DMxlr2McTpFPeqc5S7BSUzk9Knxxqo4lBLJ6AMk3IPsD4v7Z
p6+Nbesw1LJCsD7xGgXbLFlIaIqU+BtVhmULkWaM8vw8qxKnzBwZnBB3dfeA/nADp6ag5exE7F3N
q/J3pB/TIDtp2+XlTwlH9FjMm1u2E71ikXbvuzXeTM4P626JWCsmznL0eol5OQ+W6/qvjKP4MRiH
fl5gCkNWDX89cZrf0pK4UuRyyx3jopq77n3CJGz3Zm7RP0F/EF2sAN4CVd+/QvcSfOyMkuhSRDAy
RIcqx7R8A5f0EjcMzwmzZh5FPZe9CdL+2/or6xUvblVvQ/fDFObo0XwH3MIWJfOmntFSQrH3PERY
QZUlxFrTWcKg72adL0lk8xnSECpfOhnbw/LAc1VEeeJ8iLazo6h/fceck1TNdvqtngpq3U5E8qwd
jBub7hMbqWU2x6IU80e/+rTl6XyYiQogAnrQnfBR4AXNYbd+Wa8UdOepcnoa3YWhBDs+ghXQLdhf
OCUhrW2ak6DFwIDd/SeBmW6KZhccMckmSg3e6Iue2YqRut1gDFSHSHg4pOv/4e0TlEOD6tJbABmP
/m0HbaH/C0O8xlFdOvR6bvyQZtA32kXnRbzIdGq1CIzfbm8RxQJ0BFEsUH+vilRLiuc33g2yoB7c
WeFT/Hm0bqpzqFWNqrpO61lh1o1yvRViq7niFdPC4spstYL7IhM0yexDI+O930WXEMSISwIAgVYS
HsVhpQKFq/41HUnp34YDxv8h7HQfEcuebt3H3MJO9EVPgEdckMQGJaNB3FmJjW1u0gAjNkRKmg18
oeVOt5djN3fRil51eSbGNb+EtjGxL42rqYiDWgNZska/fB6eUIFFOESYrbhIYAjkwlRiLlgovkAL
6ezkjRQKsekQO7N246HX/M9/BTtYdALBs9IgQpF4ds0baaz/dfWTqWCXlmJrkWOZfzbWbFhlyW9i
2x1DdVesWQW8cdoOBv44kBPQ9YmAZgvJfjpL1uIrbr0PdgHnOhXZ3Qo2ZmO2R3A6ZoDPuWfiMHwH
VGde8e3+ddohj2N/1rj3WZhBoC+/a6vVNrzmgvfSJjK10OM/1F/waRg/g6+zmNiKwV7U/dh8miuQ
1dykfKwBiQcIKYWGT6UdnNlRgQkE8nlEDXem/QJ4jLifpdgj3u73PqJdasz33tl1u+8WQW6sPjfZ
jwcM1PfhTENwEET7E2MS9ZDWxexsl7bjfQsWxKhCiY/bv/mCXijHMoHrtEQD7bVWY61jwnQQ+GCb
FRGmqJShh3ZH0NZ1c2U1Ph9aVNt9wcIthpJlRgyDkkb1Nq3QFfDc56WpN0VcfrI+pVCSzy8aLSBu
9Zl8TBd6FfUKZaEW0rjiLx9auoDvQ2Gd7NKU/N4uuvtfQwab1ouD/9v53gUioGzw2HstacvLCYhO
FwCxnXhQ+XkW/BetySCVATujDmY/8dWDM7YuBMvX/esNk5V9vflIUx171j8ESN/tC0eJ71Yuk83n
l0==