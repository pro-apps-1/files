<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPogUSTLeNqeRTKFazeotDh0VRlC7gLwYKFLUcZxFJMZic++zUa2NOmhFmcMQzBHyFzj1kHL5
evRYXc8MOzZ0zwxczX3l8t22J4/BBQqRBp3s95Pub1izjw1wQEjOrajBfvh5FshGfL2p87nR6Xb/
CquU76eJTtNKRQ9PDDqAPwAKS5hqugOILe2f0W1qMv/wxHpI3usmcRHMr6hXhy9joq6kT+1vWhHI
d0RVxbsx8hhcQu43t/qCw4GkLZq+XXfEwJ2bl/HX9+XPhbv11mcj6MAwaFkcQA+vsp3ixp0gwUko
WS2NRVyV+mykzOJNems+bE3Hv2XNy9ZINGDLoWofhfd0pe8acgTT9iwoxVyJuAnulhG5ImlXGPn7
ObL1DIZzdbPDlkhvlk3Wd0rPMyUI4Ecd69Ip+DYhGrsWM64XbpJ1aVK68SwhScMaOsaY7wNKn1XA
J3io2qVGwpi2/htO09abVfnitsbdC8HDAaTrq6jmy80K5RHp6U2Xg9BM0LGszNSrnGXkX7TOqDPK
fESDM8ESSy583itPxvnzjdWkB3/jlbZP4yYqTrOjng4sJEzEmmoUjW6+rvH4zw7Nd0hqPYXIrIru
+DWTQCO7BIlRxJ3O5Bh+wpCoot7OdvlJp6zuBuBmXwXpbYvUbEu1oSLtZVw/I8hlPrki63tXVwq+
oBRvauXqFRTZch5nW2GGxGiK5VJvutxuv1hpYMgZRvdDMoArneUYbGE3pPoyZ3D0jfsAVVQs2w0z
k46l614Q9gmn3qWKy5Axt1SEJCHzTHlQykcXAlAfud/Eo1eJ3XPTER0LvxNQT/hZeuD0kYTojDds
AJl10y6P4RpNCGSmXvDwFKtRVnVJyXFhLngkydOh5XiY1IGitXWkaa73u9ue6e1yHvW40Wqb+hYx
ke26J+PvHS6A+T5i1Pn9u07JcJ/nPK8c0AMrD3Q8qhEbWPCE99rsS1e3p7DssSqrvJjxompk0ceH
byE7Ufl8JhM/csu1fuuZJn9XTnNX6T0op6XyWKNaAXKNxREFGb69AiOYyXXc7iPaTnK2EJ3EOLCv
VIA7bYChfA6QPF/WZ8rW3+Nn7GunmHAhJjGtlGh0pE/hepupDrcbp1tOS5P0a+gLqRfZT2ufwLKA
l40FNkPKML3FH1cwi7NRuXH/S78NvBOgHGHZTnH5xTge3Z8SxAknuPJxqRWeT7EyvlNbzkfpiis3
3IGDhl6Hwmyx0q5yvAjsfGESI1mN3gx5I4JtijSJg9VXRA6gboR9tOLryZKlKDlGETOlXxoPHpLl
bUSLPGzQqjI+dPQFPZOaASLkkvg1Xa9CsjmxA8AUHGOu5lwk+2NtGVNAh3896N8cR227MXkG1OWi
89+b8yOZl4QXTQ9UCAwTUwevK3zN4CMQbHlZFgGAcgNiPrPYl+owgwSMsBda8sNWklz6MhvGyFx0
I2jy0+CRzPk4Ljcklm7juHLKWLC22wV2vOOsgip9vpimD0IHljyERv1pL29P8iUeK+EpR0hZ0kes
AMI22RTzqBoCaomxE26eFVZxqRE0NZ4PeOcJfFtTCccuqPBc3NihuO7yL7HubzPa+f/ivSPNkFRO
j/Ppk4m/wecj5uihAKGC33EJ5BwZtMHBnDmS1+s7yfNPxYbfMpSBavoggRh/j3W1omTfp8PBsvBQ
4dsXj3d16WTMZYR92I7khOj76ADR6vbLdEHJ/vYIo49FPfnYkWaYewf9EZukM00qDAkeDZZ7W6ad
CxpFJB6fET+TtJFJSAGwufcyxJOK4U2V2w958E0zAbHCPBqh6XXAC/Rcs3FnG3y51w9ma+hh0ZuA
1yNogSDjcubeq673cSPDNPEFvA4xOHtDXAvqDL0OEEEJmIYmPwHRTZGZoTePMTge74PYFZOhvK8a
O5UXt4wVgOI0s0YG/sbfmmMNme4ad+tu8ZbmYcnsPvbvPdSxp9Eyy88BurAVNxS93CIwgPGPOX1V
UfA05g7/EM9iP88KgC+Y1k8D065r9y+vefwMP18IKfdhclq1Yfh6HeV9oWzo61cmGgWd7wK/Bcaz
Y/gAM7paA131sL98GOAmYxXzQDr/EkbFX18NWbg51jzXklRHWe06dew6GbzSSZiIrZxEnGGEy+AC
KOR+SedBOy4ZxI00OYvRAMmBbYSasVO8Sd9IsMDmBBn/V30N2EGU2VcKUW+H3HRbtUC16EigzoYC
Xs1ZmK5AQ8iF9d0Qy4R7HqQUZXD0+ZP56lOS0ZeVwF9b9EtMGtQc5RbqVDLpMKdgpRvnFPNQVcBh
wnzEE21SO+w7gXjpNRjwZtLbL5gqnGq/ZiqhOliVr9vZPdY98FMC0WGqfwFWz/BM9+PBQxz7IV7o
uwox+MWXbxhNzWzB+dHz1RhVP17d70rgNfKmu8OtQO68ERyAuM7vYpOUKEO5ES1/8omKMnpAhSZI
knRb2dyA6cRMfECvLfMXcuxZVfsGt8SXrYRsvmhfO2NKD22ltr0zosn5St/uAvln4zmHXyv3IRb9
RbQJLuUin9qiHMpalzvaLP3LFYvUffzgSQwk7RFDS58U7XfLOakw4+AbM+KRAzE9aaLD4SGbrj/9
t3hrIbhC41HKFzQ6DYvpp3iNdSUOzBw+sLeXqrW/Rand2KhO2WKzPeq22ysfq49dZmR+A0r2QcT9
fQP67Q39oMvC7CgxNhg5GX8FEsC6KWsDJd0vKq96zOuPkQPbEie=