<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo7cEmvwLu0X0pkkBJrUThZlJcAqzQsCqym3ScqGnprPxcfN8VxRvAUGHiQVGdj+05+g691y
WAmnvWafDdMFIAQL9zBZ8wfsdAfvcvSVnoFyktpCuM939WbFaWNVuK8mRIs6xpMrY6JKZezI0wyK
N6kzcbtb+bCbeNJmpCHbTWdebj08hPkBaIcjvc8T2+FZQS0Dbucl01O5bouOSjZ+VWEUCrUeRlbZ
U1SKL3PRNBIg+Hiri9FdxeLHdAKxw2C04DHubkRnt4A2h9bI+Gfx+6/Lx3YILZTelwKm4tEJyjiN
v5i8L3r03O5C7yNNkBPviS4d+LA0z6WGMDoX5PTuox/S4lVs0oxqMuYYGE2yaupSm4LQnRe/Lqxl
MqN5AUp8L4d/tIA4Gr7UBeproUxT6dDFqCheuwCgKn55i1lrDbYDxg4bMhVO5r+jQ2Ud1Y1Hjzfy
nAk0doRAQLySxVO1Zu3ZNs5ABWicBjOZEqn2AwLNh1D1xI1dQwu+N2pwGT/dmQvMI5gH8L3Yn07j
3QZ6P8VYjc6smS+P7HziWb8+U/I077q/AK0KGrD8Y0qTTwBXBSRod9iKE2GqB++YUNvnqhDMTisf
oxbH5NEDnCqU/0mxUs0BQZZo0JYDGHDTGer0ATaSwfPdXeiGhv3/SXl/CFgIPgZh5mtpagxi+OH6
HhcHBtMFlpM/IOJIHThXk/rVMqG4yfhL1ccbQkAd+tTJXpRLbIhboCeDHDK5nUW/m+Kgyd6ZLVG9
g+XHaIQHqs8MsHIowQdtU35n+SJbfLfPrcVV4V9jUlCx/TfX2qVpEy/G0QXVB+S8ndZFeGrgXApV
75i9iapU7Yhnj5pURVTdcmY/MPc27fMctuNoYt/XMi0egPQA7gUZ3r/iohd6sPVDsPSFVhT0et5W
thtt1QCxR6T3ZAAwJemQfqmpTUWLQ8a66xl8QGO0gSFiay4paegqBha0GSr43IqCgocJSJIH6Mq2
ChL5YtJOvvh4iSQtGzZwZk8do2fy+5afsB0IlXQSrT3bHm3R/SaCeZfKLZr9/oEjxv7S3S84iLQB
+uCLIf4d2T/JuKJ6mpgYAQMjU0EIosZxzYaH4VZWzKuKSIu+ezZe7ynfnExsbVSjSDt7FendV83V
u8EjNR6SKgH0RFMYfrOo/ArUeqJQDGu4cHimxJ9L7nLFHKueccBsgoTf7ENn9DisleEknmqoqMJ3
XQ9ELVWhyTCGXFgBOz0lC7ucdWcK4g5p/XsKYt8B578ZvBPXTSkS+UXvqlJOExgKTpcL+uJ98WrW
Ykw3EWqcs6b1wCTUWyqrFXZ+EUHsF+NXY+hVwHvvq9hqT+L3BLZYbw91NGST8AMBpB1mltI/Dmun
LZ2DcvxFs6JdO2h2yVVIuvC2L2JBdODF8nRRh4BFQ2yJoae0MZlGmk2Zpk6T4+hRThpWJRCQlCSp
ImuBZtD7CKREhRGa4s1A+PjJchp7Hv+CzUjNFYULaUVKzMQUO3OkVowKq8ZfqzRzrZkwjbLbZs67
W2U8NaBllVGZbh7HjazDvzW5MAecpaO+1J9rlEeUKa+rZaNyNdpX31dg6kWh58OaCKlwVI6DHr4H
yvUzVOonAD7id7IOhL4qGOx49xvLa+OrctCQIgJNihEUKbSac4Ozg5c1bLS3+vJ6Cxg7PRhYaxQ/
il4DK2IsGLYTcu167na+rqDzGmWo3fAZrHh/jC06/pLjGes8cyn1ThXCmgDa9OTXBviFR3ZMadvf
htaNzbDzf/2q+cDO6Krmsv9x1Qe9P0x0dgQlkBLaNgq+cxQEgzOpXciYTYRuZA89Sgda8SKqnz59
VoHbiD7CoQVyediDmXCuXI7re8OvwUtR4kpwgkC8wavwaOuuFLUrBb0V0K49OKRfPY9K0OKipP3k
ulliYISX8dwUwQg6Z24VCVvZG/z/fu1Zg4WmOYyOBlIgue6QH3VWs3g+T1Alp/8H+3Y85PlZEsy3
w74PdcARt4B9dCpv8Y4GfBDXZdb9gmGJ/qQwvTDbTFMtnUe1ZOqYFqShgW6aMM4S0Pr8KCnSRguL
5PFx6lKe+lux8nkETTWrDlDFG72A2wjm43xHFKwN1S55XkGUUA9pTdwrD3OJ02xXTERhEOdXoCgZ
y6lU06zMOowna18rn46RYMFlveDDgGZo7TBF15JrvRH55vhoYe/iitusDM2g9rIv6I9mgSvhLq4s
vfEV2MOCcBsXWIw9hJA2YCb9zfnzcXrWghYy76nnTpwg9iKCJ/Q/zB8pYMmFMtoG5KbyrcChbkzN
pAAEn2KtpWJxTVxvKhlP3vniBhhJ9lHaj6KidiH5O1IWyp77nWcDS1exQVa5ZdZtUay1K5um3fEc
CWv0LuLULHW1Eeoq9MR71yu2NAU4L+tJh63Mz9T1VT1o0RAIdMFzjwK/px0fj9SZ1YsLnVG0jTs8
V+KcScQzBKv/HLdaAmh2HEprbQr0ntzHMQoEHlQDIVXrEPlmZHn5HtOOlvT93TqN9umSHLtNyBt6
lPrbwdQXaGwfeQOZGQF+NYZw4IeunJt8uHv2HtZoLbscjBf6zRG73sInFJxQwhDKGoMjq23P8c7c
Ioch5BxAEa7ZRgGuf6tYoITVsDNX2mllxm0rNM4sjdGcBlwrsRPSPSKhpN+faFVeRGeSobvv2QrQ
AmmJ1FBsg5Qs8FXEike+niNO/UO+1MFsicn9KJzEeFE8ap3j3Le8V2C6wqxqqrmi3MYNpd4PE0ao
rLyBgZ6biIjQ5E2zQR3Jl0MnVt6+r46hOyDZSJ67nqy51UEUpBfkEeThCzLyaCAPeuFykqRlWnxs
YfDB2rN6237lwXNI8l9DfuhXgLkaffK9BuIJmFZH1AiBLxcIr+g+baTxkO6zJhO=