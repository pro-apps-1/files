<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPweu0JhSkVazcUMK6Gv8jOv6DrUw9/5vJkXAb3aAECceNRQ+VRi1YquHc8KtOxvxJclmBzn4
AIbud5IY+sdA+YYR4Pew0zSzhAif5B3a4ce/dfHSm9fu4gEtZn7CmoWJIQZyIh2tRUM87KoMssh7
CM4+eAKrjvRS/4lCI5T5y6VUgijAHLROb/NQjg9tuXxgQU8790jqqbrixFUA410JJzhr1EYfrJFv
mKwALDDJ1ldmGBpzKmcrfY4JbG6aU4Mz4zblgdAWOfiQetpwyoP6lnyxsQH1QLkRSg4cL9t5O8iq
zeAVIF+qx9tcQjYQlpt4snDb7xccrKrODrjrInjEVlzLPRVN/JrfNT3KFxHZt/OVGwsGckLZ5YWt
2Ud8UZ7+MS91Iqf/134ZpaVZcxU7OZw+GlUKrc5o/ZUURaO9+KVYwzwvw0h9pF6aaSxhyi2vJFWI
Ku6niTitzhjxvLg1krl+l9B0VBth59ejzOPI/Yk8NPDfvuDORgZIz7q0iYAvcqLaB3q1di7jG+gc
qhTXOAJLz4ZimiH46AuNxZcaUMzUmtWXLFqU5mdYRplQdrtANuqgawGIhzrNp6gF78mu4UTGddnA
5JTkjBWHjdgDImSuWaUQNgVgPasv0+haYp9QFiFK8fmjbGKzI1Ly2VclOMQn/KCiqT3qo7/CSkGd
nF3kTe7k+O8sXbqq1yHrqOPZgA0OWeGX6UUHYzZkXopTfK2enRGpgmkafA7uhFnG0Z1R9C6E7bL6
Zpy996KbKRV/EBiMJRhSsPU58YnYVRmcxk0RcOdrwGa8nSSVq5oRWud2Au2srxn935IyNb+RXpyE
x5Z3GiOXFK0DvhBMZHvrQU3Ec3s37DiVXxq79TUisqHvVWShvjHQNRTAqKxJhgL73dEaCMBmj9Av
K7M1N2MwTPkMPfW98JfnjGxdLKb1T/nS1iZ5ZlcFnuUef9VkDz1g6+CdYBEsZdFaIS/LiaK44aj/
8F0ZANJzp4d/OU14xsXTlYPN+kEkL1q97HntE0TfEkxNpyeJRWfaBpvWlYU9gZ0wvpMLSPz/pfRd
LLpaeByctf3pWFt58UVgdJhX7XUcFu8pniN1ryLn49199wEIL6xmAfGN3LnjQfxxPlHQEEFbP3O0
uxU0MCHguqhk7ZCSDt3cD1JmafcEc1Y9fki7HPYHvdVP8BXmEEajUn0o4qz19osMIfABsWn0Um9k
KmmGAUIYSenOrZb8vwM9VqY1t4q9WGbUoR5k4Yr/X2f/T6cmoGAUUlBwBvD3bZPGWWephB49zqon
MCdZ4qBDxEddaACly8lDJdlF5fbUIggDRqH/NPGcI32j1JvrO7PCf14ZfQu3pz4JbJ7dEhPQGvVw
rztDF+xyHFMK4RldY/FJ/krsH3vLBRm/WTI2j758x/95IKx6gug2sAwTntgMe+EgWJ18CXAMVKZP
0VoZf0mGmrNWiOlzwPmG1A630t4qrlEkdBBUlM4eTegtzM57i13epfrlW4C4Y739/vy4Yis008YM
tWyE10LwJaFK9uoI0jWSsaKMFqXHHJL4fx6ZRwPl24DdrPn92PzWhgDjyEr3IgxLufIWuK+KX15G
wAJHkw6gm43BXF2WUTt5SUmA229CfKSFvi3rpobwyn+ZjmL/2WRGORFtpT2oBijD2u2/Ohrw05kO
mqHnaiB2B499AvvkFXBKk0N4fEKaiaGbOezinZzZVExAgHq89CaQTlsVFj7JFtLQIps7vHBRxn6f
YPE1AoqOYYTsKyidkTzpKwloZWKgm8j+tAg/L7L54SYeX+ajksWkRouVYkkAdkp4EYX4nSuVqmiR
eamHAaehSO5QkNkNeGN/VxZHOT8BYA4CVIKztgUXiZdlxVyQOBzA+vaYCvt9lwYkiPDL+AMMLnBp
APDtdSFvfI+DSjpeCgiijEf1jAzy5QPfwxp/EasuNNlm/EzNO4vxJDEu2jH5xqY6qRMihfAa4Uu4
C4YNwQZyLfrj+bZLDLsFwP1xY0LEiBZGI+9aTtyDJjorSBRWpIjXbbenfGx/fZFk4xYKncMqD+br
04d/wQ28JCRxo3rWGcazRGdTthfdeZ2hgjMTNh2QJcr4rgy6mBJmi1CR8jTk3qeZba+iHT/p9Md5
wo2QkrAICjuSYZvsUZr2M6ws4fqcQo1q+XSN3nisBCulybVtwPtBGUJqKsMiMqSFDup9+OWi9WVw
sag0cgndm4CFJ7N+RmDs4/Sdtt6xNv5palcItEP9P0O6raVpk40fWGKxddhHC+Sctg+yYYl9nHnW
G6/mJBe8au+Wc38tNhDn0l7oMmCAN0JD1/Kcnj1VVc2eQ0SkPO0PsJdJqqLcks4x500Qo6736hjj
urnPC+I6APIDiE4czZ3HT/zPPFyWqrgHne3dT+lk7hFhqhRjeM5phy8+wvm4H0D9FowDLoA/xm+g
X1opntL4LVwYM4wcLAFTiTuksCDlKs3KZAnj3WImdyKCeZP1jHBP97wotOtnIJRA3K/R8aOa3uN4
wn0czfbHMdyeh0ECO4bSoLUxou373ry00qHKAVAQL1nh3cQuRfW9iOEbgUeBMwoZjgGm20L2UOTE
wJLAfvr5a5sTP7m9cxrIhfrzIRndgdOcaMR7ZHjb78u5E522gVGpnjnhQ3TkyoYdDutPqcEyv5Ye
ArCL64HXP1DT8lJhrGz/pngXI8EJjNbRvATVcMHvbZtMBvPZ3eiheEw5Vf5UNsAhv2ofcwMB42IM
YyYCnQ15wzjN6bsc+GotXTWwtBdAYXlObTBvCATBg7obPd08uQHlLJ4N3YJtRlXOfXMr/jeBnX3x
hAHnfgEuadWqQvIWxZjx1zuSneblhC5ktZM6knAviam=