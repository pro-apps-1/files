<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPssMBEIrHfNBG4kvnm+vA7j6Vbn29Egp2A2uf8XOn8xxBhjri9rhwBme4rSSJS4xWUxR6yUp
GfuUfxKegb1PMU6GsHr4U5wS+TVUmx9Em6H1lTEAfV0mhBmh0iywg12XCMhi2WdeIFNgFXKKXrPT
//xI8aAc+hZoz/wGaLid6HyM38vONVHmtvp23wlPNeAr4X5zRCWRC8f/1HAGtnEpjXnxGji15g4r
k0IWGBR8XHTNoKXJft9/wn9FOIBsHVwNjKFpRjHLK0sFFSqLpROcz/6WClXdX79KC4FSY5fdgOA2
/KPGGwDleKIlOhxoenW4u4Jr2lvsXgwXZeoMm9pIXcbMx1htFoYHeSl8OGc1en76A2nnNbkX3LjY
+6ElZu9hil/aHXMSG7IGQaGK4XmcbQZ+8gshiF7z5K+EnxEk5/g4WprZM9Kh8VB+e8qjnKjwWZzj
oZyo63lfHg4kN0xsZNpXTffmrDDyouMPoP/FJ/qGY/9GpNtd1PG2yc6WRz5sGAZF1pkfdgY5RpZk
bvbATcEyQL+LklbChS9MVMj0+nWhho2njHUzdTbIGZrPMkAGGW1hg8vvr5jEg224pFZclEWnmT05
fWZ+yqjWnj+TYGWToVxQhJHf5anOUMlLCfTuoqg88rwTM+2E+0JshnF/bZKORF34gRzzZ6oVOVVA
zl8gowR5h3389F5ItBct0roQ0f6VKQ4e/TCzZl4UXRQuYagE1KdKDw35fAUyX4sCFs5PseW6Jv7O
kkr+2xaNRiptrOXOTnBScG2Ye7jgHjr5YtlhxH+5f1ZngRwVmurhKWTl4ygMpnWepA+gpT+fu5uo
JjBst5dwJQ8jcaycgdgtiYTxAPPyYfOxHHSh2HEYEYTeZYOHlq9/NzigZLciM3b9VzIykq/Q2u4v
Yr6edDe17qQpIb1R02obj9dkn5GRYzsI57mi9Vjxrk2yK1Jzi7+3VWeAr6Vwo7FtnG9/mkPRU8AX
1oMzhkmQMdId9U5G6ly5nHW/Tq2mlT3vKVSKdVWM27lNLexm+617R1jhprF7A9ChBg1BscIqPK8W
DbdaSSFZYKcwrhvx9blOvf/IslccTmjyGSYE56Yyn3UrX2zSWwzG+pM4Vlv61orVT6NMS1M9ELrL
wvsW+ZMAK5MI3LaK/oN89Q3NIsSZEEf5gk0WkXYENfSLo0PScdyQ2xlZEKKOOUN0kqFUwI5gCiH7
QNGe1+sz210GbL5XIjXlZvpOlhtIDuFPfrV71qZayyh1TxrLYUNt9aFtl52wLcl/+umVlBh4hhas
7A/hifHNTd7uTK1OuHCpBMa2gFxw2sNAXbogEkvW7n4gpXcKhWVD/fWXb8NHtBoQ8FQDbr+Qp1jC
+9JUdaYEZkH3aibVMzYSFGDIViivuhfoJ5VOR1tryvJ4bwAbhT1m1fhMO7VfMFzJGnqCvu7REw6a
GCwdPoNkaXP2hS+px0rwyuQWfs6japLGrBA2jVEZxPySg7XV77jTeiwIVBIW9N5UWELk8tb+59Es
VYrMnghm40P9ejO6OST7NHBGtEA1WbP9O8lSSuqXar1SGE7Mk+j8yrS3qnrIPXAZxydShR4lIuM5
t1imbI5XfkVCbzpTV/jvvZuVHedmY06VYeT7KFiIixp4EAQ/qjWRUPQVEo2Wq7u/IzLGbQnjTwVl
SOY2RyrxOfjcNmADX2PxzKpq5WGZqFq4VBb2G5JOLDE/wuqYYfcF9qHHqJjXMOJDsDEpRtmp87+4
ImyNfEFHzBqis1Hqu35YhV00gEB9QIS4Cm6FSLl3V1uG5/t+jM8REuvslRfx9NCzhkBNqWac8xp5
AFqWl47GB+8qB02XpiiDsepDMHaqvUGgCjxKAJjd3BvYed53vZEC0nrnWzAjyElPT5cdrE26PhGf
S9PQfwtPl1yD2iSE/0yAT1R72Ap5EhP86nKPGNXlCxfwiqE1eb3dUxkbbYi7D2m4aWxqSlrS9kS7
x9V/arVUDzePjo9oLfXLgAllCSn8apWZBb0P7XWhwTzDKoYHrRZCSRaDD2W0Dn1Azu458SyoIyHe
ffir56SWw6LxagG5rGw9SYLM+T5Hd0kEE/dNIFINHn+IrTunPCrPrGbr0IYVySbKu0S3BYpH3YmQ
l0HAsiW/0e5PY2pP7CkV9iq7S4iRWgrNL+n7ngtjc/u9c4pURoTG+WPm0VgprrkeK2SwLgHSKQ0C
k4xtf9VFeb1FrFnFm6ZibvmNdWM1xGx0CqvN6sJbDLX8IC/z9jw0dqgik5iqqlhFD6oQbnsIa48m
fmGp8BVrZxObTn23Okced4kgeQWKh1XuYq4xEf4DtQQjSvQ37HVLKsrDFvX0ZPGUGvgYPSkjljCN
T/tKyNhKHqjXVmIF8I73l2hsHwTTzrjxn49OxML1/simsKbgwWstnkNv1b+y4nj4LHXStWpVn8pP
sMgqD11Dc92qvH/IZsjxcbarTyt0KbGOQIQMwujGf/ZaCu61+IJ2bao44iOBTLSBRALAUgn4evg1
wHbifXwnQ0Ya8Ojz7oZKdtNN2pWD69Hr/OEKMW2KfncJv547OeUxuO7Ul5aqc68zpHZ9bbmz1/Na
dehzsEfOA7at/r/T+t42sP+2gy0wlAiNGm91k1xE5HCjlmwxOq2VfvLwciKlcxxtVGx28bMSrHiO
CU97KOWI+MClzcO1vygDG9+Ck+KuWYQFSqCrQarDVFaMAcGx6JrX+VHdID3ocrI6mcv3f4Daebkq
D7mCj7B+nGJA4T0sd4R0d7qVHqAz7TNjlEpDbv92zapJakmhrCWEwGd+seZdq3ao3iCzFS6FTAcG
BbXn9yQWlPuNwpeKFusmGn6Q1n0l1XKPYP1v+fLP2zdtkQ2o43S=