<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuyvqgG5lYQBqEH7Xm626PbVuUBpiDicXuUuaiCbIWVqAvML2ow9dT4VL85HNnUZ7tPAMA8E
4VOSqFfewRxLKcAfSX4PkwPg72C/hwL1FNX0lSuJxVkhqNfmEx1SR7P2NodZfHlJhhfq+0Ydvtg2
DZbtJcXzYjMfC/JuG2Y3xfmmp0Jdp3IV4TCOMnDhtq40/AdEisjLQrpuOagSwbP7GIAK1h9vdo2M
9DYIuP9jkCw7xM90lxIrMbpBVa7Lk9pq2cPSjJZsJFEcll/GK0o4YwaYPLDf4czIffPyYlDhMQxb
OJSrp2exeP130UrxakG5Ro1uZHzuc7fdUwaggVdGgxgYj5uKEDh++HKXI2a/Wra299thuu7bIcFO
AQQMEnGfSuyBjU/Rh13D8TZDyglr0jY9DcFqSESa8JNo8b/Ou4VT2XoTbiKBRMw7q+d3AwaTEbYb
wfskxGfPpcKj+BL7Imrafh77BZa5gcsNKt9qaiPuovj0JbfpXHREzC4qm9eQ1dBL5HFEo4gBgMaO
IPP1qPKx8x/CdHtUQ5jBS243oMCcv6H73lq6yujA2esnrgwZ8PKQFHgeWWXmZRoJiIBp3LW8a6c8
CbXaXqf7g2W709s+Q1UFrKKUh7Qyg4QupCKcBigS7OQUyWeSO0yCRteGS3dp0HcuUHJhZwDpyWLv
hVTIw6/et167ppZHlvLIsej4dDOM0O9ryXA/9wxSlipSJ2YtpwBvzZG5aZOK+vN9FKZrbLxDFkyO
9K7/SqVVtboRGmQNABtfjWynb5QvKCfhl6ejVc993zQWkKNVP1NmRfzHJ3Mq/xWMbagUx1KJyMm7
E5Qov+naSb8UQav+iYfGoU3wusr3zRBr5eEIr5+yVwVnbLcNVpgQBgC/Qugptn9T9E1pMVsyCj5k
3c8pWaWo+yDbSqQ6aFNQjRRuAhUOGDVMRJz2OxMsGfQ8EQd/GCIn5uv5g79YxHDyv4drcUw5XJZv
JC9NwkD8ejzpWzfdTkDsqJy0aHnqVYbh9BJaZez81myITT3UNFWJhK3GEJPxDNUENXsBIdBMMpUe
kIkBcP1FiiqVcXXQ8dmP2NuqQ4Q5o13fAJ9BIUIjlSnToTRu6HgO3NKwSAULALjs/PbI56HMu4VM
a3gxV53ee84+7LR7QrwFLJRaUVu3741h/RSEt9XLV6xcOLfqyNGG7nNXhrhnq1fK9PMe+pY2YUzH
uPi94HYhiA3fMrIZg7QiBOsahHuKJtvg/T5Qs3YoLsiUW6VZsS+0WqbCJMCqdnVwaVjU1cSob9vF
AEJSmaMPO5RKBfLpyfQ2VXjvOY/5H94NBFqz43iOGqaXKdJyB+kuzghuBgChUTSTMUnTopBpdmBo
4clmeBvb7bk2/fRvsq+YqWCwi6Upntd7LgkkMvgpzr5+mKKZMnV2C2nhuK9WckqOfHPO1A6UOnB/
Akbozy5w9eJb5JWj0sADFoAHE7rJEHV/t4PwhqIvdoahcyVN8drnJ6mqEMFyABnQGz4zR4gBMXE5
68NhxcS7DU27WoQLUmj8DWCMHXq+U8cYOxGxN5hqxI10BSEW7XU0/l4+YCR3JkdqGOgkC+RCXfjB
buO2WNxK0/51pze922m6BKsP7oSWhr4EpIZZYEoCwElKxkPz5Kfg1PMBic3lWRvIhwo62zPMCz7d
xEdmJiq/3PNMm6V4a/wY+b84HGt/EeqtU5nBT92ZycPRxkhfrGRAvRpWUrDRhxBlihASR/fZyJNs
I8dzR/H4tOvdLCFqu/oDqWAt0JrNZE6jcH1gX1Rb0p1ODkAsBkCj9QKFKox5sDhwERV7ya8ZhnZ3
rjfUaytxPupC6wOeT/HhxcyanXD4g0c26t76ItbHE9nwrXJyu5ukTdJROPPbEtR8DAHLDZ0CkMM1
boNnnNdyLpLYrga3zLxI37JAgBwpIo87vgc+wO+GtJU4vebmEf6sE8xfhjfTBhPQ8hjlDmGF5sIz
z3XvySgwVBwUaj3HjWsmFPvoSr0w0U9f93NMvyRf+BAEdKRKueR48ONWsdXfGwLdEpwzHwEULjq1
iSg+rf96LsuAueqUrzapQn/zhb/DhAAy2hZAbI1hUxn9o2ATmhlHjjLdU2l0fhoDiOmjIVtQBPkt
UnGH9En3pwqpzoWriQNAvlqJAnrx7flp0gie3Yw85rGtLga/pdbK5fYP36gIh7Ec0E4M5dqv4a6O
Ma6iorOrg2enkwOtxRdbWYO55AWFAD57R3NyzcNpIcDDZAdEQbVaN9Z6a1OFDhU7Zn6Hwx0RBbeL
UiH38+jHi6+4vccHVviLn+VUBPDNv9QctKS50+SBCh5KiI6kPf2elkWxmkrwg6IwVwXlbZuiU0MN
ALt5/lJaVASfBTnql91PYZznvaV+/Tb6Z8SoIPUmlpdwg3raa3ImP3gSE0avUTN+qjUIcfRM/WBX
Tb0v5KOZDBu3EdwNm0xSVFlJlxyKyT7QyCSm3MBILAwKL0PvqwqPJmZgV6oIVruV707GGwQGPSUd
f6Fat82qkN1c9ytba2AzxhaeUVJhQvxZK7adGdeK76ZX1s5VNJh7cFeckDT0jPDaP5fGSvM0H2Xv
LuYepl5WCLvWhar9BD+HZs36kqq01+5w3191kHXUHr3upBIqbNeNHsBFY5V60jOn0NdSPvCtphsD
1GHNU2JjXSyzKGTgCx9eT2PHUwHitu7uMEDJh2TdnkROgI1vDym=