<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzv9yxQ51SYvK8XcbHfCJHVWRQz+Q7DQUPQuCsbVcMRVvty/y+y2kDC98dJnEoS+P058B7D8
Js/ObgH74sl7ovdPUbAdpGQGxvhj9SLdI/2WuEHTE9BlO+t0Gek23ywv6Ditz6wK8I4EaO4E6iwy
QctppDZn3jN15XPxBOfaHFtsesYn1lP/mX8w7wjrHaZ+Nq4OYmK/KVoSANwCKVeemzj0ABOa9ptD
o7qhh8Ner9ne/w9bqdygQ45fFTgCEYso7mzGfnDjqKeZJQJYb92MQiv9HDncTVbcuCAFg58y4t6j
HS8a/v92aPga4wE1t9tTAlXMUuRaJg7cFX7+qgGcUbLPTtgeSN/mx2672JkX8dd2EL5NJTXqxNNJ
rKVeIgTPyrpXnXzjnX3cQbvjR7vdQb2Nc0TKDnmZ7hE/OawHSDBu6J85tqsyzIu01WEquYfgSRWL
NbWjxHAtNlFdwFUdAw/dGIoFVqAC7pPCtvi9RZTbdpH1xKyoGeo58/aH2icX3EAjfADFa9WjcWP8
K5jSg8XxhvJmA4qYK6yY+Ehmg0PuhOygvdNa20J0XNl8HB2tv+tLWO6rSrJ67AyPnxhZ8qVuz13E
uXowBZ9QajOpleDH/w1ALXXMiAw7JGFuS/xjMmBGK1B/tQOgadqXCIE0PV5p2pTvheXWMQs+yNJP
CFLEL3xlVIapG9UlKPquA/qBI5WtzXxoel6N8DNUeZXs6BxQSbqUvxhgNH1LnWwHd7isrCHJAorw
OLfD4VNtLEidMUvp85Pyh7fGZfNCWLujeBbOQJxUbxtZXvOh+iPd4GDCgUtkFVLeRxoSeVvs9yEA
iQF0yh5zcQz2GWrxlU8OJMzDwd+j9oMYePDP9LBlzv8pIGppIBPO39wtlcqRuZCiwIADrBxJRYCd
SqeLO3EG3eQeVMLHSLozIM7VFbRE2jjjlxuBHqVB+N8qL5VavHX8Wc9EYwkX1v+bzaSrn95U8FFY
qKVPTj4AnB+lETkdxiEDLGMqBKhxw123HBhbnQza6SRHmODiDroWUQ3BmH2EjOnhFZT2xQpIwevF
jDVlUecPa0WTTlQWWSglCXBBuYIwqERtKlBRC29UrMx4uJs9PdCbbmu11+Ogtt8+2slq/eP5ckF3
djOa4vbufH/cwbVIGNSvHtHWB+ChYNk31uZOLhmTOMEsI+t5liwkX9wyT+gFPvGq4LanCyK18kdn
C1RvFnbiUUVSs0F13Cyqk7XDJFALu40GU8HJFG74QHzaUlLwQNh1QhhO5QE8QWU1