<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuZyVWPwKKCg0pth9TCq/AAxZ/8qdqY3iyHDsmUJgxvoWHKQ9aAgAO2/v/dgVx85ZMwSHF1F
M9cWimzN+UtIBuvKHMimYskVA6DcRU4COWpF6zHJer+nI1TT2c6ha5L/VhUfo1YeHQ6fQh2M9xp9
nPuCJmA/RNXb1JM7bZzDN5BIG9wNPKf5o7pcZSaYOpO1EM5COKXf2uqAWdWucDlD56TTLqxvEcCD
wfasZdLLhrj1uN85iobbX5OcXxSfqD/6XZdczY6+HKDwlyc45f7akKnv7pOOOZik1KzsFijvhUB1
YV75Ol/YIVKeZb8+cYE7GVUpykmnPfXOPUiAw/4hbxXnfWU9e1Xcw3Mwv028YQ8L7FvRRFTuFX3S
BsRVoaVu9q4lslvmhUps+4lnh0ucAqyJ8DtGknVfCEVZdwlugpf4AQi2Ghm6Oi8PprwvilAYYk08
jmT2dytk+2q9T+ELmBfypLGYCs3n6sNqIktwnO0YZe3a/P0FKVvcXEa5LvZPYnPeYHCvSHND+Co9
pkMf0o+eHKueYLKO8vTQ90o0oGctZv6T8Z5e8zWBiyxZtjQ+oinpsA3+M4s9nKaXpqUvd1bCdrgN
duyUc5tYOlhIK/3JVHQ4L08AdmvdVs6SRErU1k1SNy5IlGTV94k8GV5opTLw1uuqo+EnAnOE6eW/
5WC3D9Myq5v/FPmgB/pjFRzQuQgNMmFjHPV0Hm/gQq6po29MT0doNSHSPYusetZtFY5pocEvMuhs
WEWB8btUhPYGBxyuRrXY/drTjZyfziplrxc5V441Djae1V8wzAfxO1i4v/WTphifgdbhRDHlpHOS
ddtF+MVXVMKGngNre8Olw1aaeYG8nmfGjKCPIu7OaUt7BZPzGHYTTjHTS5bLqZAoMNRZMPAgUK4g
iTtB5cWRzk44IAUl6ajxFddLgTSX4fLhOSVCWsxXHgvo8qoSdNWi8QuM3yN8U5N1qn4bjjzdFR0O
/vxASQ7n7sGp+AAbYn9+XBpMLG239xT1qnvWfTWRTWQiyEy0XV0j8ft3RrAGjKw3rk+GM6u8ZOnV
o1oSX6MDPK6Op25l9rf0tOf9TqbOidzRS3lj+G3krjhvW/4fKO9PJcsrfSSh7/QTCDL4K3JAPryG
lVjmnxqMFjLQU5sfUInVtM4nO3ieBYRxe7NUJZqgjaXyfMIGzwYdIR5DMr24+/5KittgrmxSkEt5
CL/SkJIrGc2BOJwox1si7s6GlTF+VqagT34o5m6k59F6SE0wjgb3fYLvE+Pl7IgZ/o5dYEy=