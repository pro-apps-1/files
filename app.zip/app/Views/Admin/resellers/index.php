<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvY0W4zENNbW5q4LR7nR5TvfOgNST+zXDfwuED/IyrDjYTTVyZSfsutUBmH6bYF3+rUzFgGh
O9RspSe1e94YOIRL5ZVQS4lRJLqkAPBjDZqF0RbA533pjD23H4g5kgO0kNYeZPMbJJVmx7qe8GmC
enmuKtRtTb4cUbQO+PsPnzsSgTObwq+CGQQ5qrZDDkCmdqGN5TlHh+j9sAofnWRjTtxk2IZSSmIb
Qv/AFGKnITNodCijgzVgzb9qvYWBO6BSfIjVSg1YcngZVFhp9aQ/7plPf9bdnxtlDIpfCRDyUZJs
XPzY/okHkSB1GWPnEClPrTvSLLhfisdusIcFkaE8SpCoKxra8azUal7jljxMBs5o0YZKVmUjpQa5
G536w5qZaJI01ZhVzVeOUUTg+cC+ZTvDCKUjBNOKFYlEp4Qp9Wzyb0FWiHpn8M96JFhNjmTcAsbN
N1q10cQ79VUAWKMKu7TkIAGzNDvpX/+QDDSGQ62Ly2CWOgNr2ifrSifwkBrrk3g+rxNYXvnmIpJZ
y8AafjV2dNYaJ6gmTTEzVwpejayuphj/nHRAuT2FXRqBYhQoxbezZTor9RnyKwfniGeVysDHhDUr
6nx7EIgiBtQh1MbtIgaZQtaiLXWss6mgvukqOAbpL7R/SBkpLvg9qU9B/axRfBqCmuvTivlvdSDl
g+HnTSpS4v1kSsGR/+4XOPcKo1PGhVeTfsHdqa1WiEORXkdao5K9h7OsrDsfxWtK3zh4I/r5n/Ix
VAStaL8gpLNBpzxPtjpi/J311RyXPQaMtNzNev3mXcMPVQxSB0HEWvwf6nMr2CG0KRm1MCBrW/iL
X3hrvCaCUUJQBFvpviWk9scBZAUvxmD/ddBX/p03nIbOJ2SuoMYwAANJvjSreruSFnmHuE5Sz9HR
Nc0prI7etNfiUIX+RRn/ezMlz3/Y8b+SUUMUjH0wthZ+piYWDV0l2qMDWu6Afm8WS9G5D/I1xe5D
1reqARrsZlVi/czupHkhrCG3KXWMTWv5PBFayc8KrUyTugt2G7F8/1q/stIrWEiCWIfq6HEEIlR7
uQDrp3IVrb1Y+90bU7oOKViWXnpTtXP29WFcBlhaia9qzwQ2iWNjYMNcia0bldwHfuhfm6K3LW/Z
O3/zXz5keW8TXe7DaDgW+2sB2VxkqbC0VgWOnCMIGSgAW2ERFrvoJzSMIa3GuEYL3W+yioyoczje
PLldCy1KIctEtnzKZS2r0wn6A/+CU8I9NtuHY5SEQyrzWQ6dzXqP/lc0CkkvmNQE0W==