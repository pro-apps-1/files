<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsgXG04QChasus3L8fJMB0vICfn7+NoKWCHkVdFpwUZCC/lPgG3ymk8A1irz1HoA4U4+kE0O
AQ4/wtLb0Iy+/OAyGtpCt44ecemvZMNLt5iYRhq14oLuf+ToTAqLNiMSSaKdcUCITxXTEgWF3a9L
45WnJWGKs3Ad8aNGI3rF6eORgK59lkgP3R323PUhxQbP2YVqWz3ELQQmEx52IZwEDym0WcOSlXvb
C82JIoj75N9WGXFv6CnZTiY7g/0sGFYjZ+IO/f4V61l89llOWL6IwKXuL1ehuM17hrUr7eilx5zl
mhrbVnGVDBIfg33Bokww/CuCg4vDdCQw0SQrR/W2FVqoO/pWEvGKODyKA2jUoseLEfuj/LnIaNjk
ULsjKuAblmQ5Pcth5ik2eNMcjAd6BJad8KAtjer1AGuucDurRpfKn0JGvAtmhlpXMVBfH39wXn28
8zlU7qJil2ALWShdz3DGFG0Yk85B1YIz6owaRDn29/F/tic5zXM9FYYpzkVEPRoj6efi3BJEbU63
dzIz4vjyBWTMvODxkIo+HxtCcOExnqvk4Q4cIQ4RaYZ3aEn5Wakf/cGwj/9XFsE9pMzFeK8pfNxI
+mM8uPE0uVfqTiDqOuKj0BHKqzuidEB86G134oB9XsBQZ2ihPikjbdj4seTYV4KBHWyoD8hSsG8u
a5Ksh/E6Or106xb55jlgYZ2v48xagkEV0D0YdRe9qs6rrro9SoE1IxUtROSwi3ymjjqEkdtGbRDA
Q6hKe05uDApoa0QfHU45lGlfnZEHoxCA8ecVB4pxssQHfdhN5rNHTz7uU0omPgAQRg2AeXywVVY2
FSn+ujbMs/1zBcG+BXVyvf3GAg7DLsD3AB38rD6RLMZM8W32jFlBtqRGSiw5/aXzA8WKGYKF2bjF
h7DHm/n/kJXxNgUaoeOB7pEkTZE8xyy3opit/mTPnXRihp6/mQppxhJ9uss++UkF/SLdMYux8VEG
gHwlcS/TH6NhwOicAS7Pd2dPRhWLjEzX3clKhskxOR+d7xvYmCk4l4UJ9OgcdiBqGy7f8areXWKi
euLatahPNWiSupASpk7LZKoS3F0didXGIwW3qyyrbBIIi9UI4E1d31lPcJ7j6l62Y6S+AU6eQqfN
zLyfu3uYEP4PvCH0/BR+XKvneLZ4+Cg0k7K0FLzOUMCOWu6tCQHNz4f4okq76tveIdqX+vtUvDhi
+mG620f5T7YhU5tPByGqXQzXYeU5WKh0N5nsfLcC/8OmxEZ+n1KgASheMMkVJGS62jYmlN57cm==