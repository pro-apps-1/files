<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+KB1CkKn/piOSgHw8J8uWDIVlNEhHQfKVyXFkGMGGSEZXbFgLyugjkXV7Ys6/Un0cYUA3El
z9KJaKNy+Zki0wcZ59YlveXx+X33yihNu6y4q7lt4pZb7UzUfzta3SP+CxEDmD8jaafyWtiWcVUz
0mRat3Kt34f+wAzQ+OM9FWKpdipMSAgmRbvSHuAj4JvBLUSNq0Z0z7L+SwJT2sVpknALnVKNo4ys
jrPtrzONbAnjA8N3A0DGhlHYtTF1qUzi7FZMBExqOIVeMQvUGGS9hHbYkf3xK6ul7qBj/AsmZkkk
iW75bpg9JD+n7EynpU6FdrKT6MmrBmJd4RRnQ0UI8IFVHJqDDfB8GUQqhPbEUZItsTBcscRApjux
MjwooSdiZeTw3KKsxn6aagoYUQOii1VOWc2oZnspFmgnGRUOmmLJwujRXifUaIL97Dl1v6s+2ffA
C7J9s451Uh+0gUrlxRXPXCwKjhOCRztLPBeKbEQQstfeT78JiT08gs1JYozMCDVvFx/Fa/mcgq7m
p04JnON81GHwvT0pBE7A+pqU9QmCAIxoEGZj0vSgwEVZL1fgTuWveA8UWSx8rm7DtHq1vKsL60Zy
ahxsDnP5OhnR/BofK2CA265K0rXpnxsQpZqCaCNQXUGQ5eatw6W0QV/qwQHmxPZz4WiLKKjmPyoA
MOpYR0exv17N/nLeqJ0To1Kq/Vm8HeOjHhxRuSrve5SpdHv9NfmNNg0UiZ1CZyUIrDh2y2HqUERk
ChsiATpAhyDYJHNx0xdIoknYCmiZw4Zc3zb3LyOd52Y9G64o2loZwMsXD0sOviyKRlAii90V4Or4
hTKLeTFOoLv+ho3EnG/3ZkIWxyzdSCAyUH3HmOCzGSdhFKmELGdQCU4inXiPagfDu7+n86t7nKs6
r6wgnWHOYWCFSkkGFYNG8r6clUwdpc6jyZOQLVhyZXMGp+5gW+I+S+dKbq0sVfEYZoZcDYb7N9jN
dtldzC9W+w4oppKPqxT0MgG/Xyx64p9Ip2IwBVIqYv9TueF/xrSwECATy2JT7khM3sRO3lG7V9rd
dOGNt1ekZXAk2x8gTRDyqGBTavg6pjppyFq7vur7x1JFEN32dpZcXt52JvpmISw1DfxSJ8CCwOWS
eP7BIHZZ1kwv5CwdBmU9TF4mkNw1U1++EMlSLu6AEkXdxTZF3Pwh8Nd80ujysvszG1ui8W8cWFKF
aKdN2F9IP7huPUIOFseD4pjB0jwlLpWDGNd157EQLzC+M0wpSakOL7NqRA+gKtQWHCFUU4AWw6zX
TW==