<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/giK4+98AbWL6t5R8hA1ntvVS4eiZUJbli1XPUsmctzrtLxaxsTAtrp4Nm16Hfd0yHxS6Om
7nJH3jfL+KjoT3Mekjsxzr/mofwu1B2bYcotgkn6R8DtHxiX4b1W5+ODPakfcKG9z2vX4II3xHTJ
QGCsBhPw89ozzTYfCN+ZjafnHfPkC9aMHRggCTk5j0t5B5P/0EokObstZ709hg89KEuXTp9CuFuz
lqlwaVr8ZAxxzOWQ2SV8TASAoS9KFLQUI4CXqAdLjW9MoV94lq2LcN4zhWAaPQFvwfeKy/P4KmbU
lfgS4tAB/dK1oFNBAkZfQ0soM7pObv1Qx7YvhelQt1bFgcemctuKAlUtWxPjm9jP51ZPcQFR49iH
v91oNK7DlULb3CuU+2f1q1yGuyMiPqSQdpj/GNUf85yZnOJD90lNpiT461ad9e4PfaQSzt5b7GsB
sXq+gloJWcMCdfbZA0IsUaikN1kSsJjcchD1AchcJdpucKRqSzRsbCsYWn0LzENmG8o0Y0i4axT+
Cl8odvvon/ckv7CVEqW7ymM60w0ZaJ23PEubIJzKBBumKTZ17qM5v70RPr2BshAKgHgMYeL1AXjm
faROyZcowFjw7Y36lMU71kOONuCU7HupocZ3WpXKCYDuh2LB8vM0tGcspOuFOt5YWlVOIQc3xrrJ
GsP5PIXdIyBvLBRdrCBWYwnPTucXc51b7yp2WHCSqxz/R3TFySH1iJkJ2aBS9hz75j5Aod3ceIQz
K4Pgh7sQ1Mm2SNypDro8Y4PUabvUsdAMQLG8V12cUfSKAW9jS4po3lOYd02YrCdzdYPN0WWA1dl4
sA1qH/wdTRk2iRKtxrLaHbQzXmVKyjGUcKibOu3dU8dLD6NUKdySiQJ6s6obfczDFRWXvCpXshu0
jigMb7i0qjO1Q4ARd5XAPhH9Srt6fGsDR4RZb1ekTN2h5GzwHWPZA7/dDtfX7/k0t3ibcb4ZOJ2/
42CR/ttTGq/1PEEFTWrfWImFwsBXYoIl+rAl3bYoNMtpt0p0BQgu0ybwsEeUltOHNSBQFslVKAv0
usnIvUN9vKUMNBcIEcbPavE6hZTDR+Ow4T7CVNm/jiKEbaMxbPfBLjWBYcdGt0dK5wMWmMzUyjkr
8/oqGxEgZN1L4mutwehCXEccJF01ws6Jb+Cpo5ULb2vZXQJauDM+lD6DycPtpF2++kPo5jLf0aRV
OhhzFX7hNYNuXV5Jp5QgFzr/wVjfAigPbYGriUbeJTybaQi9Umqq7vrj6eyco47tussKT6fwiaa1
ZY6+GmYrVNAm3oclUn+/Xr8LiI5n6IO=