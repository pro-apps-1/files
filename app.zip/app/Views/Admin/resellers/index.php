<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxBWQsjtVL1D3Y7+ICjJ/8AA/9bK39AqNUPl2LNTtC1BSAYS+ogtEcItymCKkfZQUVfoXlkB
XcYg2pAnlcvexYgvlrH27Bk+RtsXfrCZ5WT4aRudCjIErPWjN44S41VMu0SIENPDE/QcG1vCcTKV
x+vLnWmHeozMUYyQFY9gWxor+9AxtT365JvgfKWPZCeFgIOtPOeHE/RoH03NKG8i9mdF6+d0qU8W
/ZehCx91X/K6y7MbtNa/wN6WtPoxwxO2fmdnQH+MgeT25D+EjpKkAQLjijN+POoSGC3QKpRMMRVk
3gxTFmQnbKdKhosV513u5jFt1JXs916kNPMN//cV1fEaa8VVofQINgPK/+7Zhe7WkOfc/SWpgIAh
kJ2OidtMph/Ozv/urbgEST53oprbnCy0E/6+4VKtjqqerKyE5Rgqih7LxJKVsq9haHH0Amockr+F
wVnhKD8mWbDXoPl0Ub42oFKvc+Vf2ZGHKXKJUgt3DmTpElgyJND7BcxL7cq8bJwC+7aq1bjXKGjZ
Nio9vRkWUAdyKYke9wF1On6NvR7txz0wvm9yKxvR/37gHawlI4YrAnaqK51rksLRyu9hhFe3YEgJ
LE9Frmpi8S8YHAmrmM3Z/Zh7wpltXf1w1jIgxoCXUmca4zn6/zEfl7SrsPCIdpqhho6Zst6CSxvj
D+cHfs87KQ4RaRNB/zBgrhELHj+7PhlCixuxldDYbkIgfUoOuVty+H5qXzeT/EAvJPmYnHmHZq/d
hq+bga7qncD39lMScRKVNa85Nh67YoFGuaF2+u02MIhWhXBFVR0n/8A490c9jgpR8LTLoQhTov5/
6gNTAD5dhBPmYE8UXiAKqlRjt2T4LUxgbqn7U7NIDyUur2CiKS152ATWpX4k6z+dR9fil0I6tSaV
OYlKndD+hoEYxpsq8mio8+oTI3IAkKcbhLdzXjSs2Yk871QenREXqGhkpQfg1VyO9l/B4DJJEuBB
TBSMf/m3t3JVIUrAhu8mQYqZimukT9YLhQD8mKJ+Q4bw3u9kIzjJftdwfNXJmpupUg/8Sn7K+hrx
DNReimYcA33PS8MpCT54UrRMepV86HCYfzVsMqoEAiewpvfgcWPDTCVfXApIFyOJCvvRedkjc7Z0
dewgvnwX3T68xLqSq8ypOtfeNpY5equpVB1FhKFsAmuKCQcIYMBOrvSE+dYkAPoJDoXVvwD9+yQg
ryFA5t+7ChvoUPjz55DEfpfAp5A+W7J2byRZUnBedwA1DEnoxfPKxRFEhvs/T1Nv490bJlURFwdy
Vh3UFQDqW1Cs