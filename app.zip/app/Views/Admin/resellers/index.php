<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+LudPkpr6NSIha8kC5u3wfeg+opzWpE/RMukUKBMlO6k0x464VoE57TnSYSqWV2AUIKyQFO
99qJ7QYNRHUnE7k/O8CqwZHVbfs39MuQb/DCGpRa5i7AnvCFmfNBXpV6NvZCCOXliN1/ihN4ImkZ
z8sTIcBNX7e0Gt3bn+OrlHSLKbv5DYYZ/32WKxU+X51ep3PhYVd/nLVXsBZPTf9CY956KdPBHNha
LeHpM5M29bs0PZggvMohn7MBpNtwGeFQpXyGnc82gkQCyqV2yCGmDldWe4DlVHRn2VHdhJWTrf1S
qKTR4vKoMNb//6W53W0Noi49hIic8wURU248Jii8ql7aNJ+1gIwYCY8fXTDLKoqK0WdCSG81NVAl
/SUkZKbRtK+AgPqD8+brUdSLNUi04+dr2S7J8B11o6qkGqMluKDSuc/Fp1OrQlp/jXXOAe4SElJc
xVOVKSKeNrO7wAbKCG7twIQcLqbZIJPwpsvafiYyi1OQHG7WTcdgiSccQjaV1rYVGf/v3S+mEFzo
k+rSWTueuz4BI4ZYoXz3PT6z9thTYnzfenti/+gnZhbF3xxtiVcJNCHD5Kc7r1B26uzB4IyVeZ6H
1DOPY9LCMzW+MQgkBLM39evM1TJJ814G8GCEOgwcqHm75mp9dHbNpncD9o0Yrlod9fjyL1QEdlVp
Pi2ahzxg5+sDlFfb0lnGuQXByplWXu2qRzoHNq48qpryeD25skfN0Y+7LlZMddl9b3cXHQrwSB7L
DHkOypB0FRtTDOzEDM1+Ja0Xp+p/Dn0cls2Xc34xr4OT0wi7u7xW0dl/eSNmOnGly0Z7z/yqhDhO
J7sGfK/w7+dM0PklMutrtqTOHlS7thONd0yt+kJpzjauFxST+ejru2lthlh0xAgHFRbs38zIgIPH
ZPr1Bnhiv/iURVkb5dxzm/bPEyyhIXd0G8qSmErMIc1f2O3KbJI3QPM2VBOm7IVzdfH0kNvhDSEz
O+yk4ijfvtr4LBDkOjwBtxZuQf5JNNfGXgpH+ndXP0f9n7lV9fecATFfryc1YMvd3emOMZxCxvZV
um/FAQpVz6gQO7QMGbZFtqIGaRzqB2/5etm9TVn22ai591nrFzqm9hPk41+wXVy/a5/V3X8iyEz2
BPOoEk9Gw8p2BHkSDkVeCO64DaemUCqIRd0E7x9PvehTp+eWyYdSEDQFVPmKV3+ZDRsiYYvGJihF
mRMOzrtWByMR317uVkk0cKG+tcxdwiNIc5+/hFCU7qSZHFysdjcmD7R3mIgJnTgF39365Zq2QXnJ
wK7HL1eATMvo0LPuIiEtMR/OxR0KTcAI