<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxZAfP9wXnwb0mimiJ/PW/8/uiHx6Ll3fA6uaT1Brqw7UM4baz5qp3/2TjAlnqKb/sbZyhWu
+kJ25rxZY8IBOI4w02Fkh4WhL1nqkmhNMQZmzDwUMyUhLD4cTt7xkehJeTSki1cuSc8n/x6+nAKc
huH2KfhCsM3TyZwyn/QvwxzgG+LIZxaCCKbh8qgLlvIR+EYX81aTxIAi+Wv+Fi13W+7P3Pfx4pdX
WyjWajP7cUwECk4WqqXUweegm9N3uCLHQrUiLlQDKD5JiWCuRryR8iCogcDlk6vyCYI8//1lWa4P
AJap/ozUkUg0FSseSP5U6rNeMztWcm45NUgsusYHCZXGVKlS1yILI4jbo6YzRYKFLGZMkoIo9u7j
eyz+2WGwrcQsIKP8JvPDgSYCw233FJdHoxwloa5aza5C+fbHZSh1413z4RNppnb/gt49DLhD5vIG
p4S6G1XLFP86OgLXx4Unzx8BwLhq/P57c2NChXFzxIuZxSE3NAOQtCxDpsubyIv14dgLmZqxv390
cPWQbL2SykYW6or6tnVbSm9yaZEydH9ji8UhsC6hOe8HD5pJwvcCxom4Y+Kd6DwuxNkDmEmgvBY/
N/tnO2Ake/Qj4OXhM6xgUHKvJQNkDKdVpz+r/iKDmpKQOrAaUDONf2uI6/NmT6Y4+VF3v0PVUB+v
PUQLWGFabe/cc/B9B953M5pUPdlTJIKVNJfFheG5DE8+H07SBHFD5NOzfMKSqBMxfWjjeE9JbPt5
X+cRy520C8gc5GTIFII7ekjzsBQeVo0ftPKRdKRhk3I/dR6W+qhW+1VDLHRuc4XZAnrVZ89uwEhN
6LdPqL9aofAKG1U//BLT64ul60wrgsZu+QvGV/bOwOIlZYWNLwX5cweFPJtCMn7tILrHlF9MTwL0
kfzS8sHFm/e17TsiSEJBPo6ytvJ+n5QnirvKsyyp6Aj3wdkrlmWwlVYAhfELkxAMOfd4dQoTbd0b
AngPpESTI+CCINfBujC79+Zv//lWVcdYYG9baztBzi4fy3rGRmc4k+5X0WOEpUOWBItd+HyXGmtE
MRh+eOozv5tmToGlElgudhGWYqy1VV06mMEWSaZ9USHUjdd/zTjrAxvrVtRmmtWlmaDgUPX82Arv
oqK4Hj7TovjojkYVAnpe+HZjRkLjkRohyRm2ShMC3Js6zqlPuvvSaCxAO17dTV8k8cZTOlxEiGF3
NtGWkbROJKArDbEp+Nd2EYK29Uejkgj8P+8oXM65EgKl4F27Wo1f22VG25lESy4wkgFvg/5o1wPo
+SUkzz1tYRrPW9Nj