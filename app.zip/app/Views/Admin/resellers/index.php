<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuyjgxj2fY+y6+m+cESx5TgdsyXvIguGxBAu1HyAxb4a2py2IEijvziY9h4T953sFhFanJ+W
1sqX0Y1peodP/EUl/yhGMoRr8axh1NHA3GxP9ywCDgQF9qH+TwnDpv34zaj50DuPM8eT0iJxXWg7
+SOGIaTb6kPNkF/fvebK5yKFTjSOVBQJtm7Lr/7NhAf/RrhqusATpC3cJJXkwDaW5mutliZvA6jE
LHXuMG3E/C4Xn4N3gDhhEGYVOLMjCzFJdrw/CHcsHeRqKnR6xUgE+EdiLHfgd0MQ/kNSctJ8Uqc2
jOKn/y8COf7UX41oniAMGIiGziSXgvvF3cVzLaXbeXvQerqqkbgSrN9qKXYjRtEQoA4Gt5wV7P9d
O2mLvJHUyPApyNNnuQUZMDtyPLnqNIHH4PiCO7HsflMJ2rnW0ZWr03LRvvzh+4YnN4CZKcoP/94r
54BIa7Dzxs9dH4UD44Z1PkEyPmTNlzaBjrZNoOqp+ELO4dzjXSB+vD6LStkNWjg3HeZIqxPfeXWL
yQNgWtFvOUC6IwNhRYnp/IuTgyJHuXkQFoQ44Lsw6LIqzLdftsQXMa6CEsKcb95HbFPhdo8ue5GN
kdHcV+hF6bLr04/pbsO5Ja4ehqBuDgJhxjUf+P9a007/IuPUW76D+ggUThDYSlfDHdv9bMK7yRac
f5Or2DzBgBj1zNQTRV2WdDF3uLj/jSEOcRVrv9dBwvJ9Bz4xQ3CfN0B4/NxASsWgC/NjlCi0OtS9
tuCHy/GMjpYmePfs6yK0Cm8k2+8toB550/hTqeQHpKvhDbTrrnR9fQtSAQm0UrawAX2TRd3Yf+Hc
BxiKKwYtMf+XpAGpAoH8crT71QtRSk46AAgV+q0Mpa1C363tOykw6ELuJuYh0wssQa9F2xPtUxTs
yIlFWSjIqOKNd2MpvqXTRSYNEC25sc26vHuZmTV/pIHPYYaQ94n0ETnryRXeAcIcBk3vw4VeD7TE
VA6h7ikK4LRmHLdkf5bu99LeK3KdHwQ3VDpJ1OiMGsI2xmYHG8Z0c0pG6M9gLBKHt3h2Ut3wJYq4
JJGvAulDTAHyc0TaHTBFVHq+MqYLW3UBXdLh3PGQuxxssfn6v1QMkgTQn1l9v+iSUVrzmbPlKXHL
I1mBfHMuZxjaVRKUP2mQvaQPSdGqL887DGle5YTrC+iPu2bd9UyL+k+k4AWEsJYJ6GEDQq30U49S
FhB/kqOJIt7RM1pykcgYnhGBtn0BX1GXdf0AM4yW9rvBgxzR6hyNM+Fb