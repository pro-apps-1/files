<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+VcB42MUfLtRoUvOuithdsY2K1xLjudASveHR1f6YKjoLbOwCCcDE85A8f0M0WQX4FxbGw6
x84HXy2rqHj1n63f+lla7O17gVGuHk2yoDF/Sd08dQDJ8IxyWKfQRr5bYpdV/cI45Yl4TExpQNa8
xKcClGJBNzOudTMStAVxiQmnpfxRCJWhcT+p1oiOQ0BhAKUXHfPXPbGzR00jr4/tQO80gEUVS1XP
CaVzyBcEaYUJc2sWyVQV7Hk2Mrq/xPnyGP+b1DhSGeAicLBv2dluRzNiE99MisY7nteF070Bkx7r
MmY7EdkCi6h0G8TiJPmVMZiV0Rk4yrhaY4vUMdqk60JJB0mgcTsZbYDhqzqf5xt8TtHywVwRAX6z
tLIVzKmeyO9W2zygQc2RvJlUjucglXhtQrzzTyVSvKZIYRtgYysr9vwtToL9e/gk923oDOsD2DDu
CZtVRTtojLD/5FYP1t7whchfnxyq2Rv0ygOvUXSSF+YRysbocm1Q3FWUMP7grKbHt6rGa7RakUu+
P7Bu738QI5yW3JrzvS9aTXVCShT/8t6PcD1kh0StM8Nm69Rte7ZX27I0/4FXwRNzK30TBTNw5EVS
MCIJv1GTH7Q2GT2gu1dl109z9OSDcpOGOHPZbZEG3mpYYRbk4RuP+yBPQ+35Tx02T67rJBw1fYCr
HMVXTvqPogowIquvzGx0X0gscrrR7OmGVdruorrEYGmLJrsV2r1YBQW6Mdk8dlcx6IX1PkxflUc7
3vM/LKRaMUqehAKlCNufu5QFlytUy6+23F+HlJQOhBKQ4Dcypso+YeC+m3J1NFRTLMnXlrFtgmyY
qXDTHsraSo8/W3lJumBqLSJEg1RAr6z3bOZHOE6ryzzFvPIK338rVTLQaX0mN8F9Aj/3nd6y56ef
aKz6CRH0vNFHf+6DDybjJqNrwE91laXMQzMMMxfVPZWpihTY9FBg5R+eHL2V1PfjWrA4tAQ6cL4A
Tux3IjVw4qHI8P5bFGDchI5A7CmUYf0utMuUKsVgdUmH6dbd2vfzTNv8YV8sHyoACNAfAURds76Z
7OoAUsaCdTagqfMOsbj8gU3/i0XFlzjsAq9lVMMCoy7KvR7HcVALWo8tY0vC25DAyzYYq4Mu00GL
Ck6kq1+tFGx6ISinrYY8yXzVzIxT7olo+nGQxKLXG6GAthJHB39kerJVyMljAyDnBcFWEeAIizVE
dxXR4KDvm72Bs2iCu6Lk9biC/KV87LbrFmzbdtiWUvdcryKFJMJs4TNVvayOtJfW9gA0Pucb