<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPowlCWF888SqbMwd89FrMdf1j7dl/ychti+DtuzTKbMPsOMtft5raBxLbwhBXn8RTQJlJgpW
qtTEFo4PcXWCq5JWTABw7wiCC7SthUHLtxdvoLZxOczlctbfKxQPVRHYztowY32eHnc/njpuGLsv
XiF0mg047cFmiX+HsnsFQGbkyXrNZj48BGJyLYyHxvUjkguDPKk3/TxOOWTqns0CdbF1CfpaRXCJ
bIe/qkk/CKgGaYi9tO1cdeo+Az6qA9lahYwKhFPx4aPphoX2ab64hzVSx7lUR9Qa32hF5LeRJmr8
Taeb4V/AWaDyiYsIDnTBoe1d1jD7duPhp77YkJAwaG5NnRW3BRDb6T1dJH1ayLbRcvaQOg6TSzFt
U82yUQPXVvLqV2xagi/h9pkxA3H6U9Ex2bhRrYopAft29urtDht3xDyHjjW7n66SfI3x/nVmNYCa
kra+/3AwQBNBtTcdKDTJXTrbedQq26NmKlOm5Vj2HH8ZbzMwrv2q4bmVMouAalPuDTT5QRIb2x0p
FQ2qrfM7OAWrdlritDrliD9ID0Vdq2uZDeJBQxMIOoTKS1yYmE+x8xVxXXBBoKwcMvslRXmBoX0e
yAPCnTvgDYlKbDnxSPRG61QcVM6OpFelDe3ioN7jLnClG+pNWAXrx5S4Gc4jRKNn9jM9ODf1rGB4
d2NYo+/uMV12TGIMSqVq5jyqi//mursg9Qj7Ry2Om4jifnBDbF8ShvymnC6FNpsxn2MYEYuqmHNx
QVc4RaQuK4YyReMBTNUY/D9lY/H9S7wBtqvGpLxHedOHyt19pN3UysNsK5OCSIQMhO3e771B5BvM
7IhnVUQ0uNTlDA/Tq4KnlHa1eMH2I/yg9p8U+E3Fp2MFoOLZzeoAb6Za3e5H/pWYuPU8IV81lElh
2UFT5zHbCdojnmN4rNuO1O3Ur8dKl649cEI9Le8KmLKg2bU7EXVZYfyeC8xWqWpMsyq5aSd5qoTM
7J7g6j4HVrlYpMkoy+slj8jyqJFa163/JgpQBwu6wAMox4eMq1x8CAc+KXGRWZ++EH75PtsKGBlt
5/fSsdduZoxhNfNr7vL7SLJZI5huD9GZbMYLfH/f+YrVDVWTU1vdjIDo8S0eGYDWwRvXylSDJ1ld
PNgS1XXsGL/xZZXOaHhLj2G9oNx67wwhDmjA0XmuPVjCRVKZBbwmjtrvisohuVFiufwZCyZxvfkA
2P5SGoytqxaxKceVVrCSgbyghJD7+Gdb9mMWDxZo40pSfE9l22hXB61+IQrKThH2/uybfEkXnVNV
Evd2sa9SnR/YTynG