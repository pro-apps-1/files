<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpVW+1VrVS5OW25jDAKTgLZ1aQE3Ao8zNysOqxr2fu5Tn4XAOyCazmA8ebL3uv20iQNaA9eG
Kr35aFIkAkOR99oXez2pK1y7GcIYjmbYHQWrqPPoC8aR8lbydbAXRVc37g2eiB7Gg1e87GtyRkDC
N/OSzoDAb0wTq/vIH2JpFShKlHRqmLrJ8aCCttVtnrzKpaDQfo/5Ji4SvR5DzDE5K7MGErBlZuL1
egXsj+eM9t/Kr6kb7rL8n/2iWdTOxPlmR7ZXctjCcMQxLMV/zya8jBPrB3uxQqvNGrRyTdHy/Z9W
v3dS1CwGLrspjyWV7leZYc1ws681vrh/3lLz1c3dPOs8pFPVNYC5fa+w+w0JQIA8gFt0ZhnrJxcO
/0V6IfYnMeRpxMMu72br2yVx0PASneylWL8TlpGL10szzUMyR7kfG8elfhJ7XzaaO1OllIhiMgH7
xit7Qa0j/BLtfPXlClAU9Ib5v9K0FV2eLQGPoF8gtlAWC0ojduqDCFgCz7dUrhBmxB03bP0orgbp
J4QVOxmZXPQHXbJ9zquG+fIwGraiaiiqYZCSr8mWIKqVkLo5ZXLzeuH1LJ34O+b8D3B52eJ4eCu9
WPvfSZzXPzB5l8slNnCg5c11rRqDy7O0EjbbVERrj/mD6lfQXps5iQKGlvx8cqyACrpsomZDx/DK
aRC/IwGSH2ZPv+XztFZ5/Ib6LLoS1K6z0OvSYiVShw3lNDF0bzdfrfLxe06Cd20gm8NJIhiL2WZ8
8+C14tLzxjXIleUmhOZDYbLP9xfUtYg+iUeu0l0wHLhvb7wvqDRok7B+Vf1fkGh3e8H621gGrJ+o
lvfqANUJjz4Yj7ih72Tg5BDBW8u0iLttVxXFg+KeqYZx+qT5ZbkLbqsIfESihhJ5C2o8UoQ1kP78
rDbBQo7EToAq5ET9JqjRqDAdI1bX06fKdNX/M5qH+BL1IKUgZUh8nucmOfaS6sysNjRXyJMIUQDX
N9o3eMBVwe8+LctEuJJ5dKueUoSzoyHE91eR3VCZRRLagS279HXMcwS2SfEx7zsihnx3ygUjq4RB
NMVXOZNFdyLC9gsCKQBqCvpSGp5RydAM5gsZ3/3Xst+9zL6axGrKiqo6+y3UhOOmordJC6yByV5u
56f4kiJLigGArqeMkA2Dtdc5duvVfvJdYOGzXP2igMb9oDIN28lYvbjXdpfV+6VlbVouzmuEGYnm
Vnb1nTsfGRRt5dcAdASroPAM/DoOjKA50qu8i/2U0rg+ThdfwTsKuUvNqAgB6JEDz00HRJC0ZSlW
5NK6EWonmdP3rhscTdyuk0==