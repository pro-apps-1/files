<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyPxVyY8rqFWLRhgwzULlehV99glnExxKwQuwrgLqmS+tHIxPvCqzYvsw1qB9GFdLRzJQ6Xl
5ltqD6HOi1qCT5vYfp1Vu1Hv34THO+LybzNOnY2CIS5P5v1mJ+VG9FFVPWnoOsdooBk8Xu1gmlaf
UTN1lyOD2Gsco2h6PhWlAOzc+UF7dcpsr2BHyhYXWNil2fKn+lRgKC5FZRmNLtuZfY1BgVB5ZBoF
hA0RTx+orUo+3Ki1j6dOmAS2q7hV/WcZ+33UGv2yD9MuVnh1EjhBxNnax2znlrofrP8OTNjc/8es
lRXPadsPBViYfixGkNlqHdrdI5gFM6KUfEwbRkiNuwuaHqA1BSF51CJoX1hUjtSU4qHW/MzoDbPq
BfombmWoWdeYFJX2Wr7+7grHKE39GQ++j/n7uml0xLYse9Q+i4LLIPWF7VVamf78JZUnWx5Vyfz+
5Qiou9/EI47CKweWbJiI4CkECt93ppKpSUl1fr77kq9Lghb6cV0NR5lNILGzv2Pzk12BnwaGvAzs
Mfrsz07mYmtfxGFyzm1v01+HbXKs+kJ6RnxbuxZHM6CFy11qLMfRuoRCLXb80Azch5t8bB8Qqc6H
FeVXQxVe7ha30fPtQnWwBgoryPR8jehzOKdYsJ1yjUVSR7Z/uY+4e8po3ya37glq+5qQze6yem5w
cmb4i+RcEsStI117H5jrmkeQr0K9c+avUYsOmsh5T5R94k6MB7BgyuuqtmrlEnU3WuXcM16DVADz
nzY+JDG7zrtH4SemJbGRHUIaUGe3YZSn1R9W4iZr0rvxVNw0i8agn947GfU0EEFV89L4uj6uDvYv
+3Tbsy+3nSQ+NNWC66ZFEWXjifa5oXL0+bcPjT3gyauWu/XfDtNXQ7pFGN+VLGAuQ++fbVuzQYjy
WRx6Ew9UJr/z0bRu2G7HHXv7ZcI8XqpjFqzvns+Mv910BE2a/Xf6Jb66gcixBz1xiigAllQH6lCQ
XtMyniK3TW43bkDfnjTIfgjiSWemFICCh4S4nTTPoJrV9AIh6Ma0BudQNiA7Ut2vLxKHfTasZI9g
L+d3SsntFT3zuwmzleBP9Ke4AvBhJtub5MH77jsq7jJBBSDcp/9mztAQ01uVaGOPA5r4oiJjYiat
8w7f/iFoHYTq3JAFuSzJS61qAiE6/Al1aTVdqVpe/nqQNymsDPgYaCqHvDJ7VPMs2bEd4LwAkB9C
Mtyh4KxrIv3dB3IgRnpwqFd39oAnAjSr4FHq/uCU+vkELMwc41GevROUPgcj