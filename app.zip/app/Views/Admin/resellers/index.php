<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs1mrwi8xIkCrR52YFu8AOqIx6/oHOFkvBcuG0rioGIAtfwzavEmObMGo1BfKlGrAQddtpMY
1zCowliUntcwqjo107xggBqHhespeD6RXHPo2SM7/75BsLc7/mwFvKAt8bGwMhEiUmD2iaBj57lW
WQlnmL4ukYGijULi6nMNWxPsqL6TNEe0prezpz4pY2UPD3bnIKl/Nk7Ia1yMcuKtYqbaE6v3KaAc
vPKHkXsprq90wlF/HemrzAT0w1akDOxUgptmXGmX8x4qZZJMw1YKFlZa7Sjgo3y5+d4vpuH3zaNh
2djdElmLVBrXxNee9uut8h72zfHi4kybM9lV8ZxUQ98xJG1fnYMP7/IKb4SoUfgCgU1LAt45OQoX
pYfw5dk7QHx4VX32hVfTdw7LMY3KiZF31iHQpg0tsAqCdYO6Gf6bJqC7uDf0WLjWTCOqcqI/WWR3
EettzuBuFYexcgNMggSPG1vZbzdYfkCYGZj6lTGx7BBkj1z/FPv1+L66nnuJrp4rnZD51/CPa1Lw
4QWi2xZb7C9nS/Db4Wvd7FJ0R/adAfGvbM5Wn6w8/97qVmi6/B0QXjBvgu0Ph5QVkGnbHVr98UUf
A/kMLi+Nr3luhCJshSLVLCzqU4V7bmRG0jkn38guGE9n9Jjt44uumq4OieIXYoXBehRNmZ0Ha0Ri
/3xkf4gzLl4e3hE3X4jGq4YCkGrUvHBh7xh/sBtopdQWgvX7QZTiVOVOPKWIJzc+z1E6QPf+K/Do
SDBqk9CKGSobtE9pjZwF4FkXrGq235Nl3y+JJAGktUurHNyUfdmVzcgRpZfbRt9nMvSU0dRYwuMj
8XZZw55JDRwoy6bMSveBKPbXGpwA9J/xFhZvcz7D0Q4LXn5Z7k7mGWFgNy73hB2SpQBKjRfDIuZO
K53Z0ZHOd6QFw7lHlbNifYNmrNwMBL6PEyQyirfBIrEQfZOX2l+u1p4qi1FytD0SrmDzwNR/CN89
iOAyPDx0Vqy+pcLd2+EtzvBS/eKbudZeFp1MNaLQC2ncx6CaLSwlkRVkFMwlNI3AwY2Iv67EMT7i
msFTLYUveaE3d43fjdaMyOKnIFhnFpj65fY/m+RS7o9pG5t+5jv9gfwxORHhwUKNTiaCGQuY6ZiL
vaQhTgt/Qf/iEb+f2y+kPt4mZ8gei2Vfq4BTT+Au4lTHO1FNo82zqYSCVXz0pAhrpniDQAaEqLVB
l8FIHV660trar7ja/c7pfayjhrHvLWYs6nXAI86H3IVIALs0eMsDnesaUxyRqDH+6W1CWTKvzij9
OuhlPHEM/iGoXuMmZhktU0t+