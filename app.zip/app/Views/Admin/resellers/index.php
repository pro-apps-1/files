<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoWJVQt8p4M3bTBeZkWfXwBcijM5OWWdU/ubcKaTtjvvKwLBTIoJRo8M9pq0A7PWIsAEN/lI
AN5/v6Wu8Y6E0jqHmbo20y/hS0hzsTdFpvxt2C2BWCigU3A9mOkhMBZ3SJB6UgCglyoIJbI/Ifi+
9axr6lqNlFJ744gpCY+dGNy76BVoyHmdTRcHIBjI3Ks4szOAMoCY6w5fggtT3D3/dvDrCN7evaFQ
sQWg1SbRSwSfwqQri36vEMLr6ffd6JUWApJypXui8NSPCilXjyMnfmuGuqO3ksKzyVeSpqBH9+Kf
hkcsEmB/I3vuq5n+l+O7LOmaEucfZK497KLWWVqelLd/2fwYTvSj9Z0EYxXEEd1SoqYi8zmu73Dy
Jso/xyBZDKCPnNp3BlgrXpGHezxPFwIYuOGj6DTQrAZZZ6yLCj+Q07n2IsoEeUqBO+iOUezJ0sdN
fDGt3psHhR1hxuXd3UZi61Kl/v+OZ3/rcQTaLqQwPVu4TcBBxLsu4F8U85aCTyLgmTMepmjTbdal
OJ9Cs6hGy3S+o7gslDEQnZFUvpVOwPCJMUu0UXQu73c+8s7nlbywXDhJ4Ba2n2iV8VSXYFY8hYoo
ih+6tpvFqtnmu5EXUPfxT7H2DID8rWj+inM8zdSHy2pcVlyeqfi+99Gp60dLoogwkRofdpJd82R+
/b+PPTdHOvFaB5GdAaSenr5v4uexEEZGafHd/BTTNNXp3adUFwvs4lFBIllqQuDCSHSXGzPaXyKd
bMXAvr10bRxVaiuv8VWsG+jTX3gdqC3i+1vuhDQdMpXDAInSfR32yvpNJ+n8vcYYPM/eQfPWezvN
2gJZTvnUQh5UiyQsj/yibVEl6+U0/RU8T7YXKyJVUNeEwynZaILK9QrOjWzGQT5+AuksLzqVl1ES
6OxufqN19l/OZlNHfv3cNfE/c4ZhNbNn4MTzYurSjlsgr3b2R4gW944I+tg1M9tQoKUqMQKHLffC
+Ypax8arNjph89O8g3iuF+PhQ5WFDt5PC5Fq8Re5MBM/FljJxV7gwPissmLFMEy9g52HwaDAJfRP
+Mg9BPbkrwbwxxSXWkW1dZqGG6GFuup22yRUa0OPpBmzbxhlbEg9fkH+HqgLDnI0+x5w/kTwbmfJ
bUvDwzRck0p/KMm4XI6v7NNnhCVvT1zotVOkgYtE0vKIW5BTxeXA49olv49a3r1slS2rJU3W5vCg
FZ0LP2uPPcFTtsT0cI91CVN7L28CgYo/sATBNABJwt6Oo/fsiTAWoiavfxHQM0SBtwY0R1ef2i6w
Yf+sciosGtXr00==