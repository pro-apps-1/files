<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtNlqj0wO2Vdmov7ymnTWqMkH6aqNi8b5UM7bz5r7HQA7EkxdWpbuNl+64wwYv+Jf0437mjD
FmEkxHIDitRJQruWSJZCMMtpXibRaEzszp6Ur9H5B4HPSeHJf/x19NLFuASphQ/3ZvwR1klEEv0p
CURySzU9Xowk3uGvCc/YYYRVs4ZDJYTTC2kA++nwy21mbbgPaCLTFxCivoiFss2bv4hwXZ2kvuVr
JCGTh9xKkXWh7rNAzB1IdpCZErVtbkN2qh1qiAHmtXrmAIhk8KcRH1+1U5fWQGyzI6FpEIbuBgRn
hXoyAfYeP2ARx5+vkCFqaLIRXk4L+MdxW+NPhDTUy03PJ4m+HdpXbkWoTlBUdVn1eW7ipd6kilYC
sQfLMjWeU0Rmsh4G5OaY/9ft/PbF51cPC5Z3RKa9AQA7ptNm9RM+1W6e6bd25EMiCLPHXq2XZvMz
/iSJJNFkCTYbmENYj0/2YoaDnPnSTDGwfnOPSXWcvUsrpwc+2bYU18RzXOhA9MPlMILs1Z56ImZo
1fNJ/KWj1kxea0TO99RTFWbDOwcN8zE0lXdxczfh7Uwreg43BtfHcRaPVgKke4a18rDbygwI8N4o
luDjieu3X0n/TQwIFf/pNkWxV/TDW3FbCUrALT6bqQ1K/i9I/wPWuTiVJ+TQL8yLbABOJEbJU5dL
cxwr1qbX1bDTk6OWmNudPMuEfWn52tARZZNjhiDwUw4Rd8GGPUQ3Fo9iBSXwEWZVj8O9NRQ5Tcvx
uIL5I4vfnRyQKE1rStem9bgJZvSGg4S9J0k61dvfNWKTSTCPemM8PsZkDGNz6TgFZzwD/6EORI/D
EdX+ODKp02XpuyMDhYbdl9D/Pb3OZUx04E5qHz4NnG1RNIhJC2X3Thy8PDVKo8lNNME/S8JBYjfw
HMWHyzkJ+JAGd0aWKclEdtcOg7sLYc6093tlWop2fKL6XlmRrn471eoBFu+a0GlGiLVPuICnSYVo
0M/TsLbCkWbD1thwrb+GwZhnckpe2Loibtj/Fa4tRJlCahDATX2Z0v79B4lQtiljrK7CgTJDU2b/
RtbeXWkcdy50loccKnZhekeYq/toK55fwhWTRJ+9mooKunNwPepfjrmqJ6l3dmQ+AwFwLzMUBHY9
VsCSNBk5ncF1wDRDLAmcNNDoVtUMR+llhaxJitnmO/SOeY2heeJot2+EeAN2VO/zrOiEbyFDbTPR
B2l79qXF6/9z1b82KRm1ib+hiGAgveLcKpRBYdB5y8cKeqUclfXMGVHXt2T77rFy9GYmz/m9czBX
NsT7q5HZ8NQlQB0FSr3K