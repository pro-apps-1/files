<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn2No677I35MdbPTGYHWKswGsQc9pqN8sRsuizhCPRJVZQuif5Wqeb/rY8tw6lbPxB7zQjwr
NXnNHEumO/ymz5etR0OiTah9YyucSUwItrlCpHXJG9qDBAi48by2ecrACYgwYxuUPvIgcBi01fXH
NYL+KRKvfrjhG1eJ43hIsNa3eaPXbZLqNpxyV64QAX1BPxI0ZmIVgXzxNGE3iYsHcPN5YeTC8gMB
iwgeeqLuHugnXm4WXduuxE4NAuyPyhwPd2EfXQMm8g4wBvT9zN6ty5LBgiPYrxr1RyDUuk/MXrpC
itXN/tm4CUvdLIOdIRal6e9f3KKQBMXtPYQGcBRNELSt4jy9GpTgKuPqnNjCg0UHSxva0sKYYftX
7mP3xXG2+Ivw3es6QyLt3d+GjcT8+adbhi0oLTHFnD687H4fup6MxMJS4abWwvIZufMfq/FIS468
NIt78w6wRP5D1jeS7xZ+JJRlv7agGRJhBIjo1PnXr4sZdBDKZf3Zl0xAsSmLfgfeuhI85Ju6yJd4
++MR+b92uWOuxWYpDTCveisCLcwMXbEVUcoPB+nV5bDdbkU6B0XV/7c2mVT78kOk4iqYYCN/FX0k
DtLGyzeSmCIoTGpWYB4KlYuFnliuW9892IlQHuSOW1cgw+UmR74gZ+GrbG6Y5sSOuCfWnKQW/lOo
jigezWwveit6TeSkdxvFAmJqjIcEbMOe8hKR/+7Kz+mjakilHjPVstPfoP9pbQ+nKpzVJB2FQzRf
05r5fU9j4NUj0r7Yo7yfiD/1mr7TUcKXHIs8oBoIKcdqmaxuPaB9dcowrwx3/Mk4h5h9V/AAniZq
1BEODGUXtEa3iuchxvdxZOMBW7agxp2sR8XGXCLlm46PEbDIytAU1yLqqtGhofWFs8ovyCwg+Mk9
63cmwbaopl3oziVnBaiVTteB3gEInydpSc3r0vOKQkqsSdS6bL7oixAzht+rqVjANXfUJvsVH3cn
61WfWfF+Bm7w1iio+MfUIWoQhVOz7EfTsHv8EuqXA8nce4lM0OBx0sEQngfPr7Dv2JkdPFch3TBJ
cDtQuJKRTFslA5VZEq/mcOxV9GQbmTe1gS7cE+2EpR9hpgQ1bu6Hl9OkQbvfMb5syE7fI3KSqRLl
R3FS0IIfhWVpjx31XHumU66o6MWpTonxR3qMG4OwFuQMN7N1+bbex8ouemkBoOaam8Z9wFs45ues
W5MOcxeE6RULUSFOKO5swlD5B/QD6WBlao3+Twzf6Zzz5vkiytP9TCJzuAcIRaci