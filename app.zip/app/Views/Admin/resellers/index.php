<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpwgMbce9x+UjMlFUlV9cgtvqcChO/EU6yuWxAhxQYqiiiwdw+NzvUAOEhfhqKFPWiH6ext6
03qWhA3HADqeXg/2wbxla7YW8VNE0RxEigl5Qwy+XhPWcCZ8OaYH1TIDMcStWOgGRiFy631FR+5g
OzaM+sgO37aANInA3RUwSJsW2KinooVkq8/e1BjtAToLhHCJ1VTlQWNHCgPlYEb1tYu/pBzuOnah
QUYiAsTN5je3vPE47hGetXe/IhfnUMixvcpyySElYLZlp2Jr3zVqY4o9JaqWU6uC+3Wmxlr/Dqx+
/hWFeZ7/QwvAxXsLRz6eNFKCYIow4MdcNi8GxjwuMPdZa+zrvW6MIkjAsyR6ECoCDUgpln1UP+uq
kb1Bl+KTzPE1AfOk2U86KO5rXaPha8ncwijJQClzis21mCXslpsIwUcZTuzYS+AGKBEm+SUBhaMz
mBIYDeyzHEUFE4p6RJjFjjBac+JUr38EKMiXBXyfzOOMN/dR8x+H2Y2kuIxS1cK/vN55BzyjFgsj
SImpYQjKmETU/JRGyp+E7mq6Fx2ZlrOOh2yj2XplNGSIdR6EbjkMgJTCPz/r/Xr1dHxN+5HRt0xq
uYiTQQbp1BSFnI+HELh6as2v1K758U6B3G2KCCikEtaz3C9aSSV29qqMiCjk4xS9RWC30k4ZqIv6
RAWYjliL0mWwl/lrJPy8QOHVzNfRgkWHDCywUGqdhaFsac7/e5+Hyiu1HjiPV4t3X1VyhtGrEhSr
tvKFTahWjUDqPOeTK3WtEt0mRjsQlE2NFq5wzFkst4jJFS2lVQRxVRbXZ7kGjt5y74dzgeMMKaEj
zGQ7/f/cJw/0st9GpIhzqmWKtKblC+GRcy80qXZSjMG3AR7gV4SINinrEuxTttp3WuFwK2JdElum
SOmEOYE/L2vOQ7CgkfTlJ4ILxiVn8Vb5GQT3DEouGkDykvz9G99DtuBzNHWDg1N2Ng89izX7xJLC
Mytsdgy1UbkDRVfepWixqKoFtoiuJ1UpHZHtdoXdbqi2vSJ4+eaLPskH/QMs7DTzr2wZWWmskIXE
lgx128lQlFym0Noa+lHy6iRhK5sl/+3dLfbO7KyUzlVmiLcmNNcJG+vhc3Nt5mAcZDqejTOJ9qfT
ACwmarKQ+Jv5YJxQ1uBam0XweKHmv7+5+vQzz3CgVj5m5US5GQVzt/OS8MnqngI0qTQYq3q+vbt+
ulASoUF1IhFtD47pQV4+KvU2/37okRWOp1y633VvIVPUf8Wt0VdmVmGn6tZpcaHHkOvlwA8=