<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt2fkqVWEW1e/MWkP6BhsFVzXs8rC0Ixef2urokcT5gNWhqaCtI9B7bUjaIUWn7kuW0VxU8+
rOuC+bZ7SCX2htF6CGFaGGD2kVmcdm/MPe0mZ8MUGAca/uPURhHaxLL4H0ag/dxTXMS6coF3sHJ7
H9ajXSAFNan7AB+N0+SmH+A006LZ+XGRYI5kXhGo+8wS5etkAv2sGAwLRNA/iLBAfXoNR8uT4xbh
T74EPWd7jGUAAF8z7m7vaxh7+2rWrYYwYvjAWFm/shcxgvYq+RWdSfyMU/bcKMNDvWEXOw//3IjB
eSSB/nmq+R2cQN0fKLmWyI+x3Dn/heL5Xty5rGnCfcuU1DiUDqRyh8HXSsZfAoYKSGUtqooZd8xP
AMKEo3Aff7K+ywKHv12hMxy5KXIOgZwCN392SOoh4YUIWnU5f7kOKNtSdT2rThjPrXrZ0fG1xAKn
vijPWFCQTSGgARlbCKxF1zu/7mNadLWvxgtmu/fmtjxKkgtsNBrtLfR3K12H8nYwFkoBRzrTR2kg
0N0/7g7Xo1RcyiuIMU8F0XwkTOtFm9cwYtPVz/rv1LqgsnDHnHS4gKDBYB3WaMHWqb4z/Y9LZwbO
cabZC6IrZLzQRP1/ohJWVx1e3hRzwKK4YgvclgjXOpc3+WZuKgDEwp5MY0zkVGg5qzz08JXuC0xe
7wCeR30c4V+fX7P9VnaV3HoSDHoQDG8NjbjxNobZzpX9pOtFUGpdy1+OGgfCclpDkLqEzGAt0PYX
qoDNrlZm9GBikh1/bk2JaUizZdMHsQbu4RoawAYrMaJC1HhVOwq3Jfx8dJ4CoHeOeuEPQmbxLXHK
Z3U8/uHjP4m9Uv9Q3nchLSr6kudqRWFiGSMEg8Oqyrma1YN8OPkn71EsuUQDmSugRGN/aBJP0lEs
1rTN8y0jgMUhHniKbOxv+kF9lUi9v5iWUVhwp2G7wHD/xVJCO4StkGTtz1FaSM9l9D3ckrYhnNGR
Q55aVwZA7T6dTf2H98gClhdzVcG99Ke7H/UUGUlawybCBrJ70lzN7iSquizQNR0uFil7OEhhhZC/
FWQwZIjJPci1t6L/Lg098vlRzIpG+YQEsREniy2iaYxk9Gnhb1OrE4DWBKzvbBPVIxQR07cSPbiP
ubNSA1CrZMn0cyOMxjJ3hHdltQX9WyC5dcptRP0V1XWffdJ7ppKZfCrcsib2wUv9b9R7MfrI5tA/
c48ePA2X5SNmK56IBjoO08rOf2CxRLEBK4FrL9zW10j+pw+VUHBf4CZxdc8B7B26NqjW