<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqKMZ8GnotIhpDSPfujmYX4IJYmNGHhH+VEKkXi56Ixf40Nz64qeUUb5Ynm6y/zh0oxULK8a
U0BNIl/ujeJpKe8Ag6mNZT0TbxDB+10LoTDC3OBVH9qCbkZ3L0TErSK9aHsGb99noPHPz4UPK/0u
9wi9j+9uGG7LWExRvYkf6vZ0UBUl/ZbEBxi7vEiHJp8XWpVyOaX8ZFqVODA15sitSjiYKkL+p5YW
Ovb9rNtbRfSZkM80KSrs8Uxx4pqb2A1TKdtDCIeADpHZv1ITmSJY4lsWpyDtO+nHg41ML7bBxB/c
qfkNRKEy2u6RRxqJaikCEUa3fun2nZIeBUjI3BHeOVlAZTABn/YImNFRg/CCoOoQCW85C1WLB5F7
rMdCjOwQFGIGGg3xBb90ZSHgkrJ/URdCtI+6mLLci2/SpULB9pKRgVxtqydg9Y/R/vcrb0TEGLRQ
u124XnIn7cfRq+jFJPhSCnisAM+AoBDXDMBmZ1ZkggWJGLYq1N6ywa7bgXXF4z9nN/vxLJXkPB3P
g7sXrgVAwTkbDBmUggqhv2VPCxcH+CgOe2vGu1r6wN04OoPOeWVR9PS4U1vDHlYmhYy33KPHhw2M
9LSR+2Aw/wdb7sS3M+1pyEFCDlWDmwaR79JHTX+Y9BWqT8el/+JeFTjYLcHGR6fGaQ2xsQ82Ar1w
/hP/LjKTXVq3O9PKs1US+NgEOb8ApLfulkEavBvkUO104RNYZm4oWWeikySwlFRl/jU210S34nKT
TyN2R+wTHHMwGszAlsxf4CKb9qtmHbQs+6cO3WKMOmbL8Sarq013MVu7BSQ0HASb/f/zMlAaO0RT
6oUrniB2rIOWRnPExU3qx+rIdKji3oVnEoecLeLSxlnrRMH+3kzduQI7BfWMkgPj9U0hhbcCI+pt
2halS9w/WODPg31PQtOcL65142NWRajzxJZQhN0vlM3cvLMEFOJ7iY5jYe6d43IGvUgqpzIZvO9g
WEVMXdaZ5Zkul0Ci/EAWmAEH5Dc7HsvTNqRYeJZeYsHdnmSoKOdhbuN/WhqzCa7HRiFFS3qgiIUu
AqpYM7fZy6Ljo4yu3B11KUss/tcc+uq0NTAsUj/kvgoYXdQoOroAXY5r+hWw0VJoPqpo0Dbwvfxg
cwRto62351hpk0sfPN0PH3vJx9sT8llGI+mIg2sJWax+Tx2u0mH/5ARvNDZ88xHuJJ66xnEs/6zk
+gJ25KpybAFIme10gl+ySUM30uxhiPi7CXW3FKL0dhjKlYbvKMSpB0vouDkOCIN4JNkxAM+C90==