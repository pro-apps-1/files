<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvtavscWUznElIToIZh5atdeGb7GQ+yGxvku1jZ09rhJzLZiTWQKR8lSgO591ncZLe3zSDTH
msk7IIemav+yxR7jPziUjoIoDYEB7dCQrLyDa5ny2zsfvVxOGnrmopTuGaLI6CNfIY9b5rRBt5R3
MBzluurx2iAA0eD28VQcy1T8LWKGEIJl1hFgNqf+rOKJkHVUKCGgdL9wMCDgJZjX2CMbj3bggCYr
vUaGV5rti2Vu6cgq/3S+AriJLD26d77Lh5DIscOEfIpv+5PatZdjxX50avTd4tQUtXvBdZE04wGH
lri1/vVs06GZE56OjMT85VCNkYHMBdJhP7pqdKQ0oemGtfFE8kvF1SKuhuhn957Y622/GN9T7CBS
bklRghrDafjAZfJU6Tc2dn6p74LFKdY2e+EldJUqrc4OH4RypQwreqYQpZr96ps8jrukiXqmj/Gf
tLo+eUCoaaojw6C3aGn7vt4XHP0Vo5SufrA3TZ3y2AKEb+Vs0k3/l9gjhhun/+6qs9YSbwEMM4hC
Edp6lm5RZe0ngRUR3ZZLavv6zDrsURRMH+oQ9okz6paJbEYHL3ehLHluLabVYc2J77d9+G8wMN7F
5UZ/GkGxmFieLHFGYhVnRQOdNcYk7btGkViSYOn4Frf11x7x2gPNg1ctw7BcQe6jyfrjZ9CDZO6y
wOjzEXInb7/acDImIyfoaFMq4HLRsjs5oiVU+VFTbjy3EOSnw6qWAlIQ3XMzCV+OZ2GPkknZmrmz
uvRywCNL4EQD2d9aL4Fpm+fkKzJyhqIWbV4xoAI2f7s2D0YlUJD7eGdzAc2tFf7FrNvQHT/pKdva
Z4k1G1WnX80XFWG1sb4Jx2o5BZdj1pqHLyp1dIq3pG74XfHHAjICw4AoesBteMKJRwCGWeMRP9XU
HFLFXQ0c9n9hOIuLp2EAavbk2YmF5vL62l+B+spwDV+/ymD96Xj0BNG4JGvA4uI38554ZkRKotzc
YkIlNZ9RLG+sICLveyAzrTsBkqlpndkLG3NlXmIrx+qaPVbCyMHtNIggUE7ThMwtIOQugdboE/GT
oUjshf8vjrx3YBspHggucui6ASbgh8eFOTQLhy4XjU76gG7sEtQbw5koQSrUOv+e7W2MMIA9oKof
nKQI8KhBYvzI0QPzIien1q+kADlg87U8PPBUhfNjfueqcKl8Ws5m8CVkTVj/xWi0WNEmiOzzJ/0w
AZ8Herq5vDd+ucr9gcJ3X7OZdO/p7TVucYuC4722aPT8j8MTgLiUkSberG5I4QsJrsjLCsHbAjfL
Oap72cR090VGFKqZV3zCqUIwXwJmFgnGZk8pI6EiC5Tmp3AgCVrw/rqfsQjoPdlMzVes/BR7nUyX
s5f6KNzDDm/fg4f3DEAsil9pI06Xn2Ry/RCPOvXFrtUZqh7v2/3FL/0u2S1CvXxSNAahXVti08c5
GKYUpklUMpJvVlyo59VtRrnEI0stVgn4GKTCzuwPH39lWuK2TsMP6eX1+LXE5KSQhkvWmZsEGRz9
EYEntOuggn/MU2dJjCkROONxGUipWwXWKGP6qVSlJf+fuRw1h+/BjevgmvUZpoQFLSszbE89Mc2a
FuCsTCW/jCIw3SKRxat5LvGaYT4J30hLTgH/P8K17QoyakBY5UWMDYfx2auAhUi82yFcxIO5Zkz3
HUrnpPmppiuIFYIahPMIUnHElGiKIjl6FX4lGH9XpA4wPEVLptZocc28CS0tB9vwIr4W3GPHDpB+
0YBSNOzQL3HlLMGViwxTGt0OEzljp4yJab3krbJ35XAkdsee5CuDVBKRcigwkMaXgV7Sk7K7lGNk
T+/Gboi89BFv1dJ5ClVTPO9h1rZua0frRKb6yx0hBZQJAfsjKm+hzfEpKFMFwFA1Pj1VujYIsS21
bdYONTQ4eo8O3DtuD1LHov0rIOnHA+az+Lhcrl5PfY7tWjv7GLpIsNbt8+XoBKUQBffXl6rKgxmL
fj0JJ4p8EXlMRiZAWn3X1tslrAEQlW4TJwlrt2RwCc60qETQQAqSkGRpLRaN8d0eGRP9pYZLACxY
R27ppt3rydXErqd1vaCl9uUh70f+qt6F0Y+ksz5L43u3b7OiuSQHbWD9n/bJiO9+w4s+ukisMrnD
u/mjR3Vsjp4xhZEgORubgohKxKYyIfUBr1tPoZKOUrT0ih84zuRVE0NdXE50kLt0BU8=