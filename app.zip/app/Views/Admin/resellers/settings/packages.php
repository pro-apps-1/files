<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+VBMJefYw8zD1VC6RnAEOZAkpTNn5QSNVb0Og+GD7ddN2yoSOxRyC7c5ibG+KFjLOQDCvxq
ROQZn/m8Faa86l7BWcPqIc2xDRPw+GS8SP4tSfcehU3imKlVWhDtq8L6NIHwFtHud1BdRKeTzB1f
8rZ2LTL+A5bVJvGCa1aSD/0tM3kcujVxg3aLNFXU5MHYKd/5j6lQGEiRoTGXXOO0R8yqbwjfYg9v
vWqNbVw3dz7F3ZqYLJUKFIWJsVbb19k/1krBbVHX9+XPhbv11mcj6MAwaFi5PiJj0oSxtBDO9eko
WSIN6ZC6gkQC8N7/wb+V2h2AhFvbGj9wWx2N7h8FbOJE3Srmn+nE/KKH1vdVHa/TTckpnHLs7nAQ
GrxB6ay6+GEZBQkq1tqD36/qSW7zw4l2bSfJz4czp0LRXxyEE7DA9OF73/sVpXrcdbESRmUrGWDW
UxD2bbt3ni7GsgbbquP4eApbsGGO8wYQUz1rSUD6poimfWq/bDA9tqH8TWrtAG/53Iw4n1e4P8OA
j0vzPj2ek5vDQSZgnaS/DnMnYUt7038zliRwNwkDDjXj648FpVZu5H7pnPnTFnxDwd/d6snnfMPA
8eB8VmZY8dE32IMABZj06XK5czl6rxYxuCHF2aH8ZLm7+5nSc1J3C01WSdZdQuqAT3AmTTn8GWGk
xbDaEL2xg5BMH6l4huNBZlPNezypTXqMPPEfcr7IqqkqoynS32uV7bavXYZogz03djIsX/U28qq9
O3zWlNtyxT80Vk0EqrO9w2G2v9eDXwc8rn8/Dl7ZGVmVXactGnqNpQTaW6RK/mMXoVFNwE90oGHk
sYck0n2vI4ujCAtYjINgQ477d41nPdkQZVs5jxPpToW5O44rjsy9XbsNaMY8PtYUvxB9ZrdSYsBn
VFOPjUTn/ZEpZYfF3Olor8yTVNwt3QgY28for7ee7zL9op2mMmvbqoP+/28RTV1+LtjKlgFErPGU
mSgZUpyl8PUivGt/HcEuuTcp4T4Hjqo6VLG/T78e9C4rbxLJPaJzD1iodJBPaKcmc8YUDQ41TqAo
UUC5o6/K3ryETyrAOTQ2kyg9Ctz8xta7RkYfgNeX1CuBbqMyG1c8thYKdQ3eJoy9OTkeLOMhWuUY
SFwQ9WqvAUXyosTRNCDWRXPQiZ8FWhjKBsn4WA+dSxBQr8fT7CqvXK5HABGmQe89pJHknE99x67I
5Jx7TpMb2zFejDQyWfj9dUyGhi6MULBekjdJtYYwI7cOnq6w8e8Kv7VFYHWveZIl8Xq4I9XHu0us
u5lsaZVHSIqJSFj81Wmb8dz49xQdqYjJPwU92U3qytrKbKs+Z6lJ2mCPqeMBn1txgImXdWTlufyH
z4Dr4sSkrazXGLo4ZtXaEtoXwGnUoV90S0ckSA4oOAdX4sXUqDeRgGERJuWkZ1MTuvd8PLNXgOk9
U/NpIH623t16sqY3e/FpmMh4aV5qS3PtHgcVeB5VT7H0j0jU4WBh3TFlXugRFSyaVLZz09t90Bn1
Hv5T8ETl4w3YPXYJes4R3dup+S9wkQPBNRvV25x+mjFSVUwpIg5payBjqVgGReHDNrx3VmWY5kMP
BviMUk4vw+VxYz1Kf9sb3Chtn+kyKCQv6Y2BWuuUtTDgN5eqUcSLnjIHxBQfQPBVLqnRFzVdVN/z
aqgl7ZSnyf3hwgHz1UnS2CPoB00NSLVud6CIixRirxoybz0RmzYhP+c7E/qNLAQD6zz9DV+fx5Qu
Y8p/DS5Fy/X4ymgGNhtfFpJduSk65eCMZGwADwyZ85fkhzW+S/sreVX77to0wqciVrfxytHfzlA+
ulZcfewk7UUQ9Zgs4J932zx+dvC2lIVI8sWQ1MJf9TMW9F7e4R46gjhBUiZGrL68n0vsKoYOUS/0
Gzjh8/m7ZVK3hd9SQeW3YNQjzSZTqadQtcPEIChIZ6l6bOdqahH10Q+1EGX0kjSCBl+iQ3Uc1KJl
G7I5hLGfX8Ullsw67Kwk6n7qJBaqxDCkUfwvKKbldE8Poe6dxtlwHKIfDEHbwTfWtcJOxGnue/EE
b5XjpeltdqftMXaVDoYZmxCryB5lIxT8T1tHlftKISuSSRojPhsOwJEG4jiexiGvhirSqoJU+/gi
CapIAp3UtOMFV55ILejymngkpHJ4DXlCgU3f27sBMPYwq0AmxvThTvOTY07OoRLD7RTHO73mSlII
0j7jg1x7RKG=