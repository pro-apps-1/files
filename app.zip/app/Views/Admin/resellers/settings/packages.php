<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmz3Tf88yqgcrP/ZiLSNhg6CiZgjoqQragcuBtYYizMOCfM3e5vzlG1vY01P3aWoZRTZ5mtZ
OEgF7jDK48SZROpi/NOovTXXTvCxvS5pCYVXLgcW0LIZsJ5awF2F1PsKvJMsiK/vK7v/nk9A2ri3
DMjCwIHFqa1Jb5YKrILW7SzokXqiO4ODMUTeNB5xqxz7J1llCb6Sqo/rha1lQjheZSv6nmL3hBnx
c9n3sWp2PhbPsmJtXIUzDEc4rA7/nXlWBPsLyLvyD5SgexbHR420sM8EOjfdFwKj14MaGYgemEs3
opXA/+cwmuzAi7f3z/scgEkjepRVBu9I/BfuxUN4DyvuD2bppV6Q6o5h1J1BHA92nTGwR/K66Thj
WGYEBtJvHh/62e669ldomoDcwM6OTTO2LwHdZ320CMFJyCzbufJE+e0Iy7P6SVAyc3ajnnqUewUl
FkOP6SkMRTsPaIgIXFaqvOxlBNXHfDS1M0pwig1NiKrkOE4ttTr/hnCA9vZDlN3Qch1zBJYIfvcC
SZHN+zCgBxK1u5/4B1WgOlgnNvXsccajLriAVDR58H6HFfjDUgdOVOs/gkr6voyTm6/UXj/zqy7/
hM7mA2YQkRJu3C74xH7Y/l3b2ra7dQymRqnKEMhVkMZ/vACqqF4PKk6l2czWw5ktjcU5GoSOgLDL
vBAs1jNvkqYJX2zkxtPjUGuzS1yfwAJ6ygYKU8FGp827iqmrC8pxRwFW7I+ZH3kk4//J83i3n1pw
QlLDAhf0uakR8Gr9naDhS3FVtJKZ2/OVzY09VGK69rdw0iski0J1KaFNkFppreSWxHjtfIRygGRV
FnnotMS9BeS4OYoFqoEQ798Llag0KZMJNSMUX8Yrue2Gt2uUOqUwfcdQpy3CuwY8aJT8qUR48Jbc
LOzEK/yxwWLmbHjgEf3VBK3KUWpiCDDnwQKWtxzjGK+7s45lPqq6+4Doz8mAZUhk8r/LWKhln6M1
R/TC8bYgErnffAN9fnqEzgmmcfKDnTYX8ko6x1HogvO3LuSTo0Cx8OZm5S3/8V/07HxDTkViy6ij
mlGI3V7g63kEN24X5cG5rsicorxvCgsczLhQ4y+l2yrcKVxFWjbDfWrsrcfc4H3Wakdb+FnJAq6N
bwA/Odou15I24KWe8JcAIq5iVFFION0p5LSwKCHvgA25RSThl59Rx8O/RajuQHdSfPcuStgbBu9o
E9L5oJAJI4gycOw4O5D15tkQsQeuFmAlbkNV9T2wZdCbC8OGlwrFXublU+8A8oIuTF9WO5fSHOsX
rs3UYbMTGpz2MfAmgHTMcZXNScYPCEiIwZbQTDqGgUiiZ/11C/ZmC4Fd0ecGmSE19N00fACt5Haq
dxWLA8OewygZuc0o445brIjlru7df1XaBPg3Hr5QVu6mFtlYg8DOSPnmxSSOeWZBOo0aoNIaJ28l
0ijLGrlMBMR5DXfv0r4jl6YxnJZtjD9I4w0WtQ438U0jl/4icHQlhs6gZze0XPDTTHcwDkN/Xo/3
v9eRTG/zgRd5WSUc203hm8Xseee0o19wzDS8F/n0jT/4LDPEvyRD6lg4mrQVhnyHUDIrdeY6/dL/
qlZeLz+OoOQVUqSZz8ZzkqllovPuCUfwo3GjkyENu29SLar9fqO0aG6wyeJuR8+7IcGP3CACZfEn
uEbbggqCKGAS3P7x7kAqgxopoHsfkD75mHMHeRR19/yo3BMr7iT7IrOgiNuhQtwGurklVFg/jvB9
Dez8Y3PSJsNjl4Sk6RBzYwOdcL4dAPj6Qutz2OY0nqXxVAGQ0mPt6HblR/3uEcPcPLQ2t/kVWled
qc0kWEk9Smp7iCD4sGh+sqACFuH7JcsgCJUWJtgjwkKIUbng5JNFY8FNKER0PHSSCapIzQyBWujb
Jx/sjBRvv6NVADZuXIk/JmW6C9smHrMU//+24rtQ2gD2SlLlcGZLlXpdaGQ2WrLnSpjKtrkoziud
FGNIAZRGVCHeoR4p0IZhSsFq8AU+fuQ1PxiHHfkhrnJoVLXOaSvwJmMPxW7f06KUndnYON2UmU1A
GEE3rvJB0dklUFUFJiTLDNixv4UEI4ox0bHVj9RHQExn0cf/xK0O/wjk2J2uWzfYj2Ngl1BS0T0R
AdxXwXwY/PgitYchYjLm7akWV8FwbAzC2pdX4qWnelG7IH5mTJVJuVzn/lIkC80BN72rgEx6wAa=