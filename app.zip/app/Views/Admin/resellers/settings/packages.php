<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo6uDNBbFev5y6IWKNS012BOHEtqGVwUNRMuc9OVvF/W5RfVv+YFQIhJfG/A7YxgM5NE/gje
qwspiqiGFYca50ROkyqHnaERmUplVPBONMsoEXhUHOb27jvNYmhgUyJ5S6e9Alv1roxTqQx27kal
kwHkfjEyFKF627QJkqTfU8TmbbULSrw9MMkkK79Pmo5e3+lZhjOsQRiLclQtS4eIoxosdreFbMjb
PAH9TY6yv+llh7OB8ZBCUmQTg++PvDVaahDalg30UZr/oXUPysMTD8bFfBbjmlyaUB5mDtjFd8MY
HZS3Ve8OtnJR90LVce/zpwpXOmrcQidkhVGI1khFUwDk0hmC5v1A8qefOal4jo5rHe0RTBLrtaH2
WapFeeWC7HTlinFJmHoSoUu5BWUVjWJD5q2pypu2x9VDMCaEOjMUh1FWV2jRsXWpcKAQRCzIEHHy
wPx3jqq9bmaYbdnmyrU4i8CkD82/P0qPPTrYqSWVKLlbQXhbeezZ0y1+UUUUYSsxzGfpOYBFLxXs
aTaYDMTsTZ35BZ2lWbh7AE1wldYQTXAHH+0Tnsf1yr2yZxyM17Caq7SUNoS/qziIvkiFTe4wphul
0ThCJlyt8IiAXH4q95b9VDYHqHf5nB+E+cB8cG8OgitQH7EEOlPMMTA+qFspz+VSSNskBbqlq0GR
Qi/EpNaKdIjVv0q//TuQWjGEE6KnKI4t3OS7G7ivxaTGzFALbgSkj63EpS9q7xVLDeJcY4mXNCi7
Vkol7vERL0AtDMRpsMNhD1vTejqv6iAWx0ErKt4OwuJHoJOWoHx4RsM41e85IW9NH4/d1BAJNUmA
gw5lcDPwB9Eb4t09eLs5p8Nzw0YpGnvkygyRnkYJcGJ82WzYmzX6f+FBepcrnx/PnnBmJjrRxzWc
BaiqO2uhP1y4rzzo8ZtKn8HZqpeWGoto6jFLD043k6YiNJDNR2TSKBXqLeYxLhlO3jLHwtL9TNb6
jiLFNK57nevfLVzOSw+hSlK2vA/mpNCI/4kG6MOljXJR8+npndvd2nwgLkYsyMORXP7F94ulwQx1
IXOaVQcPM1h0uArkxjHOm+d72rmVEYkU4XmwRU8dIQZNHSb+8KY9fXaVjkF7VGRkJL+azEocTC5a
ZluwgTbK0DeGGRKLUFyiIpQMyhHbzCcSJYuHKB7nsvHzNjRf4wtDZTfZNMMDG4BFmwKhg7jmfiaq
xcG2ektgrRngCeFUNiaX1+rcTbREBfGHt/d2c6sE8+UQ8QZbDIEXfkS6KRYGT6VIxLSe1Zead015
GBbzGHf5xkULTGf5ykPwol6X8zJsjnz75hFy9gyhPM9LshEf4Dn3DHTgbd7HEJHaGJePS8KVgMl5
cYKOkWDv/I54LIEHT4cuQ/zmO06EPwbOHksYdPD8FusHrcYcWrXjGLDcuBW+1ggIpXCMTxdF6cIC
mGE4KIz9SzExkik+UV7mKrcLscN2uj1Yw98riMBlgqVChe0AofvraYlNW20HZisvZLD+Xz/rXfF5
gcUaYBC6hkH6lI3xHDFjnjeN1Z5q266tA+mfadVV0g9KcQGvA2g960cDUt9mXOojyRma/RNWYDCm
ciS7SZxMKGF5YbAJXHCM9WFxa5hpDFtERzS1Rsas+ar4UqjLjh0zo/i8J7sa4SkB05NSWpAIpVYP
cLQTc72FAzsDU6563hzLSHujf6F+GWHFaQ2wYcGQw7odh1VjaI5nGxiKNpsOKXcb6vcTVtlQ2WJ7
NiQewnIZdlXSqJZONwvjWC1g4XiXYdM/7Eb2sR6eBHpcDBg9gs4CxQnIxSK/JPL7QDoaUkpwbPJG
0JJ8MKQNOXuU7bfqJkoQOjpz0yAKHZHrB0D174BLKX7NX/tW8SwEKBabuufqg2etaU+uZ6baj+5C
BkDAoGSpU4mhHdxHGSIeRxKOGsXJCXmcSped3aZgKDSpBh3VN2piRhfgQWWh6K5BVL77tlWScXFb
odyv5WO0+DTPvtEPe4FSUSnr4Bs4MbPcRQA5VsCvvQrMhIFilwO8zprj07tOdawXE1BoOOoYv+45
46heeQanyna2cvcOVXbeCi12KHbK5bBsgLst8ICnYlxO/0uxA5ykQHKD4zdvBi8n2/lT8Tbc+F0x
57vn1+qxrgtikki/bg3GalNtmDaZZG4hVim6WjscRLc8XGUyN31HGbg7OtDepYkK7kpsBrud7nQG
jr0eqNczBB8eEW==