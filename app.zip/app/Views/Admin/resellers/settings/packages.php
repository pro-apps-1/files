<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv60zVQSCSxvMLnWrOsimTGK5VYfHuuB5kXk9piqu2IEuYrM/wTIKcjRb0x08MmAcHws1p29
KlrBxaH+XGcGADnLRGA1NoY9N0u8hRJTUbr+5l+fdSTDRR2IlikUzdlpXRZcR5ci+jBmLIUK9ERG
ymIZMrhBIUi7tOt5+QYTkS457HQQ4O4IeboEIV7Asi6cv3yNuNKtTdYUo4QC+eKdsYb/ikjysnZ/
MLU0WAeHrJ/p/cgm3zfG3nReqknnVQ8bj78D0gIuw5Uteh406+EjATiE/PFeREDdrhwU+cpONvGO
/jSRQrE1JJHT4wyYqEes3im20szKqhLgXmbctePbA2pWJcx1+GUx/Gn/vL6VTfQAkmF7BGmldxAx
rBfOYUkDQ7/UQMv1qv5yymV1tee/8EuYeZQefrXRFej0MQCunGc56acxtT12FrDHEAFVcdXjIT6x
PtzNJIgrN3kKvpFhV48sj9ToKnBK0taeQQrsMF9vQGuCpqKwoBKqDILw8XIlOKiMbnatHdXLGhB9
IeGliQBw0uE1oxPlsEzzcx7oaPQ5k39Yr2bnPM028MPqCrWLocvstiGFLlRlQ0RehJODcteb/YUy
LFVpUZV3pWUlZ83c1JHvuGmqdK9Qs3RSqrnDcP0g1zEC7xIEXeG2Phx89Cu4u8mj8xz00bZTIJ1/
xYMISo3Mn9DmnCP7SCMjprWty6kGecFEXuH3ZWJWhq9KAex0b+ii59NN9sLaXuglO3SlxjKOXtJs
FnSsKDm36Unkavlt6H5pHzBC++WFMCcPabyNsOAG3vY9YzV4BpRJWFgY4NhD9e5Hbaahz6kWc409
bP8m7ccgSGt9Q1VIMi1rijI8568Bnxi9Hclp5/C2f3WjK77cK4SGKsnhUNRfhA4XIN6EcUP5OVIM
hi923qSSxrMV3Yy87l9AICUxxXA3W/GioOQJt/6bfGjenoY2qctkZHYinSv8xgzA/tFKYBcRe/M0
50EKEhAEuT9+0QQvDsvJ6+Z5dgH10klOoZwi4NOwTEkJNXACMsRCHaOsHBTw4VEs1XBN1TFi2btH
EdMGjMbdFP8p+HWiRX8bg2LJbJzIuysvC1yvGOPRevjYG5MhYuuE8L6Ec2TEAiBLR9eTv/cd2kzV
acOfPMIBX33QaodX/8lXb9Q5SOaRCj7yXEZDj2z9P7il4LxK6+Vc4I5fBw42VuD2RD4pq+i75Q/V
GF/Gt8rsD+y0XqXINC4EV158fjrdIFCz6tbeAnIjvSXlykBjPKmuJP+4XllML7s43jfbrP/Ikwgq
6bR1iQfnfOiGgyxLfo5aRIsIoagBQ+A0EQQahI8kRBLYnxaRWrIY/9FMb4A1CchILfxwfwgekkmw
TdyNCeFb7PAvWg/HRxVbPfLCSe0i5fteJrKJTZMFiAJO4FNJpSHILC/9qrBTJ5d2PusAvwGDB+Cq
6oEIptivssaVirQtaL1WuKLzql/mAzJySRVmOH4dLYWYfWCHEgALpw2KHmXJGOOfPeU80ZHBathW
JXlA+E6DClVlR15In5at6fKUiFjSV2h3a3xhfmHM6YNftADnFvO4SM0vNXNajvYcrJr9cMYt9NxP
coj7D8qVEmAfrZDdWEWuER8awSH6ShQYFwDS5ZvSSB9FluOKyBz4AGZYuomuua9hRQhw1jRNXEal
bABg3vLhqqW1i1PnJQx7tWx2c7boA+5Esn3SmwlNsTY2S28dzp8v803P5LJeXZ1uIDEMWHz2GSTO
O0/SD43jylll9KupJZJOLVyU5thRQhU5ylMKILJmcTxIanEfR5v0QIipWqoFh7gYkhg/se/8fcRh
tmRC4aMQmtN+C5Apa0slqNFHJQwtgg1d8omjkkUtcvd+UUEpETW6UxnlxReZ5VvheI58hPsTr3RT
vsOx5VUvBUjEIwwgNnje6aTpM3euIZHqK9Rca2E05o3G5w8sW/VNOxIjEVNkfv3Ly8hXadmqZUju
bgeY3aOE0Q3PQ5MPPeegMevVJ2Dvckr81S3ABSSMZf0a6DHlbLJoP1gMhvd/FXvrXkWMso07Mq1+
Hs6sowrGyB6g3gaMRLydLe7PEWTWb7vNSmCsrWYCBtfHjNy/35t2NemPgYSH/aMEv0P81MfKct75
T5Fr6jEMaWZvee9lqjoVoCrLr/Yye1btjXGDR4MtFvYmI8CV+Rtro+aDWezdgapI/bxRlqEyU8dX
COGA4Ppd+Kwj+YoTirgyZta=