<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu4unGxRbpqXeljGBJ+8T/9lZAoBS9QQB/4Nqh0qNqo2YP0M/Kmh0DkwWZvF0Qiqz4haBkmO
MpV3S62Rd3wNjRfAY3rIQUMF6ZGGkGXWfxnV0LUoDJMJvUNo6Bc1mwa2bfV0G1Uu/es2cPB1I6Rc
WEwdS961QaK4vpNZd3lkYILbVGpLaWzJeoXwEcyGDevUVu0WX8tEXXwzTCcVq/xiNRQdLaQlCC73
gTxvDYwJPa4F+2IuDsWWvx3TCt49YR3QVZUVnIfRTXGh5tW87FW/i0pF3kQEovPcbkJrIx2HV6V5
v/pXarXs/ufHnDTUZb8rov87WB6ma5vLwDLHrUYCt56VnzN1siWB5BNJOvLmmBnMiTcd+Tgil6Ju
MneMQKHZhokTqcSJOY9etLIF4TwSCMlM7sFGiWR2Kjlcx7PNHBmPbEed/bhlZQxonb2GoUw4Eyjo
EgtMdcrDFrakVNrL5dABQ1wCHW/12/0+e/BvcZWKhzc7LzmPe1jjcS77nZ/tjrW7DJvjSlzurBiH
0GiLWOI0ZtPR001GoldYN3kdLYdCIM0CvQEaclvHQIYkEc0wU8UZdqDrzyAQABP5JSqPP+q00qrh
BsBay2GDM2/rHOu6+QxqNRWLRVUdK/oSdngnhF8uOUd1kIMigoGSODLbXR69SOYjKaIcuO6Bdw5q
wDoTCzrf+Kb+Ad5sHlt4jAh1pAixOVzXfoabWpMHiQbaEuxCUTN5jqXDI7LZlKrf1SHRGEBgIL2p
YAXW/SdVkf520wDu6iV5rxLx9xSnG7Zln1G7BZHWM9wMvDNhBXHi0KjmOa+Nu2Mc7d98R9X9do1o
IHaaA88bHSEsQGqNxpKB8dFhNjBxWep0uZ70uiC4Uf/10cFxyuNUCL9vMZUZ8UuXWsFQa0tI3YCd
w6whNY0hLN+H3oDMuNkdgCQ7o8A4KiCRRHlA1kz5JIMsWpfmtdO3GZGJ5KhZK3dajDc8sCKvI4du
iJ1H7OXOv6PaCF/J3kumWe9Gu5efvD5bbIny3x+AiGJ6bCHa15K9DyC5j1eFBdwgELotRiQJ9BdH
DKc78PE26lI7rEg08FXIkea61vV1iJWsidqSjK+hzWkIioiMk3F7C2VbCN/u9MmCeCnKVmjL078E
o0eMLp5YNTz+u0IvhBfBzcFyeNnsJChvRTFZFaYaDwXoisfdSn7YkyQ298Zd3MjHl7QwkokK0wO9
OtPSnP4U7SZ+3cKdMW7WqplKwSNRyWuQEc03x70wUtTZVyGnicaRbTP4iue6lVq89dMGAiq7AY1w
G/BdAbO1KKQ+DSEhUlb8ViJiE01h6NFF1U/MbrgECFVxicy8xwTO/xynKjzo6G7lu22b3ORhV1OR
KXeTGT3/VUjGOK1sLf7mxOVwbxljOTEL559qWwhZWRGuTVZ1wHu2SX1iuy3ANbJuqWCpomeiGAT1
z/HApeSno9NCdn9Pzp5yNKtOp/RcT8Cw4RYNiJGJwJvwphull5A5UqC5Adma+TwiMG/1HHn3o5yx
GvHbEDP9apCmM5BAAdHH6x8ryy09OOuaLfu5zJ6otoAWzUWuQRMQ0M1Ax2JZkGTo9CTKoLOKEcxX
09DNlRajgU/Ls7KV0Vgy8b1j+CqMIGzI+0bzJ5Z9yWT98e1fwK1glDW771FX3/3hxiwNI8SRRonT
UR6/OX5EkGw7Jdkz2VGNWHwZyd4eZg6geFN6rwXN6GivN0SG6Fh/ViVIXho+hVWbsPjBrAEY1+hT
lPIEEApeQWaZvLoR6lftMRpTVprNDogOsz3VmXFSuS8iC/BXrQF7+g00KhT1p8gDmlR/XcnqWQgC
zTyYWU+wESTcnQjTvisYqpW5a4ZzCJffWkj1IYebA+cFVJu6DXoeztodcW6SusouUEOvoj4Y3Ila
6SVl0/Azix8+8klkXA19L7YRF/qmlbnPEr+vUMPAczTgGJ4I0ay/9Ll4jjodruL//zOjZ9Gljjt1
Dzj2eMqh/5fohzn45FpQLZSv0DovB5jEv1Ht4BIPvh3nGY+V+7eK8bOqId9DtgfdsRDN6UGgWBHB
z39Z8IqW937QJqKdUV34MJeIGBfyosQooRDmfmoBkri4GnFsPvuGlmWDwb7oIS8jWzXII6pxL9ko
DR7IwH7n73WBblzbaTwnKyOASJU3OhfczkINF+kgphWJ4L9i9TR4dwqfLCIjYxQgGW==