<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmAShd9RCnD58byxKQ86QfinZMWVnnIxdyqoG1IL9QiAiF5oIeJYGFtZq80uPl63KYZXwZDF
OnnOVRn1hmo2QHyNBTGLRjGTy50+ud68XVW+Z1SZd6iI1Uf/SABtR8cl+LN5E8n7juC+kaDQhq1r
zdhPw6R9yVJXMnSajf3hnXLm2qV15DSkptM1jTzkq/neLBmiZz1nRyj1K4rFK1BcfIBih0O9hOWX
pRSiqCCr6ciTPYlNrNBG9rt419b/9HSOVGpaciPY0ghcZFD7ml34C3RvuA36PHcNY4nvJ+i+CXcG
tCv72/yz+YbiV3QYWrMkEpbRVmIBzCvXI6sui5Smdp7VtR9cbekcpNLfPZWWIT/NNQDVMd40IEFM
KJG4ITJeyJeZwP2R7uFsAc81Z+FcTySYhvnGCEM9+ybZcacpkzMOm2icNheXDSYwKWQcdIu7kgb+
kXWcUHjACO9f9E+21LxwP2iB+zv6/yKz8i1ql80Hf5GDZpQ6eOgZtM72QdPvOm33hZb+rkiVtUfL
wz60unmVYUibOOoVkNvKJAgsS9cs+kW7s03Wb+udyZDp1YpPUbJgGPzpAa0VdImWepEK1KaInKrp
nJDvKpTFzHxLHks5jB2qdX6LXBTNg61xDAsNXKg6eDjCd4b7xQ6SZmDKS6qo3GYeJlTH2ZHx1D3y
7MVkmx7F2eTodaZeE6xT2nl81xVttL4iikZxxHQqlhkbGkVG2zv8xL4B3tS9ECkSjU/AfM1yzeDW
NKLIFanGwJ8BxvWJpyNQZGF39wMrZcPVCo6q2v3eoG+N++oiT8TiWCWYYgOx7wxibvjavphidsw6
JMlZVwwWEeXdKdHKy0NDj8RBr8mwFcBEQsogidEnnxlrPPkcaCOQ+ByVTvchrL8osVinOtB8inUF
t2ylm38FWpYjpxwgHIxSI4uwrAxtILuCsNzGTEiaHLO9WlmLlNsfgnQ0PFi74Zjanh8PrgYAZAgI
A7AhNiGu7Ld/vQIVDGr1gKSuNkC4ViBqvIjXtsA6bWqfnqYiL4CS4lvh1tVeoTRjtuUKCajrYeKi
tnrOoA5rfYVQjrBFFb+XmCbgNhim5cPN4aXDrlcjTIDYMRbMoGK5kTgXX7Qetl9aB4qbsyLVxfbi
6sIetdROOiP9c+b+s992Ryw37gFeB2EEIVQHhObjkVropiuCz+8tKaD6WNYroIVjZ/4cvOE7dRNt
aFSRdNpfkJCQoEJES3PxkCdfIDDEqug7bY1gIEChNcYqKqRR89QJKBlKyfOas4wS9LEJNWwXT93+
wVkzjSxT7FLEIWiP6Fib6fE7v5fH8C56zdnrXFodN5RaxbzjEVyP7aTPCn5v7WD5idMjrLmG/MO7
1+9EjoULtn8Tze3J2a44KS1T9izkO5IgwrbIVL9XdqVbFwjFboxpKdPw5sE17RN6znTcZclHEbe4
IpkRyTpLrZlXEGVtb0yaygFdSEGW6Zq8+S0hNiWLLQA3GGIuKfY3fwL/PNL5rvfFUqvES5A1XQVM
M59tU8lRIhpec0GgG0XhefSgqX0tkIhhJOCbZ8W/eRDaR+XpthOoAjjcX4KKP7PMzQZLDAibDm3w
e97qdIfJMo/Z6y30fMtQk2eqsNwnl+UWCVaiKS1rqWVafcUlROKS0a+jurFpm4FOMT9Ccroc1KAM
isam+JV6KkHo39DUj5qKDKvoyhPZQv9n9YtoIRT0o62hCs1SisezVOMKtYQ8iNZTm7NnL9ltvRL1
ix8q9T/unkjdVZiSUHE64nt4kbuPBktSD0+MWFal0CmFZqsNC/H8FlOzwMCjnGlxQdhNgDi9oqLw
BZV+L4TA9ibcGkC9QfGC5EVXk7LOPx+TWZtk5kXTa4Ywbmv0l/VI0g3B6bcAqCG3Rl2pr4FJX91m
E0CzXRjEgINrRb3/LHrasDqjxx+2BPPoaB7WLacQGpqtG18S9lPGoLeVkYR8ueJ1D+oUt0kUjV+M
RszBmlKDv8FUBf5mMFJmbURBqsIeQfZWYiIM+m19Ga8ha8j5IwGgVR6yWtvomI9I7al0TA5InQ2h
+Ce4OPl8GjmzBRFPoRITi2KEFX3218MFO73ewcqU9eB3w8zLy6E9Vf3H0bO5BJj0SXZnXjR89CAW
2u1cCVH5PN9KkamBej8D17u4ZvJY1deqiUNJDsoop9yfGvMge2JtnUK4fTZOhSo/Bgi=