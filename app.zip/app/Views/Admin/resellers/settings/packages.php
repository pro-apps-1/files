<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtRh+Q28PSANLIXiW//DdPMBQG5VQReaAOgujUGe61kCD2vpTKgkPMGEnoJp8Dde6uJc106Z
f+xdgJW/WIl5Ik1WCAskg7Iz5pf7AiKMp7ip2n9uJO1CWAEffiU5SwnDuWSL6rTZRh2ZR6AwxoNd
26pFn+ib/VsbTRBQo0r0bHIX00TTmvwDzXmrXPo2qupAmTCMwJeEOpsBxXn7iGHanywmQ4G9vqGu
GswZLG5SNq6I+YbfCwN6IBQqw4+Klndf10uvf73U7N0fAkuXIPj47u5uMlXY8hqW3xHWPbTH8l4k
6hmL//5nhiAGvYjk0YghXzxkNiORZJLAZjtCJTUqDBopRqUJ+/4zkTHwWXzS5MGcXUejVCbUB+bB
Cb7N/tcH820p5MLJ0VYvqiA8uOtae10mZNotsmEFRHfm8nDCVTTsTUhisxhCXLI0xRvCHXkMR5I9
xk11MtOMnsGuRO7t/gSD9vwhmqqJ29t3JX5ifbUyUyQkCNHFl5wHoxU/jUALoBbnDS7po/1Olr3Z
SzCWH4T2McwqgEjDde/cVd4vtNiwzfTWGsPDH+TXFgdKR3HaMXzb1+DSZ5UbXZYKLK+duVZNYf6V
M+JnOmF096gJGYkS6CpBeG8YgnRCZFdn/HzpGkQ5pqwDlKGg3Xw9i3EUuZZe9b/dFvD3e7gbJsDQ
vRBgWqYXqs/31zEyYcqpqdq4AD/rAbypo2dKzYJI2TlL9aH1qHSgvKwT0AwJOkvTr6ika/a+dSDz
ggHEpemcylZm40hRM8MEuOuKOMrEk6COJE6vuae4mZZsrKNJ36nyxW+hNjspUqSLAqdcvH8M76ns
ZU9rZd4ISIJz7LZLGUBHe4rKKBBV1gIrSujHirO4/WqnvBaIgAtuAl2boavny+rHbFIEwfEtvm3c
hsdK/779o8hoqNQQ8ZZ8+fNmC1hmFa8JJ+HiSMcKKMRJI7v65pCELYg97wNZlnL0KqbyRFvYqPaT
RNviQKHRQVyEJdNw67yuAKhWiFT7/xHNoduoNJ4jE/vPAxztuuXasBt2ZtuXl4vZeIRFf1UJt8H7
GHH2o3SZhXHEZbwgK/YICWX800jjrnxf1PAkaiFoSRHPl/DKE0CX7Ar5ZRbpW35hI6hGHODNcivX
0D8S/Wcat9JBKeTMIhWHHLAcu/35nCMle7ZxP0TeGNLU7npTVmrgglQyHNfbVEZD/mgEnT2wBclE
3GF/U55sSW9srn7BYq21Rur5gDt3+7orpjP7I1hdpRVy3W3HvzcinjFdcOmEg+X18JkxBq0tf7JC
vWrCs1S8h3wJlqKjuAzeHlbTa/aZcN6EXMSSL5rgo7nRalLx/oU0+HbILMvkDL3DDFAQ00F0RXwi
qn/js0Wtwi8CsD/BYot/WBwMN0d3ApgWWgp/t1FPqFLAofbpk+hjkpj9rwq0Hab9AKd4l0MkzT4P
c8eucvpBgX/+gb3uo0MZ/VYwgBuJhvtDbORdxk1s7C9uTxJ2Qyw2Jmkrj+QR5Cjwz7L1v2GR74g6
b21Vk76o1ziw8Uu1hSL9aIwE1Y2HghoH4YNlPjpeHszmist99JyWYDiApre+9VWJju8tpgTolLm7
8JDqUkhM2feeOcvGzuic8YR6/XG7SdwF9GpB9U5uvRM94d+CLlzrclyqPFodnv2VzeJBqNZWEVVu
PsRBJPH5ZHt/rmM/o7tne6/zb1U0REOQPHyXhcbu5aIGbyIpALO+HJ6qEzFZntZah/lLKzze2gUN
Gi7YTLrJKKsGQD+6iswxqb79/8KHgjDPRk6pwKrJYcP6jdDzYKzx8tajHZuCi1554U4RXkDu73O3
sVUJaceQfFUGiCq/jPiYoMT+q0mD1sTdg9KVGY9WjnFJQyilZCZnBsoy7oxAYQ49+/9Rt2pmq8kA
fM08+E3Lnn0dYOH/LD4S9sw7R1yPKjX0Cuiz+2cUhpQlP3+htTSUNl5NY4+6B7BhtOuA8dRQQfKM
kKkTHDIj/d/TtblfVOdzQteOJG+6Y0zZYfjzs4fGlWvQimUy5tYk3pWjOZFZRDmBm2fYcYOFySN7
JMgEtErgzxR8+Gx77XsPsG9xQfagp0D8dprsivWJm9mK/OQhM/5ffZ7bfCm36v5t2zraamL2mHB9
LvQhUVVqsE3cQnluXCWSbaw1PDRAJ5YkSTnXYdFhcUBTVA0o8s6E8Pc87jsfribLuG==