<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoXaUy7cwb/t/oEuxk92ZsCpINNJnbQUCCY9+i4YSNcuih8NXlewYA4VrCgUt93TSUqsIMQP
0nF9sHXnoHxg4P+OzuwSjOCbf2Hk9O0pszjBG7MTKkny8Wj4GRTo2I3XlEVbPiHSILIKhcZBToEJ
IrPzV5zTw40e22oq7kP+pKhZL0H/nzrGVD9hqrjHUe3p+ioXvd0ZGrtKJ/uofU37yy4x+V+MBgWz
OjFoW/PI/CF8EDAG6i1S+QFBq724MeNn+TifZ/Px4aPphoX2ab64hzVSx7jSSXvzTpkgMMWlujn8
zaabRIldAdlvH5jm/qhMht5EvbWmGkA8s0SEDKYRUhK3A3Sd5qsfemN4EroK4raTZSw8pZ+mNWab
+IsgpinjvsQzQd8DLxCkMYjGTbNl54zm3Owtuc7u4pc7znMPPdAYd/xspzZFQDl25Nc4+R6j8o/Q
C+xaTtbLr5CDH/6xTWdDX7J5zwdMCqSdqwkJkzBNQcRFOKe8pbyo4MuuhBcVEHqWJTG0exzF6+Qj
GPjhuxXHoO0vN+YSKpkcu3JWDIOTkTR5fA6wzgY1Dubs+rQGVu58K6Hf2Ok/DGBXaETrFJHm9x3p
GisVDWuRgFE4XhF+zkApLS+mRvVhT9pRrBrYEypyJlreZf1q1NqC9aGOJ/+cPapV6J34vATUuhmT
6DgubdRVz6OMjV6wm3FYSM/Uss7lkPc9D+UZcdxushFAmSs/nrLGFbANJx3KRwVcYrRrlVbBHpt5
l7UvjWFzxW+Ah+0VXSAzgXCtvOO2/5IAgBt5X4hvlltIJa0QZOhia0hEhWcprnozLNXS3SXVS7ZK
QcKxiKFEhjkp0cQ5mE7ODXFnLqy6M4dpLYubQtXuyP2OEYLsv5SLam3JlCJOpXZQtbyw7XCxtsOn
eTfxMtw0GOosAW+ZQrTRNMt0Ezq8L95grkVIbgQ7kyWQ7D4XpkNCX+Jq7PjEwJvlKBuqaqse295U
QttYPHHzBPHcsgHnt31sSXMsNBKri3lj0yGmW/9lhMSFYiFlCtrgV4mAe2fz9/WH2ZPrdd0HVLo8
BdZYlpbcNPsDcevv+MRKVH/OIS0lKol/Tbj/Edf2uJvhwhO3Apf217zqVs3cHTTmqMdw4/uXvf1O
CExqLKiqoz9OXz7fN2Ar69RgBI2i+9uIcn/2+c2oIXC1jJ4suU/tEYkG1yGRoxi7qoxVS8qjNMls
ADuzjlFSrPeYkuMvnuvJLVzCr2a8mKSENmqAoD2uOGzByeOW8KVWl1cq4Np/d/gDmSkTAjUVGrGZ
mUlJSkJzArFCOccniwb1uOPEQ/jF3cqB9rh0xcb3JpizMn1j2G8IVMQMuAdLGmkWPYN/Q4xwr/bk
VsibMIvkOXWJ+wmqyRojoGzi/YJv5r8qN46t+twhZoLpr99KP4RBKI1lVn22BjHtnaTUGn5kwkCu
XhlkQErsSbeTVWZirnOAyzVqopO1Z9Qniw9moA49hyBWKInwbjI/SR9adN6xFsYKT2IZ+KNb/2jU
kvrMIM1yygRn6WmhgSlKfrZdMgT0PtJ5ZpulKJ7alxT3Y2BVHodNbpv2JQSZyEB9lLFO8JrnQBL7
gYMQJiXXtCKIFI9tHQ5c+/IWiJ7bNk2QD8akQ1HsghHkviiZeZ5mOwlTy3YBxYqxYSY/zCIAe3ww
Gqe0vLmuatRWCR0XlLR3tyeOG35cLlzarfzP2FBjZti8aIPjChieFTw2VnqNbI996Ya2BUdWh28b
i4mCqwCZ49O0ZsRT+CJeQ/MlMl+R0+kiB87X6D5bDeUvBzD1kK8BMTGZmf4q1ioW1J65+OQeTKk4
ro4XSIxP3lsQ/cgXxb396Gto35eq7u0vV6wSgnRNatf6fKFvu+jXzup3OSKKj5H2EjoaQveqhcH+
E/OzYuj0D9i134pzIrglig3McrIGTCLC1dCwR7so18a6gp2rbMK3xut6d4qu+Ocx4NiwoKToHwau
9Xp7ccLChoftYY7rqkI+Oq45lMUR9kWZjz5a68Fj5tHjZKDgrwK9/N4p92bOx/Io95voTkpNmhZz
j32EhUVt251AYPiBCCvbcGWOf5F+4S/mu/8oa+Bytd+sc4mAx1XKL+AkcRccOztXslRf1FOM9bhM
hRHS0STw83wZrblrkM0KKKA4IEHsEOxipIYJRuT/S3e46w6iqHRnoWk7QISzZWNIdjed32yIV4Ag
0yXDO0==