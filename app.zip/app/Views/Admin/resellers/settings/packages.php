<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu6gh5hR9HMTecavUQOoxKyZHvsUzimZtj0DTmKFVMnAdn071snsGAwg1x1yypSdYNnEvisg
370AQVTmoEAnDNCY2Hg8BrAJsaRf3JxJV/7kcR9LyeW54wcC5FUwVuXi9YxQnFAhIIbYCW2CRuVO
VTHW/qxGsuGPoT+iFp+jz3FyEakO2/hMiHtNJFNiLWYu1Ewvz1mDyItkdolkxVwvc0ALn3NIX+Q1
04C5uvtaSBge9tsS+KCuEkGpqqrBe8sQc18XD8Mbi2AXEY+NIVLnj/1LIwfHQQnsOV5BzUn5pGbS
JBDuNqdLAbzDncOvuAgkCfVU3tpCRdejOAVkXclD93UoaqBtYzEk62y9W+GSn4/bU14rIAdY8Trq
dBO8LMhkUkbl4MYQMD+SpYJnsrfzdmWMjRwXhbi+d0rWCWP/8d0POiLZ3Ar998ztpahxM6AeUXKw
5VQkWKyspH0UHw9fEEhIrTvK0kRZszJibWa4pIneYUK63+yz5N2FsXASfN5PW/wM60gkc16kC/xL
Q2gpi1/s19s4DIHPLqVmza00mXjhlBj9ZLn7pn5PRPniJg4hMTW0OzsXOA0tQ6p4do/iY2yDyE2t
47CedOFPUBDsf3sPxAGt/CXEGiCwNeJ8SLkpIRwjgOjF/11L/w7Lmoehex1/M1Gs/MhyUxrm9+wE
F/2oz098HmiWpWbEcBvQ6pZeHW+ltN0BDjEUNnwpWvKE+hcAw0yXEuArZgCeYVkLSgr407Ugwz4D
FHkbZJvQDXTwBDQhuSJoCrq8dnSJ+74ISuM8/nT4GVDqxN2q8ms9uJf2eh5sW+JhweZFhwB8uREP
fP9YIg+nkyHjWprX0kiDjCZcBYkuObdtOvOW+Ngi0m+5KSGQYbXPM5+ka6cXfU7UQEWxfuaIT9+m
x7P0z217W6xAdhxVIR8bD8qxPUBsIkRdcKrI4MWqr2FkHmkVc+beL45X6hW0bniqBvXPBVmxyBar
78+onmSx2mG5t+IiCNw4RalvZdrwLjWmXAoE7tqvRqHEcw5hyBSxnEjUwT7WOt5gKWCrskwbC0nT
I0lTy6kSBLrF8J1/2kMKPlwxfa9EZdWKp6FuwBO2UhUxOBWOFoo/R68k8hW8AAkBhvBlS0HoUSbD
/jKlsqM3rDKqx8led7lp3urIQbqNYTjz8qpZhRW113Lb+MvdEvnzEul+VD3hA61lZmF5IyRGnGna
b28eH4Ygd6MbqkkX3AF17+NtSKjZKLHAs/8L//RWAi9lIc2xyyvvcbA53+Dc1je3jCSfSrncL+rN
sa3cwb/P38TRKIJkVUNM4nONyTkLtv+tEXG40nX/KwFeJ93fmQfQP/yURMrs7U6wP7VZZYU3kMWE
Jkk2XdSGfZ7VfxLEOpyD2nJY5rXuxdHKP2d5jt+Lbv3uzr2zffOUk91SvPHN26XhAH0B5c4sQvPB
akwb1lH7VN467+FklyxP0XybeHyXVf9sWmtQzmD++F6GD0ocSj7ZHyUa2qPw0py0BUxNyQI10Og7
GgBGYoZl0+zTvsu6wpaYh/FvzoYFTRIwrUgYtqvCunhWf2RHVVyhsV3Y7/At2s/N0QgjLKlX19ne
E8h+S5gUb6D3aKVJr1ATZRekCi+yCVzh/wBqKmYoguSnxQl/aobrOdtGaPSiNyH32B7/IHYkT+QA
suUoLRgnuj+4NmfG5HnDMDxIE35D8IysvXZaj2ztHWTIkv1dE+aC0Kzr4aiqz3DFwm6IUKU3oV88
UZYiwKj0Okz9IivBNlus9azqvF+jZXYBo6kHvosUVaiCAcyUuUGz5+fKn9N2uVucsrOLWTaBe6Bg
HulfzzJdXbKt4IybIaDGthV5J2eRLHTAQUoO6xDl7Mxkawyj2TIJdCWM1YvufdMBa+8LJXpxIkIV
oeQPjzXL6VtcvvRF6XMytgso9TjFnVav4s3Tprb8JAbq8ORSzefpkZhghB5sbRpUwgDBgGsJKXd4
Jt0/BZcaknNvt7GI0FdcSMyvNBBYka7c4+rZgaTb9v/yYtVQX196RkVrTrW41GRkqfWA7sb8bdnV
YQygMlz6v0kuLpSb0+xxr7a7fNk++qNhl7FwahLog2H6O/L/yk6ZDI8EXgZLLDSptnvXjQ6G83jK
UmqEnqyIMf53csELmhABAAQ7KJI6fYMO+p2EFhFiu8gBkt12rhKUwEb51zQurBYOoW==