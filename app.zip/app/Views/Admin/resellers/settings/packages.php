<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvHrSmACv4SsIQdc8G+FK93eQ12LuTo6TgsuxX9MPuIukk4ZuRTo4D/0WZkzCTn0jlInHts1
7DdZ43qIon/i93CIv9eiGaGb5J1qjMDhzHmib12WDQ4Ih908PYGJhPZz2wiSRxIWM0XUc57IvUQI
1Trd1Du2sn0qVsyCog4B+vq1cOwPPDvE8hGCS2LvVVzyj0aX/KXLAjUvbfhAsY7BTbKANeLQd4Gs
QD69pZlLXmrNVAheIvLvwLZDG8sjvETjwKOZgTMs0bR9yaI/G9MPSJsk0fnan0HryIryc+aBobu+
c9nf12ngLFs953hXVOYG3WcEA7GH0vqq2FPn5R3L7kFL3TR+Kxd7303NvxMo0z9vuq9iNMriYlIx
LhbnyiC87j+lKVG9LnSjjpU8PvxWBRezed4o0cNOxkcJi13hJLQp4OdAc9+er8eFj12jaeM7eBjb
TesprUYo5oqntpZkSg7VoHsSC1+sTDMcS6surorE5VvNQiGj+UrhAMNG0Bup5DLMv6WHCk/d7Pgr
065lIEkJzzc+Eiktx/AnlpiCxLevk/mjqc6K74OBvsle+awUoA2g6DX72i1TSqpEenA4XzUjuvB+
KIxiyEF9s2XWchGY6DcDQkDQCMAvQD/BHfYYcrveZ4MEy/jIanh/L4AutTuzHkjKStbFz9K0pp5n
sd0FYxKL9siTunMoP71qG4h8ZJW8vOabaxvDeF8uUszL87LJ7S99kcmr2CMOT5i0KocVU+NCxI8J
EuThSKWaEJrm+2euXpwO//8q+g7QWxnzVQ7rDuq5IgxRLeGWFJuAHXcSNu4bfS4rWJEi6a/gV9l0
IgnY1qegIsZKbXl658yzBzA8tmDNPCn6K60DcG/9ZSU4HYCFR7tqsAhdgBx9deLVsgHI/O/E6Rhs
7rDwpa91nbewIw2PsEFaHwL2cTqhpkdpEzLHCd124Kb/Inx1RWS5lRgfOSnq3/0PDPaeKxPDXPHO
Awd4Sb1sRnQQE4Fo9lZEI5l//mfyYrd1C9Hkh42DArjOCTyvhqtzkyfwc3jEfadQXISb2K810S+R
WsaMjwJqWxw45s0C/9AU7taqflUFc3vTDiZmB6LFey1hCPgIOoHA1SpRdEu5sDoH0neoaaR8IzHr
sMvVwBA36lX7XAftrbtsNr7FM6Psh9qUQeG/rQ9dEoiTswtY5R5yAYQGQBX1uKnISkuwP/+xUYUC
dvjgqzKgbZ9m+AftzGrCfhOfLe0JQ7XF8PutT4poUnsZSqJNlOtCjJg5QGzCVBYDxJqll14fOIXc
WMWX3h5aNpYOfeyXQerT/8+9hrOSD4rpfPrl02g9X9pevNdqRP69xGglhPnKFYkq+GMpjl7qjXor
GKngWoA5TpXs0kO7AAr3C32L/369BD1YgIhg1Bb9fYhPcR68CqY1av4w5+0S868jMedkb7nEm72/
rwxdJlcFVSgehvUWv912nJwUImUw748KY5f35m5Euff6U9P3MJCzqlrw0+pHzI/AqMp/1nCrnvmS
Y+k1k9YlZ9G4bhwWwYPTogPxuI2g01nm/MxcOMd2G1U1Q/Go0P4UTVTz8hhgSSzEK2cogh4SLHrI
hVogLLKPhUhhBPARD49KLbbo9uyWxjKvocMnHftoto0ziQ7uikGNStsDSbuwS3Vl2Wv6GN0lmlAT
1XtXjGbefRUh0hfBbDWbur5dkJh/+Gwm61PRV8VxXWlqm+YBjI4R74aPa89k4J0ZY6Ga2XyIqQmr
vxNr6+K++keh6R1x5RwdK1KzVyqN9jxubVhXdupgD/xhedXP35RPNN2zwOmuTjIWh+G6GvVUiKMn
QV9LBga3tni/WJFCT+E10hhT+f8catNTrteCz1wa+9KWGJgDkF7oZtQkhw+mfLiXNGvqHWSzDft6
198M4THHqkNZ1knNMi94l+QMRDdlbiVtuzyRNQ/EpeH72AKQluaNGv5In8ZR7j38o22MwzkFiLIV
B+4LIZyF9K66LDEdd4pcfUAyYP/YLGkJdMwVAMuJMANuXBcd7B+UZ6puwYZzC4lQL7ATJ3SkOrxZ
Bws8IYepGwvyOSf0eFrt8qMQQZQglPiLlv8+JhCtRwkJMRPbeIvxuxjSiPowQcV0I6exDWsCjqle
iA+TVxjBSSWZT1NKdqvudhExXr2UApeQOSjhucvgN0tCcivBKARfYqGJDQUQvzgEX0cgLRcqXG==