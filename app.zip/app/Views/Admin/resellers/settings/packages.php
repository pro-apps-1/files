<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuMf24I6AF5hNtMTPv755kiaNP+CU0TTsj+3iSSBkCumfgw8bd68ZQjdbmEtQx7hL5TIaDGU
7pc256s/VV8jCpYVii0mft3bMT5cMZ73NAevht1Nzp+YQvLJ+LfXCLGRT45xDmHYv8+S2wW/1RSo
N7YCeg5wEEnL8Ldzr8nBgMUGYEFDX33gVK2yP7WPaHJhGI4tUqeaEimNo3MyzFsPDCkvQSrnll3N
FWw8jcmOM4pkk+FpD3SNlS+wX+wJn3fuq2VwykbziC4aQ0LNW/MnLNDSvRN0QT63C+IVg7A4fB47
+ftdCF+GkFqOxrtFvuNeXVcmJakBl85uNriWmkNEdVYXiyiWYLxg1hRDkvkHiPDPlZC7S8K84zqi
AqOS3aGSxZNy/CcMDJYneQX1zC+n2sofbzCB2wg0mjadqpXc8L/8NPyktvnXlnwkdL0ERoVVtHJn
sPepDNZY8FxWe3PlDb8jUwqYzeFoaOgHxCm3/eui3qWYNLu97qeSHxy1oWk6kdF0BYVeWoW7BWMg
ATXcHADd4uDZ4TYllJ1QHXySVg6gHE0TRbqj7WoNGNydwFdctHOjiOn+CnTd3pQjOzoK88omDiV+
fWiKwa7uYuOHJgvUeR5Lj8Rj3xpXzcLZEnFB81neY0zd/Z4XqKGOQQPEhSr0nx2amdg4q3uVfqyw
o646mdXDwlQXTiqx3XsYm1YinpdOAbNH0Ybx6ZVr4QtAufL4QoM8UeAeu1OPwTKZGS/3i38EMaQL
VrjlL1DV3t6f/mTEsxWZp6iEN7hAVjwImvDfNRY8ABCJ8eMM+y7X8Ua8GN8KBMY2m5bUFbNscblc
as/gTD09QBywIo8JMOTFqiSsT+p1jbnkx43p5NV41Fz5inbr+BVI+DVLygQl/Zsxb3FLpTKgebw9
vIdort2OpThceF79h3wJTl077UmW6bp7x9GFF+0YQxljV5Rffj/+7b+Nagt/vzFw6WaktupbREza
hYKsXsHAITneHP2nkqacqS5wV2Z1k3HlHX5ZoYs2awWXw7wCibK+zoG2RFKw8lc9g6wPqXgilgDV
YjyWiYqb0ovT9x5+LrRxdBvsvOUSwAcA6neqPAUPJdjCZK1ZCP4SWQj+70gneIF86tP617uaWak1
P1k0WkXwcwSGSw+ZaZlwOr66RwemuPgS4nxH3T7u33gVQelsaXcxDDfWpAtPGPhdAkbIkTfE7PYJ
9HrXoLmXfVUk3RNUWkvKTJ/el3sWErWxluyCu5vA1Wo0DNhoRZ0i/rzq3F7BusAXfRbVe0jZBLa5
DhCt6DQSiEwQzRVh3ULyH7tf9hlB/bGvL67n2GAIVUSQnlAvSqLGxOMXFMt/iWTllyY2LQgReYTx
8AhHzxeBx62ZcHFTiGHBT2i1LfZPv0ChbYh9nT5HRRs4ZMb567k9Azq1FjJbVGH56F8H1sCZMc0N
l9kG9/0JuZEF0LZF3+tYmoZFLhk9vKLWas9dxwNDGLDUQa7rBCU5Hhx0Kl7XOvMXj9/jJw4rOFbu
/WyJTUuPUegexQy6lkhtzWLu265cQW/rHjUS1E9vjpCh5fNChwH3WmIf+QgzyUQ3kZOS4r4baruC
YccXBrNH1U7R//3ynqo5ASeQRdYnboGP1QGlh0iKVJTMP4uHjYyaJOUu1oRFK8ds8S/pufny3qc3
gKakhWmgT8cyiYzIGgaKQdS4TDnB2cgXQ5fWqlyvfUx41XTL1smj7V/GBZCc8EHvLs82Y9RM6kmn
iST+wqrGPJQ5Aj3qeWmTPKOfmwPRf8VPZpUlpO+QgFOm/u5HzqwM/NAn+kiSkIOfAOiV9K0Njuaa
hvcXGs3MEuWVNb+i0vT6ONrMYP5hDug8JeTpehjQBOk2znVVV1TsJfRiPNWqulP5KE+zAVXawgWR
SWCUroSGazf1pKLT0o9qzgPeROMMSDhF6HOXvCh/t4PnpqSepX5zuUp4rF3Mppczka9LNfq38fFZ
bnJrmNjvryGXCX35El51tiNNAPjAiITPlIMBAHqRLyzJVIgMQbmlJRz86Lf1ZtfwT4JS52n8HoHI
6E96ayOTzjrhEAKKfJ9b2Pb9lWUgxhyw45XlwE54cu1KhMhqncYcx+bUSWcneM+lJiLXu5xMlPYf
3EQvyTuxn6CiHoDpB3HlrCpmnQEyJR5Hj3Li04GvvuIld27ktmmvjkD7s5xGTIr1Xbmnlp6qjta=