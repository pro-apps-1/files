<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+he1kzPRll093IJpFxh9KBl0yE6QBzLxu6uoRmUoqfQpB46IqRbt+caMZ+8G9Vyq48ku9Vw
zOCBf+RcNhvaCgBi1fdDT3J3SWMGiGRmfOcnFqe3Qi6xpcoeCRHvJ5v5lIM/FuywUeJmILJVuQRS
9dirYJMNAprtHFz7SN9uT8vgttzWyTsIseT73UbIlSei5Q+dUxllkbKCakMk3MaEC6yXAxIDuQL5
NMoJQ1Y9xuxZuO2Ll33SA9zGBiewyJtsTFw5yh6F55dCubCN2OI5/+0cyXjlsNZB6njDHmlwvqNt
ZNjx9Xrc5YYqUdygG4T/eMNf7erD+krsjtYhi6bye5CrhPS5+LkLWlDVcoSBsEfF/g6Z9FTNQOue
qyY0Fgk+vKUra/bmTmoOKYs8dVrAgABmJ0TXLoNg4K/0Hdb9y7t4oA+utbmcuyG+Snxo6byxfiKT
Cv1fYjveuHb23KbqiGpOIsnwHcLh7PaJCcvsOHqNBnVj+WlQDaBmnbhADJvrFMkcWc/2U1zbVLEd
Ma20u5larg2JARmUsUA00Yi+Og+ZE5BMZ+O/4oGwhzhScux+eFJN+riT3PqLjf744MDT0dFFOV1C
dM9rX3fVwFdMse5TXPQ8vWUTwD1ngRG6GSUqC7qK0QqtuJ1ibMCErpl28KOU0iNc0foZDd+w7onF
mIdruWzU4UgUvcmvmH/+fzw8KoAsgTXi/SjAy9uURN0YNjx1bt9wU9XCray6wb9h113ZLaO6LfM4
5XCqSnnFl24hWzlvFQ8C4QDG8KTtY2mJLTe9N/EBaCWjPYkg5XVJ3drYRPsj5crzVWkwmHIMMPal
+7Px8EkMW/rtcWJsQArWVtEYt0DD0Wsg7q31vOyF2UVI3WN/gUCIt2NZWbxdnry6LWlIBv9LUguE
qYEkGNkEkHB9SK/zoA9aZdujEdsv0eqkNIiQX3YN3J0ByVnpyiRtQ0ZEuSXiPTH3XblvX+hb+sSz
vB5DGARfhDrPaWiFUoENCYO+C5mx7ujBgKwGQ9f35RG17PnJH+JImmafBO4i98YBEvlfPWI7C8JQ
XcyaoUr5cAhLSR8b4NcHlQrniim85pqRKchSyM2sIvWNn2sKinVRQMi5XJidS0FOX1EjLLkRSN0p
b/3XiAvv98NoUtfVpgthR5lCgCMhBPswCZqs5zxXaTW4d5T8fgOrrO3f1D1V2xuVrXhSH3aDmwf8
VmVBMg6yEztgIZQTb3RoORrFkac5NcSOCV1RzJS4Pzju/LtQpmMZ5YD1R12HjbgRx9DCTA5IvVgk
7oNVvW4qQEGWkXOtJkMjBRCrbgFQmk4xc98g278f4pgmmOJ4ImoEB/9geeA5OXfasbvgLHWiqGNV
WVsjYeZXekw5SN+QSDEenPCEHxWUlDUeBEF3zXmwPtkrMlWkM3L6cqwtLFb8+SFLSGgQvY8Mx8sh
QYd+1jylHrRmu/G3gVfXjcil2rV5OVgA3Icft+pmnlYt9kwUw0JQj7hNeYZjo/ViNMllJ1Ki0JcI
mUcjet6QnGXtBbTn6/j3+dFLP4it6Oee39SbQOv9HY90267KOuOGaadK/CyavQoimNxR5/urHeO0
v1O06NY0wLCYA7Zqdx5pt6tl5F6xJWCZ8J//IJDLatGDReixYMdxlXYXkjTKDrjEaFDVZP+4DlBx
GrrjD60j4dxzFImLJ9s1VIhXHULfR+rBW7F/UccJOTu2VS6S+DFF5Q7YdXURcz9nyFL3jCUCis6n
t/Em26tGckfTMy2HI7V+O5kZJO2O9eLGm+6kUbgD0Ve4Bh+07j11xjXL1cSHbNAI/4icYaChqEQ0
HhGhDgCVHVUpb7HL10NOVLplJbl2ahQYH3fcgDLVbD1p4k4Bo4NOx4X9jpbtOhqkUly18ay4Cl+o
0wXb8S1IKGTjKQU/T483G7qHlg7t/FV55oAt2yuGQeM8qiO5+hZYsEp6Hf/cJjAn41Y1vGwT59NJ
bFu6QDWxMzzEI3hdwaB7eF5wmTOmDJdiLAcyBjbJygLF16uqJTeiRv10+kbGtGs2iEyLvsEdIM8r
Yv04TcYaQkv2j01++Owyfl5RLUPhvKl3yHijYL9niG69wms2l3b6gY2ExR0goJeqxX8QIoDSUsix
gsHHvRO3B+PLFUAqyrAZJodoya/17efX5JPMLFW/AyE9hD4kMJ4jNud9THE89CyttTrux4NeJ9Ov
QgAASFCnhkcuV7q=