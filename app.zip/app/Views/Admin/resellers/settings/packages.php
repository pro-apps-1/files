<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqfDP2zi05q1QOxn335mtYYpfKx97DuuB+8RwTHHMv1iFjK21XzS7FXJrGZulbZ9jkyOrtS5
j9pIq3wR1Nvp/Wwl60qjWgloLWCIH9x30qL40Lb7IYwGIu1plQpA7UTAyUyGaa5W1Nr3ICYYBq5L
b036ROOi+LPDg9Oit9lMgGUvU3aDHDTmG/UchaoNFG96rcnMYYraYoGdGxZc09XpI/gFs29sBh5f
D53/OLDOz5OlNemlEtusW9qAMeNSGHYa0GRJgYmXTnaoo+6tnR6d3X3ZHWEaNAXvsnu2ObHlFjgk
QRGx1Vz/LFiAjNhwmv/VrvGxL9/g8ApZjqq+DL9a5mkxdgdDIroVb5Xrq+oj9Uk8NS7IrAXMLOL5
v/q99AWKfQttlktOlBeJVfwOwJ+n4iB6B1MfvvscHB6dA4rqzxivJJ+x+VTrK+nW9lgzuaIVtmw1
YYaHTvtU0ZBOpnas0Gp2wCaqD+CMAqJIZ87Ac6+1vHu2cftavCrXxI7Xok/7N5CslrsGHdU2+3Ww
fjykFeJMKilsrnP6CvA9I21UVn1Rq6DjBeWQFcQOLvbXz4rgfc023QDzOksb/kx8ilqdQyc+KCVP
O0y4kXltLmiT4OpoNjEqaIARIP+E/QN8wSD7cnQEPtL2/z9owuUYa41/kMuMqH49QO27rfJGhTQk
PiY6/joNL63cAT9qqIbhvlSBk+ZG0CjAL+xitCve/9RH2z5Ze+L9zU9MW4u7GHAjZh9oP6PJVmyE
hqVZFlWzMraaGxa5aX/izOhmN6Zo0vgBKN9tTHPQOww+DY+88F6XV5XSDjTW6M2OszGX8k9wZv5D
kUx6HI3nYEIdOnq/PdSxKhtjf0j3aLzpQWg3+FHrrEymkuhnY7QBkj/YCtaKc3CcXPWLLHHVq8pR
aDNDd741/+AbRCUeGtbzGCbIy9pFsmTtR3RLHhIl6mJzcf+dPelt1gahrbIt4aTKwqwG3dBXixPX
cCNoILDnJ1pw3q3kdDf6g5A87OWJaQMkUMy1SCiWpC+BodwgtmOMKCLtcPAUrLDPy5PlKJlPoIdQ
sCfa8pwLW9wVXo+AM5seCwRfYI7EC6UL4mRlJePRMVf5aVqhqBFG9JCU23YEPxm6M0M63UvCz1n+
A6x115QJxosD6LXwfjDGu3CPfS6qJFoKRxU2bAlFJH++42DI4V2A1ec/XsLR/tSn9IyJTo17IU4B
4OD9jLzy+/7PHMd5j4fwimAEFQ+U6GYV1E33ZCrP4bStZJb11KHUs55f5njxObsqiwna69jDXZDs
i0VSveOt9n9INEll9Q5ipc0s/q1GNhIi9490z0CV71eSxl7qHG5PXNL6/IANYoKw+IJJpmVKoPuR
zX5IHrk2MNnRAkPz/uiULs1Fc91ZYM9Vrr0ctGk775jZP47hFRxTQZP8/adtpKdt2/l3mmEueC6g
dZ7IeXGN71sX7fOQcHDvrGVvUklacsVK/wFK5u9BHXNqJNsKaob9UvP3tmeUqL4sX2HLY4AzVafs
KRiiBygsy1Av1xJ12nJY/YJtGL/EGYJ4+jDKxa4JTWonU5CD8mhrJfbe53lM+Z7hWJc+WaM6E+/0
2gzqi7o6daxUtgeNwBOWXNYEhqn0tOQC4a1oGZk8DtElIhW5TETUOY3+Bg3hfmszkY2HnzsP+3TR
RwQwlpIE31uwBTfy/qV6EAAaDQb5Fq/aA1QSywUTd+Qe0p+EjnY3149o3WMwbm/vwb0BBPBJx46Y
x6eq825lmxdMP/GHVIXoRmoE2xrEjNVMIAZKvLn1jmN3OaOR/6xtfjtFaEluWWsasDwGChTOAEGn
VNJsslfSOxodnDXbaQogBNsxOUBuuFINoq5Ht3qkXp2rQZD/WJyx8cQ6oTS/vt/t2wllAUUgiuaB
ArcoEOgVh8oscOBAqrqA5XnCEdvfnkleOJ3k4aMZEDC3Y8ImuwKbgfPzbc9FJdyCQnbclcjCE7Rv
n9mjUSUo4ES39jppW+NS+fb8OH83eIh/0tHw7R5RMg/Tli6TBB8HNt5qrUoIWRjWif/bxPnAXFF8
2hULR8d6pPyn26cvOqcCvhgtTPAyWfZRp5++HITUWKhpfHnc7brvSwGojScIoaqPn04byU1y1Erf
BDKtTLLz+xJEXuN6ERLvUFV4QIy68oasNtoN+vFWN2nYVEedGItVLDaaOBYrcBympm==