<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmwJb+8SGspLsKy2mHdlze8/YevgR/19mvgumaXIiAceth4+2vJN0Y/0V4NUrcD1phmt5lUe
nky9BtThcL4svg5C07zVAYTvYwVI5xS7dznVy+8oEdCgcp1IkjKaGLSK/3CIJLxjdauXAcheXO+X
gmMi8Woz252oJgZiiE7/lfCtUT/PyS4Hib/hN1ACVY+bB4GYHIPMeEekcwMec+1Sf+pFEtS0RGU3
n20pgs/DE8nBNR2CWUdwKozjvvJShJZuRPtk4No6JafnWqg7SusbEtg0545dLyqK6+hl0isXe7NV
h+Ss/rmgQQjZ/Z5DWusJcmqmNDC4dJYHlkSp5UpXewyFJWAWOlCrN/vZjSxmL4E6ijMj3r3pcnLf
+ABqcEJpUAGKySuEW0BSxM6QioQ21bqDOG1jy4szTnJDq5vlJ6xGCw3FQVhhp1y271eh3qXIOdMx
6uLkVwqOurWjsX8K7kFNdxbukLEZ4wfVdwjEoxPKXaprOYd/HmuipgkzNZtpsIKzHRbdOMcKQm71
EVbbu5GWDKsAp/yYbf2GUwCgDJiqfOVTOYyGAPoYfCwc9L+pPbQZMePPS0E7ESt05svEy8kTq7S0
f3utx6PpRqBx6CrsUW46kH1jrbDF5I6ScFgHw5qLZYwfLWdjaTtI0+RN3PJ3WDARUaK8i01B2wKn
xdAXfI2zZ/0jLkPegL0VKQRLLcrPYojql4jN6HuNYZQLTMI3dJs5ObiUSOw7SWXWXShMLONJcgPR
6gX5JwlG8hW/kfmXc+1MUvxyufU2/GNPx2iD0QwGZGFpuli55FvQcL+X8g5n8s8XKVa3ijI63ZG9
TScTiitLvJBtDnhIuJ/x9oZo76ejuYYMg85DAeB4eeuUMK4sfIvZVRp1k6yInLr/GALhzJL+2igt
RX6iAHCIwbSujUwKf9FkMjVqqyin7JytDpOM4Je0dWzHYn3uUgHVQyfLRPbcInDhiBEicwmFGJEB
/E5t9Lph5AJv2HZRqLcP/jKF92MAYdFRH9KCEC3VDDR0WIE9waYd1v7fPa3NW2ntU9XFOm59Y9FZ
dn25tKu6VYPd1Gc10aL+E5ug+9lg4Xomg0lrHVV8V0kzQnOIgrz+kJ9bjl5KaLDvRhH2lnR5avRU
Cq1qxIq7OC7KMdWWIdiWiGzfXxB1uursTv3HXG26aI2nXphGrG9SKEj3AybmjSlQIvoZ15WtvY8k
+5rWL8CfpteJiTHpv70aFH7NPlPrc8204U26sGddK/vJOOk8DrK+eItVzhEeSIlQDHzc//uiHAJ+
B4h3NSKxUBHb7IGlxRVVFp0BZiyZ8Qe64K86LrDXW28IuxiKyMGDXf+CH8W8//FoVZG7g8X/VOXD
uYsGto/caHTS9Z5MiXcBXCnlHR70zc0baBL60mEJcGiv78UzvLem5pZu2BeNso6NfmsokE3B6S/d
3pSUkgIuMZIq59vdhzAMhn65mjhgLIryEsXhLfgEjQ0io4nY4vyIb/GzX3bjlRJiu9fWRsOiPhts
bGf2vT7Gavkld45L2X7E81fm5/9Uxkj7T2wAuA12KkGbS9R2Ub57W2KIrFo9sZeuWdwv8vhjbYEr
z/FN99V+z1cLqH+VkCxcECdvvgowYFSsRKKJ/PCjf8jtsoOPXwvZ1g7IJrIDiezVRJcOvH7Xq33j
J/aSNHoYJ9H+dThJaYQW6HN/Nbb5aodtZtShdRetSJ+0s2XplCwiIPbU7yjWfcbhPYoqJyFiv0Sn
/mGJbwCFtUvkki3PtkEWLP19RlUPkjK/PX54VkNDiHDWc8/3y9z1exsGCd+JN74NizZGWfGQYtvI
qe5B2U2c68aVkMFMPBIHrAyjiqz46fvLhB1o2fBKQn5sMBHlxER/qUgi3o4ivf0ldJ6h19nZ9ImM
b+2+bNSi9ZbZXRnySzQV8gZcqKgsr1GijySig0QV/1y83BC6W2qSUoU9BblVQl4VE+5lfO11y4x9
/0SO0qD70AU48bf10d9ZhEtfJI5z91f23sd3IuQjgz1rx06DvAdJRwUtJ5q7HKj6ZyR/btTINg21
3KKvpjmqB+gDCyz/aFySJHiZXxhF63F3Cqd4nmqoKBmYjM65Mv53Zm9s3YFRgQl33ag24Rxqn1SX
quhJ95KsW0U5/3uBdxZyhR7xviT0GOMU0tKT/JIcSlQJRCFO80Fq0XPy8Cr2PRjcja+nRYBiOKUZ
GgghhG==