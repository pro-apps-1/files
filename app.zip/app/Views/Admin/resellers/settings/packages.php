<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo+U2kdbN8/Ey4AVofvteAQAGdvpdg1s+g2uX+S69Eq05yFUefprLto7SXNRsscw6eQVE3wM
kI3pVOdHUj86l7Q2ysYX4SlDfj/XUam5XnbEe6vQGsigwM/GI3b6aBCpsJr4FwkeDU6wf8yGotDT
AEHveMd1eyK65xJtPS5F8jRsmc0B6+0Z5YgK5sDTlMs2Hb+eb6JA0a6zeQogiJOIOz0bRb+B4XAp
l8rjAf7bXCHnPMRNMPaLPJQxgr6VVagVHchgq6Wd/76Lpb7MaO8rknKwRnLftPz/rNru+iJXrz1Q
WpeR/nVl3LEqzIXAErFUKkpLHbkcHekQU0fjQozGsewBHAnMCyC3d11P6oXLoxjzpvDVdTNc4CX/
sjpyPr206HaQdmZY4OMMOlYQyoSg3pKX1mx77bDoEXRpAJ8lshRB1dElq7Oue4uFHJus10Brt+aC
eetWpc4F6TWD/b/UtLU4zqp9B7wCQSGdxyEzH86DiQ0mGIXr66dQnShkB9Bnaw+e86ggjqQyPRy0
D12eAVuwLXHYYx3qxhuacXyjOhYrmKfM48HgKrsGMbH0xf06hNhaKffD1DLSK5t6NUL21YU2SABy
D6YQaU4PWsvffGUBiQPPEiO8m/vj7f3qNqe4eVfSA4h/xUhcJUumQ9N92bXG5FioMTN9BORzTaSW
SdIdA6y0+5RQbfB5j1UHCFQeFM+Mwqn5sNYZGAPI4OmGkyG+nYZoXt58lDhpLL4U+rsdBAfDqP27
Zw4l45b61oqmtI7XxlNAvI6FpkqDu5mAKlDvEoyGhCcBjFaWflqeEb5qI8Fhw9ZmiGAPImBW69Ap
/tE++ATmlnOiObJOrnAQGNzBYBseysroTSF1xKsIwTRCWMTHCk7pSi4ssqaslyp7oDSRZZtyBF/g
QLKlcDOWd8cXEjOBgcv1NNu3Dcse2bHfLd3H4qbMnROiXNMa3FKA61R99iV+va22ql8gE/ywvsXu
+F/Q1nYWSvvc9lr05hZlck8Ax0lrRcKzu66xQV67EXJcPCo5T8+/S8TN0tllrYqTB7/MrkepfN75
UOU90JuPaDZA5n0PjMZJn0uC1GRy35ByBRDze0T/RWueuEtYd+E1Zwxv4zkfP1D8Z2XLwghqU/h2
fFDVZn4lJ9VKe5NOW8nqqJqBsReIDs1sMa0Uadp+2hqd1X914mVnX1HfhewcgT5Wu+QSoqFQeLvd
NkCMX0zkLqBOe8RkQAgKbrqNVWEjEZtpjIR3qO3OzYWKTsWwvT9OR1DadqOFur+ujsutjIU1da85
mSqS2uBX54kWi6LXx2+sx/3lMa4D/v1C7de2k4bGRI5yGLiPIgOnQylXUh0729gkNFiqoa+vd/IJ
PcCT6lyr+bsPfbzs/H6HMkpxps9QLxniOfR8UIrW0Q+RqXjKNHB2PDwveanCzCsRNW6LzMV5cVDP
j45LUEq5GkALWZjmkkGThfFzi6gqQ6DHcdfgOVKPH7s35AfHJaexM+4flS77lS/LtBTgj6YOLwU4
+9AgnupuFSmh63Ek0ODQdBAkZTGbvatt80ZeYjoeJULB3+Ut71kOJNtEi39U0+dBq7mRTYjOhuEV
n/YNJiagwbQh/sedmdzVG+h9qM5u8/0BEO2Jlu51OcdrzuNSeXUiD8CXskCrAGjiIgkjdJWv/gAX
94XR+dtsDh+3FJ0wb4iZwWGviiQ95424LvlUgfiwAUb7kQC3XIB5BRvHk5nnhcgKkpKZxUhoxNWc
MsaR++T/JgFNS5PkWv3y0CIlDmmZp2wZNlvpe0B8UMVMkRWMczP0EyFZWyrEELrYsmpAsza0ccQ+
5dxMVLp7DGxeJlOvoVumJB6Qu8IAeFlA5foULIcUuOeMgcC3WOJXDH175jDu7GbSSHQnFlFpQmQX
9kzzTf5pBDfvze9M+Rcb4ZUrQ7XsU9fWVlOKC4cn1wnIjRCIsYh/e6MYcP2IGhUGUUSQ+343xUfJ
T6zgsw+o1zQxIVMKXmo6a5w0O40LIFIXmyfO+wIdfFq2DrJn4ImYpaqqPsR+1Hx6SbEpRKJYqIdt
+liFpDYAPlshTBIWiyQr41DIW0mIviPCip9h5fkr1nQBve9giq2OTUJAF+0l1ZHAbTpBWo3ccuBw
1sIgGkNyzSUa+qzDtwy6p2ejCKyxVqAN7ynqklBdJhc7Rd0Cqt06AdZNrATgM5TWgRd160u=