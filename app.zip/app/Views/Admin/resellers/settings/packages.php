<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvZvSnkZL4XTkZhcE2yfV1pAccCBTIIpdzzOnlHxYapKjOQjk46FeA45ITao+tY7SPwamwaX
9g8lKYXYplQUyaVsNMyY0d09VPnS88Iq25072sg3WRozO50Srmwsx/HL/dub69bKOziJaDbd6kk2
8lngBSqg3COsf+Fe9416cMZ9ryFI6NWA7VDsy/LXVz2WIAekB1cDlycmYl694VzN+msFw/Jev9uX
9A/0hG/ZloRnsK2aCX0RxNNo6Rj5lmacbA2GZkg4RXD+6Z68SCA7rRq4bKjocVjfTBflrhqbuots
e4SQlzrlGOtLCpwANAF6Ob4tZO1EyzpsneDOFuDbFa07/7IlSOe286yO3kUzMZv+LKwOBx2LxtFD
vF26Avw5pRAG7hgTKUp+ZoXAlOPenC1K0aiSSc6JWwUYxlzAp6mCx+xtidS1G+8bG3CjJpckhh5L
9GmPjbOYesBs5owmpojmQwYLCv3QNiL3pz89m2X8ggykWoHfqFcp1S+6HxNmqr46sp+GEHTRk2Wf
cV+eO86RrXigkWDTknHWGwUPGRZ/lifO81hT55aPqiJIPzaFWSlhMKLjerI2AZ9w5FhuV3Lfa95k
CTTGSBESql23gBpMcXwpwG1J17kvhJsdMP3IH5cENIPCQI53HIF/i8PzTkOn00W2eZMtBjKIWEtp
s7FPhwNEXn0G22q/HpdSn8itdlwTUEM1i9msp5H9+3dcz+pzBflzV/p+3DUvAyht6kbRvp92bpHs
CcYhjT5a3X4Qmy8f2OJzQQPdzP5lGpLKuisoEq5mcm4JYRtf+U4Lp2A2EPdv1GVJReqGJCYi6E8E
Ioh2VYU1B7v978Qwf+PdN8IgraFGLHkjgbAldlOno3Ax7UycLlhrTCUgGB5WVVKJ3fAt2g1YJJrh
0LcEx0LzSJGRp1Ey/ck1eccpLAWztQaPmQBl18phO9AFJUX+MKI1r4FO0WYWX85f+dbDm1Og0A+f
Lj4kCRLxoCZL3KR4axmU8glwlY3ayBIvI85gecpbvZXtHrxIxj9bVToRWnO2IoHDqKT1/lV3yMSL
XMTui00hjBftJ4I2V3Lp2NCK8J5D/DwWZHr5kCQF2blduZfNmd2zUY79R9Hj6e5gmDAAytutTtxz
JZvpngw7ikc4GlV1AgjARVUh7A5uB8htbdS06xyoNd7PKpOMHJNX2N1knM9QiLDlDGMT2SBl22NN
W8qGqCADwkcETpwWEUIlPSi9Uya3DJQ4g4iQV0jLYKKedsgIZeZMOSvtSloNgPeITun4Zie8viUo
QtXf+4g8hooMwR95WUWssdehs6OKhUxIvegCrNXqZxMDPo1sS0MXPtSw/n6XzlOpVfxzHNVzsv0c
rEi9g8Ly51K2mLKfGRWvx8STbHOt/c72VdHO6CqBmdqNGGSMhcy24oprpNsGe/LXRZRPuNMefX4a
RmbPVsxYJWUT8ry80Dq7m6OCSVQiOzaFNYPWGLkrGLihWbt5816ZDfJMxA6i7w6mMOpo3jtn5ToF
mtDN+Fzg/uKgHHnP2//nUr5sj2rRDaVfqSdi9E62in6zY3N2DQ6c9Wl/yFn+PU13AySNpT8ui6sL
Mnwcfzk7Kjk4NURLSFoglWRP8SuJh69Ski125UZaAazbNSaJBi/b4Bpsjm8v0SMZBnNWRpvGkDep
l5CEWvNAUh2KRM0IOoN/D1xegVy/I3aHQhefpZx4VRJTUUFb/3/y8MbIURQaTpv+LQP9izoRDC3c
BAAOAxJw8bmuMayrasslUa8AK9K4/n2h8JzMi2+VNr6GR/KR5SWxFwZkOCIeyPwla5lXyC7kbpJi
GQhU2djQhorf2r6F6+D+k5VrPexS9c/D0CvT0pevXTFvAVWsnrV5yxOcRthI4W5IzudfGIrqLOkP
snYdVwNV7+/bwyJAZZRWhlQsAdz5uiVlGPHprRbIcBTK2YtM/wvIsnvvM7HXdp5fexHmmAZc16Zl
Cy4w7QnZpZ7I6fg36MQVhZ8AbUcfgnLmuwXodJbw210aUsTS8JZ4LwhE7d5NP2ukQl5qw8fUA6+L
Ek5zhjvpVVr7uyHZtRB523R6NHr0Po+ccNRVYuZu8ZW7styhhucW84Ve3p/5iSqTRNYF3lV27EOj
gcjqbVryhgZ5AFNtcbwvXASRqZ+hO/CMW2lJd4Af2PKeq0lzUnCo6wAFEBZtk0aC