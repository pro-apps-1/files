<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/lVw0jOdz4i9GDzA7x3jjbXam6hegO0WDGM0ulP9Y+SgJh/q8bn4Se8AgoukLhn88QXrX6B
Hik4SuYsAnk0Lj4f/5N3h0somBwJqyhXtjHkFsd7Zl04q0Wwguu/b5QUXDiCyZQ5sKRwfGbzdBvq
ABzlrt48e8QuUbiaJKAUIJd05Oz2r7Sv4x4jUrI59CEo1QTH4Ha/OPKuYz3O3x6HMoeQFRkf1ELO
WjTXMw+8/Y0w1sTnszzKCsftivCnIUomAekqDg+9ME/C9FKFr/I8J8bEJI1jPZKWOy1pA6S4Ifp+
E0+YGJOw3YON4pGmYSaIKIz5OqEa+iBX9V6XVo83WRn2sJtEMyQJyVK0VEI1FyAQQWxuo2RC27ib
/t214dvOS3VqCjb71xpB9PdUW4DCVH08dSLkDsEZgIm3tVGZi5DkhqEfUBQ/UKlrXlL9tAS+hA64
D0RgdOcfAYjTcUQ+mC/cfr3gBrXHlYo5rGZQcSg0uRfpV0cu8vv4L6zDnSLWOovnTaf02sYoJOKX
6qrD2ShiD71HGkZSfni0XYNamTdrvYd/sfijoekampJPz/O8xENgLOUwRyqY1KCAOMS5REAL49Xh
GDScm3M/2WbKkde422D/E1FTcg5EN5nM1ay2BEyoNvB7y/hXbh8+D8b/o/c76bydmx+jMtLJayTM
toSLhQEoRPq4vP/kvB9pzIXUMbDa6sBTvSCH9xogErilYcMUBd3A4vU2IM4XsuTXZpHrBf/mVWYm
nvAhUNrx9BEFlSonQ0khlnipm7wEnWd5Z6fRqaepN6OldwvcKiYw2ju+sJOe6r3PFbVv2Awzolow
Es8qLb/4NLJjt/jTZW7fH0FYQrSsqjDSfi6MFhv9iijAFtL5Obwqrl+aG5n1TOvrYL2cyJsuHyTz
3z7CNXg9gWixdSeZgB4ufa6kk5x0waLRxALJfUu9o1W3fLBwSlJGf6qGyhQB+/qPgoKqNiymg8Hv
Kn4AKaKY2pCVbnocwKX/+FeBaUXmoLoyVrVmeCSZCTzkTG/iUlTxdvL5k6W4fGTI1K5Mu6fVmoXI
QorclJuqQBEXhEsP5+1onKtKKaIGRNUsKjrlDOO/e8F4YxKJd8m5xuhP6evyn3RLgmPnpmURRIFT
/uJgH5VT1qMOntsSNua4JWRMtczQOn2YxUrzVOZO7tzAI+b2J9sBtf50HGuWuY6w02yqpPY2wPK+
5DMOuP/qxnWx7iuTrdzrAj11bP50Lzm2RLesFc5vUajYWudp8jQ73s6LbGHKKpi5KK84oK1ATxWT
XM1JqbYzWhT3Fz7dnIVs2cS/e3iXdqTXgtKWLCm6oYtHYBc9w05p1HGfNK6eLVy0SPwpRKKAXM5S
cqGxMJiZ+I5HMi00IO3RetpRPorKiheHwwIkW+49qDiA0YkwsG0LOH20vZLCFw8xSoFfthBtLsXK
ejmIKKzBZzI2z1KrdJg02wYlQvtyMRac09ufoxZy5Kjo72uC4oAzCI2sVtUoa8OvX1ih+MIOllJj
/ocuFR2NhVUXIMaggGw7uvzkVIs/uHPr5uz0Wau5lwVl3DrYorFhHFfP5WyTe3gShxZ8enyuC4yt
ODWXLmcPR4Nt165jaIa6Kipdf0sOyeiObRkbu+/rmqGq0kQ6Kj/QgzFgsXG9nGgylZZ3q0AbcZe7
NQUrM6/7CTarewFCTESVJEyZ/z9cZYVVKBdlwqZ4nji0w+G01CGXNA6JFpkejIliQiEyahkfEg/+
pLCVPyI0FsJA7g5XMyP871cahp32c9w2NebVlG5OpiXWoOoEztTkBM88KFKhzwmrf1O8GZEDMgXD
LDrk6hSflQ1m/2swYAHplHDiWj2XWu53Elehn7a3bSpK0dEvd7DMjKnnacwsgne4Np8VyPAPRDTt
Cd6qjJYmcZjf9Ni5phppRn3fyKJnFNzkOi6F65bEahe7NS72Sio/NZByMU1sphDIo4CTkuntcAFL
NHikInitaUrSYy2nXQTaVZTHM05y55KUa5ebzBxuRoOi4iRror0ZkGkDADlYnMLnqDdp4mVjbH9i
DDHpURKaPcRrFJ1MWeV0upHDFKpcH3xwhp+awReXgCabO/KlsrvHBIIFqwYR1DITElrJO0EG4tGk
+9QzeuRPHeLWd2knWs57xjlIfwFdzj4bfsH2Y1/lV5k+ksPLHvyVSrQCm80i93MfcgkJI0==