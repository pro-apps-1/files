<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvHpD4kSueniMQ+XQC53u3sk6+i1N+07ofixGCgLXWqtS8y1jMYnJzzocfkgKkjH9G+aPN6D
jEfDgknabG7hJM6hIWV1RLRMjoDjtSy8RoNAn0P4JeV/0M2tUyMDN9xOY7220TH/egOlgRDzo0ZR
EIdMLAP3iRuZt2dxUpkpLA24AzWT3UVblx1dRfImWKReLzIXV9ushlEsuleSMvt/qtG49kf8r59X
Gv2Zpc3g7sVSSHYIjd4qUCIQWD65VsKQRzfLTT20WFm/shcxgvYq+RWdSfyMUmzkIhYp+HBbA1vy
bYlBeCSuuKlABJzxQeREueK9ZDA470k3kKk7UdMX6rMRIkN6DL4B+nvt5dmI+esn1yF26rPtPaDX
8NVMKdeCHy5YUR78C5ZItJdklCoW6Hs8BuEqfWlgzuJNvrJtbLLflPm0yJvQ/j/FWsroWl/bSgTp
bDwxkHbZUBdkKUFV8guM47Au8v/YSyXhVuDNb/iOsrUOideRWvaZuVREfvHUVtk0uRR/Q1bEIgPK
dk7pNYZY7n6p0XvdbjGO919MYThavSa2+mkdEO5sSB1zdM6eM7pGtyX/Z8EOPXlErGv/CGMAf6So
iGEgyvXOFHsxB5R2FQIrecMsRh7VLxoVG5FYcXWrEZWkXXklfrWeOuOEsDnLSzY600gdz+e+5lVz
Y1UbhIgNIMarQTg4yLdU4XWYCp84JfZF5YlXeU8sjrtgu0JP4HMsvgJ5ejyWET3LOb1bl2dFICNS
4gvUQEMQcJkKtlWabWOmHuODphqCwHscYrKdDUABu5Wq8d0L2wCUxFBf4nCQrbJla0JxS2Z6tSml
g8vuxhl8S4DzTygWSyJG1ZGEYEyHCToxSfM1c+A4a1qe6Aqg5FzCmAh4EBOef0MantwRWoGotkQm
eOZyJqc3T9yjVtOw62w52Z4exWR4IySkTjWXn+/C/XTKTPfuJVOJOyHzQjD3ui7AyM6ZoItubgo8
WmmRw2diyY/AbOePpcgdVDxDj2i9RluI6Mv1vy0695TAVriILgnae5lpn1B5bO4YflgJ2BF80UW0
R4MO4HTJqllyE+1tLgcWTKAxSOb/h68wtP0J9cbzZqA3aiwRoRcWWBbHhunE2mQ2y7MaiKkLp1SI
nfo9J0ylOoyJWCobyKBc/AJuAkpl7K0G5IMsL+wM/5KlukSSLmuXEEta0I+AQAsKs66JY0UPZBZ4
wvOXFOUKauiTQBaNHLQjLe75R07mg+cU40x1fHvylMPePcS5uKX0b9GgrEbufpYnpCppTWk0Kug8
jwRZHg3ZFeme4m3sV/z1Lw4cPYdpR89oIzwXTIvtcukEAd6oN57RjFCqnWJ1DlPkZ8wDGVyQDoPh
kmGciM2sqLz47EbgpqK0K2/KillHI0CbWlvQyYcFyF2/2lgYviTOEm+lZWGDX4qpo63G6dj9wfbo
2fAEGaAh7+6DL4r5ZlcSWA97nliNQfuqERK6ad2IHP3nbZL/CUj0yG2sTtlSZ/VbRSq73zAzIK93
jEpUJi/fvwhXDO+lYkPdvr2j20rUuTr7CCoQqBsbsrMVZUCFi9pnJi7WsDnlDwHE8OO4oq/s6oI+
5Qt4e/oWDNf3C7FZgBtHx3isjTjDe5nuU6mnkuO1n0rBhB2ak0SzCv/Lc/a6zfYxxw9HmKSGHMcJ
PB12tKh7X5LkYJh1BucoAYGIwZ/4vMzY/vhMo4jzauwhuGnRYGpjk5Nq8kgEv8kwDBu6QNPyf8+E
MI42ELEJlops6L7rpCRks/GIkUUGIJ2+0+ykZuNs5U0g93SjYzFaL+1qLm9em/pwvdMO0UJjZ04U
WN9KHddlMthyWccjYP3q/A3RPvn1phRoQB1MtQeaMXkDk7mcsEM6aq+KStyGfatgN/MMaswDGX0p
/i3N/K7FvBjqOQG1FuKwQEQR4qa0Y2bk1LlTsbH9yibTmT7vaycTC36nof8mGThPf6qcUhyr3AuI
vz52upFAxLeuFqIJ/GDdLbdZo/wmZmj7RPiQ9ewrwNJPsVSo9wVkDUb6IgjUDwGxQpOpU0OrEudl
UK1q13ctbaWCx2wiuOA5O809T1b9V7ECkKtxeGcb765TK3rT4dFutnMLpYL50lxv4d66/si3EcAZ
YnDRFbgoBkmFwmHmy9EzQnRsrEV7D7lDExdFWV9ubPEyrLo04THIkm+x7u4ke9N3Vv0q/6lQP/l9
SsZ+XlPyJyB3fk/Gvty=