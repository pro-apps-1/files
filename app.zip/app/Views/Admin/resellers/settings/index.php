<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPneozmhBeyijakzYAO6E3mH+Qxcgq5zukgcuqtx/pYka2LCahjWMAE6mWKUfbzS8rG4pMUH4
h3ww5v/sahak5CIVVDSVHFOKjkx9om8XhWqPnEOLTfJa8OgTOlwdcw+ttHwqqu0evO/2pe8rJrOP
PpAL4EuwHM63SKt8C5FfLuuJB2Rrh14YmgQYNyH11gNelzyaVDKoUD0/HhnqYaIr9lOQO8QAMcr6
vzLNq80PSy2Qt4ealyEIvQvOQQo7e7V/EoPORjHLK0sFFSqLpROcz/6WCXnfrp9VrkOgCCDI/e82
/qOK/wId20zuSAi5z93gGpVSykcSVroynCCUZUgTBrVGJG8+ia7nCABfnM3RAvwzLOWTpn+gkjoR
HczMee7LJdxwtluQsCfcb/QT66KpFpiQzWNE1Vlz+d+rf0j3/5ckXV4VmjC90K7IRiOJzSgUrFWT
GmnDswTPymLCnT4LbZ5//5WQ4p3Rzr5I6xAxE1Xp/PogKIYwXucRS/UX3pTl5s2ouyTn31on49d0
o9j04/7Xw0b+bsCOcMZoWbD0PiCt3eu8oR5BzcqYAkTtX4zUZMtvWDM2Kb2tpp/TNGcknZNhPSpP
R/6fjAwzwGVeA/9dj2/hMzuHOI5KUtlixSnZEk56dJ3/bt17KhebYlHMr7C2vqo+Fy+5M3Nxb2LH
/D3gFqQdlJyWWlzc7pcEqqVkM5n3pBraBXMiva7fESUP5FKvxs2mi7vnOU68yAFZ8STzDOKEaYCA
cXPVcVLyDpicZRuQKqw0isdYSu5mu9B2lFY1xaJkgAX9kqij04k36W1mbqWSBcY4FU7teBHBHY+y
I47V/ITqf+Iw5GFY0pdfdhNnvj4tW+65362f/mSndEBTd3CnDiPLikMT2C5m+EosS26kdOBLH+m9
cYbHQrOGHtTpaCvDT7wWMMDfyOI4sP8l78KXvV5JF+pW6xKjGt5wKqcbv9kX6Zw3F+EWaGiEI66F
raE9U//LDbwHzyhwAGR3i9SamGx1k3G8XWiWvwO9uQR9142+TzZdf4lAclR0Mk/B5klZ0IRP+Rm3
0M4gDeRWpJxsqgpbJR4zuYMHOzBD/WGcH8N3qKP6+8xtM4RwhLmCZC0QC6UyucrOg+4w0ZKeAgXJ
dEZC369WTCT4fBWJTqcFjpI+NAtB8RvP7taahuG6zods4jPxt2JDUV9HjhYFNXDwrqpDfRZBBLQX
ubgZz/hiq1oPRfxpHXj+PpD9TtBWwBuY6ZN+byklTm5sf53iWS+ZkxVu1y+FNyO1xAhAxcJQwzQ3
xuOp+O4ZcDfwXLikGqos1UpTdsNFbnfjpwR/RXa6do98JyuuRhdn/IGTxZ1Ham/WK+kqsXQD+yMe
siCIYqWbpRwCHuawzeB3UPpALTJ6Ue1VWJXTptcLuG8b3/6fI16jJfoL15knNXyruC5+fhlI3Qs8
FJGgc53wcfkCHRKuXAqHABYaJWVvO4sJKkwpfMUNkCFwOd8wIBjwW+yf1Zvrb8W56Mw4H99XAPFk
B11zkv7L0sfZbZueikcWNAE5qae/+jvqyCjaDFUOgLZv2eJ8VFHHPN3hOI4ekTy3wtN9pIfN0IUx
anjvqEAbM6Fwig6ad2KeCiFiTSi36XrClnYGYje1AhRqVDff/m4RWo5uVIB8Nll1q8Dj899A9Jxq
OUxsNGaGLADteDpsBam6d7Z/CLx+SfeAajE7R4msOb1gUT+JeRupiOrWXagQrMBfNAU8XFfqapJM
00bxBTf9jpFkWlUxrXtdoM7Le7xJy6BcecmQeggSS2e9AAMu8R6K4I+blcL4tog3iavXyGpCx1B1
UyZBexE7ahJY3J7ukdX0S/EgA2XS1yMJsOwYgHJCU7F0jSrPO+nuTyRTe2ZrtWt9bMFu4zSE+0aZ
30+tRzAaEFmbnxEj6SIO7JIDUcTz0qSi2bzybp3VsqXVmf1my3xa4ezaJdDaTTga1czrdQGqY/AC
PduNjKL1aO89K9qsU10HCoNQx1ch3pewyaLJudCaCqOZt/zqtn9m9dqrrNfOA08nIeYqDlp9r4hD
6m11W2NYX3HmZY4aKnbZ/s6Z3CMsq8X2f7Kqom0vRWiuY8VI+uYVDsiHiA312q7YfGF75n++otky
7X3Lvyx72QPkYvHEzOr/qe342x99wCilv0i/tarzjE2rOFcy7kwILidhBi9Hq4oUjmu/g0NyW3jJ
8WbYDY5gifHG4mjbJb+Z/cy9Zr4JwnYh/ZzEbTyfJe+WMhoR0EQFzWn5IDw4A3PsTXHjQBCCS5Nx
h3H940IULOd0/Ky7uF7EoY8UiSVIZl09ZioJfIwLxAsJ6OlqJBAt0VyiZ0PQdExxWv6NWl8TQpHe
zEI3SV/4QrmUaVFou5mg7/aB+KPon2GxxKsNRxx9kqiwVvz+5tkzFWCmci9sdzSgrrFCX37lbKqJ
1OM12ORGGUC4y5tzmNb/pm+yGfPTwHPYc3yz2TC+M6EdG44iYiD/9PhI8zUZm7A8blc+llr09E1V
qpAx50dOJQ3tcb/Kt9lvNHc81EPbrcpO846GDnIkWL4LIXX6A3UI49bPRKCIAY3hmbNVDNH2qMqW
Fj9iKtnZxE6IuwckaL03ORice8CuS/X1SKf4KWWcMpcMtSLVo/DUWi/vrJbK9BUf878Ea0==