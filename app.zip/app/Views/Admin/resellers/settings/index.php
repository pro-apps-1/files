<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyW8mYcso3OEJzLN2e9r1xBP720XFduoihAuuvky6xtF+jc5R3VZl5p7eHq2DEr7lX1CSdQJ
LUEfQx8xrMvSxgHQ3g+eoj8ob+hBnxIZKfc9osv7dhgpKY7qdZBPV2rbEgTTa2qqjIfnK9SLarLh
w8JFRvVuW35/r+DJt+t+aTTkeuP1bsj68af2muVuvl0qdrtj9/DZvn25lPRwrpyJKAfDXXtnH3NS
AlSoQmoCOYKs6TbxB+xSqOJm2hPSbPXyDcvdbe2r2DXL8GlSdw9cbuGu5Pbg+YuTH9+Qq1fUtiiJ
StXgg8nTeonw7g6RHOAuTZhrI8wiAM87TmIYahvAcVBwzr1QLuRbGxEDfghlskPMo4x2NYBQnTy/
WAkjBv2YaqRwN3zyn9eQH9hwDnaRXtKGBKxvBKmOT9eOeVYv1mYWmIkRwHppJupXkFHagPE3JxEI
1c4bB5TC+e0Ogc0e5A/jBd2kyoqzsw7yqryMzihfJ+as7+Eg9SKcEONmPR1WT+p1KwaqqZRuHfEJ
4OhG0r894Zwn/7z+w7noKzgqIiYGai02W+l5JK24TcpdVaMrElWvOOQt5Z938JRIHIbxAcOCAViY
RMtkBePQ7iRRPSQHw0mrcjnzlLeTe1nK6IipdcHRWv870+itwZV/9j74h+Xf9Z1gWYt1A0mDa0FQ
Uy3AY6vrigNEvHb/78lF1tFhp10hmV283IuuiFaOfybu6SCvx4ZtUXHtTUxAmUc6vUoUGCI48v6i
sUxdT+mhWKZBCMibtDWedHzbQdtJblZBvaBA58yxYGiH84p1ds9xq9otXO4Sj9cR/oYeFzyruyHi
CWGA0r1H2LMxAIjZPEEg0o6On6Qc99+6fLJeS1/wzYy9HCnp9mIKdExvAps741XHxvaA2ErLrHaV
t/jG7QFbL0HvSpr0p0OPmrtUPRcWM5mXs1DQ3r8eFSNo9DFXjRY8buLNln1pIIxj21N3LwAHhLYX
Z/MqJtXKrfIvP+l2Y68q4cI73EXotGJ1GhWhR1PJrZeOxY4OzgggGq0GKKk6TRDQXxw8e4hvUPqV
TEQD+WuDHJ/RaiFdg8VuY0zTG5fEgH91ukgwhbKPw00dXRoDwG2hklrFb7Jxp1XnAPwuC7G5yB0u
nozEfeZxM+hMgqtWyKx/eOR4lM1RlfqNnI185fUGFyt1kj28R++Qr4lvalAr08lh6GRrfdRKP0SV
vilU2s0f7WGL0OOQTRZPGtVSEQviWw+jI86HCK2oQyN38lwurUuLLsJcZyPHjz64v9Ib9xumgPll
1ZMeda+g7mpWK2RRzDgdfSMUXqLe4oklO3RPnWTfe0Yr1C2p6LtgKg1A9dLQmUG8hXD6Oudxz6zL
kR+tBPhVt1uwUFr/oUlFHmwAGW+tnkWhYf98JRV4vj+yI1OzIT3Wv9m+nK9we27OJrxfLRghiPVb
soFB76pXAbiDKKRIlDtl9AH1KG9DvfQV9pFjxLuFXBHBgBOHBgbB4W0I3G4Ny7fNY5H83CfVo1eg
HPOLK1XrheXATnj2WudFmpk81SSzr0/X9KL8HemTtz00jAfLFS6NX0LXoL03xmWkPSlg2zHUoO/b
un2KpMs0JkQ6OPQCcRh5psPCGzeJEZ6++suw+yRoDCNVhNTl3Cm1NynMJd7uwa2FwQfiI+L3iQxI
4M6GmljdYFRfnEMZRchmyJ23Uqlq8cso7Xx/yeMybTtfk/ywxNRcgHP+QI4mntOG78NJPonVtlNN
owRAG8uPcHJ8TZHW/dbAaunuXvHoi3OROsDk+zno6120bDjZros/ZLp/64ugbElYvnKofc8Zvw1Z
UDM3bwkKuRffka29njWSPuNnl55Z6VuYqGxiqDNKzWV+UUzAorh6pVAxyuVt5DVdL6fAhAeZqSRn
az2xalKlrfZEe1yY569oW6azVaCS60KzmwN34+F3b4fHsAYtqiyJjaqJpj+h8JbKVrY+0ERiIp1N
lqityb68yJQwWM/OdKlhDWyBNTyMS/VTwGFo23wWWaESea63iogZ5/Ni7CDAX6ZMmThzhUT/L/+r
jIJLriLjM9M83+G5V36AZkEpPCNHA221GqSay7ymnYk7X8Qqs0vTvOeCtvNQYrVwZ/ZAcr/hXzKJ
lwzpfe1lZbEzvn0GIZ+1KL3IudDwFeTX/2OJPtDWHvE7cvOPC7KFA9NGUiaZC2Q2+yzblLitPD7+
3gf993B+JlZdcarqh6mLsC244xVG/vhemWNdcVLHhNmPNxNZvDstFjN3ynGD7flHpBGmrq0AoxJI
HdvDW87S8O/bC6DTMmq6ngXmHGDEJ+QEh+kX9YSTH0rjfWtAjZV7Su91kd9FClL2oEExXcDCWbr1
zWvMLqBoTmIiaV+VY6Jl+oiwseo35uQV1gr/LQzDgFZ40mEXLFk7qZdavPD+V9x1wPCxSyv4PUHz
ITJwho02a87H1guLkynCrtwDGClCowhqwpy/B/cyPrRYRr4bvGw9RDpaN1uatwSARSiirv3kzlgV
qm5dLLrNhtV/owbP7xvkI01XNfLrRwk11CLV3UMYO8qp6ly28hmLbFYjOAgWIomrmf6oUqMmoEGI
IHM5Xl77dnBI94D7hozgnth8OeYSeoBMOgDHR/jJfyllvqC0YU0IseXmjZ8n2+oiJRJ/vddLYG==