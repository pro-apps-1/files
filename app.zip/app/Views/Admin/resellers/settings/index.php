<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv7zy2bqSiaE0I1b2ieqpdMUs6jNr7ByFPMuPaqPvCSKPDtaKyV3dMfcqqu/GaYBgdWrmgHC
WFMW4nGCnGfTBd/9G1xXfseku9uRqG2Yop1SwS9iLbQABsmd12UuDI+R1xchJx4/JyPuPgFpgUwW
Tc9lkxVE+HdVmO+OcIhLLDFql4H9EXUSEKIhkEoj9/WBkvBFwZwvuIazor72qxyxmDPXEX0JH2TG
xyK4I8Q5qLekJCPapFau4fYhObW1TchzgeJRGXwzETahMeqc6ktl13TsVIfduhLnsEdkcJAfj0+W
Ixa//tTuTT7XMoYv9wf66BS567O+FLDW5cvPxnhFPDj2TXrP+Msl0SKSON28dm0bGMg4bdO5BCYd
V06ndtYZidla5qWoOinQ3v/FZXFI8IMWvRStyo8JtyJHoVC/EdyV9SxKYSbuJuxw9KcLLt10tb16
VPRfhndsfMcgZr15y8LpP86bWhuMVu6c0NeVmZUlaMOQshyv5gDVKyLA1Gf6cmOcf/BwmJL0TmaY
5jDxt8JSIGjSCtLWeKpoeoAWbLE7h8056y5p3xCk66KhJSkV91tbTXRbEdg5KS3TjEXBVqrkLfv4
Klp0Yuc3C9+tf+sF+UoIDFuQ7wf1tvpqBORi8FnD6alx/ZeYPSVbkubyFxHDKmNW/l4B/l1ssLWM
vOsbgesFKPio4vLScYPu2i9PcKOo1NYnsehFUjNfcJ5DezuupkavQNeLO5GqIRjZbMKuCvtcwMGm
9iVkMJsFltCQ3Lu/aSEzXSGVCM4QnWvCmxhUwolGItHqWtdt3pr/kCxy5KhLFp/5CbynbUm0v6Rf
01uWK39tcRFDexJxUfyJyz2YMswPXABAo9zzcJznHkQYyaxvpGvweEotvCdUZvSCMrXbV5uuTZDX
y6fXyFArh6uSH24jlwmIh31WBMtnxQRgYgkXvT1FyQdqfxVAQZhYa2PX76pa8D/KUe1MHAY7xPMB
dWm3nxZ84/zIvq+It5UY1T82StZeAlc6go7MpsNId7d3tnaRILzBw3lrsaMdkc8hyaWt3BoNDbEi
OOImekTj7nyDEAUdxgYxNBqXPXppRu/munChLFOm17irqUh20RwrPh1gfe4MSURt20fbDhzbqK8c
hALpCztGtlqFMPCRSmrWzVMrOq6IGjEify5j62f55pqKd++fQuDcOqjK1EVw+6olMzcGBRFXzEJZ
KI6TeRdA6BBNd++LZMmkHzYJKs5es51Fhy3X1ImXikLqxMZDUOann7/Sj1A/Enk3pwZ9SfzuKts+
5jGeYfSYxsjVX5HFwRcY6KxDmWlbYMx3GEzo3QPeCtksnzvY/+CoOwhXksAi6MWC2EuZqGgbVxoy
fGTMm2WWe/hCpHu6jwQdMwKE/2+YE0Bj7KUS4AjltL3vbM8uDNpeBbxI8gHSPtLjiGPJLbcJoFWG
oicgysOpPj5poyOmsbGEzA0aHplnrt0Bz/aRDE8Yv1q7Mz3zx5QG03jOqD8riBEfuihjSE8JzCh8
4rStxsl20guKhXxjMYiC9gfs+WDcT1+1raMDEc3aglZRPd9xNuXqstVxwXBFDIExGwFBVJcYPGIP
EV4tQ8aBt7NEcXU7NE2ErA2CQ3QBUBGZayajlq1wgRdjyrZUQQeggVJhsf0JCPRyasSQGAkNUk97
RtyxNpP4r2lQm0evReu05mv1IYUe72YRNDM7Q/V8rmpGCdEd4PNm2FT9dz8QS30EOK9gFkoUqKnG
6r1/ngz7W9p79mVIWAv0x5Yrs91EjV7xnD7FPm06KhSBo2sHc7fm/itlStLBb7tHr2ETRoJYwTx7
Qbk1y0VXHBI4Nl5oWY+Ikc8ECsU0y4m4YFxEQNo/h4NQgHHeoE2E7mdStNeZ3RRVyDRbHSYl/RAc
Q+yICQil1DJlq9SMuonXFVQWoE8MVU03XxWRzVTy0FamVrTEuVqLxnnPU8/4YR99MGBQcNN9fZAB
yq8aJoHQRUcqvgIIWzMSzYeFBAzd4FlERuOj7mC+mBpq3GFuDzuORVzeKnJBIg86pE8ZO3I2AK4U
PbxpkRUzA/hg44UJp5FqOI2kIy5EZSweLsytrLkMSb6IJ+aiki1lQe9v1UpqqbJxfT8V75EOO8GU
RpvOj5xz8Py9kStpCglr5wqpkZLdAb7vWxSAfft+ZBXXcmz4sEwl77JeDwVFJg2y7Hu7/GgqAvLK
NaKKkawx2sL7b354QIFS8SYZjG3FJ9soRPUGz9Eme0Sfo9sD/b4aFVsbr5VL906zyXVEe7Fnd7kv
Nlmtq1DHoI90WoJ2GFvoHEihI5otMzoHnU1buYqS8ds/kO9Rz17cswhHmQIiRmDXTuTzllZQdtRM
hSr1qw+yVFAV33TbnU2NqNMKIMuiUYnqVHKXkmyJsoaFs9DCLwnm7hedJEsd3PIVphUBfLIw/fcE
YUOcgsBs2fFQlXZkm3TCv8HC+p9xSmo7fLh9KREmY/3o9cNzRLGQ3zMqACYw4OtiEVP7w8Cvvb93
Xux3h1lsS0lUimTTbPs7jCyn2yIhf1o31xMomyNfjjMsMo1sWjQqP139YWjawKjtN0c6ja4pzYiO
YdqSAHi3teGVkOJqrwITPkAgsmcAvoIRApgM8b77gfOrnXMG6aYrj41oZ9G=