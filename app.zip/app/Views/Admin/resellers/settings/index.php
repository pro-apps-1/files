<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpbhddcYw69+kxOBMXDoTXAfu6qEvAip8+GZHQML7Xs4FK9GQj1lS0CT3Gn6PIcQR/6mjnC/
6I6y11GFTNELbAv9Z+lrs2enLc+xhdnujUBz25Zn3+pL+vRh96lQOH4CPdVik6wV+Qb/HawHT5wI
4UAPh5sn22w2h37oOMQC4TwdwjQ0uG25W123rsUB1fi5ajuaHfIJ8p1P/ROeQmCcBItCOLRHjbtw
xlDhkwtZ0RRELz+Nh91Y0fO2wXqwcZy3T8z2jDfc3gKi+VXMPDuvxUuHG9EqP1fnmVaMzbS/zJ6a
4S1RAV+pQSuibtdy1krvse8Xh9hG3UglRtfzIK+YIJTWTp2fsvDcx29vq8hY9wretok86HtYILK1
jXjH28eE4SIFRSIM+tSEnFx8eoZF8zQL46568u7V6j+yjYQZ6uIdGlhKZ21VOjIsae9stZ1e7GmA
aoLy3QorEpTt5OSEAGEBmywnkxJQw2fiaWePgHcaP5nSoJ05X2Zte36gHBzp9uWLE6Flq6EehpUz
RPlOtJtWz6GY1FKk+c0IUhnxPFpN2lGifNnQCGCuWYO11ef9LXiaTyDKZ5DZ+s2HKhEKmuWvpDex
pa+LoU8kGk5jcd1mwhpHW97HyJlq1wyzQ4Rm/Jq4N2TyPilVEk3egSJjhDBbJKobDaBqcXAyTKs1
uoJGGe0eEW2NmG5KEzWYrqR/nfBmCIZJ/WE/QNjp2vpuQqqgFXwR6Oxf40TW8JK3MOKpulwtpwqT
BiuXs2YUwgQEvhyTmqe8hcTYbGp2u9m06590jcblhsUHwPnsnAhfdDXvKOV2QjPyrYIPzsm+PEUM
suCpw3cb64wlbNiaxKkxBFvlcEtu11wadEW7aW5NfsEeYiejU4prXtNk98+CBlHOoxA4c2DbHGTh
qcr1NC5N+Ep+eGSI51E6xbcML/qnPl4j7oGUWFI9lUyfU2Rhsg94/k+F7Q3UDHJpXmubOyPsqyfn
wBNj+XJS4JNbAnsc2TtPDGGO3BIpvxgHkfsoUdjGzuArbZjHE7PeW9HzDTsOSmvlX+DLpdEB5pS9
HeHTbD1xqbzUvJSQbAelAMKBn8grykeLavlMXI76IBykitQxyKyzWsGFs2cQvYQ/hZLoT1CU6P+1
z5iSC9YcJxoUd/Q3TKnuxAgkbuwcbzN3vmYSFpLr/N0kPirwaT3z//mMjOs6ty89uGkPS4nrqvWo
2cUWjTJa6vta15YmkLE/e5TvA8NZdQt/abipo+RVSak09n842BO8bNI1WQAnZ4w9Infcaq/CLrRw
4eKokuESskTh6wBCncLEj+O5jjJUidJRLv0IPNbI+VsuWpiMjMf/QvysVF+t3b5TzqUYnTxL9th6
tFgdjSRu/wtgIiPxhVYrT5woewLvpoQAU7km2278i4sAZ30LElJERiS3KGYHTg317pJ51pdJNiAf
eO4Ff22mljRKDnvl9kLhLc3gbXUbqQ8BrlPK4Kiobkk1Kg86ptNR39DirDZFeHK3KN0jvjIwLeMW
v1ZXovajrP5cQMN04FyUcmcFVX/4UAOuizrjS+mfOB3AdKDZC8pBzZK3QzYLKq8eyzmLsaahzf/s
Wn31ZfVw/PLE16xT9bHBuhUlb8ydTS2E/QKkDoBB3aIHg9F/J8VwflmhO96BvtAs7A2Jfo6pTP7k
l5vJVXbWTwtLHs65TUzMPvGbmz5K1L29+0zn+famq/E5tiAf/6CjNi1uIHIQ9YLtKhl+89Um3R4b
EsjnCgw/1IzOtI2KloBlVbgKb1+60WlaaVW1ExKUOPWBMPXPNiLr/g6Q/VXgOKtWDR+ko8N18B0W
Fe/tsLcMh022sbKzG/zGH/DmzkvPS9T9SRhk3TnazNeLoSzJbkjcDwzguA84ocMVpnbWQ6MKhtNR
ivpv230Nz4qWZs0l7tcBAqVKp1TlSb+zcMhZrBpQ79mHLHce0fVtDjJvDgnXgMuXeZIGGq8Z3ov1
Iv0DTTGGLg0HZj9GPu1gP7GSE0D6LWili81271IhyPC/e8tT3lu1hko9wMYeiV3KJHUoELJJhCRS
tUf79c3LFfgd+X2Nx0f6nsen0CMJVCu4h0DUv6wCko8qkPcevqje3+eR3FC80pOCpmwMyNSDqEoT
GnIFmKeufNj3+ZD7lmZEvN2w+tAUE3f8wilUaJ8CeUtB155vC5wz+3GTKKn+foJWB7HQV5gjvedZ
vDdMgcQJqilcbNC8+kLIr3ePjnVY+lqFP38X5kyQzz/mCMmn4imwHu/y6sPLegKhT/Ef/jMABSrd
19VxVamWDG0hbZJGL2NSKH9h2ulVvkAum4LpB3aXU5gV2Ee+8NYU8DKqmo/AJ/idco0LjXlBwur+
+gKibLzxgKU4drqv5+e9yzk1jGWVwtt91yPQYDgytQ6EQfONEmoWUhnRLd2bTj5OsZrEQgrWlal9
rvvlyOSrtAQjEarrltVmuJhHw9/KAfBeQk4S7O3UiBFjWh693dEyfmazC6DGDNCo7Lp7BtVP2d6I
z61u00CsbM96NO6PIY3/AiSdueoa4YK5e7NZNEzr+FC3YIDq7u+b0tahE4bH1NcVyWpDQeE3TUYP
nNMHx0eup9pL8NiG0OuXcv5+EWG03ovpJ9pi3pvpEBLvIbP0ecusMi+dKujrIZa8JtCE/PYyasb2
qm==