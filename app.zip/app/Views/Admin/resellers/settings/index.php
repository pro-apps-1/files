<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/AbBt1eAfH7TNYwKwS1VnwfN8GTZFa4FwUuATTVxszPmkx4m1lvI7JFdUUPH6JBEbg+udki
fFUemlvAgpRLgEZ2/sViFrvyKx0e+1txL2S3T6P89vqzzdnWZqZDovZhEkAqnM412GFrIEhgdvQN
gb7D1I2DYPGNfAwbQBkZpqbngSuGgin0GbkxXFy9v/S3wsIKD5AMCoUkb6kvadJpsBgzP1oKipVj
0t8OZpQWxKQ/gE/XAQ7PfvofuSj4kFIX/MAlk2WvKiNl6PD6Df4hcB35x/5mAENBfTOQOSdEBxgw
avWAMxbu3rfhZ8RyHbIP1IRbDOPPOlOaHkzQJuGlq8Q1ebaKy06uqN3+8z+TPuPo1ghjZp7s3nBL
GO7zKpTP0hMgR21Y8s3XTIrM5TFKB2EV73Cd6InoxCactPNGjQIAHWMZHjaAA6i9fluWOgG674QT
P7mRMeO4FhSUvEg3BWtwxbEc1S2okxAZ/MaZ+ZhLvPyl0ZKt37gYVZPRRjLi5s0fPGbVFPEMsEyC
m2tI/kT3SnbWtHAEvG4XxPPe3N0lfEe6+W3fLTovFdj3mp2Vq5Cn9AuG7hd6HIJq26CgEYzTzWXZ
Hzdk+HE3vGG6sQVSJzXyvvDxBOvTmgyKLUPpsVWoUVK371Gj+Zud6+sCKPfN8Zk4U4WASXH42rXP
b5wD1m34778T17SAJGRZg1PJEY/tt2UPb4PYqJ2mu1VrfkfziU/LIaRN8hBfSztD6yneYwljNBQQ
kYaizn0D9rDoU8O8wd66Vuc1bicUfbMigwpeT3YGVvLnItknhCn1I9fVIbCahwN96PD7NIJqRBuT
UDduraZ8nxrHbcJS/YTCUV0E5p0pK2k0kmn7oGHna6lJ+Mgf2IaWHh/TBo/E+K3lsiLkbbE/sQsB
gbuEe7uReowSgF7xdRpldNNrkxgBFqjfF+fX0zVwxpUY2bHt97Rejsjii4znVeDxI87BO3rf+Bol
w0RL+fVNabF5KFzCBMx9SRchObIkgzP4AZOqvTi9BxupE28ju1YQuPntU/edojHJaDtnTdrsSeDr
35RYs8id+f0pddd1xhd1XcHIkOdM3JIbK5F3WH+/Pm083mQg7rVBLZJjgsa1oc424JNr9mzWYjlG
PH4E+7Mum5IwQyjT8l9J4r8LReOSSiqLNRbrrWfWupk/HgnwU1rpM6a7lMFcjf5xD6q4n/6B+CHj
duxiPYvFO8A8qgbgWyIKG6F46FT8PtYIUBIP/kmWb8nVnaB9Y3TBfTc1j6XEoRQxCenTRHosWi8U
uOENfo1NYRKBNAdTISyGWBVrmP91TKG9xW+6ORMQKzvhhqJIjN87/tr1LW3bdWPMUI5J6dt/Unvr
9vx3h0UdGKQXUhkBSv2qW+2P07+8QKejbF8u3Jh+GvfoOFIWTWewEselMaT0e6N+U9RPI2g3pB7L
hANiXyamObeOheqwVVwIIhvBsro5YO4/ANKSbqhaRdk++SlpwuwXWt5OnGzk2SbHtLb3QArAM32C
ybc18cGZ12RtWS4Uc1UDmLgnYsaoy1FPnZ8n8gMhU4Fe/xiFWKnNDOh9juCfRD8QBfUrtKAeVRNb
bW37ANeefPCJv5mJyIFq9vJ0jxG5kHTDyYvl75ZGvRjOF+Ms3FANcMBPB01FuFaS/VV6VHrd8kkQ
E9LflaHABknPTahVVe5SyWo7GAVJG2D3/Klf13UnoK8u/vZWYk+qWVp7SagpcK637h8qqxP0NQK7
BaKiK1xdC24f8Bj/FTcGj7Tq7RfWkBm2CwPf5A4ZAgu/Av35jNLNohHrb/7C6KSIE993lnyc/t83
Ey5P4SAMmqEEMYZm2kAdjQO7NljfmLhRn3Qz9HxLMWxIevNDIaSIp8css/6GC93vP0cdHzu3jbyh
BN4qS1a6FPncJSUCXligWRyciLbKgfimsPSdlKp77x37IG6YAJ9nx3FSIVX04VOTwFARBd5Den5f
/reVNKN9Zufa2HzluIpu5Mto1odXDNR7E5o0Ixf8hwoEUM6NnBdsBLcx2cLmdd3uDnuWvKnjkKhi
4l55mEBtzyM8wTbPKMe8Xh06/17ODEyeslGElil3SN4mxiNnj+urj0ZiAIYZP5W6X4/92QevSRSr
jlyzGg4bu1gZmgLt1h8whdH5xen5zPTsc8vfqIumneeBO9JFttJWPJ7DKYjAt03zw0x/By46xBCK
1S1l8/ZcDpr4twTrl9KiiCYT+lQFHOiSnhdfgEskpMhN4VDA0BCmowhJZZqgU60LL1+oIDliIH/8
OnS+NNCIX7aZ6QQJ4IZQ2+2gpVVmUS3E/jkSKyIRsgTtGb/rr2D0A23sJ1sdXqj0JgjP890voMF1
IyJ9iFKV7gojSPCfW7bm1FkguvrUn/pUm0sDwDd3ZH/EQ2VLmO83WSqqjbz2/OmXk/6zDZX92Ul7
cAEpE468IaD5wMaZDH5IooVq03L2yCGP9goXgthLHt89QBUPIOZRuamCFnYmGOl7Mduasa2/3WyT
5baa8MRY7zC24bDe4UtpnRKaRD1+7Qdg6G3CP5FTdY+Y7BCfrnRENa1KzCKBmGCRy0UfNi52nQRb
uCCMC0ZQkqG7ZZT+JeHm+y+efNBFm+ptryu/JZSd/9DzCMOGyEGcEEho5S45ohE1V2kvEba8Vm==