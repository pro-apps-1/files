<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvZ3sHbESo9U5nzCEWoTj4Fbh/x86B9v7zPZLgwxIMO2ugXrkiSfRpYKjX6uTLSfxeDJ3RS4
zMhnyZTj04UzoEteL5cPqqTceKBnlqePRI/eUmu06Qq9Za14VBkEgiddCG9kmsglVavM+Ku4NTh2
F+Q+0gjFDS+SGsmtycHFkLIiNlekEcLesYzKTBJtMjgi+5cZo/kjUaGuQ/1Mbe9S3304uB2tUoap
UgS7l34HoQTdosbC/dH1N70GE74Nzr4QSno+PiPDG9KZFqh4jKURPiTfl8EeP43SEePRXPtOhV5S
6B6vLI0FVyJi1y2oDsV6h1gf+Q0+fDg3lGLPw5vTQ/mVSIBN9fKGJ0DaTmIC42QxPgynpJDqipYz
ApYAEA8E+mLk4ADJQ5t2dTkEv0gDodP//SN4a2Zu+41LC4cXLMN48gvK+L4QKfl6vbp1KvQQHAtu
9oJRn2W//4MmGGvkPGAC2Cb3wrsdFqIQ8cldf3NBlYeu5TYs9OCcLr4KR3zcqjHSQlEyViwgPOBF
q8kgOjavyLcsNv5L5USjdAwqmY1gRmTC6V8zE6BCLtks9xuWAi8bwc5DqdHXRCHCWjWVbxCGEpbC
+MC15/bKXeOz5HwfkUHxlTYir7hL4wRwHfBf8aEhIctSAd7m2+k9mvj2/o+hlyu/MhvEyZthjuKd
0NURVNcvL7dTcL6Kr3W6dSGU3D0XvMWHq/zM3rITlVWVFMUzk0mezkDMIDhd77m/9lGwLHBkdbDZ
R2ADkCDS3eaeKI7ycYXtMtwksAP/ja5se9FpGmTXMKzdYe1bCwWnKCNWkcLwaumgBUmlDyo256Nb
SFv1DyXYgFesoguhvZYC9KO7dZgktqWQPpYi5ZXw/3gZZYZSfKEweuwO5p9jaXUTaAz2Cpr7IgQp
MPHDDDj+HsQdFdfjFQ74t+UFsKR6yS/VFJ5drtrf5M94tRQX6syN7XOMwMSJKrnkS4FhvDsico7v
UYRIjE9ooABKBxQLcmfI3QQXmp6ImyuxyByZily6Up/UwxCp3xaq0vu4wJM6PGmWBsCan7bBQPvp
4wal6UvFRWxX9BFQftrVqMlib+JRFIYqSnDZqNLywse1XeCkLZ33fufSOwofbvCnbmDWHgmd4nCR
mi1J7hdJMm0pnkg1aIgNqQyEkj++ysoysh5FV/qc0rQuKc3HPSIW7s1i4L6H5JtdV+tpufjMThhG
x+5SPnTPedZ3KAP+6VUEw/5bKs3cgGVBtzkIHCqnOfRwcZNKcsj5q5HzaZ8HtIjigfK9Ut4l5IEF
QcO4iLDe9GxNtlvrBq7WJJI6RzYhtVpmKo/qiiawPInJoaNeHqPxti7GAcJECVyC6gMOg4FdoYSl
ReOA6R6mGXqBxiFFRlUm1Bqzqh9hctXhabxfoLfXJRFMZfhzHUbAlZgcnBfQJndplGp9aRhyQiK7
JWxWf5FI6DruWXIbIb4BAxQcgZvkGP4AAJJvdP8bUr3T/uE1l3rVia5RGVd3PIL8a6thPHQ8eM9J
i7mntgx2Pcthyi/tz6bOF+Q/WXMSrGRuufIT+Ez60LZkxue2+V+KGesn24gweIrAosNcFXDJwB+q
LmKSBykKcjQ7miL4/Gw/LXg/8Sf9lL+zezIhJiWQF/9X3roPNaWBICntHUnK7e4HzbqLXFPuAMTs
3asSfTEMG6Xa1nTRTYJ9/7WNU/RDdi9otwLgb8dBTviWxVbkyiDeh5Acq1Rv5JvJb133pRT76IXd
oqJmsCIjOW7y6qwh69WrccKYkrnlesPybE18vX4nBN3N/VmIyFUUKef7mRttI6R6Pzkd7+5Q1hRc
1aKYERkrWjpJVUJEsz7D6PVkVFq8VM3RFgRw2vU7QcotCYjXFpQ5Ke0w+GvwdqlPC183z4/3PuHL
G7gj1lQHCM0GIrkTEEbGCYb7AmLGzIpCH8rTXZu6pVNavTxTLePmx4bRdQWU0o4ni/wGaw+PXNSr
eBY6MScG4AKR/DH5cG+qdfvPGb42rhKkhNIA3KmMVv9XLORNIhJu+g6Szhc9ZyuGL6uhobvCd6Pm
nKo5xF1+NjTm4vYHz3MXemwZ8EntkONjrFbVNq09bFHOfbPpffgH9L8kHrJl/7Y629iZA3g1WAR4
MH66k1rGPZhWswP9EkyD4fvA7XC2XTC+GY4Slw8VLva3QjwXQtoydib541VBgr9usv0j5EFClpzq
WRE5Xaz1SOrdhw5JA70mGRn2g4cMjaIYAOMbiJEPc0kT9TNyaBPo91+VzBvtS2lKxVeb/G8X3iml
G4RU53qz34c/q7nlGaQgnTpBdW==