<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzPVA1Yo7f5VIuEzEu5qpjOlwJ5eAIA/llShJpDBltfzTL9u4T1T0aK0v0zd68XESBixl9fn
FPTaEXv2o0XvQGOYWI4C+DTmWvbX+ILxR3Hndy6sL9dyI0n/5HugKyuKfHpFVxGW51Vv8XYPQPnE
DYPNkeIegViXlBMDTdFGy0deOC9vhHNr+ni4SkPRwUh5UWiFpJq59TagFv0IvvsEJ63VDBgJIsbZ
nrKCYM9VoRMSvPwrVBIW1AuRUtntNuOcQ7ZzJ5Qd4stHIYDDfEAKa9Pgpab4ws0u42Z1PgGUArSx
SIr2mZThYjU33Td2dqBSeuuGG0OXRCOxVfGmJxuu0gfor2zxGa9nkMyUuA5jiQOM3Zwxx7HTUdHM
P+9H2mHVfBqrc4+HRDq6xYmVUEtWP6SDL96oa5CpGTd9ctvDdb1tncPTzzF0gKMlvLRW16PKODUN
Ev8xBf949JMNHZBnRofZSVtIy5WLKCF29fmqhqze+wBwWrX3VRx9DW3FFedOx2oLr4ZgQtqv7NjC
aa7j/v7RcYVn96BCzFKPqg0elvNCd/mD9kOFMAdL2xVmWVnLO4jwsmIJXero0JdQOL3GJT/QVkpP
bXhy/b0JT7zyP08ToMrbLgKajazaKBAXJHRql6N3FNBqJqO871YFJ4MbZmMQjG+0JmZw4LebFtho
TE7pMuHXg+CE6Se///rZ60cQlvDw7qQ7RY1VDYWP9awqLnJ2QzAwcGiealwLpWknJrGFXMDWnisQ
QDkPkxywpFCdkuyT8wgLy6ifYIU1DxVOv1Y88Kp7j+VIv47e4fxShRvOYRMl791JOfd+3ag58u+5
xkOoho2n60DzmJwOdqTlhIfWbGUugqSe3TmHIOY2BV0x6lHvpCK4EtXoqcQJFcRphZUZY34RVTi/
7b2W1YT4JkCoUyXQQys2cboTNd1SpKup67zHkjiN2Y8LtDanpybniUI7WYmY+yRdPBibL6eYOEtG
H8Iy4CLDCX1vd4EKTly+20T3DevMVPtZ/pTDdPdtR9SNB2JgZ6kpkRmHNGsrHL0FVSmBorq1HuUT
8pCa3j8HaMwAbqPjpLblWIgnl46PHa5pO/81+432Bd9dA1ap4LMMBEmZG5r8DkzWG9gDVK7PVKoZ
sGJ7Rxz++QmKfXdMLNOZ6B0B6+LJem/XjEuQOKGsHKpF/350O/08P2H1uFwgw5A5YXAnGMPXx38N
SmsUnXMPOPoK11+dG6GhIlrhBzTSQwyuKtRHw8oEpGykXTdkZPMYjJvR+QpLNqb7SyqGNKJcfd+Z
53ILQBCmziseSyTaP4r6vAj+hH8duXnHur/IbBe3Nws8BhAYDAn6iH8i/pN/TMH5X5BTi0fpu9Gs
iA5YD05cMD54eYzZM5DDDKBYZvm9+F81vW+3lFTMERF2zOphdCxZ7alKdWdmfhJ1kEpWJMDRvtsS
OfDHEwp4nKWpofq0Mnn/jE8tn9J8i81LxuX1wjWkABlfnQI3krVGz8cypUaE4Y1r/DbcnoZfBtLB
juJL0pMRt7whsSWL1e+ZJWuTiwpvtJzOcDf59UCHlWi9W8pTOLbswl0Lq8Ss7YqbwpvmwdB+qqRD
WgXMgu+CPf5PglsbJDF4pv1aKJc6S5VVJk6eXgtZ9Ss+s7/0gkx3eLB3IaVsgiD30czGZe1e7aWK
bs3OxjwXnhQB3N14iHyoeV7SKpeXVnolZWR+GIJ6gpHK/FNGg0ep1e2BTjqDtYnA6UEfdRKFSG2J
Ube9CgPG+06VN3qwdw7LzekI5XFQnseeDEVJ57iN+qghg96KvZOLaylmvEUZomsvO5u0Ms7dcuIb
GSh+hc9vJ5+vhD4cuvtMD7GQU31gDetiKFf/cc1/g82DGu//pS8AhiH3W/7NyAR5kyoi4ajOzSbg
kBPxtDpuPdARI7rbHpQeDX+ox2XplfnvmA0NiB7hBbVz8VnGqDp8gA6czXMI4F8icVfjGzmuaKJY
5LBcGUcOblCI26LMGACY+Sat09HG1XpkQ7xIFcLWcCXqM3PWxZGD7Y3qgNBYg6e1MbWpNaIkJfdn
aByjAfHGPg8q7J5xHtbl9ZxOFuUrNVDlGcpqlAqayYIyTbw0sg2wWUJ+EleCf3xqx86n5J65P2Ft
4HYn8Yk5QfukDpC+Sh/kQEzFo5JfmsYu7u5bOU5HyrlOFrgNj+KD+jeeCIviSbH84SZNRxa6JHCq
JlYH1qENf50mVwSjd99vi89UePoMvewuiYhyPmyk83IiWlQS1WnZEX6ekAyIqfoPU/zy6mB2RAyZ
jWVL8cy=