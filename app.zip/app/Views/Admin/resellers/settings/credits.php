<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzCfooSkgSy8D/LU180GDcVVl5z98ThozEyNVzfPohoGrOQiUHxrQ3fZXsfCIJ6mRuYUeFuT
ViC3eLDn2rytIePpx7MhBK1WonYhjJua6LTU1KhzXYuujCOH8wWLkFy8ZJr+cnLbdLfFmtjyEPF5
az+SzJFzdZ3nobdkaLSs/WUuz4gaNP1KSq5nz71HwtGsIwBl/uvDZcXbXI0Z/5LHyYKTUFCDqBV5
0lozI1dngarPa8ehER/AGtz70iDaRpHbEompBeMbi2AXEY+NIVLnj/1LIwfOPJKG1SkL/XcUqTjS
JB1u9V/PLTf1oV3MIgPtpFUtFogGYsmvpJXzb8+hY36xU5jsVy0/m1jnUz63iOvorYwVdr+uuYWQ
aPLwPWfnbxrk0ORJRFCSW1vgbJA7kDnycks94kFYg3RBFbrRd1+wcdiPauFkCi9dwRDxQR+0W+UL
AXKoHarW8R6kNXAxx8YLdPRNbwW/SUsv6Snt0Wd6lXweV/DN82aZz+BoYVwVZ32mC/Hfa6v8MA8D
Ts3cNt41AhjGcLkCH6eSHZO8L3W+pMBNN4bjHTkuAoQTemBtr69KZJfNkayvZ8keC4SaZAI6I7L0
PC/n7yFjkdJKFV6w2fLZk+C8PfKty2U5W4VwiCevX+iC5m0Kb5CqyuhKje/mAkkTtmF/jnhVseLe
Z411fKAL5j+ph9Ch8xd/kHm8m00BDZMhs3Y30GGqyavLj45+/4eY1S5idHPn/NUN0A+BdhodA5WA
f+vzPdppDp7wan6NcXOC/3vClkG1w5BRuFviPb8Arw1v48uemPuL13jF8EiUt44SXTuCelkebWJi
SrsybkXuUKr/cUC0TrEDhD/ArB9KBSOVFsIOifQA+8fAOSB4eYuD4o36TPAGeQSmQveadAODqu6/
90ujXrYXp6sHCn77vjMrHuGqM39Qe92n/2KcyvrpDzqJk/b6eGhqn9C3UYwncynulV1lxnEnaMzn
AtBCCq18AaJybPl0J2t/6FEL/uSX2dKLDRQg5aGta/gHK9JT9uagrTMcLJeslEP8mYYq4y7eYNYM
cOJSTR24jBc8L3g4a2RG3ILop5l7NPErWnhAmIvzW8i2mEVsB3q9d/56cvhpCAuT3pInJ3AignKd
Z9GMItAz0PcrWbZb+DCEsIe9RJjrwOJrdcFcM0k6vYfYSxBpfYxI07oUYB550lWRY2B0QsEFXeYs
eXUIej7NZd6lbCwhaoV0qq70kjUbW/TAAEJhnWpZknDkBpZjgEfKDc7RfZ9atB5pmAnr57cHCkVh
Dlsh4F4MHb60fWvTEdMbFIAMHQoeD9J/0T9pP2HOGuig7OEKwobugdYM6//IMQjOQw4gdDm5J8SP
py3axxGWAKnQaRONWtHcLS5yHXgOdveplvqAnswpVjXek84l7OthufXv0R5lybxOxurujtQhgCHy
IafpeE2MbYMDR37VbzZjuvR/5GI7u7kzqcynVJ43vvHt6p4LquTRZiRt7Z1VnmtspGREtbDwtn6V
ubx7rRSKzOaJSfRVUGrEBqO/oFCzdHD3QbpRy3GV+gvDLSFe5txAjGzgcqbF2rWN1udoGvHpxi0v
b/+u+egzWe9J3nt+zHY9TUUwMZzBttmoS995pG5OwMAm+dbyKMvCMb3lFqEG/t1ZCZLz3+aDgATj
bVpjYaqLtDhAY8UBO3LhA/gHqXc3//2C7t4DJXKdRe6WjL613YmlHWLwsRdn3mWXw7aVOWKJGSP+
CA6BvnRJ0mSvAHIJ130Lq9Bv+E+bX5Xt3lWUiXgh1LCvebznnwRx2XMHBkBA+1Fvxj8ZVWcywS3h
GrRBZQFV+mPQRHRE4Nmh35BJANtjt9hOLQam0n+sTYl+OEs2rF+lxd9z/G0aH6XkKrv8Dg7hTM2s
hBvcgPnCKVGHfvZA47Ax/pxSBf2kmB+hjOjyVQLOheg7wMsPxJImkHMpugHx1Vt/nqfBs+9x5ui5
CjQ0A1uC6CWGcXISLkRfYew/B3YrQdliW/mr04fWYncQqEf6fCBZN44rBQtPytAg3fCDbcyEzcuw
VWJVG0QCaJuUvGJ/ZGwSj4HFajXzqldN6dBCvHbNK4barMZjxubPgKHnx8sat/YBRbxkm4xJdp8S
WKVbca7g1/BztIwDkpQoVi7J34i0XtKX9UEHEY5JSk5WaZ8XfU89ktST8JC/EXqaQraUmZ5s5v9C
ll56aVClRTQn2fvZYwtHbuUqKObczqYKFxlW/HKw8OPDtqrS/C5/BwuS2QgbrvMvATbt/tm=