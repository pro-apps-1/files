<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvXp7/5wu+F60w+AqkgDaBflvUbJ1d1LnzSLUL4Ga3RQqArH0raITzuTGjktkjzcuN/v3eFS
6EODOyqYjA8HGb7ANeUIqyp2Tb/Cy19TpnFaku1ePHf+GKgioawCWLklljzib4W2yjthi/jj4Cnd
r1keTHu5Qmh/WaRHL0Cd6f9SznkQnDmoDM1P7k0C+yCvrXmLsYVemrYYju4b4bZRCIGhpZGOKaFo
VDfoIpjj5JFFkIAHZKxwj3GqB3ck+Cjudkc/Bdun6RP6XlHJ5iRjwexuwUnL66lf9G0J2QGTfvep
IGAnXLp75pfSEURCHrUBSNUMpJ7qU7QFxQe7xyVJ6+5viWOUaJyv+wGvZ+4OTjw1EAJIsW5726rw
Q7JMc0DDtb1FR8pLhh++2cOCEkkzQufbUtmjFbfCc9KOehdbGwc2jfa2/Qxo9dC4uHYJRJOElPmn
R1iqVS5u60bP5cRgi0oKMonYLM1D8YywgnK9YxKe27SLnoDk9SyUdyB4gYXQX9/qnZdyjBh99i03
L/pp3ffntLSncKKmr5aer7h1sZEIug6qi4gmMc6MuR0CN9pnP2pEqlAEm7S7ugGqmJEpKih7bsNh
aBHxrIo1LkQZqsEtQ7+QdI2/gIidKwxBpOJwUGhABjJO7ogCRnYiGlyqnyHQJ+sQ/8zkd74jmrUk
maF/1W31iy1rlGdCqcZTfgMTpDXNBtEu4rMgFkWXwZUdhKsbU2DcWT3gM5L/RjJOFTro3gDzPbq5
1QDmj2pQzBkOk59I6GrVWu7f73EB4eksgVbXWFnTBUB02qWmYk42loHWoji7Id72bEEBt3g/zCbG
8Lf8GHLp2f7cpynfR2vg6RK9szrOJc7iYgRjd7/hVn9rYrnk6fzNqY6Yt28MUwXbia1mbfFZTm7u
5y0Vl0k8tn2Nrr2gWKbCsqpiwCSDEcot2cPHtAhfEXRDe4RyNX6COHyjvEPOGUFRr99z/NbosH9P
QFcO2YoQAEH31V9K/pwEIvzWwWZ7DpPW0sOvGXmb5aiXJ80kVO7a4NOpy13SZSsD57hAk8KMgds6
TIFkrXIV9td5tN9FCYFIZctUxC2ARd43YBTSjjAgELt49W6p6yxtu98lELWiyzAi8/vjF+jcNN3u
KtQO70SdGr69jjcj11Q8uVVNai5p9UkyW2X3ylfuazvNrdm4u5EuHQjvmEvZaYF8SzmKcr6pkeeb
1UnSpy3paCJL3rjpyCBkK46I3h3i2Dqwuhmm9oNuGqZp7bDtffLZdFlZX0uUlD5p0Y8EKzhRIBeg
1jrBf7LimNWEn5CRnAPLWysG4xNkIEPA/FURf3yZBG2Q2sknOONh4Yd/90fVUep6vO2QPu4lFyqD
a9dphhFrOD3cDMxWZJNdURTUFJXZI2StvmSXsdmHBvtJjmA2lv8uKQf9wi7KaJ3q7jkf0PUa//9K
XPp3pAHI9N/lmjbOwYyXxtCcaqi3pI3x6vzDanuTNe8tdOMUZV7PwpiA309xRiLLKJsLiVgDIV1Y
9vXc3g7Yq9p7U6UASSlZejy4fvVFIQoV1DPNi/xhdvRBsFxd2E2C7SaR/bfQu/0mqD0oZa+3uudn
G7m6JBSIILPgw93rUPQwdAqPOyC7h6rt+JxdWkO25SS2AzRf7WxyOFC+/CFVwplxp+6QBFDNK7N6
gKUsJ9fHdOMzYGruDmQllbE2nuoNzo3uHM6urvcshU4fHbzsQlz9MK1MnhaqcxqueAOOJ66iu1tl
BWG8x+CP1DU99VoiZU64Hr3Ct0pG9BPaIPbPGUDtVjhb7Y5pjfoa1NIiSlEWhcUdq8/vV4/Vqxst
aPyZZVlvsX/rI/PzSAnxP3WTY9C4W3N3E8PGpVf9iUrithzm5NS5h4G/PKKBT2ehgJw0dBgwoY4/
TazdJ8XhAS6pdBMxTqcCvCtTRmLVX7DbZu+eVGmoygrBm7rDnd7mdc2zL2VOwbIZRdqPDFpm6x12
pY26huW0nnkCTa/yyjzKWXziA1owIDlM31BRBxHmgi2rLUjoPHfTU2Wlw+CQ9o+3pIZAYCfovrG7
7AkBycQ2MVq2/t9Doh4k5cJvvZFAzzLu/AedhPgcSGqLnuIb0Ibm0LpLUJUUaVmmV23o3lrC7dmA
7kPqcL8gcocGk9QpWRYHyShHx9lneCx7zviTbJHRrdPd0SIMKv9MqebkRQhy+VAcLipBbCTpjua2
ispdNGErmfSARwj3A1hZlXoO212XIw6E6v0qvemBWNGRWpOHZV++NF+W+se080vpiFZZ6svVpfeo
wtEzoUpVkm==