<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxYsfTvI91uHAsem/PLodm5GSkrt5s/D9PkuI4fmwoqIRZc1cYVVKNFONaBcaQIOKyv0R9W3
tIDh6o0TqxSWUIj+WACp0qs5YRt7yKoNNvxvFKalqIg3sCsS6xdrlpj3pmzMAXN6I+CUrQPfAGFg
phGO0+NEOcm/CEJc7TZcK1FYhJDKoQZAFLhItb4G9GNvMTic+j79sHzUznAI4VHtsSbczsO8Ay7K
6Cb0QswRfbyYI4TJhYL1SJivSwNzR4wP06nl7nWRo2Rxs85Hakb8U5GQAw9YdxBKlvXtY6VOHy8z
OdyOxQogOyonguAYgnLVG+9a8uu9uFHSVxsehLpG1msV+AVNSBSvlrgX3AZbR2JcoIjU0SFZUniU
sSDUBzP++U4woMn7r66/MF17KaXix9u7uYWvvZGtg2Y8RtiL/GaqtQu0Xsvd6WPbAHmJaCJ9GUiY
O2PThXv7FJObDg2X39GNg8Lr59lzH+olXbq/JLXncCnX9QPFXTtkQl4P5BCpVp2YC/H3FcUX7FJ3
+Zr8Ses6j2OstVie4FT6xYiz8JU3CWc8Au1IDrhy9pukEprjh0uxh3dvbsaBiIq3ShVx4DRa9kVd
qbBPIc+1DxTqTozRN9XX017fBYfqiIzEBg7ZtZwz9ONQKJhLTIqlyJcob2fi/J/63jdMBdUVBxP0
aXzOD9XNw6CAcO8FZcDe2PAlOU9kBF0ooAFb1F3JJdwjqHbo8H+IMXNk0I9T0janzswbOzhdZIZm
a87fNwoVsxEqys9PtoGtRszIRm7eOltGacfnPtjC5sna6kHrRIX4hH2dD6W9fXr+239idJaukFi4
7km4XTjHHxO/ktaWVD5yARs5MX+xgtyxheElZM6KFihR23Wg1fUxvFqMpwXwctgicmlBfL7E3hCK
jL5XZ8cMX/tfGOZIlk+dg2K17zG9cc0B6PETwiQkWFJnxR+6JRxTbY7DiD+L7mDENFkBOau73eu7
l8uTQux6V0UQeLV87LoLFlyNMeTgXpes4Y62mSRqCkBu8u0oNdTuInpa7Tt6iTKYCokLgDkoGYoz
ECT5uDbV3bs/TVLhy3P8pvtVutoLnkyjqTL5TkcPPTE2F/HbZbw24HxCELvFtUpxCwVu/ehB71a0
Nqx6bxVRUXR1EN19IuspCh+jKuzmlb/1ugZFdWwslMFttgDPgnJINdp9xabWEYm1k5Qo3evaPVm1
V1Ksc4bWdR3wIg+Pw5NEOyNb9p3gi3Ts5cIA5g4q3d2f4MC0HiBAkssWE6OUYQhVjY4ec621hdEq
dMK3v0/Glv42zj7wR8aES1tDoTJ+c6orbnQoiYY/2MB6N78sD2w3mPhBI20S8I5qsdRnEAtwD0Is
RrqbGXzGl6JtAvTqt1kOo396JhGl4vmcBGEvxGADYr3POwzhsOtTfUgPQJQ2+Ot5dFZGpFrr39iF
0CofsSISNPGziYXot4SqxGfVtApo0atA1j3WLSGwuauw4NkeTFFA1UVHjASEgENgg9frGffZwiCO
wTrKTSibPMWT5S5kcpC1iLbvqX663485J7AfTx7PlxNSHvGr05WJI5on+N7sLxe+lSsUdzSahsSu
DpZeLASiCyUCRVpK9kGDzunw4h026bJVeoKHmyie16YAVL9LyTaIdbM4+DZrKsoKM/e4IiQdeceA
JPc36LL2WWcNdUZgvXW2HLzcTBDNE2UKGXY4YzbFmXHy0ssz0nQYaWkvEd/6g72AB7RYWLnVDkLB
hI+CojF2Zvv8ZHE/PkGVQ/orwlKGWHFpKznPRykVjpWvzvplfP6lUqhzLeEqRjqDpKTUi91WvZOe
kmDzQzopl+cv3XwrIgavsX0iTRzJiJ2IHw8W/yp6MVdN+6G3s6uTdlhVlFQMwndvvzNRnKQsuaDe
/uUh6aXMv+5CHmqwRY24uWzflQJxP/juyqICIhvYwbz4vnL4uw+s6fn3AobScKIZVWN39TKb2lix
C+LfgKgvpOIdYY7aNXDeJwxZrb2Q92qXrMq1t+Mrl6NaYxcdtYP7WEpc4Ohw1NmYHQOpwXSqxzuM
2BDsMDg2/N85r9P/moEHcZ6DB/6oWbdfVWhFBB3eMfFfjy85TAHhDxXsfWpBeeXqE2IA1DXVeLBi
Tp9hP7FPiC28hBJ08Hv+YRPRkVLcuNSSpmii0r5fb27AVwwg0KC9bR2bKtfPH9aCq0vvUZiVQ3Nu
7bRsX8qXwEIz2GV+EYcfOPW5nt+4ggSwow+gChBCN85nrFI0pTEH/ueW7f2gUN2zAB5sP4bB0KpD
xtMrMlZZ6OflTxOQtZ0D