<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoFA9GSxY9uemXQm96k0xr1KiSZLufBWE9Yu/TzTlSBksXfzgaovC8Gg3E5Ygo5s9uuhOjiM
OwZnUfclqy3gv5RUoIYBt2eiClDvqqf5X3lPFvdeO9Tj3/McmsaYeS5Kt+qMlB3EEMrjC53begzE
KEytWE7z9TNmarQ7NXRUVIY0cNBfWtdBITNpGKgBdTTDtgCOoLonrjwnMj19/uYPbuW0K0u1WfAU
yNYLImr57Z8EWQ3r31SX4puzB2G1nZylNcXoRjHLK0sFFSqLpROcz/6WCezf8pDmY93xgqjyP882
/KPA/xxxB60iLEroSLYLlou8W4wSYHmEG5a32aY1F+RWnA6qhE35RYLImXV8DE/ziGY9xoAbM2Ej
J8AgC/M4SR/TkXyRZVtM6Exfkj4XszPviUx0Nsz399X3ibXXCtoNFO2n+nFnZgN+179Dj0Bw/agi
srfMOgDPPZbtq+ALkCTtcha0Ae8IxuSRlN3d1YPhmTDSkWNVZ2pIffqnlilOFWgoB1lATBSGbdLi
xJYSY88D4cUcCryMbH3fvj+e6j6QLA5wcY9vk5BW/Hztjwsycsdf93ksU+JCOk766YUwGDq6ixG8
OGYSczjwz1fJofAFufqpQxW3I8OwvUeK+KwKH8jpD59ztz4pafm6p7vqsLjuiDSnE4ZHW9QKf+T9
10R66xmJHjLR7wQpbjrOklZJRvcaxUAUYxEnsYyB6iTeuTe7CNBOv64WBU+MuNuv5Q7jNVjwi4lK
J+EMQXU96vZC5YNKdXjsmqcmzMtmCDraCkX0aLXnwBPaWUdVItMnSMSXD36IJ1yjvOX9HKqc27zZ
htMmBVU+W7cuDY1CaFN5YqVlIHFBg3Zhjy46gx7pCMEcmI8idy5nKpWp/R+Z5pzdWkfgPwHjzST6
9zoT02THCNIp5yRw9lhp3VcUsr+fIGsFZ5uQDOwVO5TNXbv0LOAW3WxwEw0MYhTYsNs5/BGGhy+I
sDBUCoKWNpgnNV/MBuYV1H6ppx/CHgGn0rQtQLHBh1lpNV+L6Bs0XpyeQSwsd8vTd/TxN0FHqvCs
Zo2cWH5vEPQ5wrJJxwxaPS1LgcCAWxdFUbrlF+mfB5JJQ+vJE8hZYw9UliC+eE8Ce7VFoE8iV83Q
KHmj6BVgJMTi+l+I/8faaTcBC21MvAfTfhhFJw7NDjnILsXKzGbHyBSKW92G4VJYWTAjysh0UxYd
5xnqMlRF7oPnwg2cAnaDWZL/FatUZLtef5uwYVl2Him4W+ck9n5CXHriE6dOqbMPzvcQusUaUAdG
h/eBwcLCXcrb7xK8Byqvuvi9ZKqqO78kvcRBe/nTmBq8RpFNMGvkVD7Csh74Wy7TODwIV4e4dzYZ
kEPdGNpyvSKK65i1pcka/8VUz6L/SZCP+vKtKE0Fqok2aSQQXRQA1YTrRsjT9Xnvzr44cGNHavfj
WITaq5I0Y7VzYOjj866U3jnA0xxyQkVCJvYunX92oyuTT+hF++zIEizNhYzGOzBl/X2EjLg2fBhk
5nBSA5mSeZPKuPVaKdvzIFi/6I8lHV8OKFr7cbLWNMoWcrLp0tMOZ8MXJt0GuYt/GmYVeUnLyL2s
cQhTOdMonXE6ZoRvsKv5M98plR9t2aen/s/DU2z4pO/5SoJAgCvoROpuDXOaVKUMfCv/+ZJa/uDe
BcaiGLX8KHGzb3lfro//pvKIpX29sYEhif4M+wWpJQqC0+t987Cbflc2vByYCZgc7duOk26Cxb5v
s4JgSno3s/swtgeR1EjwFhX1Ukc3ylm/9m75UXdU6bRSFSBcVGC88ZQRujbJYYNz0JOA3t80LiW5
bbfA2m3vaDKp1wHl622qdyZtx/uuYJeKAmWqeXE+vWpzV9dXEXzaTOOBO8llmw2lqm01vwcNPB+l
nT1Iqyqk/jQFSg5Z5t488sZLMDzrQ8akZlzNcj26AlhtidGdGN6AjpBc35IrERikn49ATbnELN5w
q6grG64ifyRdjp/OiccOnyMDJRuKNPuEBTIiVsJ3bvv6gMbcw4HgpUb74xG4TgAsXMgYAWV6uQ/i
wqheW+48x+y0kjBkCGA9/acg4pX1UnSxPGl8lf5T4/fRDqvNjqkzq/eIdeUJ15V/kV6AiaPp0Ckx
aEs+bFfBUzdAaTIa/+S4ReP0IIpEBOuK18kKgG82VXAuT3E3j5sBENmP89J/MDgDvp3moeStP9n2
K6n8S4pttLH5W0jP4ikkp07L1UAxqbGl2Q/E6DoaTqHcfuijnYm+r4mt3NOolHwRRIZUqm6zvUNn
iG==