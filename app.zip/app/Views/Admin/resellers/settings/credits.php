<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrVeB16WRfKclJIvCg0vV33AHZX7+LRMtjjCnU/ZXRfb6ZUN99qugng1qAXUEDemqZqqxi9E
J9BpVdyEIeGx+S5usNNsZt8l1V3sOVjOU0RxmIfdxi42CeVmIjzvQCESZi9p2OMPCOjhwg145Gpd
CtQLJdPWepxzBDGk7u0EJ8UbG4p/bwM68tc0LhHklk9QjTPSlqCPxT3R6L6rD/B4xXg6OUTfSjLs
eWu+4BllBc0OdCrBZsUmRaiHrgUjeEAs651xBIeADpHZv1ITmSJY4lsWpyFzQIN8Z8jb2ifHkOBc
KfYNEF+92GJdky/0orC+fCRLkXqhiFUfqUXPjUo1AKOVM4nYPmguQHxzROxkpvSespDwEHR+xQ5u
233O1/RnT4zgN7jTqf3m4+7gwVra7NAD2ezOL256dc472ghe2KBcPKS6/aNnnt6t0wYCuT1R+6x5
af3qYfmeuJu3mlZtBJ+iKVwg2qpIR/FYroNprQ5QTzGn7ycJCX3RiQ07OKAskDLS/El51vb/eHHM
9BTHsg9fie5iHJDBBjdKoXVwknPpd7vzxAtFS5GKRZM+okUi2h6e3zg6xnkIKyrLrNfPl92O4wfl
pmWWzXYPwfxYZYxAmsDtoqQrpUCPmxmXHqnIi289c4em/sUgdf9ij8b4aroj9EejNpsuWdZhEM4F
DFc9Dxcd0YmPKu3EmKQOD1Ga/I8EUubmt0f96xkztHSLWq6My5o4uGZ9jUB3uogcI5Se+wh3N/oF
Vs5WLfxS4fY172YmnhGAfFvk8OVXI6KRSMpeds3RlKpA6PmcUTH7SAebONrNbpKFVYE5GZJWc344
T7gJDQHsepwnzTmCqcQdG3y8qFDKTeojHU64jUvZSkjpR824c3ZA4+VAeWpAy1w1YCbvB14lxbmb
WZ4QcltsbKc+y/khCLdSNeOY/Dh9SsgAOpOPit0Zp7GWFuDNlklaGVFZd5okjoch2IPbjAv1VRJc
s45fLI0iMVWXy02bsempu+Qh6nkKSlv4PkoSP0dfVJfIFiwk9MJE/n9mhYLVmGTIW/o0gtdIWsf/
FscDFSqOu5Zdbdf0NQh7SncOQX+ZZN86zajw8lcGsZfcSQLguPpi62cM1GP16mlpIa4MJdFtjGpH
QgGpbT9/NLAEK1kF6q4Fd7Q5RXb2HDimFQ5bumdDs0z7A0MsguTmBJxYYU0n53rUKLtRBk2GHGoy
J6RcPGZjQ8TnrT5UUkfUMw89hYxtkcyVGUUJa3rDezCVXoUZo9NcY1ZYxCMNhABS6isSUs+Fw7Eu
dIlXwKZcysWEMp8Og6BYd0wCVAy5qMzAg3yFx8QPueQsnJ7q5/+gGtEuhNm1E8ps3oB6so6a9uej
QqcR0onl43NjszV9NPtZcAPQeJQZyEGDL0xsSo7HxS3JuPWKAXwkrpNn/1lCJN0tgWINqqEAtSoY
AaaRvz2R983K7FXeBDocw1FS59CqTk2SzkWqClv655RPBQ1Nu9ulU9bJKnsTd/JeAoKufNYv3V73
L10F8px/XLVr8N3GM0rYWT5jqHAxyeugkGbni0RSssni5YWN4Ll7Eh091Xc2jMWHnNvt/zmEfzoS
h91JARQ51pEDhkvUMiPkD0bipMH7qcYVvVQdF/fKf26aaVneI/vIk9M5/zHt2JZ5YhED5W6vt9aF
YTCQhIMslUnx/tYIBlxelerIBdriBTElRjiKQloQ+VEEenXwDH0KsSznaQRfjRau0CWaed41mPAJ
d/ZMMc6TPCY7l8LMgP6ZaUUxF+ToCt+PY1+Rm9GJpqjV/tgFwLYBZwsGy7SoIAL0tMJ+6lyzdm91
qa7SoREeNlL0Esyk8Yu5HnNF6atTF+JStGzYmyZ+b2Pmro217g6tUp5EML1P3AfYHHe7H9G3iYRY
i4HJmXjkEe0839OmpzF1jx/OpfWzhUJCog3ivcsu2UGgOXA2hhr55Keh7vbM5+ki7V5OW0XDNhat
lLB43uy40GG+HKk9RnHtTrCVAipCuqwAx9dIArau/vU4KYNj14HVrEwsgVZw/6jfDTufKDSMc+1C
ahZdLOcXxXZs2FgQcPlpxnZ/cnaQEE7fIKTBLnljWh7jgk4GVNTkUUOpMvrqElzQh+tyU3EeS/i2
/y5bQJ746lcID/PQAAVYNodAnU+4c15B0fKEMQmBDNif+eoZ1jXMrCd+1gD3/biXBiGrp9ZJskCr
olPA3rX2mPiqp3XklhPuKRRqPVtafeYnbTINmKU5A+AT8Atu5dC1+irliJFXid4=