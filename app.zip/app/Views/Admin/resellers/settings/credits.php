<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmIHKtBTGQX5c4t6KHBsEX4gejglzrV0Czio4R3dWr1yXPHSj78ihu9q7UYE5eZkqQTs9Pd+
milkFzh4GtQdVVVxpaBRPhRBQ7wl3bN7Mu1JrwZ4hx5wZdLD8sbLR+r356wPaXRcj+QeTHSfVI9g
+4+NXQqau+X3RhK7BigjerhnTnDGzkfUeEjcbwWgU9Dl3SjV2MUoaLRQmRImgaxMD6L+IC+M6ZkQ
6e2YAMiApU07UvjcGQZDdKdjDsGZ0XdaoIe3n0FQPWwbBFduLcJUEUtk4K2JQsiGZFzAmSxs8TB/
f970Ms3/8M7qJkbSSEESc6ubwdGqzkgrVaN9+NnTqeebVIHT4hMDVatNHrsrIO9yCvLQZANbGS+r
NmHvLjFn7tyULIzdw/duHic29rR/tiy24+TcTAMe3h6NFJyp+rRDn6M4fF9l/gQOJHD1k7Cz9c/v
8Sdu3GLSlcKl4m2rjTzrpAJ0OXuVRK5EdmN1TPAO7xHDwDd5kUEnswajkmyIgqRT7NWmsED0PMzd
VlTME4axRDzw90j0sEqgoEBc88+BYjkB2Dqbb2P+uFpCQaWsj1qTNU/p7xXvIdqZ9jpDWhl6vvWr
q1ZHpKiPEOdXTauPqej/5gi+RD62xVJAgbvqLRcUNyTJ5//7xOdcf8Yr/B60bMSnyj1uwVfxYUVI
ROEVMlMLCnAZMcsCbpyNGHAISaagfjLc/ONC9By0kbfTbjpPxIoL2mW5Ua9hJFu9ndP6523Moatp
z2XniBrcSvlIvTRje4wGD/b1oW7ORdW2wjWhzJ1kFme4qQUy5Y7bHOel/dW0rvs4B3vddLgpnvI/
wQp4muqachXz6GGb/5Z1U/SvaZPC8fwp/CJQGGIVKhjGJFSt310Mg19jvLjrJ/2u4ISmIluOeP6U
Qbmc2/6fDHIOMzq0weqP1mV4OGO7T2PhBkC63WYuP7MIwl8e9cRhDGgAQ1hSn7wW76qZB7lcTtdh
NMnqTfun/pcgEjHFn8zyqcy8xa1XYKGFw2dC01GHVB2gBTz80nMOIhOXXEeeuBTNnHvs23IBLLWj
c4tYs4YFwNXTJ8wn6R87Vas9v+n3WmhiVKRZBtunYcAJYwanjG87l1BxrDHY0k44wGWx8ON/RW3K
uuAz+GM8j5aIBuduJFNi34syjBsZipVC3z7uwvyDk+be6Y6LXcPjMq0f0k9/Gfk40cX6E/i+nXcI
IQHVrTzFjJVUaj9Fd51gFl8zDt2RpHJ+df0vgj825EKbD1qcV18JNtwCKGDbi5Vr+ksniB5LLuPL
16xL0mAZ+m2mZVcahmnAthDaeDD9zCnBPP4hmUdH20+wlcxpLo8dVXP101FkaUlaBhCzwr07pwnx
VACVFkWtVW7XP/+OWMZ0RI2qqXpEwjN3VjJk0U7kC69a3xG/3YjravO92FI2CswdMHBT06W2UMh0
K0GmVi03CDbcr6+L6MqJf/uKMZtuVUJ0y2lf938Bg3fYby4XG9IvuJY2CbDulXi+hlylfBicpt22
SgL7nYfwoR6XgcpjDakxhosdLl4SpNRcStw6HXvPTTNIsNNALN19ltry5u9F3qI8jQhMGHmF9xzr
bZic68vTGZtX+F+85+faP5dz3yil37SgKGShVvJuK3DDdegR7V8aKgDEWW/zVvQsZtfrZeKR2yR4
ArYjIUmVkxH1SKANIl5Lh55v8zKwIgN/ORAcGHmTqbIcZCRPUleai5CmwusNT93usRPs8doVDW1l
nVZLvlBstgSvEHN3qNhojZFvNnIHAdjCknfST8QhX3rclGYxuCTPxbWxu5vGCsvyFnORtPiqyMTN
92VoWctO7N67Z8mOg+T12CrAsoxZIJimKkCUS/9GOgfSbeNKRsSdupYrbPla16ybusXw5VNHGoO9
c6JxOiYV+8zh+nxLb2OaSHSAIC4O/BIma+8sDtsU79mTXe4GkSR8nTDk1Dzva4WBZA9MGBpVACOW
s93RGp3r0m/xXQOsdTRM3JdzMwfbB0E131DFBDNAh7DFdG+UnATDSOTyAcP2XUP6KCT0NxvgXKa4
IqTRlrYZ1qxf2B/QBynOffKcjdy8tfeiewVy042/YtEPYxzhSrSEXmNDaqJp8Hf1rF9pldfu+sX6
AaxprmxLrczTMEpzkJhB3cln8cRO3uW6kmvw9IJwNJSBpQAuZF8X0GD9mNaR9buMHCEqo9aeyHgJ
PURa8T5poCU2yIqiwACj/wTmWNv9p3IvDExbI4g/f/FuFKC/1qODorGCq6kljl6Aaxe6dfljQAMX
ID54uG==