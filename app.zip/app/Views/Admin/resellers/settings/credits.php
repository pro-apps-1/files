<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqrjBCMixPJggR6vvcFSO5O1+PzXoX66h82um7Y3I3KeOEYydDg+6fhITSP56fTk5sBdR/1o
0Btiqb1cUX8xw7cMoykJu9u5yrMO/yJHsmy/XtYNAai8eMM91BvVEIsQ4ciI7PAiHWmIaakb25w8
VV0As0EffCeVll+VSXrZi9ZqtyrL9EsdFHWB7o7SdUZPR9WhpwVG2GqXY/BO1bFsPAZkEDmkhKqg
y9H0sWcEynVGLW8XejHRFxvPz+M619ynyRJcRXD+6Z68SCA7rRq4bKjocNXfOcRlmVzzfLIA/qUQ
mDqt/nS+wx97eOKgu5Yf+u8VmbNfopO4bpUZoDALUwKuoTM87tzaj39iSWz/ib/xY3hC+0b0/sph
WsQJH08g6EgD7HHonXrA4WZFsPiHVHja29e7ioItSMQPqWmxWv1o61tQxSxAqDrOz0SUgaVLYYLF
2zVfodaFHbuS0fjsRiLhftm24YlvSxIlh8Efmk5LcGZADz/canem6kG60sm548d5ldbvdTN6MgC6
9g0hLemH8ZNZa+jY9hdzLcoo4IcqtNHF5slZccRAgVBc97KXALaUw7rVQouvTQEGDWg0V+gGQvwP
1FkGT7q6Dl1E9Aucy3S42BV5qIjGhiKFmqysEFqd9Yx/g7cP7VP4gntNqdwCNOGMvEMAMeuXg5Ox
V9XVG7qxUxCtIdKL0a9srzyCaboZusRhWLa5WDVTIVCW/JIRR05YD+m2ICXXA6YdcYuSBtPRq10A
XkO+nQ+PZAdJpR8YCtFpT4EwX1jweU3mNd6czgIXqN68AKjDG2JkrSlp9smn2RJSYL8FDl81qVbW
I9Tu+sY6iWXeGoFN0pYXnEVJ1YtiS3NTiy09DiLzOVsKfBk3V3f9/uwIYT632EmwTxcqeSWT0iSz
vef6IVWevi/QJ7PH0CEbp86S9QCwbmgmsTdm7y+TanaF5c+bT4C5xPsPczom0HPu3BSTXQl+3z7l
M9deJKlE4Vs61OtY0XK/0AAUjPLzeSgxggiXo6DraupeihtDUs+9GDj8IeYGOtLGtrwvFwZDcB4l
dxro8Nne3O5MOwpowXdr8mXXDKo1jkgDJLuEte4Su9/vjsVOAZb0KqEUVKUa9vEE6ptyw7krmnPa
HBIaCkmR6VqvNf9OGOckNlLrjlIk8d1QJ85VJFs/W4hC0PIuw7tzVB4Aj45Hjnl6MIohynlfQdF9
I6XKK6RlfpgPhRy22OV+KSQtPgTyNPMRPLFf/lq+IlaCExisdDVqVFMOtuYgAc/aOGFPNoYMJbFk
Wjpn9OVIGIk4Djv0wbpfwlz2EEmvCl87DWxvuULUdBmcGot4wiiJNnrCve0QeSoxnodwrHnPam0c
WAc9XcSQsVoCpgWN9vAN80/FLc7/rmNplTpYOG6av0lRyelGhlhqEoCzVSEB8hE0lh0nMI5NUQJs
fujIxOY6o0xyXTt2ZynYXUwz100maofB0HcBcJ6T7mw/dXL5ryIa3CqFHbrGRn0kojsWxNYleHo8
FK9UxObcePkKj50HpPz35qIChPoLFx+Exlb/c+hAO81JbYBrsNtLTYjLbxXMfWgWsHZoXnX1l23o
krx+Xw43O6mYDQvTe4oghjwzJ0O2H3QSNt7KOCHCzjbfd5heZV6eITlLGfp8u6n+l88ugnxIeRZ/
WgTclwxoZHsjy3+9131MxIt/22mSG0nyj2O2fgytO5o7KKvRoeZWw6plc7Bsi4KkII0NBjgX+AEY
ZMAflWnfcHjFG9LPrKYfeST8Q9ASrlMgMynyPWPFCejz49M247UN+qGwcUxnDJdlhBsZ2QB7ukn7
jwFx3aRWmZsRFb/QZMGOZHNAZQ0RFt1cyhewp7zhHr36pt4j8sWpbb7P28k3m6MibyL1MeOMmqlW
cNHpNf0mKnEP60IbqBMBBI9rWp1jGYUi1V4PFRxw4cZi7eIuPYl344BANotPagSQNQIo2QyTKGRs
eLNnrbMde0Wvw5gNgaFuRaSDoqYUQ3BpmKFMNQnyMBNFiN0kzFFleaZd3t2mMwn7skFggg/n0CRI
mrpazQ7VaoUMXIlwppaIFJazrQzRvc3jQy4tUkErrogxCBsu5irg9maJjp1Zw8cE/LvAksRVvUXJ
eY07/zcgQuPeN1sliJVLuA18zta8LnbfMswNzuKJSIlTYGYR7ISzDyfEvRRDkqqtew7u3yeqiabX
QYMmxyyioLUIWKVZ2NH66B628jT5FM3VTUq/i8Io/t5K3xpfrYhjNxsp3lDex/PEiWtViQG=