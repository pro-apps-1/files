<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxDYlAbRq0IE8hufYh9oO6MjzNv8VuxWQ/4ev2nmZ8HvfRxARVWuWwvKUPPtbkfeVkBNzLMP
fHkxkKrVKWNiHNA7WCXINS3o6H8q5Hrc3lYJsah72jYjJcaqM5vS6C77+EW17+wlXaN3H835ZUAp
u6d+0TgNO6lIpAcOPQxiP4wxFS7p46e1Qc4wpmGL8Ah4sPm87leKiwCxvH++/3DGzzlcVh5+qHj8
M6kLLk+D2oUpwg3jVOHxLlLko87LY9C9CPFSQRQ5324ZiJIEDDRe69G++EI30HqhRepJRJY5MrVl
BkP5wmbxQebPpbvssfeqrZVsku2uxTeUvDPrp4tHiDCCch2oAW2i1rcjRM5VykZyy8M8JKEkqG4b
x7/f5MZ3BrGv1YcNqUH8k8iWJbBjzONA8olioJr/erfBuSJk2Cc6lue5vhmbKMbTaqXwH8Du43iB
FqellGWl2U7l6qS6CK20RuTabjHjupFhgTQn7ecSIufVUL3dAHDzWsMmjbfW4+sXdHpuZ0GvMgTc
/XUlGnfxlhnVmDQRzJO1fA3U9ICY8mx2Eh+x9Yr1ZLDtHd1MQzB88Je9BduLBgvNbYdzEQx5OFiq
3PdXNYHnLnoSDwwFvdMlVw3QqttibC6Ya4AF5MkN+kKGdcma13aLjr8ZgqWvr4n3QpH0u9ZS9l4B
qNtfXbxq5NxgAhfRc4dquy37To+a5KMj2zjwpimZsrfqmNhIqM6DASBOTU1M4ZJC7aUzCsD9MzIp
Ve8A4q4LdWyYpMiCWADGectE3Xp/vTs95KjMEeK5V+BAVNLWo6+GOOlPcBkxC0aM52odvd5Mrr8A
ugdILyuA231tIX8xI7nf3etCBxbGYkqstNMbMEoOTK6DndpPMz3o+ROsXuE2JLCrXA+UNW4SaPGL
EVtRpQp8aIW9qcrvSGWcOkNp692X4rxVKmRLSr6Cq3Gwq/Z+BVgUJlI+k0XHTSEquJVS77M225+R
5RSjzFWTLVJVdc9OqLHr+7hjRJRb56znXi9czxAApOHJYG8jA/0lROR/EgmCPJtFRU94FOJ8z9PI
NSqNSoNmzUUAxF8lGv4J9iseZIEDTTTi9frVJBX1VZ5fR7YETzLfdZZJrvbBSd4JIpy2ZAp7006U
ys939T5IfqjGVMTtxsafxYIZWVoIwVWeCeZGxLt3jr8wwZkLt2jDv7TgsWAPECBojMXjE3WM2Mdu
odbe/cU72Ak+6/dG1MhKZjBFRHgAEuWg+KyOO5VRd8oSUl58ksbagQpKgje8yikhxR+G1VcT3cs1
IW7mdCcnj1MN01qtLXJRHi+duad88bmZbtJbcaeH4GC1A/9IZ526P9aLBf158J0/714LHvwdE14S
AqUMkdYqgxlIbfmG9fX+4nzNwDzDauV42e0eG2rhrJIS2i1sQ7uad8NeTRdR+P6Vu0ANLwq6hjVB
uj1nVy9niS+186mVCz7jNEy/Hsz0fFaiHPEtE0vnmYbJjF8pfnhjf5DpvjxNSrKPJTJSlFzRmY6M
b+t2S/K5bjNWBU1hDShVAm4qHFxLlIQcyO6MKi6ZQFYMNXVJaYL2SI7RylBL74QEZSQoBeR/OrJF
aBgtkKVe5dJS0va8rMnv3SX6Sc3wAhyiKAaX4Bm2ffqvex267Liu44N2dsPqngUjQR37KWe1MvXq
eQh1MSgX1OQsSVU2d+S7fh0666jfRq9hmcHfdcCDc+dWAB84TjsuZoNlswP0jErjQr+3O6QP+20N
4XqDw3we8eGJfsiADZU5sbigK9+h0b3n2HSUKezSka3uxKxCOUn7STfLWqP5CQh/mPlD1DAi8ujn
lgbXHytqCQE3VPk0lwkn3CUQ/vCL/giF1q/AVknRFxx95zSXvba1PxzgIWDBDOI0Q98q06Rjg13+
qUwHqxPi+VefqoU34Ul2YTm1O3THhh5itlBUdseSZ9r49pK8cd+uBROSSlFzKZKlT67VPh+QqcY1
xitLH5uZXKL+nQYlrmc7Qw4gbqrrdpQhv5Y6xfIf4WRN/j9zo7ORZByt1aakJPd2q0bU63EX/j48
uc+qzbnAGrQE2g/xE8I+GudOe7+BTOTf3Ybd3jEtgeF9KEIXUHaQ/oG23ezICXVvwA/84aSE160L
G6GYiuy+SCv1ofG6OkWtQe61o+5S9aHykf8Clzlqlxfl7rNcwfTegpFYICvm/p4lHvlNXgkjZqHi
oWB8ERL7XovsTjnxBi+DlMfKrvSSbD7ZZCg6Ciz1YSGkW06rRkXSE3OdUeXRKr8jAC35gIc+awzI
w1isvU5p4TtePotQk2VS5te=