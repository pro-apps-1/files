<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsqAeV4Io1d6wzOqqgHGyhwVNNIjKzxasFObd8IyDnv8DijJbHkWodCQEM6W4a5aiIJL0GZU
x6LUIUILPC4r/uwIO1NNEhGN8FMD1T7rE1ERZcUNawfYY4hFAV0FZmT0W7MdEhPh3IJwtrsRjxy+
ui92VUj+mwJ/awkmDJb6qRKHjVukB7SddG+CQO7Fhhi4barfmsQ0h7crtw6zQPtqgG3Xjl7MUPof
IErWGXjSPIOfUZNo/OMDFHQahoQvLHqjIiRKmAIuw5Uteh406+EjATiE/PC9REPkuP1SuOrLBeuO
VjaR2ryfHrtKpICb+CpSx2cOqWQKd0Paq5qfLvavpeiZkiPv3eCtuaEDi0PLbcfPlrCogmklHNeB
2GksNSsfkQNg7oUgU04fF+je6H3UkAfIx5Vw9XB+whgUEqCaUEVwCeIqfeiv6HKkqxi6RdwgvonL
rtfGak5YvUeokIoPo2TTPGAnDtExpocF8CgYHT6VSYCBXby5+RwXrIWFL+XliJW1Vmo2s3wNY5tz
5o+GIOKQ1kF0osfIn6Z4qRDZS++o/9EaRHg/1okzXfAYW5tYLmTsA2hQi8cz0CWlTn3qX+G838E+
u73J8IzjSDAkGOYC7GNohCeo7vsQ8nWbS0ZGcA2yH1eHh5aAPXVkMpxxSCPsNo5bRFqWtI/8ecEe
qlk06fpW7RvpwziCizAGuRqaxzFtyjbCtbiSws9PnXLmLIoprEGEVNzNd5hKFQrudE5JxGMo9As+
2KR7B1wqhoeGr10HB3s00bF4SJxKoi1Q6FzG0JwTKPo/CZO91jVKlvXaaeMC3f80pBRGNIBfa2e+
y2ovMQSDEmLzu1pkZrh9Gl2Vx4Dw9LX2mDDg/aIisf3mEO0ktvSSWjMRfMum4O0sA6N24CoII53C
3IrAgHxL2JDp5rAszVEbiR752SjMRESPmRKqH+WMNOmCuGT5xyymkf9+pyrFtw+jLg89LU5m+U+8
zXc8N5zXgHfmC9HhDUsf6WIEurHlxbJMBAMh0UEOe2GGj+Wmx2WEABcihnXgODGG0aGYeRQZ+HQ/
bxEf3eWR/ZhhtmJPd69AMSgkakandRPkjJVHcapbt7GAZajg8v2tLibEqCq3Cslkh5xWxn0URUgE
T8VlYAIi8X9l++lML1zpp4uk4a3mr7YtU1rKXNuAUFd2ea5nzKwQxN25w8nbsYh21xWKGGpoEdzl
/lEGxBeLqSUmJ8/m3n1HMtWrcM9CuA9mS338faRsn7fD0v11RccYhWD9UUQouw729xaV0FGi3/Fk
Octg1nSN1OK/59J0S2XMGopKbOJm8lM6o314WgnfPU56KDM304YDbLdW+BxYa7/FBlb6GTzVRF/c
JAoxfQBkzwsuPMq/exw8aRT11/oA2dP0uO8eiZMExWREX6ShfD78u/NEwnXJytBefiSRzPjOMp5q
Gu3qgXQLloz9vN8TqU4gWD14l8Iq9anJ5FrVU4FlyNKXyeKUT0/jOBZR0XVeLHAkmCWCvZUXvDrR
Us9Cb7MzAgzaI1uGdZxy1R8ARKRQVQiDpMBFAA2elYvuf7btuLWvVmn/0riuJoylGIGW1NHoq/Ik
9KAtFnElMA+DPf53k++610AAhwce1L5MN5vjPSHQkX2cyPYMQICzU50l0qSXsfdVjPXA4sNsYXLw
n7AI4Q0zjxi12RoYJ5lByw3Avm1umZF1stCIPOQD2V/sQ+6xe3kP8L8bxYk7fofofwF5p5lSSFfG
b95XsbUBxGSgQRVWWKVlw9oSH9P/Zt/sr0czlOai6V++Nfh0YTmN5zdRpBA5gAz0fK01IxrzSNGH
db/rnjucr0Rnu1cBlSa9agiScIq8LHJTsRHhvHTOuAvtkVLclOytHzv5sJVIaKM6HVvHmzic/RPH
To7jGh2KqXlN2o+z5Z8KPW0p1b1JJ7c8mcqsXv0x2NOFk6KB4ZLm+vtPz7OhrigxEiO+ceMKbrcs
S56QqTI3ptHUGsuNIRxtTX12xclmEb64DCvkMB3mwh5WPtmg0WlxWNP/BtYRC4iTWXbvUPZf0mUt
jGUn/0t0u4HviyzwLEZ+WroupK+fEnCJvfUJ2ZKAdiRGPNBvxTomrdTsVRnsCOLlUfiOvMRz8jRx
RyOPg4V5zBc7BxAka5EQWw7XwFEmlGt8BiJ4CxXDORJbwjRN8ExILzYvPMBfjIINs57we6lFC9JL
QONMkSjLfc7kYxHoTAW8Rcj8uTa4gMIusMQ41ekadw2cnTNgEz8xvkLPvzG2+gEynpjPnUd9CvJi
3PwCkkNQugu7XyDR24qUJhmekIu4eh7lgvS=