<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+n5rOPPzIsf99b0fIkL19+VUpur2SCvSewu27HerpAs6WwGRB9knhs9rzCGC1THavjYOAE5
9t5ZgqJZ/32PTlbVZb4lTiSdy4B814I0VIOUWcllLNifAO7m2IW0Xt6q0A7q5WSlRrNd9dQyNe0s
8woKt9PYmsvBwaxRnI21v5gxhDR1zJgCPz/VMl/Pfuv3nCOwEDd8BTPmLBkFhPdwEYs8lbaJGnCN
L7vP0LHTC8BLAnTsuRs33ywuvWfJJowaOlAwGv2yD9MuVnh1EjhBxNnaxB9bTTH9unQ0HkSjJues
WxjO/x7mBATyKRdFzar53I6tuQnNZmHVz/IdshSp6VBB9LUrwJwb06ABAYSTC2SKDbIhtTGARBHr
hKZ9Ww00eO4c2e4XhpYA3dAS/ZObS5xGa2xJu899METcQP3nkSEbGgvoixCzGwfBXlXgaOID+s7l
JYyINItd6BqfLmegLyj9CxRx+tGvXTw5nvtFhEKmVts/r5e8Gd6KnVFSC2CjnHn7yCOtyPKOkcV3
gEzYrwpjYlrxA7CgNnHGdevZmEdT6kh13O0SfLUrrYsWGq44SLVRKza45SpRwve3GjFm4jdisefr
KzJNKYU+L+CwWOg2mFGLnHGt218wQ/uZHUpF3RIS8rt/Rr2bEZGSTXYZmzWlrNjuVmvs2O5sra7X
FzOK0hxwNOPL/jX4d71cjHjTjY2+MdbQeC1E7xpXrHJApE2mELD0i0D32oNt6PgK551Pot8BrTr5
R2G+Xq4GOiz5vq6JgYR67HTfl/k9ED1vv1OJ2aqVKmgG+MM/eDEV9WWSLvcN0wIlWne/Gena5YbI
AKTORpGKZcqkYJLMqL3tLG+/X17GUsImfadWLn1Jpkx/MCfQvOVDDnxhw+cxpu/MKSSr+kB6s7k9
mFTrvTbXgh2gsqB/zfOqezcrvLHtLiTMVPr7ywJRnRjXOM8eotbe/By2IUvGQa1MuHGIF/v4zaWM
USD3382wWwctiUdkQOCMKo5RRoz8AxQk/kaSwBBOTFo0Vzfw2MVUVoZX2FX0m6h5KSWkb3tLX2Oj
stIT0QnEG8VxOZCjjSxGKtipaoVZ6iIHTGlIMZaHk1DOgq7Bl1rfUzNqbmoTV3s2yxhot2klHtMU
plpp7uI0fJQzDPzQFuXFzAN4/OmPPduA2NvajsYgKLE0b0qXd86Yl/5a+5zLHuNnqUhWnunI+b9k
EVhYDt1KZuxJ6ATgfsVJp2dfBTDrUyk35n5oWsyWMSbhYCUunOxpx0TaNF24AIQS93kVbgHQ57Ts
pAoos2w61V9nNPWs4fOA2iHyWA6IrVObR4UB+NllwRcNCQe1O1Tm57VEdjAa/B6O4aSSjkTdGseo
5ghPUFGuaolTdvsBaHbObQeZMT6C1Uku8rqIwXMzOvSfbrE+DD76oLc+vwcNCrgCCBvajBG4C49y
l0CH/I5GuL1/iEla9FBPEQVBY86fUHbtA6YKPtCoMrkuGIwPVdaX1NqFjOf4wxPXcISLXEDN6GtX
iMTUO+MrBMWaXFVkIOLk8MCvWlYaT3lTYnGw7Pd81a8gXPx6OD3UUjB1HruN+L57ZsTS3uBySMam
pPgoA4Mjhjx3Bp1fqzgmEHC+6m4A5IZVI+fv0K0sEQ6lq2B4zrHeiDG4Ot5c439y7aidNqWDXEIy
7JyVmHZZ6nykJZWICq7/gt8+6xAbQhx92UYCa3Pb4cJ1O6MkWjIQ6Dj7aclGpCY/4qKl7igu2S0b
M6rsef3SEZkNFPtNkFgFVdKVli8UU9HCRx8DER98rxZW2UL1+g65HPWBP0tQXCwK2QYNrEVSg4Ax
+QeEa3eWuRhLvKuLeAduaDcidmJ+HnVPLoTihbvbrN6F65LvMtGn4ND7WXLQhp3jw8pT765yzHH3
wzW2zyjb+ddCPmjrazICICqiZX3vthnUxnLeuynMwSx/qr9b96btI1amB4yI/yQY5/PbrkJ+7YEI
atBFwg7zcBZCA6WnCVyZwKZgs4Zyalw2o3HsIEXatWDHZo37pP1RcTwX5ZlYTl7l969kQvUgGFrg
0ZcOFZ5r8hwYW2k4yNzQOmdbLivskDO6iRRZh8aePuY4NpD++BvBFRBQmngMErK1FvMvDKaYf8Ek
Tx25T2yPKu3Of5JJ+L/2cQ2gqBrVnmtvvnxBAdMrez3Crz3KgoIr8F3nYuL4bhIe1K8imcCFEvR6
IuKhQ3Pk/114FoMulTF9fF8=