<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzBtmDv5PpaH42jL/NyGofX6dxtyth8lswEu3cxUHVwLU75m6vzt8lm5bSVff9drYiwLLK5d
lmEQcXUuTvxtii6Ylly+o6x0B8TJmYu/RHyeroXSmwcdTRpYgkyrL2dfxvmVh/ZL/0hPC2FOkmEr
5wbLfGdELi+bioD34aLfTGoZlfObZdoRKtT2wiuT2lLuEfJ08sjWvRTtcJbbnGJGBJIAkCnss+5G
4YdQ53V1fT/L+bdyQIDpvLxThizT4fOtX5qUCHcsHeRqKnR6xUgE+EdiLGjkcAVYO8OzVCfqyqc2
hOKmJwHGhKwN3LSNE7DEwZqkBBb4tnn25uT7WJt4UYILcCm3wQeUdJu9X6SmohPHztxiOnd/cnLx
StF78al+Mlx38yL19a2YXVbk1T2V+FkiMGcGHKuCCJD/H2AzeOho6XIzZgy4XVIm9tscXDKIO4s7
hb7fz3IWJU6WkuNswxKfx3aQ8Ap5HrLu/6MnUomIPHhptt5vcVSWbEjMSemTvY466O7X3SlOlywi
scogiwb6eG3Fc6Gu1Akw+10HZAHZSF+5UB7jHfHsXZXSIXKMiFeWYzLFtR2jUTAsH6mnqsXHD1NL
qUvBmO+kk5+4lHuSwNc3RoAyeMnOAxFX/lpt3yFZ0ZlboaZmnMCEL5hVoc25R2EDhvoT+q4M2nbj
/+eBBN+Y48wYONwwTvReJNCt9kPAx/R1y1Y2LXtYKvwn9tdrV2C6uJuVgVKs5UNpJcCH8QWI5TBm
wcrlhFdmCFO60Ydyq+qmUMz9mDFleN1u8h31He/petaHKobG/jWHGK0F1MJFCNpzWyjRJtEQGnmo
2dNA5o/HfKG6MrWuYMls/FArSSwkJm8HU8pNeJ/yKLVmXCW92+NypWUnYHsZpOcDPy9ItHA36chD
gWkfjTf7uWxqhw1HIjPtfDyTi+zEWHMyf+HBWThwuFTXaRpt6ff9QX+i2cpC36YHdSviKRZXd3xr
Nkpgp2K8nMdwbaLcYyHsR/yFeXSHwRcbojdZLufY2itowfBH1ieDsNS38F3+54P959GNkMkZSQSv
9RFrh8WaoKvbAD4BpXXdWyR0p7RaBsaXse3/dhqQ+wuK4EOVkwUC71MCVw6veaM3RRpraRfu+jgP
v0nPu7JQctm5NKq0NE2gWL5XQufgft8jjtOVx9nRBOvHbIsNmFeq3WC5SKbdDTMZoOEjICuJz2W/
UttdIj+Y4LPJe76xrRQWgiNPqKEq7+ZuXoGxhixXtH0W4lc57zbtzPSCKLQSeruZtZ2qcoD3NLkN
ZgLFiFiX7ZQ5tCgtvJBCP00tC+4PN1jVdlVymffOq+7ELtdLWgvZyUEZmC0jvxXTs8DA5j0NsDM6
IaI6D8MnHZsRBZE5UBH9ynulJAIdRr87A5lxiLW42xVkZFQNPPVboGy18WvmApKRoPnvTETgY/zp
urLo2Nf2DoAL1ei8+qjLHY/RH2UrCY1ObU/m2CVFH0ZKVDuf3kzslB2Ps8gmPIsT76T1fDTAwqdd
n25joS9NaIxOLVX1AVmb7Ng79A4/B/1QGLPXLbV/4MMX7SDGhPFxlyHYEuZ4tXBzX0kRZOxOl2PT
mkmI9nU2EGAY2/dsm8304fGLrizN36JTnvCxvRH5DhlcBfQdTDDAlHGj3VfqHWLerermFHTEnydP
8qY8ZvBx1aZOmvHbIDmrCkOY+nQKcQU2VtsSDZvH+92+UIIa5RdmrD/jfsydX9/nbDYD8ndbN4Os
5SHt9wmI1uVbB5b6rGbMnB70zqLNSJSdiswh7x5K0vI9B0M/O1avdPA2W0nxQxiMUaUmOj0IHJ/q
61S1s8jaysaV6D8F67R2CQn6m0e6/gTq49I1pCpQ0YHCv1M00Lu5U88TeqRUzqnn8G8NFTX90fOZ
VshtdKw6M5O690fLO1Hm/wMu7xbbTBhW1D1F4FwH4IIZmPWeT80GQv/RCrYXEuJh6Yn81vfd3KRO
9ojWxJqmt1oZNnSwDvSKjQf3JRPa6TPQ+nhOq0YGnpNyA9kpUCzr9nG+iW1bKVZHz0T5M0O3trrA
aGEO3sX+CRIYUNM+vKij9Za8AM7okhBzvoybmyAiXovsIr3axWf3j5XA+ckKUpMNg1bpOk9exIV0
UWNw6nEnmYUyK95+3m7V4u38VI7T9gF4gsChn3cxZ6BzBSPRV0JEAw+it7S+BcQoLqNvSkeFCT5b
dwAP/Uj45PZo6qWZDD//PxPae8Q+WCy=