<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwg2hxx5C1Ina5uwdJvaLrU9Ir0hDszV2iAQR7uJ/6avNm/OvWAjHvNkRETOGH9nffpz92tg
xs7S5CaU+DJc4eSaHKXL8yBemyrbMbZ9Kg2XNgX6mV2aZsBZ5nP4MraaDQywNgK0vFpr6D5fY6DE
rCrzz9vuZNbiBP5os+h9d3+OLq8+VVlh/OTHxnr7u+bZvl99r5PEvBZ+w6QE4W470W78C/HOkaIt
rVXtV88EKJk/hPK6MeGTTbMYWVCpkRLDvcxstZ3ZmUmbimo8G62q62zKbyctQhHHPSZ4P23hYp7n
GRTyCnl5EnuiEYbYyY/btvIa67ACqwND8sD76l5aknsJBN/ZHiu8gm+KUuDQWX3ubRbH4Va3Lw2v
HAETc66YY5/FLQMsn085WOlS2G+CEYAScSOEVHLB9v8wsOYiDxzl7f05m06jyQUx+K0co6ixkMmT
/qkgXcLTrdYNOJ9Y9arZvSxujBcF8DrXSAtrlq2B6m3lCWQSMr8qw+LA/00VHwzGoCYEyXxg0mti
mWcNqHvJA0/HKRdpZ5Nv2PHwQsR2fAFgOttMaSquYcw2BHGhPHiaXm50UHgQfHumIMDuRjV0pQ7d
ppP43QUyKqjGdcEBQkU8NhMV5o7CS1eq64LzgPRA/sGgN4KfRdHpxVdJBTvhPjtT1q7UId08cl7w
IJdDB5ilFgiwR8ZlNUnX/EJ0TfORAUSfAyanKIwHDa6mxDsn7ynQz47eJZj473ZbnIBrs/BcNRWS
qIi0ML8SR1FgCBKK+WUTxB9puJ66RY2F6cGn8mUPAee7YV5wa64WsDRG7wmgetFRZNxT9EXxy7Ql
eVbPD1cf33RmC6dx3uUFtwTOAR5hNcDAgLHU3R2LES7FDe25EFL68oR+/biG3Br51stcD4usczoG
Fi4Nl7MZaZYl0yjZkC5eKEOU3t5xWcLa9o3iNuhyWJwwisQ7d9PZKVzhoIuECx0nvUGJ2miG+tPL
fl0WI1wJEg5dv1ujnmcg7zlyI3DQctVof6dhdtGUO5jsG29B52zWYQDIBkB++ZWfdyS5bzuqvI/s
dWiX1T7F2WnzWUfN0fAIbqqfEmZ/y4iDuaBzTat9NuAajnunDDNupOAQ0uBX+Z7l4r+Ncyl+iMql
XNRa5peZaQe3wFXHGSCJaKMm36ZmYQm1Y5aMNW2NdHYgjpfa9lGY8fP24zy7x3BnHB1S51iGcuSS
likw3Ax2vNR/lsmky+H3fE/bSHa76vpAMyQaFUg929SrCmI7v3GM1JyAhbsMZsceaLek38Tforvg
vVvzgJtsWd4IVGs9kCPKp3Awle9XwZdfCJgV5FSt9Q7WQc1z7cuJZ66E9K8O7eQ1hd43e00WPtVQ
YTr61opAikKlJFm6973DqnRLrvs0MLEL9VXN7VaY8USiSTORsYfzNAYFkoqJAgI+DT5HEjSqm8GM
UPwPdeO5RldRB8+3FPU9fnTs8SyrAIo9f2LCQO/+xkYwacXODNHTl4Xq3m/TgGqIh6KqR/omoC0e
Y3Sha8VeFap6WGKexdM094+m/D+BwkejdPG65Q5WfKipIUIgVpumrF55YjuaeGPcG+aqN1DPj8OW
ehtVsa/NdtzGE6sTMmno+zu80gZ8TCrIG3F6dWyBEerYKsJyoaXgp+UOv5uZ1Atuxsoiq3Df2t4w
QHzeI+pSNwhH/SjeIxHXcwADBxfcOtU2v/t/UVWMqwCc/va6q4I0j4un/E5DJMc/cJIGbha1P4zo
kaBI7/RcRO2b5CnarE5OKrItsUkmSnI3Rvdt0OHDhlCCnrYg4owP8UFJ3LHcl/y9xLfOspBAOAq9
4juopHga/3kcD/7yxsaMNnwObKq9bXpaikBXb93dA0qCtMDXhzSHZCOYMTEvEzmfgKpAjptGFr6p
iGsPmTs5obx+l5Vj7czL0xFnjb7FPts/pSoYlv9qSN6XytSO+qlz8KhHIqSZOdr/S4Buk0GqvHKK
zSKSmN5eIuO2L/PTSZ0oxlUlp8jWgC3rptaKp/JI/RNt0F1BWzcXRuKIsKSARXqz6Ta4Yyvi8Ha7
OILWetP4HGDrWZ//Io5ujcTdOAACumb9uXzehNoQGZtq0JHvnplVyIloGeCOuzuAC6LkPZsLnw4V
Bd0OSm+2WjodlfEdzXIOYbQMUoLalmgIVQOJ1TEaXSvCU3SfY6+9sp5G/eBMMXnQteJpITIHfshK
VYj3bLLqxDOs2FR5YMd50a1JRarLkB4z+lGGsHgxc0u1sFO4Y0dULNRMcZH3LbGQNwKhWEye1HZG
YLW2KYc468KkCbNSlmQPMKkif7o7PaGJysS6Xzca7SLXM8YLjX/qe2VWUn0bJdhNPtjYRC6SNGm7
ueF23sJ1rAoZHE1ui6ipqkmv9XZwICep7WAHFyQT59TVm/7bHMZrJHbPgcxqRMeajckRcRYHHUDT
+8cSEsUmG3eBZGyr8ZILFcdO+alk/FJwK1cai7dAwp5VWrPZTQVWk5bvyPvq9cwsLnKEh0==