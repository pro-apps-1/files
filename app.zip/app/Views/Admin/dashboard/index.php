<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+G40sqeolT2DTYMJWf4JgDn/3jBE6sGY+aujnJooZ7jQ3dtfdZ+j/sx+GZkwEogzI6gfRLT
NWSvO8TbXqQRXhFhBx31WdK2ERg7+2quq9fn9ZMvVuACA8shlbG6sGgMEyIpdxPs+aZcHXDP698e
0xIBpPpLFJd3z3lQwFOQUfDm/efHxgcUw72tSdhlh++UcZMcy/ecdjv3PPqti5a5XAhp+z6rhPRa
VDeKr4BzWEqGMWq3FSQNJbIMl8xX2Gfsfw6FQl5UV3HNAgEvKMn0WDbY3cAnRaxna14EV4k5MdJj
0/Gx2lNSscN6Ao8eoKXOFXeO2DyaHZPXrZe9Gno0V1lbodHS4+7BRxXwm9aw7mVejZg827tOeZzT
61ZUEuITj6WWFXSB4Lm62v4GaRjlY1m9NhUahaxS12HHnnu+FghTfVzpq1G4LOjRP45S2nez9Y9q
eQE13J7x2lvJetts/A5lE02ufzxFBl3b4vCTXGb69kwd78HPwED44/YFNmVKfDkG6F68jgGlhwrk
kKF8O0eplWTirD0PaeFuOVKryMhPtCeJp14nJoa7jhRwfZNBPXtN4HZohSv10afRy70pig78SqSu
Vuaao3Q9wC37Fj13SH9DRjJdQICjpOfh00dWJUBXAc26/HjWKLHT6eNubHEfbUxzZqGdm22yjoMx
G3Ax41vCaAcZ3+4qDWBM7xE8NSUe9Axz2fQPfJ8jVCRFI0z9vQ/Le/QPjCAE6cNKBG+RAgueowa8
CQpRNO29NAqVPWzxLozt+egtxk7xaJQwi2YadfYWcZxsjOhEw0a+sea5pP/xKnZpAX8AxKZxZrLM
y57fvUxmEwxgLP15TaRSHxNTdclI0JwCwSGXj0V2/ikQS7rjQYs7nYiNwg8JeL0u6m0s7R2mESlN
qcpwmi2u2UEKRlLXz/QnrOqnd8A/AfVDRiOH2nubUD9i0+GpmqYNG0q7yq6MxwArcxAccZW+G+23
4W8pHAqKHtgY8KVfa9zBk0MuUwFjLnDkrqFeUyRrKjyQ4d8gHmyIkZAUZPUPWPKxAspWl3EECTQe
5Ojv6rljZOulB+YJm6wuPUH1KjrgpxacJaHsO80PJbJUUQzahbpls5fTIGisCMcvGjQeys/xonFR
n/0Lul7Rk++8GjGFz7UfBwl3T8pwUFvEvARDXp0xuZRH3vIKV2ehuTz4PNk8VGmfoohQSj2/qyV7
G/uTY+IyxVBiEJImPLjYqHntm5pF3BRbKw4O9bp1+hjXTOJs6wCwwGGK1kl9vnnhOPyvcTJLvdGE
1eN3jTvPks0C6cJm1C4IbU27k5CLoBcxzVpTMcVvBA/Uwj7iFYlKIbtZElyHV6pHcgqDMe256F5G
+SUIqMYR6BSdkjJaRK6T2+KSnB7bpdZSEAH1Tz5XBw+2Vgw9oKora4Ussf9S4DALtIUPEka2CfH/
398rJJ2miCIx2EjLVIHdL6D8+8lhGNcf3o6/kUJiMOMajk5H6aGC5TyTUNDIyrcqDYyRfh+0mWQp
3PIcqLLfXfPLxFAzX1W1Bj3ugOFi0ZC0iRUKYasL2245AtployaTEWGGxSt1dpqDk/0X5WLmPz0c
SyCqK0XjRZqd6SiBU99YO8rmWP+qUd4Rw4FFOvlMzacISCa/bCBGKD3Ki4AxoUJSECl44TO+u5+G
ybD90VtU2o95dq0LfE8nRZxMbsuVNBy7boK9olO6qjw+VxODaEObzGjyfFVU8ZXIyk3opuZAKgvs
dDmGjHN6HDSGlZetQ4v8+h11ogNUChAyj629bXH5N5UkI8r9ocem7uk4Fkv1tp/noooC8vPQRGns
n8arMkfR60grq6QwaUKpaCHR8oyDpHDXV1XwMzI74Mh7RTRv2JGl8/TBNhxc16gqCj58jcdEj0g5
Ff3GeG0hCxQdyKk8nolAe1624Pyq3oUS7mY2GVNVvn9I/oqi249eJbm7r4uRuTM8Lba/grhK0iNd
LDNtmh2RaCUhPenRXhM3+dTGxL9USh8Qi8O2QUTeAhuIJxGqXaab/bAyH3GDsW60J1xCtukR4DKa
j0fvysYJe0kwr+KwB7GDPBlfEOcIlBs7RjhdlQK6T75se/qMCE4rHspUgFBnTOnR/RmAJaxTOOIW
/wTyQVVDpUPpj27OPiej4SrtbEKRQ68xjwfHtAiv0IiPfIs/Jc1j61lb5BtCzkNbXFLoU8hTuMHc
3M6hX/UbRCF0aW==