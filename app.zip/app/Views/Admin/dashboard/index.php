<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrldNeMnLgEgJ3lBfhvSFGALTPxzoWxl6y+29M6hTDWe0jcxodFSoI4NmNbqomYkhAPhfYOO
xhw5xuMWXMqCi6kG2Xi7CcTGuuCeWtSXACHcUg86lNwFe9xFis6zIxmFK4MgwvVfvbxnuqMOBSvV
/sq6DxbQL1VsLDhmqO+YYgiEyriWFG8UJJXJwEJniNDvZEr6P/+ft0WqZUkDChOrWrdqTAzIzQ3v
RLP09SXADlg/bkV0y8+9GydTBqXm6mP1rfTSe0UhdEQ0wVtC5XO2MZ3dohAHR65s3x7o8wMLYG9A
JraRP/ySYA913RXSLQYhcwmCgcc/+hv2ZVKY/ZW52p48cs3tRZeFz7QRWyTQIcm0HJlShvfhBpD3
9cfOE08ic+YXnHe8XLNAYgyQRe9oyK5ghK9Ec0gas6BRuu2a7CLwxQefyDb/aYGTESk6lYB8qYzl
KbG7PZ+mK12igNLwu8OFtNxF46hFoJENyyGFO406hJ/G1tci+YT72FBu9jya72zxlv0VKuze/xTy
WIF8TOBeLxL2OvxH2dwWSRrry55KQM7Ve2jqDxCOinKV4GqpCDkkxu32+19Xv4mo3GYe1IovtugR
6FTD5DgItNISstrbyERaZWpnVJy6sURpPcLuglNpqhT5/zpRVr2CGXZsyhsv37lG9ROuy/j3ypR7
C6EE/wZdC+ptWaUU2eoUSOTdOTjgI2v9kHkyCyf5BPU0YTjFnHWh51dXCeo7hzZ/loO38wHcT1sK
bDf6EuTimTUiOIeprpgRblYd0gkmCD5Z+laVSPZdce79u8jthVHTURBzjcrPvCCmBDwwtlxfTEdZ
p9BHTXYXVa7h+nTrb9SG6Fuivu6ZPGBgTN+vEH58yVhJLov6ftkoAeFDn9fFwocvKwN0xg4gUW/6
pQkfaLHUcLJbeEjd8SpV1XbhcPhDuiRJIkxms9lx2WBsc5ToX3LJr6VEGmKPE5oyg+TwyDX8gRvm
5I1BO2V/YCrpaNe3/dnRo5zgFRfiLMPqmTadKb7ENUWLyWrmo9bL/ih5/m50RMJluBSARM4Xw2bP
J8B2OF2Qi3+OLRNdXrvmAYQU3kSJKf5GcCgdLtbr0iI8HEX1tzPmB/EvRvmW6kDtpjSuDQfa9wWp
7v+RrgANmaZMwLswkfKV/62aCHMxcweDjybp4z9ZSGVOuk/3Bi0ADEWHI/lIn6YiBIFsvoVDEJx9
7k17s52LZk49EdG/s17BGkDa6VUgLYBH68BJVp1YGR3eXfPIGR86qOq71KRBDOzsz3VdGUs3to3g
eCdyP0EAMQGLnLns/iUjzMNUbqpar+KW9mQ8bJEWXyi65mB9JfU7BZ5LReHUpkb7hXiAGLdndMgp
HN64ba7EzR/OwvcblrGojB3zzuDRNMdUAnqZJ3XCyK7RZfuSDRXNfMJ+kjcGRINgTCih/Ekg0Omj
8NoY5n2w6OJOSH7ZY8FDG2DNmFCkrfhqKsajQgHLrzqod1azb7H9pzYHyuhp6OfSbUIFKolr/LKP
9hQl6bc18OaYnNN19JHH2VthI227LPhKdaUa88TRO0vYacRP6mTvo4JmHp8YkD6pY6gDxawNaiH/
d6peyU2sPkO//sh58LiU0efhyiP+nKjs0dKX5fucEJ8ds/gAhMEvKVaENzkO/PIy5nI5vlqj5CP5
lt3a/FSv/CPB+/GwvtrKMHFQSvmFHzVb1WLRke/tjlLS8xX6ZP3dID+qH+P/nKzsY9vSdYQm+pZc
jtVXYNdNhu82mhMNHHNpzhtrgcNw4hX/45VjIinkkexALzV3f+nDWOYmZRbvjpLIb4rXfK22PzEC
x8XUpzAGFbjd/HHpxVvWe1FJ4Zw1SwFuqE2yxGCC6oS0GciMj4We+xrKe/ib8qfkT1q0uiQyvoyq
Y8fUoMi4cbMESIlobOlSWhZGttlKs7dp91TQEqNN1ZrI970XBqf1JA5nlO8LE1ISd0nlPfw4wEsK
I9EZu9LnixnwUEhOJ5g1JovflNTE9TRvarVb5jf/66AV59S3ub/5+Imew8fIGpd/y8aQHYN96kji
m3HLEEx2T5H15A/16XAypMWZ3XhUElFrNj23TGPtsXGMN/DzuwYxkmfe1jyMWkC4JOtUk6yMUzhP
XlFB1SqfZ+bAsJSY1hUB7OBtilNCIewZjdSm5VvRsc1x8Vt9ZiZH5JchvHlVkS2EG4fx0EJVy8XE
cGeOKbpRc9o+tO2E4uQpnsv6gpBO7I+E48FzW7ZnBIIBBoNl0OmddpP46eiOslrQZOn/FtZxJMbO
m1LNf20xp5eWm22/ybSwKpMQgjgavzRJo8swfPSOJakTKOrqXivwXwmpAkoPQQyVnnebGNDtmEYP
td1raOcgA9nWpAduO2CJPBhB6pdCUzzlCXKxmkZISoKo5THxfkw9eoUL57ZN4tjv1Uf2e6CNcS/V
6+bKqfycExgZA4Hv7JsAXWaQ/j6kIJEYPG==