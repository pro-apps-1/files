<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoTAT40M24rexvRXOx7e9KqeVJX5j6oqbD9Vi0sPS+JVGiHWKWZifVVemj7AZGvO27dBZSA2
Znp93xoCb3WpK8teIeS8eGyDlavg3k8kfNCRUIwRgZ8ZmSK/NGEcfE/MzUMc+IqHEbtgYIBK5zn+
QJRUuVpsbXMLE8kkMBPOQtas9H9/njmszSoVyzBtQxDzKBBEay78v30wtyQVvECiZIqc0C8f+mjP
ZUINUAalbEeFShqFVjaRPT/bnCkk8T0pIzpAWBWeELB5xncJHZQHAvYmnUywR1gAO0nzpg5oiRyI
jucOOW6gWbWS/Ib59PN53ZZeOJGUpJckIBUmKGwaj5B6uDuCuduWhXbf6KLv9Rv5h7UBQCdQtSDL
1csaD24XoQd74hc/qxrl4CbhZJjuC3sDPmSV70m4L+NnQGBc1R/3N2f/8ejARLN3ClqzUOu86P1g
TRCKp6JEiQRlCp4AMEl3E+phAeRr9MV1Ilm2RPe52oDL+e7pntzTfoQMqt8RLrNr4m42p/L6PMV0
25vVM6wyo0fRF+O9B/p7sCTi+dMDUwduIJgQJef3gUAp3AYx6ZQDGoCHw7dgGkqlpNaWNMgBh4BO
OgGcTbJZzcjfxgzNSjqzDP/xK1TvBobqJeCKP0xmaAD4Sk1Z/+fBrSg2a7fORu+lIP2M6zn3s1Cu
PGtUlv26oGd3LmkkHqqthrsZqtfSfIf2gnIzgr6siwUzQx15dMjN0F/xBwhcDUXNwTwPU/NqOjCY
xoafdmaIbZtLE4Teek3QiHvruRz3lcDpv6MU+r5vbK6O9ir8Ksj0Ud0vRchPVuouVoh3ygxNf2tD
0v4ooC2UgdpbusyvI0PaRPIuT21W16o2JxWuQv2dgnpqCwcDWzJVYLVhNRmL4gMCq9f7RCmhIvSY
+UUELQ3od7C9QDmBI63R7yItI4qz6bD3aupKh5Aukvb6JKHoLlNXStR/VEl33XFNJryCk+D5gxzE
aMQPevLWbYJSlRdTVNDDWJ/9k+9LQIFYqolEGE7/ZKZrBSSl7BczyQbvuo0pzfAAZbYzt1NVY1pw
GeR4kNYxlhkjFo88WKoW7hhiAYxgpVLk3OGaAUHxPLORbbOL+E67Fe5UOTKFYcz2yEMc0uj6EEd4
HOYEhA2KEGxgkne4t0TInAaiP8I0K/wqJ3Gjy5sTSChrvJOWy2gkI5jKA5z3BdtH/251ANTIlfXZ
2SnzOJ2Y8QRnTpiOpLbcPvvoGD0kmybwdEnLhnQZpsvx1CqnWPp4U9xmDG/cqWMkvklS5gxt1zLo
88HNVY9SMU/2TM3HMOmBIYluv0uqYHlQyWsl+cBYDMbLTyomyuhdKV+YDrKwPnjj7ZHYj92mMxDf
BvnEWfJKpWewLPf66dJ3/XrVwGnMErVOhRJPZvi7jV+2YZv/AtaZte23VkW3ZzvMN6YfmYPMZ+n0
gyFEWGc4Ti1T+03tTjfHPORmyqXhoSo0mKahcIJSvuKcXirB/sLSw6w971ssZWLusoCm3zrZiD2B
uGx8bbVsO11Roczq3CuKYrYPEF2XV/e/nz+Lqc/K9QuF0E6ehVlKL2ZyvY1TgEg9quvg66vliumV
gGvOHBQ6l2spIR3/oMgTVlOtvICMDM4IKykW1gj6enOd2vByo/S5b9dJvuCaFvztydi043tmoRSD
cw1FSE0k0EjFmUW2CEnxZVdc0X7uTwR7KGE99ANRCf0RPDvQjznIG2mA5mZZfW23bLegEbQuoM+N
Lw7wYOA+AscvdIM5hXEUo/AWsRw275TYErANiJALyOMtdeytLxD4ZO1GVmJIVPpwlADq0wNr8OVM
8RqA3LX4uXuZmUy7kAWXPWVvrCkMzPyR3G8O77kASju59JDvdXaAAL2lDCkR7xn8yPE63HpAx+oB
PWPakh8x7NHXKQOWIiJH8CyRZAFgaFnRqQ6m/lKXq+8+G9MolbKbMKtJW2wUwCtKyZ3tdBDoU2BV
H3STn5P/fstwx20ztuZ6HDY7Av9SxXjHdEy6StCPjsFqmFd+yXTcJL6tA+rsYHk7iki9+/vsY3yQ
ICpCFkDaHgCDNDH1gxhYexL5eiC1PxqgzZZg9d+0Q324zebONDki4CK6nMDWULWomX6VQFdMZDV8
rOEhY5/Zmn2r6EeGfbpPi0/mcV0MC5u+5jL09pwkCmRNg1D7grMEFYy7UA+loCTczH1E+E+MJynx
ADRn1dAOZEWDx95BibtAfkW=