<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzmvaTftkMaT3kK4+U6Ev+pmEZNNFVEJ9QkuePK1/qqjC1EJ5kGeYICrgowz7qZ0HLuoFKQv
J2YrtlqLoP9GmVAdzvMyzmwTLAPqdofrugOq1KBdpjQ0an2nofL8YLdFBfGPIYeRTcYkeiQAdlHg
oqIlWwgEI6tcPl380J1UJ/OqjkUaPdLs6BAe9VnlKzawzxPVubZwMfF8B/+0IiCghlgS20jzcHdX
jm5DSVCToAjaWo5oxII1YvFnTAjOHKx+GluLAWetD6Fa59t1nE8I/Q3FmyXh/w0/AdmVGFMCAUPI
aPS1/nvqCqb/2Am/bZUhc/hCgD/Tor7LKg4VEB/fjkoH7NwAWY0uRmgM9LTu+4rh8975+EdMbzb3
1MXOL7JvaLGsJPFvG/PTxuNUjkivEa0rMTmNyDWDOc/JzZz2I7Eh1TJnGtcDG+y4HvsaUCkTwuF5
KuY6/Sl/prOvxE8deArzQ4GHoNCB+jX/k+rv8Ng1YF9LypwZQeNAQ+FRfw5osUl4wHq+bZxd/LgG
+z+ngbCT4ZBvjm9qcWSdj2yCiA6qzIrCFIghOWrXHEqlQT8KzTKOhfXh9A4jB/DOmopscZVoTuOx
3ASic55yxBUJoo+wk+VzeSqnuDrjig81WMvmKpGzqa7/HsaXcnMrNYHnL2/H3G+kD/+8T3GlPISU
iXcXJRWH/qL+rktAEFUZyfLQ+eBtSp5zB1kDfnRXfbpN5HnV1cNPZROGxpxKwmCPGYSl3YwGfwQv
VY9neKAJrRHsZwX5ewdWVMSmKGXB/Kk8soGtopbXSSJtfby9dwcjCG855KGa1fRuBplb4B7157HU
3jJa3UX8kJRBaL2wd9OroTRrtjeTS6GFJDYVz2jEGPh60SDiYAHy6UrqdV74OHFQCFm6JYOK/fSC
vThhJ8npaiH64wHYM6Wj+0W5Q0G8AgYD9jy0qznZ+9L2i5AHmbmquBDRaFYq6y0lcOcZLdKlwpEB
byT0RF/0Vnz6ZO/BBWl2h2tEhnddD3LSgPRlvvVC/ZGcUye3ovNxqejFpjrgndv03348e2sikzLC
EjpMHK0h23VPBDp+u2pW2KL2jmqWMEsWCLbuhoX805eUrcFqqdeWn0daG/UdEeRQjWsLcolvZSpg
Tl0zwoHhfSGKJ9bTQGLbv3TA7zH8N7yOWhxF6NneswO4ukyQQrxU8M/By0m0WrSwXcWlbdvBPTVx
0fq422nQYfSX/4DYkn+Q6QqgTzTe47GGiw8V2RxgLx6QZ+QtI/J3Ojsk4/px1IpuSI3maQuqb8EK
K56SsSnPixv99vdqOdylmAEytfFoLBa5dgMn4BHdjCOXL946hiH4EPj9hUpxH7eX0GNhQL1fCwBO
4je1P6+7Qquk2CHcVZfeYS+drxrP4oj/yegWJg/zqZYL9Jbbfov6I6eR5t+y88Uj+jp6isAFSeFe
sVTIIe7l5QfzTllQYgolwOH/JGy4rCCmlwMpMw+1tXeWTssaSwxylx+EeQzVs7LWIRcoIUP/hcWY
EaXvESuZks16+ZILQPeu0piePf5GLlZtLXioz4DAwE1I5rLKrSOCVk/ag9HHSlvLmF+M6pvp1Zuz
7MrQxNudbzW3gGbuBfxb3ErhtcmFvaKG1hh6LKbUcZWcSFvZinkHH0z/wLkpx4GbKaY6HuPgQTz8
YROuEPaimbV/nKvUIXsLHUxB9bJVmGMCnrxRj4fWm9jNdkFgsCX/pTny0qcytbZrPt6bml/o8I0v
quSOtgf3mpWOJ807OIv85TufpQJRVTR7MFAolUXHvX3LYiZLBIwd/u3DHO5yJ3D2mKCYK4Q8YNGR
fvynfxjUrIWL0/2ODbiR5E3IDsVMIr3kkjw04Tp21RZtfMsuz73si10xJZQzvA6Jhmlpit9g5MSo
99PEhKZy6GF3Z+Vi2JirLh6V54Q4BLqLh6YzWeO0r6nGq1kQtUjtmNbQ3Ou+1S/6ZBVVBQI3PLOR
E3YHQnSjhL6yzQC1slHhB2EQ5HmAjSUmDoeDEKZ9nxD1ifSd5KNY5PdF8SemvLUmLVFl8c5wAkq+
G45IngPvXLJobf6KchL+0XgxaxpdRapcC5ORCBTgv7C3lNSeqzHaAtXADHhs027I9G2L0nyxngfg
e6/KA7BsWGjVz/eWeHAmAgVAV2yubluw6ePQJpAlie4mW5RUunWlY9IXhl3OkG62mGf9TDaD5J4l
0GcmcBklM0==