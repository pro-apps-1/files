<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtUqxjEaEjFaiMXxy8cmwXiKt++ewDed8gUuwiRj2x9EkN+Uw6zbBG+jTfzt+qllDtxnfxaG
9DyBdW855/eJGV14YuIOu2zeFNeGwv9QPQjWmswfaJOC4uDMB6ZVLo3wtn2Kwgd/oNJOzXrPeUJS
ZL805mOlsS5SiBcR8f8CXZ3f4db2S6A+fL2DaEDj5j38naQlIFINB5gDlSz4cvEO0IBad4G6drY0
LuZIPOvUKQYEq1ppHXe7/r2fbeSNbxwNuRpQz64dw5ckNa472QqPOhgG+vzhhPYw9EeGL1BScBA1
kfTt/sXDrfvONeMT48k0vCgEayIpFwFmA1g8yuIeZ8q5+p1rmJsYYrsdUZOJ6x8k1YkX36YV2KVK
Ae1zX3J6DcqB+ScpfDbxpPzrrubOwURs3Bnpi9e61fyFzV6723K8/94ifH12JFL/IUIUG1LEVwBZ
J1j3h8mj3j86zCQ/UQRVkN6TzeCAXMWAtcMfXU+bMEpNarzJCt0TC3wvCo2HPnwpNEZ6xk1b5Eh6
Ezc+oqTeOme2fncVRPS277YKegwqnW7rjWLSSfRyW6+Isv3SyBHepOsALTGB2CjB8h6YTh0SSec7
7UUxtlIHw2UIjPcpzoQjX6IDawl9lOQEZLkuwxdc309kg/FZqYrQH1BOTMBM4v/QWimXCr92POz4
UgcQW4/zBm5W5U1b5wA4UXM4kQS2+PBuj1v1jEy5+Opr6gggLEmb8e23ygZyPJKrEVKa5f/C9exD
+gfrd/woWegpgOT5PJ9dKu5Qex6SSG8JSAt+aSw24IDR9xdzfQDLtn3dBq3RD01KuPGs6XK8TJqH
GywUulRsnboDvHkZJj5GdG2LVmVbPCNA+SmYVasRvd98zGlw0IZLDCfWOFZ4DHuMhuI5LMbLdbid
EIPHiblUFPw6RuCs3ZHE6PbTJFr9QvMA4Kui68nDlqW1JUlKFf3mK0DXbJi4xJ5LuF4tl3EBz1NX
/dIxnpLGgRx4IUNg0ElPYRCzrwlucKoPwmY8EsfMVbqK5doLQZjhsrVsuhjAERtkoJLAZz1JZnHC
SD7guvLnxQCp+N0LpPS7rB8WhuQBjpksjGzNSqu7QdptyOHw9sq2OU6stpTy4QCD7Qmu4HVocisv
Z0uU9Pyl3YLm8019L97ugieQ1i9lYhoQHMu3IeHNg2NftxiIC0lPbxxAe1YNq93aNJQhUu2UJh9W
CV2AAXOLx54HPVhNk/Wf4UaIZ8UkdXZM1Eqg6cViE6wRdsB3hmfwv2y5DBGJ6IrzIzZlLFBtxQsH
DG3CMFodJ3Pa/CAVYM996V1sg0DlLUuYKh4lnngGDbrkZhGTZ98Z1787/x53fe8+LbK6fZeQzmdU
IclcBxtklqFsN9PxQY7IzIu9X7h8yM+/0ZL48mk205hm+zzM8ELkIEQwwCLSqGds0cUtGxYEHHlA
Vtox4XENAXFCy+UFevBVCK7iO/nMC8bdcaohC4gPcx4YnxdhPKjOQmBhINnGqSjay2iO2ZP25tb2
fDIqqpfBYru0BrHp4u5ObjrYrpxsCaPTK5dm34FllcEJlvLXkFn4KeCY2Y1LjHMx7Xy+1Z8rq2df
dZCPl2gHp3rw/vbyEI4nN0qVpsmQC94LMp+170RUzGJUVzTBSGt0R7UVE+JegVga2r1a3QJ6ixjO
1MHWkKs9vwaJE0Kln5e7/mD5eqy8XvgiEjYYkqWkd/5+n0Mf6oEYU95HhzUs3obEt/tPpWvlaill
cbE6N0rPYXh2x8jTEre0T6KNPbBq1f++eelkmLcJlrwPhU9hqGMq0IQHgkOwZw/RwG8OSipwQefV
0GQ5i7+9aLXyfXqDb/nE+8HD0owczdGEo7R6wdNqP4Q3jIOnMMg8+SivQxERaGebZKTQVvn9MEXh
mTLj/wWwZvxZ+8oyXkXS4lk4ZaaZZdfwpTNXDfgp3UgjFMmuD0UJ4b08wsDF1jM6+Z5aVivPFsyw
Z+XLYnO3LMLDMXVT9XwQTYmU/keV+6enoP7yOyQ4EKo6TxmJ1bbWqqyb4ipsm76151Q/SWe50j2h
PhLng2DJqNCV1zdFz2Bbb3euB7cfprBHlkHGb6p0UuLXEiGSSdOu2m4fdwScAjiBshGoIl/YKuF+
hW4aHMnic85z3y5F6by7Uj8W3ScBTBGVePsS1oeqGeJHpxNQnuPJvg0a9oeGtNKIUs9rGNoC5nmP
zcF3AMjRzURozuYRnlYeuRKiom==