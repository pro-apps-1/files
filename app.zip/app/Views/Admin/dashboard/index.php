<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqZ6EqPGT81fBHgkPJ4ILIwVXwuceOyF+AIuEroLv9Aacw69cJH4CBtaBzH/slio7+0VPotB
DqBVk3URNYykQ2dbViQHQaHULU6Wl21OSBTYb2ByBpIUaW69t3XGnEnqN5dvLvK8L0E6teca/LyH
o/PqKSgzkxsIANULFMDOhdjvnd9wyJK8gnqgZ5oRhUFZ+v20h68N08PMaEZ/x8r+f3AUZHt06ymv
WwUYaSFl/4E6i7u5B/qiN7LtotS3L38La66IscOEfIpv+5PatZdjxX50av9dpRBmBFhtU3BtxgGH
k5jh/vdVsFawYfR7pyXt5NCSVKURxrWIzhK8DmSpqyvxNF0vP009rbKlX6vfrMHtnVz4hrRbyOZs
lobJyrjbWPP1mOQ8mmi1FXwJtMk83kQtRCVNIsonZyMtOpcUcKBRiRG1Utd/ks9QRjTQ4dMGb0U8
EiFO0wwotS7UZTlfJ3TMPOcKKOZM7E2wW7XBuhS/GsDuwBE1zYD438WdWqTvZ0zUcy1vnXrTjg3i
dIG+AczqcQ7sQixgHi5CKdBfsaE+pjoaEXG5inY6Ehbe52PBE+/ltgRacjtvMMswI589GKEGOPyw
HRHbf0oeNOs0r6QsIjCLVF5u1uLC1Ryjbr480d0zhMJ/3z1indjbY6hmPzStVrLiceItcJ9m8GRJ
q8NgXkVegV20shz9Yc3xlDoKBUfdpScrzgjKma1WivLIdBa6UJ0cNZEjh7Z1pnO964yUsCN7kJVo
51V0JnNaKWoiUsvCDbwRQD7gtNHP+0fGUGPGueQ3paDiMa/AgGBZ3Um4nInrLmdpqSsitHsMQuX7
lQvlsozsGVLNrKnDg1bX1+ld1p3uUCV+M0RqC+d4vEGTboQMwIrujZ1GzxoRux/UbX6+W3cYKbvC
x0QPFH9yRZsF+oRD06p6p/DDmUtqmrZ4X+tSa1rMw/sr0KOX3DWS7YEL1OhhZVoSmfw65CrXb3Vl
GTKO6/+DL4MlBUu1RmSSqWrjIkxcA3dpayPIaL4THgnH1RwTzG5oQzX5kXVgbFo+LAPqoaOTXYlB
LhIpLrQzJcmvuagOVhtkaow8zB611tMhdJrp04j+g2I9vWqU51qEYTbsuAO7Y/axJuz5hI1JI1Tf
lW/phaF/bgj03on23IxoDj1FYlwEyjRfKwQkkUjVtMptxhJ6yef9VwNeAhOv3+AkjEFpOz9oe9JE
m2f0KtNXswlhUVhnPXC+92RZlDWzGZTHIF+E121Ip6QbTrM1Rs5Nv/7Dpy7QqXpJtXVJdcYEyw/f
e7iY8V/oZ1yORrKSKTQhIfhUYS5AmuF5T02w7Wb/lEWa/xQdZ19ASDvCrxjOpVjJmnW0MTCZElUD
f+x3cVzBYBNQwM8hrPeu20cAcRGUggFSEqfMnd8vNHaqKx7eHeeqyJF1d5XTRAl/2HYBQk7rsD7N
Eo7fHXgsdN6Ejc8OEkHhHMoMk1i1ewB/zUE5KOaSEISFS9vFyOjAQ3BVRNER0WpQ4Enx99/ujU1O
xdFvCokwAWxc2MYVm9JDbGTMYgySacgmR6W9GHcRyOGYOgx7uo1DH9yBZ5ExOcFbOwcHU1BkaLK1
lMKGntEMHMpfrLk2kAENxBwTBYr5PqD/oHbHbnzs+nXLQ3wQsiRW3xwjjhTX5xynhTbwyCpzVtqv
7vnDdaV/65NOwPGIUFSZp66u47CrJCmA7wnXAgCsHKvCTfRyitnWHtERyIE8gRPx5K2w/B6jd+H2
nOCw2gg8MnoNXzhAzgMGYh8hqkmDYLLloEWxFbZDyrrk+JbY3iGGmNqTvV0BHy3OCJDG7IVMBVkW
dC7D2fOj5Po++TeaQmTSTlgId06n4gwaHeG1K79ojhkOtW0fQ3/MaXMT6ZWoQ0eNKDicIUqBdCk6
kPGnMr0Ah2q+QjChYA0nj/3o0A0YQxFCNOeKmr3OMPd8fPckiyiRBCSoiyTTAg5L93ctajeJDyYH
k7jjW28jx2gYSw9DcbDwlVwSc9QO442FpB3QEV+7K55WIFyrikGIk5ovY6zz83eInQbQ0AcRlUZU
VFkem1F0tBNviXSVHI4qYsoazdJTKOImcve8yvO7Ht4shMLfQlIsMhYnw6vfIqhrVO6sTDz0vgxM
69QtfeVEOTZDUslD12FeK6os0w176sK/p9b6A2e0aBUrBHp1wH6PVtADG36iibOnykOdEj8p5nxw
ZqJoSS8M2kIabrPxbCTPEgYVGcb+ZF6l+Nzl2wF4/JGKwu+90esAv0XTPpJSjrzOUQQjAv/klle0
GhHyfE/Kf3TzPuONBjdoWxxi39a3QqWQ0dQsRiMmFhNUCvphd/0nf1qStvLW9MBHdsafNao/fkAE
Z2ja1NGRE71W/DEWoLobbbElBtAB3cCm1GITX8BWGJUkmV9x6zGtY8xJHc+g2PvHeuEHLxgm2kmI
ytO5lTPPgleb0Z0=