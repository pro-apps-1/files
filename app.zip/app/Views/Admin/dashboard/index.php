<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsBhVu+aQqIXiJVgh4eTLJJmN84NhT1MBvguFPfF2/U9EeiBgFxPDY1ADkQYSWB42HxBQRS4
/Pd20r7JuUD/L2x4cqrpO/LeLIpEUyBYD/g6pXKz4bttd9GbiChxhYQ5tn4FdTZuuVsXOvf/t2XZ
yGbQl4LM7xbBYd+V8H7uYrIY4MerGVyrKn4URzBbH3giZbvm9ge97DG5wK5aDdf+kexFKGKhq/fd
q5NM6QcVRW7S8T0Iu90agHMDO80eNyi9ejacDDLlWsO5PxOd80HtjBOots1aCdaI75luDwrAPzMr
X9yvWCgAtK1pXLNmj4+TVn6Gkl+Ax+fEB+wULRM41DqNsE95JPviT8yf0k0i7OJhvfuYXJaKwcNP
VhqBTUA2ljtmnOfu+TX1iYgOYtD6TGYFYsL9jGGMcB1MuWA6j0U+pL86Q2Ghjju3sSIVOYrjk/rL
+b88UAt5z4b7uW4Do7HMqU5tcLOsVdfdTALqSLmNXXjEF/s2COFAFJ8VPoFEbdpfkTjsfLLEXOCX
lOEaojIN7VCRzD9Zri/nUohe3udHd5fZf/QEFzvzoumov0BHgVCu06MFe1Qf8TkO1FYtPGiYkWjE
wyPt/efg42xvyU3b2OrEf4nWE2yHs9MWbmMWhRjh7kGGuN1j4q7K02Y5pPmDp8O0gI+kwRLs4XKU
EW1SFreL791b5doGkyPFOEE8W+T8hPS15MXA7Pugp8Sb0Co3AcWCM8/GhA+R84GAXyWBzefEfrMo
cxYmtS58xEbPAHAn8bV18bvPq8TavZ418u9R3mytNf2kO7fCM6tazdWJuJK2ISsRsyZsodS5AuOE
IJ+PalvfD8lnrkXlt1P7yuckDs6mtlcZwED6XbDWgkdQOjU0TqOLvvBAdOOJWYA5Vj4bJwASxSuQ
eFgeH3cw2uv2d8oAJAHUjQTU+z6kNprctS+rdolnqy3ByY4T5fAEJcrIFO2p1XRc8EF6YWZ6Mjoy
jBfAjNybKEKDdHVJN/yTUdvTzmidlC0CWk635UalyQs0uD7TcIsadqtBXEEUMLUH+sHdKpuuaeez
XIrqdZjmE0hm33lJzxYZK0enHmzb/90tcmSDCntbDhE5e4F8ZIIIjEfwvUfQOXb+WSHRdrr0EQVu
AXMFqemTpAdi/Vj3eqqO3QLqZ1mobca9LHrYBpzxUEvwA9ES38pcCax0ePIcMkXBvh2h+rQDA4QC
IKlJwMCEWfz2HIfpjNKC40IdJctJLR8+3pjg4atP0ANZClqVhHRl182TpHqlmTlwIlvnqCtWNNJF
prWfEGD8lbXYEvXf9oBPz1uETPtmq4oFJQ8iuXIZhx2fipT+lKy10iqE/rFqm3WB1qjraDxLojkf
uz1GLK24KjnZ3TfiQI2CkTjqaRIMC//zdC2OcehVqBc4YiWCVRxF3UtG3xeeMcuzPF2u32zPbhGT
9uODeXNhVpOEZ0Y1IVo8gKVv3kWmdGk08h+kP8+vjcu55ULZQSEj6KcIaBMG+j6v8ZcXZSc2X9Ch
Ua5tjosxl72zrWd6ZLMH1w88wPiSg5B24P8hYBBN1TJOKhmJaFv3pM2PGlPAa3bohEe7GGKig/Or
xBFHKn2vDgD2b+tTREotVUHlCgUm7LDiKTNUPTG9uvb8cjD+uHoFjv4nO+cvZdPhfYtRhOe9yjg8
zjjNM72qvQWbuHDjI17/rxV6FgTkIUSJfe+117E+rRJ5WCq4hehjOVWxPUbkH5ZImL8628100CFa
FdBrVGz0eqfXHYrq3kjjHQMCvfr+8OLWCVNQz/qZOP1jI63KnHAAJnMd4Bf14MLitv49USneLtUj
FPNsqLnsCHhobbB1kpIZraTsz4c61Gru0dJ+flvjMocM6gaeIIFsrrvQ7iUsZ0IU/RmwWwqfS9Zn
pEOAoETkGoryQxpcpheYpI7pOsEaS3t/MZq17o88fsoueNY6nDQuH3P+bsbyAnH7Hl1pYc3dAdzj
1e6KpBDKSnKjd7NYGdqQoWWOpiYuCS9WImmeuv+RphHAE0xIsg3O/n/3GeBhTzqgrTipPMGgvYzL
hPz1ADVfpMqsYU0Je+V0twbY+9D0QY6HXX9sk5tJTe0mzgeBm9wc1v6BfxGi3YyHfwWnWhx7Nm3f
usqFBQbyQPzsl2uSsyqotAF4RLnlTSX7JuW3IvZ0c2A4RsbGcD7oLW2w2GsPHoXLA3xhZrH7DWcs
Du3NgO30aK0=