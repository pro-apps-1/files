<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqM1o9pmCJ7JZLrTlyy8EgmEnJBLG0Dohkuja9BMfKvblk5Om5hdIs9en+9mhhjPK5ejqGoz
a8KGOpx+hMeqKZJAReTP2sKitoaIhagXTOuDNQoNMkH+WiXtiGHsRmTVoxIo4X6vvMVmmqgqtF80
wpwcshTWBBNUdiliBwBIRMOHptdCqME55/d/EOPTUNakHTm5krI4z466ugMFspk/jH+KdTBwgPsA
1TjxkvCHa1Ogah2+zVJbdaPI4KW56VuGh18IvxaiyeWvHy6v3HJQcNjRMuO52siHd93u9ymtivv/
7lVHfILGzKIAXvfxDGfGLomAn0pLXdxU4oJhJJGeOaTuzFXs/0YkEqU0npeA3vX/utkk4XCTEmi2
/rRTe38031jdiwXnysxjlOp3vO3c/AF9x8Qg8jw5KKaHvLCL92fRJtsS3rQg8NYlpmQ9SYYSt6fX
caKxSIIH+p3qH6ZDQ62P29vA7PbkBvFhws55DWKN2CZ1bnSV+C0JPtobl0fy550wrXHILoXUAE95
cPYSf1UCMNZTThTxOCJp5IoI1A1IeNmT90XuHdchlzmC9Fr/JGW8KMIvRgHcHF4ZcklddZqmK+Mm
YMMRfD2ZRWtW3LwR3L7LQP6OuRbhq3bPGGPY/xr5rUn71CaDkUkD0F/C/4L/f+JcXX6Y16IpEd93
a6WxLOPWQRH/4jAd1ElqJ8B3AB12nM0BFWl0GLAoR3l1uFXQBTfYrxaqYRFvW2Qu5AMchf2ua7fG
FhvdDh3O//uYdp+7aRoCeE8ZtLfUdUiihnbP+GFBWANyAW5QfkBHpLsjbA6lkTLnHu6iYal+Paxd
HFFCGjn1KrOAUDDLJ1Mol79Zd9qgY7A6IrZ7LATYeV2ylM8XuBYewn2rtXlVeRq4q6gmEIncwTng
EEUc4QzNSsMsTWuOEw77DtYos8HnhV3RG8XxLB4+Fw7Jazm/yGQBd/wUS/m0wsOUp+iTXq4XXaWv
30gbiZt2IKG0Ei8/ExSg5WOc6t5cEUl33TfjEVu2BNYUBgJ4LzUwb0xuj+xMXdLVviEpqOYSOpFd
XP4PFuqonhJM06mdKKtLEm5Lcx5Xma/JOvtGN33si77l7VLcE9fQPbnqqOjeWWSe6cWN2Nn11O/D
nfXIEU6rx00TwnkJlM2wRtotMxXy182W1jUXjGY2y7YO2Fc1wCdxSS4b3Zi9h1OnJVDutb2sLq6h
MSW6rbCEIqphi72UJvtcKUmiwbm10rKpQIDIPVaE/VB9/fvoOafzSdPfRzn5ZmWk1lErTgvdUCmi
MAli8eHzVoJyvoQFmZxvYvt/00rEeDeqSudpu/asVLwEDT81LhFtQKpJcHyC8V/J34oJwnEHiRHo
Q/3j9MppPAjD0ahFuDj40B3u/I0rCTDgVEDIexPzJ/GD5UCnfeaPd1jsLAlR3mzHTJ4iVoMiuBfh
KQy9C51xVasJj07SNr4jPc4nGbsPDSvVZtp4EQTBWacd+7sizguUcg7YLcw/1zEk4DSfinjP/3BY
kQAibwni8/4JLUwCG/zHxzPLjom+/tVdPnyc+WnlcBh+nxsHnyb/Nx7EWxV5hvKzyrxEYHkM1V+u
760ga5wkzgw8+2fUl2Tx8pqRIzZGW2eGonh020x2NGq4fQM30eZm6QppTLagtLZYNKXDsRpF6k6n
yG42QjmVUyHWclvLiDJ/PK5R2+IYK389qhtYZJD8cp8hy4mrVmCL0OykguEHvIn7JPf6vOeKtWhX
5YQ1TD7LMuFtvQgf4lvURlZu33ra/+RpBD7ZBqb15roSIl3rjXaMIYQhVJZz4F8fFU+OHzJMe4Zj
eY50Cg6DGKozLAd7/ARI1b0UHck5iH7frZHgR3qdNUaP3JaruVtLhZyVwfKps3OaWLP4M1+zAY0s
+diANocsDPW2MlDEbsyTz/H32dxXIrb79pZSg0+aK11Pdl0EIrYAgqz4cDD1TSyzMnqHQslgDs/M
0vryXRqp0NP9dV0cB499cLOf+vSiuUTF+yqzg0auUEJxPWZXnpqkY9TuDFMgC8k0UmB3b4M1kTkT
GHi+eG1f4Kxkj3NvafohDAh5Qe9qv6sZIY2Xjjo0lgqUfqvuesKtmeWAS529M1PLC7RxfHR9Oexi
bH/I7zOdD2AucUvkCja7N8qW7CbeQoL1jJ8/xi7jmLOe/9JpE3BeHvn69g9UHjEL63gl/D3OddZo
/SfWXanyDor6dlO9lVYtnk8=