<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuFOdM6qcMPMGGG8GanPjqQ2B8AJr8xT+9wuO8Yy3NiOUrDeld9BTf9ycI09OSF+Vx8gOn4G
yz3YFJ31+71ybMGqlfwZhEAdds8mrZASAV8KL06IBZxeaCE8IeQl/TX8Dc4AxWEl++u/FHEJC9AE
oGqqo/n3foINyBFg1S1dV2KB+fHeHH4hSz0qspzS6Rgj8s0g3Ff8Clgn/LkmxoilBxiCayDxUDhf
TAPZ+D9Fk6w+ulkEehQBPSe1GVCSVlk4M+47GXwzETahMeqc6ktl13TsVPTdMLgn7ViFMnnDDWyW
9Bqb/nHPK1cxlNvA4AJ1jqQBCZGX5JR8pmDX/7cyMHXwzglhWjSQ38OU2QZZl0GX4yhakaOhfZWP
8FskP2drOF7sDqVIqcja1iNscekSoyj1kUjkPDNJ6u0nUqHZUaBnXwtPzH6GWkYQZ7gEhvhp/QZ4
7Ip4f4gQZ+tnkCiRFsler+8EZ2BemLxu/tK/sVR3UA4vHZrO7ZIwkTJENzGK7lOt3XYARGUpaePc
v+wz92khmJkjr4ecexn4aVnxpPNjRRufDCF4Qi41Blw/PRlx70x889/BjxWjjiz8phBZcrFSJTEE
KOUOMrvxxUx0fuhXR0lzIo9+tqzSy6mRHksjpLLZC1z39Msh4ufYH+52VlI1QvwzEd4VWag9RqgD
Mtz1rXoD8CFs1kpBR91oA3DzWMv0GuD92Il+SL+ertmq6mQ+k6YLX4k0KfyK2BkcHTcHHYnxb5HL
U2qNPVJsyCkRuZTc9C+0qtcI0Ra7UvO/I2YJCJu60iK9SawPv0unggX8cFTBc2BuEvFzEhw6+zkW
Hd79FHXruEhburvOvmIPjhh1ZypZ7taQ5XQwfcY4zITUVOvyzPZdifcTc2BnSvTG2lybIxVAQJlE
1+MUmo6ql963fFbx17aCFzFWq8SSK2ot4KZeTcrNWKSA8irbyxXmsYdMHl+vR2Ip6p/QasvOPQCd
98srb+xYURxj+Bo0ufiOiwU5pPTKD5Hww7gt3s8FXh24nBcGWdNyJyqw7tmMHX/gl5z10FVeEt4Y
+if7LAMVbZEcCkIONjadT/MwRdafMisFwH2TSGS11qymcTltgfvMLF18WhatmjZHXcoEotKfkfXS
ZxJu9v0BcyXZha2BqQBp88lSLLi49wW6wtLhtYPdZZNGOiQezStSzcE59fM2GJXRzjjBtwLcWVoi
VJIsSa+QG/RmjGR1xeGnASNpltZofwEg/ikHcUSoEqRI6kiuB8BkYBrA1cYx3On+rg1ohl63T9XK
NOnMQbsggNg+ZN8OpAnqIF+RD1azHBh6jwGsZC5f0xyBadaD19osgf5vJi1ojV7QbG50p6HYyydq
h7VLBw1sAavr4+K0Vm+msKvonsIz+hWx86fxOKAEaoimJc4tQYpXdX+hhO84yvlz6qfjSQkN890K
mxyh2Ug/DvdXAGnKPV77MBIzgIXk3mw9+GfA1r99h8igvYnpxKNd7zvq4kLTMqZYOy8hPGMikdY5
ynEaT/ZIXtKvKtMu1lTUlIQ8KZurxtzQCvJ2hiEApu9j/ZUw1ajSNcMqUt+Adr5OOdbZY310iHHe
c1uTP/SRAfiPq2Cpj8mWRIgzgGabtB8uHpySIUQKqpgrH+h9ogOk0ZD/ElYNT3+RWZQW6KWcZ9Ue
ziP9/NJKgNqG7DtsEKvwFh7rdsQbs7kKO9wwyscE4vJXTJVQRMHXS6xklHPR+0CMhUAXY4Q1BeEt
UB3Ak02yPHIoGmTc3e6IzQz6X67+cFW+8JgpTDYdQEEaU3AQnYRL+ar88XrzLISe+Y5dPfwmV9y7
PKKws47ycOE/iewZCv69UwPp9peDCdVHmnQbKQTXCh1M/r6FMsPslWwvFuExjaRWhjkPT1U1Q0ga
Ivl8Pset6CDUWWciDuocm73lvu7kiRuTm01BA9GUWkYZWZNMsZBAUpwrRorKUWYhN2rkAmPiYu0a
IqiQE3zsObreHsRMHRWYbFngYIjU0jCmJO3xPvPRseMpvxfQ6Z3IpgRHDgLGryRlSzcqm+E83WB0
S8xnQN+iFgmGikIA8+GWFm57EnQ/tmSgrhlfwExgoh9x2D9mz2nbpmAtS/tw5qoPk2mQP06oATT8
GNX3kewTAWkt8rlfqU15ztDxItRjTQUONcVJDHMcr8lLOyKBgtu7tI8withzFbT13b7iqPuDmn3D
KLkjQd3ed8VAXWWE27P35zP7krtF0tO=