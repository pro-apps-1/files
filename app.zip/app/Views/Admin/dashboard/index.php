<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtm8n4+KoV/lO67KKMmFyepUe1Lb1+0uQesuglXEKSW8GOevTw+4Im2dzr3ORgbpNcCjJlZu
85LqbfeGTU+mNlJBycX0l68DN92lMc44Wk38BNrqbKjVu7UkRyaKk3YzXVlEtj1m68wu5HTV4f/6
pT5KXJulm774NLTg+xJj/pURwEoftkOjRFPJwjzd//mko1gvFjAo5M6cBJVjUTg5u9nWal6JYQGl
Wtb+YwECdgCfLoM73UvSYfwbOYqkXtXUMKELZfHpRblOCEp/A79DslgBtpvlvLGaM88zb7DNjyng
6Uq9/se255IltwqW6xV9oRAms1iW6Uz3KhuUrdMCOs7SjazfTOk6EotgpLf9Z5YxQzFFr3URDdzQ
fOlmQvD2FUPM+cA4uTaPmeJrR3xkmpLftpUUYp5slPSdl93nw6TupCQsdx10Y9tHqvhrbEyM9i/h
KTlgkjtEwbCNSAV98w0UGCT171n3VBcilz+dusLNPF4oM6AKxT2sdX8/i4hDlUp7Pg5zVqqY59om
46RCRa7J/B/NDL3d2wiQMdePHprl2KEWy0NuuvP4vpv8orHygByptA6th2w0FZFw1IGYjw6I5W09
60Zoy74gpK4RnQZ6sQLOd7cJf5EgKKz05p+N6LGKpHt/v2vYjbJwwTqiSOAbIugIPtVLiZQCd4t2
AHzAeoM9CBd//QXr0BUSG0gScu8dRUL9lV+FxCLuDtjbaIulFhHiD1UqIX/7fXc2yMgx17Y5ubsW
+Zq5+l36pvo/+/CFZJ0Uu26gRbgfxzXLkHNag3zC1j5cZrhM7M5aGiyMfZQQNFHK/2Owhdptkgy0
dIo4QmATTERlmksqZ+mMMrP+XFzIqt8pVaDZ8bxKazFr1KS8aXRe44cWwBUrLyxxSEiriMHpRwVp
nnutWrJzKEBZQ1/sWmuKHD8OZQYc7/+3PUY5WoE1J69+IP1fsTBRPq1GVFL6ZaGLqsHK09rlcqVp
jkw80V+vkLQZthzhaEnD71//1mnmg+KGwnEgXkqzEJ8k/B6Qs2UxxYPYNK9usBeFStX4wg17gpGB
orNDQTK53Wzr6hAB0zL3O45NnBU/n+I9Fr+X1d1Ll0YSVmk9gWemLF7wXoPrN9rPK3Dx6tCDAECf
VFePiEDUlG1ibMfsNqdwyfI+vTe4myDUmZwbEHPVczTUcblTIqprd050syaBQqrQfyLMbEY77L9c
1EUSgWdg/VmQNYpqb3NQ1bakiukG4yaXbKsrpl215U4TdRQepROgWRXovAswCM9F50H7yW4PjL4i
ZiGDtFZDgAyPUNJmdxGmw61xcRcPtUyl5c473lwe1wWrT4ji96VCgAVnyXCY7/i2yrvDMNkrHNF1
7YGfXosJpvI0cqW32mk7LfgieOUpTrMFshPnWGQgrxFBdoHio40TpnKw0xMu56JtU8iiLydhEL9H
xlo44WRkGg2rIwlkUJvUM8Nq9xGZaLPS1W1OYZhpY31n98wubH88Yfoofxm2WGqbRXxLkwjnhXmH
qMcdcJc3ABPbYRyPKBnqtgmi06XdQ1pMjs0et9otXIHF/KJcUQkeQ4pNOi/BO3RWW3TQ7kkgtfyB
a8VK/1+k3cR/ZUqz3EfOBTVocbPE+3YKTRLH3uJ4uUDS8y4psfN1a0LNci/WdBfey5ENI42QO/bn
MCGSoZ6dkZd/t8fEsGHWvGSEw1gbU4ppHEuE9+CAIIA2noVwu70BW4c1MSdWt1mo2/b2Okw8qfgX
l6Hj5HS0nz3cUfhpxl+LuydpjYuSaQ+uYSFwKBCXTDoIGU0AJMqAlbmDuhUvN82A64XpQ2T++4NI
DKz00nvrD+OQm9HcGcZWI2zdU4lQNem73iADQU9vUWm7NPohh0gSMsqWMVivl3IuN4T5WqTQz9UI
YgEeZsRn1Ct+xg7s3aEJqY/7hnUR5TvZNPAthg2l83xL3WCDLrWRvhW2GXhSAvK4ZayNR8RzNI0X
3FPOAni0lSjdENEE0PERkLRPT0RpYqWE1lrisUt4+OewEpi/8LY7CiHB4NEUdkQHnttdfzbIMeRf
TEj49aHP9cZ2ZQWW2LFNL98uYVzNtocSyN0tc9SVblreEc66yyMta86aB2jHBho+UETmukbvYLP9
AKHTLs5JxNpG69nNWT5S4lwqnxfd/toGBTAf+9XzvZtaXPntRfCDANLJM+NBVD9JpCO1o/zJLAYP
GQnO9smGI18mbyDzS11IxOrBfC4/z9unNyJ/QvkKOmruNWnvvuyrWcxTBEHlQw9+SJvE8mWfCUjM
6GGQbWgPl0JW8zOI9yN8ueM8bNQddZ2BABxULWdEM/Xzxmu20jvt+rEyv2Vxh980Hs+nGrhc0UpP
RgxbqKAy92PKjYZDL4163dDwbN9cNwHda/DVYE1JXdTQ9JVBB687xZGiEpS7dZjdwFRNMmw8nl6W
TYHlvxhFLCGe4qhjw5Ur1Hjy+0==