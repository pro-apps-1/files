<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Wv/xTjARc4GZJbgKuba8DbCgNpkha45Q6uTvZJCPUq+p1TKtvAS5sWZz+RBFawxGJfEVys
GwHF18iTjsNdJcefD8LEXMOSOYx+8hEAFYKzCmaUWfKj21TFz1nnTlephCFIsh+oiWtPeGaDI+9i
dw7vbalhqe94b2Ou5cYzf6Ho6q408lUr6NKO44/udpL2xQV8lktyInGXg8DibBL0iGiT+6RStfR6
v+YTa420Uuv3rP6W1MPgOlImefyGJIMjgXPrjJZsJFEcll/GK0o4YwaYPNjcRPk0tUmBGmLPCgxb
MpSX/pUUQN/S7oXZIoVvEnXnKgGe+gBlNL7RB1KBAG9ywTRTCzq/mFuz6MfGK1u8/hNfUn7KW8hX
aMSc8tedy9t9i7eDVj533gN0xalwqN8H1tXWT0k3lsnAUNoQRyIt1SoYs9AbjWeTnSME9kGdYz2b
rEYdWuTIfZJs+2bZQTXCmTGVMYBqa08g/qqGNqVd452DmGlnbeSRxWGKj9KK27goqA3qIgzHpxg3
w/+XGr8MrjLUfuTmueLj0FalsY9LiE5yNGcVw1uFOwzP/8/kKwHJfiQHY2NA93CAVzuN2Khhag5R
zw7CpLZ/69cB55sZUmySS7D+4h+pVIHpgk0EZl0qT2SAK9MXevg5PQr0fuSfSKCXaOghWGuecMr5
7mEgAzlD7bn1YXPqiAUECBQKx+kUcpz7k+R42TCUr/qRzyYvnWDima939lC5Nk+oxIdedrxeGkR+
aJqzJrkEkNyAoLy461Ri8H8jWSOfhiaOEh2xPh8RxVCrxhYaA5NxRwtRm24jv4SGrVaQhBbZc7+b
1J13xw8Eh7etl01t2RhznXbNyR/NhyzmUKETi1jWH1CY+oq6ALnDQZtU+PeEhEe65oi3zJHDLpAD
PRfvumQS+E38Uxcm7jKJWrgKEct15w2wx0quLM1u9AvkBuK0JtoMadgeTH/rw/SQ/321m7RQ+WAQ
RP/3nPZ955L1E2ItFjGcAZ/Wje2dTQpnM00PB+Q7YmVlNAhBzmht1xPiCuztAcq3lnmAKHsUIqsU
MTjrErrDNJPh4PBiT9T+zabt7AOcsrAALdTh4TWYH89t7OcM5TWuaawK/QMQ+uSdPeWskxE2Gg4v
vYoAe1MLWGmW6Qoey2Gp0uAaGFLjrll7yxX6pn8NNAJbjYJQSmmrpT72tsKRg9C7KRpEmLz1U2Uj
4KajM3hq0dCUPL3m6+Z8zqFJ5Uefo/mXxGzET3RdXGo9C9Hak2EqENf3h+3fiMO1s1oBUn/Xyfuq
O2eV7fGELBP0b4TFmM4P2kTBcRSmMTjeHkCzzp+MzQQK+QjMD7YBfplVuDGR/vAEfffUnap2XC5d
hjbmhNCSLK0SgYxsZOh6RPbprZkg42Ay48foquKTQ90HPJPgXk/U8n2WFh8je1oYwNIqnDVxiuXv
jxaUD14U552GdM8GJ1cNagXC4ulrzh0L/t8KDe2kMzPuM9GLa6yP4dkxOfSVuTCufc9/3kb00Hm/
pRQnrh+XUjZq3crr7eG0YF03hMvGjEreUxKczoIYR5MD1EOnANpHfCHdIdrrwGg/8bTlJKTEaDCK
+0vhLLScXM0uQpjzvMLSynxn+HxZSbBQXLABbDZbSHpDbKDcKQEdD/wJzEsdcK32YRn2270A/Itr
54EGeSF+lpMQ+HzNzCa+t0Kgbev3OH9QERRqVxyM6x1nx5BEUfcTUNv3bqrrsX/jal0o4blzCZRr
bnqWXVOmrBNXUVaAAJb6t/bG/e0SWx7M/IwwDHsIzmCPNdTRM7Z8rdfdHXMKGV9EWXqGggxXR5cF
Eer8UMAIsQYpU6qaEED6kpPsn872I4OUEKb/STzGP7tlZEJVzVTSbuCRPFZmkKvBxeY+mT66eGtU
7b9PwQWIq4NNa3MNoW9SyWNoT/MAyBz7pzjC91aqH/5Rbf8sYhRQdqvhoebrCrmmk4YEWlZmhBqe
klEkQzSfZlqz5Pa+lIUfv1EwhUmJ9Cs3bUsfeZyewHSh1N94uMchC8tTJ7gFe1W+SO5EW+drMOWB
WEoJ9uyS17u6d6figxQoS7AR9eIUlojv0L/N3ttekoT4CCXlD/yhX3eDa8egeuZbfiwWxnfS+5G0
bDcYKlRJHyGuVmqa1CHBP9sjFKmeTF48wffnhDfM7G9M3Y4ZfF1teGqU0tOKihMqGSs8a6n5iPm0
BhNMsZWcjYAwkRWhdm==