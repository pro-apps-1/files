<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq4gMUlDgA7CYFRCo1tpHp/AhTENY8jj+PcuBtoS7QPMHv2nv5K94aN1sulzOGCMlGj519IG
pd2L4AI5WgacC9aWqpL3nZsrBQmcgEoY0/3N522IMbpcoRm69LqSMbqkPxgrdDwN99L1rBvTJgTw
DI2PMU/R6Ts3jNMDmM8NpyhdGfPiDA6Z+oHr/TWnV7/+GE/+FMsRdA6+g6pbxgujGFLRdutNC24T
cburh3SCuUe2r2xebe/joYRUl9S0ItB1ufAdXQMm8g4wBvT9zN6ty5LBgfPiFJSHTPUvLSTZ85nC
g7WO9nzMVBDDLdpVQilWsoR5LXu8LiWwrxMgtIUCDH09DLFNmfQ/nR6oKvYm0NTwhn26sqdoBWYg
WnynNWXQ7pDSzJGkVGwt4wSCAMhroG8myXj8zwhk7/QcayYZche0EKK2+r6ki9bp/n8zZIKOxvd3
+rEHS8POMBCApu8dw6DFdpwluu4u9AMWu861G/aCVQLZfct6rZ5Mwfwk7WZRLGtfLds3N847Fbyn
8xnKNcHqmOjTFpUir8lMWJ+Yml7Eze7YnOpdKo9EkW34wDg0fGCSQS7XxsTqhfPCWLkie5StQ9Yp
wN692KdokOc/uDeHnjuP4xjyGEaExie2ZZzBM4pfjGk/R1K0qWPCYFGMwcNLN3IrvACtv5NOYhuP
YTVOscaCkvZM8txIvY/mNpGko5dekfquu18RkfZo5S6CeIz2vZBbRhnfW/4lz97kwZqDMaFuMd0M
w8OjIBBnTt06UvuO9pDwQnhh1PxXaWNiWzZUmko9P/rfvDlpORUHYyPVlF+zsjrQEe3OSM4P8zvN
83ihoPX1JQ8nYrKUfC5NP1AbpHLWZkFSalT8AH590ZMxGK+6XvSCnxQ1TRkZQ+WzPBMBRNrKJgwH
cuu4HRELDE6HzlVlFhS2zS2uk9ye7+KE9Aw+vIuIKmyFAK7Tg4MwzegoNWPAs0HP2SfGuhc3LfDD
vy2WppAejqyCX5wYIVNuJcbmKYexpuXuynNeaKywCASqewg2Z5Dqsh0QwFJkzVt5DJEi1rVACto8
SiRTnlA4sMPRtvhBLFl7bdu7Ac75bSo1xVbvuMIghCMyK/+B/3Gl0BazjCxz4DsGW86CMZezNgga
4praKoLf+tmp4t5TKUhffXBmhISU91eT8S4cl06b0dywhRDAQx/GulDePPqAZiGQCiz3nAeAk1Rf
vWVOH4YnfTL9wezJLqlqlBw62e4iMFbSQU1IVytuICLNDPf06CajONDFn49wlo2N5AIhGTvcrFcy
uyBIXzZr8IG6GMgpBd+DNEoxMBg+QIrNM+x8H+VMqebNCGbR7fgJiquM0K02/w/tqmXAku0Fr9ti
8I2wPFkkLbJZlGFX0JcBg9HqLsrBlhg/ZTujQyf39yOq8dm+srJm9ufkNOT+1uMqrjZ3BwhLAzm+
yYX6j+5DC8EHx/HPLOGImWtlaOQ5ZEc//KoaazncTlPmrk5Qz0pDt46VLxJIYz9HKPv5aIYIfYBD
tbfb//aAAIRm9W0nZYDRdF7CB+RSVbWsbkYVcYCD40Uc9giWEv6mBIxmuWVc3fO+fgcr2IYgqWK3
LhEqHg+NneWxoY6Ij2av0CAkSSx+f5Ht71EdkUvFS5voIkTz+L33xFBDHMPave+n6CeWgLu6VlBr
LG66N3bCJ1ExtneP5U0dsaAMt02g0ZZARvN8cQmsSV2vdbza/E+K3W4jwKZd6eFztrtUxunGCDGp
BiwaFwYd7vTpnWqlAhlUBoC38CyroMBxJ9RoDzxvXG2ZelnnKLjRwomD1aH6iIjMwz0ut2Z+fyA6
CvPjIMJuNAWKSbVNQjThIXjJjTrHpI005j+I2Ystg3GBsLXroZ6blcprYcgSlDMIw4CgSfGrWl8Z
QBx+YggkymKu9C4gxsGs04XHW8XCtytahfnnPp4D11YkQw7oOjmcTXRaxzGAOqihsV50cdXrc34f
//ohsspG3rpaVr/CmLeiGNrOt9B+lDYMyXLMcX4GcgTepI7kCd6g042EV5zbkG2yTeQsbU7DdxYO
M5FAZ0AFxC9aoacB2+yJhsstiL/uKwQrbbzrIJHTJcthCpxOTyYf20gbmlSAGd9AW7x25CUoC1j3
eCh5NBVDf/6GdI5pqktCiZT2X1mDPhTe+15+GwWMt3Bxbl0a6D22dmdeibdKWck/M4MtIkJR+HgW
/Ed/lqMLThdbP9SUNg6jrMQ5