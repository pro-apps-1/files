<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtMym8APFJcrP61LeIOVGjuOpaZPs4SNPwsuDvVicWxkhzHKPPLP7x9lrFdrY0vIjYOAPehH
N/xirtMCaYWVjgnM/X1e64kxBanSgFc3bXi7srPg3rcTt1fasJS0eNaohSounvRx1voutFGwaGe/
gd2abki5VCoYBjXWNaD4wcbwxEAWJ5hcDNSwCqQlvYKDuHJsDamAWwkdhf1gQhkl58klkwnC8UyV
K2tZiSPsMqYA/IFWbJC02+KV5UJQQ+ewcyKXgTMs0bR9yaI/G9MPSJsk0ZbeoHDnDQ36RUrimLw+
u9CN7Xt+ZsqNbJrsGFnVM6HwBJqTNuwm5aduhhtlXxSAjvTGAgfDvJstSBfr1RXaeq6Ov2JMNV4d
7tMk4o6vHvUQFG8kKi6yZSUjF+88k2iW7phBcSakHk+zrgWUM793xCuGlwI2INRkuSvSGI2sS8Hd
Yz8hUgaLMVUYRz4JpWNy0rV7i9wY7bVg8DBtO5QOife1d7+/ahVQM/cYCfcr12P1CG+97816VhUm
Twcm82A5LCQyqdxXUt3Ln+ziWzxYpuGdfWcYcNAwpBHAsh3v9uguUpLL3FpmLQl7oKSYXDpIg+vx
HXWu2ndS4vorQF3Oc8SeULh2bB6OQWZxP8jPWIGCCroAqXhUjMZ/CTjnURpC0Ya8WQmw5DPI1EWD
niA8cvFy0VUDhnpo7Xk75mUK+0F3uVaG705Ux/ev7KIOP6a39QVqKbx2kN9bGb4BpATaphF+aixT
7BJOuOZqa2qxSUxzadJn/fujXCv5JTrnOYqKJCP26l3xiAeG8/jHfuVdyIZOQEGSwPOuxfMS42ta
vLGbRELDKJJIzzX75h+9pI9XIl+SzBVxvpT7RnhvSeYW3hl4sipVdEArWY9VMvB1dsmK1EfyPIGj
hlco/h9ntttahors31MQjRuRLcfhkEvDUMIEXEahKCTGT4nhuawvXN1wpW1g07XEdLm8Hzit64eG
vYaDlmbl5paw0VBwkfOIsVWReDwocSA3OU5wN+yOLl5BYNTpherkveat9239O/1O9XT2RwqYI8n5
aRApTalWfK5hQ1dsVshln7Cc2TE/4/GactOTe1/ytqUd0Tj2sD7y57nNEqhM2zB0h181UK4t9ryf
6CFNGTI0vMm43tZunM729RstEnA7767Kx23AoxzPQz1APcAhqs0OCwhL4GC85Q1xvE2BngjKXD9v
DKJBTWpwEJ5kInutszw/9D83A+qcxXQowqAyNkpyfdNeRNooVWj/E6aO9sE9ncWE+C4UGeWYHwQc
ldkYBA354IPvcJ+UT3XbLreK3mKV2aIOX84fPmnr6dHC1ckeqabJcA4+/vf3WwY6XUMT4H+5yPLu
fNZ6Uqi/2dfrjyhN2PME3/2nf46pgK/YjFKt84DQt/9bdJ+DubnVOCF2FQt5YoofhiXZXqZ9Y/B0
WX50w8byhLsX2LC5ozwG9wEyz/mHFPVInxgcYBLXQGn9y5ns0WQAJMEhYJ55f8SsERseVMOHYlrr
k45fzU9d+gv6GFzwd8u2WITO1o9dkvlUKLInf9ca2FTfmiXOD54095aayLnvHkiF4y1V/n9Cap/8
Kv7gjEWG7Xnw8a+Go8z/r/tWGem6zsuRMklRLhulPi8w26VHV3df920OUNaqsWxh68KqCgWJoLqX
rlE7dA6hk7lw9vDsQIJ/CFw6nE8XxwHH0/fyllp+qdA07rHM6CM3ILfPEeUzJ0inka2yI+3ctNNL
qObipPtApkqtoG/GL+axva+ydeO5Nj8TXZAD3OPXqg666AiFXwp0H70j20AW/jrZbMPL5bzH00tJ
oc7wx5KuFS0jTacGQ35+ejtNj0VAMaeVnPG/fhaVsQuSkehGw+8jlv4oAkPZMhdHdk7n8GuYTGtU
06VmmA01zkZFTBCxYzgnQsTux5o5y1ZqVv5xn97rfyExp7AiaLzam7ofqM/juSWrT2Ljexk2VDYV
EtkBHdqvJfC78qzV9Gni4Di30eHOw+tHXKRDg44IBoPN17Y9KpRV8r4/JoWb9l3uO6bSf5D5B7uk
l1UbRaAH1c8sZ9k/9mIwO7y/R2NArf5YqOTPZrG4rgqd1VtwWpXhR/xA7CBrKDCgo1E9ANZ61drw
qZzUjZvSJxUrL8EnJfQ8ldmlXMGg28CEpbZqR2SLBLhoqLH2Ur+PiFmh/AbpVLpLHKcd4nCa/6/f
KkuSp4uaQNg7YIPpWzNImMzatFsTfiaELcLbYJlJa1HLJvSCpCrEDwBUiTZ250hGJSHwAlN+HVGr
/sIkuH7EKz2qJxXqhtTs2L3wXs+U8Lkrmh2knRLwIjCGCZPYLK6jTWRigFj6Bod648rPFjZle8A/
6HZPmIS1Rt+jYewDnY4wqTHwG3l2SGIQwGkRLznp4q5Mv1bfOeCCcjov5pDCG1Sl7D5ewSpRRwjK
QPmbzkwVXEqKqBfOP3JXt4xeyb3dHtC9wHQtN1+YCG==