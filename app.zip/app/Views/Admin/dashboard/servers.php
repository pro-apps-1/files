<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqbkj+pZx0l3+h8YpyCUeqsoBg1WE6IFbOsuk65eK/QUPU2CStiYG9YKu6jmxoHtdfc8zFhc
ApOnibO2mcIDqD8Ozfb0Ko9+IYzRYPti6PPcB31O2h1o2u/z+N4vExH14Hz1pKOaaxxssc1kk5NI
JY+xP93TbPph29+0J3dNSn9ZSBPJGEhe8ABPQhEt/Bo3oJ3k9fEASBpL354jiAtfYnjjP19UtBBw
Akquo1ghwIENRKGBDeBnoDcJeCQZnb5bbUKIUUReDWkAy0QnKAh9nAMwMRvisOLxEGanu2m2wPoh
Z7rYDujUYy+q55VQD4GZYVoCChIYLb6xZpztuknqSgc0awIODPaqV8L8mVuN0fgIGjqXdUUbhYA7
/wI24XLcxJ3mZWHjMRii2HMm7TDb9RZ+dfZerzibfBbnqoDV0L1zcF/QNINd65FsPahPs7fkRPXD
/QAroCRH81JBzEHimEWsN4xmLZ2orEWDMLA2bIYL2jhROd84cnsqWRRH87HLQAhhJmKKbPO825Vd
28NA0an0Y9Ce9k6hX+gXYgRdSjdKIwdbLRjblFLP12hsGygKsrH5ZrvPcu/9HizsY01PC5FI9VJk
cbVzZZG/+a6otIZpPuKp9pzTYqHgVpZV2VckonmLRdBGhatAhL/WXrALlrV//VlUfEiq98MhChBT
uX3B3Ju3u97XElNdOo9vbP/4TWEBs/Z8Jpk7EcfKLrhWLlkhHfEtFyjmmAm261Axi8tPoUWWjvqJ
Ccr3tIo+h5Sr+8MeqtUPSUb+mrdeqxHZTteLB1gYI6qd0maZpUUiDfqB/3cLRt3O4DIIqR+30583
okCQpgFHJCocHlCSGWSJh1BecLS8+y99n2Ui7iuTcGSw7SDXnZazo2X1gi3QufRFRcJmuHl7Qko3
n7xAD5vu66f0nIOeRH65QDvzodKNL6TDNA4qrqW7u2h8Asg/nA9YoyE0nnjb2ySbUQg74MgoCrTW
29c1mt1YPzjWX8DF3dVV9Ev1Z9qbn2vvEwltzqz3jK0cZol3Ej9lK59GUc3nFQN82f6sFRyY5HdJ
8XyhgABMdvxTDsXuQ9CW4jDsQf2SpVUcNBQaT1RWrAc+51BKTAiUJ6seJPoOnBDi1KvFDY8rd85K
aDEgp+ug3gYbGzoewfxIOIr2THW+Ey44NqPzc91erR4Ec0mMA/S+cue3u65Fjh7WNJjtl4zs7UlD
y0xvc19Oy/Y9z5rprXzy/oznEz5uPaySLs4fzl2/hhCzQR+vFm/V+CAZw4TARPldQ1LynVwEqUjP
/Y3puVFSLanW7t0UfoT5AnD9A+IkP3xmva/nX3Lv43seDqIVJZ8Fnd1FPkX818Hk/uBXh6jOwS0K
zkLBmZ97d/+40OLHdOEjG3wUcN1WQXUlrfps7HtN6TtmqDODbVh5/0ycEqXSl2ZIZURrpZFG1wM8
pSn0dHvOLuZGMOrdSAiUyuQUGsMDwtPXLCUW57ZKkFDvMEYGLq3ksEXlozAvA/twiTG6m8/+IZjc
3EgVUm5kZN2gPjBAP6IFCScDukBjJmmHQfRuB7wfWErfZvyD0qjUPdUTdeKN1WZgsOo/bSdvrAV8
oL37urM8e+B8vblVNpKzM6bElXmwkavxJbBfcE6cxYizn15vZiiB0dtK58MDuDvNGjotSD/iJUaX
rHHw+MuxTZkuPICpD8t/1LCcMtzzwD6K7vH6ceSmusUH5CBAWm0xd/qneiLmtvzIDtNSH/FhfxSN
N1AiFj496JcOPRiwxCtpP/NcL9QFlcw8Y9ELPvZhoPc+DQJPlJaFWdH/z394kqQBt9aOyEkYiWS3
kq1DfzafIqXlVqahGW3UHkg4VZa/OyqVZOYk1R7Jg92V5LXDkfNCKnurlpROR7OV+e1d/EOkdtZO
pLPAx0RTfiONOLHCFuPFcDXKUr+fBbN/6UG9TLYgafcfj4Em1wFpjoBR19NbBjNJqBkL9lrCjNgO
fN0ZOVevWcvFscBB9nYCLTvbTcUgCuDVaB+/G5+ryW1Z7iGWhOIGaW4FJAnQZB2D7c5azQPUcU7N
3JxyNfh0Y3haxjRTzLcAY3WKIELtiYQCOXWG79wGc4bftrJwSeinPgsQ2uun/mzZSmTsxA6TGHQr
fGduc4TEseqSJH2Yckts+SONMlsvrrpVdr8NZQqTU+OHEqEUq1SvNfsC3ZeEU+ieppQuIvcsAUJ9
j5kOYAXAHImGLPTQOFLWLEiJtfHjOlqBcAVRbes4xKW5/Li29tqY01Ifwt9mXEYKGUBvIFeslKbQ
bxgw+dc3nB7lhVnA2j89ESq2OPlzyH+DaGZYVLrGK79aaS1WNGqpRvq0gPx+GUy=