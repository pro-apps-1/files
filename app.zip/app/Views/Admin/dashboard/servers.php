<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpG1tY2ziI8NkDrB0vAWcKrlTqKnYg0jgx6uTV1bCVUEpHhxIecSpR8tX/5zCqydWAXWRN51
Y0MhOksIQMl5MxPNOePrAZ3MVGZxdi8RR6m5FebdtQf2EE6LUH1vhNjUD6DtluSamF3Bk5wAIC1L
P7aIf212Hxkp/sITUv7wH9m1GEtcHKyUAW1WpeQAvkMAlHKeKyDdTY8GaTRBZehVtEdtMYxluBTb
RLuV04Zz4Bd6QRsFP1TlXsSnTDQUZSaJNlIct4A2h9bI+Gfx+6/Lx3YILc5eX+hxVU+QCUmpwLk8
JJrR/wXiOah95axuvvLYtPXy4XbA6kKFNM+TzfAMB3K01Z4m9BEX1j1LUliG8lMQbN0nNcD8I3D9
dEE+JUiALAO8CquETh3d9IkIv+zr/XuZsZKJtvk8pFyoYnnhpyZ6T4AZeYXhngL2x/BP6a4DC+Iz
LbICMiV6QHCNaDCfMs5hpWQMzFs7UHVJMJH5lkEWkjUWGUYdpY2HsyKXTNrDABQd6QxD7/sbOqDD
52xPAe7TDv30MdNqS84ZyC6A/cf/rBWXrdMqWmC70Ub7wohdW7He6GR4B94+75Kf9PaEXrq33eGe
jIvqJoyEWq4k5ZrS0HoXplz+A1Usg4bkqj7N23Qr1r3CmC5grYAs+sWFiJxmvEGQcW3/I8OCaojV
3rFVAzIhHde00wNkZwcF05hEH42k7HqlAxigtsB0isKlbBWav4d/f8/xPGOQ+Q0BKCiEu+l0Frgj
E93g/hCLR64JGdQHdFtJlF4G5t+X5Rl/M8y3UUdVFOxCun4oSHgpmgblPZg4YWWReSl5hKOmRbEt
nuCG5yAUE+6iWPzugTwDXze7MU4xTi1SunWLGkCS7/1L4Nbod1pecfFugpgkL1laSGu+chTFrueI
Fw7h+WEqEYVMa5jvCYKoJEn3QkkoOojL1dXlh6bdEbdYw5NwI7SELHM1Ibh4QeojBba3CFNtHJu8
ShsW/4Xr7l/yUeQAQgTi4XDNBLWa2QVd59YjaRlvTdCEyjC5URb/jf6Mvq5bTjhOKfGCNZD6K0DD
IDBwgCtyOIWJ5WHNsGfBWm2uwq0nQhgCRopZ8LICaY6drzZZGQpUWRrmTQPzKy16H7wf+4SEH7Yg
ArMFz5NvhCQkdsSklSqv6w9AVbtxn7+a1CJFoDTRC/H7Ind78dYPV3xNLagNFoflRg/yj9T1gTsL
m2tpojsUaAvp3lA3o8UfPdxKucN+kRrv6hBVjO5AW9m/WXjEFsUs8a97wK7VEFGMFT8+FWW3mR0T
YafVsTY8XY27STLZEf42L8ATQHMuacr3UkplHfDsG8LtjtDd/o1Y1k/hZWcpWVXntEReW3hdop7m
LPDv+3MdKeoN7xnG582pK2nElM6YmZFC+PSMWX6zGO9cpC3nm1Ppe/h+00IrgZwv420+4My3puuf
1961L7ggefUsIFySQL1mpsjE8u2laDdg4eEhQPPMVE6QATB4e0FMD6yoEbRQiEQUGrT884jRyt6w
Bkq/Cuz5wera+UaKTwYD6dPI+5zr0IsCEz7DpKzOV0wemgKnollzw5WSmxePvPogot9dZc6f41iC
/F8gFmrpx0IG4Asfst0zJ7iH6lLwhvto0gG/S8zRMQ42Wq9qe1K9wP1jdXHtLaN3FzDsNhrYOKG2
y9clKSH2Sch/UfT503CWpKdgtCGrzjUQfIeW4v24vkF+OO83++vMbt1Gc12jE8K4LhSl8Ucg8cN/
MFf4FJUIBsULadrUgXS+4DA8DVx8HiOiCp9QjqFZMZxiPx5XGrbP6lD0VfIcmxFwAqisdDjY1C8B
0H4Jn/TsGEe1vMLl02ehZr1jLigHRhd/srD23oOi7W7udH459Ue+TPO5zXmwDxqWvmK2Y2GoXmJV
rmcz23dNQzzWrx+CVEuk880RyASHH7jkxJgg5/j3gRvEa+Dv7VvP0DtGxwdO/iZkhPprMzcplww2
TqGkDB1CtHn9rdjlpf3UUa0Tr3KMlK8zA1GE4pGUwV7/LRf6Sirz7JL3L9G8ynHNLWc4AcvSSy/2
PiYiIEmj1AWG9+2L/UKPI7RxlyXSU8R46+mXVZUGWHCJyhmmWmqS6pPOH0jCJTlUmAcRuHAMEDre
cNjDRSKbrfR9lXg5ULwYukG02JcwtF0oSz2v8/fsO68WMYkWKh+3LJ79bivowXQcPkHkau/eHPcf
nyDlM0CrLvT7dvMqDN2a23PwkvCLdGeOzpLPgcFGbrWLb6t61fZD8L+EBpRBLcx1VUgu/xKmyoAX
/75yq6/XJnIhoumFSAdNeDpGmMK=