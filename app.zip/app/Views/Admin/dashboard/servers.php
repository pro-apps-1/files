<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnue+RFBhi64alHiaA0PzINgjCcM7kY+1Q6uwJ5gcMYPQb/B0u+6kjMmMfLLNEnk+ylu9EVU
kmI6qvCZADcIot51QDpFqBu9A67nH+DvZk5EnSYjfMXOFbCTRcI5OrQtfZ8E2xPvcczjiRF62W5/
ktCq4ieXN5p3a/6lLZthHCCeBR/88GaaAs7pBLVUf04YCJSXPNBdrtuNR2hneq+BdoKcoggLuJ3T
HBINT2PDBl9HrNsM79bqXjOOUsq/MFW5Ap0Ube2r2DXL8GlSdw9cbuGu5HDdQYJNEH4oPxopOiiJ
R7Xum380TeMA6KGOSYEQeJ6U0rChbxjZXiTcgMyNjIC6QBPiAI/ekgN4xi5isfOtIRdcLnIdbSIs
TI67hmK/2jCYYkuzzugLeFnMIebVYHift8OBrnvoXHEOrHNY7Fb9zXJoxW3vO0FFvp3gcpVv0EWr
hToyMrserT+/7aGQmN6UzjqlJho0nXBcjYqzPg2pL3gKLTbIXKWlOLQxytW5UN/k8qRQkCm8teWE
wCdSiiMwHp7hXt4azX23PFFBwuLl10DqGfX+PJuTie0aGF5UU8C15b9a+OBhlSOo9jz5ROBC2V5q
zPmcXLQM0HEqw1u26F69DaiZwHCcZWqLTMxkIJf5zhIWKKd/kNlQkT9TW978BM2FVfpl6loUYhLI
v3TRw6g6/A3478/a3A3tNBWxlrQ9teMn1cyVt02ud6bcu3x1bS65xeSpO2i2pGp1AGb3qniMveXR
zRJ5SdxnN9Zusj39XaH+iwGp8EjF6TnlQhzxjC+tm/yHoalazk1oaFGM+kJW8KHVceXtrojh3yjP
7VTHCvNAXl82t374ldSYU3frTLD6jeDHGQLq9aSVUub6LZDY4KEZVfZr8ygGfDCj1LddnAi3BYP5
3ydthkw+wuALrKPv3VPdtWJCfMQuASvMDGvX1ajSap0xBxXt3x1t521UM+OhBeQvT3rCrAo5jB3X
eqC/T5w7IIe7ooqQlw6by3/GumNaEsQWlSknMGJC1tgJ+Qisn2M5LBJ26sq0TGmeVnY98GdKBfsS
0kXbkvS5m1G+DDhSzzgq5hYmR8/LVcJRYkfLaQ2qVLJzoO23qsjtQ+b16xpHUH9u41pRAl4YOZa+
lYQCC4KYlJyJi9DZ0DCKP4yYCgNqPo4LBpY282JZXTPMqDqjR32xYf10QdY2hiKwY+wXsiPabGM7
jvcWRCKn40BsRE9iIClN+h1a6e12E3KOFGMUqDcveF0WYR0mp6yWN1bhzpgaOj5LBZ1pbzMeC/J2
vYtrhvINlfgUZ8q2TimxO5AlGZ4WoIb9LINyBcohjGW20CdNGGOG/nlYGVezNVxgGCO12KKDpbFn
0sPqPu1HO7saxxPBVx11P2yNt2fYjG9W1AOk7p6ucChDoHmKD2ReoPMMEUm03BfhpLNk95UEsA1F
Bu8+Tczw2lIikJdWn/wzBVqnHyFchXjgS4S3hmvSp6ZrCR/FyZuNilOvgiw9MuNOZAYcSXXxs8pq
PpUsFPZu78ZQ/QdGGyLLgvimU2F4+eblUkvQGhQzBWdW5DAD1Zau4HpiW7GcROh/ehaYvpJEQp0Y
qtywW8OE9A8+gqhEmbjZP93qZEoh0D6Zmg3w8puLwMkIQhN354ji0aDRMy7turCLj31KGazGkbxm
18DO07uW8Qo21Go3p+tnO7VqCiUF+wke8f7hTKtBCI2bCEGNbXzaHS5b+tuDjjnnxDpSx/evYXzk
3E9V2bxKXyW0EjW36Il7sPDqkIT4ulwAhfFJ6uuRGkrOAzj/eF1TLk2Hmdse5+NgKchvuxIP9c7e
Z1u8Y72nr5QgXwKQGB00QV1GEEm8Za7LBoVkUL2CFonxdSRm5SytYqUcnFeHinjKVKJme/08BNJI
TfdUvMwYeh8pTV4GV4KeQ5kHVkvrtUeS87UwqXvGWfalU+FtHg5mroRUJd8UlSSJiAzkBwYnMe93
wFI5ZHDN6xE57ePtOPJ1V8i2cFkUib7cNp/2hZTKwNPExESlumk3dM7K1iSFGNfChX3ICkEGU1Sp
zJIiv4FP3qoY/fG3SJFNxMsTqI2qV7gKB7KGeF1SIHUFtZNKIpBYMBadAXDB0jvkTHg97+TvJ4yX
E15Xmf1PXSwswwcCTPfZzJOflMZCrAapx+WezZLVFyYTc5EISlUaE39yAUqZYBEOkvLPPMuKgQKX
vqh00mZukIQ52gTgC6ycd1GWOOBFmSuEO+Cbyyu438RUnrEEN8Wh70X8S6WElh2RWXxgUlGKKVWp
dphn32gd96BxhayH1575lnVRWJG=