<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy0eKDHZhgWRUlJ5zzuxPWPn7fGFIWddhFsRHpCNFaxzHjQeo61EOLYQsK9vm+ytiMNVrhUg
8hrl9M6CW1gTO7Ic9qBtB8JA0+uHKDkGMl3vFt4vUd4gftSXuNdRUIiDL3TUXGiUPVKNrzZu8igg
6osfT6XYe/WdZPjd5/2UcBYWHvZs7IuSais413/h6Byciv9UEMnNjbzTfiCug2zQaecHf51C3YHV
XlM9eQPLQQV8Axp3oD6Q7DHd6su282EVaR/7WIeADpHZv1ITmSJY4lsWpyEYPlEMB31LODRryzpc
KfINT6lAUPF4xxhDkuaiWuIGuOo0eb8+FcB9PqE7GvQtFz54AKR+eb4ReofLeXSP0pFUS+OYiZCe
N1nUnGZBFnUDhLCj3nNpMhTycZf8Qq2ZJ90NRRnBgV5OQG6OXXjTerHr2wEMMRdU3sgzDMWV79I/
3YDwux+GLFE2p4a1J1q/Q7qviaMaVmt6ao3vUiiJNyfIyaAGQ8vITcznAEwRp1NjQsOWAGFLr+QE
QdaPo0f2w5hwvq3zHNAt6swKh67WLU8uUBA+aCMeUf5k4uaYePeZNWxpem129NhAyM+NubO7wgAm
JXeul3kQAw2EP1BFhjOjTJx9x62GWM8DGvT689vQkbARdKRiVb4I/nK4yo0iGAnERrRIEqoQVcdo
1xhvohhMfff9OSRmCv/x8wPwwM7+iS1d2XSSsTB/SthF/32VasV0edXe+NtTYdvZztFxLyNdnaOT
FgUiTdeOg369kceqKCQwOgOwtXetTB47JGGG5C9dyWhRFqxIeuxqzyxGInx/nYoEuSKs9yQ95vtT
V3vLgG4m5UzXpuElqZz6G3+KC89T2O8vPhHOf7g5YIbW4QFND+Mqzylsz1D3Z3Aplvk5UNIQ9j47
Y3wVp16bOkfiy/w2IagMRjeFye8EUm0IkzQ3IfYp6u4uJi3YK9MW1fhdgKvWEIpfyx71GNziNwXx
cPPvndD3UNhoPWWV43sTKn9KSPIlAk7N36KTLA25aLKwcedcyQdClcoYqOXYRDzAAuXmHdOwPTMz
A7rO4spxhFBMcABbZfD6PQCEgy1Cayc+B7zyXCsqA7Opzos20Wn6GPYkD7YXh4vVESkaE2feC3uG
B9lMnlLzRUqJLpaecZxP1ILAV9qx9E3ZSrCNozULMXBEn6F3Bw/Hwe5M2YVKlZyKQw0L8aJ9cnO1
ZDkqAdYPtj9lUComSjrm0A7IcUZ3B3PAD1enoSAQdXt0lYzcDhi9VlMh3TGn6v2BV/++a4D2CrxE
amfEmQQBITVO6lQUM4SEXI1EYYyknRpVg5/k6dBau4whQVIRA08OHxGUFVj5xnwQKQwpd6r7rv90
+d6D/CI92fX7UZdSvBRcX5/0LbD8517PYrQjuaZecEZUZGSV72TwGYNLcPskWyzv5NCSW490lg7G
B8qcDSJKvnr74P4Qy2k8u+D+1eRc9hDCR/Og0jYDgSZAmnrLv+jSokR4CbwP5TXMJtIx8ZgaI3aF
puJRo1UBjOy2orRRwPFXph1P6LT0M5IA09ROOPzVrlD/Bjb79bhKjaZNpiibqiq/gPVwwBQv741m
w4Px8ndqWlkr24AqhqQ5raJIzobj560zOTlK1bR21rwMWDVviINqPRA5WMdbKGUCVgCVDBRA6igf
y7uToArhMGSuLftaJ0DgEoex1P2FD+EscnzVo/zO8VfsEysc0sZxhuyX9pH5MOl0hjFHZSzPRw5t
5tK1od50sf8k960aom9plYlUdJMsYJSICjWQGghKOsjL80iBbE3ravcXQ75dTWxsOxdr+W9G5gjl
kivPjgK2rSfnpFE6FIPIEIZG8qnsgfCZcql925dQzHtA+pUF9e/ad2vG6qNOcgMGyHsgJP7PULRc
YjkE4VoFgUVWsVjR5dQcuD3oRXMoqMXFn7sb3sXo3vCrzgaOj5ZGVsIX0aKGQv3EdG5hT2aW884D
A5OMduOLBQEVfiVN1soKuJIUCDyKsO52FPAV4sIuDMALgAmC0dYxgc1NKXEtoojR8Tv2FHVFcePs
LLn9SdmrNI8d9U4xjvxLgdgb4DoKj3ZyMtO5Wg0vIEKaU9KQsNuBDnBimD3q9r9jMZYlKvLPq76K
DVOg+2MDC1OEejcdUxHBtiZrFLmleyqUG+fzwIaC6V3AWZ3Y5QZX6FYMcG31E1Plj6tX3s4nC77n
5ALDhr3Su9stan28rqKlFrDHkxo16BoRjAICZOygzNgwQDjzDshmp1ABSP/U7fodoZkP9MasLwia
z5frU99PTQ7UPnzvwILXh9FwdfankiENFM1RUN1ef25AjTJWfHC=