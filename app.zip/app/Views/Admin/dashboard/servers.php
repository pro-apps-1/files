<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPre3c4uUis1XvzyDRHjMESrJvrSggiOKAiDLv1UwMT7etOXf50Tz1KBRzsalGF0wuSoLgB2R
G1GULft8YAn0javGyp8M6Hs86e0FiAP+2UTEZJ34ZfjOf1znuHA40WDg4xU3oihAG2PgqS84dwXn
0QDYr5iEaqqL3aJE5+9y8ouvJwovaXGoZ6N5zZ79yWTAB4c2PhSCR/iHkVz4MAZG7jv6V7/CYDh0
NYsBZ413LDZK0Hi2tX21nKDPdyK/txzCZWk4PJJLRuDc1MUs9o04TxIsCjzgNzk1V0etgjLp8GpL
jOQVKu+oh4ImLJrkM+9kN8puLBoDknqE9L2D7lgz4Uyf510Oy4p4ggHAdhjoBPMh0I2fHSNrJeZl
dXqwm2lkfKgF+Ur+KIEgrJDVgPwxu/tDHx7xUkAdwrxAMDjkPeJ/3w3tWObcsTUh3BjF0dLz7lF6
juU0n3hwxU0z0y7l/Mp+uaGzY7y87godlO/Mal9uQggeZvDiTM+OIYEsBFuW4RXPgPMfo/oBdmcL
FPLoJDwalJKEViViPTRbo7/hp7MZrhBz7Eb8DelN4v+jHI3CNEH6VvFjjWmrqr+S1s9NA6hRaAEO
D5o2bOy5j/F6cFEG1jN8MYWMslJiZ1Rj9vTTWWCY2QS+t0vgHy6xbI8RUw6u1YEEy7PtSmP7HDDZ
4pWtvP7E8015R1Zhh4G43NhOKc5iFnmticvw/J+ey/BJ6Ut5o34XkY3sQwutVuY4OsvBYhKvj/oM
bFeLlGGkqGnX/ES2eivzzAt+HTnnfchW+aJ99K2LkzA9cmqNtGhxfcyqmpy7cb+8f2N8T4YMZNIJ
zSaYmxtr5f42V8LKUdAB4oh1dHkEmssOBph2EYdRQLiwGjlHxkJ3tGmpxFuWJJ4fuDRK2pj/RVI9
5mgNW0lWGiLzxEz/WZBqX/A6XzNy9wnMIgkvfYMF3UH14cSZtJrr+2VaAqCMbnUJ0+VjBmQzzF1L
L/ZDHjyeSd5frKd/cbKpHzB+nBLEIoTe7hiRE3aDprSV6ehBwAMUjnPqKTWGMVx+nXslb0Jx3FGr
B1evVW/C2X0InAUhSUYG0+qd2rHPKQIcT7WBviPbqz+V63QI9LYNs1vf3wWbL0k++E/Me8APlk43
uvdenbvhnXCkYusK0ehmPCA356v3Pc0GgzLEsv3RU8zKI78NlKZUG8QtcO83G79I2EMAG3k5/Cz5
JyiYL0oJnY1NWreTqJQHL5r3UDZzYTu+2QE8bmrnv3qNX3Di27Xez49Ynij1ifgMVnFMWuT1Bj9s
+ST2wLLHTGXwWvv5Cq7BL3tevghujRL5aScfRK+mz1qeWLRoq5IIJB+bfSxT8N30Tw8H6w60VoFw
35Qwk9rWgvsgO26YrFCsKG3A1IH2BNqkps+3//FMeJD3QUNnyJKIzwSOc44S2lKXpRe3hiMtaq0o
fFt9CLuiME1PoK8nl/auxQ6Nda9p+hoUvUFV4D+hN9FSvx1h4ATsHY8n4EHSS229XsLnW2SJvD60
mvbWbFhd1xbDMNm5t5FJTGlDfAWlR/a3xMeDbAp7XPCH4V6qxKh+cdq2ibornW/pHvazJz4MuGVi
gekC5Op5MZC5i6gvBcuJVtlr++3BPWKD55KuJC+sozLELQpIdffimPNiSrrA+UYhlb7Jjj0+O2ZA
YAIQkdCBcP3Ec79V2GpRuQSCAnlVoRpJCPC/IE7GOmXvkE2hiS2WXfTCI/8sIM5Tm69iVxROOdBJ
pnYHiPsCA3ifw5Zc0f3D4ZAqmbihfmkBUyVVM8/KtnlcCw6d5W7t0o8icT2Sg8EMgrwRCGofccuu
Sd2Izuei6xLfaqOO/SoK/jt4GvaB7GGYhPuoMFJeyik2Lcy8OxgJ1qRhBc2cDRrJf8rZy6ee++Px
Q6dpIzw/k9GQRxTwoJAQ3WsxTIQMIEbRCQLu/G+1oxgsvgOsVPuazDbWub3ZH+BZT5Y+syAjetiY
pXjX0x+cjBoAPOrjDuyjSyQodO0Iz8s4gfRX4j2O3ZB/VlH6VoZT7BsSk9Iuyte6X2nZeHFE2aEl
XX753DaxIHbu3Go0AvDyQCDmJ4FhmRO3Xo5oZgcCPGR4BDZMe+S/Til3kkdXNcMBeDJRBWOOa73c
jIoqmvB6fHUNn1gV2eRuabtbp811EbzjBKCN65MqSby/JnAO0GpCU5AB94XPvQE7qHoVSlZu0o1B
Bc+4tGVvSuB/37af2JO4wiyu6mzRhTK014dqizWbO7Y+39I6XVJGmL0cd3JcHxrZvfDzQw3Q5AHq
cagIpGRGX8IBJ+0SvsnfHMyb47T4qVnbyfKanJxa+SQniVWIlm==