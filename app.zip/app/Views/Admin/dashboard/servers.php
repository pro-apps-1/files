<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqpHFcZvW8DFX0whIo53BvrRG8lZ6ZLJ/O+uHds50rE7uwmw0EJdlZBwgFHOUPsjfWCSqqpt
NkicwNx1GaYv1QidQn4qlNQ++uCfdEAy2ebibOk9v4irdtY6kqmTOaBf6m5fNODjXeNp/9yTLSMI
2WsFiWA/YK5cxlb3zMeLCTq9xvzAoq8k0c1B1dPbRmmoBl5A1UQr6hRoECOA5NWHY8PkE9ON+lG+
hpGOHdYidHJD4O5GYUscybPFdQEyilAfnlzEuTwEsDRsN/vT7QbbsKtlWKPdyLBGtSlneDGQYldO
eTrtJJEws3tuhcocciS2fOSuL0xBZdFUg6ZlqIFc8bGxgERH1n31nSoVhGiv6UN1eYjlNscghVFm
yWO+JPqFV5EtXxdXIOEIqKDUXS4EzOqebozviSFsr/UB6Y4T+Q2fwyo8lON6UCa/Nti/pWhkN9mB
GP9Q6mUiwgGhAHEZoruc+zYFraeShfr//1iDvnbHZb3GM/r2Ou/G4MLiItJz6AjC8icUsrUyZFK7
Hr7LLwYzW6xXUsAyv2YvMhKeCYf9muhJb2ElTXw//1GU+o8sdIuonfxJREvsbKjzhkq1r7gJl2xX
xLMu+lQeBpxtfAl9x95bTYpRk1hJ68K6qGzThuXg5rTZoJa3FbjdcKH2HYDcJGCVS+GcYkhGjFw/
66oXqg2fDrw8BHx2NEhIwDJOZkGM+o/DumDvtJFa5WMkyP63iuFWFvWz3K5g/EYFRWpeSCvIdr22
i7IKcmtwhbtaQm4D+8cfWeoc7RwxtGudUlIvC5wVRpJjIDaZdeJG7AUvBfDMITZKniWF5duv9l47
jYRkNMZoDgKASbYJU9TCd5aATgOeHl24OaLeKZ1ShWz4PFePhiHrCP/7GoFFZe+Dmeq7HM4C4iiE
PwHya8KPZyG8qHLRtbxR+VQXJMYj1WqmxnEp2n/XXaMSzimA6vG0GHdf369A55dPoT6x5R4KIx34
76WcdsKm6xlqWRaj1GqRb+zPGVyuvR6jJ5n5KAMCOBgigFm8fXfDhj2whFpzMv3c1c9uXTW5jutN
6X+qRNPvcdn97M9Wn4wfNCKW86Mbvm/NAumLYo+TbzG3f9/g08X9VowDImk/pshWLAzhBtD7HnGJ
Sdz+TGW6TUqiMmqK0Q3GfeZMBZxsOtG9cQxZpzemWR6b1VCwv+uczQ0Airvp4l0/z8jy88Y/99Ek
xpwsgMRXoWszEH4m91H6kq/d6Z1PHvy4C3/EbcCLyK14l/YAnTKDkLYKj8D+yCCe1cu790j2/P/J
RT19vzXaxZTudsNa8b1zlTWQ415QpK12m/HVn9VbgC9KrFG4sXbTtAZZCtt9jyi1kmBwSRxSUgU+
HFHz83AAvPW3xJbp6TWDJcLt8yWKqLbvAtFUvS4U+bBxkBoTOb6iAUN3X9NKss3yNcR7Y0mH/Ehb
Vb/alO7B9iMm5irtGXG+moLdBA0qbAubrssnjJDLkwkStE/lLtIg+9lSFmiF+ngKKyQNWH5AuQO7
RGqPXLdwuaclcnpLqTp1MF97rZlNnPf98XN8KwArRNiJHF2yuMOc6gsuUXC5DDhELEFzRm0JKoNG
JbP6QEE07zc1f2X3yc+7CJwXLF0g2QfKOciBCfCxkhXNvxg+RdMsujTltK73+qC4Kziru0vWBeuQ
Zj2ZQuiCSqme4XNyL4xEFNCjPE3P9nytSohIvVLDC39T+pcJqdqWgPQbZZtbPz5CQc512VjEGjTf
NHPu/xZJo+0i0tvlJyeXxYv5Lwwrsvy3PiVmsZ9z6THFqQv2ccBlhIkFpe0nI3ERcfb5ZcGH029U
OpCfi+Gn4moHni0Lik47CeCOnwbc57lemYE/GrpFojmby64qIME3GjuJ7nQeFoub+I0uZ2VbFmw1
BUD4w//K2/dvdgGhpK8GZ+eiyMdyk/8TFtu81HG/aQJzVBmqeD70h/Ox1cnEFm2OJF+UcLtVfEhn
CR/DcEYRY/sqa8EdkNQ61hkJxUGhjeahbMdUO/+GsstO2nrNXzZ8NDys0uLjhOYddOxWUGo4170v
y0i8VUjdBabVxeby4XyRKl5+DT2Y6qMJadFeRCDH6hWH3K2C9B4GkHcllM5MTPwbI0ClLYP68bEh
bnLordMCV2M/X37dMaELWS8RBPRnXDrZqCJgP7wZat57A1O8OGWiIkelJEh2gMCmhWzHAl+BXEi1
BdADYqbGyUhRjDZKljEXh187FxUyInnGEp1E7lHXGz8zhxmgxjVdyvNk1nlq1lM1P7TViwzt0Khy
OvSEFG53W7BQ18PdzLii6aJ9G++uX+sLv4O2sX5hLQELyrngx2jk4fX3XKyMHQeZOz42QTs8YwEM
P8AbkUP3PiiskUArHLkamScWAiuTUz6v9Pp4KALbr+eSOwpVSvqWrgvmpG3D9Eo2t1Bh+6PsXhwC
8XuHACvANEK33H5fjNk11Hsvdiyre/YQx2Yx+w39yerSQeKmWKprNR08HhTtdZcgC9ek1x56xbeN
4ZbzsE+24ce3m9IUvy2B+OSYEPolVvjE/oj6WqaaAQxMJ6MoPUSKnlfzFgkuehONsnTVWczFT9m8
rLP0CSLj4Yzv9ti0Mti8i3ceoDbav+9LDiM5IXe9Haf30HL8vZDF8PIl1+r6PE6BqqfQSA83DBx+
PiSSFsdm8bGUKv0AIv8aiyQ4mcQnUyBPxT9ZBYh0YMd714WDJpFfykQigg706/gdbq5RLLONHx1X
HDRFE9zEgWttfrWc86sEb3knYH4a+cSt6cYLH1y3TnBcFTPJFmC/k6UDr+lPRJGq6QiCvt3uoyfR
4ds/JawLFo/Iia8AwnqaxVaWvRqiiuzc8lRgcJGoKvt5YPqhMtbiC0bkA7JEn4EIU8BZwYVXLPlc
FWV2P7n7/bRkvQMj56sdZVu/cZMdLJOYUt1tSu3+bHXN2d7aGzfatRuKy3+d8n2PlmyoK+d1QORo
Z0AUSs1Od57r9xnb2ZEE/HCd2riLKm/70VjkRXre+TnN1KLzShgo3Gn6Zv44/IGDWW/Zy5O07lpk
rPhlr1zhSCLMP4aRuH5VgWdluc2Hc1mouLhIwet3AmUmRihkj4ZmBN3dYip9ANgxi0/NwYQNGqZU
0vIw6GpW2GhyBbgk368WqwnXIHmb38oeAFYiJ6Btq4j9a2m9LAIbT5ktGD05mS08mPRApH5PJFkQ
wFC6Q3x8YnxZ0egaQXQ17iuqGwo+MfqhiNnrqNIEotihvviwBUW/hf0m8Hm=