<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtbaHYdwrReEWxdJ2iUe+xnIkVSxPTn2LiuvD6E3L2iVs655paAZv9vGoIF4CdNVY7Wf2ieM
tTnUODbaoefT/QxbjckrtXajKUPtHoKdvcaiPj9WYNxT1QzFmurOBj27GAlBKzKVUl5l78FzCNGQ
IqUTQEAKfBAVM6KKEHbJkmmBqm4772vvmqlvFVsp2xv9yOR03vfvJv6+STHMz04c4mfXumnwq+Ry
hR1GSeVG6w3P19KWOqqvhKnPhocgd4cPx7ykGQHmtXrmAIhk8KcRH1+1U5fdPS1wHctX0mBu3nVn
hXUyM/+LRgXbdHUc5YwByiUooKM8UrVX1ClpvdrnS7F/ffT9hbJlgVpXZhDqY//zCzO+N6boulMw
H3KfG4Py07DKPfO9y7IKDG7TAb0+cN03Dvf/M7+SZx7U5/vzjXsoUr2a0P/uKFuxEq0AC/EaEbq8
wx6xg3Z97RNdTDjb+T0dcx5obwp5Q+muAIl9DKw5TUFx2HWxUiEa9F9MJxo5OiW4dXpwLt+D4+2g
B8+HnAf5+4eP5dTciG/FhwmDe5Qk2gf29F5wpT/jH6HTxjSCPoCOBKooyjoLDbHTD4Ctk3AK3IM5
zoMFXvNh1ixHE6ZuIRy9/kxp+AjS1XB92M28DNl+0SbR/vNrkeQgSWXX/LQfNSRZtHH1O8SqHFe8
2UG29Vd+j45lJQ/ywb1YusLUHC0R/cTi6UVhkWj/wM13+t8NwZgGr8mHDDrBSq//P/d/3vJoLDw9
L7RI4uGoEbAanFqIYVihIGzzt1/PeJP4tt2Zxyk/ludvIcSKZqKFht2lwlNq9bl39Ht0SfcNE3i+
Xvm7FPyfyHxlpgNdx1PtzQUr4SwsPeGpFjD8HF8tZDrQyNE9eGLmhp7RlZ9cDxTUfO77OAqh7TOu
lyvfa410ymokyBiX9GGcgVV4eg52WX6hufFJMODbrgr2cshNFcE2Ca5yH7oGwftuqLRgVRmpWaPg
eLhy9GFJfSy5ZESpQf7jw48rrnwIe+tSGvY4GqZZ52DIl30JIh1Q4uooeTncQtU1MsrkEgtkArZn
jgTWD/kFRZMahhHUhZqP0jME/Y3INkOERMJvi/Ir43vWrRWBws7HlEHZFJM/Jh1pz+Oxu9SngU+x
/w8K7N0wPm209RHk1VKq7RaAV7JiJrwsyZuOVO3bI5g0N6ZlWN9G6F9LsfPSzo/3YZ7jct8MxhjG
N7sjdj26vtWLYx0ANNQsVGYGOHiGl8uUAS2ByKo6SWLhpRpdB23uRadkmoF7guDpDoi8zfoYBnit
C8x68Y20syzHj2pv17K2psWs1n0/T7GPmzqSuwXRP0K7iWzY920w5v2xaFpEb5ViFm8GU7ia90pL
mw+FrjtCCKLc30pEouJg5zx/bcMbBO5BugynBSVTUQb8SRK7J4TT7/YXkt1Uj46eJ1CkiCbkkQ1L
NXAd0RE/e/omsljfd4azJCJ8WExWf6GMJQ7A97zK8SQ16Mpa2MA3YBcI+ygQ8zTohzorZngoUsQr
Z7kfAQLxawvJDOFe3hKgzYTzvVbqMQLtAgo4YTYS95spXPwgOf7itySsBUEZFWAyo//kaCqf8UNg
JPOQlBRtRiyQl9g8ydCv4s/0nuFbnfO5876twJLoGKcFHMx+lDMTPR/AbBWGO8VISROe+E/OHIrt
sbYPrh+r7t9TDzzZSlTplzpx80tzFKFeqLMRx+xNpedb7/+3xZi6w99wcfUAlVVSa8m8JPWPJ73e
1xtXLvBlD3V9yxuB6os5lNZ+GRG+zmbI0VEVURq/kFa1V1cyZl6ooyPUytKYP8rXrMFutnejGt9k
PYZ7ues11nIKt81/68EgHOnWMTVNHK2w4zeU5WxcAHPmb/LRO2RSxR3mHtmHTvoQhz3QMguBIQS0
cTNjCXhNOc1xPND1fu1ejx2cpaHl62dF1DhwT+dHA94jlGf6QT1CgWjP9xBVCGYTcv4rsxqWPuUA
WWrv9vAyCA9pA79qTga2vGAYam6GhqpyJueXo/dJypsdTULzIuXUoktiWNP3P4+LmtqFhNtc4riZ
QebfPNFPuDip3w/hIFAxCyAbMqz7ahjlaT6EXe9VdCawC973Sh63RbomFuC5B6QeXZFLAuezazPx
UxkPTX3pjDJVErlPh7QkKH7ng2G3GBNjUAJqzxaXwk3pNIypa6T6XxJWE6btFsAgJtGRQtN4hLnY
mDh/3bxktyNDaknxxbDlg0GtCUioktlfO6i4sShJqEhhPpzVLbLbAh2XkrsQtKvudqinDdh56/Bw
lyfPzTR7X+kzSBkcpvOklHabYH8uq24FNccTt13vac0d7YCaC7bNh9prS6q/OIqss0tK1vg1vqUl
Fbe575NSCaFJJ5Cr9+q3gRxXNp0G/de2HjFdyKkKLfbiMyNiZRae8/Bvb+x5hG0LSB4CRtA8AtnX
qM2PSt3mSQytlkIV3p1WP218tkcd3guYDNwMPKUAkAH78vGEscSFLwi48GNA0+jF/4NdT3dBfWxU
eohjOFn3vtryCt9mOf0ACKb+T1Z4pOQPtgsM6yw1y7vtNCoAYtV/AjCisB0IDdupihme1sL+fLfU
aF8=