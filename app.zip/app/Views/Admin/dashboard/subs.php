<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwhFcxsvZs2oH18EdeYvnx0hqe/JD08TuA2uNH8EfMNmY+SvdqO2VP3uWPtQzKcYK1w1ZFvt
QMBjWyhP1UIYWZJkrbxa2FYGVUaYrQmUnAkOBN/XWPHNaxZh0aLwR3NZcDrK7K8EH8KeNwF07rz9
NGuChyPQoH4L85NNOH3dlbsYZNiz6fCuLvhob0p2HVTT6UXY1auUoCyjof5wlyW4DYhRDCKxzb94
SkoKd/sQZoh1G9wZps/lrenKXdxZ4zXxIvWAhubOxymazG/Nz8XCYKvD8ELfUXgk9vxXim0SEVwu
3A9s/woehsFHMi43TwCKXhsRjqBxR+YsNqDuZtv+HdSBSaejer7iQJuteg3B1xc/ngmL3f6nt76S
2BzXyHtQcgwyHgBLpBifsa8sJ2KxOLyPMcqQTVWabQUO3+aObNjgNiZXb+NyPdFAx2SdLA3131JC
6aatfIniDQ4mpiP8rDAmsurxo4Q8QSqPal1wkeFITczYVkNeIR78CPVVwsl/yOUEZq8h27zCAJ0H
NrQZHFYg0I2vgGp7UR8klz4SNJfNzbz6+IBSni/UxoxNau0dLnx+V/R7ibYqTSMia/bjzeNGhcfI
nvxLAI81bIEb492D13sK1NMXq3tqRh6ngP4NaUuGJaKnCi93pcqTFKLMbm4l4CaHgRbEnjosnjkw
jteXOWuMYtyzHlyZSkgot3Q9C3Mrkm7LJuKRQY34WbTKvFanXyWxO8sS6TgAzlBy1EmKeOhbtYGH
o8b8NOgW0wo5ZU8HHGvTjdJUtZeAjPdqKzMoi3b+eMr1BWj5kQw9wMB0m9UFf1M6aslRmZf9X0l+
4bz/50bJr6K0JbosMWIJLWonN9NSbzwk6J/n1vXx8kOdExL057vu3VugEu4u/7QP7i/5N9CWs5Oe
k+u2PrW7JcqriOyEQkKdw83wA9qO5L+06Lo/6WkfmtIW1cq0lP/aCbdcQ9FxFebxIpNfau4Q+US4
tCm2awCcv9r6NgUqK/69NnjHfupQiHqa79dfiYVlkPAxSRX5TSVAj8iEE1CVol06wSdJ3EBMBMno
2ERQ4eQutdqvdPGv53+ddslducZDlvWlROoiPo5SF+ovr+/MHK+SMiQlueU8jw2iN/JzTf4lkNy0
UINl6/2cFkB1QXM46PSb8pyRoXWKtYGWjLZwcfX1lIpViWol184aPCxsckrO/zS4xJAq5UbSw6PN
z0CEQYa6fvwFHLVQA8rcqdiLyL1XwQRugbTeQ2lWxVP2qZLRvXo3CScKxNsrUZrCiw8un77EHfIR
eVMrU+Nc4e3T9yUs6A7aQNboOTOXSOPFbvOZhXUIxfrCCWBRJRtR86GTi0KxDldgjCCBTdOtHtI0
w5hUum0DIyMwccPmfUcwFs94V7jStqsqyyBqOeUdop3POPJwTsg+JGPV+usMa72Hg2ijvkIcG05M
usW5wgWYiynJnspozjoraF98ylEK8o7uVhsuFkq95XZWwT5HkWpo3vA1/XKMT1v06wEnrcXzC+k5
QDVGZ8cMpnxrzgsyrONZ98bRIsr4M4acetDgoluN9Nc4WZ0n07ZcpjLaA5ipdek4dIaaJZ6lvX6k
Gd60WB/LAoagL/uJ5BlEcE8NnMHBRJScL0I7vicI/VBMlrI12qRJLi47BiF6Iw9Y32yJ3RLZczQU
sIlWCNdC5Hd07FmhR3/ttG8mv9xPI4QXfXxWFP9f37Cr15kFxy4AFI0OjS4tvMYYRRi4DTBSAtgK
LOS2l2vID6+PWjOKVV14Kzoulw9bxxnru8tpwPjFkqlGyVRmfakkWzmofceiPdQg70s7mr4qyt7T
0q80C048IoVH5UOMgOinxOYxN9BX7Bq1xONBv1ck+yEXmCoARCK3MsWDOtwQLsWj3GvWRQsgjHmX
NpiengsvbjnKoNgxJT9KLOnzjtpZaUCWb5r3K36b9wcxaLx1/llUh8d3rdEPK9v8ogcONSWrDeEm
OWDhbUNYHEdxZFaksXj9m40RSgwg9AI0XixRrN6x7E/t6HULYiwVrLemblSHwx9Fy2StOV+wQi16
lNVrE+rxRIXoJpsLGQBeKM8prz7ggiOljBvtbPGdREzIDxW1AbnzVNS1dwMcnTDgYgSTWsJDygbD
TlKJybp4W4feQK35V2mHOTjmXAhde0521iFcLlmgCPDuXJy29rMc7I1SGHnzPovyrvfGQGwSXU1A
qUTX2V5rNwv1Kr1XTi83iq7vZ+tqyFTcXtTydLNlIKNJ/DfOgnzX0/nQO0fS9Ab64OEjBXqdaVoA
v66+jZLt5cNiG3e87ukRi+LtK5go4BPCe3KnA81qClq/+IL2dzHHMH5Jkm9R8KMCEKGaa4nh9wD9
vC9WwA+tk+n+639L1n128M2uQW1GPeO+cpOWipuOuD449jtFfV+QyFL9AEL93VNYCIV01Yt5DztK
nyEAQtagheYDQIT83HZLLq15bzHAtVbSe84vpqNt2sFN8QWCFbhrT9H1IJvLImwFXaA/pFJtVpG2
Mbenjj2eg6SS+bvfU32q0zn2Kwl1YaXiNjoN4ESpGkZjSjbPN8jZEyCgy6WUAcsAZf25oNHr6bqb
lYPoKTRwzfZlg1TKD7u=