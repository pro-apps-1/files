<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx2oSPTb8qhPS6/aj9BAR2XKTWg54BhXUizaErc5rB9PK7BUBrTxLltFyWyBKP55FvsTBZhJ
x+0vlNZzXehhyaJ/OSo89B+v7c4JyXQZNxzGXs28gyvTJN79XzkE51ZD2FCQqoT3XSSz9F97blQX
xNWQss49A6YbxmU6AqUQLubJx1E8TLQayWUu9MQH0tV2aMPPzhE6fK2TvHC0AANpMkglQ4Nt3XhF
UWgdObYoeO5sDp0zypAbcsrYstG5ceFHwSMc3lAnZnHPpE9J5mc4XV/W9lB5QHZmgr/IEtKBFmP5
zufxPV+rC+rJsSGmmH6aqPfT97BxydnO+yuCXA9xozQ+xPwxC72a1PJ8L3lUbRbDRJIYFfCNtTlu
XPj6C09raXyfruVH093v7+iMVQ29VTBiH0gBhum+Ud24NS7WIAO9CgbBmS9RltzMaM1bsV5Lzp2Q
7FSV9h+M85S8uaSjPdBCCytl7n78H8GlCEb/2dQPZ97BvQavipeeMO0tsacM5bX71kKDZt/ZTzDL
Mla+OLzNTbaE9Mu5PEt8rSw5V9gzIhLpKPdMlqu8NATWc4J3KDjv5XWieyhviRLzR/rkax4DxyWv
H2g/42yewV1qAecHGWAp2WiBeUKg9shK3Bgmue5QzuD1/qoPN3UGGutR8SmTS8xa0MmvEXRu7KZK
wGVFbq+huGFrsTlk4nEAnOPyxHjrs7GrwqjFtTBVUNEW8J4lrTCQMGOqPXCVj7aKeRSZXCiCO03/
uTILBJywdQGAv4PzRw58GNykZpS7KyblN1ID389XYBGCjtNIjH+BCjNq2xsb0Tk2QVKZLPJFfhdG
20iWBEsb41Mu9AqQ+bDRjT576/vweXN224RGsnOOIZHBWpu2tEBM8yc+LPIqGMmn4IRaQAQCRwLA
9O31HBgPoFnW5p8AHwxB8Q/7LcDM+uf53r6PFLGcBs+IYmMGuUFizOebrkZ++sfmasQcOZ7VXsKb
N0pc54R/QtHyZJEsqMIQoubKODXpH14Oty54uYa8JKikjx+5Y82Ye3wc52HNogdnDCY/YwKEr69u
ovWVdChh6oxi+Fj0quxy+hXGVSJUHC3Qjuqe4D9cy8aJvym780oyms/+fVsEydv2YD5sI7RIqvIi
rpW21mwK4EVzBqNaqkFDczHQDM6vCDmzVic22fssivTRK2dKrMa03x83GQksltJETrbUyoovqeF1
78DK3VRyB3cxe6Qp0EnqPfq8f45BumUHnOM9mEaJGhybPueoXHZ/4qPQqH1u3KqId1iv8DVAv1RJ
MX5qEBsil6W4d9rg/H5GhXDaMiYuo+spYfkIBdUFKA5hB0SHHvNvwjpaZ7Sdzu5lt/hV0zszL7vT
2ZSMoDPljv9gvX4n7Z9wc5HBU6lEUBlCEhxXaFOppu91Fk3AceEhEQyqHfe7REfXMS5Eng60BpbD
606Q6qKTnoX4MYZAvMvSWsMDpXR3fdZCV1pc0Mmp6OJZInQUlrRmSjVRvcDMiaFdEO4KOOKCmfRB
oUJ8g4McRYp4MHNOHtSWLlR/PWtTFr5L3odm/nCmJHD87obiKDl8bdBgzW2NtqO9bggRQS9kcocz
TwezyIDNmIHpWZ5TRU8dYYkpXMfqn6XKYHmBEeiSp+OFCWBEstvZaKCXsadtC+MpTEp7GTU72xQr
orgQZFfGcWuH9wwgEEJcOKna9iLUr7QdplY76c0j6zWm5YMNiFU2BVxFewo7wW0oqv6XT3yiM0ah
EgnZzbafqVANbB7FIA5JZpPvgmD1M39h2d1bJF78UHJn0HJQhf7fD43ds45c6/O0+FKoyNWNt3OF
4HEKlsbyiCnQYhXwJ3OJHvib5hdDmxObbD23SoYzLlJpXZS/JMyO80xmprvpJa4op5N/uUlxywuL
Xi86RsWFgxslMGNzuyAbwQJMBW+votgPzZf/0BGa+dW5p5704zzuKOkLihhfub6x7UZMJWeMGav4
+yOh7GfzSi7flHCBPBn6FeadEnejnRoCue7kpIARl9RsbnH9gENIs3UPV4A5uGd/yyqQKMNA+p98
TFsxJMNB3+kFSzH2wVIrngJ5s/uL55x+qOYLRAWcerWchIjCEZASEK4zHwOfvpdkkzPRPSSwbE8D
8t774pDzpg00kFyVybJo7P6MIG3wBOoP8/WGqGJO6Kt6BFmHDkhwVlK4vDBBt2sKUorxgCPIlHVz
frk8qlRAZMsOWI6BAPaz2k3FjXl4KPZh8KmwOlbI3zipT/1d7cCF3Ue7o0xuHN+zLaYiGXaTdlgF
qFssZYXyvMO5eFeSi3gPtF2agV3AJ22G7gSxmGNMceQRkEcKGwzwsjYHXX4/3Pc0FwCg+BRagV8T
HHbRruGAryGJ+VzDY0BRqlsYMeunyyepMgii0Ml0VJGu9HSfwEOEu+gF8/oLourdEO1yH44FKsk5
9nYEyqUfc23a0p1R+L2X2DinsnNRfeSqS7RwTlv4L03t5dUyQcLvS/E4UnRLFRsE4G1oaHTeaPby
NS8U3n0WG/Y01mmtMKZv+oWv/8tBpkf8kGyj9zkElXh8lSSPiBk76G7UvjZpM5Uxfh95RqK=