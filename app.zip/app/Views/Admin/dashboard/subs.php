<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmymvhJkeTgxz+rpb+e97B+e50UWrFiJSCHjJYQXLAAt5E9wFJbCSEV5MlnamYSH5u6h9iQD
jYcTapGX99FvJcd5Xq5Z+eJKLuIhuHyt5u+dGhkqsOY/T2+SBSQj+0SaixABslmXj0yh2xZnGAaH
cy2oj36IsYHp1UgYvM/A+NupQfMnPS80fBLAd8cnjKEXi0jRePzwIyKwoDK3Dx/oHRp6KySaU/5Z
L/UVb6Di/VOaXkfatPRlxi2/iknI9NcR4aoQ7E7UZjZMzb/+NHsfPTbDxu7zSF9mLeXAdNesJc3v
sAJTDYXEDo5Qro3Hyfix10BNqvMuGOvVlaTqrRtA/Pgl/0EL5o8bO2uqYz5UbdSVPYpW1i/Yx4bU
EHw0vKcRjGZLqruiAI9mcK5RuFiI7xborBbNyXcPjorYsdpTGvYmbBdu8Ydj6TjQ3MmhzWdPinbm
OVvxdmXnmxpjoBPaC1UDAmv+Jdidfs3EqSB5L/kOBa5ya5tz/9z8JZDIwvJ546Q4AeNh6OsuPv29
roMXfD+1msNbFlriXhG45eAfoJhYvIdkDMUef4HHTh2RX6cEgrCxUk1WVLKtlpkRh3w/+nZcuoo7
itaV27k7sRkGEx1lmJZD9LfQVoGfwFaXBRVCuLHaot/1GGzLagZZgdPvM96IvEQs2LiffaED41vN
kkPpTYN1zN47P7vujA2pqUg7L5TOSTKCHrgIeKlRMpb/2A1YcJW6EXiF7XAgPa9JAlb/TzbWPtnT
sCo7uwyL6/mxUfZJSLE06d6P6Hmob8hMwIroTZ11MvAPFa+WHquJN5ypikXoKfvXFtz8EX16LOvR
36AGymCEFkysW5YZuyMSK2bpHIQEmIhPYmI8QzTNBWimkfFO5/pK4Mggln7hSnTXH1yBO0uSjWi0
j1D7LaKAJl811TZkq/3PvcNBubOKSzUmwiDWOJYfiJjGmXWBvRGqQ7mEPbPcTg0c7XIIdnNvsRRu
9vAZSfVWo5vEUtm4z1gz72UxfWOOMVdbp75vJk1V0f8erXI7v5es6oMJ0kIkXkvOT29mNiwDvUoy
vOCccQWmIT+lLiNPkzrTwk1T+D4AX+qvoA2K3o+jkNpzNPYg2Kuv2Q6hBt5A1BpYoMzchiHLc8OI
0YaT+P7rNjz0wAA3YI2LFqd1rkzlxO/O9WSm3oIvt3DVp7UNsrit0rIkAXsyyjHDxLwIc51YSIb6
QQtZODzCUP/XzLfAbsZkx6hHi88Oy+tfEHwvtmAGagw1zxZbbwWCeg6aYiC7jREk6x1sRkX26ZH0
Z4RAO8cvZgfsRqdnTDhLiMHMsCASR28YnGbVebe++08Gz4l+6h5Y+I3jJ9s7hDOQWjjMDD8WSFyN
kGl0UuzmJkC5pj6tp7cna/7NZJKRd3S51P2wndffRooHCBkIKa7qLrd34OahwTdwuExAwjqFfXAo
VPx7ZricMS6HCTchaxb465ASeSevhAnvCdQ3LRT96jLiiLhW+GGQcK6zACtkhLGw2VntgrLKnwyJ
ka3bEZ1oxRYQCumGUv0XFs9N+t++W4OuEExKxWEnHrDrLeTJTvSaaJP4iyoNgWRjjbGPGGrYrV9c
jqzA3TpqVrzLvCRC2zHsn422p5nWo7S4q7HxtXPkN4RyGi0P9/6/zMavj3RARWcC2YjO1a7DOqWg
om5vwVXUl14SaOrEb6o6k6ndLeFtX/n5mQKLfe1hR0nCz5/YrAzaJpLMOq4sJX9N3M+f+kOnLl8X
TI5FcRIH6FeMg3OYvDOI4YDFcUFWbEhNwQgRB2qIFjepcFyofHrTUqLjJMpT+FNCNv1pMOrj4Xjy
zt4cN0v4Ipd/3DTTTKmzxOCBJiA7HRFNeow8pAfUyTeJvtU5reRGIaHmvnR/M8VEuLQtnYDweSto
wqB2JRVSU7Wfd+z5d14C9aX/IBi7lrAL1WPOr6T/fesCVXw75FvCUVROyJLgnTW/0ZzFL+SPhq95
8lkJK4Q4vDpGI9gb/Yj4MFLXI0pV0YgEP9rcuDzLudUHFwuf4Z5wclBkN/ZiqjGjeq8eDNLp5RUl
P5N/iTbutS8jw6lqXhlir9vzuI+eSIMBBEBEhwKL0RSofnWrPCLS0J4O00zumWIDkmbr5txLOuQo
e0zWMZB6czurQkdXbacCr1I/dAmOcqVuodK6Olpns8zuXszj/wBFkRJbA8c4Kpk/MaEZqqseWaOT
uWJCHHSTPialzIKsGuHyanAgk9OP1bf9xZ+yeKKnZ14hfidl66g/h/XCbTS+iCMpaAekeOtyHTAM
nnawqa2soUdJVM/CqpJmsN2XsWKwd//BA3xnqIeqMYRcsAn6fxgXsASuS+rYQsD7ajIkSn0sg48X
B6hbK//8N7EL2cP9xntSl5vxtIB3y+t8HRc6ijMwA8f8gjg/M0+Pa9Ipldw20SbaVwefVkg00QAx
MWs66XUkoh4aGbr00nsaRRqmTuOOSkKU81z9f7+EU5/nZrn/NvrjNfoB5o6SNvCsT3XKufCbfTNg
43/QqzIdHQeIFiGlQWzKx0CoW9yF+vGoaiTCq8qOMmM4QW7BDJHPz6rZxwFIcQBWdHEn0xz4As+w
aqX6ZW==