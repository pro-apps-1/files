<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvIfsVLhBYBwSdHCrd0TsgeTj2XnKXK2kyvqxjIZCuD1I948VM5RPrSvKOVHxt5cLjVYaYnb
0wEWsjYsKmoNLvazqWopDhxaTPcjX0lHdlMNeLxsuqTLBygQa/kisGSdR/Sw/1gT6ClTwWh2g37P
OC3KkRhuTqK0bJGo0Uv1jLmYb3StQdljy9clSEAyIacvGwD6mRb9ZbGsBMVJezKqRJBzcLwuZquU
fGLwh8UvDR7GkD1bazsKCBsF+qbA3JKU0/i7gl5UV3HNAgEvKMn0WDbY3c8TQbcF16yICa204a/j
0/WxFyJJLMIVi+Tdqo29ULBnhoDOxyO9SqLslFrL4BR9XDgMOFRoRjoja+KIG0hqCqSqwa6AnUk7
ypZxgdMIaHIIWMFcthQTO23ieTfseKQZ4Ye9OH+Zo13u2RaHtSXtEaFaizNj/R6ij9LarG3cJkJb
MJPZ41G0OcNtDhblC2CI8PQoltlNwWXB++OhpvlUA/nwQ2zit+eahc/hmxWh3LXHGMshQwbMh6nU
K6FKMWDIG/HPsi3TZLT0dEslSiJSJwMs6xybNBd+dwfMEfDnXNG0ia8V4h7XZW3Ui4g9d8rInI92
Z2BIEO5/G1voA4ywWpl3u7MhTOodDjK5OdTje/JYEZ21Wk8nNiLhhpw7lqjfrLkQXeqwL1dNe10K
UGUmlqqOjmSNWQKT/5DKb/y+xYDfErg3qP+hPMn3b/1G0PMT/aBdv+bUmFW90k8l4sJPjOiF+pbx
zW3LmY4GejLzuSh7vwwsdGEHOnMWJ/NmCuIL/8fvBOqipx9styKXVyXcXusp62G8f3M09XoXC6+a
68woE0VCdALCVqOuZeQd8rgOSiVnwIA2Ee93MWdPmp0XsPEZEgrYeclGCmLFDJO1Ym0wwtrPmcMg
ruk5CRC21ErAaE2fdDCFGS5sn35beCMK1GS4BawgKQJR6FH5uOY7jkTg/9hiR1WSxw5LzzKGsGD2
zegce1BKg9nsFqSacfQ5ati6VnumXhi8hEfXGoYMRU8JDhWfs3Ls4l4ufTW1HohmXpe3TJSi53jx
ESBuLKawAckJIJ+mylqiNiEvezODat/X11G+OK5Tm2CLMnjlnW5z4qi2XQryrNcvOG6hUOWPeI8w
NS8+TO1RZZ1iHGuFfSBO/3DaTxkzJoUOlrRTNa9y9vyfjYGkmLeQ0461Dj+TfuXC/Lfv9Y2mZuEr
Iawaf7gXVv2jXoyBJ9kHql/3vGf58W2Ejapppz9W39Jcbkc+8e1Og3HZ2STh5nEwDDZAtzfjARbc
jWz/v7qTHptglRuKffrr51lZCiF8bB2AstSL/0y6caiPvvacT0/eGbGh3OaJwsXqVfupbQwa1kat
zZH+Jsy55q7kffnh5rjuJ4LB0Ju7JEFszu6EAkmvCCKKGdAWuah8ov5GgKDKsYNuz37ZJctjTnid
sHvpk/8pnmdR9+M+MAYQiJBwqD0WNZjetIgxGlCC6Yxo636j78eSSAOAWUPAGrJead92nlXFokPo
J+EPpFOKtRKI3EmbhYfGDqwcPAqSzTqToBad9bj+M2cLJ61UbfwnL62EJzkswL9u8QLpXrnkwiyR
qYA0AMTcD2mh8ZH1oogT6CAepQIvrYzUseiT68cNtuzVAUEY9CkIzpJNc6pgZ5xcIHig5tKO19n/
PBl8xFkqhpgqmyPorBhw3dHdG73i0sCs/qO3bGdZQZ7K5r8zH7CTH/DQjQgfEJukjatyODJeQa46
f8UAhnBuTfGj7aNYoEUAuWVdwv8C5HlpeUr6//GWQahFf+JKa2hTmOegG+L1xRsjyx2ijE2f73Rn
HuWmeSfdZDAhmhUBRqGpt8xD4dGe3cYXuu3yz/PlfVvzRYn+LbM3bi6dkgwJ5/e7HVW1ew33dRVn
vwAKmhyYYKAWxUi2R9UKMycD3SYTQKPXiIWGjZv9SslmGOL+AX/qI0Ub2Rt07vwJiRTnewZOipLC
sFk0L3KWcr3HaehfJIM4hU8jwK/uG3uz/8DQx03uh4TAL/GCU51V6EXGNS7TS67YpspXorS3OhAb
bp8K+/9UMUaqkbSwyEBkBwbym+rby7EuLycCqs/sqm/ymXZIXeT9yP4Vkehf5gIlrnxR6L/YpmoK
FxwsokTrWV2dElV0sJ3KO/jwMW82iFfD4P0scAjopO6qhfVngEmpwrum8NX1nhJIeRjXVI5o24J2
l45RdmmEDhwGAwv2jKTT6iQYnPHOlxKeyP9reYYXaE5py8lW9DNNsXsAjuHkgSN1x24F9uTOTBaW
3x/Q0m1BGLt2bhQmmcoCkWx8napuxVIQQVXA0N8UR59FYyfBbZ6TxkPnt3vFasq3kDQcfjWUMKCb
hRH4JCGG312Fre9ok9uhjzcR787Ol7dRtNdCNNLAML5LkZuTLrT+0JUmt5Ol5R9Lf5NXX8sbivfE
NaoUJk2cobUGm93AIrY/a7gR7F74ihWK59ry/mhWOafBgDF9rabuG+zTpb9qLmgSVT3G+7tRMlLz
dMiTqNzvNbmEhQiAUX2ku0oqZSm+jhNsaGtPUr//6hsTtpWcFxw/i61PxkFTPN15iBE6QZ24Gg5V
BZP8gR/8dXY7LId1IdydOI6wxrkKRW==