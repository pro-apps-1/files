<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuOAk4zhom1WSjSjRDAKb5lK/NmWYRjcwuUubyyRg86aLWXokbKGRXIYBJkIa3h5tMFKa+wg
4V0MRHdQh8AhE2i/i+9zqX0PqII21qDmZKPH+Feitl+qlYFAXZDMNz5P3XXMroPo3wOt/ons/rxx
ppj9RIUj7JafFGphfNrrbRk58qTYOeNfdAxwvcf4accpQ3RJUT6PDo7WCjMIszhUl4AKJJ06xAhe
cz4u9U0l7HVfDAqaD7erMK5x55ZLZGTxkgyzDDLlWsO5PxOd80HtjBOotxra94Jlr8u9OJlmpDKr
ZPynPCVGSAfllMJfLLTJVwZJJUot/2lSff9TTNHPmOAKJQqQsUwXU7PzG0OiKH4LFkB/toSP3nPs
k+qz7LQ/v+F+3yRGoHUs5AnqfDySSF9MegPwwkD6TZUup6xy3InHypIipaYwemAHSY6QE9x+tgyO
5BtSoNZNg7nFynH1zACGKiyUNAEvsbJxyhypuedCyJCC0vYqd+I3WUP6/tvnJwgZ51xvmivy/lzV
1fkVTHxBOTsvAJ1Rpmsb2YwXNnHCrOJ5b26rB/Z0O1rdhYSw32OVcWKlObc5NkeMkwW7q/nbx3xC
IqLuOemVas7co2196hRhE870BtRQokcnX3YmLqHk7M8KW4ffUO/18+Ndog9LyURvWBMQBTWvVQQb
/nhuYsIEcWpxGFAYLhDN5wMPkigloUJd6nwdjYs9+IyuN53EMPwoPZ64/IUY5dW/mqwoFLu1vFOh
9J8WXlUxsDToOxlJFNbZLFlzDnDYMCcB2wc7YcmtbKJ5Ad7vN5vWwlMnp3F/ngSDMNecE29A3Y0O
TNgoEojlhhrkOZBArKAmFaAjKaOEiX16Qaa948TbhGvNQqIRVz4mBjw9ht/CgBhL1CzTsNiUSF3m
OqrSMUkF3N/Ue5dbtgWbjW0Kt6DMBkKpP6mvjHjdFnjPietLHDEYSAn5PEHCNZBXC2/7BuMhizPv
30VJcPrRFShpPFzs+RK8La8tMLbJ7SuVI5wEpaqBxXCTlszvvtPRSuj/kQEsDi6lt+k5gRZ4AV6J
EOp3O+dXtORXYiTuWfSVb8edGKyjUUmDrQLBj4xpivy97DRt0XlMKE09Oy+k+xTQ7MS1yLLcxKgY
QoKX+rKNfIFeCwcrdNZrakYgiv8Pww5jlHH26L6JQj7Jx8Uh2/vb6OtlWMbJT0Dubp9ryO6dJQDQ
UHV55Kj+JwmtM6GCLhMFL45LUrHSrb7YF/LR+QQ5iZxW239B/Kusp7xFT+DE6z6wPVZcNz/vy5TZ
QVwyqCynkHFmJX1JbyURHNd8Ig3fo3Zu4AnAWUjXxIysuMWqimHp/nPCHe9LltqovFqdZK524cv+
sLtMcMrzwlIsojuappuJ+04udBAWoPLpVklV2PlEOwBICmADi9TogIN29dYY8EEVt4mrErXOWVLQ
oLE4FgBaB9lkYVX76bXWu0no3J/ywEj/j+z7uS6W9Al8iQ9ZjkZ7tFq1SffXc0xHb1zxXpvyYOtP
WuTuEx36bUiXDTRwLKAtV/CwP3Xiyqw7p9QWkxCnvtxl48z7JUM7Er76rjIJAVMeTbupZwhBa1BG
CVnDq5DFXaiBDYKIm5NeFG+oAjbx6lv6pyENjh8KAwFF4/EFUVHYgwcE/L6CbcdoV1BCsKqFukqa
fZBToHZiIGAzu4f/j9mCOXIJXA2Lu4oPe6JRkvAt7dopfgLnwIFFFvw0+DzuMh1AEDhRwraRM3zz
+SgnSDh6/jWzNhLVg59Cd4044DYEuLRwbHD2ZVelmidqDZ15vo6KiGmkTt+bxkG6bmTC1pi/53ZL
2HCnV/6MAgZoa/bH/OVnJVR0n+yDDS/C6ehXLtz9AIVaaeL2OSgYYBSTZ6aLbkHq3RlbakGaCL/e
sYC2a6R707fEJuuEPFahjCVdm4Jn98bKevXxPfJl/WovgD1qpNeEX9D3wdc2JJ3uzpTgDOI3ZVSg
Xyd8WUgKMazO+4RrvQmQCy4tGgHIZsPB4hnOK4a7fN3uKt7pvR8N4aymRfCgBlbprqhPeNotWTDg
abwwIO2/bBmKiK5PcwIXu1K4C/Oozwk+O9wguDP0dmQzdDRJyOREyWsKC2OLXyfp99AIxPSaz/aJ
qIDUV3TO/vD6e5MSg/8I/qA1IFmXByNOdETXAMDxhFxxUTED9jwxDTcXkeowyA+kdNKwt+AZf4d7
VAK5Ft12h3UnjKbbb27ktvCRjawEUczhUvs1NZeZOVWfNtLAmsQTP+bnI5VijNLcbPWruAHG52/d
BOBktWsBm4Q9psKzdv18hb8WUNmHToXmvj3MaKn+x8DDMYFGcqSzJ+YxmQ9zJmYFFVSncoCVCuVp
lv/QwHBXScOcrg8JbTizhETs25xnPCQBKL2hbguUZuoajIU6hgH/ZTwPVJTsPD5lZnRXxYVZEl/f
KyozmTRt+konRsdaxBTfeIUfiFgU5QMT92srA1SGOczUL83ntI/GTGFaxmQz+SBgiIGii0q8JQN3
A1+mU23r1cpooIpTcWO7lTQzE5o5vXYvc5M3ZLoO2jeQhHoihffMS8y6kIttkYLcdRel2ubiLX3w
WxVDkgzkxU4=