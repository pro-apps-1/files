<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmyf5X7Whkec/VI3CjojyevH5srJbSvLQTEYNql0sdMiu+wYTQqKVnq2C0tl5sXZqCoBJwhU
QsjlN8B6pd3b79w8mJ0cXL1Gsc7Jmdo3j+IJaevqHbWx0ZadOUHkT6pgqPwxhivXtpZ6EcUxy3L8
45L5nEcgiz4AHHB0IsndOhpRiu2QjleMcPUiQEe3mAA3hnm3tekosdguI62nhG7i8dunWvmCTokd
jJFAh886wj8i526qc2N0Sh+Z8ZKnhHLQQ2H9AvQ0jGZOLI4Bt9+YPfU4E1K9Q3c6kZitKfCh37hB
at1u5bz9/coWp0sz7+FL+oef+HtLOJYhjy2bgFgmrYfypC0Syz004uNlzhTfM1+eHmFBEnHqxNaM
+ca8EILRHkUvEcAU8gcMgQJatNjXZLSXOs7m8w4KQ1BLspaN8Am2EvvifvPO9fr4CVcsbOHjvkIy
bfWhKOpJ7acGsaExP3WUGfqrYSJmvv2vP18hXVXHWedSxLOJ8yoSJZWgRWhRUt7TTZIgBVcf0O6i
yKaYalL1yvp2ca7MJ9Ih3XYzgC68Ss1ThtQLDnkCZkAL2jksAPkT3o8UvXavrgyDYbqYULz6R0Bt
JHby5Tukq/HKWXFNSFI/KMxFcbgla3yS/T8hqW3RlnWXXaHh0JWoH1ucrB8wRvYyskOA2Acrw2NT
Qq6/ZU0gTW87ZMtob1NLpdFyE9nql0UUWLFC0ECY6D8OTA/qrDx95ZSKA5mtpNtp9pRFab08GaV2
/6T4jEWJJW2OZ4MG5a6uBrvPk8tfeXcUZFK5ZkehaPUHfg3Y911ZoboB8xgbFeEuywHjmsH/sxti
XbSSDQrL5eWNEdU1n8TM89Lw50sZ3ejOTZFVIjywvnDImU5t6s1c2jh7et9AMt7f4czaBWppSCse
B/0o1RslBqJmL/PpvR+FGrXvmdKXL7rq5d2G3yFNcADuvjIJVZ1bpZ3R+gQkAvWEvJ9wZCH7cn5w
nVM70nyGiibvH8CnK2wdhpZYIZeUcSi/+2CoWmg6qtNyUJJrnnQjI5OQeIkI3l/YR9LLGqu18DVO
CBXnGKLr7vO8nUeT16GzeBajPM2HaQaNjflpNie0AYiRty1TlJBsY5HtBNBTqcXRuiUob5opj3gt
0Q1IOJTFmD5+UvuQi2sfkuZv4jma8aB6fZ1mnuR6uvB82dNlERfsRGdCLSB8EzgKUHPhSzGQ1s0i
tbgPOse342CUEFWKjVpxPzhPiLvOdHYyxtHc5sLcCRZ82iak+RnZ73AZXjgk5BrVrnbThWsz3edN
D9ztHk3ahl+d4fVTTalK5vWx7HnhIgk7ErpdfjgcBpuAGwDR4talIqoV25THYAQs7lynCRjITGnh
hSMwS+BDXHwcC86/7ahX1XPQgcSe/nG4okTR43GIAQsLVdGi0GAh6mD5nLhq1o3MPafmk77Dex0A
Msjz+Gc7MTmdD//tsSv44nWJbGpL8kRR+JInNvD/30Eaa3u8m0wfhxBtdQFcv3KrmH4E5RwTz6qX
EZgUi8AN3ZXm9uDQPHJ8v8MvyCrDmPGspiVTaEywJ8vKWl+YH8GPjLwxJR/5NokFAkhHU+kYwhaC
ibHuGrKnw4qcsFfQ1MX8EijLG0i8bl5enQ7b43yY4N5XgoPEOe0xeLTgWYCsYklG6zNcABSRCqDc
IGF9ThjNYInTr6OQGlgqS9NifULAbdLAQuQ4fvXP3OLHJ8btA0nNmzAp+Iy1aXnEJR5G8XIB7gJR
O+H4dYyaTghY6oZGmTIi1wBjuzttlVCpOQhgj9E2ZmjgYXhwqjZaFQ5NmLQ+oVcurQAI6LgQNNVW
fbKPSkE1lI0UsLBbNbFsVawJxn0DU8FqGGxvTq9Ifl1PEJP0fPy58m8hcib60/88rPWzNpRaDy0O
teelJ6YfRI/2hUJgkhWh+5YVfk/yhC9zTkJ9RJ28N9pU1GPXLvueiZI/WRwSq+leWdh0VC03taz9
/5p7yaOSOxgKJpwbKPpCDyj26VTA+raoe6SRxloSzWcGGHq5lFsHjNBCfe5Y8TpcjWd8ZN7/u2A1
k2+ffycGO/wM6Ol96gZBQWIqehbrsJaDkMdZZ218SQp2TezH/FEkW0sn3qvkuBXZSKomLjFiv/Jv
69TQ2v5ughX7iFXNb9dLs+t9/Gt+79ZlC6d5P2AMzv+YXWqSOEilVefN6lXvG+6OpLlJUG3dEdCQ
e+WXYrpGQFtSPf7DCryVE8djg97GMOSfHTAMlvFr2uPNlkP4vw4s29EsnbCTJ6Qc+/DQRJlK3f38
wu+cCU2/SZ/j3vNr5ObldJzp0L7W5O683/kbGr+QUu9tsxe5RCwJ6Gn8HCCkQF0lUmHjQ/vV8cbE
6AJusgSIhfnhvJgPCrL++xlTf5xzBcFfHmEZhMs7Qb4epvEy0BKSZfd42diw0Q+N7JhrfEXJ5HMl
+X8tC00bj2QfyEP2/vU2sP4CHsFF9qgwKdS2sLL0He0WcxKcPZTgZnaRtMStoV8tG8n3tbpSkoU4
bA2v0H1YX5Ujjy4Vcw4QXr4cT5EL+EywsUYJoODeDeOm1vmYPoipiZ8RfyC9VgQOMwmFj+QaQoHE
YpXqZtwZYaBUt0==