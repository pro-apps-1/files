<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvOeOTN4hbaRaVJqzhZSyKRa8CribQM9h8EuaJJ7Y6Gu7rKVRwkKHP8ktK5M2CDRCTIn8cn0
0HSvKYpw5WyqiiMkteKzIm9nOr2B4luhZ8/S+jRbPDKfij/4LPIBj6aGCCptVoAGvU37eAVpR2r6
EqZZv5XDHcseDrbWymwzWwai2nzCEutQ0/33OaWb5/YzQrKft6NQOfL+9lID+Szy9QLP35fCLDXp
q90g8mhNOskssGwQXWlJH/v9GldlKbPNwffJ9+6KJ9tsl3a8lfHDjYU7lbfeQKEvzDmR6q4Wv8xp
qjDU/o4Jy0LZ0na0I9+6IIVa9j8cDosZyncANaN8Z1wArU8adA5abYpUjLXXMA2UWhvK8rNX1mtf
6ir+Z+QSxTCwI5dholUV3SJR2VZORDVYWKm7zm1+SAZIYu7dyIS6OFRXFG+ShIDF9L7AgI5j+HQ+
SJvJf7ocRgnmmB8/IkU4q2c5SCmIirFQhx7+RleK3MClBc9iv1t5OLzRH5XhKOWzXOosOU8wEGZk
DSRpRyZvtveQHVNzVV+Dqx9hdludXeQJdPKrT9o14FUB5Gi9NKlOCn2tqV4lr6rYvGGcjIqxkNU/
JTlwloWjFV/UdBvHCv35UkOWxqtOf/07LsxkPW7l/a0AXatrqsqE/nsg/e3Q99TnpA3R2P+yCnXR
rmMwpJCZu+FETbfe01/kjo+4YakeuVfc1FRarxgEc+X378E9S24dZjPV7K9+tK7hHsydtY98YBub
h4yOAf8q9QwT/XcB80n5Tm7ikQCiaUJU8n4iIGKqqr+J8x12t7gRwzJw430ig9I7ppFQtOq98708
q7FF8a25m9DXVZhL/mnwoPnoWCUiyWPZQoCCX0rdN1BXzlVSR2bm/krDaFJ9GopFSH1trsrohwvv
IjDukzgWCM58WDDjVKzgr+CoFlZcGHldffFmjVq2SbpBDDJPyABbOuxthzu7wOZcveRpSouzh89i
Fg09yXqUXYXHCiknCk9JqJ9TkDZpOjPvC/cEzC/loASQCCorV78NbqsQw4dUOhg/Pn7cjg9XGFdM
z50YGkWEQpRassurvGIZpJYwIByTW2PfgpE5oizmiiqO78HFMXbDeohfeQp8PvSo/yyqSjluetAB
KvQM3HduujSuYnvIBGTQyf8jGGuFlxY0ukEIjVhXfCA9BWuXT0MHMlEkCcRTjU5RtBS4S0PyjjCB
qKxDmAFfMwj9N9ob7BFVec+1fyoNgtsa3nkK9ax6lb6o0C7/Tucb25mkgPBHMpCa4ZKmL2DLNLMc
2McFDhK4rq4pLpNO26Bz+7lWja/UT633V1s8M1UZHX7Omv4AnN+lhtaa+n9cKH6/JxCFjCjWiLKm
pwA106Y9Fy7NEoVQf7BjXifxGbXY2dXLR8q4CkF3MwnkFI+2IoKePFcDCFrAR9K9eIpRWZIUiw5F
m4S1+geDybGmuHpnt9RAJDf7DX8foURXWF9R6zfwwcExBLZOwV+GnZzUpSyFJ4JDdrLt3Y0P5XeI
cCZgijxo+XNaVpXfTAjEW4kb85EDlEvamk4zPSQMxmE88BzjfFS8qaJvAL2i8Qvas1DA1A/ALO0I
J7OW+HJcD3GWtdKHMbxGQl0vABnThyCi1WA9Q9EaUaJ28oProahYT4rbV+l6zxn4qfJS3sPQeZfn
iCNbyZFOY6vMXDS70/H9LZSmJCIqyW8x++3Pf5N70WbJSWPdl8ul6twNmtRMsLO6YJekrHCXN8V9
MFwTW8HN2RsdburgoVYfjOzTBC5UMb+1JB0+65vAlGbailScIdwD2KF8iKXqkcQUZhY5FOvLbey2
iiN4bGv+UzoIV1y0WivJre4zWB28heizNGrU+H8ohTIM3Qi0MdPKDwUimFaPAftvAbz+WKqO4J/r
Kk1mO8ZfzoN5iz2NT0UdM0l04L4BdUJDx8xk6fJxfjxOe8bbqJAWE2ZiAo8ueBFw5nD5zMEyE+p9
2/6Lo1K47705wRvk+XxW3XIc4k/q43X6NyiTgNvPFqW1Y+MNU/KPJcp+08ef8GJZPJJbUlzdWBHu
TOxAU8SekgJYnV1xBBuYpent1DR934F/M5XIM/N37gZVMOJuILsq5zWB6mrZi8uBnb4QgiLh7G7E
OBahcN/IEaTX+MW7NP7YwcFZv+aqUHMW+AdBb5So9r26MRt5CCknztFMa9OU7XR4/vHMVkAnRICe
ICo1Nn4+WSfxbjASxOgufNTTXfDTdnxp6+jWjOusDUrWmjKvrgqPRZ/n/jfYZ5QlmHDId9tmuumi
k/YamJVQjOf4ttgVLAb+zPfpb6vh6E5AHVRU2Eh2NSazFM7XjSelB6QW45Pw4m88Qv92CtuZwSQb
MXYmm3ftMou4NoaiTLgpDMoJuMNZP/TIH7XjAs/sJ1qIg1Vxcs04yx1mUgio7qTF/zvRQL/aMZrY
xvZ/M8qLRAtdkkJuL69jGZ4wgVyk5BgKBqWri2bGjiNiAnqden4hR80=