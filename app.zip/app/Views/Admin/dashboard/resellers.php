<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+fjusaFxTTErh5sIay3KUNacOkdE5zXovkuvd0olVHX4wzO7mUT6hEJvqgK1pLqThWplneB
zEezyE6Xc+n1G8AVfwyaHa8dn7FJOerupE1+n7N3ScLJgXkq820uYxPCA7ZCxbi0iiY6dmnK8Uuh
scTXYgYWXOw7qYWWr8uPlXCbjB0VHl6cNP019bopt9VtNgC+G0DdPpCJd5yA0SJslT7oRZzOEaGk
HGcwfAWsH1KLOSLzw6E7orwQa6gfH6MqsAWu7xeLASVpR/ki6MzQ9EJRHUnbJ/t4OzDu7SBIgEoZ
G5DT/ze5skb2vsyd3FTt7JIIXQKdP/e9FKm8opIjgb+DMCJGfMF99g8F1qVEmHXVOcWuvq7G4dHr
5SxsQ8eT7hdJH+8mM5kpmaib5QnHndXFNAjR6ufwy+5YxIMy/9fGdbqf3XSpvlF+Joz75Gj2b7Ea
hBKZWzXQJPCoaUM+DgNZ858bFgyuirda8NrIs/WI1sCvSA+hRR9OTq09T2cW6yFre+xy47U8CAtI
Xa2G1Cz1GHSKhIUY2g/vdThEQS6tJL2GhWZ22PF1vcBweJgxCaXM5XCOc28WZ2+fye2Wta18VrU3
ClEgFpZ5zwjMd6bOYX70KfizzDU0cotuYxMRyf/9snzm28/sOd0Wna/pzie++1JGR/kvbzY3MeOi
/xXWsIXy8Ek+k5JAG2pw4u/bYz5uqOvbysoJRagWVa/57Wxl3GiACdnKM/doTPwOtk48a2LhsO56
UUbThv1VgPbCwOCZ3bueV0Df6DUbUIbpE4FJECJdR9/5IOw8+MjPHK1fpygtyu8YRqc6cOjN1w5b
nwqLvkzLex5XuDztG4J6RpsVmO99SL9G0T8EufFNwaT+wWh98jgWsh+hPsgnEOaNpMCf+fX69v3x
zHEIMOuEKYWY8PzvK8JAK2cHQ1dc86w2yAlYiyXpOIKX/kbJo4AekH8HvVdLoEpoIJIVwUIf2x8L
uNUt7RN+JGj92+PyH3a281bV/erbTC8jjbqBcWFFTYqBkQvGDvEi5/kVdOf1cou5M9Ls2a5Hnt++
woqABX3tLCnYxfpZRGVMMma8Q1SqRgGpRIL+N7Y+3gzlOtRMmx8glGbySGH7Q777gBvgFckcqeYZ
AzkguY2FL+qnHySaHyHZC3e/yUDnfHKoFua63U9DYai/Px36PMA3+kWckIJESd1+Q5HT2M9V7vSj
UGPJCT3QXpFhupFOBMD0+1IQDbaKT5mGmvWwZmYjWZXokasWw9QuIJz/lGzyGfHiMZ1ykmLgK+so
Jl7wW73JH49gWVVWROlzEQsagHHn61J1BjmZGalknUQiNyE46AJZQtfL/mF/dOMuR2fFysXKiXTy
cJKFMsDJuuqPs5BaRRu9+PZZT5M2VY2hlIQpDBOVNFzhYB54n8N0r7pehD26Mtp2DDyMFipL6gfd
6W96vpeV5F8Ofs+z8d++xpr2n/dxMmvmkcYapKbYSuMVqFzFRXmJmD8fDl4rRE1Mz1WLfV4vMycL
tLUCNSOfknFJqYsOaGKPgRAZd6yS/4dqj31ySA+lmDjjs2DjgMIp6EyvjhFu2lrYTTwHiFM5AfZz
zuh/vhx3cUopGPnvS9jNf6Yfx0O1Tpq+tQxTS3k/ZQhVuOkihmO52IJ+p6++lcKpTe3vxtUsodmo
w6xB7YE8c1wgbkdEVGeq7QYf2myOrKfGCYwkjskWMfRA1AmWqu3UEyM3AvxLDq1je8HhJOjAiSv1
GTSlWvJSOSE3LefrRdyVULRUB0thJSnA//wNslCqA30HKgPR+tgjFJs6zj9WXBzJaSb/gREgZqU2
ZtWrhBF/M31wg4v9SIgxy7/KZ9m8aPsOaJM1joP36oZRvaNdb+13DnsHxAteFzd5T6fdan7MbwUO
2i7bTvIL+3UmFm1uiwfvvVtqf5y5L/Fbt+GfZYSHEnmSqOtMDoeUneHO2ba1eu3EFYlpklAyi1vQ
Hrkeixudv0uUPW1VZw/wpiMnj6roG6MjuCMUD1tQ58PaaULh3dPzIPlqGqTZiQxB3Vk05p5RxZbe
6oxs/VSbhKjEXIgbE+bfRYDj2/Wgmeqq8eQVoEIksk4X/4rl0tkBDrO67CXxbsCNom0krGP6hwB/
RQ/9f28a5IHq17r7GUykLdPY68fw1eF19mgurjFdbyapraqfp25sGol0yIeRNjY/unWzYMScCFQ8
lEerDYWW1AFwrr/14Hy1fVqe5kSCSwUgoK4Fa+46vO4VGZl/+tL97elN4XZXciDHWxrY3p99bOtT
3g49Fu7hfo/UBCdSFc+YQZ+GYz2NLSYHeCQiASKiS7i+HWK9EECfrPn+EPjZQk2frJJ3xToEtxUL
IVxmMHtomjYN6Ks2VWxfrUZA1S0Fq6JIbs4e0KHpHs/qVpNnChnZxzuIcVVyQSHcDJGznmRXNXVK
8I47g4bbeBUnytpxFsj5ATaXvnN1Og3CMKVVW+Vmjv/NmHSUhJB+Tf2u7okagPqgjtm=