<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzC0JUa6jhNEtzpOoiGvvgPu8S9wK1isBQouaP//gVTz9BQ0eHh+/WiPK6V/mbvqy+LRCXHl
OTdYyz3DgeIxhmx169PQ+pBaemZilYYrfnp8sxv8DprAvIsB5J2rW6D6uMF4nDTemNKoxHOd4WqJ
MpcXuYHbmf6dipfOU5s70/T+jzrn9E1kQqhzgAf0ObyuwEbOvYumeRvj+SUWVhvgxjJ5MJ6Ax7+V
skIa0WtLzTWqUzgqHLPLKLIynOaQZeiN5Pu/XQMm8g4wBvT9zN6ty5LBgiDk0dfP1M1XTaYQP5pC
fdWN/sEDG/XjB14dujiRc5Ta56X4RbMAS8dR6EI4EDAar76485KF3cgPhLnJ8R0mmCjoaXobTNDy
DkdcT07g6R0+Lejn8CZ1O/M0OpKx2OMqAT2CEmPpR+yBKPHErCiHUR27v9iUri2uXAnPESl67YZY
K11aFsj8pG7dazUqPLqIlkN5yUcX6ahzdfC/X426Pgu/Qlcl0LLBXWZhbLbCnWxMNhW2M53+Id4B
54k3urjJoWHbti4gagCsHdkCduj4nUwscT5bFjFJSD6eXbHmKz6mKIMMMWIqLCqK/5GLmh4XYW41
BRvnN6r8jWwPBeIVu6CfiSadaIwh2FkWtWPP4XYOQK7/sqqpe2AxZVJAOIRAp/FQOCRoPK5rpqz8
0thuRiEt9NY/qdCZqW6CEO7pBVwZe9dejWsSgk5hu5Ad50vw0etIbR7E8x2FE2valLUK7SrbxYCY
400wplAZPR7jTALjWvfFT1afuhBZCjgxX2ByJqI+ElZBgtSM/VyZTV5TT75gs/P0AwSOV0UlAC2f
uo2fS7swyghLEkLCPHX3uLX4Ci24w+eXbtEwW9TOxb69VJDPx+AGckbIUuIM8k7BKxY85uYbq6WT
xajZE582QjRT+BWqSBLILE9WKju7Wua9enLGq4xMmD5JPtnN1fCdFxesPjF08iW6JXUd/Um0swtw
0qLJHB1bslVeerw0A4bkLRW9Eep7Uu+pjdiuREIKqtJT2ZxkKvX68yyVlv+GLhDcdWoChdY8a1Hd
VaScMz1MbX9s7lnm9YUEB77PvxSVviHc1ObfqwG2aJGVjkves8MJIkVO+zBDNSioHM6cxiifEznj
Z4gSdxbzq42gkjjie9g/m4neYJ8ikfHmv0fa0HA2pAHc0KC/jsE7nMeA3SduoSYM+fcTPqn+6AVg
/orlmvOcVYcLZOJ3CKqj8hFh5eN8MkN4HHVkgVQb025YTYGX023jvP36bfWkTpGP/xHajgtD3050
wPqEinP1nnl1qg0FJMAfH/7fibBQmB7Kboia6jpeHbaRdf745k7BjuXDvsMmJy3bGL40SbybChV2
CnBP19vEFbevA1s/8XdJe7GDeGtvkd4mtBFOtzF3GfJ2j7fWShLQ9YbkQp9k7ka+f666ZI4SD+uZ
BTKcvrsDHeYqCVEzrnG8CCK982m4R5q4OqbOpFtwuzRPinDiqbRHGt9Ih3bDSxnhlbd2BlTLIvWj
vzhTR5QmbCBcJaoSaFP46XWpY5PStMHG7zi7gkUKiHbwzkLjhTfsgCGZBLUche2WswSp/Bn/57eq
jN+f4o2azWVsbkMes66Y+v0mHueuaPdreAzIuL+cFNImgegM/0CT/49KJm2Iexk2x6EAPxyDrtcD
jzeEeInyxvwxjIiR/+l/nk5YFIOTfF0NCMJj5pbi6RWpqrQFOGo/3hSZmwn8CfSbw7b26ZlNf3Mt
8jOwbxNE8RjkDzr7Kprv8ERKNdJtvoGfabfvaDSpkdoSOFbiB+n/v5CsVrencycD0sYQUspeTcBX
rL4h+CgAuBOEHUvstM1CZmNgcd5ZH/PZzB1UJod+mTr7VB4vetN4r2Or8Ti8C0MmiVStQnL7fn0k
wvWMMWmaUsdJePRxeMuKBE89zS/L4nuxD36JLvqVx0xIiEFe1O5VWGmPqgBOWsfR5KWBlF9yhB3C
Zg//A2RpwVbaqKOJW4CV4Gr0MU7IJV9n4V+hHpEwyxxL5fdzVHB9y7q8JA7yQuCbj/YTDnps4VjL
iki0c1dMKfjdpx3XAwjGJIHtht/LaTcK+hBDn6F+f5Gur9bSoBreegBUgt0eduhvHW9AziNtD3RW
NH+1ApQWWdas5cBh+6QQhh4octkQ8nmhdRUsL518seGbqFvDYX/IYqVxWeDSfZXDQqYP7b7aBPGA
YadX7FBnCHHt/d3FW5GMxGYKx7G+XQCsAedSTq43LYoUTm/44uERoxYtPFjDf17Eu/pT3w9/1pXJ
dAcd/OiUpBShfHnC89Cpn3N0cd+OmdjKrGFhPocb7nKV4ifycKb+uSVXPi4qIoxVOqcm2oiFLf00
6VIGLRHb/tZ2HvYFwEyN8aKN+SLsTxzp7rRs/rrmRiFbBeNOu9NV55bCiVu55tyLNjmeSKHKO0SL
xjKYsFd0nVPzOJkcYmHYKZJCerWSM6vcjiHrufkYh2PBCG==