<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwE2PcJ8C5jCbLxpHufBl/R/Ogl51Gl2m/jjulNzimvNL2GEGSA4NtJbZsEbzm7ZTnkMbyJQ
XEDjUTlJp4JwRAqIHNQuK29xg014Ucyt9Rc8lciZUs5Ce6VbPbiiDS1AVtKSVbETixnZGsitdqXw
m6Fns0M4Yij6mHCk1tJYNLIyn4pz7mnuxQfAOxy1odbq2WF6hNLDgwRJjWiAZk/l+vh0c1s6GbXF
fVfVnJeh1VUJHT8KzMSp2hIvEQm9WfNmxfxc0FPx4aPphoX2ab64hzVSx7lvQVObJKkM5ehBy9b8
zYqO1l/NEfdYFxqWJ84u+p+qHM870jYg1DnG+70XhTon9exLdqoS4sE6XCsPK6d1iVaE3gE0rsrs
PzMVvPKmT5eVic2wT/VAwmXTqUwj+fLxm/z5HiV30Whg8KSYyPS6nYG/Xv3ayakICtwtd13DD+tY
x8OCW8FBIgZ48PdbxzgQvrqSzIAzWEGg5MQfbyjZxHXTDjfwsvz77JsZhVoesrYr83LBhYhRsb/d
OJP4ZMetjMrUi3SQjnQ6Bcu+Jbf7LG+GGAcj4KedyRkMBV5TqYLV3zJjNCZPtdqw6ABLHS9y3KUG
j/BirZ0xOME6HrUq8bDFHv05DuUplsoXZAxKOrmJpl9h//wuNUojFLMS2z65sW6te0FoNJ/xB3F6
/4WPP9o0zr2p8mKmsHv1oFa/HKyg/ntMPALrw0xUTiQavpbEqWXOFIvNjQLX4CjCtDfbQ24hyt2h
2OmYnydMuxbjeDA4/NeAPb15KvvjvBFCPA2SOWLakpz98XpssEp+bIEg+S8jRMAtTE73KMSBCzpi
GJE78di8B+L1BI3rZVHAOdwe+jk06bWn7kfl3wcgWfSX0hpMGEVBR4qJORn9kAC9+uTD2cyW4lFb
ZNNeD2m+RoXIylOB6n8rqwQGPBZ9BCWF9BvIZ1Ro+er092Uc69KEBDePHBDQmXpx7Y7hhqe2fHD6
8gISh678rwChMOyNjfXNMi8dlkztBKAACN0e8tezaA/82LJ7lKLetJagHBhyDvHZonvpmC8b/jMy
6jLqKOkpuTLNUsuVEc/C2vym3teBndxejW0J3O5vI8e0zolpFYrskTdjK7GN3dOvHFDS6YgdkTsM
g7WnwJfaGQOEx6J4nLxszMoWrhcT8eYBZ4K+pP4OAOFMt+z6SGezroMQjxQRSly3CbrEdIfer0LJ
D2qWxOObZyNTyYMLpKyi7YuRhuuRdeaGMFnjK09YTQ9VvQk1dZ8sD7JjmYlLxVHGjLDREBDkFunY
LtR17vMR0MhF4JTc1i9H/i5x2e2lcCLJvnbzyVW7Uqar8DXCCuKhakw101jl4BLLeQsCBupvOo15
7SFMvVKvr1w1X+NFDDjPogbej0aqZUkrGaekRTqKRscxRsYI/+LB1kWoR6NydrTYBV3SVwAqUUZX
vDPNqA+bwYY799+ejTAEW7FYGeapsO8Ih7zWQ33PqDMrxyvpZkLU+jUSr567bWpviJOW/5m/d2fq
aq9KUJ3cc51Yp2udGyeUN6vcmoupA+g438xCe5k1SRz2xmw0o6ilj1S8CgOMa18czK47NFGkfnxJ
6t194VLwOmysNe9AfCfhS0k5p1Nagb0HTPwQw3tfb+4SDCtBU1j37x3j6EvLXHL+5G7IYvO8w8If
b8K7iWtcJrk++E9jhvG/QvBsTfHnYyvONxpzfBBmPhtDctbvRVLeadyl4XAFO7U3q8arm2hgKMPe
3kcJy968zYwv57G1Fh9MuWZrwI15kLMtuFaTvy8GOcqs6ZOHiH1ZObUhYZtT4Sxq9NPrXosA91Va
vIuX9RXf1ELOzfwJ6guQz8rIvCsiNh7JtNOW3aHz2SKnqZxE6U4+knAdtT1+dl/wyjSEVjOA3cZW
DLvcQYJgXd7Xs7t2IYfRwl2D6cPFfr9Pr4EezxYnxWnxRxxy9fVA5FPb0bAAdiWoB+uhz018VAZS
9LOYGrt2k0VdxnYBcCTNOVNSW3HSO0g0s17tvCJZGgAr0fDyXqvg/14ZSbWkIYvS7R3cEWLlM7Au
1sbXh7BPTw0svjP61P6GgUEpxK6RICFKLS78e0RcYzMnV9WtTz3WLjJLv1Bb3CVU78rk0Jk0/yrH
YeYYafvQvjZTNgSItMmelV1BFj6J+DtvufegGsF1YGdUwe6Bb5DCW2HwH47xM7d0laQnWYEcMH47
Va17GRqLi3W3WXCpOIsL7utVxMuUDXcFNripXzl9uBWX4pbbJc3y+yt3bwFGNa8DeqLdbXPp0UBf
VdEq6+pQxH1LEvlCxfrlHSUfDYjKrBt5oLFXWRLIrOxyljAYlgn4V+DGb0L1kTa5u+Evcg9QnZhc
7Sc7zVtPe1J+L4j304T5V8Ar2L0swEmhSmGwzj0oeja7jccv84vmUH8cTG0OmO3HZSyh5g6qKAWd
l6ik4Bk5w1Y17nuTM/2X/bLJA2oK+snmxKr0wLAWTDS0bz57hG1ID9rfaOaq6GGMuUiagXSiPaO=