<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+aNDUuHnut1xCkWpKrc01pbEr38Oczr5R2uDpBM35tgc8Fr9bp+f6qr171SP5jX6AepxW5C
wqTRV5mAFx6CNuVf/lLqyQuD7aBz6txyyjjwlLZXOGBsAJT1ydqzuWZJ3t11RPEkLAkRvcd9jdk3
ceNvmgXvHV7p9OM69uiXGZtTrYP+rHqB6IKKp4XTnfXRB8nCDFvMJLc1P3w5HDqKDAaTQYNf9cVX
Pc3zdSbrvC56AtI8YCWup77f/oA8Mzg360UqUqoPPhjLP//toGYqjdKiFaTdXfE50eRipi8R1s3a
+zmMEnHVjboBKTF+2ks2HVyhgUdel1TMAtCn79xQshlki2Q0koUwiGL+zBcM5BlKkC1DNDEXnhc+
nSRgyGlrbWLSmmyXojBJY1RxDk2ODVuewnyFQqJkRvR6AH51FfMQYt37AXZqeQTzrBAnjEJJi4eM
gGfLP22eTa002auR7L7EJzdXocoA86PgBh4Crd6sZSxcB+G4BcyrIPwDlFyt4Tz6P3li6DNHyuLX
Z3WwMCHERWxpZtj66t56iALgfaUERcsRuefyydPXzcXBQR/J0xGIPp8ps6JS9SKMFo/5Jx4zSA2M
D3bH4EGAWEHjOqBcNQ7pcoz06pwOtCAqiSXAcLx5hmH/rYx39d8B27S1KEfOLvIhNHqnb/GwDhjI
XNrgrZHgG/A9uIEeWMQU4AB0e3g16lf6l2YHdxtqa+4CXcQsioz3Ts7CENZjGCAa2HfOPqXMu9C3
Ui4bxPY6+9a7QrGj0DKVDAasGfhf9r++PEqL+cohOJjd7sr3JnbTZNBdhFnMbNcmQox38XLJGC/Q
gV/258vA4fcKycqr9O5TwfUrl+iux1Ixr9VhHtSvLa925RXoiN8YTuYJvPGNnR3Sh+OJ5J94wuUc
Ro/sZlCpEwQJtBdFN77/XLMA8NTnmyQ3DeDpNpSe8MhrwgZzKjK0DGmIoakY7ei4OM5IWrX4GPAR
3cE0lfonIBl0F/+8AYfF3jrOHGy7kAhDgdYJQ1YZwPcs12sH9VeDFeG+kO0obBCAfmNnZPXd7YFF
KzLTrxPhONl5rnLoOvoR/jANVnEb1e7gdqhlyJYR1N7yZ2mncNDXiWKw2bm5dIKboP1AIu2Nssk6
iC8k5h9VosMRxK+tVBs4G5YXykwJ6sS3q/HIYDa9qM28CwHzObjDre20gf+VfrYUnofgcktJug/e
lu1lmZaH3DNlwzjRflCQmOiCB5KhZoJC35fuAGGj7n+hYu9del2PG6Q0LHGohdA1xclcxTb+fVGx
Fkq01e6cyC/KmBt+levLMsBeeIpJsBvRauZYmGtbZn06PBZCznzM5KSrAQ7LWOX1wtDUnYx2HgOj
DeAGqvPfA+a5QOxQVr6bx0E0Id6CN4UyItOWMcFwodq2tt0NPK7AO0J36wHFxy6/Hgz4G2DxEJVv
0aU3TvmJkldMvs13mANqafZqKU5IamxKoKpFmphIHlSGqSu8tG9wRbEwL6VEFWmh2NDVedGh9tS7
sNqQ157ud+yDjccbGhTWGIgaMIENZsbXrxP4NKJn9DXlO9wYH69jYgv4Eop5f+nhiPbeK85obkOx
2wQZYucUibB4NQeO3w9yRqYBppOwSRMzEs2tX8oVhG97MuKFN5w08AmKV5W8pjN/qVot/jVLYT6I
s/TkA1zVJspBTvuhPs//UoPtOeinCtVp5HP0MN6hiCuzWivDrdO7so2S+DTdtdl6SLxhtjkzA/Wj
5eajVkTHIjcjYxmarDnImTnooyWmrYFoCoy7lkeXYUYqgDgXmvrDBMx13X8bziVjaMXfKliax6lD
nqiSN4FEeV2IYUM9AEdkitpgt2tsxqn4yQ7tq6gTHRgnGH9q4MBvZSBUxXJOfvY457nZJQ3Yx5V0
aBzU77d7aoXBj50zqzyWWudpPahfFPhxOaAlHxYhZrEH6sZlNnbzr6D4dQQkZ4/RkfQOlTGhGc6t
i8JqfcJyzPNl9AM7sjdXsrmX1wWVEAN0gMbHu8WI/wzlxen+RbWRcm98NMy3jSauPu2ZduQ0+hRA
uNcQ59lhSSsAcwyMqS3goJAV+zaagdikZhUOf1TdwI2/ddI5TJuulAAUr8kYzhxs+hlB7/HEI0Tn
KpL1RV1oZgnEZqXD6/tLvkX+DwXvpBJAOrQ801Hjv6ityYeZ8Qi1ASgTd1Pj3GKgqlWcOvn5a0n+
oBljQA7sR3DjYF9fzX4YHU1h+n9ghvLtR6K35GKnPGqU0zl9cMx9d96ViIraWlGCKINuAajwYpgX
u6vgVpyICPPPxXdKWgZhmSjpw74ShXfYN7p7gYRwX68uuZCFk7qTf9PC324oveGDf0SDxUH8Zjt1
0k3HubjxyBnD5bIZ0H/bhddFcVnL0kg1bN9qGwqJpUmFOgbSX1Dzg9D2mDJ/yD+iMTjUUUNY7/kj
l/aHgQE9FJ7NnWqsLlLjZvIzrJQA6oDCo9VSuD9agfksxHkG6+cripM0BG==