<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpI7cEibDs7CC5iDoBid7uzgoDeGnto9COoujX2eH1Xd4/wurUe6UneBd21usLFAjPySxEcM
/AjoToLpiMbBQIVLv/6LKgy+jl5Wi2fupQrTllhp56f/NvD5mk2Zh8taQevctRjWdLyRggb0DSq1
/Z1zeaFw/xRjPVoSBWRVFtRTyaI55nZI2zxyqxxUaKIzEvwhcFa0P7dBKhIzt38Ae6zJ+TzfZRlP
5ZXv9yEZUmD/4jejK9WBL745qWth8nZvCgIqf73U7N0fAkuXIPj47u5uMf5g9Qj2xvaoQk1p6l6k
hBD/77fvxeCOVKBHCAD5zhgTu8r/yqkyZhIqY2xKEOYVSGpY89fdWttEKxGZcGqBa5dLxjYlqxp+
OmxYp8/9GY1htbjQVBlx2jglkEARGyuFzxxtg/WTO/9D8O68DTzzyEqVgQjlpHVtpzSxFrNnwxpO
KztCtZu7ULMV6nDJlH0zhtcpM3JzOyQsr2i4qXymMinr66EVwqbWCOs82ZCd0xSDgZ1jXgvGiB7X
2+goBpfRI2lV2v8jUdEpGR9dFTqL3TdAjAXJGPATE9D1vSHZ26rME0t9KEiCx+Wml6RYawg6ZDck
FePbIDg5XB44l2IuH/hPPDMYlU0FUN7b9vQ2KojA5L83Hb3efqr2CNHqQQg/SxLG5nYCwOSoM7vm
RXhP8WBAnbaoEH1mS2YiDdc3+wAQFn5fCGl3HX9Bfrbpm+nj8/fTph2CvDyYR58fGZtn2ixEQh5q
N6zTTq73bYZS/7sZIYKNrA4wUb0eJmHGtDaLvOiqDyWu7LyIaHFocL1MmrXDbHd7EkS5hoJ6ZjqY
oAeXhYkznwhwbvpl3eVOrhS9YY1gIy+20Ck+TewcGeWoVF5X6iLLmvd8H9vCo0YysFZhS5IwJ7r0
58u0bYQ4Klae/KrjULU7YK0PaFfDgFEu+L43UGRmbGjA3D3k48B5D9147XPYv08SAC6h4Dp3aKOJ
1TTCv9W3sth/6hKtCvtexzMwavVdMWfndf04ernR/tF5p9TkHXvVxT080SIzuw2Wetsv+y5vpqka
Lcpqg4qtDc1A9NLrvZcuUXJ0N9CRKPbySaZWcmc3C3/KCEDpEZtpQfh/OBn9BWzXxlq0A4YaUWn0
goKwQn6h1sxWRO5hdS+v4ydJzbYXeREnGxSYKNQXa7xL8EXQSmLnJT8jqp1FrAa2B8hBAI/aakUT
+xce5MJG2p4ZQknmFjOXJa3V4koRcYmIIMteFtd+saSIh0LWPiamu930YhLjxSYbjXDlY42p/MAz
sxMsQbzS1SdttfD+crUIGVW+ZVyrytJLPBPITmabJn3+J0amO7Yp1qLc/mZONG9oryv2fMWc4Amo
uLMvmBAWJOLi6WAEjzpKBoBj16PcGNNymEmkeqOsAdw+joKabcoSQpt/UUnEfw4NaIIMDWpvSnM+
Qp5vDZdq7k6XU13SV4taelUuoQ9QHBL4/NFYKB/C3Hy+k4xL5XdO2Ux7H0VCpewc+QjETvWaxfN8
Ki6oIX/Z04LjxIF1bW0Nb/h2btYmJthkge8jj+TPC69QGqIi33k1vqT1VzquK0PumqjI5anFLdfe
Pv0Bccbf7hMIiK1g6PD513FAbtP/ARoadSVjgBtdZeV1wHvfox9qeXaBiLf6i0UDec/iWE0/lwn4
/scF2iJPcgxn1AfSxmuPTPjeJnsK6HMB2tLjadJJX+amQdy22YWtLuvV4kKqbYmjPNDpFQWI5V58
UZSgsXTDHTvnQyMIyRz4e1gQiELWmO45DwUiAQIS1nTGI7DNrsgaSijsDTvho/R4NKP36o7K7yLC
FlYZmmWXlBstWror80Ys2k8LD1iilHOTv9ZSLhAhCLO4umC3LcmuZhlgAZgAWVMqSg/TrfSbZqcG
HMfy0LfeukZKIgKJ2WJUmdcPRUrmX7IFoKzlcMm4G8249QVU2QbrBw4phSOuDP7TOvDpVA0X+5CG
MLRZ4IawIA8DG/BA4WU7Kc2S6QERANU+SI/lJdznPAmg43LYcpIb3V7aK//317bZ30Oj65YsD7KH
fFbRbvP8XO5h1EuWoMRxlo2Xjz0/PKPmSnWzbYfNHZXeC98r14GJGZKa2NZ8u2yVtWjZvS3J/mpq
ks6t2W/rTju6Oz5/bF+WSu0zbPiR6YRvWpk9U0eNjP9ZhvI7mkME7wwdFSIxzmf0xuTQVLRoX1bX
XPlPtGu2vq1gdznKsk7KstJEBAjw6vwyYTnNtuQmhg3a02C8NI0ubJJia5Xb58hyf/0g/u3CNfDd
5GiwuIH3ugT7Og0zLAaYETLt59sJUCVmiwj7o1rN19M/PWdKe2fO6U5sFhY4oG12lhTC6Yp10OUW
B0z7z1Nz7qO6U2uk83KLg83EOSbCIDWruuzNlUy4AIeOtH8BZUpsAyvjnm+OW76w2tCLQJCTvfxx
kzbUlJxM5A3ZJKUGE+JDv6UJduP+dcVxPYc/ZpqMQZQcRRh4gB7t3bgx