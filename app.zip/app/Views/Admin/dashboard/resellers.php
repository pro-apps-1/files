<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwfPSiUa6KVfiONdv5KEE4TP8rsofCY7ziQHTBVTXNJoRUfyCxwaZdC+eLMA7tdFRro1PXaS
e4ypKodONuWbymqO//deKLIk8iac9U5pw467JqONhVoyxPJZdwsihKfTK/CXduTV1sWYgHJstmrU
OjAuObqi+JjBNAM773Je5UZ6Yv3+Nt18WZ/AhXgwz8ssA1mw2lwGRzhBn685aXMBsI/piWwiM9+f
pCJIvwmc9Ho90McXJ7E2P2gIY1WZr/qhEbBuAMuJVXenY732XzMz19LBSfavQ3yn41HGXc2OI4n7
ceJGVMzrMIl2D0hcRIPO62suZRG2kcDSy/JB8jNcAA1PAIWlsMK4JtDRMb3aUn1kgRaixa0KUSkZ
8ah4SvL6gFhDlTQ3xQCZ21X46sNL4Y1Gk0mXoOHCByuZOR5X78Bqg5tWzw/Ku3DlD7t0HHcB37Bb
pYATiuEpKuwF3F0SlriL4n85Wkc51ZVb0DSSZTOZUiireM/dGWBJdC7GBwctPOeXSY5Y+lhie9pH
bOa3HXK0Vm6+yJydm39ieYuV7HT1sB3U+HY/6vsY7vrLLWiZEaZd6NOLV6QUpjKCWHA8WEdS1mup
1DpeI/3i0bcR0V6KAY3JZNK15IGWw9OkGkwfC1/mC5pMSIH2A5hDwBsXkU6Zw+hLGRV53nB7j88F
zcuiHfQ+do8uBtUlpPj0E+LcB0t/0oFYQL6fNGh1n+jjwCBT61kajY1NyvQnfRVFAMTYyQx0+zcm
BX1hoISinLj/1nb0PQA8k4vEODDHsrVtis9MYngecTQVtYe8gaumOMaJ4/jfVlmWnNoD0trSaliK
xFRrNyV0ANvPFewpr4mX6bQp8OhXN+FTVP0vEFKQBAczKlB7yyqSZbXvLUfSLzV3ab4xQz1aPNaC
LIP8yRtmiyasaHFyXyYmt9fm5sCE6AMksFsZWNjTiPbde9DpEliA6s+fnUqGnvN3ipWjRECe2SoS
6cn9hiTg02K9PLxd4JuA/xDuLBeEGMipDTkaqOvxsCJxV1Q7UkGX1uMN9gs0ZKCpr1Q+qRIwpcQs
AkjvhNSeR1VwvNp0KaxgpeX5UGA8Pd0+jXRIX12iR7VYc5/L16YqRt5QT8KzHM93fSa1nCmtA/cF
BDKbkmQuiFTSxEm7aWjKoGCh0I7SbA+vMViT14Ze2kmXOfZ5HoTK+6lAkwzvjApUVieO4hmP9tSM
NjIDIflVN/LVfEoUoRsHkvdDlSb+wxAVYuh3tD9DgKMXpgAoLU4l4s3ptf0qn+UUHmJFSzEa7t4W
OPlNCFNmbUulEmVbz5EBCzs6KkAit0+LfBxT5Le69kEaD9Xrr7R2t4MHf0h/7xF2okYRXJcE0DiQ
oMAMQWSB/KnC90vNxADHZBz/V9Hk+gfpXlH0M2NSE1KMVzL3Bm0HyrAcA1DgQOxN0KGqayxMTzDY
HUecsVkzu7h6TXpkNacISqD3JFYSxu1EcfiDt+GJE/nnE2z9cde7PRnAmaNA6RvSEZHcmqzRCOIr
90y719h40rrr/Kq9e7rtskNtk4IEM+919lyWXlIBC1dwwykJ5aY5O4eqiN44umMi/G1MSqIy7X+6
UdwoKHtpTRHILQEtA3F9yRkAvEwF+UmfbJ/Lx9qWVC/kItj49yBUS9SDU89ox9m1ghpEJmR87ZaH
/GLQ38Q7Au6CnY5jeICILm4Ab+L9/JRNWWxrof8t5q1JdXVh/Tm+nwaga7JfbmGp6meXabLzeS20
3KYiaOelmHDlYSUjr6ENawTp3ZcV7aMVCzpLw7Xn/a5/mN4gp8ifWM3U+zYCq8ndVzfm+dp53Ymr
H1GaedbP8TwFx4VhgjOjIPXF/QR2fMtoGV3ZSHHcDpuzAX04ncOMmUurz7HG1g3/CI7HmF25gdSc
PjbPgRHoE0fIjGiFoOPsSDwL6acWWNzRjwla3x/aYa5mDCd298Bnuo10ArGDX1bcONddRoO8oOKP
CEFiFxg7HO2TeumTAJzU2gmk3v7ciBo+UP6axYIOMPnv6EAcw6VT9152pkmio45l/uXcZO7/3vlF
Ub++QlfQffPdmLzqjy1tn332RjWZw6dgfm8SXAvUu2YjDu67VltRye94xPGpGA9E45u/BHLv0CwX
TjwMS9bsAmEpgZ9Jlp2lkKeWARh9b1FAsFnPfvuz3WIVEydUuBx+alVTOIRNidQyvhWtoukCexeu
04WsDRg7mrjCGhk9vmlRgHFw9vaOaOABtmy/6wekJ1waVSlMs1RQAMGI1oMOnxOID4Rz49TPC4KZ
XOUsvXuQDqLe9repBhgz/L+ag9s54nyFMbDTDrH5S2mCcQBljr8rYzXXwvQ/528nm1quZRke+k4E
gQvoKufvcu8ijXXtGrDKMkzdyNSqmiGUImDV2lQB1sWgapRTZE0L/HmZmOuqeoA6xF3lfQnoru9u
XhluZ6cpwhX/iGUNlI1raR834orW