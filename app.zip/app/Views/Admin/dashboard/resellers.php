<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy80fvSujXlOnTmoj3Dhk/rWBFb0yx6IMhQujVYlRkm3QzURsdm/+IrKv/8btdgX8YyiwOxR
VHhauq88tHswhuGvhYUI0Q7zyjbdb6dm1juNI6H7AHS+A4M4jsxUxtO9naJYWuVYSyX15wh1CYFs
9FzQ9JCSEqLXsd7Nqn1ReZ45VMzU8HJo/uW3dy/a7+2VKVRbpS1FfmAc4e5hxw7F8AD6OZlvZmLG
UvWsro337/8WAsUuo300Q2v0+377gUO4eWbmfBZeLxUYiG0Ruwqfsmxza+5f4SmB3zW76D9ld1X+
6HCn/zo7IPjXW1XWMdEj+Qa58ZQB2frYsayF6uE7lylQOFvG4HfCoAtnHMGtfhrCW+f9nE7o1HRh
3mkvJmEFog2qVxuYgENOxm2RPeqTC0FTn7G4T8rdN/5NN9fyIf3behe0zOtRSFFKdveAyUruzgns
p7Pwt2AIKb1n6+38BimP28aGtOuSR9UKIp7QpIZvrU8sC6c8xC44QgrXbr1hgleHWRuY8xMRkVga
/JwBpHYCbwBD+IiDO/slLbmzm4QxEaqhl8tS9KaKswvXHTNAenm4bxcXFwuDqsb7rSlZMPq99XOU
3D5P1oUeV7eWGAFqdDlrefNasdQtNGRT1pQGYHLjcM1TFI1PqLsDZvAqtV6LJAMD6HE2P/tnNWsR
covjM7c+Wy+M8e5XWdUqJsQd5CnOjtNg4JHY9YfcVqP7O/j3b5GXnx7ApVHdnWQKRYfSBaRAe7B7
PWHs3i+yOmDKFf28W3HYeP7liTkYOuDrxGla1T2bLqPQUyW+YMXX3JaTZ19voHkaeW1qhFZQGnc3
j9cenrKxRiYfWJCiOPEpOC8NGNxSGx7QEnaR5jZUDEtZdrgq7u0/qbxmHlw/puti54dVOtk0BmgP
4MiBhO3RZFth4Gt21YTbCA654bBTkU0O3XdYU8D1i6+TZ/tzBLSt7VMkclHOk8VnaAwc9NDPC9JG
XRPIdQnh6OV/hUe+olv6/QLRDowq1XUh1ETZXiPFdwCMg7XJCEmE2Tnv8nQhylhpcMdKEGYy8UxW
6yZgq4xriyDetO2B0TAE8ZizlPqSdSDFeW1ks4fsOeA8Z1KTp6y7B06BS4WollNXgVBsajsW2g6O
2/rC0BgNcNoyJGkU7d8kclmBtgcoA22EL7hdiikP8bjt4F31TKmBrJsFZdrQVJbSsFPgqHZX5cRP
pADfr3+5A8hvJ/0KhMXLO8QqveqAKbV/fX3YG7fDXcUPe08CcMmZTzdelW1Y++419PuCH88B/OcF
+zd0fJ7F0ZPiV1BYnVPqsalqpqSVzB9+k1Kv+65pZceHmdWif1j2/mtu3vIjsHTC4b+1JUi7zqq0
ZfwEzyZbtTFJkrynUl5FmAjA8N2WZ6dBx+2CqOT9XT+otx/FrjZEZzjATCzo7zhSvENhOvmlwZ/m
NfUOY39btBjwTzcmc6cs+iu3EkQ6271LvrFzWPlbHsv3CRfgEd0O9P2QYBSC4+JV2/3fhQFJwTr4
DYvaMBnX7hEBzRAuyGvzEFsZ8wO3I5QfhX0zMdG2HvA6kp46Z7FyCMZ6AE6TnFN+OKAhv2Lt8g8p
057huuPwPSRXqblmXJXTz+HzHfoSAr0MUi4mhWjld7RXW5E/9U45bRkFBAp0URqZqgZgGGDylIly
FRmwzpxKix9GPaR/7k19JhcSSfRl/zYJluRLAqkTOSMviU3InxLn+l8kaWHh+8KTrS5j0G3q16HF
JYB2WNA2CVzEUiqmlTxwP0i2G4X/Bsrz79haZrnfk6DH45wRW7JQZmQPwcxkTpq3lwabzYlT/BWi
TdlxaXbJwCGdxqeSR5I787CmpLMfBvvXQdvkvQsRhe+XXI4J3/aPJxTO716YZpwWRJiezgO2G2Mx
fCuNdS3BhzVPMW9/Xh41OwIYoW8OQ6TW+c8+O0fQhUBTmLp5Fomn7wahF+afHiBDItko7pXn7vOV
a5sPo5i00QcL4kkbPVORuvtuo9mWCgAOQYiDLR0FHFGN0s7JlT7kGHGnE5BQVvLjKd/F1YnSL0x5
HINSsu69SKrg1xjLPlmS8XeG/pLZpR7mo4lqvNZ67ZM0Du4cztg7d+YJpXqXXcIbnv684fphNJRa
tDPBo0zXnTlaMJssojMP4gW8Xuq2qVBrKK0AjP7hL9n7SLW8J9GmIuSMcHVZl7K5bmylGbg60Jq7
gW0heMUHy1p+2dhYg/FwQdDqdFsgXUzsREg5nvRXTxWMo6ONTS0LIcRGCfetkITv7a02F+9S3xUu
heyEn+wJbOuxnlEBMBsZpdhTnGkIzqXtC3c/VLIU8/FXqkLxwL4wykypgDHG8DJPcdaND16G1Yax
AijYXHe2Jt/pDYdt7BcmFQKmIZNGDpjDBenvoHGNncdInFbXi8EQBzM4tl24PTpuql/9NYBYLkkf
LWov1Lxouzf0TpuGsXaJcg5VAGaUHTV81Y9xtWBm8dEVLlileFGimGq=