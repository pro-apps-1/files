<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Q/L8tbFwsYy6F1heKdhRlze/m6hYE5ZAEuGPd0Mq4Ccl/GdlmxiAMeveLHlmXiGIenK5bv
mIiHDOVRyzxuZCvHDlox4eosY0y94id/kVkppr8fgDald5e5W9yUyz90Ybghyf4G/5lrNAgsK4YZ
5bk5ZtAoqEg3jFQLs1xCfDMwnv8GW/lzLNNbmv3mUcxx1RMoAifOBVxRjNQ1DFZhxBRqJQt8bT4m
7pqL08ekwJPVT7aqbVdJ6QZ74T1m5sEy843ECEF1x2Mp38X0OBGOBrINoU9nZVwoZaa5W5Rwgl71
jdmhg28MrFclRK0sINh+wl7v/WmSldFYEYboTeQHBd1uI4KPCF9eeEsfBOLSpaVE96kUFs9b6Ek6
BLR1reuG5SzsaANSsFPXX9DXYav2vymBHP1tcQ8WmBW88B2Fak9exSuBWnTuDhOCOLgir59IbSUh
1sADi1H8lL6f3eNZ0Rg6J+PBxptw6TPmzSBzFmJ+VXLaCVHEb34j5p3S2HYsumQdAC4QAihswolq
Oei663RXA9d+ZWitzQ/DJYTSytrfNr8RTQNSaF8Et3ObPtsT9Sgc0Ww4fkkPHYBHTDjop7ZkxM7Q
ItEOs6CVOnhhpkyzEv+ssqcfgBgWHUv6GJRqRugqKj5wLqBOl6lWpbVlZ/Km/Eq8hWmsiyxV/SGt
bVHkidF3NEWTN/HgXa6K+AqjcBGxfRfFAEi7uq5LOLGIRTtREMKgfK/Ies8kR485GQQi9CIXRlJX
1vLhRlS8KaYqtsDkNaq9sfuwdvPixLVTCtI+jVBnrcZg5nzjWJ2KsPBVD/ELVnrr9EIE2rkcx3hO
ZnaKOtTiW1sdZk1JV4EGTEFYoRInFMIloZL+EBzRnaWJbfBTpaDaIO4uPCoRxSHIqhJH2N6+xabS
6B8RDQzCzoK0/7en6MjrPrPSWon6bGWtajJazwaFnuZqpw6BYcuUSnWd3cRxVU0lKoyzzd73Jxtn
95e6Jj5JHJ8CD9lZ3oklpHTTlTz5WS2DqfVd9oYN1orHsZ9p9ePvmQuGRkm1HXK7DGzO9p4a/EN1
ZsPSqnFzhspBTyVE5V27A+QmntsaT8adRMgQNPUSNSL6k5FAEaReZMymzi2rIpwwh9MUFzAblfyo
gDszQz0HqEokR9F01+YdTBbKG+Ld61V6XIEk8PbT4jKF2EGKTMZoXuQcMFhzRvEYu0WtI65Sxom4
kRpZYiB4/B2BddlQbcPKLjnE2aod/x4h5l1GYcxABcN54PJdlYnQZQA/hePCw4q3IUJ4N9reyMxO
YiklG+nMNMJFYcGbg3WVVTQ4evWl6m3U1f+zfj9v2TwMi8CdvUXlX1tY2Wme6Rfqztl0XeEIVrbu
i7ExeBVQNo5lSl6H9aA8Z6NbPDhQ/EcRXYfmtD+sP+pQwEkiOTUySZYQdrnRGp6e2ZZM5iHhjCYp
iYXYgPBycjjSl01khKCAnN2w52O4T4KrZOHvQtzjtw1GM8CM0/txK0mUleqj3doguuYcR0ePOJ3X
ynNI543zWPW2JZOhUwE+w2MzCsImkhwCzzLhpHMw35nz5OmYXYNxT1zEqGn6G5S0nuJCGnBHPaas
XkYurpfelR7V77XjkSgtdfI622WAD+EMyKAcQcPXICetuPphynZ7oJPcXH2mUcMBQvW33nNPUDtA
8thqFOxoAO80+g/GFq9pw5q4D37/QdH4McCxGw/Mkk1iYvpKDRSGV6Rg97cHqBGCDmTo17Jfph7t
JivuL0kHZoU26JlcR/I20eWrS+o4X4zmnOYKUqlcLmJkGg6hBH/wJ+LZ27pjFj+IOWT9X7lEtLl3
9qVoDS6DPL3ZBbyPS51RnOVmLDcX8samoV02XxAo3/oA6wLAcfhzL916+DkBJJAPq28MsargBXwb
t8jgYgbEEhoqlntwXnjzhQoxQvdnr3c4e81/YcuaqnRmkqIpCZKeriD7q/oCZixVQDlLTz3ocbjQ
KVQNTlnIlXMLE6O4gTnPf63p2psV9g60UaCgn/bcNsyCNYISW5lQsSm8zYTzq0cuIV/baurOVoIF
c14tMj7tqVdBoU3yPYk6zuxqUKRTJDR3vTsj/yRWq8t1X+c4DFgwBAZpACXEw4FD2/kxPBrnrgFS
Fqat5h4EBJ0jO1IkBO7cC+dSRYjsom97hIZQDhuN/hcdRxQ2WXsy+UDnGoUmXGLfPGd2AbTuPPs6
BS9PhlBhkFf3/N1qChUz9QLJXSGmVjdZVZe8WzTIK8Dt3ArINbSmPoZTZvRBpHhTC/pXqUTbobFC
yTUcTd8K/7KwSvwBTZu9m2C8MBrZg2u7JkGZPs51vpRRBZqk9qD5GOZvdXFv+slNZhZDN3kGIsSc
6EzkZbtBv7/gsE1zOfbXjTxXn813HXV+Ooy/f3QFCdHmZd6Gw4EIjZZTbIi5DLsuD+gK1EDwNnkh
LLYDv0sZjW+GNy6O0p1ZqnZYv+qJje3/JlB0Ze0dc0k410EjCJPe4m==