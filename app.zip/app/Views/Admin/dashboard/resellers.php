<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzidKRJgbwcxy/l4bu60YQsyPttd3wmLLhwu8xSVYA1T3pd8tPtOzzTQuZB6gUTjU0hbs7L4
itQxU0h6tNu+Z0eNXar1EJ8W6cozFLvVdHE9AG2c2a/D0WUhLQMe0feeQ6lKr0sDue6K9mMEy6kN
dPv+DtXwEbpcYMyx1IVDKRxFHn6MO2NidlygBv5IVyBb/7++9QohGpIwYSCeRQXtMQLQLUW5wEyA
CrkeUovikNfld0kG8rSXnwZcX+8KkVh1KhSuB25t6JBBuRV5iQSE4ED60mjcRo+KayaOccYkuAvf
hpijA1inGcBxLNKXUCkUfIiNn5EzYsSdqDG3TrykcUAwDiWttC3qrGrboBMDdG9/p511BBQEmoVW
h/Bxj/JkI8rtJNGO6jeHbJSpuRRD8lXw/yiXZacGtVa5ugWLO4cxCktOI34QWJyBUqYg2GSOOJMI
sH4+yAGFFxK8kVEpUlljNR78rr7I2e4qtaYCW+BeKt0n2fvBQnHBk88rVg6YWvoV+yJ++gqYLfgh
YqFWye8J4IdmFXvnWDKz/ErBlWXZKBcWZT7C2cx1B8QFWEFc4gapEVc4rvVxkL+vEv47HGYFVe/m
9bQvL8KVDYEXN6a+jw5nqj6+Awz4lZH6ldYbBoDPhcVYU3u4PU9qrsAZIsQT9voYxPYHYCNolwPF
uPvXvrfafrVY4SOqQepSNjeoRvkciVOYlhKaS68wa8w/RtfaimsTxxTvh/p1XypZDDVtctoc9RV9
7zZSnvyiXBoUQ+Lo4ZI711kQ20Z3NhaN6Iq0mbz2omA2htfs51ybaPaOulHKlWg/TyEzZscmpSEL
se2etBkkKipY2kVMd1k99c2o8okVm4Pr/ovb49NweOQg0IB/MrHGDjNMSDiDHdIn84wN3pF683lI
N0aY/WAz6i8VEBANWJSV59W7pgJIDsKAMh2nvxeQB5agEQL3drORANquweEZKaLLCnbEK5vf9fWq
QJhZXwwLERYXKL/4o2WxmifHCHJ9x1y5VLXjQLn1d5WswxHQeLzNk/NU5iRfm0eomEzEOGjz9UYW
8gw5oZ2+xGsCj9m1GYPVqZB401QJ7hd0bHr6o2Oxq2+CGIMus1ywe9BawDO44hZPTNcVCHmbkcdf
dP8RfeTCC1l+mmVa3nxhUbw6IxFzdlZFnb1jiGOPK4pGCWDtxA39do7uUgAsPuBoYyzruOgER90q
8m4pz3Y8P4kW1uDN2xfq0HxPwyR38B/Z9TL2Pl//YULeGgDISo3y7IJJKu7SbsKHZCHHAiu1Rf7s
t4PQH7vWpGTzpPX0GuNtrQc7z0DNpcYTbaPLfIwC7vMeArokDvsNMDPcCAJRyGOpAt3A/NWVKNyO
5K9T08gqXt6zDIuHmJB4c0QIwvBMTPWgH0b09ZQ/aSfsmEY4eKeKx3YVbXI8sKpkNGiJNAg1P847
h9wAytMg511efxKzgrZaVCIFfHDRdtscvjQ2t2c4XeWhjGEwNp2RwpNGA0W3pKCZchmmCCTuTwGv
6bg9CQGPIolSv7oMhDCl9rDV1FxT+nyoOnkNgVTnl9u8YzPG19ECd0mjx3dwcQ9YoihsUKwtrmI6
Wj5y2ESAe9M28Tx+uPSr7TS1/+MYbGDrHT050eczK84GDGpuOeE5/sMDsWi0UHYDyt4bcltn+/na
/zqrjMALFIyVhbk66ixyfUrPnuuHgXODJKwT63YR/mhkX/4NPsmeM5R/AFPIei6s7BQbmQ+SmnyS
kqkf6qKEF+VP3UWHU3H2VyTosnqmm7OuYrGDMMB+BOSh8NapSWU6eyDfpKZVIZ8N0OPIk/7EXsou
6B3IrDiOP4pCfsCGg5+rm3s0KQEAf89ySkIdaL0Hql2WU3LZoe1WdNBTRqDeOLJCcmV2LN1Qqkqn
L0N7TwCenDUT30fI+1yTqVopP1yJkctheM8jrhupSsprv61D2sY/2Uc7xUinkPXVWJxCKJH3thx9
p4dgjJlRdmwzatM8gnBajWVBpu5iWNhXrNbdCDdGNvVFG0n7X1Ja1PaxznEP7yj3l/8TuXF9+C0H
Gu9uOX15O+JMT/64TJx3f2BbX+dcZe+iP4xf+0jbL7k0y63kfn7HUIelVi+aG1EFZxDsy3auU04H
1mIyCMYFfjKesc3v/uI3EdtkNPN4T6pTnIHi+dJ4/+EymDQDObEGEO2nXLHAGvtATJ6LezvD8jJ8
MMYpYooTVgDik3WJTmMRJoxxauFuT0P5ibH1SVcf2tLWLU/sGK1+XElqOa1T9aiGbvscH1Ng4w8n
Cz+s9Nau+2XUQIMc2i0q/PgK85GxrwbJXGiObCDfSdb9snE9Miwc4LdYyI3UJHzNfXONFxMuMezW
Y7ME5I/hQ1RdffHPTcR/N2xZiEjxyMnf0NY9gbGMEjmi+Dt7cs3cIZgNhrSqJpAzRPo1zmv4Yp1D
//gtriE13077XP0imcuTXruOXl4r0YpYilqc1A4icK4UTLTjDRwUWuHix8sK2cwXXWq/+FxpidYa
FZPcjpj/48grMYnnSW==