<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPskw8rEJEvXaQcQsS0s2U/rmopgIhIXfVVixMUxtJq4tNNbUX6vbFsYqOheBm9wEEqgnAdgn
EazGjXjo9yUhU25w7vsKw5fPbRLRuG1ac7Cq2x41cOoyVDU9913NsuHAb18vedPKeGhrbvwc/bpL
WHiiYxCHMAuXWv5zYrkpcmafEUINIOx0TQRube9AyXO+QVqk9L7m0iScPAh/uDCjZ3yKz98zIIb1
zfa84WbcKUEbcnP+N6dmk/az0YOuFWWZUaxahcxKLL0DZptD5Sss9lVne397OgMvBFyiPcyV1xk2
WZGuHV+80wnA7F8j1OyRMYO8y/zcXxZYL3dR5mrqZ3C5IX7nFPyNg5jt4D+YsRqZ4UfULvzVnOig
r8MOVRgUetOMjkwZ0MN2kdst72xRfBdpn8YtQWFya5/laYCbdxv4HYQbi6YJX4HIKValhLBbGX6F
bg92hCe60VbYjbLs5kJ2zRWtSgNytSccZN2U0aT08mUzBp77BDMcitHD8WKNc6ToORcAB75fgLYw
aLNcMRRL5By39JD/3a4swUPme6VVmAU7fy3NrxyZrfVTMlzoiRXzyVAGs4z9Is9SST0RAc44+4m6
FXXNAIFhZrMjcpLlPwohGTmEee5RQwbB6ZRKCYAE1645/+nUr1V/oQ8wvMLaqjB8XOowIAOXRUvY
/z5zhunRvfQbT8rRuG9vxaaWgQMBqfTdh88p0iYCVZd38/TsH9Kk3LTsdC3CCJBOAbP9hgem2OCP
pMwN6ijlhZ5hPNcujp2UQAuhgi9a7FBn/mCGZbOc+ELvv/0HTxrlT3guILICeraB+cRim+GNbB3i
qpcYVAyWKmy/d7ju+jFZy9uUatrHiECY4s2oX+05OQWTVwtRctscsrde9sqSrUoj/+bN/QA0NT2P
V+fls8xZHNBn/w4INjS05KE+qpDnxIstmFfOzkrB2ru8AhqKuofSab1UTMQMBFVHvqMPCDwAYeX1
Yq2P1svd3YLkCc72jLKafkuYyKR/eVG/x9pbtfXYOK0jMsQPwJu/NrrhDR2O2Bo8I/0nU5J5B0LA
2kacfvBsDEDPoxuMiniCynf/Af/IFNA1fr6S5FM6seopWR9jKZQQ8fc9UqW8DfeI39hXMuvh0fVo
dmXw0D1N2f3DfGynewcD1GiLLDr3gCZZSVYFG1Vbg75ZVLKiYQW+BAcIXTC4DjNbezAHwhwdom8F
7/JE+khmQMNrSRfSFmD5KGU0AFAy2GVPb5vo9S2O3gCbQwl85HzCJi9UCF08NlOkpoxW6G6DgVpu
TNVfVYOpxHMNyiteKhRkyMvDeM7vDeINXE2KUJVlfA7E0WlgOqN2zCa42PvveYflpnA2ryWUloK5
Qynh3U4sFXrJ6wYgkeKxso/0XLzM2SIw9ZBjQc21FMZy2NjQc1sh4N6oN09OYrqDTqY3y1gv8Tu8
Sa+x//oGTQRvFSpUh/shQh7mo0SNhN41O1D0xkegvlrz6X2oalCXh6qfHHVSEUaZdHMKmD1CeeGz
ERVzwa1OaX19L4BOVmeR2ZyhXZ4F5DSkk++NK9lafj89Vj9mgGmBmWOTMdsEH6sGtGoVstVXnVMn
HNRuyXmM1CkYtE9B2brnVcYeGr+ATJzfqIvcGQJik1moCVP+WRzcniRpZyXg/SJU6Zav87853Upq
CT7e7khhMwt/7UqYCPhaDYdRAAbxlBV7ZtkDBZiCLRzzSvgBz8imJZeqtbifiDO2Tkj7JX/Dk6YT
GnP0Vg22/HhDgcVBHcOXDy2aLiMhYbV7eJYw5+fL8FIhx03b+PW0Dk0cjxOMp6yxrPGEnpfKnv7k
SXtR3OR4PUn1Oy4sMeTQEVtN7VhhRds8gbqBRbmYv+6TYVZz3DyO4Yr8zsvlK1e9nt2ZIP4EeE5l
mXL4lSLsdSRHPs0Se2FqHFPyrXVjJYrY8rj1LJVg8UQ/OgcqAjXkMQa4oF0+aAdkx6yh/KdiOL6f
Gl83/Ih+/UNX5bX9O2ai5MMzh+HA1MXgiu2x03aLSLXluGUIzs1OXQQGzZUzEqCxvTalIXcq8cku
rvaL6Zs3jS6gmaYvp0l9HOiPDKhEaf5Uv8nL8XC594w1zxQZZhrUwg7qIKJald/ZY6lNWeY0rRuG
Av1Ua53WXNEvWth5DTWEXxXuMXCuAodNxZMJKZS2djMGoDY2LEBkTuhuWtL21zrUzirmWszhaHyS
wEP8iRiTx+mY1G1nsSOt5H60Qoyblfi53fJk8ke7TmiQdgglYraG/sz6xchJElLXKfH04D6LsoW6
aMYLS7yPbxPSGOHRdQIfaHfUjvqo62NeGlPjJgjmrJC4l/XkZTcJm62oyTJjUkHbfTmcvhDLa7PP
Ov2agMV4PgQap/MxiJGL5aN1Kaz1wJKnA7jgVm9IHsNuhq18bUJ2/0QeB6MclX2gK4j9I5aswtu/
OzIOX5+VI8eYrFFAXudQkkvcwqRixDOFURVkAf5l85kkXUADQupIAsPmkrOhGRy=