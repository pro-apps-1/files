<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPscJLJBYGgu5+r304MVdUf71ajPTlAdAu8wuOot2TMYalBdD43sO9TQxOkPLZ0B7ejt/75m0
nIXz+s92wtVfHxIfunFUpFfThdwuM23YmAPlnGKTFPQhqCKTS7ADGON+lpGG/W9ztcpbzAgWGFJM
85Ur6+kU9Kz8HCcBtvxjM+RGlU0h0sKIVtLFGzDSe5D1RZK2Uy6cp21NVUXxDj4DuL1ZcwiFKUsm
JADIklpljqpPeMNpqhl6lpF1q3H+uA0e8LL2nc82gkQCyqV2yCGmDldWe6rnYeRjzKZ8/6+Q+f1S
rKSQ//JEyIcLEgaJWl8o6I0NlsNH/2wiZi/cKdpNgF/frNrzpOFXxnt5rCvs4jIHGZi3k8UaJzdc
SsQhAbuWdnzNh5GEOadj04G6tvhqvYI0xCQKb6ox9097NvBImJLm3eFmSDMRUfgnC1lqkeYas5Ds
rzy1cw2ugLm0eu2YmcW0I9VDRRP5N5pqwO7XFW6Jn2f0eq06kdXqvc6jstbGJ1IGm118lWkhW6bk
pR1hGlxYkPaHcO+ynbyG20OR282j9+vnK275Aweh3zt+XQhIpYPomM2c6egCxq9QaQNBESgpa4Iz
EN+N5dMZ+1P99woop4M1d+5fZv7QuimnU9XLC3gMW22BKVgpRV3mqdO3wsawpmGhlz1UDVqtaQFW
pLyOE5HJ3ihNuk6kduwXWfZoNMH8Aa2ZqY+1bFO3+f1YF+kNPKdUshJTsHvH+wDOWyqx1F97Yuri
0Ewdndb28QlaxWe8HitVXT9vItOpa6n+6oDyFqnlNckTeRN51g/O1MT4+qQ5IrF1QVZRftW/h4Tp
Je1I7dEBqsOafT1RnfpuVITzwUAq2RrnlsOA++4CSz70SlF5h2oyaOhNE9933DaqzfSBvhTTDiTo
NM4HNNeGAuNxo/gko5/rDU7Wd/w5xuJYbz8Up0h41oieGhnMedeQLdaAI2GFtrD5YkE60MsiEIyZ
LjmWjPSeNF+eYz2iK8BrxoWCpYIpmmJ1LUL25P1pU1+QQ8FVGygQRLtoz2hlSgILrNhsjD64v4cy
kQ5vIQCZKn6b3Lgomc1BRPo1+QUfvEc7BN+jFaJrbbecwqsq/oWKTq3qtQ2n4kPJhYSNvKij0X05
L8rLEh6sA1Z6OV93mbYGXtvnnRVM+TcprXkUisGVm6zHtl60jk80NzJ+vll7X36U6TcxLDRiAS2f
7zgImdIK+yDORVSJ2aeW8L6LP+xfwrJY266dp3eRFdbgFp97fwwhOyL5d6b4dZ8NCK8CkfF2K6Vq
pJ/gbTspyffZ0fwi2WfB4Dn+w8LNwFfPjjhtSqh8vCqFsgz7VOFGTURmBTC2BylSQQG604Tb4b6S
bZHTgk837XEcWEs4FVQ94AK61Ibbd1MkhAyVwJQUrLTuIJuvAqoOQU3Z7+/Hwg1MIV8pYMPIAYZ3
f16K/AjeBuofLoTVjQxMXlERy2JpSNv7wwBWfbhAoi/rzpipKymj0uLidf0KFuJDXtHpWNv+EDVm
9jrcWHsxFtWotN0HQN+n9hrwJtXdI7lou3xrrxAO+XX1Iyp+jpZ+r6FUNjljxtLa4ZtI25ox685C
NqxQCJyarmSeUpQijTxxM7eaK0pjbBijd9wG7+bppA0FZX8ruBNQwoOeiwhlXC5hLS5AQSVWVn/e
MV4ijgHTbVM42at5X/ZyDktehvVjsFBEDeKc4+UtnfsqW2OX5Fy46YtMCx1CWy7Gq8K5zFfvXwRE
gBfI8rbv42e2ub1uuv/dgpCg4RPGV742qgocdeQ1zll/9v5Pjr6cgOa733r2XVsCtu6EPP4FmjkP
9oL3rmBcTdss4vHZRVDO/qjDs+Ktrvd+Uzj4YuIvq24lXFfyXL/184Q+VKKxWLSo7UOGnYaeZ2pr
vNYoWZXzFhQx+Gf5k/EP44ijeb3QinXz3HJXD1EafScRppJiBawf1dbmW0==