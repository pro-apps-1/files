<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnoNVCrTIKNZ65NfxZrRP6t2oQlDtJNWM+aeKfSj4k0Ad20Ucl1V0MUPkbkh4Hi3ekHUHU1W
ZOwEK5YQY0sdQ4Htau6FHtFwP+jOJXHLM96NcIJ3OO0B3uZuINDoHVO9zPhFwHl8AOkY86TJGUdR
x6sJnPrNXT30Zdy6IMWhQu935sj7Cvx3BVGaPOcWucYBH2mzLhHXgJ26tPloYQeM2FROpiZQwV/G
++6+W2S6sykur5WQU8+QXu+WcilHUGk9Eu8B0SPDG9KZFqh4jKURPiTfl8DzQ3vV2dFbe7xnOYvS
c9N8FNCuuW6jR04WHefxg7IYRZ3pCpy2G6Cn9oKEiIw/tcoH0LNR5gJJo8NDQJc7eMoYTAJHa3GE
/dUFXj38eDJMOAwWp+gXm8OdQUqV4v/us4dfcx3VUrtzdtm7Exy5nbr59O54+5y8reTKciD+BHMt
SdSPrkIydVq9E9VqlHSfaslWyx/GuX0tK1fviz4ofvJxfX2pJnsYhJvmdZY6y8wbna4FmiHbV5iw
a2R9zSMylKFOYPmf85VXwR80QHDRVW7qKnxQDg3ybhfv8THKJeUhL8YEpJKQYQvBCKxJyIh5EbR+
//zaRQ4FcijRjUvwlxquXcK8EchNRWymoerQ8KEV4MXGw6a5cf28vbPp/tMkvHnuVA89+y8ruMNy
qg2wFvlzIGARUcgre2rdAi2iRT/pBRDIIwbt5vWkxDGAeN+vyUg1Ujn6SeUR9vBgBxPEcBeNt0BN
kxeb3SGrdydshF34IQtGllXcbyGwuPdjfT01GPFk8fkZzg2ywWt94N6nkxHIfKCN/th9yIkO2noj
5wsmixDnSpe/8p3Cw1qwoelFYE2Jz0rNESPQbsmbRrl8gZhox/wxp2CFBIQSnfUuqpWCueyVFq8w
DV+W+zO2Zzl9m+1L5Li9BuRFn5C42hwY96XmZcM2Hsat8Kurp9NRO5lMobTUde4nvup3iaX5KBfd
txHx2613WHN+BOCnfcB2wkjuUZ/0+sLl908l39+fw8H6i3rFVh3xFrwFm7OPdrFZKhpYJmOSG2id
SxpDKqmSk2zjFLCE+w5JbfhDTgVW7y08GybzBt0YsEOnZ9SzT8XSWIhol13rEFcq848jOG8nXLcg
GRcAYYVn6osY6fLKqtX1+MsEBLgZIBaL9NnboiKm0CPj8BK3xRlvzV7NLVydBwl5bQuw4N+CeRT/
KSnPZ/jIaL1R2Kca+x27OYBGccLi5TY1JA3pRI1F6ZFDNOI/aPg2GWCxjga3UQxuNK8w3yIzwWFO
A5lS24pxRxVI/Ycxu4x74yNceWg53dA0CIWYzOjAYQxRpTl+Gte0l3qojceV0H0dAUVnfsxYaRq+
W0h83oM53Xx68Sp23utJjfgrsQjAywNA9WG/ZpTawYVVXy9f0ecMYH9F0hreZpOcdtOlGp1zJOWu
KQdzS0aix+1LHju4h6jwNmJxgqNpedCaOSys45D4x5RAds9omWJvf8jxt/gRB9OCtusLuffsnR5z
p3IoUp8FecV4JoLctt8RvavhBEjNS8viIO2UyCEIIofhKGeDQG01JDVHrgQlbZtz8CuQUB4RQeIi
bI9Oqipg6kfEg/kYnwAGq/zrVDjduA6JUozjuRPzLyfgIDmcnuQlEoyIBq70XluTj/GgC+eeR84S
Ym8eGTKLFZhKIbtAJLrW1g1E8gznFzJJFQjPxB0iPGy+2JNnkM2dJPxM5+YjZJEHcyuHZGJJnWFB
VkRNLmp+jgD4bGIlqLFI75pJmNzAe8i+M4IrkGuTcLUyt7hX1b+WYYeKIG==