<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsVAYTPgcd8PSmWSzLgvSR3T0rlpx4U3dxAubFC5ES5uAyj4i7ec3aGlhs+EmFi/wgCpZRPs
snvt7brxNP5Fl7/MaGGs5GZJegFYcCr4A1BPyx8vHYKt1r41P1KqQW7BltE9njDkAAWwtJuh1xaL
wywvNTE2O+LiIUbK0/pxV8SXejDjH7MQKDkMoZWsbUavJfLml6bFsFaIe3HKvjG2Gf/l1BBga21b
LPPc0tn0w85A0spt1gRZlYQWied1zcx5whM2f73U7N0fAkuXIPj47u5uMcjcy2456D7tPtS4dV4k
KCSu/wS1Vzjt6yB8hMQedXO40fCv2yoYP2044eLA+Fo9hvbq2uhvRierXbVjPIImPd0RD/xh3lfL
BRSCK2Las/4FWUJsmhb9Ibmpim3lT8jsNYo9lf3ydRSaDA0igmlmSldx4NNgKluXdfDp//o9EhGI
SBnA0QdozKOmb+9iTHELg5B7S+y6i70f6p9RubKkEx75BOT++rYkgiXJ4RP9N9n8ugZl2blqO7Pe
k0m5GRMstNXls1Q/psBDWQA7SY8DtC6yLK9NsWQAHjR/1sDDENsk54lE19jZGZ1wn0i3FiudRuYP
rWgTcOcLzDHbeEGfM+xw12+2BbQMZXSvPIopWQfjLct/uu+kMUoBJDgiTYuqoNHIHI3g28Jv4kW3
M2gaAMZ6TQQzxNKxcyWt0l0ZmFQMi5fQFGXsxoHaynfiApeTOICFruRh/g9tAL9t0QtELZLDzffg
UKW9CsQ86/+y2r4SpQCZY/lJ74twiQZd21tRC6lIs1LsvCtPJ41dYL+JSe8+wAYgb8FlwaXa15TO
M96bDY5KGRw2uE2ttHc5z/anWTx+g5H2mqnDXG5QeA023PSPkeyAOaXR9NLfGSUDjzaGdht6ZMQe
3mElXE0HR9Ei3AdZcVgEN+CS2n4kcfsQYkk7eBbjjY+cvFpEphYnjWRAj2FOYZrGuYI5BYYo6DeH
8I1hGlbfjIRDxyi8ufKz62Pp51Z1kzxPuh8CuJLSm3AbxakdXRVCEtFayu4o51gbdPXFc3+mhtyn
kckysiyi5bGJYcyjSlyigyiD3/wPGlejskmrTTD4V9+55LoqFlGnM1TTWQXTlvRZpv9Ca4tsnNDh
hipVZR5FM6li5qD/QfbBLFRHN6kOdUowMtSdckuL9Q+J6ePsfPbgdbufl7zuVHDDeJhZArHytQtp
fODpwFcXeWXPBNx/cqzDHIk6lfNDjOWGB1AlYrljGhEGH/StahYbNxI1cQ5YKTx6OYr68+QjHET1
5YzuRPZG5j5tAWxzyx/VIH+p4sd42k/2tRc2nbO53vnMqQDLjXVUmQYjePDdj/OsAj20gs2zeS7z
LaH1FViRsaoPAQ+OnyPPioqx3PbvcP5K3mxf2Xnkj2eZDzdahiU6iW7sLI8AFSZS9gNa0xPNAYCn
6NhfbhMkDstP+t5MmBNXZcRS3OyKw8WTzLMz9f8pfL2P2DVxHVYYpbOTcIDpB5T7xk6Go717yZu6
cwoiL0jfFKzNaLn1NYqDhMRo7T0alePZUDt229oeNMNmlc2URNv/Zd5zI3L+/A0CbRGPEVU7J1Tj
LWzBd5WOZMpUuoFuZ7AnKY5K7pr4NBpAL8+PkhxsK8Y/8QwuGNkCnlhkZfg7C1S7j2GUkvadT0xF
12p2dmtm42b3OWf0y2z0ExtONH8CDmSMRzByxAbNBCdpfxLJKeh1jF0Sa3dTYT7NCT53OTBONB3Z
SBgYL70FeiYjWve4WmJXQU3tnp59mAyd81Bs