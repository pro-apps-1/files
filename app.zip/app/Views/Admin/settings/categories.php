<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw2zmryh43YGCdvMV0HjicNEW9++goFoZzfrSOHFyqOT5xlVg6trlxrAVX66lOCnwZT1Fxg+
WGhg35SzX/Qo6Q3qop+JrtknqRwPoFZR/bku16uZ+iaAXeWB/vS7oEGX6B6hf1VVYDyKSiuVGbne
TGf7Wzr5khhUP+U4AUmBWbYqtWObuMGGBBM99jgAZGO7g49FIiBKa0DkzgZCv9TQHu/RqXrRJjgd
5VLnnVZSXvUYE0seBpYkDbigojZW2Me/rU/FW1+MgeT25D+EjpKkAQLjijM1QrEX6+6Fd079p5pk
3hBTM/yXrTpVgiLkr3aGcEtpzMvOwScyE4cHDr/jn1CxpcfBTjl5dZbrI11WJ5yRkUuj0RFPEZHe
3VixA3LG4tJtGUlePTUU5ZAuU6vQZNWNLtiNpBa194WPDAQkxv4TdEIuAl5lpbNA6wSCk7mWb1gT
x7lKJUuL+9VSNuTfIlKYWgNPMWSTHPdttmfRYuG5m36OE/fPYZCB8phyAeG4VLbKHMdbsUN8D0Ur
E7TssN7Ys4xuQ9/F69NmoEy0jxaXR1e1jmtE5bu5S/FzWaS2bmP+pOonVRHfXQIw2QPYN6pKEoYL
eMfi9sl8qfS6ZmN1KzMVZuRRfZeVdotvIBp6g5/Uoi0KHc+uVgw0/fjjA2EkQD6laUHkUnkwru5l
kLorTpMLFeNutfuRiuZwc9s93cvIenYKbzEU+nOxwaRmCVx+s2RqdQ26lrY1hs2KiM48B3Y169fv
HXQ1b8gK2gw4KayBrYlSxF8mySSoc7a1NnRrE056GdoepQa+EzyZ3xLrj41n/zyI5iw5rxWuY4Ym
drscNmBpHnenHiAYWv8rZvT8ruN98yqVE0snOTKjGR/0E5OrcIX3pmxfDyjfPfLrGoGpseZn+Mtl
Nq5JS6KHOgsmD/+BD5WktRLzEYY9Q8g5Ul1lixuUUIJgEUPgqNRuWv/6Q1m0YXecmysr3vmBg3zP
zpq4P2A2nS31qPjuYUhyFhKfl0ak5uyd40bY4RFXG92tGVJTy20v6nhK5AWQnDbzPXY/znLnoMZr
lPzrQBiDXlmE36odvJhQ7KSZs22HRv1JCR0vQDHy1Vwn+Pc7l5VGhPc884jBIKwsR2l5+dWB6oJF
k8cgPoG0MMwyJx/zJxFAdfKLtUe3+RWvC3DNS6I/GwtfRqqVcELN2naZuoKce369SHpjbxKF7Hy1
JWjOS7hLymw5rSDb1fK57EX6PgFKpKGgfjY6ZmnVIsp1n875p5ykX0WiRcxcrmfUNuIxGFxVUlsk
IAB2k22mgpYAKslJq0iJh2KN18H2hWuNRylabIL943xicP8KHjvUkeM7UUbRyHX+kJf8mCQcYM2F
sXC4mg1M6KUs+I3fVo6CojZ17gRolWV+ZB6/YFq4Sp3ZMMmO1FHrySI02f4ozge6aKHgVHWdhDgD
a0Bx99Qdvi+KckeTjgT0o6LLRVLQqj8cjfT8LgDA9PS2xsGcbT0nQbEr2rSEeY/MqxTVJdDb5Vq6
3/shIbIagD3CS/UsECOznWmjE5PdsvjD14hAEMi4xEXrJChhj9Y1u0qSeDJM+3Tn0ZiAU8kNlRoS
IFBVQwKUwkmY7C1ATMPhnzzUAUzYaGcOPDgOTaQM45Zp3aEFCC8ND/ljBS3eLzmmc2OqcwsblJb5
Ip0vPthg+2bJsO6b9eZk6spN3UqFyKWQ7hUoHSnQNDwoGs7+zC9YOiTpi8d8968YFm/5GUsGcT14
61VrwdXcq2+I6F9cAMhsktXyfY2Naidn1aCHsmA3cmdu3c8hkQQc/DdYPZ6afmF2cvOY1wc+IYig
rdB1xBa+NzIsLc4LHq74JTtDofTO9hZ6wOtIp8aIkeKGnL5xJBu2NVdTmiXAGlsBp62qUTeJNKHM
e6/j501Tr4tLVCYApX/wlSyRFVBSV89KnK9fPDbVNnwo+Yyi4X2ngrsvlW==