<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzrnsgWDxpwFoBDFYqp4ry1V6QJ1HBlPcFL7Jma42FztHzQpGbCm88+SGnZsQfXWGnXMAUou
z6EHls9WRlsQPYMGSr89iTdb7zpttuX5K9tBae2lzJEKfA3A3hoq3keO3z69S4vPpCRLXfW/Phg9
ikq3++r337refmrxzLrC0siKMN55xbzF4yR586oSYP2xtJMYj+ovbajILY2aH9+h7ary+MmCNvG5
6Gudr3+ynwTo+XTlOCB8yhHO9MIcuhr3fhXTIDfc3gKi+VXMPDuvxUuHG9FYQaABm2Aquafhxfga
4LLdJmlqeVSOl3J7WrE7u8/UFSeNb8Q12c1U4arwsBeb/0vrHv5VNgu9Jhxgf9ajKzVaSSNU38vp
PYmacjrB2tCfP9ShN0FJxYEaQggW1qGmhTQUiMkCljV78RNXONp7RunhVPamHgEbCxtBno5/wOIk
eswo1ivqnNZT7MddIZgugcBzXCMydOVy8V2uh3igiscHC0C/jV3VCJ9psLXzM/MWIUWXYpue3GLA
0eN6o2DcIyCSMw2Rxu/4iuNqO83MTAtopAU92vEhWBRZ80/iMcHP1tU5/ZX/s3HPjhK2dQeQADLK
wxX/uFxN2creQvB2SrZc4TT/I3TaNCyK7iMfvkOGoHKWGPVmnmDE/tr7c5aFo/5DKO6sb4qSNQj3
cj2BEKgVbIOq2+hvi7nxf4VQ0eo3u0AvlUjRngGzRaOQ+xIR5OjF3sB9GyGHNc160FI7dUB2u541
waulvsKI4GpNEcSjv9rVg0UgNZbMcmzToxSQX+V5aQjxPx1uzYECsMZWdG/QisKc2e9WdjfYY702
PjqGWxg7XvaQqdl5ZeztRjVtPsh7ir4oNH1vAIVYie9iBs/m5kzEhwu0IqKW34u0ET+5a0qm+voD
iKv+GEJ5cjraHnMMRxBXHyF+96/MdNuGn+zA3BYqJCq8hDAA1E1F3/InRogGqgWmBVq707Fg2q3n
WSYTyRa2z36jptV/vDndyoasVE2CpVcDjm1mjQxpIyOMTvOWOGV5ThHNKL0w42vD167SeMPbP2ku
SkzvqYKdyu1udyYLHZyaCu8scJLBAzLIlbxGVNDNKq17bprQhKQULz5QmD79f6/g+BuQ5/jhTs6N
6r1igZVuOs3+spOFHQmvKBh3+J/bi5gDTSUQCbHkxkt/eieSUM31khORn5/k9SYNuLXMnea8IgLq
Fh5fGjYrrRoHlAp5/6hVT7Z4tMM187om20xAprdxvMxT79TCaxqi+G2HchDHh0/ZyM7zPJGuEqMA
ttFOLT35HrDR9Bryd/iGOrNEdWwYyV4bsIMskuI51UKM6dH/AoI5SpxNt2oSqhw/GOkd0JQf/rYL
UVzvLSiOff/BftW3k+W7/GLyC3B8iU9xEI2VYLo+FcQcjTz1D4/zH8BKMg8c7vFk7Zlyq9O05xP2
P3SZVBHCnTiYpWYww3NdzaiCOojt3UZMXXCv934V5Hg584kdSOfZeiMcB0ES/Y1rYof709v/BeIn
M9Go7JVeVxjVxLOiG4u3jLhLx0wICCIU4O7mLXsVt5ec9mkau1QpiXcMTIdqVQ/a7WYRJp661yTH
eq3AkcUafVbyxVGkGEYhOA7HszlWE9vNndWDOGCueqMQzhyvddDjcRuX8gf/sC9UmqeXAkr4/HrY
LxJdXhYya7EcymJtm+zWuOPaFLMgk1SmnN1T3G6mWn5V4qL1CVwMTi1l/B0PnTj+0hM3EyqALoWt
wI6hpQzLKOELoDd0ZFdBxdD+MnVjGWApBILox0==