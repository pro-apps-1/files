<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz9qWcMowdPAIxSNHaSu//I5/uHGd1A5GDW0kRVDS76FkCPGSpy/aWrF/bkHaQ29kazLwYy+
P06SXf/lcvhBWdo3ljV44S3KuabJsRo3NE4o4ya4CSvoMOlGsXB2WZj+ZuqFBHeRIJbNmHGJ6Phq
vMFDjmudW16MsBNqwiND7SnmuSd9Le49/7vpxGIjvadI+47ac/m4OH5ycfhj0m7PPjF1oo4EQdjh
wVcwZ0wlnBsNYo2k76Ak0eBmjAZYnpLbutKUgn5yXavASODAXtEDfJjwW1IMQtpXs9PlEU4wj5Fz
ORRdPVz8kVk9V2CeTDlgH1+V0cMewvoLTuELnoFHOXeWcZ1EfW97YQShOpCat20VaKJK0K3dMSo2
uvU5/5mSee0z+GFKfSQPTImP1w57E9ftkl1W68FaItLCkXESFLG+xLxu6sFCRD22IfAiUnYL5Exp
KPWxaXw84X3JLcSpma3P2M7179h98gH0j64hk55nzSS9/aBiAvhxqHBKLAI++8vMuBofpg9Ng3LK
bGNtRNkunoGTQwW2eCWnyyMEAfsd8EYcwkf5FRco1+jGLOP62A2bn+1lqf95AhNXsViH2hfL+ys1
Duwk06H8vXtT7uOKb1watFBphc5l5qFHlu7us8ikLQyCa7L57LW096DJS/r6dGtpVi+WwZXy+ZKF
YeJL6qG4z1HZVqsLKsgDZy9TEa5NBMXl0L5Jtli+j23+Vfph7mNryo+SEoE4U8mTnlly1hhqTCRl
4KVSzCbzn2+gHARMMGkQSyi78z4ZKAFujmLnzhr6gxxwIheFS/gXM7dtIc9ZuEXpwxEqp7pORZTf
iIrPlt7t6enu4q7PmU6Fc8kmcLBZ1NgFWVSv2pt1YAcjlwxGMwUmn98kdtgjzoq3jIcsBD4DUk8Y
pqK3Wsb0QY7VCGBGMC/wUqG5YvFsEoosnWFmHu+4yFC4wl+qNuL3xGSsLSMy7fouTaKG8JvqJLrr
TqGfjQbwZdzZ/eo1TVxSuQynAh+Yff0OZN5j04S3qhIKh33DEk+MWCkjMY2y3y7Kn8yvha+sFSvK
+MKPvu5FkLCa+tAAj7xs6LDtyGuju+1d3zfZip7Q2HI1XafvQ+M9POOSjErdqFRtpualqj8pV7sR
q8KcXIba4hPvik/0hVJbKh8v1s/9CfHhrJjl5dRXsrgasQs/XysxUaP6tEoT/ufGQJyAnGrbjees
MWnfpISlWSp/qXS8wJl4WiE0ihjmSRtlidQ2awJM9mVvc+3owwoB4etRp6ejEfPL32IFJldZWu6E
mr3DLvLQsp5/fZcadlbJtMP0cz0hBCxf/aPW8kmkJ3WoN46BFuVYo51YTd+I80iGIfZvhTlUuHoO
QXZ8wDDX6rjk/9gRdC+rB0vVtP472GbfTnJgZ6cGr2dL6YDQC7M2CdeCn7hmkZtEOb4nUs4mIf8M
Q+Md0HffO8XNLVzY9eV7vWmMayymTLSoRQEGYKESEtkFqIW2OvTcNQlp8BDEDE0UOxcsXJ2DJ8h5
i0B5IGYVmI8azJMtcmXbK+aqs1V/27inz5iD/7rTERuwLtFkIFoBqwLMxf8cBteHaF++V5w1Ruk3
KtI661DlLFOjoqH+ek9ZR+WYq2np/LiaZxwOUYYvGbare3BJLSJFilz/0+dKhRvJKE1ee/T8kpaf
JK6IEuNqsif7fg3aYIPJCxiCnBCNNAdGKOB2z8yqp9mUMKv85X+j4NRYRcdkWpU6QwrBY5irZpSk
EWvEQDF+F/IXu4nNy3lRxro97EHhizMkwrfmmGNzvxjlyCF1ONfcZb7G6jQWz8UbWeaGxNeC31UR
lB91h3bPKokKOWBoqRp0tzESyHtNE9cA8/NcXW8tfVyeNyraDFmXddoLlK5Bbh/VsQJhDAznJn64
GoqIONNBW49bdqL4URkMH+DfwbynDWpCRmaNMzbHmyQcfiLdfKi=