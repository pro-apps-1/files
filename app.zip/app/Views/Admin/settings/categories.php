<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+L3GmzW4hWWVO3MB2iMGt8+c7ajb6XsK92ujB3Q3odpaTs5uDA3feytvEuVe2i90CwzZ7Tt
d1yH2V6O3SnJIkhIQGDXYRWJzMOTc6u5Deb74qjPtvyYHIFM5QpGybDyZWVLShtnpu/tvVGDp6Sc
dG8kTLRWpH/4/gnkNqPD7gqjnOmk4lYVo+zlOs+ibMPCD5+03v0GaBOFvGbjVIaWgvFJaHS2s95b
ljOMVcRUNVT6FyLgfR9wG0j1RkVDefS++3kkCEF1x2Mp38X0OBGOBrINoHraBwblWotx11D20/71
w7Hjq6CNSMvD/5Wu7H3GlgfRcZPDpL5JihmrWfGZvq1oOMLrkKJiqhLb78K17ti2Iz0UwRI9JXrY
HVoBuSsEg0jRAeqMHcpqtBK49Fhpl61yzfM7SgKLIJer66fhipYg3P2FlhAnLfKja7SIleBABNQ4
KMvlxVF/+8tV+5pW0wDxpkEQ2VjH28PnU32b+KNvsEJeyAFGdgxbyPxIuK9PMpywwtIkxar/bsSY
Tvl5vMe1wjrBJnEHlW6gqKFeSspUUywGStXX/fIo/77OvpwCYJ7OzgcDdomkQ38z5VS5K6QvzZig
TQuEGv/DJFa3x09Vjl0gvR6CrwKq4f+qgpW76Wn3HTgLR0V/us4ZFwYqqXMyFv/TQNfTB2InENNb
CuYGsctJKc1456hhUlJ4bVo8831DcLWvAsfW7xWsvDO/DMv0KsSh0BToDTlOSZ6hqDwfydMSC5+A
2m1OCo8+mpxDllD4GQF18F1RYBdqBsYMZbOP1TzKU/qBRaoPFV7r7Xy5mIECUjnRpb4M9dQKoVPT
qtRUGNLUwnoqBKCpxwyvRKV3Jbwa3ye/5LfZjWsZjZgN2gA83uaqSZGe9mNiIMcizI+g5ahiFX+s
tYXqKezZXU5oOMuVUjqfeu1vh6S5ZVeBKlEI57oOb0dHT58TWq+b4FPzDTAjVlbdlR5Feid7QYWJ
MFlBdjXZ7LGYEACHOWw1hrc4Uojr4bGSjslkndeQR7u2iwrSyk6oECllSK8Smd8My0knTLhulm4G
Ze8YZsj8AdXAWIzNG9jEzbXUCCnRhzpNdFzLK0zsYiVWwKETGq2gnpftsTp9G7nlD9FZHGvWcU/3
3RzxMsW5O/T1U5EDjO8qeshZImCSEXvmG6JMoE9ZBWUCWzyx/btKXdB9lbmTIKgvo5DXwfNxZ8mQ
fgpCftVE63i5jdNUxs9sEl3iqHWa3e56kvl2qhldHr+uZDFD6d0ft49PySqzVtj64L28mi4v1qhK
qSSP6MAbEkRr9fMLkBtwX9MAVjYaYxq6XzjEX8TfXyQMCnbTo5ni/zyHXO+Ihl0X5DgHwlLDTIy5
lovyoKSlXRsgwPjNKQy3HSALdWyxDwWbuyDC2EVWQXpOYcKaY+9stRnSw/CSyZfp7tkN19oTZg1v
TknXTg41201/KoDlSH9cTkm5UMHMwHV8+Fy6NSAaeDmLXnucwFdXAtmwgs2BPGZuLjijpcfCHI5S
oq9qGkfiHKNzO2t6ng0fvMdQc0IjPC8MHMeGQM2iE69b51jMuuOMrvzPy4h2DOLuZH1rs/vhVlh8
DfaN35JvHJRLAhi28u02MI0lHbMXCr12tP1jGHRzGXx3RA/M4G2dKFJXmz64H53p/v+/p/WQO0mf
KPIJgH1WaPk/x1i/a2c6Xu5BREM4nVvaR737V2mFJaeTausYJN5PXFwgnGKo9zvXodqL+1T1DoNz
fD+sSGnPHu5jgyxYeadS9A7IcteTV9U9ike5O7QDoDkVs9YG8X9z/XN63ctj1+TgPqfoNgUmlANW
orTFapTYKIe+BjmE8SqJ3a7+JCUZAIX4YS8kvyPlAA9m6NsxMzlcnjQmJtC7YHFArt0oYvi11Dcf
J4bB42hLOn7E+ioWzL+j4sTTYfReqxJZ2GSSGNGUmbstk5OwXW==