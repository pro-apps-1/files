<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo9Yur1GyjTdBQ1sS/Y+gGjkVbbuqHps3OYuQxdPhoDcLepKkdJEnqglpzhS52/K5RG+BcXq
+n4iID/FbQKHHlvve0a83kE/NZkOZTr+zKq/YZ5IDPKkYaYmk4We9SGVM8IzDVz3LcvtFQ3ul/aP
WCnv9lngcH+Xtx1P5RUSQK3N6TzBVD3f/Njsj2y0T2xmBpHkMKQtQ7bFiHLxqIMne7VKWzcSzGQM
ifCBNSkI64aJVMqS/k6YPh2Ijl5jpU98oDD09+6KJ9tsl3a8lfHDjYU7lbPgAe7cB9qzmD6XEOvp
n+W3GxqTLd+0M28WRj1gSlEx634jCOSEQRvfPN0swl/+WNUVLtaT9IKNLj7byd1Tb0zk2kgVX/zg
wroDVt0H3dQ6J7u1kkA3TtDhMwhcyc9Z+iv1AJKYdPCqww2dZ518Y9MTy4a9RfLrxf094JZ04im/
7KclSipaLQN6/lFl9em5NRcusqiTLHoJfH970nBd2PbEOHGRJEwVlmgbwL8b7DStIfvVWESVEwyE
MbROfAgqv48VUBQJLYnFVXjNTI4O5T7YJ3/VH9UJtuSlu1GKRbbM/UD8KctY8xfSzS0g+3SV3hOb
xw58YxrlZ7O4t2L+qD5woE/44FuNHZuD3ob17YVnank/Qelix7H84dkCEwdvkvKZH3ZE/fQJEdE0
G2nzU3U4+wL6GoRtiOFDAO5mtn15vbHBWho2m9spz/QRaWvx43wbucsuYJP5YqsdzgMAqIjlb8Xb
jkkL5t8wtA4hprmzRFFuxgRnAlkPX7YMcz7HL3yl9rEgSbolxE1/gBFYpHOfzE9GDfD5+Kzd5TEy
CS4GZi1tDovPesUcfxCv7CnL54/K1E7hCL3AjLbbuoeMxxgo9eUo3vObPBoBUEdcNU0+Uz3EcGIz
0o7MlgMp1MYTrK6MnMdAN6WUurcYqS+byDH9eoSQUPDGoNUwxKFCL5BSV97808gwh3JeqI4uFHKa
fUposYJbN2STFK1XNZNXg8esZx2abHYRMwJOPEAXbx3Rjm/Gd6raWK0MbqJx0fTSq4usYsif4mCw
lUXpCSWV0jl1G9wU6JljAzIP6td6lj+xNYskz1As9ar6AY7LfXKRMwEWU0HgvC1DaIxlixG7OEM7
Mx3cUDCksHqEQn/5YCnk49cJV8tD39i+4FNfhcgcDftrzStxnO3HRZ8mKOXprfe4woA1dzovC9rp
ZKgJypCzBWk3L/11In/u3W7RhhkmLGOcPUZUJQD/KjABSBHsG6mFnsenv04imJqjiuWPcIR7+p+i
LzOrQRGSx0o5+Kb3zPJOnr9J89eDVa7g3ns6/8ILTK69Q09zWL1buw97nmHtrt80KabWn16ALPSh
GAoREG2Y7EbTBqkcG8Xu8h8eJ0/KQdXX5IFOumycjPnlL9XAvf/idhR6ElwmrJs9qdAuaKAnZEMl
TEOIJay3yyVwVTKKN+C0J620W4L92/GRwRfnI22ttxfBM+dSdCpy7qNUeMfEFR+2+2pqZzaFWfa0
zAc2lSVO9anfyWoMPbsyQ5xHDbcvVO+wDOkawKvheYxF0rFLs8MbEs9zhoRMCLi8afKsfxXh6kWl
7f6se2d9tyxl+BJNrIR9dBUWmDafTNlis444ZStWvZcQPtW0PJJxo+mnpKSnM2yX4n7RT7uUSW3s
kl5tMx8Br5TgbNLHKTc+oGRJLCilmywvSmax1n3rfSasFHrVU/sRXsmK+C54uDMM40p18vlhyxLg
MZFWrqVsTv8Tic3QpaxhDrk/crPxszAQn8uADFsvhoN1fG==