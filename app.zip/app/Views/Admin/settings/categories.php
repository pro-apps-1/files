<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw5Ir9tM0YtIhv11lWyieKXQGl19NSCxTxkulr3UGj7BsToiUMJXgz2UdO96TkrjVB95VWDh
6edR+uVH65EH8shI8t1NOSx/Gp1C1N2j13OeSHyhNgZ8CMF4z0/taKBAZDDwTAg13Q+P5eEQV0S4
L1lRjcpkrQEslBqz6u/eJZ+0LFvvV//+OD+kpRuDMoo1jjcsvs1S9hOoawyfwLh57fk7r8zmHmpO
LAnwEl+LkI6erAdjyuYBEbhFHOxyCoK2JsAM7xeLASVpR/ki6MzQ9EJRHJjh6YjNE2OqW6c6XUmZ
v6OxB/VXH2diCVcqQCkQW7Fa5wChZGhysP7p2onM4q/eEwSarekCM2QyOni3mtrBY+tccoS92S3Y
7kjNIN/NCecuQyM1T6KAlamfJTbPJ6jnwEJfBCaLdID9btlWuEDhCwPY5K7hfzm2gONWYTRqeO/m
/4nLGTpXSA/4vtEUIAMvHJfL3O/MM6ivwoNOogFtTSNAc8TXb2jf99FIOnV3asJ7sO6oM+SxV0Om
7bDpiZGnLjiwmdHIL/ujZCw8YXbTTYK4dNJGpQoAhc/DTkDR9Hw8BkXIIGX9QnAO00AQTvu5u9TZ
Zy50j1XOOkDeG2RbclPBaFZEQ+4fLBbVjxeWz0RIQplKEEUPwpiA6Ou5w+w7ruZs+vjJBVIb/PI9
jFhRufcWZm/NZqWq5eic7/It4/Cb0ePRZggfyQW89FZQa3uzzt2GoMJGkA1gQda3sxBhSfA/yHIL
jRiZpMM6I/fccMXwsXX4Mwj22WPtTYVgRk3/X1SP83+dFMSXFolmKhXvYA3PixltnwH/8J+DuWiS
4osMnhZ65aSTWvjAyk/3SLj3RM5myfJSzEKs/RH1IVaCK6cM/Do3xVA8BTnxAM/tHChYRCeUVkXj
uufZ46ZNm1d0xCQEVGmGdX46pzfGrlvtjyo+HS+sUX8k0G8dveEiyFNwmbG1VPmC5+hLSEBK2Y2P
q4R0DeszL5yX/HmROElOK/jN854aqEV3VaB2lx01V9AeqQldB0l+8DCHG3bRvkezySZ+hoj7W+ko
/sv06bwmKVm9VZiYNUuJTMEg55FBUlf/kEn+LSf+gF1iRWKkUbBq9goyzTRpi30wD5aeqjkWREtQ
W2SjkX6/DvhLa1cLAtSNf9LDeluEhIZHIr6kLqwI0B7uT/QIJ7RfUwMuDhbXrO5cn0ic6rJd0WJo
2ec8SOpvhc7BxFqkeS/TOi6N7kx8mgYT138cby73tT/PKzVHzbbBYHfCFpQx0xp1KdGLFbcfYWSg
oNTBmOCM+gwsd7vRO3+AilDNskfQW2qx4oAXCOLyOWm6uu6ittD6AZdegGOD+G21ih2BHuaXh+x3
nKPLiRXp+9Buy6IOqZBLIRfaxFo/5wVZaaydaRkVUABETY0sMIiiWtKPnHvJqKxw05zdkypa04P1
k+xMmXsF7/n9G2lhmgG0ydarLdzjQ3yI2cm2rE7ZwrNt/cbnE4525P+kZuJsSP3sDQjerZZjD1LU
8Dk4XnrDAJlz3nrwNKCQQ9wvJUiSNhGh5Fkg3qOKf7VZH3B4eYpQ36r8h9dOHQscsYHJpe5BfCCP
fKLvUDl1888Qu1Pnn7ZNfDJtftjNHyfYog53foOxSUI6lnU9gWV+ZGn2qtePa38plVEywNvDAxCc
XdfGVJeStgoMu8q/RmKA5KD30p90NEY7iU+NHiACFj0FFiQsMYjyB2shR9m48PzkWntmqHpzx1ky
a2vP8G0dgi3mKaSVuZ9QjQ9QFGrYfAazm/14lR0ZBa2N