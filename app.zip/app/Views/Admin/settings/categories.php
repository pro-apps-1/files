<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqGo6Nc8hU5+LV2CMhJ1qu7ySXNtQ7mveF2FsW+pBwRcxs/1DnSPX1YGgV2bc+dc/SJCfqJx
gUoFJxrgNvlqLsPLbyCKVdeM21VNLKDAdktBeyVM+8ZgGi4qrr/xWLXZHZ9oIkOn6h8x7vj27/av
hmTgHBtVVFExzmHrKMaNDDkzA257IyilLDwpP2xbS/4UE2T1XXxrcOqcvAyvaHwv+2ezx9edpheS
zT6ZA4bPrN1qiBBKJPLacfDIKlhbVLhpk1rJtVAnZnHPpE9J5mc4XV/W9lAcRX59bIJ3iWtJgAL5
zvDxS3cCIn9R1rTaQjb4GbH9iX3JU4rwv0Q1jKsNopeN1Hy/mtpSej8ArEmQbpTOGfKq6x1FmDtx
/RxtYosGRtWiAV6MrxaKBHGDMMlegLzIn2ZgRZ+m6DJH3hAtegzMMdXC538VCSy61/Fqhh6ONZIO
tp+EeG+5lK5tFdQnPjz+VWC9liy99df7Irkeqynq+P06kcc19amhSUYAOQlkmfuCMJMblpB5Y3Zq
syMaV0QtuJETndoym7y2vCwYG+kVUGGujSrBs4HyEbn8shSxW/++wJCDXg/Mee74mlY9GNAa34FV
XzKmiJA4vspGnzItbsZH8+I85pGb7Tt6eN12MrEU6jGYCQzMfRqT/ubVVyJ24C+iVuUmq1VQjnls
KuFxPO8epK6Ob+G3TjXg7d4zZvB5Tliz+H6FaqFLwsEiQkP7qkPLkIkCBWtxCZa/Ra8A2eMi4qbZ
V3Ifu9VrQp+bQ0oEy+sYovCU9E8UtWj2lZ9ISYHkH3/+HbBfda1tuEHWEoLA4r+B1RLx6vAP2/7V
8SZNvqDyzA7/Buab8s0UeuxSRE78y+WpJuBHCTJq3a/bf1pCuBe8hA9IWjNy/gqfIiRSwg+32Elj
V7UwZWdki0Tnks+it9HS9hXioo7XDDE80yNUyiKvxTq/CwSVtCEUCH/oaGt1NyUOstWlu2ZCULug
3Unrfill1tUbLWX71pD0mLrpUAAEbrxV/PkZ+5/WYcgZt1DZLaKOVRHqcqYjRApyAp1WDONED6rX
n5a665k2pbspCnH/UbFjafNC9/2xXk5WJb28J74b5du4oOsYnmX+1ibuehHqIttA+T+3fQ/tUQIK
0YNLJPBusNq7Zf7i3tA1hNv3mwRD5WOTCpVZ0qVvfSLB3gcbRwMthishvWVsmQFGMD1s1u9cHtSf
vOkvx+SV9o6LUhidjb59KGTyI1wIihC+gIm2EQ1DPHPxx5ZqWzXAgzKIL88pF/bURUc1BDsLfhS4
77CmbibqfLAza9Zx7wgFpNWUPd4bDEW7aNVaLs9+YiSRdN7x9nprczqx7zDKY8dgOl/979a3XJNW
O8ugGUEFkq9dPxYDPzcwG1kZaxUlCNawBeRRPGP2NAUNBqqnk1fXbYrsrH+XdN0U5LruoEh1VOmt
Fku+43vzFffe/kKOOjp7Z/5i3IGmXRORoNKHjL7t24VYL86rdTFTpWWUhwcBmJrCz/6WQGpvAzCN
jxMqIzJNyh+3W/TKGr5Mk6RT4cddBcCaH448EJYnR4xeYDeoCOk6d86S/yO+3hczjuo4cjskp5XI
KLQkcNdamH6EjSIXv4eM5lWWDxoKrBevjU7F4bRUpoXdyLH62vXnAUDiFH2f+VDgZRpfYr/CSnAi
SoglN7+1d8JUFk9GL9gJ/WQKWZzoExPY9l/KkV+Bc814km2+T6p+AeMsY1THYHPMu0uoy07ohxSq
ORtitKtBmjSdxjQyrNg9jmBZcFymOWWoLG6RiLqilvq=