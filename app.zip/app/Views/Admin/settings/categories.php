<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtKvdFAUbcJ5P/i9qVziWsqxmCq/zL1DLzjdcKfRef3qjx3vm+BtSyZWtdpqye3LvL/6EYUm
9AQ5xGq26IgnRQW9H02rlflaUVNs75orOIgOSjnu0YTD00odLKj87ZqkH3qHkW4RGMLNdOrq1/Gt
WGvRGeSe9IB3aAR73NrpiRUmRhnG7cSFovpj7TCads+cmgphSsKFR2CcEtbSWvKBlVPBv142LiFx
bnBvcToU5y1fSqTRtZCEsJFTPFH2GCTyiKby2rRsZL3HKx83E6zV6oB3CgfWPNK3LEiey7iUez11
cGn8ElyonegjHRRn3OP/IMjvZTPivxQvwhsO7/+UliPY142z77cPyQvKudkKXkeWRViRuPE44kyG
RU/R2z/a4cZh1qdgFyVaSu9U7usniMwNr3ecxE6UtT1PokyT9AdBfcrawTvVG1p5Y28H2I0WQGAM
PQ5dQbvvVrj7drDLkBg+l2XzOEafd5BBJWu0mk+yuIseACRAtTGKZz7490oz168HuR7JsXcV9j1e
DtLXr36YyQQM7gJ9MBv33yYYxq3cvpB91tOgEoPrxoSJkxg9krH/HhX9qlJ56rKQ8e/im5TfMNpo
O6CvgO5rpuRV0PpUaG9WsdE+6tZpWMbas2ZOAlQmsm45Xd3ztuT+m04iBayq4fh87NzHf7FZGWsl
VDyWj5Fwxf34oqVwtVuekvG4YLJ4gzHLpcJ1QlM4JtaVRu/1wzc+stBlK+qotP6PpdZW3UcDlmKj
AKVtdwKAG8alAl8nn/63fH1XClsQKXFsXTFNEiDWNGOU8oqLwwTzyRbnD0s2d6HE6hwyJwQJXJaM
U7FJsZxTlFOldSKd3u+1b7zPhp1DXu1ur4NYMfWhiyzl7RTacZa5FWR1Vgmzo348CdCO5U/Ufo5/
OFusMkd9xgoeAB3vHRTjmmQZLIlT+9bdJcD/LXZpjkL7G454zYWSQ0uAaguomSY5PKDfWnG2pWBG
EjMbv858FH5lJmhHDhYKda5qXR0CA42XP/kerWEnB8uBglxpx3SZaf5Ut7xlqGErL4JaG62GqGA5
sGogLl88t5078K7qb1B7SvOq2Fg+e0b2STM+NTCs+6F4j8QirinayPjf3Mb9Yk0iAbO9QXMsJvwf
ksFQEejVaLaVXNAhj5wo9aWgbFi6397rrEiXhaVm2LcEreMJcXlLycVBn/s6Zco9A5z6LcNnzn0B
ATLxjNlvbUSddERpUBh8gnkDzMNWHwoOlNJwKV4N3p3nKpbo6RG+bfxdKXSpA+W+Cw8OSzhsp0DZ
Sr27ALgLuhXiDG2vufghdhZyNJFnAhuJtpr/SNAV/2m9heArlYtE0YPFEV//y3xvfZ84asQXRrsp
lbkQbzIY24+tTkPe/bNN4sjlWbCg26GEDNVI3XW+Be+b4yAOi1NjDWsQJvUb7dBoT9tEYZNDx9xe
agYqBEKdDi0bxp5uDsF3ChZFLsHxgugcVPM3OYQLwcfZxIXZ/ZXMyD1sqnSxLtVN6A4wwp6tbrd3
+0/bZHQlEsWsfnDSOMomxTiDxIc/yi2zj5300GwlVr1AYMjludLlLUL0GWl8GmW8xHLGfd1aD3dO
juyAI3KUt9vEs7QOyTM9A+kbJlYgw3ezMOaod92ZxEVa4HWuJ2hgI5npWt0W0B2YL4e7TDShoIER
LiVw/F15lrUkSP5ntY165kvu3yyqiGmd5lA01KH1CvEjY0TGQck6pmWdnAIqShqgaQ4DT0xfEN6k
trMHrvFDwJgE+jV+PQ/kkWaLaMzkP+8ainieMva=