<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzK+byh9psljbDC2wGNjeGWDFxabPvqu2FPWN1hCD7a73o2tFJKNT6jParXaxZrDQvvM5+E4
E1G/zePPWuaJRZYyRyzmVwvxdDVsl6xTDJgbJsLy/kzr0TyvgVXBuM9ja06efOk4fqhXFMtK/vt8
RC/lA9SDq1ELzmn5m078dLMTrUJbviYNpsLae9957Xp+eer5VsSnlX0oq0S43AkyL2Cjs8iYgCTV
EDg7FoHvYuD8yzxPT1INwkAK3gV61Sok3tv7xa8muy7i9RCCY41Wj1WlL9V9FsZg+Md4MoRCsNLg
yK7eT3Tpk987w00k6SqdYh+Pn7DwSAF1qK1T8okQXL93ECRYgGfF3brNkRNbcmtfElTq+OIgIi5j
QuapTq2i2zA1+uorfCh2jSMAdQEw3LQcDi3bZOEBPLMz5H+N4e2GxtQEmG1KJBNh9DlVVT7l+IIq
djzCetxNyvVzPYStQvEPBNiMlr+gx4C5yYlZkg44ISAwo+gZhoObhz/uhZfb13KDh3U6LcHZHt0J
mtKSEtDVrTo9K/XHJeOhjACadjc7zUWcJCOUJiKOBDdYCSME9YrLWni3+yjw7bjhFxl4JWuhwynK
CATN2lRSuS63vJtyADHEufZ/Fh+LCA5Wsgf1y/l2aE8cXRrVIoZLN/z34TJV5FTt5vMv5pOmcQBB
6A9cbfcuC4XFZARnuuJxMP6V+FgWYlqfisXQQXb4KofJ6lvOfKrRrly7Gvz92kYTHKTluX+Ilmwt
8d0ZgxtnDaC0VXJbkz9kSoE3SoJOYlE953Xn+yi8ykLjc5rxJms6FZX+McoYj7lFlarBYAJ+yFuO
LDh88aRy4iUSf93JgFLn4ptSgRFzrWpHdo6ts+1P+J2PlpqXy/DsdAo3rUxL8k8JYjZjhsdELSeL
otIFQVbo+GnauyvoiRSdY3JcJba3G6mmz4Itq597xXN9EJ8bS11CT7PZLHgtkYA2uJAzfWgVmd0Y
kEgl0uCH0iW6lWKSCDeM9fxQkco/NpuXaARLA9jIoo44LJx/21DdRfn0vy3FE0IfCpPMvii9RBBe
H9XccvmI4SxU7LzAsmL5O84qkzWteNAuUK1TZndYVo+xqaE9s8dL2bklhNLfsj63k1zlPf0xL2uZ
4J+PTp7C6PAdp4TgsevuyZBUlmR1+mGl2UUDN1OShFlTygj9mvTUz0tKhHS8MCxtsnAE+1OSEYWk
w7xS+A8tYP8oZHNKvNvExcuTb62bq6htBIuKNM1TP05Fn0L21j+YRHBHVpXGWlIWVp+neehARPF/
+/JMonLVeuV9bdYQiXbnzmlRYYnSfpC+koBEC99QpE1SiENXOQJg8ch6R0XbNnEm1ST0YWQ/q1SI
UDw944oOurzie5VAFLXwMVEksA+DTaOrri3OQ38XwyWC7L9B3+sAmX+l+Mphj+GpfQ2vW5gTPQve
nn/2JEKh+BkjhiTfe7upqOlOzehI+kOlyXDqMqMNOvY881ze6+/mDui9B1YoJuBs4nUe+5V4cK7k
ECI3aPa9xTzetNW1jefy8C7UpnkKv0grO5DVjgv3gu2wSLq+e1f/AeYgsC8FvOk1QIaU4gA2273F
ekZia/T9e8RO0B33jwThDVVSjSohjlBOXAsV8GiZhTeGdFBKUSVc/breoyr0sNi0Wc36i6KioIra
8miCpiM5v0AB0LSC4PbO6PQsvcXnYhQOS8P/tydeThsLjhrUzTmOm/atOoWnH9j/MVRverF6EaWo
PF2t3gqH4/jXaLKTX7wGsH8dSMY+/XFvsNXgfrIaN9cTJYbt6bysEzalYYYkbRgIHlpXlnbwvy/l
FP4R8/YK8OzSiIZHjWdF4wCKLtd8Sj1Oj8CloQ87BCkUP74W8wOfARFOgmkl3v37ItZO8De3n6QQ
vJe/Ki3sM66m/wseBDtDLFDVtif5+LUC+ikf2D9IqpMMji5A/pZWcYK4nxXxc2IPJSQ/us2KkhwJ
PuI0vZ9+Vhe2TXbrH293NrGsrVgvIMOXOLW9DZOvez7ZoESZG63hD3X5x8TBp3Hf9XPtXEJMllGa
/o/QJVguNQA/dJBAYngOT80swB1sWF097GduGV/E5gFUAUKgJkb8BU5ua/VsALH0ZQU+bDqhojZq
r9i1TIK5aKG/Sjq7Jy9MrFF416B3RKvc3btxfus/TBimLxv4sKNpxu0JeBOVg12kg5CA3nYBQ3bL
HNvnQ2XeCTZ2e8SnU3UlJnMrAZcx3AsvZnqggha63t6454qoVYSBZk9PBfxi55YJ5tf/RcsfLhpy
V/N/bbyR98s5mShnGhAdnDy+YQCLtAXeQlE6Bcb7u04DlBYXU0aYKodvVz7uNQXdiRWZRrDqS5cB
KnDbBOqBNyRB1ySW0ioWf717y1N3/bzbMcRJDLd/Hdo1EZPuXfcyLDJ78bMtdCJ3BVZNAUtYXss4
//lUYJXNKMzbMH9CC8OvdfURNiYsI0UzB8HItpBWOnYR8eDaIpKh+uIALzWjIepcDbacBnwaiD5O
OB8CPd3fRCfT6QVsT6fO+yp63QS8/14iwxyoSofFpPHPPUjFlRLHcwWKhmjoJ2nej3IG6Vyqz8HQ
B/WDzVHzwtjiuhzPVPaoRuQI+Q+WA4EFyWkAeGGB45S4JX+GuqUTi4uPz9TR8blCbuNFr3rQjWa5
MKfjfkm7R/UdZpsbeDFyIfM4XJ/n7F0SxXchij1HLo7zBZKe1sQB+a/Zi+WBgkMMuYjNdr7uJJQQ
82ZBS6sve8Wp8yAJJTENX6ADruWEFItL28hgzGdHgMGONTL1Oyhj/tZmWDicrew3vibuBObWkb9B
Ko0LHDBT4wo9wqwDD1VAotm6d7+8qlwtEt4UVG3YPIlYshnVKvwnCmj/T68m8rMAQUnnBRCx8xGr
qz6QmzBqdzpo354iJRNmgRt/7AUVdLa2pD0J+XVVFx/dOR3PT3DsFrXCvud10rY/I90F+yBU7Cjw
L+FbYxXF4jSxSXW7RKPs+9TTXeBjMyveJUIsrLTeZxC8S1IIqvZMRfdBxEF2CZhWhswqH5PVfZKS
hwE+VvA+SG74wOKAYP1jcxY6gsazsmEo9zfqflNej10t/pcZ1Mngf9cqPw5g+TVVgjHwGI/NZJAF
iRSgAz6yMofCqjZVN4fmxC3/qUeUseyhpLMWxCZaiekvOEQ+HzsMrVOIx7nsK3j0+BzG74X6WQSz
TW2AQlg4ZgigKKqW8u48DVjUttzfZRNMjkVP6Ye3mgV5DUNmjA5Cl/72nygSC7Tj0MhVdhV+iJ3h
8mxE9XKpetqhAhJe70NTZ58UABxahnt0SjgTQO+dQbmaRhzN2mIsYn6e62uVq9rP8QcvYXqZz6HC
Clveo8LurjO9QSgt8b0SS3cxNbUxmIFyniV+Xd0k52Rvf+gvC3rzzCOwyuTxUpquvDg0m2gCV/OZ
i85nNcFF9iyQk3jApRB7snWcYa+AdPPAUCNyRO49ZN0xyFl8oc2KxGRKTioj3YryREFJl+/r9L4K
XnAbFLucciF92e/Z2XZExezYWtWkAC0jQNUE6wOPqddFaKCIMbFfFJfcQqYqlKRuZqChUG2AKwgx
QvUkXnwiECaZzbHBoLrsPlCs+Hv60XgBMcHC+kXEwGblHORTq1lk6Qmh8W3tx1LMbNkhb50qzxuu
uFtwFbiocR/WIsw6yw1Gxxsssr3OIR22/CkdM+At+jIqPq77RB8wYgkcWzGvBsrIdQEd22wq/s1f
J83OB9ceqzqr3mb1h67uNDTCC8jl6qgvw7+jSDKm0oojPE5MOVwxB1R7xIwDfEsM+BHtKBoG0qkp
rfjwmd7+E01y8KpCcgZEU4NMWht4jOCqkN3iYZd37v5CB2534ZikoC3+0pyh64FCtlzpUL61E6iS
3Udqc6DEDRzck6MJoAz1fARUtl7igqQUEavbDZyC5PfgzybIJxHFvZHQH8wrMVOoWQ4//IDW8qK0
nX6EAOM4ShrTBkxF+LigZ32laZ7k7tFUnKqnJeeXB+Jf9YNAmO6qV6CpYtNtXjqUTtiMCAvG94q2
8TPpr3vcwAV4CInh6XIwVPa1kNv0tUu+FqlG1+NFAoolA/4qxodskiSUwlTGdKEG34Md4Bx3sbUo
3HM4ahlBwO7vVyVPEEN+0EEtCI/aUCjTcBRSmyrTc1vlgV7V2TapWtspwck4P+CmROH/iLchN7G8
kVQAW5g1fSY86rPhLq4Tz74Qg7bQq2pVYNAKOFQ8pfuKfMdRDiXL4N6G/5LIMLv3O95568drBk2f
ZOZQtni48vI0cosnxonMqb1AAer3Dy57pGEdGjno7IbGPnZ9yMo1HcTXYx1pv13ZqvWYcvDdSglN
5zOqI0es2MN2WXpFgvO3RaJug49NPNeLWER6IEnI//9Lv7tby8ybdvC3Dot0SaoxTc28FOsHvsUj
QbIKyUDeArGLeRd/woMdIW1Lh2RB4btFP+rVRJvfFPuH85Ppk+wYIZW7jnZV3ABxkBMRlF3hmBsU
Wg71VQkzlcvoKHwJFtYBuO4RlpauHz7qV4i60/N0P1UA34w0euK67C57hbnULSC0EHRd9kd9N/Jg
vk7Ox/iXnXHUuqfC0adY07vLh0avuE3yuZxVsFijSMWMlztpoNgZw/mUpgnnt9xeVEV9w/SLz0DU
PWbroGO5XRwpX+2zWnJdGAcaNAG4hiBrkDFOFnHygpJeuyJS+ugs+NcYMUlisjlZCFfs7Sh8UuSm
UqV6RymX9qX9DlCnRDWenzYZQOjLK7kPbeYy8LBwvTPXtez3H4KewHW6CKRwLRrTiTx+BR5V7TBE
xI/reRn+1KNaYj9Xm+OI+4jKO1faMpFmLqO8/+M92Fagqs3HBXdEotf4Fxu2WoEf47H0KuXZgGvX
qn+60tZPIzdjUncZdiUaAIkJg1m8Du7tRyWIoGPApqEBtEKdPSW0wVkQ0HjuYtSQgezyNM8v9mxh
jYl1vuHz7HAPkAa37WkjRoTdDNo9Qq+RcQqMnsQT3SyoojtdguKUjfBR+TBU+ZMJIAWuvCeGiVJy
mr1sb6m5qu6XKbUl55rIHke8qgHlKf9s7KRitMVdEZgLUXYg8eQn0vXLrpR292Z+1uA3pw2uxG2+
wTxihKjrxgE3JXuTs8foT9D+lbv0XI5rm2E1BeIc4n9c3XWSe4RyBvtXyNpPkuZgJ4SugikGfv/r
QFwH5X99c5bCIXzts792bfvjG+SbGIIBFOeY3pHT8WujZo07IcWb7Zf0zQf+V+IQYEBbEM1FCWBM
NQ5U4iITYumQBRUXPcPKxPMOYd3Z1LGIoOMTwlw/QOE8TqBqVP5l1lS7lUM2E7j0pFPEb6Tob+qf
WQ3ii9ngWe5I7A7QZq6N/OTHuBiS+tQYxUDsaB8jhmjEqV7VYu7trXjB6cYpeNNj5zPtRnvo/Usd
/2w5z9AXmjf8EI2jRWVao4zDlDkazKcRYxc82tgj2H2MpBVeLY69rKK6il5OLY04HV9rY15yxeW4
QzEQsq4lY6UQJShMp8DUAvPtEhRHfhD3/zED5RmU6jqEmgt7lSkWSr9blwlvrEr/vdOcCTSQidQV
c2EdRci/Bae2qEj7wrasFVKoFwn02l4olT3UXs3iHiUxK0yKCCY/ePM4BnBILdLLmUwoEwiC/+SI
MBh8Vu5khzG4aFXEDwi2503QB5oJIkjZ2IzoNpZhCjM97FyFfc3rALo0wU4fmFIc5S4YJJPH3Uxk
Vx8ozPY/UGwOrfEaC/2P9ABQnroHka/bt+lH6xYJgk6MINRN+yuMqg/y4jqdKHFhuXo6dykCmiYw
juqDDOc38e9whqVeKxOnu/aN5ww232Nn0T2hTxZE06cb9qlwAcNACnl3gaplbJK8sNZcfc4KzFlS
TT5T/rKvalp319UzsT8Wyb+1K2ncf56wI9f/sG9IchkPthyLVo5j2fVXvIf3uxgAJtiSEGNavwZN
gGwXMEySjlLzhvViIWYePFZINm/DVl22Rx7s/kdpGyGHGFm7FIDJuSO9lrQUk/J0uh3CaICnBq/l
dkXYgjL3TjdxZ1nrIJzmW6LZQ+zpLV38i5GLqqSXnoa1iOon5xrXd7atYx9cIM1rvJ5NTa+xbVn3
RkNHZc/U6mHh+VM1bvFii1p5c7mlBzmj6DKw6x2LfbOkGNcyqug5K/73tbGgxUj8xQl97lZAOcpM
TNSvzVIGmao8jKAqNuYGVVosR+lSu9RnHGhJE3HCZM8pVCSD8P3zYiQdeOamiGEMDpLvndLKZI+L
PYfybtvP5lO3JY1wm75rRisVdZjbo0njVTSdSb9baK3RvRBPjp1LiumV/rhfJmdzs1jmvP1wW4vA
SqYcbexLnTJl0Wn+M1EAeCzXPGfrMR2ftqnQh/Cki5J0NwF48ObYKY+Os+3ZYqibEWQFgoRLQvYj
VFSY8n3Nwivllis1LL1k05WNHlUIhkY+CzrHqkgdpOla2AfeWUTWGc8hUTP9kvbLVJdfbqrY9Fuv
UPemNFvsvlocJaK4qQffsf+MBlA1GIKzAKrEj2rMy4XUX9DS/8G4mGRRxcQOE24bCmGzERF7WLc9
rY+ne5x9y9ssRzzc/+j7GIYGJ4PztZhdXN4HL2zpDvF+RkAZHG44sdJgS4X4ERsljh18Ni4SiaAz
iayuKOCT29KTnqmKwE0qgsFfd8FtgrHYsBrlnJfpL1I20KRdXfG+o5clTqiqRr1s6dT5RjFrZ1ge
2FTUBc1LyN4W1wlAMzVsyw7L4pRkT09b1u96J8reHQB6XmTNH+rKXSyTB8jsfVEltj2V7ayoTBM3
T48hYPgkC7/R3A5uLF4OUxoX9sRPPOFRLfo5nSyAfvBQ6qWnyYRF9OapTuOjKrRJy4+/AjRMPD0C
hhioKxuKFihX4QRV4b/ml7zIdTYW1+fIxm1Gs4aZvz56XjpD2ZJf2XA20hy1++/R6hMHcIFnoSDv
Uy+99tK08jNCr2jFASXP+IfqgDNyirE8o6FV/aReWZuO5dlagfcHT1FfFm9VWiS161UxDKaGWj2K
99vZLQqTZu2H60s14Cl3TxBGqk7zsL8amELUlSNLC3l4nqmiaG3Kueme5x+j2T84Z0cQcRhuJP6s
dvAbMNocrayusJ3ILW7bPX8B4qBv7gU/gPmbFdNpg8zAVUuB5V7BbbeTq4L306OD8rsBsUvazDfY
FmBWAIU1gfTxjOto/fj0H0JHcE3+qEIWPaC5E9+YcUG7M6HYx1sJwqkGw+U107Fg8W1iUG73MIxZ
qoWDYksVkUvH9H1JdOkB3Vz4O9TP+6LzETbznc2fbdS6rM3aIGhoGZ40JJhEBUipZtD8+VjJL+dF
BywTL1zBL/Ixac/fyW7KWiGask+bCM6kyqXeBCF08WWNHZcSZ8vBWaNjkxD5VoJigEIycOTUUI4/
LEmNDd284R3fBvT1bgGgLuYzAnEkCM4MtVcmsxpHAtu75bxl/TT4lLlukY9s69DFNyMU2bjnzi+h
pmAeYzZi5YVzrkhMnBtMvbwKKzGT7DXeKU9tApimFSGX6S+IaKukgJ39xvoJ+9MFxaK03tGnN1It
x2dYXvTn+s0sL7vu2P4fplvdhN5jVFfIpo/efGGJ5fJk7w/WCF8wkLkxEPeYVN57S8s5WhiQxFNR
/EmXBpXGPUrIRb1ZvbRZTdIA35oBZiUfdbs4LJ719gX+C8pZi8Qlnz9GsFuEz5RC9yKiWmOZRa4O
74uQ19oF/JS5zoy1Oe9ts2smCeNeJV3aQINRDmGQpfnctg6AFYXhwRCbwJVSNyyYwBbG5fmXLRvh
Wgua9yUkWeWSEtlsU2iTwt9ZY1uJ5W9veG3uILjosfQQZe34i3Qnl8LrAOIgTrcytHRsQhm2Gi5D
vmm7XSndwnXBWL9ii2ZNB5hDd2IeNeLUXZBcMlrkB4F/FxudXHztDbKF22LsBB0EcBFd/XIJHIZF
UvQPSFx+t0Aq63rtA2oWX2c4P87kz4ZAPJ3jOnyFkP6MbWQLPluHvulGkWGNLtEoBLf2O7CGo+H9
1TsZnrRKy4q69xaY+qOtO1ZRqvPzOvclaKyCwuEQDFETX0AnMxs9tm3mWotlcjkfETH2t7daZbyo
PocN/gtoCrWP1JRj4iu41YUZgudKYomYx/7i5Gk/uQgJ1SWSSi0YyeU8t6t4lYMv4IvlKEfcFdAs
bD5r35Tui23d5sQU6Y8RPlAcL4hZMXVQ+1GYBqU+84anTEejmZ8qpvlLl4/zv9wI/aUtAcJw3Qxb
fOdp