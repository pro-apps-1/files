<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoT7/KoPvyLZPAfeRuSlY8J1wioXg46sEQouqAZr2vKQFlegBFOJl3LhPcWSPAOTidlF7Mm9
SlogsRQ30Sv8lHbyUQbltxkPcSFtLew6kAA2B93NhqHN74Nf5O+MWvI/YR+NlgQ3zrtPB/RAg8i5
AERqzuDTBnaqry3FcT43sUIDqEMS0WzqXdKBKwT/32QZmkUxPR7/VtjWJ3sKTEfmDX8pi6pNWIOP
e9ziS3vTkoAnYicDZUSbpPar8etHH0deqgnIw+bf5rxjsEZ1L4EK3FLilJzkIMt2SA7og+wrCTWM
CpKG/qhIBo6d9jDF0LDjEprnusXc6H9ZTvzoULNFGpjN5/FTT5wlza0M1rvnrljvXhRXFPLfm4P7
gjFwHhIecwducGby0ehL8DP8jVFY445p3HOBKU6GBXrf5TrgXDSSh7+bhrsWY4RA3mpbLEXhPddL
zktjzCIPI1Mhd91nlkgRuLwbxMjuO1SgthvmE4MtHN2jOFAHJri0EKDN4fkQSYVXBj3i2Nwobn3V
ywG6PK311fsuPXAMclKzihlMzYcMJNwOAIA4WHr4cu0vnbjbwD5n7wtz8cYR35jMsKZF8Avpskc0
JkJPQFEZMSVRjNzN2DD7qyGI2zCNWVk3vrJ//o/K+6l/YW2zIhPFdTJkZRhc8g8VPn8nMQt19ZOd
00HUZV8jUSnVkyhWNYSXIDe0S/8Zr1w9pGpc4puTx2bJBET00aeEEFVnbb7wismbfznE2Tw8GSnu
lN4amvA/zgz31jyBoccqyE9BhGrmIiRs1A7PSVQjw7I3GdlevkwwtPKXaN9VsUp/XFptTs2IMi6l
JL6v9MkXcGY5SCnwaCHxsqpQv3+rNX/+a/BtY6NSGwXofLeHg0S2udEu91Y6parwLjAI8omplsCU
pyI3gFJlaeCga0fcnJU5LQL+fD9Ag49q1KN69pYK7hEjyPJUWWFXI6PaeaL17Rm2FHY5l0SB1Dp3
o4tt9eTnXnA8DFpJtkUqzefzpXn5Yn0zKUZ7AKvkMxClDbX7SMcCJ+DBbzxAlH8zFuBzpPxty1Ju
8MVQJAUlv551fWvdX5v75O4uQODVsM714LdKYkADkto+a0mwgiW5r7XkeEMBFsy7zy1UR4b9Q1Ol
3MX4pYpaxqiho9gdbpGDQ87cNGwYBxBbsK+6m1Dtx6iamuyfWqDoZ3DBalMhJXpxwZUKR7vrBBOA
KKtjUWouYuLbgUdPQCWG6w1m1YgYIrqAdi4i+eaOpra5HBNnE2vLWszpDK8nt7mdKYGOcy5Hhieb
IuK4a+dz+g+ZIFyGXdU5S+A496Wj23TAudGiTlsAAQ428OXrIlEbYK++IaWi3JWEuCaCZPVCkOGf
SEeluNunznsZwvxvngHCyizyls4a52qBLdzkafHTsZw6RWIqv2TOhOJY6zDAe0GEbGj5yLmcbTy1
j6XT+eCWwXAGC2saDE2dsdvSNnPo8RC3Qbm78LHFkUiBl4+oquu/tM/u/h6eyxbcvdZ76o2izbO7
MTvIyHlNSiPX/wTTuOh5uLLsuU5tM1rxPJd0CXF7gkZGAu7WLqvivEDA4ZHmdT2pBmsklNZ7iKUe
AIugjrfFsTf55JllP5Kr2C/3FPrRQbJZPQ9lQdnrhV+s9yfhOdf37WZrHloGyXjRGWSsnhOMXSI0
vj09MYf9pv/cCnx/TZkWRKKwkPpvwI1kUHKjXZA6MFJWk4r/cblt3+fq4n7m40XMs4dDrmx/H2Sj
/iOWvbcf02Lw80hlG8TcRedFo2WpcU35FrBZvzruUdRZUx5AweZJvlwr5fy4NXYRnF/+FivPjp8F
48GoenIef0p7kdFY21SDUsCL1LMzm67VCLbdVgI4CRCi0DtGR7rDdk4insZpCfPgVlktXUU18wC1
t8nZaC7zUEbFNHWfI5I0oCwPe2Vg0PQasz3U9vr9WeF0jOt9tdqWlvH1mibEmQMMtWR4zEsnFVWh
yECgFfW5Oll++pHsFfS76VePsJL/0jABIU6bZmdUBDCMSwQMJEmeCVzkhqJDgngdCbc5V5/JaGAa
JD2Qr6MICqNAXDMO2OmYcFLcccrYm0EgDeA53w0BRT2SmPRGawBIPBtDIw/mOHpXQN2tJfy/hFDS
EG3dHQMAqV+5Ms2YSQpkv0HjXGQ0y9y7DgiZWDzv86/1rUSLBG9jbPX4EhHMSeR3wbNmw7twVWzz
ri6pZL7gTCLdWxq52vSEl/xo39w8pGEzSGMB0zwsmgEsMGd3e9/+hLsjhwmwK2Yax+T3PsASHbGg
na0JY24gsTRf6qK6x5RBRjosgrWYljLc++4FoYe92q7M7qJEijzbz5y4ap6tl255OAOsktrdke/X
ZmA83ogbKMjccge04MrxB5bYroG5XiFXRAM7EvdEW7HjxHXzMBQx216lG+04fidxsV+/rhhkWbNw
L6n+i7pLvW/ShO35Re68xhR7FIhwabl4cYNJiKn5pBPjbMhRggiSGRB09KL6nX45h7bXPXYLPv5F
dXe33dfdKihomP+E+wO3FUr1IE3xFJbmHGUqc6VEWAhhlwiRQ9Rw9bRRk1yKOVxfyhz1hzgryE9B
vsWaqP0194GCDUcr5NqvilKccepN+GKnwtnsVXk/JV8mUpAFMFkOw9K/NYb8o0EcgBUCHL9K3ZB6
9noPuu1ezfoLustCZIVO67Jyap1kX+0ti34Hk886Kk7lEbgYdGYqi0nKUYLi2z7NjGZwESamVFuu
dNYlVvyaO3MGcmEcpJMmKUodMJ5o2kc33edq0FMSk/QFqPZXzmdmCrAnUq5lyf8pIDwWZwNV6Vih
urjicF7yFncijy+Iyykcjc8TLtlUcEhr3rUtkSdD42K1TCU5Ov68XQCzakShpoGDbprE43JNfYZP
+vrc5OuQ3GI/35nPLKqTxuR7Wd6olbpnZfxaaHVxNauE4GlypksE8BIfwcyAP6eYVjAc+xeIewSw
jAxu60aD2thEa1QS61u0riNVdaRaLGwPKUe/dv84dfGL1hPFmRk0rSnMEXO57aRXFUXHIoaIWKkb
Ag7zD7/FFXdLM4CxbFO9lcyG2l+/sW54cX/zM9T/7VhYaSKfgA9MTogvsVIuj6KtSYVNFqQiTiyk
GXrttIh214rSxzkxUkKFEw1YHJ9Sfmd4Y7i4yIMDtI/4yLE4vfl+PiaKzu3CqCZGOSEdW7A/O2zG
nqyYlFgEWnwlfCAKDbXdEgvvKWT/sc9KYWaphEspBkUX1Dn1seBqluMVbf/g1K8rT6Hy9GqcpS3H
axeOcnbqhS/+NI6+XGIBHeA2TtGSbSwluXC7RhcP8OPc4nXHkNM4sgWouIibwAY31kFcLdLgR+rZ
UtSJ2+BwTYSXn9ImjoJycsW1HWRoHYQdqHpta2bxFHDHZZluS3vD9U2LkQZogNemkIFvZ3kv8rjE
+eKe5qi1+z5aris1NhbXKHYwka+f/OwwYi/4r0510vLMwoTgBT4VNAsKkJkZofhOKIBgDcTb6wPW
ezLoMMn95ARyohzFmk8f0VJ4jayZ7oAzGdzEWJ9UNDgiwSw7M8L+Wg5maRJozUI85lvvlN+gKc/k
6E4fI4Y9gIyIg7ReaiYszaKFDjEOEYHJdBGTYJf9K11VJHoyaUwL5jFUFPcR5kXLZZf+zs5NXVis
0cxEfLhia1OCHTGecKtb1cL80PuYBrz5f1WPuG6miY18rKN0TFxWZSOSoNjQqbxfWjTfWEqqwUgl
GQz2CqdbSYBjxikeZijRuXg1u6uciGbTxZlW97BmjEToqWbT7URyHp7u90V3RVesyjUUmb0u1NUy
TXK/jqDI3ldKKpWXJQKKiiPZfgS8p2vEVaN2t6fqfYWtci2LqGA52P+F3Tp3Vh+17Ql8MXZ03fxg
R2/sYGLceKU543WOOKl6XD6BfGthvO8cNU7bQmUSXYZph9OifBch1aL2lIQIcWYY8Mfn+AuZ6Bq+
z48xz1pgPdVo591iEp/NFLKmYr4P/2PnnvavD4NiCcixNJ2vi70lpEMDUUC2yoRFQJVuZkBFDIL4
lthFk9czvEeT2AQDODX0pDHyMF68XzDAlWbumV6ZwNp3bcprB1uflhyzs3893CrKZskF4DEUJYGO
pbU/cajifbLt6VRcrmnJSwDWtkgIYPNH0fyIGB1c63GYBSoEiIT8c0OvtEQC9wrJ3YL8Lc0+VvPc
Jay6ukUDeEBkxg/Bm2OsvYYSKLyEZlgbFRPwo/0iEjHLp97RrY3BgYnFlJ2SHJ0c/RocgrLyX/1l
KYIgm9T+wlhCJVzLJX5hGi16hX5Gb+TZDSeVpqvc/UjQc4LX9j/wxRsr31lSWu0BQMaC+SwETtJB
y+jaRYXTA9puv8e0HGx/7Y0nhJMLW6cNhdQF2YK+N0C2EuBgKAuPFpqevICNBbHM/BXe0ka/MV88
jRDYPws+nGr1BoI2nYvQTsh3J5kZma3Y3t7EMMISwTE/PH9v/r4ID4H5qd3mI9+rZlAm7iMlSq3S
DKMAqzNXUPpMYZAU5NXzqt7sp0RWX+66Rw0idxpmrZlZTfhhtUENZnzu57TpBIhf8tsTmGY6tEwT
IScaWKA9S2HmW9odUERkIMlrCkRU2FcbSq1JGU3vb3fmBeHrqzqfCTcZqHDLRCqrdd/iL1E8XL93
SeOtTn8z6XkeaWF7Ell6WkDOzBVtgX0lkng6wDe2+nt1+AMg4kvUw4Gd/2hMvwbjMC52BejzoHH9
z0D8l3UPQGgrXsO2hEJp+grWHx4Km9CsLFT76SWBhZiOG50e/HfECTOd3qY50l7aQJs/a12HDIZP
rSsyyWuLlLLgItMcgJQMZsnR6kQb0jOTMQpFUifaPcBCARoI/PE/yBrjlmoBpSGuxIwz40sQzupb
tKqPQje0ostVcA5fg57i+xL/dYpJNhkGqYkMwAyDVPYTU0OZxZT0Pv30h3GYywyBoKCWkBfS0Ndr
2fMtSPJ0kw1g+2mV3K5m0qVaNsRpAG6CDL3hUA9dnAz5160X/Ic+EyGwSdWK/J18zQNFEupJc2UF
jqoBMiosgULWZW95nqeACqOFjxobtNyG7Iw69GuXMgvmiq7/Bxh5UPIv2NImkH3cYkDGgBMc3Ed+
IenHjAWP7HTeegea3eVumfPVm4H/mOfdK3MePpxrdD/iXYIX2IEvD//5Upd4TZ0XVOFPjYQXacGX
XD6Cgpd+IlMec6UapwO0/3OwkqJvBbpyjSJNU+xcsN1Yu3Gtmc3bedBrPGL5hWbJf3LFTpknq2/x
0adfpgjE/BYkaCmu5wTjEgJ5eKIoEWuh/cV0zo90e5tyr6xvzZ/0layb3PaMaZ3FuieiIH+ep0Zf
gqGCu2+2uXx5r8fLj2H5rL6dIMxpCu8uWVd67kMSZhi6kK+6xygloih4cWwcDbak3dFBS8gTNE2I
gaiXq6cli3xtpmwm5jpXsqboSCyfdaxQnfy9ttRutLnxd7wLSYdZA/pn+hMACVIdd9YFOsSAxiMS
VCkKP+ZVCaw40pPaTW7p09NlGqpotTHcbaFTyqXS64/HgEXs1bi/Yu2yMdEvpth2sZRdAbKKwJLH
/qWIQ+qc7AaNohVhqtOpMG9A6Llnlkkd7JzbzHyWlzLt58A/plhrOAJlXjLZXTydSxOTKuF4i2Y7
Oh6yp0AqUUWRC4NUJg5V8mY4EJk8ixt0TAmK1OM3Plh4RldMK3j5EYIHHYNETHYTblgI+P+l60m4
A2NuHF2Y8xldGvKjIfUDaGip33CclH7g/ov0TyAuFKXXRQD4CHbqaUSN19xShoPVG5XYGokKYSVG
LHMKc6Ieq70ApAHaQt10JbUEl/vpquDoRICM8g1SLBbftX2R4fNCgv+703Z//1lcg643kIhXb+Vl
JeW8cNVF+RxzBdph4UBRSQHqGilO11s7R8iORxVeqlYittXTZc+azxkOr0/4eC7HVn/2OR22wgMv
srj36920RijuopsynodFxch0Ql3XFzx4TDbiWtSWu14dByfbSz8Rmaz21rwddC3fKGq1EgSVtsjX
rZVuQ6Vmh1HGTDIPCtpa3qtM73v6/oTyID1CWve+pxwWwCFgfi6+2mJK6bKVqZBYa7CsAOYmO3B2
P9HnVxqM7TKRuwKJpcl6OnEeTjB5xmoEZnNp0DKmhCKhX0C3tb3RyyhLPzaXt+oBlCWD4rhBMHni
gVOkQBpP8Jrpa/BrqswlKV/DT7ppj2G44Xi0wRnDHh0Eqf7Qz60MY5gsZuPGtwnCTf/qBdodTKFE
Tl1IW+z4w9KS7MsOD+kIKpsFpzi2NwK2B9D57m40S6Wv8hkQHDHmTZSA6sovD552RVycMkGksn+O
Demv8eUWj6r9/+M0b4GTwasfFfc0pa9Q9pEUedZyS+WAmDGXnt1NutQRzLqWRnXrfa8XNxhMmKH4
BcKqJWNEHhTd51NlLhu1KAhshiQOhWfrigRR5Jqnf/14LjRWDAhSIYQw6k87gCZ/Zepug79nGgMm
wSP/mTVZR6GiWLoC2wL+5EWAtteTo1/XW3vIh3KBamhV4Aq9PFts7LVT4xiF/tIqBut0LG4KwSIb
veNTxDcn+DRJ9nv2PUUsHro/byJN5gtYTAAu77iSilp25i/OHQrceg8lgcGZWsQdKZROOP7Idj1p
DyWR32ltVsJjbLKjTCkmFHE3E8Ei0lHkn3AyL7TgDbNFonMuQ3ux40QXR/XJqiVSKQdqPhalO5xZ
rp59K+MuZdghS0By43zeCQumi31TwiXHDd0vxtqHqdGkkTxzIWCzB6MPerlLRIIC1Ll8Tr+sfEji
SgtEvhtt5i5J6xgBXCEwkmj7gAe3HmLWXqALGvDJS4OegYxv5kEoYcWgMf0AwZNWsKNy76wqpVT7
am3oKXt7DH7ureHwemdXuKl/bnX9biUqhJBpRDfjJ2u+oWAIUrdKBtMdMqeqBT7C39Z0s/Y8xnt3
8eAg0+v3SdD5B4b20Lyz3wfWeMrBvMyGjFonfCwLWWgaWyYZMjjwvbFPR31lWj2PqDION4LPPa1P
a3tJDF0PPuog1t1w82mSpYMxV07kGO0ntmCv++mt9co4NKviPlnYhTA9fFPQBVaRXyIEbsF3jKIK
2c8SRAhnLLAW0avszACtBQS0MIJvDQBH6fkZEMQLVZsNFsvBdMUf7eji4tnNcJAGc3wHzPzewlTm
Wgi6m/JpllRC8I0+ipx5CAlRjZwZXEUggjJYUA/MGP926L3cM+ZTRzU4lBAoT/y8rnG/DC9MTR8J
LPPB9YjK2gtIqoljhZrudgX7PKRPz8Iixr2CKtqxe+jSriJR2rwheFOtwHiq1qdTCWdJaKV/rpTS
OPA56ifqyU1z3GWLHyeH3PEXAVTZhPZ6bIzz+Rkw1RFauOJzEm3Bx+XbEbmDCO3H5omM6lnPeDUK
eHAdWkuD8JyC9xT99AkoB7vVfrjP8jH1CnbwTrscWJJAjJRbtdwV+t+kYm+JUHbnLbFwVr5T3NPB
EbFYm5ZHy7tWaqXbb8mIFzyTELh4DVngoGBret5yEm+5DE2chWXOU6EfurvEbnX5pr8iDpJa+CeW
MummL5x7SO0inIQFPwSVgDmCcdL4Ag98llXGxkyGtgI56q6iQqVYfqs1rK61Ih7g5ye4G9FFzzMl
87xuErYeUC8WyTn/iae/gxny/zGrAq9EG04+ayeYILX9nnPtwenZXBzQ5KnZoW+wvet3CNgclagb
sUUBzjvVO+9JP9rpmjmkmwbbo6Rdx+Kk4t1alAsLSBttaX9B2Ec3uaHmj0HGcvbnsMfkPfaWAIKV
ZDICtnOPjbdNWoUBp+Mpp9VwtR3/63k1OwNZIm9igfRTSqhECfZ3ap9lWu2/CDenap3CzztJ1t/4
4yhOVVjma0uCfI7ORdeiGnNCcgzLXD1/DUAzTbf+dDWCEqbh8H/zoHvunxiz7BJXkZeb2bZZNjBA
u+Z/OeCxGExfFMfxDOLlXBHbvp6pk/k1s7h315q2nfRlq46P4oKwkL80a0BsHgD2TLG1zIscaigT
k/M1Cwy7dObqpXmoLrX+JxGlPIgY3xU2o1eoAOnbqsfhStqubjcvo2UH0jXj83rgtQP6E3IarQXW
m8eL6NTfDgosADvbZGwik2ExxbBh97zECHYVdQetfsNMiqW7nqDgHE1TDiVrfaCQZ8CEvigiyIXB
alUISnu35hKz1rHfFet+c4RHfOFj6CyhkBg3ijNo2ycytwItUzQW7v8jfAwTrIuC+lCW2zExdOrV
C0==