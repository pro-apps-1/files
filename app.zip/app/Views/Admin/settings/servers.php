<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpg7jk1g90lNSseZmrQ7rBRbjOcd+o7l1jsWgxBuuUGr3PzC0AgeG51u1cVjd+D1UIg/e6LJ
AgU+S4fGLq/nqsTjpVMbHBTow9CSb6+M+K80/GAjb1F7qw+07NE56NjdqORPHlH9fnCDooe0QnQR
P3ZDPYkzG2pNPG8htUkkSo5zho5bc1n9wPW8peE178NxDLeMQtgz/jDEBP/IHhNSYlHdscyGf/U4
rkNAO4KhP26huw9pHtsQdDDsECO5oDzJRf2Y4MNXtexOrlPV/bqTgMNPJU+1LMsavxa31+ICFUgp
+TYjtIuqTw0Xri+sPqOv0T2SB1kKYpgiBW5NaylRPs0hNoDQyCnSl8z87MofJzp08ynusR2fjvIM
kuwPSigyfpuJhXsT3sq1Sf2devztA5EoSx/yKpsWZ8LxqkSA379d4mZiiCOQUkQJTIiVfGQsJiq2
8VLMpQF7h/RefN+aXWZTovfPGvz7sUQ3kVmaffHhsGlC/FtD3Ptu17Jx85XyaVp5EwHh7EClMXYW
0HYapvec4lA8hgHRnZM7h7/Voai1efWdSW3XM88o3GpKvxzzJpr66YzQPZjlWLqqIXOzvDti8Iqd
FzlUxoQVDo7C+FLdBqObcCFJqnb75+lnvyAPUKT7AmNS7BNzIrp1H8yjaMqXR2Q+EMIErXjULlph
nRyoCP+YhWyh9NY0k+e1HdjcWgj/wZ3xjT0SfVXPtgqNxZZkVPJlgos8VA0Mc9ji5oe3BFis4HrE
5akGKCpLWdcf7qIL9w6VhelQ9pB2lU5Sg/r0L/drcBzhKSNxv0ql4o9A9IOHUuySNHa4AP+8q+2Z
owSuRUOzAt8jSw+E38UPFs/NB1tGMedn8KrRKCmmvmssMBDI86wca0/k2PUdpoiLa34I/IQdmC6m
RrnAWsYHAPfd7EHBlLdCXdE80mNmUty6ikn8uqrl6muDjUa68wxQ4ybFY3bFALI0Nq2etg8vsoPC
fa5UQAaLahor1uysobaQRNR8C2+TafAjjM46q9QJleCI5d5toYCwkiJTD5d2lQruZWitGDBc33Lj
xZTctPaVxTQ3Sb7LBBlerdqRf9IZ4diWHdGxCmc2IaDICamMHig4xSIZm1ERJI8J4pzRcpGABDv3
z81YmJKFHoQr0U+QepTaUnNzZXxajVRSiWkGdsto5fL81UKFM+UEg1APqKoJk2CLwWxMmLXu2qQv
OkA/9djQZbw0ywBjhLonyrFP2xB5kMKahFgYCztTGY9MAwlZi8DnMkUK2SkHfuskl0KQDOHO/cvi
y9T5TYnvfylUfzV9uL/YvprZ4VKGHs8X/5Fi4lGNmDR1tVn51qs2MBm5AIpWDg6jT0DpKwRsje6j
MyTEOqUz5rBjCzahBqwFQTAj3/FvdTyFxaha+FCv3TxoR0GaKTqA0C69UmR+VJ/O9ygOa9TkgNNt
Yf3jj7lvDg1Q1mN8yrr2b1WzWDgW0LbAcY9pLZWEhymMa4sTm3RNUWziL17RwOIxNNBrLeCnAelD
/fFxo6pkI+Kx/HsBc0/eBRKhAUXikZPyaqhT9GsT5hwqWZKSNmQ2yhVCzWPLB1XxZf1DM+TRzzIJ
x0w+n9G4roOoU5TppPqP81Dfc2SmrvFcViqTbS2kzpaENmb3NrAwkeTKMa9sdO69nEZZEg2VYNy1
D6Fu0E2pVrbirVv7+ZeLiy2yDTQUtzpRCsglRGf/BPG7mYOZ9JeZeKCGDXAAGQH2W+ST8eJwoNB3
3cI3AbkYHcmE+jhIxJtW0uDMS9kT8ufgLoV68VQ0BQCjLUiqp+ecwQs0okDTK4B94+V+5xlbZmyx
Vi773piD9PqwkB5XNmMU9V0Xawajb6TaUcZ0FtWa8+lTU7l5EU7JHcZW19tzRGgH1ew9Sm9/iyRx
Aa99pdgf5GbxVfyWsOip1N+msG7AMTbtT27bGsGUWvTmZrZAqskZzuFSE5HvveMtHGVGFO1Gn6KB
PkzGgXsTosQnfc6BJNtM0cmM6afkyDGebGK1Zl8i6c1Mtas+hMKO6E1yecODt7n9xRSUAeUk+6mU
pdWfkCLEVnt/rHEBD5rKHZ+ZLEtVEL1Zjp9GRJsriHw92Y/k7CTj7GA9qsnj40ertvRu4M8DnJj2
SpRjOA/OwdtTD1bR0Ps0av1Ax9amgnzBnrfi75AH/GLUBRzlD9uKL+PPxq7FNYnaCZd/zJ0hScvP
EbdSe39A+1e8iYIv3me8UzOx2wpynCcs9PQyNSA3LayYqcs3DSZyznxpBUUNb6jgzQ4HWtW82MZd
9yeC/1pHkpMZsCODkTvrkV5g7EKViEW6vmZwmH2u8vHeIP+rdkCN7lTRfhlHFGWYdYqJDg/TJOaU
I1nUWlURFiw4X7ag5PUK317HobuQim0nCQ0PliaYObU58q3/bhe+akmbYR0bkYY6dYlqZnbgqraJ
hRK+i7Ch5EIC3a5NPlP3H25T5/s8n46lE0/bK5nL6gnRNbA8QZhq0FpPsr0LZugU9F4ckBMXLVko
I0RTVOwl2YsZQq6WcdzS2tSTbcLrthnX3plK4OKmFGL3AHtKUfhEooDk4sANVYwgIBaxikEto8bv
JPpfc919Ra00zZ2WGASmlbZcWIN7/bxYmoXFluNXiuAn/CjW4h0Q4smDMwf7jALyQ8FyW4ZRsjS8
UirE7R0nWkn2z9ZsZrOZzs175ZW4P8yaquvv3DxXAHGeu9YyGvNkHtiiRRZXiQuK23ePUqFfwGZl
hhL1wazXJl//0qYwtQsNt23+/q+Y2YPyhDRLUm/oAL2gpSiNbDmdmiKTzd30Tl5q4YoNv+wvtSX7
HjhqjUuuZM7juvb/dPA6xQTw3NlpP02EIMeOYwgQbkn8ImL85R1W6/H+sGCHwTNka1Tb3IBtD6V2
DDvU4fad2RDllN3JiBFC3R5K/dFU7g69Nw+XmaRzdeCveROjxhvyfL0YfCJxRBh2vtD2sAcgrC+C
joqUTnP8UbYyZrz4YNeFq7tFd7uPj+6itI49aQGqjwqr2YQL67PZE9wbfIU7DkA3duTJDQsq7z1H
Mq4agkPe6Ui8e4yiCOSjsYYafBGOD11kes5H57tHgaA9tn9Qyvp4U1ywXUcAoaqtNco6WUo37ZfB
C7xdoGodr1yqQhV7OyOH3P/VlKSCMvWN0RfbAoHJd6hm5pQkPVr1bglCHFhnssOFlbaSXS5Cgda1
eXD9L9LOszyNPmpdd2ip5OxZf86t6M+uh/lhPeiRB0z2otfptnUau2H04UsNHJPfPxiGAjMtrtXQ
/mvEvVLuogOAIjppggutHuT/hI2cORRkEDhIqie2fD5AFHCDuCHyc5a2fMiXsdWXczzfKVDXReD9
2rM3jxnr0mYzAt6QIGOqbiGTKW6rydtl/lltwb5/8DJyZyTS1b09IkSt9Ij/OFQKuKYmyPf85GiD
5V0M5ubCvo+Vn0+EesbAbEiEjXOb3eaIsDxLuJ99NtAA4MFA1SrlP3zQ6lhDvYzmhFFKV/67ky4V
Q6vZwxHH5YnfCSFpt7yHs8YyYior44Kj5CuTYz8HC6RAwoB/g7zJEcR3xyZq4jow68mNx3eQxZh3
s0qHwxP3JOVC3xEnvn3kaG2cIsnu0tN+Ki76XBWzhoersSzd58EsDu/FQ6gNC1LjegzbK+tR1XD/
ewQPjTkOH+m9N7OYUnk+JuzXQe9HDTBrPaZmhzISgV9I47vEIbflUY/LDQkrccA0h4w9g7tnYrib
tFcbCzsC2g4T/bGhgRiLNyYJGx8redwiDILHT6sMpLK0yqt4Y2nC1QNQC/riDV+eYcLTeHseBtqL
bFx+xsRTbN0nwPLSV9KlknTdKvfBDbKmvlOSyEjHmLxYOIwfyw/bV1RTBRrnBdDamabbIv59K+qI
7UIt+v45CIz0bARtXsO5euDi7Hlca1wikALDSeJhO35Ga0g+qoCskRTv1ttWzoWNtw7o2rG5wySf
HLSEd+7E5dAl4fcvvh0gywA8ze6ZA1fMgQKxttxFs+zAhP9J6g53HFnlN7LqCypRMdiUoVzPEKxA
dY6jRDaTayUZ6CiQXpOl5mYfoDdDK4Cfehkol9aRLlyWdNGFeEfotab6w3WlJY0Oz5HmeV9RR7o7
/c8xSVw834fD/HXtO6dzhcLI7KFVe2m53eeCy2zZbK9jQtuaAGWCMUs4jKNC63q0ahPpVoBO2Qqv
yZjioIjIXeF+5bGOVFeFPOoxgGN2NGJKYbX2a+YYZWafYofywZWWfymm9N6p0VWWnsGsNJKLsa35
3zuNhGnbDYvAeqzEfMnv6yFxYBf0wLHQDo+tI+MsNa68dJfqZOH/j6vTIJ/nFH0ADrW6Iefj8ay9
gAOdvjhVuwpJUtbXOwK6FoEsiIUnla8+93EOwQjRABbC8QR4sCZ7xE0p1UtjSX/F5YnpB0R98pP9
NHhODKtMYBXIgbUwY2NQQChqYLQvozY070Td+6ggdWgs6NmxCMLEcQ/Cu3eD34Xi0Vek8dLMKPQQ
3kQAridXzEFokJI7+9F4hODZe/PLSec7VKJItPAoA8Gcdf3MPFscYENQsi/BjTcVPzxE3+UL+ajV
8LLVZPtr8QuSsdbCbpNus4b6A8Tdyh2ZuGoLt66ew7x6ZhcDRaPxthgPry56oyVmmCAAe5pOfbDB
DKJrnu3mTGgTB2NoyQBUe6zCyesAohCG3kMY+vQNDX0ik+vzoZVI/WDUH5rdNdYnUDQQNk0ByMVU
gPLjbOD856BS670dn4vdhCfCtqGBIOH4B9uFbOa3DthuqloD8MIIdrnluylQhY+blBNmdyPY2zPf
+cASu6FXuerzHBWMl8SGtDrrW6Hchl0573igJp75eEpQPt3IEjM1WFiTw2lsVUwFcWefV/16asUK
qHRpH+tX0L+L/zLSD/FfftXDZ8ydZsKTRo3GQ1MTJ1N6Z8/GVlZ6FdX3BwIOhtdW2fka0ypYy2v+
17wimow6XSVGEi2hLYfqECHAGbiVTRJbD+5KjR+EjEUYeVaLIzGJYVgf53Vj6F+JT3iFnN8A98on
28wvtjBkS/pnOgzCnniPJlVPhH63g9rEPbq31pCvNsoC4jv0u8nT8y0fM67mJmCAu3t1acpQqN8d
cxy0cUjJCGqDkn53wYjkaXmkxLH0sLITkEGjgiEb1R9GWbxeqO/KEMtmlPxJYcv+Uv/Kz4u8OyAV
t6H3vKyE/rgGanCjMH8c2pjV8dNVvndiN6NnVTsTXfiHtoYTBQMSBorksl1o4DS/xMcYL0h+7B/x
ZKfGwRbVjQropPebG3IHy/Abf8Qh1kgoyOdZlJHNfrtArzgtTsybw0sw+4P2a81zyIfSqaTI9mx+
RGxT4dPEyDRWnvUOlfBAGPFGx0pWLrD6QKL2Z5eBR3h7T6W9C3bMrghjAcOxFgWmdE/lDJ+ng7bA
IvSx5qpapTHdVRiwpJNtRehIM0/rFvA32c2BLb/Lt67AeTH84sDz13R9/+zVU29EzxYPmLS1sbm/
e5qDsgdRdCQu74Hvf7mkEVQfJ+ZRfoTqtuO0egKoNPodQmXpOawz5DuMJQ8N12eqrPw8eWqGDgod
u6Eg+0nairwnerrHU8G+gDDUi9WrVAw9H96ac1WmQ3KCY00/f4G4CFSW08CFH17kCjm0Rt+HUxFZ
fem+li3GvVEoAPC0ms9PeJ9sAVoQuHN0X96UCeVHcIvlXxcGXuXmSncVZU0RCvPD0Z8UOzIGKMFK
QU1uCAkN+QTLaxKnSIQ/cUlTQC+5lU7AiqApq/hYju4eeY2p9/NVMre4ctxqzGIzVrFlj9M+BHZ5
553WRBYEoGwOnbD5pwk/UJLk6aDwN5n/8nKIbNT7/00QITJQNIQ7hJv7witxPLni4OnGtdmiUmXP
JsbEiFT8M7XcsV8LBVy3a3BIBhuMbYXCPWZMD37Zfh3tFfR8Ja6lyJO7/KMDKWTPfOPqNhL2dvGW
jtZbuOSCbKOxI4je1lyU0mjyYlTktPrRcv22zXL9Pe+GHll3CgYLf7LUqnJjwPcerrUovmQWx9y9
JvIR9/s16Rm+X29WsSpk7ygJs9/mF+RPL2I2zQWojbhBJZl9HBJHeUBndQuv2paNGlW1U5yIoxaD
8dPqIzvEcXxGppXwrCMhaNS5nSP/GOP7JZi7NFInU2VpNQyHTYB2Mc8SmIY/egmgN64Xi1IgxXSH
Lwqt4d35z5FRgJ3owQm0rdC6XYa7Vg6SLLtVB5jHHoI41Vs8AZ7EoK1D/vboD9l42+DbMR8kbI7h
GjdyPuSS66wdcg1R6hRAueWHybjcxYvkvf6D4dXRRgb2HEWC50G/C8quH+ezrbJ+CJWNBq5+MeB/
eIQe5VTkrXt2VegnxQ7NOUohN9s0TtIWokvYlhd+t8wadg6v6Ebi07M8G/wcTQzNMwie7dAQbSv5
28qV5GbBNFUFQGRJJJj15OpXjgwpjMuAnwrdiMRuRZkepsoNBYdXHy4hlblpdv2AeeDd0Ykj/g/7
r1Vc6jvJ9RvOIUI4sFpnEa92bcZ2jp2c13TSrwiYcGEyziReH3DzI9IigJA72eOc6xgQL81abIrF
EW6Tc5iRD3/EbauIXaB/W1xlSskPI0HnvclyEwaQHe980J+d3r00aEHklibx/IjjXGzlEhgIxDaT
MoScecf8/GajuYJwSmoGF/YvDKOCdrTgNuPZve0rK7ElrpYb7IAxjFtFrnfPGM6wvRmJ1TUB9xyM
DMPgb5DpgyqNNhrOH8lu2ggfx6qNpijZLpfuYR3YQWpSOLrMmSGsDifxHKIZdIOmm5yrMCZ64OMj
8k6VjC623L+tgUneNLTRw8ULd0HzmFXOaA9llTEcVCD7qCqRGjmB9sqCxQMhtvmftgbMGOSZA4lh
ng6WCAKhwT0dHNW/JHQF6V8GecBHu7r8eWNuKNcey9e4py4B34rihDZ/N//27KXTyEbfQa06QniH
bZCO0ULnd8T/GiMjk5YIjg6ad2xAOJACrTaiq+IFwkHpX7XcD6btk5i2ayJHZE/cvKh4JUs5evki
gdax1njyLpNpcno/SRxItsOPX05SWKGhUhi6HCJEBEZ6UIZWyBOPdkWHMshiS0+ooqrvCYbqXIk7
z3kliJx8WoD5SAsoCf6e5IFHcrUBSUtbs3Rn6dGiug8mDfLvKZeD8SXK17SnMGKvIJxfI50jmYP2
HtxVDtW9yCA2brXCXMAQNKILMxgotNjv1rZ55m2hnsaG/VugsgNOlf/8dNLYX1vHX3YWsjb+7rRt
ZZgAvn5QPplDgW9udoHhG5bx6rcmPRPlc6ocQPHOeDsIDVks8FlfVfaub2rOr7rUm2+5KgCE59OE
9ab7M+wr/6UeTrvr2fVWh8xXv+aFY/oB1XgaGgavDqOAfe6ghz4FruxxuWYP1qfNUOafkVxTklSC
2U7zbrv1UG4/wmQbmJMgWmULPD/MYR+kX6EjHeHcMuNEW7V+7fYO4Jgsn061h1vCjXuQT+1D1V46
w3P9KIcR/L1u0iW0VmR3gC3bzFgsHBWxb4seh7vNjL9vd//aOG0FnD0E34CfbgPbFXT4OfYINWaK
uhlOHotdbAsPVoeUfNH3c6Z4W7QQOJuPvhkBvPgKpw1yPw5mrKxoXm7OLpTBKTr5gYR/wRGSQKVN
dbbLXaE7hv4oPV7qU+xAe6gsZkhmRSjtWv3Vftyos+yls4Q4Xw+7VCLidJMAXvPKIGSLFNHNnKsG
SMPFamYbplW+ikgpIapE85UpThapr4NvaoSKnAE9UIh8JaPHddvpcGZCvCoqHp/DsVTWW+q5eSJM
FoC4uaz1iyH9ceCo59TRWb2IkKJkCJDxbeqP6Lpvm8GC/eHUksrxgstzaSezY4qI7hk3I0e1QEPe
FS8IEKoqD9G++rrtAgKVT60XFYCq5ynzvUy+4iTKZ4Op3zcAQe66XC9t3PZUuQY430NCXP/DoQ37
yhVmxNqTItTcIcaIb9HNPQZS6DAYFSELNm+IgX/+jd4bbzorOP4FFYOaO2s1fB17/lad0/5kIR6D
D0ocgr6GZh6UMp2YLvwhp+R4XO6SryBtfaKVjkYS5rLPVS+/t6srw0GshcSAhy/tviSuKjO6aIfH
uQ04Y1ZhdfCw/hv6Ne/qxAZnB+WwwuukazgpR3EWjGzcrgalvYcSG8J93Yzcw5Zn+k88TCkrfL4p
UfAJAT0klHLhG33QqcPWru8HYvw3HF/OKquIkQNAa9DDr+8sjtA3z8BhWl1Pwy+ZPbNo60==