<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPndSIKA1RB9rN37SOIFFnumaBvabo981OUWdTKXApuqm4JXWgvyGcFvytzEI71/W4Tw11DkP
MbpFfsd2E6+bktzIjf0tvQsOI7pK9hWq6SkkdCuTDDYTAQzXJmUTrjlKU7cnCW9LOgiVDio58SVR
6P3m0ZkY8EwlmeVqPts6h+PYG7cdp6FMXo0ZDy8X8cDCBEDphTuT2CcCRGuhg40BOddZYNZaOUMa
JJWjAznBfQIimy3rCPTMc1I5FVlS9LMhCfhlNkbziC4aQ0LNW/MnLNDSvRLbP/m8W1dLFeXYQiS7
+gFdDVz/j6eIpF+9FS8Xd7PcL7vnvwPDXGAz8vyOIVR3dGhanZFNC73ygvIXNvlZ9cBpwiXvOG5u
VCnWhiEc856qr1Ac7KpqFeLMdlIWCn1yyfGsXNIdmgTGtUXthvkP2mnDhO/DlV2DsUlbhYhAi2j/
SMhyZjtIS5mjZNvCP4fHNQujL8WIt4ddE/psOoAoxmNJMBs+tqD9FriD2bkEHlMLQjkTfyI7iOxh
r+6K9bmVBxXsEUyvAGedWfCdhXUKnrs1iTrtY0TyST9Z5tmfgFOLV14dT1BQOTwQBGyIzozUmyEB
xFIcqwvTg+93AxY+WCXvjyEeXjSLQiq4p0F7BbP9ubL1CnXwHNiu9Q3A9pADnX2WThl0+RLvhO9Q
BsQMg2MEXQtb06AQK7Pi9D2dOK9aGTYLi/OVre524SiuYu9WHXJEMeT0nCagxCQ59fdDy7Fn2Vc9
6DTOQr49ATbHClX3vg/MHgPXboFhfgf0D48tm9Tflp4faRIdVjOYwsYrpMcMDh0e5tL3QsPaQxpt
tRFUBEQBbxeGMBznz0ewDNU/8V/VOQeYAyw0AOH1LCBFrz5W1MfVLvmjFy/CNUYiq8E0lmvkcJOG
P4rr/LZE3EA0ZB3TrIxqmlwMHxRossnb6WSxyg1D3iJTicTmo/gk02ZYN8FNMtoV48vHAHjEuBkV
CSGGcKdcq1ggpA1gu/ckHLrh8IFf/S7OCphWIjnMz1pNWu2iW6UMwMitLbUarKtDU1m1ARfYt1AV
CF0tshx/rZPKy/zevnauA06dqgKhI8VTUMl0XB7YCGQVbuG32d27kA4+QsJPlxyv2Ly89KtCUxkz
uBJHNtXXw3+lQ1pHFf8xC/tPPEFSlduzJyPAmiXRm4dEuoFUOxTDiu8R3kLeaqoWz6bhqqvxmQuD
4IJQ0tKfK0MQHMPKOeMLf+iI4Dv38HooQxBZ8r6GnNBKRxqHmHGhY5tW7bdEDsSnVj8ZJg5+uU1B
NzWZhpeLW1hF7geVI/8I6gZa1qLwe25f12eo+CgUw2bV7FuQgo0jMV/5GyoVyqnEt2H6rLpcnUJ2
p96hSkNBNnTG0uT+bLAxQjMZBS91qCgJiphEN0knhpFBoK83r3SFElb2utX+APfazKfpVEwadXTv
vLWaUTIYPSi8xnbcd15urasdPOAMO+EgDDYi+lbOq2kDBxE9Om9LgkedL1vZl6WwnUkOqYbeIFGF
XOCpYFMT9pqjpXUsRhEY5mxwWtoIhmemnJFCiIBXSw5L9w++1hSTq5LGbK6ZraTJvaal/4+q/3l8
N0q4J69uwTs9TyLzop6vIbii3bWpTUef8mAqmHIZgcwqSrkZqN3LJlHlOgtcA8gsQnh8wBbpyCb2
HWPsChmsNHpgUPDPWtzpbu3RfefjTvYEC1RSMKQb8Dmjy9Mb6S+gd3es7UE3ubnCeZ36VYcNE513
PBEf8k+mTCc4XSXfU0Wjy8lf6H5V1ABaro7amWjew2sUjNK3wnnnFLF6ctTnuRJo0KBQckShc2Ov
EqVBz8MhJyuPpuRekfMNMvrGCe6n4Ab4M4h5DpNZcR0C9ceq84Fisn5Kkc5IibFB8Ms7sMp8MAcR
Ppt4n8mq/NMSo4CWqlPLZ6bZ5fAsjd4YTVvTl3lrnXN+5TbpuLzyjDc3XtqeyoVlXjQprgj7L9nC
WHn/h0V25/kLGEFFMwDX7fOEJdB5fMqFFTv9RvsK6nInSxaaCYxDxMP7a5UepuxJZwym5M//pSdr
uA2dcWZ0xq+IwLWQia4preGP304nLBUp4AqsAR+F4wB0gDiegjOiPIbgPNbluGlgSBk6cbwxVxi9
NW9lCl6lbIapLzYEsveGOPIdXiCtlSouno7C0XLakoUXesWt4skKeHurUpxVRhzRXhcS0MKYggYS
OAEVm19dWm2bJ7d4J5FfU9SVPC6N6vVsvotaPkGwCpWIhrxa7FuTWlQPv79wdp0D4naW84tewdDd
xcc9L8eM1TjaTXrtzlFUy8HK1QvWMQ3FTZzW+anehtWw6TETMCipwIpNetOC0ei5mV+qBcnBwCUK
VPaBPT7ExqQG4SpDvadNBt0oarpbSl433sfzCPbcUhL/H1lds10V92o0tap3SR+S8T+2XHJLnc+w
EWKh+bqQL9GLhj5UM2wdfs7G6AhYI0rGwV0D4E8fnQPhX75TxGZN3nOdMQS2zzhJaCnag+ArPHMc
HhWFHNajwT20HAgj83b0iNQWZuifHLF/tBXLTys1HFGvhuXbGQ43gCXbDyX2NwGTeQ6Xv7G0K7Ed
hgZW83f0Zgf9WcClm2yW/MYSAmB/sXDb/DxnCo6HgDlLiOb36qx0Vn49UsaXClDUR6rO7OT/j2Fx
Pi/PgyYkcDHBJFcxlzjSolF3aN2YSUmLzg75LQ9pDYX063StH6EHmtvK2ShHd5MnG3ILT2tXtL0m
gZHQBpkS71iAWuLvBqq8I94LlUpRFv2ziGis0qgB4LoMlP6iEsvYer0AQ2acF+toC2sgcee+ptn3
XAwvEZK3b79u+pc6mmUMYpfsO+2YudHLV8AR1gLaMqba1SJonxBLQqllV2yQHYqM2xjGayYDpMdL
2HsigY0GoyTnSPHZJn68jrLdpN//k+ovMfH7FcRMpA8sZAcMALgVj5gW2V2PSMSQe9TzutcreXs8
6e10V+Gj+k86rkWErNs0G1/66hND0hl1SPHAC0ypRQImQxBL3Mn/H8A3Inp5+alSR2FU4E5AUjaK
DnoqrwCCukPOFSfTzwB/p8Qu4X0YUNxm+fxtWNdp/bxTMsoJnBHZJsBLKiZDLluFeIP0AaV03p8s
1GjUm9nMMDsCtaiaHugEzy5gg82ZGTGBKPC+7WF0NuKqzMxTxoHahYhvwwEpLbRwjyqxlilHqJEp
vaVhMlHDezhkkBRDdKQaT5pCpttrTR6jWV/v0XtQwv6JvR9tANl2E0QmFrFvboFzhXC6f+xyhqKi
xmjl4UyGc28E7qTdZ7HAQtMCFyXX4wltiE/k90QIUMq9sOPSy7wf4SCrmlUPt/KS7SLIs6iO1+H5
JiUHKJOGJwl/1reBKYtI5oatANPLLIm+WtSOyUC6wjoG9ULbkTLjaDo/SP+RXOhgA/Swl+yNWWVQ
ouHd8zLS0lncQFyEQP7DykmfleEpnQ5erTaBg0Yxd+BLeVMf30HiBEFRQ1sizim7Zz1R9dcxXtFY
UcqqaqDCSA6ObzID1UaoP/ljfClnW6NPdJSr1RrNjNGxVDT8OhlWPAkKm9X1+B54uj/T8WpnMXuX
xY4POS15EKHWHSyn/GrbfTVPkyJ45nPwtA5sVqGGWnwiIAcDriBcVGmU2kf5cyz94gMIEOC2a3ZT
ihwAHKzc6jnMaOHT2glD1NYLc8kESs+vFtSxM6Fai+xV2zSMv2UYj7RMQoutxzkgSJh2+5pqCVm5
3dmlLvM9EVF6ymTp9/hH1CjYItKYL8F1JkYB2cSoc4zuD89/mKbl/qbscLDmJU8HpLH6tjV9ZscM
LLcu6Wa+a1ybEljZLy1bVXGwEx2E/mG6NEKl+R7ppOYtGeB5E96F9I3qzlCc8FH73QCE/7sMG762
HZYTbhhIyhcYG4yM58wfxuXnu1jPjzqbC+0eau65AqgRHMchqPuX9Neroz1mxg/r/w6r2jrd1aof
eJBK/oC3kR/UThWC24eke4aIWyPDh3eoxEtABhGAtUcXUP6WVt8/YD2xATwX1DYJxVF8n4pkmChi
HI8bDkLE8Vh0pFdYSAvY+Uf/HSHVE3OKGdy5HTijDMc2o8AH+6MI5EZXf5MZguQxn3z5YByOL13o
55x3kX9jDqTbGnQg0Rowii/mG0J38yMEGWSqWzFfrssoUa8pPwwy5wC4229lQBBXJjeei5AP3Zge
CCeWZn1qIk1P0NNSQAb7Uq+6Lf4lv1C2624uHfNfM7z1+ADY+qKdYxE0wohm2yg7SQxFPydKQPd2
l42sJ6q9qEaFneynsHIU+rcMaXjQkX3loXdw+PRNa6sQ4rvsI0yTk4OQEDa/o6H1QyLhFOI8e2t2
ii0tqip1z+K+J42MDcXK5jvTJxsAAorrAEijmqT77ObfkXxxIheUr+atVSqrzzv3PvarKDTmK3jc
WDyY/QQ+EU/+SYG8g4cwqwJYg6k+fxxPJbhWEBtSYlkWoaJssRekSFxT2Qmj5bpui8hgA2IqMsLE
o3lwuUCn4my3CalkEi+VrsG7sMBBOJ9gGpIVCbSWRR/tCDGhjbkjpRLrdyhSG/1AXGP5JjxVOoRK
3bb1PSl6QKZDVRfR6VoXbqxB9UZKJdkzMfKDUAYMaBSYFHh93esfcoHkdTRLVyTzB2MXcpa36Xbh
E9YIwsC6ytnZ7SqqGw7PsluWE5ZBcBS9N+DrceJX6IFjDynHnGZfb44Zh52iYN1MKdrkGyoYhlaG
NnUdt/XHfsLcVUut142neps+mOW2TABGFJspNNqjKRHa0smx8JtbiFgwCbZ+HfUfFkFjVHbf/pOg
YJeWjmtxoGyjXJvale/5RBS8CsigtX9lxMbpRARnBQTkOL3g/VdKIWLHxIYQ4oIcyDs/II6gDylc
rTypydjQzgs5UbBLg8W00SjF0+kSZDGF7DugyhgAoDaz9JewWBjHecFmC5mcVl/SWl3g6HC37TW8
afTTwedHbp10Jk+JQxhweApIaFTLkQ08KFXsNf7YXcXdzSvdnQFHZgCNJqVvU88ZWloboM+t3ytS
vYBDKUHnrNXLxKD66ImvxbKPT46ZqYfNweHi5TGiqA4qN4LiC/Ctfdckp9XA/eMDQD3/sWKTuggV
zeqjVMa1grtkVPts+Oqm6CzFtf6Pbd6fDQbsDGFQqqYou7UnPh/nHrlif8/WjUTqGsQuJ7kSbNJR
nCipyJcZVaRT1FtuwwCm7hXXQiY9YxMMCwWDihBk8BH3C8yidntasiUJaeiS5c0TvffpKc64gPOe
X3hRgf9km7MY5+nwBfhh09EVLbwK6DWj2SGJ+xCwK7eScmTKVYutX2b3mMdKhyaUzi8trXOeeylr
hHX0HlpSKOwNMazOiRfGq5mBChZWNpN665eBfq6P1j/KuHSM+un4oU1aFtZ+9fPGbBFwEM8LNM9y
YsuFUHomfuPXI4Q6D/iVvo8qiV9JkmMvg1GqQJdj1P//+VRCmjc5IU9GMj7nvSv1S8jVHDQu0AzE
e1xUTG0CS4fsjqwCdBAx92zRNO0gZ2KGAoTxkAOPs1oTMZ1L/2bBt3wTCXQhEX4KUZyBSP6l2mbr
m4fCDNnfWE2BOMXr/GRGUX8ZyCnnwpY6/vVuE4S1OaYfQOzybfgGXDwZIdKhZeFYnai+XljdmF4X
bTIZ+x7mEH/bHc9FYE91ZiNpubTgTChTg3lapRLJfYnXWIfdHJHLjD7ndJiOwoAbPJEe9wZD3ocN
7ktk4pZBCJ6sxSWa+HZrY8qzOGtnUDC6Q8Gglg2QQVs76lfS3P3hDznagkRN6PDp+5osCIAW7NLC
cVmV6RnBa2GkjL2aeN7tw1AZlZhXnw8p/LcyVPr3yDSfpLk4p26Pt4y5APNlZl6rA3ICe/zDdu6b
AZOD/st1stJS6Tbw+ZjFa7JzpxWA+gzTVxrwyRIO2dCfE0uR8C2p0OdLyoRiZJf1ZTRibkAdC3S7
SYnVvyY7dvMpNa44/L0HOhPVX8Vahclf/MtOdpCr1GkXNzu/PgKMaZL3TBDewi1SfuoYsw/PQrG3
E6bS+33JQqrbq3LWK10+VVzy1siiiVtEHiMTfM7IHdKarzz+yDiOIUuuiXVwtjR4J25mdo9niXqJ
lBffz9rGdvFKqc9YM0hf1gpJ6kslhre7j1tQkbGJCv7i1qFByor1oRfcCwB5TuE+rdlCtTMqhPfX
RxzOMQa43NYrDZvHzvc89UkPS9Uzj5lweYXzpa49jGj67C6SpxhmriTzCSVFZy9J/pL/QIf1KVrv
CQuGaXBjdYDaupEKCogAPMcn9OlYBjsrMA6m+zyKpiqFNHJSTNuo1pIGKvRDreiLBth6QPkUFdzg
K1EZfiBP2MT6UYBtYWqgoeBwp0RuRYxHWsJW8d8RkgqpDzbTviFE2JMt8e6hl1+k0ANKGHi4KX0a
Ae5MnNZWyEuqcQUNp5QDvhJ835b7YQ/ZQJQJ143tQuK5ejhfmDmhbbw75/oZ6mSsEWm/y5ZDZjGI
Se/lK3tDKLa0bm/nvkbUTfnQ6y293x5QKMy8O1r9CdbSr1df0AY31IpXqvNnbuUr9faXlyYwV9RO
2kk79QVe2RDX0fY/D/iBPnLv72Nq5xR5YX0P9lDBUnl8phZt87ppv7WRfMZxu00Z6bXvAfbuXX1Z
fTVHqTn2udNcT8mEA8G72Xaie+4gJJ2O2bSEzt5UvrVgiKabXNAH2Qr6URr7gv+Lvo007ZhNf23H
E/8gkdgmNs/ST3BW5Yybw6OFhDXATVgJ3xrVkHr0x7I/ZUjHiLmPRp/TZLjYzM2mSu9+1sR3whJh
7fGD2hB+Y4a7vqT5i97H0lH+O6/AT5c6AbaImRnNxu8Owc+v04OpsE6AX5bLOH9klEo0Z1pYdCFe
d4kF+kY8JaRhUbyOYL7+Sq8VKi9GT0/tIlNbMtY86RBGCmwKgor7fIb//mMpVUmX/7FxS/ooIf+m
TJ0TNCULsf7j6J/dXCxpC6WJ4DB8xXa3SlzVLKpkO9EEmtsC5SOa61Qex8C2lGjYA798PLwBzztA
Db8SxZO0EVdgQSZjcLrLIKXtkHPn3cCs00xU6uU6ovcriNAr3IuRmg6NQAHBuVbFMadJocdE4UJC
nyEcZc+lHrvSC5W8PGL3HmF33ipMvowFMJ8SYWqnplfqXUyRecFC2lz3z/ikMtGPo/SJYmOqh/e2
4dwmzQJduxFoJH7YUqgeW1xSjeignls9Gsi60wSkqZBLrYIHNVm7JNR7YXOQlya7ltpjeYG6z7h5
p5VvqawG9hef8TfNcbWYXJFJ3Nfd3kAznwJK0pBXy3Inj/97emFTCvsf0qxjm4H+PfZmRjn39tNn
gZTFylGbNozg9hZ9S9RvmiYc+DcoyARcnPaaUNIRQdjGauKKJ5pgShqchEc10mUiQFzR4A8qqBKA
qYLj01H6ggnsPyr8iH24Fhgugt0TfEPcuZuEOoemLYRVJODJQ6ebFlqCE2bCpt6kQhJRfx3jNWD0
VTzM52w64gQAVHeE3OXZPLhreTq+gcedrUlO0QkSGirZvXG1dBtOj68LnPvU31CDRs4uA4TiejQS
+n/EinmlEEV9A6DOoYo93PtsE2Y8IOgYxxy6Ygy2p+q7mO+jBAa0U87402H+BvY5VbIJ1TvDZ0ZW
fPxbkgNtr1vAucNHTKjiDDnqTp8317tBdIjQqm7Ov2s1aNKa+oPAJaZJXOeHsqbXRhyAGvOivlrz
iJQhJ4OlX0HGTbLdZz/va5b1RSFatO5lgUbR5tK4wKLfrlmjIWZymwbplpU5h2/dE9kojzsJfzEw
jVmu+wmmevHH5SS8zV8UHPTr1aNv7N9ZlZhBc8/lR6OnADbgMuSHHeVzdEfVUE2WVMb6YRwu4aAV
m3fpu6gVJ2ubSX/eYf7XAnN2+BdKbLxfD2PmtXhxrY1tkGsFCy/ZIfOQUoc8HeNk0jE4B28/skJe
o/r68xpM4dF3o5PRqYooBIBtAK1gTCm0dqtB6DD9Z9RTI+jOMqwb3JZMJ6w4mB4id/K25utyyoUU
/CMNOru3ujeA0OgHRTyMvjYXedtLW7r5SuDHZO15/bSMe1ofa4/0SlSgaj1dBqWsUHiB+rme2qzC
jSNBOO899K51IGFtOegdSdRP1dnReNKhYazCK5ex49cVm2rwKizmWtm+jj5J/KZzqm3WfkmAnuY4
Vs+RcRD2XCjBlSCv/Up5fWzCezlylrAjyvbHM0iFGXTg2jaLBbAQ/qrdeHV3MgVwt2A9fJc0e1m=