<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvVkiV8Admh5qmCaqOjTc1DpR0oenLdqYUkJEcmxlSpXzyHTiJuO3IWJKdNZwXQcfi8FqtzM
LLcWyq/3k3GXiarUpGC0xuX/KT/hQOHmQX4bxdqX9MjVrgY/dQFsD2zNAmU6Hdm1wNDLndW3tbhO
6QRnW2TTGPU+evcuN4eZYsoGAm9ZonameTeJu7WZxeoM7p/XJAxQRRT1aeSuTniFzaEXXWLGGgpp
ZdQ1eAWCkIJ6dOeBQ93UXgPkXgCF1I8rk1wsntBhZmjDvg/bOO6oox0E1sx/w6LjT0e3Yz038sJq
7rDL1//CyUXreCGOJ7b2UXotmVOMgrVA2jDh1Taw3eIlRffbppXoh+joFgzOD/KfJ/j+ksT7RqdF
zYtJ6bx/mENqQgkpFVmIm4Jw5xdilBXMf19nHdbm8PVKT5nf+iws2E2+7GGL9e3TBrDJJH92cq2S
OBXHbNY7yHJZ+M+kMShFJI6Y0eNzVWc49Rzh1gUDZBBuykJWEo4/+28i4dmLE/sZ9O6E2zn7S8aW
DVA5rOcQup1vKuEHb+huuZ+Dc/uLohTEwPBLLGlWemikvXGCX/AxK0qv0uRraKOztsmJ6mmEaYoj
bgkgQP97KNXwVAlxX0QJqH1wB5SX8n3nMjWnQJRgk+GE/rrCaNX0chIGB8RS8i+0nOH74vUcbLct
4ycSYE8ialWGiNjZEvggtx7me76cu0MrUcMS08+mXc86VRZcSo2plStz8wa0ABE5hy/UDdwfVgwS
JsHdzNSsR9qdGPlPb4B3dwPydfzuBSbRVzFYzlzYV6zkKVG3jQCJHMzbGBFe5Rl9CgAuZIWPSBA3
WidznTVHekB9S+slvvwBfjRyovOCDtC3Xh0AA4TUiUYz1lJTQeJwirx7H8juIhYNFK3f3o8qmJrt
1eg/mujQTmnqVrPUcZaYQPtQRJwYShOewsPeYnkLQO1F+cNW7f3LcmYmgp9eMKE8Rdodg0AVk90k
fBRkN7yTvuGGPn2dRtwl5y2sapRb2SHXwu6e/ZLyJCdu9N2V+tRXnycDzK4bq1sUPtfcxy3+pdm9
QVFuJO2XmXeTof1ltyxnxJisqnF+pa8nRt1QXORsA9oUofOwrUmgrV2+d77/2qwZTD46Cd5amNRj
JLcSFoM1ZxQktscqJa+ADTzmYRtWoMw/Z+0TYNtStIGQEc4haMJ7hJTlekcUBunkpDfTPiYV+VE9
1mHmpzrKNPNlS1WThBxLpLJ1J/TKzWp5Bv4sVYTcBoI2zgQZO8qAVBkhMmIgZOEWEOqpJLj0X0U2
4zX+JAr+0WxSPMce9MY884Krkv+QlSJQrJ0TuqMmpX8Vm9ZIJ1WYWuUrjzxA5/T5zow+Kx4QaXQT
Ks2ZYJQCWpwoG7yrf/WiJWjKglW7bcg/EhVP7ZeuW7mjflaAXTdBjNLcY3J01hm9uTCmHkvuKmwa
WgoR5uN2Kehho53ZvlQ2SbZPd1VOR1/xpdr+CNuEy2PMCApIYjpk80uJclxKCTdjXQpqv7OmQpjP
rX6hNbeA0kRUE7r+L3xwY61+Az/MajFF6dAHNAqaiEH75Fyh7ooer4uD3i78IQcNpnwQ35k/jbzk
mRtHyRGnvsA9PEPpBSOAJfvbFJDTS2SgEiTJQf52FfOTEvywylB7maSKJIjM3WK9bnIKrIF2mrDl
j/Qrorzd6v4QZ+zQa3CbaOv4dX0mb/nasCTW8PTWKfOXu7W0MIX+445yxrf0Obh0DmJK4CawKGEs
wFU/XUSN3/poovWcwPBRQHy36u7i8N9Qo3rDFmyIoA7FWpYBtD+9Vbb5cDZOuRVlVFdzCsBkB6bc
jjGbrmL/QkO0ndc2ByA4xfw0N/2FW+JqDOSqav/rgsrXnCtTKn8rawPywZd+pg+5B7zjenQ1ksHW
RZcwSZhWQlyCzEWzkx62UoI3jgEe8Sn+UAeM4y7fhRxwbu68QJCYRBkNHZxVnWd4oUsBis/Z0NHf
RqHoi7wHrBC6MnZrPCI9Vv16JLx9utPyanU5c5WIyLBDcxAwZkkc34inUuH/z50jd50NSWTFsNWT
QRV/ElOsRzRrwoiaZQoLgrjs+dLV9rg2OpaiTLtIUaIZYlS/aATQAyZfSdX32W/6hynZKY4tmNz3
lggYWI+ejdFVi9m4IRr825teP51rm2XcA7oQZ4gb7iGtV7bx5C5RiGtZn5fOe1VvgBt1E0R5KPKE
zRdHL38bNs3mvu8qTNWdUT2mm1nWVwRuSxEWbF4461s/PSQGFVlKbDd4Cv2APwMls13/zu+84yhA
gh2gwn12eVcOlYYjQDsL3PCnKMwWzu8lufscUDsYW1JYsB87hZ8n9fbJazlbuLxF0hV6qKVS2CHe
rFOEGFj5qL+LTPR5atiENQYzELOAG4pTHOheZgflI706Zv3B1m9H69zUioDJ0aVDfyEuAvr09Exd
wmzv9Ju0oT2ivmCQQcKOnIJUKMZVnOITWMueyfCOsavlkHAt8Sjd88JEY0qTHxRsKxtWBUT2ZDgc
QWAW8z9lI7Q7BjWPZLvpRCSnqTxwoSxgQ9bWq94ORNBu8FBjR7A3ZuenzpxjxMqQrrw5vM5qya0Z
yhWL3CngFOuVev8TDCo861VrywjLKmBPZJLGWvhI6xfOhY7Ak7vL7ah9h5xBDInZM6d0h5IjQ62X
ft2nJ58wD1Qo6SLwqyNdvETByBhg1nXa1MwBNmBQzelIJ6fiYD25Acfjkk4TaibES6DLcKc/vfqS
/pBTJ5lVzIAXtEMGtTKbb6PErLnEGpWLHaX+RJbZFoZCTJ+syyxcxuflSKsAH8cvGBTcdP4wMWF9
qCdZR3z2Zd03m/1BDIlAfIMuE2uc1kLmt2NstRhMG/hEtOBc1HPpkwXMvIDYsdTqrCTVTAVg+flF
btj7/oQ+Y5Xe3k0P1ziiZwCbwYiiMLrOfFd6khEr9kaKXgx1tN39yPoA1Ql0oPTBa67g/flflH3y
oay/3Gyq2LHHdJPDpILEzweBbYQibctUpEY8WoVlR8r7I8hY2d2kvY9YRJzr5kgbAozY3kdXAorv
6Gmo+fyDAumdzSQIAG2odNBtfeOlAktDvgiPuKp/gEwaoK9YV6qJD1ZE8EUwcryxBu1vogvVeqSh
dWRZKSeeQqMnqunFuLJgoF/ESDbkooZi+LrDW+hVejSlWwDFiTv4BUtEilpVkxlqlBDSwRWFOUln
+EacZU6031Fk6JJTxiidoGo1npkgy3VAp0ixFXaXL4JEu2l5IP5WLAWSTt4NWOSa/Mx4DgqCDWpV
xnAQu4jnkXxlVCln21LI7Sj/CAmVUEUY5vziMfuC3SNx1R6JKezxqdU2Df3uLeyc477+H4ibBLz8
HgW0LIWj2OjtVqaKpiJLviP3D4NyC0MplI3ir6U+x9TOFIzC4gvC0LboLT4d19cG3GpPf13PVBsZ
9V/wscX+L9BrOZQtGrA0eH2j+v407OJuCfrJwZ8VgX9o2xKa2cJ4cY3PVon+fS78PnyW8w90ZjT7
Re46kLZDr1hK0t6tZiCKsnu6eNOtTqUo4ajvO+mrulaGBuaM/sBpyRTyJBH2DvcR8GclJK19LEON
zQ/ff+s/tKYkA1/eFGYSqQkFxPPAmQJE2CoN5LwnYyJX6iwLloGweA1pKJKDCEMHc7ILYN2Ub/hk
jQeo40ed16nvnXv8MHWIVkIQm7w1CvSJrIp/YcLuuo7qdwLW40ZnwQ4TckyNxy0mcbRTLDs+ABoL
b2Ln4VFkf4GbjTL8S/YMkYggVB2RBeOmCjRsW/DYKsq28F1o1PxCglkJAIL0Q7eI30AoTzoTNRbA
2kLomglHW+wjUaWx6W6WsUGd4kSGbqeCBgHa3G8TRvBB185CnTf0Frz1dlsVVQamHq7NB2OSU6O7
Wff0gybO6PuGAnd0jJvk6dm0Zlv75VWYW6dl2dxVS9sF1pf+Rb/IHYIgX0dJMrwCjf85hly57/Jv
X523v4B5LvJT4RWVB5LA2AV5SZGqyfrAsOxQm+e+GEVAiB1cdXA2IewzzkFS/bse+JyqQvipb/vu
l3JWJ7QRkzC5/1TWiO3EEU5uIJj1wK00/SIa0yK6Lz2qeL0wVeXvd7Mb1RB2LU8Jk2aPiV5LpFi3
HnwUpZx/XnxSgms6ympB2SSGipbh8Ja9hxiY2xMncKZC5TvAaqCPIIVfLs5/odaVngj47/4HQf5o
p1iuBaY9qVMfrIpW4zo8rN+jz3O1tLMogy6eBBcEZVGAfA5jApbv4ZPmazIGLAOuIw1VOJH4apSJ
P4eS1DhXVmfexIR5/RJMrSfICXINSXHbugj2u99/NXi2gRvJjgMVmDlDYQpByEAEcv4N+An0gnHi
zvExufnD8adqML+LD0/AylTRgSTgVADjxZK5NRpnMhlLAxx9THIk/RtEmA0fcQ/HWNIM67KG6Q3w
1R+0BWARKhfW6O8JoaDCDfXSVPLpatTTMPAUYEGvdITHDGqDkBdhSU1YwpzF8aDwbISQyUtPcc7E
9mLN/JXKma795l8o2hdP+BZ+iZewughXcODDS09KCsA0KYWCtJC1rg+UmDQcgQjwLW+w23BYVHp+
ShgOIHFXoRUEyBtAgQmeRFMAONJPD044Fqxt7IzxJvUzit3ynjfT7I8V+HxyjlEv5AtIiwNS2GCW
AhqabN9Eq5Lw6P8vHTh931WXlbTXHcRzgHvU5CEc7hS52gRSn4b7rg+SSnghZWjcOYPrlbjHS2P2
WAecnsjs5eRGP6NDFiAAXnYhLuHORh3wCFYIMVYZyHPy+Givxs4Rrrjv7aJWlfGRew3VQUDKQsnU
Grt+avp80HXZ/mH5CRYpukHFiTHcc3VvxlM5BSQ8+8FruXlaY4acSrbj12ZGZKijZrJuVw7UblV7
WVicsvUd8W+vc9jMEU+6jNyIwISMygJfRwPpCHSzEaC83B/kQ94L5Z/E7GGVTU9VUS9LI4X7r5DG
GwjCPsK/yfRLoib/10h+vM7HQPJdHX2vYAXZsQ9xTRdO16ImKDkWcptn2wVpaihWnHFJQcHeM80n
NhjJFwsEhS2NAO3lnLAFpKwdoJSFFtdP9OeLRdtHO1CzsXHy+Ua+fP+dHQXOkgwZO6xobMsJJi5K
qqzE9aCPePWCajA7q0QCgkd6sgfHSFdtWQ1wWo6YTxTTas4OscJ/qbMTwfbA/Ea6bMFHXbVEvJxo
dAGITwy8CeUkAVvrLffCGA6UOI5p12YUGSk0YqnYGD2skchy6+W6OEX07cT3z4q7b8BGct0XIApg
0jhxV0gZ/ZXFnpJ9ED7M8VoepxPbne86h8ooEZa6URFw6IgIw4gdMq8lCdfK+IPsA7GHf5Du2YJZ
BcZvErLiMZenvI4F5RhMWtRUEPNoB11sQurJ+wZz1ypJxckvF+EgpqrDLzXlmsxA3OFL1OrHyJA1
XH39c3eJgOOGFYoNTSL40vIEnSiTrvHob9eEbXjdH6GYaj/pmuxk7SoftLjyTfIr9WeqESMRTN6V
cipMkuPi2S6bOCLBsM1Bvs0rQEjRRnw0sMaENzePOAyb5rzfipC5NgjNQxfGkpaVbYbL08DYYOml
ZPtX267RPrVMzQbYeK2zNBqG3zF6PwXSQacMjWkvMOouq3bZOtFFXLb4PqZd+fUq6XFblp8k6pBf
3PXhRm2N/g0bwLmkyN70dfIc4wu8PrRj1wp2WQYQL05D+b/jTA6HWlKG7Xte8tvn/ouBVXnZNqi5
wL7reYzBlUObRTOPUQAARUn1abBX19VgR4u2J5RWgSvYjlvLKe0K6ZcDjMiPUQPlJyLs8G2T3fwS
akpg1XChbJvm9ea219RMYxGVaC2PUHO0tFWDggzvZW8JFUYqP0WM5EezyAZvKXSZ4j6uSGE+/znJ
UDgbMl3iru9xzAUQFS2fyHFU+guRX/eu8oF4sm5rvwwsl4VNtQaPiSTHOOykwCHwS7pEjDr98ITo
MI1Uz57Qr45uh31nu4ZiCH5RsdhrKP/N2lR9KsdjVrJXAoQTsHds3lPdqdQIwelDyjtwqSB1cj1R
eZzAFuI/e1vAgBkdlxOiZS26QmXXiZH1rgRACsbfxrVZQ+L6O/MyIVRoHG5iRj4ccygnh6yDhM/q
3zm/kW5xZpeOgjJhdJkr5ihKDdnjuz2mHHypubb6wwJeWjCorvHQ+8aBriAG6GZWYzZZdXD/1ft6
CGwCDwHboES+y+LyCHJWmY//SZd7zRAT5MD6dL7Auet5olITvAw2AP/xBk7iLymZTh8LfsWOswuP
TGA6i8yEXVf5mMjq1SGRgdTBHvzIfB6nvwj/bX5EFSowbVz0vEG5+NvyB4RxhNVFR6vvS95mZD+z
9EAKAsQfkSwsXliutEcxvBQaPoBGpN/vpcsdWVX3Utw3rV0+qDgN7QW6JytgC0JgXnIuiq1sIKhp
g2pW5q+z8qfDtdOZwOEEYQCw997hz6lRR5FmJ2af7fXMZLh/fiB8sMchsDmrBPRl8/2TRuIAMnW5
g1yUEDLCWI3HZNBhpRsx0/CLJnu8jlSEJU1VXq40DQLAVoI9NNlvK2GwETO8BVyCbkUmD7Yi1Ksf
/gf6iu9vD033prMEXgdlcAgaEzkXkClzOBRjhhf09ARp0zExz/jL7W3DT7bFx3PzBFY/Nq4Lc0Mp
8aKlH2RvrEfEa2oLoXUeHzwSL96dmyOTek9QmGOYNn5kMO1p4d5iX6CCt0vovNEyaIYu9iz9KXIP
U7LGxFlo3o0TlqDT/9PnVRFvKMzGA1NM3G8o5uYTUrQcVdf6+PbeQe6AhMUI4YLB882nE8KqN+Wr
/np4/qpr1/k1JH5czRYqRFb36MR5SIMWuzLR0C+ojtdHbyJ7ko/AsU1KkTtkcYVjvf/pqFCL/MDf
P/y8UB9tNQoIGbqsmOQR2tvP/pb+8pFj0CTBw5oIn/D+naaljYWqv1njmHHSdsNnTo/Ruq7w8/ZB
6fABaAIH1bCoULc2AKbzSFR/Xe9nu21oC6vkWT8rPpFW2pideG4ZVLmIXZ9Pf4PKFkLoC6PTND5R
TMT4njQq1A8m8uTJH0Tg+x0G6UiLRhBUu/3bX1yFf0Na6X1Nod7hwQ01xnIG2oqkzaCJyU37N/jj
Pkoi8vl95BIIbIw475XrqTz/AnlOPZDE8ogqkNJeHJSdhL1yTNCpEdIdGABvEz7cSPDnrkL3OTqI
r/MkFOENonPwpKUAMv4ppBaeS1uxKYRGPtWTbfTZMBrQ87n4gUEFujp/dq6S0Jh/wUErsdIw72NP
9h/vDqvd+cGEicdpdh8wVsGp3/8VkdbYy6DCoM2lFHD64RlVzxx/T5Gi9s2COP2KyP7fgRAetLP3
Tuv/kpZlO0wJgm9aW1XOIw8BVgvxEclshvEltVgsInD+bsRX+1U1Hytf3CbG/5sNyu7y3JE6oVcq
Z3At0ro+ofhZFRDkpx43K5YNCbveLRbi6RVaIP5yIowCeJFMX+LEHW0b6HxqlRsjM2AgmhEcDvdy
ywCDCpTaSj4/A/tIWqbIEh8Kon9/tkg2qTdPv1wAS7+V+O21V4NNJ5TtQ6cu5J5326zpw4dwzri1
J6H/gJPe0U4hUzMxysPE9/AkKikF6Y96CtUhYMS7+uThU2jRt+LAHYXgJJ9asxyvTBef6/FgclH5
rVtzm4DgQaCEJjUHe+doA6lfIsen0NaF50I7UzqfP9d7wpHTHm43rAePoXa7xl47qaSMIkXl2EmO
bx5fST3jTA8Ja5BukM3GqbWX2U7gORvR0q00pcH42TZ3dWbJW6Iimlv/Wv+PGg7aBevALA68U6WU
d9KQuTn10xN7t5Qa0nO4LTkzf59gl4LrfE8KBqfZg4944PBW2S0fS04m2wCgBqNYo1xplfBjT3Ec
e8J9ecUVettkIDrxRWpqDZw1AVY462OoJHowjnyB2hz/z9tPryH3WgKMQ0tb7MxwgViaKM/Hz4XE
qV19EhalaG8GDLg+8q5TLH2cfWRS3ljissO1oyO6dSWSyET8/dEVJqefRnmdLNIGE6Gg/f2/9Hit
xsrSDqTp2HnXIpjIiqvCAbqEv8I3GbL3O7nL9b9ddUvrhSsFPO0ENwLdpJJzMdNOscdAyJIeS85L
qtDeE5SGxQZ4pr45rh4G04vpJF68L1t2Cp6DcGPt7F4SxBC5EZ+fMjTCJv7k3h2GvIYDWgLlD7v5
XjdbOpdxq6Up55ldwRuVv5jc/meOqP4rV+n+7Z0XA/sXwBZcygQiMpxTbDHoNAcdC4Imz8WQLG==