<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxcEi6V3IGb8cbKbHEvZ3qsgaXTVP8as+8+upEy5DEkYzt7hESOvogqRd1CkA71YRLgaCqHA
V7RAgTziOzNmURVnKvgwooOGB+XAgOHjauzj9G7Ub/jqg/TdmIQHPKedGA4Jl2ZRhHn0XhVHoYnF
1k1FgeJDy8n5Z74E+9CxEg5w+Z+brI4Wgkmrtcx74enGMo21wQw8U5jlgCyRqNMIs9XzQdtYeaAG
2U6HH88/Acb91WzZRC/jGmya22H9Q7WXkuvVSkkF2qtch+LXWRBBi0u7Ribbcv7KMT9V8Nd2ZFIV
K5KMQOcU7wmBoOKoCLTwudpGDCpjAIQH5WWolk74KNZqFyMgJN3QQhjyHJqpX+2JH6sTongph2US
gdVp8QcbeFXPkNmNe+krzeC0vPAE/6UnUiWO1QjrywazBvhciGboN+fmBYw0qjsMN0bDL9RPPPLy
3r8oiLyWxpuJ47V/bs7Ks6fuAPKUqnS8Cz6gop6WyhWLRpzQDQkACnnL+WnrbOQ+3AVtUatiKJJl
Iatoc+S2AVJCt91UWaQNhdm/VLQri9oWB033bmOPPYYTJM5H4fNO3F15QElhCsGvrYAJvt63yDQA
KRJaWtGunPdT1gHZCRrX0Ttgb+7o6e3Phed0WinkhI4FY4niiamUW8JQLOO/IP2f/aMqqC4LggDv
YOrPvYL/lInRZ7hnphPCfVv/6zpwK2LGAuNWACaEtZc3RJ2SntbaOGJQrd/XkwszNkGY0pXtSlgT
+UkSogZKHtlxs5PU4oo0vaZGWcmQf27tBBQdG2ZeZ0jcab+w0HI/IJ47ywJfhzlvay/m5cOnQDai
6KAMhwT9ncDsJET70tM4AvhgmxtdXGCKB9W8WFe9Tft0A35K5+XejH55+/LSbLD7ZsNYcC+weLub
IAm7+2qB8b8p8JlUAZOnIzKF1B+Ck5Dbgevsk0DrJEbleUW7UxzqDDwQhK0qT0+sDIy3wZPWciz9
v6oNf+4WD1VcVVzY4NaSAGdIrrt79BpMU4ky/LqGT0OaWcQsbng0SlwN+4nZrFBXfLWu2Us9H0od
38uU/6miz0qwbj6C0z+n+lpLKkFT2vV/Dd1rdePeYhz5JNTHq8/rRNo6J+d1epaS0yqkg3+78CHN
E5yXCOZ23UT7gna4W8xO3OuJ2ZlN+HTf3eitRbQPx50NI5KnfrsOzGxXchmhDA4PmDH0AFX+JGIa
sKvc5bbxmOeW6qYu0gVMzS9JH41acE/UmqVOIXvJ9ryPtHuHngdyCIOb8dMBPDLG6iVZj6oRPnbm
+qu+k05jSgk2hZqhUXJ1L6sW/A28RWMXIrC9tl6O/KP+ocggxW0r/+dI9dt2j0c2HEYVNjY2sK6k
eYdDw+LQCjj6pw3uKQob48FlTHcbUwa3Y51RXUQcwo7SlvuXYFm/3/z2Q6xbuPcnEILDCchyrVja
lSQsCjdnMafK//81ROiBOYyHqe3ullSCA/SX9YC7jluD7UPGX4YXR6zEv6COt3RsyZzyPYTBkq6G
ZgUG1iJScP1ZSzXi7rMe6q7UKll450oxMrgHMgIQmiFzbgHbT/3KkXrhMG1NJfhJO1LEtlqsXt43
xANHr0qt25+pjwa820+89C7lIo1wQZHjwN6/WCebXuB6LmBuwGIMd7dz9GjIHv9+In1IYIKVE/4K
7VBEvtQ8Grg04sl/3w2Vn6x/Fxnj2TUxPslc+iDzvtYhXf2hvfsYhNRObmNE1QAWehJIrcC6Tc2x
l5VOk/PaHUTWQyOuTKWL5g/BCbO79UIiFGp7er7FTiiucc5c1ih7eNaaTMhSrLxOEcEiMz3UZw+Q
95cz8Ylf3H0ROqTlJPISNeAAeLbH6+J4R5XgY+XMbzInMI0JjwloivFh9Bv4A7kVYPLRKTIQtly9
Kb4D3+skFsQIPEU6qzNY1wawnVO6B7q3wxi/wh+aSpuQfjiTkuvoL/LHzdyjVY+RY69KQ9QFjvXl
f6uviinoKZIpA21ryaaenapesk9WsSS7vDms4kKkQ47DR7Zvoh17EF+rsPbte5/2b+tnozuoJvbt
pfgtjx3B8FOfinP1zjt7KsWIOqfSEKKZQ/AKDVTLmm8+Q1+aL2j2RQcU0akokQ2vhbWqxI1kDvz2
iMTwAeyWlsD2Qmo6ZD/Rd5z2ZCtP1ypFwYxSuO79+l9U8D9av3aSOPTIyUu2fK0vFNp2tMwj9zw+
gFIPqAixpqjTR+FE02FJHA1L+NZ5suLQNiwTRODX4OOHe8VBogR94SKvlZ1uXyJ7MFbj7yZcWIav
t+W+P+jMdl7FWK77FWEMy3lfWmIuwPYxueVhIwC3iVn2oKZBe+kItGwKy2YTer4sjsxfVflc1VmT
rh5Nj1bO5vJ/bjyOCNurniq5xVQJJ1+/eHf4/1eS57Uj01DqTu04AO3Wikg/RctC5FWhfT2Ry7tL
t2gfR7QOWsmgigO/WiSsjKFZ86elc9BAkj+A0/B0l39AT6h5/Z7YEInIiT8FpRiFqQawZATed/VW
yqe4U1wwMBzCO8MHx91EC077m+NwVvVACYP7/TM+p7gEaGWQNCBhMtcoSvVoGogy/VQtrcNbJczK
AsyuhakkIhFl9AKmXlCfqxPVlTzPR23gXwW+A2zv0NMg1PMxEN4zSq0bm3k5fPHgmd3GrdGIaBL1
VyUx8btKUyDq8Tx1r2KQca/z9Xp/a6B9/dixsagE5vCFCBm4dAk8CJbpFOXcDGBYyumkBrSETuO1
RS0CKuZ4oNHhLR3rQ4iFQJF8RsBt7c/IS3X+83TsIAV1qWjF+dZOrJHf2JldZuGLcsZv8Z9aOX1p
Oc95z/PWWb/8NMHn6Etv6l44oKTauwGbsBUFhWOLJSgNHwPwRBOquzPbbJO+2gSlH+zGXaHla1SK
VEwDS5rryJbc/USgHP/CzIe/KuzolVcYWbc5m2tyxWVqRNQRmhVmG3yo07wcyojEPBr2mIaoef6f
HGlCeuhqOEsroiVWOSFSiFXkO18bZQfYX6NmVysTLjY1zC7Aanz6EZZ43+YdJlK7fU65fbXzmCUC
3NsaKiFTBuR4fCU97zCbD0c7nKn5xBbVJOVsQ2x/rvNnAUho6wJuwtQtcZJZu6x6x2VQj8OJBMXn
o94z/swc6skgVg7RdIvJK/a09xbTjdnVFZJB0vo5T5hlByVTLUFtiQhTsYIjMFBf30acqBZtMq77
pGN/RimXoUwwU3A6lV6vovze2rgRaNgASVnkNsEja1UIZCgUlKzdJfvTagrjG41wfrUgS51H76MT
yJU+NyRADz8ZBu1wW8nJQ5yo9CbppYQrV5AbUAIy0lwaQVOSwP6Rx2b3PUnPAPAEdUel8t1fY379
i5h5O7zlhHQKEnjlCSs5byWkya6kWNZwa+cwiF3U5UwIr0vgWgnyuMeYmXrMh4qm+xQRi0CJyPv7
NuV0lfj9eaPhBsPqruJnEACqv5DvYyY0JFPRrcO7tE03J73I9JuDm33iSgzICuVAifplRqRWPYYV
+CuxSquzduJK5UvZLIqS0D80pox3WzHhNwyT/8m/uhuqmg/xBpDbUO5WfPQapvk/UfuQmOU/hrQG
OuQB6Ub0ibz0hL6medLq0UzWCVW5vQkVANjtIro7p2Ttcblw+0YGVPOZ5MbzvtBAFZgIXKcu+8eR
SdElwz/wuPGzn4cfrJbwHUxjj0Jtv11xMKmnK97iTw1dDKsA5f8O6v3XVr3NEqr1BchgQtfTHhrq
Ma9c9os6zS9b8KRnq5oLKPhED4vbp4GnOMrCj+Y3ENyczInJK8D+vawDfy0PrQeR5jsr0b92sIQ8
CDW8WYIqW5Co5XOPlwXAk6EXaMjStlUQ2cdeO1JHheqbun0Mv5AcP8E7rOjbDfM+44zjLxgFqxiP
BoL8GQ/bMgijjDAsXb+r5pkhahTV4RZwviA+BTSWxj9g5bztx0jBrRIt9y36/x3zGftzd4RwvTaE
BcQ5gfsq9tlIrtqWmqz/RvhUd9Mtt3+2iEpk34yg9LozG2I+M0bVCmQYenkDGkdizyAGZ295pcTk
EBUXuiOx2rRPv7HGtim+QYzAhGLfPmsxduyUnp0npFlI6sEvgWnP0qYKdwELF/IgKWncXbzl2RFs
ZiaOBDidKbjArfgR/j7PQyRr92hiN8jQndyliTwrVFpFGl0eA+M2YcTdl+fn95MtD7DgkP4Vs8uI
RIy3ZcibD7d+3byt6/ezA8AR4HhnPNtKYlERvpkqsT+lKnqFKiCp6RO7s4iddmIJ3aSnuc7+GTWx
OAEone+sPSE35uY9XtfuXhtBsG+loQNKB2Jl2LkCmIowOSghBs5DpyvxE88mvnbuV4P+2IbWfxGm
SN6KXKpJ1s88Oz/2wKsJhRXLti32qbHQQQY1o+mYuBR62ZT6YVu/rqSs8bBQiewYbHVoppWGU0Lr
z/C09aAmqgoreAfuvCzGixrlEUSGgRwWEgx8VMZ299+yY1FV7l75UEvj4xRl9XLHkrQwobjMlWzz
9vGqoZg1uuXdOx4nirTuvtqWXdsnhAsKbrj2Ffg/IJVN/rRkPxC9e+iFppCPw0OVf+WgueHH5l5S
iV8QJkev31WzzbsSd3se6fvlerhWEftA7kMtlwwiguiKP8jJUNfEYXadJg6qe1kGqzukUbTR0A84
NzWlYyM8woXrb2p78dJvLhej7OyO/xpUI+Yn/9K4tuGsQxUjrDHc2p9NawVEnDDLqqINZ2brAe5A
VjockbMb5KpXiZ28XgpWQGrKsVVcYWv8o12QmOJWXtDzsjAX44XNWnjD2s49Z3LoAunsc4TX45FN
qMgvNyrLpd+5YoBYKcOEKLMIvVLp4KRz9DOIeIUSIkK0FZyOSaS+04fF+hzdsdM3Vcg7vjbSrOQ2
fv9ak5paB+hvL5lIWrQn1uEWkxWYoYA3HUUPmuF50BtBFGmQdFEqwgtko+jv