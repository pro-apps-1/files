<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtxua9hnVsdTZ2C5kMRmGDWhb4929Z57EUmInnvZ3WOEQS0jzk8aMuc4Gb1znsbvm8ehK4oK
vYGXo9RQupiROu9H4XGHfYcZO6wmSR2oSuCZ50gTqgnkPrK9cAJATXOHMtQ17Pd2CcHuwNjopCTH
fPhkMAzB10AhemWxBegAFnQAVaTI5p/lvNsl/rLsQiLwuBWXI5u3xiQvEmw+b1ONJaCJgoehajpM
cfpC/ViWWEtwOSALapSxCvWTLkJD3sy/NLoiWzErEFPCywQ+/z1G38IBgI9bZ6DB9GgMQ/BNcZXJ
hcLfDpqoZyqZiQJPL647Ni0VkZs5ULR8bBHXfZl5VgIbNgKqwFmWeqe0CKIAR+iw9rAhTTgUkHAT
DcmcZ5rIOhCAzuK+8z6AIvj3E/vJw6L8Wp0AUP24EBYOOmfJueLHvh+C/mwb+AStnEr45xSOVOdw
9e6UyTVY2i94fyUjgts2lxUrnzgKZpaT0O/JaqeYWATyGTnxh43pJDdPh/lmNP2rhkK/j2eUSVwh
j4IqNQjj9DSXk74Mn+Hgs8JuNoNDMpsnm2ZIpLN6QvU4vAkr0zrrM1Vp7op7X4kAsr6PaAF+xU9j
1OsIDU8GulXc+gfJe0iiAtXKKMwdKuvfms5ccyQ9TiF5tv+kArKZEVyXRXSqsMv339EvtmhNhl74
AUFjYwhTsJaWyKU40z6weOWcuGTNycJfoDzCEEoFde3kuozGsCIDp61Uh4Zp+L3uzueBDbe74XQ+
d+UwWs5tKcAT03ekVOcWCI1NX2PWKjfUwuE06ABlMyZKhVR77QtY0tOsqapeUXpsBhoMkqxIf5wc
sCIqivEFb++vPGVoXZO5vNPxHy5dr+dZIi2XZ+XWtdW86drwrcfVTnqmlqlTGO9RiFVOYaDlsosW
Xk9vPZNWVrQWxLkbFrTdU/BuiKglHiBN0m+ivXzbHiJwbVz8ltaJ33z2pagLIZwnTS36/gVBRZlW
fG1waqf9Pka5HWnY2ZvXZfY8Wzuvv2k20bZqOcmJfbjdn6kTvKBofCuKnCGhblLdHjBhmQzHWomf
Ch0Z+DG9n57VeZOO20dojsL0Mvx07rX0wM3eXb5QdjEe9wAYAJCF2v+16oLltsstyJiGHRe5PLpi
6/jM7MvP5D7j80E2d8OACW2jO7P1s/kwwGSA6a5GDbWjSd8PV26eKJdoTfNKaG9IhLWOaQmrgL/s
0U/MCjcAOkCPXYJUEGM04nsCVUsSyC3ZEtxbGhZpeY0nXY3coAFPo3lxvLqKSevWzOTRsZvQdTnL
elSNr7Jl5IhjHnWgaLdw+S0lHbwltrvHlf0318UXZyozoDGBA4157RFft2+3w5R4WkKxhMUw/sJ6
sd2orBLclYhdDS21MFNszL8K1DqYC0UPAXLa0QVyavxJ3X+3+sBdzdVxg8SvUOyTbm+48geuuQuE
GsHqQ9DX9LGcta7ya+B4j1AlQnzj0zNEv6WV6FOwW1Dk63VjQHvl9cmnC+KfXkieuI3NgypEq5te
xu8vLPEFombxidKOV0MOM1KqW/X5FSZt8k/Bq6Z4jMh+CwyomRjH06Lfr9p7e3NQT4KtYF0ONqRq
x20YghPWvASBFRjQQcGUz9OIBpPU5rZq6Mxm73j9OlXwOZ+qLvifV0+ndNL9QPnV4SBNblm6bduW
P17BOSYEjKJKXLbcQAwZtyOGBGnX8udK8vtb0+K6k0oDQW2BFP3oDryfH4CaCcxn5y6EN6VDdfgr
dv5/oJIkV2i7qmH4M6CGnnXnZkGTSbWDYM2O0Y7YRlp/Vz6+Bi0o5AFUHoBP1+vJmJF/7L+khmRS
XsiYrJN21NnR7Z3rQVma8kAmW105NzUFa2hbAUwzpSZU+F2LGFtKvmnAGFxvEt7DUuic+rryDpLd
TgrKHe3xKbk5o7MXSwrHuTIShegsgy0C5mLqIFouC+CSCqqnk5yomQ8/Tu6A4P71HBB0CU7Kainq
H9XxAI3EAkcKxD/aNHxwTvKN3qM4H2iXBie4AByUEuQl9+1ekRto/BoqaXyG2Xy4k05RcoRujm1P
/+NKQeTd962SWyNuujRCLCoIbVRP+b6Tf1uw1b9Uxdr1TcxEwIZAPD5kknTOSk4mA7QL9eV5aB56
fAswe5p14x99WraSr7qzK3Z18nLBCfIsQw1k3y4YYUr1CzgWWtIyOee33ComXDwHSZLXYGKWU45K
ANBiNP4Uz3y/dUn312GH2P/MIrJS2SEZZpYoncog8fXdY6BqaTxxw3lOHL4QIxa85i1iFzdmo/t0
NTHAJ6Xm9P0iItRgiJ/NfEqVOQUdDSkUgX0OdASVWZPAKsd6uI9lYMrMejamNdA4hT8DwMvsuTUE
csusluHyUstNjNdyoW91icSFh26esutWP3rfq1hscVzvRxydzULofJvViQbwktOSGcWh3dVzqssg
gB6/jZKVt9mHlkueCOe0mu4IY6m5UTf5xcOVZUy4/kahx2pSIU0DK+/URhwlDrQf/+DBcb0aA/wi
PeT0xegcjIHyWOKJEW8zqGYw4t7na2zixcA98Y1rC3Rbakmewc359nmbLSQYModX6qlkUIoZc9lB
4K7AY3y7azcn6A9HOT9JB8PuJ2uZuW/qfNixqGTLB9JNIQsgvYW1HGaI0n1IPC1tYAlYG3xDNlvE
NQcQ1FaW+trAbgkKYRAM/140d9XSRF3ELF44lngp4VOOp+GJ1vO82E1HeW+c3OcXckzS24Ul6xJh
kuXOH/yaNyep7e4dz6piUtutFLU0yNcFY31/C/TrO8VyqXPalksW26TLUgmGY+ps+y8YIgbTL541
SynPnoi55ECQgfscnrt3REdQs5fw5wtaa8XlY6PIQKwLJqT/DI2zT9YwkOHXeQTRxQBGEN0mZthc
dKV/4VZQSQZGvNuYOx7Usol9D3hPe+WKxK1iKIvlDSDWjTNf7tDuwKObkTPXpUyxEdGt2AoKnylf
ZQUKUfRFrdIuL5N6frtM5uibo9jU0bis8Yw2zJWSpASVmXzn2jez8+Mcks95taU4SBkDczIDESHh
KlG296sDfOia6znOXFx1uzIk+Zy85FOw3KZVS/GLD0LW/sBNfzmpDlLnLHh/IDC1cZaof5zyGaXE
+xwp7HExur4B4yHRqnN1WnMd9CTSDc5JnI0jSPmwbZi1zApERT7F/sXaZK+INP+bgNrqXGqjqBY/
0i2RPuDHDIujvp7iqDjVOhCzPNGfkLpVJoCJhYybKo053/ZsbLKEmm5ZoxYXjSqMNZe8i16ydGOd
O+PbtshhnoENMygGsGonSw94eLwYs3y47ansWiWTw9TuiVXGPTR7Run+KuDwChSE1CgDvxbkdKsy
CyhyQ6b/W6wXReTe+VCS2PSPRzdFG5hatdFEPOPpJ2KwkEtdAw0h1igHndsT2ujcIRTgO+ytoCQd
w/xMOLTfBTuqLtiXXZDwDuvtC25eoblIj5kuORZAC2pfR3iWd86CkFhlzFhOfCNzYOXZi0ltqNQX
zFjQGtAreDLl1+c5ZPRDUwKQshf/ycHmEq/r4JLGdo9KZcOdqRo62y6Fy8FZAIiQzjMmSQxlbs0t
bS4Veom6+4+kUzdT6qYVyDFmQ/w3xtE5nyDjQkNjtHalMnEjGwYATZtnXxzW/ldPvo59ZVRCCQ9a
5SFdSdDW5F7iwha6DOMz89UimmuQ1ovT3Rak9bNN/S3vtQz7vUW29u/XiWu/gVjZ6KtWpbU6474f
PIj9oAdUnZA5WqmLiJA+RSNx8MQ2eLEVPg3vcT3StHNnLnX0LFyBNmu0/EpggDWstd2IrZGc6dDp
QnGeSs7iuvMiEhuKyARGtum9vIhgnyv5vpYpfzpLg8PXpjS5/IMrnddFOCQoCYa6gpVDqyMDIaqa
EXT6lhE+W7wlMVhmA0DRWI+2dy8hNNfC3xIUmC6K67AYend4HzaNH4DHCU2uIExNjouj7m/wsI02
QxC6US+xq/VvaOleMkC2WALKrCwbjfn/yCyM241nsXcLztfY5/yRKTvjN/vYuLjHylS3GNq3XnKl
xvOw7kXmiG2rs/0M+0isgc4btROwZPKp+AX1asxnhomJ5P/y4vl8+E8BBnCjJ6PR1fnVl++NoVrS
SPwozzPGciT3BUM2tcTRekAipX9IrZ94hCdno6S2mGO9ka/bZucMpQlNA8Ag3cfEayD86RGGN8DF
KD4E6FtCZ8xdE2o5W3Yje0CsasJScsQOCxsRYN56TMxuHt/Uve9g4zY3U71VMnj7I/uCVOsMEOqA
TeLqsR+Ds7ErZua0HqKkrIf7nNQYo247ZAfES+RS6/eVBTPK18UXbXDI7FlhWDOvWaAzyBti+Ohm
XAHQQdOosaA8UbOcDl2s62MsObtoiVf6nJ7+VY9JMmN/ie8hUdcHrLA3hAjwwggno8RZBPxzjB8l
wr79Z71qgVsEKcJeSwtPxAs588EosEZqxDgnVD3rmIS3MYCJdmon260TqDiTUuZSUXvUjh/itDq3
xSMXcATBFXqfs457cts0OabYgbxKz2Aps4WPQ/tsXJL8PO6zWG3/NJXZtnc/i43JN/XJBpxb10MH
GZ6E42tRtym+ocSqzM5plsPyhP+p0SwFfejgoq6dEyjUH66N826I5vEFRpCD/sd8SsRodP+Rwf/v
3xMiRc1m20==