<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpIcWbq85dUIrNmNVfPsoOFoQR9ErRPhxe2um/GNBRCUgz7/SVtr/dmScQDMT1MLmmy5WY88
JL96nB4Cf7fr0aOjhAxKneqPfjY4SOgKxIv44tvaYnXbnPjfLKGVRdKgQL1O7cN5+gqS/PuWdD2Q
dzPwS0SkUdu16Q7gxnqKYX1RTSFjslHcLRbYCivXO+1icWjoLKUyngEDCjrQXnGYcYxy6i7HvbIl
J/ZnrTOArKklBZBZ0bQawwPDWghimmOLoGFrq6Wd/76Lpb7MaO8rknKwRoDeLvFXYIPSvPbR1j1Q
Y3flDjondIHKCCcV34JXFe7UnFttxwirpc1a7QBD78TsYc222Gi5nQrVYhE79go32NJCi1J6bxrq
Heyu2cAYND/9c0cKy/dD2m+rfcjMOIuI6rHUOVWsSXpdVMmIrPzHjITKX6ovBwEc9enF/gbuhOqV
FUa372S1OrFzfVkRd3PNdzpzqNBaYGmc9VngeU5Xh+k7Ope989qg66O4lOXfJufCUsKAFdCJl9mk
A3svSN026WAteE+V7SIvGBkgN9R8ZKQ9IMa+ubOuq18fWTy0p1MeIWXkDeY5QqjQTwVEV0HEvu2T
hT4LmtuJvAfjwzNfAXpFKkpMlL9oY+as4zwOy5B2e3ADFw5wvdR/LB/U7ewdv/A1Z+4dbuxKXG4f
Mhnup3CGJbD5phM+sStmoeRHuJ2DHYI3vnuOeNuVP9nWvOBweWdMln2FuKR1V8tbcJ7o11nSo3/8
CURAifNUzBP+3CAkF/eZY6/yuKbWx/vFaqa3zBWb1HYDwjQiqbWAU3RQlLodrJ+1L3tnbAwDscE5
i2j8Qywp7dlxxzMAaTlGmwMfRWcyVkxk9wlOfZtQ38Ahz7/s2DJw+1+sLwC8qiLpssnOgDnnUN9A
m3NTnLlFCKOe0Wqcg26tS3HZiWF3hzEshpdOTDHWQdAEd08Zp8652INGcRxbrX3b1AHnwt38ziba
J0dKAumFo9InI0hurNgogBt3p4GeYB4+z5ALL167QxGqjin1AY1V7nGa1tfCfd6Dsr9R0VC1HFFr
NzHZO89AS1LfDSojGFfsUVPg5Iz7z9Buu2yL5qeGYbBcDdPHYYrYrqma2Sri339dsNztyceBFYUp
a6C8UW2dcIVQfNWqNd8ZPpQ2D3Dsu7oUzyzwxS4rxNqpfTZWKMgfe2Nb/CL81T6jedjI0zOc13Ub
T3NReT779t8fObDB48LbYwmU7Kprq/ZhHfG4vQ5uVPxYX1O1AW9tpmkmOUGwzpUtBKG5xU2iZaFt
+GBRk7t9LvTJ/U7r1SJUwXs46vJJ1Av8xWQe1FKtVSB/v9SPzuSWH9XlLCtfkibbSoScC1F57bx0
MqYgoMI2I3lKJ+YDRrVXMzb4r3ejqOaNtDtQ8i1aIuvReKvpMDDA0owHLhfDScC0KV0/znVJvP/D
JhP/N+fNXvDpN+ZIPezO5Aejwt8ZX1wMpBaeS8Y9Fl1ugXX+GrcAkXjp8Bo6mPzygsddg3ioFf6u
FmeXhgiO+EqnAfQ4I+mqCycMHTonA++TCX4DcxUyrs/3jXk5/e4xjYqx33CB4iJCYkE7KF5vRR9X
Idrg1E+7OFNqapsjy4mlmybqOBA0OWWIdsMPiAEW4xopHe/xjIuX/YNrZMEq/XN38jb8BJMGoZbh
19NNvhcmtFCpKjzjNVFiKroID076OlspwRKccsAcOJqi97RPhWolz18WOfU7mVGdCY7pDLC88KFh
ZengM53UvzHg/FY54TmgLw+1j4Jh/XLBStsgK0HpsKLcbJew2pCoWodFxtrBUyp6iG32AMrJbJBP
zHegKr8GnnZM3DxysZF+I0ek7Yi7Npq37iJ3uC9DsOHd9Rl67vHD1YMUkmYxafCYzVkSV6niUo5Q
eMsTtnVOFpRV7vVqwSavjNWqCGD84oh4nYI7XXpRhW5FWgl82cawG+rwIS4audYyyvqG1+i60o2I
TXtyCXnJbEOxtxJ/66jKpKwBhV5wC+6bbDOqhp+1QUM9SldKTV+Ks4QWsl7RVtzTO4eDUKVRsZLM
kFZcvrSp4Kip3ETn2VOTOWeRYyreionDHp1h7+W3reZ7TnJqGLCCKGlu7Ntv1t6EOvSnoWR4d/iv
zlJt1zyo772zl82BUxIznxsnHftHpcVW1WG2Zw7+E62EZhOoVO1/dej4IEd0nQRrVN++tx0zJVfy
nK6w0RYEWFVG1LqVdcb2aFMRRd92DRM0J9gmovp8My2ypm9x4SFAPM2tBp611SjiHZI1SSyuDPEN
6IVt3ABXDnkXtcLP7TGbafOPiwxp5Q7TIvd0qqxFZSs1fJ9hy6jlXIyfcwG/tcxdUoMCBN7qTQ+M
R+9EA5gZfRTtesPdk6Y7ZR3AcLG5fi1dX28+ciAeVs/zBhISHgSgkgekd5tn9OLxRShoUR04qBsl
9odk6A9OZecvbiS4EdxBxrnWrzet6xSr4rpCJAbXNIj7FpBOZv75wl+eOLjsJOD8H9bfpUvojFg3
p44OKN4xUdfuj6h249TCJ6zNWMH3cHW4rm9vKLM5DqLmxAs08YkVb0vFquUC8NhTC/NqQ26H+sWN
sjfYgrAM4O2+B6SGT15dyg9Hr2fDaSMXUriOWAumaQUFjvM2LsTb/kj+qjOeyk/A5Wh5xnMr0eGh
HdiO1nfF9E4+yJyhjV6T5hbgPkrU5tTxc7DFqMNE2v0qkYc5eDcM9NeE1leGk1L10j8MZh+Z8Wex
XU5kNGcziHa+ZFkuacqS4/xk4UD6AXyYZvxy29voMH93UTPd9HunN6TjZryGK+mudg2T3x6MTCl8
PFUAbnm67aiJzTNdd4v+S65Qea9oW3S0f2Gfj7k+2QeP8p4wBCQOzGHXQloy9T6PGVpowRRPpBTZ
fdGiCsGCrFeNS9hq4hNOv8n7CHq5ElAaCyu78FYA7OyrJEH0JFdsBT65Uepm0DfyYYqPZjm2EpJO
cNqvShktfwTBjx9XwLIUlcbBVspxQiLokvNOgGfvLWB7e1GrTDbwE2P2mNwHS2PtDj4/8JrsS9pU
hWMErsKvZAuSOrBZiutFPXn5IwsXdMJDIkEr662wZfgOv/EB1V/vBvLavC7gT68drIKc8zCL1ka4
DUuMLEGnqA8tK8tsApIqpTPpPDH/9K0xZTNJKoFjWkXbXPmBGc7izBDso7qX6xyuib39K2X3HK/i
Q63igDCmn6mXEui3STSR5All41wr2I3yxhYzklh7GpinWn8OxfLSrtwQ+F8m6HsCSVtqlZ+3Lqc9
cWwg/AFItZMyl0UXI5lm/u+mTjZFnNRI0XcblBdJvbyDE9hdSAwYq2Rcf2OqfJDoYuLlCA8ln+He
dQRje8aOhXKgwcNDWoBi+8H78ZtRwrwYxtOZHryXy3Rx0F8YdaAprRoev5gzOT68GF4JSCuDg1Vt
gYx5QLPP/e53/ym6q6p2wF10BNKW5wbKVWk7973dCcLBRYLbzdWJYq8hv9pZzj6E0HXUiIxnuVFu
Zla3E70t/xkg8F61BQCWA9BVdFJA6zyNex+TY0PG6mN4t0YOPwObLRTOgpyayrI94XcVLfQvZop4
LbGH/9hVNhvPPbcvrR64rtzL3Wl1du5JYbp1ze3RjwIst9NFh8gROKnQ0AWo44Dc8IYriLL34HL6
oky2T9oB16Qb4hlW/bM7KX7wwvkLM6K0dY4liaXqpRqsol99ygbJNW2VPOd1H0OaHJQtTr0XE4oA
LeZh645CfOAkyVjI04bUwBBIRNo3u7JB2sEPH8kqoRgCDbVKXY4xED+K4em2Yy/Pob6qEpCpXIoS
X4QMbmE8HE9PiaAYiJJYbVFj4seQpzwBosPDTIuNfq5f6mez3hqRHco1QMSCgsswoUXeuo7p4+4o
Xq5+jaJrvgXy/79l+S7JQw8IYSC3iVTP/o9bN1JHlSXQoD+2+oXAEUIifTmZ5XvIUdQ5J8QNhXaK
6uKzef22PpiRIJJEgSmeNbcWEc6A6Pcqm98tV9fCeNStboBYDFlyBPqmIEFMfx8CrCRTVQSrTyWE
4ZVehYuJ4oBt6FUWvcHME3gV51cwEB0euVSNUzfWdBMUnxeFZNAIk48dMUazG4HUcYMqfUJ2U9ly
dOCokovTK4DeNE/gxUnOGvE5Z0TTLMQgyUsKP3MLVW8/9t+d8g4I3CNHPscH5+296lQcNh/vH/Xd
g6+KpUGrCTlZT0pFIBJdG7ihTDpg+6GEf1gNX7S+7sAVyePrF/uaVGtaniEY5/XuHhXJfZVZrKa2
arxS/Y40A6suilT1untSENxhas5MNq22m4VoSO12yJSllmrRSPC/n3C0+ka1H/6tOs2pHz3DAm==