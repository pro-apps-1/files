<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn5H3JS91lOur8oO5EOqJRQXNqEzR/YUPAEu7k+6MDzv5883uq6t1ZJikEztDszXopXOdoFH
j6OhIk9c7jOvXD78ZoYqAtl71kmAmivMhlRlQyDzIeFBldo0Ry4GBKBOR1B1o7Z0IHhroRhKajac
LAezLkd4+BKVvYKYR5FL8QRe8atbc1MHCKIGRqPVXyA2M0LZQrjNkaRGIJVZQl6D7TB7mD10od/N
FgT6vXaB3LIbQ6J5JJ7fWdupxDUAmvQAwlfx7nWRo2Rxs85Hakb8U5GQAtve3vzJLjqY5pOabi8z
2NaY/zHRtZeFjxBV4dBJ/YKdGosJ/jOvvMyr2kzIQczxUoyAJ4yjtE8Ydx/xy4deBP+NGlFxBPsd
6mwBmCJZdml/G4sF5eSL66DXfNamh1SKKwfDPvDNOUfog32QoNFLaFbSvaF3nmvI+3sp6HPFMWql
Uy3bS4/6FgpzNboUq5w0qBDEtw3KVpdZMjzOXcBqvzoX3E1i4CkjcQ5v+8bNs9U59/SSx4G3KWpy
Lz+Z3DdXN0wp9NauZNh5+1hBaWgJafVCLEShyVK7YW6k/amFCouOGIregolB6Z17W7I0xlHaLhpQ
YPFNbAfFvKsSW9mIiKvAa2cYu+gQv9FMjBS7nsipqLdLNos6VutpfMpY7omNXySlm7aX/2Wwq0ou
pIPu41JfDmmwqAbBlw5Ajv0Bh3WPOJRMA6NPhgcGw/ve2YZWaZ8Lz6FEqsw8+96ki+vCs/q7/FT+
JveMUVTo0eFsn/GLJKYNxb8EevRKSf3kIVSwqqCLpO9siAR+sdULrGm0ZyP/n4jG7cTXhDU+/2Ub
gC1Fq2XgtOphTQgeete9nlug0Lx/L8BmTOKWu2f1PoNoUA6KiULEmXridwwKcpfN0l/p/yvVbsQd
sWNZg1I1A01OsvXLijya3LNJcN9qAVE46ZZpsF2xV17dtoaKgDqsZ/3tvaVDeywhtP9APHYvA/OS
Z72MAsZNA4T6eo2F6G3Jzs9A/GuGRUPIaK/BSSC6rEJdqndFoftYU6u+lMVyNFanqJL16O1BhAGf
q1giWC02CwUQE78x45hEJx3s+qoDneXi3xTdpiqFtRfEEZZBRW2GMa3Dqzdx4OohEkWJoewKbZw2
4fguHi5l6nUSNagBc6tKTKm85olmR9Pp/PaIs4udVJSAuh6nQDFSBGjs+iP2IPlCH3iYdgRDDyUz
Xajz4W2HO/0SknfxEsMoGX4t1WBDY7QHRnIw/P0bcKtM02RIw6bW0O15C2i3xgVJVgXGCnNmdxJ7
0AjyRi05KZ5/m3HqwxgIoDFC82/hyW4uupA0M1pF9aOHdRin/xCIBtER4apkLzfoqVnoaCJKcZc9
Ho222ry/HrVOfCAsZQ74mICSrF2xqDdtdmUFb15SafO/pnFhEAcSpXa4I1r1npWe91WXOKex2pHF
vpPZQehs5Z1Ua0EPIaxO4kRN54UgzWdG8JZWTNCLoLpyr0Wx6bMBNE+nvtZoWrvFLb5Q5wb1r/UB
DTR5GQp+/G6OB+aZTF+i2Y5TQrTZ19xgeeYYvkS0kwepum4/zqrBTZt4nbClKlTHxHhpctmvP11N
MYS+12mFpVBM3r+BBlZIzN4AscEuq4TVUE7wQCdvWmiJA5fR5A2WR5tRA5KjAYJFRy3kB28Dvyqo
qLJQyGzwu/e50xG/75jPNn6xAgBog6aMHtuVPf7Pli+z5WxlXhhqWUnZ8eJ19VV2pIyRM7np84hT
xdl+n3W2eYbCNsMJXs0+n2KshFU++8o2sa9T+y/VJwHM6TP0FISYE7kuuuOcvlkR/YEbNZhZ78rW
O+rQOsKLWs9JVM5uSCCux41DrPRIne7MK0JmIRDSmenvUfEqynuuNi4uOP6XU49BgcF0abPC+Gg7
XxKLnsLnsTs28ZFqo2FOgm6GWcGKLelizXKBDbPC7C0FN05TR3FFoIlNKSMCypzykMlasWlwPIKs
othgKVBBRmZt1AvqDSOApNnkOWm7NCd2dogM/dSr8COSY7lclP/JR3A4vQUNM4mGnKS4SfZXq1d1
ki0l8+huVhXvnt/XMC40zYNy024O0enafaoZIqrgnz0YgmpHZtqBvZhD+Pzi3/pYM0W9PB+u4rca
9v/GYND5Es1pc2i76NVV377hChXUcqqo72r3rawHF+HOt35kwLs7ZtQON8huyBbm4Pgo+nXcA5OF
i4/E9Uy7ebPa28z6JNoEHAmi9OdK1jW//EWkLijBaHqqFK8FQr5DVMZ1r+WqLSaaeMOUnC9tUal9
HscNluZAg0XMSBA/dZ2qbW99eeDTFzi+Rc09snjprTGRsn/TeCCPzlCp0XYGHmMhFaKIdys6cniX
KEKLIS65jAD3TOVUJfvnHmYlKpXkBsrkXOeMojh15osteh+CthbIMRNQLnKAywQCq/tflr2ayHwc
K7ED9J+s1gFCS9Bmmqi0cn1mwF0n59WXHmwwvfAQVYbcdhI79s5tH9POZm2vIZhGhVDn5xRfTBxz
9D+gBpsPUfx/2c0j+xfgubvNj1x91od9RrAG/RhUCFiRbDNXoXCr2XFmk9MjVKCi/rW=