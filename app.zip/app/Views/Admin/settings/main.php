<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpl4J1SCTRLOoHdPDFiKwAIQntNqhcFng/AVAcE2/5Im9Mm+Gmzz77wgvVe8PNsvAw2sEPN1
hkTJoIfLHN3pZJGIizce2vICN3taRf+wlny8YXFEbIjRPi+XxjZbgHovLQ/uTVRs7GIZjjGliIzC
ObaL4BueKxSlBRRquvGtlkIiBaweiEuASEyz60up7E2y2Nt3SI7MNgP+dJtH/S/FOWkMTTy48TF3
3ccpK2T5kXNfMnPegtvN3Y1fenW3Y1tgvgDoiGUhdEQ0wVtC5XO2MZ3dohApQB05rsovR4dR+fzA
JsWR3/y55L5ubsVVkw66G40l7kj58CC3BHB9vdibkApAnJJStMN2+pY0QL3TxTft6kzsB574DJy4
jGsStb9x+rMeIv5J2vmj39uNhykevjKJXsG2rvy/frK1exPnqEEV0q4ZhgnVvXUop60JhS/GzbOh
S0f+e3f/3+W3GYm6LsiEwe7tdHb/tLfwlQKtYzcAg22jMGfwdbMC6Bl/72esBmupzkt/LVDEtzGF
r7pFvdVMHBE64VP6fe7slPoBUTefBwNvicEDT1H2T2G2Q8HnZlswfpHsg35YViUPvmfBqnvQ4F2c
bH7dXoy9AObdNnaEuH+MMiA+rCnRKObk+Qlub3TCbQ0F/se87m4ONkvdsg+ouOxRYnLPhOL0SC8G
Tz+MhxG/RBv8TlecYT4oYzXKAAl3lGWSJLqNWinWTrdcfI7pAim0fmZFVXr36pqPj3r+idNuFx1W
L314xIIDKivRnNpOTquwA2w3JqxmkQF0L5RMLkSAWb9B+VyiNZIOEBW8ur2rn9vY43T+oE2XCGyx
MahdUaA/YUJUPEerJyhroU8/38mRCWJFtH4/BPqf84oMC4FiCSe1QaUjIi6+FmfV3xef2erbFogV
Hx7iwbp9H0DWvdKr6lwH0JqjNn5spPtQjXZCl0Ok7cgXIW7Z6BoKbEstjmgTX2gmE/XA0a7w+Eiv
3bn1eMV/Kxu+fpIXVhEDLv8Nnjx/UAJzxB+rjDJzzvMSqNNESgBEvDJp3T217lBwG4l5OvAob/2G
tMKYbZhRdizIa+ODYTRk8+OL63NYEFB2CsAs+MajO0MY7+3h1kOiRcvmiBCEaeXxe8oVGDOQSpYl
ZLrSedX9H2MPqali+tYqpV9jbMQCabn6W1lWTkg/lB5Hy+Qe1WemcImRyh0oRoPAnjQUm5UYM+UT
VDrg+wvFl3JBKgnLLkW01jjOYsCwpkebGiuBRyzLJdiccSRGRS4xmjIYvaLvEjEskx5w/KFnTAHf
JHOiYMlI3feOgcz/L2j2aj/vVhvYkYFe+285pfdKHEbK7Hqri8aSSm2OhH7vz2izGKrMmZAlbP6K
lkkZjd9Gb9tnLpcg6WMmRhowU4Gh0RliKf8I2MmvEEaYC7SiqcWIDG6Cu0HYiNAw3+otD3b8wqgN
vGhQ8Nn432jLG5wNHseKvzdu7SWNzAea1hNsKgviePI4j/6AnpHFNIfzFu/XX/bIZUE1zBwlXVv5
SQYI8hD4BFqZbdLuWkzPA9G0ZfZhWooueB2Bl03OTnqOv0aiUeLCZyQBOF01luh5zRl9rSKpbShT
A9aflPJy5K8GO6icKHLARyIh3H3ow9TGnhX4W2g2/bn5Et0lI/hOYjwn1I0DofYzdRee2GrVb4tW
ecEIH2aI12f9NVesswwGAqCk5UmRdOskGYoeMGUHlrLfE2bCzmQgyevWBe5ERM4H55zLZ9vLFoBi
LHKIKLeozgTkv3Zf4jj5UVkYakuoViglrd1ffqgJA9VE4sKK5JDcB6ASW3yw3kn7ULTWLVKZqAco
ZlVZUEnaQR4eoHqhg+z2IOacanBhxxgWG4amgSQ4OypS6YRaoH+23kQ7auHAMrYORbggSH8RVO/o
U8UE7G9dl8wTImRhyNrEDR8jDLGX0BDMTt5RXCyUHrcmS/lg9tW6QcGgwG5+BfGU2eo1hWA2t/GV
zfl4odhfuFXXawTnPul4ZjXEpp8E3V7TGuZ5umiISwHbUL+pWDsf3H32DYBC6yOAhWAeSLKmzbKf
NvF1ruGOpaLGc7OD66gj89zp5jZU0HxDvAIvhPAPtPq2Oa1/VWgfLhWfI2JcbNXIpZqGM1nWlnl/
EOnpI4APtpbiThwAQFrXzDA57v4aVviwVk/eHydWAfj7RZ12MVlaI0+UHvVdwN+p+Dbh+xnHMrht
HlXqTI8SHYucMo6wQ1JA1Us1Us2RARRBA5NpV5+G9u/gcsXTLPgjM8lvZIu3ehyGKlzSuiANBAj1
kfEOWBMB2GDvAjXuXDNXNiUabocyN2Kx66+ZYjpf2UUgm3fqOaHkINxFbEZP5p5bSZ+IDUnqqBS0
kSWoFQx6k9KhHxRg+FCOIFLRGhri34Nv/LZ3TLODMvGh0d4WKHewBeldwnltqgubG254csbesIm/
s/thUliwlEqXsQKPsgzZuJtTBnGqnljlcjYH7rRZafopoiDUw/FEhI8gGn3wH6n0SiJeNpx0720k
DvKr23aNNJS+Ldy6GKnTtOIIVxBaJQYV8qjlw6GC2GEO/I22pzafrfKKdDTZMquk5+E8SfhEWICN
uojXYCAY3a4eI0==