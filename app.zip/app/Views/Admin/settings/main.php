<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvtGaZXlZsS/TXC76m4DD2kdrAsEUKUZpyWJ2gcuT6hZna/lEl30DOWXDlVBOVH1AX48UcBg
CXNukFSGLzLOGGJkwbBsHK8NEuGmLn6woMuwbRr1GPRhpi190ERT3K6dP2YtNfwf3vzR31vX9KON
5+2XOdGY0NwaDDgs4m8vyq82NXlNP1PZkOZmQYytt1wGbybL+eJIbSB++anqgP4o9eHODEs/NxNt
lioRyFhtffSJ2LsQWEKZAgrXCLgYaC4bzygpYUQlYLZlp2Jr3zVqY4o9JaqWKcP8io4QVs/btVny
/ZXqcHK6sefx88b5bHGz5vUrjgQ8FQnq23scRgSwFycLgFhwz36jdQGQu18KlqPVId4Ix89Tf7s3
65wmDF2tQkT2+R1Fjia/wg7XZUHV+5cFjcI68m7tJYWQ5yAUnCEfbYj+Mh9/d2tegL1/2D3D/1k3
ao/8hfjRcbljnSiGn6gyy2tI/Y0cV7TzCQeOpOEC/M/7QhbC41VESGh2M1liTfn+9IbRSY/TrrKJ
q5oIMMuOxkVImTXkk+0h2zPA3F3rX3EbKSHzBv0bWZwnIT2tuPFDvN5E5Vn4N8BL8DaEmfzvsCWe
yaZ+J2MRb7VfXBzkKDZf2u2ca2gCkPxRWsIux43iuBCuPlSV8wQcTT++KFx6NBqNySYTfMtitnSs
Na/Jg6wlNj7BpJGjVBHuCYRm3jj41OCoIWmHuAhwOhjldGP4ESrbgvdWmjQHWlCsMzd2jq535vtl
5OeVAKdbMApIBY/rBT9PiYOP28hYSijJjBFFcXmsoGeu5Zg49KiNaMDqGgGMad/Fw2iOf/0jpfBD
zfVPuDsZuxsjAkCE+0fA7/VSx2koRk/mymZgov9pNiRvcrp8pPhR/YhcpqNWTejtaksGAAR/lEsZ
BPOqfjpY3KJk48wtOqvW1eCvqbetm1jnqm4gAMpCfGnroeHVbN1x7w5FmDNJ6bbtagVeZTAoTc2g
k+QTJ9CbvjrGX9Fhr3f2/rVoQgZwbrh4E1fnxH5kRWfz9RqDUTSnKzvoHAaNlNMsPnS1dqm1AKO6
CMA0DaQzSYEEAC3hFhFwCThpcGJKjS27Q26YGDLnIHu2sAS+1Tand58rTCPYOnRMMqv6OXqlmxPu
2YgSb83PPy0s6t19Ih679gwSeKZNRXXWHdtf3A1BIneHXkLCSFYBZZfF4prw+qwaAUEsQaCorIWa
Lv2s6Irn9pigJY5RPyekf8J35hPC7/J07Ssx8EQAjuhXah20u3yXruO6mQ9XPEHBqxZELpWF399/
UEB3PNDoqrsfrEtsdXkYzL7OhIYrLM79B7hNSrnWoFbx4CqH9uGMCk5502XnpPBBT3H1hjp/OPF0
iWACJZOYboTvMb2xom8XRi75qxLhFSMhOp5707toPfBlrB7s31fIsXhOuFa2ylUPrn1jr0ZrcDde
iOw58hFJQKgse/Tt1BlEQc9IvcCeGL2gFMB0EZO2hX9K9USfqQhRV6KinS68JomTgR9S3Z9WTeSX
HssFEekTmQ3p1NTh/nrJZsu+chwCtHKVOh1jiujbGWLD53X4rZknSXsRDZCNZAjb8yn0ymLvFPN7
Pq/uZ6o0WhgZnnWDE5qGWjPhpip6BfecCmZ/rTW+S4uM5BPl/dG8RFam5zAp9d8OImeFFuOu3W9f
QyOMKuwNqw7wklUoo3Nwwtd8GlroQU755Q0cqZw0LVkDtizjmwTVZyy37rlmdKbROlcjdpRjltRs
sU1SwkC4YzmWW4fXDXzQ8wUdqN475aa9Nd0BiCcGLRp31KiGMx2O3hq5mZHcXK/G5ZegkqCErIB8
CDSGjxciysGI8fhwTO6GAfiU5bNFLMMW2exriff7HNwwnnGkFqFuuGq6kfJRhisKSuXFvZJdm7IE
CipzZ8XSAhA0Y06N3yxukRXNgKu=