<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoXAoYG42yyBqPTV1viPDoo3ZVprYWaoHhkulbv+y7LCPcTMdBBtN5hpJvuNigPxJFHJE5+1
ukB+cayAwKMzP2di4EqFbAFOi/g9pvomtmbdY7nDlhv3luHSz4K6/GKJiOXaBAcWFM6p7ucWnqQ2
9jYrtrMriUurl43Qq9fLAu0+SJGsSXiVZgcOGB/2Rrie4j6/SF7KXz2RrMUU/V5m/RicxR6+IMIX
sOXskQSAm9LyNCtvP4Kvao6jzX4cvyYfzPqCIdpduDuQEICruOA6s+HRjPLj5feGsORwLRm/Fi6j
+RfDxNA3Wx/nfljtJKwtfut07ojXjwIfrxZFOEHDhWEbg/ZvZdOrromzA4ISOwdGeSxZHuG9Bybf
VojXUAAX1Rf/daobCX325R3Lz6VKyq/qCbl8yHteUNx7zYDEZeLT0+hN1YAhYSUNUrb+cWMN7VMN
I/XPScx98ukF/XvEgzWl0ZyOrqW2wUOhxGRndB/JcwZl5An0eOedoxaGl1KVj2XCfGcBrle6FZwO
Opf03H9puOYzKbMuXXKBMsjnIq3EuOp5TYHO2SSwvc8NdSdTNPTWKWgBfneIE4plE3aHdtrZ0v/B
CU0DKy15fe1+/oG3o8to314XgB8tTxebEYyc0uSuYcS56YN/5nmumgHGsvMj91Q5hTkNaOTYUDWG
h+6Av1sCpy8ZBLfwEznJnvqa/RkbvJPQlgNjVsDBHjDfY9QzOXWd+a52iaUaXfWsQxEAxOI/p9EK
tyWmkOG/v6+mKwqee+RFOwfl7TPRB2/fVwKbjlR984hCz8tPspagB7yHa4UozSrygx2ZT7CY89sN
qGYEKDFjzOeHo0kiG4UvVRV+v6nTfRKVQx3ERseTUQ6PKyXNWLwGfSHR4viEopT+EYuFrgTrQMgM
vhyv88YOm0dFW0Og7rBEbf+91YyXXK0FnVqFuDR5i2n73cx3W2idJsN6JtoCdzfjffWOdNvTXeVV
M58h+zUUDlzV+7b030zRRokSSPNbvTYDmvH/l9O3w0PNNwe7u+uqCmRRZBlmnVs67yPjfcgkWgpV
DfpX6AOAN4ZF3AJCwFYlHiQ2ZPfI0X7Zeh4Fw4uTkDQC0RFc4EyDyllQjSWTlwQ/PKDuSIMnuIKF
yQ+XMSE+8x65pE57n3HQhLxVfDMAFPjb7nEoR/wwxp753FZta8ehO+NXro7Trm/lWAhR6TI/tKPF
PNnrRJIK2r2WErhaukPmAOOP3h/1uNcztu/+tm5mOOkFTUyt7fMmKZLcqu9D/ozgmEpVfDYAoyp1
9z9Gi5tb+aadDqbeOdfQXbqDFcZQkk9MdE9vD5bT6AO5qlPJ8ZO5gQE0ngOYYszMtndNeKUiPTM2
BdNySoYsRwla5szntxMJ+m5t5+XwJnF4vhiQL0Nw56hCHnOkAkGR0IXyuKWpTZXBtdfC0vCuzS0O
UoIvxe1RRx1UW3P/jEiwRR+iTU8bfmWKi/lVpb6e6krII/K8Y2xweM05CD3xjEMc6hv+jKfBbDXK
dCl8immX293SjF0psqNWOF216b3Bzo61nIGJagE6P9Fprzw0xpfXdv9W+H6RIOGdE50DmjGUDin2
QNCIhElJL5P6WZrp1W2EUOPTOzoWN90oA6CnvCxyRW0ojvWmGW7B+qJjh19lMpGsuS0X/7TLyeGV
ycwBRsWh6xooDIXeRX+eMpd/py+YwYV9LU1dyVULH6e1jOTEzl4Hcd1cWItVocVJ1eHetbyWEi37
1FUleWAmP3ueksoFOP5D8pfjXbMY+Np4ijZvB0gB0HJo4EDRWXAvJp418q7v56BoEhrppkVLvjNG
0IaZQQfcyFPlVTD7Lgv9lzjseS3OckqZUIz9Y++5hBvyWgmudnuYrLx+hDeu0kUon8RRCF7PtF3C
t3EhmmvESsF7ixkXvPvKkxdv2e3ciAi7l4mvDvcsu7DrXqoZuqTwCDDN4sFFGcYfwBXkuXOeuv9i
vYu+nWZepw3qTvC1Av2vrCLm1S5iDFgJB0XQSFg5W8r14JysVJ5jBPOkJb6wS5YxkQcy/CDeJULj
8hiV1Osnyed5rPBB0Nk8+3hINNxh9YXZ+IY04y9j9UB3jVQ2IfHhjYthtBLBC8nQseiChosUgHlP
SEmKgL83YeF8a5VQwBlXHvNfKPu6a6yjV4uKunrgX7uuWq0KE3dJ4g51gzWQjxsK/5ie3seT6UlV
e1qsq87JdnaJOWfD2M+evWLpuZwbNXLLGSqRtpWk3684Z7Q3mzqLRBAhN0Na4pB2E0xFvQ9Fx0mC
N76aMIzMRAL1hgnL07v1+49MLa2YnKonbg2NSx15kuQaqkUDTraSIyTcvq7c0i8tDnykeO3z9f+q
4SBMH2dyec9QEfdC00oTTU8ZBL/oyyXfSPuLZ+r37yH4ARxRH52Ig0kK+X8q5r+gyC0nULaztk12
Ra+jrr1PCQ7AN1jS/NlsNPgNjQ23YaB5J+assrfAUtxypXL7G31yvzY8IRYDXMEbYBI2DMPv7t5/
qQaukCAqB1BHjWAtmkfUvL9aLXR1pYrcLAjBiNBNx7Wlne2YtfrJhAFIkrPzgqIHA84xR+PegTL/
j89NXAy=