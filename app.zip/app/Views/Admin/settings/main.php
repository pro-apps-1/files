<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+9QrTeQ62uTuuP0+Rk46H2SnvBYnfzFnQ6u4bI0PgPqTE9eorFCK4iDKA2CExepjogYMJ4U
mg6vH9gCgtwkh7LUH0aFM3cslCvzJ6pu6xHT5YhGotd96ZYs4zBFyejRJGFLmWdIPtMGfPHt5JTn
zu8K1gnCzLWvSXwjL2sdAMDdrF/ATYUcUZybWcg6WcV+ExjHtfGq8X1q3eib/kTdHvqQgnQY5bwS
Z2q02jp47mJHHR3MmjKmd2ouLxiOtek7hzEWk2WvKiNl6PD6Df4hcB35xv5aWwPp8kzTLegkRd8w
APbG/o8+dWWwK/LbfWNOwvJ0I27KLcpPdYpfv4aGqVCUH2jxeXsaFoCIutciDfkhUzVMJq4PD0G4
mm1hyMvmNEIk+yYBsKqLEo5VrTSqpzQbcISCkaykWB6JRmC3oQ8TgN/NzNeJjEXnnFDjsX+q7sFa
ksXDDgwpZx9WYAapVO8CojsRGhlhrUnSsAq2+Mz0zIjlgudbUuz43OpEm5ENVaBmyqV2U7sbfeEp
oKFOkrCxb4nZ5+KRGdHVVn959fg7Y6s7Hz20hcUBtawCvp4U1CEBrJar0b8M7gHbdDlTr4EjGR8V
HoXOBk3q2HES59yI0EbtNK3ULpG3tIRCKZKRwAwx66LksCu7UosKjayu5eRaKQsE8kzkpA3OhEoM
WO7k7DwzXKtUxk+3Is5rBhKcLHWoekxB4uAEdFMMu9Rv6J/9n/mMVV2defw0EnKg0VUN1L/cYmys
CMVjGkG/KBUNwADxD2DZG3IqFRUEq3NxX/M2Jc65useTftBbWn/p1eb9E65CP2OMHLE08QhgS+En
erFekFsAb5raVz09bw/jz5OgqViFUDDlgk5OYjwmsl957dQFPf2oQCwgiyufExaCFPvm8M93DDP5
9yxYVGyaSMozd8E4ORq5VlGzBhngqL1aKZyzH+HIskXFfVBotiPfmE4OmYFf7sv9+EFztvreJ0su
HWqYHhIeUHgjYO5F9/zVPzHS68vp+ZXVRwq05xDOb3ukwz1xeWNzaEOLGXaCxrFuwxwB1q18hSVy
3WN+AowqQKhfSR8G9shKauVT7LRqFGkARQXIwCtDKIBNs7BpHiI0cVr8swgGYLMY+azJgruNE4z8
s/LwccpTeufSVflq/UFYoib6lXzZQ0Yje32kNETRmYkpp6Tc24cyP0jHeePcScvrMer4RHd4e1ZA
rX24WoGQhjhGbdER2aw04yCfPInC/DZfykY+8VljwUheUhU5gwiVk77en8Vn8npiDTxI9gVNpyAQ
twPBbFyGZyOwE3/adQ7aTYNUa3M76kBxrSUSApO/GOTO99qhadkh7V1g/ncIxr7SnpZLmP9n7cL9
NHJTRs/BolOxfF9u0j8ZwnW561ffblQNq7Mvr2ehrIAPcibDSoBGDdGphMW7nguJcmGn2JrVcfVt
VEHjt1xE0sYyCjwnSN/SKIeYSD0fuh6HoHeEn4snoX5jhxl/fWL30JaJEZ0upSrefWB2BnYC6AyP
igGHau4NGU3TEsMtRTyMdj5oomSW48F7K+3XM0MZ1REKcZTVsCRkXRSBuuOA+tEUyxFT9agIRJOn
mftNC3Lrmrdf+S0jrzruwAKLoPxHocFtBdXwvjwj95ONDNVnvKGPzGBLveU1cN/T5rjBK9Iy2KMv
ponPwXMvqwyQRYS6Iol/A56BvsaoKsAt8uD1rfjOXie2GtUKCB2FB4H6CRJS0R4r1x0tzgEtAmPp
18FOz9Jwsj6ULReI0+wWv7bQ/5MeC51Dgis86Hc0BR4vFQfHS5r6s0QQOkc/nIbAdrwY5gYFKhuM
1C6JIOKWa07mdTPhjgwUMJcU8+edYnW5AuBCF/qGba95d4ZRuIwy8q8ul0KjfVbgHg4bbg/sgwWn
h0TJklthBulbNdTqv1vt6UR74ZWWJ2legHhZbfoj38eSa+q8ZqwIeYYsKfcP9NwjBAJHh9CDG2cD
0HeW0QKx3hA7UcSmynBkZrcrEIbkcaRsOhXtn9MZy9Hwwk4CdfzkW61m329mlH+ifWRmp3iKQeCt
3wD4JmGGuvY/ox1dd0Hs8f3kWYlLZ8X5A4BHCVBdtPKoYGyipG5ydpdDPAWATOoBh6Ig6dEw1YcQ
jJCHqprIPxE50JApmvOqFZcj4IUkeXpZ7q/yPtmLwSD+0i24StZ6Dxk3R3lPYVOoXQuVJWikLxlm
7Oh5SiCBHP60YQGIdqHnhtKQE60XJGllJ2iZAHQuAv5ZW64dE+0sOdV7gzITJ4Ge/B2VDKqkwT4t
9uj4wnCskPz6sMXDCfldrOVXZwRhD0dEPbzaBl2bd+frt0hMIQjqn1H/DANQHplXlKZWJ1rD/j3W
CxbG/JKO6IuvqOS/3SC6W/jE6eWJ2E5ocg/TX/FJayT7GLPmNkQl5d0O9jtd1e/WW9Qj1/eqN2Hh
H2qwRgAoYngcbgpvCrdmoZZcSaPct51sET/5ELlBeaeKHuCcPoszkl38i9SZe3a=