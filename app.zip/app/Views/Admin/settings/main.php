<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtK09d3utvf7XSEpKy90Ef1ZE7DQkk5FoyyDsJzvEwipwZHpcsiAtA6gYGcce3MHkQ2oJLHf
pyOM28wSgd+K41hVhFWNp0IBpDpjMAhfU/ZmVGxTUYtxi47Ci8Qm0j7sX9WQTBAJaZB5tFWwejbH
+axEjeJwAQbNFG8ZikctVPN3qHOpOiE5dw9S8/CssNOWgfRVhDenSI/F2kOsuK0Ynoz5lG2R+mJH
ceLFI+7UfVBBAyS9xm6mcytyXInPwA/6IMGochwWm7ezVyeNcVDbdJI9JwJ5RwxGNVk/jS+ZTd+5
eWiv0F+np7k7lOcmuDadCT0OC4byK9HcyErnqfpmmke0P9OFDz4g/NV3NTgvqHbTl2kxR55hsMDh
8BvzVEVR7GDWy0RMY6DbxBFC1SrWSNc37s1MyuS0+Kdt5BAanxOWBPgCDJDFVcMe3ROx0CI1n2Jj
0u5SKMyUgKFvJZRdKdFqqwUZyxL5gp+eXW1BhMZNJMm3eUy/6v+exPoUOtnwm6XI3xZJx3Y60x4v
bOWhtfEDb6bF6B/8GUWR0R0pkq3Fg5Rkj+anBWmJviLUTr67UpR85LRg2c+K+Wl6i3jib2W8yKFP
x+pRWFmOvn2UQjnjXUDU5MXxEszUKyLCkCLWE5sNEYu//mScl9URz0zBhM8wPsLW5nVC8oKe5Vjj
iORDMKIE0w0D7ej1E3c3eRUHXigVvfrpf2EX//Xmip021au2r8/PV5+IJm2F+NXX/C9+jWqKG0YF
RoYVXGWiL8bWa0uaFVfAFte9sR7uyNwByBy72Gj5u1uPT4WsI3fULg0Ebs+N/o0Y4dfCgNtKfR40
AMGzMtPtkMXWKrX1HTiHeux3IWxoIUQ9Nq1o9jpbNvPFiDxT1KJHjS/VJKVMnXAWbqrhToLznb5p
xYzTOEkazTgZuWQi6htcqagC0oFMhlTT1CuOZX52A8n4GiPMLxdQXF8o5kzdrkQxbeYrhaN6VP3V
BeIlj5fWNyk/Jp4qAuqCj1OUdQNVv+sXMo1RK9ew3gU3TU4mEj3cQvEdF+i+lHRMks1oSwNFZxs+
rHtg4ap8Vl+5t6G9b2CWhaBJp6b9ycmw4SRMQcXQEH81wMiD6HPa0+fcQoJAcZC10qNzhO7B8PeI
enYDyPxkvFTjH0NEghlT/vv/zzpiDD37Bt7t7Vl3MrTWqeK6E1F1w13nYCXpOJFMVxhrq2ATz2hx
lWDP4tUREN4P92romvF4C4T3104+bMt1vgzcviV2UsxmrFpjZfTCKhoOmYJnltkpQ8zA9RUTEJDp
QtXnfBptaQzvqsBeLbdQvc3Uoh4ZEbsbvnxHaWT6LxjaRxTXCK/57lyquktpzzaFnp82QNwpUXyI
hA79d/cuhuJuHqekOUDENqvfFQY0m2sL1SXy+JvKtH2pN+rlHDmhpuwhKSQmfQL3EMrCVqYjj/Sh
kMt9rcfWsFx2zbnk8HB8tvRDRHPB3a6Vj1HBH1EZne4C6haZJ3h4XBoCFtz5dTBlh0yD6bv9NzWf
bHJ6KkukcDVJ6GHcXgoSurA3AQmF9jhGTjlYDUXCf0B/0Ikl7LBDtxgs0m+3VK6xXn9EGmqrLQz+
ZFNUmlqFpmzgmqzxoM5xNts73gUwTYo7ACcGq5U14M+oMal3lVG4q34Ms0j6lheQ9N8MQHQpJQtu
5gCQ7b/ysZeJ5RPGNGoBK0LyG5hP89A+UI2VwBrdkUxc+JzJemEI+K707oOiKRaub+VHIlZXlQSc
AtlL+3ZF5GWxLf6dJBHS/vgnnZMHfs+jfOkceWb8oYbhyAPDcdBYv8glWUWxMY4Xef2tE4CFYDtx
2M+y6uhwIfX7H1d7gfT/fxL4zqTmEw+5gTqjlo3uTBVMVzfz7ujC4Yz3MMc9zwQ7FuHOixZcl4n/
GYvWWyO6c02W3528p0==