<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/mIjH9CpGqb2T4WCQJ7D2uehmEQaXEYdecudq7RpARJgcD1QG7tzaH9agmAeve97NW56eC2
tWVU7420S6w3DLPZ74hlyGvMuVAErZPbATs7Y5WIB++tr8CNjuO9NRnxcYwvbznpa8H0eCuImPob
iPmehbrwy4+5rYe3X72FMaVRl8vE7HDXREdiKAxAoOYGo0llwEqD604PzjNYG8JUmwHP/X9ThUvR
bR/40iYovBStaDEDlrYKWyece3vQ1H61j5KWjJZsJFEcll/GK0o4YwaYPNPdeznTUGmLbNWEnwxb
AZbv/rM940XlL0PxGlX/a8I3sfK1Um5+pflTvsS6IrSRzp2jCLV1xN9XKtMTeYAaMicofBXnJTG5
J0PMSWTV02lgPxt1YissEv919FTM8xN5ykGIh3dL85QmliXX83Vu2mDpY3MeueUeVvNu+CfGYUuF
pVHeMYdxVIZW1KU5reQHhk7L6Mze7GIkHcRPgJMlXHo56FPtdGIsYTBXfGgJq9lvAcpY00z01Kgj
GFs2OWZy89Cg0gbc22EYAv5jLJ6BBXoFfS54fQ40zhnoA8tThZ+tmVY54jukXWe8NvqiPhbsAdMo
zC30XDQBz8Y/sI1FAEsTKbLX+jQjpe6aePXPYCwZpap/kFUtrzNuJqdl6qPGfCBTcqQO5ZvkEfr3
4xacgEakNygIbJs5HcjctSDccFgkZtVQSe2yR6XqL9SpJLJotDbasSh/vBtLoxiay8AYV4pbHbQB
ljhA170sXNFY3uGSD4DQHOrXynIPr7/5AJi3T13MpD4RO6afFZjjzgwRVQX1UJzCzrEN9wFQhLla
BciK+oW7vqb2gclD1b9CrftVgtVCXImnFUOXa8F211ZB4c1ox5XBURWQwDnWXqtYByzfZhRacrzM
zASH72UGrguKCmjfquJO7rIF4bgphxmFEiOrO0OVOy7fYR8BAvUArhiSORgXUbtoP2nCPvM08j5p
+PY6CpZ1Ig6MXjYtqr6xTGa1egrTKmY0/3d8hrC8zwfn0rLRgeCpt5P+T48sO5J3GJ6lHANmkPIM
9nFLEfCdAyOAUk9dzg0vJonT9Kq7WrJXUzjkh3yeN29LpK3bKOMdo2CDWxZJSbNuSf7BCx4F51QD
10panktOYpesWz+r8UcTXW51hmegUPyu86Z4O+C0mcgy9jN3WflLxk+ES3+pdsokQ5XrS7N0Amod
TDUn2WJtR2cvDGms0XylwNwbAvJOJMYuuuyNLJ4SVfU0tatvdjH+mhebU19ehOiQgmZw9I6MSxhI
aH56ryqFRsj8L66iEa4dE9wxDG38KghE8XaG0vngmWMnQYnzQvNLKcvufKVOGREKeFwVPUMG9K4I
u+Cj+byUuzlw3/OW8QEEJnNtwQYotnGG2fzId+nycfbz+GSl2yiCzd+vtnbO6GQvNfHxbJiXXu6i
mkW/4VJv/1+2pZBDwnZVIOt6Cty7B62zNVMnM7hddRjVXkiMq0kXCY6ozS3EgsXiZZQ45b4Qvb+H
jLbi4z+vTGeQJmgVoGgp3Zl08aPIrT4otrdhSInj1sPYbvFNUV758AKMW4XELd5zobrpFyxAFxIs
+fR0uCnedv2472F7poSQ3yNWY+QEH+g1AWK+K3bQcZBE/JLuoGoXFlUJyYU3di/LSvZ6WUNudxbD
0RkDnXeADyQpvn7FZD2o92EUED7pfydp6tf67rp4uXsE++RGaj0uVNGeZlyD07y9A7UNdeSzYg8i
nfARcmlJKuy8/ERE0BbuVdu7cqU7/i4qI7PpGLMlexCOnzQRgvt3vUGEs6wFSYZrOUG9OK6Q5q+S
VBnxqoUhwsEAQuAdApiBfVNm9wZ/IRvDekpHxuHa2UdjAVvmmr1winQ8naJ79M3pOoe79giBHceN
C7gyCVUlyKx7m0==