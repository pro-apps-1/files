<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpll6hQfRFyQkRGoZvLBoKb6erpn9zD6lRkuQ2BTCrtjIECAhGxGmMgXTXqQHyQnXf03bDAy
SmzIK0GYk8VI47Eyo5lWxb2yNspaoj9ed5Yp24WJcE7TnmdFwD0T9p2VDlcDlDZSiUB1ctVTXp9g
JZrKgw4Qyurdtst6916l2exC9ByVUU4w1tWiGxPVyrLPareN7DO9tSEy2awbXZU/8OCs3GLh4Ej9
6eKQEf+GKJS9LJt2W+x0+UwQUpR6pRQZQr1v/DTf3JtsYDJIK7OUWvKJvXDe8tMVHLPVw3kOCvjJ
ayPm/xhMa90INcaZgi31LN7q8efqhevD70Tem4jwfBwnshgrnyHwHkSLX/s1YCPYU0TXHggeMG/t
w1Jr/kBtKsI6MAaUc/eMlXre4HRuXE4+nIhw4DORUg8Pm5HV7ABOgpLyGIpHwq4tTAUhITZdHHc4
6NJFJq2j+23W3fDvARy9e4zYwgvp6DEh8QkAA082YmvIUVJVVkX/eON0QfA+vTeNsk0pfRrfoHw8
d8xIxRR6LcyiLaFM5WGkOZYlyT8ZhS+M1/1otOEkLd5SNRMBgVs+YcjUGgZ4kPv5ulLC29MvDD9M
MtFvnjnDeMfcZYcagkz84S6Yn8x2DFt3RO0IH4QnRHbwvt8vjAgsRceXA7ws8X7n6atoQF/NZkCZ
NzPSYD9rk/G1Frz6SvJ5TTmlt7QQVOECrZUzNHD4+ATFDi07lWciJeCxR7Qw/9qxolAhvkRXWGG1
ITP1LCgzR4QzuSC6oObMrERyiMDils/eeOtpiKH9Iz0ek9AgK6PXgkkPt1b9dQkLinKrfIl9KBnu
/oweRkcd0ePB9VO1Ks+ewi55vyufypsQ740qnRlOibK2/j50FS/v2LUjX/RLwQVvZWla3g5/msGh
OkbbCfaBKHb6vAQrjq+09wuaUIkHrcESOc0kZth9muhwaR5m8441VBt0BIjHLEG8Uiu21bURwpVu
IBrjfXRKjgFUusacLb3eReEhdjBmfvYfRJ0vR84guLNzaIoPFX4uzbXf92rLST7DVG5RszL66OVx
XKERalFKmUFSgV1jRyE3Hef9tFx3oz9L4XDaVD+u2of9Y4cjhvQ09J9PTsxjeF2CcCfCH9OLSdk4
yJKnvaa8cgSWLdkI8KmpjWUIpZGHLAz73jMgVM7NU/JNeeKEAGeCPJWwHHMxC69IYQDyEqEk9uRn
Gb6VcjNcg3+S+oMfEAV1iLj3t7fZvmjqQsJ+wc/sWPjwkK+Bu0doaepk5nsu10jpHf23K9yOd35M
D1VH4SG/tYNVDckW4FM0JP1G2d3Io7/0IQorB+C4OOelRKwJpiwXdbJGHHJXvn7dU0NlbHKAJZ3q
ryOuSMqHxixKV7aZtpEM3Vxh3sCxOoaEJ3zx2iuJzrrBUxsWcKE78w//akdE0XJ4Id+G3n4K8r1Y
/50zjNAuJvedyJaV1EuEzZlsAegj7XSQ4fhOgXghTyM9U3J5Lubbih+wqezuOPxcE85EYEzmAVrG
swdee761tljpO89y0XYAgrtJYAtx4FjhYRF9cGoymuRSrLIiU/7a+C+aFYShNkceqc2G56p/3kxu
QaowQwyJKd7s3JVmermuWirSr9z26saPtR4LLJH8exLRHvt3AL+zuMj7DMrhS72WJfGMa0KFOt1u
XgmTnMuup5IOTHu4VNaE59wGUX5IJUT2AXrjZthxzFsWatm7qpfpTfO+EI5DK831S+j9+bV1qPJJ
4mSzP7tIEB8s0rnq/M8vIg8rHXAI1wx+WD/+36IQlkv/CQwBmZYRpILTcwl7UkO+3P2Y8c2br9mZ
HzsJyOe/0QqMXmq7biWwVri8Ki7wktc+X3dXa0tPvqvnOSr0M2NfaPf/E4OLRvGnWEe7vDIiBiCs
ojq6mnIWPdE/WohJ1U++Ij8h5bgEiLBbNe9tjSEhzUpiWIf0Vm1pX8K5XkNOqETM0pHMB6aXC4pD
c7uZHAI9aGrKnNItuq34JjNKlCH9r08HT6swnsyEAH/VfmnVD+Fhbcfk0xnijj4opl5Jg7YNyhWU
y0JjYvu1BRtTBZEok/jlNl+kfyKS/tv+HPMr8lsfcqkVggdcadUtS/3JAS7eZ2wqWYyfu2qxgIys
6pJvhWa/kI1UWJwv7z7RyU0NWaTmDabHGwUx18DhUptn6FnHA0GZFT4I4Yum8fdpIM3DTX0+aaMU
SUvOyQgimJTkQBr97UHagE1WaafaU9Y5XOVpDk7j2BklToW47R5pvLnpBFs4sbXLDFl37H5dZirK
XymVvnGQJjMOcvaHt6GkvubDMg7Rlf7bY7tImUtV5GPkO0G+C/kB5Hd1TbnFj+G7SpRAKu2Pv4CS
Z6n5tV8IoXkruqGpw/cV8RSMBSHIAZcwEnZf6NjhE5nOu4bNZJRL3H7Hsx1Ub9bQJNI9SlXVzTd6
nB3E3ex7Po7Y5gaoVKNEve09ZChg5PB2Th3Y6/Qb3chRgqF8UKrhNsuuBnmqMvVXR0A9pegpS/91
6kycoefXOQH3yzJsg4zHmJvnT8QQowSw6hkxTcKl1q+oYiM2B0zeyFkjRqJ9pkKfF/bQbVdHj2xl
fEZSuib0eURg6IshVBXG2DJLHmoavCEUCZ0FaGtfzEdPMQfaQoltmOqBlELilJK=