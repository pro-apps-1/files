<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+isljfDgG8T2FKh+M7eQjt3OM2G0O+VN/rSEtRSU97LizXuyTR1DBUJYQTncZCfGP45C+mm
rL1gmkcU/NPF3oYqgu/4Uc+XmuWhAv3I62ZbtRNl6bkLpalAsWpFh47XVhFC/GbBVmx/ury4vzRK
w/ac1MB+DgcvMq+fSAW+58RSd3tror50ll7K8tSAYGH4t5HDLRrOW7sXnWejIdgZsPM/ViJfRkrU
SgH7/H1x/LktDig1uO4LNrDKVa0xGmc+BM9GcIeADpHZv1ITmSJY4lsWpyE1RL5DeepcvGCs78Zc
Ke2VAcO0Yh7RwP9KhdGzZmMmvw5FQAbLpbQv5HJWq7z6glWI9TrekR7tw9YuiF8LkMemUUXkD7mV
2DVxO5jkWUEZce7ElTwHkFi2gBIYZf3J0TEbCDCm93ebqG1AzJGg+bP82JAfmJHV/3QAtoSVse88
MosDzmdGcgGovavNxIEMtgJdunt21zXA9btOkeSS9dZ8RkeuValt8xdRmlnQiu5Am8gDsGjGeFA5
YHGaXs6eLq7cIVb06cyHtsAaZkbZZri+kYEfbwRi9c+1tnBUE6pszvox8zsuKMCaqe1YIYgu14rS
0UT9rhPuq5aWKRnRbp2oAoXN/IWcVbnmCv/sgml3UMhbS9i4n/nKj3BknHIswycOiFMktU7/wfdZ
dnH+A4QMN186Y3GaEV+NequR3xFkdMNeh0clHP4LYkGsw6UiSgG0qHSAiD2IHAoz4IXY15hGRD/d
8eKxzaN42izRidQ3cva02XI46MOR7o7bsH9PNNnCtkjKuro99X2p5CDy4AbVxSAlIvFPYlGTeIOk
PJMXpw6DOpCJMoyI/H7UjWjO4aBiizppn2g9J54OhDZ0wVnv76cTNjTnZcpHkkNO2PJs5pFz6O/g
59tQVAc6HglrT9L7BEasgOx/MjW4MPyqLIN01NXopBwbv5l9TEPJB6hCOSYxaMkNpqqM1w9FIOYt
Xq1g0OKkXCPgywrAWOQKVaqCeq2zfwET66mJci8cZMWjoq1m+3FIH2avn4L8RV7+GmS8jwm6Z0Rw
edQDQK/nr0bbtcBU90LctJ3QSZuKWLr5ltz11EHEcHhwg62/VRjvyhJ8tqOGrDHkw6/cmoangDR5
lxqzuKhgtcC7cI7KsuWTuocO0PJ7ecCxXfRgIBBapMiwMMTiLOH4yhfYJDKMQjtBadve1P/p2bJS
QPNpK75R+WWTDtuwzv7QTlA2nYKa0bIURA0UcKQHK6pkMgRtKGmljR0mESMtxqSnts9tiNvRYcNs
x3AjGaguwwATZKXF9Y6B1C5LXYBxR2IKywIpePOgHJHbP8WRVeOSHUqLxZLLS0CtkkHqAliItrF+
qxiF0x8jeRFDueMRBZwtNfdIow0bzJNIPfKYNrO12sSd3s49yaaVw3+EJPwZeAyVVktqbnZEbche
pLFFSDNDWeOml/OoFXUpmLou7FTBowinRr+4N1tit9Tb1RxK8LA+2IwPfBlrSf7nic0qfPLqtgT0
hQsYuKrVauWOvuLIMS0S3MXY2IB5KYJnyrs2EsNxAOTWWkKhgxvAyY8Pca9ttPeF4SA5m2fmmlNu
ggX7XRPIRNzmeOVyfZkVgykm1G81grJTfdQ7v3uOn3dAaDz1VQsPDbJ4W1B5VbGeM5K9XlQHLDlS
P2f0uRAKzIK7lrM6Esd7JhlLv8gEFmCe5CH9Mm/Unv4kEWv1i6iTRWFh4ksjfP8cPvqEx+qLoweC
PdFX4bXn6iMGl2HvgWvRPj0YeVRzTE4OnQ8fpkgFeLzxoaUj1w6f/2iZTLkxMDXsxk0E1TrgV0GW
wwiAkOA9m7z5KXzTlfLG3GTckKpEZtHf4p1G6so3ZU9s491fj74S9JQ7BdeRZC+aCNjZ2PsH5ZVk
ft4AmRgh1QUjliA6yYO3uhdH9my4dm+o4LbdaG==