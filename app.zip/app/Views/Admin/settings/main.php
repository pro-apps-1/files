<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmHL5Vzs3nhkyDQ8WDp8r7jpBVeEGiWkzuUudwt8Hb2W6u1gtLsx6GEhVK6dbrbi85FGuske
6VvafyDa+ctlLaGZe32XXiH0Z5QJd46iR2uhNOV7pifIwnW+nPN8cJERBEZ2UXwz58qHlZr2mE1E
OeoJdiRXIdZk1jEsEvEr28x7R+09q8GSGjjqu6VQJQzp7JWWs2CfG2RW1Z5eXVMfxgZRt3e/QzPM
4LaVWg5q0XlRGTsh9MuqnxKmy5Evqp60Fel6RjHLK0sFFSqLpROcz/6WCfnezP96SIBKPzzstO82
1aT48YEAh7z7lKLFCa2O2KAl13h+Zug5OPYT/pstXdcQ5OFughc44pVSlcdYojqCYc+6K7C4T2Ek
dW5RHnnUJSFOht8V0SsUOHoF5fnZDfhXjWF2RYBDxC8ABpx/LfJlmyH7f8mbnBC6sHhCYa9p8Yly
aDV9+5mQwVcKj7cKzD+3ulWA222mQBHJG9/SM7adHvnw6sFcDHANP8Sac0cHE/3R8XfA1hZdKbvz
liT3cArWhtOZCm/iPp/lOxMwvSicOGqg1WEjyJfPNewLRGDNHU6v8x/X8rQMEsfJSWKnoRVFsJBX
kmlFNXUY7paA3nGeBZqft2olo+MNtmkTeIAhrCGcyd+NXZV/EmUs6xogDt0Ys0q9pGDKC++DRphI
Zyd3idBWNse/doCq0H0P02Y71eVb9qv3mtq8K6YdZB5QClDnOduDTVx7/b3MawvhOHy97XeSQ9Yn
EIlK1QfieE9IHlwC5DBs/k60D4pnxP0YnI5Xhti+B31D1OMAAGzIwAzLZ0Lt8EX7aRsJ+x63r4wn
c0vepUIxKY8v2QUkMyNsymx8wpO1CNFSETZOmeVyuIk2vOdQ5i98YEmS3HEW/AN8UOjx9/yoK2+b
3bw+sQJybvVztMUGAwqjtZSI/0rbc0yxl6ahEDiLfvCa6j/c1aKI0M4XVkZV2it2EeEDVVopSWvd
jdTCodKt3F/ww11Hd+chfDvVkcRh8t12RjNwHQjGC8bfpI2pHK30tUIZuXhDqX/5lfYp2ij6cXMq
viB31vS1CX91373uNTYitGmouXK37K4wBH582xoGWbG06M0S33CakX4Fl5a3mc4iuO1RBOCg37L6
1xtUGG6WMtlZDboLsGae37RvMuuiHn8I9oRureNRwIMsz8VzHUIeH/g7Olr4Ca6g5OwbpfxP1mKU
xxSO6L2HaNW9mUKmNHJp3KoWRlxBi7lKM0VZLIfDSPrfCK2PB/lRzqtDe+Mowe8QVv3l0LIdcYYB
s4UM5z3uqcICsU4bfledtxQIRGfj3Gw1qj/hOXYlGOyq0kDH/uLM0N3S9vZbe3RqL3tOQsreJimq
O0ZML9sB9FpbR8mA0WMsAlHy0fThfv2P9s3vyn2H0jyEtDcrXzVqYTHG7BTmqVShSGNLL4s2icdA
Qsv1LoSWJQZDdwqdI5FHlSe46cHZniQT3FVfwdsuzUir8Yq4ztHdR21G1jXhSJexP655b+dj98wQ
YRQeE/TqmVP9ZEojfmVTxCKBaubHa1WcoqjnLA7hmq9x9GVqj5qEIUZiZMvMRO0R8rHN7QDvmd5Q
AHwVJfOOHu5bexiORruDImeCc4R/3va4K+RNFOUrbpcaOmXoNHjxbRyjosfkY5c0MlI4cN6ozz75
6v+XCSUSadTd6VO9s3r9vXGg0jhqNnbDUUadMpJzVi9CUhJ5qtBHXr4tDERXb5oDZk8KZTzgdQ+v
LLG3JsVmS7TWFfly/90fk6mj6Ed9ZS01k/KDRDOj3qInizhtvTUWPKltxn78gB6fv85Gs7WX19Th
QPTobIBVNEt6BKbCC8D9wMPCLm0sARYDtGtElSTlRwbq65u8kebFAVUUmlZp1e445otOlUxmlj1S
EHArT7e+GonIVJlVZIhI6BUeEMWNX8a7b7Z4kkEXOUm8/7G+G40lLuphrwCIeRuxe11giU3lAjiT
GcT5O0NKxFjz2Sd+CxE6hey31OqDhPQioq4SHmmGYUPqNbhMFx4hU/zhtpfqSJeZfymrdLqhgLc9
UtIZaWTWjUYBSSQsyA4rj9mhlSzzU+5t847Hv1WsLMt6lUlRC2Ch0IBelkzMBPBTTEL00GXm23TB
9PeEMVSRrb2ImAwE9YAHIJSsh6xbIARq+/1UUB++xmu4iw0ND447YO/EBnYo2PKf7LZTq59/tfzN
kAX6D/IsYWTYMEQaFV4gQr8aUb7dShll8RoZBil/NnUNEA4sPSCCOzqfkdWuSw3icjucty4o1jFT
lZCLm1DrS38ALyXDwHt3T9FrROwLqcWXasBbxss5RuAaYXptTEv0xXe1TmwpU7X+ys0DKt233VC5
M1I4EW0V7TMAh3iLWnn03r+HKuUnFd4UyasXT1ibjjKT5gqI+FmNr1kMZKbXOCBvJXKWl433KBjX
J6jdriB1j3t1ypx6HCk5Ob0n8c0mCPYROb6lAw/IbpvWTKLJCIoA3nUO9v+4kSH6WWp35xCKvH0c
nPlxWY5aqydW4Povg0Vnq/xrB4cvl9YJYPzv8kt8fV8cHn0=