<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvzVTyYbyqlWi9/YwxY9WOE8GpEi3Dg/ShMuWoChhNG+qqd7Qklvq+KBK/lw7rIUZNiSKYfU
LEC9YQq9QMv5mqJkVeBDtudLPA0LbGU8mS+TgdmUIGjXqtC6bRiboYpu9t/wHJjO6FBjYEZe9q/7
Qf8KR6oXojIFJwx4B0dddI3FeORrIYsYuUSPFkVkYkpEIVaItRuUJ9wYSu62nHEWrHGXGR0AsvJl
AT+9T6EIJBIO3jVagMFsRPDza/NPJssnZanjw+bf5rxjsEZ1L4EK3FLilQLmEIKsbOQlWXs/UjYM
D3Kb/p0uNQdRKh1m/mcGBPc2I42eUYJEM+LXGKjr/yl+XCZSrR96grpfMRFQyzXnDIgJVmsavJBq
15QR/IPCee3fvcnB7LxmatqH0CM17vXpQzl1YrpXoWbweG62EkpzT4gEZPVx7T97cOGs3ildqtUh
4WyTP8317rtnPUD1SXeOT+7Xm2kLtMD9LZFfSh+3W2WOXqYlXy9MdWGisZ5eUnCInHjW1oNp9OVT
3zjG0o7B/dAGbqovvbdrwN1+4kJsCW/gklCCWFu+pIj1S1/61NqwnZXz8eZs6E1ZNMPnAFqWVxrC
ioxoQtyNPlhkEONWono74Vn17Vope9GXt/JifR+vb63/voqiN5D0KmEWgBIpyM7BtRxV/bySOkAV
NCf7QiOKO0jUNGxSCAYtq3xQ0citcshRvy4ngdJozCccdZ//Yq9zrSIfHxcPzhQ6nYBqxISD7lYk
HJ9AsZjUcOBcddBLjoHZIgBkcwbulPSZ9OMNTwTa+KB8XrDLs5P6K/NlJVSUNTkQc1eav4JhndAE
J6SxnkhK3iMux+35OTdphmw1Fue05/vn7YBQ47gI38FGWtxdAh1zsf1zc+66b8S1sXAbHM9Yj8DM
3kdOoSeBGTQsfDQNJesaRXHZHnQAE316LDfgNKM7JwsFFMXJ1g8r9UkzzPwVCfqmqfLYrbBS8MH1
5AdxFN8KmVH+ZtS8SxnUldNM/z62Ob/DVq7kkXXYv3537iBpkMLcJ7SzQQNVFlKbxDzayY3mZUz6
LK2FdAjW6nLW5xFTD/83tqZQHfKU12TJVInM8eLunlVe4mAKc4OkzMGV7cSiP+MHPvc3hRFv+wCT
rd++88cqxa1UH0==