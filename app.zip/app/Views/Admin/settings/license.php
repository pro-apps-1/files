<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnC02f8WqewbFS2ViSKpscPoldLgpUvK4/T+99tDHccLKqCJozwz/9CTmYnF2iLjG1AoT4ZD
QG3NyUNclOQfAHFJYB4i1NEYnRI1q1eNzFQdeR69UGhCWa01hwPXsBTlfB9ZRch02tU1N/stcrWo
JqWtAQGMX74JByYhN/rp13FHaD11tvZ1eEjo/1/mSIwxH2z65TcSH7IIh3bX1JLxjcXJOx89h3Wj
ahVpnIHwUL/pxojb7uY7Hfa4eckp7vrxL85NwWUhdEQ0wVtC5XO2MZ3dohBlPxL3JfrWjSvobn9A
psWRBFzcJKTx/XUu38Wi6A/CA42pRgx+RauNqowYrFx+wMUGNub5OYMYxlJicoES9iYS8A4vhTjP
zR98ACN/4MxuxwgGTpXkorzNbEsa/wTeIi3ptAjQ3oLNmhPkaP+BsKO9OskcPY5Vb3V1TLbkxX45
EKmr851OYJrvhwaglqeladUwe4MDisj1AFvl6m2C3zdYMKShhn2a08LE1o7FDbFbJrLq+wRhTXGD
XP1tDjcTyNTLAAv+Eni/R+T1gxg26J4nnJ02+A07S8QrQRbMVF1LMTc8/FYfux2BaC7GbYdbId99
VkC53apHgMwnIYo2UX7RofYVoz2x7c9YOtsrASaFB0yC/nX6DkcqVWBAGNRr3h9dXQCrcKMu+rVT
NlQ4tfBUoWF3OfEwqR1sDj8s0IRiSSBxW9HIr4ebO4RY0bXKgHea6YldZ2LBQPvb7KqouyhXUbxd
1khkdCk5/aC7kRMfff0HFla6+O9S+F7roi7KmFJwbtbLUT3dMaKOJ44Eu2/cxMoIGmDpCm/SrePB
CVqj3u8P1WqUn5+pVqfubF1cTheBhUn7dg4lr5UynxK69IG4fipgEIV9PM3CCtTW9dINtklMXimE
187+ebfhxErVb79RhftT14D9eWRWWkggxE9D5yTUZFgMZsK2Ip6i6mR5QpKWmjt6oep1IFax0xAe
P0h4+4PmwO7mT4Kp8qXG8IKUhHmMh04aJgrZLelmrRpEzc090zepx+3kumKdTxhC+256EoKS3hvs
kgCsKsFFYFgkwlMu9Qkpvqr1qgqgaQTX2XZzWBrcbdkE6TwFOWuo3gvzqIN2pQ+nxp35D5RxI4JH
PV5L7AXLE7xH