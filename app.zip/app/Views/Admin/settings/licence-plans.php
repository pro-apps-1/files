<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz8p7g6YhEAMk/ABWZO7TXaX0cqzYBPAjB6uETJkM59AgahwNOcAsxzDkdsVBNcN97aVfb+6
ogmj85+l7CI9P9mr3aJaHgYo5X0eRtUtN5tBkMn630TAlgRaWMFclTiUzd8mJ+JqKVu/siPFAC8n
aNGkPKwmrHgM5QXZ5RChgSeBCHCas5rSP69/7rYwpXsL/zbmvb8rt7p+TVIcwBFAQbpKNRzSgMZ/
jfOd4Br9ygOqrACH1cIdyDPKmS17FQqBaAxt7nWRo2Rxs85Hakb8U5GQAwjdtqAmr9SL/04PTC8z
1tbx5SHCfkzVBdi8HlYHu97ggARIp1exlfil8nGO8p9652jnu6lAfTFqjRNEXOFQ4uEjGTI39QR4
Y7BJbVvUO7x3HLVfsfdfC+68A1LYyKXBAtZybLoggqerIaEGeWyfcJjfmpPK0+1fvKNvQVrZm8sA
ok+c/i2fZVzwxs1tSWzJh99OpCqR8PcfCOtkl2MeFPoIYW6ZVXxNHDl4/tHkyURmhQ0CeM+CDSeG
pr/UXtqIxnVC86XvNAKE2tg8ko4OMY1EYGccGokqbrVM+VC5PN4w4fDeDNAg/9RqvG2mLiOdEc+S
yArKlSBemPvUbjswdDaZzDbFfYuWaLsfhEn/6QQEQIN0FtOCA6mxqa2PjfrWQXVjlRE6sZc3k5Tb
UMb9QTUuEOO8/TB+oATTJfwJ6cuxw29YKMytfCIhR19ZZ52HiHxSmnYCp0jHMB9zitcOygIIVRmz
dzxRmvuJFUyNyXEYi5ci738mCIDuYfGA2pFgmwKK3IsaTcBTXv0U3WQgQ3iWLt4j+7r3cd+5FZRf
XDK+7V6erun8S4UsYsjASH0JymHVhe8bZ9hVQ5jjtdbotz/mC1yrfpZ8ByhT8rFiAs5cLxy0NdAz
EQamjIDnAfT358lzVPBdmNnm1NSU+jIMPIttbN7Hix6rAjsJaH748OlLtta0EHgTt+oQZc3mjRSi
mnWw1cGB/xMBcYR10nMISlymwutpT0cGhBYerTNdU45jvuc6giKaqOnJ2MldQgcDffL1juZRBvUd
fIQIyCIahszMq22jogwK4B3JCC2Z+hT+M8YJRfY6zz9KulX/DWdlI2mNmGTEu9UnTmI4jxNPksqg
T4KovJf6vv+DlU5LBysmDUYvlWRi9YbYmfHb5CDe2HfbxjfI+4XJXzAR6h1FonqNWn9kDQjwfLyf
+HNAjjvkgWiY90sBJmM+YHc1vaBwmfmByPWSYFq4362x7KVc2gZnRfKjMv+4C5e/N0ka4ZrNGV5T
seTrGBAnDc/dEAliIL5LHkKBEgsLqnKmg+mr1YZI7bboCXrBGSV9dIKCjUKXAm+GIdL6sutVcb9D
q09iOtXdM3RdFsWMd2rQqqaouLUeUKW7YzdiNRZbMssXJPaujm==