<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq0xcn8bb7ybCFeECNBmXfWYV14eNFNKRkmCpxvzJYJG4tXsWxDHbAicUzVi5YRpbEu3S/vP
I77PFGfjSb3u2HufUiS6MNrP5pZUNbUgpNJgZp6GdkHidMysv1gV9GSvQn4Z7ke4URDeuU4ttbVP
iZUFKDGfUrnoamBgGQCbHjs8MiwTRxzAn5Yhz0P8xf0OzzCIITNmkC6PfrqtNk2xhld/pnKbAmsN
vcnR812pN/G8nE4ANEQJJhsQAFAh3CnSCSNfVjn2WgoPKlaAU/XlrUmuabPDPt3MCnVvtspRkCbR
Y8Sw4nAeu+hYHjTCxd6LA6F/n9+wEfEJvpVi4Fu48nSgbUVWt6Y4aH0laVMs6EQXM+GozxJAmHbO
pwPo5/swQwczj2l90Jft+CT5YxHSB4nr4mgdlMyrGj4x+DDzwFJnJy3RDzbXc/XSsc3b33lksgTh
yBMlSU2M/31ZdVJmJjUcYF2WBUJEz0N4y9118OlUARwiS6EpzMWw7yUwJCF/ETHHwTqiYZ+JeoOb
jfU+JS2uJ9EY/AIQRxHh70rGr246zaSLPPGGFJ1FerXIJswhE+Fm9iBhn+74c6Ekd8BuPlisCO2A
XpwO9OoZxryvEh3o2z2+clFoWPXHW/0u2cbu//uf/NPGsamTTObL8vhjXc+0Ym7yEvOZyRpJkKmw
zKRKdj0lfQEv8La0Mby80BkCNy/oxctHOlU1nAOCReMgBGJNhMMxW41p0Ho9bwjNKdZsdHsca0A7
ifaDZKRyGlbgGtl+0xmmDOdXtgeuJHl684fMO+sB7TzvGqfFDhdhifqBNecGYsgebdXvfCX3AzY8
ZyNLpwfPargqtGxvA6fBiHazOUf+fGyrrjVem1Qo0IAQiK+A+QYtYjD7CG7+Kx5Zcmktz6NFQ/Aq
0AazpWDrLjLxD8i8Z4KUU889LQUa2KyVCzImmxR07+JBzqBaqj7wl/ii4ScnvC6UKG8mdxsqkXFK
5kFzL10fGSBn5NB/D7z+iod2aKEI7VBelEj3EKlVZoB9QhnXz3On+pKz5s1dKWX5fayeLTDQNvz8
PActNJWw30QozUEQzCq30oiXU7CjYF6mQdwIqadqBuQvbbeY19lpoSM2BL0rQWtkRX73cfKsWwwq
RPYm63aLLntwkhA61RBxu7jFCHR8sxS1YIuilhEFiws7cWcm01B+CpZ253JXof6CSmdjk82ZFPI7
4rGId2G4mPAIbZGgrZiF5e5ybyh6iM/n/twX2s0f4f9wnTBhw47BglRNAK3H5I3gTd+3zCEUveMD
zDYZky32A4gA4xF5YoAelNmtccwtAFYCdU2pBLn+Jj24Pyzs9Ixr1IU1iBPVVUeHSgptHZ1FroYR
11zwGfMOeXzCjDniOa3ExYZIsziLSQssRgGnf0==