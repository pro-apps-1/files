<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoRokqIrRW1hG3CkP/3xXXJ2hHmvyobEdAYuiJvI4R9UAXtmz2TiOMzTdVnBFO6EMPSilhch
/s2exnAlHSOqNbu3KLpVGiep12L8ogM0yAq9uF1sHL3xGVUTVTd5Jh1I6oYGA/boFT5wBcdVUaSc
Bn+3lLokXybI2m/0K/gEZjjAqu4OI5mklWiiGacSOyhFSIAOkHk+QgI0Npk539M6fKQdLPQYbo93
khqEwLvQVg8t9mg0r1rlTuDqRmoEqC0Ysfieyh6F55dCubCN2OI5/+0cyifZfHTiDR87FERuDaNt
a7ihZ4DGsELsiQCPz5Bje4kJmrwyS1G6LQhVCZcA9LoDGTmKu+98yCD+peIMLaKcAoBm/JYJ1cMv
1xt3wHQIUh7LimnER9DuFHi5VUv9yk7hP1JWV3SzQ6wq4EPfEeJd+LLcgqsKZH0ak8dtckC7KM52
UYLgruvahGxuWOj/AUEefGVhTuD/dHVtVL+S1M06otjdSXLjNqRd2E3PYwq0yz2JlWktQumaxStg
aHWYjhBu+JAf1a29dgQ2L8wcJffgRU7UYvPXK542TVfrvqSg7upVvKwEana5vkrBo+oL3tuaOokE
MSrUe/V5YNgJ8cdikIV/82E9duxc2+4xwjDWbhW3/2he9YT3H/R5Ii0EdliKPBAdYj8ZtCXYr/81
WYtqmRu8og2MZSU+QX/9w7Mz0Abs5VvIp0GACrCjyqvcZIEVW3iXjq5Xg1BUPuSgLY7ocj8dg77e
QKsec9VeV/5CZCyvsDmhBgzcQ5zJHg4BWlUMWMvMK80uaXk9RNkoyl+bln7nET1kqGcXB1+4HAof
mHpQLETto7x1UUgRwo8vW5z0WO42ZtHcFxQ9m57vPpfK7BhsfFVjjc9WvNbD0Zckg2UVRrN2NPpM
rbMEp6r2wW9ZwwxChQV+RcrXDXUBjuY10NR5l1c/8EdtXRwuzDbQ4w9WWxDoZgjjdUf6aJFrOXL2
oVMJW8LyTsjtYkB2o8NW6V/IBGTgYWlP+5ofNcBw28MHYbzRmh07zew+RhP/OpTv2/yG6VVGDR68
/pcvwhcX44Hau3vHh/DhEEYj1qeBYEuiiL7V8WUVoluYEY9kdHJKwxfOB7yW8FnUDfkaqfwRsMMG
JTcTtvUP+5vPzjWwhpQ0HGASFUXMu2atbZTdgGkVbQwKJ45odHFBPuIXk0zgymYyL6yrr3UGVITQ
Uf06DSJFhS35YOgi2u+d46ISuo37i+DmAjSGH0HExokJL+Db+kZH/Ot6DAvs7qksfCEYENvbjpah
KJlEoK7oxsvgSsTNy03Q2WlryGVl5lHXYLYNYSHq5zVCH/MPv3UhMieTqWK9B7aQ06pNufGxBcz8
TTWRnNOZhoR3FqwifOOFYZeAUvDI5pVPaOhNmlJ4o4ntjFIZruq=