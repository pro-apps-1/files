<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpX0ThE774k5Ne7Za9qXrmzAT9lhtSkJ4T1oko/XLJu277+WTNJ1DTSMXasrMOoTFK8II9JA
A3dojn6yG1nV4dcmyOOlH5jFIJR19E8XxbcTuALTvfc0hwQpMXISRGhwcs13ccajYHoHh082TCB8
Cp7l3K3+HEhEbU4AJN3kHTit7FCxeXoavV8NtMnWeaMfL2jWZSNXxja5WkTosXa2A+8MZclo1etw
OpKmjGh7l6sfqWT7QLTaJT8g/8EfQrMA7cxBWQIuw5Uteh406+EjATiE/PCOPiLAgcZodgyXxECO
/jeRPiJX952smBYdBqQEKgvI75v8mZ9aW3hr4OMvuvD/k8jwSqbvmcxBx68ZBR2MHxvVNBZXzOyW
Dls1RUy1vqAj3nmm4Li/+aAxaMio7lufnCLerc8UtNYiIbpNrIK6DtLkWNi/VtGdcdOAVj+v2W/A
3b9UgczjNzHne6Joljn+Lr1sUy1C5tQ8oM8DZ9cOP8nWy6QpbvtXjsSnce1TXKFgH3qojKLUCIl7
nXOeGiAV0CkUt/NcsNOLfgTaWgwI3hItW/fDybLVXfaUEZyt44gRDm+5RdVzynlrMR7BH6YZ5HXG
m2nb+hcTg2fTcxrebyA1XQrZ33d6wk+M2M4OUpVmkolsB1KmuD93DqDXDW2716u9JMi7EJ9oSbTl
bpvx0FyRuPElU0gmtmsiAfcWdImKAOvL60Du5cHsnbUviwPfmujIllxieusq5nFaWBcx+MVufRxq
7xtFOKbizZgUyX0Pd3D0O4KuPKuA7tDKSgzMLnBjCIF+gNvI9cnBTuI4HBdx6cKkW6kQ+9VxV9A3
osd/BBSv2Ttw5P1fJHVMnYnzEnkBi5UguDLn8U6WFtCdWg1OsnfBe3E3XSEIiEaMOXS/PfsuaQ4Q
tlaUO/yYQIFiv3H08oh4EW4wu0l7FUQZ9x084cbfxTQ4a3Gi7XMj39vOjdodEGou/EU5HzFeVDI+
f9GpJKhLLUdsLdVV+A8t107E6l3vmMnZl+zmR+BH0u+XfLQ/n41BYu6nT5tz+bOdmpEGpvGn2hhc
4Qi7tBwvV7JbJmG+Rbvy3Tq8u8ZYPDVwNn3pO1AwqzYrJIGBgxb1cvScsaj/L1uaQp90L9idm9w5
cDO81nsF3NUYPxzVg1fMjBcBDty5RGA2sOSaZ+ph26uCTJ3q1OU/D8+VvdhaB1Ua1ztyBVEwz79f
H6EMnCc4n7XnAExFmvvNO5+huZvGBMcy3lIoGgdtgoEzrKAsK9MDY6IPXl6bphF+1RXzttXT9Uvj
a2B+rz7FYvTvMH/ACw+6bu+k+9JdSGGrgTD9oa0FrxkUlXOvMhMu0rIsHntnmpHQ3N/MXXOEiQS2
MhpWkjlGA41lt60LcGGm3OUUVmsIrGKT9V2nB2GPvm3/gUEICBi=