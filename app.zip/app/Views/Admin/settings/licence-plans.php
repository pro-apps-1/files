<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn/lVIHbO4OCS2xe1oPV9nHRMS2YrCMM5founse2NqCVo3qfqxDj9zRE/6kiLRHuiCLeiCpH
dxXdR1k0JAWHGw7BCpDBl3ffr9rIDCf7+xWeweN7ap4neoUqRGfiKnAaY1/2DEWft5dsCwIKuna3
qeqUkL+RzPXwJmm9b28IOs2LsZIzOpGMWtVtXGzqKq802uTncw2kU/N5hXnME5kKmLHrsYkTkemz
ZZOGABKkFjJ/WkWBDtHrI7HL3TlRxtd3MS+WLlQDKD5JiWCuRryR8iCoghrXCIKxoIwQOFJL7q6P
AJaEFMDMOU5tp5QV3LXlNZqqgY5JqxIQr0ausMmk5XegxYI5MeHI7myPc1hGIM+GeyOYhDFCqHEg
aPmDkTE5ac6Eu40DLyKrT4DQmmduxK6yL80iBREneW2ZbVkwqlrYO+Dsob9utKEQHRej51z6nfo+
18BktfOGmYfSB0dAukn2k/HaTZzSO7hPZMUGZj1tw8FwoF6eXRlsBwO77LbsrO01DTovd1luRCBD
24T7moLYj+YZyYfdWS1pz9Pu7iM9M1NpRmSGgDdiYvpN4l2F/hgwWY2jkgPJ9WkmLrShHpZw3uOA
i6XG8ZAEpd6wxtYPiSj+SxUxuBlSXJBFa6h/HElhgK0qHHVa/L1ezgiIfeH5lIf0mgqV7z0rrpJf
PcHeNRz0SsAk0Z9yZQThHcM5cDcZ9E8bGZ6xtyychXV73bHE/t9VRLVrBKhSyFOeDEMxJCNkWqm1
pGa3eXfjDAa0RV5M7Td0OvpES+qFx7D9coHjXMMGWt6MPgb6JvLejjwg+u+Fgi0CEm8zYpXTxlPc
duleIQ+iWqIiOu7AA2+DJ5rGWElJDCFpUNVpkSNi8GkliD27f0MUBJEMf/b0q8wV8viEPM7RlmRr
kgl0/DsZ7Z4qk69kwpbDlZ2adzyRuYejFPYCgIt/OTmLKnhsd7vEfv95jOP9AFrVhqAMO5yt3zsV
qky8jyN7RpZi04GuTx11O8FnXTXXeRs8GV2R18+ymZqJUcYaGKQgGuyFuMgek3iYa/qYJUm+drqU
t2b+5qft4254qwgwX0JL4qY5PTkB4uKGMzDNVagz9lgvQ926uHA4W0TXhM7bBBdoe+ZObhkniDQA
bSuVoW16NiqU69nlRphyBz7s2tvcdrb4YyDTkItDROKvutYxlceQBhQ1+Hmvc6GDrDs97K2Bi3Cm
uwCYijBnJYUgr9ghTleMph64rPSNSauDrwR9cEGuUl9AJucz5RAkVoOtWIQPrqgOv7shRXUlfsa0
w9v1nkas7e1LQ3IP08uShirJwSm8OXmdJB67kqXF70YzIhBdd0GMplRaxPuv9JMglHl49SKtcaP0
ClMkD5lZL6ANFSMDqju1EUwPsxDkFjL61Pkk59eZeW==