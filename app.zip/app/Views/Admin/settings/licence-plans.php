<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnqWOr5klLTdT+7sSao6BmQk5yqOO1X6RFGcsFbz0sUjqxcdxAeTHQUXxokuGTpwEV3x4EFk
ZeGU8UTXwLH4Dq2jaOPtO80spUOjTQ2j9uip8dLK+I/QhM27SR4a8qV+tJ4Ua5RHlm71BacmRog0
xyO7ggnStePM2op42+rhzd9JW1n5x7yCiESgcdw9HIHnaU6i1HxdIMEjV+co4Pz1n4uEobarAyl4
m7Vsvz2CAHZ5fHFzzmxKO/7EZKmD0/fyjFnnHNBhZmjDvg/bOO6oox0E1svmQMxzTw47TDInd7xq
dr9L0lzph1jrU30W+76vmLusU2j0sIKQtK7eyfqd8Tmoi5nBOaC7Q2xPgrLxTZqW8xucIAbeBmxK
ADhRGMgXNmnjga+H0+dDy4ma5qRpY2MkUynOlr79xH7rbdUYzMbjmpssIb0ocjzsPoVlh20wO4R0
GvSFD9mOKeBLIVpe6xsvZVyFMnxxgSLYuAMBpX1uZwWzYFKc0aVth+IpT6gATffOLAwnngak2Cqj
KJTGC6aGBjbvAOICjar9+725EEOYsrHUTBDfRNN6lPwe3QpCe4aQVRrPTMhi3FeqjBITZjvekbcu
ybC5xXk2rE/mN1aRdeuJettwQ8zoQbV97R5kxzGzLIzL//JHBf3RhUHAcV4rdjdNlU6OaCaXymGP
7xqzMuPDVQEp7SOjeYZNv9a/5kg1GYQkBcG8SnDthAZC624xGtKGgWR1X4SCwHZ82rg+Y/+pgbD+
R0dEiiSqyjDXXJC4HVNFAO5Qa/YlAY65Z/cHeZ2CLEC+0jN370rzNRLkM1b3vrMSUFacvu3EqrvD
p7E5DHhdfsx6g8MOKbHzW4lxOMWrK97QpN4hytxOEl+Zb91GDHqN2n+n7ujS1GBa56RdDiwUyG0Y
dC8dtJYS+Hhkg01BGt6u6MwUJ/AFaGCaYP5HcUgleifjwl18rPC0k4V6NESAEPG22Q35dhBap+hD
R0TCi0B/y9TpUhBvJ++DfIFrmnt3d2V8LMXBBILKtYkT8RzCTjD6WPGdaEk35I3GQXXRgexLxoKO
lsfMaV9XCazAsxHkrczeSuCl24q3IN0ix8CpB9iJrQpx2LluOiILR1CBrdV5t0WA4vQxMqu4vR8o
ifwwcdh1lzyjAnxVm48ioDJGD/8+3m/cFNfNS2uY1BlXCG6ZsKc6LRkQWpk8OHPM11861YjXjmd5
6QRFyxkS51+fjp1YdOLTRC0L3sjMEvYFFW04GaO2WxTzHqEW8V4hvHh8hPRBUp5PUjT15KPsp5io
diGqmNy33dTuOp8LYrigixltYaQLB0QGk0quk7ZHPXQLP2iUp1kaIwkIojQH2jVOUnV5boi8tHoE
A7a2Tyl2zdt92byLMYQcwd0N6zK6XBOL1Cy1AIEcAePQUG==