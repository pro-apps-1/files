<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwo417S/MVrunaMHLB/jGJjNynpVMbGfmugutw/weS/yH7EX18HE4nrq3yc9QiFVlByg4HF4
ei+GbIIgmy7CJzZaIcbhcGmhU9Oe6UIBIPKeJNNMnWAKEEtUCSarfnoUvkuiqnWgxaAAEyM8Fl69
lVKDNzSfsmqpTssMrk9qG5t+h2sIjpZWsTKfMwSChbU3h2odKuGtB3hAd80VwqQ3LnHyc5gzPcga
fQNYJC6LsiJ5bb8UGbqJGMJLtL9eDDWlJvr5nc82gkQCyqV2yCGmDldWeDjgWzdhRuGsxWTZ593S
qaSU/tGCWCzBSysimFw5+Ede8eA8XR58NUYJnOGqHQRzMDWW8u2wEZqU+0s7dujww7NWQF3NJZT7
dsSJAe70Z4izPJg/Wuhpa/ihLa3LEE78/t/6Yi7hNmCF5DQj5ECu8y/xAiC/590PbSZ9GrkhnQN8
6njLyvLBQjEKN5GVqFYMackRoPgXhMMvyLV2GAp2glzJt1tPpKTlDKhTNB9P/yI3OmZvAayep1r8
y+VlWHO/mXCbRGDXDJ7tFysQ2OS8cJS6XsFOXtJIINN57vvInWdxP1QRpllRcESn9lHESIGcGemK
hr30rIh7afKgEha0TbHWdjusA5M8TApfM2DlM/jB4G3/Qrq11+p+FPy0CwH3E/9LQWrf7WG+3xZZ
jCfbshW1kc3bENWoNsUrGFLUTyR4HUeeKaPJTlWoAETPXcPjD++DkhpBpIpZ0+BZrCYCOosVfB5a
GkLjN4vz1mODzyRD3KnF8o6Ybgi7/U/hL587aOGFwQHa2AfAmjsyZuGOY/ebd/z1UrdvhbFRUOCj
pqLEoToPZruwpNRKlGsrmxR6MAK/UNKRQ/+iZ0xC6Qw1vJffwuLzKlkx8n4L2meJh051EP7yYUsE
rt34HYreQw40reeR6nneglVwB/mlzRaCuIlyn/yZ2+KGFxg/ddcKWJHqNnfac3OwHUjMsIQTMPnR
DL2bQ5OxH0vdqGcZYxcp3qOPIGiceQqNGn03tOpmDTP0Yr7HyE/asJ6iR8JeKu3E/JM5+rl5mSgb
nUyoZueHv4b8YwbLg9DcWYMJoUPfsEPC6mFd6Kg9iCfP+8ZW03X3gEJuQ3tcDNmFs2hFqL70OWCC
6zFdeb+NHgszMwvJUz/r6QcnT3IYuT43/IZJD672DylAQfRshu3B2c/9UhF3mYiRR9QYvSd8Fluj
Vfv1RZDIzIq67qqQpsagKbsEka9L08MoMnJzc+gy52lVPvn/A6S+5HM9zVyO6o9GuOomCveHZsdq
OT6hvNI2J5TYE1L0H276ZnKwHF/WvVrSNIo+6wg18rBkV+ohzSOiBWBpm6SdB40bjEGwhBGUz+el
ZBJPenJZ2ffYhZ+8Ty3pt7pHU3u6qnrOBrXZ4LEcyPW99m==