<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnW+ldXZam9/UlyxAri5taugWbgcYkOp0VoI5HNmdDkq35w5HDVTOVfJSo0s666DFXtlgJi3
w7o7V4vOSekSuxsxeim8sOCz5ZTVgWFeTs3IyMJ1vZu7CB8WFNEWfh2hqDsTdAdOkGLuV0J7DeZ+
uDL0M9PaaSIEJ0844yIJ5t/XAtpSnMbchl25sQYaD75kOdGD/tRFR88xnuAt48SvXQ1KK904sToN
7AmVT8Yk9Pvh3/2ljX8pMcRaUPepqJIpt1vj0wHmtXrmAIhk8KcRH1+1U5hiP2tqBM4EHC8K6BVn
BXsyQmK1VUDQPujGL6Lu1lSprN1yc/4p4z0dpn0iqJPQjmQTJSxuDIFgvePSH7LtsV2ic5Kq8+TS
a3MICeoS5gnq1/HYTbNRCZgAmQMNCU+zr3yifl52600l0JqaV4QPrepCj52fB9udpxXCGiQ169yW
QvI/Qu7ZdUTMP03yADJ0tsMW0JaQlggMDMEP7RrkOuXq8W8zF+9vhk8LFd2AwMBtFRWRbE2eYTNR
u1N1b4y+mL4cWUq566/2mT9aO2sS9ZW/z+nfei0xPkW4q1sfKYqlh5lxoblb/842ITdsWRx2ouPK
5SkqYFVlDuNduEn5BzVv8SEcV0wBMHSH5sFseEX2Zq/KqAmHZOf/njfRsuIKL9RA5arbxhrqNY2N
S3VImjnMzvLgG4Vly8jofEqfwDYM2T1+ZsHe52uPWVeCzDqbwev0a4xTr6gcVbEFnz8UQ1wyPOi/
JeORDnkNmaI6vIeN6dHBi9FchVqQ4uEOFTju2AqqmkJBX4WgxaQtUqV5vmkXlMwrykwSfzfUCAE2
0Xu5BdKZb450NGthftX/otZw7zxGkNDPu6G45mqZEOLpwMcUu9utb8OSmwJW51L9EjBzdjEH77x8
j741/ik4silvAhHEuLYSi41hjDf6ZaKnV331g1LcmbIyDvj82oCU2oWILMHSjxLdKhLo0w6L5Xjr
JTkN7GbYXLdPddszWCH+IXKuLSv5s+5yj9xegxZjEFNpsjLlHXvbNBnuPEUWVwV0T24JIq0tQSNI
iVypYIzcyhZnfEAM3HlOCCkLBMB6ftSjtmL4LjCUmSYfn5xBV69SIAPKevOZYMAC1cyFTcKvCLkb
wTV6p6Pj05UAWdaCD68gJbJtY5NceoelpgK+fEm1dMGldv9ynluplDwE4r7oWrRrwozrqgUntuaE
tJCCOEfs7AgxQ2GOXozgHs7KE3Hn0ptRZ6P21TKloNJE2tYJefn7teRABidXrLGlbC0vbVZMv6VV
GakSru9CeNSzEMmUk4Lheu2pn+bwjK5fBJ8B1x/4Q64sQ5yohc4/FnTcN/Wm8k+8EYm+jIKglqjH
eibXXk9mZGKADVhyGyqLNb/h7EPu2ZA76g/R0eRpNVcMbsgL2QzucAm2