<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtB3yOP6dCgf7m9afHcNiRmtaPEKAY+MlhAuLwd93oCO5U5lRut+1YvLcq1bPcHrYjhUS9gg
3XZWNg4csWGE6be9fu5a0Q70JERO6c5spYT0V7lhApfl3fq/ZsgX/OjSalnJk86Qm/CRpWUa3GqO
41wIYtOcdQvzPkvuvGf3rwTdjpLdV6uSaHZK7w2K326Jhd4kcqsQ7VmugubigWpkLJIVBVZIX+LC
cX/2r6QU5frweWmYlAUPMhFcK55QXU0DPjRyzdiIHdElA4AIKOIlrzpiU+vZDKhNPi43UJji0aXs
JYLC3Hl55pL0bkBIHiN6yuAC+XBnfZupARQNB46iJySSqeEtTEzbfddA7o4GCfCUj8eiV29Cjdi4
Kq3h4zDXuinZ8KjocqJ7UTFL/dp3FUoPIM4++qbwyWlsyQT5hlOzXR9QWNP8KF9AVbKUxEdnBGAN
uiC+T/oFe/feGAKdnOlNl4/L+KdUkJlxVpgPOYVtIULVDC+QBFYsEd0otI4eCr78mwH+njOPEfY6
HNyXVWfgPvyKc8VUIpz3dFpg6eYowFuDi69gJu10k00nKDvoAG8cBLxlAdRxcNJVKiZt319rvEmx
y933WXGBCWl0jAkM/RoViXS6Ay0WGwnaHz3ogQoXsYnQIY6pA5u4usYyxkiwLEbxb3kv0n73ka4B
lPM+jHsDrkdEGyiCU7NccEGfqaof4U1eu9SQC792N0p8xk0QCApSjaKb81ZkyROIzZ1eubBCalpa
6yh26mkor+S/GH08Dlu1qsSst+Tfh+hKi9EUK8ZIWKtUuAArlNeit5IOTCjABMgg78NbNZgSS/yv
fSwtapPz+a3c66z2safx6LNQkKSG6HGFtjn6NYtbl6fWhnV3lyKBWTgES8c1eWLBf6r3xMNanzGr
7fzx3UUUTvSQPXYbEFGMmbZR5ik4os0S9CsDGCneE52NIsGE5Sq1K6z1GfqnCUqDuVIJ/Pp0sgrH
zDn0glT8p8mQ3/zhPLh9YwBAMpJHui+YKc9FhAGe8bjEfOXgCdve0T3A0g/HrKsBm6sk3PDAz98E
Bl9yhBXzvgZBvRvU2vol/nDYVwybzCf4tG9d3S6Kq2FH5OlouIuDloiFgJqgHQLg53lkJdfR9gti
EJxzf6LQf85hl4bVY+Sa00yayliX0WSE77+BLneoJoZ+l53lxWWa5ZVlbYUVpuwHbkXMO+/+3z+D
sak2tDWx5WZ4NJHaGky1FPSJhml+b8l/z3ri7EcOcmOv1eLvMQEWNN12xdhRWvo4HfL6BE1JsELO
iWwDf8TfJxD5j2rJOqBsXA3fiq5Z9xc4iuULq/bmUdU4pQtYjK1/7dtceORji8RQvCJphqTTAWEL
7j6jpmxitlbTOjaW5fyJMWkme9PZKM+y9X6BqwOsdNXA