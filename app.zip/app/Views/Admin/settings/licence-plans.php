<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxvQ9LW5zvsVq9kmUn23dA/Rl6xJILBE9UqGwdcahoz69/6kTj7dMeDOOfwdoAfAw8mzFsVf
HvDtWhejPFwpbHjnLHa6M95G/hpIDt35dg73dwe1GBrG0aU/Q5wuBoBVnqLY2XVppZKsH0Bt8Ghy
uteAiIfyvYN58swy5fFiGFkancaYTd/Cyd0VWx2CZodJHOYXZn7JgE6H9G9sL7eEBCclg9ffaAa8
ucw0zxZdnXCLCOw6OHH6J87xuM790X1UuUmjEhKuzappfhx/q50CX8kf8cMQQMKaZHca2U4LAxMk
PMWt1lzvjIw1cyNbeu/Otu+5/OQ8jF5KRgK/VPAH6aXhCBLmU2g01ByRTWW6YiuCFTimpXN0bOyQ
uaL537GjfQrt/nyfh1JNv5ENV/Ru+gL/kR54B4ctLmESW4kqaXD4rx2rGQZYYSIw5YaTIAGXpRl+
i/qouuTJm2hUvCNDhw7wFZsCDenv+IVu92tty1bSIi/Ad+Yj/5VmdCM7ZSx117cM0Jiahj/vOYx9
d9M03wlijCZE3X1DQAOM4VHOKntZAIFK8GfGpf4ULkNWrhttWNBU7RKGWhliZGJwZqSmd72GraJ5
tCY0zgozVX74xFVK6GEBkbDBww325xD5sUYZCMp642Xx/m4N0Oi8QMkhAkz8jnWmc06QaGG4DDWY
e4giLD2YvqgJQQbgjwdL+b2qZlWSHw+zt1jztJ0VVRksIhBVmoQPNoxy9/fcNc9YWshGH31rvPkl
A56TabQRkI0bdgBmVKRHQnDwNKHcW/MXr9cjgKYde4ILM5id4b+aMcufZsTk+ciIal6ySTeH1Uhv
SmPMh+6qe3ZP2bVPRzjOg4qPSSIRdWgmkZMHF+35zJxbLyI7uvWQmCNa9m6cY+u06vhiG27Vj+Mv
4AundZE6AZRfJn821NaMdvSC0FzsXvmMkuga8VXlpWkn0YIcj6YgMPG7epY2u0NWxjNtd+IxcwCu
vbDD2eSb5lwWSaw5/F1rWY+ftDnZp6xv4QfnutpmwouSzKw/A8xj8SzFReJ84lzpQtloorFoM4MM
TJf6jRufOjvBE362SuAsWTuD/c1EQpuSkDG2QiSUvoHupTQHMnh/DIoFUc3iYGj213kPJlCAvZP3
Pm7VxdC9qTidUn3qcF1bUn2DsuWbJtSnDDL/4kZ7eMOsJj/MeWs2rNW7JK46QtGGKPRsWQRu0NIa
7f97H1Wq3OMK5SgBDLlq7+9UTbn2P1KCuiH3RMGrguKiB//Kadnf6aMEj8m0s2Hlwh/u11Qkf/2c
W0TeaxBuMqtXY04KInsAa2/T+R8ukebbL9A/vBAPukMAKpucPcamUbblc6HKxYQ/027D76D4Evwk
GUvvXhoHAzzTwtldpLkY5sgUdcq4vnSvFQthcD9H