<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuDWoviU/S/Svw5Uk1/yKLfilXqrsV2zykaFteGNvk6oGoTfkd3yGyNLwKpC8+gR1gCOOgne
9oGbGcnAnozJF/AJ+op15D1q0Nq+WDzb0ScX4NXb16mCD7aGG3PdSyzzNTDsRFYm/w3XIPjUqsZC
0VN5tVXOiajIaLinjCokAIkXbo+Zin77dIbbAOiKRsW+Y50qqfzmMQDsIiL0pwdeK8LqgeSZYFxQ
B1SSARJ0Wr5CZpFYsybI6P95unR7bMDz9YNVg420/3/QkRkhcBJvk2TodnPxuseh0Q3sQuosS1Dq
AykbnruXyG4RlNXg7yMCjdtyKbPbg2eh0s0wKc2qolH+h3OiL8LudWjTtOm9S3BEpJ4KPcMQX/zz
2r2w/sZUjktJ1Xzd2L4DGlD4OsoGvWHmikToKnjnIYSla3Ce9YIwjOIAQ5OIgA15ujhNu1hIiZ+F
vZconyZJ066FBYKNpP6VpDnbcw1TDomj/+3I9I9nsD3Jhn2AFbXuQMJSn+yB0z7wTopm8Fdm00BP
TszUkLRDeZj4nDFzeG4jzFctCpx5UWbxZuNHUYT+i6pLQD/4xLGT105LPblBu/Otiz+zt038c/Vm
hBE8aHzFy2DWAidf+xfFLqbC1EDctF+iwzkJryCGySt5CK9RO4/9Y7eYInAjToVQ9NXnudizjKph
HzqafWEdWdF+ylj/dJdbb6YlgRhbxJXC+IerqmqpvUyoAqQgNmPxeCqel5SCLVOBGyL41zL6Napd
dJvpWFfrZ9OV32o7RyHfNBZiPmpkrAcRy62rTp1eVi253+1wkrOgVq9kVB9dH8sKqe2V6VbxHKjw
I4YLyjcb6tF3XKZowTFJFY8ntFwda65FVjUpHx6X/yLcjF2tRWRY563+rAhEr5sSU4M4AkmEfa35
ecraYMBwt9KV1l6/bzBffEtOfXWZ0NHXnYRZB6hHagTybTGq8XIK/yoKwFiQil1Crvj0OfKbgOel
PnS+oRe4LfMPiMn5DhqB/v/uVIKojB5yxafBryNwAzRxYfE0Pvtgcv7whQjHk86EvOL//VWTz+kc
rvALVTJI4jBRsyS3tFQfKQvOWVA0fL4BMn/MrHQbIKg+k2S9rJInBNSe3OZT8iXsR+LMw6ujKr7/
nB4nLWI8SUeN3Szi4czRUz49Q7N5NkLlMXMHpoYtTZT58tl75NQw0fpQXn4/is9RhW0GLhrjznPq
0eIXs9a1PQvCgVTmMuln/NLyE0XVIDj6rgOl4NcFxdJ6+TvMED+WUpqeuDQDWrJXl+48l/6W38wS
a3gLgsBFzyVRuoOmEaMQUoTkxLV2HRaIknVV2n6pI50KAcKLk8k44xpLpcWBvwj7eULEgbk70jU8
yYGWs7/UUdG3Tbt67Ku3ANo7qigJJDZNsHre4ao5ADOe/c6sbASa2W==