<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPowv4cA+5UTLHtY7GVaI/4I6X+VwFYFVM9ouwpjMj7G3m33lASibie7sG2rZRNIQnNfjyuc7
suBlAjgeh0OeTtUhBR/PQeoeYGTJNLPlnKGHNDYwM9KOdMMhpSwNz8nczpPTB5iaYBACd9EGmpS+
JuaAFdakYh3QIYHUXz+SQYrJRqqN3eogXjBUZ3tdmUoILDVx93DdMzuM8LIOCl1QmW6m5UcLnqou
zf5QRb8ly+BjC+1O/py8ugffrjp4iGoXToPMnar0bIC/IiIrHvjcnscyWvzfRavEnDtx3WZIO5oO
ihbx/pueTTMcrMfxuWp3AfblmNl5yGQQR+NNoqXmwVolUmpt+6DNi7z4TtskkyOlJZOGDzKe+cGF
0T/5M8J8PK466b52xj+C4pMG87boBMknLGMH7bUjRLJ7pK9KsV3oklEImVwqszcuNA9FnAa9OLUc
f/PS4G9KlVSkk5LU4EWrc6O2nSAopbNDlBuuHp3IrXJip8cP8ojFSn7j7nwnG/tbw5xBVcUz4o9m
j8hVkV68GE6b/ij/Glt50AjoilLPya3N/PUmXxvPj0NoMlCnPeKY9doPcDRBsAwO13ILMvCZBoqO
SQeui7rIeMohP2/AMoLCswl7uLl32M0gbj5AGuexjMyYjP30R/tmoAX+frUSn/OXZi2U7w08PKf5
chWrJCZJN0ACXuzc005tWByN0j8rb+WkrzzSO+cRnPUnw195ziH7U9WNgL3E6KZP3thzRCdXlvXj
dKylE+Y6uHyvj8fEkyL9X5aIcDz3BpiZJl4q81z1fJuTOAVXtCKx3wfL0JCY/FpbO43/RHOUjWmD
CA4AcHVo8Za1gfEpiT2X1KsMiVeT2N9abgL/RfhZEYzX7GPgX1kCJ9aEPLyaYVFVoD7ye9tLvMlQ
qaEzhpjtZRc+n8CIbxcEKgE/XOrydN/YDSzp2Crxa+Ko7vCmKTn36baHh7jIsX9gjDf6r1Bsb9HF
M7iTnueJ9qVgUreF53jt2mC5TyKWhHydK8yR2Zg/w0TpCl02zytESCWXUqwkmIxTKz06YEP9Exow
R0auFz13raBBiHb+YeIVEK81RO8/9iAedpYRTNdhpSj5LbN8Q+uX9sIh0Q/Sm9h72UfMQmvAyNlh
/aL5yjaI9PG9FuKE9e6HphBp4DW7vHAG1THYsCm+B9RKXOyUdS876exg98XEnBQLlS4CyG/TRyDz
o/Ld9G0eeWqz8rCwEDaghSCicVlnCUfeptNzGKduv9xmZ+JMJ575qUD+qApSL6buCGp+qkq3ybH7
WzVTKkOQQVEzZAOa5aMWW3s2Ueg7biTFPFR1l5z0bv3RROpmcQbnDjzpcFHz82ifGovKO1HG65Zq
7vFIDoSqnHXtU+AWkz9rFJHocHwkLkO6/oj352jlKNwWU9hWdm==