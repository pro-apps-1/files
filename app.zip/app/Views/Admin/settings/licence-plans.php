<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtQM+4P4Iy5f4LTjPGa6Sjff0OyvugLXCjTPG50nY75PJa66WwVTgwsgX9BafbVDJUIg6e34
TSwy0ustlPwQ/Z3XPtEgR6Gq5dec2Lb5yg2kYVHTOEam4rUeneZDSaSJlDKzUiEkwsA1aRpXbHcG
e8+/wWcgNb3E624Vzxe2biPFOSGSWGcNnxzZ2eybGuOx45L4gc4niZkvotIyE/YriWB69dkRp90z
epxWsltICasFqVqN6vKa4aEZnFwef/IbNnYUX43xX+QiAgcq7Q3re4ZJvB3GQitQSKYRrCGkGkFz
qeA8A2jO6gEJIrHtxYyl69tkN+iUmJ0eI+BUgkFUeSSiJ0MsyjfbQoA40uTRFkf9Y75QMBzR36zt
KdrhUU4F66DqFly10yicFxxu0HMcqAIP9qBnf5efkdOkJ7BKPqCfAloCllHEmEf4qzAHpEZXw/Ph
ik4b6h6wn3A9jUWliz7Q6JggNycK0ND/LpcQzrfwUCbeqkpaEw89d0GxloGhX00AMlOIb065KpDe
qJZa0dU+0sLEiKVZ6CntQcLdQ9wfHmly6mHYnHnkeNXb2zXDS0sUmKxwuAfDa0N1giOEzyPDsELJ
EcqsCdGvaUv0NI+vrsqUwUg4IYF1JC4rMo8V0tX7hl5mDltjcAmXGUN/QUdeCPbSeyyjhhGJ//bg
pKnclb/7x4AC1Z+E/54gH36fojYDIhkA3qKm5k4DtJ2hrH20bU/T4xQXbkW8AwLTWQfclSTesUV+
a6O5CG7t1PI18rriyzFEPQbCR93+OE7cbFC+1JEGMDT412v64NCTixY2P6/QRbMOpTIH/VJepGnE
kHilRqQBJ3fGle3XC165g+Cclzo9G69NC2k7MCmkd6R/UFxXNMEKwQtSdI0qtYAkMTFk7f4V7bpn
xMDi4IiHDPEScLe1Ikru2r4dl9ObCwKS3+2gfjtVFT335Mhc2H/bHivGgge9xEVBsOnCWIt6Qndq
+2z32zyNY79YtoZ+bsgt0SQJ+VoYMNaiH2m6isWKlo+coplgonSbxl+2C11UMNkHbLFUqo45FZO1
UFUy4dx9uz3h8V6H4iVtZ6eZU3JXXFoYTmA7cn2eGyoKenMN4rLo8Ddf+OMeoNJiIEm1LZX2PRGV
lk3JwWsq/kBbMLUVqNz4E9FEDPBOT0qcjdihuortPukm4enqYosx5YiGFtQ570IcJHhmbZJF/zhH
tcCOxoYJQKTJ521enuRZxzpIrjRzEzzuR050YWikHmo2xgvkNCJSlqmpKRKQ+hcMNxWJQkTwXtLE
tQFyuS4EDREu79M6230Xu8Dplusx6eKMTXZ4v9j20TDWKH1aHirqDn3NmNBL0IpEJRtPNm+vcUpT
OZ8ZMEGwbyBKumHCNAKExahdcsjucFr+iRSdw9cHqKwtOxR4chVF