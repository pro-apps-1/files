<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv9QeMKKznbAuPiqHhAmG7EpZ108pST3vQcuGe+y6mMxIi4Tn8yHN4bFp4pHdZyQ/BkcXTLj
tVi5newLIVb0yyf20x93/sW/EcUCCuZ1ZM/AmRE69ZHkLdXc4ZYA4LjXTTQn2drc7wUh67UCzWHd
d/IM9dlou9kP40j4GGYQu4dmuG6CGvctQsz90TD3APTE5eBXCimnLzIcFS69IYRxg86IkOz2VYX8
C539gf/l1I9Xzbsgf9repPa6M+C9ZJ4vibjl7vQgXq8KtuwtDIuffMsorGbaJAgoMonu0gWnTkuE
iTqw/mdcJdvSvD2wAkXvU7Ku4EqvRGbFj5u247sZhvPT4af5XuOJtbIPJWwce0zGE2nSIogUvkFI
cq1JcihX++5W27WiwtJBttkRHd4PhkC/7vAIzaunuoW2YiOt/MuS+P/TAWvCPFL0bTcBIb4G28ZM
d7OPhwIzKYqheyMGniDey74bfoNHWuhq+bv8QTMj0pVGS9VU3WFal3IaWDXub5xWhLnfoVZcL7Z0
nL/tsn+WCBqXZx2OwX2d8wNf6osMKTfeKAbcHFlAAPBWZrMC8lC08Eakdse1dinUbWkzMt10KPRi
p5UqQQHtutxN+9MOkN8oRoYaeSqNQddMjXr8LPym20//r1dAZbEOHm7O5N1OOwce5Q8pSDMhsCuA
lp4Jv1A9SHpjQvhJ+KO/IC2jWCdiKw61sXsIQ7FmgqwoMXCIHPdtHXU4TgyjDZbkqncI47X6suZB
Tg+JLDfS8urxgGmleh0x9JV0wAo2GY5+aDOSIizxD4a5JhDukOE6HqTTEuzc8j+6x1LNYl3Z9uHJ
QXYiegpszRilAE02Q1NIaHr4hVlmKIaaeRSaCf4SqMafUZUJO0aSWYhI97GmHp1k6o8DmS41pRsN
46x8mEYhFMQ5zHACzUPp6AyXpQCUYApIsjLY7MF0hqOVHBXBZxkBodKBLyqzI2Tp3ozQvG4k+joL
3O9wP//x0vcMBOKRqy/sOH41pxOVAjo2ThpPUoZC2Ouib0EiV426OVbazooL7tjaa/My1GW/RlfD
3vw+GBAj1doKf67CQKLPS7cy8YXyvbqJWAYENyoledjI7Vvm6JQVQ4G9hTFoBzzjuqdHlV+DeCLy
PIYUaFPNbtAro9In2mMMLzloZqBJS2Zj6CTvapWRDOamliFap6IfaM834AJGU042JfWht8XxHGoP
PzYuUvUhkk2Q7BjOb0knfyzxhxPgq/D+RM8ZwSp5oTl8fJ8OKcf/ysjF/7Q4j3KXAKTIJnMrDSBd
wEmKKviMtU+MyqL0X+KSfAGc1cNJtKQTilL3nVqZVubS5d+obOK3HAJa2muFQvtPk0Ol/1XO6H6S
tMyJ0bNd2IE6Y6sDQeXogyvG+OgPMQwHZix1