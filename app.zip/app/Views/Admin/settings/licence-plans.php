<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoIsi6EmAWbKJNSbG0y7X3+yJm9+7iz9Qe6uM04SxzPhI3/zXykODQ2KfKNmS9ghhD2EBv+X
tpMVtZarg80bjymTcWBiiiR+l46qttjkmzAltaBqd+ieRy/EhZaIfdqFWccjzkmlmh8e8Fd/jIzZ
Zn7lo13Bsm9tsXbbva1Geu/A4auve6flhktAKrkjB9TzkauBhGBFTmL2/Kw7iuZemsNt5MCR/AM1
1RKicQdt1kb1FKbxviH6HqW6WXpA86nVgV4LfnDjqKeZJQJYb92MQiv9H6zewk/lrBVV+IY47N6j
Hy940dlvXCyaBfn3MCLtWfsAEOr0WMQiL76O7g5RylFG7cbD1DRAgOgPgTvz4ugjRPU+YZZS6oE4
/pOGmni4QTwNxDq0NOG2+6ITJvR/PBp0y2OLt5B9gvvia3Eu8vdKSI2b/jZFRivU8zZ8hH5MokUt
El6qxE4UwzlhZKIgr7E7cwzw+nSJWtmaJ++Hpg+8R+03gW6UiARu+GGDpG9KCHjQ6pf30onFhtnG
PJECFGaOjym/Lmbgd/IrQRBAYU+Cmx1ZD1EwVp6aZK8cbXuJFbv1+GRYs8eETUQMlsfoqpANtmx4
JwTMRO3/6tT3HewVFREPw3sMumrAfpRlA2UOwVyU8Xc+ZObVib4Wg1N/mdZ7Kl5E0JNS+JIEgJJA
7LGC3N+jXLzR6FXbjnKUmcz9+wEDLSfsTLTXRET4YfR5rPVSdBw8Hn41yvnm2keP7tj5VUc3EXP9
/cPrCKl9HUlHe4m4Qb9ZZQrPlifZ17zWspr7ZQFc6MMVRvmFiPKBd68BcsToU9cdUaMXWr28uKP5
9CTGWR/17EUXA4J6EKruuT4A475BjVq+/aJ5R0dKCxPZ60GEu8d5xji6h+ZdMR0GK2UwDYSoL4DL
hkY0q2zyvxa8ID/2/0ze8Ckq3kray9UqsMr/AL5A7mVyoGM44kiW02dD4718mkaZBjwTIZzPp8E5
fyZb/9kubXWe0EI+TFztxAU/itV142fJSw53X+b1qbn5j4kCPmqLFvUnLYaR87W4nPLjbOVL9BzT
ncJD1PpFOb1K5+GTZYSg9ZrwgGsZp8KFkpdU3QjaL4XhrU5fMVlXQChE3DC242VdkZRqJIJ5pl2o
o+0YsSLgtsCDSSuqsiEDcgfp4o+5ej2no9PoDSTQ2pOL4kvqVzo12+Puowid1pPhT289HN9mys+V
p59C7wfSceU7q5HPVWNyoOZ7y/eFPcR8puG4hdvA3NtnXRTSpTZMhgPSEeEmKpCDmpQyW3e5gyZc
rtbXzM1wKTkNlJhHRuI2EJurj+tNhW8G7fMl6IAHLKsZ1mXSUzJPRCGmBgGAoAippMw2GlwbRBK1
l7CDZFaY5KeUGiAkk29rIB1jbfJDDCe01SbOzyQBEA6awPCWuG==