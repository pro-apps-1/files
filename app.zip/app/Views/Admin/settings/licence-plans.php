<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoY+3JOl4/OvDd+O5Q2KQ3u8YhFBTvEGlSyTjVs974Ih8zO9yh7UfSAR49tDcC5KKjKAb/zC
4VV9MEakZChRynDyHQlyovfzr5Ud4ncvWQVUbEy+qMqqQfBrHbtU1CM6aoZ0wafbUYuEYZKs716z
gmQDaNaKxaI2d2bl+dLSd4Z7W8JMl9stJ2bAE1K5RuMOeols6Qezniz/nmJ03GtSv1CPveCfyXzM
GKwqZfgV9vVbk/vJFpZdIpIaDfMuEND6GJNdod1iw+bf5rxjsEZ1L4EK3FLilIHgf43XnUJGz3zm
oDYMCZLaaIVVnIzVDX1AiE3TGHXx7AR8Z7RVNTtAjiRtXpuwSdINvXDOwVm9hxwqfsjUjtEMKi61
j9dBtuB9H3zheuW3z6IQAON/JjARdX2Go3JSZZxKrnj2eJRmkt8F80siOtYnE3PKolSrvhnM1wwL
aI/gu8eqBiWcihM1hWjiOEAqeKrtgQJfHPlAUa4a/zgQ2p4MonI4Xd15/I3p1ixZfNA79vX2VcIG
U4vx2qhrPik4sH+00TC4Hji1ziLjLXVVYy7GQqfizaMHLtJggZNH843w4uto7Yl2Y7AijB9raAHT
9xH37GnD+5jEqQuMDCUbYx1i6gnvlB4ckQ8Xui6hYfNl2MKLKGMKJqml7lVAv0l40+t9s/KdvEg5
d8RqPvKNUOKjbW8YUNIIETmVeDBJ7ceclkubOBf/VqACqZzr/a/GN50Y3E6qB9UKIbvz7WO2atFU
FTZwL7fBx2BmAV/lr56ZhuAkmIaTAkvRxnnwvY7PCaN9KEbA4OPiIpr6vtnxnNwcmKNA1r+LcFyw
Bh+hzWVtkffU+kIj4prpMQKgK9ZRBxhbv6YWDW/G4x1ErND0d7+gdr8vMRF6PnSDM/cNrH5CK7y3
5jFLDHFFkfTFc7n7DdRZfBlyZoC781F9ujNFQPInXEpKLfA7bl+rTOFyfEKFncfGQHplm79ZWqsn
lbcsEX/Q1B+JBlBAM67xDWtq4QIG2lBZgjKzYoxvbMV09MDfKeP0MlxtSu6prRm7Oo8aAfMIk4bZ
hbbDK9nvXaCPJ+i6jZttrcIChYmdN9HkVFIwYFya+kLvLMDV+0FwhiTGP/zJ2iWdKDjG8zGlNRl2
jlXMMB6nuGQ2UmqLphNYL+ugFuE8j968k7tk02bIimCMgPLAR7rP6l0ksgy+Js2gKGeQPFjLxl0h
cNQBr+pjGBdQVX3LFf53M5gqFLORBwXOnk2iwRgSoX+NNuw2ChFHfoUeYE7jM0bK2JrNWeymIq2U
9kDSx6FfZk6Kebsygm3PUNfR+QOvmR7UYQiLrxf5i4A0wfBpHSDEHhjoABmoETvajd1hBX0MDB7i
BilbruSwvl/m7syiw0Imi17D4VM51T0o26TawYtb4wY5lgaDPt3u6jkWcwOSD0==