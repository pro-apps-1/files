<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwnM0zC/2/ZanfUMy7C8qHTaLBHaJwUac9Iu+4I22NP2I1ky+mYotoSzRjhN5p2jASpD5t9M
nbvbgfB84lmxgGCSn4Y7Qd4ZGAgWqdJZ7/loixC+KmDjcxZVFiOh08rjDlnaC4wiOLjy9ghzzsP0
U1qPrkivvOwtFLZpeTeCPwKXCi5L5DpgViV8EleTCH99hux/D/lFVXgX3Br8+tVaBPSV5LS+VdSO
mP7tgra/Whdl0xH3EHxfgXYKEez6HFgj8bnfhubOxymazG/Nz8XCYKvD80rdywtF+dqG+OQf0/wu
4Q8kpmAK3me71q6ban0h8DelKAQg8zGQILoCgdFbCedhAq63BinYk9vCw8n5TQ6Jkh5l+webhSd3
xN5dSWwFSOd3NT8CJtO9noqKwg2W5zUJjs7njNkVvZKpGk88aPqrM5MFzkdRBMSmOmlwP92Oqaee
Z2wWtT6yvs2KAtKlvkIdpmUWqXUwmtouMSlTg51HLFYBijBJeKwHSsExmqxPMx2KHcU1CGw1f9xX
vH8lsPsWQIEzSllq6/+K1UbwQwe6iiJu8Y6lA9ojhRB7jTniAmHVFOxX8IzqxwhRI6LaGV1DqBLq
/9iDkQxTcnuOy8fp4ABwbFrYM6CXaUO+GZhDWZCVb7ydTIh/tF9A0LV9FJ7NxPDPqfa6v+BAwaEH
VoY8OqGtFwBmUvTv/3cew05zWQvpl/OBgLdeyVYpmoFQ3CZVBl9ta/+NciCEs8ubu7EZJAlm1/85
D54uWwNPNlcc8SaL800ECslRASdamFtml+9cVIpxc7B7Q8yigikoWy8GU1pQ7N4lt5gS9lXVjODG
KY7lRbs/JFXq+ek58a0MuHDH52SEpOPchzuEV2JQETwH9EMpy7L5mIjCsTVgPUSBZzSwYetvJaFC
3ko7Ar0DmC9t1mXlkm+JJKufZojSyFY2qn+KK6TpCYab8Kaio6zHyP1XfrDErJkl7cXGP/bfARN9
0ZH0wUbF9a9lDgMbkK/uRAIMp2DIJg4bNYDE3B+wAkV5I2OhpgewBLZpop/b49eAnyfT57Kqw6Oz
Ue+Tc0groiYE7sTLZGtg6KA6PnAyhdfJ4rfmIFf4pHHpzi7Sjb58dDOWXom4oVBGRy1tWIAflz9I
+DDgheAkkC8V1LF/4OyPZwQKlnv9/Rd7dE6fRz+/sFB/6Al/qL1AlhirYiq6Z6PQxto5GvvbP3Hy
/e/1yBFk2LIPZMdeAL9TxPO3iQGbmhBveyIJLVAIyQhdgwtDusDKMpk9uLlZEaCc7ehUEkkzVN6R
frTAH8xIIvoycO2TCbznatgRfCgyCImq6TVyMHJSaW8J/skWA0XWBZ4ETFGCfcmFnYaLb+Y/wsB/
e9CNzy9t4iAt8gEPY0mk4+Jz39ykWaQNLDEvpXQjswAEmW==