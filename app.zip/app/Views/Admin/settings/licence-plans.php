<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqQswy5JAz3sAdT+ucyd+0SaTfDB8IS0/BcugOx6cBVLHjF4jKh1lSL0WUardwIwdb037gYf
ncHaW32E9FcnhTvQJqXuiMyOiVGqgvmT4J07RXi2/1s3E7xpkZJ4ooPnr8FNY/QYsFm68muuajFB
07HQRucsra3RDH+0WgonntZuf/g93DRZ6wKYLFrG4aWbZlmjEobGy6LZChf4K2cJ3fWZCKpx06dZ
7Jh8ugiOlkDSZKvxs2WFfJqHFjx+/A+wnFXH1wkSve3f/SmM5W9QCEVAiebfJS1ZUh0wy9DDp4hF
PXjD/xJJetPzq9JlkT7UB6nbqZ8dhtSDsCkrM1eRIv0Wzv85qaXnN7GY/W2+NlWQRFOY7Ey0oMeW
uiDjAB2yMS9E8fLYMEbuMoFNATL1EAMJr0a5GksZqaZCN29WEysH7Ry+LIlv0UMGhILN7dgSNhuC
ezsrRJsiyAth2uLjgyqkuDBmMfjexZetKs/G7tJKv4/49PtnaeBd7+Fjr/Jf8FeN31mNZmaus24a
rglkwaSRKFezXzyJswG0ClKhy78RwS1zyfGAzTnxO1SIvCY+YMQMRYFh1hsoYULcqYnzJieS1Jw3
C48tX5ZahFZmar/aUDAQ3GDFXC3y6bbBGyHhE7/ouXrfxPXxtrg91/Bn9PaLe//iWldBXc0+tcak
z3IWYWNiKg4eINyRV0UQbGBpvIVBbZHLCgXv65Qjc7dHgi9GSy/ipbnaV+th6+Ccu+0kmx5vEHyo
XcxjvQBVmd2RIprklOsdkiT5n5dSyay9dTXpbVhn1lluYrRxKKOicoW94hYkwcGPjb5rUfgVGbTS
2OTKFsA6tpUlJbVmCPpum+DWeZww88vRvU/UcxLLu0CcDEXqLS+E5EyGYn1bjIfr5rpBbQGPWlu2
dVkYB+x3iifRyVODFUD6fJ0+3VXCaY/xwvYBEKJvcwb9xvNVRi+bUpx90ff3V1ZvmJfAImzfbMpK
8tArMrsF7l/vcz19Suu3eBkT1pTLcSVbYEPz3DqqP1x2JYKFwaAFjoHxLw5U92lv5fYsm46+fovx
OwJCJjlmizEkW+ezxu5o8qd0f1Hn3di08ix7AqKSz3C9NXTAJOgSEBH5axc9qU0joOc/TF0C1Z8b
aOtLmaKPMQF58C55Z7TRCquUlmukB0q03cVDJEVv7aH6nlhuLK+EnCNqQ65HKpNtOVmusu3widFj
1tOUtT8Glk9/OxMbXZUYNnG/KtbfPwfx6w1ETZ5E8di82gLA1vDAvAQv8hFxVyZo5Zr6GZiCdObb
3kSSJ+BlUPr7BjpTWV7R7E0On0V488IAYF8JG64VGmpRUKLTBx4jdgQx7AiPrEDQDkfysM3fHI9J
k64NeRX725h9n5mFnMd922/WGR3SE7VD/WwGe5YQDoC=