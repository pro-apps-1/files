<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxYOk/47Dm36tbikqY97LH+3eBUDXujZNwkuIS4wT/ODxcNFZKIgUy25/huj4THZe7Hms0JG
fxsxZwr+DAZp4/s1diFpeCA/rVkRiH8UrdF3wBtw+9wdNGZr9GAO0lEl03D51ghhz589YS0JKSMO
30pjVvmOyCJC0WLJUrbDvShqJRYI/mDw1q9Oo2YDU+rAa2jWyP8GyAxUuBS2bUJZfcErNTYV6AYy
vjUpcqpFC8IB9cL4fxZ/nq24cdMMZugtRBafzdiIHdElA4AIKOIlrzpiUvTmZZCiQZjGprnQsaZs
JoKA//r8SMBjaXJPy2Rx0BvCEKvZdPLp35tssoL62LdN8J+59rSq/vqQdG1w1qWIqnQVpdEOmnl3
gZsGOZBXBdI9QqI5wo+e8j2myOQnpplV4i+oPw5Hc7nmyTFESBbnhOuwjTdGFMHorVFMevICR8Y8
x6GqL4T+WlLOg5wktDNdhLfROUmIJ1nbpGlCj0OByHgmXXS/tfPCU7jRzMlfWfkqmCxiCJIay77P
5HSGpawbe3bxbWag0bF+uRH3qxB1ZQVEqvxXwxcMO8xAlDFBFZglAPFVQkraEL9AugTLMR4ef3Vm
KRXv7qtdlpRUA/ZJJb3XOO/2EjqSWeZ+zc/Ppz5zDnBRRtR8Zrk/JYQmLepqAL4R6BSLx89/4WZc
3pYhrzjzL6CjDOLY0R2tvOFYulsKkBXE2ntGdKa7/GJ7zoigpxnzNM56AwutODErkU8Z/RwVvm+Q
dHPcPo/pql1l8cbXOr0lsLxJAJ5AFySpvn3msHlqwDECZBqAEI+NxY/41cMjzSnvmDkETRqr4gSk
SLhuyOjCLGUUzCS75GYn17MgUh80lbdqiPAFdpY54P9mplhV6TXonIVm2HOBYPi6DY5yKy7SHJyq
ZzSCFtOLxorFPZBhgxZyJ9XNLU9nvjAKacit4TqoZTD++SflPtrGwvmfnmpVbwCm4RQfTqGYjT9w
YQL9Ruous0GSVY7KgRg38CJeCN3DEkNdlYqeyJ1J2ADR+tTuMLGcjfdvNwwUpHbQ16zmr4ilTQDd
uDYbkJ2qEkR+V0+ICAFpxcLOWeDFSXcIr6WX4nNTCIL3IWVChXx2do/NwL7hNyWtMb+eNGO0CwU9
nEAW7pY/urprt5Te4kssjnYX0AzcMBhqcHzyWZccEx3b8eLcEbI4ZSJt45kRi5skx5qDbD2+dQvX
+Rs7EpcFS+fxw7mKn2jCaITs39HXTDFv3RDkKc/Y8Lo8eocjYjz28c3dBis0nKq0vRxdbZit6Kjx
DJM3pZ7yvksON3EAs+qUUHVX8I0wnGhtLb1qpSDJOVZdEXs92Zam+MmOvxmZ/t5nqaYFi+f7ly9c
o9PQ+xeDPmSv5jGdvFU3AFE6s+U8OpFl7PMMVfY6OdRCnvIWEJf88FcF98vHkinhYUA1hY/ZjAEf
sSAK1FlsuX5lhCsaC45M1O50eQrp8ckvekaPQkDx5SvNuo/oSr7hD0FXPaMqiFNdaGf4dwAXzRN6
zocxN92liPnTr5jalefzKaexbvZC5xO9TVxlhXzhJt12WSZ8O+QCtLPuWyH8wL/4wflP0UH4MMuP
dP8gXmIcNIPVyiIvmH7p9/qABrCg+JeiBQzV9oNtD6WDokdAyhpKQYEb4jSp+uHH4QXpYTiB6o+J
y7KdlzeAsJ3Grl1nIugjK2rArGOowVIqb4DTfd9JnPICVHw1BGwJuFNG6vtFtASQ591zEV1R2fiR
tBnKxDSO4uUY3StZFYwCydRlH1qMUIDn0++IEw3rzbo8gqcDDrKz0LiM5/tlCk6eqruuxMbBu+G9
ElEbtNnj+nSdgjZDeZALmWcXJ9ePKBCqDv/RfzpfY1GoGcj36Nah307LsvLh92+ql0qJ5BareqAV
49b1LyOKWSXFo7Qv/vINkBRVbZBib0YryIrVQWyB3xv3D4KhVeJs8qRo6OzrkM/2iONH6MLjU9PQ
xQ26lWfAjdWrAy1YjMMd6rVzXuD+Bl9qMWJkReLf0z+Wo2A14F6IeOwFZzyRV1dnRq1XHGPhBo4E
GmJsiqvWbL7uWNE5483PT3rK42BYHZ/FZjATaJQcmUsbNQ7KgG==