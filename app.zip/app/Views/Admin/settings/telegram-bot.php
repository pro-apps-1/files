<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyU1ROJHN5Qih4BufnWgIbt1p58/04b9OQUujJ/9rULEW+Y1D/0aPZvVLKTFaprIHl8MwY8j
1KIvtk5ELE+NA/7RsiVROgP4ZGyLxX605V4+vZyKL9M1xxAu49OEWGdz8pqtx5Fs8u7HJkjVnarg
afNpCWqU2IASOD6qMxTHM9LkjGx6SDoS/tjRplqWJE8cBNPuuTdhAvBZ5ukhCbfuOVo/QFAwwLY7
QhB00dAWpMn9Y6lemVv4kXkES40X25O6cpK6SkkF2qtch+LXWRBBi0u7RhXdVv+rr05fXYFCyVGV
KrLG/+bNRUoDYpv4m0aTqe+ahdVDS68TaFatgsVAkbIhWjBY3veeoSWKnsvjWXJxG0Se8W5aA1S3
TyKXGbv+25MlNpQv38U3NSSMc64KlUCs2yGPY2JNBxqA5uwxK2jKwto0Ho6LjDCMdq34GS9Z6+0J
AbMWRAgX98J5xDevkq/+fx/HgQl+BpuvBuvZkEMvb07Hh/eC7eB/B5bxm308ex0tYenkPKQdk1td
ns5PPze290pn2X1/VsyNmkmGWF615VKo0JlNHWUQFn4Nf0PAQpLYjQRrM9ZfkFJjQbqBIYjWhxmX
Pn26e6F1u9crypcJdb2sLibclfEge2i/mcLfnnhGQZWMtW+gfKuHgrANy5QarG1NwvhoUpRTyfYj
2QhrljC8v/0m46SNP24jW2Lu48/wlxadXh52uinQPNc2EIyMXENxQrcRxep6hwrRug9YjP7U9Zal
NZbiVdMe9Up+RIUEdnnfUffiscU8o6xLsaFu4RK1PVWjosbuS+tzGMp+1vGgstZ9k4FnPHRPxcva
ICSXg2gzjhhd47naKtJM1hyTLSWjCuAQxNy57TKAotNSZiwYVA4SdY+ENIcQtiOAOK1PiIrhEYCz
dOb+3ZtbMMPbi6XP65NsYnxXT+13Odvae5EkK92ae1N8/w0k70AidVa2tcN6QjlElOFOBkPhvPR6
/f+Ril6uMGF/0YC13Z3wAEOjNR7yno1SN995J7+pBfFOrvGnEenXhv6/GOCjFO8KDzkTRsTzm0Ip
qKwXoaCSTZOQdrk72iPyNeGEzzefufeXEqsSiWysOxMOCjc8vb9KATYeG79kz5CmLoePUCy3NRhQ
2AtsWC+xiFf6fKdtJdLUQSad7vpBViT5k9j7E/92w/azMCL7PgmulHdebY4ItZsS7+cIvFaXTDWA
WL22bGJnn/dXP2pqaJ6F19x/SPHrPbUMOH4LsjhxdfY1KTfTE4vNxFOY11oGnQa8Y7u8jfKdG9Pj
gSC1kDSnG7ZOlIL/Gt/RRtpoCQfiebqxdK7lK81qGo7YOzzg0F89LcCbn08JOI6P+I3MgNe04ox2
C9pGIfTZRubOtEGsVuVHhOfzI6j3Zuh5bTB1tMJV3JBWwX71AsH4hfLs0Mh4lsajlQYLdDENpBuF
D5ldgiCAIcOFCvzpi1hueQI9TAtTPjk3FQBiRS/+QqfgrgL4OYK/jKkwNgGeh5jZEUH7W7cONR2c
mOzonnDxeZj1HPvalR4pSXKR24OtyS0PbsPWFUONp2EtK0VkwV1g8BJL5yw0yay4W/GKhC+Oqft8
csU2IzMCLff7QM25Ddywg8LuiWQNwVfChkIgsK93wX6Y2sD7pbpVvsreT+0VWJkcyHKtwvv/gOOd
jEyQFL0lwcXgvVxMBRqIfWKpdOqO3j9hycXwGlVx6+jfK6IMS1pyTv5GLoAE818u3U4GS2UHXxXM
1Htp9+9IyXfwo/GHXQqrozbDZbRFuifK8E+m/PUwFfdiW+AAjgOFk+UfKekMqltAflsmCJwspoNW
fxcatMAxv1fWzem8Y9KfdHlfImMG96PwGDl8IpLu61xtUcs9669TBAYTfamdqqD6k714/HrfsFuX
uMg4jfJj+nWnmLi7Ep7AyO9SWChrfmRbvGXhddQAtLFikg+xOWo3e+kwaISvYiObowspTgzB98gb
yEhR/e25TDzJV8uDLtGZ4+vNf13Hci76802Zo5lQp3A4cmDLJTvmibHbQc3Nj8/62oHvneAcTCFk
OyS+PmZtq5DHz+w6BzJ6xCvehKCJmzv7gQf1CWcljfaSeG==