<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyAxQn6ZAb0dkdZ+CaqAL9Y8AfGb8nKeNgMuswpup1nE+i5WbgBIEQ9VYMuBbTXCa+oQqLEl
W7wypZsljjoLer0R9rBkxkFR3bKlu0UJEFnMu3PAimJeXwNxMBExq7QEsw1kwRdB9cRjzJexh/Hr
msYJ9XPX6EQ/w6Zedk5W5OswFJHQVXJXYxILnNXHR1ryizO0QidCHX5JpXA3wvwE27//Zl2rCwv+
K+Fui/i6W1M65LVVyLIkAayNkw+UuoJcVYqVnar0bIC/IiIrHvjcnscyWzbi4DMAt83gefGZY5oO
biXN/m7thCF6b/cXAu54k3ABWzBXAbK+rkL1hd0XqEbVbBDxuXTrr0o5KCDj7lcY8uAjAk+qXY9s
8DhJ06/R1lx8lLIuCanDZgkYeEOxLNp1eiBhqJLs/gr4Y6WHWizLGvc2o//aNwbrgBv1tgkDAtee
wuanMSb4JIIApmX/GpCz4DFGrLSmVMzzJA2NGQGGLqFSwdUUCtQIuuw1+0ZBRs54HP4cZF/mwJbX
hYHhENjbXDxTrd/nSZAfY38VpVV9GG3uC/luDJRud6f3r7gcyQ1RaGIf5IOGJfip5tP26gm7/o0m
ObAPCLFW4/jYTbsUTxpw+/zxl7Fc3xBrPNuz2ZSXk2d/dG1SuXSwD90xe1ZPL7dyuVhpw7KjqFcm
jDy49jBKjDRaJyowWJ6r4Sj/0ctJkll0VDwYm0YGvPM0VkOQlvSXOTxNAAfRokmGSVqMsMt+R19v
BU71hg4cPsmepyb9t7um8fWh/cjvR0ZLBxDYe4/MjCdZxmWdODij9iaAqVyPsPDbinqhd7XOTvl6
LkUYwA2zNXMhs6gAS7j+MUcZ2jXBK/yfhMDnT48O0G2BW3/bIVTKIRlaVl7ajE7E3UYZFVkJHSU2
iHbKC5bCQH+/dr1cNtvHo9eEHmzLXSbTPv2MCJN1eOmEly5wzX2jRzHjvDoXnLQ0aj9CjJ8BqzXf
GAPGJl/T2NFy4aMs4VcI5VUmtSORZyHFJK/m1a/FrqvGn4NPwuov5uwnicf5T148lJLCe13cSbTB
z4+bIqEWU0weAMBWuJ4Oa21B2fKN6r04cjiPSe7UvJ5G7vpuaXTVIRPuvt9QrYj2C3IQ/54o8ILj
Ns+MHWD7RO0bivajZ3KE2P4pwIq6q4MewpZPzCYXUqr99gMjRK740IECBVOHq7XVAF7cpamzfZeL
1vL084Jl3RUceo4mGXHinhNovmElT6HYEtFNVRoLrOI8RwzZ99rj8HoC4qtLLgca2jsvYgLdVSwE
boM+0LcTx2z2X3vR0Sg06p3MlRrbT+C+ywUnRIC3D3j4/y0qrOMaQHVELonHEzho8Lf0BU2vankW
O7nbt3eVINeSxN3qszoQL/+3u47a1rKsJs24M1L0knQA+Idc7o2hJ9euLwSfjmk9RUN7g0NTjcWW
/r7/wx4Q1jK1miYsxTTolVERzbQhR02ZI1RS4Zyw6cS8WSNz3IrHYPaEzs5Y0ShEWWu1vm/4MVic
KLNjkfCLyhf9hDyFm30+A4EdyVaX+LUYlE8cfgpnfmxmExlhtqBxvcnEGiCoYameTQaR7en2pa0Z
wPGZoUtnevvxaVPEqrdB+J6X3pNkM1JRI2OKjvrVrAccUs4rbhNWdVYBte0VvLtP8/5vNIIK2mf6
foHWSn4sjUcI3Pj0xut1qO+UPtgw55gZ57ybf+bBdFU+A1w28Y9n3Rmd08q4YLMPv7T51qrirWoX
YZGgaUjUo3ADeCPkBwU6yQkFJnvH8vnjkW1GjhWLbsOaGx9MMhpukGS1ndDC3apk6xZQh+XqPrIJ
xOkWCdsrleQirx1ERkbAgAjddovzX/WjCOI/6rxqlZIlagKCrOTCXMsU0x4m9lE7QHPAOXNgdjJC
4ZLXAPW2Yw8whtc9JyHTyPs9jn90AHRQNBLfBtgu3ObCmwFd7pghdBcsjlkzawGc5g7N60UCS56B
hOO0JmVsSh9JkLpvjG8upGmdOtwTdabv3HDSB9/RPpZVWAzSTHYy6wOlUMiOY129iGMItG66bcnu
2Qjq3e2Lu7852rAwWzwtKecrqm==