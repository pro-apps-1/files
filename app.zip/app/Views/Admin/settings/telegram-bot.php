<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoGYcDYUl60VP+4D+pJzYn5dVPMjxj79Y8+u0rfRUELfzTRxxD+Lx9LLnKvb3Ph3mkkYdRpA
ODZGwICAjSmp+IbDboP66EOMLYTmBRRW9bPtzIMxz40fx9ankkyFIjlzzrhtqcMPoImEPzWr6AnT
tufssDYo9ZYVyKAn0oDMj8OzwqGjkuhzZ6orHarSjfFwGY2DP/DFMwsr/6I5LdbKkaTOzdOEinVg
EzCz7U4zGcBhpDiefZg+gpHiYVYHBGOlGlGl7vQgXq8KtuwtDIuffMsorHPjyNBLrc7EiodfdkwE
iTrRuSmis1KUxLrWQU99zelnIqWINz96L/6oVRMQfDPqeY/qbJaEebvIFsQc+QQ3nFWgYaQXfhC4
Yz+I+cAfof9Gy2SnbdAas4zks1GkZiFX6W+czm/iy+XHekQXLf4wzgUHGCyq5GN2fUoW2MEZJWN2
7IR4OZFjIQBUH4HQ3qNkGk0xmkJDhBZbH154dngt7S6yeZ0JQRTVpn7c/2VaYvkNtEOv0oU2Qaxi
9KqnF/P9H1n8U8rsfXFM2VER0LVW3yFyef3zSCi3ozlAZaARejyem2jiOwtHV3k5pAgOHaCpsdis
UfiWEHqL/Y8J0zphJKdJBep4orirhZhOWpLp8NEnSkm6H4fM7GpoJPK4OTvH+qB7VIem/MYsNeTG
1dIi/YeJXEWlG1sVyMiFFRfIcyMwBJE8xd0QUR4OuajXy1kOpt0mFuHutBJYsob0zf5Ia/deQjRt
li447l13tXoAbrgeaYfwY7dD4ia+F+ULFkf0jpiPeyZabUkm/55LeYv3URNY7XzoW3gd64OmQUBw
sGJFmQSfDry3pgL9/Zrg2pb/HVSaLgI6UbBTuEP9dr1hUrceQnHoSDSip+vwK4MYFxNFp621U6zK
JfylYNkribp9vOc19KX7Z6KIqbrvaXbUleSHccK5iF1OoOXGsOOr0gnsiJBosDzITjq83x0l774R
o1Uek7Cr07Kk9lyge+28HhwO/2woehbWhdJr3DZR2qHbuRgxVAYXzmjmA2g3FVCmUN4AQfN4Xf8Q
P0HhUwJg9y/cmr6Oj1M7VKbAqQDJdd9NAO/3x2VtDsJn+a/7Ns+WR0Osq7tZg2EvARFB5Xn8adGA
DJItyvQnU6YqB3GJ8R4/ve/VWrJJsTirYdB9d7lM90DJAUyJ4l4jylu27TA08N+ZeYLooF+FTWwi
1R+SdaneJ+cVtENcQ4Aakbi6EeJw2dYOD/NJivlNRYHGoeD1I7/EbfBgFd4QIa/0l30qKorFxWFc
zmR/bZT+d9d1nAOJbQlM94epk+rFLzxd/ijQGfa8X1opAKQWYODM5TimyGL63TSzudxH83DOxf6B
FTt4jvPqREdPpgQVRwChu/vafPm7JnNpuZPowAdy+/vR/Ib1vMHYueihN7UV6vBBx5Q1ehLHRQiu
+U8YbVRbbZAHsBW57Bz9HW7SIXJwDSkEsfQRNmChha+H+VAMrJqCCHqzDR0j+Yan62WFHrIyqVcY
lFMRqL3X0qEeABG03l0Ij/epVP1xpUgtYQY0FHqrQAJm9hfngRN62iEj2Jv18VnPDaNohYR5xGYE
EPm4hgJnmg5HLk9KelC4MIoJ/vf0spZPZ0WSwt0hGlI7qujyQP9vaa6c9bbLucNUDbfJ0fIouP+T
6pJIsgvUnM3sfIThrHl/kXwGwKS6XlBh3RWeRNH0qMMWvp2Y08O0hNh8jSQjkIfPf4eBBlkicRS5
fflVyHQYWNQ+9xp5citmQf2BzCop/DSJCc+g9P352ueUCU4QZDz9IbxL5K5CyyIW3WURmEIHC9ae
EmiVjeKEbxtNGMZ2zwR9LILg54ucG6Lfntxt14md7zBCLnKAw4zk2P7DZVQfj3SQVoc4uHd1jUOX
OS3WneA5UnF60ZwFKX/asegrnPCUgcWm47b+pyCjdDG9S1J+V6wseDkZPHn2RvsvAIMW/YlaXrp6
oAb52d88h0dVZy/qkibxSCBoo7NSaGQtifQ9Fv8LTnGCfQUVfdu5i14cAXA0hkXHzhVnrnkp8G+N
r+BQuW+oJfAbzm==