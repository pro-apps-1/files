<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqzS818WyvWbFP+rCUzsNJ0OckD8tjAcUQwukg2b2LNqJZgcGOk1F/lNbimJZUWsLTB5ZUY2
vvEx3Ijn/yNdqLmkHsAx1939u6W3Xk2YCNk91wiBJ5cJ6St3OeyQ0KZPf3gWrMyUhd4sVRubuhWz
aOL8ZbCoCzcwHeWLiSgGGbBfA901WYbOc6Y5jWnYmvPnuQsWXRL+V1hXl4rqghvpm0RT9cDev9CT
QymRIru2I9OKar+rw3AK2QLXhHtpGx99WfZJw+bf5rxjsEZ1L4EK3FLilIPePyMD5PWwPHg2WzWM
CpK9/vGuQbWSOXoYgCwiaZUmoiVg+opXR7waqfD+oeAYx9uTe/X4pWTplKtZ/xvuxEnEhgU0kwGH
0X3zvULS7X0TVcxaSRZe+VpJbetGwOW/xKPwDJ5k98mnRIOuRJ6WPaijMi7JVObPwf+mEqNdGV1n
bWz0gqrrlw3C4NKg/G09kjdodfcejZWzyDw6gDs+3hmtExihqXzpG1g7VbCXUDZPeDgz8DHaf40q
5vDvhjVzGfk149wC6ZXXYHNOtqLVUcpfCElnBwmi9Pjm82I/3HilbmDGPQwc9lwf6BCie11KnFJc
sfjLaPb5L2VkXY6Drx7fh7MPt8Xj4RR1JxWsoTD3Z3B/zTqPWlW2XIJKdd1KjlH0lbvDSvJyuSxe
tgPxLeXMUdvEREIC9ljWnC2DxOcH6DJKIEZ73wSqLWRyKPQjiC0Eu/mLmchL7UvsOGIiZzs64kCZ
9xISOfCVvSgOrEa775HYnB+41GaOnIlqCNz0rGvzQLrt+JbU39cgwiW2rJjpJq1R9jFnZfJ9RSBP
XMknkQrmv3WCq46j/UkmlrRW7wr13Fd9SddJBLYt+169xgmfGTqW7eL7mshM4iny1Sdyj2wi568I
q4P2rpbcCxzLmaF2vIOz5mI08ixoLCfVK6v6w/meuFS8loBeKbO0mViCUFeQOaEj9RWo8YdBfvk2
heoS888wqE3MmMZErq3JckXxjCTjCh4dW7K5/7ZjgOjhBucYz+lIQEeYd2R1PlcfXqhhxQJdM9rP
OnNMBtVR4HpL63lG/Ifr39dfhAvNjrF5Ie7BQtoXG7ASuPc35yDUkutWTsMZiHmuQz09pLRuClqq
E8fMeeJio0FhvVpZPq6lbL3M5TJRWFKuV2LoMqCFJxskBGD2PE2FgxILmXrvpRlglHaXRHxH68zq
tS+XcBYonvbn1u2O1dOQPaKZtxF1aVxtjaTAlOvErDO4LbaJhjTz4x749WY36tssyQEivtAFf5Du
vQwVykFQKChto05nLUu4gV6fJ1ua84ycKzQ7HxlB7cP0f/1e/vsM5vll8R3dYTTVpBPASXc8ZOtY
Th/lRNjAZFik1BS8sU8zgF/A3qOa6bjE2bYOqt4bpwnV0ZrOLb3FqqMe38jD8aQHL60AYxGOPaJ4
a4wUE6UfdUL7aOz1sEQdhrrBRsxwpmiGbw6w8JV9QCQOhb18+O+say5zX0cDUV3IhgRCForyIthd
QMdXonoF7AUsMoVC7eMMnrd4j36kEt9gMaPGYIxiwJ/UoRh2/T6GPMMAxWNjrIO7Gbi+askribVi
Hh6XdDbHL/HatoPsd8E0TDdmUqSU/XwZIPUG2FFXoes2uCosrk8P1c4qCVwJGIBA6ouNpqUa/gDf
+nJGcshEY4cIP6M/Vxq2V+Dxoc/Bez0bosyGSOyVErGGR+4+KtqgJtOsQIx4PesfnK4uZo6fNoNG
6ikwTwl//ebUDZjmDQm/9w3BXEqPOAkLRl41409bvG9fe1t+wUHk5ZF2tan8yniuJB2VrWJBKpfd
sSuhAohLj52RQTTXMO/g2sGWMl5K7zlAapRhKtLFS96PUD5FgBYoAYo93HPiGUlbT3JSPEhlkfdD
I6t9e36awtowmZAEa2YgLOOqEgjlhsEWXc4KJKp1Lg5K6HM40I0m4XRg9bm2yZEzOnSHp8bXJYJB
nTeISxho+zX8kDeUg/b/bMN3/i7xsDK0N8WLcx16BUdgmGqB7VfI3GDz2tQDjp4Tvx6y9++K1kH7
of5X6bF2Vap+SkMFZ6+r1p9QpbIr7ARFU0==