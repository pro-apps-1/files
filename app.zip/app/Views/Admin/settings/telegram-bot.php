<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoVfA7+5Pv5mK2gzNDHRCAKFJe6OY1BFeFIdFYyzBQfgXhSHT5bbGiM8zaiajAZdwExUxmbj
Q7vaX59guUFeaHs2qSytMknvwbpQRGfmOmkbwdEn6LLRZRSCiz0ZDLf3rqhS/4/J2aaFUdR4AjT4
2+Luv0FSgsHeamrT+9QanZye8lhrJbx6Wdvfh7owoTgnJwud44ZPbJUwN8mVcnqMeU1A5jLuGrvz
VNWQ2DToOqKOgHYjXO6bVSNk9WTKxwRYb2UQ47jCcMQxLMV/zya8jBPrB3vxPuyD8u+ApSmjNcXW
P3tSHkIGPcHLt+t1fsiQQmf32PM9caalQ7jgr6DCuzwMMGUnxk3FXr7hHFvqWrtwRNKzhV7UN1vG
oC54SmY1+Hazdz8XEVWp/CMl/WAEYL4XxEx326fq9gjqPcNPOA8D3Ty/xtWEvv+gCermxh8Zw0Po
hmXfN51dOQBZ7V2EsrM3pb4ztajQrjiaptujIes8g1306cmxw3YhNJPjcdaHU8pz/TQ1OSXuBzkg
ZfcPwLC11pJdEDmNGf843Ak4p5o6m9tXu9Qnd2HO9sKsv/h62OHbNSREjoFMiy0XdKCLn9OXLF/M
IMCimyE65bqQQYMPPyfpeq4Pr3bZtk09aLm52gDjIBGnDdHR/ny4l10GBL0Zuimg8mzFUVC3Cc51
pueYj22PwMq+rxT3Y8y90NLSLOHwEx3pCfaDyPro7nzC+HD0dUYEpvFa/qE0ZnyOOglmwTbsDMs3
TSAATEPQ8uqgYSAFMOftJEXaiUEZSH/QDpHqPAaK9pCTAGvVFo+tYN+NIjIHw0dRKdinRIRmTU2n
zKS6e0KZMSLK4E+gDrQktY2VsAGqNkxNfczxSpxFzXXWGreC1UnP2PpwGRyFWl4xd7zCA6jM2g7e
KUg03lb88DXqWlTJIIXUvxzkOoA6gWBUzjJ2qajBxqHvcPALexypvOaZ1iODc88gf2bjBRUBxgix
iuC2q8zyGHh/KvYrNsoK9o97nhr75QJdPAI47sFmBjZB7p//w/yMSobTxlUOerJbn7TrDuhpTpCf
ObNQ2isp1tVXZrfFr2sYrBFBJbvt1Nn9/6yH/tAdRN/hudYEYpCHRclKvettEeVpvtbIQkBchjae
XlQMVrWWymWCNnsTGsJudKibMBT4ocl4jSFsycEVRBLToS9Dclwdh3RqobEA5qBwpfx6YIAu7Vnr
q+dbSLsLdkXkD6/Zpu2wYPkTNoBL2//ooinCIeDlLhOK6lON6liEtl2wzji+7ScVYtQ2mXhGUJXn
Y5a6H3KL/o/jbDZ4oMYCaTybMCrIBLUNkgVu2sqFRIyIyCQYP9pzgNbQbiyXf69HE4U9Wm+zTF+v
9+kIOolAmtB/pVxR5ZJxwoLzOlCIPY/yqj9QVSiUFLFo8sw2Hh/McYmXjcGPr3q4j79U8zXPi6Q6
oo6sX0ypfeYVsCraUX8kNADCk4Qo+xVobxOb6RuOfHX/qTPiRG1sAqIsJYMzQWtgisbzYx8MniYa
0H4mzt3FZnfrXKqsvVD4UQfvDamkEDE42WnYf0snv9JFQ9plEC/0NwwRyqn3llsUbYVoQZSdalob
RdmLySPFweMKVPSnz0IH4sx6bJ61BPK/1XsgK6D7Wvi6UnmCX54eas9KaI16l2kbNWbQpDnaR84h
sy4CfTvjlMGYcPXpDWMT2joU+LNK66La0WcfOWYI+rn1lxi/TGU1sHwVO1d+Z75RCBdH9lJK1v+R
SwqOQHZVsJd38fFBMa2egOnKw6L2zu5vsRMIw0mTe966HnuVUoCb4h7I3d9NzN1qCyxiWzUHNyQc
JiQ58qy0zJCdqw5i2bGbtxLTB4A2cXuvXpcS13JurbjFJ4HIYntxLrIztxmkqtFOGcLqFR7QnBHm
nbfDQ4Lr8q7bZAlDKk72+WPpqrx5Y8ZegijOwC5rfwFT0/K6ynWL5gizER1soir+fb9aIvhR6m8h
BjkmDkVKu6EfsUI2VRRPNTfj4Ys6+xf7gV+fXY2m6I2WpUBEYtxDf1vdnMC3+2SQAALfdeJVoXrx
AlombricxFTwkmQuZueA4G2i5P6Kbm==