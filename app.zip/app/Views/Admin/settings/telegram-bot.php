<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyR2rTRRdIuPeW50zS4AWtYMwHCAtU8nL8kugzEtLD6sf8CbEkRD0aRJWJJfLiGdHw6cboDH
NJD6puywoXrqTDwsC9YR1x+kZ0wtQmO3FV76S8uS6k9GHEBUCU6xyIGI9gUbi5KpKMwSRgr48ue1
xUrOpdSBbdCA14kxEes3YAHYWS7m9uPoP1uX31FSSo0S6GPY7K7cI7oHAs6GHWrQGExjNgxQz/2P
xjvrYI64nBKlhZPZdMyBih3hJ/ZUcDcWAb7Q7xeLASVpR/ki6MzQ9EJRHIXc8ooSHSXBV1ZgakmZ
vMOf/uQPMCSOvqQpfA3pJp8CgDwV+PuC6NyAGexwuamu5bSHM35Et3dNUR2nkTs5r663rRmBM1tn
6lMmHAZu25XL4E7VegPFLIkmCRCaWAPoW+eQZCeSpVpU4q4692Ai6hRj0lOF5amK5+zCpdOAwtU0
IuwlztiEURMyKSsR1CPodO2ZqT4JRr3Vc+KoB2ok3Oodg5YpZlfgK/DFWsxe+JFYD4lmZqTDyobX
svQS2pLPPuD24/Z5aqPD62s3JBQ3Xu4ait+hV2KgHdGHAha2uwuvq/wi7eq1hpueREZ52CLI7w5+
GtrymXQa0aCxTGKPVVctEaxvMmZJfZrGS2JzNPeQu4u1kuvt8MrS6IWmiQCe8yXv6/XE3i6VGNqI
z188JYdJkgnec3lRR2e1PuvcPh1HgScwRwQdC2SHNyE3Lxhi6kz3Qk7f09UjRjK/Zl0l1J+AIEgB
1NiNZID+zj83IwusbV6/ClXkJbV1BihG71ol137LW9KGWOacZm/z8n3c08PBvKOr/IqrIQtLn8aZ
1vI66m7XmybRBtfwyChd4Df2Y1OL8icaEOoq5XcmJx+LiJ4Kw5AfyunRr2ORtiGMTeN5EM3bUtWq
SqKG5lZNXnV3ho5CK0/XnP3yfF5T8it3qkmSslWj1dybwJI9vLF9Idj4+X6DINngg8fB/UvqJS93
qAOT/DLd3xOsKVylpu02TAaSbjv8dmgvKI4BaGWMK8Gg/jYOo2H9OvEzqvYxtIf9R2hV10wpokLA
y+tYLhVBUUoiYV9NsSeuwPnP+0vT+gItKK7wfrM6jIs1yLEZ8nvYk7DlCpXPzg57gjBis2fY+CrC
zc0srCvINsz8ZUWS832YpgIiOoG3ucg41zYumhZKjrBjJZvFug1LtoPtvNkb50mVrLYgjuXuB54F
JjpTjbj/ChI8isr77TpWWHNSoW+20gKHDvdqyXmkkZjAHWyQXG9dabWZ6pE1p1fMFuwXr2v6UCVz
RN+30ZdNdo+/3bRJCEgjEbACDud6K5y3jfu6pGMKRDREEzXt84PtDYhigy29wN4xa4XvvrdwQUp3
bK2wWwcaXzVqhd3BC8zWlKIB3qVK8LkYHtpJ7ZlOMrTVmIaxKvUPHSXsfAx+2nBZEPTv4KDfD33f
cePuRV/m2KFY5vuQmeMV36tZrwQntUWIqeRYNmSR2qSdvFpVIAmYEpJ6Fb4hRBY9kld0UGk/OLPi
Sg8d5WoFDRs0DTwNSbdGZXY4w7l5jFf2isBrF+W9BzsJMd1Gx9lWJig72MxuIhf338NiQxEt066Q
SGnaaQyxwaEpI6Edgxxs48kyc/08mtf8fkblhe28WCDCaB4QDwloiJDLCeM76RgC6cHr3wLtQRS5
5jVMv6eYfREd7VGrX3rEQaQg6I/f+cLRZ/VV2xEpjOSJ1uU223Ul3k2/gfxaO+sb8QWne/zQrko6
ozw3X+AK234fLSjLe54rRCQ9NYkvZ/jfqxkLyaFhUrQukfmadPSHi3qe7z7Nubj2VuN1WYonP+Ex
Gz6gz+uH8pS3EXim2hoOFZNEMbNpst/U6aPs6AKkN9iaKyo3GgJ0jld8PkCXlwYw7lEMYKj1fotw
0sVLzyMn4HUNTcLxHskCuotU7bhpowUOi/INglR5eDyg6ENrUSf0fp0CMA+KAZgQXz4OIJgR8QXX
nQ7ct+8lhpco8AyRMtPWr18ernpxo++jIROFST6qqv1PbfksLuYjPJCgTItA51MJwQwAvPuluoH8
I4K8kzsfWDgNAcUKfNaJ/u0aBV4v0JwjPavU5A6SyRU/IRriawPm