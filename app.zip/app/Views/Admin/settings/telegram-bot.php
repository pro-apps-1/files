<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/8D84h1m9XjdCwrQGUb2srGSnx9/iTGm9QuyxYPmud7hYEw1KtQbjnkelmA5NyuvKctfWcr
3PdbQ3xEnewiqBhpOZVUVpfdIQ8a5h5gZ//K0QUcsSCzJlRabCqzJuB34/GGcOu6voE/GCkNjeYy
owFLdjohX2deBuBJ1pdozdVIvRY862uROZYgIRddFJWfilobyTDoyBKAYCR1qyYvjz3eo89vmdqC
I+2E0RAeuyzrtqQaFvdVM4XqG7MRp0fi8JgK8Rv5Gtg/oOGMaUIvJ7aVDlbmGFrJ81ka8Vya3y49
zyK7/+VQaXw5p5vIP4JdU1pMoneqJazF41/Yp3lx+9lJE/ozD8n4ssrL+QuXnwxUg6SFprLtjkkr
7qGboJQmIWuWnWf/w7SF2dFXyJxUIXC+TxAZAgZpY19Vdhdb0NhZC9TWrluJWu6Coli0Y6XVz1/G
/etDU0UnFSiT4l1M375fbgegerP4Zxbjd327ALFQvRUN1sbWLbckC9wo/GYsOfAgBQDsgdiD7Pvy
Dxum7ZdySqS2gCLa6zLPyK629zvA7QP/H7kuAo1fD7g6f01exSmHOdZz7cgYgs+b8zCxC3uVFUMq
sgjmSQnVbkYuyHeoixW126mITGz+9LO1/rLdjfl1O5i/SBfxOGjLNCvEU21JhkYxjsGgNNZOZujF
v03YFoWOEiIe2dB1cWiEVzJw4LzGkNC5cq29p2mmc8DxZsOa8L9tcxzi3787HKIioYgVnSd/buoW
638M0SDIFi/8Iqiad+kGzrLuaCeL/JB2V3yfBkz9r3439BK8yddaPoMo8viBh3hHiiy2FfY5Ldy3
IsEjoigDxor/2iYkvt0bA8BrGB1jE/SFBMLxdtnyUuKDNigIVtgO6DgKTTMxjMcr5QyEsOTBPaH9
LRwVa1tKBliRbfIGusWjQMQcgzVkd946Eii/mjI/V6LfnHCMH35SB4TRQcQFdj3nxrYP+lX0nBYJ
PWSec8/Mxwlf3YJj1//rusEVBJ5wEupA1u9qWJfnebliEAnDk9Q38hRKMCYGeTFXSuJ1gVQT7/RF
20n1WtfvRd4+YTyNh2f+7JkMcMBkLutHEIAZgobE2GEmSLK5fb3xUQfizM80OE/wiZIu7AYRiR8u
Y5gkIiZyc+dcqWfQt48HzoMOHM7tUsGtqdrpc3RowrLm0ufyhrmo2Fg+DcrtRR6Y4E7bmqiUiyoH
zGXwfTsJZNr4TAeJq4g83XSlpjAH418J2hAYusuJiAOGndoJPrIicIG/xtz1rJei3xPYI14XuoUw
DO4XOP59nyWiYXT+uWIx+SByZhLqppSAh79zy8vBDa2E7a0QTICGxfOI/rjUpoUo0mhA3a3zCzw0
wcFCFVy4k7r/Nb9np90LFtn3q4e6NVku3noiNIscIxW78qjP6xb2olWjaZ5c8/8n8e0235HBnoQm
7D9Yhqum+yaHMNpnRMGUq5zvhTRuI/+rPJSzJ9h11I8rGzQ53MSOxoa7C5XE9osXxlhjHg4s7bYm
huvcxesRy9ZWdz/6XkQkBSDzSWikRhOB3zVVgnJKXtYCd1/AXAgimvvAphcGtN8ty8pzHJ6qoAQ2
qXed++A99H8XSxn0Hb7UnmuW+XkP+txHMz2/z/LaIp5ddcZ1bQbDWQYV8SOgkPiR3QXq88C9/Dpg
P5jOEuXsexeCVNqA55LfbXFVoQKhI6fgp4jvaJzXg3jAYIoQS8tmkpRkP+KzCbNOo08KDo8DyOMg
BdN3GJZznK1d35C44IoJhmakStiOwUldqscmXwxuJyG0UAqTt3U68BxOzyyK84bvZYnOuAJlk/rQ
WZ8YEFX/bLSbbKqh3D3TefnE7k9Y7MKjcBHr4FeHm41ZQIpLuo6+alr4E7nxf9H9/nFA/t/LCUV2
Z+gkO+/dE6TFeqoIUXF2YFXEyNhnfYFZdY1Rpd4TQdVnlH2TDOrekJ1ijEuPmLZWiezkyODOoxv9
YZseVtOrHubdWmKmyQTxuOlEcbyEFlHn+WQc1U0sVa5Ycg0p0/wwEe+LtfGjGY80mmY6k7GrSqsQ
SeKQmuCIhDLM+yyu2DitZYyPSZlFo0ryg++3bQO=