<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp2+jusC40oYINqYhbQGxxG09I3J5faI+keu9KO4depZ1/WjXBwwtONASLz6QFRVIdnG4aLr
csDJGQbfXdgzJi8+I9icbIfuDj2yB3dmpzcWbTF021TDnK4ADxrRe7ReK4PsO8711FyftH/QYYra
f5vyXg87j9UWXs9VY7v/L9Hd+2f5Xe1eWWtEq70JmyeFzOS7kaHXN2OrpoX0sFugIaRui/7Wn81r
n6d7iljeiID/IiGTNY9o2AZ7fnqgj1jk+TQG6oQEb7DkMzWmxFyeSatQ+elVIsU0q4E+WZ1Wf8Dd
pEgTrshIETQ3K1NA5hI1xaKksJBmkBvafceEIDkBK8HUrys0pTpWYOuRBLyP0n5cWE3CNtJ+o83R
BEmpV7N7FQoaFG1s6hUcI82KB5B08wE/ATFhttfj/h9bFYAiELy3LPZS6CIXjhtcaDIFwgz46UH7
7OW9sac/dDXMfJWr2jgLpYdeUDxVVGZSaZZdKMjNdGgycl2LdApOXj2kIBLq6vtuHz7guzE/bEkv
q41MHVFOf16cRFseWUdUpuAkp/qgCY2vcmrlqR6N3AvnC44dwY1PS8OJGr7jYcqOBE/bi4fGB8UH
lHilFbEMmB9bPdONAHTP3YYEh6cALGb4mgBu21UCcSQJ7zLnUDDUustuL0Eb9V1vSKATrv484wqa
PkKwVsSgSfv+LY8CNCQKVlldP+ri1r9VDbEsEYnKqwecVNdbt3BhyPPR+Qd814v2Knbk4Y9SkUf2
D/ib19R+ZyCbbxyccFVgRcseBk37sjRuHMgB0Y4c+0WI2tianWB9apDHQfGDJg0Nm9kQ6XqY+v8c
tMQ0ACL2wezZ3wM7BOFDJQIcl5B74xyN9+RlfZ1C9hcHOOnKSZcWchlpZqBcLy85SCzUirxTHYYG
BwhmY85XLxsmUqRsWQM+FKKisnAocFaA7hH4GkazvAulY5Pq/Doe3j8Rv4AZ2l8ua7nUg95HdOgs
HGo/GjV3/Z6eGbdv3kmx/yq/9ESsPyDjaGyzhGdBJSACTOSLnhdMdLrHeqreeKoyeQrzBzNLtGPO
BIfyN5c+EU/U+GpszLjSfRNL0xOgSoFeS+pGL+h4JSwUsskvjrVTfhL4s4DYgOCAuC6Y8C9K96gj
XO7j5otx48cfh229WKHdKeQtpoGrcfVUZ4zHbfCb18qdeMBtvkafMel1+iRRpvFZneoHOLXiez/F
fZQTDrHG2gLmOSqgtojgAPMjm8K5juhBO7YawCnQR5jJVPcPy/t8iEsTkxDgqLj0/Vtg6I7n/frg
9OYFwqwU7fud3kRBgvYnFwurm/NbMiN8RAXs52q7V3ciaPfeDdsvdoOQqIB/uSXtsOp1wRNCr645
OT5fhuzWPRdx1pBpnExEa1PHYwrnELVkrP7QN6PUZuyluQSVd4dJ6QfxGqTzBBjFXX2+3L1SVX8x
4cSmVZjmrPOIZ3Zrw/1xJoMDpD3iqEPDosdvo1lzhtAxe77+pnRibxjHNvTb6BLol7w1QxafaHsS
s/nPRhgW0TMTGke808nepQ3iVj/kcYxYaqDbufR73alTStk5BvvfkfLZ4x3mtDB3O7wxW0cMd9Bw
Q9FPkATQguI2MSwVlOcb96l6FfkXq4u8cWGffAb3Jdnow/s/A8IiB7ySMb2Na4xdS13y0KID4Bq3
1m42t6556yxPayzSkTtQR/+ipNu0Wl9rdm6JUdd23MBL+NTmK2xVt8ywmcCJV+CdYLt2zTy7vmaf
T1Eb+JR1Ul9i9TGXOcohNorUh28DivnwHW9Z5TfKLtreJQKWN9VFoBbExzKZsLWs12Zd8YjiNuC9
GWfWfdnalIp+FYEkNiFRebEcdZ0+zk0fsnun3MpoelErtDrinpkHfbrrXMzHAbw1W7of+tUNToqC
Tjs7eeGNfBcD7aiDnear2YOsaoSjRPUtRM3qbd0D78EJ+8C+eFMJ12pBE6qQmKkwm0gqhDT9iLIF
S+Fmxsy8tY2qjnDFOTzCj/Iyc3K0NZ2uNtYzkDJX9GwRBTAP8iw4KxdH5YLU6aEfQWUvwqC+eP0s
7GXVTSjQzx25MsAVBLfkksISneG=