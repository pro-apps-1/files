<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs8lCVD8fed45Uoaq5vqbCT2mzWz0CqiH+ebOyD4UCmF2zBow28nFUEfNRLJyHgBSZAg4qG5
jh6p8SQPopuNnli0k97vu7wvPQVXOD0rQGmj8to54u34ixyLoR7kk+U3hoYOzHr4SmHE1nf46/CX
0fOB0BtIt6c9C0SgAtMRENXWa4u75o+pzf58NPfkgKABKWOptTYjXVK0UrHUMqwsEYecsGi16Ft+
LrDt13IFpETGnzYtlnVlvQKIbpRDW7n0tjdlm0mHV8PEId63IeTpZQKxUe0Kg6Fg9kEr7q3FmuKA
rUAsvrN/nldR2x6SH1mYvdA+soNFi7EJUwKtoLsBNiWT46uiH9Hka5b/wVx2R4tr/oFg5Hxkw1ls
WLXXhnPXOCbKf1W5i/v9Y7zYN/15i0Y4x0hPL8eQ9cw7kFoz2rj5+lmZvlUsNI67p/0CX824UJAH
Q61DJMzU4VUGVEpUQZOPNniiGYBymB5IVngvtrSWQJbvDUdKApAArIE5pG0M9aDRqkBESpSuHlk7
GIczFWkA0ubUwCUGPopTzYT054Idn1lf7qSJlxlLmRw1qpOl44HPgN9MGk5jL4nUSAGfFsNse2ef
i8bLNqBghXueY18g6XXggXNC4gYjN7x4Oy+/HOU9+NNsCS0LlcTuPvit4LUlbEsY1gOM9+6R4Hdz
/L+Itf1FRvs6EIvp+wwCdeOJtQAwVhiCmfEARcCG3RXZSJu9YJTXhIsVUCYMtFb5Klgc5yfLClaL
Jr+xXoU9PvgPdJbHdzMIMU53rMr4gVUXR7cj5rHm593JYSp/f6EvZqC4g9mKdBS6z33PvUSQAC8Q
fNdkvUNi3zDAl5lALALIXmnRm1kNECQ/bCd66g4NROMVkzGLY1bWKM37cQabssrNUrGHFV02t/IH
Zn4+NPJq2VGqpY+nPwM4jF4dlTlEvY3BxoGwYPCq1GdDWk2zAX7qkCcHMjW+Uzr1tL74dl23iGc/
957B3jzG2+SPyTXXuiwSqGbW8ubbjhBPOoqNwWNGl4Fu2D6G/R9clr0rLe8LAd5ziMX0ot+/3Xbf
sjiE+remtEeCdtmWeKKFu4ypuRM3DvTqucEiHynEIHeJrz410BHU6fOG1/D69SFjcqpUS2oiHKnz
pt4lGhe8oPDidwnPsVordmYp/2FQIfHE0Kpjs7RhfLIlFvXTmxxStem9PeYhVffaxPIKfGg9nrW+
ScMvr9pwzKuWI7/MYXybmyoqjUBXozcVDEc4lY1U4urmpprzTtVXue1e1Um/osTIkz8mIHH6ZYp8
oVBivZrHZGP41KEcNVGZ21DyqBNITrkP2nuDWB2ebN/U/id4Dzckm67s4cQE8JvkFgC9w4v3hm2Y
wjCauI7yvq2qZMSO5ZfhekjbjRBLIpdzMtxawKum3lwj375dft9ymZ3d/I8xEmJtLk2UvksBzHE1
8cBVMT1dfeSaMzHzrRRM7CFZgVZDusEcNY88ch/tMse926fkvpucD1BoB6mdhKsW8S5ldGk0ddQI
lKaGxFuveziiTleCmRVAJxogC6xtdNnOTNEhtIfmhUdetAN8z4XdqsffEovazFhxpanjL9u2mIDk
YBgyEN8xYPKdZbabl1dM+iD0uheBfteQ3RbWzR7S2OhAZtPj193QJhccDkeuZMCrW5f41Qu12f1R
tOszWOWt221GurDt7REZ4sVr8i63UAUB1rjq1ZQS03bNXmzAzzOTuF73xfxFWLDeBunIBIrDfj6E
W379GdAFIJYlnjYrk2Pix2nDu3hXZabbWFhER6nIJTv3uGYIABVx5oTEd52PGZTDBbNlC3C4vtMk
PA6vZvTUauH2bzD1htjOPJeI2xcsVm0vpZ86JvR5bpG3N8Lkq3268aEfcm13HJ0fBwxqKNHj2ymf
sa/C+eGY5/f27EX/BDb/WCDQFZ+HY+Zr2HbiHUdBxsftVxNXBuLUtTyMfYKuYVWroKU7CHfj4OBE
dODvKlC79WSKMSw0pQlU3fBa46JbJ0vd0gU5eQU00AH4BAHH4xrjlbd1XaotJceV68rEx5d22NkN
+UdkLPsEQKJ2RWbTBV3VCgh/18ePh0==