<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxv+ZRioqNMyoxqOc7X2KvDPdDC0GI0M+lDjcgFFv32PiKE9uGOBlZhF6L4+b6LtJ2Fm6diW
RE71jdctAmJMEfVXwdrcByD71OD44/lIVcVyqJDoZcfOeiGMaqr0cO90u8vNlW8Z+XvPETw4Ky1G
I1GUEeIaM8dd3nEZfuPKtqMq8/F8BpS2h8bAsyVlH5WKqCq/+P0o0gLmBxq5UyNqDbd4TRmiBVAo
ukHmqLI4HOziy5aHPDJpQruuikHpJy/NojH7sIpoY3b7mRaD5DgPUrjRXWNKPvcacFrC6dFl29GU
zz+bKtJkt7tXUbeig2DftNn5vQyqHiCt1y5uLMJB8xKJP/Wzd8rqEgIs0zBMds7jA26PxiRZWW/s
/OliNOEGUF5vKlYAOBy5vq1b7j4PTnj6KXEPU/Sd+ckMS5PYoH7lIgZOqTD9RI7LWuzEq8r2o1C3
FXsYl6IJ89EGKufpiPS+pRtDAe8gGdnB7EwcgPsiUjKJsJjLdA/jjCQpk+xwttrCTaQnI8sVUc3Y
hLsolTgyZCBXzfKZVychRLR0RcscDvBz5XiGtrYvKrC0lKpWoWyJnCR7LaD9ikcAXsv4Oe2l29VJ
tsjDXoQEWKZc8MUl8wjaLIisiwb8LjqV0z6FuOJBiOHnq1rcevC9Y1ZgEr15l7Nk8IcZx/6zW7cX
7n9Y0IeHFpHIw4ZW+8VahCiVIR15/oZO4uQC2Z5StuSqK8eZQ4OByVE9xSOCh6xFnGCq3uw0IRqK
uT7R44DNQDRB3F8YzDZNtFcHOG5yDdwaeJ2pLI120ut2gISNMwiWbDBfIQoLEiQHGGCHrFJB6uCh
Se3OIM5WSriLlCvbiwQGo2s0D60LsbxToA6zKlY6M7LRW5krFim+vAipD0ArmVU61OCfknzsEiI9
B0JACsjb9JteI8HVJ1lZxVVcDHdblo09QR73PjqkuD1BOkGkCR8OcTnPPAnnvae2dgHp0jcLrkL3
Gs6KJ+/CQoHMCrJogHPUOSWW5XkjcRNZjpgd1sHhYDMaJwPAzPwME0j8kWtXvcDPc7RRnR61fn8G
It2ep8dEC8mRS3L4m/TGAHLEogrNc0Zt9t3Uc0tnSyO01AE9NUBgo5hZZ+/WmLVJgbPngXNJ9yDg
kn/SANecJ8yHGWL/mHDxo1W2WPWVv2JZIDbZ2QVBytr4L954OTKB/dc1xKHWNqr5cONp33iBaKEG
QU+cQlamfvQ6w6JUnjhviJiAjDCBsWWun+FrMXUp/+om7XZ1l9+NM2MHJ8ccqqM8FlIldJ6Rv50J
kdOcboS3OLmcbe/SW+nqifG8afJiIHmV3l2KzYWCFQmLRDNPJ3azOC8zE/zz/EQSTnJFgMdCWobW
qJRAo+13bpW3is+UwbQE4c1Z3y16lkG1I3bEwvIOng2iSysVNIC4m7ZEzCnS+vVDeUfp/B9R7D+t
+ZhJUxHH+SMjEWIAttOPfzOtpXFMLpFh9NWTsIsTPqiUvTiCNh1+scAgLPF6NciAJM9UYdfA3CMh
FNHUGO1o4jOv0KpVwd16O95B7Gg1Lql9kGTa5crBoRscTZOwjIG4XWONv9JFPLjB+b3LVDYPyUQr
MxhHkMhvv2QfGW8Plkf3rGIikPduVrzlhmG5h18mjp6P3OptC1RIJA1rcsM95WJIEroqYasobs9i
7o5Wtfc2K1coOizFWZW9/vV62cc4YSDA+d5cj6qtlE0QP1XlfE8oR5rrFzvpteXlobvLlAkhz410
Ncu93zTgPjDoZ5IdD+u8BoZ5j3akEUx86lW5lArXTuDfMV7FouzxDEXyKHaVG4I5EorC5JXMZZuj
J9pnjbRQle6csfxOvO34T9jbh8UzAarP1yevYb8jxuuU4xYzos6XBP6+NJX/NqapRW1oUY2CINzY
nD06i33kVpOERD4bjEKO/42gUXyg4CnfE/SDnNTGNPrmSdTLg/nGf3TThMhwGmmqqMPSq9pmRTuq
Aw1PsURquDb/lvKKNL+YlNl0mWzEeIGXvBXd8IAdbmjBHlFD/Du1/bZ50GqVk3K++zTbP2CYIGyI
K12OnB/zgtCwPePzb/HmqMO03hvoZELt