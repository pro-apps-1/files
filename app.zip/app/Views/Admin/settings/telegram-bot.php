<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpWPbPEFjssaLje0iCoWOGDkkD0567YTBOguMPjffe1IWQwqwgI3tyKhZXn3P5GnCRIBVlGN
LUUC+RJ3j+O3t7Xzk7m7OMuYGvK5lmFqX1zohboJPMn7Y1SMqKEDcRjrKu9xnbPfwkJc+7b2wLE4
2NREMjIzvsfm8hmW0r9lU+fcC7DuA/xXs+QgypIYHqPwduxewUWr7lBQ+RnYI75/uag4y/sq5Fhe
3imiTN2IyF/3j6V3ZwgPZf2bDKM+rs7SP3yJLlQDKD5JiWCuRryR8iCogkXio/yePYmNoNFNxa6P
3KWZ/+QfD7gXg2MkjfsNBb0V27sPJbrFHhlfCBYiC8k0Vc3P9zUxB6avDi/Wu0wtgQPSEzp+n/aw
+Vms5uMHL/Btc3YPto1AZv/B5YUg3l9s7TYQ63W3Z7Maz/IXdWJJsVVhCnz1FrSPPT72U3UeEMVI
Tn3siVwnwmFKVRRzmS8pLrwGhyNQLbeBOTgnWJJ6FON9VBpxlDgPcZxN9fJmel3rAoFXr1Xe8Fa5
GHDkalxH9GH/ORatr87gN3Vltz1eATmXcBMklq7IjTf8X9fR5vFH1B3RYehSxyBYeAXSQcFdLBzD
QRgOoGMi7N1rAS75JOuUvyZ4Uv8mWDcvyNoAr0RlPabVwCQ/U4Sn7hOngY/mS/FYmNXkK2DEFNZe
cu7/IpHh49NNQWMfBaT6cWRNDlShRYPj+LDseTuSnMGJhnOqOdjP/xVwY+f1Pn0fu4jkIXrJHytn
bBvg/ArmBawjlm1uxQo93Wem0998u3iLYbX2xc+Li8LOPwnh9H0W/FqNclMmg0l7tFfIcnx5jDU8
wXIBOkhreT4NYiPcRbbsN3+XudV/WDgTab62ngOQS9ouakG/W7vAeKHDJsHDNNO8TUQYRZQAOqwq
eApn5m+lTiDLKjQB02D272NrLikiG47jDZaKVNkct1AQLkT17nNnTq5RhX54NvVlmp/DA8JGWuS6
b1BOFVSe1bnJUFynkbrArpbCEfwzFtQzrTlzbagJkyzbPI63+2gM+wY0FS9/93jvKQca2gDl6+0k
hHHjc5LwhkFmKJguBRE7ybHkwOKgNqyJFyF0xJtKI+5q/OA+mQ2qcf4dUasA8xcNIlx3ZdmcXulw
SqrpxgLebEco7L0Mzwgu1vOlJ41B+vSKvoH+tsrz+ZwuK64+BBwlx6BRy8Z720ITDlGPByFb5+Ir
pFvowIxFOADAY9bBZIMk9Jaf5ZEo3r1pty19nEDGUHCAQOnUkdmxIHApvOo6o1lNIBFvPNcZ1OM8
f8nHu2RVXO6vgV0tBrYARkKclngi1UmNOPuj7WWdjhv9kyoOWMb8GG4L7YA62hjIN5QQCGhnv7Uo
8SW2pdbPjMbr9L7WbOuoL4QJ7TibZaF6qyDH4SUA5mbrO0PX/Ll3m2vIQLdkze1VY60FUfsn/fkE
Kc2R8OuxmxFP5QIdNTbbIqtvDMrChsW5QNeIGDL+UJOGpVLWeT+yWbPkM1ghXns3q61XSzzmLdaj
RTKWfaa4wvskWNOl0r6YWxi2SOBagx513prj2X7ytzXobjyZOdgOHOeO7uuiVxFisdB0h+nS9vzo
DHLFZvGTGdJbSybiGkZz5De0X4bEQuGDPWvTkZtog3C8WbSsvpUedc+u6dIVlURx3zjAb+Y0e1Fu
Of+/N6vQREuHwNj1rhtwsox1HsDtqnT9vRUQ82UO724iMEgNaRR3elTESMMVJ59ifDKJsWvLx7GZ
X7FJqg2LqeauSYONaVMF27xDzkDtGmxhtfROOIfPBAp/f2WayOb/4u2x2R0mrrzr8F9LoeVkVllA
G0xDKcMNqsHNeNKmUSod/18Zv+GYZKPRO5wHnJuLilGobF9ndPfNdv7ObjybMBWQwEzgk6c5Ybut
QoXMsnaOuLac9dpn9IcLdo6J/jLPwoReAHditkN7mC2oFuXl272ekOw63JtUDwSlJw//SP+Wt7S5
dETIR+x6/VIvq/vqdv5qFwAMBIrzqlrP9zsgQlO7YEUBiUaYPeTt7qfcC/aidMCzPX+pJz7qjRiG
/Ws0dgpD0m0CSv06BRzMEZiE1J2KrDSUieARVMK=