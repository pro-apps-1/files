<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPquSz2egiymDCzzX2S1O5wUe0ZWuQYSvXhEu+C+eq0GRpU+sL4Xq4JUwHUwuNgZbaruvCUvA
0bWdplsx6sqP3wOnVmTfy9bCkjx9rmdUwmlfg1NVMA88GqnyvJsoCX3r505eMrl8L28/LcShzh2H
WNaKHgwWoMN8cAKnvk1KDjVMdMgHI+w6JGs4gBSE9gErSj6T2rn0Jw/mB37fBATNrz4zYsujIld2
Yfj1a1ZGkszTfaXAfYvuTOray2xICew8vjfFwNsmmIHe1LU3zR5LSrpbjUXbxS3MgLm8SyLhJ0Vw
e+TL/vYfGYotsoWdyA+u44XYoNcqMdxNZM/7PwC4GFeFHFdoNwfZ1XIyG+kbr+xveqiCzhw9ufVR
raiAnzU1iF2AvwGPfzaGYbuxl7TU6eIzc7+PforLsf5EBDbUt0zhl6v9CW6D7KNCo8u1FURYrfa0
ieR4oqf80Q6RsmlOMXmDFJblJ5tZFv73BRDchaygIhe6rTM4wZH+AdNh44Esoc1lH930BavCdc8z
c+FIqY1oD1woO9BqBVCLEEJdwKAvwica57tp6ZwA8PAt7RZmReMCIr3F1tXZkBsGIcZWDpAdtYEW
Cxx1e3CWtzEsMHJJKn7GTB83vSKmB25W02TCqyzNjLh/eRwRT6h7wkGUINORU3NgIJCf4KusKF3f
vPaHlWozK1ug238/Cr10fgzYD8Bq43Nq2Rjq5J6Ax6TXhTRj9XjURoJqCUqI4iYM0MTK3PXJUdTD
0J0t425cjCgLSmZQuqhpafPDEpbB9+O6is9sZ5EVn1jM5lb4wLzd771+11azH+9jBta6Cb8jMV3O
gSWD9Tp+hrn7AQ1s8kf9yuoadB9tNblRdCNMwLlVHb5rQy1M1XV4fY0m+fk/4dvBe9B0DUne2G+I
zQsa/2tDqKt+t3de1BWv12b/U69HFhkU/hYlPe9J9UOTs6Q4wrWfcgNCXNnJBBRIFoRRyUz6k1Ck
i+zE5b3YVVogbp/F70mefV4i6vWUzaCBnHV0iSX4Ix5bUEJ01kyxtptUVWNNoVTr9ihU+vsYAc1I
qRVdG5So3vVdYIb5xhqUi2MFnXwQB/vDxTxIcfPMUQv1VjvL6ckAG7D4mxqxd8A40ij+TJAX0j3U
eqF/MEM88G9xrI/z1DJl/VM/DvSKGMfF7eXolWKmlKswrU8B+YZ8FoLBiEIkvXgQvlHE+jD5efoO
xtwsE2QqvBdMNGCNRsT5LyoOrmZiJwsMlQLh/PwcW2qBheSZodJ2eQ5BH1fxjTyUsrMHZqu0wwuv
aRek9V2MyMWVe7TmuxUPbwDspQJo+11Z7K0F2LSTjQVGGRDZJLQR1LicJmV+wPmCyZDAHvXR7cC0
szqTG1U9nVQy4lHkSdja8eZfSXf/s85ND6iPNYixBV6dtrzgLbw5elUXwMI4BqnAVoXToUFh9GKY
Wy2Bm5UfrpQoTjf1AqNt1FQAYI9w7f7/l/3H+PwgM9EOoMAaVDoV/L81oz63EX3SBEFno6AeIFt3
0yzKNc4QIk4B0VHgam1oRm0aJqW7wUd8lJ9nAzm+vSB3EWerLHsTiPujhIMwu73DxQ4fun0urlJZ
9A1UV13K2hzgYhQV9rBAmgFSmvgmTlJYIpqWfzF9xookbRncAgbQBHIHZ0BMJRgU2ucgmH9rIuxx
A7Uu0PV38GRNNWmux/vK/zLJTGRfE58Zp2JW84+SLSkPncDmHiOvQMxzvt69lygvylz84K7aJFmO
a8q2k0abugeh+Q4Mhq1cVTw9OTSsR0iEzlZvCdKqb2PBmocwm7qKYHKYt3N0fiaiTseORQLX8elG
kcTrGNoMOCHGa2BJ8DrFPMK9o7292r1gJE7/64oFN07x6vbN6CtrlH9mf9CsMQ2ilF4n6ndjPttj
fTw93mxEI8cHs6O/amR6dX8kt85wd0sWXTYjeUJSqbwSJq732K2H69ooSCh4yLY/rg8rpuduOmKV
VG8QsHgb22cwOnH+889UwKpMW1PvyfaD4Q/N42RceqkavU2Z4VIq5AHOrbONxYcvK2Pn5joF3X7W
I9Xo4va09kN/iD+wgegtx0==