<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwfmvWMAuTegKwnp9kARmAuhJsaO5VYa2x2ueplw8KE+2ElwVeMpLlFA3eMqgyvNznnqXqax
5AxQ651KHPO/Cmwfcm8YtHk4g0erFLoeIevOQaefJtEvJJgMknmMfpYtPHJ0eGYBWdGEqTNpJYVJ
vqbaoR/993ZLqp78kM3ayDqCUSxvQ307dGjO4lMEGv4rDyM6wl8gfjQAXhRXW7pmueepYkz//cFm
FLJ+WxZZ8xlt5awyNBSQMgAcXu/DzdDI4qgozdiIHdElA4AIKOIlrzpiUn1g1r0S4RU1McLvkqXs
JIK3/paKmLO2daqWpXwfamO6aj7I/WPKch43REiDb4qEEI/wRex8qfYIGD2V3pZA0sjapbWZu+PI
tQqq6+5Zfq3HaTJJ2sd6cYyMVXak0QlqbEOeG8hxBKxxr1ZjkSFpTIz4Mm2rAHCPrWUHm7k98/DG
+/8BdSdntrQoKQgplPGBttED0zJ1ZD6jHV1PyG9c4FHmAgdSQT/UwWVWP0p/rdY0iG4vL2oIQEBn
VaEJi9+cr+piBXvpRVz/QILgAdf09g0dLLer1xU1lSfVNWhvbGqxcg8Tvs/aNwuPUdyFb1k52OAR
gUVljLqvtJRekjnST87Ss6tixsoKmiD3XF3AEm0VPXF/7oyH0mFUsM7s+WqDfpt/dZ8/QDAZWzzq
Ep20aPzAHWG49GlAnbHmLqG9q7NZUHaQcsCxguFib73/drBSDv8dbt6ZwaVUkJs4tciCyrJ/Eb1i
lFrfeyMEYKJZMULfwu2pi3Er7h75U5s65MzjZ1zlER6wjAdffsAq4LhUXoUJc5DRQJYSFTO1RUbx
ER/Ek2zy5H2HmA3n5venjk2YasNogWiw7FPJjStQaah0ZClCCG7wprbQVT5pWAqvMOonRwr9p8CU
9QTLpWKgRI9Fi97QPfBJhaubluqABzc3CiBFC7wAaCTco9ia5atVCF7DQ4g5dRkycD0he9/U58aV
HeUXE//cxnlIiQnfpuDOX8LdeRexMMrzrZ50rB2xDVgZEeIKsv5otAMGcF7m+pR8KRYNilhv7mcr
653qp3R27BKO83Ub1upoVed4LH2OzjGobFnMFu8wk6p8zY5gHwBm2nr76D4KPR81GKEwVeViteEn
qJ/WUZvO5rzZEWz3/dm1nyGcLpcS0RirOyEdRbSzEhQSu/mLvCRSC0LuXDMJLZP7sRN4oWOAcrPz
IxdGzNckfIRHWMeT388cbCI1ktA4vTXVHSAQm2SD6x7shZqGREHTZQRZJKQdkrk9HhzWALBeYlpI
Glto9aWHiy/5S5DO3D7TmHPfUWw/1k6rursq/d6TX7zRDjf2jPXdux2n60jXafc6c53G+l0lxGXE
Z6NwMDWZ8u9d5cwCnMV0dFvi26awuZxssNzYtNm4w9kpWRCC0hEFZ2frn69nGpTJUHRjt59jCP1+
+P60/BhSBTy5Yh3sdowGJFZq8xvBokMC3oKfwCyPjLoa2ow9azR+0+lYXLyo40Y172NMc+//oOF5
IzVXk8aeZBkCQWQjdQ0Lpgwr7aXfAFhXlYHWbDEJUNVCGc7SCwhAUXfHAHAe2bSY+N30IaykQTrw
Ykuvy/i5zouh/XITucTNwIir1+LJvszkME+A9U2csAW4nCfCon9pJg3XqUL+NiRcQ7SXaOTtqHIq
h0edg6jQDxDy5KKz9h9Bxou1TubROhwMN5Y/Sz/TtzBaPWPwpFGAzQJPIpsPhUJZPZacdRUUjmlN
t37lJOYnxAS+kXSsO5fUjbaG2HfNrffyC6JigW0C61in+mLoNUjdT/NX2oqekxBCMu6B58nkT+tn
hhM7leCYESv92jdbphD1NqaiwUJiSluxYOm9CjGJemVtmMlrSWxeyYRIe0/zSVPXPv3yhkHSw2dJ
xt3XJrkjeOvdWnac9CTVnT7x5xqEDvhPbhFcDU1AK/tsMqt8PDFOv24feLl1XsCOgq8S+b5kxzeE
MruSZUxPgljonCj63DLHCFA+4hzUzUMKn3hQZTibB6NnGGe3JpKDOlQ9ghyu7o6F7GAShdi/ns6z
4CCrC/eRbW6DSVj695BFBkR1dm2OlYHty/7ZptJDHmuClddlcCr2/TRgKvcu037Qvj8FqRCPhczq
gZ/myPa/mgVrW6yHqNr9XkYYCGuLzXul5u0lZ14pUsDsbQx0+xXKPlo5FOP3RgpYEiQotB1Yy2fO
VIimBhoOzjmedlnoOXRHQLsdalKnKgF44VIJc6UufkEzhm==