<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+1DGVyHMmswy2AHrDmB6bQjxC5CYDWIs+QMu+ZP+ChCwc00lCP6e95I2Dj1oYiYQgNkl02D
HgMBZX2py8g0h4eVzojvu/z0nAteDVXFelb/EtdE+gkJLtkhQaj9wu2qxJjsHDgsev0Fx/XscGqM
lf+5wPaDE+Ao4HoBpAMyWOYC86yfgZIIuUT849cLXh4HtK8nQkYchaRq9EeDL2dRxmNHhqHnW78J
qs+SrgkzdfKDYo7fu82mjP616dU3y95wJRd4jTfc3gKi+VXMPDuvxUuHG9COSXwdMImld5cQr1wa
4SHRIF/H7SGMt+gHD16Yx+OBb/CTT78i6fE8wcWED72zU24e0wNhUhdIlLhSWvkqtmk5hQE5lHDa
Ou4nKxXLwnKhAuGPpinYyKowkD5SqGeke9fe2khA55wHyKo28L4giwXtwWtcg25d2+MJtqh8hSIG
by7Ikisipj+uyTrWL021XT9sXbSA69aJkVUTI9ydAEqZInWDeswTjGpnJdUFWwvGDMzghkg5gIzd
cqW96ER/fX5ExUx8rwdSsWTf66irmBXptunMDMLzUYF+MtpxFi77/AI1kiO6vK8/wgTLfUqWBqkQ
KWjAV1pDlDC0hElGRgzNEwIu9e5f2DNnW/uKhVWEz99f/wPjrF6SDTbitIcZ4cahDgFWnX3IEhMj
DlMakgZ0Co0A7iGYewVe+zNj04YUak3QXH5yck7STkHi5G7va9doDxIUjzxynVGU/SCp5wA9YK7X
ZbzyR998yavhhFVEdneBTZ5XcyOqpMlDlqzDCpTyoksOvS3gMaW3yyhO1Wzq+s+vdbFHUF70PINt
uAvmM3aLZit9REgOs5wva2YTL9U7SagBOBACJbH7LsHkoVNYtVTGZNvZRWBV+44hiGO/VwSrkFMN
xfABaBDgF/lY325iU3BZ5NI5dqWqgNIJKSRxs0dms+9TwvW76bLGsZAhFxRrjj3SvJ3Dnui4dOMD
MDhPBpd/Ivz245B5QLM+6hiW7l7cVh0SNHDhDf7bTs92xD7u0BgGxFNBQQUAVSLCjowG91P+bXHn
2tb3qDepGUt4CoicDsvn4WPwZPSjGXGY0HnXqvy1qdOX6WGtyCZWEPQ3NHArnrV/ivmSnu6fW+G9
ciNPYm99lgS+1bUKPZCGfe0hSHC6pfoP3E6nEFwlCZHplyXxV8OmqQlCKyCjyG6mLuRybvNYWiRT
iIgEjuaY8KJxS/X+1sjgH6QREp/kPwG5Y1JP7duOLduanofGe6NjKhoQ7Wk06ovr6QVU6+1vPKBT
HYAYNEjPAJBFuSt9aPfcugwYGLD4k4hEGG93bdwu/YIM2F/oB8zZfApn+BkPeZkJmNbK7YItwaTK
PWJlQ/Rn3YrD4iEsv9bZhpw/aLzY6y02WX8JKbKUuYiPvjVWLDZ8oq64SeSMLbaRk2js1VwsfYrI
bY73Nv0hBqgyl+/3kCI+1ySSel/y8MSniZPJp1hQRvED4uxwlNCW3y1CwG/YWG4j5MsGgAMTbMH1
IFvSqiSKL7p+64cEsBk7wIkBen62jgt92CymI2sGWNog3ouA6YaR6+72eVd2KPNJFO316hN3Sz+c
XSt/+4Ck6YeOpKKjqtf9LayT2lU6oj6T/nwg/BdDywuqkY5F9EEExg6pMgDtKcNzbQzVAXA/f3+f
nSH+HlneOQO2cBu3+PcIodhhzIhsvxrkoJHeAGbS/LgbKXsRoGfidvc5MsqfQdgjqfL7mLoqgAqM
MurZu6Z4MBJc5rJAdSjwfbQhRREnAmu1c63416/Um2m9Yxc+paD3Bm7cYZVjar68R4uXixsvHnoy
1Fq/ZZAc8hZAcNQCaNVvUjQOKGwjHmaB+7jqZiDFUpNTLPDMR/uoHp3pxXCzxq+709ymbAR1rqkB
opt8AWIlOwJxTRZ/JIE5d8LvaMyt7pAT9+/AtCyuUi1VcsFQPs14tERhnyc++9l8kmnw1WQZJ6U8
2u3a0SGZGeSjaQVr7cfMfKXte9x36+6Vh0LvLo2vvt0zzGMdwbZbY6gJJPPtVAJhLbpdcO5mVbl4
gtFt0qD3gpJ3Waa2MirBVlI94z0eZ+xhBeGrJ1Laaqqa5SmQE8hCWgdxJb2DTAUBnT5BbzjZ7iow
GwWStt5Ex4oxjCRv6j0I8duOFkapzCJw8AQx4Km50OQIX77BbOhEYnjl6DxqfeSe8n4tQ37rGvWZ
mR5OcHkbfgnW4m5L16BHPiA2lqVL68W=