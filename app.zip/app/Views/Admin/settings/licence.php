<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpy1EHm5iO5JqDsiF+6/BgAb03H3E7pcvDjjwFepuufO5jXZ2eSvBOzwz99xc55JcrTcdHUe
wF2JmcZPwXC2gcaDMqJRYAzNhC6rAgQSabiNnmlJa1F2vLCv+quU7KmkeF4FqkV1B2jPMuptK74v
5/hN+/1sqOZZFjmLfa8tGa7ElWq2T+UsuBXAkF2fAiRoKkuGronv/hQ+dwQAZaGYm8xDtfFsCIfL
Fzv/kM4Dr43wp/9poCyEXHLA+CXbiaqUOrZpaD1e9/nnbSvHrf62DRiLEc/gRAaEiT9aPf2zYMhG
seSw9soUugxDdiCiQsBj0tKPZEWMxy2ZeXwg1LzrgcaNZiuwkJIEaG+XGzH0Gjd99RWZtjGzczHq
Mp1byNtK1v5MqLiBgAAmYy0314mj0+ou4nLZQVuI+F3NkyC+o7e4FvXXAVdpJmy0Zbra+mX4qQU7
VXfYh9HwxUGWNXf8AChrfv5azea+fKdmVEOHBSQfgXlxCuLohp3w3wV1662pvEnWZshfvSbQXoUu
8ByZtWWOC5mPkXCZMhwNxerMlDsbpOxvtrOxJHr4gPV11faWP+TeKFwfhusQErClc9CLbBB+rrQw
9/0BHszmMSnd6Au0hpEw0Z28ss7ZLYWJ6N7uuCKc47ZoZJrQ3az3/onYjg9a532AfX5gXoYh5qPp
Re5NiqkcJdHqdpQ9p66XBmWJAjwoPXH/TFRPhz+DRSF7Jtwg2a2KbMzqxaXQUKSx5wD8kBxIiqM0
/pMWtT2+H7na6BcvvWPClPrCNhhkFd+MXBH9lczOdwlBUBgy2G6OrSKg8yEFAX1AMrc8WrUE9Q8t
lie6q2UnhJgoRlU2a1KunNwlrUK8M/ofw5vAVlc7mlzhU2Z8lhO8WUHy1tFr8EZPbeEQ4KVmg9Lf
48W2U/K63k+0e1PJNqqSKqqDxp0KtlQtlZazSjmnuzIOJJwczbYBkDfa6PP2RGB+dUKgUg4Xq4VN
XMLUbR42sMzK1XCdjwheGlzSxE416wJqiNfByChYeWdArLA/uQ0AG1p535KncfDEpFQjauuLr/8C
SXLZ1kFnO0eg2CyHC9Z2wkZlYaoHcj03m4FQdLWUI6nxvRhMIbvQZ379uri/O5aQmFd2l0i4RNKo
5iU+hZPn++9JeIjI9flfDAcn580BQ4mFb1VDoOZ/EjBQT+sY6aW95o/5KlUkRsfRGRnWfKdwKsAU
FSKoGbNswQceCB8YEQ0svnjP2+5QrAMAdGaHloFs120doJsqlRU04Oh7tavLiEkmalp9X5j4ugXB
sxcH+Qb+fk81hZ06pfnWQeShjwQKHjJ1L9JMo6YKCeWMZ5uI2X84d+YsB7vjmD7OF+PiKiYSgDAS
NwD4lOr/s6p1uKyNq5uz4ngqVWeLp2UPL5ai99d5bL4iDC2q6gxRub4R9DlD0I+qnk/yS+zoQqcj
84F7OSCdjU6lRKqJBxM9SSCqbo6Hwa/GBoexrJhZ3WVpmVL2O9s0u8PcJ1dZjmc89aYaWQ4h5aEC
u0s0IbGJwfk5NXjNxuYLeBpmVvYEnRxeCYGZAqUfyFEz9ngOkRFLwIKzinnlZUCfP2CLf5hTAmft
y9QoUEmFxPKEbHj9bngGrO1tk21GsqcJPR6T+uGdS8w4YfFVenfF3fCGyd8RsQjt8zRZ9CX1Vrmw
7iM2536cZfjtie+EUKaxsy4EhlW+B9PWDysN/zlo3ZXXL6eV1BoNouJAVcbOEyPuntXJShOZaGe0
mvncCcipT34TQPeiM3CtHdIeNp1lw+SXGBwcl5DfEge1/bdvFQRdPURK/8/dbLSYJw3ECnDNeeWv
x4+tMePk9vmbtSX+3eddVSiw5Wkhb8NgqhAWqiTbVgf3YfDS+uqT4iYXOV/doWGY6Gj9dbl75sLM
hpvL1ieNmQN/59A0GhnZXMRlnz6QSuw7Fb1Kxi8qBEP3pyktz4PTzaPSFHuQipLzgINFFSke3oGb
sf4rh4QuoY44e7tHCQ9l84tiuk2X/yHet4a7TbF41CVWOQ9BDCdQRNbczdalWYFsRHP3/FRUoBgs
vuqYoBsvv6NnjpgSedsXQ8uByCyXPw2dsHrP0GSBme2kOj/RskJH4q5OFiLRLlmxf4NLd/K8iKog
UDis2vQ3ULXEDUpge4pQ6RV5po8T/Ah+QwKoiYWK1g5yHrrplCYcJnrTJlIchcMSbxI6gozmI5jL
o3shHdGUCe7SmmLPn6t/3pFQ5bxzrG0CZkRvzSCbvKci9i4YJmY8ldhIYKS=