<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuQGRmcEGLGlLqpwAYxyihWR5bzBxHly+xwuYcvoKLD4+p4dbIC8NdIzY4NEe+6GVgjT7JO4
xT8l3jZJZ1VG8yJbXvl7UzTKbqscAqOmj3ivDkeGVkHXA01+Yi3Ky+32MfkWx3SM8OmDScTXMzTz
4DUvcuFIBZGU1Ys3tVYwLeYa1dw4BadlZTrAalONgtPJxBKijwyDraoRbalv2b542aeanpVK5vOR
+MM2tzqT9fUF8T1nVtOruRcNb/FFSX9p/X4Plg30UZr/oXUPysMTD8bFfE9bqcr0vUlcycCOh8KY
33atYvlbp0zlwagDL5AzxlrPJUUbmXdPjv3n/a2C70AJ5kHX5+IWoR9gf6yZNrlFvNZtpkYP2IkK
EF0vzCv0ec+oIuukPMfDOFpWvDWDXH5dSbAyRqzJWxAisT3GbplIXBORH9i6co5BJlVWKne0StQE
rxqlkFhVVdJBPT0ZZlAuqmLOBSObZee5IyGIO6ANd6Cmj7W5AmbA3P8TBwfYvbp87Imb+57apnAb
w+kgooaVNzT4lgHIu8gv85dG1rWbDCJOWyHt0GgNgtz0gC6nRiUSp8Pl9bvIT1LQ/A7Q85p0P+Pi
vP+qeF2w7Robg8QHl/nickTlK3DXSpPPI4Vt+DUf9HL8a7FZboiFZ6DkrozoucUVhGcUyYU489rS
w36m9m8LKvuBxHyoOlD5Zx9FcFjOqf7RIgVhi6Q6n6TclFNonQemomzgSpjiQ7hNOnea2Y9Wd5nu
6UYx/yK3tQchqCNUgbKAWIY6ww0P6G4gZL3shRE0F+WdsnXJiy23XMEGJskox15UxbbkX//JlDRf
rlp8xbOTJT3jNvVLqWIV/l/vCMCxa1c0hr93jhgYhiBWaHnVojkvajAFqqTgdWOd7Dht0J/pRQA5
iavbpbHBENGuoNQJRPz1vL1zFQQDSryZqtZnkzrvtIYH1wNFQQzxM1BrfnKHFKQ4SizWKMIpEVAV
b/QA7txe3F0Sih4lqsT76HWmp3+lcBIEG7HZqOcrL6sI9Af3/dUvZBsPK5lbrOJ4/4reFbp/kTNn
PfwDjojFplLT78et748fNE70SLycCfIoSU0HfKjpfhi8whlXHi7xreOZYDbIoEN4MHq1dD7exD7+
zMNfkWZTPyrKqoIrlwdddJtUotl+YgThUQ6jlXlzQVUSBtdRmOYGGtv2XesZ1ZMXiFVN1fOl18pp
fuIOsFtiI3Np0r2PgrfsSnQaRS8/Bw06Lpx5L+beOgaHnIoLw7CbEtnYwIf85ssUstRW1VQyUWfp
8cbBJqfyI1OwptdT+0ErEFx8TuZbQNbSH+4mivDMw0x2N9ysMnX5R+X8/rlhTfkwK/yS+FUSNSWh
HPRwylakAV1a5j6O+HwNl2vgA+gUuLf5GtR5beNQTWPr5E4MKOyn0e521gIZSe2vP8KWTfRoq+gY
Kg8XM0iHXwsIwkEjbFpsowy9gdT5COX2BM9FwFWHcY5LtS36NkiKS3uHvOn2s4KSZggE7fTwyHMI
I+tZSDJY875sCoTdiukHSXiv20Lkx9SiAjdfMBGQsvVLmdmq7rxG3myt6tpye5YPCuBmpCE4YeZV
gQTb4ldf1pfVYzm3+3NS9HHBxF9DQO+ZEwfPFmMISvFqPrkxMB6ZZsLbpJG9L4YWolpOLkdvuM9P
zKB5tSjsUv8GdzCIb+rV0RCF3IGk/swKw+q2lhLlg5DvannGfioTSmnjznzi58dl3NvZCJ6cewn2
KHbqyIDG1pPqePsmx9cEK2FFETNdfrwtsYvTixeJPUPrYE0G4WbEPxBuuwukO14CVWM1rT2+RJcJ
ot+r4Ka80Fdk2ruFFdIv5IO5zuMnXP3vX8vOym2p2oY6IRLE6eShNj8iBUM1qivbLa1raT0/yFrQ
dAyqa8+SaznrLH5RGpHJTv7o/1F2TV4WvYTR7/7/IhtWgGpKS0+EPC5GYVVdME+jhbeoLM/i10RS
5Z/l6LUEl+1VNwWfqxV0hNPJdwN7xSsyNnORnobdCIkRlUtA5QHliRa7woyWu+lNWsPPqxYAYnZU
d6dJxQd+BzMj7I4YMKHohsfQp18LZDH1mdRpcehfp2Mo9SnF8dYxvUziCB5VqVabZJdQJ+RTtSlM
pzAzZMx/JcYI/W3+q2+cYT125dRGUZhlqTE6/HqW7rbqKe/UOU1X3gh94bEsz1TIqaHt18Q6D74f
ntdUS+2yBTnwWW==