<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPut+cQdGKMAEhJqCYXximQn0PPq5zZHu7Saktp1fvFv09e1QzjH0mLipYMAqQKk7SDGB1xzA
cazfObE9VZHa7CTZ6y1TNiSfkEDFuub89ztNfN8COBX81ZEBgAqVS3URejjPRagzp42ODzJ5Smx0
OsfbbHSYchhNoYYlK4+zdgyEOg8EyCuAEOG7lqf8+iQiv8gSEzzf344m4xivMy4G9eh2DgrQLgHr
83huMtyFG94UP3gSOMeMRhYf7vCflXU/ZjdqvYRqOIVeMQvUGGS9hHbYkf3xeMED6Ty3nG7v+BlY
iW6AcGV/2S/gLZeaCTNUqydMuO6dzoHL5Vqb0nzrAiBL8IQFqySqOh9Sg97Nkozz1/2ctTLt31C/
8//CqpioDBFsN2+D2B6xWZx4FIOlepEWDiNk3ZfJQh1MPbsNFvUH3VxV/WpvujJFPxYo5DPb1ZcW
0IxBwherfcYoypaud8EAgKfXRnKSiiurkAVapZ9qc/nTv9BRlQViqyzAkrdHFmUCpSxeUR4WXwOt
aXN2Y0u/ctcrbCZhF/MmOJWlqvXZPn6SBfwbJjYw9uYiefXjhA1mq9+aqrobJFUdzg4RzXHCaI+u
ct57qghqKGq+KNh4WCstk2dkEUrdQOpur3hbxYyGexOh8F+AUJ40Nc0/lEVv1twhKXgjYhQq3BM/
JWN+Q7dwkJSOr1R0LFJvadwpigU/Jgg9HtJEjBvD+u2VDe8wZcyiprkHoD5LdxDQ6ym+rR1Iy7ds
eAKtP1yjaCVOGwspbmKsMf8oJnqYm6yWG5UZdEPo6VBVt5A99ksNE/wQzIgQswir0/LTti8NMx84
i4/j0U+pL10omnqg6vPhru4axOwdjYuKWcYHc8IqbIUqIxWXPStZhRQLuorJYG/G/2FpHbnaqD5v
32GRZhJ1FIvdcud6z8uspTPvMaUR8YOaqVn6AVv1Xc6465Ec6DzAhBOIBm0kXw1BH4uv7vQbzPdc
USr2gRb9/xNafXCH8cQGkGhQEG8eC7MB1etxJ5ifim+o7lxPglm7BpXdtGSseI7Dq3PA/oh1AZvE
bkDyJ97EqcmRlGZYhAtdhl7/eyx5kzGDmqNvEmDKCQIrQmvRZvb11Q77z/sIvdEvpMdJesa6rco4
7vJ+DvsPUlSDoZEd3bKgEWGij4MrtFSL7tJjKLcfnT35OCI8mVkShAAkYnynBEzNLtNCctUkZThG
i5Xq52PlPAXSaF3OIbdPBy0fZbliNKockXRi1ckerxEZYnjxYH80iPFnSvM0SayzdY5s0B/5LWyj
KQ8YK7W0zLh3IEs9/LfzP0wCZmYWrpsf+RC1V6JBklJp+oTssWk3qB7NaYlvmYgUseJrigMQonNK
3DtqCcjxWqC49e0d6x4gQ+yDPYcWy6jKPfpeLcMf2hYXEnMeRG2tzkamlHLhpdEDs1IeGLL6EB+k
By//4xvjKZfu7pzQ9wxnMu7rV7WgGaEMLfOanjoBsU1h8yymXmfijOTTP29oslh2oMesfUvt2jEQ
ODkWNH37ApV8de/Pjo43c5yS11vrXDKsPQF54US+CUNZApWrGuKvfn4kLdt4T3xVZR07vWfbplc1
NHWJvgK6nLHVVNfcMhtIDcl72M3bbd26xpOW9DpqArppDpImWrENayghIkeqmfFcA6PJbuO2ROKj
4n5Q+SPhJiKq/Ay8Ul/mnrlTvcZwvC3u/xDhPwsJEiQvKsOH3XzPA8Y/7uXdvmCCm+EF7wU7fUpL
UfICBMxk3d9HwKs39zKd9Ngdaa+uGr+oWzBjTTkyRJd630V5MfpLc3wTfMpLnKEPgpbQFhN1oDXH
oCSVP8Z2s8utj6u0gtjUXaAx8+HWu5m1onFyXSQysukXTCcmJkLCrtJW0lO5+E0wzChmOfSCTvn1
JFBT8vzgbDvCUmDCt+AVWtZxgV9zPEz7Shc05x0nllLHuzdeYFMhjtQLaIL/tqoB0iETFNvhab0G
G1TY5MAStUZi1m1BBbSDGN4TXO7/Pf9wYcBYEPoN+sZGutBZ3oXpuR9sG7W6ZqqI3bDidII0N9lh
L6R1NBzL7M4nzx6Gc+lQd099zff0oSfQ1NYzUqQk2g5us1dfolKMuKEHi54Pk0mt2jsMJ1GmVW6o
LQHnknbJ5DzddfbU7E0b6w4Xt4ZCqqYOYzmrpIiaO0rzHTRMxIxlB20o67QSeTN5mCS=