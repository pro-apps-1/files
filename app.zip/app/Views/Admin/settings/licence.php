<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnKknvKLh3lQuF9IjYeFFib18/cwVKqzLx+uqwkwUMk8Rta6kujzBIUdDaISgD007CeZRr70
u4fDE7mkOBSwID8Hru3ijt6i36GKeKdsIQSZHdug4iCVSVOovtzUBHqVhMCPrxIhjywKrU8Vin1V
sV+KBfcFaHBGcKUmjn5zMFoRnx66Jlpgopdb9SkEsdNV9UQmCP4qryP/nFkDVp8m0K5t3rM/cJuk
6hDC69nb3WUKk5+5YCbxxHCSiab3cKLXkhd+f73U7N0fAkuXIPj47u5uMj5aihH1u/FZyP1q2V4k
JySg+sADY79PwBPB1V1i0LMNWxU+1Ebd4ywsNaEBw+zm7bPsWvjr/dxH89IPT2W/b3BJq9C6Dd8D
9o6hVmHQ0kgiLU3x5lN8W/Zz33KRHCzrtWwuzp5qgyAAaIXuVPUWqPSMUxZw9B1nB3X6vN9PvLT3
uIyLdFSqdEPVhINSyLC4RyFjaHecad4ZKUJGaGv1FZEM2WEhi5jz1vZ76xyuiSNpIwkFGWkUN237
+rIhGrtQhtUeI9xh8qyUuYsDx1+TXqSLCtrdCIzcwGEMMeTX1SsnP8uTizDoU1lrqC6mImJq6mro
hrchlXZhwi5OBkj0EzlBVr4K5uiIXOKdDAUxYbT50/XU57wCqHwuytyTbwNLQK26+cNUI76yJml5
RhGrEypumeC7vVrfezwPE5Dn82LxkhWLb1gSxz3ih4/zsy9Iak47Xer/xbWCXHSs1+mC5e26999V
hfB3dy5ffYKjhOrbkGNACu9TkrKqorHyJWNi492TR+YHUmifcLpu3QeY7UiDv/Tx838Zxb1yug9k
rR32bAMU+5S4tZLmXvVRGbT9yQwS0l3nFidzXwFG7tMVvwK8nCsdBqmR9HaFximCa1RtmRace184
n6/2PfxZFjI2PxtP38khjwCKvIUXaIK/jQ6aARoNLij2Yn+NilEgV2QRRtmbzI620JiLZOri7dHz
xZeK4PJKGviaxKLluGW8VlzLI3Swlsa5Ttoqcp9DP79eKWtqL02g46k77qM3Bw36JaU9SytxO6Ok
HiA5eTH5eNpH30mhXSICrSOUBcf+BDNFybXWdp+aen/Vsgm7Rw7COHQG3V5jH0kNTrxPwjYWMxUz
gedjtUXIW4pKzikPimnB7rxOO8ll7dcifoSmNZGSSP+QxvFHerl+nye1Cgmdc0Q4PXThbUWeKChJ
wUw3Qdqh1YIYj7Yp46xGAu1qxvlcFhpX6lf27BTTJf+KFuSZvzkiInpzXypYRQ6JcX/3HISF8dSt
crQeIM5hAbPHf2vtR6c1IXArkv2Pf5vAyr69lUvWbNWNx92J7fcwa3kDUm1a/ta3He/OdESoMQvv
cRzY/YQs/3UF64Cdz2+MfXJkAz/b7N7kz7otEOy28Y4pE5SRjvaHo3O/ajyiIKta+jwCwdaiNZAb
0OXDMwMV1RmaYOTvNOEnImsYGQh6EXvlIaN/ZKu49WVPwYxyYqLzGAtINOXGUyA+yAu3mCjCjb0R
dJUHbbW5lyAW/S4vWhmxEJ0awLw1cVrcKV+aft6QtXCq4/3lLztrGuMBVBmZCyQOEIeNQlUc+UTl
AH2z57QHkcbKQeuxYfS/0eUuTJVHj7aWo+Zur7H7cP6/+L9nzzD4VcIO6WQwctEyxnRD0//IV+zW
8/6DoEZJzHUgf3GE/gn5LWEhDtmoGJFvBP+P/BLQ/6bXgU4jV1i3xQ84AyrtBzgIXSWV8zg4B4dT
BLuXaSZG2ETWro6U8V1PJKUUTGzC00zER8CDNGDaVPhi7h1hxTRm2n1tYqIWMU5FjCfy4VBh9HJW
Lk4b0HrH4HB4b07HRD88XYC11AIqDAemEFqlfkKjPXB4QWDDS5WO/G/a8j6XWtbo8fqKqBh1CLEd
9R8uGfB5Hdwf0wAW5xMt9ivoWuTq4KihIgjjIG557drPQnu2/bcSb7y2GQ9I+gKC5LyOkx54MwkU
sYl8EmPfXEW5ZFUbqSvEFSPvkueEzh6Q9WbB83vdCSlWB+ifWmhWJc45m2nrKDLYXIhP1NzhO3j8
qdiER2oTKz4Ex+gqxlb2hww7rTOhIzXUZ/EKLuCr6nnWbzOAZ+3brsgdzv6GitQrnL8qgSXcWAHD
MhkrUQOkfN9O3Necs3E9T4W8cIMV+BJ39QT0vHzvsYpttVhLHGoEbut6zJ7BL2XO36bJ/pgKKCfd
YnOTwSErpCJ9XJq25EVGjIVkSmwI+OZpBFRI1VJ4b0gsk5l30Ki=