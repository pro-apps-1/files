<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwSEfZY4pne/KT8p6yuPESyDN0q7WLluV8Qu9XI5dEqNlp4A8Pp8IK7ztLiW4DbqMSYlUR9T
J61SVhjLDRXhzVNp1XvcGmWdCnMLBsY/hK5PR67dOgk8WNWYuzcyxp00BEFNLsC3RnP34r42+jNZ
df1kW9E+QVBSR8t9ukq89trFgsrQWs8sL1GnMxG6hZPC7nN+fiqph2KxSe9P635diiBonVSZDVeO
fbfkoLQMNKzlTAVx/dbtCek0H443PZgbAAqoDDLlWsO5PxOd80HtjBOotmTVBUJZ88Ylr/caLzKr
Sw0uyHg1KcMbK/ke5+U6nTjxdR07o95+J0PHa87tDH8VHoWEzwpxBTNdyCtAv4cQKsPvr6qJ0Ztq
tudtue1UgxZT4MUW+tTLmSgiKjNGJ82sGrPUQuxH7It9YCsWVSL7LlkmoFV/KmlnXp9RziC7YtrS
81UiK7b+S8Jnp1FsHMZVw/KBxFKM8RKX9PyZYDTgXw1UcCA5nR5ho/q5lu/rvWn5FzqxA6OsTNCZ
TbENLWAfWOKCWiRXKUVM2JVb+3hffTdSh+OreQgK/wSFSvR4HlELBG7pbQYNTUGkHP1WW/oLDhA3
4WrARFSqX6yF55LXn6im5pwO5GiDBBpKD2Lm9iEgL6QCcLrzvYWf7mirosQ3Im6/RJJ0Ym24Yw8D
DCzCxA5MMhApFcXClA3ScZ3WCjG5APxdBdwReqHNpT6vUlCgNCBFfS8P1oKDgIZEi93d0b4aZhLP
ENb6rlIttKDEN/6neYej7JXacCk34/pmOj5AqD4+7HtfMKsB973z3zbsJyqaykgTsZY1q0Q9nmLy
403GQFHpmniJIOCN1WAwBzrsBIvVoIwJPUNOpKog0WqSxRwZjuc4UZuab8dHqnmLNchpHOOUsvBB
uhjRCozteEI8tikw0a7pENN+EkT1qRD8tynM9DxF7ALehftq6FuK7Y7tZMTbrbkwT9yvq0efXirz
vWrHQFqAj+7YJ/yqcAIXS39URtGNDDjbjkC/y6+VSA5QbgjzPtQFcuOrzspEM71cZKwcTg5Sh6bd
srm+frsclobj3mVz5zXndp40YRKOwYbLjwuf2In0+WH/W/+J5B1iMBCBFhltJT8e48f25VR0Q4j9
WipMRBXPDBbU3e+I1CJRam1Yme6nMIx8FoFlqe7pVJSLDAhjMjk2MCypzcvyR34tLfmF0V78OSq1
cLxJRT6Y45NyIuyoIVaNQgUsVfPeBhVRhWAlsr7ibtXhuc0x7vMF93UQmTub4UmYWyNVBTeNnyTn
ZwZrYvDRNSiol97I/P/AiIpEJduEr4mXAT5STE7Qx89gMAWDJO5l/y/MuNTMCmJPyi20r3ijNFDg
wxADDPIiLoiXaFgH7+07n2dnneG+U3fCIp0ETNrH+LJ/5UhUcFwgg7GKTVhI4zL+4uYbvaLfQvye
HGCGw293lcW9GlfDZkeXOWF6ZD49htqo+DOe0EI4T4to9B8DTXu+WH9JmK6clqkyjtR+yuiubuyp
B/vqQLDL9wjt4fw6/zV5TlNnR5weTHOn4c5eucrOYfwTVc10L+FF8jvkfrNz6XGAM7OwM52orC+p
cwtZv96jfVyRVngCl7RBm+ffFnKhptobgZ+FgLlivx4Fmbvz++SDHUyjOwuwt7mCdOvxvvZJPSjA
bFuUHQoXQQSOBJfI7A0dGgglpTsNXJ5ODq4Kx0dsPa+dGy2MXpLo7D7VHVPDYFdpyLw6sKP9t0V+
Bsb9aZZrZicng4pvwcwsiOb/JT6S1ydjv49ncfuBbE+92e0iiPguFtWtiBXYFZeG2kZvu9vCz3KQ
JR9YU0pZhyfLTzCIC/a6gouzt2Cnikwu+3EYbHsUtivy6djfbpXqLILgfETi2Fjr2veRtfNFfY76
jQ6nmZiXiDbEsHSNAskwbtlauFEmIaO1yhiLJSRxLLlXEajqFyREsmeFvLvk34YVIqepq8jL/rkX
BMRJFoyinN2Pg8p158yzWKWmLobM5iXiVPwa5tXRVbkZq2p5O3fi0p7nCOWu2feGJJsBag3HOpki
SFFmVBNx5OM/DUUc1lSUaw+tsXjl7iANNyMkgdH391CTg+slPH4UG8YQhPzdKN1Ue8Oq0MDI2N3c
hNkz7KmjElOu1Jt3C+yHiJVDT8SAXIONjCvBCD1QsyaD7klOYoPWLoDcy2+h44xJAQqMay+NJ0VD
UCvSMmhzYMJ2/PsU7GkltXqQiD0lmZhffXWVmBhkkDdGWaS=