<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyyh7TvKg+KH8VU8/MJ3MDWiZNYcaA5sA9EuBIFnxa60I1mEyH7CC+XTlEcaHSeOTNsWWnwi
n/+GJLSLaaCiwkwiSG+Had90FitSChhecdp1s5gaX8vJiezFmbHgnRZ80DAfVecMV3zWcgXLliam
o8btKfZ3WRtnsfU/lvoZ32n8JY4f3XV8zNr2Tkume+K8iHvep+E+iTV8wnPukLg7n1AJ93+T9SzS
ZLUOC84eP4qAo8LZYx7lT/YzMsfysuWfdDHe7xeLASVpR/ki6MzQ9EJRHO9ieUpoqNQRNol3IUmZ
usOo7r+T/jT3gLK0JUGLWzap6LNwRQlg+3NA1uxZvwDQVf6IANWp1n6isSWV7e+aDRjgHA4ZJbTZ
UqhK/xLEteafKa4CE8BkceNXu3bB/LdVHxfPnAJE/zIuc4WugmW5XUavKSzSWzYPIIAVVHDUqQB/
TwgRJw/ozkfi6SZ6IkuM/sGdLiwHFwMJnSTJ87wzXRoPoQ77CHG30zn2rstgH10AvR4Br3D28HRo
EJkqEsNjTEh/BYdJXTqQea8oDGDFOin5UUj2lduVDe+2azYMVExr7YLxBan+LjobaFb/tf4BOybY
QItiEd6sSk42UEixusYQ0ksIXbjp7zC3AzuaspV+N2wTJMLdSHZ/LoryNiGf9rrT4y1xCcsqmA0P
PwywByM8vr0OnfQCItFQ5gMjnlV+A81xUu35jPN3wuTiqvYslyEqXUb8yH2/+xiwmpN/k/L9NrrM
QVQdSYnV84oy4TOGtVMXhbgnVS3AH2SBrnJgl9nUdW/QqO5qOaD9Ju4avcvsuGNJaWGAQw8LTy6/
FSgXAat3bPoY2CG9fKCCft3vboQ5wYy6Vij0kvn1xHxN1kipCedWYGi7oHWgOevowFjviqT8TGTu
pBgKKEVRhp8C/7npPfYIbikpAmP1WcEC4F/iIjHMSE6Jsxf/dGTMJHddBsDvdNCrHMrQpejqxDgO
9yT4uUYdO8CKN4v86tQ0LlmLKFJbQ5zRuD2fJx5EmBp4AG73V4W8814K5BkipZTyfYTZCpRvytf6
zFqD69UeUSYXs5xOL/sT00aNeXrR9MTuoeeX45jXuzQSbGuPl/BL18TwOnj6dE8uY2CzZKxA5amk
fkxqR8xSGNNMVll/TjiCH4bEt6MZAINOjMJcL3P1GCtKV/GX3FCvFGJJjFh/3jX0VR2mcXlE6g3C
8rq/HcnTp1CcfBcl8ISamCcyExUDtY8EkvZfTdR5r6JnYujBJb+Kg5DqLu+1MlG+IKEvfEN6QTAQ
p6ptmhfiog9/tuA1W0GJH0QoZbelSj32652QinJKP287meIG5Wn4IlCXRl76wwMcqpTkUV3OhSyg
Q/M6Bm7E+3HxmvNa/ADxhR/wz8VyGApqoK/wM72KfMubYl62VPaJNGsgH6ZufwBCNtPuvELnHrvL
Cj3diat3ImToCknz5nm8qDi6M4HzLYMC/H8hNvchASoFBqOIc5AWL4dPigWOxgbqH3Zmhr61ZHiV
MSkEjtU5sWbMzgbJ4l0MsMYL95IuSup+vYrVMErYHjwC+POEOgJbzwqOQAa4c1XG3gsBq+sEzY8h
fL37sMW+FyAkBYiq3rmS6Ae3i78b812mXP+jAWJaE5VaZwOxQfNRhjVhRdvSOlWpUFC7D4Y+TSvP
kmr9j1kswQ66bcF7NghNxZrLsU6BjYrHgIN/N4nddNFFTsXBcus52iWaq7yY52x+XSPP+iTdsVUC
humft2SCc0pf8xs63jgOx9Zq3E14JbKsc+74544vfcxPLpK0Z55162uaSSuv35peSD5YGFcxaG1K
vX+gDeABwSle++BCq4/fbbi533PhCNon3wy5ZLxoeZJNSursT3DXrWLC1jGuxdwq8yfwMvcW5Wm9
rbV7+d9HXy3PooXl8Sl75CyANToPCVuOk3PUCA+JRsg+xxYIq0YuuUeX1jy3M58AXP5IDcW5bgpn
V8zZbJuGrpaHH1JsoB0nhvxfpKFzodD8EX9KVHUgFXOTobhmJzKOe6ItzsRUB7eF1Js5bYlnM9do
rC9GwLUsceFCeoQBfQ6wrB74FrCJj61hio+O+zbpQe693gDwbC7z8xMn9XoOPPy5rG4IdizPGrPV
M5tb/NIe/kn+7Ou7HkGLxseKsTZZfVX8rc5dP5vn+baIPwhZ8E7/IqSn2PA5zUwKF/ywg1q+ei/F
x00m/L0loFeegDsvOPzkt2YTnuH4C0m2Ch/uMbwNja+Lg3RsFZIfCTdKGm==