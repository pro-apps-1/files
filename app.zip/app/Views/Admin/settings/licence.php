<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnaeoipfhixZzFHVxxWR+WZp4vF+Erbp1iWBAaS4e4f6D4ef+LRnE3+SxhkiGoOmskFJ8iEY
WMVUzKmX7r8kf75ynjZxRZMSOU9rz5q4R+fKNiTO3cqa6l3tW3XYuuGtZNFkODLm0C1qe4AqgYPY
4Y65ZRktSjAUUaQqGWlv0Jrvj3teekTPQTNm4be3Yfn8ki87eaFy4oJKWpE34kEkRBZ+2hGBW+DT
tDnHxzp54cVxsaRG/bvoBdo4SIn4vutpAMFQmKP27hqvsIjQZIOQxUy4DtPzfchhntTIHizob8At
3w1HkNpoyxPmIOMSqdFIwOpt1uVrA7IvPP44vuafMln4aZ7GsG8cnJsxEzohg/YxI0eFUCoB/Lpx
9Oq5w9kEZamLZ04vP1DMz2WdQfYjqIo/1cv0OaVuevij60/x7igmQmZ7oYQBVzt+EV8q+DI9hw2x
TjzHmD3JGgDwX7gu8vWbQlhrwBw4ae5B8QuAwUS9GbQ9EF3UZp+kaZuzCv9PxFd85PapnDgsAVob
b1egpoBLHpNVTkIxHp0gKfu+s8ehAynt5IbWX3XR+jr8xpYaQrL1GLyFdIhuteLjQoTzNlkyWApT
gh5u60c0N62jggQmgEWqV+fBg7wSctKCTeNE4wNoh2hRinXU8qiAiBS/ug4xIJPEfHl41aDpLKoN
4XHE/hiWhf51FQNQ5buAsQR0KTAlLZutf+b3NuaCEWGvTs2rqAXS63swBIkGDL1RrE4lcDnJdXc3
Ob+64k63eymuQK3WRzKJybhC2aTT4Vj3QGUUX9o807qDQaUo/y5/Xhk9oHuK2bqVViNWZyLNWN7g
GWouXn9IXrYoGaLl3ryK3DUCZFOwsMB0qxZxm1L9mYcDJjLmSaYJOlckEvEGdEIZmGoFN69b3EYf
yE0rdeV0vCwb4dH845okGNkD/gUOBDgVzn0isLkC1i5Xf6mVVSYetxTLxvk2ClMnREYXkyzwjZsh
Kofxd7Dh9zSLBx48p8L7/x1ZAj8vKPKadqgzdICf95RfbXeT5J5ULkndNkddbC/ZdAHwO/RVqkyb
jer4CdIInUyTU84DBX/stFxR0vfcdQUbg9rS8PolKqUOdqMRM0dkyWYW7pCajL9o906RLgcnHa+T
aCIBbwE7cYBGPRgZoJHfsgFYGWi8uubgnVj/MDyV4jkiPJTbU6hub3sWMi6sX6lLGOGD6i1mqkox
+fW2qmmu8ABAouIJD4tDfSVNMG8Xt7/CTZSxp0mNIvWxVe8dm08JGn0t910GkmUzPPZQYKrqM8nG
5603sbduMIRkt5NEDz+H0NE/bYOOEAV0grcQ49pl3rWcSwoaZawzc+brTrkSuEHKkJHXxJOPNLAd
t2lIMQQPKAzdYLI9rcHJtL4sxl3AKkoL7njOcujacHCMkolTw9HJxyrHT2ZlhocdCNF9rSBeKTmv
t7uBvhFAkYMsqxi5OzhckinRibXT0TaMdWnjKZ4PuRMRGSMNWTWeVqYq+1cfmLS5wy2pSZXRDYfm
GvyIVDZjJ4R4MtgCa77gE+D6j3km1LDLfPBIQR+ectKIOWh52OgbC0gHIWkNwhdqkuQ7GnJ8bSGW
4TDIMAINCmD1Mzn3J98ApcCPg/N01CMm6pfkfZT4imSJAF2mdwqNwf6hQEwsSqDOigndkk8GlUr1
S/6Rg5Ln4UNXQKyBhersZh1ZaiXiT3fWXcBNT8TKJ46BwCO1XxtFWPqrf2vbrxOSBc60AS5htwYT
SKMIvDa/lR+iuu0cOQUaeh+69to2TvZTwXo1hAhrvDfRNfTZzXfK0V129vSmxNgRVeCHAAqxjFWD
uQHhNT4JkDxyDbx+YCyHlfB95M+koJEeZEi/VHkdncjrmsS/2f8tkqUwkQxVmgs6r8R6IYi21BAs
jPnCGpc9OFVTnLlxRvi0JLGJbxvDjlFJARUSKidl4HzqJ2mI0nM5tqF0bRIEyYZUswSGZp0mn7wZ
+XgafhoKy5NWJNpvjAUwGjud333UfD77FlrnscpDdxcT6u3FIa4LdySq2yHWIVSYSLI0WGGV29m+
cFGUFmrt1/X3kv6zTUVQbo8Oqig3vSr2mrPRLKrC06hW+lqa/49pR6BIPj3lLXT1o6A6zSxF/nWC
pfhYAF94hbcbzn5kESiEKaU3irYhay/F+ge1kihGSIYyujfnHGFeki4cTcwq5UmBzTxjA/jvJQzf
pcOWbxj7HNQukgj2IYiFIt7mlsGATRj5Q4FYP4mDCrW6QqNG8bSinbQrfzdONW==