<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyFUJivBdBFX4WBRxM2YWJE15OzQ7LS7T82udFbNm+eiFLHI+P3Oc36eXkZdqnjhiY5q9vQF
wg9gu17nSX2MFbcSUtaiga3UJwSIQl21NceeggDPM1cFA71wRSCJp4VxEzDzNLJxe0Hlal47ikNc
p7pJU3/q9E8+hbEWYg2MH7Lbc3G7xfA/cfXYXNnoFN5YTCsB1jFjjJKaA930gMMcMHeF0PKY/8vf
fxYpO7ZbHS4h3D3qNQ6HSvNRNvUOBW1BRIWMhubOxymazG/Nz8XCYKvD86beS9q/HI9TxhWEH/wu
T9az/u2EBRDwntHamhEWyjaat23laDUDAQ50+0SIAEwLbPzNS+XlDcJ55Cl/pVPv8/wSsY2vKkDr
KopuGu0UnIIyVePGW8iOwSVbwTJ/kBIvhrn492Irkv7wBY2J112wtD846uDGWYb8X+nmHSgyafY+
jkAJwqPQLvqJeCLLM4BJ1Sc/V3qh+JViK6gJ+fHO0L02NkV8Eet/9q8944sIzj0uxSEuW860FPTo
kEJHtWAx1lIY+jmMBnVBWJSilq9itpMoTFOnlsktZeOBV4WlDLVkE/xE4dnGsyTBocK2eym0/Sg9
oMnPER+AxQYXeqL2xONTotJPs8hXLpGL7ZVq0kGrttcuNFSCmgDI3Zb6tSOQqYjNGMMuhS0u2IO8
Rrh1eyFJTz3zJhl8e92s+QFE7y3vPL1Rp+o5pAaLbd13k3RDn6WOfIazR0dvtYqPwi/m20VwyweK
PalQjwH1FNqcBxgIOVOqifdOCjIynCLHE2wFdW+3ATHj1bt13fBRV7KE1EcDW+bOGm8/Kq6oJMon
DHJoxEA81PZXIpQi/r/vcVyrMm9+uHkPwlBFz5hXvvaUdf157dWhETXjpvPqWvaMOKPyEBBIsEra
iqxA+G90veaA6lhEP8ElHGRbAQOGiabE8obGSIBqhQMXUD06GY+ENeCeqz0wY/U7TzM3FG8YDwSt
iVRYHisdDF+fKXg1uzDm5bMH5qht8SiuFWa6qnPXx3wAZ5UbHxSuq6ddPlAXch66D+Nc/csxvPjK
wDcqDwgtbp7DkpG1HkGW+xIDG8ztWb9o5iEbA1w4e1wvu/YHro93t4CW0elvko1JPBgu6dXpgEd2
MuaaHo/iUyTJrbRkBfJim1CPpeHrZKJFFVDsW6125Ky6HcbXZmijvbrwVWdIyeQ4FIScs1ACBYs1
niCxlnjgasCwY7ah2l9sCNMlv+AhJpC+9BjowGBCYqAGinUnGWRzR28OmTvlPmdYHX0iyQkgHqYm
tNKcFfM7IjaomDWa5a1AKQFCoV28k5GV79OI7s+E34wBKviZfycFHVUBeyXpnz2d3nkYKI3m2T3i
+ACJ7gaDLfYF5h+fiPuMcGBguzSHw/lLSYaWe9M2jwdnXGIJ76oXRycN8zESnT0LZSZXluwTB1df
i8eLa1QWsNtIfCrHvn499g7MIamXC4ZXkpLfgZOdx5NVkkWbMClx4d7l+gwfrNfOgflwpy0A4jg5
YPkPM5OMg/xtdQyROXsDaB4lQqcQ+hFSu9Mc9O5FuxDGW/KkLtoR8gBsN9w6m1/SFggQmqzePCMf
+lob+harEHR73OcECPg5OfF8pRQu5eTf+8S57jcIP+VmiOSGEmJhAGsXSuLM8uTwQRVwKaSVzzS8
jWVQEAJr7i71lnT0+S2ZJH15OurIrbLPlVD4SrK0jF6ckC6VzSv7lFG/aGt7+tcbm8gP3MxhkCHA
6fTELgQ/QDVtGaBNqpdRdL5AlfTWU1RiXO9xChNSxbJMEl30iZvzoRlGBfoEc2upfZl9aDDKg4Wa
0byNvmRi/bETInj/FX86Lphs7Sz57jw3U9hmQFY1Pcds6FTEhoMsS6rRqm97jTrIJC+/REnzszW+
Ch2bbGrx4r8BHoh3IUxZec/uBO7dwn2m9T+r19Tn9/rJMsMY7sM9qQNMKMbgUr2fiiT3kVtooaFF
Y6Gd5xzZ/BQrJAYokyjel9Nb8pbNoeACAVQ+8t3nROHamLiUgi7x6LIP1iUJpND+XVj5pZ3aM6jd
t6izBkO0WeP/obAp//hZ548/w4WZssPinc9rNcFpA94M9hPtziKN4cU177hsADNhw22pkm6ndI5M
Pts2sOSGC4mULrJbOH/CFxyTi7ngi7jnf0qN9KnIRQL9kAiVxGAYIV9FLKCRZ994wRIZ9qpxVKBs
hba8am2xnzLSlG==