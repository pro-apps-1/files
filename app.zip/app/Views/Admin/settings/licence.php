<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/IkQXh38czUcd3/TJcUV96gvvgPxwVUNBku842RbnKIXWMqQUy9CxFfjjQsmDg9TXlXXxKQ
Zxfg2VPbH+O1TGDZP+vJEHuHz8wo/oH5YW0h6zAjjEsZWm6z60ny6C/oyecJnGQVH+qMjk2PnSKm
l6b3bPPvUG2s4dpizOlA5DQw6G2NWR9tk8G9OyKnjJTvxX2HyNV/Jd1QszJQRR4QkxCetF1blBot
AvMxnERDTQMrklVhTt9Du0oWvkJOo8a43aPiGFk7vgmggRGTeFMWIDFaiE9mM29rUwDgClBH3lrI
XeWB+D2wwWDqMpYieUfILTGMy3CxmaRzbnDXi5dMsdDOPz/9PHaCUmdBZZWL6A9qwze/RKVbTiAY
boX+LxbL2/uYUKkcnym3OkNP2VAkzXKMjs7E698ktsRGtjENjESaiAbNPGVOyKLR7qknZZZw2n/6
+itk5GF0Bv/lZ41IZg0B14EvuTEB8U2VLjZb57h06dRdt9ouZlRmHnTKb058XCdYqA5I2yu3IfTc
itZNOe4LRL6BeXOx6qfj5NLSqsePQdBIw2ralcoxbWrlXgNCOX40vNv5VFgw8dibH9vVZNw44kXg
vbtTsRtKKetGiQCUFpbN84E0DyVOnZwlYzX61lrH2U5WMdhPdV8idzQDlHAufNBXtrx3R/3Sl7CV
2yvCJvo063VLPx0W6fS1G3F7RvU+L2Wi9OIsJmVw0gcwf5ucsXq8L3AHoBrhBRK3wFHmyrnecSGY
l6NvwbHgWb/hTkFd5nRSR1z/vkwcoHH8QKmgEp0baPuHNGNMaXIeUG8BqMqQ/Ieg7xhX3RDHZm+Y
XVc43lC9e2gPrlaDxYMp93rHsz54BIipxD1wkKRiUSUEa7GO3YnpysEsXjAr61x6feYpx8fCXunY
mbyrMpdMGoVdkM+Ey7aGLi83PaoDmo8DovfeUYLz0SPex/V3jBLQArRjvv9E4vZDPq0NQ5a9yL3U
dyZeCyauOJ/kQ0ntkFzLZ/OXodacMZU8yMhodEFSY+DEE3QxUHOJ8MuS37aH/JDAycjUPdD5UXPR
722l2ZHZ/nwC1cBb2R/hOnNuis94UnultKkKItBGzZqQ8RB3a0FGcuaTONCY7wcBILrhL9F7+kdd
SUSf3ieGfCHE2pgfenEksv6D1xDHM1jMQzos5RlS/+Uldw/UgSBKqaP68FvtaRSDb72UI/NqZTo4
X54wwOUPOzGDiejUWW+EMQ939BqfK2tvTqjrbkE3owbJqn67wJCEEa4S9Usa+1Ho1vNMkXFksC+c
99Vkxt2KUeO6th5A151Yz0FuR6xSb2Acxf2Yy/LfpsNXEVMVyuKINyWPl2Rqrr1Kb6yaFzW66HRe
XgX+I8bxjHwPxss16R5sAcTM1a+Ezr2SYvESDHxWWv7Bd7rGcyfKuHQSa6jmBmRCcsOxOEym8ucl
mqReAnBRZ1Z/Kew7VW2rQ32dZh+MX6rrhlAhmPADl/An4EgvVz2jvCgA8zP6aghEDJXos1t8W8rL
/d++FGh7KDyQXIMWuvzlr9UEcXMhXD5v/vhi3nMRZX02BpE1mxAFjX7cB79wl9FLuXjrfD3VIegc
3yM7cVXSGc+lAhuf7kYzIGb60IHp50nbjHbURNYGleldkF6wX4ReuXTxEP0HdAozkwI6IXng1wuI
VHl12N4ZopbOjL9FJraHFqF/gUBBKzLyBo5XBzZKe8eYVMkJdyaJj3MfxIKZxRirNE5fhUkBz9g/
rsFRfArzDOeInHZXtBTH6pXa2Am7eNsw8+02ppZPAjw6KuXBecB3/LBetDjBhQQv0WTE2jo54ZUC
MQvZGtACpcvGw9bDeS4lP7oN06A/ewmoOcB5g0h0FUTu7W40kUJQXulo0SmrvhnUmlstGrHT1QYA
B+ccAD8I8kH9kyUsFKf6gs2DvqlEENsSHCLh8FAtYjZR1NktZ667x3+q6009DcUMP89mDAU9EvC5
9JhxfqPyNX2hkFJMom9OeMJBjYZwFrBohKnQtGH2VrlhwcwnhbOcYb6eMe2TVmSSrugoS9hUdxPH
S2FOuYxtID0zeFw26C7QhDOJm4WqajcxNg5SzlqLmtyTABMy2gbQyVCvToAKAU0Har1bErTcfGKp
wNraZLi2Ycdtx0Xy8TT7fVjqSSb1h6PosZ+GMdj+eBx5R/Nb3Mw0v2tOFXQnyJ8t7kDrhpOfZusH
QqU6hcLYH9fITkdQHmQoLfoZRKHxZO+Rhh/X752kkzEhb0y1kmOmckBZOZxIveKaoJgQvzHff2S/
RYlrsEZejIrDgTrPJiRTG0bBauXh5tU3GOIRpiMIa39Myc2QkA1i2B8kSZEUtXv7cPYjP0LjLKZc
K0O6KS+FfYBwcEP64dkaY99jV4r0iDTB/nOJBiKraJN3WQqa02/O9d/8tWTOXG46SicdYJ7OWfi1
RD1L6wzmU8axoOm5NrmJvOcCKmHqbxynDjAk2cVaYvd9/H5XkSLdYU5VQQSAWj71OTReLD75A0Lp
EzCta4TUTwvqjaTL8eXQvFOdEYx6474qryii8+MRfgJCNOb7JTcxE0gEkOkH+l1Ay/+ILCJqEn2l
VnSN/ygDFutDRgkHC8uHUkwu9FjZQtj1HxS8fdZMvK/BuhRxMIvCpMjHMFQ2d/GONy0r4NMS3oxT
UPEameEMBJ8qfOH7cbFPmfk7+JExVTvpDjTx07Y9y48QKmJ12Su1n9TCBgvW4Xn5Swg/3b0S5Dd7
giyB1RgI4zYWvq8eRltQ+IlgGlfmIJdRXf3W9UAhlJizUjIuDZ8r8kMllr8wDyo9h42VYMO4WB8C
hzNXdkwjqR69Vh/hnyyRRUfnx9yQ2C0KxAjjqtLG1l1FZuS/8rBlN4P08JCo5WCJUDgxNyuj7pjq
JkrYRZWuOy/PWrQ5wstpONoeEQkSjsYVjGa2G4AXbnSaH8Ty1Uf52CF5Hd9lFtNeQarVIiPwBgmA
YGgK1A7zn0GXIK/EUPjtrnpIvxco/vPf1fITnaZ6cdZK0fv6+7F5/YvBjgwb0YGZQkhyFHV88Mcw
WcJpv9jnpVnIJqy9OcXC7as2w/MKYyGYttdSSnGS9KliaQFcwJOi6x46H9wao/tVgvCNePSFMpa=