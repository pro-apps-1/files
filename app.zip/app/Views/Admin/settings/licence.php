<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPviQKDc6swWUNyR5+ZPFBMtC+KywA77Qqhwu9d7mHssmvdaWztGx9zLtl8BIQDdHTKDyubs/
ARenR09BEL4K2UFkv59cQCN+qyrV3VZitXQCLNXxwPCzWKMzrFR+7fP6kwjM0Krci9C7f/t2JhoK
7aQgsKUm9nmm8Cxpy6P/Y5ZrGp/4Wni/xoT2nLU0w7Ag6gRQsRe6HCiLOKBWgSsg6rfpWWFHDpZE
IydFQ919/KM63n6Tke46k9zHL+bBOnJ6VEvwfnDjqKeZJQJYb92MQiv9HDfgKFLi8DBevfJsBt6j
ghbI/wMAnwCFTjOC8TGcso713+IBij8J6/BehNhFMm3sGiREp1xaJb3ag/q6QjcepbCxUFOI8QsZ
sS4B93j25DYDKrgJY63cuTGMnyvCgRRx3Ppq+REWJkvt+AqVAUclqo5TnyxC84pQtjCEedlqkb7h
nUKnb6VZjJfXR4Ijb1nzB+vsrt7Niy8uburQpAB461XuchrXa8NNej2wnkhws9LU8HRnfwIjVAo8
3NNMvwjqhYiIa/BrZxVdPA8EGqKlgglfusx6J+A7lOuR516Hp0QJ51u7ZWWFCdm3THagFxvJiDd7
7QdNvyKAcuB7W2cXQ+/5tF10xNNAj7GDzHp/gpRJv0p/MkG058Ib9MquFunAUX9NAmj12L7jxQkb
cYdkzrOQ+W91s8DFQiI00ZaghLRONp37Nv9hVyqcPdY4E3iVgldd2k5LDymaVbapcNHlSCjieVvp
MYe80yLfv3yXwFCoRLavK7NXCmFmnrgAVMn1xp6YOktSTYZvyQ5nKcGCwcD6Gk4KkIB7LwZU5MoP
sAGDf61qb9c7zOu6vV3AJd619ok8K1LAN0ucBIU3dws9H4bo5cKDGVEFC5i2+ZrIg1cqvp6LsclM
v9Fi6fLG2z5k8t8x6Uqg0yBYX/REODsa40Ps6fXzknQe4R1OAhYIzfW8H0CMi/WZo2+ETmxm15/b
RP9gRmAoxeyQ3FpdLWv/xAZnBmVsZ0QDdgk8FXuWfVzxjmmdgw7XbOjLjkhSyG6X2rHyK8f3jjoa
JDsVscAWkGD32fez+mb51Vk6yPQH3yqWUOXTI+udoAI65EQmeRGe/Pc4sGrPLaBRaVsiliofjjtG
ZaICfDbi4DpL4q2WL93KQtBCOnKU7Aoq9Imo9Vv0akk9U1Oq+aLvBi6Olmr33aHQp2BRxVQK7PPE
cqQ5R05MD07llaRe8De5eKNZbGFKy9u5gwc1GlDBlwUpqNeHz1Ii6hhWoX4pwCYL1dx7E31x0NKE
XqmnheWND7F9eQD10iC6Paij7ankw64qxBcxDhzP4e4gP0yqVNSusHK6S4zMrdxUttnU/VcLAY7T
bj0WKNo0b9hF5EKxH3bX0jFpFGMxWjO3tHc0aP77zxgyb1DUPHJGQiKuV8trb3HBvPIvFM6xTIWi
3ENETTTHwcfPVn0kDsI1JTwuvAYt4o2m1t6BZ6Z7WC6ZNzE7gXNTJsfs58vK+3ZHb39UWUD5/mAx
/ofi2KoEHZdYytdn0BHD03byl5ynU9gCXP5EhO/JC7xEOjUiN5QDIwqrUomGY2cMLUCMwQA/Fwk6
IlYZi3U4Mv4MnYheNPiKQZzFi38V67YspVQkQWao3SKrGKtG9WksCP0ivKMNEK0mXQZ5ea0jRi2p
Q2GuKHjOldXp2J46kFvDMbLKaQXQco7J/6AoOG5Fe+jPp9q7JvcpO2bnqF1rd0saXqLmknFtUxRu
XXi+Benq8u6l/ABSpIvQNNqI8mKHenXGafpSmQ6mGO5VgEUXEFS0cUQfBW1OzYbSqLT5fzQAMMgp
ZLe1ZcGzFvz5lY1BugD3XKxTG0BIOiuUz/5clCuZSYJFO0g0frm9WjJAQ3wFsMZTs4jcUACgcCk/
94YAoS9rckKm0PgG3dCvh9VLdjYZ5wjT4BbMAbE+P7NAMyG2UfW/+CaSzowi1tUT0MFjeekVYEJl
J5B8Yf/5pZEccqBNOTD4atuR84pTegk9BNAw5Q3O3615VqgBIoHrzENSAmwg4s0bpDAy0rcgO2Ve
n+UWA9OKI5A/rjONm0YwNaQQiAUrvNY7ZBXgbblyY9y3+eskfFqSBYpiyH0Q1ozPZAg7PgEPPqCL
DpR1jolRhDCnCcQQPvJBnO79aozdTim5dz4NSeDfV2bET0VxbqhrtBD/wrb53LS8ILCOoNUe+J/B
hDH3UurbX3P9rvFb7oYY7AmkmKL3