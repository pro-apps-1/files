<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr6lY3JDBt4xY7CT5sLZKHeglH+KbvjnHOAuUSzI7R8LBNr44H6WxJMx2QYQKdGfyaUBYEoj
MFoVoZ0ihLAai8z+VQ5n3qWtn3/v2pJ0sjWtaMNh0mo+2MqrDLgTdyefcNVfXgNfSPUDQ98pro+b
EWnU/tFl4dksLXMtqd5L0WAcYSdCkGQ1mblEv79czkrmDX/kH3H/slFy018q5Le15+cpTa1BPFqF
81/3Jnh+c4eEO6aJJTQBuu+4hPK0zOXl5f3qbe2r2DXL8GlSdw9cbuGu5M5X+9mEISPyWgZu8ikJ
2Nb1mCdW+Ur3ATqbkPMSgRmD3Qx+U0cNE9MpJ0qlt6SIdZHAEi2STf/icoKWjllYKQ64MLr7TciR
NgEX/hZv+QTOmEVWvyPpGT0Z89eu2yGEL0z3LhoXRFvMc+yqUqAeDVIU6m+qWLX1ZTGmLARevT2o
MEPkb4rFAS8RjUdCphoxUcnVk5BCfomtHYqoRkyOBXFIt5SxjVUlMgTRClxPEIyzGskwjNTceC9D
MMuItdHfAVpPL/en/CXrhXfouhunp4SvKe5eM3x6CVrGJz9UFoHxqHWTRDrs7kdlBWbDmGO6bFz/
+gWAbDXYeVMSI/r3gfOUOFgWwJEw4ldxX151UMN/ASx1Do5TaRnDY/RwEnfjEZVBsNqZE8wEVgsq
r5RuwqW5DTqdJNugHtNIKBYB8LyI436uVYEydVYge0wWouLqA1FspZuE/+JeFxs4MrtTcRPa5w20
7Jva6XpeIL/1CqwThpx1WHfpeQ78Q0tZzQ4rujwsWCfLwHcRKV3lhFlPPUlY/hpJcQTWiv3LDtL8
fgqC49/hZcowlYTU3ajlMVv96OqGtQtFUYFC9A0enYr8Wcmlfld2DCDKeN2qFlqi0RsYThR/OIlY
CZclbBaCw2YqlSaOOqCkpxjQOanMag1YPvpSJydttcMLbU5AMLHIfLUMZw3phoEJ/7zm3WVwBbwp
fO8CqUWOvs8LFVyEcGAbHl/POQytaUAosHwxNB2PLTkrjzZh3ir5OO1oooW3IrgGhAVnqVGopN8h
tjZwzBda25goIUgiR/qKbFlXfpScgMBXYOlIJKdAVvUPbTFcZ8uvKfwlyDzk7rjZGCWsdkmGdCbc
Zm1ntIcUPasRjs/LMK7eUoF93QlhKQpLrZGZo4sWlfPt79AyU7bO4R+zm0elgZGC5aLtYFY52nSX
bktLbESJ3PzD0kCWZLmKe3vVlfFc8X613OKoptxDG+s3YU35XEjsHOClsxHcNSqRL+Yb819611EJ
OGFOXGJcbtTFXmDkayv/Y7eMEMgH4vd3iGeKjfH/2tJGqHVukeDC/nqBwiYZihSY28xfPdcv/3Ox
5U/76mxO8G4Ikdx2vEcfxEow4N9UBzkJ75i0UDraGaCfgmbI0UT8SdbWkBchUNguRFA9I8rXkgwi
h2kV07UVgBWGyR0NgFiutnKb4baphxMsnXN17rbifs8+y5hLqOoT8ok5Dd688y4Zxb2wGPEh8r/E
PN2iSw10EEAzC/ySGituSHV4RoDC8Ypf6gWHQ6ZPvo617dC0kkkzyVvMoUJYjCse2awZjCSbu/tH
4ui4RFsNNobG79SOeo8Ife0sHpT6ibejcHjRE6zQgEFpJbDPzkDV9TGqRyRitwNqmLg62uL2Be+0
BHKgAzQXahnSfKQAbr2oFdg5n7a1xj8nI/x16rL4ooETZoe+ksNYBN4a8BYmgT54Y7BSc5U6f8Ri
RhggITnM6HA2C9zP37u5jInLFjjN2rzJyClEaAJ4vLcui5EFbEunN8OTLySMH1GbeqehiSm8cT56
8GTV2+6PHYPUXXk5FUmoPpr5UxY/wqslh2sLlAgcDoId4Xr8XdHeNFOf6PhvvXQqSnsRWUvIw+3t
2akioZzcR/g99irGRK86fvj/Tq5sEv7HvocKFP5YourE+MvwhDKIbpe0umig81+gExWxgNjtZhHR
UWcUwANUwlqnT3wzmIBxKioGYDX25sgt3zhG2JsMY6tcRZdwV2uOZKgVqRpbAtdNDGx+pJVRJveC
afhydiYGo7b6MBnWCyaZUyuTGa29LsVI9J81JmYDTauS8Glq3sXPcsDH0HvnYboOTL9WBPiELdZD
wbcsER8Y2wcA+50IntiuXfhCwtGY6fdzqHMF/kKEYwA1iK+vZIiESjqr6ZITb+kDldoTU97hiCA/
IUe=