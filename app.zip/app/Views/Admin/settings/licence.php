<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPssYWNBo47f5YtuKKURQN2ZTLoXT5BcGMx6ux3rTkVw15ZkZ4YAbxIuJje1VJkjnpbnqwayi
lBmK63MVndc1OmGE8Ekj7ad3dX0isRhyEmIaaEG8AXhtVcKRv5Th13JNiv8TOb7NrHu8lgbTN/zZ
t6TfHAQ07BRxQVSkf2irxaNVdXbKiFC36DxJTOeV1qIUA3WAEPlQcOYWxIls2kxUac8oGBjz5PLl
kZYMUnhclqDRd/72L2aGuJfhxmIhDMlBN2MiCHcsHeRqKnR6xUgE+EdiLVbaCB5YMjg9TjCIR4c2
k8LMqnrLQ79ugiWdsNgB1H1+e4eE3ZeDwzE6Zek9dEfU+NN4Iv6DezphzDj7Dg7DheAUfzMhdGcg
TsUOrZOglpAc703CY1fzYcM8QyHtTL+GfLFDdZ7uZeFVTlgOrdu07EbuS/bmIIwfiHwOyGwkt8yk
+EwtR8fXS1PF9dj1Q0s4zAGdIB6SWvevcj4mx4wX7+jZE3KJWroOsixTfJOBVMlHEkm0t0kjG8Hg
XU1Es45JBJQZiyyBqbSXZYXbid68E2W/9fBxJOQ+5vK02o6wFT2zYl1vXQsM0d0ZOezrKIEPOVEl
oSlKhd7uoarTHA78uDPtb3WAc4nAu9DpH3MGo2i7RrdytzW/9qqO9MgaSJqo+iA0SGhZR9OOaWrp
KEzWx9+8ZUWeExabcUoZi7OOdu1BezNM5D1sn4XC6hVfI61a9xsPDVqGR86DHmMkBAFSCVw8vr3S
SNJqJwsK4ZEjmjE6Y1apge9VY7x1joMoleImEs4epMirHd+yVJL0b0nT/vvYP3DKgNib6/PtaPdg
WA20W70k/XUInX6APItD4Yw6ULjMwKgnsp+RINYWhJD7tJq/XerzjojA6lugNYFep+2n9hNcm9Dg
a9gC/T95AgYmfxZgPqoXgcV9XGXp/aOq+4j+Gh9Ynng5838noMY6xHFEGPqj5P9ODN1orNKfWO+0
QzctK7BDXndlZZjiNfKG3EEf5w3dj1yzrV4cvjIVOUenynXZJUArtHg4dNHYHG/E/zL6i3tNII7U
p6luJIfpruD/yEnQBrWmRRadgPDC+PWSGl8505tdwPFS28QOqWvWgpwYLGEPm0s/9D02DxnziJ7e
crgmsl/EJgHDM2/jorvEkkdjjyOPEXUNWIhVUPcrfxSOcGg4WeXFjrM0MlFTVkRkf7WY1O6sPlpA
64rh80s9Wvqs4I9MEXs49N9eLp2gsSUF9M9ZmE9Eon4bCxXX1fcAivETeyOWTCS0jSSVsREuBLiv
zPQpfnI5tPe2xYHzKiAKiepR2Xl444PZXvfBMkIU9b7CKBZeWohTkk1pqYPclaL554Llqpj5dcs7
FNag6cahT7tE18IZXST1CrAiLkjSQQLgZqIX1K/9RdvAhtu/9P+otZY5vItsX//je5DPqct8kLis
OQdfTqjn/y2k/85S04/CBdgUbLq7ltbZOT4q0xuKCsvO/XfF6kzUYnR2vakvWXRhypi8Vv39YQlc
6vlHqnQj4qCrbrDfxyiC3Ej5DV3XyWxWZBE/VLVyvAbHzTFIW0XJPen04HOPkEndfq49HIvSZgY4
+OxiEZvl6NU5QO/qczxCnIw59TpUC99QCBv3jKTX24MxMd9sk1J54Z8dkatGbqgxoA8xHXZAJyvV
mC75e9+YAmoKRmbWbTWGFQ+GEyulOPGmpGOPIN//nmavc7GDGX3dkvzU2HOOCVMhQoWtMcSJv48/
83xKVrheqkQQlSxb6u6/eRUtPKKaFRbixJLPZ9x0ffLFXqG7iQimHl3vovjg17cbdMKEVJ2/R+jB
OoU16H4hbSRxL5+5eN/IUB+K84jaDrhjtHPxzHGCHwFwjEPRbho+A6DjSSb/PaAo1Lje6cIeNVMG
CPBD2e0bt1PVnMFxQxoQLAIVxjANExPrirJxs311KL5uD6dHxPI6KHw8wjMzmkz+fW/DQjx9J3iH
Dv9JhwkHdLIKOFzYkl+IKDDFoPIibT0YzL3AJgFYV3GBohjtCUoyttF+T8FznTSEcxv4iHAn3hc5
OPu2GgxbSUUUKULDEaZV3+XlB2DKHCj1BbkMd7yGCUrbQGxT521Upx0cjjHsnvkZIx/0e0syt4D8
6MQGTNzuz8IgGLmZLAI679LdD2fi3/cncf/JVHEntNVUTCEy+iqVj8LY34W9g5PWKD7Pui1O477j
WmmRm2f+n4KMWVat4nlHcfMFo4B4Gs2Og54AzY4VZot+ILeA90U0w22RWeO8yRNvq+ks