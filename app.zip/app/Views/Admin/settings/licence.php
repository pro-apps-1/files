<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz66ReXoD5EW2rhxgtpKSSfr4qlJO4Iybv6u7VjL1tNxYQFkpviaudh3ncrD1nlO/3i36msv
qinZXp2dd45EU8mwqVtNxS3qju+aEkFbbHVrgXX2tzj24kNFpT8MZC6NUifULK7QvtNgGMwM1QHw
iKJm5Z8BN/Y/DSftbBTtPHsARNR+dwHbgderyH0YR/bR33gQZ3jHxvN1Q5DD1AXumGg0Baon4ypg
9pXtGZbC3pQFvfVh/mhK55UU6RxXH5jHbu65k2WvKiNl6PD6Df4hcB35xt9gynbb5kv8MRWgYO8s
AfbM/vDCwdO9l4ReyhJ0Q0ag7agfLzJZL8GlTwQg88cxBNMhX5VSlhbEkAcBL/Yr9DOh6/GHSgK5
r1sNOiWXJvM6H9gCJBta4Ah645k556cAgDToc/J14aspTBvhdrG8xoBQ460N2qN2zcl353Nee5RM
RkqhVnMEWVu2Yk3/qpWKwlhXeDYGhgH62VqjH4SkbZ231ZtTN7db0uQREiAxk1UEl8bD90jiXXB9
KRfm32BeWmzkUZ/pbMgN/k8uC0jF0HMBZo+dvCjlXfg2+icRYoUyCoj6tmXnXUr/MnzK6fRSvZcn
nbzaTqscm5cS60OdWtYZQk8Nz/tC7Pn3rGxxXR/EIJss1ZLF2uKD3oHH0oHi28LbNIWcltm6a2W4
3bcuROclFvagYfiafpK4hSNgjzLO0sXVnjajjIOKqd9EFbEKakavAnIJeKIVgqGZu6EA42KpvXTY
z0RzE5NToz1HCKWATNKJcSOGEHE5WWvLILJ4yGwRAw4+MtPZbXbM79tGteyYQgssuLemgIEiErK2
GHtwmq/ek0swm3sLhxBMwaIdnturWmML9cxZSCHG2mpXTYmnqLCqx/Huar2T80H8gYiDmJ478nSK
wQqEXg2JZvuKznDSMayBWAQtsjn914lwqGpopkVDZrFcxE6h7xsLHnHQtZspExbaLhicK2j+6r1A
mDZYqFnwPsgotijLj1tCKleYnuN767FyFhz11e+EGPNB32wL5DPELnU6VFYNZacwLse1gBDjcHg4
jzd3OfGnVJDqq0wVYi05WIMYJUfcw+w9gb7nakjDOdQR4TIbxCF3GukuMcfSofCDInRFIawproOY
XoTcb2XZNKz8zudmek90qyKg0Xb6nWVF6qc3JMNFU0cgMSZTJww1vtHSSK0da1Cs4iPfS2mDcagY
u2E6juLDqNZnjUhITusqkjx8X/kOSqx3CGCp9MYFiFs88CxYFihqOPfHI8p7Kj4UpZA31qNUOPUR
NC/FZ9H8CWhJx+XJDE+VRGni1kuvAen21O+XCjbqeebxFI5yG5Tg/n9hYAvij/4lQUahyguaoJxy
ct9ruasYj320MC6eJABWNII8zoI6OMz7TZi6nPOcmBCed2KDY42P+2u8DjVby4UJD9tX5cFdC2OA
SDjN8T8IxgrABWZRPX6slTHpSiNNbDX3qkQBnJzyju1Agj7SFKBdxBg/anaHb79iX7FCVlWMkKn4
RwK0Pdru0HiIVTDbZ6NXRZqZh+965P4JAGzOCMIHC9glQ6FmGY2BomUrLl+9RDdhsPCkQVhCs9yf
NREb0L1B3JqRI4JKJHmpWVoA5OtxaD1jEyhu+X1Vwh2KneBJ8yfDLKc65OaHzFYwSsDHvzfOn4bY
uLIlpDb2ewuXsJF/LodDD1PGPopNl4iTeUFaHgySCX0VjycqM67EeDvoe8NdfQNYhaTyNBHAnSvX
vOTb4x4ELlJMCtZvegdYCAIWch8408VKQxetS5AbcHi0sM4SqVKU9NGXXhu7ObgOGd5TMn1rXN92
5jA5ok0kL5t+xuRKvr9yciGp12n/YmsUL9zgUH2X1/dq9KQzKnEpu6O8aW2G1AMGaIZrG+KeV8G5
3jOQM0FR0SMBHNTzxDIZOZT27S5DlmAjGnkNcWQ6Hn5sAYs5Z6Y/ftyIVvC/cWC33mUjU36FWEZ2
19jpPckVk9b/sIPrg8MuD6T8mZCLLyhpjqmndmKX1tA9GrgFJipw8NmGywDtA/gxIC976n2PcLXB
0RMEZRv9J/AtfOqDhF0Jwt9NXoP/nnRUhgXn0WwctQtnjjpfk8xPqe7O/JqQz/JXe9Mr8TRYyoxs
beQlUmlwZD85c1bcBBDtYnlMZzbWgaZmGPEBOskSJrO/ykuRe9lNOQ0+wr1RsFuTIzJ6kQoijoC=