<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuUqOQR/U3fQYePez8N0T2ECTtdkE5n+LfcuvL4qIq9OZ8Z2zy7Uny43x8cLa9hHAqec5UXc
yO89wENU7dM6KtTjYtxvD1F/CSl3seJxHZ8IRn6K4thTJk6pSmh5Phbj6Xq/T8VDe9fWUhUebAC2
Vj+7srbLya7pzIKSCy29vT/aqJXi7y8cLANN84hegIbKqvX+96xweeS85igUOmt8cya7qJ41oqIH
GV5+ewcXIHk4GTmNVTmwtVsvnwYzbG5IxS9VfBZeLxUYiG0RuwqfsmxzavbjQXhLgAnlN6MVi1X+
u1id/nbPbKjmm8Y7dVEOyj+ge6wYW2y4VGb2KlC7ueqxq7slUM2xEZLVWbAZGQ7Q9016qdN2AL3m
mHvi7W0ZNpdGFKEQwATeUSJ1l/WsGFdAqyBXOp/ldUR6XHbaEL/1b+jPOFvRjk4b1F+aeMqUQ/ef
dQj3sJqMMRSQUAF5iOw4oLd9FZKZH7N7D7b3SUJRUrLCoUoXpJF/T7+bs8hkSSCJTaPHVyH2D1th
IbwVScT5qX4OuPDRO1+lKaLCbkXiRPT9yNlyKjrxGV9f3VCK3DGjcz71dzFxBq/HQumcMrz7Dcf/
zMDiYMWSBr5ACwqvllfmU9JMf0BrMAuF4OSStQ2B4sP56Z9gQb58bXHmWCQxnD3Gnx2qG30Tl5Cj
hcbdMRnEdgcVQIGs9og+aNRMqoYrRE4WEyWOwoZtiQj9SqOMPINRt7yaV9gJXZPeamXm7jCrNmC2
b4tCCR4BYHo6v6QbZcFAFstgCnlpXYNE6b4SNuKbQHXqH4Ke565xRe79QiY21ZexZvOuUq2gYJzk
wSk1m44vpeS81K03wDYawSAop8LAHGAFJVegeAPGXaTq+clMoXXLPcUrH4E/a6xH7a+n14iB8BWT
+B8wwkA07mh/N+UKHHPLZ0fODGmlkDpvp8Z67oMZSl5pV6Yu8GBr3mO47mX2qTozipuH+oQCQMYe
xY1gcz+CjPK8NCtAzO/eFlGQvcy86IOGSCQyRhjYycPla5RKK8DpVHgng058QYE0PwcmwQRI/lLi
XwwVU2I1fCYnZcqgtwrrygk3I/maBTxJzlOJADlGewhgub2bYs57JtpZx9mZSYjvyt2ixNWNrRFv
qV+ADM5KNtUF7LWFOE/mHq6EMAkP4iHfS5Fj0t/ve1iI8Ba4key3/rdGKXjCKkkYKF4bePZ+NR2p
FvLEHoQsk7nVZ9Mx5OaNUkbkRHktPzH+QKyUxKqaMrGmEoGGVyK/mPzPQXMqdBnwCHYyq8mbozdP
KrLHeWZxszp4WD6MekTO6OpUuckxXo7CZw/ry8brbskwlfAAupSTUOq4/mXeux/BG3J1veQeah2A
nSuuz+0jwSpez415Oy/vsxtpEe58f6pNwB6Iv8qXHmlT5PhqsbQgxite91NbMPrxZbRWRZfT1TQ+
4VDU9wKGP1JUJUDJAczsueyE6i9uPA4c8ItZDFahFIliWfasiQdj6zZsyLUk9nYp4Qep/oQfAmud
K80K1J9eA2aEvbjmcQ6FddaBhzHYjeClTkUiMBhDhPdCS4ZDCq/rX2qnDeLp+glx9bA79vNvxk13
WmumbhIn71nfEDNpZQqE4q6/p08k+V9Z79FgGIes6lJifqTT3/Z4orKkjnMu9oEhP5ejzPpvrnTR
zGIPRPjDoUKBez4O7n+LEUzAqMRS6hY3qF6nfhFyaW2dr44iBlrKMiM1aX/wSqNQPIlIIonPzt4A
wBy0xkFJT6dnbzUQh+qWEraabXdJL/W732YmAtdNMG+2BYMY7aJW1UexvsdInCnaPz7Z8O6zD6TX
JByuLVNJ5M25qn1dDu66u27L5dl4SNWEqFwiArGHFOa741hcZ7KoY26uFv47rpW2laMVjXrCAbTe
Xs7fYf8tSK37EMHPMgnUYIQ4hwWDJyLNlB/7kC9jMa+4kQB1vxo9ELhBjDG67+9SBS02ztF3XJUL
Df+5hAXxIO9CKcKpmVmUhPtQIXpH5i0XAvqZ3/LUnjkF2K2+cAViQ4xLopQusw048w0G8F/xVPu/
K8c2oRQn3QQx/q7twvzUfkJ3UJYF19VQnIDeEhmjDWg8f5StngQ/TDna+OU+pIlTyDnz+yO1Hmas
e/2oFqNbEJT9bzHit1xh9Ao1w7Gdv67/oFuhlRjV6soMUtmjVFVKSAMTp4xu/zMAyQD0AnTgLi5g
N/gcSdWKJNcsnoESy8Ca2sEmH9xeJ1KzbOonpWD8TAEdG5EL+NgPWmCt0PQNJ1bSGtiMJycKuQRg
pylktbgXm1zjNj0fwZTu6c1xAm0RxaPd8vYgUkqP9SYPqZPmMxxOhKM4y7abrs2sZzlqJ1mbGkJy
wqgPHUF3x9YPEmIyjOKpo00oTXJwvt0MHQ9zHso3YkgKUxLeCafZTh2rRgyZcAQEHqvvlO2I1N8P
hveeoqdbyPuSXu8ZstVp3rslv04hJshvKOTSSh9EveLMKki1KrRMWw5Gih8i2dy=