<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmAHTL9GGKvcBKtWSSGBxXlMk7uRzDP8WB+uoz9Vda+hlE9dXVd5zMUzNsPX+0GzVPaxqJxE
QI2kA4yWm4UImJ4gWOu2vpG3dLpssdIJezNmNgVmzc6ZtO/+q2AqZstL/Vfw2VOWqio8lVAEVECu
bfXEoCokS5E1jRzlM66ugVwrXgV+JV+yv76sbDw1CiPivTKRVHHZuNlDyBhhMFM4lOcZ3AhgAmq1
Bq5Rj3FR3LCSng8g2+ex+C+vITxO4Tao+J/St4A2h9bI+Gfx+6/Lx3YILY5qG3lDkz+vPGavWLk8
ZJeV2NEXF+eeDx5ref/TS/KCsuvr0AoFKFmD3+g2vdDt46r3Lfrk60og+epuz+Ig7t29xNFwqK+S
0JbDV2jQhqodc/mtdeyI5TgjYudJ8O0Sjz0athIFnS7LhOcFeZR9l0KdIMzTytvOMXBYiVHxfDMu
3gUZAwLlKAV6u44OpncvonohNFfZ60AIcT7XIR2beKix8Zs8mEj8cUMAII1DCMZqgj7Z1MvJRhjU
deVGJfd5VmZSCcteXoUW3pE0UFnTyreWyOwFdUHROftzUQ4aVUoWxfPiP9dMT9bfeKSP3wmBiGj6
tW0W/+fYQDMTvaQm2/sf9WEVc+3wKhDzDccksEfUlMR284R/2p11LymGAzc/gTNUEB4QgX/TLmuk
SHu/LsgoaCQUvRHk4fCH0MsRQ3jLuCC3Z8YKrmsXv13mULExK2/tX2fLQVVuVFlBxOCvABtzK3XH
DwdBwjLyQZjlfuMV8j5onl+6bDjOjVYe0ryE1LZJ4nkRwKJJXGU2P+b+M1hH03VEHvwxZQo82cwE
h55lAlCECBHC/NXGkfRsh8YSqTfFo6GAgVBv3iu3/XrCK26KE3boLdOCffJIP32tjvpktdB3/LGp
6QLCxIWhFKzrw0CMfNchre4TEayeNF9I6fg4w2U4D6JZ9I+esi+beP+Zx6fq0nt7LeUFct4XRBJ9
r4Ju9EDN2e5/fTigjMhJQs7X6oNuiaiJg8W6g20TDefHDolMNxZeuoLjYqu9UfTKAlurCktEJLJ9
OpiiE5IilzNMcWjESYJsH8ajLgGGuLVpIlfxmLFbvSwWhM2m64ytRpdwI2nPjcwuvl24OhZYuuyf
X3dAe+9QmVMZmmY6hnD8seRqncU7URgAL78DiiUbYjRNhzGzZHd9fv9k4261BCJV88hu5Uopgj43
yPS50qISVITA8goI/D1OENKRwNMGrcbCyenB6DgPlyTNTkELshp2lmwqTTzjYxge71EylHwZ1M9g
0cNtRfl94jwb7D7doKA2q1Z7OnqYZvFuxX2lyIsONJ9mwTw/v9tWSmKchuah81Pwxw+G/K+YuJtW
j+NrLT2muEWZTIIwW6LZip/xtfTqije85T8gxxyZGJ7bpRkBfYqMP+86mPJXn+Gmijh/3nXw+Sgg
BE7N9a0I7VjJKGffx/Cq1faLoaVQnFb5mYzES9Qswc7ogofAn+6mtGSbEb0VG49+O7zEGa+m6mUb
9Y+GzUaK7yjYwd1wxry/E2gmrxnn356mYJtcgPaQx1coZldMlEvdH/aqvezusriRKBtp3ef+FwDl
Dk8cVui8sQywueQLi2rlAs9RPRUbHu6iWmKRD8OeQJN5mm2JSeRCJWL0lXz7PUi5zAUYjOpx0LQJ
e0YcNW7CbDO50kQjWRmplt12SKQzRQLyR2NyHaOkdzmMuX+qYSUmluxz7BVZLfpHrjUdmTKTN1J8
qq4BjQZPOJkL1G8OoM2mB9CjiKLrV8wc5WAw7NGPSvvwPQ9rzyHMi6OUrbh3aurD5d28zIGlTaeX
+sDfcW9N4+GOINXdR4RJftX41PpBV0G0mkVSd5CdZRmToo0W1ApflvAC/zjMtwc1Leow6u77CmiQ
v8suAiYsxDrniraEBNfBO3xGlaCp3O5+YQB1Xx7g+jr+FVz4qXu2GNbOqCl0SgLgCyCTAGXg3ZZe
2QJJfQTWuLVKz9v0GcEEM9SYOQJrVbkIDoFbvvDBJt6U9LF+biqGC0TNy5NzUFA80s4qT6kUg9Eo
a2Z/78yp/BhWYmzBNPQXbVOtRiEUGWSfyVA4DsC9Aqi2A+djZRp/mkmjrbWeJdwv9pBAHST7DmHU
75qwEzvOK988XyfB2CGgCf3OQDIeXtHWiZaqGCFgFSlcaSejIc0SkSfUyoM9cgRW714GX9zyjSfp
vd6IbDU23SYPQIVmJuwC1tFOXnkJehEot/v/upL6G9FIWnHptySYOWBSFTYQRm7biwd5iuQNjHq+
HNb7Ji91uBWg5E3HvRMeXj2FNxXOSRkIJazuPTkbGDNRp+dSGle4wyaWENoqpCFbI/6GLvCnreV0
08+3V2mdAGbScqfnqQfVNZB86XU/8cckpaF3pvFB9LJGJHJXwQ9AFQKfVEnzlq6zLyXzAk7snYzn
VSsvVQYFtYvA4ie9DtgvDgwQA8QSDrOSLyarmgfynZO16oypbccCHpTbbBJ0k4NdUJClk77OLIJ9
56wjrV+iafW=