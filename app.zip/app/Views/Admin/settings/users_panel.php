<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwwcLPRN5AxPhdh0jRl7fM8ehHTk6wtWQ8cu723PK1U1+cNCaQAxDRjgp1X01j+F4yF/W0l6
PNHLXkNTTAUehXjPjKGIKQEp5JJhgO0kddFC/ahXlG4NwKiJFyGZvgUx/MNXGP/2TyfVXoRQsmJg
jd/UjSuSYH1sCVpn0mHvcbaSHF05iGyCmmcAkZ+7Nka3lGwLU54wvE849qt0YQJnd4ORAb5CrLUO
EJVa/h/1BYo3J9anFkxx0bnIxWHm7NqruqfCZfHpRblOCEp/A79DslgBtnHfnXOZtJECo+jOMypg
hz1II+DNvrb7aVKl/RDbitRW+tl1jDfPXdd3zgmWZfds6ARw1z/CJ+fS32b9eVDuEwCTv1GLiL2f
XxOFQ8hOpM/XHnMcWS+e44jrl4oBXfAO0RDSMgLbqE6AZ+mUy+wraJcl/ohNFasTGLZG5wMODbc9
QCD+HpZTXhoaXDleJN70DbKMuUy+jUyWes4Dela0covKu5Ylu5Qf0C/QYkt/coU/GuxIWQCwybfH
RYUTxvG9mYIoGGlZ6UhIHrrcWkhbQ+0+Imkx2KczVMU3EXC2bovVeixIlj1lCSC3ZLxS4N/ef0D6
8FH4igAJxsuct5XM1+6nCzLHBquplH00KQlhUm8wFzvJfYo1S8u58zHc/kTe07Khl66oZT9UUvzH
QA+absrNFnmCA2Bsmhbm0V2KXiGe8yqzGHJeBbyKq17MlkVOBvH6n78fZ/7JhaP5u+Q0CZwfM2UQ
+B7PRYolsM4teu68XXnm8+Xrr5fMVu0XmRG9vvqBO/faFuGgtdrCgOM4rkbA+LSnEKz4Z2G7IEWV
00NzSNFHgzoCGcQ0eC4aX5hHr1mvf0hOcVC42js3g8Tl3al6dMvqhdI8BulEPM18Atf2rI55lnbc
U2R3s/NJh/geDIQpzOSzVJJd0/pBGsJpvYIK5CT3V1u6tG5/y9S8HFAtB29NVkBvd54emwCbS1A/
uHD2fQ9XnIsML+NbPI2TXaun18Q8dqjCDyy0aQwOXw+edtIlViJ8uUKNj9iFIOMqP0llNLALUOTN
jb7k0uIkJjAbcvykZMKWs+O6qWvFBTg+QsUuQZg9RSEhfzEMALxl52AyUQG21ZwAEml6h6Ycj/pw
f6CHGVuTj1qcB3hpxEkb4gYE7AEWL6EqB6TT9EFZKo90HdIN4kQ70o6vZBwJt3vh682MDxmpm+Ne
DHWoLDyYmffeOM7ILAfIiw0pp75HABIsTFUSqgWFUomwXl/WUwSSisIlZ+lXPk6N0WozdAOxzUYH
XyC4tylbg79Q0MT1b+GsEqmcx/oNejJzigGz2s9p0Q4sWkzhRFncKehPm3CZTBybBk6uEX2QzcKr
YLyA29SVckkcIGyls7xT1mY/FfPxsdxXD5P/FG363xB5mPc8l6I5PZSdzga5+1Gckvv4+1TN3xJ3
w2hstnU9XhQ/0XQbhmgaCUK4Qs8YK+vjb+YIw1Qd34khB95HPJSV/ZVN9vrgEVus766Vg4KqdX5/
RwYEja2y/YJ08AV4yG9UfuHeNSPYJ/ZuGzD8zmcRSShjXxgxq6C7JuLhRHrgsIsqtqeX6Q7L5IRa
eHY2O9D3JU6oeoGMXcNqYIviu4BCQg9NoujSqySw3cx8f9UvNp6f+vahYzbw9tOwxyeHYNlTjReg
Zrpdol5uJhQR1aXzAZLG07pSurZFbWgAanX5hmMd8is2KWYWIXrTqHL22GpF8pxd2On9F//pMTHw
ySSTp96uPioNwmjKi4ftQ4IfkOYKjsFB5oux37Ik3t3Z9H30Q/8KdZ2ZcmLQcIWQCgYR5RnfqMjZ
6FYyL1RCLXScDjocWubEZDfrxP/iaktqJMnoX4fcGk5tDxWfLLFMgCe5s6HKMZfS2j5LU+4NwAdh
t476IosbUsq4Ji13VCh1/qrYb/AL81+OldAlgnHkCT65qaHFQJlmpG9KKzE4X0vNB9ToQ8dxKjwX
I5aHy3/tDY79lHn3JcbGQl66B4XL+W30GnUNaHfXsyxDB5Mto7JcOD/B4in/qZMXotVv86txouJo
usaAJU9+y9zgba4fA8cX3FGgdf2quzsk+W/wiHhd3dFA3l1ykFGeZpZCzzXKQuj+griVp8Px845V
ahEEjFpYgUal4shBrqNoNt6ev/5a1P/WZn+DiKZoZzAz0qHpffGZkGvEuhp0jW4iolk/owlQcVEy
DDpsP6Ui7yOSxnXDZnTUz2FXTDYwzZOQGxyvWwdbiGXecC8KPjU6OLD0wmENg4JEBkkffkUSULuX
kldY+IkeyjB/LDLvbXIkpSy5+y+v/vZRjqfICRQFscCJuCF9y0sThCRhAREo4vGnqf8vKwSOfYel
qD5bqVhWjIikPqzZOKKapzt/70WU6K9GrHRqNDBITEI1NJy2Ahs+rC4pWaZBh8HZdEZjSx6EXUBW
KO6kBSHb0s04Ccsk4fgEgb0YvRnzhj8I8pzcfE2+21OO0dauJTEESkc/RJCfKm==