<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpBi9irmOflY3J2pxhILzfQk5UVrIml14R2ukpfKEOJA1Au1kdFA13SMOwrfDpiX3+qqLN8Y
2gP1dvidS6cN0SZcNi5fRHGOPZMIDHvwGGKbt3KOloE4xtLiwdVjHZYSrBJdObDkIdUCLreMwJ/Q
/JACdOD9stZ+pld9suottqoKCOkGJq8WaWmHIjwMooZcy7Kw09OYoJ3vApQTwpXF94bPWUZqdJOe
2VfPuCw9lKl9+lh0Ksq3jvKKxVEalfiNFhA1w+bf5rxjsEZ1L4EK3FLilRfdwFCcetke9D9hijYM
Dcuk/z+wd+7j0mlGsk06G1ureG8qaRy4TrMjFzH0rC+XNkGfOkmsQ/Iagyqg6IPwonpDNqsU1IP1
lNOgkYiDff6iwxaTIOHArOp4DjvgOniSuTOLZDOXJFhOPuyoEE6WkWpumdqmbKNXqv9DWgv1yEmb
1jco3L/bjOyAtkuihg/jgwTxKWs5JvnCHpuLAcZgsdipPVF3L9h2ZF94D1NEorqT08KONvqNc2iO
BZHW/6RL9i8BR2O79+vRQDUDIJzDaczA23k30qbrUPhOB5BRnK170lye+9KG5QQ7EPLjRrfwYWIS
ww1FdwKorLYRmMw7EMIGwIz6UuH7R1cI+pGkw9DzNLB/0qzKtZvm7ekwsp5dn/gnRJiq/ajF6xth
sYOwO7EOgSQa+eX2JaUSLKbbXCtpwH+o/RpSXxrNlB0Vojy+dYDLT/Qw5zvxnOWC2z5d2Pk4YeXw
nqK+tM5hWoZUF+Q65R29zfWM5/XeSGBxx3lcH7NcavgL1LsSgV/E8vnpJpMiOpB1pL9Hlt4FbgvD
Vroozg/P8wv3A8tGEooj1o49asqmzc4db8OMUJNG74i78WgYSTwMqM9rGc0GSN+Ps07bRy9pIZqO
buffJTV2zLHGIHc38WtZp/DjCXAlIon9+V5w1zOG28l4AkcnOj2qJrb0gyNr3w1lbWei/YD3Nady
dc+UQTHpQHe1QGOFKlVcBlUd+XxYJBx7GInLPzinkBfcRUHxDfrsKkIVsMTb8StLVFQgkHDR0RaI
cXfHDUU/4wd9ELpIUSKJIqa55H325VDr9WCqIlxzMf5YFx1lHhSlGPETPeL12sG4PqIfmhi/1F93
D7LI1PUux6FqkrJ0U33dxzgLewH5GP5RgazvvTSW254olrYguaof+6VTAJkRehmuKbqXKlDmVYP/
tJjbpbr4jvALEQqY0Pu0hbL1eCB77Cwh32dzy+//kaGSEPFlw9d6yYIBXR2+B8c2KYhaHN79LsOK
HT2qWBvBp26TG/BOhdqLyX+eM4sWsMOqQEnMApXz2cw8lTz3jmVyPBkG4lg23u2TidmQn1ULra/P
M326Flv4Yl+nXxJj99XYgLfHuJrVkHM5UOFKvY7FNlTlNSy2AjKhLiCIYKnWZRBcOnQPVy4K39hV
oGGjLGCz8b7dE4piMbMXxEIgk6To+o5VHeqELemfsciscKaKE1W96T2IrBr76iSo1K0f9Gj2KR50
zLDt6q3yy2lCqXqNtc1h8NIBjiy4tvkQfaNZ+ar5/imLPoGI751nGa1dsUpYKDf4GOCQIqUqGueq
Jyvh+wEohtUJ2fMNajlk6qP59/wyTq8GASRV842EIc3avy+UbhHSUB0QXvHgHQl+jRqzpX6Qg10Y
gYA4D2QRcb0vC6CrG14FzJLdQuGwJ9X0xQnlfU8mMBzx3Yh0zfkKILfbhvFw3dNgSWhWlsHvAi66
WTv+5OxbO0c3Vtp9x/cw1lw/0DRm/VPVGQ2IGLMXENuh2w+OJd1VhGIj+B6yDMnbHNcomC79qNWY
X7PSnS0J7gQ/Z9XmO/ohiy5QE+CLlvA0z2i5MF79yd4BOzDnBLZiTsoB5WukSNFuzX7DgSTpN63t
r7FMhvGWyeZWzGLxNLl1sTL7DVP6IBK8xNaoNEbVLMtdOrz+LNnDz0RWedlkGSZ0Ud8+zlImSnnT
37Ccy3yUMc2g6sBYKcOACd3JPPbKpGSk6xb3QE6tUeeogM+fzeXCaQklFddWJvOxwiwyfmeIlfC3
Rlhi6hnuxeKIZUU0DmlqZEoKjxMW8nNjhIy+gKEdZWFc/Sv8qB0ua322apuaGLe1qjQ+LmJhdE9m
7aSCt/j2InTcTtJCnkEpCaLVXgBPDjS/O7326eRsn/h0khBZ99fHzU9UO5Irj6PPiCuVdhz/XOc8
jP/bZeypH5vLzH8DHa/yHRcxC/h2W6C6Cc1yNCdH9HOVJzViT7ohs1l6IqQDmwuldu+0PyRxpE9Y
tVzjY7vmEz6HJsYmtZiWQ96ykCStStLw9aRGkBjHS9rshwH3w5JZ9icgVCtZnPMhLQNxes+mIew6
xEn7SJQRtg6kA/J7HCcyeM8t7sGFaksXs3QoHdtQFqwknM4kJ08gBaD8i8wpGCrgD5+NureTQDvp
sx9bQE8W7Azgdqe3JrTyXhbVx3l4SWFCZp+Q7JWEaI5Dbcab723awDiKA+shVoGmym==