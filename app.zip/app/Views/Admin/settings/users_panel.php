<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw8rUTdGfK4VhUdi+bcIKIzxi7VdXll5SF58Yv8g1vhEFvRqZTRpGVQ6KW7SDKTQZ4g+LhFi
EuTLGApD7h46ydCqsz626DvPov3j4xrch1t7Xl/AOIcOKLP121byxHLducPBh6zIAsi/iZLQP0Wl
uKFRTzHQgYdadrZhHJGujvp7imxLDxT8MveR0r/C2PbTV7uvCIT5SeRxVzomRMt+Ozij0vcXbTfa
grxFbISYUDJ1+HvnHLrBMaL3q21sq5dgeSbm3k7UZjZMzb/+NHsfPTbDxu60Q/hKteb6avyjuyFv
ME7kRDXWaYHg/WhqDlIka/9DZ4Zi+xrrOjAS6F4jcl5io6xjYfGGN+7y1kgzMmvLnQfiacX+W2CL
mM+b4kv7U9qv0KdUdNH8Dp+GXGXw+9hqm1+9eFZfKt40vwRUWVQpaEYHX3t2AX8I67rzZlVqM4MD
VLeu1LHzV+VNfLBNatctJPzRNfyortb9cgP+mriZNbKKRkL215sHL+Sp0HbxyJScP9DESaJHb+Br
g9STPNLLJF8uqWyNzrh09uGt5DkP+liUslmHTNfIKdQGpqTswmukC8+2HsGcvAkhDxACC3ucH1Ou
z2XWZfB+w8YWsqfEO7Kznruhr95a1W5XpwTwTDfYgRe10ALPRkScWb17D5ekz+XEHqy45xZe8DF2
smXmoz0mDcP9a5y+/HuBoODbo7NhjoHp8hfm/4oA+Pr6FPkd/mIVi/43Hwlyuwjt1YbrS1usa9rm
Xg7w3VRLe4H0s7eX5C4qLZh0STbC3ygY8jJR5yX3A9BfcIGsaCAvIzcnZ3Lt50s79Vy7SinjEHZj
PW/lpRvo4/UrBYhJEn8r9vh9f4T72QEDBDzOTCk3zVFkNoJybqCCXCy0T+D/Lvftj5BZYCxZ9sdt
mdGOpb1gUw2zjUOMeK9T0IsEpJ02WL7mHVpm/KMRI0VDGGOcMN+hYdAsEQ3NftYCBx1iBUA5yaNj
BB/SDi3WECtx01V/KjJEQs41hfX7lk5+HUwM2fQBt9NQsb6kXQev00Y1GlNCCn/buyWRn9gontI6
DGgwR5ReTmKbeoCoM71saytm4Gw/MiRLj8eurEY0IWWx0mPSBc1eN/ow6OwCd58rh3jPR1nFnuaz
h6LpWianexN0XvWfr/8fuIc5CVjpkcEuKI3ia0LLjXPk3PBsRZ+/IJr0+z8A6HuPqBVpdLRC3BTH
LzLwH/73Bnj9JX4xBr/EXa9w4rKWeBMVzuU6K6IdlrbjW4d+gDgXXUnBX3Zvi9B17X9RtB3UkkEL
bkx2TJIcQXOlsEoIjGo4HZQqgkh95vFw5j59WBfZWbPMflFocmFZ87LIpAfHPlXfdJkhd1yI/04x
c7+b3gfRBo9ovq2vLYM+sCwhLxNaDwtvi+AomN/tNLuNmNxfNdBZtDTAEY/Ih24nB0t4w1jT864A
GSzgx0B8Z5mZP78Dw/7uRGNlPKMUC2waijCIcyrJs+oLh9fRkzB9pBwsAN60wXI9J2BFZt9OnQgH
4de3bL4LP9YGApjODI1Sf0plk/Kt39WJ2SRtH1jTalLR3+eu6tWr1fb92ZcmP4FlzvkmCZIFkwUM
u0Y3fV3vPkpy+D1HLTFQPFgk1HW1/YoIY9GCoVTiRW5pOFqn1yLGzSvYLItgm65qZkE3B9ThIZe+
dxYwVfsza3dzxJKQ4GHX/wB9pMiQp/Fh6Oknzb4MhIl8WATilxNmCDODJZu4vUbm/feo4qdzItYY
hjjKA4sQcTUPRiRLk90eG7zpKWcUQCjh6SGxiusz8aTYI77Gq77yUBqJg8DYCt7bp8+fmih24OKk
sKuhAm0Ao8RE7O4gNY61KfkcQeV3uTPO8FaYbiBiUC3OcOVhL9dflMel+pQsEostBCMYO0OpA9jU
5XH5otsSc/tVhGu46ZsV0fd81e/P98untnHFgpUyAaJRFGQGw7xGoAy+o4PJNc5F+44IyipDLbno
wIIafMfSaGxnYBmOxnCVZi8fCmKYayUDO6S1h+nn1d3rw2GhZQbMmHHx/11sNFLR6onfB0sPIAaZ
nC9YghcvcGG6ihMDIshJqCxzNeNLP9EpDtEVkj97Vqm4ZTVVW6cVr3F0g+GLcYEtuRF/+90xwoec
ixqwyLx0v4R/gJBkib5ZudCq5QKNG+CBgK3gZB3w477po40bJbycbSaFyKl02ds86f3HUW8gp9gF
5eLzrnMvVYHeHwgLsSLw2oCpT5k/aiIebDSXXQRW5k9rT5bCkUm5PCmgWGGaKI5IpylZHaltZJcW
tQJS6q6QOjNkH38k5Ql97R1rAdoQ1dMFrYx+vE+/hIfvbpDhH7/9gaX7BnHdqLZ0DlDPCrwhlH8H
MA8s4O+lvduYGzVf20r3zNh3PjojPpwGwI5PAird4wcud1HxkNF1qw0153LHcr3LCW6etFJVyLh4
NYQud0HHpf5eqJNKRfZUMIXrB6khT607DVOoWREH8iAO