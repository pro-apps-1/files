<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtVJHckSWhjCMG/JIAZVVGkmsN8VDf+CSh+uZ2y3zkwpqY6KLQO9FZaj2530JSXPw2ZfzuzN
W7191RQdYUukolniShZIOEEexfuMeRWBXuQLKkQHEef4P8bxr5EJW1bU/+b6uRfZBG6HEwItj7Rm
wQghyTaWxXvsqBZ9UDUOsdjsyLCjh59gYkpThLwd9o1ZZkmXym7rIW4DXRUK2u7EQ5+ulvXUOp+g
pyfGC0qEeYaeEiWWijwyXzHDviPkicEKTGJv7nWRo2Rxs85Hakb8U5GQAtDh1yVLj7jCIKBaQC8z
2taAQJUk2WXbu0Va0nvsqzSiHVBvxed8LnGFm1UFD7Ut50ndcrWLtuQg9vIkZAJhgwRNG1YMiMkh
Vd0sANN3rN7aJdmbkjl0yOY213cJ4CebltBBeKu99GmQceNnupYOnOGw+Cx1Owu6/yuC6Ofl073j
vZzlCiFnlM3BrMqpjiUohZ1vEqBIAPtulldBer/imANCPUIrirzFtvy4XlX2Hz80P1ukYQIXZ9rg
5FXiVishoNZxBOyMNZAILCORLlbAMqB2GGBl0q4SEFpp6D/0XImnv5F5ftRmrS1DAltiookjW3e0
90WeXKHAjR7yeMlhbWH+TSWEOIIdsefVzF4K99+xeRwMQ8AcXK/SN6+RzDLKKnfq8PHVqsn2EsUk
USIE/Vyna+c6LZeekWVYoGBbCdT55VmGeK319Mz9KVeRQVud3jpO0lFmSqFguxXvhpXfcWEhWNAp
+MFcYkoOvYfbL1lmadbtbcA5n4gci6Ttsc1hTLkjzYu5ebdn0vAzfU0NFo+UGyGJsQYw+ochqRxr
0H2Ar43W9qMEBg3yEIGx2mU0r80S9HXAQjbYwG7DQ7VNEPKP/IJ3H/7ORKAqr/DsCBHVvmIrYEhu
uPGcEfT8VtAcVpeIjtoRt59MGG9TDvuIVSS/OhFBi8ydQIBDk1gd8d0sVBi7nW9xubMkXK2TwuQc
aBQbxZFrPOEn7IvyUF/5dMAOoGhnIE4a83zpMg6YyBQ/T2sQOr0szSVGdhQrR8NiPWBSdbsyj+cL
rY6WavgyFqzp3yykV2zTYX09y+zaP4Zmh+fOajxEkqRNhzzOQtb8mzJomdvNcCTiGH62pyJOyb85
PDHBckvHYdzOla6DnumwqfOKXdlsx+SnlfTVXEsqXb31/2My5936jSr26jw+eDYM4RUftptkHH7D
gg6/o90XXwQVbvV/5hjWrYbYdFedh1mJU3Xe0XSMuYUEIy4udTVdCtIZx262lZRmyUQr171KgHor
bgW7tC7oHKGk9qIZH740GegaqkUsdQ9XgxhqYnFhZR0gl+XhJjHwhxaZLmUNWmeGjsB0GDuLWxJs
/HIKkoEKW/P02I0VNUuXMKqXm9Pmxv/ViF5Lf/w4SrFlGJWPedRKMlqowyFN68X74PoT/sKuSNU3
T/tHDlgbz2i+jC8D1YAWMuDhEXq0h3ALP7zNrUGfH3V8rgomYYO846hMAQEIdPkXj9fAR2Xqm2+l
eZq/iC68wtTwOM6QgYKu54KNrDqLYC/EiJFK9ps4ZDGcXG9XZEWu51oah0whU8HN/qgW84sWVbMn
wOnVc4zZ2wTtW0Rz6xFre0z2WmK/Fq32Sud8trXToM0Iy4WC5/L9p0ktaUcPtiTXO3YuxjKNMqVS
r9r9rcIBUJh0qg9y3ES69lQ+yJvmoe3QyeZ/rXbT3iRA8hXZVmZgvz1o8rR++YGd0U0fzp9PpLFH
3y+MxMWh3ZIuCH48MA88fdHFLCY1nouhmh/Qvq9w2DAVE7ek/MJpvZ3XjwwduSgBiBhBDcb9rNbr
7AZb037daBT0cOTveMsRU2gy0eFraAgRPlwDYVkiXy1k/MnRfH6Jh+Bl94bqUcKPMyVLkSkZQVgD
wYIHReLzhdjuwCFTXnX4sgAwCwEp1wLnwKoDP21NsO+kgk+fwyVoeRek2UqYjBN8Vt5gGyUyyTXD
NkrJ65soJsMgYpdbpp8U2FuXW7Y9cSSMb2Ka5tlP9Of6UYoRdVys9AXm/y+5fuV+ujDOE/Tq/EOP
bzNj5mp7aa+tWchWJAvWmUgNrvZNaTSKoB8Eq9UEAhyfU3UCKW1iKbUh3MHzNhrnSvWCZYdY31N7
osCsggk1VXZ/dZL5Deg37D6JHd5uP1IUukSDKzKhzEQKajptNt/8xpA4Dw09IkDvcX03muNgPF1O
Btdgr5KZyJdIcb8GUxFyUkIeqCXypRoz9zjAeghf55rwQs2+uIbrLCRbjSofMGqXqz+zjyOZ9RBj
J4hQKS1YKrfNbwbWFahMSrheIVjGFnDZQ9uMBAgRe/B3oE5BN0y4hSbU2Tz2vVNQq9RYobskb3KG
8r+pPUdOCQLbluzU1dmQnsvhi5qRcQJXGteK0VOfJOR26OZZaET20xsiY657NtG2lti9OSJfGV1K
Q7ExEbbelCbWGiusnGJqwohTBVsuwfixpsg8MTj+WnlsSBWni76Y2SE95sv7BoFHkWF9OOYJ907S
4B+/XqvFtG==