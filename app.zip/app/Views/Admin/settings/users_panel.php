<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn87uo1NjzSNBjjs0mr9Dn4KL8YuIx0s1EzKUFc2EG8XaCZQZW6iB+sVeRj/3hlC7mYFY/G8
borzu0Zkv2D7BjK1azZznmNDbkJ+WW781aS0z3P/0OmJYVrKgAtkFsa5jy6wjHpCSvrAMqKf33MI
ymyJ03NHqRYuhpssnq7iamo8K/lx4SzbVQs8Q81KihcG3H4vJj/voGY7Tder5gRRidPPaP4zZoik
Y2ss6XAdInd7V8171k4uR3y70fRYnUgWO77sPptnNdmqLogZkL5iG83POWvYVM5TFLtcgDv6QRAd
xOFIE17i40F6RtRfwsh9WhztawkCYYL+O7FuLvh9xU7CriZ143FoguheyxTFjmHvLKs6/yTZbLmZ
9mZKwSxsej2H2OggGX+vuQ1RvdzE9XhUf041/5SjHrjkr1+1U/YpwRRqaelDhsUIKF1HHRPD6oFH
Aki+ZSxtKdF7CFlz9Cn2O2slUjyCsFt1dHnl9k3WniTZWMVdIw6K5ekr8xzAXyp9Kozf+mJdrAb+
xDvoK0nmsEUEwNH3PzVzFtbpBH6FnDzQZuy8M/b4Kanxx/BIgSrb2M0SFPK0lyxk3e/OVSSIcO8L
YZQmX2Ds1myCb2OOheQHDYeIX1oZxn7H1QGO2K/w7YwG1of1D2pLwNvhV0vQ6EA8RKviBB2cRfi1
wh/WDRrIyrC5Ic7lqzjTgfgNPPRQm9h+tfHvKN8t2BNHJH74A3vhJuHKMO3r8l8C633i84jDua+0
NAMc7e1kOBPyi5lRpaLtze7rGmwCop8JTObI2yzA3TQ0S5nvaOfZj/FzucoznqpZKDyH/KG+fID7
JFPJDqqcADfQGxr5XE2Y++LJi1KfMo8j/yTHwKEHMdPVArSj8zUQmQzlpsnOI+xOdK4gOsjfHkfW
5t+yiPsI4VntuMmDjkHQbqFG0QDuH+iTLLgKJycuB8FnvpvJNcQVsxss25AZKdI9uKJKzjlhy78C
0SAPMT7YKMEqKmakbTWw5pWLJkZynS2jD3AWlTLH5w9DJRKxaWikcbyZvw43CRvQu6cYqU6dToCe
5wajObEMnfleOjHYpsEWpgZHJF4uXcPV1ES5zwUUnawAMumBmZb+zmOz8sCZVc+Y5SeesHNrvk1P
nRgFTlTrtfXOc68v22LQFmx+5satVb5EsK4GdJ/4kfUdUg5aDISR9AIIvoeojt26MR55kVau45+i
UNntIKCwZXn0zkOWosFRxe7mPnY1c1T3N1doC5tbk2FkTAM8/7nCrFddrFZBvA+Wl4Gl3RBLQOWg
Po26Cfo4kgtLgF7Vz83a1FZQ56b+RxHeUqCPbDcnpdGis1TGcq17xL1q93GtooIBcZ95NhWI3AwI
fIniamcMIiatMJHWd+K5p7YZPdU5Zfm48bFer6HL0d4VASJedtFvuAQsqxKBPkPnp20N96z70kgm
RfXMsmc0l0G2v924O6ptxX4u/DSl4uG/ObObwDSw/aUaxVOJdoiD2izBeEaEoEg1vC4pJymRx7eR
ZhIa+U+WdG3vV3TZn7elIeIPP7CZlcPT8wKuUHAL7P//VIc94XVtfgo+DIhcekE2X7jr5WRfaydB
NT+h5td7gGwMsgxIqEbzW1/Bi67YYf4XhZU7S0KX05OvsXJOgExrpa9Y1eT0UB01MivMOG3urV7m
gFSjxZg/BGDmY1z0GpVMsKpCq5py7V/7Llv7e0Zn+ZiAVfMr9aJhevokeaRjLifH+s/0ZsGqrgYj
/8pOzAprtxACzXBPN8Sus8uK6sRc2jk3fLsjMi8vZFj9zZjk/ySC4WiqcX7YVM7iUBIoudRNCtyp
nYVUSl+CNaLAeIvD9CS6sUnOdCDig8GT0lkNpK5CW5Sco5qidLh/fS1ned93eYmoXH29LrGUu9QV
X5uE/o/CN4G+m9LqQn3Soc7jp8eJxc7XjbhKEarEW+OmWTmdu6lsx5NegAwRHfi7IdDZy/9wzGJj
ViFqKsSD56RTruzJ/D3ME+L2bNWDHzCWQKIRmMRmZm1As9JT0xJqC+jTZRVGSyXRNKHBeyEZcH54
e4vKH9eCTSIlVHQED7DiBoR+jBHidRADzPj7ZbQtGaFgj8LIIXfLFr+rhh0J2jInhr1sgzj+Q9p/
lxynyAksjOJVpHow7wiHhY8ETzj7a/J4Aa0SK4rM6XXaAOUYmXq8UO6vehdx9XBvjlBl7GQ5SXp+
Xz3545Lo543LsF++5dUBJkh6sNoJ865ehFWDpELcJJqp1CJ+GuDFe+cMuTUB86XRrvJ5mRulQmqg
B8b/l/bOq/9AHIwQOjir4YCjYu9ZdmIj/q6PFWMRLnDBTj+1CvxC5clLfTlZti1XnyhidLE5gFiW
QtIJnOQyG/dtDPygP7aOu0TkZT9PC19jP71BNxxlKuTtESwzgJ47Dp2Fdv9XUJq1psafBWLxYgLk
1V4VXtOehLL8GQyEaH6jFymGz3eANcKiAwqih0+2hn6MT1mHsbbygWamthhwi6Kpt9S=