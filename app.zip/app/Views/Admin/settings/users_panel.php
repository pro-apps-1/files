<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuww9cpwE9j3WsQpJ/b2Qr6LoL/1sY/05ibMMFW8W4e1YEq7r32tjLJaB0UQ9b1baXg5sVhC
Yy8aHJt5uLdW7mKpr0iPF+9aq0i46Kf1PlOnMUq2R1yCkMrfG5ef30CSpKQhaE1LlMHWsPK6OH4A
AFYiOTRZAd8ntIvbtj3DubYtaX0WhtRkUnbvatrEvhlf8+b1T/6CRQtKzo+UgL4LLRnpwO9dZfwH
Td41Rx8nfbr4lw10+PEnldhvhxZ509PxPbQJ/83yFzgvkwkOjFcu9tAV5diSQEyhFY6iddpaOkeh
owZ7Al+KDvJmB5JZEsX5VoQx6+9GYs7IRIBCJ40li9yGHCKYd/l74/NiUkj/UtDRpy/DIaijKI+Y
J4nUyKyays1qvC248pTW716gTltuNRxF+E1JMf8LYLVN3XePm5cId5AePJrYKTqcz9HHuNam2MfH
dRlpTqBEYLq8YnX/1X0nBAB/bv24AFeKsKZx00MvwUWQJdO0tdu9EQ/0Q0R0KomCWU508lSUoztH
sPQcJ5+0Tzm86garNV6bgRLKtHVcsltcHRONhKZd9l5cM6aahHLlZdkL5HVCmgVKvSW3oh02ouTW
RKsvuTR/m8enXkvYAd3DTdeTqc9xbmdkGZOjUtTpdony/mx5InU7wQ4a7PANjOT1q46Z5P7DMJ24
YBI7Jv/AMh+jOrFn3q4te2DzaBz/Lo+cKgOR9Nnwkz60ztWUehcVG0ypSuYFD5MDWaHF7puzWAeH
LdFHt8PfMvim2aeUdf2AhBSXcX/jziOz2Npf2LDaSPh4veMsZuLTvDFGZ0yLPoIy/Vz7tn9n/bry
Ws0GYUdlzMZzEtGxSr1fpZ3HrkYOxaA+Yocx3zXRQLMtXe6GtjqBX5iztLDfDitQhQtf8zo/Ve+M
hbu/S1ZYwtOF9zF6SQDzVqFiWxJjSaAKEvB9ol4d6QOPtjOjx8kFf7XWdTqsVsLZYiT+4svI7Y0T
cYTwX0l/aVlsBm0srDEkVPzs3QkdTjyzqtc8NmjLU/D2vcBKHb2nQeoNJlVhbPSSOlw6zddeTpRm
91cwVd+ztkTP0YQY9q+20DMVSui/MOEzo0TNP4FaslX3KV+tBKFEggNf0a/EzRX43B9HsZI9NJ93
8OPcejx4h3NSJHpXvy2v7/JkGxfklb9yBA69SU0mQXwKgPmDiZHPrXT5aPS5OXZIQ+91cXQH+rLU
woTy9T0guhE3fXn5yoNXsjFa/M/yvMp+fxg+u20JFaN1xaJCrs5epUEihPzytvGn+OfahI2XR/Dc
Ql1EQwOYiAS5hOXbd4yJIpV7GCSjJWFrKplNmjWhZoI3N162KgE3qS/Glnd2PFXS0YOnUfnMV58G
hCZ3iRwrCnrcglaMWKJFB/DjnFxznTCGi/JbMFua9vvDRXlUmCeCXUNt9W3YVtAbtB2NZQgGOaki
RGAcmjvyiY5ww6//E5UIp3sBWKKOAqb9d916clsTw1HMDTckxNN/1nfzO6oggQ1FAsPdk3eVmZ8R
g8F4pBaf3BPz7bmZRSpZqlnSaU0sOuyAysoFamHlO+u3ZQEQwsqTB45wohQ/MpSpr0FbRR9Zuxfo
cdFfTb0qhZNebVphUir8CtVdPiAEnRetyf0qCL86msqFkIQv6g3Tt+eR3mSuGCezMhcuHR4TzLLi
bHq5+BCQEdZqXl5t/sFpR5/nlWvsNJ9VBbL9dh+UTSvDGPY8ahjb6RuEzrEKamOEYkWXGmdXvlMv
OLzZ/Az/5SULyGVlNRa0KXDYvAUFeG/WyeoKMAPlWRBaur9w8yPrshhww+IWWz5TtBGW9NWDAImr
W6zQ3CC5fCES/GoH1Vnm1w5pn1XUt2nQ4875zC9cldVbAy+bFjYyRSozqPvMb3MEXZzE+w6i7rVn
aCGSukBeBxhh7VAxt75LhB35PLjE7yhShtZzZ3vcVvvXvGRk5uCTHxcBFp6mklhYPyc9xhL4E2nX
NoOYEdLYmgz9MtMGl0QqsFDq2r9AGd8PKqz/7b8E385rtVKTaE4v+o///kpiLpJCsxmJYhvhce5a
5Yw29K455QLRUf6yHSKTrRB/x4klri0r0q2wz30FsTjj3KP/hnd38Bp6suV+0PIr9jXJfS5LADEG
QG6ustHTRt1HaygSxfhwhSBxt2nJr5cum/Ydb4rPNQku0iEAJkOU4VJdG0meeOjF6Ndq6m/zBCnC
0+nWuA7gzg5vjp0U4FZHKHprWWQyt3t8wb4qOhGrNfPlGkOQBKicI3/aLtGOfWmljxg8G1LfcfrZ
V8M/DlACGG1Hil5+J/+6qr5UH0N7CXPgI79BgqRJXDCCLD052CjNllTXkVhO/HfgDQuWPW9H+Qja
EqeftI27ADIR8ql39K0kpzYkIMjCDCDNtOGKrpJVrWxOAiXQuVG65nRRXHVUaeQS6PO76I21qkGv
8uWGyU1qsN1CewvfwLfHux5QhiWpXQ861S5cExzHifGnd78=