<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvkmDl+Qt2QBCvbienysVg0Ut36KXfpKyVCjdv+wEh0JIIkB3o+LfsVicj/i3XZwvZqo8ZOM
BIteZMjYRREgdMHT6XwO3wKQkef8wLeUoDj7WovjSzPUojqAcg+r1HbVSpgLdpG04BQdxcVLv94T
jynPfCre6Xte1aF3E/LlDGONDzARd4Ex70ZupR8A1f7wItPwixGradevig4TwVCEWrJADDgQ8hl7
jxmlcFRav6Nbbts9VRCO08BkAWxH4FbbmgtXs2VXb4oTzhmv2BwKJROdXxvKQCegv+j0O92SZ/oE
yyde52PRWRORO4Vjhs9HCsz+CSLg294CLPTLdTMebU++Uv7IcfPE2aYEBvJPKjXUJ+piZPqY+adQ
mWGR6t8KclSP808szEIzaWJfLgGE8QS6IRrYL9ETEkBhuzjiKXwJZ0UlYu+SJRf4TMDZ6ngUYmbF
oolFDICWu3Qzi37TvrWq/UnvxTVlyETNMU8Bl1U3VTlw7pkK67Mmgir1J1GR60fX4o/U4h531jZJ
AU1woqLCjvzSudOjcUaolVgQEcE8a1Xdz2XaRlsl5mQ9+cOC7LVxNJCcPJYSGF15u11+WVjjr1kn
Hznd6C+dxUS2BUbiGEsiUfjj+5WR9MFJA9PkJ2Oh66x8my8F/x8tAfH303Je4CxSiB1EBP1L54YB
hGp6J1gWee2SfSj7RXlaBhucAdEeNRg1AgJProhq2w5wfdY6+xmhsv5jK1iKCwir+rI22/CrDAfy
/cgS7hD7pGcFSxtHz6g4VLCHtRQFaVfBI4tSxKVAaBPbseZ9Wj3UASOCyF2nV7m+ukIHmbHICM7K
LNkICeWD2km45ri6LUMo+Vtzq8IjhxKrpQtuCtpu3bF3+GpKIOr/d/MYh6GI6DVmvcBXlMfchuPa
ynvRqeM90YLfnx+MsHTktz1mpCQboMb3OYLfXM7Agleop/xYUCa9KVLwJS8oYCG5cWjUCkg6wPp3
Ram83VCOk2KafR4g8LgrAOJIkfNT4G+/H+7vLmAZThBYP6IJOldAwm6MU2kvXSKMsl/rlSGFwPFY
BBdZMOHpKwLCAxvcj+uQiLfO08k7muafCW02M0cTajuuA0x3JokUsxNSjIJCeTOd3cmtfWyvIj45
31fCVEO2r63IyfNMDZMsI3CERuPDGSXtavqeJpk+cJbMFfY4g9FdxmsWqFnEEosn1Sia1uMczb70
3d7sjgZs4VGFkQZ+pKB3QGJ+o7d43i0VVC/rYhj58D4i8lr8rMawoFun+L4u75JS/IaLWU/sk3NB
d8/xCj/PUsDz2gZ8GCYkV76/fniU0x+Kwy7D6toPjLBs4MpGOq+U6F/sT9Fo9R6PlF32p2UwZ39Q
XHuazuEaF+1HH876KWb1AaeN+qmI8spHFLhQfgG1dPFtLkeKXPd+XIXg9pOk//0w/nAxVRHi8DX1
e5FlPSROjUhZCNQVC+ZM/TYCwPMm1o0ncXyATAh4LG3EKeC92Ovig2+GNvzKvleeyyx21QbzGiwR
42EDcfaE5unt8tCtoILGmkK/SWFl1Gccqs4HQP7qZAs0AbyR4pvMuoj31WwiebTxAZLEZYhzWMuG
AjKvT6Cqj3tl3xeRsDRQ/LJEeuIqNT++W30uQ4QnUqkOM//su9dg8+vPHTHyCQSYC3gzh+2CUe9o
XZE5z3BGFVCDg19L/+ftWT315FVm3DlqvqM5Pt5uyy8e5wtLBTA5VuYHjmg4KINnuH7eZbeOejMc
0hmdYsZZJyGGEG8UDlXVoXdAUV7Jw5gfl65Fxb1xhFbnhX/wCMQJIlOa80BOm1ScG2JBng4ggR+U
tb4gRF1tHvWqLlwMBLfqeAfhOJxqaXZRCntHdN6AyVUvxoGBCJsZam3PD5Ydhm9X89S7ot0LdLEM
YwN2TilZLRawsPZ49zbvHf45NLHRBC0pQp3Atue0M369+p0+WXAKrjPwzI2AVEbN4RlJ0hFKfAou
pebrN96XMKlDZdGpmjWVRjuRXSnqqvtk2edo90Q2vWFxk6H5exYyfYD93XquD/lqicvrxE/aBMIn
dlUMy5f1JV/zXMj3Qyw+wzb4B2NmsFkqbhEHmZlwqBB+0Mis4NZ9kU5NBUVf4xYTR3UEjajdRF//
wuCnJxNtMdKJcnMzteyxWX1PFPyC5cctSEHtCscT8L/2ND5gBwLD3CaXMmKzl2G2en4t/NTQaY2U
nVW4zkUEPIdYdr8/y7bob7F3B7bnqjW6JZ5X/rI/BbEs10v3zM8E9dizDCQ1KCWknUiBac6SHx5A
9EPM0gY6CkiWGe1EIbY5WRK9U6F9EvY8cbEafkv02x9JyX/NGxRsXQMxWx7fe1QrrnbpdwkuO72r
+luNohFQu9RxHE/BCUl3MHAJH7AJlADO3B0EWcYaUbvnJz6PvpivNETaNvGD3j9bwCkXjtr8YYCa
SkuAzWWva7iiNIwlBpz5l4cKcXFIO71T8w0s09VzbulQbRhbianWiJWmDiG=