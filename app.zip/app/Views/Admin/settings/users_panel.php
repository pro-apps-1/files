<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrLECrkE3uYSLvAcU7ZCWMrMkn0Uf9O5JTiDE1fDZYkfkYDMQ3lOyEPcDXTVnh3bKkCthtwV
LFjSSITJn79hZQfyCZHGVHXfq7w0u5R5D1L67+PdEIKNBwdSpLq4ghfXcXJzblOYY8DRh567PZ9p
0myasdkgZcAdq4B41hsVeYsXU+UlccMDSdYBtiKuH+/ph4EvjsK0HtDpbfwL/wNd4TEn3z5GFmgs
N8yGfHSCcgzM3G774+8twkCKNWwn9IIEigGbItzoe6AR6gDy+lCcHhyVEzcaB6CqglHHMhikgRE9
D7Phe5qIWO4sSvY90a846DCWKX8XjVx/dKywxEGEdV+4OR/btjZP2LnuXoQmbUiI/rXoR+AzUgu8
RgdmyoFI5KrPR+tBo1fZwHJiqzNh3RUhcAJHJUL1UvxVzI5GhhrYypSt2lfAtdJKOxTZ16ZbkVAA
acrJePaVOdlSjVw4jDbDCIRtY/7IPHLq+hcRE4dFT4ZtAfAmNqIl4z39wNWGZ0JkASJJtRIazZRN
GyamOoiz7G4XznBOe8LosshBfgZVDSWhejgP8V6Kf2mTCmCQyl1i4nRkgwNEEXuNHOOs+TUzHxGM
hz7t9k4mNDV+Rr993JROr8KuNwqBvraYR/OVKyHgDb3//2zZClyfW1EoiWPcMg550t73uZLIM+YJ
0yUk2Mrk89Zm2mph26EPZ0Dtv3a4Vg/ji2ASSV4D3CkGJGrphqCsWd3TaRQWN+5UoTNaYjyIWGyA
4sG/G3ENwEMfXeMoYP7pJgxAOMAF+OMfo7CW7MGngOUd7NnIjKlGunMVepPK4bllMvARxB3AYlty
PYaF9mnQQSKu+eS4FeoiYxt6P1raoIo8E/hI7QsKY//qUVcnybKhiMm5pXHirMWTV3ipcxgDz7F9
LPSJhKqftyVjXtnEP864UH5RXn/aRVRdgc8dKbJyS4otVrU34GL0lwAk+1mxeT4n2U4izDYFs1XQ
krYnI5Z0AnyHq6Fe2l+NmNOVrY2a8aOBcRPfUXZ46IHjIDkzq7KdRcPMIGHyRqGID4cfWxDAQ8Dw
DfpobC74vFZcx/6CWmwzlbi9MyAs5QSuhEch5CPY8OuDkj0ooZA8SsYxviDq/FWBAWKKQs7S5+Bq
Q8o08W3bmV+bUpb243vBj6pCIkZHQqym436Wl5FsM44crf8+pN5MUedE9J18ZDCqgNVure+tujdZ
4hF+MsjKidoqYSawJtgEpJwShr9fBHx9/aZId/xLYyXYZUSwpEEHVVi42kaVWBUHsLikMPvMEk/U
jbP+my8EPJiEFWFHDP3+Ec2IMhrlmZXwJjKUZc1l3kNSnn/03rkw6YcOctyUqG1akZ+ovpDOUxL2
G93Bd1ZSYOLpiD4nCxEpWaae8lQiuPDF7SWdlGx+GAupt6rmkm44GbYJ2pLTERLZaCGW43rtIReI
PKp/CKRHjoVp/Bd8dFqzys3lscuQf9vnMBJGeEfs4lCBKrpjuJy3IUWpWhwrZb6cpZhlOrKOH2Rj
SjgJd/udICd3hZkQ/HmTxVHs9FTiiNc952W4Osjmg8YZU66YX0hAThyIWU698sxm4NnpNVuvqABU
tS9aBWsNsWiMk1j0b1fOMiO/gBkQkhoULUovI9t51fVK4tJ+zV964FfHiPIWIEakHDhkeJIqhRcL
/Sdtqw0nTrP1kW1qU6fNnY8i7l/AfqZBmLLpR9RlDBz/9sq1GD8Br3Q8BxM9hLEJbpNPGinx8Zio
9z52X7jxy9fsNG+57ck5rfS8vCEcGQJHdPHKH+XMDRKXeGxGsS5PhiI90BWCrh/Q2kYxD+kurdGW
JXki6W40zvj2sse0lcGz4t7CO1zCXeMRz4p7P0rOuz0ZQq9w0+Pad9+LCQM/3W9AAvlrEY8VEQrU
LwAgMZFz1ZzTAZq87rGtxjXUcZs5wueuZJTerd7SnooeezytlPI3Vv91Lj/M2qMl8iEE5rJUSKkn
KeKNjEWKewT3NLak/WqV//bhV93S5GNs631/cPRa5tPXWX5cBSSEfqeooSLGqVXP/r/2t6OIuWYq
b4/s2XJVxfob+M0cjblwWXedCdN8figm+PfSO253vtafkLy0zC8YtN5UQK/YwnzrfyrrqbtgMY0R
0knQiQiW5qJnfTB4/A+q5IzGtk2baiGiv5E3IQc+QMea4R/OSOt7nmv/fmNXE/w74nD1ksMCfOun
e+3f1JN05g9dRutG64W8a8PWCxk/wbLn/kBBmXodSVLRiq5DAN2HmTKtqkxVQTWQIbGO8mNGaPe+
YPkOPM1AteOlSLHbXdAF3YcUYDcrcl7PgstkNfqmrmTfdZ162CxlwQpvBobm4s0ktns32b20lpDq
ZA2HX/4egJabpdOrmF6g9aNroMPBTbNJuwy4LDI4X02LLmmvraiAxbZMAe/1IKEXEeEiKSEquUKu
idXywS9A6OdH4N0BGTzVNuzjSxKPV5e86WOKqguHVztL/gYcMILglZqim+K=