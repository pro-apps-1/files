<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsbCXbQy3NkPkP4JTIwCapBEHyLDdAY2Hye/hW6GNzB6qzZYeO6oMVMuotqDXwtnuzOt7sqX
Ui538T4Cn8/lNh/g9q2Q4E6RDZ+TVGM9lexuBIgEBm9Bvd9ol7Wt4bHlTfZDOhbGFIFVx70Fzk8R
0kuhON1Wo1F0q0TDg/CUq0zLDTTRfNYAsnnqu53JCDSl4jEcI9PjaFp3CPZN8cippz8PZHas/cFS
N1Sh0H5JAFTL25BOEXILZWXAv2JHpFNlXNrgPRKuzappfhx/q50CX8kf8cLzPySZO33+lAeQasAk
PMWtDei5ccWxGDEwMGqRQQ0ht2mLmmtwK3AyH1gfQ6lcWeaaH0aS1iDCSwARHp0BAW11PkzvnUNf
YXCTTYz0uyTF6P1zK3+Cz8j9gwYFlZMTt1UvqLYD4SDnm3DSMCFRgJekocaOvc/lNCJ+xMgROHxT
uopCt8I8QBCFpgDi5agTUSzQxc5GxBJMZzl3KstgbaXOSWxCnFeaC3kn4Vrkt60FGQZ1H0K27c80
Ff5NU337JQAtYDGsdMDiwKKLp05GghD+DsDjtbVfEktkJmxYmYBUtBLKw/Wk4sX7eqcMwOt+BVqK
pQ7ivylbX9ak7bX3mjMwmQs3RlJHK+r5RuZlqs9jFfAghfW3I136UiPe0lVmH32NWV8QAmqCYAeP
SqSom1/4IE95gZBAEUvQv8HHyH5SPvmp+PJWXRZUiTUhtwq+NUtoahy5P2cDk+0qmjtIJXuKLHa2
mImYR1bstdHTtvAbuwg+o1kmDnUgAVL/GrpBr7gQ9h/Q3eEgwCM9zmo4NHZvIhwWMDpM9H1mOZNM
5SQPhHCvcqI920DhVCCfOQgIXE507WREwGvKA57r9Nn9M5LDRrvjdPiZ7Xvc4/7pu/DYIaScAWFM
B5KUQ1RQaxaqG3RorIGi3YTOCTnYg7NQ5zkVthgsjCj9l9oC/jDhObt45JqeBV48JzQD7+m3JX8I
SevjAOI8EfvmWG8Xu57feqOHABiKMGUOmHQLAiLfwbhetwEtZYTSqEdwFiKnTTXAH9Iq0cRuM6RZ
WNkHhp/MQlv7X8JKCK+x0zgSwU44UYWmQKmB76fq+veeNj6fnt/DNEnBw6ErS1sPMpuvhqTg55Vr
LuhroXXE6nB5VudDn1f6l6xAhIMxE9dq7Pg6FnRwC6mhEYsq9vJvxRBqgIUgcZXMtejXI80P2jud
Y+oqlJfqj4YRZObITjAOoPGG17VXe5RC4GfKTVLePHqHDw5s663mN6qg4tVzctMuTTOpgqWrNKTD
QqoVkzSCCY/aWcF5SCbRjGJUsvvzrdJCg2KLCuGMZZhg4lrXYtK7NIsii8o91pFmIK5cuanL0EP7
wbaRfygOzFsRORWobru5DZGrumFXu2NGmSoPkqZWAQeQOfncp+iOukujxTd1dRyjJGV7gwBtNla7
q68/2bMomuVn8YxKAun9gFUXet4ZDo7ypVLY5qGzHEoaPebWniesWGGIWGN5ziPWaTbQszrH5YrW
Ep2er95eTcxrKtjVMOB9v6wqb9NE9t9RrfLj8IHceVPNZbBeXhWwvGTYaBriFstNEQpAR9fbQWOI
iQ0cBKBvOYDvoWVgfxGKlIkEOcuBaPMgc4kqt0J8f9fOcX6l+SLEUMdfyBe4ujfOmMp7HPGQlpDT
PP9+SXPC8wNWTkOkIBgu0SmBHk1quy9yC5M2MWkwdSBBPC8jG82Mu9e49k7A+a6n1EpDkgemqdyw
CNjDRWAXPSc5yuKEPtuYDmPAcvJ8UD5OBUT0gBmAaRci1su4BkT+sgrrtpyIcE8mOHspgBtU6Zec
JrcKaFoHb9LiRHtZKQbF0uI29+pBtPbhsQmrBE/XpeUDOMR9DqGAFzqER7y8K4YDDXONk+rsVxmV
dnFgWg7OfpOnwUcXwc6GQ1jyAV4Oz7S/O/Ci3LOIE+I23wui3l2uw1ivsLtLvhjZhxg04AN/KFgq
JkrvFLPVAx6Ku1/hbtiDQuEM8v9X8X+4GBVcha6AWPD7rfdIgStgHTI6fGiH9AGSxRDsAjubmwYa
qMlJJvGGMdMZzs00voOOAwx4YoUMFHZ8ZtUACEaI2/EWDI+RWeYD2pMsNira+aFusLLuBV1XYwuu
VMjQfyK26Eku94UFL6+EYJRe7IEdyX7lug8vR6efWFx9PV13hTHz0f096nYxDTYE0gj9B1OO2NQA
vghT8Pf5YezwYL+RCasBpt/QNkumyCk5xynwXOz7jIHIjOZMJ7IQYbiGpEuCVRiPujysoROwoiEJ
gWtnrnh/y7A6Sbwsm74AN/s8QcUUZn80LO9+vgujhWuFq3IUTpGkHNQHyIe8oayoQ8+VTJWp7tzy
w+V4hyAFejVdHWaXxROf0mpS2tjWBQV9jqjRPfSB3lNnmI75CRjkLpvel/xsjT54nxEk3xiH1Yk5
rp6E2E4BkXiQ9BhupQsKFegCy2pLSEPX11BJSXLbUlOrsKqFXolYP4zKA1NQhiEhnBzuR+mKUYwp
1YVD3m+j+xZWBw+vFzDyURYQBWKmsb5zXBHnptFKiCwgEJZLwm==