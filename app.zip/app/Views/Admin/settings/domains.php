<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo+67+aED+JErrkAoX4Dc1QPU2RRfm2jlg+uRmli503prw1rvU3zTeyctAUgyaIifhGSQXmt
ZSrWJaUejjF1PjEqk9xZMTF4EfDoxl3OB8Rq8x2AxLlH9+G5ZcJJL8wixOpkPjwn5yM8jSeEDuG7
6QTEFfRfjZAsaj4z21qTYlahObJwgCNjH/W1Ra3CwmquOaFFo2vLRDR0huMdIMQONFxHiDzaTdL5
cC3AUr8v+zjMdWaZNZdGb/AHx4tWbGixw6Wo8Rv5Gtg/oOGMaUIvJ7aVDe9k3YQBOXtQVm6Xhy69
zCKu1JB+mqyzc4GL+MoSsFLwMXpGwQOHcVoJn7rnSCSDXkzT3WfZC8JlawnossKb/55lGmFUiWID
V+sgaQUqr+7E2BEggRVbDJtI5rpWgdbeJp1S1hwYKW8UiMumurLxgLQc0K2K8MPfaHMwX8yHo5p7
iSQU+fz7mOKFfZfpnU3xXbU5HVeC7OP+bMXYyTgEk31xUYb9m29Q56XRnKx1YP2s0K551aJHjwhB
QbWTGpYly+Ma4B7suYeYAadYZJO4uWx0KKRL9k4OZhWU1VaGeYIHiSHf31E3X6yHP0gRBIM6jdiM
MALW2D8vraEBoOOJ8VFlJcv05MsKAmivDSJQhCFb7OY8T0b0sa4RtTK9T0mUeLvYUtgZ/G+d09Dl
sM8lHeHRP4TB7qyHkU/DB5MXuGNXnjtbJHnRk9CucJsHo+AFcweY5mAOxecU4Its1gQmJnsxUC13
WRXrrc1NBVPjqSVvPh5I0OxG54sRD3DewDnuBrfgZCb8Q7+HZd4/+6lnZzybqDIi0vvows9FlniN
xPLPqJwxsc91AzrKGbfpaFL39XGgK1C8GTQA/oBQklNft94C3hxvCuYMMB4BaT9zK58XBtqiCq6B
RwrlrgbbpJ707hV2rBotxBgxBBn/l1S6QuafHTxjLW1OtKS/t7y1T8is7osNuNGvqI2MB6Kj7hxS
yK9Pdq2UNnSlboGWozEp6bNgd4m9bhL+rtE9KskChG5CfadiDOjjIEf/juuWeEPu+f3tBoHJ9G3q
UEXV1Clxm4mqvN4FaZEIrF7XroO4PpN8ElQ1KB1QaS8EBt386CJT2BoKllTScb943EZgKuURhyHY
4MPtGOHqA9mxVaCIB9Nqsv5zawgTt4PB0KJZYInmM5op/nqWa4bmJrN0n2PlvztcNwzzJFFqdVC9
0Ii7tLdgHxW5aGDXhq80oDWH9QuI9mEpGl9kSiXD7KGIimNlXxObShRCTeEm34vnDUG59pWkKAv7
4IB8wsqwX/cJRZVgv17ikOzOCFafGZattpLbSFn/Xcx3+NeuAsO0y8AawBuqYKWHAVSRidC25LoE
8l0gU6s41v91zVqKtSUSC66o7+3lWHJzH+V/5sehCLbofNNwOS50MnmL9OINc5NlLhgZ7fPB/WF8
8DHYELwbRwz0TtUbMX2Us1QJqQH+9Sgimv//mLPrJlvLWliZVguma9gmrM2OkhN+qsaBkD3Gzdcs
zoPlj8pR+5OKS8Jc0msEFyfi3Gxv3FeE4WRijKTzue6fT8jKGmSp7bEDcyXIdfNxHhlIyHa0eGTt
vesRUH475gd92P6PLP4ECaHBxumLlamsUBqwMWmxeAWAcpG0HurXRv1byhB/WVqeqtm4lS8TX1/u
dalsrRSRFPrKQOVnl1rULpMOsWLMxd6s/8+CeqDOWtz6RKCTFGnImYVvNuEZdfM22upE35QBm6U/
ALEvWgoTw89b2mXSCq1NDM9efb1TAcJVoP4FjAlLL2jLCj9aNVQmSz4RupWctKuId5gWJqdPgmPb
6FKW6eEI0ARaZEy1d6jks4zlyrPHS/cXirp3NjD+4CCfwjarjvHoUEj5AYg93HFef/F/fY0+ahF/
MmYpZ+ICmXR82uW+YOSI4vucbelRhwTok1LFlr1SgWRg+SSa7/edWwKvi5+TKiRGCiHVdKVuTAcX
IfjMqe6ywtv4Rvhv7h2eWYr56XTHXtemjTlItMbnJUGV3LX18FhN6n50sIi4toJUxKrRDheBDFXK
ygvTHwZoOEjMRAaRStqTbQt+KYXBHf2l1NX1SWpFpPmvUaQ0TFSAgOxj2zjWUH3081RmDr7Teom3
QIqF++SEJnzZlmNchgDBMlX+1ycz1SbzfzQc86ksiXDqxiVYFzhPJLHv0EH2AitcbT1Wyyr8ioDf
73Vvg7+G5Vq43lAUyF+n6Hc4oboczVVTy3XZQ8YTB0AqKCRe46osecUUlvMryfjpnHInHkFX999I
xnA74N1MxKLb4xOagzo4OwYB6RMIOop7qFHa8T2NY2Ma4PRdlkSrHW40GQYPMEMQmepoT5+HewdB
QsA6cx+y/SfoWLnS7djc0P0xAVebeQovAJqLBszr3vupgODENhOvu9ZiHDlGOU0sbhIBTMk9Vlxw
Sk24H7I2yTOmGnyS5k1IkOGwlQTzekfE28woB25rnZCzFqZr/LkQXp7ZeWoJPiKv2xkIgRZxMd94
z7Q38BDr4AV4ChLn3nhjdhoEmNOZnyLcTmoVi1mM9BKKU21zbS1Ghu0Ej/ATIl6RhlM0xcCzroMr
T3sb10==