<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvO33jvjiF8HQDwR/SAR+Ls/lbSz5PLChRou5ALgpx8qVcTOkSkg/QOxy+iJpgce7YqLCIF4
CgdM83FtzMcMQ9TOypjb7pGESm5zfzvhkXfmzCifcHrFXLJ4+A0W6rPCJzAsS0j2RXUbfZECk35f
RBhrFwDOMlX2tSyctUGZUnr5q3zaAJ46YTuiIUS9zLHKCh5GXHa4KZCYHJHS+tSzZip8L7vMgH6V
dnFuoE3dMATmvoWd7r0/Ui7zT5r85iJYRkZ4UUReDWkAy0QnKAh9nAMwMV5cHR2a5wlRWh8A59oh
+dfZWpLa1AcmUf49WaYm4+w1aop7BCZmg9dlhqfOW7tV5t1jg9urM73yqWSbc79ZQyGCYKADEJTq
gnCu7x1qY1t7eJvPYu8ewkZX4ZAvY7AewNLpt2QFsnunRvedC2kS+tD4x46H5EjtJqThWdpw3SJM
koehsKJaOgs/IxdZY2hSCqOK4D+xWoHvUzahJi3BG8Ic6nwOqUJ8dEZJ8y7TSVHpEILyny+wfUJ/
nXfM7VFy6BDnqOttBoN3WYlVIonAYQdrKsYijiP8+7xGrHnV1rLbq+V+vuwBu2TzQFJrIItixb4L
l8q4Ubsvu3y9q2oKageE+O/9BOW4dUpQ5hR2ezjTop22T5QkzZ/Sb/aEZMb/RxyEXaXfiJT3mF2Q
2+aKbH3s7wTD2u3Qz5H5c9O3gSF+/Ocbf+IHB63bwxZf57eP5OtrDHrq/FNAxqdpC7k8xy/Uy1Xd
7Pt2jpGZ2C8imD3Q+NlZQAbEU+JkWyCFno7kwyuT5xHanCYxkP5rBTe+y1MNbwNE6tXA0sskYjuF
rg0kvuY1c/kxba64LXe/1rGqbfz6udLiA+hy73k5uj6EWKyPEIk4bdb7KDrOP7XbJq3dwWHd8dGe
Sul9O/emFMrHFMzjY3t42GEBvgOQky6L65YzrsBEWImLfdmlDb4zVLwUGBJ7AXPhoweFzS7a6ucn
3CdgrHT36VhiSJv3wKzYnj5D/OCXOPZ82EWmuUKgoNJfjL4FYiu4y4TsyY0nxtu2JXu8WZJke5Sd
RYL3pJJtTtn1bsXQ8qvZov5d3y0HskkVFT4BD6Ymc82lhg54npP9Ey8AHd80UQy2YyvPm5pKnuFL
mUJjXUS809VKRtvx6vpny+mVnjN0DTNz1FfeSdQPdVTq495eG9F3bky2d71z0NDF+6n7+ro3BERu
PPahXEvzZXMSt0r+68yb04conhPT2cNmXXgh/+wnGdS9xS+QvAtMEsfLc//Dort6T85HtcGt5p2t
4owH4QyR+nNeOofmBDOZvLA2HX+IsYujdtLcZjDaksxgwPMUXIaG7+fU/yMB7U47yMllPe9ZQt0n
WbCkN2uKcOQJbGNBIga01iJT3y2mWb7LKenZLj7nvErWpvsu7OisjR6YOncpC9YdOLcaTNFLXhEO
d0ls8N2RD6AdS5yD9qXPd87k9byULYHrMZWNTpF3UAJt4uIWCGE+0IK8RASvpy6CTQRMK2Gelia8
RrJGMQ5DgrvcDw0RjiKBSgC5jxovwArzwXBLHDxR/pBOZpUYwzs65ePRKjTx5S3O70ykcurk4Ale
OwezlNAdbAok1j5t/ZuSv1BaQQSNR9e35hfduq+B3XA1Q8ongSARP/h4CEB7fwpINLaCqoR3egGr
cLGtq40VZMtWo9Rc4Z7xBthMZzfu+LHaoLvwLmAHGdLhAj6+ElIhYIIdzrJuxeXo1lCvUmNZx+FA
RaBJ4J3SxrBzR9cWBADWTEKOsTuDiNJySa5CH4JeMuMFVH7nE1tqQHvghQif/chujIOIpFsnro7O
Ju2A5jkn2jAd3XGjpCNdzIOI+mCc8rrsIsHiI8VV0TRL3ogZDr+nRwl+JfynoWPfakAwSlPpc1Fw
yD7n3Ct88CbbiEQ6O4BYlRctPmD3zPgANSB/0uPj5r4SL7Hfu4pLPBkrq5fvGIxoM/+dKS2ptNWf
Wh5Wzjr8JCZ0puUOzkFaKr41WvtE/3WRL99MrvmYBgNSsleF8pkHxna30EGA9uRe9gX85qf49h/I
tHJMpFFbmShY/3uvfRSlOOIbjktPsE2jlCSFzb5i3VrW1itZ6r3Ql9hr/1aIWIKU8WEzfuVzIrnj
cJtzyYNKOlpnFS4FujRxe5YN17azZGHsiu3kPRlps0Q+YxGtuSB8w/xahMWu8ThVJKqLWFNLWHhe
145AvMhCdAt8m8VROtYrS0jYagSjBl8CBamMSMKYv1ATa3gYyow1iofZUm0bVT7ONthAbNgaRqxx
+MNKiJUraE2/9zPoCbOG/CA3R3WbvkeQounKAxTmKRWp8ojUxMb6EwPOvi93NS8ikfBkmVxTSbSq
lfYn5+PmOZBSQTwyOcsqOfMsMEWVMoqjGAaaaQkaNuT0jpFIlibolT5f18KbTkKrhNQAxTelWwXB
uI4AD/pK1oXhCY1sJwIjLyCN3DvzmsMFNNPOTgKHf1FWy/W5Xg1wHm7f+/a+FX4OMAlATMz3cHsV
/MelVSOf7qL2LawRVlnmz6Zk+bBokH34ckk/XbwntTUNdIvi1X/Ure+Wfewjodbp8HouJsAIpm==