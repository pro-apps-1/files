<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyW5BWDmof8q3TYx8EHq1LmerufFSx/auxQuaZ29jwHXfdkKsWtfynEocROqaO1K8RdweOHX
a0YDKoJYQv64IEdKDg03TsKX++E+SyKWAqZ0/SP02QZyc3YNDo7g+mp5h1tbJ/sAreALCmUi8VQa
mZeCzOPHB3cYu+h5zXZSMTIWJXhSzwNTx2QhEiLBp7T1+id1JlUmDedzeELMv9kNNGKQ7BQXVRgq
fXd7ONLZ916scxuqd0UV1I91WwdGG6sDR5lBRjHLK0sFFSqLpROcz/6WCfviUz8NGAr+/ZLjduA2
1KSc/rHabUpn+9uU/I174M+Evi0rr8IOxFFuHDGmc5jjfToj1F7fq5j0W8JrDwPGGoeryVzrI2E3
qu35dvu8FeFsp0mH/k/qcWbgzuUCiGpBazcHjvBv1ihk8bNCAM3TZL74GA+aD7Hy/OVmwEecpONs
1+ccD7oAhUXoIOMFqntIGSA0/p9Y2dK5BCbnVknF97X+l5fo22ZWP+mgtPzK3mXODvk9kHO/BLL9
Ku0BGdTd7FKbBR6GHp4In22ucs8vmdL50eH7G2/o4JXvJDef7Y1iLTwj5xNbvXV5umVXPu2xvtDv
T9vZWMZGtzy09v5+mb5q97rENLRFOtHhtN4zbwm/vtf/wyxcGEVuOJUoDoVmXDizHqB7+Dl/z77k
TLW5cFDBkpKLzGgjTrBGGBQddfvZcjxWowByrmvSqX4a48aOy080dQny39ltRsqMYmSryXex4Bb9
f5ZwOPBmWdNQ3/UQmv5VoOXSEruxvHrvKCNDMB0F6goPRe5aq3qsKKMadAblgPhMQHVb6uXuJCNU
NNwwKX0xT8FC6AOG3q2608cuR44zAVM+TwwoSAYoSYtZS/L2mP7+7x6SfV/cLZDWx8ssMDr0FkkN
N+x3P0d1exYkV6yT8702WKU7gGLWXt2NMQ3oXOme80BKJu1i129KvM5EzoYCCftm1Y5M15Tsyzsb
FTKCrqAwx9zFDeeJ/FrLKgLu9nz8yA/Vr7rVrNKL+gi6mIBim39/CgsdRYXyTuh89EKCjmUPHgpp
Sa1HjKjbLIbi8neEYGoNsidERufTNjiOAZT5bnk4WkfuPz8DJeU501z7CEH0WbShLrGcKeS0pxr6
hy2rEhQ1BGEdI9rIKkXI9zUhVNz/z7SQ2vZNsTd10KUN+fqTEFGcJDfgYwBeoW6LwtAfGSBNLCY+
jx0oG7bJKlfDRHkICMnPnIJ7nNF+L0v5D5VkJEVAo61HU7MZkCyJctK2oYiHh5lfQ1XX4IrwObVo
wDw2x6fnW8RPL2RECpiMrC/U5z6VTzZMEFEKxm5NnE2NRZ+8EWkE9er8MHafSQPZ9nC6TRlMcIPy
43s/ZaK5W+Ei5brEJDzhireIZ/SaRhvzDS49xvx1meFsMDV8uH1fl8P3kP5/7kHMQxnRRyFewh8Z
wFfA4Q+4OZt10nvbHM4LQZ8h6CQ6G4VcGMF8V/5A6x8cJfru2mE31sfVc93blZje2LsmaZxGkC/d
YIxTk9k630hK04eIQ+NLvNgpyd9zvequl9Lhf9UVR6vB/G8mnVqH0iASDlVUyCcI9PFcAw48/+Xp
uxxsmvE3pH6VKxC3p4PeWw6IlBWXVhQ0n+n1Xb5lHpD1Sobn4JtQwTp0QzeWVM/CYXiiqiqCqKFS
04Zt0fd8io0AVJcbhjwgbQZg1QWqqmzT3aRamNso+3Ho48uDFfnMIuwkhZb8WJqtxVnfp55POsod
2La1XS1W8D7yUUakNLoKl8zw6HmNKviGxpt+x198Mp2kKIn9BMdux/ZkryGphggLjiqq31i6QcNC
ob+/Zxa0eIXdQmV5KPmJRZ2tJuHq/o4KE4RIPmoTLzzhTHBEH1mX4p7EXQEUxOgclGAfjWjYKVPi
+hbOBx+XidRLO44mvwTI2mdLW6BZlLgcwKLNZhRTmNAbuuQ2S6te7NJCPaD69VCvUXAa2O9JdKBD
qxEIIx5l08QThKFK8tdb9ThImT+70S/EFnJpg58B9aHx440mzhLvMEU8XUXGj5exIFlpOg706xI6
OHB8iy2IcUpCKfBndiV2mS/7j5DW3O2/C8g0LEAqHvozIhLaM1KlBM9jYHDb0GLUMUTpvWRWfPKv
yeKBx2huur40HbbmfZqKA+iTnWYcDFuQEYEKcD4Q15sRN4hRS/3ajb3blxGnnaVpKrcHf37ACF7d
5F2Sn6M4Ht6DnNOAhtU5r3SOYPbkigXmbZ8wvxw+wMZQcQ05gog5opFYfin10AYzBe1c8tGfhbld
N+iTVdIUH0MR+ZTAZqmQaoxHCyyAT9Nc/N+U/tpeqGpNZfvEwf5AVPIph+2jkweSA7qh64xKHaED
aoTHLk1ym9vmf8PhCR3ImIrVnpTPcO5Yyd7/T7udW83Rs1EMnnw6WVpx+u0jcBOQq33z9LeNvgHb
y8cfrSSrXLoqKYqCzyYLDvusgUUC6nNKG57Ntrt0QUANrrIX0CtRq9DaYHHfjdp4u0a0u0bTIy+4
p7YnM2Df8x6ufjNSOa+2OrEq+ht/2+yNIzU0FKRV0BUEwGJE01xKe5FWwKSIfxzABBi=