<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpSfBjsykf8IkUYx/YkYAVcGDvJUGlfp5CmWCLR5UKoG+sFQOWKThBFHdzkD5i7GOOKJTVGr
OOCmtqQ4bsCeZfEQW0rjz0YG7zn6+SINLX8FheYC/KCvKwfcqOq8OffjzFrp989RIoedsqyN+6ss
ShUhgo49TjrAqLUxgmtuLdY262tVVoyrENgAA6qv/xfb6y7GcYUjQ4UyLu0N13NNgH2QJHIoYr1B
2ZXBzn/YRtzJxh+47WJIaTd/xXQyHQjE4aDX6xWeELB5xncJHZQHAvYmnUyPPTlJw2XccFNAQ4mQ
jOwOSFGoeZWPIwmILND+U6jGosspPR6xAQwAbaBhJEyZVN7B7hQC0Pahhl4dHXC/tFYv0uz4qqIl
BxBLtJ8imq9BDHGCe5sh3eyxaTuqVPMx6giiN8ZbeGzdxIcBXMO5x6CRwHH1s0iHr68H4Tlebmn8
w9W+wZ94PgPMWN1N0WfwiyznszkTXzegCquHompgipFSTF9xfsjfQhQpK88iVhWRJXBQlMxNiOhQ
tyktycXCsMiBKskv53WCsSeTiJrMwIBQDFQxKSXBbWEDrv1/8v8pOuM62EF2+XF/V7pWzULv3MnI
GXoW1eBDqKnAmRgAy/LtPO6WlTmCaFa82iPZxeN5zpEo5G02/t2R6T9X4WdiYa7NnMslWDtGYuTL
WYi8aDpcUIUYWpY1PkuRP5bgRL/vVtNuyh8VhJLKnIHr1d7vsrBAO2su7IPzqMM7VN1j3T5DSHQN
4EtkYgQJD5po1DKEVR/4dby4uLdeysT8JnuK99Es/fSZ+TIs/1MaZSkyXffxk/kj9xaRPOBxcZbW
4SlT+6v0wMHdNzF4Di6f8MNIuLZoeghIeFKNP3xcAay3qS+wUWGDx3ULn0Hpkvn17q83zTjc8wIb
Q87JoXqD5iNP0SSQ1t+zvaApR60judIvliZZJHB1ZfPLme1T8z9vyo/3HjY+ZZbQLCnkJ/TLz454
62rhJGiANW9VZWiKf6vG7Fr2xtgxUew8Z2Nuezz/1kVH8afvNBW/9fuNfDfXDKl9CoGW/CY5EshI
k1v6RUX7mmRo9+AmfDL8CrAy357DKRfi17X7Gx/h0S9zHiXLe2IoD81NV4MabSk2BNObmKoEmfYi
td8J9H8NdzgAdhUZCFSGdlgaIr3F4xBf5wyhKbn8E9PY1Jh9z/fqQkx45qsny4k9tewCArD8yKis
1A1vGOM0E1oFDPpQkelB3Mq/WkrRSyRFpOeJcGiw/eq7sp3yXH4/0mt6kQHbOk+w