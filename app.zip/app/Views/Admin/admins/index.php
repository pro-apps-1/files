<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz/3cMwOds91PG8CJIKkilpaSeHctGg1nfEuHI24JE2y55+oX4nnOOOWAU+YtDGSZ6JYNKOA
WA7P/a6xJNxvv23bDXBgi2b/r1Fl1vxBKIQZq5BPZw0/g+9zfks3qWJaIb1S++rNVu5bCZuFjWN/
5jFj32+m8zJP6s3h/zs8YtXZtK8PuPQKnjQ+zIBsRRgln1/vjmDZ/vV44tolxH1Tp9Jx5QRmstpt
SxFTb+gJ98lnqnv5b0qrustwx+93XYnG1zALSkkF2qtch+LXWRBBi0u7RbDmeIS9NzrtcjMwglIV
HbLx/rOXf9hyb7UIJBxMRy+SxYifpkSEFPHmLNEg00HsPG0ZD9xlD6xZ0aaSvtAuTPIExrn5bo0a
hJPldB1HAkchi2M9I+zO0ZjtvomIXZLuNLzYUXWfdkrJLmc0G1cvpiFLzcKRv9njlRGLPVpeElY0
cP3FPlQyHtO9R6R0Q9vkrGVxpyoi8Nw5iuPtx4AxiaMc5g77sPArzyHODNAhzx9FZfH+KRvJ2jmC
K57q2C9/PPon6CHCbHFxbbOVi7bXIDU4MH30QPnzwmdxwSOuYrU7eMPTLyobYb+c47Jf1aZFvPVt
i/qWopzB/RxIBLAMFp3IkmS4h1OtvzLIrVKMRTe3isx/aqehn9L7HUyOR4I+TUaW8uXRHDEsI41n
ASgewqDySQ83x97ZPyULm68wAabmHWQJtYVUmkuRz52etXG0OpWLy3sdmNlHAuPCryRDEJHxMR+a
kYemxUH1azU8zPEG3TqfsL4aGmCYUnUXpVznmyIjAon2oIk/NvPJJ8b57u5irvErUwI0QCgVzJfb
+ECE7bm6X4DweFpPJ3i44qK5PiWVGVANMPGTKiL6EIsAqoXB8ExuhxAzYX00bF9/0zVgdhjuVBf1
RKlR1bXWEgCKuBgVjvyGpqXk6hLU7wG0goIzow4UVhf70plEN2pTYMUI25y8ZlvXiyhyvToAfqf7
vDQLOt9BRGBXeSZSVCxioopeGMSKH62CznaEwdyXB/sefZj8SfxIdhUpZWaYfHrC/EWWuUsU/Tn0
HgzJRhjGehafmwWqDxkyOy3A5knf6vjoOdvXh7JdaUVOz5+YgzrJ13Q2o8CU4wsloRloQJFiq5A+
D8bamBc3etrltCCIXEpt/1MlpCcaeo63TJAUFR8avy9NOOp5QWULGTKMEh+RbZwC0GXNZc7d4MMg
UuyAilIl48R7hdKX1GQGXEoaJ5zIekz0hnwV0mRC3bd6t7t0mGitehJc/r6IBOttTef3meUup5FA
rjVbpXlHkfjuIxi=