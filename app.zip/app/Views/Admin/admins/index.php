<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyTCGAHW0RcBVOtLXv62gUV343AU9ApckSDxjNJXQIaDXtO4SH2ysC3U+Vdm4VSGIsRZWDIy
fLA9VTA3od/SHH8QzGTESRwK5mKLeBK/BjHNB1UNe9Fz5avk0Cw3QEQ6KNmYkQJ1B92GnhOEHlPl
ak2ojF2j/fNwFephcMylaMJoIZXO4lIGnYFcoFg06xuFaoztVU2kcJivIEuN9ERe/L61h4hp7fVl
dGJqJSE1nP8CcHlU57rZ9Qj+91SNiEhyavFg9ewKSsvRs33i/oXoJThwYwK1tsHlhc9lVoqw5qsJ
gyng7+q5/xuY3/U1LmqFZ/vKhMm2PZDz98zWVd61IjqRXnMEVT2mBjK1+qi8PxTEoxmTkL6yX7Dr
uu2KgLa5DUaivzmk43z1QKv/aiUmJsoFWo96Fn28n5Gj0cGDWkR4Z00GTmLJpGiaDHUlYznJnTFE
Xx2N2roaNt5TS8hquEsxgX5EzruW7xLJ5FtvAM0xBpZKATr0yPHBbcOuriYwQl7bxk2rABHgE9jc
CpDmsPwHC2eU+qk6VxOFAgqhRw8pg9jQVY1/cYq4pkH9Z6azKltQdWVDIZ9Pn232bGyRzPgwQfyV
O1IvvZl6yTibqN5iRqVge9fWqZ9b+sZMNuvx3RcHNmXPSXBDHSNCqAR0Jr3iI0/GDBcHxn9jTJw3
R8X7M+/CTkidgxtqHrALfb2Ki72dmzfHUUbU//G/cllBf4IMv2gIR6tNPvqowF76WK88UNxNYMbN
GPljWM9qcASrbbJ9523Fbma76lDyCGRuwovhoaAM25TSvqY5QDbybryg2SQ80ahHsSPNXtWVRZVt
8WFMfAEVK/JemBxzKZic9foL72hfeHpQqMZxR64DRKLcqTdM1cWTv7nptF3hxi1SdIdGzj1wpM7e
T9cmVJzqyGMQ1I2o4fBdFWRLBE3+9DEU5o4gk02OJWnG9dJ89A64RmugtvNVdn6rRwcTIUA3H32n
DM4LM4mRxutg/L1hLnddagSnCVMRuSz5VNZjzgLwBPoy6pTSrKYxbpubR46MtO4hRZ3xPW+8cf0Y
eFhKgS5CI3vodTeBLLNfAZ6xRLIKqnwMpuHPFJlEeSVW+L3gNMf/6FQYHiUgbi65tw81b/Dj041a
7qHHuL5W91/0H0K3+UeWqdv9W9we4t2OsHaE2/+OFINXqF2khOMzS4zgUeN2g1n2qRX6oL0+c/d4
mHAXUlqzm+tGnWgne6X1BlH9mUxJkqPkMNX5tgjty5S3HOrQ+2kq37D//dXrveiEB9HoSUnFUZTx
A9HG6ro4ltvkH88=