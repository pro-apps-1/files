<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsEprkC1B2lKt793m5GLRTDlCcDN042jEx6urTJCquAHe3H8+5Atuigs8NB4lZvYSntuA6yN
4Jy8H9fxjvZ8FPdBxlsspNzdJ1yzwnrKyCwOsEpOuchDIu+mV3cIFze7boykOzktr/TZQNgPalgG
H96Dz9B1vbvpLOC5+cSxgvImr0PT11yL2b1LADRCXNlJfJ3hXnPRbOOec+8RKlRnBIVI4oAds3y5
QZjzLNj2JBDG5bF+/I0vl8/n5HgnUe0TOH7I4No6JafnWqg7SusbEtg05AXc80iA30Z7AdfUdtrT
gETTd4jgdyeJulvv1t/9vP7Igp/c7q215EzL2upoMd8RigsY0z2xxlZxWLROlii+Im/HnU3Ex6d4
a/MWPZYjV0fuGmLzvFd2XEuW7kwyzBUTG5caz0FJOcsSq9vfcs+4r0Xo0K4RIilMsfllAW/HrwI6
4aXnqDW0J+KlcXsPlCovFm6LI9VdwDOsBp+GQxgv29Wbn/tH158KdlNBGPa/qvrp8MBli2r2/1Bi
kynJi9aulnbM4MdOoLuuv63mNlPEzrzOWMLk7zVxaqk64H0J7pXxYt6j8QkdSsh+BTxbXWXkCLr2
7wmx8um8aTpiYabKlXKXTAvtgq8N2tz3VjSzdtGx/kXIL7qjkKNH/nv6IrWrVkOQHUsDbUX35sxm
jePDnxCr4+baUii3WiSxfX3Yy9Wiyk5idHSzqHAhrj+rUyy/mCDV2AjCTMTRZf5in7O3EF5bAraF
bXERJBiRz1FB1zyeWWIiZIorml55AUlsHffn4Auwov+dyEO3ntnkrtTmFJx+etsDJ7r6ljiOurc+
WsOd2g3EX8gVXkjPnnOhkmVFG2QXI63/TrtY58f1Ha4dn5M/GNkBeSX1LRhR7KpwKJQFBpGvTW7c
pfkbjAk3xBTeUOwSh+ufKvyYlaYtG+Q/59v+heCLdVioHas7iFTFmjrwyDgPdUK93qWqbiQvT8Xb
Qea2jcA6L859NLQBS9HQCzvBnwOneg0ft9DJZbDMfc64zpRL0hy6O7lJm6JsS0OkXQsn3ugkizSb
EmRXP6T8FbQmOYTByxF9K75HagIX1tuKQJScZCL7Fh0JsQX1y/rGe9tMOuB6QOJFFLgoeeUYxwQ1
VO87xfrlPxTtkw4FcQYPEnW10wRdM8KicmdJrQ4GcsxiScd73UpyqNPE40Nb5V848HfFLMK4WObb
LDgE4yZcdkN/sJLC1zhm7cVtZZ6YKbT6aU62u3Wf0iqqDBnShnzgXvv4Z/0+sv85X2X62ewHtya9
4iqclejmNde=