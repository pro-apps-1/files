<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsnah3FW+HG4/QKv436E30LfC43uMxteOyCGgtL3uhk+s49nYRTjHqJHjC4rOg3ziS7/ls2R
pcoAMzYxEeBaA3w8er9hImU771Sarp5LxRkWt5Bx4J/ZwIUe+nhSw1/0T1w9SKWiK0Ey3cdWrnvt
0YldI+d/fKX+lnTpzYIrGokd7ERkoKLtwEWcVL17sIdFhb0fblceP68aMHXc0wnWMudHegbCPiDK
otK6grk9k+3pyoyr3kemqIBWcad2K5eOdFickwNGQ2VySPNEKTQHWZMx5Jfl8cfh5M61GaYedbDA
qDfCFLS6hF2FM9cmbn1c2rA8fslAAgGP7mjTXX5HUJsatfnJdXTRc7Gzl6/5ffUfxNQaa/Oixdoe
zLW1xoZUuVmif1D4B/1E/sBN1jfG8VOiWbXcZhJ/69VKIoC5eqEXOLl5vfzuwNoB/UWxhbxrFsiZ
jONCs6t2ypdZLK+4dRnWV2FiQwaa2MD4U7/Hwu1MthiGe/fkeboHx59o60MaQxNCVSqnIA6KHrrZ
caADI63KHoJc0rSldgpZNFT1I+TwhA/eagVXk1vCZDBsDRzwcYV0uwZUnHsGDHNdX2/fLfRIg8u4
nxSOoW8FLG7097/yC79MwpCFq9A4+nmoEqaU4cZhCO9pwR1j7l9i5hNi8//yf3JvBvFrjT5YmELp
q5Gc5rJvbnPybGvEihdgWciM4zDLp12YY7tMOnTVaBQtRYxjE14mFs8MbL/VjPNtExjECux8NlEb
lWNAvNQsG+Xrg2E5dwFqlMXVauWMgphX1kgn+lg/2FwyeyueY3gKHFYPtjO4qHZORbgSg+llxbOr
BxMZs7eIRFb4QSZuSeyJ6/vPT7B5Gv8Q6qqoqWX6zz1QjvPVE9VGvxpsq8Mt794dceAcUPCTbRVo
r6KsJeCNkNIHmGARgunBki+8+9Cpc/xhm/zoAPOSq4ydNnCmZTYG0o67Amk7rejGQV6wmGDp8f05
uOisMoeIxTbc5RjiT48PnGY41Omz8Ewus581rFz9MxjEwO9N5F1HzzTuZbk6fCoxYo9HbtAbo+J/
SsUkh08/ifuA/L6B7iEmLyuZtoL2wEMWqxzN6T/mNyJotya5zEGo+pQ72Pk3mwMXpRaqYVWUlq06
wMtaSw7DeQM8TNo+r3+reoysyQOZvJv/nNBTiDjTCk5GDoGtbHIZa3lvSr/ELohjTo8hWEYd4tia
3HIJyKpEgmwQYsArXtKHvrHh4PERVl54Wprnb2FkIy2oFRt0cHWgJRuojcLo96G=