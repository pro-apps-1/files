<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmWaw6hSkT1DcULzILI+htljkMGDbTdGve6uPQSOSgop5cheYpglAYax0z6VyY0iVGD2hm5N
BF3vVDL6C+irRlqAQpR7aqTCvj0IhbyuaTuu34MND+XKvewRHOgyI3JDEpjHgYV1fCtxduvjiRGd
7q9p3AhsdAyjGBs4oJYsG9Tgvma6g++l5EeY/2j2dZxLvBcZds6yQmw8t4dGwaQ4n+EWzAtSTvfu
WpPajwRGxCZyChqe5RvK+BwCqzF2HNjra2YeBFA8EKV1kGqKsfbxMrk61JHiD0BM34haoTqueXxt
qgLC/n7yil+BrvEGrYIeQ9eh4Qt2pPUFx/seU26XZGDG5mnmreesLKeCzZHg5H4nQ382ZEdmXbIx
r4+EfkFx1gK9rkrY2jWT028s8sVBxjQ5T3uTJRNzihUp6Yx/KIkqSg1fTEhDCYl0MwC3gumdz42/
m+gd1I+nVg4qnnd27kKwFVwVGlwEDSfCmsD/HvD+Ze1UaXlRGdV18lOv1TpOCZjPPcni78ama91u
NNtxQts/GccQ6ZzqMOnSwMyfhCydgV3R0eTKLl2nA4iqi3J3rA+QBwkdV8d1t5rPQ0Bl/AbCdOVC
QPgpFYukHuB9XyQHWuiEwUVnKXRbGT6sbV2bJBTF5cLovIhjnb+bAuE5ZPdztWzSO1EnvnL0mR7Y
lVVLHc9wQHzzzaV0Qz0AsS05tVPnnuqFUoQr4eYR/wDRpIJ3EnkNBTh+1VHB24enngBDgGYw9CfZ
or3U+xs40uuhyRmRmQ845VKAbJghnBB+VobQDnNDzVCVXR0RJvbe6Bdo5EYcseceX4jd6Exhp7rn
dPzen9Ws58S034louvWn6oGCv5FmFpffFyjZU1Js5Ab1kQXnRABrp5v59wHJ54Sin1/GkWbQu9K7
uxgR3Xux4e6oRQlmNACs6q4kdwJBNCUe1S05wdya+C+b2uRu7S2gCM8YF+Lodjz2Fcyw8SLncYe4
nlQwBTbjbGGg0SbI72TohUp3WDC3hpOzFxe2O23TL9Zl+78Q9Mul3WgI2MwejoFog1vlJg1cv5xD
MDtFvhHdgMVOK/SBVu6WwJP+9WKqe5WKpNtfuKUqVdaYgkczp68BobKGpbzuEObYPIx92BNqN+mE
RPPIIfj+VYF8tijLQgm6rc1opdYTIu6m7Y4tYKH7THaqGHSHldsD4TrZjOa5GRpnje9AE/pgLV4X
/3ATxI7/SuvG2qWX48I2Oe1mtdwNz7WGYhhlFqhKtJBuHygYQIvkx65DgHXaLuO=