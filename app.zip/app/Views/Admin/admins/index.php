<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsvWXx0K/Nk7uQ4IayKuvNiS4tLu1wudUOkuPUAdBVoKbcko98OEK29LGkcQV4o8X0E+/8W5
Rij+CsNPBjz3zxUXEEQiaGjK3gmVerLEc+/D478Qi3zVB2wvIszYieqoZsjNhSsI5+QMGHCxCISb
zSSdkWeMUH+ijBYDVOKYk20Lom6sMVYAsnV83DWYfN+A+otU9do1nLKrwcZG5qAT6LjTk9j6hA4R
ROfyrGFJht0JblFBpOx9MNLYU4iBRgYHoz+lCHcsHeRqKnR6xUgE+EdiLH9cvDxqakMkApbwpac2
heKsMiV0imQ3UgFv4th+RA/uoMR6ya2Yj8guBZh7WyRFT+fT7QBQsQQad/Gp0OMcWjk3D1VJfipU
2qMvA8TzhFJXP43VQ9KlLX/55hQrgb+AzWDlsKusrV2f0/D+rfPvB8pALWpDMmqejFCNPFvToubD
4CdYcYIvngYfPmMMoieKt7vSP2jk73k+24zIHhp8nehsl955T6nXCtXXz8pC9v8j2OFW+bKGGIEn
x4VaORFL5ewGuUjvKTyfHRvsebPcDqm2agCPHrIF5OafmC43p7JAazYjq6QBoWTyGOGrpV3bgLPU
Q4/Jza/xFogZKynx5XUclYHe/gRv0zOAGdsYM9pU98sHUC/iR7x/394Q7pB6lc1+ohdQNxsXhEHU
+rRNIZjXmd4qryZRR1mgGb6/lIFyz9kDenfR2uHQQHj1s5OkGFsG4UJCSGWUN4jLTU2FZpI9gZQ0
MZQr219xa4uJwJvQx7OUni7iDWCRLtKJ1cvHbjmp+z3Hqv9IkLjQoNQNg5rcmwcshJteykb/D2Wi
ubj0f5n2xLleeWd9vytwZOWzc64r/pCA7eo4iWvmud12pOwM++8oOHjjgdMNbwBi1598mHaXTnKQ
O30S7DXSQJXKd/ez3587EANpLqFa/rDPorOwAT5ekLoOHLsVX3YbLRnzz4x4uL8Wn7kGuGOXFmTf
9mfDUZXfTnWPLH91mVBow3Fll6LRV2LmutLc6qsLgNLXMSJV7K5GzvFd4UvpTHMq0fDJ6nWT9dkt
Cm+EgP+F+Or6ddNyrhUkgxWbH59LRRt1NR9ECC9MJ6jIg0pjJQUeZy7Yq5u2/XP1G0hT5SdfG5CA
y6G4oeEnoWx3oqX71KTWCvK1Qb43vpBZI04TBmNvrnlYFrq942BSSb+tA8ixfQs3fLLejttz7EpT
YaHR9cciSRmALLP6NXb7D+fDrTgeGJJAiXGulfI7RFN2dWQcUai7sYFDtrwwas47TG==