<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq4Y+Ehgly3Dy+DjoVllCktjRqXzrmS1HQkuIzy5Expv2emv/f0LZWRbJY3a9POVOrBe2JcJ
yEX7tXoA+4XIuFh6mNkDtGAX0Ux6xF8coqkrxewPNiJWQwnr8vQmLFtzTM4c2S2bsYbZldX1rPxQ
DXOUY0bD3h9+CbWSzY+mnjZ/TluUhDRD4PQ2/BAeOn23ayvjupThHL3eCO9g4LOT4T7u2QUSiruV
s4nXxwQOaRrFinM1kKRBkQd/a1v4l8e8dAQYyh6F55dCubCN2OI5/+0cykDl/G3GFg5/1XGfb4Lt
vd9J70sEyWZ2N4IWITzSbQiYocIzGpuZGjRfTvJ81EIJUmnNjAbzQNTIn9Hk5dpQk54gd1RglbRd
RyKA0G/SMR1/egeV7dg6k5/M7xGL73QqYXM82WH2CV6zkME2IuvQ7kvJ0lNAAN7E024quEnoiQUo
AdGByuXxLmM0ZAanBPIhwFWnq7knnaitnfnO/g5+N6xjY9LgUJh8fN/E47HZeksCxaef7CQ1KYif
zv4L30FX4J+CH6bO7c+tewKTXk3Smj85tEGrkBD3RQla2B9De84mai6WMmpXcUogfg6RGGX16R85
r/Ff53HIzpa4kLG91Q5PRoUol7W/1N85yn0e2vU4CP/go3Rgmz1fFtd//4t/cvGuSSPh9zshwrd+
RWipCCLrQjJfJxXN92z4rJAGFaRxD+qFqRdSBxrk6BEXt6P1mgve3tklIq/82mi6vqpnqx2D3rug
ZEmIVvliGV4eR6SdjikxbCu52gbWs6w6nwGl2S9cVG85QVoCOriMu+c6H4OcgudQp0GZrXAyTbo6
AlqXkN2xbHWtqwG++F8krlKEIsy3py3rdW9C5R4gu7ms3vhqj362c4x3nRpia3qoN0YskSxG7tQ4
mu7Zs+tGYc/ygSmsmnsJd34PK8vMf/L76UPaqanKRsu1jX6rBbJJetubVX3pPjc41zTv8oX+LBaK
pdbiKUxltsOT+28MH+RmCU4McrL767Nb3PubZxvbWp/39dB0jCzGM4+VZiFQirDEin6vkxeN85E4
KMbByCU81xBZgjCORj+d3oMP/v60asFCsMe0us9myE/toaOiocJgL1hiGvd4zz1ZXFAYki7iOx4i
CPtx0P0pyebGw+B3GVRYRRtk4bQgVPyo4AzuAeAS1CCDAIm1aQ/Rpm6LheWX+JV7AsfkN3jtFw+x
gdfx+eRucxYAXLJsk78ojalE8LrMBJbARs/MuDgN0ydYtvlQOgKZ7LFgGtd6YuTbznAlG35ymgqC
gHpVMy/oDJX5e7Gz7DMZyNMZd0==