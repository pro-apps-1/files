<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvQTN5qYDgMIErp9VcO6SdWjGveh0V+unS5QQGFoHZDRsZPQYfdT2RCFR+Q4PM3R2n5xc9XI
causDypn6TUwYh5rzQvP1wppvjVWClQu9p8tUCmLPHqfoq+9tEndRGyZJBBBUyFncaEKBAaxrVmL
joJ9STLMXLrXn93/yCYD+LY+MVz9wbX4ztrzSzTMiP/4/6O3oPoTn2U3tZeVG7+e3DPw3klFGHS9
X974tzdCqo0W+PiQAO7Dga464+tP/n0vyWsaiX+w5Id7ys/xh1blMYJasqLGQoPdkhNqcFBbR6pi
8wXRDlzIuGrnewFcJvGfCS5fwvCV4dLirZDl0txpiFtIHykkw+fG0FH92x2VxRq5hUD/jIdsWMLf
q8QRCqPfFr4cOa62ETrEgdSApyX9AMR34yHk08mxvblu0hVKdxBJvzCK57qPFj1EsOCwnsmbaOKQ
D7U9x3FrfFP81Emw2ykKc7SqfMzgjE0ho1nOVDdt75tlCWd8ZSUUbBm/Th7U5arZ8gPm4DUbA2GN
FXeeHF67eJ1Zx6mSj4k3tLllE36flsSmjdnatzRjwRCE/dH937lM2Um+4eDwLx0ozy3kiS8znHmd
XAVGLWtBO9GOuk8WrPc5+DGG460xPW8p+uYo+pLF55SJamUf3jgneJAyLNKuyE29l/QQ7XGhcvxJ
SDnGH7ccXzNDfSxxIDqIbFdiNB2dl6WwJt7a4tlLn8AsfXMWLqpWA5RyVocV44lmXMtHNUKG2bE7
eVwjTAkQCa/Tm8e8ViY/vEm9Ny3ZIuVeRqzEragLzcYGdsk8bCINhjRWwDtdAT0117UAW9VZfnnp
x6iC4u6kJEoY+vFiRs54fiIMS7Nn4K7T9VCkt+JiSebxXARuNHIU/2q2BkphUh9/4PNdsn+nolqu
tKl1mHYLkWFoAfM2PDfa34svz3uX7VFIA4SjQZPW9yTcmK69RvEPrTe2IvAJutNk7XRzIollZyKu
1xWFzn0mTrgO4cW1/bXtIq/vxywZHj5sN/6PpIQvQOrKSQUgUIKZGtbuPVmXo6aWyTA+r+DweTb+
g0XeUWV0J/DcEQLqp1pnSAUGRWNTs84dZFIAl16/7r5zwmKW97m9+pv4uPaO1Hoyz0Q/YfAQSBjJ
ubDRKfBO81M2jhc3LTxaTu0nXJYO6tndutVZH00CqA0C/u+4YXGWUsd9wn3BO/aTPLbupsZdpAgi
7NI3cwu1VBTIDWvJokRUcX+/TxxGRu4wUgkowcU3KEP72NbUBbHCentiRNy9F/3cph4eMMqZxiK4
urKciwjctMVkxwlYv9meImGcvFw4kwM2bPW=