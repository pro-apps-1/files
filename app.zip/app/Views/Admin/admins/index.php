<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmxLLc6fZgjMj1J3GaF+Z/t9yYUes28sWErXXBefBXJp2JW7OXTjAuCz1bgfYElxo66Iut2b
20D9elijSUzFXqtFjm3y4VpayLeFZDHBxVLQ4hECd5LuSzX/HYICOLwmsTK+nAUmXoRYRd7VsCnH
4GsfG1Y2Jfpa2RRC1gvMMlqUy6NdNwLVFV0coaApY0+58F7S03gHLh89H3JcYvqQxPvy7VzLIplC
wFl5WadEMXc1zfsBj//9K1uGFVCc28K1/NnnZGUhdEQ0wVtC5XO2MZ3doh8GQdMd+2+QhxQnxDfA
JreR2xFPkIOfP2OSLfXx3ZK155J9WLFEJqrAIaRnBzletfOTe1bIe0GNBuh3gLvZ2FMAAo6ulDPi
s2eHOSk+n1kzbsYjnL0WmaWZ4yIfTY1VUjE1jjwO/p+gLp5cUXQNPtTUV/LhT1dpSaYkgaVA5yb6
zgzqAN3RVCxotBoJX25eId/DMSUxiDvvDbMwBLD2ox9YWdEIdM4uu7KzQ3aK/rLRdTHeiYJ0pNIM
D6D+Ye+MuO5Ie1jvKuif3KizNPPPuWjLseaGJFYFgyM/hmp5/gEnHgbN4+wyTAEfgQWEk6E24OMy
NusHAU+zly1rVNJgWWu4cy+NKep2hmGj/ry+qGCq20Y7JzfSDTblog/BW8XU2nasaY+ogfCZdZz9
EL+GgAspk7ytOhf5Xg0lPvrAFu7SaIVLMOL8pWEgs/lQd5KzMpwI9GwKJN3gOfitoGpKLriiwHN3
heTBtFtiCeuRWUlnCLN0DpFbc9fw+zaxXIQvtCvsUaEDekuP/afqnwl7c+UygI53EetFraDG5h0E
Z8R9qzd89Sw4mQRUdSATgtbjhEUZ+J5L0zpX9phP3tDhiSK/Y+TGaRmjuPTgNgbzYIwGNKv2ZkIo
eGxfIhfy1w+2eUt1hJW/MWP10GJohKjpJHbiDD6HWzzFiAQIcKL7iWYxBBBkTPCvQvhO8myJnzMO
cu38ueI8s7J1SSF9HWpRA6pUTjy6/LCtcAXMQUIYTCbSPpKI1QrAv0dY1JdFrl6Ok/SjfgXwDlZO
9TB3Ry66Q0iiRfhv7qR0By61lnywMN1qf72vnHgnv8jgM2l2HBKqaMa0d5P8bXuUANKOTL6OOKXp
pKXr9D7c7QM2CiftT3P0dY+wxQQ7IvyjOaiGL0qD6bRDwHBF8dY06qDnxDkbuh+O9W79Y3le198T
P22wNhvQVEuaYp4bbTZJrICJ0ptP8eVE59ZbVKuZ7H46MMXnv69LDniBdbIjvPYTKkSsPt4C0/mz
lvVdEnG/ljnfUlG=