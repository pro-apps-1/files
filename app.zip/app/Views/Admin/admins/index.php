<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzo56zQEMU0PLqIEzJyD13Wqt7O0gOzz0SX6hvmvw7PghbAcTU+dDePOQdYalsNLzFNGTT9Q
hQrGlvRyZTpTSrTTQ3PaUrpLGaYxeVq1HLgDc0OzHChv06GTwUU+WmZs2wPnefXT8DtakmDoOmRM
/jzeYgWFNHTI83rUa6OcsqblXVYZMIdNg+dVs7XF9JeB2FCZJFHz1moI8P+8fXvJ+51veQs49LSK
LQZVGebaJ14O0atIwwtg5xW2CSsZtda5ICCsqtOKAnTu21puFx0CpmxcZildP6SggP8M0n0P6exy
OMrS4CQuLWreShJH5PM7AtXkrcChgg24uks5YeF5uQuQjOdmGk/AfpaFxgrsOf2Alv4RmJr4s1kp
llK7DsklUBjqAGO0kqFXcni9JZYcndFqCiR77MFx6wKZS/fZRR2HUYj3kpb7mHNi+DY/+7t90XVN
5VMT76sQ6+pk0tOejkve/rdjgzS+a9h7o44RzSGIDFX5WZD48qL0MpahATCETHjFAxFA7hM4DiDX
2zHAB/6ZyVNfMChU4DYOqvQGM5YbVlP8ouuCU8RjdaMGxZOusGffTPy4aRL3BziZ2kleTGRXQSJr
iNbnoZLZPWR43oynXMmVuVjTI6XHxxIL4BESA51hSBqfezyQSIR+7iIhr/uBOslCGef8TGPW3H8X
Yes5UW48V+2xlBwNl7uz/7T/q1AarbsBvzGuOXnbEwiAOjXRvxZU5ooBFqROGCzUtuPVcMuca8BW
vYdeTfJt/L6DxIQBPUbsdo1+FsMIR88DMJD+mZyBHy+7MHY+clykJvYm1SAUPMkvm53RqA4I3NMs
4cw8Nu+aymWqjOCvzvFY+oZF2VFbLBNVlYPBInXVNuQIwgxl9eHVSzyeG8gsQ5NZ1YjEwfkvswZ9
c4hpJE+ESYqzvCdnzZctby/cSqyGIY+L9MX3bCMiXe+97JMpHpDAO/kyrzp16d19fOg1OaQ54VSO
xIVOztlPZHWOh0hgerF27PDtBdF9gmJ7x5mrRf495TfStSgDCVx2lSRI5v/sIM0v0tCN7HlXwHpt
CEu2/zButQ451sRbtgPDrR0P0jjjBGYcW3FvOoq7PVZ0+lIEDwXCnGTJC+UIMlV8Sv+eMrC5KTEo
jYz8/pvFgUKm3gBxrv2L2s2vFQW8pV/vBeGwUqhBo2GTuOpyocgfQH/KR9Q2k9OweZFRog7KuXng
aVkx26rrTXvoVPCH5Iw/1ywEu7mqskINpHjFVpMy7YpFffatCKIJXoy6f5c+CWrNi49jAPW=