<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+iDiNrjnWboQCmaNaqMWH19xw9l6a5xOPEueBLlrIHgBFPxO0s9s49UMaQWHEOT5ms3PC1I
mFerYl/+ZlIEWnMuJCqr3Ne001RjOs5IrGtzOjl5AxuAJX2lxr5qsXyq/bT/TYLSbCW/YsJJAeAB
JIUhGOrlrWdtzcw7+Q9xwguCCzY+NtTsKGWb0qPCv3UjVmW7ux7mqynewJiAAMHAomVuLgDgb7IB
YdI2eJPRPt/K5Ao4w4UCnIPGYBIXHRCtcu7icGvBj2YX+IbYrpdhsNBPbHjbxP55xwuoyIrzSVbZ
kemh/sLOIWVpqe0+/m3Iy9bqSyMfKEbcTAHqeNRnRyEDj7YYeQltTjC4UE6KlDuAn7HO+QHnHJJG
0wpXv0ImOYYTsbEbETRs8JPd6qcaUIBUJySFnaid9M9MYQi2eave9ZLZr0AUzq51NVVr1D8+zD3w
JGDwc4jqcFH3TsiBsBl2VJB1OCugOvU4o8aiXyn28YaH89Yg+sweBs9Z6bsCvY23ihk/H3Z57yW9
PacQEb79peBXvvA5UWVDmLefCox7SKH71rgz0N4IPZbHggXGlP3dOC3lzVlmdGlMvbsyxPaCrPPc
MQe+2tM08LaQdn/otNdnKJ3jN8CtEuTELOYAP4h4bL8H7GZ2/Wo8M+B0CEo9gow6t22ILX7jpOq4
yxHg0+XSwTHOC57CuY1wjWWEVwTFLWR2SlhuvJJbWG+0E/H9IMGQGBIlQVZigyWNw0GSzY5zknn4
gAgRHQHTplY1xcLcpM4acnCCxGwgH5TKzYdWZs0p+KlNbzdxw28pxpPDeOW0cBVncREy7hHzAIbQ
slZNRf4I3l7y87aFunss1SaSFpuUPbXSLWeVPNWUkFFLD+g+25fkgzusW7Cjm9SdGIhrEQVGVDkJ
suMqIQSd9CQ/SqyMbb5++d92SP1vz+sm22CramH2zSTuGouOn+VoV4fT5uiLTPbcrbHUbN+JXN3W
h537o2PWICWYfhr5LNzFRsvQdRv82FWdzjDHakZezm1CTh6AkY4sIiXk2bVN5XlURN0ThpdVO2L1
sXoUYz/8PCSThTUygUc+zL5Z0OIJkjXC+SOWds6X+REd+9HTggI6hYegmKB3+PvlwodPpwfs0tlq
+daJQHyW+rMmKwcqfKUneq2JRN8UO/8C6dgLQmtpo5TYO1FyGFX4bnJi6dRU7qS+DonEf1DVmXMz
IZECHUvhMOLIrL1g07VdaiBR41llusMX90B4VwQIHIWuoDLwmuYzAGyaAmEaoDyVhUE4e9yQaE2r
nsqXLG==