<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvbWf1bP/HnU9A4nEi9fsH16nRvrQWY29P+u6ep7V6q1Iy2WWuSjtByhaPYB8oBY0/wd8a13
vFjrUZewuyI2cQNKeL3GwJG7v4wG+kOv+yJfBNI0Mki+Bt3XNF6N/OlX15RDukNRoxGX8Fcf4EVd
ui/qIeZDD1aV7mzuhS9Ha6BcC40C5nmmgFLTTvLHN65bAcVM24Ed3I8Zn7GScEh/k6lfLLwVrsY2
g8nLwVxYijf/BmUWdzioPNXkJVGtjecRK7dSw+bf5rxjsEZ1L4EK3FLilOfiLgeLOCYGp0UjxjYM
9ZKVNPiouupAerksjVRe2AOLE98YC0+s8YYTVo7y9U73PVxjSiL8O+jQWZ1xn+D0ziIer5zRk5Kx
23/LV20k1wZUJuGPvgGw/Z1mKgjnjy1TG/7She0XB9CIG0CZOn/w3fytKQ6FycwPELrRS/rJ7zfD
nKZMtzhJXILskv8B+wzRKyKrp/Bs6w/qeZ6Yol0lOzVPvvpmTVPKOWEZf29L66wG3BnDnvbpPHTz
3pQnqXvBxGLcKI45OqZgUOSFWo4YSK+bazRhyaUv7XW0+oAIaGThSQ65ljWRTNYtyDlCy8f5Gb5X
DhZR+NL//vDdJA9S+NERDD9MBzmuC2b8Qm1gKUb3Mx7Uidj5yQZmwKHdLFxuW5a3jtKx9kg9CfTr
L4BL4g0ocgmxa7t72dcHQceBeEmfHUhX3QOomKBQMaiQ2O12V00W6WAd0tKvUpqRcvrXkHYwSaKw
TvE9JLdn9/T7PCxNL5fd6fhskPfjtj1UTQdi4qW1xXjPdiHzyQVr0s9SJLbMm4B565wFP4Wf5xJv
YkV3shCjJy7EAFggUDAH8iMZ3njgP4RonmykvY2m0TnJldLdXEh1wojYugKbdGt+zLPbr88G2QIq
q0KsOwQjoe5tswKzxJrDCRAu6DYDe2QJ7l9Sucx3onPawQKRp72YZZttPvXVZz4IHW95h0rwO2G1
HXHQ1swnIggiHDs0VLOWPaPmlexi+zIyV/8kEdlYMF4zCHdwSXC1eT6mbIfKYyttPukcW3cN6NIE
RjvI1nY7GyX5WD8NHrhcppVUHObnNv+BR4HD0wpETaFbAxB0N0HAMGByno1wtaS8EqHPOBktCcHE
chBXCS7GrepJeu5aRNGHEI3hdgzTGrMEWj29FLP0tIENRfo4zfNEzfNcaeoZ5f34wCuWdnklUIeR
5X1BT5U9eTHj0NJsTm6BgmSQHNS6hnd4p0EKK0UT+nm6wTL16S10EnOOw4EWKzegXzKVlKbDELil
Rdh0lBl/m6OYWm==