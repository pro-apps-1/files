<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuv8JUXv1RRF18dOomaGNXbaMuPnoOtc2C4haCgYqPac6+2C1AnsuMkg0em2/LTzXU0Xn8uu
/zFGIY6qUalJgjgdyO9E5Va3HBsEW8XLyjXxSXkZ+Vx/kDQcKuLckgM1WOB4fuVziR8Z4Oq2rkRH
RgoAZ98ahe5KKKfWcbkfgkObhUTwzo0/XVo248hony4YoNTrpDtAodd0uLl9sNbr86MAMv+KBBfD
XswK0D/EhHjA9mjQOImjEHywkR/o1jZTLOkQ2LE+eC1wFN/A5vdpPPqqYK+aicuYLZkkdjMKUgRV
XQ91DnvyJVcVMlPViI/U7eOEFOkGfwB78e2twa5x8/laf4IzcSwvRN76+6iE5AjoOgQyefgqurd7
bsut4zIirRJ47rGOntE4ugwj3o5ETDSa4cX6SoTWoMFZmykbyIHIlN8hidXkNOhQEVbYYNyH+vG1
f56Uvphdwtba8aG+NuIdD9vE488a8TIBv0Tfk0uZw78i18ZGFkoUDvKW4buVLkhkbMMC6RmPb1n2
jhU/JRsI1K7xrqRRvl56LABzapIoimLewLy1OkEJGU9oMU9Gm2nH73XrcbJWL3LDPzwQGwPbJzBc
/1RmBvUVco5F6rNF2F4WYqofkCzMpgQVsRQLfBGX4xp9Oi/JPw5mhdgJFyOFPZIWMpSie0naTWD4
Hae61dMlg6PPesITnVut8mXuGVoTn/tqC9l+Us+G7ExD9k/JkNndCYYzwKw7z6ZvvXtmwRfa4SHx
MqDCllT7OfTi0H6DDnAF34sD8GN4cnac5BjrXeHZ6gmgjJEY8WhtjK0ORLJT8SgbqbR/WYyY2FpF
2z19C5PGQ8dtMbIGrFX6H6g018FQVLfSynbnz8Tq6KI3+EL/sBMAT1L7sp7ms9IFy1BM4R7gZLIi
JHWzBJy1HT5DV22MUZ0YlcFZy8PPkQneuE8WnTcFUktT+O15efhuKPZdI9bxTHXmo+i8tYxoGs4k
kenKZniPDnT3lDtmiVmgolKubbILWdheNfG2+3HXw7+XiYxamG0kFjz7e1XdGS3dJopE2WyGD78g
idu2z/jg+xGjl4A6l64CJflkiTgE/vUvHNquhTxZuoce8UjZwk5qnd6Xwqoda2PWg4tZyzgg5whS
Jl657SCzyN+rdHpk7RKDr2lD2q7UXfYJGDxHBC0oGZXmFrDax2HsuQZ9jCsBxyMKrc1/GM7dpBgQ
aTlb9opcf0xf6ir4N+fgTJD0kyUJ08TdtT+Nur1FXBgH4fMp1/cFyd7+T0A7s/Ya0t6iw0==