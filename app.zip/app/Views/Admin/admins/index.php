<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpwwXFm65ttpttiHtmqfn4A7aQFxrava0wIuxhnHIwyfx+IY+M7JHqCDf9XnTrflTKqKlova
TUP1lpBAEVyfIbrnPemgKgn6ZrcTcbBEJChf2Wt2x1+OSQv2p2IwFzZXI+EmEHDxAiKesBnkwx8h
KM+GE1prM+J3A7fhoy2WSXTBHoEOCN+CE2jVyNxFwf99hJSSwCIKNWKZq0UlPj73J3NVpdaBQevC
/Wc2sGHV7hHth80hnHwJL494gNIT3GgdQvQBjJZsJFEcll/GK0o4YwaYPQPcoSZZGW+WDH7rFAxb
O3TE/vCHawnNEhEv+I9jPq03oDL6wFgNwK7VXrvzfL8KOIefewWFo8f+l2I/XVZYt7HPTqM2S9IK
Svja/iC5rJvuNVnGdnaG3qUy1ujoHnqN8w13Y1AUh9vmm7/ZMdKK+ffGkPTiYyMWN/4b5yPILrkK
DqjcR+GJ4PW7FqP/UF80l2Yvv5q8qseurWluL1DbRWGkSnSbSulfcdIZAIa0+omveMrfOwfOjjzs
EvGLbFDZ3hAy7gbV9lAWyPtmbMNW0PGUsdnAU14uIEeU2wVT5OzEiTbf0SPLYAW4iXSDhnE8zKNw
+65o47Pb7ZUaPxE/FpwvlM0FjJsgpq7P+k7RFnJS5bPEJRtzaiyl9VT2XTv0aTTVr3HdSOH36SwI
eAr/FKj+2FIzythswdplKxwAqd4G7CXHk1K0J1LgS/5MWKV85RToP/Z7rCDdff8LlsDV+rRWbhql
iBIYgU94t0wvUovuKQ9kgeEepfCjLtfbvMSlV35rVUuRmnux4WzL+PYh4gDontOsswK0DNh83iSA
3HWxYKdxwbdhPgz4Ncr0RFn9/ST23VpqJs5Mq4hf8cT+rLEbfFOANS6MiK0rsFmn0ON0lht7pJbR
4Y+krP9pnZT25wkTyrBwPWp5ebBs3NbSmLMf+uuZaT7i9Dr/9Zevbz7Z+2ZLOFkHjlYw3Y4/SFsO
1sQtjhKd5ht2L/URLAoHbslR0tv/5yelskkp1uYtMP81RF7NHrQwgn3Ap98Mzb9GmXqwzVt7sOOM
rNHkyk991sWBqQPPULDNTXpRS3rB4H78jm2UtoU+hijRGZDs6MchQL9hQIZAqD+uxXku9Su9sBQ/
jpOc3rxIOPY6CQtk9alqsFKsDaLANT6IKaa1vFU2Chb3prx6uK+SzpDMbM+m2PCixtGWbeTEe8P5
IMsJUr2iFVKt9LGhd4qB+Bi+L0eP7EIR+y2mCrpfp0==