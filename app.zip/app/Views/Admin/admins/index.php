<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnWsNud8gwEkbVVAgbiftuzfEpsxfD/kwVQKZgSC6z8x1KlFH8kPXuj7C+J3U/0Ls6iTsfpE
hTVsaY0YrhPqtoc3iSsJWO5zKmjNy36OT0BJVPfZBIzBJENqQ0QJNjzxjR3rD31YiF2fiSN8E+an
w1UklXH5PetIepLt55dRR2g2HqKI8NpM6mvb+auShWP75tTDs7JjgOAEWfONIHEhidV5I/WiGvV2
TeaC1MA7TO0Zbn2Su2FpMHHzXIerpgge0Jsegtdcw3OBYl06iL2goSIbkbdIQ8dGo65FUV4vQCMS
Auzz62TELrjX1Hllo/SUmOXcv3NJtEm/C/ny4l7ms8TbKyzsqecaWtD16FQOiGN2feL4fSHeEeKD
zLOen5L+8btu9Q11ewSTHMzXgI5qw/hAsANibkjqRO86c2T3SXp4lz1sh5eW8QX2q8mnQHJ9RDbG
N+XWtKpIeewYitAPGfLAMyYAYzKrNh+2/cfIzhwPmunaSgReBK6m8HeRNtuhodkn9Xja9Sg4oOQ9
HwXbElzYK9TJsx7vLUeL92s3Djz/gp8WQlgh2Jblm5T+H60zD2nk3xymCFLngDxzkKT9Apw2gJvV
FpfmMXMXyJFIC2re5jR5Uq4KfjtZKnHVdkYAlFu49MGUbK9EpOr+m7xH2weFbHBPOIrZCNkwLl8j
lPJFQjA1jzjbG5F9idlJPrTlWhn+GBxCyhCwMOxwGoUrCt/YRXIzQeM6+uaq+E+hXmv85IQ0OIG2
vkb9NY6iBNUSt7WDW0b2dsnPAXsgFw7L6I2q/R20weMcX2FRLA5fuE/IX7pzHUguX8wZArsdr8FO
ncWUwje7MjfWfUlbCpi9myaKsWlLMp1leQzJ0EYfUFi/s8Uluf/txdt97HwUmE/WooL+0igMNLFJ
tjol3PwcH3wy3W42I88UoIif+Un7Mh9idjgIXSbG0AuGVceLd7O3X9GL8U+em1qwA37Yule5zESY
AhqN7qG86cp/wHUhf6/Ax+cbf3v0fCgbYThNsIhOaI416PNJ2dmqMsG+Nf+DxHuZFlC2V9e3IPJW
vgXj6+9L4G+L3DsMWwgyloDSQLiIlmWVQ2R2QIpP4/X0fjuPTCkfLFa8j/yNwOXTVHw6Y/O5kBi2
bo4GEnXOrFpbRnMMQUVRSiUkhBrkLTyFJNDANr/2MwTeE6jR78Q6P4LnEFjwknAzK5zJe0g4QLyH
OYgyYsyFatRcUKUxP3NYRkmmt6kk0f49UZ36+se5ck/GKakyBAbRfSWhPFv7QxhdPBji