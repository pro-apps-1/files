<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmtuWyl6LNZidpaMwF7yx5+ZjH4oNMfrghUu874tGfojhek/KvJbxZCZjHPdk5Puw/Mp385q
inyH1q0Y0rcvZUDxpoKOuyn8+NRC9Y7p5HJf6RMWJRtctOTe0pgta4A4YlxR7qRZtl1xZ/Wm+ASP
cNyv6K2ThOAthlNlJb8PfT6htCRxy3w+Ayk/KuSCKd4lnhI/nLSO9iiwLg3uhM41YUiuMqJcOlNL
/yBRQhc7sz11ybvdMojB/vOZfRfJHamaRXaUGXwzETahMeqc6ktl13TsVU1hbaqCLJVcukfK9GyW
9Rr7/vHolNR3JXYrsQ5gDK6ujZr7zL5WY+cyFmKEBs5PQo2q8IJ0KLoPwbi/GOmOR+dd6YwIL1TR
NwORyUoW1/TY4Tb6oidnVjcraV7SsscXn6gSWJIwI/bcUF+lxmHFgBQQQdAbe3gD26xaNT+VeNpy
qFoWNzPUGYfNVxLnrhNSM6OfglwnOpGGorkz/T3mo61KniJvcGunRH8ITgAQV9KXTPSonSHEiJ43
suRO2ca1kPWiu//gkAgG9A4w+L4apZl+++RZar5pyzGGDlcvVbZyEs6CiVjLrbL55TklKS/Sh7Pb
FhkVRk1LqveMC1oT7aV3goQft7u/oNBIP0Dy44zK82R/iqknlxGuDQssrYGPtpsQPTSfuk+mkM9g
vQ05XJLdpGYSQIAXOwnOA3bHlti5MUDBWnZBSgpZMYJOTumxx+BMYAWAh8/r2xBiCpWA1cDSUJ8j
LO+kG7qOeh5Ng/8sPwEO4am8aNPduwzxjedCuLOHrFrpwbJgWh6R+s3jzSDrn/y3r3c2+uJj6swP
6Q1Cm5Vgb60nXIrs53cHM3sRfy/qpxWwFax1bcEV3R0U0ubvGi3D6MRNuFcvXNdHsF36L3v1ox4+
AoF2bOo9SE+sSAOoKqifJ+pjvNYNiwwmPvAADNjyi4fGBM2Te9xVD9lYENfxN/wlWmVRUcagoS1M
hcybDyq1d/wFbktoNzL6405podmYnwsPc2mxgaCDXvE1/+bibKOmyIapJo3tX7C1GthMnWi8k0r/
u+VUQOcsEiYjt6ti8b+wNNHHfr8SED7H4KilAn2oUM++1tFE9sifN7w5/qT/QK7lxE/QSWiamSgi
Lilm/j7reyZjfcjAXcgg44pLHU80b8lzNt2bAvY2Zd67CjvMut9e/9etJob7q/tuBQk181HJnc4N
3pag6D8rrBrXU58GJ3uABTRGJy2Ay/wN9uBWYguqNZwMszpQFv9ohlPnAL8=