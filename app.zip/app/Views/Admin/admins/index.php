<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxzDePPG1XhPBOmqjJQKgWdogOh4qDLCAUy59Sy1obsxihbVzkuuVHPeSa8lpF2OlaFTIthl
pEGLxo1sDUAZvEHi+F5tK9NRxaTXuUfZ9zPINm1FhMj30UvQRufyeuz47AowZ8aRblMhOa6uBi+c
wu36Q1jjv5H5ZZUTJa6o+2dshnzjpmJKjAQnZAmlwEGGMXvxUaxw/74r8lCUzseBCcOdnBqqmzkP
dZUVEuUTNcwBe424syKbBA/Py04rjkgMyatyYI6+HKDwlyc45f7akKnv7pPTRRoCDeDXfrJn51d1
YUh5PVzTtlGW7LNOETKgYqCXjUfB2ID8PxNjJnIdSEzLRja7Km/Su8AtmC7Nin2J3xOVw0Ggqrgq
eL/xRkpj8Oq3Uf2veQeGIWaTomXqlxHv+JRBKIvT/goRardAyK/v/LaSyDAauwx9g8q5LNTIdPYJ
cHwy7FXFD5+hunh0rrYIgT8dHdsrWtfA40Tp2bqLIQQki3ryvGTWTB6+voALxFOiKPJTV61aw9Xj
poGQzOzrlxM9jqOxIArIYhxxFexxmtWi0DyL6oPS3860tGmGIjuxbAYqUlItpE042afvRu5uvX0Z
jb/l/Ur0D8+ydCEhrEwj0+gtf+Fhb6jv+/vRUqOOUK9n/xbpr1Zvj4+R2a+kZqogOD692sZ+fxPn
nKUqw6ZIbU+za1BSikKJ2STQQXDBwzOmg2+8I3fVq/Lo+EVONtF68UHM0+DfEoDMlx7toNwQV6L2
4Q7DxDZsQZwq2LN/zUUDg5Dx9ZZkZknfdxTE4/4E7bquXvjd9rC68lVPPa7fjtel6UKoQjFEAk+4
eaw/YbmLv98F+6tGwrCB/LGj2h7b4LQ3yCZhEoK5YQu2Pt8DZ3PExT9mW4ZIll2QVrVifoRw72Xm
hk3224K75SyZDCR/XtCpiBEESYFEl0fIjY2+roHOCd/IXcD9+pzQBhc7O+W1mUEm12dOk/g/TKhE
eotS87quM043YovKZINSK8iWDH7hf36s8jbq3jPhd3f+wJH8UbXKPd5g52PcX8BAALAta/xldyz0
+T1LU3wTzJEGjWn3LIioZh90kEHcxnF/YivcD0B+p+Wmw72/ysivb8bPBya7kMVG7fMLkBsjDCmG
vd1QQ8GV+vEhvRR/3kRjO7NKpKN+JAfsvm4Bb9nhVv/5NPGLDfRkzcu1dIUd5AKNb8DiPw55It1R
umi73+QCjfJpC2gyC4mqCa77rZOFepNJCgIBCvy1vpJz0lhmENFAgs5i98S=