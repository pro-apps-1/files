<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+u6fG6HsXqsRCSm8iCssjLUKhF6mSD8oOMu3Qkk48r0jUmggAbHmjtBWql1sM30k/cLErtU
1/UDGEuaNm89YEEsFT2jlbVeBmzv9KCUYwqi3/44JBsvZ4SQa5QyaSsLZWjAySSElN+Olmu7w/oz
8atvXSwBCGHgR2Uz/ROE3RnuplEzNaUr3RJ5z9NxTxnhyScMa9iF5V5HaiTi0sj6snT/mYIbgbNh
kSKwbjF2FJUXrcvF2eoc84e/G4dlcDsC9xiKXGmX8x4qZZJMw1YKFlZa7U9fDpgoDqxu5EQBf4Nh
07ii//zSsW5SzkLSWM0Weal7ltqDu4LjLlP/5R66lypf7tqbCrmIVWdpf7hnbb97UqfH3+ztayQ4
IsaLa8vquDIG4jGUKLVOXMAtmb0nR+0ryo+PE5WtQx49IFTY7NCCv/JbKOWakITBJ7NyPkYJPYxn
2E8FvbbZ1GjM7i1Bv07ak8N68/M4itwPbw9ZCyJX9pIEArMzYzXNQExSAv4eQcT5a8xdlQkl6T8B
m34CWnXPvZG8GX1PJPbasPgyMXmfRqzqOaB5A+qBAZJgxyuPClKGejzB57A0b5SfTVigsZqxe/OP
1h3ZEB6nccmwjj9IAwr3UmT5Wg93OC5Cixv89FcnMIMTjbONeSjYur2uw095g9jCkwx4raVWPGhj
GIi+S58ncHr2GSYvIuNqvgQWuVZvSXca7uPo2hLkVEXAkStO9Px1NjB1NXLdleIH+lzimdGqhCaF
gq1HqoCa4XAsa7sbYqtWZYiIo0aP3dVqPIsJt/kUpQqzOXr7wr2GgiRONuxP2VswZwehqwd3Hvcr
fQQZQziZx+N34Bgen6sBjQZqe8N+8M4qIcm0hvWpdm7JnWiXHJwlW51RzkM6grj7m5cqvgtn9cPw
1ERMN8aL2FoYUXeaPCaH/TiB0gqhWX1QOiY6lZ1PSKnIUM+BAd8C24DRVA23njHwNAXwuH/TBooO
nEGR7LTmVjhh+NP4Sajc4bU7nFyglofqdTEMoc//r35SjDr+7EUcaSsVaX0DP/VsZm7RBbEu2vpF
I+vutqduubKjrCE+oUTfxhydBR3Zh7lXPEO2AHpIPh7HnqXhUAM2IqS6sbPqDOp1gr+MtalMCT7V
h4DZ7FS2Q4aJ6Pm9AiaBRQb+wK8VjPR3IdzkY2Yh7+1YTl89r8DZKEeDxfCm0EYqC+0ZGQ2fRu4Z
d+zlcjNJ6rS2OZrRROQw9bvrbqhYamII2SoCRpWUx9EVhnFx9S/Lk+38akSkKR0PyAI0Wdm52hxj
R2ae