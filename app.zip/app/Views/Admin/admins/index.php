<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyLgiZLZvmOwUgid5Wtg+JtjOl6/Cq3CT8Eue62AqKUMNxnbW1XoEKNon20SWuBLJwoSKMpX
m0fgiqXQzLkDrjIqx4lzOD/SNAg/aiFyhTMS6P8QlTbYJo5h3KQgH5QSqGxw1ZtjdFKjqEEZiK88
gFQTvdWJrNozz4pSWlXBRSNj5YHj9+Ck6vktiIP6mb7FydA3S4DkVYJA233pifraj962SFRanfpb
dLarWF9Wmo3rwk1VqNSUpylzXwpXMhJIaOhaUqoPPhjLP//toGYqjdKiFe9o5/P6Ck6P07RkDs3a
CDmkwS1OriCQvfNIQuRAwJ2vRlISSBxCIl/1kAIlM+V87DD52Dol84ith4Zp3kWwgLLihxlbhYL9
zn8+M+5ojtWFTKmMTPivziVQYwb53V4PfWv5lyW3WfW1S4hDfddoFQD0DLuhgNDTR7wYV1fxYkLt
Zwpm2UAPnzAPAbpOlGyFHWsRddFpv6uiMv4hlvZ5ZZ86hiHAe3vGle3O78RLIMjBVch0xtQbGNMX
2C5PZ3Y3CZ7pkq4KW4OgSxDRibZyN8YZYBwg90dlec9o7OKxiXhXItqB09W7pkg5f82auJy4kWEM
+j8v+4VVGyIGZf445MjZsuk0C9zWS1+YvKoWQto5/2N+9WyQfVtIt0TyinZJPJSUGqiXH/45xh8R
xGg5AdAF0playd07hawK+ig0Zm2i3AFvfW6P9sG0ajmRNgp8yQbo1NhUBB6SOV5d1wr76ZJneb4l
xIiSzM8QZKMFn1kWjEHniU8paUjlsuJYrSQsce1zFa4GGjYpQl/KL1xNnTIR1xZX90enZJ5ezzB0
RVzV+eeniK5+vmNsWEbyd2VwfuWPQAK//apk9VsZvyU2sGx53BKosmRLiz1wt8qgSxzTai/Qaft8
9HBFtenPfWjKU2qaV/4P8pvDPm6GvUGbeXeJcp1W/7aBt0wsHrZ+MWWPEYHK3df4LBeiDNUvLarB
/Ui9C+b4XOptSoYkWZ+jLVMjxhoqiB83yuyq3C48ME0FYPhGnrroCSjrXqNK+tKKuzsfasm/i3bJ
VdUSzLhN1FG9Q9DDH4CLYkY+K8ySo/CzQRkvMZdBdi23srx4I4JeA2a+rTXKDJXSBKmQIGOJ9ANQ
kl2QoVRUen19EfwGlzd18WnGYhnoMdx48LgnevnrYyypwjRbez11GESbRTB74y+s1ThBsgVy1bd0
z524m90Ezr+g1KLXtCzbGi9+LecgrBV6JFCqzDRPGadHmLdyvyMvWWMMDmRdBhwjdvEO3Wmgty4B
aKvDlJTsAIm=