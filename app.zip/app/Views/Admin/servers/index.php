<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyJW6rmfVE2JD2AEVwwmBe4DTwiQhDZv/VTvQT5Sm37bd09behlCCP4+CD0fFdX4EYHmb5QG
ua7Tj23WYewUh/+H2eI6H9coZ/wAELH7QLXVOm6wzGAWWxn4uMsptgqmxavgoxr1gYzmrCdcK2M+
P0a+CQFqsBFYt0fKzOCifjQMYCRy97iRqlqR3mQZnPxHQ52JVQu+rleNWfs+x4HAxCaI2xX42ul1
/7NhLruRVjauJLt7XWUdtUrR8ZZo0k5pYyFSIj1e9/nnbSvHrf62DRiLEcyMRIaBGO1z0Re+j+xG
seGw96wnNvR0xFUUfqtvlrUniTXInDNHLbFI+0Pybj13ke7ulQ+t2aSz4eXL/yGtY0czJw4HEfyU
r8Y41QtZH+a1XkmWSMmTgTSwbOA8JPmmeis/DCWK+tTETFNlsPoo4K+NxC2z3KjaVBGZrPRO9wQs
L8GtKf2qopNJAAGJG2ZlHaoTv7ZoqKvw9BALkLEdKLbVsk4DQDq8YTDYH7xuiEM8dbUJxYABzS2H
Xfxc4yIQA9L9bnkXzuq1S8D9DylotssP7/I+5Wz3nKzI+BeJTpFEM56SxIpXaKQJqWNrAGQhHWul
DD5yCyliaIw6fRAJxwyory6PYwbUAKi/UqXcubDrk5jvbmnlolFxUWNhxoPlmMyqzosoL368aI7b
dcljJTzU+nTWUEGqTGkHqTCFbKY/g81iPcdVqj89fC9+uqRDY981vfrgnevwd0AhlZdF3ubO1hiV
lN87HHQSmzpKoQkP5+UWMIKoox93qX2qRZq3EgHzLOwijIZs6jpHwDAYNJSB2sxiXKhxW2QAkYbF
sbIddEPCPj0pTu3zcwfCCg++3wIG3it9FQj6/5tl57swDzKi8vzyn6VTsF3EVdmJgHhEdOZWwwKR
Jj2fUmQ0AbhnaisFz6Cii67ccOiJXE1x9OK7dX3Tl6tKzfhxiq8XgBtjXXn7+V7mr9htNOhbU4iV
/0w3unu7qfQ55LXVJGyS9idaNal1DhlS9/lWJcuOIPYPOaocPJr9YshdGuy+CU9s4cypNjP8kdAC
Y2vNH9/bOP4UfIqszQLmMojhPHQOcxlcy5RnIhNaP6IU48nb0AOF0zeYrurCv7jx1YAEtrDii0kh
sEX9YixDNmpl02QbIp0pATN0HvLs+NyZ9ISHyLkxtfEMDR7Pc8qSxPvkQy/4JnNB1AX2+vD2VkML
bC1iU1SBIAUQLRCaExdS9bOo7hRc1PobU1woj5spBer/5WTjLxg52QyDXehmmC8EptbrE1EbDxIB
7wLtNvWquWPJe9K1GTQHXjEmLFhOjJ+ok8Oudn/Fn9XOCB3MGNxsNeIOdpeL8A7mjQmRKLmqjDEz
p+mBQ1dnRHZ8AMMGm5vE3MDbSSCcO01jySZ1Ky549XT6s7HMR3jdc423dcdOv6ho3DA5oxGUPIVw
HaQXuoWaHmjYpjJqqHGz89NQ1a6g88aSxS3he4qbhOJQsWoymaHUxyNPkIaxnspajJV/gG0w2h0S
hujsBuenZRH6NiYw24LxZKK/tG6JgTucqv4Ky5gCa1rbRskuXgw4sz48