<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtYvwJB85z85bNjy4Kt72q4A9pxPbdWOTA6u6dkO9VEhVVXniClsJSbmfPNgBBUxVUUVr7jL
7lRgjen81CbR79kY+G0rlPqAWa3xroTEwTgifG0WuuQRb6EHIOQlEHEa/jQQqzU3juAiHWxphJd8
FzeG5B7ZcTsSPtFIX/7MjtSdYqBitUFb1iR8JYgaVTcNk85n8LEK2iPV4KEE1/7JygaIE+WYRpAQ
H4Dx/gjoDE1gvq4EyrXKw15T/77Q4CzeN+qK7nWRo2Rxs85Hakb8U5GQAnriBHt/j8q4T2o8JyAz
1daL/ymvxqz2KlQtbEO21ffufNMv7Sx+HQD64bmTluteMoWAaI+Re+INhqI+RX7kocF5jgNcLgxb
Rw6WTGVoxmWnZb7vB+YNIMiGvpulqYvxDylSCcD52k7U21vOvrp/cCQavPhg0ooeZosg2HBOX7Rm
izrttdB7Jg0nYwARtI6xtHyDum4Jy4nV4t505vM9ChOjdiN3Yis6fouJs74zw9Nq1ZTvo+ZxhsGO
MAQAUFLjpF2N0Ich0YalGM+EfR3HZnNCOH7EW5/Xh6Vl15Wg0f+A71DACjOJnj8ZBsmdjDwlu4it
35OdZOnGSRynoK8nIkPJ0sbNlZQxAO8j3iW5YtJRfmD3ob+oDEkU4VlsoEDuoNlpyM1FGG6As1Mh
UxLaR7sbkb2ULf0guBjh4NS+thJayIZDAjg3/rkVkwTdHbnmqdZuB7UOwuEXGrVao8nSYOLdetYu
mxAZx2GAgopo7WPv45RzJJSWEsnkqdyUyb38IdadXzWiV02VBFdq7Xp+IzEjmkRVENQElSvpaJMV
hqioWKVG6CBHrfuegNzaY9tBRfc33HCa02/MW9oTCEJN6w9GZ/fyxRTOGwkGDGAd7wVs4Z78Zh6h
gnUdaw5WFeDvKyf55gOXwdJ/RtKnQhIK2JbYVb7kHo0gdTbAOz7pbZNvw1LegdnvEEjHXYui5IYq
1OLLNwtRcXAkiDwlBwnvSXCeoG/FHTqMzk74IfpXCVuLyLZ0zAYRE7BKL3x9sxEWwxs5BomulY5z
zPMfmHS94CF+Vj5e0g8lV5UKqqyg+z/SrysDKl+Ugl3Bp+YRH41l/6ur1Xhs0ZQYzCfwU0k1zv7U
LzDQYF+2rlGE2Jy6MV8xKviosW/wxSfVKEQTTb1hYlpf7GD20K/XWcYAjCCmX2RUIR8prPRBny9x
IEjn07Fle8820jSApjBiZxrwKWE2vsmEQ6hS7ibsXZ5TSkkgNDJXja1ezwNHAAR9UNT48cifm04t
+Z3dhjbIktgZLU4F2YJ9ODbe4sb7V4cJP6wOW9f4ZuGChBMP11P0a8Q51zrjGsOsG9NSeEuZFWBb
uXSsPzm9RJ+ZzXjQ8JGkcw/vDLd8iE7/3hhxnT6X/PLBwgexxkqe9VY72ZZ/GLsp9vAIkQZMzucD
02HWWuLK2KDy3XL0qoXi1EgYDypAHE6vN767wm3Ebo55jLXEyVgT+d6DTVQ4gXcfLvfg3FSCAKIh
VB6bRKWUReb5pAILu1dQHCp/IBDsIU3fNA9jkRHk3xIHyrG1HVYpKktagm7WEQC=