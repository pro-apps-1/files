<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpl0Ub4od5zdomBlSfUNkEgC1QzG9/2aciC7I52yJJycBfIm+mwQBlejEGkhskRgvSg1/kf9
j/gLUJeiClFelEZwQWSnCpadvkZFXapwHBxlcggVHsrn0ZI9vcr4wl9Qpp9fFjrpgGI4jr1dfRf+
DLERpRMsNGKCkqHPPyWX63F2XQklwCxsfFvGcGgOGAbBEqqUtBP5ZZiPDI0Lac132eDiLUJKtWr4
TuekLFPQmTEFGmAMA1rEvdcsqSSXENkGTs927NAWOfiQetpwyoP6lnyxsQHhQ5frWkiKmScp8qaq
zcQW3td9lXy9TaEjpU3tfGevS7BT7+xewWz9f8VFmF5CJSv4kZ7vEjRyYcjoKq0lxIWoFUZjv45s
TGTV3fLMJoCYU5tGSEdUc5G2TLFMZ5MCftnLjR1SkPZAUNGnI/rhELEIhw555lKNIBbktyO1LX4z
rS7dSS6ER9ysCtyZZu5l2vqMzSnyWUohrvg3ZpbOKEgXZl53OBe3gaAusj7nu1JOdaipLdNs+B2j
zHAYgXTHBEfvO6Xf/QUo5j1pEP5Af7IJnPW67KoroLqLPI6Hw0ZkQX1ENH3wWBRN4Ne3rcSXc3yK
7abfS5pSGOM2fQa2MuZJ6uY5fV29MNNM41yunDuFHPIR2Wb2KbNNWtxoadzW/v6O7NLp6L6IypRJ
uLWV58d4bkbxqbzdEdCzQXVw8spTfHNh2LiZ4G4Jb6Jisy1n3qNV+qDPtI0rV0sGmuZc8FCUiu41
xgzWrRUFBaULOXK+M9eLhXZGWi57pTw2+mwD3UWE0KiaEK7LloTLiB4LrF1dIFTpWsQjlUtPslUz
5r3uCSr/hK+fXCiM8wmC1uhcRpM1QlL8Nj+NxOmxfFQjDtgcghbMgNQd2cSmqzbIJK03kCmCX5km
xEm6vWNNODaQXZS0CvCXjIs6FNy2V4/IDi98UPXu8rVzAIj+Nt0aHqIDjC/Sf6ZbWxX21d6sfUHR
QAFm/O2Z5TxFurvQveLhn3gPL/djSg5B5h6zp5eNoXfmmayzaTtHLr/2z/4+gYspPwyxyurbaxwC
DPMkUwwefbsR8gkvIbR7jSXJcM9gqpv8k7hMKt6YjQzsOYWK5Sld3FvKCl+IB6K5spUdU1YNEHOG
qTSa2+xkOCQZurmg7jSFetR84JY+vPnsRopJ5kXpC4rN6y9L59nbIPOOxkXxj2KdMG6rU06Cy2q4
cfDAPMGqMMy9z2MU+USe/xQtmxiKyUepTmyLfZYe2nZlOGKgbiv31lze90WSe+WN9F6tDen+4Ra7
bTcPSk4xKCO35CrTHqrfqLL3GxEqELR6p/oAQiVSoU3VlJZ69cTC8G/Ru3SbzE7/EfwBYQN9m/8O
JRfLMT5W4wATFKZfEhUlMxYKG922WEmNXv87c6CCblm+HYomsOCoiNsZpt8HgbvVjGrP5RsBH2s2
MNRd6mG9oT8SfmSXWFxM8IrgxGTCvn/qdoFSkVbVKO7Xk0D2B9IVqPPFC6OV346JmKNcZKpUDwYq
YYCztsaB6DZt2o/ZUYuwejzs8X1O7+X9uOQFcTUallfr5YFrIxKFpjeS