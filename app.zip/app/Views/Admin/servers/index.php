<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnMxrjySE2iGsMP3/FbI4+j5wREf97nOI8+uTEZ9Wl6oV0jA31Vt4skrrvtwbts6igKV5iid
SbpBiugx0PHrZdJI+EKYmgz1HsyLeYy6phwPQfybIQ0d9q4xbAoHzJ4LliSsPQ0TI2sAK8qE5Kc5
I96CCVSFboExXhwpwfdJJH/Hplx6nHBSEz3crTCc3W83ztLiW183beUCn1uO7PSXy/ShWTlxn+cy
m38LZOhoXzEUpqgIwu+Ls0pM15/xQuRhob8lzdiIHdElA4AIKOIlrzpiUrvgt06N9AoOpSiM/4Zs
IoKV/orldDR5ueSeEc2AHO3gvc2oxflWjxJZGoHHQgdU47jU0/e/e4tuj/r/UExMIfPRLBno7lgn
j0JGikmQ6jNEefVuv+SctzDmW591nL3YZsOPyysLP41J1M4Fewoqpd5XOJzER2qY60oQnBsY4nLl
GXfSol2tWGTOz3VaXCtdnWptC670J8+m2a648uklzvFEW/0mIxKUuotoElYZ4rm7SWi6rdz/jGIS
ZrnuYsWYSPFM/l+ypKSJwoGhlhGX/4UrckzeZietl3i0sj0rys0SlcD2FelhExthvsaomB/Ty0/J
V9v2C1xBUFft3RGUeszu5miuJaxSjNarvKj6Cs2G/7w4lFX2QI+QtBdBy5RM9vifcMSfz7dXgA08
XXSKDuiStR1Kt3wTe/Q1nwk/YVDGooCDmMogVdr7jPZX6DpUPNdC+Bg7Mg4jSwjLR/oX/zaO2Ygr
0mhkVFQ1kj33GJ97PMfSThec30078jX+yJcTiOaVmKE2qSyfFtxzt6QJtYyfCIbEKO1XdXmQK0QJ
QS1duw+P2sUEtERjPHUYlgIpV/IXI7T6HHVfb5DNkgKwV8d4xhz3p4JpuUKNKPmwXKv3UBB2b8hv
/9PSKGeO+kYAFUzV7hhoPg24ifbLcjmt28MyrVPNFzjUbprC82z4JbPhJPnjKGp9MRgu7ABRNJwz
5mR4gb70OxQdZFM1UlzJjuDLL3xKxBjDXnY5O4mdSvabzeDM6nXC3ITL7S9wcoGLQ/Gim/IscEiR
85s5AxLYLrk8lmqoVGfaYaUVP0BJqAn3YJjBnBVrYsPo2JiEDKIU/uzqGr+yZlUt9E6cgsZrSQcm
d4OpuzZ6V4jJr/1GqFHBtj3AKTKhHJs41sMsSUX5LOJr/tB6cK/2ceP+rieDjh0kkicDMTMsMOcM
fxEXaiUIme9uhGFqi57A/uz0CIXcxvN6GPxRlkxsr8D3z9y7cyjEHL8N2yoDWZ4Y50qQi6XehQcD
5hwS4MkeLyxDSnLPFtWbZ5BgjgLLTi0HtXyJu70TpbBKWgDRrDN6eHSR8iK86zcRi/8kei0UXs03
E3G9WTdb6iQRz+BIfmN5ywp3QKoR4628sKhNGxacr+D9fruVAODpjJ3LYJlIX5MSspgYse5hR0fm
TMGzC6PxvIND6Q/LHowh/2m9LQvpVydyY+T1LRny8eU/Vpsq214SPcomdroV93HNOQQNwS3ekyU4
tMSa9VhUlJ1+TeuZ2j18j1IjJHeu1/pNw5u606RM1bdsREKrY1FD8J7FvAIP2e1JPbFJX0tT1rJ2
8y7osGZyOiBu7GLGsJGBQ+qLYY+zV/DJaidSi2wZStez0V5Hn5627G7pSbvOdfCYmaxkOYJpRurM
IIAhkC+6KZxveN8m4k5kOs+gEaHjL74FBep8UPWf4UxX2FdFUyp3/8/mggD9JJPI9SI1DJ7NwbAj
/KHqZTJ/8r4edfKOvy/QlwqG85g9swMG8LsEmE5Y/R+hDHAnd6WOcDYlQ2eLgtqLcreDA6Ahv8Un
a47yTvdlRYkdauXALyjpWOGU2v5O4c7AkzdK7YaLvng/6hIWjGbr/9t0x/Xy1q8c7fr3KNhuHQfy
OoShG3O7co7qCyCd4Edt9SGVtKaED6UJytZ/g9ScX36sA7l8c8hZLzubCoMkH0sXIY35oAtTmCIz
mwIK1UffDrm7seN3VAyBB4QlIESZ24xtaA2ZK249utHXiFVFcgXXmYBX/tda21iSdhFdP/ylBzhB
+/2zQp2VFLx+hMNJgpxrmr1jmtb64VkBGHkI6/BpxDC8poO9C9X2GPAZI/Mlo2U6UW4WuvAqDAoX
OxlAdMSrioS7qciT50mzq1w9A5aP9tnIgOOPA9AO0UIZ1nEk4+IoMSq4ATlr6SWtAJLbXjFPDzTK
OTzKQgg5Mcng1uTNPz0xSLHzsi4MguB9KDceq7UW6dJJu3QKdk91zD3J/UogUmQQri9t9SAcblY1
A5jShgB/51nK4kIv+qTrlE0svH0OiTA4SHHlM5Z+jU5VEEIYPktzMqzHAPQXyz7acJjXWe3WROa4
AhrVB+wIAlm5Hlwb5Bwq1O44fdpsdK0IVJuIRblsasZvUqVQyFlYsEqwJQcNFr1mdLoQrCzP/78b
p6Mjsaxu7hsb/Kthk5p2ATk0D2OAgnHD+nfKVau0Ogt+PcDsDyLIEj7XBO21D9gvZUJKy1w/KyB6
IFItS6TrOhOLUzOFqebCr9pzJVBXf2MgWdpSckf+PBFVzf/Ch+fLsbK=