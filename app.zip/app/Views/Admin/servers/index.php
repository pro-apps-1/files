<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvf12ScUyV7kPvoSwfD092ROQEaNV6vONz2aKsvEusq7/hu6PKeisRTxohnZcHZVfkbOdCp9
PptcozhrwSYk+InYzznAx9I/NTHYuHmoIQzeLwy0jyM3Zb5qL1TuzrAO0x6U88IWe8+KmTdHuEYV
vUeJCWd7QlPZIXVQ0QdZUKdWzlcgxTYJO8D9sUhlF+ARH6r4FRgrSg4/bHuL2BtaXS4F50bwsDgx
1lfDN0vqyGLegks22haXvFWlR3Jai46C4thM848UlJdPArgD9XhjxmGtTdsERv833Wl2B2D7INWF
e4wv1VwB6YT0w+mAiYpfZrAegrVlVTgg8mWuJ9H1bbhoiZ4/EV1i2CWlezKJiWJk6fCKlxYNo4cF
x1oJ0/h26ryB7kV2zXyM316WKj+ux25l2I2gCdUtCqyw2yMmkj2xZBC55NCFrgBSZYs4DObPANn9
K89Hhz+XxuoS1wUyWFU9tQMN+I4HeFzxSX1VzzPIFGkkqlUILKdAuBj0tF697GYlV9IUzah9wYx0
ZsMIUwUzWSww4OOSmpO5mCt5wKwresq9APpn3inrmlCxnacq1ShFkOPqGOlXIDJ09LCR0Ge8G5I3
A2vfKYd4T603nUjUgZXwI+A/5lb0db9lc/NwJ0eSceNw60dBdkfZ8gBpcMUOa4PUME4lkhABf7R6
Z9XaGl3NhnpjfZIwJNi9/hguqNdsEKaNuGvy+kMtsSGqWzYRLYE9G2U8Sf3DAL7diOzE1AzPRrk5
YaJN2u1hRA9NyvBHDphbtaSqg17LkhBitjhyNePi4vRLbuSZx++P5hVxXViS9TwKKiY6pYy7iAWh
6+Y7T6DPdjXCgJjxzbphdkmP93JH2LmUBqB+2SZW/YZO6MLd7uMn/P0RafnGEU5SIEuWdvOqgT0O
eV2IbW094wycQHhHa0U/bYSN90s3GVKnYIw42fzzgYJdpW+pgvzGoNHFBU4Qk4CD0rxLvBJSgcEA
6e7ETI8Mfqqa7Xa4QtffHzdF/TfUBZHFmSiUC0UrWPktWjy7V0TxccbW9e11BW0kU2bEMeS+RZ9Y
D5+qZE7fn2UZZarogw5a5ikcJPFK4Ti84Fi7CKleV0vRxwWbzXIXr4VJ0kq1P1CqB1alwyRk+cCT
N7tzDbGiX90RJLg0Q1kw/+XkPIjV3IhbL9H/DqtB3GViS+ADZFtm7Ly1aTYYE7cjYLuNlBJa2+4i
CopfaPwtzamKZ+Fsd0W8SJt8afzLqZj2zu8hFunac/44HOHGbQRjXmm7R4tRcTJPL+JsdTFcCIxu
iVrFC8e0/J8uT38JhnDJMhar+N83aJsmmJ4i9Bzm9iMi/9DEuesED3TmjAylALTG+qYbUokoa2+e
5vzyJdBqup1OJMjsou0bnNNBplYVbxti5BgN20v72cdwOllHRD/rw5R1+Bcwb0AWadjkKlNXKViM
BeWWVzqfDfMpsSigtYgN51MkVr7oHjQ9IeQRVvVtOoo32Zdj/vQl+gzFinMd+FzzW9DL6ugqrQOb
mumr7BaKsvHJjMUllc3bGu2JlFfwgVxp2V1C4nIsP+O2f7U0B5jYvlHuB3eChUtuYk7Avx07b5rZ
eJXZzViTosgFaSs5ObD3TQpoL0nIHeD0dwbP49DM5AvxTrjV4JwgKdrKIc3GzuQ8JRA37zp4elbk
frM/yuQ0pCENPFxTHqaO/ZhZPMS6Hl6AhjAKtKvW5sP4eBA4eYkIMQLKhLBRcMv/6hBm1e6jQKya
R0ACb9D73wcTSB+lO2SXufWzSV4dgr+Hm2T/j6/XIEjmuPlaPWi4YBgA1X1dW3SV4VxcduHsk8q3
vKdua0TNXvLtUGwuSAX1+MIS/7dOY/Ixzb0Yyevk5k4bFbMHxNqZfZ/OTe3GbVMddPTD+JaiGXkb
8Nm9NH3IOstIMZhRSb4SAATcTdBj44h55E/WEkwHGOFp0Y4PuDMe0lGWXLA6YE46ZQn8+7x4SYK0
/WmWdV2OT1cOduAlRHQnMyhmIQqL/ivmiuxJI/AnASuvXWOjXlyJ3H5EgN2wTEhqFS9imIGxfT19
zDDi3pEPdtgyLq8TT49YrQ85rnNR92ZCnLzi/nwfPmARhMEtN7bpxZV9goYdy4eTdc0Qz9O/dwYN
c9MwT7I5x/Gt1FoPXFy+XO6q39CUn+DdLUHZOVZNvFCb8OjZx3KAiAw42KLd0d3MsmtO5cn3QI71
klCJUpNZc4A7J2vcrP5KB7yt8YRjuZEgI5fSMVpZtMzKCAN33/ofTjAGMVJiOdc/a9jcJ5cu7YRb
D6pz+pw1CrMXINwmP1avS8MDnobbhQSeeqi4/WSwKXLyhWjfbtCMIiI6BVBwXtjaMiExCQGnt/K/
ySGSoXRt47sZqB0cpX3a+99yx5PF0AWstrZTYIn07r5oLnjifbMkpIhud+nAMuNTKpifYedVZBzH
v8YvFHl5QhRRuJFn1LAjyUSA6yJycj9prWhf5wY60BPr2SsXH8p+8KMlLTlR9Wtcv5u7qVJsEibt
mBDA1swe6rZ6e3hIjVTMaH4FzujhJQpPwHNhvgjUBDjG6yzAfWfXL5Q3aaVAXW2dnGgYtoUxaawf
+m==