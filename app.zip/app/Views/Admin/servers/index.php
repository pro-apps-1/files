<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvj2NS1D7wRt28F8uqd1LtbCfGCEyxsn/gguh2OeOTeUrGac6EKZ9DbUMiUuCTtFFzJM5TQh
Qj0QgnfVQY94uWODZXHUAhh0ImxQ8l/462APH3rWNa06Wrmjk1qBi4d9VQLwLnf8MKa7vea9h7/u
NY+V80/dwAfhmoVbOfsIxE/dDBnBAy9/++GFvsG7/jJ1cPYeUx8N7tnPQHstIz2d5T95UftJnhkN
WtezPk94r4h2FjftTAqFiZTJPVZaPJ7TXnW2jJZsJFEcll/GK0o4YwaYPOLcdJDGE41rJLqlQwvb
PpS217hMQFM2qm7wh+gL6z4YuQnacyaRBuYjbMY7HWg2pYl/hrqqJi1PDDyABnzVLMIkYwGefY9T
zGqAeK80kX6GH/vq2Q4XjpfTm2IS7n//cN8gdeYv8s8iQZAbGOSqQi7oZ/C6TPQNCEKRe8ooJSxz
alctdsE7dJ6V4nhNEN1DQu55ovSxL7/q8JwFamYl7ng3CVfqeiLzvDchMV1ukLezr55inmt3YMn5
tsZ82KsmhIhcaNxfN9QbMlpl9QPLVHxgMhWnWkXv1ySJuvqOK7pW/99ZSEzja3DHLPPxw83vgLJ/
kF6HGfJc1EOds75U0ByCEhCqxSDtE0fvGY7Kt4vXDBx/+od/Y5/X4GyJH0ACdrFx3N8HRwVYFxNj
TUaVIxwNQDCdqDb0UClmlGxEj8qsTXPdVtQ4mtTlQNW4JhoDip19ld4U7QrvNItaRWE+Z2prGmbc
BSFubaQJhZVKly9zl5+3+8GlytO2mOhGyN4MVo3eG+7AXAGLfEqHom/qfnHouVr6mh0R2XCgUs+h
jmEjOKssW6k7eaTUnCUGYwJR+rLLryZVHlRudghoHNo18HYZDn3yl8i7TdIGabZmHcrT/mQietrz
q38wrcbeQQItQREmm0/y1bHQO0guRIH7hWFH+DXXTynru49rTyYoQ8GA8QpFCbBGB8qUwF3ZrhR4
WptX43XqK3XRhdYOiGKNKKi7IRk+UX83sYXB74vOeZISLGjD6X2dxd2Cb9nBWDIog/pu7Kjo/L3U
u7XLIkEeYf1N8XhilNA9Eo5BWDf/c6GLjC2ZBMcbrheJGpaCX88pBt7oexiD0hx3Qf8qelAs/XU+
GEI4usF0IOl7JLEnTwt4I6vMwE+8Ktbw9EniLpzjlN33O2Bd0ockd1LExsy+XD9Neme5hlkx07qa
HWLOkMB5h/TvQUopox1szqPuFVrkFrf3h9oYpQOT8xH9iQE2wfx0VAZBPWMB