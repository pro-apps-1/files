<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoYGkgKUGH+AvqqlXdpElCoouicF827h3jEYBTfAmoN/2xsX5pLj0CUI661mTwmF5OgAWw02
7IRcLM2PV4TSXwDwIzXAwg1l1hIRQ/Qj64Zqga9DTee8j54GjyBKl97zLzF5PnKw3sPkFGXdsnk6
0njmDi08Ct2xmmVN6pNIHz5BRXIzpTbeKsTmctmXWsRweM9SITHLS2K3c+3JTRXDPG7W3zjK2wnN
27svtsPhTSPLaiAJJAjZSb0ixSnCZHNMLtFXGYpoY3b7mRaD5DgPUrjRXWK1OZt16tYRqM1okeWU
zzkbV4lxHK7HwYbft2E3MqPoSoMrRulwefCJr179886TV7iBiIWEg2J60W8dLBp2Qr9KQkn4nrK7
1BgdSNErZbK/t47enkCJYrPqzX/CTKES552pQNRDsAynBPGxyTu8JZThJNnTDW30O+iUhoh/A41a
MXwJa9IztAormOPR6/p5VuqishZNIKiTxT1rSed+ZSuQ4EvyDAGE6CioRn+j+7M55u4zrqjtXvbB
Ssjqn2ZjcmwAC+6cyoyZLMZgop6Ev1/ni7a58C+0te/PjGORPqv2m11z5VYPuDeW0/JdPPZMeFHk
HQQn68ywnE0+PNGY7UqXygIbY8Hbj36uh463U+aBDgD50buKkc3SQa4/Y4wZC76fIYd0dqYgIv66
9KTHE9YyY8Zif2ql9Oqmkut8o2fdU8qv5EFGpeILZ0a0tg9W6NjPpSHQh9k6XjE+sYz4C1ig+W0l
KlcmZy2mS7TnZ0mkfhPbJ+8SsA5FciXHm5iC2i+HDkn28KQ2IjNaj+ubCBiXC++HKNVwoCHbbfhF
eSScu3U5fcv6pg7YHBS/WjV0hQB9L5A4fmXqKEwl6QscpKzdHeKswmeNKp4rVTLp0zR3P9IvE4J6
f9J2T9XEVWCtSBruG3FmtnwSQcAgTfvRjkXt7/iGLmqkwuv0GyvY/9uboeEUPELXDghn/bM8UOnI
8kqibYg9OMebJGpjrsinS9S3GgRFALi8BYAshjYMh20eTilqu9HF01x5RtANKYdh/HuULEMety5z
He2I7CXpLHaprRqQEEp0gZjCxmLIzSrdpmadsFg5Ot7lytN61yOa2OoqF/rla90waoAe3w75j7D7
yZTDa29ncyl0zaYi4zZnziUjdIzrg1e1f6ldGepQb9q/y7aeHOrkijKVeRTdmH6scd/1We4HqY16
keZMeC26LgfYsXkWE2ANwumU0/rr3DsKX35m0I4LH8iWkJvwt2r7YZVgZp+lDrxmIMC4k0bLnylQ
Szly/d3fhMzpYig+4xDh3ClG7HuXZ80o0kCsaWLI3iNgC8z4CZcNBCy0ixSMGc4A4T2Em39Imv8w
DrqN2IvRgSgLP3GYaERzN5ka4tRFss7ujAsIEBC4dM/mVMzshpSqJhDjuvzBUdmsARdPLURcw9kp
Gdsvx72ACtzQjz8XQ5cKm/XzTDWjKjpxTgD237LmWi5ddQIbEUvyokFOD23UH2hPO5L+5JQ2QkCI
Ar1kG5fUpVkqNVagb4DgZaE1WZU88iM8c0JP3CfLD0jvxzCqbE2Losx09brI/3EkmixM5l+B8f35
MO3IUICXDMp/eaMFwQL78IrmDfc0LjYgdu6PNX3qziim/xpiWJqxgOTtu3IP5BIqOoPxKnlZ49R6
h2qHC5g0S7atU0wROnzQ3FC0dJe0BkkZLRQCLbHouF0J032yb6EMGy1wCKW+4mR7KuQM2UyPQHij
SO1v7lyY9aRIjQQ0SdVGb1TLagJtBywxNdMTf9Dv6k/eDrOdqieGjZQwvJtcR686HVLdMF28Lobg
Rd0ngucH1zZgSh5bbJMxXpcNgPIIitREDBOUJWTEIdfb3VP9gFRBd44IM/eXVOzmAdNkqI2z/ciF
4DEa3Mx3cEAPKok3I2VVd7Clxzc5RB1z6hBzSg+64X8aD7fnr3EPG5GBZTONzyyIOnqWRFR4LnXj
Hw4f8zzmPFxrQ7rdNDHJkBYis/QXvinyc6tC3QyI4aKXR9jZSJtTElmcOUxhZG+WrIJ1iNN/bllo
8zoZXuCtYZb7nIx4G8gE3gTc618C5yECEffC6UOKFlL59hZ/MCVTMEH7z2zDliwGWSc/MH+TeXUC
WF/9v65h/27G8PeZtRjXJL3KZ0dzFGy4c36grL4Q55zRf5kwmhVHDSc2CDeluzq9jZqUK/k38SSh
OOkTWw8tWX6f0MjGUtCmDO0Y2DXUNdenfIK3UEobUqVgXa16ChK5LlY5NoZ0sVzqGsLGmvEazsIp
pTfe7kHP1aW9qtTgazkQnpUpwk/FiUSHZsbHcA73Ap3feV8qOc/BfNJ9n6NmhRqSRyRBT02aum0P
pPVs00xZn01m+ILail7qd4YY3noODshA17jAE9R7FylbWOhGcTdXYBZNgN45mnZsaoboHwwsffWU
5t+OjDEfUirKaecuZuqk7BhK0+HvYLrK5eIezRUuqB8CSrT3ZLdTOai1p7gS57Aqx40eeRs21zmq
K2Y19lDKiE9wJhFPRCuI2DPQMShLxeGQOwfSx64f+l4/3eckKZeCtm==