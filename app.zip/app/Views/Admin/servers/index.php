<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzmCd8fopMIj2z49gN6R2qUwhaePfPIwYjE2zH9G0PMe6+VJTPErhVbf/0BJfsX6ne5Cv+43
3ma7edxoVNJhNHpRb5q3oNMKxZ55BUDwc5ZbcOEf9d0ELVGzLAGCqsHWCM2EcwhBb4OnTjIfH+6z
8G78te1dbPXVsvw7zk6LueHCrw94TTFN+1X7w0tH/v0ituRbJQ0318HXFMcwdeervp/8Ui12zSVW
zU5pZR7p8F3ItZdFOcHZ98UwwrqV1IattIpyLbRsZL3HKx83E6zV6oB3Cge6RMS2iXSVerV3BVb1
cIevTwsBtUTJ3WSwuOAjTKjSeZIyJZ6iwczsG2pDnLzqGvQ8WlnXJtF51Lg4RbQf5C3Il9MDoiS9
q7NM4yVRdnzBIe3irQfU6giZzDP/FTuAkM4UIisSx5UL94m85z5QD5A7jvdbQaXA3tsmAoIxtx+x
a1+L2d7EyA1X3MBmBooaahEp/IhIt83+WGr6IgvAcmVL2UF70O3nz0Gh0f+YHR9PWpNfnImuSfhn
vdkUW21VefTnUr6SMm+v5hXa32VweKWBczGVMxMdc7+6frPRJCS4BQUsIYeLcWJFezGZZ9PEM+38
58CG9GfuFpPq03A5brKD7CweGsa6cT44eZHqFzk9k7vJxR9vGviLjZ3xf5zGKZ25WKRCvQknUUZw
x6IKK/nM8PdaQw1s6ecmuN6Kvz4fBwR+jeDuFpG1UsFWhHec9LITWsnEf5KuE8QP8Y90R2fSoqcj
qwAvBg2cuMU/nf/26HePFgeLe8Frmiy0d45Jor3TwcfOHlhVZ6IqdYk0couzOuplTUkuTMX+/HLd
VeB4V7gCfZjMaP2HBDEcDWTvDoJB5I/tb4pVo+w3NlD/vzwl2OqzOZ3M4OqJXZVLHGqqTlVcrTVH
f2fsO5WH7q6NnEeWXNSB+rdvJrGr0Z+dKT9IIsgmQTNmM1PX429veyQuZgK9cmtYLBMFvo5+JRui
dnRR+dHczNCaYUg5pn//5wLsoDr4042uWCMsGofdQQSEE5kOOnvd8TchgPvqDbZKy49klXSxZq05
a0S05Rtgd6ZhzP/LfmBbieO32cDjwGFauXNMW2+vSCwber+C+D9SxDamVi16FREco+a8Hqc5dssl
E53aCHUds8TngLJ7fMCcifMqqZwddYicZD/FPM8E9GZj7qp2sZSjV2efzuN6l5rsQidyE5EbN5ju
m4KqqTXXTZxYJsthUL2TEiYWNUdAsLQp56NjUUt9QwWgkKD5XjbxreJAG/qqhntjlJ9Fl7IcEGXY
IAl3bEcU///Br3hvOyYXW25J9sTQos8Ep0YX0I6FWzVUQ/pav5AfD+o6LFyhiwmQgzuADu2c1G4p
pON9fKe8aoyjnmKgGA018BMJOEKav8d4ZqhX7xdg0jFNr+Z8t/WJPumz7K7n1LySxySdYOKLa4d9
irXqc860810O0jWEBC6K+h+pofG4VXUAMblQbqDYL5Bs10p26O3C40wpr6a1qAsBJBKMiHzHPWm+
EoJkZU3IOybw0nXPMXMd3Q2RZdFe0r5cG0VykHwzaZ0mHbicUX3FGoOoPYIMMlEog8xHg5AaRxm0
GVirta1is05whYDQw6ce1NpyYAGfG587MLBx58u2QvQ+cCBPbgQqmqovGLOsYivLvO6Dxcv7rwvm
PwCDRTKpdrYPccOSdZ43sNt2fp9ME/AXPIb6748/AMuIl4KFupUDlF30fic3NMhoXhCHV8JHa0Mg
+32UywSLiQ+aotfoWEzDDFg3sLM4PxZ6RzohVpsRO17CywRx4ubBYCBi/E1PDd1ZN+QACA6jmv6S
nyhRT1epkruXiWrVSm2Yaw5nw9hTvD8DFJivzEHzRWz4ut5T5NlHKo893S+SwKtLKSSXmxgArCBQ
BljGN8AIAhYR9e70Y9w9HucmpEyvYLp8GnZt1qOSlwF1EQsna5hWnNQpqZj7qJ3ebmS29RL28GGq
5v4jIpg3enC9gHwuWqAIMemGavD86u8w7hJCGyq1BUnGMy4JeV7VyI8r4nyDWv9/hHR/0VQaCrM8
3AN/71ZMtmSkpY3P2YnIFULDnyf4ku1huHpwCrd6SZeOH10MwDYvaNwWWJDzG76eov6OGvaSBI+/
ayd1BnrxWe3l/vVCRkQe7rHcKASKbZtPyVfAHaTwk52++ERrxqLHSur54Z4cMLifcpdqrJEm6QVT
qhlfIORxlzuYwzN8aVU/lb4xLrlbgkReu5kdQxIgWkXXeBlWJnTHO/BZcDttteJoz9zWZbldHvKt
r9yPdsmqQBGrXW3og8VaGqKqE4qUBhJIPMG69RQOHu96nkO91MHcadwEwInmLfLeBUvVl0cdIjOB
IkWakAlbfm0HmG8BF+esteBuP+P5C20E1u3GmCHzkUBemCFF9BM48R66bxRPdoQ+rXfkcxeWEf25
5LAPQCg5t6OCPcSnPm98TMN7jpJhGdpFpRvbYGM92PHqvw/2SR0d8RoQWJ5rBKvad99mNukdjc3P
va+Eo3JTBlw+3ItN4jcui1/2TCodjVdcQxIDjzOx+E4=