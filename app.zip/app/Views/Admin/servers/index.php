<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuFlm2HkOJaBTorL1m5fRe+42FEIkBV6vAEuk8q0QtxBbWANFJ7AT2r7r0jO6VEfevK4hHTX
o8ucnOtOA0eP5UZNBz9F68jaovIaiOg9hHRSbRecBO33M9qxuytUEnJfRolnmpkCrTae9xgJDBlv
cQLAZsyeBHmMkkyTcI7t/iBh1wKqT1BcA3kQ/LkQzfCGA5c6ckJaYJZzPxhc/MGO5ukrcTVHnilo
lYFsVsh9FfSijGGC65DhwidzHzDlp1Tn39NCUUReDWkAy0QnKAh9nAMwMNjgGa7xh/mW/lkw9Pmh
zte+3tmVzsjAdmgySdktv1brdvvVAky/1vngxjReqsPtaYYU+0fzOcnyMm9kEFhYRynhpehlEb03
k4XyipfJrvUNJZVpdI6BCt24/YhrySCHWnOZMswekgMzREsWOcCxcIPBofmjaEkjK6WZczXoGDBO
PZyUGZ90AJzMx0E/3r4lG/cwKD1sT/nsqvRnDCQLzt+KuxkkG38uNY+C5ZuTE72sIWrlNYfTUUS3
jzlcW6zmpq+s3htgDigM9v2QOis7mK0YO04MeIxzWrSO0HAM3t2HkagB8jGffUPTJh1DtmYT5hcQ
bMjDVdUlcVTCElNE+it6pGdvmIIIDIzU+/liAfwhuYGCOOtPSlv9i+FxNcuNfNVK5VHT0vwAI3ej
foniVVTR0JM3IdS/wZuJ4mMvrryez6Ge5O6p7pi3XGWTw1RfFxq1BOJlIQ+Qh/Dj8QzS9MBzka+A
s+/R+gWtttvrZXASdgCnwLzEIPbxmLWB7AfAv0BA8jvdLPDsUD7r3VuOJx6ei3VUVBFq2yXfEhH9
tAscmG/CCnOQ7MfgM/M+lHR7z0wPhrExoPzPbWeE0jlBxJEQO+O/CvglsB5SdiIW2MNjgncEOc5T
8a7SBwlgXDBT88Xw5qPCmKL8VO5cGoU7xzr4AV25MxI2x448cKv8AUYkkTlhysw8UmmeHrrT4uBf
DLVAfmqrAKoJvC5SiyBkb+VH0UDNkMEe1y6xVAqanneTRGCB7E1MJO/7E4awePB/njcknFrFs5+t
omokU48q+JVwotzvSLzfMxzCVzZm3RhIjrjdnKMrGKPa30SbNjtExNNTOk4z1SmS18fbpo72J9ZO
DHjwxdszwotSXys16LwNJk2CO730oFIRnIN54tcs9dXWp1YlGGPK+W8+ZCDPQsWpZdthelFiJ/tr
1oMoL3YmVkWzl6slAdjP48u1Oa/G66IrdHBtU+0qkjt4V08Wa01foZVNxRYBphxYOtpQJyPpQmp2
uEbFh8jORPIGQEUNOwRSkLmU3Mr5NFL3bwOX3GHvpvcY5H4Dlv2ISQE8cJ046Q7neTsvEcvN//9+
WMy6TaTkAYIbwbuIU5yNOEi8aHyL4/7MFIq/Goo7HFarzQeRPMj2s1Hz6eCxiaZSHEbF5Za3hNWM
34vLhjZsTl85d5KwHIvWhmlfiB8Eua418UxZMMNjNEefisNkrpzcUiYoQbc3zp57jPULodglOznV
UKb2UMQ6NFLks8iThZZFzS3dXFIYoKclUxd+5Pp2r3YbgtpG3c0=