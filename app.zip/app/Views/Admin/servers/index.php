<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqY89IexHPuDmacm2Ttp/E9f6hVip2qKm8EucLi94M1hqTmNtRaXmIK77HB4zEwy4ooMWJel
hNVW1UutVy6uFieGkiS5ucOca21p2Wg49mQxN+j/u/Ix5ifntaCVsWmbWdhsaLQsngzd81DNeFh4
3pSZTydRT2GU4fiv7QR7zPs3JRD7gOKTLVxFjxB1py6tybNxLcs81LkidOsqZI6yTlI5yW6L25Yk
G/B2JJiIU48XGWdtDlbzpo9GIiQRumvIkth9hubOxymazG/Nz8XCYKvD8D9c59rB1RokwkQP1lwu
4A9nycQ1fFsqmfBEgbp/RlludY7wbBbBdgbYqRUj/K7//WynTyVMb+leldOZigv8AwCrQFOtLxg8
RNYoDccgjAjWHyLw8W81gTw4lprE8/OdliIGneGxkE4SQF1BfY1o+NbA3q07NL4i7BEB1tLGGsI4
VTjOIDZt/SgHOCjjOIpERsXiQvy/WyweOrlO73cEz3lkIqWYIkvhv/kqXVo6jKYwTVAnOlG2Dc3c
ITOdKrOqsrGCnEc2Vh3/jNQHKhs1LnQ915qlLnbfNostSsla3HnbIhoZ1OfAGK/p7t9abKRTti+P
K/5puCJhRUkRsu8Z8naYz/cEaPnY1qJAmIlg0aY2j0K4wLvbPIR/72urGS9A/TQDK17La1+m86K2
JAt1kiFkSg2M3n3L0LMKf4uxFw+SJF3UYocPcTjGeNT8kI70L5RyQWMO4vFhreKVFNnGWaEETUgl
DpwD954SQVlPZLyh9ZgVrUAXKNCWTbC6HXlCYi2Xz4sKoBesgqpK4rLW97bTCRkjCFtODcsyuQTD
1czSs8cGLQadFOF/R+xh2mkvEk1nEhvf+Q+Rq3AMXqRh95K42muTxYaOjunJ1WdGpoFR60LILf49
1izEaiug+sMqBSh2D4yYv1G1O/K/q8+j43WuCc5caeHS7TzTZlfM9Rh9aF17DKl2yx3DU1TVb/MD
xQ7HQu3CzShpJ6gmpdLraTx5e3NzAz4xn6EH3Pt9rLkbDNuGw5kJpj/VowkvY+15KRJj8a7+n20H
aQCnkGMbs2LPuL2XTfYPmQdieKQkHZCzqwbMNhxwupWX/PpoksMvlk+DoA671B7HBo9CcqE8vZcI
fJE5Z7ntOLGsCzZNRFi87vn6ZHJ9v2SrEfiru43OcB31n7zVDQPTYNGNHkugh8vkIUra4dlyMed+
JiGPEIlpUemKcR0azHPcbs2XeUoGktQXfD/YHMr1bPlIOOqiXmlv+lqK2+NtCEMlNd5+JW==