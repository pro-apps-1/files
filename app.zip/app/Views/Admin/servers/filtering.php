<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxWT4lO7jkRvtjo7rTI9p8jvCbmvDvcAlvsujhD9ua2xU203IfWuE54cDIwWZo7SLmt9+eYl
nRQ1NNmLKr7gCZLCPaC4dnhzFR51C5BHN1y0ELDNmqfLgS/vGmFO5yAAXeWql86ajFL7maAWLMVz
ndAdxLpn4hbKccrrjIcowwy5zPz/tErNCLjqlBAmeavZvr4bEjw7BSmbUWjiT3SjhqfSnzZNwPgT
1IH6c1KTgsWmp7N5fsvmiuEnrYZNZI4O8JBQwNsmmIHe1LU3zR5LSrpbjSLdMRfCsDm4kdnZAmTw
eESG8A2FZWX92rydWi7flRr6pJOrzODrpEk8ytB6zIBIMZVyq7ivIOXvh2+kYtKwm009keHnVpRA
3E0NipQ2eGnIa+YLE2jwiBaKFXXg0aOO2bsG3dKhVTpBV7aFcp66QlfbfKBqNcahqPTK2wi4kEsP
H2sKp0z4NRVBZLgpev30a8Nn7qHUzteDPfXa1lFzhFR94VPx5/ga4BQbdq0SnNfSnYruVjrOrCzt
x6qjdXK0Ame7EZeI/k+RUKgu8CPw3+qlyPJLaFxZ7waYCMXc1+KmXfA5gCmWhX3yFlZJfEHkhI2Z
WuplAwZdMBPUPO+Ek3BBYjNxk0hs71fE6UWddZ88qaP3LAtti4xi0BSOfJQcpGrzFZJtNc6m3rhC
yeltA32qL1+V3LOTRMxtftdR2x4S6bGocWjWy/Ynxg35HvYBgqMd1+hBUKRTw1iYA8adaZ4/5fBf
Z3dsjlmkzYYpUYE5XZ98BP+VIxyqr4NgJHtCdrOgPwSupfWKjDKx8KNQFT8Zv6BE5VhCN7MkeZt3
A7Zaz4bdgxL+6eKCqQaTgWQnd7dVkhALP6ahJkW/R9QeQyhhV+Z9NKZkL3P0chTHOh8tBz9bYKsp
Gi7LAzz3c9XTkfwYYP9cHdTqrLHvWEhl7NmpLhml/AB9cSP5JZ3xx+UaPzEhpHcEUK0IYWSgSePd
XIXiY/5reS7BobF+5udF8DiWiDUhuG7VWqoAGdyf9W/0+dBqUFNdNNHGE1QUJ/Ngqu491WBFbvbJ
xmRAxQ5cI+1dznGBDLDu1sEl61IA49tMKY85vdRJb0XETDs0G0ly/SjQsb6JnIyZEsas+d8oWyp5
qj66fI57N3xwP/usTdEqtV+AhjaUEEZYNJ0zcQjr8HCKiTIHaPSW2dNlw2ZZU9CAICpsActnI13T
BQ2fOjMTdusyTVsP6lGPP/v2aV6r4v+IDFefwHHJIB54JSxd7fBBOu/XLfu73IxaUC+CXCxTry3x
+kiRQ97/7dFe9DPW6iiLf9EYXJZPNKHxVAs7gvGV/kARmzXq5BPgYaOVfKWUBDCWo6LAZsPEoWo5
HvrMEZiz1bVZoX2FZQH7M1g95q3d56skzttytB08qujKhzQS4+y=