<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzaQ2oMXjuyAlDkU1h2XJFERmGeVNgpYvkHUE+mghfFTBseviDmZQWbQsVzoP3uWpETwDmTc
L817jTh65Nnz2nGV4D+KvrVJRqaZtS1Ll4mVgmBs+MLZrVFu5BZnJyA5VTKmdwjNm2nqIkFTkE6T
PG9Z2F+tdTsaclyOcBrqJ13hYXYaysQq8ZDLGUcGZ/tp/ORbka2iqOmAgaSBR3h9Pyn6C9RQpCZW
2cqivU6UTXYJJOiKzVLl93tXejWI0YFMUuguhOrowuyBJUQlvM61iikm3WTkA6x1GfTMs14VtUKd
z9zFLHp90JcJcF7ViLHV87ruv2YxcyB5Gp3s1JOpX3rQeayizOZfouu6dwn4EU5GqV+cEc4Q2XYN
1/Ei5v8aa6EXrbGPH+BfmrB4Pp/QapAKx83aaWNVXnJ55brGNRdTVMVYWI8seqqrDVZI2mr81pf8
owPCyJAHS6qG1xOsJIBw6p7OuPnbKsPdQ9MBoixF+r7omQqJOsLHo/t3xmVReBNsK8dtHKdGQlbe
8xvSE44q5MiZ2NbAnG8m0nw5dgfKULYon+Z8FrnFiWfIx3JndEOLDKZiK++mqjUfK8D6NpY7nCR/
2bv1U7MzP7UzIcTXiQFFLMlehXLwROyINqDX1aIydBPHpwdVT3cziDBq7BZoG8UmErSM8Xljixjo
1T+gd+ULAhYgsI32PRVOZcYb9cAMMFCaQ13gRdiSezCHQ3V8MfUKhrh5WmusySepXN0OZcyaDBei
jhqs6Wrfa4Z0E9tg9OFSX1hpLVgPuCLg6ytc8EwUMck4begG3pbD12HBGkVss0c4bvmSDruimQZU
nCDe3qa2VCab0WLH8r2AQ/ZQE2mXgg0krqAM1FBd0/Z/cFam62tOcpyA0byI80uH/XQfeTPwvzWz
gP2M5SocYRI4NzYcD2CbFG7Yd4Qi9azRZ7jrwolnNPgM9J13SDkvd0S8jTNd4mNE905jzD/DZxvA
3sC5Ni8wbV0p74jBCxPChRCRXxAf63+MaRHfJq8z+3isYPKGhmOmD+mRZBblS4rtY8vuCwyLSmto
QJzYB21HyekY0tUyB4/VT532JipM0cODeZVADeBPD30JCIfyhzZRjJghAAQL1swgOwFjSg7+SfaP
rwp6AvyFHfQUigeA8atZWYPYUcsB8xofzd0u/imHGtI3LXSJAetvSJC/Ocp+vfXUweaE/ikRR2Uy
63Yf1qxJzBE2YdeOADVN/eEfN5CumpCodnf7B/CeVJBNkRXs+PdOcHj128laqPCKZtA1TZJyDcyO
XYcI803HBjL9iu4MJi7lAj1aoa/EsNozs4D8KbD8nAOWWiu7CZh8+h/KKc9z7tKjM/YZ5nOSunkG
B4ugnbRAQapPvvwx6D1KcqK7H/D7M6cS47dQVtxD9rmSpiE3i1wBhoC=