<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmWA5YLXn+eAVCk31ZsOLTznR6bIbOUF4SgZZFD7m3CsatE8L2CLORxG0mR+0Yyiq6ivz2t+
dU4530JttWTkZrFrBvdWxDZMf6WXyrb38jUF8ywGOj2xhfYzoF4ZSHVbYnBom1RiaNN3ct7PKns2
QJYiRG8NGtvE7X3W/SIXhGABIjdQNiLf4YCjWSXXwQzBIVg7TPDJ+5HfNL2EeQa1x6Rl7GjL6C41
fH8vOblASJO1HNnGSlPD5m++v+JfBwOKMig+NMxKLL0DZptD5Sss9lVne3AEPEz6UEmjHRcXzoo2
0WD7OFyDtVDqfJThtdx2j8GJda+kUwlqrtVpGrzElYUv7pPXjXikwMtKIMKZ59Ogzr5t9vMOW6R/
TULr1k+6IYJZTkg8yAHzVQKCG+qvaIx6+nBK/Z85dBY8NmuCSpDk+93m7DRJPziz+PyHpFFY8bMJ
JBHkAi3jGilNy7ipxhpVcoKB2TYGnc0t2Fno2x2oa5raQQ4QEaosxFQeO31j71UVRHh9vkUnohZU
IVgTgffWPfnvEMhTcbsHQtBCJpCdOy+bdN0exk3ShsVvfwQQ7k0SivdCnlW8cHsIQaf6hd9EJnhd
K59lGqXRc2OttIOsRRdyhillpUPAOzfdv3HjmUWfsUut/qszSi80GNeO3T17OhIZ7yDnmr+wV2TU
IV8I6mVsWaZy4++2+wx1t2eMTM3saA3bKjDGIealOU4WLu+HOzK41L18JykA+qVrNTPzPVFrziXT
8II3A4vmSOaheI/hTXef+KB2HVHMwJfmtu/76ioV1Qoja/4cp0LxKGhuXn/6KcFw8fHUYZfkJrDa
P0Jt9lU56TKT2TpW71/D4/ZDoUnCmTq8Wqiqo6rNcVSrsAe3R8y4XXcxjDF8pj9neXB5lYANfb1D
nmumcc4F+0mVoUDezbCGQrWN35LEUuYA6L3qppeS+FLxv/Ha0fxa5nKB860Oc57TXrM618ActZBT
N9sFEJZ/SbtHGwqrS03XZFVgAauD06je7+gTVgDN8J1IudOnIkQqLE7Bxeo4gNRJz28BPEM0QsEB
y64nDGQWl0npsxWQA9VwLgOVqceRNEMpQScaFGtKgHcXudvGyDllk9pP9SzmDwkciyJ/KPYeBB/W
poGh3oqfYS+qlfaO3q/Btx/KEH4OaGDPhDlIP//+1fLnahQncu+xKoII0907kxOJ/31rvfZ21Q4U
Lt0IF+8Y72t7B18Edba4Gkd7yMdNfwMmcFtXDczD0B2WWKfWU9Z3oFiO5RDROqgsucvialXAEW6W
MBiUirA8GLmsDQB+NzL0SD8T7xcV6MT3FhZlN5KhLm5rA2bStqEOn545xaZLpWtsKh+sZ/g6h80D
5Io8WPCAibVg7O/u2tfvPA8w/wasbgx0