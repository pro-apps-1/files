<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmjiOPkOu5dTPQtqkFJ9AYLyqMsPW6jJXSa6FIz+IIoOjx5ttv9itGR1NvW4rr9c4vpVPJhF
Zk55x/3wM5OnHB4e7+3avrCcBnqrJXpYotI2zts0gX+y342+y0mt/OX0XYLK1PMwLby1LMv7kUnd
yRXS7UsimeGrLEO8h4sULLWo8Wj15q4DkaRC8Dd6Hphay+nwiEMiyF7IH5wOFy58AUwZUBfqOo4X
IOvRLPe8YaIHpGavQEX+K12vyEsK730uqz4IM6uJVXenY732XzMz19LBSfd4PPO5gywNerM0H+z7
ci7TJ/zNPBzvfbrakfxTIXG4r60s9TFMDJ4CSBt2QbjnMzW71O+Y5mAqyAQGckW74u6VCKpBXDEp
g3Zz/ziIdkAN9ID2/uhRqnc8jsDcOAcRim4adlZ8x0E7wN2NgfKjj7/tfQrKYl/opS+OpTibyrzL
vyxqXwKWKGkRDhQpw5JKJbtEdACSCNRUFPPvGgU0hEQjORUPRl7tU2oqXe402rsa6mxQWmqkSegD
XA8Avnm7l2hxCDEcPwJKslswPqxMptJ152OtcO7X3ConmdESfIoGkiBe01FKpIQqvb+KaC7j4UYW
KLfDwEGJHcSvTP7W1xoxzRVCaXWWQTq3Au299EgQR/WL57SFDIH73FX2f0MyFaUwR296hMhLbHmM
wbp8HNU2nQfgpDWN042zA2Y6Q9V1pxPL3xMvAZCK3edok0v6C2sm+yGV+fUMmOCSwq0QAj8SzLY4
rAreMHwDzdLxn3NVjl3rwY2MPEHspmnjvLyxIzkfG61VJlu6uxaW4mjSqqKvZPdcQ5JFVtsJBZ9G
CfzNNKXLU9JIiUWX6ZsZTfvq9xgKL9d85kGxhcc9WVy9V6S6+Sa3qpZ6jPhwsarwnec24xwhDhlj
gp5vdTKwcjJS3AintbCeEw4zOGdzABME8dsfqtl8zzpn+lHOTVGGKh0755cCupaOyPbSUoj+0Thi
z3hwZ9b+AJ0AIAdu19oa5zYRff3kLFJfcAvxHG8OciHmexEMOUjjshFP4mFBk/nD5ZDY1MyIOjJE
xELGfZ9mE86gCdnfHRmJs/XBNKFm0zHSMI1SNf9OLx/HC4iM5XCD2BIio297TtzkdaabPo2zXPDL
V10YJ+6Xqat1PlHz8lVn7ICLfCicCnpUrfv5XLvAe+wgdcVfW5DlPPqwMZaM/nFBeXcqApsr+Br2
5RGh5N1q1Y1fsChcRgmAk/FeM++XWlZLYeANSJgkyhR4hkzE77XGUNp3ZxiEOfJLekW0jm+HyxYt
asmxsIc5Pqf+6ht7Y5dJ1kLPswfendLhE45iDzoj+9qwgkFomZxT0YaGvNiZhTKQW6+bWwtpfD6P
D35H1vxp0Ktp01+8ON7yR9gdY2FF1wbDPQrMdF7M