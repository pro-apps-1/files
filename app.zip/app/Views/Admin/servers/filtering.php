<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+UVtmpsC2GZZrvABvF9tczsIMkIM+wvKF8WyYy8bLOZ7yX5yJ+jnE2ZCISDI4EzMb7gO97U
RB6RDggQbriYa9pfmfH5PdU2C0sWPmbUJkk1XOA9D1NF7zsk9y+ZVZVTeLuqaohg07hy60zbGDGH
wA3pRg+zuDA2FNhPA+jgZ/rHGNiVnD228Ar0agOfiM/5oWBN7FMGRZ+AoScngYOzkknJMBBJUuBH
rycrtQjvI9KeUT+SUjD8lxwwVI31W08Ctox5WElfQHTUxTZemLH3b0prRBtbRFg2tXvK9eTcxxlO
bYyrA/+8HiUJvqB1aDPaDmdO43JTvoylEzr1a29Fhgr7H+DasvqCSMBX0orv0xBEJ1rtlC/ljJ65
SHtNvnd5qwbVWpRztCNkzuEdg4m0obHWySxEyyCurj2PwiEonJTx1Rf9ewdGkdfWwVAHsCkeIkOB
0shLET/IwtEBBAcRa8g80Reeo3Hk+Ih0JSJ37k8haPL8XovFSdsTtzVuzL3J463qrk3aJr+pH+PR
d2f5xj/Vz4x0jmFacg80bqhqehdPYHe05RAjVBd25GCZFNFx5BibtVLY2TL9aoLGAR/eWtvuPD/N
6QHSl7XOXQAv++bdCR1u8dft9zPH8zEqOVsskIHEbi59HG2+B5Vhakz2LmlQoSa2HBv9ZaNemMMs
rDbqtNiOcwmqBpggvqBcj4ttufdUqi5RYJT5Ara/2zVy+pysLUkrdFv1zyMaUOcPPxa055htV4rQ
8LBXVtgQuTeG0O57yIAu4axT/OupuQoDxoNYrjoNHkNiPg/2A5pQHGBpK1v53GOULEXlS+nNbbpk
QE1/eNHGyFbs9sxljdl2TkezhA0Go0VmIn3qNkN9cfpMggd9a1flw1ZKcWIWQ83fV6xyIM3Xe3Bc
5ZsDTLzmqtt9bo8Yo5hxhDbhQ1bpXbMWe9+L5wPMRYfpil8qaq34v1kfg21eRbtPb9QU9m44XoIN
Duo61QCfTIr78LjznBLQRK7tX/5nw8iWQr58/iDrss2pGQtChrYc1NS/768iqvfx/LWZVeaWtlQA
YP66xGOitA8h2VJ9yM721otw6bK0KGwDK0otuH5aK7RTUlyWJAzrnKBcFI7YC5/MlDa1Y2woOUpt
b/EISnwET1O5evsCG/eFZYgsUyRMsESc76A4/JXAWy/Hu4Z0Vp90DyGYxT/8KRDKyFL88caHdbYe
KZv0xUa5lt4t6MIAqOy2RHlnL0HQvth/SI+2wJQE6ZVRrMcErktEoCpRNUlYzDqI4DpZz1RYJN4W
3tco+rN+whKuOGLyWiJe61PIr0dCt3PEGy8K0j3Dl9GF/+V6zWWH8I/puvVn55nPsrtqmNwAp1Wn
qP0vc/iY20+23k3wehdPq2yiJYu6ss3z91XD9fHF6Rtlg/f7