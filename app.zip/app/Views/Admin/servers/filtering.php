<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs/fR95DUbMd22ZviWTlvbmlUnwH0g5ZC+vWLjv5FmVt3PfwhNzvWmmrjGsMumO1VvXRB9vQ
t0mRsEkV94ysrkiJ57ANLC/1VvrJCR5gw7TXriPjSRexV1SQj+bsZVDpthRlks/VCwKQuix3JWAy
N1as9l1CcTJ7KF1zfrU+b+iJwJ8XgXFNOC6OBtIT4AJb7Mwkjwf/xIQItB0Mmy1gSihYsTgpmNvP
8Ncq+R20yRgCLMwaWSTncSRcsXP4tvMDyV1RGK3xX+QiAgcq7Q3re4ZJvB3lRiZNbHe4RmxCOjVz
Ke68EbYNqb4Z16pQ/faw1+HlU/ahgnfoQp8megmPm462SsXtm42kcSXaYE91SHAOVJDE5MmkrLmV
gVyarDwU+Ho5fgHcJalglaVY6ljsj+gaQG3IKIYQHLSCFj0Dcjz/8zhnUszQ2OT1na57GjF+el/p
qZ6cnHNykEcJlenwKh14/Ozsd+u1J7gfBYMMThxZREo0Nn8uepZlEPVtptNqMvLhEa5SUo3UYDOx
h36MhQu45aU3Sj4MQE5XEtOcOB3scYHSL9VNl1ClRcXOuoj3RWSQ4P21ftermDlC7Trm9qenWfc6
eXMiDnazPiPCHd96yXU9ae1B/cipBECdGD8MGyWNnsTVX53tsM4Hc2r6I0MgUm9E+4lfS1LAe8nV
yn2zgf6s57RhWvA8/gKIZN7PtWp75TLBoHgO2ax6co28n7zIdOkyRY1xKPj4sUmgr8IY3wu78gHg
C8PI6A/7Sph6daNwqfpeySwNYFN3eGSPiWaGlnPPPtjmKHjnfCzBboLQIjHSZT97R3P87Lz6hV/n
WMmrMV1wyFpRx1qWlx2hsebcKPjxoxM7dwhXJN+qhzbP4FjWP6xKKTfZ+lCHBjgD+OIRS7BZPT+Y
3XmRhKhH2m14PocGRhOMxX6W4Z/jTl4XNy8nXa1vUqXcGGxjg17bmA+eSuJELV8p75oGwJdQgWCw
e5nz4hGgAXzBcEzq1X2thn4OFbt/Wz2PRsT8HsZYxcCfmlQ1+/nBd6rbXRH5mCK4qYR62SvKsl2Q
P9Wen4JJp1I/14IjL5eZhd8VDniRY6um2SH1ke/za3ikKkDIqleq+Sm1hASQQ1siTgYGXV1Ip5Eu
3gTzgaWfl86sZIiuSjnDGM63aQyKW+1JLUV5tkMSG6DC+pAUH2ldrnKjNkQBTDPR6JcjQuoY5byG
TqVI4YhE17OCiE5HqRixME/dxi2EBKJaz6bObrECuuTRAjAz8ZJBgJPCL9HnbeoRJh+htJyAlsyE
guLVdFXGxfLceRSq2ZqMs58gq5vS/qIZKIUD9ZaAzeL36iVt59m++iqHxBIqBPGVOYbU1tSJ/W8B
heZQ9anR6RV1t/ZKrroOFjWJdIqrS0WLSwd0gsNkLh4UHx7zaaX9