<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw5P92Sw2fq8mvYn15OgTjYQvYhXhVRjIjYLB7ebRf8cW7414t1w43EKrnl2h2E5SZ6eq7w8
Qwbv57h8Q1iGxdHeB0yluSHYIeY0636gyfK0jZAmygzMRLzTneBnwYwhjE4TSUf6OHSwwNAlwDBp
5AbTAxrBMA1wXEGRRXoZU2krFZXSZdT3O8+OkE9w+ZtM50i2oLZdFOv6qYpseYhaBBkgxJrO6gZQ
I8k1RsIDmy+j8kCzfyc49I0+dUN6YheGsd5RmVPx4aPphoX2ab64hzVSx7i6PvaVri3pLjiWc+L8
zambG8w+jPDxbfdWIh1RPdHIxTyYL8SCgDES1MfNki63MZWTovE0zn8o2WEOyqtFCBS6gS59VbaQ
sZOhD7kXPsPBLPunDqq6KhaJN0QOHSvj76n+S/V522Q0iU45/7SEOEFoshqlnciRs+pvAeQdlkt1
BG9Z6mng5pMNBiXQxCAcwJMf3HFC53HiiBTp64Q48yZTW0CLINDtxUPz29ofQ/Ipbb7wClhrwplS
a+Tc/2DYlBezDaMIZsTCzZFA8Cj3LVFmecFZsNS0QRZ11rS7zM+M1Gz9AmH/7TxZSIXqBRsL7Yyc
8nAblfG+xU7AFzCC/JbhUjRSIDUMfpM2zvkbh82L19uXDaQ6Uvj66Cxw2JdeNC13KYdjMGsH5qbi
W9V9LH2+zuPqGEO2Exiu/HeKwY7OMbYTvxIMesIiAZUh4PJYc3YQPajLfO/8rLn+PPykeUQdhv3z
iuGnIaDqaeE1Xh+znbWNotfWq6jtW9NPYoOfHL5voOHd3y/ko22cT3YUfZBPPTK36X0PPaxy/OxQ
p4aIxzwNpHzb7+HC8hT/aH0LM/OZ7qZz7A3lSnCURDkbhId9NMZAfQj8J56+6mZQ6He/bM0P9aN5
I4izWViw9brpc/WDJ00l91qm9q24ntCmqWY0VEI6+ciOshx9vez8M8cCW+muKJY74gdSggamKHke
sOaLj9xQExlypZipwNEa61inPKQUYzC/nivxNqAtENfkCKyUEZ1rtBmHS0i7GzX3iKmnQb/wUCmG
6S/o7tCj7gSDv5Y4oUNc/b3mAVfc7IUoR0CcLud78jz1BVRVDsfsTKTG1gbia8wzQJ15s9ppxXAz
EUlgIFuJ3rd0OSPt38IHjvw6GP5z3VjR8qfKU629TjBIjlz3j5KO9Y37JexnWO80a/X+f+/z7bNg
Gm/LvvfxWDcJE6fQrEbArmUISzq+/n2NYJNBOAgRM2aUwNF7kQ87gcZ4AG/1NSQI/6arUOXEaOFm
K1EF5iu9eGNkjBRMJfEB8ZMiqOfETgg/DfDFfWEPiXl+9sc+j851xIk5f5+2VIynMo/kHdarSqt9
vVDO4/7gRAbXYn7G0k5dfbW36BVS42z/74mEIMx8jRQp4WY1OAf+ZWwE