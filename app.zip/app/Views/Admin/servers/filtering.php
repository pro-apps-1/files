<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsA+SE9p4qdM2d/bmOU3d3klfPC2F/Vw5S9pY7+U4L8BXQeW1jD7mPkaVeDCHiTHA2PGxYCJ
fEt/g+wH8UtM7CRAHyw9A9MglPQ5P4K2kbXRdZlBJmhFzd4M8woLmcSoH/vdLgLF2wXGGmhwVDgU
PrRSc3cthucgLn1q8SvsUo+fREQSEnvF4/aJBSaLuv94ToFMzVENyWBR3ML8nquZnZqqE0vZABqD
hF7mimo/Ahzj0oNDWKESSmjIzkxUKSxp+kVl8iPY0ghcZFD7ml34C3RvuA2tQIR6FSZzi799nrwG
ND57F/+WBEfzAMxQwRfgh5LzCUTTgz650ZdszHFRgZNjpZAv5h4MPv9uo/s8pzH73auakW/E9ZMK
AeanJWgFbgeVIHbCaKW3iwtMYB0W1WhukTG9qJdFFW1FEBHm6ivmJJOV00YzeNlWZVLbA3UZ7tUa
n/zNa7xLI0efSkHfmNmfTAX2HxGfpAe8MKnmRCnvqtGM7spk/XR9D8FTbOYA/4BUsA5DFTbbd1pO
S9hHLbhAbIgNXuJ9ce5jxYXRb45gYQIY+cOJqtT3HzF7BU7R04Usvez8klBRAEUavVzks+SENBJN
jt0r2BNiQsG5glNU2CyPPjKehJDL/YbmAs/a4uYExELD/sn/r6OMp6y+Co6WVhV/0/LjLJKv/Wyk
jugNNrBq5n9hdET/hjMB4bUa9nkWwGMK7bUSRI5KyKC3bpshLLZMbBG+TY7mhYNn2oNiw8oKJS0i
LwlWwRO07gBXEQ4sTiE2kJ1MZP+Is9/xliM7byMXlxDG7UwigMv/eKJQjY+buYNTHzEYkH7cxXZt
s2lIDRTsnNTHtpZPjeUrxCVIcoXmyvHCeK/vSJc/Enl3T3kOyQ/041zwzRaXZWF0bVbmHeuCkr7R
3NxknJEw5JS1o8+cbSdB2bPJlKOGE1sS17VZFKRQAn1LLN6BMEjP/h6UJIND0MgWa2NaUXurR0kI
CUTSZG1pMLd8k7vGkYBetkBm4s4zL219druZo4B63mf3/n2q0GLERL0RoSDzv+0Q/n20QMwvLT4x
rx5BQT3/LgotwCkr/p3qmqOO2p//qDcAZHvn0y+hgB7uanyfLYQaK4rlYQEKKRhDoJwjndE1u6mH
lrkOVpTveu1hMaN/QKphQVuGVT8MzgQKTK2hDgXJqi/lIJ1qt/mXMsQqt3Nzc9QKmjwePpP8mhfu
LGNrGNMeyyZlGUBYdB2w55nPzwpx1xgQrcD516kw8hcfOGUzC2J1pxKg9PR+fJg33jTuudi9Ytd1
WdDbeA/ZmJQzgh3iTQo8fFIVNZ3MZfouLc0mG8GCeBvP8WffUi3FAoy07TtxLvN+tX9JCoEG2SHc
oDQDIgc1yK9UTiLHOUmCuUqdr38Z6X5nEnDrbVbGEh0heR31