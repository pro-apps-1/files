<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtD+7lPFq+Bv5h+BrTO/Kv9jRfltKaEpWkfXstxTYv3gh7frt/w2OxM/1TWUqgdHy7VnaqMZ
AFSxD9/v3hBDfKmhzybpkyU6I5i9SIKMUajVZWH2DDh7rgP9d9ppGQ4kTd8B7e9bjivael62zRL+
RwMxE0i7OTPfhGIXh9fMBD7ERLtQLc6EcNkV67v/HL1DpCK7Nyd2v2kZX20tMKIGn9l4S4nONwpg
eBBGRsEEpMjgxOGa9etjUnRlMZRustwawT6TDfaEIxGeeVafOjSvwzbosPKrSBaeX8756rGZPM/v
OpHtOnyawGPf2UI69ZYniTQVL/S8lyqNbCzsZMXzEqgTPZ3LWnuC71vlJYHHVJd0Ll0rPRAM+ICV
6g7BSHvxhzwdBZcCGHh2/wyCv6jbwUeQbI3JPZ8BAdrxxW5Hh/8V9wAHJ3t/Aovy1HWMnsIy8kHV
ESoQvTbfKT+0HVG8AxVmnk+JMqzH+dFOOIQGX36GiR893imFBh2yzVpp18Cb1h0eS6j7Gmnb8ikl
1QZ+LHXsQfI772sq76l48Xm7VH+gCerc9Otoc/wvLQ1MiawmBirECDbdOvpCBYwiL2LuKzOYPaVy
OWSRl5PpFVQ9khNhAmijnXUJAsF/UkN/D11mvEGqXUpm6lx14fTxMjTN5ltZooEEmPbAOKpBKd+y
+mtMyGmeTKvT6+I+QDHu1Ctll853khqJQxyMHEyRVEJLDaxpLuyCfnh637OivWxlJN4+FiVQUMIg
ugL16qrDE+FqSCaua0pEFPjNMoj8CWDhiGocmPoc62l3R9Fz9TfwvDpDD35PAy2Bn6rwx3tNGPTR
rFi/wYj2crSzUEyhAD8NZWc7y+WK6Xo2g/eiE8V69RD3q8LY4ZwTyfuIoAXhM64N+yyYjC3aWmmW
zNZFKmP8z+jdpCXsAvFxL9b4PPip+G2kSS/y9sqCC1pGk1rn2afXNAmrX5bgWoMNFn1bpgYSyyGL
8ag+WKNegCj5Z+pRInFbkGTEduNmSHO3miCZSbRgSCRc4qIUvUAVEXbQvUOGZgvoIx4ty50Osf34
pWqXgV8OHXIctPDCHVegfnp8b2GTnqMKJluwCTC+Y4tHAUVNsed6Xzi2i9XtDHmOepMvdjy7UPtT
Y81JiTaTE5BXCAmGpQXWuILGahCHNda7BNseT8vCyd0PLOfBX6mpM9sCNtVOKzS0WJzWeqquYlSa
xFVkKxDS7wUP/oSPZA69hz5onnvJ1dCWJf+3KaqWnU6/oUD2RdY2COqbgYHBzBkeMd1lEYVdpMd3
87bXqiTnYYhwiTNou+/eaqFI5omH1SltXnWGhSqVX2Ns0cgLRdh1QAI5PtQ35NgdDojUe+xmz/L4
AqNa5sIlGI9vKCEVTaLIpbTiENttoV9j2UnZYt1kJriYSvz6kO+G5Ry=