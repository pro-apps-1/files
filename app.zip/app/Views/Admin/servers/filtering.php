<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpEyyRY04Cg/NNracpNzaEqJyR9FDj6cZhUuEsv/zWXL6wzGPOVpXW8ma6hUyGnmEGtfq3t3
tHb3v608LHM7hYGs1dKOKuSZ0gICp6yDKRd3JCvsnNl1NIBe75LPM4Jj4wpEo8IYQCZdhbWubYFG
wh5MvzOCfzyMpkr4GbxY7yEeSjE9rrJYM0o/gbwb1sRzcwnhEoeGebld4G20vqg/AINCx1xZgTsj
9btAzJz/4eFAmoBtabWffGxfVvKzMa8KE1xAUqoPPhjLP//toGYqjdKiFlPd+/eY3ilx9Zdndc3a
ETmh/tDMe04KzxTaJ54DalgbOostLcv1dSxsjZcj/qNwX999lWL0CtRVUlzRIoIKkHch1qD0G09S
9co7jXbrMGzQsgletPzHWx2KRFhL0Qoq8PSSkoVbok/w4ALMMgoJBa9PBRx2v233qx3Eqv3hB6Dv
GcSusdHbIAit/boXs518EDs7YQsoeNnddidpACb71uk9VKgo5sHLn+DF4VfKzKy8FRajRmz75bBu
RCQaH3GRqYJoNzxmKwK3d74FCWLSIhIVhZw5vmWgnYkHYst5I1OkGvD6Q9Wdb46eSYXJDtth8gTs
77+0r/T+NcqdigxDV24czRq93YZlQmJ3jgGfffv/uoV/cHxMEEPdh+hNR4fHyYZp0i+g+sc4xuMP
uKadh/Nrutu8pUBS2ycBfLIXMf8l9fAS2nzstxnaO+WBLzAByMYcQI7JVbsxXApS3BDpqcFUN+7c
IaFnl+ZBCLA+N1A9wew5M1zPmrUskiAZv6WKg+DrbO3ydR8j8FhwwjWJEI9rJxEC5jl6eYcbXE/5
sLxODtGkNJl7G8QB7bJsRi/vDR2und4pEM+qbeXvtqpG6+KfadPRku6sINojMF3VqmfDS8DX0ujI
myyiw0TwWKcyqWhQ5RZ7OnCfaRVzE97QC4V/pKTEk3WlGVu0fg9M3P3WFuFTTqNJjOqW8tBtfVY3
qZezQMuXbYHQaUmkYwoG8xQr93l7IPDIuf683mqb4LnFCypdxdsnuZCj3kfx+R/LPhSxMpTLGQtF
qM3R9HJpHwMMtnTPT7iP4tuSmPHl5l7ISQRCsOGRBa+ZtTITHHBY2fdT7uODq19w6bm+1Wjzk3Xz
8ucUOP04H4V/qQqcyyD667SlMn/njFXqj1oKvjBIAcYXQxhDBtk1PJ/sORErjTOKfQ/slxZn5PyQ
4KXD+qtXuN7w2hgFYu1JThJ7b/RjodxH5AxPf/V9SkQ99QZB4LRQyOk5nYsXvnw45wrzWiOKSSaF
4VqZOJP8hghivzlrCAT66TTpwFef1WA1XRU6qkfSGvmUcEC5BMMM+9C182uWwe+KvsyNZhQpG9zp
T2YkYNHr9gz7NlK2O6HF9BW4srw4FMoowwM3dThS