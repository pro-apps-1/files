<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvTKt3JX2IKx/9L95oRMyy3/bcu47gy5+DKRZ1doZ77uvE+3ZTQh2XcTgWvnvOOl5jv2wA/Y
i9pmlM1Rrc/ux3GMceL8QQJ/h//qf7nkLK2pe2tNeMz5Q7NC4dOZ/3wKSeiQLPzZoXoCMU2NPojm
BK0Ro/vb1IulfPzoj9PwWpI6N9Jv/4Zdzxo7RuZlBT9vjdGFTj91x4Lb1LwH1PZLnQjsEWFUdJ/f
7PRB3uppR6YCxvAKP0MVHKAXBGAmgSoU3UIVc8wKSsvRs33i/oXoJThwYz/uROMNX4wsBrkn5eRC
QfdNJWdEmHz5ELtlBOkEjahrKuMkXyOXqq0NkowpgCrL3O9auI0UEHuZUDwppAZQuMqz1FeL7FCA
skWDyw/VKnXVnip2N9bTvbej2M69OZ38HfEW2QBRTeN75GqaXWg3otpJgJlI89mUp0nakgf0ZJ7x
5ZXinf+Y1qWGe4tyRDX8P0NIY/SFp0s88rKq/Gl4pzZTUQpRP0Z3S/pWO+QYCY01LqQG55VSxTch
KBGFgT3D2pHfJqecuwdcTUu/f2kVdPGz48GWvKIg60E4htLTEENmVrP7eLcEkOBKSCkEzn0cOcbU
B8CtOVjJnmZOlSsod1sGn59aH9mIrcViKb3uQYLKzOi01jGfZfJx95Jpg6yj0r5F7v8iWr74/Qax
SI8mkvbmw3RA9tFYwqZ9DVZ5fuvF16yqkqCivozKezn5vCdZj2LhMPmnGyfMiWAQVKu5PooMWpcq
dGVsnZ0dOIPJNJ6GbdX7iGVhRnaw8WpdOksb3CyqVTOjXO+xiWMCHpbJxQE2sFAcm2xDvqlEcdKj
GmE/nAHB8pw9/czmlewb9+sPPcYkS7cSMxTMgrbkhAe4G2qIPtgX9pspTbDznfGNH4kbEXuEdvkD
ueccDP+FbzOSm68ZPTFiUmjMsFwUMUpgZOwIpP1gobPfcOEsqx8As/pkl39S+dvaldpDaLV38od/
X3wvo0yRW0ifsYB/3hLcOuvGsEKjxlIkj0Dz3+Vge2gC6fJhaYsQkt2ud2ghCR8lJztT1vzOD05b
o4BssunkOEF7P27qbRh+uOZlyp8+Kk/IqxCBoarbB+TJHd/+PJT3I7cnPtUe8RuZYJ/57vTz2VvL
nokHTNiGGq6tJ+VIQqaR5GottHe8x7J7ymh0CC8BP05O+Abd04G5atLjz1Pq9goNbMBI5+zAwC3+
CgbUxhXNBix1J38vjl5K4NVuw3SPFxu5t3jxGycXL20svzPz75U7GQ6ASZdo/B8GRhkxEypVr77y
sPVtl4yx4hOxhwBQGiLIUMhgprVOcnnWSFY2gJXIThojElnItF2V4IYjAFfJe4HeE3BAFzAZqCCU
BH/WmvaDjwXUQhhOyH0e2XHYXPyiMvmTaMmv0g+BgXIM8Sm=