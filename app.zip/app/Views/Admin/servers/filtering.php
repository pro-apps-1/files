<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyhx9EsdL9t2lZgnphAsHrluxHy9NBaubyf3BuJOzQ+cE7J67HUOzzz99OoMD0DDyOCmbtJQ
MwasMTOo5DqzEwaweUoss6DjlV00cq2U40dwW+cDQGTx8mySjSNzMj5TwaWMW/qlr+edH/t3mhKo
U3gyVXrS0JN7L2L5deNDirCCCjb062wzTOZzkq6b5OiI43RdXlvBuLp1/xjl5x3ez8iWBCSZ805G
Hm1noxLza679wBCQqSFlSnO/f7QWdXPLGxtPRhtyrsaDFVQ8rD9GTXw3bHFccsgHomoP89o5y3ZM
czEInZh/RIQu28lVeQxDISdeTVGSucoD6eIJi/hzrZ2sNqXISfAwprrXcWkUqA6QLOpheRZJJrnq
CvKhh8PdVn2HPgNRl0xL74fu7cuxg7l6Pnyb+X3AA4XOj/VhnlDVEhXwMO+aKcE/44Cnsn0PtjD9
GLZPjN4lY5mE58vCOicUjTJtPzpk+9z4CcnbgmrqosrsQyWY5ZJMMbTtFWIEskf/cTz7fAfNfBj5
COD2jWTU6/Igs7vRL8SGmWGgW7ncTMZrV3tnnw9z6PuLYFS1SXHflWieiHt3uS1dtdipYw2OH5cd
w3/ZTQk1c4OJPmM9K5NcimO4hgTZjlRcD8qHiIpksu4NSVzjfFk2LbYO855VYbPSi9d9jMtqKk05
eWynPbyXIXmmaEssQgct/KAsNbVO+zRpxKLToNLCUAfpvTaIkUv7ZTCo67wkrUi8gdR9gWDUEVG+
Ay9rHhpcjNc9AoB8pdZDe1YJV1j6rmLrSe027RV13lyqmc6myVHHcymlsMQUPQCbak3CmP7NXcp6
oZrvHqR/lO2THjH5ZWvZZ3BJrAQJ/QPLAsV2E2Nb863XftAvovZLfAF1b42NYffeSBB0tVfF3jrg
zWzzLmuehqbZLMXcMqpdbzboawzF0+uzXBoJ+/dN+v5d+NfBH+QO49wrBBMOk7+9sRTJikaxIoh3
u/krx39Z//VTr8nkErJ/qVymh82z25kafbUjQ9/Etd1juNxcnC056861hqDkq7bDfw0f0Skb0AI9
pNE2W849dxVoUHUEwemUYTp+YrsvXotb8rZHaKhGFgt3FLQllBMfO8y/lVVx2noUWM0uy2AjWzHu
Yv90BHSI3EvoSS6XJhzgjenU57lVXHbLKe+K4khRGgN9tDkj62I44SrkgXLdZyB12cdH+DpaSVf2
2RvnF/gjtwZdk7R1MZHuW64iMu4fqKtFW45kY3Rh5+LJYk4Rq40W2l7nSNHawmJ9pzMruHB+Plv8
+NdrUlmkBYvGYZqrByoFamn5msxlV4xjdykGUu2tOU0MdXSe4Dn1TEJPZm2v3gwSswhU60X7C8BL
GdXoj+wQ7VyadwfHxc7PTogynhZBfXUN