<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxVa1WyAUViWqoMJB0rQqriPiqcEg6VzNxYu5MIGApDLNQ1UZAYvxbfIE2Y8MqrIjvJXBp3S
5hKLjUB2DIsDkqDWqVh1bYv8GSjpKg5nFvnDChB8mk1IgqewWYaVaUioE5MZNhICYVJpyWc3RxxJ
nCLc8wCK39qK+6ydunJjT2cMITTjhYvZ40Ncm0hPIVoBYvAe48Df0IbrLgJlRX7UOl22fmFEmVDq
ABMNutxdJqoRucaEwCND6FIMvb3aIf9iX17Z7vQgXq8KtuwtDIuffMsorO5dcdLg6v7WN/FUe+uE
hjraJR30V2dtJy4VAxzzB9P1ivGY2dJ3U1XTNzo+2pvYqVN0GvNF0vWtYMBMEOINdoLXwMp357V0
fUCW4aDXy/q7kEGLKy+cRNSW2TA8ZZtiX5ukiPR6CnOxg/OzVS9wIlY8c57bAtbCr38/V6C1uW+U
kelIqJNmI2czMnhCpysrgYIbjRZJWbRcL/ZedKvTLLIbex++MV31IUlFdpbEDFyMKU51+BFjiFh0
O6NN/gbmalyLe4jZhS/gq/NgLfEGLOyRQcF/l1+XQRBrYOvhmUdWyaPeNTT8lyZHrp1O8OYk9wpm
91tOzL2vvmUw2iZA1UddnljKPEleiv+K+OFAXz13pyRvf5G8g+75eWpYeocKTXfmw71klOywT/TB
QGVYCLO6KI+EAY4l/VNbkBlv+Q5Y4d8qgwt9vqbFvPCQENTUtC6gkdypIrIr9GUCKuRCIIvhp6Mg
Ryiv7Ads74z7zsFhx2w0mo6oCBcVbckGaO0p4HUSu/Yvshsm2Me9ZeuQ9ELML9g7NeLD6h8mu+eA
omA/K/jY9mwqvoxOkMcPvcAwZOU3KvByGSboQFaA019sIa6ymcFTleDqUp+ySt4GfZMmdFmgW7bJ
6wOgvqrspzSiErlVYbOa5Nsxz+82xwgWw94fGAjpmnL0J3MOE1QZLXfFQqspOHHjr5s8ohAZy/zm
uZ2s5oPU3fkM6AsTDVy83+aJptZRXsk956wgOzszfg9hpEd9TWtM5ryefPvf5HOm4svYJKyJxEJD
tqn9XnFpZaFos4L1/o+CQ7UUU3KaeGQFLsZQGJ6puY8a5yvD1SOmvTFE0wHzvs7YZATnAY+MOTLh
6zsZ2LAB0fnS/ZEC03gFfLw+tuHPkC7AH5dHD/CQr9oLnCcpvyuVXXZpaAoTKbwfcJX2fvRx6Ikj
M13O7fmrNkwfe+D90ANvqVFcI2KASYCEz39W5Wl9o/vMCpxm0iNHnMD1ztZD6sElc1IZboSAodim
8MO2oCg2L2h4PThfYSsKS0WdTEkI/Z3LNFSmE3sdt8hGTxMrj4rOzbrh472kUQpDtYXKLeT0N4F9
v4YBIGiT2aOEGDMPKMvbnrC9TUfXqmtVinfy3WBgT1Pm62MymwEe80==