<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+rilydwuGFkWwqgwWGl8oENKUOY6CCfvwkuccb8CA0mCE7eSm9LGSs0yHTT7eKh7qcGQO1C
mzKzj2+S3+44ZkXdAKjoTkLjuZ2F3bxnzaq2A+Q+a9eBjbKKXPw0ebOqrLG6lGIu6tnyqpPSCNie
GrvdXOh0SiWfViG7MKakhwtGP44oTDLNTP6J5dcPvCAjKgEyXVGrIPamT1zv+jc3i0bAVsr/tDY2
knU7+mupZKdO3dWZAUJSnZ3jEeJbcHq3GFcJ4No6JafnWqg7SusbEtg0571Y9jk6zDlj2fhCBGLW
ikSgU511IFtNmmSxPAYOr2bCCUMVBZr7TG1fTz4toOOxG3NppzqGoMjZfOfXWFbqz0AkyNVRBKDA
+435Ifd49dY2e0sBdixLMZ5l43AUEwIw8m4HUVomXTae5kFut5Y7opqaSMxpOmCQuT4WHmQPlVhJ
W4plMYiKFNp1kughJOOr3BePJ5XIEpfv02464OeXlJAIQmSPrO2n5O1hMRBbI21NnuJNMK+JPmwu
28bJDjmBYVxBrouBhEjUbW2LXj+0GuwSUGEqdbMZJnNrIL/wfeyGQFymG1k3ouoqhW187lZugB7/
PEXheJx+k5H7j1OV29x4hhxp0cI7EwXsB6edoAj0ayXZJK4hb5hKHWWs0fUHqMogwNijfwGxWGDC
4VadWt14WMXX6n38KfzhYYCFSaeHQ876UTDVLmtnxkIuTopIzVdw5gK6t/yxXavxopRHANTDATlm
EtaSi5N6qpbroBYjDUnh6AZp19eFM3g4EBDm3ZWtUCPWxM4NN6go0ML5BR1u+O/aiKdsSobJasiW
hj69nSo/gc3XlNwnp43w41AAWWd45ptlYL9qQpO4TIk7ka/fqTfDcvLggkIRzh1AOfRYVbb+z68g
0CXHNlPuSVBcCuymbQR8PTnb2YzZi0TlriUrAwJEKVxgCTYe1cRqIrQH2w91gQQjn5fNAwSA/VM7
TqPe/sfBRMBVUVyXpgO4hFM/DZRMbNVTccByJ2/ejSFc7mON0mwN37SCh9L7bM15jYxGP942U68l
Dw6w/nnD/pcsO6ThPFndCofD5LnFGdyRi+UcCjCIj2dF2IaXw+NiOii1CT2IyZAIQ6V+vpU7SgW+
sFMsttDQxivnURMjShJH1cPK6EAV/4fdI19JQB2kWmh4dI5vJtQJUr1ybqHjGZ60a21/2lQy3c4x
wjYHX7okLdWdGXUVyT06kTPsG5kLCuEGFf4CEj2ZubwTkMfjWSdXFgG5eVLplnIXUARgc5p+yuDm
dc6ITNNgeaVqNxQRNvY/JA0S0ddYzUYXEXhtljtIoRrTacId530pAhxSl5G81kgQyr88NOpTAqO/
/MxPsQw0cXasnXK5dHtJN6V8xW5sRAGDogoua5kL