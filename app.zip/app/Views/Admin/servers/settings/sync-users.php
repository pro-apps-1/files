<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrytw5amgT2UpVLzUlsk9HmGjn12zMu1Ugwu14s5gne7OTy2Hh1DzKbku4oNvpU1Ha9cTjE4
22X7aPhgN2yDc7lDjnWTw3AmVQNcsalswYBFyILC7oUHkQjpmGINa3NkQFoT52ocS+LOAzUMt0Nu
vAD0bcSU/fhvJmuaD1udtouYhjRuUZJ5ToXzvCqLCckOIdya7wSmYep1ARTQhAanZ8/u3zWr5bUR
uJKl4Yw7cwCUOoueTvJn/tp13T3a8vEy4dV/GFk7vgmggRGTeFMWIDFai4DdWS7bGgapXTizI/tI
WOXk/vDbpnnHNUyiskIsv/NzZP3QgnINL2PUmvJxScsrhEUV5zxlucsE8YHJYm8HTiL/P4o4kb5z
1C19GjWGNkVsJJdXnSB2dbTfGumKUQ0VBiCQb/9u3r6YvcgQfZq3VaTBZCJy1xyqqZfkrKELMjtY
5C//Z3hzZYnPkz5EhVx8xE0OkuhrVN9v3qmRqGJ+uaQKBSUX009nZjQzeJa+MzPO4IahYNnpaaHn
nXO6TU/ZZkgPTxdebLfvjel92lXY1n8kUjtZOBC2RG23TdzUbYSa2xVJ2nZ5ERrjo+SVw/UHPALC
uBuelAhrEZFdVkXTBTVSNtnQGWH4ny2mrh9qg0Uq2Nh/4H8c4+TjYUg7QRVvTYCE0Ues9xgku4nj
OYKgmZJCNCtWybpdzftKrfuCt8Z/eRiV8CIbAr7WmEyCkymjP278yvmoxA1DaOV1n6VTfthn5dI7
hAml3+7BCzJ8Ov8RTTZdglR3FNCd0p+JMl835rmQwljpN7tQG5N43S5avt+LaSjOk0moYcgMuEO/
qyBmUuySGZgffvt+voMB/SHlK0KaZp1Zo1JYauw5MduR4C+rPBOfIQOGhs0sk2+O45ggAtkzn3JW
sjnaO7+EO+syq8zpnqRQ+YPUaiwB8JiUzZkYnAaa/DL/LnbvGFKsB5vyNQutqKVlDsp8dwIHuxw/
qIgFOXl4PSSO7FxcZlPoZKwKBV4Ul1KAflYRX9QdV1s2zcVZl4WPWlw9YDWKddNekeaPj7YmXlkZ
eUfxoq9shsCZhoDkfOLumEYls1+CLZYtkNWJIBYKQUu5+FW/uDEJ/NrZZnjRzyVs7Oe4wo3s84k0
SpjOM8HsDuSA/gcQeQ9LyXWAKwoIqfXDCDDpM4fdq+JuwL4l8G6Twfhi39hMttn7k3ePmiJOTyCP
0Os94cM9B/DEXa/4bVHitJNmaSZMlvgGf+7+Jyu8eSEB3ZTexXWafWOcRWtOwE9fOVpR3Ja5qidx
Al97NB7siNPHA8M1dGQ90tUXfVb03p5rPgJ8nCPrVAMzIwbzlW1uxM+eXFywB1ZP+mP56MWVukG7
SrO+QEgu6ABfG9mmzeaVQPViRvzNJxNbZ0P1VLD2Wnypm31S00am7pB5Ik9O7xygu/ONb2k5lLGh
7CzPsEeUcxius2Ui35HsMJZEWFTh/4JF60bZ/2FeMyN+ukKLhxOSlqduzM60x41c5NktfVnBjO/G
qiN5XmRZodb49N9YwEood66V+LX2CHuwSVKW6fXL3RawVX2JutBuOXL0neAgVsp8rX9+zWwn1nsT
xbW7WyoSrs6LWQJVzHSI