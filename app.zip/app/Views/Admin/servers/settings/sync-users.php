<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoGBhGxQnHKXeyauBRyGUcVuIdjhRF8VGuMuhH+6Z8eDToMI3p3AZr3QXWeXy3X23Cm93Vhq
YoTT9jeN31tF5OmajU/M4v0BZMWho92q15gy7JlMQqXFocZUOgU6myyA98u4vOXvx3h4ayN0Edw9
Lxltxch2J4qvIUA2UPQ8xZM9zkhML/K/lZOFG8vTIvjjKOry+XcTjAJrERIbEMdMjfKwXBabVeDQ
EawgMNrPdamcPr//Qf5iT+QOMLwAY1ZN8xLzZfHpRblOCEp/A79DslgBtynb1+iT4sCzTf4Cvypg
cTT1EBMdCBleeK1kU8ctvt9IlkMKOiE9VJyGtdCqV3gzCY5sxDKb/x7pwJe4Qc7U2LJUBFifktkr
oCGJWSCLngMhbJ7F3eLVQDOHzb+lEefd5k0IxAX9bwDmA7jgTFCFsw2ArgXff4w6HCHAB0xPZGAK
0qJ2uyxWoG0aqE7Eh7kPlB3vX0LClr2cjUPO2xe3eG+HBGE8PyYB6Qy+DFY8QA8Bi8LflxpMLZIw
hxXzldL81lF1zPFZGUaqgCky0YNOrRfk0UQdVVLIKU6CwLFzSyotiFEW/qtvk9gcFJIjUEw/x5Ev
LGL0htNHC/lfH2aIWfHXDEMWgIDqpJqPxUJ3tuzouNog/Zal2rBaIcCPZ8gZ5l7hEtw0g7E/Tert
N2KLj8LvmaUgrFTnaK86Ho5GT+Djw4ixn/MPQIdF8TYPHQJ7eZ/F6rva/8+mQrYRfhEQZJ/aYex3
KFtfWA/MIL8HaX3dsqYZmQj0vtCBh3SIho9Z2bCQlOjn41DY1RcZTbucvVmFfpXDeOfJvCA7ZyLA
/p2PQKY0yHfdKmlmIaXNJOnkpD+6Xnuw4mynZSKf2S2MhsvLR56M8bQcEi4F2HKou8IvAQF2aeAI
jnQpx3tq6E6VYbCcdoXRMityxGskndShHEy9jNe1cW7EucXY0BTdvFSJfjUM5gd7WB6zuUN1ng8R
0G+PoFSPOrXSBYhylhaQrsmJb7c5n9vpLhAz2HNR54X6SYSbfRcIF+aT9z7X1CITeE4CH+wE3Iad
Q7fd0Vwt9tdtWWc6doLIT9mJrmmf2ie6+lgi5XVUUNAlV6AxrhzfYNLcVna30DlsWsuSKC2ZjPvO
BB1zLQ87c0QsRvuo3Rf9fcR/fFsRud3cidT8DZ5vINOhD8afyK1YK3wcW/7oNm2fctIPFt4wZn8D
rzAEVNiKWZUBtqhABVQdllYKSNTA4YU3nQsJTaECBW7CjTnpmf8OMe3kCIodkgxWEhIJnOENnQo6
P4ai1KQf0fEWiII2m7vLdNao5fJ5s/YqpGGv7VrQbqUan0R3qNwhBqkF7ANYZcfdevCtQsgai6pw
5WHiMCQCaX/kSZc02ZNIRG/fyPIgAFv3uDIzDouxq9566TGD4W+908wv5+5GtPHhmbs2+2GHMym8
vwb32tKnLSM64GCLVMNj7LY2aNx8lNLDLsJGSU/Z4m0TxDslzlExn3bNYcLNIWnSaIJhANsXJ8ZV
hk6b+xr4HWiRPZUekEyR/aucU5DM702cOJAhr685WD8jJFd1lrbYjgo700iZsy9e7aDxGg8XUnrM
rXyptr/ZECzZu72S8CnMQ5xM1Qk/xA6ZNUbuX0==