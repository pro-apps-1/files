<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPndYECJUSe7hfo2jvx4WG5J6s1IDDSSG3DKwWA+olZj2UwUgngc8MbhaqI+4GfWop5au168z
AZFC7DsRUQl3jE7uYt/6jZk3s2u3AVJrYtWu6RhPjDWPUy8A5oxp9LxgQe8E0+osaTwAFkqkbzZe
4FitiwBR5Lwgwbgr+CCH4hWT0O6cClxnplVUKI0kK7bOj+ewNrVa8jFXhiVL8QLxfaY3rNV5AseY
cfah3qXGQeaCdw/ScE/dKGLKhTNprLjzLuqOBtj3Sg1YcngZVFhp9aQ/7plPfBziBf6iy5qfhk7z
5ZJsPw0f/xv414kl5OkbtdaRaeq3srqz4PyW33ThqhI4jLw7YAwlnwKoNvYNqXDxqSuh8j7pP968
VDo7YH9tigK42VgM/4jZ40RWL3lbGaW6vnUlOUQnzA5B91CP0htR3NqFnFVg2DKKdRf8c27SZ5vm
YzOAMufcH7FItgBiNUineeqmzK3NsZ3X3dMbaF2uMZG6D9urCqDiJKQDvwxQ4mg911KLdljWseb5
visC4ervH2OWyIvcrE1DuLBrngCNstzRYqJw6zWQWG8isXR84G6/vuM4XL+RlLaZLVZZyuIrVvYq
bd5T4obiWkQWQd82FTY39CELbqOh2jbE9VXKVfwyPUzEYNeAyBRH95okWEJs7ve/CGuBrVrn+SDU
2ITtR3rD/v58VUNboEqnrWKIhnn46A4CMbR+YHQFGA1H30TQkApN+4Z3UNsrfAgb95wUbFAbZB0b
ddckLhMhmPFOwLX9m8SlYeyc0LL/yocepYOAUn10RWVW47S4+GfxqDr57Y9X5gbIdvujgB8DDaSv
pk7WLTUeUf9D1Ai0jzn+gDA5BLMOiNAEfhimTM59WtLtUcEqPtyZ0KuYV293NpAZ+kaqQeQFmeZ0
jusnX8ktP+2PAFiYd7uo6wvIQZbDPTO47hYlASW1fM6Ql/9cdMqCIoeX4GpTS8d0L4mENMMUJ/kU
ldrUNRnrf1exkIno5cPBodnCqYBm/3em4U1fAmbrCCg5aCMRZEV0gHPP8RllQINwwDBDostsNWaU
5DkatVM86c/o7lTfe6R6FOA+ZPw2XaB4KlYQ3rU5q6rmwJf7HNzSbUGcIx7pj2/+BFHHvQNNFRqO
YVYMqM+OYJ26cP0auIuQfaYEu46ASRZaFxRPcdzRizIKEWMOOMz/WqKLUNrZMDk8OXGt/txFRY3Q
CKZv22WlCY5YReoBv99qZWzhlOBJp6Rpry7QIXPOspAPs72yGmlaBO+tcS9k73thWc7KKQYStZvX
jRtOkI86qjHvEO7WBWgQ+puiyO45uwArQs83E7I0ymhm1VyPKAO17yihy7i4AVQSn2T8AuSPRHgj
07IZtbpzS090C/mbFat2NZJlZPp2zMMSBxbBRF+wXCydfsxhdtrqWQRU+4x3/koEi0+E3duh3xN/
Ff/duuHIU3fM4Ftp7VpJQAljdxILYJDQCTIjS2LO7YWpN2UcM4TYXPX0Jv/C0AaDOG0fNh1ti1uJ
MSRg5pjgbvIj7yYRn8w6fLqg5u+Dt+UZI9HcAUVUdLPleEtkCZbZzajv1yOtaw/V13OJpRN3liD/
3QDC9pFzlxrqGOrlSf7zDlO4rYk1BpZdc/bvn62ejpBdyCu=