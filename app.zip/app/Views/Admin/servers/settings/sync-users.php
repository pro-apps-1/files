<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsMHOOyQJrgXurFqh71sD0zyCyM75GPNyfQuLUgXGhEA/uYQZRjwrhsu3fLzA908PtNOxD9+
KrnhhemFNkV02ju11y3JVBTk4EIOp/cNXODboiGmJimVGFxP1ao4784rg5ulhwVXITwvnGisn7dV
BCEzQ9sKhPjEbNaYgz21ScO8jwWx75FM7RtYVKDOULrWLlhR9twIREe4mXqlULlOJZvx4Xzq6DEI
4t1hJHGC2KcFMJKBWHar6vmlTcXFa1Rdg//l1wkSve3f/SmM5W9QCEVAiZbb/W7ql+DrlsVM2afF
P1jK/rdLC4e7VeJOSyPnwQuh+gL4zjEqCHFHV0wGsFR2AGehdMTVDnDHTy/rTJwRR+Fv7gcJMiCB
+PoC+BBnsLW96wC8hAQ65v+9GvemFZNktqPr+rC8og0KhCIf1eaMZHcirtp38wWZUQIUJVuUcfzk
ViVpPzN1U7yYhYVaRyJ+9xxm1vuXJ+hMPwB+2iLSkk9K3VrmvgDouM6Y5CYrbl1Q+sZreWSxQmH0
G0qEo4F9dRkbfg+TSMlKVnEgaDU6WHdyZEhUI3SUMeYDE5yvjJG2DFVCpxasjr6LAcdP56pZR/El
58wKolZ/K8nle1y2jqeEVTCl3CYYg7+ALndnPp6f4NnfScws45gSRW5KHAZxDlTDa1FuhbF3y1am
tUmk/R0Qo/uZ5OztyCiNviNsibZvNDjZ4kZpz9GKYXpBFhMlNg28CR4eqZA2TH2UrPMKH9uIBKyJ
bQPYUYzlkcMt3pTZHLqMFvb3GDAqyckAd2eWL8+1vBOs31oUr6vP6lRbZbG4LKXprZMAY6hGqUQx
nfOuAHt1yA1+TACF2ibRt5SPPqNHEePfFd5ULn1jw0/vvRpm9NIbs1gx8QyGD6+FnPZ6mBS4le15
9q3OBcSVSdbaekzzHgWt7kvM05F8pVX2wE89MdGfuGzpQff5LRb72s9rCSGvNM1Yft76RrZR4gFX
4qEtyYM4ugvJDD2I7esh/S8tnDlGkB7AcNF/eCpQEyfRyV0x7WvI5okyjZxZMXFP2qF+VA01+o69
hrw8SD/Q2isZS07hbEUy8waN1jD7lk+mbp7E/OdrvpEY7ShNB1AKaBRQEyMOyDkCvqXUoKsd5QT6
TR4XxTx0QZ2lSqZZksz+C64dbhYNdD9Ati9ikaxMNdk6CYUe/hUdQf+7gwYpCY3fl/bpN2Yfcim1
1N2nY8qt14RXy3qY4U9wG6GjIuSLJUCF429vkH8+BAs0XKhI4uXuZTJe/Yn3Bgyvb0i7BltVCnJn
PaX4rUwa36whogCatV6Z6k+La2p3UMG8uEy4Srg+m/h8UZLBtVD0GZj8pnRhUyAAGi8v5HUVvR88
miC0CEtiijbQ2rUFcLrHXTdmAEgATa1mA6ilUyoQfizhvQ5iTFcgRZ5jtNOOpPVVzSNhgsdtN6Ff
qwGi1zpReBta5ALBi55XvtExa26jGgN14aAp2MyDJOjx2kuLntbGaE7ombCW478ndyNcO8sTCHVg
2oMKzjVmkKgYV5yObKosI8joeFT6UK8DRJ6ToXQOtea1Fs1uVrSC6vNZTKzglz4YVxdKW374E0EW
l7n4R/n5bT0zmWs+UYmHCGt4UXf6UwOlyUHb