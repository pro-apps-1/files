<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyBx/p5jjbJ4GayvQax2wPxr+SjcPOpQLkKONjGR09GPeqSmNa4PBKg8ln/ahM6PNlAdlP+2
c9JjCj686IkmmsssNT1HY97LhDo4LYgLS8VuSLKZVDfT7pKELfkt1lVf0w2bR9SjDN1kTb3d3GaR
K9Qo4PyksE1p6z2hbcTnY9f+Q2/eydPsHDF7yAcdNCB2yK7qqVeJkrHBDM5+Holrzs/bTi3wbNiu
WGFczjfN/3JIelfP30Sih0nVQ8NY35GFm9JHrLRsZL3HKx83E6zV6oB3CgflQrJOk37hZ3u9Olj1
6Gj8IEmHXaMVJMfoHcJBfPGNmwuQ2Z891ukBgm6h22XoK/IRzYV/hBi2ADVsqs4U43BTWaf3qVqA
UevqXX4TW791O/Qs0LifLMIABRX4oB/diU35njsDrcsThwulyzwlxLk/nla7+EAI4925Zd8ftyeT
pYXKZEoeklnRCw4r2MAPMkhAhaRMzMnM6ydc/rOHHoqCplLN2v3TzgMeOf9jOqeBj2/cpbibCPm5
cyVd74SsDnfW9F/ZdYVYTnIepKe834kRMxflJL7jSHH8y+2N4+v9OnLFJiu8MFVNYL0jqSJ8y9H2
LQqd9NsnK1KmknXCqeXjEX8G8Jj9OjeBpAGdcaYhZwhnAZWa/qy4Eogs/Yl6Jd9xjhU+O5uuXw47
ODa5SpdccSlTw/nXOHQlmWOXc8G9GjJexg3Sv7cjdXCpkmQCPtE7QwhTC/O6V8/LEET6ymxQNeC5
Bv/mr9QJosaj+kwK2J5CAcM2steQVONJGIHICTHuaebNIFOrgWQkE9fHTS9qBD+TEFdqRE3AH0gy
J70GR/mDdKXgMTp/rCdH93yYINo3KyvdyMMIdlhKA0YMQyOomeemhRq846BAFfWYG5TPrtCP19v4
1fPabK7qj+xevcbunhvbyEs8y8jTjIRc3NvhLBTXkhFk2DxpMWXsuV2caI2mPSIIclIosRyfCZMb
n3kadZjH7IR/VKmXExzQiTQwckhkBNQqN5sHx9dgJIojDCcu4bp9XUtgUB8CqdsQ1i1WACEIg7dJ
QsxqElht1zgDSehzDxPANCZeZdILdlcx634MpOfUsjVqn7KdKECwm7faleUNeQ4S4cg5+rg+5JDD
xXLkGJLx5uRQXkgUrVMW+tQI3zHpsZ4a/zHX7M0m0LvcrMKx9ndx8q/f616LgeUHjJWYX6ckCgIe
lwsc0b6vaugH7zlRX3h6mFzhG9HLocj53tKCvDKRXlsTV4oeuTz9UnPSku8q6toxPGgQtYSz9DHT
u8UBBnFFbpeP+Fp04gtruToouVxVG/X+9FxYYvhnT66Fbyy4ZvSApNcDcU6U5rxhn3vqpz3okD/W
QxV/ifYO4uGKXSm/Sd+DW+qvabfRpvbMmk7FCSTaujo2hN35TNLy6HHcIaTN2pCRLco+opsdpHPL
C0fumu9fNs3FaGH97H4RM7lhMXdIvkUrrcXvwquPThk/yjvjsUaZZnlpx7Qc81u0vLT6xZR5Ug8f
VZQIjQWQW9QX9oEs7tgCq1W5oZLBJe5tUT3T8mqaaR+2d7b4vOwKL490IqzF6tasUBNiMDqRdw0l
7cCRfvo8goyx4nkXSP1iyUM/rEqmmm==