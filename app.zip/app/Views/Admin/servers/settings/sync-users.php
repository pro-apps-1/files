<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPphEh0gkXXKjjmmvATNo7oRV4Wcb7AJKIwsukyPGeQhlr+nKFplK8s9ghojf0PLbGSCpE5bl
9+gY+xUEQZCVizJvX+QT2N5diPBrT1w7S7rvPMH+BaX/YTfc0DY54gQB/TaqWJBMplgyBDJtVB43
g/BJAG3DJJv8LVXKrHvarLp6r+Q+1qDvv4JSiJzvKAdf7oNTnOJuC/5vfA/hLBtw2EblX/hazDqN
G7+lxsBavoQXJ25/iaxQ336aBjLJcJx7X7rvAWetD6Fa59t1nE8I/Q3Fmp1jbwgng2N4H+F0HURI
dPS74qzX6We9BYkMso/bQ4v0h+0U8BE7BL7haw1mC1GzlRxOvXlmyYUrPdAdQEAIa1aZbR01QFmY
hDz3ZD9axnn3vg4ob7lM4BRYmzQmCkmo/VzD0Pz3Mj3iTmpQCzpBkVI9FZaXVr8k24eD3gmthC+Z
B7FhozU9m/a4xS4KDeemeAi5BGLtCcbweibpfx03raQrPuC7KdjSbVBznCarh2afRvr50193daD8
YbsQsDRym75jXw+TrBnmQkZLA6NZd0sL3lO/ANfSnBm7PRtaB5HMPs+ia2yRrLJrhHJhi9SZUZPh
q/t0JjulGnMfIiEru637LUcZoZqpjFQkgVsqMPpkApgeAZwPrqfRSqrSQxUcIvACdaK2fKvyx4gU
VggxWdDKGgxvipbjSzK2wEN7rAdeG/FkEIMCSQbreHrzH3Ad5NwR/BO+7cU0ueNyf2P+InTQz7EF
urupm38rz0dJQ5GEKxODgwXeqOKTGlucuoaLQOlhCxfaIVj+4RSB7vgPUQ2dqQyqd4x4FvMCWQyj
2s4u/Mad/FzyVv+yvIpu3tlFddHxPTfw2KV7XN7CcGJL682Y472Nt+nJTJJe5BS9tKr/YIQAkfMi
4IUxyMa3S6L3Bkp0NhGpFiwjOL4DaeLBrY9oLjz+z3LHp2nv8H0HYXjGp7lvf7FFWir4AYDhywBx
1XcQh6/ePLqDTGafOqqGvPl1lU6L9Zq3iHM0dM5UyI8WsHko9p7pDFdy0DyuY99J/3s5/14fiWRC
ME9v8F/gNPC/UN6jNxYThVx/FxAWLDtdI17yR77uFd/2YqDasX0HCqiT7LvkgzRv9wNir1pjdk8x
4HkXZuKN5RNVggSEwRBzUdA9NzwfNKf7OumC6pG4k8xXDoM+girQmbOqqj949LZCFa01wdsktAK1
Z6Sjhhnf0pQuAh5SyagRL40D33ImtcdJ7A4AxS3nj3yfy/Y1gqGgh6yOE2WNfQ/fqrYPTGhWKfYv
S+KHrGRyPegBZOfr6iD14QcfzFG1aQ9nyn5eLQeLpZQQbh6GqWGkNBFDRgzJnqcdxtqAtJMIrcpq
yoTHZ5ULVAQTsbLIZ885CbiikXqFy0FUPpSkA6h7M22xgKp6zjfZnH7zgGzYb0dAiHnQ7f/GFign
FwOmOMd3d0y8e61B8NB6/zBv/XGIRVB0dWT6B+OUcBaUakMSP4kWP823K20RhTJkN8lU25FDj9OK
mL6Pcz9ElW9+oPhMeg4RR0f67xDLAWI1i1fbNXEfOKNunmrE0s8d1QTyBjnfRvLnAQyA0BQ7wdLJ
DpvaH7/blrptfBJt/ZiwMK6w0E5R90==