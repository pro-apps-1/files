<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqETlkywCmF0mryhp8oeU1+i5zGDrJcFBfYugiTv/zyrtZUUVf4QLmRpHNqvRUAyCjuPjDPo
j20oJMctXH5UKlYIEZB25S/X8EBeoylW7avE5isPzK/uBbr2Ni8xQVpHa2TRmuP4aVdObfVTJMHV
k56qZQPwwxunUumC3QWECq5DxjSsGWAF8Mhle7gqg4Ehd8j8jZBpMVGfCk0rOxjy++a0VDZ/IgLw
vRG29ZhHn4/S83ZUKPEOEbOipLDFLxBHcijBhubOxymazG/Nz8XCYKvD88PgKRluSTpXZq8SoVwu
4Q96/uVv5CDgPiCPVsd3P2NRAzwpmT8ZDbAOGqhY1sRFJlQm3K4VP6O4sPFR3e70ClNTcQbaAZx7
bvpTHHd3mGblFlbKPvBQS+j67V8L3I/1YTQo/++rFHC02v8402y0bWMrvmP+9L9jaO6WTwOkNj6/
+PA3Jg7UZX2r7EC1ovHHCF6uPp3VpGsGc1qVgKDg93HclNQKxNI7ER+5a2xvKZWo2SSM91F2Ku4W
78B9I+pm6oNbX661kFb8jmy33JyA8blyPdc50UtB44Fb4f9m6deqa78MQLN4aqNuAX1H8bxbRWwF
1dpLDZlqROddsYd3az3Rtt6KbashW9uInYv7V1vt/MBK+BrbwsDOLUCdxEShGaTmzJ+2CejnAzP1
gXL6DOh4mHVl1YnS6C2GaMyuyW4X+MNwBtYPnAAu0PGj95rtnUDY7Or09+TRauQM08SK87GnVzRD
Ox2l57Ihe1vTD7SHAuYt/j5Ye9k9UUCJf3tNfCDi3n27+oynLtfAzLzFKElCGsL44HftJT6FuIRQ
vdU3Cg3CXJRHHbV4jMJ8UBqnmk/VBX0htY4WNsaHSJ0usH6ddqDRzmIrfEK0Rnd51NEHJFCUlUbc
4Xq52qFRWv913s1bvodd6xg2X7qg4CCQiQSi4NUMHf0uqh6tWQgbEf3tubx8hw3AZrMxksdfn2xP
P/vma64dAJSnIV4XWVrPo+jbvsc1lIk1l/NKMee2CVmx/BTFhPP1ecQrFseTHUMtn6RZQLulAw7l
dR2Dk76kYLeWNGF5CtyjMWKCDV9ufYWj6RWmLz6WVKzoe/C6Hlete2L+xtdZpx606AvCBYojQEP5
YEX3tb0NFKQETddoJ269KUMIiBwUh8boJGsgt2BYcDrflG9+6ZjWtyzLOqzaw82sN6d/qFjoZaxT
vFRefv2ARCBXo2NE9MImGOu7JdsY3bBKMiA9ds6NYuo/SWTmsNJLfvnqEnmz/p/Xx6lxDD72FhpW
k7IBNMHG48fT5deF+/XTfbaDbAkRGcotmqFFkDTLXtuLOnm+xwe0u609EbmG6RkAu/RabhHW7gCZ
4MZnX/l+0Lw4aMYV5qGkzQJWFMQJb54vtTYUw2KItZIScJQEMmcvZ343N7w9ltq8tp8oMp4Z5MIT
d1PFh2xPIQQdAlwkA2ly3eOwTEiHj4dcIjf6dc6GgAi56g6MijF1vKhxXbVwDEew0knle0peOMG/
pFOlIfY004Me46Wp6FohE2R7tzqTVqzcFzPx9pXaFLjZiVc5M5njAQWQLr03Qp1B7QbGNl5q2mWD
jcGZi/nnnvNcxruZBEqCC0aFvtPagp9Tn8SgiguAt1i7