<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmQuHn3p5BmdYdhICnpwIcYIfG38eyvUvg6uicSGgXPMIaOPeA5cQjrm6lcfw6hOlVqOeCNB
Ax6QXR5ibYxXXjMZrh2n7dnMq1doW5vaN6UI4UDsv9C2fb+jvSSOZni2AP2ntXacG7NVL4Gwh8Oa
l4KXkjYsZzV0aSj5X4iUUfoKsFM5+eoaeKs1R2l9yNtvlR/hbTaTK6pHUAVxZtRWJ47NVl7l/Eag
dnRdnpForLERQmJlzEeBqiFNdo0pP9XdQu4EwNsmmIHe1LU3zR5LSrpbjNHmj1RC01xSq2oO+0Vw
eES7M/7exfABW8D86uQFSXJEQaVAOIi6fehCZQohR+PxTicLicf8o4k4S+ZBAtARkgOpesI5zwD6
Gwp3MoyX4JGds0UdyWBMuwKU+bh6TZkhtbXAVabjfmqNfq3T/ZI7+rWADdR3LcOcAEYmuvWtR9ZD
LDUm9zVwie+UmzVny7VTmYlKTtLuNZytekjAuRYptQtG4TuJlSYhFlHxDBXlMuX97anz6LqWzPE/
+Iexi4AE9YhgonLRKd8SmMDgpCCibE9byNHgMPBZ8qg4icb8/A0hEuUEUmC3Z3z2biLljks1wyx5
qNGcHZDqk8y8KZLA1A2KdVy8+bBVjgx6JKMtPUIady6KmUxMLHlBfPt9tvurXIcgQKL5mlp4OcTN
0+3UnC7n/t02EbfQlPaMu+59dBi0CYE8/AaBJcSoWwhW2vs9s1HG7b813tbKsqv99qgauwa8od+T
+fM+adorU9ExL3Hyaq4fIzUEd6Kmts73esVywit8jzeDVWEgHUFf54XFoPNhqX4Q31Rn1wZeHD5y
OTEf2otlgEj+98A5KgrT39vP0/VgTvarNuwlFTG2ysYfeibmlnL8Firwl6m/cEyWLU6AhvBzC3bj
BzhoftTJP5ZoZZ+LkCURY0upA5y2w++zpjJ+8/CAoYEU8yzrBJLqiHxLV54kptw2Le81WgjGcPYO
z0tb+dWFMbOaoZ9i1FzkXODy9PT32KggEaQOtmE28rS00X/JTuJ3zW3MidseEV7bSCIPzqUrZw62
UsbcBK4g793g94LhqvH2hW1goVPBg5nYQ1U3lUE76uhUryoPMo4P/+0SNj/bgcwgYweVMEC8OJaO
9pG80UsjcvjvRWpz9rJGjnq0MAThQ99PUmWgQAwzweezfRxnHXSsIEsRvQM5YYi8i12XJU+0XWmW
59j7DJ7y5Y5XZw+NIbkHiyY7cDojPxRLCiZv9MjeynPievU2ru3VDU6R9O4OvUJ+vXQCxMckLlm0
ODpgJ/kaAoGTnW3Z2iAbkHCs2fwiE/L+XT06ZMhftnb+wGlYWT45stPtoU6opU4o59kGUE+dE4EH
zekCOQdivLsU/lr+fFhaaBkpSiZLatx9k+4R4kiKl5BahH3Q8DouggZSf0SHyrABB75yyMJrxPTo
Mco59scHIrbsRgs5cpbKlXEpcTsdbv/nQBm0hYlKAXoW06lZOY4DG1puQzPGEif5A00TCv9v0BB6
t4sX/JzH1uSqVssC4+IusAzKF+SqLsnY/lPh7a3B8RurUM18uoZWelEy8gXStlAUy8YA6a4+6L1V
krY+ROXs0VYVfuZWi8KkOxvpyZKE