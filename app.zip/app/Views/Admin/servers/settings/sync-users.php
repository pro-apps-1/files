<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqEDaqivGsXin4y6QEQN1NfZ5NxvFq5taUC3T34Yq6NCm4bYWaCgM2Rp2uY7cRwE0Nin6eqn
kMnKvUQ2NNjGSd3vvzE2Z+s3DbyH4vE0i1ePtPBy27j6YY0jXUI4I0zdJwrtGg2/uZ2z5O61jTLh
tEgsGBhFQ4LmbBZmD4IV2Fkcp/JQOhDE68Z20edf8OXUQJq/gKMujIt0l91j8B6oxdlv4OImDe8z
nISgj6zzHTgjwaKFgnW0ZV1tmfowt4AdjGuBxGRXtexOrlPV/bqTgMNPJU+16MaocbJz5NodS0qr
+TYgtMXYBwx4E5I0LR3i4WzsU2dtat9HDMbU5/x9THvQxfLsSJlkkjSsLfhLuN8jWvFjdcsOr5ZA
l8+Jc0IBh1ROhvZ2gBIm8LpghoodhZ8vENgaQoeZ0uJp+ZVCh5twr1Z8TsTU1ZI8xqkSj6/XO0LF
tK73isooTsDyqsMCNj2uPZuu/+oZU/cn6jwQD4JWGjGtxghF5M4fL6uOG8WiOa9owqicCjUK8m4w
bcjqVDC0ys4UxhE1Q+vCj+phOutGZNb0Xh7ZiB1rpqsmQk4F8vI7yP2as9ZdA5C/siTz7VCr3Cwc
pChjxFGViuO483tGKedQ6Oru667ej3LWLFb9Ys6+GF0C57aF1l+kbV2MJH8AuGCp9w/kuvpPwV11
duqc1TyO0VRYNXgzoxkdw86XdoL0e+n3HT9Gsj/wFawm5cUmtfCfH//SpIqdQEIneBGeR7HP7OW9
IhVGK+Zm2So+Gpe+h5mXkUPMemPN22Ww5pOTlpXzsXyRgqDN8a5ECuouXVsb8ie18q0N4O3QFuJL
vDbWfVC8RF3bEZkCElt+jWpHSM85Pykswfg6B9hKAiIhmr88OsqT/7AY9Bpw0cAQTvbJptqt8T6U
FmrnAc/0f0EEHPC7IXwGfM4EwhY9cQo76Zc/jf7xv9dHkUy7ULUjLQZfvQEupcnr5ErvpqeUHBWp
azLWy2+YuD0o/QxYqFAtuazqk0bi8t1ORvH61IEMNsu4uuL5yYt9JAu6N2dipARjHiP6hAJJNNQx
9vrMQmcnd5eoikwyXkLE6a0qEORVMw56VuV+qB6+rSB14iF+4aly53S7Yv13NaB9T/wAXIdhoMUL
25WqoMK1SwaG4lT3Bb1Prdg+Gm19yBvsBR3vXBl3m+/AjXV/qijTXKS1Es7o2E2OKom//9MTAhsX
SXAcefoK+UaQkRZxuPxxYG0gBQtBIqmJ8Yroz5i48cwyNSvb3DmP4ZVqTrBpgYMrz0rX5XjL9G3M
vvhoNgC4/mKMyo4DsO2DOuB65UFGmxfzaasik6PdK2METuUIJKS1L7vTMu+35sjwP/g4W3WLWpPp
Zy/cjWIxZe7aRcbFTi/tkb/KGc/3Ws08UFzU1XZxtp+3kAuPs1KkfcwQXPTS2m2uh35AtKubvsB9
vZCPDYSEvpiFIodYIH44mOnnzPRTdYLmS6M3HckVtvuYighPCSjG6Tb4WikyJYwxnDcGK7wpN34s
/zIrUTGRCIYqMVOBjy8O9xxatEBRFKpa0DeYJgsdGqbtgjvMEwzTYi7XqIAMsPIxOdp0m1Hw4/VK
mZVu0a82vETgps3R2I5v2oc24hfzYCYjlUrag0==