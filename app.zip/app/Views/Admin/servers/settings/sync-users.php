<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvw9iqbFHmXk5aicQbYmkF/2Ucmr/mlfwAsuax08tRdvK2lHA7WOzSgBg7k/iyp+j3ale9+I
sanrMFhemUbwMtkWNjz24U4Za4ToSGhZNzSq6AzF0XXCaxOkkPxsP8WEsSooioKROTJlQ7SDs5HD
uu+NpxgAq0e06CmZBezgISvkJ+TjsCptAAjo3JBAZ87IVX0gUovSqwxE9ni3hdDRPVLGO53pJr+9
83CuQCoEb9Z5GxIgy/d+EriBYNr/eJbxLOhayh6F55dCubCN2OI5/+0cyivgWKnN+2kOUuExT4Lt
adjn2QadfEKO/RB4nf7fEmLFhjYWtvjjOPMRRw4QXwr4iuZKFlwfvy/r0Z4Pfx0eYFOKCYZY78jM
RNBlFZCUERmTNEmrIFPn89lfuiyPG0Q+2EqZUouxgeNg6sjC20MKpbKNNpT4hyPkYQOwsjYepLPP
s3MquWvHgRIgFVtgYSu8PNTSNw/NtAuKxYsX2z4wJTArZl+7UdcKYKwrQNk6MQ9zqoREXrcD7A8c
C2TYHe6CH5b5hPIh5+I6YL0oqGQmfBAG/F+p+uexhPNPWj9UrRnNyFmX7jLDVy4Hekc4DjK4ZFL2
qPiOfqur5JE+Ukc6yD+fmp0qEgNFri0fUdc7rxhcqJ/stanpdlaA4Kjhs6bi2Gy1l3RYtEQx/KlB
6kFBVSZsdN0jrHoKfD7aQyNgzXstRbIE7bg9+cr9+oDngakoH8X8PDqcj4Ki1XDpsa91uUSjTyqP
uYFACDpnsivNX0Tm6DGnCO1ENEz+Zwr3fWMpJWdl1+I/k8cBDIgJBHa2dBnQqpHkPf750M5QjCVG
2BJ0ZmfVBu9dsdVCeGSCOkbcnMxhultqLCxcddR+/wyXX1UgkrE5jTKRes47Dl6NCSrFiKa80LCB
OnxVYvCvzZfAo0vKRy9HFeQwptsvml38/vqY/bpiqBz593x2XmjAjTa2rjmZO09lWcyY/vr59v0D
2tsgEG5UE5v7T38w9tAhJOkhC4ymkte7iVA+9qXxHB6hNjlNkdISaV2/JogtNlWkeSxCXa5KV3f/
9isXD4F+62l5tZ5x2e2wbYRDh7H6lp8k0gmVFozkmtQabkVjtkktdNEd7vNYwEORgRaxAYNiXGgv
yiNRoqhVkZQOaHEIQ9DoAaE3QPRaatqv9FYI2i5Lo1S8BwreiS3ECfcYZMyRSs7bfiXZcxtEXZGe
mhFFYrWMJfEvqqcHOTnuBLKi2PZ3zpJqk/G+1Uv04fu0KSU/yFEshpcgPJsJ4wpY1Q3TXcxmQ/pq
X75R8FH7wiPoEA/zKATBcn1ktmUbetocqYbEkfq3rly1Pnjq8M6fNAupuYhGv3epn+YrjNG71snt
QvD0BOc0kdpQhYvnAfw1IisW/EIygqZ7pzwSru6H3bt/NuwglT2g+Y3bjLOukUcgqdRvxPBeUGIQ
L+sQEhbCuSmpcGZTrb5aTUNKTF7DgUfiNARxrXMuc9ed5uM9E9xLniFyiSy10+aHmGPwfBbeWBX4
kTCevLNpJZv8Mmaec4dr8MAaqyQ8H8XX2MO1TmB0ggS7JNkDpniKIxzIKIuMGEIzUvR57tZeOEYH
41TUigyNHUeMX5zdLaJL64l4/TAi8VVFeG==