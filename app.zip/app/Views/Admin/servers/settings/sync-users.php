<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPta7QDmusL0KnSNz/pCu+wZ7IxG2sSiBvTLDkYSugkXwQ3RQaqAhWWryLpVGx8/o5I3VUiSF
/o2x8vQo5pyv8siELdAl0rpFt+ZZ7Mgoc6MUwOCJ0TbV6DO4DmFFN81RPYHrO7EogDIDQffIoIh0
0tC/bgTH8T6BS9hVfa/QoYp1YseiVYZM18bU+xPanREqPcT1oMBhmU4zzk7iVEnri+gn2vYB45C0
2gac4Hln0F3dZFaPXBhU4bnnJpDHIp5TOkFg1MuJVXenY732XzMz19LBSfcIPno10/WDlYWx7v17
6iBTFggypuAJRJHAFWjwext1V2J7ajStj9RLssCk/akkm3ZRwB1u6aUi6GbPmA3j+V884KDIaL49
VNIeed1ab5LkovtlB4nItSkbj8iuKxVaFQQSs5UE+tkLF+K3DLF4lkx5EDPxdiWNhPVB2h+Oo0Tb
AWf/A+LmUYtl7inU6+DN3G54bgdvTgB+hhEonhLkcnZOYTxYSjNfTBuuVHH9Dwah0/JTvywJVqvi
PhulmfxWOWMjusiUjO9vDnbVf1qrwtfF71A0OLmOOxRlFufh9qEFQtIYbqbT3A5upmVyzgKd9IsY
fPrEUX6QQmBG639QQzkrkbvm1wwrx9gxGHLMmwMtjadGUryUHQEcPd1cNAJV0ob9KCPyulZLtjMF
ysI58W4rtRl5IAtOiyAvZYfahjmlMEDGD7Y+sDZnAyd/UNnoSoqa2T7Ma2FWJ2uKKnZnyhUqIov4
5EW+PDVg6JPXASp7Fkj2YQjQ3tZFX1yz+Op9JHHkwLHUafhH4o1P3yiQzGnPtBEWbB9Ir4tPzF01
vopbcPOpXlDl68nO9vFKCNsj6j/KLw8xFjrTUebPaJhKUevabFrf2k99rP/bLw0D2RXCL8FEekfq
8ptHkBY5h3SD7gkc1YXrIyDqUr3XVpIeBPCZ+FCPW/QHp5URGVB/5RJjObd+l2uMMIOa5edMqnjg
bAkQ1R2RgWY69IXg2rq1Y9YDU8/bisFP9V1z0N3/x+tYkQWtnRn9gw9E9uaGUdLJPNoUYkz3NgKE
PhuV1DaXFcnlCai/uL+CXJjRf3ZMxJdtDhZ1EbxeXgzvT1oamrpRjlpA/QUFUWNzPWNYilBUyLws
eANM+0/ZXxfCR7w3/fC1g3tVfNZ38JXQssZ3rX1YZEgIRscsP7NsunJT5QYLgX6VtqRzPeXdXQbJ
vA2KpANOSDlyvYXmN0k7Dzn7Vt2jZMjf3XtM1cof1pKwzw5fTKIIjDGmkmLImfq5SYIehaOGvEqe
WMxXWIIgsqynIRIyDpJsfwaJ4wrrgUbiiFdlUWWKwA4Qm539uYLkcEyPd+4IELX/SqwiMu8o6yaa
Aidnsw6Rhzg7She5XJ1YS+t/+DNLu1l9SFQNZFCDxt63/sImYR0dd3JCF/7Hr9DTixV5LdQ7mwpd
8jOuwBUm2E9KCmpBGQSDrqDPhUZDezkrMAtr3siDJ4S8aGVdY/CpgbMU0MEe9Y7M08qxJrMAtTFq
uaDL7o11snfJhxuhpozdDiTOvIC4G1jYXXFisg+aDzwJnhySz2oQ1ba/yww8eNQAzKj6aO+caYev
ho9fIyoLEKC4g8Un902+yHL49CVJEhP+GD9m/q63xeEyn/horW==