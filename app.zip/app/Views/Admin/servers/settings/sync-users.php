<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoG0JCIitBJhgSBPvuqrjFa3kdvlgat+jx2uu1c2K00OlkBMfyj9eTuZwOfksqBhqgSM2Wm3
CHT1dhptrG1E6GVnxJVFT4ldAzCCM+VAoUwG0Df4ZS1fM0Ki0lQAVHMBNesKttrcX+51RGiGS+B1
XK1X5enBZ9CwTraUQVnH12evmnV0lTYq2FZbcp0eCWHLdeEsVxomrfmhTdKxGchilUB3ImoyCvc3
oc4m5sMMKkUixhH0OPUbPjZ6xQWFaKwghrh1nar0bIC/IiIrHvjcnscyWy5fFoaEamNIzbdWQ5mO
bCWZAOVlZ08teRkUXh3NhO/aLilFQrNyMXTnzureXW79H0Vn38WEJ6MvgO28WzjGMdNF6aLYHoW7
s8mNxI1lTA0SmLpN9lh9I7wMtGWkJWniOt3UPrtEsL+HWznDYXjgo/mieWwigITKgX5XtjDxjws9
/mLD6UaT//3BIoVBYjePu7oTwzoOSbRBGf2EJtgnsJgnZ+pFhSpUl6QZPPlAQirpPXUi0NS0rEKN
6DpOiA6tO6r1WO8vPSnpgFhoV5MX3o2t95o4OXtU9CEWnuPTaZtf2rWlQ8Azy23H1dyGHhmvM2Ol
doa33QfdEUt5TlDhUJkwNBzlHu8xGeshFb9piH14pNS530fo5KF/Xj9jE8J/uMNEPLy53sSpgid9
zBy+KSShXfBL++PqxarhuNHYx7eUvWKhrsjWxBdT2G731eZyPf3/ENysd5Jp6FG0DWb5kFgM8SNO
XS5mO/3rtEggEZkwmFnGhX8rz61l/TPmiXJMqfyARrTML2h37zPCAYq2cd+pzBkXaY1sZW6ZlLIQ
bjO2VOaB8RXt3tXpmrIYbfWP6bCj5Dt4tFXYJ0CHuwh6ehUX+oa4OFnUJyfSuDzaqkChWl/E1NiE
KIoq7QAx37TNjBkGHdBQqpWhZURiDGi9dIiL+BNyX/toScA7SYNDdfq6BQ9UizL5UbauWS0jGmgC
EVotVo7v5aclNCKBEscBuhui0boIbuxlA5jcCg4aymiktcqe5VPSrGdQyzOWIkfDim4ssIZ08RMp
sU+uluU/HcboMvQXg5tXyqvNGt99hhlARJ4Iay4KqcJkDgT7UlAjXVkFo9gdEO7AiRx5WnkgIMyh
QsjRDNFSoFn3TkLCYZbx9dyvwP4kq75XSypVMwiBnLyqU1TplVkXNTO+KKN1610chVoxZL0ulSjc
MCk5iKUnfC5svxsZyAoBrn+PB5ld8EAdaGCqlMuLkL16XBaOxPpQ8ZdINf4aDH6H0igLx9MOdSpX
hxzQ5gNj2nUefPNd8K1m9wQHm7luTGHzpkCr7Glv1KoIQ89r5SYv7n5PdchFCe7SMFNhw1GAbzJp
+g49PrfwVaD88nQz5ICkhSiXaNLkRA85SmQ6WZOUhlvOJoockLswiqklpqQYgc2HZJgwfvJMorBv
d83T9GnA9psZw4DMJmqj29HmLhrkIM/PqpYd4YYlq4KH3InqijD2TojIuC7sxiUjtPSLlztRQg43
rpLMNiz4S4gPD+rvrK778Rndi2+XvkzeAry1z7MncMyeA5oiY/H1kpWs+BsiWCEFQGKQolBFGH5k
HBmBCm7iJ77nZRi02LoOzcsgYUZZUm==