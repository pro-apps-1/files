<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzTN4E2A2EdNKvM5mwPmt3NjhoSgCFkXFOQuLOsbT29RPvJ6GvgPoq7rSqRQ2uNRvnNbqtJb
DjJRMVLKQBnh3OjrFStEHqvOk1x4I7tiTEoExi3beuOSQwx3jrGKc6J4oQtFIV4iN79ApIM4MGtv
PzOCvty85fXVtSBk+j0F4gURUctM+fRMexOMsnQj89P70FsIFRC747lk1jYPvaH9ZeZNSOWwvBxe
2YE/dU9u0Mo07Bbo3ct8KtwLthuGGHuW27MTyLvyD5SgexbHR420sM8EObfhjlHzdJUhqd7iJkq3
pZXwC/3CBD6En1RMaa9cVYmi8qa9UMNmLIoxxD0JKcpUKQSrZ4BGDVZ6T+7sGjY4fzVsJNKbYfeS
USkmdeZTZpIEj8S7H8TWD7BxE7DseeqV1Fj8ps7IwJvIhqm5kGliLYtzTRSzg5bpohsJQJ50Yjpb
xiFzyiHVjnR8xDmPhaM9b+grsX6fR4lX1v9yU/TZzJ7sb8MdOwh9cJ4RTWm3AcllPAiTEz70fbAD
25hFBcBRhCe6Yn0lkvEhVuxLYXjHYXFY1bO3ccrIf9a5TDEzzo125HLxWLWlLUFXMmspKnBmQOgx
9HFKMDh/sp8AFnaPscwuWVVjWAW9iQL08kd8fBX/7fa80t//TBVHfrEz8TQs1+duZYVD7h49lgvm
yABuR43eUHcZ7YUQ8p5GB4ki7l7xlW4TQXatW9TOuOATaaWi+mxSFJC9X7IDzzI1++UoGHql6+EN
d3iATVLZZmPyfPeSR+Q2Od2ED0hIZR2cRzS5QwFtg0vU6Zi8GDTdewB7DGIpS7JOrst3jJu9G8Lo
X4P3y4Nobpl5iNUmJguOP8dxM0CDOpU3xqrHQpOdzPK1355lhA3nY8QDIYAcRiGGl1V3cjXTUIcb
feIy3/6tMEAhpueWYNHaVtLLmXIYVF2SSdn1Tc9b6nQlxosgHy8S/q57iKDlqgLQN6CYCahYSsrM
w5UWC24wFc017U9p3v1qkY1/7g58K0aFSmTig3UROQPQsw4QSjoaiud0OazW1o1EXDRbmgS3R01D
z0zbVHDjd1HUdEHgsp39TdBBKsPAwrI2RoN1P/pi/FUqT9Eyim1A51ZA1Jx0T6sUUGIAlT+QnGwR
tLgrPMcl0TwCEpeKYgk8wHhSrc8HW8NSdu+fuQoCAH/UZhdVT7+K+F0YmV6S4JCrzhFUmN8RUeg4
U2hoYNvWKg/X+1ArAr0JwvC1iJUAM3BJ4XJ1JqgLubxTi/XepdV5KlF1fM4UiNGUQoxAW32EtHJf
qDGDTZbPBhGXWOY8eAfXSDzoX5KG4njFudCdNAp7hL9Kr8Ifu0+JJ6fPqKoFiY37AhLzCsax10q6
TUbrMMDJfSOKYVLBV5TRdVkLKl8kuPByw9xDyloLrFYaL0njkyom06udgurHAWlx6u4zagIDeKYH
y+ORZldTA9c6ZflT2K7gm/4V0LNeCuj34S9zNqqpREZI41adP5A7uy2mKabyL/jJa1lsKuHV6KhX
26sdmIE6tc+vr48gOYLIurnZ3kTfLwBWAd2b3zzHT4iNInrmQh2lsPId/CcacYWqk4ZvL0cybDlh
UODet3JrG1iLXZEHSEUkdtB3UOuAPzxxfklcv20=