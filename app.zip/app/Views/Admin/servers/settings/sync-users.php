<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwE0WuahN7YkCa8MgkyradDMx8Bg9uclEe+uzE057IduthuTlaHojDASVjFJY7MoLFDFfa5E
u8JAX1sGkI+DHViMJGRzJXb515mAwiaUgqm4aU0tCTJx6fizsC1/rdb2J82WkW9xE7SmfdwIBjYO
uSGYBDU4L2Fsfd0FcLa6oAN8kkFsK7HIBJw0gsv5qeh9SrOGTdpzvnc8m70Sp0/BqDycG4v9Yy6p
6hFmSUabHjTZjXAfWRJkMrg5uGGhrHwz9512CHcsHeRqKnR6xUgE+EdiLTTfzKDSGHcJdMaujac2
juL4FY4H92sAPPbFvSa38LZGM60YI96nqnY5VoLELJcWvK7dWUab8K7OGCwaimuNNcG8N5Tp1ouj
UgqwI825q0tHX0yjm7avVDVSlb29zECzQOg9TOwaH2F87OexDmZ6KRQ+iXUXO16JUnd1U9xoREU1
jSn04PL2wgdlADNt+ksb0msecgCBTV5hz2T2M0j19ZaahzA0/IlbIG43KcLtCLzR1JKzpnE6RlQ2
1vJZl0lhSiNaoF/tI0fgeZ6jWlrtPJ7aRxschgOkwaTctAKngmbAS/qxFyaAsTSSABt+C9JDOc1C
uapTNEJ3ZyvyyUtgxmApu9Z8IqnzCT3HMBi/XsFo3z6qAIuCXCawW8or7wyJmN3BZfK8k7MUITLF
hGt4siZzr2bODEHe3lCE4Ht8JR+ADHm/acC90KbhiZX6EWpaOOZXWpazG67V5lTI/7Hgh48YX18X
xaHdkKEEKaohgfVTWl1yMffKPz7agnckEBudY4osTYEsvAJVmweBDGnQBcVoNja/UE/ldhW89zlX
9SdcS6sgBh0Bfguk9t+uirHjlbehN53Uj7AQ6zxcP/WohRB/bkOXAlj4/3SxD1LIX/0sPWhuSu27
Y40YKYw56TE8JNSvNpygjRNXJXwNOD3NUD/Ol8rlOl9YtDoV4kzsROYZrydSWV9vvROTEUC2fdxu
rGaG4eyTAWedmoc/SFz6bhJfBBETvn88Q3CAzLeL25s3IuZ4mzmTi4t8wm7Qx3zIlb679a3CCq46
EFJsXiuYGBsjmjpviToZGsulArISuh3Lz/I4wuJRvIY2cLJF0YQoqg/EHlX+fiEO2qc0SQIFkDOm
aIdDwVSxxV8g6qluyZiMz9RjCwV2wf1MbJPn0O68tvAPgx35+sD+5vFE/UsoLfRHQR8ihJddT3/k
Rs/Z8EtmQ/z1KtEbVnBlJWXToekc1KB4R0C91zLXNwSlXpiXX28jbIpOR22rcL83pG1lOZaTji8U
F/lFdzh98I0/nqX9Ik4tpwcaPAoW5HsEIXNkaAqG3r9Qab3tRMVOQlTmnhiujNDmDPIb787sjSpC
Ot7t0uFZvE/EQV1WERCNTuSzh13+dnrDX+dtpQD2ffQLaQZC1QuWAbpumldVnfq7xVxpISjfcEmn
Yyxhm63WnDkyB2UTv5TJ2xBgCKyvOX+FBLlcTVJ6ASNoZdmsOpen3x+l2R+XihJaMrzP28KMcjcp
XMUkRV/Z3vF75euzZyyqDkG0WVEtAuE/KkMw0ejaZjkZCQ1WOv7FLRlrUdAEJdYSA5xTMrnZw8XT
w6U1RX4vMtaGjMZqYAgFxIMB