<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/1RokXgzSxFSvbVovHJcmgcLSSTGJQy+/OpFUxxK7rJoqUDOPr8r8t15mnwPtueigz7C2ao
TpXnbtkmLGeWaefPZ3e9ubIMXVkuSz1VluGj9ya6evDwyHQ8zWF0agFuvV6LSqJN6xjWsby0nFxR
WwV3B8MAo5WaUVajWHY7uh6QRKyNv+j8v0OGjf88PrOkkQJ8gVhhO2GLFpjRxJr5dscoSx4BZRJ9
yfxitDmYbUUE1ar7GDxgeEbc7vjBMxJw0qHfbdjCcMQxLMV/zya8jBPrB3wMR2iAiEep3VzV3GzW
P3hSK/zOCU5PI0mdwuZN7XyZHnD9xNt81YD2t6nlt5Ni4/IZ3MngJHlhioz1A7BVr982y2atoIK6
d1EFJZs7q0OTcqVHryQ9dW/mo+9OfZIdcEP+0NFexkKi6kc0v7UP8hBzKtNEYzO6cJTlLFaqmuT9
RWbdQWS4WcXsWLh4Wu73OzItf+WFFitbbPv/iBQzBHU+v8bQdKd7vTuFxKrbGNH2Cq007XGuhdsi
JSPBPcgNmAH2Rh/V7YeiVrvbWwsaQGrtBeWHXUz67IDjh1+6HPnNmJBrwpxdqEsUN+c/NJV4ARxi
1FCc7w8f5v5T+Qy2PiSALDnUUhFEryJFqcP59nC57eOQ/q9ACcNQjxcAQOdc7nDT8GoXQG91lPcH
8xTCyC+Q/ZYe7TC/LbdguZ55citYd/Ri3fSZRJXJjywS6Ba11zf5cH77TOt9rX0/CAk3Aqa8QYzP
BSt+TmtO2ecrLt27PKvPYghCSJ+yuRylmDboYjAIgnVXKVAQE9Pt2vU3gmK0oLjFcojD2ueb0QGS
C6TuENoN/G+BOYVGlo3QQbprwy3uJMj1ad6MZq3LBG/wVrlyb6xlFzxqOO/rBQvrxwUoQEr0IlIP
ek5EpIeb41VCBjp46i87qP7zt3BKummvyjH/ftE0aywI3FCK5xcumK7yE1XrCb9F61cOdQu6MD2P
CpVOb0vcPW5aLYXtsnILqtoboSw4KT9qt6o4spIxBzfFEqP8oaDR1IOa4uNK8wA1xrb0+8/fGWnA
LbPI9KiV2wDf66tZj68BhSBveBGpXUlaIZZ6zGADWRm8xH3pLIA/Dhh7+Mw3LR/pm1/uZaLS2oZ0
HYEXXkRwdJc8dDrpZ7EjzF3Y4vciuAEUxztHbmwGDZAv+E45lz509NPIYK/URUxTFVVT52KIwuRX
k6q0mOR2kdl9ePHLLw+eE2jSv2hIu7KsGRd0yOODBGMmf1VxEc66h/xkIsZuUm5hCq5RKPZREHUG
UfDN7sM49QcQQ9URRDDGdLAdp98JEc5f770ZKHjiy8Yfb8PAcgmaKsloeLiOK5ixTAVwrPZ1bui8
uWJ8wxk43H9v/ZjgDE6T1KWhyib1z3ZPHQGC+4ZiB6nk8INXOGZTB1ixgUqAifUZv77C6yhkdzou
W48ENkPceNuQKgvWnerghYbZ4uqP6QKuM0LE0kbbmxQXP9FfQ07RY1fD0dbUZJfwNE8Qdl3Xde4I
vMAz1/3Y9qUq4DlJ32It2Y0W2Y59PJQX6XS+9TMbKbwZM9be8uGxmLmZ7e61ZMh1kSteoZ7C5zyt
/nHXp/FqVwFJ0YliJ9Pqb5cNY14jS1TIYlgbfwVXhMi=