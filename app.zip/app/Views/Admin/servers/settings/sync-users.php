<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt5t0j7bwVRcyBMNyXlFqT3OaY466zGzQCaBK/ZXuFgwcvD470tq13yGKtgxf/hu84iE4wfe
UfMNaWYBdL2jrCt23rDVeLgQ8jFBrGhhqGqm0iERO/Z1UYy6eepnh7SF7RJz9MFHLc19xuQHQ2RD
uB+UMJlQbSkFsiqnqe23JlnkJdfViyOqnp3SCowVdMou1Y+f9yMYibLeCDD1BbEoUTrUZheTTH2j
TENNkfEIYr3QpyjwNp978uHGwOL3XFeAcwqOOCb3aBmqbRX/6i4wsiljV6JiiMvwZqgEc5K1WWlm
YZQ/k6sIZXZINkDlOv4os6XgHl/YiAmUIvWoMnhS0rmU884Qz7YKuv19Q8ZhfLiGTpeN/sW8o9ni
0L1VjAAGvf1WTl4HpwIsRaaYISEnOhGfZUyK5Fg4LnmqdlmKOR+uu/dwVSUq8ps9AGhYu/qgaqvl
tn/B2w/s2+WpJuF7oUXlgVszHCI+sschnaG4GfAkW4aPOm8cSfYDDNriAVaMfxor8AoGWMtrlN8Q
d/D41DazG/KqLs6C9+9RIzYS+EHI6YqSWWakVt4pFxjKqcv8wjAxgaEaQrf/LKDKji1xvjHINsfV
T/Fi4ea/0ucZclxIOCiNSiAaPH/DTxcroqEOTqrf2QNZFv+WKKs5es9Ldk0vToUu/lV7nuHnQKBP
bnCFrJVsIqj2mBLP8oFp0fd50L43lNdTGas6boYfzGHjWdIAaieOrIDteGRG8V27lL6r0SXOqm7s
2v6GCe5M3ZMg7CJhAkbJCBuzBbtsTAc91VAGB/hHOrk6ACbTNvkfYo/FJgE7lGcixWECdLR2N7qC
4z34Wd/kcdD7lnO98mzVumll345B2+1EB324zijUc84dZGdHZXq36qnRTcpQcKpJl+vbMzqbiqAQ
kwTQHzXSRg//5+jQzieGyOHfzj+IztOlCgTHXY748S5JMgXP0u0OTGixSA41H9F/PKKhtYn4ElCz
PKOQkyTAKbC2dyFTpsW0UTLcjpvsC7VQTZ+dqxiajzV3Xo6aERGHXdpVuRSh1FYHc4dzouQJBJRB
zDfvRD+WguvUR3cS997eAvLSMDYrOfo/8oea4sxYXmz4mp+ZEkCRdHLmJHOuCHFgnpVdXjR5+cwz
qMafSHbIAH1cmwhJ6j/mNvNrb+nf+hA09GLjCUgcD5pgSQau9ffeDdom4+nTd5wjFlw3zgqaO4Uu
yjguozWD8/W6IUBGr7g7RT+luJI0c7W444UWGTHC6Bqo2vS5c4gDL17AqxKquIbP8obaK0VKih4q
iqm5H1iiMknNO3voMnPwzM2Fr6cMZeNgFHUANj8meQOx4LqKx1d4PCLO+CyI+Jc0IttDQoCmtwnT
jtIqHfDpzclgur/jolwex3qFgOERI755VnGDq+KocBK8vVhlqpVTov3GLXxeyxsQeCW7oedSJLoU
LIlRPctsD5CUNZXfRc8X5ELLOWksXxrHKrpzQ73xO7Z40VoqTa24Q/R4t+NI78HshvPwaaOmz7jx
JP0cCshF6V5cUhDi+o0W1LuJ7zq6C/sCmYuuIlqgBDEc/aDk7f5kw1SNId7fLVHQBIT0OlbbHNj0
wwzsEtSG4UI1zICxcxOAMiUJm4JkH/ivEywg5RHSvcV/r0==