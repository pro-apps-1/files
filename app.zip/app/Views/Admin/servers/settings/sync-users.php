<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPudQoZ1TYiy761XV4mL1IRGlMhi5hxS+eknF2UzF+aJazVGuf6LVOItx8Y62DkRRN9Q34fIt
8j9PTTXfqDh7o2gIHzdjcc/DAwCiKlr50v99lFAohYMVpeUVUjS885bwbD1zu4ciBmH8QSi5p79u
TU/y9Zk9HDrtZBaClE2TjF2dXxHGYUjjgCpBTi+5/8ucts20gATU3U0hiJkTjYynkAW42GKitKLk
kqc9GrTCUd4mvpQ/CZhDA1lii+0v1Vn1BD545q2ofBZeLxUYiG0RuwqfsmxzawLg6Nzbr65Wf0ji
OXX+t1iRMiUvaWPSflVs2dckSiqCNxR6Dw/eHOGq11SiRR85vTf+eeThVMI1vr59o40t9banEOUb
UUaqNH8eq2I618vLzsdVHA2mpIhZzgw3rjq5mbEOcvEP8iS6MuOinPkRCQJRryOC4jXRdzH4dFxY
EAD5g/TYB/cRIXitHV1Dttbsw9GR4PdKnxUFd5ecO/qDgXJm6EEm227PKZ0bAxOFywJjhcc/0y2O
hgQkcIxusOFSSl/EN3yx6td97YhBrRGuGhliK/V4NUNkNMUkXICwGxJbgbVzbqqeLCkrc9M8bNYH
9DKsf456Gb++h8FJ79SMno/7JYYQ2RsWDivSMnfZQbsn7HSsD6mc5yhLT1qvOwlqjCgjl8W4cXNY
9a77MNG7uV/JlkFFlAcxsjSfN2gCTMIrBerT4R+jAQopfGLwFn6vvRUGdGcWKlR40Bll/AM8fkiw
J1cWYs9w+6kgm2MjQnvhy92dMyqs5Y0e814Yy3N9JJer1C8qfG6+6kESJ8Uwn6x0n4ec5ZSDjci9
caNJrhz3AzOvgBhAfgVffsqirZR6sgfhNPYjNptTL47dXaek8NbxP0118Qlo8S1lDA1FA/Q2naCr
/+8QZBPPJXfvbNDxmdCm0H6KyZqqqcsQocaEbeq7UZVU78HU6I8wt7brzaWFVwEs9lvfXO4upVad
YGA5bxtw/CtK17/oEFBoJlyNnRrP8LinpnfJ0a8MiHy4ak2EPIiXo8WibdXm4TXOgLEzCfBGabzJ
Lz+H1ZIoGdvQHhMf51MX/C88rpAojNaQK4/UVYD5ZsIzy7LXUoAS9AeD3vPUrUlCjnWjT2MyeRch
LCaM80BR7ZXxp+7u2Zdv+7v88HD6sTDOysH5/j+so3Ii3cOq03xzQ2xjxE2/vhD9/OShlabQC4Bu
ewO93vv+bP7CVgc+ZbPwuINGW8lyffmENOO+xb492HIByDIJo2eU+ILJDqxdMvg8LrE8Vgd1sBqv
xNa0zXEbfQerCPo7HjmZZ3NbpjOc8jr3/5jR5o2CZLzajw0V+WXcIOq3Y6m7mnRqrswxmcavUXVf
pu11MQDGZzvhz0FbD9MJp59NNQVAR+iQ/mOX4sCTxeEl5p+d7+3k2nOWJ+rDkUxndu2prj83f1cP
OLw29/F4qZ9CT5i53uRn8TMVzo2BZFRPktfgKy/vhAJbERr7MBa5HjQJzPap/ksIue3E4NC08L9V
OcsGDXH/DoMjVNChZLdz8ob82t1Xpnvzrdf2LGwDgc/QskbPI4B7kkd/yLkRpMCgTCNBLxYuDmrE
sW7c6qa0iHfpICPhUAhGtskl