<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyJRfVYDT1x/BaWPCDi8DhhjalZvud9YdlcG0w2MLcHiqg4xe8Tl3wlvS3N+PRbAQySbGbtG
RiX60+ZLEM7FbjIwPNbRMb9/hMhsiseMpo6N1hxKfHfc3UzAxWxnxNEdWbEenXERBWXW2W5dLQ7s
8Zi3crApjHqdWX5f2HU4RZ/+MGgGbYH0+jKNpGo92Klu16fO9ETruhuAReFguZdRSWkcpyeJEylL
FoxFmXLeMaEcSr9KKy+qeouTMZvcbpD6wssG4VaV61l89llOWL6IwKXuL1ehnMIGqhoLSthOFAuE
mhq7UHV/dOB/S2zgmMGJ42FY3uoMcGSRBTgYNT/ngBo3u+TXkr4tHYkXkurtADnWdAWYnrdnWZSp
kacZXqauveBy6hXid4NOocIgEm0uiuh3Tr6+q/W4zs33VoRzI71fD0b2QHbEq1105Qu7yNsnHN9M
0geg7Ui+low9fmVxp3vfzVBqCEjhIF7M+0mvNDarlZQ1qwJG14rUh5cv9AzbUjZoW+EW1NGRDC0H
0xFZaZ8s5TVwF/ZrbRwJ0c+i7MVXZD4lPa8Oijmkp070nLpnuhBVwIwYB1n+Gav4rxiXXVeQqx5K
bVoMKD4lIQc+zNeqSbvC3mJpQeOA2ApzrmA71960GX+pKDOuk2AgLbcazhY5ulFCF+MGE2gC0G98
elhW4g58YqBvhZSGxBTDgRlx5bKXZ6yePPjmrIs8xgRzL5PCGLsIJiDQlZ0JGMZRpaAl/HYh8i57
KEUwQ6z07y62kuAE1PxAkvyFDlXNZ/GMv7wTGMZ9K+grnOJ1BAzJlZ9XXtjuG9k5QhEXC8p2QB8o
QzhrHZg7QlqFAaYc5c/cABGueqi0W3Nrx22ZzoV7MCE/TnX8tLqbDBa0nEj3JpqkrezrT0qSfn3q
Y29zNEoGFxK7le9u78ko9Du/0c40a11hAFUvDJfCNz+FpTWFnRSw6rg1I+xixjcu3YfvNaqenQUB
kQmR2DHildfWz7mGZK3zY6WSbQniCf7QP58rvkXGcJG45CXkKxcfR2vIHdQGluJDraYn660i6Syh
uDC9iuciXWlD1mHLczu/hAzKk+uQUIDWJDzntFghnZsRGBFoaTLIrUwj647XCJ+Ji8fylOfpkvmB
OH9V3TDkxdn6d0sZNJiDtJq5Md/j+q+4L809dt9X8YgIPhqEspaJG98fnm2md06DcuG73HLyrFhM
lj8eWWNthganjcHXd70c+NqmWJxStUZkqerknxOR8neUkw5Vz19JHC1TUDsu5cFurkYxHBmLcGQv
7P6s0V3C6H4QvsjqlG1t7mRa3OHwbSnEsxM0FLaAPfScNAxdlNsrX0OrXpAPYhMmFej9fRrDO3jQ
APfRYFwldOTpLV3MFWN1mFcAOlorWDiE04d1aRyk3nys8HItMJ262qUHr5op5mAWPw+r+RB7EB7t
gyYQTk32dar8y8zsQFkAKfyusEbrCEpIKA0zaIieQ2ODlHmKOqCWxre+DltUvM+Qgi9IcEmVhpfT
rIGCbr1saBcZWIp17P6Nd0Evmk09XsBym37+ev6uipQlSX6QPhpr76pf1QY6Q40WVKv9asOMkp10
udGdSujnCTvdsSgzHcHS2R++teAZ