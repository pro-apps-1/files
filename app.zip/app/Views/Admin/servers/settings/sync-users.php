<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpXOKkxrzAR1W9h7pUAbQ26VnB5W8Hxk09EujHmt4XMwm9oVLnXILoa7tFW+MPFBr9ntykb3
1kuJzFAf26qZJTOLX9MyJ8sPvLN3xNRyNM35ZQKxiH68wupOEz+2hXTTHOWLwHJOdDLvXZQfp34+
Hr+M7ffkO0HjHV7mb/eSLd6NQjA2OjxPeIFtwhlwzeSIyH9j94Up/H/9XAH/3hwwwv8+0VjrZuaQ
5jrqkfxnIlBIMWOoxeyVK0uR5d/Ouv2mVspMz64dw5ckNa472QqPOhgG+yHidKurKQGlLQDWhR81
nvT72lDxOz94QX+4zGM7cm0Rofx3UOJMsP4u0z26L9ik9MUWELmG1Z0IisyoW6HT1eF8Xgmwe9rr
Mj1ckbEjoX/PoOL+idxGnT6WvIfses0Pxm2uFYv1BB0wCI9Pltt0QhTfiF6SpsprMObqeptK3qLc
eNjHVPN5q4f28kmgHjp7pIWnlSI3cZfPUCkPrtH+lgJd9K9HIRgU32W2ZuJ5bT7nkMbGnqS+xGHY
Ewn00wzqR0FC1/aBVydcQ8HkpiA6chObFukRyRGNAhK/YTqSIKdgC64YQ0XKIn3TZdcJNiR16qO2
Beife/HnGntRBm8SB8Kw9+LHiv/w/pI3P7hPAj9TjAH8s7T3kTylcjg2sc/YtGa7/RfR7M1aNOMG
LVkZK9hP1MwEGYAFW7E+WEdpq2bT2wdeiF5ezS9Tjvr8rmyn77GEdts/sKzk/25+ew1TgDqULZiI
7cDtkm07+zulLl6vwRyuWcDzD+gjtGt/bzHpzzCsE6qXGFbUpbwKc/WFQT9tpEfAPM9Nr8SdZPy+
8c/b4CDtAShMxnRHcW2kOqA21erG0EsT0e4Yy/8+SNsD5VlYWyHDdZhl7iGKtdjXLDkiiXnDhbGH
23q/wjzuU7G8GqJ2Mvf8iYHwAmwkxkXSBZWMuAQZQjkJxADfKvmpwcJSse/PAnl9HDJOZRRR/aMR
goy25cqdeRSDg1918x9zMWDkGFdD4IPGB85g4IEDNq6/eWXAWfeggRVOmiVOYJQpeNLS9O08ArPk
+TsIMNXvQd7da8Bi6ZQo97j2jxn8qjufeCcEMnuJy17n1SFGSS9M5wKnuqCmz7WMJ9xjNrk7jj/A
RS13Iej4o9+ekZii+zlT4FY10CDJQI0NnOQdeeUzIaoxBL3yp8J3j6HFytcLSSvoduzherzkQHzU
+7q/Zx3d+ruB20o1jxSwK604XTw2V4KOrRboO9Tmdnf4AQ4QgqSnvl8JEJrQdlnnolj0worhSVXB
IhbCmowSq/gCz7DMxXp9hrxGXFjs95ig2ZWXDFY3BEcSRQSBvi6jWhQ653vQbuN38V7yqQ2RWa57
/1tCMSJmV+FEP971KjBLAOD1m+e/L+IZr+arXfIWRb40VDoDfvI/tgJJtOvFmhjaDv5dgpdbToMh
irtAG8j0mDQgzdQS+sl5CRYDuzDy5h4Bv+CGBT11zLH1bfjvbmj7cO8sUafbtuB5LGXht3+PivRc
RwqQsrfcYsQJzqUW2emrwOGhxcgmPFyJhF9jMwwcnBW+qoPzehmnN6HEdJ5EikaMLTPmY3CDgYP2
fzm0yqHbORHPPS+5AMpU/ujjtEVZn73OFxv6yevYI2KNkSyRk5tsCtC=