<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrGi5Zu3eEenskw37KTLfyO1D2E22udZM/HcMC2T7M0XlnJhqnQ6LsIak2NSVq1a1HViGOoe
BWcF6fmOci/bHYr9vFFUvDstugSOkZMxI6/5I6C/aM62IK45sIplgKK83crapYO224jDISh6Z9Ri
LMfwiM+H1zgKxr9yzjOrnqqDWL5xDG9QtPpQ5LN1L0oJ89r6+AkgAOQHTdr1gmEOmmHoJQ9xO7G3
wq6lvczfM57NSVjuOTZwDDHE31resKBuz8bS2uMbi2AXEY+NIVLnj/1LIwfpOqyXnfz0MK89rDzS
p4LvD/z+NFfXa9w+fUPNvmIhpdOhGQzcdMNkE5s7ZUFOSS5LwD4LOm69kl2slNUI/S7fOs9uk7Dj
oodCGefpYDeEGg94allFQObAHerb9n71Jb1vfQVmZfT4fzFlAd/B/yEtrePihArqQ+ztiFXOkWHd
cQyXBVO2LhlrntwAPAFV+T4zuj5W4keMe7urcb6z1sfiN7U6WwywW0FncKDX5nBC5r1g0X0TpQ6D
MKJSfxhuUZ6BNJu3cU7DFlNu8H/OqW97H9DiId8C47R4H9p4c0+JuNDiRfHIHc0n5nTOZCqe2bJb
KfedbanAXodv9AzahFJpdD3uEzFK3Ic87r7wB7rPOe5wFc0FFczQgidja9RJsai84DagoeDq9PjR
B99zdTHCgs8vttGCNt+XsMH2AknFrsJkEMMkPN1rxJVbaCzwh0zqcamFXQ45FfWTJpXUiMGhstnK
IAB5WzJnHavS0deQjzgWjYoGtHfIovbRf/RKInHpYzo3/NNXxyfLiK5MQiulyZKPNqxa7kuRxEVT
dnnPq/wnCmx9cmEt4mmR/Vvq6XckmE/9xuuxybC8IhDdLsMEmgz6wHGDGsZx60VMGYsc5LAjUJDD
1TrwHE6FJGiwNwqYkvkQNypSp33VbsFtpSN0NCm3Vyq2qaLBkSz3ARQmqoZCruvKLbwujNnTfWUv
C8Gvn37lNUtPg23/FN2G7IdNIPJkNoofnJVcB0Ufv8kTRdqVNnZw6Zgu/zpyzPk9yZQQeeDu4K8v
2TdwflShsYMwFptHV99RTjrgQdAfMNNU8vMfqeD/+1rayE1B04ZoJDQnrjhtqYli0K6RdJKio6/H
fGpovc247Jf3Bf++fiVcW+pz5ZxK6H9NTxL+x+RzCiV3XV/Gs+IqunaWpr/NHZAWlzzik+6piZBt
yRVpxUSPOFX8Ax9rThm7rfCYz65uovQHeOYXwaggHX0Fu1mWRJU+hIBWk4FarzLLdwdd3EZ6nkI9
Pan3dftq31rGTPmN37wqHip59eP4VcqGoJInjIMwY5KP5J8ba8leOo38BscOhE/mzjOhWVWKvMMk
SGHrxLKoHX10ul06kz0FTuEbOsp+qodZJQujFHLbijevdTI4pHdIcIRWNl/O/dKUgIHPabWPGAqL
yryjxGR2puPspPIIAWbw1hpyjCyQeC9D2U9vcn22GykuVEDHNaWhhY64WdD7sq+koiFIFGN/LOzk
eSBtvAHEvh+4EMw+Rl23jXmrH750WcjUFYaDCacHAo6Em+va/7yLpnDEtGIWgTzET6apmkhfWNGP
FX4lYC+nm/S7wukiu4wp/FHOFm==