<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuitvezqgTgW0VLphBHiUvzVke0JnqESzQsuBcH8CidZR93dsBSZNh3WsNfs54VtgESbUA8o
wq1avnusMge08KewnjbOd7a+4MQwbP0Z+j6386rv8gA2BjJHlF2rpuQIyd8+6b+KTItRKhjA+Byb
4gLh/pqJWn/gHpMN1Drm8EQue0dvj/HX/r5KCuiX1zvjKMxI8+emL0kLdFc1TjgegqP0K/6KLJV7
7M4PmNLNcyiqCB/pX8zqu4AJrXf/MM52q0HMscOEfIpv+5PatZdjxX50arbg6fq06XpGB1n1lQIH
mrj6fbM3Y2QN4TejYCgOSIOhTI+3QqzFiNSlS1G9xco7o9G8hF42NOTNZFTWNXA13m1Febe5xldi
8CmOTNgtq4jOPHzy87pxH8XkJDKj0ZFWFhgGsWU8MXHuZDzl9wNHn4EbndsTYwGrzapKnsbwineo
fu3cCOAblgszsLyPmvSAoJAaHjRqjbPjwQh57eauJ3UlYmK1mRxVlmoxqhByS1/z3qTe0MU0d2o6
dpegQdSiFm//ntV4fawPYlYn4sPgRawK2KbfTWXk0lhgejNxmhZ5necfAbKHckCgBG+xf7H9aAux
iuumN7JjeAdv7oEj/Upb5ufo1fj5bokC4H/NvMxoziO/fAWroJabym+Bxs050Iyz4EN5br06Jsjs
v3j85NwLtMyMmySorxkSHIP9zvaHTTb/1MDgj5KdXO+txBLph7RHrYa5T+K5cZEMNHMIP3t1RDgA
7HNr9DPbJEJQ+lA+c2+3yAc7k55h2AidzDCpBhjfbnPcxxx69a15nAgBGx7QU+DHASiFpjbNEAWA
pjCXiPHGp4fY+rsQv6IczKODzw9VzXUeI3TF8kmBcQI9nnmvhcYR7Sc7qrH1EjHbYRUEAs95MaNm
FduYnvm/cO2rtEjSZVaiI/pS3yc6bYmPHEAYow6d7rz1J6jvRQeldCHWvUkNb3h4DK5KGycz4Me8
5G31UzFFvv3FdcMyLsL3xpO1FLEgjnLsiLnIoOTiHsjRfoi6eA8g/BRhXxRJT1DKJW/SY4ltw8F5
0Jxym38IaE5pGuR1sXHiPahTCHYDhwu9OA2rdjo8mUKhjau92kI2qyaj1dtmDIAQZdK4c9f1L+lB
1fUyMfaitwJwR4PBExP64xe8pNEjWZKl3jXuSA+6m5N+VbF962vavCulWqls2GdF7uhiwfJRVAHU
eUyryLwZRf/FHq9wgqPreSBV90QEqAoPQ2gWE65O9VXWgxjQEE7uvTTT7EOs1zHZdddskhMCQu/6
R6UPOFMWQsDGluXGlDAEh1P8CYYN7vKPOnjyW/SiX/tCK8qGhkJ1x/Lj/k9fMUH097Xk+va+J7ZI
9UOLFW+UYjseCqgkw3aLNkXvy+pZ2atqOeTmOXXvlF4s/8LmrttNW2bS6umhVAf0B30mPhmUdpUo
OGYMaojCJq9Klhm3nndl1+Dc2oCzYPyAQqfWyObPMSoWhkUAUxO21FE3t/KFcv0wZFXyob/YDBwf
5WyjqWb2yLFW+KjKL54TF/vsaa/CA735z95ceoWwSIUfeD1GRZszW0Hs0NT/iANsGKppwez7bpNl
B/W55JF3XfBr7Xmb5vlcvORVih7bvyG=