<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/72m3YKdJa/OG1L6pj2csJ15yitXr+ssSGQ5PWmi6x83nA0NBBxSzJrv38bVpvM3bc2TLQL
dT7BIGeMMuLCI7O2Go9vxedciAh+N9nxnm+VfCj8XHQ9czD9uc8LZ5HGxSKcAamez6jJ9XgW3u42
FO+sDLaZMPf7gmNb90FV/3IpPDlc3esfms9XBKZkT+rx2FHkImXzU5ZkfJyc2m2KB8LtxgZ04K+m
34ICfPhi4PIZewR8sQHyQzPul3UrLvxBDEQDN/Px4aPphoX2ab64hzVSx7ijP0ezKIuqGObqP4f8
TambCaYH5C3LyYaET+GH8E+xyPSqef7Xy/M1WeBBV/rO8c4l1w2mAKXcOQRG9OaAcWxl7OVzZM2Q
CG0j4Wo4nkXve2PksWCr6M/YYV+I4tosB4OSK7dDkZ23S/nJle6gi4tc4dIZkEd84K7R/tU3qaZR
88rNNVDbawI2sBLO7wQ1bMb1f+W19mGKJFZ7zhixbkk/sT5S2vgr+gP1CXNQ/Pvxfu59Qgxtprmx
MfsYv9u9kpUAhESgP5mkIbXjL0j0ZBasKRtwbtcblbW/Yhkcu/MYdj471Q3yj1jYlK/qp4ZpOBgs
qtTeCjT5rYd/w56svC33tJs4+cB1gzATUGSdLUISONB5qtWU/t0YfJqdVfABJcdNHMRjmTwg5qq1
diA0eD/Td6NqH8bGtASJn6bUcfOX5Ili8YmEPDDRI/0gRQveM+gYtkMvWfwEPRw1HoLK0unORxOP
hvWbeOvZtfbADiAj+BT2MvSXYZVNFzWtqjqc/4Eu8MsBW7dqI2r8C50Za/tHn7lmFNI2Ze3JbRyp
rUPRcmd5LdgHl6gSSM407o6tO0EYERZx84z34idkl7YWLj7X+iY/+gIcubFhIfn3zyczbTh3ljaB
Y8VoWfymviAT8tKgWyXdmLZIxMZX7Yl0tvFY7Fe5iC7xlI5/BZL3zMGqkby4QTdst/MzPqB/8UsG
IPN0rW7taXXZBxinANIPYslgrJXzK8t4qCjNfl7BaaUxKUePMlTvxOVBZvz/rR0vPkzlQnq4rMDF
7rlCosTojM9yfZg8Rsr2W2Ctu382jdHmYrrH4MqutuTjLlQngAwhzGyEHvZtDOgmcieGcA8JcpHH
8CUY3CFcQZFqu0X4a8QsNSIl5joW8/EmxvXySwa4aYihvhUBaOcjU2CgpBxUJDXZL5t94ELUw/oE
f7ZdBYEsyjS1zqW+J+X7QvrbZWx7v8UZuXnKZm+dAztSDUKedOHm2SZZ00OTrcRSRTotKvk83r3H
etdWdatT3ymJSAFMrilnfe9oOvC3cnaoPGZuNDpugEbK4+VlV6FE5vgjT96ggtQ2wEKe5GIN2Fb1
wTJqPVGCT9ZWHnw7K172JWBSPwcvPPietskwcg1Ldw3kDAluo5Y9Y1973JbMaWY+M9CDcdXh6QGB
43QMcmAI4D5JWGPtTH4nQRDyFWFoL5G4RsXno8WT1auuKx52hdRimUCzOto3jMplHZFw4kQQe72l
iqqRjp2VCLTRx0n2NiJb6zXXkx1QNA1IbuPaAKzGFWnPF/CG3J/v2iO5MS2DpPnreOvqDi8dXWPa
8R4gPH/vVATJz3D3lKFnZDG=