<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpJcN42gVgLtioJ9OtGmmrbiaquUaPA3U+0DkDFnXrYaaa3Rml5MGwwgs+envEdwTyVFPQT5
bA+KunqeUO6oshxlNXqGP9s8wHq7gQD1VjkhwJYHI55+2pWGYbUfWGuRUyStns6vFnvEsHE8Zc68
q7e08uvB4pst4YnD4WdjHsr/Ad1iiXKoejJ8dcd8pBuuRfujrSgragB6NHQpmGvcKJyl6izFvPXl
I9t15F5q5Bz2fa0LWkpHAsinEYJnJnNnyqjgGFpNQGqzzeZKqb1s7eEL4+RSPXYYrpK+lsngo2AR
KvB6D/zhpHUOaFgGOsw4To21ttemSmxWUI2wgs0SzHlsEQyVXFVL56pRMlxh5Nme5/nb9ok01Nrh
QDrTjzqRqljKoSpkQYd+XVzPx2TQFmGNdKWMryTPmhxchet8wuoEDMHoMNwy6GDn6A509WJc+yJq
84a6VdsnOCVt7E+Lfb1ii1u8gszexvXyLBkvj41FY4w6b/dsupxITgBHSyC/CLHt/CNezjnbN3Rg
E8GFzj4g5wYqCQRMzSnycWgX2GYS6hB87JAyqcB3+WkvOVFNOG6Y3A9/fwjYQwZeTcCcdR6lbJKb
xOpvsKf1Ra6z5xym/dEjoSs8r8zHcNndb4V9X5T+/YP52WWj+/m2qox5VUU5O7mMyCxB2jEDzpi5
or88SBBbQcMGX2UbMvn2Fvmoc5C4ZuOQQx5uWlvXyYF6QofBS2gVwdxQ4sM42Vc/SuM3QnM92N3Q
BWODE6XTRtQJe50zCQHstLn/454qeXcuABBUQhQQy8UcwfJlJWL3dkVjLY8fD53gPqZthimpm2dz
fS+hOt42YDJJ/l93nxLg/jBrtzZvy9t6vS14TBCV2Eq31hoSRtHj2mw+B8yK7LF9jgtJ+ionGBoe
Kb2VGZX02qsOS+jhXmsw8HBh4txU3GN3yw7ZuU7DjpFQZ4ptqff0VztR8w+1BItmiNw02htcHXda
9nW+ME3MWT7WvRfQ+sxQeiySPxevfMRBA9HtDGuPC1rQAhoAWCMwsgtbe58SvuG7t2+/9JwGg+74
WOLpnRMQVhFXsta/ZUc6QBpawT7hDXlhUcviH533RrDqTkAY83DgkQEgBCs1EvzfTYBRirBHlRC4
cOmA3jR3QIfQ549PSE0Yp59+U9F29fAjHDzyb98sqJ2NWrvsnUK5b4PrSL4DFdqfTO068zvitJK6
twvdCrdpa2YzTc9zyUyscQqBocsRbzMwPEUTjLgGv/I14H9eaUHRXI6/hdc4ghCcuvbNdDkJNLC/
WrVwuKsEKMmaMLp456MK/muGbeTg+4JWNtf4so8dBJdms07lj5v9NABWep3INSn6ZXk+ZVSTA2NM
a35OlShozEArKrXc7E6km4/IVWKfD7m2n8k3ER39veVDP0qAhawJcWhv0MHti/VW5Y+lngK9ZjqQ
WkYncL+9lx4G/70j7Qbggt/7lliLayfpPowIOR/26uheZOdWV/Nvj2HEU1mnUTHQ5yWveJu8UXMY
Kr8FmLPoyOsotY845s3s8NSSc/7bQAm7FUSgmhUG6dmS2RrHWlaPHawzbgtGr2GaMIsfO7fcntn1
+6i1ZvaCrSpaBP1f43QtA1SvrPy7yMses/H4R0==