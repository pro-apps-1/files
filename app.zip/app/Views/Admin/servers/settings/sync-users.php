<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzNXBHE/VfOaHYEuC01+UTBMwke1PC2HJfYuGeAiG3b6UWLwIvP2Y8asNaISceJHGxnJKp+8
miFBkQez3YLQCE9PiUk3g2UDrk1LYJCgbBmNV0g6/K3lpvcb+FB1stA1b46r5/PzNFObOUFHlvfU
faEs6I802uQVTLxqVS0z1xc1RYAbFf2+HYKoc9lFV0o/AtL+Z2L8Tgg5K7oECHICgOf+6Jr6n7Mc
OvZnhmHLDoaVaKp0XuLarei52YsmMp3OKl9SDDLlWsO5PxOd80HtjBOot+TYjCwAN10p170RFTKr
Sw1DO3CPq5cUM3PVGvNAJNEOe+KYfHgvfl8Rsmq8Rx/C2jnicf8bxfNHNmsok2BsWTRqvJ728YoN
sd4whmruTq8uESwH1214eLSOMInDTNCEITMJEBwsJEj31UNvN/rfxzWKEerJ2vxhy5OfIr3WhJCk
AXrMdxmXNj+S3SggX2Y8MfC84y276KyNy++jEZvd/zvwZwJQ4nnxty+6vYFtWsqN6h8pWox3S6jS
187VGwvg3rQ8Ck8reLx7x2tVnphwNYH/nrcs2zrI9aXm6ZDG3fR4NHLA22SznU7UL+aLfIsrJuDW
AlVO2jjrcDvRSFfF4EEMf1zTzf8M0AZq8X/u0OzBFM2CqMN/7Z9lVjnYpD0MeyCMkitSO+Zd5jG6
6wXZKNe71BvNuQH0u0AQjW4oQ8A6H6r9QCU7ceEDDu+miN3FBHRjjeDtBArwpFO4A70zoI6wmMUX
YtZ4RvIGd6nxemCnYjoCl+Y5EyswlegEj5gsccjghfQnZBfgc1Zrzolt+A/PnXeX+9TIwiAdvKXg
MKQsXWXAEcsIcnpzGcW0X89+elpaqTvcI8M5AU4QH6LIm1UjtD0CMDGXRLuwDFHa9iKOgR3GOgT5
IKLozvKcusXmctUuNSiPef+zi246BFr8vkOnJ6bzmoo9kcGI3nbe64FoL1NZLmS/JOQNpILNRi/0
EH/kOu4S3/+BCLMavjNnEeTJAcRM8bGVJD6Oxl0d4dX/3lguL0f0riLYrgNje1fFejkhMrCgfS02
cHPGH2lqqPMyCJldLOegRGlFJLO1oKlcANIBCaSRHqjwqa+Amq61TNSQ8cwN5AQed4JswzNELXQn
R9PHnEk7i81yBq9ct+F9Si4sa9c77y8kcdXYWZIXJzZZpLXNAFgnYMo/NDA1yxc/u1NSK/6R4sye
1ISTza4RfB8+ypG24LJfmIEM99OMwEKX7kfeIuuqXHcZOQRb5R/dlj64zZXoh+XzS5BYw6fjw9Tm
Z5IDFPa5rCdtl4pc9pxmjayPiEArZeRMLoVVsT4Prsu0X5eR3TjE1LTkp9TI5sXGGOwR7s+fNVWA
pDNJ+RbAiPMw9VdpX4lO8GB590Rmy67au4STXltuQOF5gnrss5WD/xkjbleZoE7Ln10LJHuqvXsF
fgmcRymRTrX/n4F0eKzdHID27v+IP4Zdsvxl0C9N8gLFuV5FZWJPZugylVE05sdzz/akkItLqRZq
zFMYfK7WzCIRBJW6NEnGIs5UIi92KR1eGG6L5zAxhEzo+7jr7JYHovgBZKvuhwsgWGs9QuydRmp/
LDPjo8W7E6dcJTImekI1n0==