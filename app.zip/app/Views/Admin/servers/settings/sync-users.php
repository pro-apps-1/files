<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrbY2hWtyew/pg2Vcz5W1o8S3ybx20MhtiGkcdekYmbCR/CfYMDoyJV4/ZGSIN7YGa/Irxlv
UtM1JN5oouIAtbTBFcqZtNrXf8c9r6I0VEW2qyxCDUO/xN28IU+27HOkLoI1xSzeVxTljBQttNiY
GiHsZRJbFH2dX5eIN/sqqVeJSSiEezlkHCPzci6zHg9NzUD2tFj1YJuz2OVjLhly4SU5t09Unxnk
tz0IBVeSxtcVJeh2R8X391PthfOAoeqkU1KDUhWeELB5xncJHZQHAvYmnUyFQ/Gg5EmSBaUGziZw
CoUPRF+3QblGb2yz9UAc7VfWKrU4yNlKxOppC6K642dKqNIvEF68S7wLXRwKOSUHFi2NfjJLLZRL
Vn/stm49AFYCFrCMT3qTGgYUlLS6YWI19mltZEGJBUNBieWnmkxL3Ol4yNI89fkZBgSXaDPehcmx
aIJDeNDCSIES3OqzfaM1VKmjlVpBQ+PKd9zR7JZP//6CBCyN4nJ2AU+AxLaD3CDSByaswVnvsSsi
2J2NFw76meUvdVmSKX0Vi62IkCWqZaMY/FC6P8M/SrHenwKNP70p5atr6Bc8vLajeOsKsS8K9+wa
ZQaOQM/xSbzqgdBM52JLoVD/JVJshnIaFl+UEhp7wUWO/tnRaTz67sPrNAM0x/PS5E3CBVy41QlK
VNx9rhZ3X2vUlG8cyJ1vlHtzy5W8pzgdJ8qzKh3V+KSKrGLHzpqHKfMHatM6lKVTplhZnjDSTUDz
p1RX5flTtJP54h5pznzxb0+IZnpVus4k1ZSv8c8M4+m/p0YAbt8GR1tyu3UEdOvVdHPWn0t7ShYk
VCfk1gBcmnAWt4KuTbnAbjsZ7tmW6S2rkWcPImkRqi2+hh7//kocWC2L7QaYBP/8gcNtb42WLnEo
CitaWKzPIRjMfw0dZVykNHCudL6LOs2J/78rSeTikGU21fkQKRgASx4SHwVVWwQMVp3BN/QGG+om
SrKZp06pl0BG84va80QJJGsPotUOcwMv7VEa/zWnFLztM6QCzpipioJjOtKuppX7sM+d/B9VWhad
+3D3dFlA4dH2lMNhSSS4szNum1DpApGfux1NpdI3i72OJUw7rcHz+t3Tjgl5TUJZdWe0yzGps3M1
eLlepM0VsEKTCKd1b7mi+LjlJN/Xvl/oS1QJdYD6sicMKhZYJxRBzB3rpWOjyh/dhXqjmEJzLdB+
yhUYrl3i6vJjs1nGefs1rc1BAXANr8dVnLp/ZUx08+cTYXz3Iv/mjAZmr0YjEZkEc77/sPT0p9M6
mGQxWzeUBd2jIJ3/9LkxW3OHz3fvxGwYMtGuzT7bSHPlYH3m3uZ7Sg9h6vDztFQMMwZ6rKhpQWJ4
3hYRpCSStOife9j3rA7fjVDrwW/denahiqq9AUfi1OtnaDypcn9MCS6l6qsuDFXT4RLviSWRPxIJ
ET1g+66Tz9svokcKBnilQ43VYGY+p5A5DvU3PYclbF+w1H41UH9A4rzCOOiqt0UM3189QBgBaJ7f
cGJjZxjEENxXjDCJSNSPMawZGcf01oYB+T3oPZqKDbV0lTVE51eUO784USyX6kmIHhoOoR8Fr+46
/o8Rm5lRsg5Gyhm8