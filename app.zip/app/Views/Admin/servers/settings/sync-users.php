<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPm02dCgdqcJjli09wPeVWf+5dOFw3FVop8Iuej8KnXmdhKnlzu9cWBp4K5ANjI2B2/o5i6mS
jivuK7KJwX3je+KLEThnYpvDaXwCVqRRBjAlQEh973s0mtRyEyD7FTCZ701XcCYSDAE7U3smCrnT
/r6DFVEtsrHCZfD4SQnY47UL2IczAoDkZn2YlxX0LlMMIf3wOsQjSsUigO46tySOXrxE+t4s+V8b
P/1O6yT+1Zrg8Si1sBJCGnXEILqs4VfoNQxXRjHLK0sFFSqLpROcz/6WClveXKeLkuz+xYrz28A2
0aSX/o1BfMl9Qg7m49mT2L2Vkw/U3dXb0jCVpTwrhdjgROJmSfD85fv4DuhRkYJj3W62PB+eBP6X
qrNokZbCWF+4HvdAc8wARNzBG2GiH29pXnFBkRlorUEzKwRrvtDgWfxYIkuTpm9RxHl3rRiR6C4o
FkEGhcNxPEXPaTMx8SAsxAzQ5qftQ0fl00OvrAIXj5AAq6Q+AKxOrjUjFx4rY3lO5UIKdwl6krtI
ldjz0jKtvTSJqPCAfLr3RNR/5lwZU3I50XkslXwfU0E3oDEA2QulJ0UNz9bhSfVXCh5QI0JpZSni
vDEhOxGs84cvbA4fPZ66AwmuuYyxKaJvnxzyhRu0QJ0TxqM6/77CQTNQKm/zn9Dv3uotJ/DXbOjA
iaupuMgG508aDrp/RjwpdUzO613UcDwliQikKhyXfWO2ZxMkSsrPd+KgQfB0WWjYZKooHIuQAKSF
+fPtyBSg76c9Os01qYZGTRn9CEfuH+Dgb50ifdheseHnycId7L/u2XI7uPElvD4vv+7EWHlrWUbS
/c4QpxBEL92jErvn+Qs+3W1WgUij9Szm0xRxuNxopCnF2vCgnNQHRXMi1s2c/DeXBh/PvCuLqn1j
B0FQ0GxZj2Klk5GgmdBiTqnjke8382xumONaTpB48/EdxShCaaYklhOQLdlZhDv0A3+RuCFajw5W
ov1pTpL+dCVM7fMDQW5NYXiA/UPPEhKXTlEicN768iknBDNxDgdAJKWYha+V0PAdKdRmZ5sArCMd
MMm6HvzDdY7aotDVHRITcj9+yvVBqS7NQgl4EZXmy88Sx8uFKUvhXiipdUVRrGtNbjUEsfdB6NWI
IwYoW7XdMIeXa9XDRea6EmrtPMGNmG8n3I6M16V7DUpR3QhgzOVWZ3Cg2PkX6zTDH0ob8Iew8yJc
bDR9QaEgjRnxEn1ZNm+dQ6jdkK+ArQ0qEZ9TQ9/S4lfRKmJx6wK/w0OvD8ElKGNofh5gs/Zh6wNy
qbe/rQJX1ooWC9mQD8uf4rOqYQUx4dzN6HMOSSJWg9X3WLuuRvBGOwygD8KJWIg7LuDvBwHWZmJj
qp3vH4KUsoyPdFCSfTCznDHyUqwiaRXsBv9bTRjzTxGZ+8g70ret9TXvorRW/t7FTUf6MupXR3fC
mMNv53/zYTFEGCcJNuehnwcKg4Oobzi5Ohy0O9ZpWKyIvqR+fj+1r/CdugMPvfpEBEO4etkuTCRS
BFMVD9C2KnC0EZIEndm+uLBhMEUy9btzHV4RasnvE4rhX8A09FBR8F/y+ICO1GFUsKY40/xQZjS2
GxHcKZAfWfnf7L2CITON/zmIvJXWvL1SAYz8z0hXlaRp/Km=