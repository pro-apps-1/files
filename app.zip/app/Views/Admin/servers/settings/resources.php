<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxhgP9GFPrtSrYlnjs/srdCT/x9PEQ2ZWQAu9RDik/yP+yaEUNacwfwRfTouzGVw4byaHSnC
D/cACx87DQLsLAxdso46HjMP1ct6p6mYp0a08iRAMXBtMCebbl6pEDMNUFGA/wG9tFXaoBONICps
sWAKPSBdVExSm/Wbk1wiO8vm7ulPjlZ7kI18NtMfAOSz75BKc86IaHXKP0RqpCWn7MN4iG4f6sKA
J1Rc/kIuRJB6aYZq55T7n7ML4MTmBObf2drnTXGh5tW87FW/i0pF3kQEor1fbQ6yBghC3W7pr/nX
bLXgQApUVUlq42DE9Z14o5OjyJj15rBvIWhiHxk8Wl4G5HktrQUPiMB8Q5tsfHS1wuTQPyCmhhz+
yskSBwU2iIHetVTKZqsJ7McqLKb5Ab4irbeUJq/4cgSFAEZ8+wZZFQYIzVXmR+qFEE8NYX5kRfb+
xOPw8io18kfP5+GI4YvlfX6FOzmqi+p9tYXyaPa5z+7mjfH1bYvwcAZXLKVSHi3zb2qlj+dN41P8
CD4MEyXjWlCC4Kkb5SxkjwhRJTu1FG2Xbm141GUp0gA5FMoVd2J1uu7C/mBZrbhj1IawZbzV9wDj
AuiE2qUiCgH7esmUbt97NUW2OW+y+KgCdjuTYEhggJYSZ3Z7MpF9jhN56vhiBoFoncJtw35DurTc
Vb9GKmVCogQn1nnoU3cu9wtrpEqLC2NhBUZX5aJ+wXTEskfYe/eY7LW70+/jAoAQuTXQBHzmimzJ
V+LnwxNwI2EF+M+R3oEd7fKXV4IiXsaoL4q7dZXmrdMmB98m9Ugrg/729aWs3h81twpoqDCQb/oI
fS568gxjjTueBvEhbHdV01CqLfjE7yT1R4o6fF1EX/Cc5NS6jPj5ovl4uLKkAbi0T0NECGj7PmGp
tWQu0R4Nhb6QDif0anSdDIw+tERw2xR8/Bwv/RmSpuQMQwRMczcgx8r8MQhnlwanstfPOudsXJCO
hp7O+0UCNFJqGIHK1/z585RWS6G1QgBbCF5WMIPMzvdo3idUZLNP/JTPlamEvhWiwSaTlgDjOstG
c9DM1nkHjqJH0uA7+YKj1gT4n1O4s9hNVPGfyAMHM5OuHzkEk0lv2rXUimKMvFV8sXOcKW7M6q2+
zf8H8mVGsj+Ylu+UFWmhaRWOTj/HOxGtSIiJLSwJPDmwVefejpYHAT6oQizGExytqD67CBdcOPOU
GABhnFPqFLz2y5yTLkWV3QqsWsJygK1Kuu5OloCcu+cODW3NWunZGGvCANaRcdrsB9L1cYRaTEM5
pS3Nx875kHmoMIKrm1JMo7U7fmE6i+/kLCHZlTnLgoEhACa+Hd5DRYTVAJIHSstSX2WKzE21g+Ir
49hotXMzTekBxtmt5kzzJLVe46/NfalbN9aghjIIuqO=