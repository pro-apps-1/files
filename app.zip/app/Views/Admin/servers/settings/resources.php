<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn6yM/9D4Q3527tEqHFkZ8ow753YXU74Vib9OQhDNGlw/wB1dDRMX1B9dqtBuSl7Eg7Jcc5d
9RsMijBD9xlAffRBoJ63UhSYl0rDH1GC5ylkDYSTb6nN0WzbKB1mzdZebNYQATiesE8ama0QwIDv
6C/SPFVt2wvWXqVGVyX1gmQduvCNYAMVtBCXicgPCgH5uoJ6fGfTESZhXlA5NHzwzkwQN/MwbqtC
B6DOKG3rkyNqM0BO8CtQ6uetvQ/9XiBPOKqY8qiduPHCdVQyEGY+b4ss9uU+Gsyeua5feXFPkaYY
ZlDavb4Hw+ORLuHMc5kdmKp7mXUGWgkHB228JYRKUUBSHDrNWvZ0W3UDJ7vqJndjpdJZqsBlX3fU
MV0OcXsRn+ZX9cITGFL1mVJdqAhB6mJrb7E3mx2RVKSUuixI9iKMad9gk0kqNja+afASo8jePlZo
9UowAynUr/7qv+s7t+xtUTZV3bO13H7NeAa1Ia7lID787QrFhvVeRo/zt0aKiSVOCO141aUGStVD
KhV05R+qwRqrDCWEBrpwec8nfuTCB2cmP4u+hsd2RunJd9wIyMwpcvmksTTpOLQc91DV95YKYlgW
OorWt2OPjJhpcOOwPHpeK5oy1s2nyvOLFeWWuq7wWZ7/wbhAnFUhILEIFJjIexX3w7UM9+S13SDx
Dv6IORpjVMn2qWw6WTZoRbazNTO3bMMjW4VJ0R81Ohr5EIeEJDW2DfJtFfTIlvsmHSCnfOT7SZEf
BwYfJXjclO0KzPwhlthx3Kd6gJtbM0rlA9eD7u/tSV4bYal2azyKaXscDWXk9axGCQHFN0k42QBE
rNUnWML7Sv51CsSmZ1m/lYdBb0slMsm9CnsJPglMXN1z1lfjCvEe7DNxSVDGrTlFb2EPNvw48/Ri
+vFIw6QYL20v6+bZd877eSZjskTYT1RQKHMiDBMvooldOv10uxFkRhtsC5jtOvsFKz7qWcSPCHXv
7BxQHF978sbLDu2gw1S2Ck07/qSu4dU6EkpSZ57fq+x9MXCaoQx7nVL7qwwVRTLgoW2wq+k9RaCx
V4eBNX+/1UFHPthGcD8YicWey4jv6GUBVMfAePY1Vd9M70kyY0QbOZwgnmIatIENntb1IwZVQsZJ
78s4UuGAF+LkL6/0AhVSTR22Kg6QVbk0MOe7vDPA1wv1YAerwlRriuP5YinBR+jJl77aTiJ/ZhPm
BpAz1jaBIwmarXKLtOhAZg37l9qRhEl9b76xxUtpZMLqhjhOEHBsSYmlFX9mH4weZHcejEpXY2gT
ebPxNK+gCUCgQiHLpWDO5VZRPIJJfQ4vHrBDI/SKabSFM5woExjZ/mdD3BmXxKG5qMcRhNA4ZsmL
JZTuhFRPd0OWQm8HRPFMU79rQJPpZF1b5uE65cBC8+dCjSWElOWQgCdWURh3Jy2ffa6daoC=