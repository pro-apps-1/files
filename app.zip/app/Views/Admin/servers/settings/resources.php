<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnpHrUfxWYxD0X10oIX2kSNgJ6KMo/La+CfdoZDMYpsu8/4NGUVGrZkb6rk48Dgngvc/bdRw
D7tA57VIYOwjlxF/sOepwnahVwp8FkEzTygUSP58pCRLSYbqe0c4ifX4f6xsta0h/axeX5bkA+GS
LIVDX+uRRNIjBP38cI3X+pWushPGB9w1RfJyQnTjL/dboEsK4qkctvJSyn9mvw/KQrAjMj9j3aUh
n4Z7Nq3mCGPPniAS11rGvakx6mop8prJhTPXIO3yFzgvkwkOjFcu9tAV5djhRmY7cUOc0zkne9uh
IwB7AV/KRUAqNG5MaeD8Mezno5T+7d8FdEYpdx2fYZickj0X4nU3Ti03BVWw8J0+Lc5hjpqxCEa3
LkOATk08/6daDeSnS/oXMucmmOGlxGmgdbh10f1gsB9U4YKhCkB53krQsEU0YmlnBv+clkCf7Oaa
FxTN6TEQOumdYQuSvgvEdaxXWSmn04zWAJT4m2qzqeCh72cs1NagNLRHEFWWKf97aAigY3FtO+fZ
Y2H3IxZIri99Ft0J/D+rtlZTpI/rJo8gzY2iu1pYyAWLlVqc+JdaqAlG/6zk5QG+CDQdvjVLRIH5
I6v4ib54bAuEuUTrT0N1S4Wm4DyWiN5P3C34MmtSd31ZGAHPSU+H6xd9vJvc+IcQ26gcXG4JBWCS
+R0eHPdVyazsBUARVzFPB7QMei1j5AokzM7welbawM0EY5oDnZczOC63ONmq/vpMyCWNo50seWcv
tSZCuNadpGaz6yohAMaBoQ+2bpPNZrFE3slf3lmtKBNTfjWcrURd/vmcGYw3qVvsq7Okgh+wdvgu
SdqDEG+nTG6YV7f+vuuZOEVj6dJcUFsgRpfyrCPi52VGWf5r2GG+XK+HeeEtJfMnI53UahnlcXJn
ZvOM5zypTVPuFGIgUjJuf/MuBMCc/hEMWsFVBnhXA/tbn5yEPLZokh4vzyYjdyncQ4rQy23Pby7k
qjLQczCtelFYhLZyjIvMzmQnH+HuKz+CeP/2rRj33wqVLXlgGVCMR55cqs+KIcof/UWNbxO7pYvg
+DWoQHYP5G8vK/PjXhmuQGMuBIzA93E8FHiPtmIk8ho8QDIIaxr6LqPfl0n0AHt7IUHF+CLoUErJ
ASgIm6CTcreYKntO7L8U5kFO/sz84ubr5xRCQVMQh+fdUra2WRNSWYxlE9mIKeFNfg+FzwaUbmdq
CgazPae1vBnXmco544KCG/FOS1hFequGXdHtJOtaMGcZeP2Oczn4669fEwzLB6ObpT5pv/bU1sRj
4OLmaSWjMyzN5OD4q7Tb/D/xBzOnEZ6PD4oGY7fgijglIu+nAIMMHRZ8xLH0CQcO2J3z1jkovI6C
2j+LCzyPg9H9VMHNIEbhNtjtyBgNTj4MNKp0R+MOXZ6EbV30/00nAZAzjPw+im==