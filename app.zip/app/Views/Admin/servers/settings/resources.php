<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPomwEpspbfyoIlkk7WZBZhYUgbIybkZIMAQuyb3ATpKq6Nrlk76bMteraM6bn+SvLGak+1WP
NAhL2kM2N4KtGLb5d40/TrZm1sXgYGm9fZ6iQDQr+DgHT2tEymqBZB6zayZVRof7CI5sz4fzfODC
slwN5mi2l3CB/T+Tw7wJ0uB+wsOu2n4TEWK0MEuMVUyUM8UERir5kHPuUBwBr9ZvKHejT5lr/XvX
2M+kOQb+x+ozxJFWe+3GkkH8nWq1oHzkRykAnc82gkQCyqV2yCGmDldWe1revcMTiu3Jj56Gxf1S
qaT8/wfrB8GrMsoSdUSXboNwYytupZSWBIrRoWb2dximuGS2l3t2/tJO+LedRNcGPORyy/VkB4oH
3GQpEkYhzMXNlksCbjaF93P4PjkL507cP0CXmD6PcWCCfaJhRTCz9YtnwDu41VRD3MAnLpfvu25Q
l6SdcXR90gn7WP7MHchjUkcfByIu/een2ID3MMLL4lLkw1cPGZ4aIly69MiMCQyo7QHfHiXkYZFA
2NXm0l/Kek/yOWAY37DSvLfZKHeFgMYa8+90hctyFPk42UWjHV7+COsWgLsekkgI5q9lj+Y622OS
DvJy/8OV6duNkEnG2NRJONN+dwThj0rp9XLBewL907d/EoMjqizvkHd3z0Qo7bIKhRR5I+i2dsxU
WpNNYvIhA+rk9oTD+T6u61KmGi+fvFubw53g/KLvIVUt+VjfkrByliUiiX5X+ptE0Po56oZyzBJ1
OG/xa1RKdH5eVibbhlGjN7MkrNrYp+FRn7I1jeThwlml3kvcTXRw9eUFKl43NR653VaGiovk+s7e
uh2YO0SwGhx1ygTMGIKrumY6WjI9+KS3sUro67HXEP0XCDsuBz645TrCXKx6cmCAPKeMOHHf/AmR
yUqRZ+EumtkYlQx3pVSfzPwdOBa13TVsVuS6c5SOkEauyz+QZHCTNeGxDMumTd2xyjUgM/y8aw+W
4X+7APN1Qf9sdmX4TyM3Tqk9FlUyN9scvbBD8Pyp96jIJr8GxerNMYhEwEdyBg4Hm7mxKfTJFjTS
uURIcNYNE4wsLSeB2FvmPfsgbA2xNLDXG0jvdZ4u0EhuYV9s/8DmVCU3CkbKDkSCSo4BmAg274DP
dracGciTuSmZambHW1wInGzRIC9s1jMyseohwQYUymVzSpGmtRZZ2ucjN1i/KH9ie7qBR0dBQGwb
3oZEPPDu8UZXm5RySxESRGrDe5mJ42qhL8jNECm3OpVeGDZeVRxGznk4qaTlja+Z8WPLJ8VBDFYw
rArqQxqBwgeRzg7H5ybkh8E+VKJT6h8mcuo5J15mOVV5ZuDFlziJCa6VtpgB3L/brPLWEKqlAAw8
Wsg04VtxtZd0Gfdk7VJJSdlYZ6qdgluHsh5/AYPGCSsjfdIQZ5O=