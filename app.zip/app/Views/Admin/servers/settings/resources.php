<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtBNjFT7Y0tu7XOXr8uG57cPXQnqegsT69cu7b/TZ418nzc81BCWkjs2WpuUYcwY4ZyTHq/c
nSHguwo1jNtUdFqo0t1MEMkwXNULFLzIJwwB9Ljl+IrG17dU1lvRYJagi7+HPXIEZbSSLvjvG8Zv
xT0d9lfB/k739i+0S0oP0YXG+T6s5FyV/FB/xgTbUtjU/KF4V5lRC2kPugfxgKHScUMcNcWvpyKV
eqNdp9xHDokMSX/6ocQmLzPnG5W6ccrmwy51AWetD6Fa59t1nE8I/Q3FmtzfnNsWSdcrFUlWcERI
d9TwCb1Gux8gWDqdhB6057UdchvtTbSZh2yPUCyZ/xIFpRpFfOHZrCwXqxjyzpwCHu/mdJPWck1U
p04PXJY1dsTAKYO+UYjvYCKTz5RzomsGhVJtwUdeAvamkQzUbKTIxD507KasyJLb32uBxWux4Fx5
Ur8GSYg57b460UhL12E2AEDhp3LLrRFxUUxuyHPpLEpHgnBcYqVuLLIMwFlJlmueDThSFwqgcoD9
2k8tiYE/EXnjzRIL2vH5TdKMt38XJmOQOPTTXCiD3vPdtuyeinOJf1uXFQPnKwBOB4+pxcDdGgzg
5fvDqaLc8iNx/jpZv/o34mvDCqqQUzG9jbjXX/rQU+2ZdHB/4I5v1/siA7kydvKvk74K4VmWsmIW
ff2Bx95MMfHYxCYBAOxGjQR7KrvjpdABgt1fJJUtPC3qg9aMtkLWGNINwwAwIULa8zsDLKdOvLab
5gPiQ4QZRHMqlhtb0clW0MU5nb5Tb32U7k+V4wiRe56kbLwR+6oQRv/A4dTG6IeVeC7DKGM6XG1h
FcRnsHLCadPxNgXpmNKPgWdAvvlSJaKAemi65zKnf23Up6QnWz9OWDZF95kIR/KMqImbsdV1jtDT
bzLfkryUAT9y+kR2KsalSF7IJ24oYZ2dGlVBDbo8TZAkwYT32i/SWRPc3LNkGKEBebaiH36g7vRo
rEexVZ9EUHRohkNnJ2jLz+lcZjBu02W7l9KuKbpPcNv/j8mZE2WvDkkQmhLrVR0Jnf9Yj5yq0ONo
1vvSzvaxsHDTHNJSCWU1GJgW3z6sfXe26tzT5dAOCU9JrgE3ScAlRPNtTVep2qsXFO0lNzYUVEEi
+RAE7uNiWg1afA6amIhMUOKb3czKqqomU/bTkJ1iSpknZVvQro6glAopjGrFAx4T0rWPOw/BgbHc
/KwpgjnACP8hPBJZsO7xwdzBQjQEBpeSLG4douvofESfr13CZ+szbt/2yv/jD3Fu7LOGA5Tb01uD
dKHeX51tLITWnf/CeOcQSSh19ezOFKHNNzkHXQgeau1csoTI59g1gn4EAOAw9BaJBJXuvp3aFPHw
qU6LW4GemkxpYHsN4csQ2jV7dOS3Me8ZYCMSi3+IWYS=