<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvrbilRY/WRv+wGdrGU3Ckzf1VlE8/ySClPhHlMkN+06rmvQ0BKq530Hr1GnaZDgZ0P3LB3i
psXftBCA9IqIQoXO2/j8pUp0flKzl2ZehGPjvmxDwzhLZl6co8+JMWybtKvu+nzqKlj3Bx1axaCV
ivKw2fq42pqzR1UPSJjG25k+V8B8/pQHJ8FXrkz8y0pX8Lag5ZzleW9J6QHizv+Li5Z8QIshvCIM
krfe/CEUVS2qmAoqLiLWuD4hlr2ROzzOVGcD2opoY3b7mRaD5DgPUrjRXWMdPuCTUhCRHjISVPyU
Tzkb9lI6KXqJCDbAxjEzBF/3akcCE2o5XCkNnoEr5siGNAeTtWavS/MzWToZ8sAGq/ipfwiBGr8f
RVNhrLNGxK6YnqFWIklvdsbs8F2a+8KOzMV+2abo0NXtWe6EKx2ASMpgq1DFHaTi8kjurUxH1aQW
gPIusyotnta3dSwOpTXp6hQwFz7oUVX+3kbNGmh1gSA8sQjBxMqQmFeXbw0hl/dHO+YA0Cr9/iIa
rL3Mwl+vNisonmStt86k3/JBBcM9onYBz65z609GxU1orMXrnFsEW28zCN8M1N9heN+KZn/SHXn8
E0tHV5uxRNzmd9EMBygjbLjVdbiVXdPW2dKhnrRhV2rIahyhVwJ8tB6/dVw0DYfHsi3m9Ho6hhVs
Nb2UDjiABiuumhaQsk4YLCuYfzMH5Do5a9muP42Z34lxAWgIbDGcb5ooH+ongewLUCIHkswspyvJ
rRTWPAsrcazIO4NoK99TgFMVYyTECYIbJXIsPzX1SCdQEaOxRcr4hlGMsaLtfk2qiEcBP7KQMy5L
czMxczL1u3q0qxl5Hnlg7VvPLrhrjM2LkrLaZV2IUjSis8WpBKI8rR/12la/J6Q+yzaIQ0PbWnii
6ZSlyoQc48lC8sRxegAcop5NazLYfqU8lSiMeOZox1twAU53//bSSmaU66KIeDpFKHlZ2YbcWaZi
KTvZNWp3me4YJ6AxrWpBu590+VePzS+0LYgxT2AsZA23vYKj/ipmcMUgEa3pZRMmy8DLQzAesMI0
y7jrmvp3M9VT4HFvMlnuUDEaSheGV67H4BTSqdqSvOpDUyB92yr41qsm5vOMybBGd7hKtvnxexpS
lVt6oSGbRy041w2LhyqN95vsX81asWuHuM5fo1SVJJbaa1M2r1RkhmSPN5uGCcOJoBqDL/zQRKab
jOSUf+CpIc0ZkF2V3RR6zDVftBECsbN1hzllpe+4dMDloX5AaOAgsja/VH7WyLsCd2GpUacPDWHt
MOvNRy5VAB41rnVGEn/sotTPRwiW354cLOiL3cZX+9+uB+loJZYiWDrurp4fC2i+CkKE5k9VhopO
Cwo+R9Y44FLxGNmDo26kxVUWWTdf0fvIERVSU+9f6N1wlNkgVSW=