<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpfeKF6FvAZ6Lgd5qlyZK/gsq52jrf4E+fEuKAYUQcBfN6y/CyjerlIZZ7PRpdwy8svrWM63
Eo5SGAcvYLLpzPI86aQZxHAmT71D0Dhm40AFj865JzN3xVdcx6LAnmjzUNATw8ugXIRhWqCkv2jL
stfFpu3iKjYMoXPLFKDb3XX5jO0NEJizRaI0wfoKxHGYRR53WHnAAgb3R2550pEJTOzq9xJb5ZbR
Vnq4WrZi1L3E4F00M7Z89j2dckSKTuuFqyEM1wkSve3f/SmM5W9QCEVAiWPdQ7aM4lpsI7qDMahF
P1j1/ws/z9263XWMcfRzVKLgdQXyldjmg4+c/kn9kHoJl4nuDcjO0wAJ00U8k3AOtqKFOvCeJnvU
nEZUgo7HP48vvfGoOw0U4ws8O/4deYj+8HMB0+NgFlE0DfVGh+n10S7ig9lxbDrOrKgcdLQbTEHU
4ul2dDp0EObYBanyxyrca7pkdpswvkvXB7GeghHMB8xTlS0SaMdSNC4x5eyknoa+vLlAKasQ4nSR
/vCUBdFhuu5c3CQ1bYzSVM5TY6efvnM9DluHh7Qh3y+D88ycH9uLQDkBzDKbfrwiAhJbCCW2xzPv
7vuKrCesSTeGG2HB0laEyefwW44z7xrcU5YbOdKIIoR/R61+XxN2xkjVAlUAxWwIpTJstSpUZ/m5
Bbg90AwMQEQgTGXwP6f63hxFO5bMTzSIWPqrHx56ymOVdTFDYInT8tOpc6C85dXe8K9u6fWw5HVY
tJNmG27pmsJrhXyVOS1qXZfcgGneflG5469CKVMh29hAdkMCbVmGxVnKeHJt9ysT5DHcOfCmGvU+
fH0rlUWhZg82lKq+Bq7htqOHh8fiq/Y8cbLe9rTdAJtcg8QLobL4BJSwlcWqQkFtQuDJN6vokKFN
bzczS+yLAirXnyuOsUz06Fmwd4rYOkejy7iLgp665C6QB+FOML5RXXctZDvhzKkNVMYxIOAjUqK2
SYBg5Vt+zvxuuXrLDodcWM6u7GYvRWFDyDrH4216LOtyFebN1lVqxxXwxc91l8oA/u8wxNR6sQtU
aTw16cFTwRBLPAAxx6VEbiEvXs3cMmGl7rBfEhtKryvMZqUxnsWRoylE6HdnNOx+4gq5m8MEmA4B
qA85s0hGx/YY+ZCJ9K7mHIUsVGyJHbYndivbC2SFlUK03JM8+wDw/4gBcqyGNLkynhODcC8Z9FB1
8lhO9aRCFOqMS6rCapgmwUvkR5Sgadyg+A2V8e+aExKwnP+1lRadKLDxMwhApwvb7S0o64tyXjuo
I5J6cYjN+Reg8qbetMoPYN1N+mWCZN+ph8MqHabkbTmo0HaSBtcW942qWhaByvApZFcWA75wCi1W
FXvRDLhqB7AurUb9bh0/630nwr/e389hoVeDfxwME4m=