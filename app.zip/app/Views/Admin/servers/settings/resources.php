<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+c+BPpt4vRJZd+ulmKu7TNgmq3EdKSSmFY0RkRyaocnvLDFkBy37TG+FxUk2ED/nDNw4kSU
4UvXyEvNmAFDWDi0868uvDUJTUnRtxhnq+lOU51xp8RvACciZd1Pj3DdHWbvbwIzVVuuRztb9dai
oPXXvwvCNhTekyPN0YjeSE7fqAK9GtUIMgoJg6pZOKUbSqV8J8mPNkysyMQ1DwtSUDym0l5pPu2+
xovrePmQq2YEaG7tEiqtzeN3U5TLT2Hs8u1N8g+9ME/C9FKFr/I8J8bEJI0eSA8KJYPPmARVwBR+
k12YLFz2wORHVOKbVxjwZmizpif3shgyIBVN1YQz4hgD3EWSvJ92b0QOVB176x17qLV1CmQEGnXL
iewGant58rucfhzNlnetVJKdMDqjREkNxDVje1Lo635RmUKNHQe3532VkGFiilgppayI9IFm6xgo
K1dak8oLqo20+Y+5ztDXEuSWx7i2FJyUoZeVT84NA78cUWJObPHNaIg3nqg/5Co9GT3+NAGQ0UsN
kEfVTOU987eiCIVDFopKEGSZ5G0RfWG6tnmTi6T7kU3hW8IlZmC3KJkf34dorEsn5VSIK/xxDaA0
2d6+uXqnudjj8LmWb3TYvZBSvZdw+5Y1yWgvUeGIytmUj4sIu5wi53sZWFFZ5eqJmMFLku0g8YXe
L3Y8VsSUVm4QiY5wBreGdnq8D8V1VFwA6/e6KNzVsUN/MsvWQHMAAXU4t6jE9gGD8PIBK8AoSftC
SzFWajh+tpSJ/AeI20vPG12D6U/nCxvsPzw67t6gvOsGXKbmHdiXg+BVwXt/ZN9zSikcz9I0yEMR
VnEWIN3CkN/25ZS4Jf8EzTcXidRua0HiCbnzpY8MmQ99kh/t3I2tfG0NG9ujNafAyilyiEQGLdp/
WsvpulX3UOES+ttks6CFUBZi/z2TsrC+po+iIgH6eL8AJficWcM8ZttvD5wjiFue/V355KMHBjxb
kVqFi/QODJKTkIrSGC1IDT2SF+0EwiYst81Qqew8ipAeTcOMFJgLra6Jf43qqsgx2mXuAmk3aNLM
VDr+UdFir4phqJV0tTG1jBlf2FNRcFzQUgFTa+lx1Tzptjyob2jtN1URcS5izUYfhqfb6kZgObru
pgpgpCF1ybPKj4y4ToWxQGjHGmKQu6cw3TUmDKqMCRSz5vc+Sn5lymBZ4GIEofiov5aS+rxrvpKu
VBaT73t1BADFkOEexP9M4W3FWNLsJPpy5XeAylEO7k4qiCdjK8uC6KnSEW+De6YDyoVXSNb/acYs
XD7erdkD0mM9rjOJiGj4Zqmru2priQTdK3FHhKpUHfnRTtv4wCiKexuDTo/dFZ9iOQY0Ira7FUkI
NXL9/ssL632L/nfz0ZCH0rI8xOohrfd0XUSmMqMyMb8ZDRvJafnZ