<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx2nCOWF8eglrd2agn78LYHl8YSFs3H9MDeZLvXXaDW9exTighZJIgDZ6ntzQRp1ohTzafbK
uyQM+htlp8s+b9JHvTA+XeW9LZVfeAPYfCl3b0QB2XqfshZpxHO7hHQKqyVSXRmF8BS3z/tytzpl
LaYK7/JGbZrfqlGUnooWb7uODPjmX4iossYuu8/EFfiahjof9PlnZRGTAdQuYeQ525EAgQV2G0LX
hdhngZJmgWPVtE4HjGV2+wAhe8Tbujsy1Iz61djCcMQxLMV/zya8jBPrB3wARz8bxO+hhSjQRKPW
v3hS1qDPr3tVD6sIEK+AmVBKdzkzBhZhaKs74kS4zGbRSUHtVCwiQXWtI1it23V9u8biHeSEhz/R
j0IF/XXxlyfF66RVZrokXmHnksdaHWl1YO7Nn7TBeu8bkZ6lxxS5ovw1diK/4p2JZxmpFMxziNLK
XbPgmpcjiib1sUiKzfpmVN6Xwk5IRT2B9AtF48voh37cg01vKpJIpTO2M+GAwCGkT+932ezmu7xO
QagU2ww0iuzabH8ZKLY53VWi5tZCq9Lt7oS+gwS5tteAkWJ9TUJg0LRxj36NfWLk+553avpN74wo
uRfF7cwH7rZpyll6FdDHFfc32MTOJDKNLp7VqxBm2rFEWkOX6CB/5fLe556DnEWhyOl9uBVeJM9Q
AYlQVe46GEPiiTXApEk4SUCjlgehoXtmFHZxoc6VjUPV9FfedY1XoKkfVLKE18ydPXZvbkvPV91G
H3uFp4wpM5v2Fd9LHNf8gwThECjATPMrSSmbIlSVGVkX3FYuWkqrzaUBaeRwkA4x4ZSKKFIhafP4
h3505TLvJjamYjjrO07WHdfAtbaSVqPiRK0w54Y58kCeL2up8UbgxSovyljrM6ZHZSA1OdG7mgg8
s2i6gd7yOHv6MTWz4A0lrn3UscuRIUX++tXsWA5z5FIMRTmnONmegZ/DXks3dz6n02eSmv8oi4KI
0AsKu+JJ2BPROadaJims3VJufiqSzKi3MAHTOafYi21CtrLzMB4zATvytCDVwFj+srJ19oLWhAXD
Kz8AKAB006kIzWbUGXyvzLmISygOaGIDr++JjzVqStCxRNTrcIVaebF84WjesPs1UJ6HUFRPS1u+
pmrhrCjATyqAWEWBQm/CDanZJKO6ulwf41FCOBeQ8v9bZOjmDIa+moArSqsVVsqSvdfNUgS5OYIF
rDeMM5Nni3Bu141HD0/Z9TdZKbSLJY5rTnPbuD6Iq7kOhUhulexYVjO2ljmUUEJQ85xbNDk72NI1
D7y5IWNCp9GQWcO8YUW+6YT+1GPTVtrl0RM70wKSl6uLm31EIjCFnMp3CoudSOwrcFrtZBW2ioHH
p/R4RY6WWJXr6z/ab07dcxUQqWb5g1Ajv2VZMllgXXkrhzYJHjK=