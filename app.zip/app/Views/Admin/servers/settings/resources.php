<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmFozwjhRyoCSZDYY4SFhf/d/jIvv8kSz+QY2NlMYl1PVU5CWUYQVxrKEgE+2mrWfvgM6WId
mvdHjnqgSRZMiBYJ2JjLnK+/FS32eHqdGImeJq8Hi5QsfrC+Yip+ucAVxoHAvIb521rQbeZCihcu
306eZQd7JU0M+4bAkkUuzMqEUJjHso1G8G3j/goYolXoj0n0gXtU2jUvQuBigzDuykGiNIjyFNUp
+0ra7ldreiIgC9B8obRJTMNftg51fnK0robTfU7UZjZMzb/+NHsfPTbDxu55S0dvPJNr2fHp5ehv
MAlTKV+gkIUwQJUxxdaE3Umht+mrAbqBD9VzEy7BuhUl4ZFt8o7+paNQboTnwgH72C2aV07FY1HV
UPMfCYrCIzwz/vrQV3YzPiwleF+ipbSe472yXHsbDj8FNBk78JKMSZF+3rhhMuE6RPz8N8jGinPC
a+bKKGnQaUSBBsBzbw7DoZBcKNnZ7Z3lboHwh8dEbVkiN8gUP1OiELcTuXX6/2nNIBTNQk3AE+eW
2e8VJT1ntlHbgBu76q2LumPAlGkgr+1+dYv27No8H8xg2U1jMeqRN/fJOmAjJJxYDO3kEMdShpvl
2Vu5yr5Sr5/4eIiROYjKQR8RWYPS9t+PfhTnGsLkQXvF/ogMGEfjGJ2RvCYbEZJmyvxkNfc/eQyE
WkuXShLs0MGJIJReIExWzQdCKYfjMl4HUd7nVnp4ISwyMg1Pjt4LCR4kVy/O3c7uClLq2KJtUoRn
sGpCLfj7gu+5ObFAeng5theJ9AMZKfYf1e+3Y6OTxo3a7bqnDFST/zqKxCLXOQpfTNjbywbnlMCc
0e9V4WGNXV/LnP0107xKYozDSLah2pKuSNIqHvgSGJD0tDS1sxwMrKJ2DX1x2DsoK25W2eFLaR5O
MZrhonudLl83C5ERfm5bxVKqDzOrZK6fh2LF9iTQkI3uGYI/8AP1ueMiovqo1NtjRxDwLy8En3Eq
cO7HAIaZTLuO1x5eNcFnFWvE6XqL9OE7PiUSZFEZaI3QG/KelgfCAvk9lIlRiCFZs6hMlKmHd0bD
83NIHlLEbiWLiQ3CkzobpodVIKSzDuae649AOnHsiKDTG4TQUc7/Cc74tggoUhqJPhvCnBse74Gq
3NFUOJvj74PkxVEEUKPuDR/abQAgHj3kvgUt/yLGWmCxg+XhTKxTg9zoyqKf+kT3gN6sA+KV72XJ
fhcsP7toVCOIdEBIubdQOdAKOi4m4+PER+gFb+JDRYxKcF8pAoGo0QhYmbkZRucXr+P6EXTf+kgh
gbXFhoZWH/0P6z0F3OWR7Fgqvr7gmhq+WaQc2reho580Lg3p02lXoP5atC7thoI0cnhj6oY6hq7A
DEZkvvj8VwxeSef1FYhqJTu3mNQROQIWln6FSu8=