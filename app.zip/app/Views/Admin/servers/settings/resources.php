<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz7JcQAaZ6ALiH8CWVR1rwLG8c05TpYB0CuD3NjTu6kVNwgL033bYjD7zOhFZIqFYrIaYll8
3cS6zKeOOnE533VnB5lGdODvw1PtBANiDPfKdg9PA64ph9L4f+JLWcYNKv1niRQ5lDgTJR/qYccz
SmojOjUdsLRWDupfZ/5SV7JYHFqUiWJ8r9qLhcXW40rPpDIGTFzIWTgd0yqF7Wjb9Dno+ktERrtF
h3IkKaSLZpfAsNUUHQsRJGTDs6a1BaTts81p64gakEXNjwAn01lZhIdR3lsJMMcho86hZvYqa0Oa
67xR6nNP9XVaH8eqhGkuy938QEOPuPa9tBBlCRaPHwU3zV0hJHLWGN1WfZiFYvG0P8DtLruCtkLv
CC76rQaYx7DKZ1n+3UmZRNPj+QEpzw62AafG2OrujY6nwrc+1zeo2Lgw3zvmRkzIkXYI8zxt9gxO
d0CsfpTCJlXIzJhSt7A9+V0JonEtw5m9ntYOkWUW+/l8MyQ89kzcUAcKiWcs5cmRXvefYgW/HJIJ
5j2zfvcIuWBvspVRXH5eNu1wf/1GMKJlB+umPcCdahWxKrUwp8YRG1Ef0KtCqyd+P3yrD9LP1XQ2
DgVWeqVt3z95eBBan/FfmgIj8NI/XXOs3h+54F6w7oA6WqPCeVkCICoqMhLqCdxi3kZpTXcQP+cW
dj6ntQwdEBm+y82pWzXN7OKEA3P/WbN17G8hLQWlRWbaSsNOnbEKcIk1b9+S+zl+ZgsIs8OGy7nD
m3EMBdwOWB+75bIHBDXWytK5YidIBzGlrqB/XiyZOFC2CSWJn4bd+BfVj09/TWCPSUdNQi34jQ+X
TZgV9Sds78MNmudwiyfOyq5vmeId/0Z5koAiC+58PMnxW10Qe2HihareMYh+cBCwE72eHMw37OLl
uKBxahs7OO6lg1oa2GLA3fQ8ZJ8o3NB/cLYI9Vpy8PRHIZC0IOuRTZ8xAaGAKlFZNdhUT9f8Ae8G
WZFoQYHqcYNFrRpbGQDpQQbMsEB6skfG39uBnYqOl9sSQxSKrzep5mnlaIVv99eu4fk0opXnYZ7K
8LDTrIqFbNXjQ7Ghrs/zFPpgBVBZPCm0/rzHLPNUahvuAvl0GrtLNpI56I8gdBtKEC7fYqg+m8rl
m8EVN5/vS9EtFesRDCDC2+youBLy/SpWw6ke/kBF+p2ub5NlGjRNdzc6esota77A/84E/ldliv+p
zYGWhyFZMss5GEWS+fIEuZYzIN1yPwJl+5KTxwXTlOaZCdPjjwkitDI+bWRNbwE4ptUPq3RhDiK0
ZSbbUD57+6NVv4DOtaXSuW/HDCfxRBLA6Duv/e1KTWA7aGlIPAQUD7m7HZC5oPwE2a4jad5Q6kn0
JjdRfWhgfVsFGqmg2HKJ+SCxqJXP4xEvp1P4UA5At+6h4EF1ifjqeUEcooK=