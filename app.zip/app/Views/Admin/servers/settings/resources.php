<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPplf7S+7PURWNYY8xFcE8wIpq7bhGhvfBzXUKNKBi+kJSHnaIusQ6niO6tb+R4unk4pEhrGp
mjj6QajtyNeG96xto6Nmmvv8zXRDAu/3cqVNsmPYJxRxKfsYlGzeDEjdaUFyS4hAY987LdEIEIUh
mukO/ccyoau5WefPWJbBatFgI0NSaXiaz/Qg5tClBVjhpqlzUz2lZKJByKnau26029uJx3IXzDy7
UQe4QpLblCAxGxN41v6SZbEDNG0rVKZAvnweSdBhZmjDvg/bOO6oox0E1sxCQLZcGQFPm7ca2btq
dr1LJ/+QyBqq30lj5uRr1/fbbDqtwngjVyedxzXOlOmHMYejPOoCbxE7pNrMP4Pdu7980MMmff9V
2zuBHjoK+2ZvSB9tT097A0xSDUjBv5GOqrUJHk8+Zq5U37B2KugEzu+S1v52K05roaG4iafy66MN
mlyZNapYgtRR63bVOKhQ9AzXQ0WIEitK5MS3XlXVH7vpX983dkYu/ASo7RE08XbsunUKb7SbmvWR
CSmCIPtZxE4+VfytjycPpg3VGmpkznnxUSf9VF8Fq+pXpv0LiZeObmqedKU5iHK3/fSs8q6GhHbu
hBU2JEVHeoprYawD91RmvzhcGcgYKislQhg+sk6MKQbBbe1sEL7ZcXqMYK9hX+t59CCHMfe2ashM
QU1UxsJNUH/IQ2o7HcUF5ZvyqH2LxVDPLRSSKFsYbB/SoK118FJwyZXyp36hnmM63sllvFgbTIq0
eywFIS6YXcBSxVe5bEJnohmS02MefrNWs7SthlBrO7yGxBBzn3gMiiUJWx6ysskiHTPr1QU9oECg
Wzd6iyK8FPW0mBKO2Ok286Ww0GdKZBhj5cmFCIM/kpOBnaDEcMHPSSydJKpzGoKLaCssH/AtlNz5
NIgNxl2w0NsuHLiahq92GLFR5QfLMYA4cgR1661LJIGgWawx6j8TakQIpxZrQAC+WzhPrcT8Fsfn
WWbDNuV9c1BL93gxsrfBTllM6of0rwc/hk5citPakrqNAn+uR4I0s6+NjIarOgeWG4/mx/wkM4WU
OIAh5cTigrS4m7lShjQqE1O5yRm0Qb0zKu1ia4sSDTW5v1UZVrhqu78G8zxBum7BQSDjyLIsoQK8
od9oBeB0T5eOd6wPbl6YCfDhaeSXo1c/5ZjycMmvWLOdNSdT1q2J6KnPKJdQLPhEVM87qtXDXZ3d
O5yWCbYkxCR0aBfLhi8TnFYV3OaoriBjfrhHtwJ3eOAiwtsiR4XActfAA3Hxr9ku9TDeabqIANyQ
sPRt/HXEn28pa2/r5pSupZ4vNwjnxN6QCGcI1jv4tfjN30O5a+YO3pJqkHNDlx19YVm8RiI+ye7r
cALxO0XAZ4PeeKb/CiYGwtjQE8FsgW7S9rD80oNTsg+x5zFggt6PWDS=