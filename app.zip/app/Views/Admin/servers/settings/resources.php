<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmeiY+sOe0/2PUqUpXfzg4DsFODd9UyeNU6Um+pYiNvzwMt9jAVZIrwiuTYSsBklOgjdsGbp
eKan5kfqCl1+IRgxdTUf9m+TbiWNCGg3AemIWgpBTN6sLc798oqxmicUUcgoug6PS1eEFltLDFDw
zUB9WO8jPvK1APkuufH+23lGO/y5gKpfxajl97fpvoNcNFFKPa5q6pP9ufjFhoMZ3lCB2jHfz9k3
xVCuQAAgJEIqePkBBqYW51kT6GETFoksHWhASgHmtXrmAIhk8KcRH1+1U5eYQNKxng1STqqxdrVn
hXsyTF/SB6xYtBtM4ytqIrdaANMT0deeegekRy2D0p40FLWznFcgAWaEvLzHSxeBcOo2UdrM10Cx
bU+CNICaw0iF0P7ut6n91uugdnNBpZh3SThI1zVXC/F1EXB8hO36rAitA2A4gR6HyWHMlnT391w9
Kn/Y2cye7XQ8VAqoDCnN38jCjXjEmP/Rrnkerjm5+xtOlRRz7rchNCIVvBCdOWRKRDPhWgvF854U
cSnbiD5YY3IwSv9NyAhXD4FtAJwVB9uW4iJAoUSxj5XiT1gJ1lIQD2oV2ja2PKOteIJMudBezo+v
NNA5qUKHd+UwiTbbs+G3PGRrZbMRA8+69+ToOcqjSm9ZWox/BAFotsS8hxfJpsoGh/GWfeBwWy7m
YCq+y4ENTWxwAhd/bL1YX699kz/GqPkMv8DpQgcMDtle81SrorplVP7an6n9j+A87LG323sVQLk8
i2VCiZ02XMMQ/Mjn7H6GrLU7LLfXHYKBfDRzh4e68K++0aRfyc5zCaPXaFmD8GqTwd5CWw0iU/us
+s68jblBOYCUEB2PZaYr1LdXe+2Pa27W6r2K/5VtwU6QBjSQkXwLpE63JhelHum6yY4Td9gEmypl
INRANY4DIEW0u+l8TbRZ0yzEPW+3tLXDjgLTdhyj4Wr0rx6XmsQtcERF622uVxF6dGR1pyXbo6SJ
t+bb4IzalmB/M4ba2Y9WQXTYS5t/hTeNUWmxIj7+1CmaHlU0sqZYcP/t7kVghMtH9VmU/xubh+FZ
JHe+bVRXfHEHnODffVuY5MbThjMdf1vcbaTH9AZydGn+I5xEsY7e8PpbaKR1mml9tKGwJJ7c9BUx
3Jku4IQW6OuifvBsQAwVMvdIte7YMc3yQazHeOwsicUi28ujCHUH3gYWQDVZylG2uSAALxnRqVC9
vq5j1+CEXgjcpOrtg7oEw6k+sgw4muE466U7p1V0eAE+FL9tunVNMtApQPon9hBuIgxdUwnCYaSb
oP0Zh3W3RJCtifji472cv0mDPNAJcZPuv9Q4e/YJmFjcI3HGVot4kvxyDnFA2RmhGteWziucIi14
RfntcVCUXCpdQs7ofNp+RfKUvrCaXIjXhx6jjveLdW==