<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt2yk+r24G326tqkph0fBnY/C0qdHOfOseUuFe2nvH/S/gSj8L0+Pos34jNznTU61Z12LzhH
vh+OvYLzSDyNBmRG5ZJiZjtm/x5yo1RFBGGW3dqeZwhAMacKy7JVRvtTWWvn+nj6obMpY+Ep6wdC
7KMlVPXuqGpzbkB6dvMVq2sZiLYvjVAsuwGMKF0bIMfExf2hFhuJi9CrriY9CJznjusyFyGvrDFk
yIuuRpq7EPZym2/Cz4BVNcgDkQ17FRCwYRzsCEF1x2Mp38X0OBGOBrINoIzh5KnDZ7JB/TmrFl71
vNGJ/wGJDzhfyOJV9oY7KnLSsuL3f8SKGujXzxZ8DdjtchipwoObt0n8UWAVURmM3xrJ25rK4RAr
kMFP/TRlZ1Xbayb+kkUsGkqkEYRuoEcqwSspXfv3xqYnVw2GYclNc9LQO2O8PqPM53kQMr0DqB2W
J+Pk3rKSWXKcNTWtqnktsZrDL4KUnlJcCTZBLJfbIExFrFLin4ak/4ao5tXUtdePSX9sYNy2kWEL
Vdwqn9enpPdnKf0dpMBXD6+33TnfqX+0GXPMxyWLmShT5wEXZ8T8ccPktcHtoU4/dC7RKzO2al+F
fek24F6rpDCqL3FngGp6+OV7PbQuKMFNNpynuJaBQ7l/ashWZgO0y6pOopRoIoMo2yXUGxKXRTcC
2Rd+sA5taOqIT6JHGdF+1M0DkuGEdkj8Lm3qCNWCTWD4/ZRyJ7chlwtoPvZwgOSU9Qc6DGN2XDPB
febx0QgsH1dwLIYAcuoP2DxpkCKaVKnCzkZQM+3gdC8zBYXmXMUMbv0UP6SqjVImPZIfEpZEVCsR
OWaEW9dTOXVXnAVp5jQuUhdT+1+WEkMSM/eKdS7r2lpUSJCpvO5HPd22IX8iXYAEq5GwtPqLK7KU
n+2IoWXBCK0/LSzjtqcGNuRTcsz7CJElFYvQaC5GmnouSBPGKEZkRUgWv3Gq+h+3yg59cv0ijV8c
kQlbM8QY+hETJe0kkaM1JUQUOisJHm7cINfxnsigOQlIYD88I3IE2Y3g3LL9509Kn0Py/Oq7c10o
hfA2jYx17LR4X8ntG5d1NwmnjupPhzpFjCNH5PzlJbHALuUOtVunn66kLvAplX58O+0LcGk8sXgz
KatGfR4TBaGw1+9IL02mSA2p1+gxHdhfG9YeFa/iK/vou2GlRtUNYWhHNky/wVIHxawF9zZ3hnWF
8OF4gVATwnjiWe0Xxn7oOpcb90bZ7b/3MK2e20jUysbcl+FuyKSkpHmpKIzoMFrd+rPOdlvKAB1r
JH/EeX6UjCQ8Xzmq3YcuWWIfEG7b4MzaMS34e8vpk9igIpA5gRWxB+ugpDLuQcY293BnFPh8BSrq
dKQx7G6HB9qlDj9FoTlubCRpUGDXcakmNfFuH/xMhnUSNbO=