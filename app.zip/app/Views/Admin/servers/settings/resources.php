<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvuUafFgisQayzy7i3MRb83jyXUbZXZY8eAuu3D1ocysUcs1t4xvkXi0RsIKXLF3EenQBF57
UcXeqrs13mOUIq+6QmW698Tr2CEeuMwZcEDsLGQTJLJeicpi9tnnfqnY3pS9P4r/mcRH5BvEAfT8
mT0mxRFsk1c6hrQRGEu/iL3s7DiOmwcatDPqqF2rE1rd1/PH4/rBlPDcI+0t1VuwouUB+QS6gYk8
jxVagYgrYB3mGOfuTHGrlc/pX7DBBpvc2pA34No6JafnWqg7SusbEtg055rbgrnRB+StdhYk47rT
i+TE/+wtoWEQNI8XHWZAdgFzVinJTfGD/cUOZ9bbmkXHiP/6h4nDaeE/X1bb0p1a3s5XoUQK4xEy
0rcAXhiRprI3rVzB650pzvGAi/TQ211fjnhE4IBvwcBtpCtjL0S+EAWg0G7zoSEYByI/HniosFsZ
MtTgTV+yQuL6DClCXdMvGvJGzef618O7jcbvNTRZeiWdw2gQq2zcZ5r3FH8VRk2+Jbp3Hkm+yyoQ
RSgWmph7FpCrJuBX42y+W2IU75Kazyd408xFbeMfydKf9FFaQgnDgrvegnHvi7LRDL5C2/ocXsfJ
Ke5Dc3ihng7Gi9dW3ZqGfvtyJbEiITg8kqWMnLi/bMbZA4cWVi71O7FMXw5ZqbHJ0yRE8wlNTK+E
Y4xCUXHkk56bU8iq6JKZ7MyDV/ZvtBtgR+Rbrio2gyDj9ug1qApoafoDZEbIX81EabYi+f1U3S5W
7L8dtHeYQh1rWOJv1W6Ob7rbYLKjcopEALQsyceXaRvRFx/QP0mjsNP2Il6vDmsfsr+Cf9hVJZJA
/WUwq6VpmnoI5cXhvpkn6AymON+d6kZ5K8M/CIUz+S4pEzSBllcd5TZArOnAtpv07XW4mpM0snVa
ayxeBLjGs6WekIqpmZjx0XV9EFIjxp2l8P7m46XBOkzC0/pzZcmsrp0vQr46BVgNERXuh+ZUfKXg
6G9n1SQ1BVyGbe5jvbY8CP2ZP6f6aI8I7T9yypQoojLWDkQVtvpg5ZFxBMK/3hAbQntKkLD0PFIg
TUU85tQr15EPo5/Pd8ipkwcirmhJk7i2COrIokyoRJNHxsSGpavGsKPPwm+Ud4Tjv9geVk+mppve
IG+tyaLHHYUkV/FNlEfROyxLkS9Vql3qmchyJ2UYG4bHpEqb3gRHkuvwSnLSUzxAlmq0xYGE7rGd
SIWhAPuUymDwqs7jr21S+QQmy2siCj+6GM8CBfcDe+SVJfDwvs3v47YM6k076ud5ZfeHzdZL7dR5
/pt7HpMW1CTWvDt8FcF/gCfkhyQIJ3FjrPcLzS0c3zDl3lSVCBNnyZt1ZEnw3qEl4rYr1lELRrIQ
8LM7FfzFYYWHe78kWqDw/kgyido6crxKJyLEwhIbdCJj