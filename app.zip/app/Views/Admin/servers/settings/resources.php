<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsjQ2Iffz/4DT9kS2L7cnXCD8HaGXoAmukeNG+9zdRJWfKIE7aqk93j+Naga5lBqXpERe8rk
Mnl1V5tslsEQ0ddEC9hIEd+irl+AirYOfaHAKy2yl3EfD/eq88eXiYwioYfNv/yOULT+XOnC0hOv
ZgN0ijkKzlnaUtOuJ0GiTssuFQBm8AgguVWWW7Z0yO+9yTv8eW+odpv/MJUHM53uUnJfO+UZGkMK
4wwF7m8urObG9BzoqJIb9OVR6Z644Dcp9633TJJLRuDc1MUs9o04TxIsCjyZPhKai0++yeKz+1ZL
DNAWN8n7/9uziUoZV3ZO4GS4QW28FHuDVZMaeqGuQtgHL5BZlpBCE4XWE1SIOS2j1yS0uCe70AR0
P8K6MEQZiWwlXdckOTzntz02uMUC1s0NGh+qmA8z0kZCrFTYW6Xjz3N98mqTNdUeIIzhGSJqTd4a
xm7oprYlk9aAjnW0f2wFQbiBRYDDBJY+aThxi/LzCPnEHNAmnL0XlKr4J0uTgVGbSjlvAukJkDp0
Rz3gG+hDKBPKqZWz6yMeo7oPQcqCgxx6+PMsMM6RB8KWSx5AaUigS/C2qW6Xzx1HuOXV9XtiZYBs
6U58NAW0e5xsq1Ak3N6e6cXlEuSHKRvBixdguoRqBWbuzrrWIW1OsCMQybRR9RbqBJGijWRmm62R
31uDHnSDVgyuU3f+QoI7oPJQFX1OPmFTqWTACiGZ2w5mk9GM9pfUTq+5VIny0NQY8jHO5xAMW54G
HQKeFvZ+7WoU6NOwO2AsTmzBQ3zmCKVYn4XVRR8PX7MfDsFa1Aw725WhJsOfmzRn/CXa8DQwzLvf
oHQx4lw9v92hu0HUt9329HXRa2d6fo2guaQO5Oqzzaqky+Aa8FkQ3Gc5SL5L4WZKTbAxyEYrkh9d
liqOx1uobhdotGsu6tSs5dYJ1EmQ4dC4LAGlszqBW5hMtguKRfXa4qWrdSi31VAFSyt+S98fw+GS
kG/PcE/dfMJXn0YNwsIRNa15ss0RXd7ZS4bnMpqiBw+gABpLHRvfpboG00E8sQuvupqlh4sCLbV2
556/jlFCRyfNNxSjBOW+o1yXpNW0zngaLGE9AMV3WBqrkHoP7cjOIPI79Qo4H2ptGZjFSWxG8weK
hke2jo+NHWXJTBLr2fEWhofmK0vxbPhRO/gaVaOzMnh57jkeTcBXWz3X4/zVBabh7RgJkv09DxAb
lZ4rcT8idkLaKdvrkfqjfwcOa4gaeqgmdU4+b9HMV4U2QDpg3IZksxKOsX9trSTG++Sz68J5b1Ey
bKZDpZjgu8zJqxuzcJk8U/qYdGvwahzVgwseOsMv2WowFZiGS43duTMR9QlPBvzaJp7Qh5PYppad
1NRl5L/tdIMS0iJKVXuxie5RHQJCIl7VWWEBzkQwIu3tx/+dpL4/C2j1hLsDwJ0=