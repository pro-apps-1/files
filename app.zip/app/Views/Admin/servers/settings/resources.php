<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPottiacpQmTkIZOdQh6Kze2TvCWm1/WoHTnc3b1swnUs8+8qqXGT0op2i8rn+htkiz6AMFvB
lj2KyH6c/OYZf9PSAAVZ8nElDUppfa/XTsm7HehDfHQ4BjFIGqqY/K7eA94fpw9GXXPNUaBjNtXW
d1c8IBp9oVaWF/OXvUGdT/scbr6vTyUqTx895BULni3gpGCSvRkEd62mXIK38mSM4slw3PcZq1sK
GhBBwMB+Lhu+ErXop81eXb1j+QweBqA3fH7fUKEGl3ILk7yQmJhQo+ryPEpqQsngJwMR2D0XB62A
DhwuFVzBDdpFflF5SfTtRfv/mn0s121HrzRAnwA0p3GP+q/rsNmMl3zYkPQQ+RH00yBAL5vrTnim
1xVtawpQYLmbTINFt7bv80FgH+1ntq79DKHIpTL8R/DyMBuz1Xxq/HnaCumpKCYlYejyC6DD73aR
jdbixOWfxxcnk0G+SGfqzpq6KtOQtBiwihUsdMba+UrS8pMq3i4iqqzgFWBXcVeALuallfRt2nDc
BkYvMPG16dMM7+aOeS4BJJVV4p0KHQu/g3NLDqaQI4E6mZkFXot6gWVMRy9niR3frAd+dGZQnt6k
A0Hqhh5e7voNrt46iC4DbXhburcwhmt9jOfnM4le4/Cv/tfltJsDgBukoYWLw/59tBl+IR5uRZI7
3I/k2XufOQMaHBQqIsqfllcXoH4BUU7+egrWke8q1780Bb48CPlhp+6/qG1gu8Y+yOJOUQdAaNlv
bhy90LiYJoLkWOwCSeWJxIld17MDx/sgHFPmvIuqYOR4wJRQhV4v/XMN3owS1DaUphOb+VGROaVY
jDbVz2LsuhNNzJrmVWFump2OsY+B/u1dFidpn7hbB/hnO10llKrBAjng1Dpi9KChVwdULJln9cR3
KAqocy1RiTGC9LkOWGX0+Shec3eNa5FbWmfqEOHWqi3Z5CZiApxp1WeIRmWWIsTd/xa78tlX0rCP
wmQVq0//Gx9LAMyqBzSPnlqJHjpR9NzlWSWvkD4ECS+KV+MdqF0oG4kHsyKfmjpp+EzuWP+akkVL
HR9RyIgnpwHSOfbM8Do355mvHsWDZRahQ+Pkk6I+zzy+9JV9uZMCPxiVSHfKtQCuUq0ij7Lj8F8x
TbBCKQFt3+6SXrJLXYEx6ELEE3/L2VbfMcKBFI4xQfOm++zMzbN2nNIq7PRQc2I7c0VMyRv0qaOC
JA6hVCANn9v96yUy+JZiCEXr+0MkJGtI3/sqojKKgnk+g41yeq0Y8EF3tsr0kf+0t1+dqz00KdaA
s1oJ1LVWUe71k1mx0WAiypLTqJzKuSte13YM8amktiaqHYu5IC5XOZNP1Ay92vtUwfKueTlSzRcD
ROyLoIdnTe9lPyRXGwqNAgYlFPhOcVajXiz+1fsQq/NVLQmPdg0C