<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoyMLiApoghrIjV3uRFO5rE7RKjOSwv1SwcudD256x5Fwx22VCVh2bVguJgmx1AeMUa3Hnur
8mwDFygpk0xcXbLE+kqIyIphnn5LlO30sqJW6tfJAitzdko5tdjKreQXhShg1/EiRsFQYKMtVnSO
TL/XZrfCLeB2zP2CX2xgoLVGvB8D/mgx/x4DoxNlo8Wuebgd8wsB59XB3edGOtsJMvXPo1BFUM4n
sMS1D5dsRje6Skr2k9IFPE7/VnM3No1/uSazbe2r2DXL8GlSdw9cbuGu5UTj8aZzb7OR5J8pwCkJ
TNXRvwu3gEgU7Dl7PsVwb4ebkW4mdl83fVDmzkj1sSsfWscvpUqPQFepPuLi4vi1pbidJsLXTc7V
hTNcq0R0s+5sCeaRhr6zJmnNsxmGwmdhJPBabiPuzYjg0RczWm163XmBLm6sVTU0zHDLC5gCAH4d
oMOHRQlC4dr4GLPsH1kdia6cpIUa6nRdNGRoLSndTvk1rjTpzhY0kHvn1AtHOcDRr75seL4ZfvJC
85WFNuIMoEvHhRXcEO4Ay4LPnnlgKBrshd8j9PG/Sh2u88YlJ9KG6WdriJX523JJtvyfJNpwH6EZ
zwCHpFP4Pfku9HTAUjDHd4z0pOqdykvT/U5hRj1mvVmIy12TZtz8JxsNeyXM8D+HEytxBvExDG8H
UcFH7NRSPGNVPQQBNQFl4j4C3lf1IunAgTHoivAsxaYms5EwkZfloaDO3Urx2G3QvksiyFdemgb8
fqQmvOXc3o+u0i+aRJ8Fwso6KmUtKM8GYMSFWX5oUAFkkKwzo+SVDV8lpoJozKr+PP7fV1xDpxzz
EOjxlD084Es74IrV71yDy3Hl65KEKv3zIIVFOMKaJByEdgO7uTPWItTbpjaw1rxtYvTPJAdGRVXw
90FzgC6LibU9pqmvUaGbiM67LTaE3fkt2BDIvFk7Pbw/vpY/8uQ408DCyIBURyNPliHZwCBiW/FN
8Ut0I0hSI3IUhTv6H5A3BnvKuyTnODwJ6SaJkqV2B3s/oC2FjAeXsVdjt5Oua8zzLS+tPQaJbiFr
ezV58UMS53hWLrpkI1aEPs0LG35M5pE9Aea0KyBYI5RxpL2+NsQTXDL1JhNZ0lhi22Y4IgqHuXtL
kj4ixpfzO2uPDBi4OAQxoKvn13QQR4G1ygSkGZR7TU1kGACIIlNN14mCocWToA7+B+2Qo3cD3svF
okcxndF8Au6MAWZnqECeLj+9BOg8ArJX2u5FHb089e9vAqHl6xZOPN5uQ+aXJC/DzwfOk7IpQ48s
YhEXifQ31MkpYh9I7ncIVI6a4W04QxrPznJl3YjIpVdLMw08UPPTB/uuCCYf/WCeTFzf7+Mg90ha
xLBffnQBmPFLw8pQvLGNiXpYcsOf0BdBZNA9q1i6Kcj+fKcZgCgOidS=