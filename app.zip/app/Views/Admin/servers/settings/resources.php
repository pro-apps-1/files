<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsz/FqD1q8Dq7BwgO5XYuG2Cq96UIas+mAwuEWkDAFwOHHBVYzuzB5Y2z4kr0t5T5D9qcvxc
7Ya2UDMp3JgW9T8c1I+wmRijWNHa1udTrZ/Ra4jy1JhD2s5qX6M5J0PbY42g7H9AKzI4g/t5qfV2
CUP8KqIaN2db1osu/x6cpEuejCx+9/aRNm7Q4QrdpsFa/kzQRjquOjArp0zgnOy3blNelVWS1bXn
4ixJRhfp7VO6HxSIw0eATpSP/D7vfQCxiKnUyLvyD5SgexbHR420sM8EOefbiZwSIXarZdq7rUq3
pJWXr6d8ji7PraG1YfGcbpFUTpCxI12kgbuk5T1UZhxGJTGZpNDYVRIBPd0LOlxvZB29Drflj7D7
dd57M9Fex0+xy4jEqBtwyftiqgnnIo6INELu4+VSqSzhiGfq1GyPBRNpRsg70WdJPE6zuwVvnz40
OL87P+4ghCkG8zr/3/7qKNvrxA0XrgQcMSKoS9mvrX2gCUUaIRT8R9XiHEcqhPJohWYI0S8mos3C
06coA9sXYLE5D6yRoTV+cDIK0SaMmv59kxDGNRiKChx3uaYPHLRrURo+wUQcWHfCAXFX3YVwAG6r
7QN4f8RxwhGLNvKzEyDCr1Hyuu6NQ5zICPiIq7w8XkGGuWh/Ggq7R0hSH9O4eYaE/j9+9TuIyu1D
GLb1341ox+67k34ebe8LZ9KXE4B0CVEZOlJdtvaOKhQSTIWl90ZjToXBIFtd1cIu9qSRnNQ7Y3eS
PUOtKBmsHpB4Nla4ebs2md3+mUyeESJUTulvIj5HHiq9wJjQyK9wOrsmQntCnSJXYmqf3ir+Hjw8
XupsppPrGTl96sNJuHWtbDVrX08vD1hp3ziF7GogKssfL79k+Gjz3VrPlsT6FYJRLlS7iylOrmiv
bOFPRYes+oRYzmtBA2NKtaW78FFDhcrVaPD2mjed8r2lMWK/ews7/OHbxLSOUE85773AISp+/tQW
Z5BtIYd1IV+cRpY4hpyxE8YobxxmJptNp13nq75TmOH+wQlq7zw/pwYuQv/T6ZzgumDdVmXogpK2
IoGKQJkxAj5n1BjmJyXcG+WMI/q3iL7mbWVD2Ds3NO/cCohqcanD9zMsgOYnEW1tkEWUrk9ovrsn
pjWwKM44am3npKKHb40+986Cww0vj2wV5vRarwAmGiP2axbVlDSaH1pJKeTpxKWQcbRQWY1D4aqJ
KekK374uxweZz/3CThDZedf3Rdr8XNdwJ3G1yxPgSqGXFKAicDw7jxXjXY2gqtIZ75tV/V3JEJJE
bMDEqAv/uTRxw8DmTjWVHNC644JnBkzV+6KviRONE7hqXrTiAjV0B1tCX5mtQNW2Qrt8TETEgT7k
BVkG1M8SKnLf1u3GXHbQEhYp4t4R1QJFb2tu