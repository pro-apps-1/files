<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyU3N93KNAMdeKB9ixRFaS2rvu0KlTTktkT2xsiDvvrhILmmA55oqdRhVlD/cUgHjVOR6HyZ
ce+h2WjUoBj1/DGAnekd2bZo84VWGUYQMYWw+/2HyVnMzE9js/zVctMsHZwDAlp/df40T/mHl5lb
MbPJUC20tliBx6H/EL5RSSWnGDtrpLY8XDxfm5Xz/wsIrfhKAyvqs3RDFIbmEjutpQu2VCpmM2xT
IhsmTFJNy3xEEQgXafTxJi7eH9FTc7T8kAWK4EbziC4aQ0LNW/MnLNDSvRKbTTxDTnNj/guCpLi7
Ug7dORTF3+SLzWTYpVqO76LQtDQOVNgBjxCsbebBiyANKZCNKiJsIUS7PveK4W5+jUDoD2F8B6RE
w52F/mo5YCsTKMIiANX0jC0u107xN+r/zdDnkkU9IJSR79IDeXiXQSapBYYppIPLZIhr2Q5w5qsB
BOSOmEFgvHhHV539/kQOgGsXNNelyTzRh0nhPMyl7nPL6MUDqrO1CufFjxOGIeD2ZE7WwX3BDoA6
zj9HAa+aTXuwczmACezVo561BMH7a3td/MRsBncoOlY+9MU/Wf+HJmfL81qn8jr1hOBqftPa0Sc3
wXXOUf2hgI7UVdgViuBYkHrkJnkHbr9aA6072WwnhyUtX+CozpwhFaGl1LB1bjvBgxDyUiOWM/9k
j/AgsdbdL6JFXbKQgOwpCglOWNOJZAT5hATz1noT9jSK2jIRpO1E4RjPIbNxIovflAKQDx0dZ4Ei
UKirAAtmI1bcVMgfNGTF6sLmlutwKt3lBcm8qcw3c6uQzQq83HiIQH/kVbjjTOVTthZF+pghSQ6p
LGuQigTX4XPWp9K88XUXrJuICnsbnMd8V5T+XvgZybL28Da83Ww+bHSlgUUe9lu0RKAj8lmrvEX8
uchYWs/c749BfUnNWnFi622CdruqBOCmkpFtTIrJ86k2bOlNdyr+kqsGPgF9XDosgwuqXbf9x6II
t6a70sGGkzH0CpIqFO6OPAHe8u7C5n0F5GMYV/2AyvUat6S+9CFTmqEEWyzFoLJo65xhQrdH7XSN
AfK987BYfBQE/Kj2Xd1bj/PWqeawdVGOUowHbu2uur/Sysbg6b9FCgExw6hDteAiGfGjQZKRCkZz
0RQ0ZFNNhmC1loWDU/fKfMx9XlF6E0b/LPtooIz4pdrpFfZiV1Fl8Ya/8TA5/A79U778IsmbU7CB
Ag5K0Qk+qBrXT6YnJjFmuap9O7cGbBLVIfQl0jlW1BbH1h4Fu6hhSCmSsTYfg0ZnN4auodYCz11X
vh6XJ0h6vCqbSzWiutBdkb10p3fPe9vS+uGjH5EVDAeZ4w2L4v7MutvbHouawUVHDHKSD23WrVOi
t78v3f1Yx2LHY9KCcbPf9FFBKILWLqgnCOkGliETztlIjd6Dc2e=