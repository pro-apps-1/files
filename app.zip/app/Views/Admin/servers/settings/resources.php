<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Y3+l+4yrpVCuf2Rn/k7MPb0sPDMht16esuE6xQ1pSiUpvvGF1ss2k8iqc9+5JeGAOVgt/s
FU3e7s67FayGyjH2Hzu9r7f3Q5hdQNJ5PptgtonbsITK0XOCsQg1UgNOy6BV5w82D8NoKqYH1C5N
lOY+FVMhNuWj8sDinVB3LVm2N4c53YxYcexDzoMZSg8wUZsExZ1SRCf1hVTgWbmJ9I53EDSOmmMH
q+cGCj5CHB03lhoIoX7/8MqRyvCUkjQgW1KM7vQgXq8KtuwtDIuffMsorITc/s2bfA8wMiWmcEuE
hzrT/s7rzpEpuNTNlJBgKMpyt1fQBN1HsWBR5VQZ45XbJQnaOJFZ6v9N3qWhI0KtnJDKcB/Ueke3
z6SmqUAjhrEtz/5CpKFAWnRzctcAphptZANIov7M15blvHg7ghW4/dhCP01d6rYQJWT+sWwR14lf
1SGRdOX1uCHkQp6XQbHJIsaVdnKmGbvjVYlxq4X1EKQlqBscOx/yr2QjduP/3+May1LhwAEorza9
SYfjX+z03GqUBU0Cki6IO+dfhKpu/OBJli7wL2JD56NUcv/6cL3dbyJbZ50aJhmW/AqLlNNxdRrR
26e/FhuUh9VFDZfp/sjMApWrSKo6zKNTFfC8Ummbd2//rR++nyknjnwNdoOWDLMHyr6LH3bI9e3X
tvYHw/8jqkOlDLfgGDJfjDvUwB313KRsY4KYJl60yAD04a/8gB1jVXpGnvi7vFA9BwQOUQKwUu0v
siud/IC7PBgHirPDF+lojFlcrSH5kCNeolbtnBYsCAeOyUSMv1FA2pGFFMEo6FTm8LXM2EZjJXjj
K2xn98lmty9mqTqHH0H2o+/E9ntGQ4d+JD0EXMAt5xqCaQsvJGJ3u9wX7w/JgHq8fl/38oaSsCxk
kSx4uxf3h7w/SM93m+WrPS1u4FpTsG4Cdp9hR4RmseialMkKkbphvXdmA26/DfxaGOZNyBtNQJF3
ncu/8/ycPU4NB0nKlp3yhPaheyVK/EgB24Dx0iwS54e0w1iaVnYJUkV8WvCz8xEyN7KcmRzilGz1
fvNliw68vspPMBYxMb+ERtVnQRmgUiKH3wpK5qQi2VTdzVEDoZT3a0rGlfFqU22wnztoZeBjU1Wz
HyREe62uD3ZoxjeNIlv7OamkPEztIR+6OjbGHZc272sI18oURGS86N+mf5Z8yxxPb2nbB07yDv4f
w3DJjjTYbvs3IBKrk3aGo1KOjv2hEB/+YFHHFrhaWf8R7vj6B3uRJkQgOzVSPPYXvAYk++ymes+N
cspqdlMh9MIi/JRHQwYzOBMDuIBnTXs0NLHcqCo/+LH6BFoq0yWgG237uSreoPHPsrkfFqmqm+ZJ
4JtBE4ZdNTnHMIDPa3CejV8WUl6wf5EbAFq=