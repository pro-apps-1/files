<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxVMEjq4YvyIqHUl/XjUXLpgiCtnKnRmYhguJb4nT+0CKmvIQSF6QtQfdfAv19ldDdgxkO7n
9qd4WqlxIioLXSi6TG1R9LMMCzg9LnU2caobAvWqWsVeBqblyUASnKUdTYHqhX8dndjCWGBbuWWD
ruyHViYy/aIHGtIwYeu0bGhl0PONl6OMEcSxG2MVwfSJKzWWfusyiTTOnlmCERuzT88Al4ukdXSl
Ot655La/GfnhUe3AjaSdlnmS9/um3BqkkURTlg30UZr/oXUPysMTD8bFfFbZo1Kwv0c12aCA58KY
I3SeFOmPoM0DdAhcT66/0c59BPDt37xloIUG7fkeR85Oq/9eaFROsN8W6Z/mAeYzuYVW703vonhq
lVDMKtwRGpY8Y7J1E1kJFur/GKi60C9wy3w4n9sTiznWbtTk2IgWVAaOyjf2xGLFGk5MKpeDrE6g
u1L9OK16Z2UiKuDGa8wq+HPFDCrbMAxp+rGfi/6PDfWaeWaPbXOEsRcCHH4q36ZeJ8ziEQpBYm/h
qGknft4p6G9k8Puql6/foISnsMeOxnaQbdjwstGlSWxF8A/42tNGBmHAg/tJt3JJg8m5bWkPQ0c6
NidRNg6o3jtwKZf3t2vW/bOhNH3SlUzJq9JU0Xk9dF5Su4C9COXz9JfEqGpLWmzmzMAD4+9u1zBy
dxyDYxyc2HwDRt4RbH1FdxAqZnjBDu4rSKMVgE+dYBnpN0JN+uaNXWYRFgZQOyD4+ilnwWEWi3k5
BBqTbSoA4haC8yl6Vg1KMPhyzedMMm6d3Ncd6/omrNsJJwJ9KU1h0w9B4O4mGSkVNRR0Fu/wz1Mn
T2+BwIISgU8MBYpv7Uku2bQiXEHVTOxZsOZEl4/HOwDXBy+6/htfDZ+hGvxp0Fl3nRnGdSr5JCuH
eY5Gxt03RXTNpQOtYFUZK+MoaPvvD8eNMEHVjb1WMRR4zBrnMGNiwdogJ9/BgnKLGWIMHPel0kEk
Bkj29Pp5RjT78xykIRjwOFpwoFP49vSNv3yo/tSNXKxuzXC7f+sAji7D+hXxZciQT7s63r/VAgUJ
5KWDw6sCO40oMj3ZXhqgkN8uN+UGP6oM/LV5nAPg4jr22Ji5RDKkL7pppvNVEKmZIZia3fvjJDUG
dObiY0bUNOCGoBSE5IKcUsxe7zMyqXKQoPnrT0WckdrfG4dOFuYgrqGGoWV2EttFmIzAyaOqnisy
wfTAoq6OaFFjOsUn1QM1jbbxj9AZhAfihmh219cSY8EIP3yDzZf8MstGTXECZNMNr1BlqSs6OO4B
iUQgnISSD7Oe2dpaFydSUauuornH16TSQS9fpygNly1bJ9EIRDhZpj13BweX7FcyiSB5KfWEfFgQ
95QDj48jpnEK35Vn2lbL32OwNcX0aNtRX0TJGmdTUlaNk1gK0vC=