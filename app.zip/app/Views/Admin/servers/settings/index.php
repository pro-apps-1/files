<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/JZrqbOK2nk9Jv2QZVBqTqguGPcwIhOvzO+Me68nKrcFnBWczIDLF4bzYo9gnBnce5DvXgv
kc2mdMhmo/IG+mg61yqnQYjbR9uUh8e+Au7QcmninDz2xvda45pJ5We9yWLa+ykr1JqbYJ6gQBv9
I5/Z1V425BGkURUoRxHepobfnNbXMReHf1V31Boz6SA8OKb7zj1eAihvrtueZi85+keNnF3s9yZ0
dP/a1NVzJgPPj/M2hfNhVcpgmIz+IX6xQ1r4LpGiyeWvHy6v3HJQcNjRMuO5OMh0alULbGalufli
7lVSfH7d3XGCswAoxQ9XYFIWktbhjTaxNcTs+Z4hzoQ1ADrGURxAA6X70fDWnA7cEP7h3Dk7lEuO
8KRkaTGHfNnnN5UgzDadU8lis4+4M/T1a6SZ/W2hcKXZLuxoPno6i7NVj4YOOgTHgObANlvgqFct
dvmAJL64XM7H9iPcI/i1RS3fJTPHUmFQPe4G4+DCkWDuKQu+31MJkyxWc3+C0yP95tWOXuEN8N5H
Ha+6QLUcXaPgfRS0t68lOcUlieMUt5lqDLUX8XDuBBzdah/w6lArunIf/RS3tiKKBjrriYxXUsHb
w1qgP4KE9UTXaLfy5+VSbonlcn2DyitKmSAFHKRBScoRaW+oQPmtcfsA/O18KaPkeX6gvLcrj/qQ
Iv200TVTnIXzoRE52HClK7YETHGFvcWoELTcX6TiemHVke+AmrV3g8YWjGDGhnlpRkEF4l8j5nZF
y73UVFfXBzDrkuKE84tD1xLxxBYt7TEchWdS0/7A24x2EizcN87C8q91kUzASjhXbhdtWymMaGop
R8Ag+OB5Laf3LgJa9arUsnEw2uNwfC29yHLYbwD2UR+83koDy4TXLgynTvIFzD0wJ391OxxzyW/A
EPwPW16eUvLhXi+I6TF+mTTNZUilPup7p1C8j2N6JRIRa6rC4v3tFbRJoDFirry68+XLloHxiKgD
8/JrP1F7Emv6o0r3/cT3YIBcoEhCeHJIKLxBKhl2J5gCI1y+MxFdysbiP7rMLkuJngCl0Vv6UMQk
qNfI4pl8eb+RPO3NvvTUBN3NrY77aG15d0RUy5MEyKtfiVx5w/GiEKkzD//uC+3Xh3/8I57/UyJ4
FzBUNhEgiRqVy/iNr8HyovhfhcmgQKO0W9UZOqGk35uzcGHaM0MUsH6x24PFey8WamtqHS5HPyo6
5W1gBHo8NZCADa7/bj+l1A4a8Ab0Fn+qhp+pD0ei4cRJPj5Fyk0HGo0oBj/UAu7diHrekl77pbV3
O+3dE3TBtx/aZ33dhFzhm0M0U8ndzBahyMFCQQN+vzwxexuSnOd/WmL90LM9VnBlAbFuxLa5sJCJ
iwJ+p+lKLvFGnU7fj0s6gPMg0dWvgcoy2PZWDI0sd6S4KnVIC3QnsikRgmmlqNwnWxo7FhGlj4/W
IHGEc5wCbJ/0jJUGQqV90VZwEOCSxhldXsQEO2RNlw+pds7x8Fwh9C0WQK9DBJS6ReY619qPfFZf
FHrtBSaeqbUN8YFYAWf6oL0ePY9VMLN+WOymup3rg5KXIg7VWw7b2vGxmPmXs2pJuVUzFtJn0shU
03ZIkGDRUCt1vIO9udDZuWd6ERXwDAH8Ls+/03e6EDpUzjqsSnIluwB8G+5p2X/WOOIE6sx12JDb
bm+IY2aDnEA8oRdN0+6yQ+yZEZYFSgUBc2K65fbAYu80WPz0qLeVGgVIC69EXlw8e3lcd3uhVMgj
/HExxowsHNVePkDtcSnoNx2tjfiiNzFJQ0AXwsvkosGWxS7xtVG2KSMXBcd5x7ZkAmOGnLEabnw6
QQQPo2epKQMa6IcebM8KqOQjyO6QD+miKjRTTCVM88NLyiiqJ0OCCgP+o94ffWziQ12OHt17cm0J
wehRl8U/2lZcr08LqqjNCm+dtChDXcBWDyKOqzO/FqjNi9oM6jaTwwi9Qj9OyQqVop6fODPzxAiG
r2ejjwIk/jEA8LUG1IaYOiSSc3wa/aNvKbluqsMSa2TMeoJ2GGuQg0yPN0sDBr7/Aubu7WJInRq2
7GnwWyYFziQhJ/M+9UsTjLL1j17otDUKXsJeuOUdR6G/o4ybxYnJ8plJbqvh6E0RsUfrkfgi57gT
QfXrCK29kwSdTk3LfbFVxusmnkSDWwGqubELoJQmreksfjiA8mi+kPlNOjWIrPvQZgpX+x7NH/0k
zBF8loUMx9XYLEGafJPD6+96OlKX/4k53JzgJ1HSiNbggO/ROrTMv2O/KTd1eGrxtTaI8Qz8Gw7W
ixqWPYMkR//W363L2AzdvfDafTxaVZyd4hsapJbopI5rQ+TBCdlGSmQ3uyQ6/B3vbO/2s3MEwgtc
oLDDHrPRo8jx6Xwhn1vA/hxxtI3FFoviLUXCJFnfAaJLjPjfRecoyOrmKMdswqs0iRb8VFipUvk0
4ddNW/EJ8AHM2FoqdzymY47+RObvsXN3eUe3HHiE6HYA6iC6bVDqFVWsM6gL21/5qKTMXOk/gl9z
ac3jWLtagoB+YFaFhx1Ocquu8peTK6pFk6kfF+1Um9TefPbFpc8=