<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwZNlx2OXmI7PGegapb3oNxuzak+NAKRZSzNEjR2uITr33R8obQcswdHsXpKTQoVGnNHQWlI
KNKI2wdoJRm3yQnmwTJbCDR8HzYveOcqkXvbR8qx2zQzvsmPVSa0ZDxHRuj+aiXKa8E49F6nExyf
5l7Qm3RAsI7MTvlU1tFEu9T+uJHXGwpUtazpwo2jgcqePMFzSbrbUHTdE/9jT+vxeCsB670+vqfq
ESwlARs4/IMRiPCN/4vV8rzNZa43quQ1a8V4hws0/3/QkRkhcBJvk2TodnPxXt38mIG5uLM+Qjel
AykZnsONeG56MNZKucxukDGbHcOhjsWYQTug2GE6EbaGeiFnYxD/XXTP9Kg0XU5mxvczCYjvNnwp
nkbkOVr/1RsHjJ+G49QMx//5xBv6IH/ZSsBOmToShEP2VESVtHUdaYyfgfDeamg8Ia33LyCpRzA0
7EEfumA2jVuZb5KWdb7obOySRDUrTnR6E/ExFuSM//zJQbMiTZwcLezv+B8FrW8CqFbjdCK6KXO4
YoWdOmbX2UHQ0AypZfV274ZWCntjn4D1+h4Qa1nOjrqHKTAnPCUhbCpPdXHdRfEIhBmL+wPiNDyY
DTtl2PqPY2e7bw25NaFUzCSB+kwVL6NftrieS+08uljUTT1WIQQbNSksNa8UTuONCKh22+HF0TRl
okzp3YnCBX9J3kiPgunN2MrKoWsHGekrSS4na+3pGgbAhXvc88oFjXWb7Db/nVRMVzjpaBwUQmcy
N+j2Q5RnkWp6vFrEG2APMhLWe1j+a9ybTNCX2MK+ltl15BzPeoASbr/6UIyHeuDrIkNMcj0hjsrx
xiV/sjmNRW6Yxv7FmgR8m7cKs5q/mbu+Q54kOrOmuQrdn7vtRLTw0sDn1hgZoDaJGoHVsHNjFYiM
OnDFVBZIpNOJsgE7hhS1VDsuHbqPG4Iwj7zgwsYW4J6eFr2Y8Fna/Nl9mTRRyt7RfwofaGjHVJek
3F4njGs5MNpxpZ/mtstetgLzNYYvEkXgTQLCuDVuhp5AgZF5KNuVF/SGgws2W1y1Y8QcmtQX15Kg
+hPmIc/gdsmsckyHG/1H9uGhkaJi2M2uotbFQoQlFP4/h2tbpKsk4//9XfdfBZeM8ZUGMpL1UygT
R5M5WCUxFLUBvLPXwXQEOjgRb2GNvyJGujEXviKePTmpRlbeRW6rzqOipEpCvSxYTTZux/7BQGpp
dmxn3kggjNoJ91Ij8EfrSTPh/ylE/t4E9qigEluj1YMlKMOQ7n8IdOmbUwvyFnXT5S2HyPAuzGZH
AYv0hDIrWrJPc4ErIcLQNA3c8kdnyPKPOHhig8xiywDHiLIw91xOMImU/qjsqCiESIodwbf9TF7V
+lkEEPeoVPpHDmr2bR4Ww6s1bYgn705Qg8zYa17OiPjvL2Vl9QfLJmUHR722yADN83c17biGb1h9
oy83OH3QRKIN52FAyfemJX9Zg7fL7RTAqnN3qT5zRlmawaQEGoepO6Zpiai5973by6lBC3zm0glc
0vOtcxDn7lDaXbDfZDCtLZDcvvqNV69VmLBh/12jlmt+Yfa5FZ1wkpG80jXBxtt3sGT7nPSwNJx0
OuBIrkDOhfW/NQWfliN/pS0wuR3CR7ISPqL89zJ7JmAIGiixC3MtRmX1XM0qBn+Mvn+7nVJWfZS3
YFANw8j3ov1MdjhHEVSjLqY97fIPIoWPTwxVcDXcehvAnCaIEJr+oFelTu+Y+20SCVoYw25t3sq3
D+Nshn6MV2wasCO3ZpL2jJlsyEIuwoMPk4zFCJd7fsIfUYYO0npp131icHWvmNjHZmvYb3B0TH/T
G20t3Iziw+ckTCgcXg69f1tmlj8W3R1FQgozbaJfaYQzmU4SqZgL/6nvND7TTlbYsftlO57J1a71
7ne6VgBlcdgZu58QSVROychxQpqEubPWNQzdkWNktx0iJa1BN6kGgyGqhz1+8AGZsLaQfuofpvlt
gpD2UhNPGvTi73BEQDnTCaairGF0yPw1zSBwTtt2nYIN1PBHwNBIW5dl0QiiP1Dy8U/+D6IAHH0v
6Ya0qYzPTFzuODqI/z3R3NUvoWNBYHQs5paqeMhGVRiZ7g5gCykLeig870IfVnmvK7TBjl3ZB8Zd
LG9I+1SNMyGODxiSzkqhFx82XHdg/hdeBYfPcALEmyMf253I/FR/1+Z0vVKHPokwW/DDXC7bGgZd
iB2bSkifGbSScWC8xjlS+U4FdoSfcEdDLyvlWfZpMKvcanqgJxOp0A42art0waBONwsZjjPv/cwH
0IiT5xNi/JMzmorQ3dJHapHXv4RS9kpIqgBEBxOXOZkB3kntIM7lYGmh0zOKySqw/fx0IRibE+aM
riImHkp4CosltdFH8TqxUBDqIifHWrvWYsk8Ekbe13aReyyE4cK910jjLn3iD905tVUKgVH870Vy
ngZ9TToBBXB6RxIspIj55rgTNe2BaDo57wk6Cn1u1q3XncxUlDo61umH7JFn9q16I94ASlS9MQ6A
LK4lcXvkrqgIDbhwJcNzHS6GSxGGSBDLzLNgdgSsDYxf1HgNewMZGMT0