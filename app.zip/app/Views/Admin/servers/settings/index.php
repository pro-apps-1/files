<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnmgGqyogxTWo/VMR3+kN21CzLxd9vjacgsufHs9fjl5FZ0n01YqId40onm5clOG4tCjTP0H
EZLk6L6D7Vd880DhqWsxAWtwu8M5C7qFlFyGxu8lfU92YkzPhYnfSgzF0lWR4/VJQxtO6H7A7oJj
XdVVlNg1tj4sXZEMBDbqQVRKd6Q8PFX5192PKootSE8TevEXg1W2l2CuMq8X2HNPhxawI/efDNgE
Z+i0NH+EPv0eiBEtcYn+VKu2e183t4zyPSeYRjHLK0sFFSqLpROcz/6WCYHWz6qAEQ+XQj8wE882
0qTg75H1djEhmxoAW/dKthxEuGOUGjjPkOc6FJPVxxEACGiwAIMjL6RT07PzdmjRVKJvvZ51e6po
GnK/HQp4BSQ94n2bTVrXieTY+fEXUxm4mAF0jYYZCdgG6oVTeejZGgVzAPnGs8zb7la797oA5Gir
jxv9LkbjMrNATyfuiGNlPMr0iiJEGEYfDpZlDEyq+tMgPBus5LGlU80WOMysfKE2ISUdrHZii4Qv
YjNZDjWWecRAdFeGNJQ2danJmB8iyucwPsJaoAJAQGwz9xd+k3YjKS5SeLtsdRWX5SPE6Co5yLpi
7lqHiExbxOITDqlyMw6Bxlou6mISGGP0tSrNDQX5NkT9rV9REdplOxqPbQJoWz64MxhYIuRUHi1R
FXTAxpZq7PnCuwCxGoNSkRbvWOCS+NnlulaH1hNuebq61HRbi82zGwKReUTPC16CXHJrJJh7muo7
wnx/roIIOBOXgUmcqjxHCxdT6qnSMt68tWXIylKfobfznVGxfUDbQVwULdhvGCUfXIV/A2vc3tyd
u6efJ+0Gkvc07XNOKPAHpzibHDd21MH9AqLJvCzelWGaaiGl0DCAuoH/CfYn1RmZ7ZiGjtc6VO/s
rHGo21g0dtqBMfT7NEa+2PBJmRHIuoNaPza3G9lopKzvC3Er0/36LwWY92HVqfLx5osSbc0F8NF4
P9HpbR8JcCp6gh6ZUTOEKzdbuC1kw+TyGBCO/sRrC/FXFq3z3NDBmRXpRPulImggeTYBONseoMfB
rTQ60V/Oo+qGzInPyQ4BfYNcH0lShA+F4xlEisbvRWyvQd1EiGmNU0PwcEE4rV4KIhATyb88tgKU
qxbLrWYc4/QLauICf+mHn30hhSNZ3raBiJECYSdHWWcPeW6HmUwBNoalnIfOa2Cq3bSauUZSLxKl
gUJrcg4RpfsezzmlgdXWTsD3JykWqB2MKDXcENUVgx1p2aSafsGzvlzC5Hg34+Y/TVB/3fqbmR0/
cLCo32hRReik+RX2VxgZqfBDIXl3+MK+bU/QJgom2LeAlZEdYZDURwdGQZuDz9DM3YnKC8lGdpN7
wEbh3Z1ubjHPy7R5id6S8em5/yTgC24VQtNprQsFAhFuAetj4k9DUzmlaYf8BssHS73hcy5JMdrE
MSo9jFODMC1JganqDT5XxvqkcRhhpH6FHquw6AQJfxt1rlvUQ7a12RIoBbiDUTIGODeEz5AgVi2d
plBK9Ofn1rNcIhWaI+qU1QX+hFTIJmWDvBmz51b/Ci6WgC8tf0ChkeRpjbnx9shkLdecE0u9eks4
VUN+YrGSnJh5pqIA2Hn+ibFwRONtXg/1kF1PEb0qdqUPZSFaDbuZf7GrE1Z0VXNmvLL6KfOk+fEF
KR9JghBgM107HFQeT1htnjeD9DlEuswGZkU0Jf2BMSNcnXSvzljkx3eEkb0AaBSMev99CAwTJLDx
i1KGRnQ0aEZ0l0LOWRgWVVXrX67eOJAcDijwIkzcG7ngX19xYutCqTSo/LF31mG5hAMlqX060wCQ
IFkohdzDJOz2sjtoA3VA7sEjrDpxHj9GktrkJizH2Ipe0e8mkNka55q5J9T53RPqOA+fEJ/7ZWui
RWL6D8lTDNOOCg6RZnHqD+CJICieepi+OkHQfzQ4iKbSdZzzVFCsEAzc4AN4SJECL82iwiZnN2fC
P/LPFwhSRCNWyjDpRihpZUWA025W9Q22QelM8CerUhTMbM207YWSiaAFKm2Gw5ntuyqAouyx4JFi
EcPPnwrR9nzbhRpIcmdjDiyD4zGlqmlTTHjn9E+eyPsbOcAf4tNBv9OLUrUSVZfKADQHkGnYqbI/
twdM6LMiebhMN0pLWWHzONPI9jBLs+nL+QKQ6JZvKydHyISz41AoJm715JOjm/BoThzOnFqmFbv4
x6uNeeE93yelyJFopyxXkbAK3Z/6lZ/Rftf6PgbZ/rl6Fn16L8MChNXeJ5Alyp2TniUCNeAQKZJO
W3k3p2hlSbqgRz4sLRzOfx0xjWEBCetE8z7PSxQelgPXPMtx7VNvZ2nzg8RWmiORaKDlaLOK8WtB
lrNvlYPFtznR6Mdh3FG4pX2eSHtHRr6u1dUup/rZkGfrQnfAlRgVZ/rgOr/dNnQqwtI+s5c5sfPA
wVZQMS/8t2uo5GBFM64toIw7WOD02Higk07bDIdPtXN846G6xfdacaO+CTAgi9qcSQ5leNh6csLn
zkPICf3p3MaeS6Q+5JfNwsMU6A8E1A7WHDXoktv2Djm=