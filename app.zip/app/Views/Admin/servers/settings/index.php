<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuOzI5E7lR1aNk3TS8lq6HK0ghymls7UhhgumxcHho0wkuz66/I81ncpz37fm5h3PaX7hGY8
tX+ZZapDEEnuu805My01V/7KEhfOMIz1m2nxdO+nMWOkozbaHV3fvxfeR+XWrigeNAavTXWeGfN5
s8UzpRYib11vAkuwzsT99wVOVsfS1H9mDtRJoNDEKyqkHPuzTEva6mFdwhPuA7IkuljcY+q3eLXu
tG4NPzcqRAgy+AVhVXDC8vrY78CxcsDFsvASLlQDKD5JiWCuRryR8iCogZ5fkWtqIefCGiqj7K6P
2qW+1VMOnGU4dbL77Nsy2klEmnQJOJi5fq7XrisQIsokBOtBwcYl/J+PX/Htsust2iMY2jgyDXZY
vKLQBjO/MsrQnzsXQOYhXpgnlpB6gwAYvYYTI6TlCe/uxEapAbLfebhz8Icddjx5+QCObDPn0IVb
d5t2cug5VAHabq2mBJfsZ/C4GW1h/AA4WSZdqOiBmxtpe6wTzciVVOd5kkCTCOyGqvuQTYv5pWy1
ejw66WmVKWu+CmwxxH4JmbnhxsqX31CukrHrGEbwBu/xVD/cPu/ZsrkIATTeZrZ1Fynmwc45D19J
JNCRDGWUtmlw3SQ0Le7BHEQ+bd4f5cDXHNkKh+BOTTq5kYI8Y2SKXxTimJ+UVfp7YSMwKzCU1dYn
VLQ78rKWWFTuis1BVPdaMqYi/r7U0uo7hOcmckvLju6Ix+YJn12LFs797B15sOQo4WIN2N0UFPql
BBEb6TuTtpQW5d8VL/ULjPmFp0a2kzitaS8agsKftWAm4tdVXLtmeoUviXQJdMmuPuXQEkCi0Qr1
zYJY7002AbkisG1jy1/89eKTAdEENEV97+8x5d6Bhw0jj9ki9COGa7hIK9+vlrac8x07C/sgXSsM
dScNJIxyxSomronp4nWFp/8vxqgS0iccjLhgxhXceBD7kgTq3pBYpwXBUmFCyLDcHxJTv5Ph2zYU
jbujcutLRVRugWakGAs/4F+8h57wAouwzl1aE8R0u/id8zk5EsN35fdk5g/hT1ppYq7oR3KcZF0R
GSb5/nq0UhomLwCReWSRS6BMM1TycSd3X8RZ/kjJ6WSwRbTsnX9kLfaMtbHSXuOFzkdjEZy0bAer
CpgoUlyIptFj4ZX+twOlkG3CI0+lVS9RodUesNoZ4XI9w6KAxPZ50gkfH6Sq4ycfejRQMBMKqnlx
ZEOUeqnyfsaOedHZBIrvgFvmhBfrBCht0lh6xBHa0J9YNWQ8IYxTg+ySQOiijrLk8+Sgcj5q4DwH
4kFtvyf8zTadpKfspHKcxr/zUZFkXdUBtAmz6cg0eeNLI/pzIaBQgPeEmWS5AackLvAHN+JkCC3Q
0NDOUNoxBzH2tkXsqMcOwXPe7S+wsgkIEhpYICeOyeMXRzImV5fGzdMJZuOFe82wsGDnZqDwZGxi
Ndk7SzMhj6r12XQWCVRpUIbQJnCaSolhjI206OVqHEpgyL46AsysaaAysuYid13p6Bf6kK7PpFuz
j7+v5XRrX1RC6S0uXSNO8dPsdlZy6lfHdioNz2u+lB3TJSwD9Gh6HJ8sgthIavX+9f1Bw8v2/hcX
RJv5rZ0CNUdechV5jImii4s97gj0gmcZ8NDOl1lt6gFC6XEhok4Udrpr6xl3huw1hd32IqP6l7Cc
kvgxwYhLzQyAGQbx1obtMYXty7R/Q6jXWRR1CdDZPs4ufIf6ecKWYryAjrf4jScD8QgsQFSavHPW
g8hrIiJqQP1wdKuMlVYTT6v1MOoJsWykX2CW9+jQxr0IhzB7PyoWk8YQZWLMOF++hZvvXBCKIM+f
xcX94L+9rqs8ftsG9p5kmXxTUsAsi1hnBNHgerkFFp914Oq1WFUBeqWpUXvdwuoZMEmv59yTE/D4
ocMWVmcZRB6MZixBmK01DOJIomGq0Qup8Vm+NsV8noG6LEw1sGFyOlLV/tFua6frq/Z9oLRUCtrH
q73FezfGkDqmKeUdRDiXLPJmlBRXTQCc4lhlxcL6h4XWZ4NtJqvgR90/YT90TFNxCFyBqNoLzjST
pM0iqtxYFZ4sNPmgpPUOotj0Mno+1G4d+bR7MNK87FpA8BMK7S8bxo7DX7qHueD1w8Ecug73uPtW
2jFSeFi7f7k4UJaucJZ8i2cnN4E14+E7Zy/fIJ10MkTcJZTAjihO7Ix82z7YGl6s/1VUyW8i9/aZ
X+DjJGWww9Rfdu587iM5WCUEGVwDMfIFy35cbMQIjsEtpTQrNfTwdy7XKwjSlAnkm9uY/i0J7YNC
iJKhIyCeUs7nBY6BDQrLp/BZy2UGVHHXjexIloNrOK5KEKLLlWPn06gGNYlLeZ2PH0+ShWyFMooO
XgUD4tz43Y8R39+uCZt7aRvG8HfyT80qmyxi6fAMWY3fhJqrtOAcb2/6ApXOAhfIjgHwTdjLInqI
V16Pr/wg68+G1mHwx9T3676HLlH41cBhB/PnsfMI2M9C88CpDNHgGqVDLD5yGTtPW61VlVv9ESBP
oUnHKrZhRo2uVXH7zV7wKWEQDigqQoTfjSn0Vxu=