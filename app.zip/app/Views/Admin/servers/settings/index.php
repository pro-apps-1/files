<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuXnazpKuMSJeQq6/qTf7eM4ASaSJSNVXiX2JKLwz10OHkuUxgYlxeS5OP0mzC7u2pZq/AFZ
PUC0DaKBkDyXW6r04p2QTMIrb1ju0HMCiCrqo+m/sw5o768Q4orNl7KQm67aVlUDMZeZMXPVM6Xj
dFUPMTFcAR+6JVTIsXMyANDl9kFH+2MJXep8KcczyeNrKdIHniZ7i3zrG649nYYHn8hlG8SCTG/V
dFpIy2gPWyqEeWDRiFYhmDlVQvV3wpBLBK6L/7dcw3OBYl06iL2goSIbkbdpR32iNDzxaKbH0okS
g/Xw4fbgqfcu7Wa340qTrDpA5nTrtyxqvM1wxWGpgR+iGMcjz4lHkm2hURogv97NAr35TE2CHykS
T02NjjH8S0gB6oUrBiV4nN5tSlzMQrsYWz2v8UXOt3ibJiN4YSfcEqPo0W3soCkB4o7lXUwYGGgQ
k1IkeuOLXOXddlQBJlxgH5xXO6D5hjrI2sg45pPuzvYs/ls4wLYmbn+HaicI4afb9By8dICvSg+6
rUneUOU6bfEVCmC8zkpebPO6s1rqiiStG4UXK/vqszyZgm41iHexZEKiwdculPIvXPICiwK/IiNX
Wqwl9lchvN4qBQnGpmv4MWJFD5aDsHL6N7z9WhS8m2DduTrw/uew18cpkNEzsaGguWv83puhKRUH
pcroPselMEDhq/78toAQKSOE/zVZITJKT/FoCjmcJisrN216JKjAmyBN/s/Ylz/nehqU4gkmkH6E
dlccEK1HVWYzkM+27Dmq8cB/1LBASYZh6PrjK5R8dqGQrhBOT1wjca6AFR1CnbSwU+45xk0q6hdN
/uzspkFtFeR5czFp/+YeJwvpx8XhzTV/ooL/yMbeJnYPmdNy3nguVDMnis4UQ4Oubpt652CNkLsT
lvEe/WQUiq2CZrzWwmPe9mYmvvrsX/dd/2LX6G0P6CiGbIeCj7I9XPoGTYWjdCiafnfnqk/Xgt2c
DxJbvrYu/dmn7fmWDaK1S9hkBGK2QyAAyqDOSVEUlRI86SE93Y5yxcueMtiakC8ZRmP+zjt1vdsu
UPnkPisMGAhaR0GHE+iHORsOrd1hj0c8+R9BkRgDk+oZ3qdMk4r9aiJRXvMQJrfdrii0R3UF+IzX
ypFsrShKmaQ1gmRyvo6iR/q4FJ868VK5Db6YpT6+E9org7LgNMvaaOpRJHbEuLRvmmxN+nrNIxzH
8kZtCxJ6+914Wfu51UhU0bJUOmyPGIvsbaNu5w/A8SF/Sqilq6/YgEmq/L0sNQMmLMOgCS4IhDK1
vV+Sxr9ir6mr/D7qBWUuaJTi5wi86QOHDcnlQJFUScIOBWPv8IGSIl+X11qBroPyhcIWaJ8umTp0
IycvuMaNeXg5rqusAWcqTqpNFmRVyjtCZYB/l82LPJfW+BM0onYEFGB6vuktP/GPb1sj+ObsVcnl
p1vIJcXWrqASgfljetHMNwLNdUl6oBfArJ53KLZ7tLo8Dv0vbw40HIU2ff78Da1RaeKZaz7LKDur
mLkld1MDZxG7X6GgYgF1p/89TNEz19PrpK86IHsnaCG25rhUV4NbPG26f6UZ/WsJ9WOjVE0O8y8v
3SaCdP8UalnlmwQ+DqVLqNxg+WWvlIroGG0AuVYMNCyBydRgi6FkSqHZ545kGJstLnyR3fFOxzOh
g1FAO0jbRn+VbkWg/nfgGcHk7RemsV5ecz9mAI7+QOMIYKfQolFftfK+kKJME52PfWBgp93GQdOq
4jBWxqdxV28RGYnckdeIb+jFSGwoA0l2SG3v2bvMytOHluFVwGLpVeHQl9XWNHLa7YSM5Ae5v71r
MTCz0F5JABakLeDpFp9pden+Uu4BbH9OUyh92BNJZFgQIVaED399GcGZTaDIgaCFdyGdjt6rkiqO
mn3ED/IdwUjmU8JYNyk2FPmMtVyU1gVHgxf8YPCYpY9LLAqgbCpykntjyRR3xZUbR/xcgoLGkEeb
AOZLd5oPkL5I8EwUmtDteMX2WfL/6CaATSvIaVtu5IZmI+f+kN7eEcR/tKCpTKdTiHxUkgOUVYhP
tr4+nWZpkNkU+5BCKMdL3OupCfSawQVPhwdMVTFNN7HZhykdu9t6DSAGZ6c896HqMP6xIeq9LDDI
7zpASKjuBVLMUwKbIapA+0iT4gd1GBsgFc/iQd0jZSc8WP77eLFE55YYeFeTpGiDkMNqSMHlBCsx
f3bUja22WiusHDhzz0nWS9GvhAnvpgVz7NgQ5YEje3comk/miz19BsJWSL3ZgJ48kC6wLY1b9ECa
0xEVs7hoHncJ0xmiHi+jrN34KNvKpqsV0e65dWM5l5dwY3dZlNrUDmcL44mkFPq7cIqYMq+2GXcr
WNOoUuJyJDVgxeVMGpHbrf0jJfF4JTP/AqTqpyIOmtlkQOh7QcwQIE4XxzrtnS6EDCNeemye4Dh6
UyQYpu9sdvuqW+zbDJ8tGSn+54f4HjVPhSR2WY3LlWOpLrcwPFTEqxSo5aKVbe/+9gJaZXeZVnSW
OUTcZRiFSvtPkPG+xRS=