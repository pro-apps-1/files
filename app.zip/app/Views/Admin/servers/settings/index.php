<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmjXLne3rgjTshp2EV8LSec6w4iv2YDlHzcXsGPUe6V7wC83ToBalbr6uU6Rxv3TiyfDdMiz
0ecY7XGFx7CU3+rJ05Bw7yfvzn6uWYnwZ4ZpIuzfHa6HMmgxQNk98OHJJbXBxnLazMpqwDIrbPSa
wkSRCPNVwhpZGNypGWV8S80VOIEYPB34cd0ep4xcoIm67kXQiPqVWfCWq+hkMBATWxn8zZveRDLl
orryEaPCGwS0qltni7NtGHFlbP+e5Z5AVqt46zn2WgoPKlaAU/XlrUmuabO2QSkOLzH50LU0lvnR
Y8aw0LHyv2Vz/SNdsmPMVRMnru1y22nTazFdTZdbsGH5dDrSRDmbS2n10OOufuKuUacWfkSWtnIy
TB7fC0weGRZpCd33LlQhdvYv3E2rn3M4UqWImXE5QRs13Iwg3m/TTeQHXSN4k9hLzYoTUbuufzZg
vftcCT7fz3sAhmBi4+veYMFUCwa7vbpCtWrkE/J7XjoVM8dfjpNdSoRbW1KXdGIFTEuNc8QwUfTY
pNAMZy/Xce+Ii3Vs2yXM2MQphhnisph7W/qHbOAqmlzvGumHmnnH11lblAi1Hx3VsUCZfR1KU7fv
B3Vc6fHxWHVGV5XjjwewBZYY0w+0rbB316dcoyTqS9grXd58/woFtZ38sZ77s6DaOuf/eJTIXG8r
gjSXoDjweCfKJ17g4cG8sXCqxf0+EfwPwfFGkzrWkf4jiQ3NOuvkWTSx7d8wY3SNumfOiEeMuHr9
dk33jxbtOA23NuoXyCQ3HtVAjH4OpWNsSNii16WwQay0kQIGO2+5G+vQL0FBnKMQUHV0MxP/Q5cp
Cd5WhXmNPWc70fehqMo7bzY31/Kd2P/QhAln2yHnsC3VKLrUDFDPz92n010A0rmJp9XCXYqktm47
uTkCpo1RT7VU+IDj6QSR5qbd0FHbAlHVn3wFxXfBp9sit0Xe5swdVSTCDcrzkH8xhce75+k/AqA1
SkxKLUCwKoP3nww8YdAnIxQiKf7PAmKooZQHgE8bxBjUt2+YyKK3K5bubFym0BZF+ouUK0IGD1K9
SAm9Ms3txRTxlrDCAlcyNP2ukOPp02UVK3kRgILIfnvz0FxSIz51yRKqpowWLH7qnILc5yh9lIu9
fc799Wk0iNK/mzLQ2xTVKY4EFVD6V0kpyKJMKuHwxAh2Rj8jAEoAdyKGzZLJWifuRW3TVnnqq74J
X/6e13Tzsz8eow0/sdYpbUKO4h3EnNGA6WMmDanfimvfd4hUg9WiCK39AKNGNm5dL345RT5ryRUx
lXinyUDm8N3j1eCMvFxXsNfNKy4JuzBybFqjdDANtuvW7Tp8ENzQ/n6lNpYgb85CGlzEewzXqm4a
25SkCJIpJYkh6ftvJihAWXfWt543D4PFBAlxRGCpkbmwFWNpTPwJaay75LDy9r1+aS6zUlYAw/8S
B26enesAMpk02aRZwZ6X+WWM24EPYL3hNIEXAxi0RkFUTTJKRbFd8vLJJbLKhi5wgFXty1H7e5Ux
EEt2iZKtBtwkYc+CQxFQSTWiUkCaRjBaivlny0A7E9QynsBWsyG2ZV1Mh1ibRtvFQuELKQKC/Es4
p5teqMy6kowshJsdsHL+E/7deboVw2FSs4csZZLs5iuCw/TTgxtaUQfIqbABojaKEzKHBVSJ1xm2
YeMmjWZ2Sxs6uNI/21jRhnWj2YPy0zf9S9nuNyJoyOu7XsvSiNEsnn0bE6hn8T04zvDZ2pyolrSs
UGoKwmKOuXZ1Ux0IBJc3PW24Tjf8yNcPGoFQaOzXxmwr5hyaA69jTw+xmTbKoIvuRIZbgJiqkYUI
ORKUjRgjKwc4GaJhX6AGejThvlCf05/Z12vHAn15gOxBhRWYZ1/IYuTi8CaGBYbUpupRhZD/+LPs
+iSpi9ONxh2Y6MtcJNsa+xuYO5mTy2WJmi+9ObqMMosuDGKdJy/Srgw/U/PQlQOO3r+439vmdq9R
DcDIp5ODIzGldqIbP5FGsZepSgcjzo+QuGRGKkp83H9i/PaKntMv77R9G0/phPTFr0Y+XePTX6x/
C2EV+hSUp7LC5cSZQ2FUO2bwjZC5Qnnpu+NKOHSaWiPgtsUW0mPgN44GqUFaiFUgfcH7O+Pb/r6u
H6/VZ0Y4VtlWEQepZPYgDdD+uq3rIrKbduGwztrXyjuWGe0C8hyoOhmfNiIAzSzerqvmbQP9ZXzg
I7I2oxNpKFjcwpMsNeN8I58C58X3sky5pW7rlzwF2gwSEzerHsIwmdO2U6oD3N+Zyx7cUN0vvIiK
hFXNm7jQ03adanz8SWgJrmnqDYjJOeqoBbsKmaW1Mrr3+fYxoVHooGPU0pkbVYxx7jPV8lu3njOY
72iBsOnBnGmcnjxjBvQzLbMC4g5HREq2srcJDNPe86SYxTJQvcQbWgorRLWk6kzhtz10RAeqi918
cl/e9WKNC+dganiG04Q3OjvH1h5/nw4mK1vgIpiOfuqVYSLWClmW4DoUBilAPqFDBbT00SDk24fO
q3DgM0vvd5WlZ59k+ZOrPtKEI14DxJgxATslqwXZ20bWlkOkP+y=