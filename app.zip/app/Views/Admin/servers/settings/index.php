<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP//jRhb3rEm1TA6oB620ZR8+YoW9rllluzml9iuRJkWbHHSxlJ7dDIz8mPRfe1P76+vkYNgj
Mucx7mkJQkHf2rgIRcHnf1O44NBg2WSUxorhTMMcguNw3Yx3b3r31INwXvZmFi6ug6w49LlOyHTv
YhWS1FDi3392+9WaPNZXjLcUIFHxjaxGYD6IvnzQhcbu7skOUgfHCnypuIfWxbzKPr4fSM/ljXWi
23dNoehhTiwA3kbpKrzVTFMF6LHDK0Mv1cnajjzVfnDjqKeZJQJYb92MQiv9H8Ta8NbOyUXdP7jc
qN4jIC9O/uxsj3KIEqB2kQrKh93pUtferpQ5PN/ekWqsbEsYw6EnwhctdGphcm/z5Vy7Hs+pJ6nx
4/0ul/YvnEZuF+bn6BGo2kOOPZQFclWa/4Ad6a2TpzH1oqGu2n8EJA4eNbk0T1rVTMiAf6q2gWdK
VV3BYsJI1TyvWUxcVgcTcWTDXtCjyWPNWvRY6uRymd5Y/BlV/c9U/OHqKdf+84Qg1Ui9PL8LvPs/
Sji5ZqJZNn9TVWzzogdv4yFnsWjhdkok4wMz8U/qkP51mWr6al5HxJ1DSY7RKyS0FHTjhz7z2cOd
9OHr3heG2iKXO8KUJBn6YWlJat/ONO/+SKle9QPzyMu8BsFBzgzOmuNKbLIiXOgqgMvIxIhDl9I6
HXaJ3x50s4NENjnu0sp/PbnQj2NBNEXzwWKkvnBAtRNoTy16+2MZqfA4NZ35/6LCC3XLAIIXGH3J
xGq2Q40L0BK8Jnf4YYjdsSk+K1zqX1mkNIQunLdjVXsx9VKdiErp0Rb3yNsUPp3lSSoBcXzfqiLm
fupO/4ztBBG4TKSImFn9YWVWD7vL3qPewk0Ml4KN+1Mkp3vTINvDr17OqMuegmCmNt9tj5zcFmHG
rKVVSMeOMNYA1/E3HWmpJMWZE8Q3YBDTaR8KaM0Qg4Aan+U8j1bOhA7aYmWu1QSADFCcJaR//LxV
323Qp0OSa7nI5F+PtW5RWUm4T6HuVqIsNagMsynxqwQ9wSONO5wubGUAxbyK2PkBoTwJNkZ70ZrF
lJrDxIU4A85kenyQOhGgnu4Z3s6Lp+tgtLji+PlAV9kE8IjhE6BhiveiM/xfmU+5k/YF3+NdgP8L
x5P+4pRA5tRh5gBEieiKAu5u6EyA5fK8He7kRf492s2zPV2yMDe52GwhtNsXvcq7MEWq/ZL8bpY8
pCvthqoKcZrYHhDoPPVv4EdGGJECJ8fmuLyi1ZNrBrGhN7t1FlLNYyLOvlonmdmYf0R/TXbVyBB9
pIoTKPLFCcbh+V1+oN1ABaLC7bpfZIUy7RjRydCC9UZn4zcW0HD7jVYr6CfVXLXGjXZ/QvE7T24W
QUw+1pV+WbZAOum+OGEktlFLmYZXR5zClmJXvAm3HwFpg5LHPeAysL9VnAXN/PjRBZt6u3D8VCze
RuzUmrjLEycvmgSmWmohEuQI0WyV7GOqRaOJoS4mfyWUyIVkGGlrChhPfEjZeBqQQXJEHUxxrW7a
38lU5L/PrUI2hlx2SGQ/LWIy1tNlm6T3NMqquXf6v9+zUdwZ+UlXG8TNQ2N8kGo/AXg7AIu8VgO4
QwGjlQYEIN90TX13aD77Kkavjc0XpJUZdN6UshiZTm+qmnaxkmlVdNbM+SSfY43mD9cQLuHyDo2o
bt1mxHit1gMGAG23pTXdG6mIFa+GJH9jz3yOt8WWYVw4BfY1ZCGrKFm/uwckXir9SdQQkH9Ca+IL
nnr3t1vW+BUeFTtmHSyXxNKc4wVc/hCXVKz3vEEy500ZEKtWXl+14GeDqzKQssT4XmXjjUE0G/eK
DsDGOLsVbJqhcw/jqlLPZFz1nN5RYj+ZL8LqttrlS4er+y+b8V9RinVGTqQ7APs8Bg9jPweGGjEk
rhJIu8zqj69GGtQXwztSYsg4ujhVVTbc7KnMWY1KqFodb+M3dAC0Re9sKB6g7YFxqQ8qWLq0Uddu
V3MBum5Q78egPLJ+KPaiUqpnVxkXIbaotD2OIJEYMVpFdY41YmO/dm0w2Xc7q0nic/eGSQRXHhcu
BjpbyRjd7zA17c6kTdd/viFuvBegEXRHyt2Q4WHzcgjwLt7hVc+fsRtcSxph0CEHlmJgqU6E161t
nZHd+PS3QzaHNuk81JXcHPZ9BJBQK6a76Ps4VHOZEoENz2HRg34/kMGU04vlHfWM666X5cupuN8h
YMWgi4SIxmgG3tmG4RAMCZKSOx/37nRs6+5CnOWQxNxHIIMjCwUkirJYx5qpNvTxaM951UdoiA8W
kBBFKWG=