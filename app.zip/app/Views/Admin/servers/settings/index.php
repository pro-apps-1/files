<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtjeXspTxdj3cBGIJoaKTuPLmmg7dEuXlAMu5KZovuePc3N9GrQZJsSCELxnwwvAPXGerY/V
RbtKRrkCwY3784IllVwm2FjITqmS+i24WxVH/7ROWP2MNFswafeD8yrR1yEW6j9GtJMHx2w+5veC
h5TStcqv6zFh8gA06uyKoTvAMzf2eSFEpLiDGtn7CA2UgN7VSK03TpI6jjWptr9SzDnR5b9dXNAt
FLBQXZ/L3b6EgxM2BcmPCOJbt/GeX62mgIc0AWetD6Fa59t1nE8I/Q3FmrreTl7neA/c3XzNmkPI
dfT7//E6uJCSPBl+ObYg6Mz+JyiNo73yi/5IAOiYRHi189HOYfgm3uBeMhv1dyQwSRc7Dl3JvhVQ
NUyeOQUneXcSw1J5Qz90cOLmuBSBqHZcZt2tdX5+cEopccK4ZHVArUIQ4481NJckwe2EBkT1cClO
HPsbLH0UXKarfR5H0BKvHU5ESp+WtzhjBYOVrF4Jc+OjaEh6Kffc0wknldQndY7H1Odx7reAVq9A
7pfbKu5PptHurMUlDi8KIJTiDTfDsRbHkERigDR53zsaNfHOD7XNMmkPU/65lrNuz3XIxfgC1kOD
Z7CEtvxKpFeRfwrNksotFvVTcu3ght58qO6x5fhSy40Z0q6PL4Y08gBf2dmMf2hhFJruhVeeFkkL
l3hpquU/sZZ68tA0vt3RL2mDnIak95urrHZuKoTsm269Q06oxVuA8rIYOzdvOJvQArdgfvnr5CVn
b9mXH3hkBhw11Gq2NlmMBSTWpYi/17ccBtaS8yECH1q1VbT/200k0lJd91t3bwLH43rOIhV4WoYW
ivRTGTXYspUlCjy1dQgdFaVFTikJB6rWS3QJz03Hiewer4NVKn4zu9WqQVaqDfBFqwel1VIKSuPn
T03i3pwIKPHYLu1whH6U6TcWwosCKbFH2mg6ehIcnOBGjFjMqVlRQVEZ0eI6vygZOloMVLOzgLvL
fNZuixiqTo6+4KldZqET9X3Dg5WTn7UXRSx+B2j8hUJAe/B1NSqeiZQNvbpTKI59LuAZkOHF+st8
yQtVlCFi1Y6J6DNrJWPFJSBW5fukzw5mCJ+eAq/xrI9u6xsByg17wrZWozUlyZ4XiKUWKZAstZdi
RdI1+mSmXCc9PFYHLixIjK2aI/BDm61RJPPgllDpOd6rGv0FiiwfdcOgi1oZFdi9O40MUD1mcGFK
EULFTQVYVcC2Y0LKucQAt8y7bUmmb+lWWk2N5bnc+9c9KWwLxYBuGUW1hcLOw0iqJNJZqe7yUc7k
lV3ahGCwwfnckvisDmTsSGfx6X3K83WD0gVZqHpai6ceuSa1xYaP/v2APFqCzkCgP8ia8HTQJd/j
MdiqQEl0LFCUfxL9V6iAIz/6x26aysDcXtugcpf3mi6DqS96h24kYVipC+8UbgjAKbsJf6JAGBxN
gifGn7rN4zhax+1QZ9JrIc7+Rz38o0RSjoXVvbFl2N//K1eVJfLcnAS0vl1uaKHp8w2AY+kxpmhO
J+It7Th7BPvpDM11ER1VmGx3JnzW3loVZzTx7FQ7lxqVGXKHZXFMtfF61hpqLlf6S/kgewsIK8iF
g+uKdUK/sgQfi+VsCPBYubLNNJyOU2O/U8roaxLwJyq6nGquzIRMNZXugsSBd5SOO1GWP5DDVq7O
rrb+fpkuuNH98rLzS/+OdFI6SYUoNr+iuBKXUodChOx+NFIMweI/5CRmOZxujgeDmgzHa2pbsBtn
HRK6dUma55K2JZdJ07aZkDOfHBU/0aqmtovNi8MiwrujpRNYyYa5aaGd83hUGl8ZIGnx03DPQVKG
9aE29jH6pHmLoYvOSASiccRnyUs+cToL45Y1BM1rmkfiEqub3sllFUvC/VjHnwzNp01i8D3rGGu9
Np5Mt0VnQv/mA6Y2lrL0Hl0NxzK6layjC1oTwjOKob5IAKMrdHiLo2znrdxpVREGpLCvPu01tvj0
slfKexn9KpSCtQup7FwGg6bl4aNP7VMJANil+ixQHETo9qKU5m2FMIKwFmbFLKhwtbMMUS+V/Mob
d8HsV+Aop3DbCUO8NEQFWxyiZoQxWl+Gp3Hoo+Md1/ae95wD7OkwH6WI4/+3a502e9mcZ7RMxlST
cgHb3r23qnjcacv1kXEh/O7S70NFppq3ej0E7GP9n4k32feShHvet1kCCo1ihQw7iwzrHkc5VwzO
Br12V22VhRxyneHGWn0DqchlTJT0IsDSL7bBTpTWSbYZ12mC/5RZJ8/edsuO2lO1+IXOkLNPIAe=