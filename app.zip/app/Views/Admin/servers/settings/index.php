<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyWmqzT8eISO5Ur6z3k55RUx5UVP5MF4BTcEL1+RF+rcuzvBoejN9pt8p6LnbFgFtzB41G/8
NSgyXC1Vge96ompGD0ve/umcTrmioSEorHF7ytEmLvXBSvG+hj55lNwUwte2BG90FWqLFgpFjzEB
BwEeNu+sTqnP4svpMMrRM8GrCII8JwvqlfxRk2XCgVU15KQjGTP/T7O9Fo3Zf30wn/k0zJRiitFK
yhSfixJvC8JU0F04JIZN0oxVmQdsFgGw9vpabdOKAnTu21puFx0CpmxcZijTQEJA3bGE6EkfMDty
uPPOSV+LuRrlOniGxSBKyyQ18RBpcN+XMGnjmZKAuZrhekbG1eorKkVNEA927qQxdCJ/ili7/vP5
fzaB8l5W1Y6BuWv26IPB330H+OdOmW4tyEJ114VVeAI3NWtSkYD3KsUWfT2OnMOGabowEOWkFoOi
yHjsTOMmRkmDnLkxgodeVRAI7nUIfbyF9PK+hW9dha7xVqjBGkkHqvuvqknHhWZNWazSQuzHsbmK
Ny+Wbfaa51iW+XnoHrrZDh8ITJYx3zf2aNzKKZyU765vft+1R23mp4SjdM9yrAaMd3DiLwHEId4e
ZabvevqMluxkI1d90dd4w0aYw6cJvcnfCZ4Tg4G7oZvRQtsK8TmLz4Zq2DPr29l2vQdDAUCv2psq
Kb2PzS2tANySj86qWE+P+ETJqsshifnZN2GtZ160MoMWlu7DevVlM1PzOzzpkF8ELziU3hVYf8dP
lyVNI+W8nbcEHc1nqTGvH61OACrl0LEgbqxjcszharsDsgIaxMd8KMpZmw6A5d8UeTg+7EnX1FOP
XUPudyQ8r9IYTQRXdQ2jOoLRUd+auB0Dg+cLO/NRBsuxN8Ghi1mTsvbcfDWopQNYAhbFgCHEiNfr
q/T45ccuzioTde/jXdFm2BO9xkB9/9ot7uhNbj+UjAyWZ83Nnidm1xtqvOVYtkUmXobyL7T3a0Ze
BSAlwF5KbGbwog2kWRdaP8CS9kK2DNinlpdGOtZNopRTwaoZqdOPLjOmhcuTC6g8pyYwWPVsGUm+
VWuhUXhFX+rppLcL/nTSWob04oHIhnYy4T+iMvTHdfGiftLaW58Xw43+/24fzV2Ejzjzbw72/sNS
yvlF2GFXFjoTOCDRr3ISz/695pM4R/3attoDwSSK60H7hQd8VIoQHUrxzu+0yKM+ZMaENe1oDaPY
oYCrnLeFrAZI2s+idECvhHJwxoYqW/XpVl4AROsA17+xUh/IJMLiteeGoUirWLuKOHZK1+YQiNMZ
H3XW5sTy4x0WW1AGBQiTYhvHr409Pts4oAsb0P5hW33/DyowCj9MCFzpYsqegUCH3W3eZutiQ6hB
OMzAdcmBINgGVjUeC4B8SC0ws0ngokdZwb9V/e5aTc72m8NBOeZLNdE3rM+GbrkE2Lhii51gYWCE
GlQlvqqj4WXasUmQe291bN1uyVgspY+sxIJAI9zmjS5FKH/qA4+2lGa1RvI4lzdodIynalyXaN34
m9X97N0uL1DF7udUmD3TOUWOQfL4oe7YDvD2n39WqjxdmafkfxUxhWwZ0IAYnK+p/IY12i6G5CoD
iiy9KZFj7edn4Dc/6CqGb5pWLngg2CkrMX5sMPXiDy2m48UI7y4EETDfviJvrp9hcheHp0SxlMXb
DtXRzeiXNnUxFUq3N4R76CdbsedXjyLS7C9J26BShsRs1VnH/I26IJuJwyg8Gl/T8PvctSljPA1e
OFc+Tm1C2i0f+lV77wSXqaWtkyIQd5JEcack0l9Fz3kBV/b+kPcDaz9324wN9/vmWqL2QSfvHFEU
LiLSKwDHpolXV5eDEDmpYeTWXszBdUmcjZl+pxMu1iNLdiQwsEbYilTqE87/CzVlGrbkKBKiU4vV
Jh+f2iyM49gayJDi8SoVnDcY1bm328SzGt8dPBKJcY1w33dfou5o1ZsYCe9R5JX83yJaIrJUi65W
1ULPHer2tXbDVHSUM2jeMlAFNK9Q35oj+QwMkD+DLqnCbuFE2OXQLS1dvOkI2WOOFaj7iW6a52e0
fLecxq9K6AH13k6srT2dXbHNvf/9wQgDi2M1R7YkvqfiQEWhHphrQi63VNMQqb91vowxhM83Lw7u
ux4N7X+XVN5kvukeVgvfjSyfIFGfZQ5YBGlbm/93UuGD7d85vffJ7G3r6kiWZv6fJ7trOCqZf2LC
AGIMFhaQgTdyGltChIuDOkUn3U8bHFN4xZiCQMfjSBz12o2hHYVgqF+T5DbqYRLrVSaodZYup2jx
X0y63cTwfxRrRRGCGjfMVOn99NOrSQyh3ZHmUiI5VfCf44mjrXRs473srQ29oGk0FTZAMaUwcdnf
76nPcjYZf61R8BHy67g0vVyVvC/t5cQAtfe8jhOzSDmnIO//ccrU0GYXuTroKidOdaVp5orAjUQx
dU76p9jSwGq+z2wVCH6Sw7oiB0V63RLdPWe5HQ3uaMWL3/3hlaD5on3E8XH+jMdNMc+LMnIizg+8
pUJ2T/LwNRhmgSAMesa6aV40lcIwh453XgC=