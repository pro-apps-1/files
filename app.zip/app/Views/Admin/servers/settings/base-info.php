<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrUd2OAz4VArk7sSeN5r8vawjzib75eFWiWjAvrk4/Eq+6sIY4JxmPetZLpm/x0qHX380Do5
CzICxG94+YN8tPrqea6AlZrkcufp+1kgNOwjQ/LSalWJj9oq6+o9E5I0u/U0smMJOM6HymjdGZhT
m8JxizG7aSbM2887O4pWvougdbV7GRv8tAHCeD9oYiZFIkc/xeNZbSg3inh7W/vyEEWuYUwL/bOo
sJlKCXF68YDCcSDDBGj1RCSn2ODRXa/2Z7Tbbddcw3OBYl06iL2goSIbkbcGRUjAmVVsVN2SENgS
A/TwSTZbuUsyTQa2RNKaFVEs9WV2FgZMtAv/3GmNmrXAl/9CTjUjzFEge21/hREGI179perjOh4f
X9Kmf01Da0BHTBLi0iXOP3usSaWPNQl7vIR4d9e2BrCPPlGNSrdEl73OuVjw7CfdTyQ6w4qXqo4Q
HT6neIH63Hg/5UkSCBpz4zl0h1JCE8JNpRBKz5blWrpy8XFVrTA/bG20bWVeWVBBG3kO6qkphxpu
gjDuwCj7D1WIUQUxjPHhyYs91z6WMwhEUmSGTtIlNEzcBp1WJXGYsM5HuZVgyqZFyuwHCYO6Gfbx
PZsjXiiU7+z6Aui9dq3+s5io84zZ7E5xldP2ZgnqmLnQoYuc68CAKhGpWLN97Z8vOK+wgDVA0cbV
Ewh4+1lNX0UHMNsL1vCtR7MEmh6vRTt7HcuRBu2z8r823dmLA7RWG0QLoRFtYCVL73GJKhe1YRYM
AkhS8Q4Mo32A75+i06ePAerPfOSuu2/NjzAze0VMcno5v4F6Gpv0njoTdWE78nN0th3IeslvjK9e
EYvZZPGXhI3HY4Z3E1z3HBB987HQaI0Akgd2ndmrgjSg9QZleUh1FLf2cAsEBsxsnmVCke7t1jhg
N/fVDCXhR7vs60s1s7aU4VcPtdqjVCOp5hcT+rsBUE+scwYEXXQuWNexI2MSXMV8dVjX1v8KX+HI
QxpQFjNnSD6VXPJyFY8YrlMtoF7WnEggLGA69BVHR6EincPKzv2dTt+Bj1ZfraneSu93BjnHDF11
acWNC3rPnfg8RNkw9iZ+brO1LUmTJ7CmxRAqunte2zD9Qom6LnQgpzaW/BNSAWWURP8A3oYTjIQW
CCSBBL+1AoWL9bJMUTTsrfhiI2lnL23AhRdVoSWx5eCOCmvnO1DpNzRyCwwyloDzKxQ56IxpDNEY
ob7G/KSEIH1AvqTglaa/3OEAt4aJrh+M6vW10ThRrqYUfYUDOealeyswCDTU1IyagUUZAr+gkDpf
XLIpoUili+5tdd49QgkklqaV3I67vwlHsNDk8XR9tTze0PSPqRCfChH0BXCsR//9nmHRc4Duuk2Y
5e1pZKFb3NmAWNmpJLz7vj76oR1UBhmn/f7Kzr6Tsgmqx1x2MIXgBctJ2n/l0uQGUD8Jcw1P0i17
Dgk9DsUlTdmeXsiae9N1v3IlBh3rPhaPAOZn2j9K32byKQMCouVbrhk9YARng71UQ9T55mY1AHu9
bdi3NIy/Fzg9mMg0xOhEJOdh6vVIT+i7JEcwk1Dwjylbw7ETJVFmeBiBm9v1HTJkx2QialgsDCrs
yuV0lRUuFxF0tHuG8+HidH5ghNCkbWfGGPCKyEcp6linJxxHqv4xpfTAlIAJS0V9GvNEGnCq3inm
g3aGTUFH2NuGCB7IfDfmLbXvwf/JW8+2hLLJ98YBCOgwmXQdkDSJOs6gYcdiL3UgHOebr5wKLkoj
aSokEUcKZQKPbcICRRN+kcPRxHuIUfPRFKVQjqBLpFMcTX4kRB1l+R3X1jmJI96OV3emoDVcniZq
yVUaAGpK1uS4RWjdXmGGsOOQXq49tTJ4115xtFljXjL9t5R/l4POTEf/Xirg12mPo5wKq8g7sSzb
qRCu4Kg9qoO18MnudtX+bmGOencTW2r0WfWQ/7us+EwcZ9IYAWF3dneXNOfvTTQjI+v7npOxTOKt
IqWfsHlwfqaOv63+QA8VehiboET+2hpdKvdtEnGVgXD5q0psruFIzVmhBFckqyEmDZl/+AXwnl32
4aPVcXXDxIUZ0Uk+SbH0OdcIlbn0yJduGn4kTjlQXcF8xFU0BmfueU4mlSxIEwbTHweXCBaifM51
EBslWRKzCQsGbmmrOLvx0+IGhxr9ozC16rL9/59B1k+HW17eyUiVqVeDo3EbXFcqefMQEKIRjAGb
stcL1Lo2WrzPWoTsAWgSHZaI6vYf6JWSu22gBR5Q5obpLZ4rCHAplbFck5rMoEliZAUgK7BXOV4o
d7jEWKWIMvMXv38qS3C84csYWuUUBbBVhPKrbnaMbFF9Rb4dKJZ/WbZeAfcZAbhNjjflr2BGt3Le
o8snZixAwik++50x0IzkEnSClikGJF/xJxw2JqV/zYCGol80bYn9DReck3DUpkeU1U8qMfR77YXs
WsIT9685GHELVIFPMEVnwfnpgx2pR533AyBbfQZ0SgiNa6NeoV80X+DoLfzCiHh24zh3ulgxHBlC
BDqIU4T3xHg53BToGUym9U/Gzr4r0uJmscGpseEumYpDtD9QiHhSdEVpYm3tV31JBW3QKNt4Gar+
Dn8SnhV5md9BI4pQMJTV6/9XIi2+DF06IdbMja4oVCr8JS2LFe6g+7T7+ZB9UfOunEEH68huYtyA
1keu7PrRxloDfUrkZw8XTzVX40JbjlBIlWvY6U06IkWe8OJkCd+zbb0kipvcUxAOCgS7h4ahAxRx
NZ1aQy/X3B4njq5s0omnj7Qe+mxb9V2xHbTzoltvKXgAxJ2+lbtsGlwgQLbpa5S+XMxfACQfLHs7
4K5Bw7+FToEGjsDRQks6OS4PNM0UtvLy8e1mduozxtm6FMoJtYdgnfDb59/EdHdWgks7IgO5jp9b
qjwGJ2RSADHH1Kh89qerKYK8KXU7bh1ihitXAW1q3yAMVjNH01iWzXtGwLhE1OCZIjkfGWM7icub
9yA2+rE1My48KRRbnR9vWS7C2RSxCQYIASPCjm6M2vfqN4u/oOuz1Ym/CAnM03TKa3k5eRYtB5Vp
1e2KihVxExTFZgnoVIYylEUavw1fJfnDwfaAq3SNQi+62vTLl4vy3qyWRrUTlTl0EmMDqaENkWP/
V3HGhLjI+q69Cy+hyXNE8HEj4MctHOquaOwaV5FEdujoGQ9mZ7iHemu1zyv9C3QgCV4hj87t//SB
St7N4JizNVUj9aKpCKsUPvtWIcdz//TQJFliyYByTXiutlrpN67ZJwdmszvXrzdUBkmdSlPIgWjh
r9W11dJu+IHltkwEMOQRVcS15dUC8T4t6XlmvngTRarI0NZKPYDFIrLzJiQiLRYud1tdcSS+C6Ba
MpfaCGt38WlxpRnxYT9Xc6JmRvFVkSXAx8/zhowK5ur0aJ6J0ty/7XlI6QKM5yvblItt8jckrp0P
rLRkpq/ZIl/Av9p+UCIh9ntr+RZVW7bEG6e+l5NZJ+wYdeE+ZTSKJUsif6QIh8EjNRGNnIc5HkuC
63aB4NhLBrVIVdSZ8TjPCJ7N6m/3xFoNpNXDxALJbkBgWaI7nlz+HuKezPRhxVp52/4TtXUGxgKG
2NNH98ivDBRKmDqwzZzWkLWETaipe81CUn7E2qp49V93+qGptAyet4AfV7lA+KpeJcf/cAmaZZFn
aWASWeA675o9DzKQAS4nEKzQ0ZfwpYS1djwPAU2mIcwKrEZ71sDXUSdW/Zipq7FYe8forVLK7r9T
uLdbtvESwGYnRaSjGTw8nZcssXls1CNJ+GRpxxaLE2yU7/nA/qMZC2iC9RZhNjsmm2yYTwy81ekj
PzQM/LbEDC/7AE/Qecdmd91y0fhxUxHcN+6bl608m66nd1MZC4J/9qLadFDnfRarwO6aLdUgkKSL
g1L5VdAib8yBdMmzO7uaCkh4sstTOr35z07iAOF56gsu8TAcQJw8YDfmt09/V3UnKvehCfzHYFCZ
+ir8qKMzFigWnPaOml3e+tQj/1PkUixbbVh9u2uf6LDWH1CFrkteg9N83MYEaGRnHlugl1wWsmRc
6GR6SI6PnB+hCTqcet1d9M7EHe4WRqM+JkuMjfWKNAg12n6kvwy5DFUFIRQC+R78EUEcsoJHmegO
RZTp+GroycOAi0hJSSSx8nyQkeOGUtzt6c1gPyyeqC9fv6IIemas4FwfOvpA/ReC5rpLVNYMnfWi
lALbnAIQ2y5EGtUWqS9aeJrVKH1kunAAe0zd98F9MGfRneDTkLtqnnkrIhOCwPmlqkA2OQqoTxQd
4M9iTsAB5shv2Am0CVSVoLNKbwC2oumBEOQ8pd6QpcKERrDskehD7Ra=