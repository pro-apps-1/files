<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvi7dHKOjsLQvTi8Dkx5OUFGvGOgCXoJuEETz+k/YnL/cy2b0TdcTwmiqtuIOWKiE2PvZ8Df
ZRXSMQSNBPGAWcJj8E4jaqr3fflvPgd1G51jCFG2G40JCBAkaCncyCELVz2TPb1vbENFG7mFcun2
KAG+3GHf2rFYFWMS/bpcMpHEMLtlChgWYknhPsxOOeZ6hEqKaYpg7mzo3cTJgfEgB5gJsST9JMe4
aX2ZkMXPClkUvLvgoqnyy8uQQjy3RWJxzPB7ISPDG9KZFqh4jKURPiTfl8FePQia7IL4gfXKWo9S
c9J80V+bVHlKUx1BE0KLGFRqZhy0G7YJVPsd+r7xTOPILsmmHcj+IGTIU1WctO6FunvCehJzBDDu
pRMALl+TOCP0E71LeG+c2Wx7x3ydm+aGG7wvnwhpmd8t3wLrjpPmwxAxx0xVkxXJR5ihjxJH/TBr
YR/7pMuVufcGhqZEAYTZxUTfjTmzqMiBiElz/+57R4UMqeCKcYFh4pHeUjcSCJvbfQaRr52uKg8q
KiuqKCxLB3IE4nc9aI/9ho8o9X/0uwnbEVbm56xVuXQLHiUglb20Z/khUj/jSe6OT/cmLskLiQ/i
TCXmtb3hFOfYAhbU1Z3ZyU7dDKQzCDMFfQYJ1PCKPqeP84OeduaZx0UV/IBssQ++pdb3LoSg2Mvq
xCM5XZlzirjKcSOWI1r9554p9+S124tFH8SHOI/JJFLXcDQMLJEkZQCcWdUSSbfMPq/0LNAR1F1l
SHbF844JpCAh2+5jE41tJryocMNZTgiYt14BtO0DAPKsqxmjN5sbkzwluqomRjHJLbDVC+7x2XBJ
KGXgdwbkn0uJFjfkfUYweu8QQqLmophRY9B/v/tsrRyQm7aF+xwCoqEPGgA6f8h4XCJKTZOaLIM/
fjhdofGnjNHlcXR1dOXroHktFOVIDs3fSsmFkI9gxC83doD96ZHXvd2Bgg6+HZMUUiDUy+Omt67y
aqu9/yVQAVnGT5E3iZNHzqPFJkIx6R+hU6Ik5CaeWfphyURr3mtVjb7XKku/j6+wpdcfI3UbtgSp
UCAdlMstUUr6koaX/gRqED3ZYU6AP9nCcj9qQbX600FLSIrbySHZt2bVnLqSFfh/uFjb3WiVGj98
S0Ih7MJ63k99jY5YllTi74Os1NHkL/Z13J/JMVEJ7b1xmiED1MekKhMl8kiFFT3fbxCkv7PNCZWW
4/5HxIZ+ah9nQiSF5c6X6/Ic9iA0k0oCnDPwSZ4eRpz9+u9c8vjw5ODdrLX9Ojf7qUyv27b5ECby
Dlfo4/jQsyz/slta2KNYxEmfdqu4ESSa8L36NOPkhHiniKbxHfd7TZBvHXJWgFI3rthZqsp/H3Pp
oG67xlJ9p8QD7qgWevNVLT4hKUH3Wtcr2TETTtstPIgaq8ztg8Y2GulFCEZAi8vJ22oBSfqhSCct
c1BgY9q8r4qEUUZcC7TkfCiYVkE7YGT3zZdh29/UGf+vGcFn3rERQiJuiD2R1ZV6P+Uc0wUTNS3r
Ls1uy8XAxL3R+Tj4NL50Bmh/Nq989ehDzxOg64UBZzNVee5pTYUE59U/prpQcUE6Lv2+63rGAE5V
CGXgl69ZHTVMXN+G1m8O1z5JZBbGbnkjWGaeGmhyAFiVgPrbn5e2Nd/S4bzjH0w8VmtyiDcoXuro
UHfKWz+sWGCzdTH60gltzFcPQ3W4/tQrI22zFhdgG5lSjeqUuS3syj45q4fR8zA70EPOapFt0S2T
pMg5cvcpgvaxZggkJaE1lHJx1ozfvFbUuZrtmRerXjwP2crURN/eiMQSpI6vyP2niK3GxTKFgPAx
isMlCHOx6bY1TXWQvuKu4VPtX4LJdOhf/zWVXS023S2xn1jd2PCTNoS9ixzgcA42DLj0mj3ivBNr
ePdJdi4tn7W4swFeNXK/ZoIbdJ5CW+J5FH5I+n9M82mFsndXyK+XC/Q5m7cBf/70Gdr9Xp6/s1SP
UgIpwc3+wmNT9LXoVOvbepjfRTChQZXMgMKpwUU0/f87mCw+wGCIG7S7UQJpG/UVZsJ7ABH+Wan8
n6why2PdbhTvjgQ6XJrUrSrpeiKau/9UfZcuYGN9Wdc6WX0RNxbo/GhYrxFcJu7QIFTCcnTUuZ0T
edBQCPn2WW95MbbSUlWeEHVlBAlE5f9bmJ81LKf7456U2kOVWnBkc14m8OGlQJTEHoCSk0j+0FQP
N6oF5YUUZWL0jUUL8hUjiBUzfiBjsHvxq17DpxEph+TQkA15Bh6M0VYajrpixk9HrXkJIkVOk8bj
QGx5IlGij1A+GS5zdEQhXmEf1aD4n8HcBm5nZonwDUTOk91uNkd8jlVMtOHicVc71YXOq9IKXNv/
sZ2kvBooj3Oa5WRsqGaqoo73qFMBkHw4/+t9UGUNwIDqn6fmizaN2Qm=