<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvVTSjRjdKSQw07dzNbWF+1nth4i491uxVXqp5/s5myImWFOGuz60k/f942enEe2CaY56vA1
lWa8A7uCvpKGjdOiIQnZNQAHK6hsulguMrD1D2kc/TZu8O+DvP8UvxIxfYMnRaEjrsm1eE6m1YS5
0Zj8e9ID7RAEDmuGZ/Z7qCCLH5JtyhiCcJbOEBQaVNwIGtuGvQ3vpD50eno6WfWsC96FRiN6wJ8/
GRE2DfgZU5wi7uY8bDd9UQBn6EcH6mWexDtsGX+w5Id7ys/xh1blMYJasqKCQPDU0QTIq5H6jfRi
8+DcPl+Gq7bY9wbD1kU+LCwSflEcbYA5P0tznI8uejbPcc510sWqqcsxBDOkVnhF33U8y6Zqhv01
OH5suJIgupzCAYDWPiBmrWe2aKW4UUbfuE3y+WA64909Ud2b6c4aBbhAy5kBYNlagD6wcrDCOFlq
9soIxzO0sZk27FIQBBnJ3DDO0GQ+sKDKEB9321TYwNuDvMQ0bvbga26yyAmTeE/zF+SQQyHE3HTq
p+cg0x+oWO09DIPOFNQJ6eLn16fISgNP0c6AZznwO3zewrVxUm7btxLWJIuBmlqAoOGnsQjl8hWT
JvztyCHhrK6+icdABAbfBFp9SIj5jYAYXEE4/hL1/DvB/tQKnKZErAFwwrDSqrH+8v+GvzulkcTd
mfy95DKuhy+8BvT0hAlDWHw7Yi8ND3cYpcNOR/7QvdMT2IYoN+g89hP590C8bLrtnTlaSCV39/hn
Meco3OmKXjjkjx7iPwwoBCNCMOhKB9odkVuH6bdIkTe2VKPXeotnOXARS4rqv+1DdvyBUI5g8Qs0
DJdkmhXx+/eJs7G3P4P1fO5CNb+D+MpygAI6x1ukyQ6Be2Le/Jif0M3X6UfbuwQqT4OZvrsOZ4E1
t2B+3Rl6WridkVSYee04x6pZlisQgEzxo/IL7OdbrYRCX0OVmb9L8ElrjurtN9Cm0psg0EZ9vSV3
PwYALHy8ijfKaYRxc/gVi7B3ESY7C8Ou3696neFPEDxfKEvdnX9FlJ9zj7DQat6Dx/pO83YUZ6aC
iZs43hdW/AoGWDAnioP6mYn8PwHKkMRCxr3ZxDGoI8bYNXkwaIFt5emcRdeGoz+p+OR4q04+KXLD
6kY7x/TR7nTWezl/o6b0rURDwC3EEzFTUy/ng2B8Mp61nWSN0KIagAZ5Kfo97j2hsnITzRokYl9Z
oOWTQdo9bxPDEeETp2L9kXWsIPW8l8/V9QkGO2Vwp4C/X8GlTUbszX5caZPVCjlkwG3vkO0cjJLE
iysVQI7IkBlKYxQD3il2pxG1Ub9ILMrlwdihAxf4suzsV0IcdtNv0VzAjpirWML1dGVp0R3wOfYH
Cb6JkIFfEfrxZaEiwrpYGLe2xxuianwF0i/VUJ/3xCvnAwObhWXR5rMVv9qknf0wazZwU00HvFdv
yf9Fu8AoTgPn34GTXgIEGznnbPDGae7piQsflYV5vi3C0MT8pbTGr4YNbuTt+lpi/d7p8L2isQ4v
JqkWKHCJg0GKqGc4zcBM6hgYKPz1f0E6/DdIzli1NBmwBK67HzstjsIQVK7DTnhiPi0lcJ8mI+zP
w4KXknl+beg49I+383+K51DfaKC8kEbovg2lFaFZeh8k9fsk6kXvjchXgC8a7m59Nv8G6uk94LpR
xTGFlH1h2qNedQH8A0fiqpuTAfUzWSBCW76ZoYr/1WU969HFl9nAItHKlsX51tjJr5DE2iA8tZxM
bKCF20qvx180pIMc4fpfoH9dkQREDwgp/6VgYT4o7iWbNnj6RP+5oxHYoWEH1ejr0sYw7fsI0U/z
+CcX0Hr5OR1axf6whCTHzSEMWz/R9/VqquEjD2gzFQJGkouKRZzQ4ZxJrlKxUer5XCgfCGHbrE+Y
lf0DVFJHBt8+Rrdh82corG83iia3NYtF3ywyoHL9OYpCyTHHie6gbDodpl4h6lCm+nIYSuna7je5
nvtnQmHdBjRhPuJKTNP6Lbspb63hAP8O6u6vQ9EB8m7ITXuiLq6HBX54apyJN2595/32QO9HHLqS
UTqXyj/iSP+W5eSEoZDQGOgBmbEVvaJFXshSpJZZwQeT8hfwlb4vOAYdz0l0E/ixmR6dMxxL0gsE
IdAMx5UstMPUcrQr5xO7dRDkhqO+12rR0PI0Gc8Tw+ZVcGigRmcIiAND+n8gu/ytaZicTdpMsItQ
SPFnrF6y6zRZOxWxvBQBajYyqi1TO3B6+xpNYXa6RwoMXtmuX5mPxQPXFzMO9S8wCipqjU283IJ/
JSuIXgXTjUCETSuLSkA6hwxEaqXB8+tSFdiE7qM31z4vz7oSpsGgStEiVH65LICkos4Shy+Kr32L
XVyTt6OsTxN+QJ+uFctWRSglU4oeJLpaSmlCoL7uoeY2M/efKQpD6XML