<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuWrOVFafLd5yUdqq5br2gznPMT053dcG/9yq/i2E0W/NpXxWv1QzdLTrk57pXw457uBXvgX
SLhKPIFV8kHtqOiBc3C+bi5vLo7pkMrwCxGiL5cPavbHvgAXaWsI8okSdUnjg4TR+4rp9DljIIgb
15aOSNaf7g1bYkwERy4kSu+w1LS6MH4t18jcMetC0lWH6BEFZne1ieSxwLUY8kmHUeUL9QsLIZRt
ewkQZQ8hooVZiuqmH55h+IiK7bIWdJ7D/Lo9BMxKLL0DZptD5Sss9lVne3A4O/u3cjz+Lcu2r4c2
0WD7Bo+eUiwyhF1Dy1JZdP0ffRa6Wn81jkCBVix1UoPpElMtlOaNqV881isPpsBL3nEUt8yw2ZwF
IVK+sCRKxbzx2Qa2uL2hn5OdIDgEeVHcFxvq32jtM+/wxsn2+LGNcsSLzcjrrffj1zO49rAdhpbw
y6cGjee92JKKVG+ZOqmdk/z33mLK3bTpJ2zDqZLZ0EVgYsjXxROXrXKznxvg1/ZZY1UE7hdjWM9b
4lYz0ed+Nbf482BQvLO8xj71UbbicfGhFsb9ADlRuWPBzqUbnl06YeyBoGFoW/J03oSrtt6sFjUV
N6paM+JOEKiP0fyslFtdQwTNN3qf3XPvW37AMAirYJz/ntaqheeSiDmQGam2YNe8lAgmszrhISon
VllyDXVsPmq+GkEHm83Bq0/3V3lE/eRyL8ZBUoR7bWrsCmUCGBMYWvcBp4sPrYCAG7A/4PewJqc1
uIRu92Dp1vLP+9CJ1Ly0Yu1hlNmQB7Ud9UHhtLD0tNwNxu0tVpu3wm6uR9kVJuH9VNS2PCBGu9fk
uC9RaLkidSQ38I1R4KbPZsm5AzO/lPBMLpV3l7rueCc3xhOEQWlupjOLb3lcO88zdtwdZfYg2zxs
xtod7sE5tbWOmvHrekPF2u+pEokHx84LElBt5fxkFzjbc2K4BMx93Y4regM1KxyfsgOoEbKpEwj9
Xs9i0J14kHGNY8msRO98LSdfOJjYSI+It3l/RGb4dvpO1EYb57ISna8AGrsi8J3dT2DNe70z7n/J
xeCP77TX1oAf+F68oGqG31m+dX4EnsS+kGXhX2lW82I6Gts6Mz5BRIVreZbZ6aO2Nrlj1gqgrtul
c7ipWRjURtU7ysoxl2fRRIGt4h1wvs8F3SsuWUSTdd8ubp0LLtL97tIyN+4Q8aZGr6qTkOfufJUs
QW7Z5S3zWXgA33FtC4YdLfT0qcXImAmo3SHmoGmLBjgQvC2rMX8e/cSzB4bAfJVywIz7J/LgDvJM
xhRc0Ayx2inu7eMEycVnOzKcJ0MdfpjuaSb+7ZHCJ3HXBte+Wa4w4Ql1N/oDQBx3W7NprOcd3vau
MHpQKAD0V1laHV1Z75c+RCXcUWFtSZly3L7Th8sMIU+Ej8n6cqvQlDW8aN5jlG2/tgByQkIYvgZJ
wH/ZnDfLelLYdll+wq0DHSJZ43DVdRMOW7TDRX/E8j9cjbi/jRBrycG9A7WEX8kk6GNb9nUOuVQO
swgSEL8vEorhEiHh+qQCdfe9lgp+QI4tzZSXcN80rwXNRBVK8pIFErHb+xmKbNSfz2z2k4cyYMe6
6vcIbJ2ZAzB13UrT9MURZAk93XTIiQO0PgflEUpVQC8vyCVFrpQR2Sqp0XMetbnbTDug8Mkp3Pcu
Sc+4XtzB7C3ZCheP8BESSYp3uUIB+gjmBDOD0Wa1/olpirkKpVmrK4ADodu+T9PZDIA4hR6ySrR3
70p2G+sXoa+jkY4ok/aAaVH+6i51SgofY+Ku4qV/+mWJceSaVqd10pEUiVpAlJJQopwanCJcHxJu
wXawNJswgc2QIjQzALraOpu1v31Ns55C2ZuYWctewA0fEBKKK9l8TaHNT1u5/0LFOVUPxbHQy8bj
pXKXYNQQatGB33x2dRhFbUcsk0iMB+/rLz0gNizv+txPbr8VCCfAmUsa1e/+U03TXp8kD8CXuab3
TF96AFVm9/mj6n0hY77pqwRO/9O7bRQMVXe0I3DLQw/we/Wx7QMk8H+/uHyp52WUSEGj5QZoOsUZ
PYbuD9NtyhZ51U/rdW2k8GArC+Trll6MbfeBStPi9m4NUx0pqe2I/8++TI8Hehodhgg9D8/GTiPu
OaGuaJO6RfPi2je624EoiVXuGhHmKSNr+idy9N0xV6ZLyJQ8jbvqH2xeTxaIzAx+KFcjVzMh0n3O
KBiJM/iUA8+xYU8IXirDD6TKwya5+QPw04mA3LyGxBdBISXBprGryCuVVNYcrs3srhILKI0MZ/+9
cDDlPNySu7Gr2TyBLgprAy/ty2sPPvAwiElllzZpwKdvJBm8d3rjJAmuEwOk2sCZl1ig8tMPePMI
RAHeSWQIjcdR7EiMgiaGrGjg3rjFIPHW3UmbAKhBV5ej7mWZn0ukO3P8ERXrz4QT