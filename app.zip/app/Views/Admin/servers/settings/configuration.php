<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsko1fP88FlP5MwJjTMVmgunkt+oQcD2/8EuJD2nrbWJODOfP0NaLQZmYxXyIVi5W3z+RXWJ
GSh+LzledZHSDh+UAk5hkEBsbdQCJg64KVZqrqVXyOCDuYoP79+gDVxqoPiFLT41YPKk0eLVqigB
RpJeNjxMwS2Xr1bsiZ68gS0gg4CO57Z1FmYVJ+NG/XcIesRACwmEyqBRE6tVV6Lj/go9cE9lzxLx
sfF1R5fhb1jyxfcOxCNSS6tYBaEGG+Hi+Ftu9+6KJ9tsl3a8lfHDjYU7lZHokqKIX/ASN5S3Quvp
nkWOBICb0mXneGqg7mL0j35xU2an4LRka6mQ12afbNZlsJ3eH78BN/cX8x9ThLeqYvWE2Zk4ucL3
pE/KDEvJlXbL6l4VR5JwWflxwU7Bj5/nETBUHJNWqCy/SZRe4aGjRt1JDVNdOKXfaIOAc8xBhKC1
3OES9PItO+bfyzIP9/UbeuBKJZAqxDXP+WTYP3URkltq+eHLq5yAJ0yR/SXuqWsPlAnnoFWuVJwz
TIFTH8uVanDSCvC5hQE/RXoQWnZwfFxl/X2XiYUokBBmH3svmwqrnBrNatYsJG3C34y7Kuory41a
+YLBiQmQWhoQaK+kbC9mdDXvcmxyOFjAxopP7L+cdwsg3TcHkz4KDF/FiEtau4WpVAK9YSaKpGlB
N+2oOfgtplL9l7ADPSr/q1Orq2vM5nHagZe1+bW5we0wEQs54/Qgrbl+q9E+SPAqykt64vASxbrD
JoAIs/IpGam35UG4H0iq6vid9tvNLFk7D2MeML2H/645nkaiDjqvC8nyMUzsVA3tU4D5ZlI4vpcQ
SqzrqV6oIYq41Xb0O8GdCfrwuyCZTynCTlzcqP1u7jrTgOEmONp0aA8rRRv+crHbSFJVUpLcnWHx
ufEaXWD5mUXDNyCEBtj+edxc6RxBimgypKFtUqzDOLnINzXeE9ABVgo1td1SxI+LBJAjwpHQcbEV
r0ZkYFB0RO20gR5TWiQ1WclVAXZJu96kKYgtVj3hWrNFwM1WjVyhQVRUpSui8pP119S+4aS9G6hF
qcPGCeH7mBsBegx/eVirOfPjgNclr/d7N364HEi5Ed92XKzyNURTAx0l8SxbgBz+th6dyeAed8TO
vJ3WGDL/lqEezoQZ9hhmOmXbKAoO6IdSoqhhb32TU3qRnCicPa+0btzII4f2DdZjoasBSSGdizqc
JImodGKJO8fPeHeOEXVumw5JPZuMES0R6Cp7t5B5/GlxMcZXET8u50u86BvwCrqC7w7hLpU6o3ew
EaGxKaDegT7lEf46v4fhk0xENj4xa8s781wSJa5YJHw/bUWvJv4oHcbkN+7D1KvPjdrLll9SvVee
juGf+ADMVxKw3Gmt9k1jVj7AGcXgavFpvdQ1OeSs+utsVPtuDLJw52h8v46Ud9903GBW9jWtCxFQ
iGFgRFPFghWRkWc7NW6AhaKnrtj5KSgEXLkbGrKgrv1macQUiYgQIv6YJpTEo1Ezuj//C3jt+BKJ
zPD92+wNpX8VfrKbkBbaBwZTaZte7Iwic8BR21phP6bw/AupXqZUrWWAQ5B+DoBlJS7COHLTGzLl
sfD1s/O0Frqztcki1pJQbWYIjXV2oQSsBMnsa7Snvz3/3ZOXxNfC/51dGbPUGPPgs8h8cpMgfM87
uabLtWvI3/hkGVgRF+qpqeTanbgjD/yHEvkRQx1Tq/7+3hZm2tZUsp1AriYWUQXvEFK58iLmQP1a
LYFCS2qX1PGBbLRo/L1Dohr9CR4MPYQUR4W8wBS4z5iIeWfY+o7dvU34lkD6sjnu05m7moH6jem4
hkrKrTE/3er+rrOVGZ9DxN1mhorOgFakrA5icUIXXcWbedARg38R4DTxt+kXwG2Oi8tBts1BFj1H
ECJT1PAgToLKxhyaivkHd9HoFVdX5YxXN4pUd5J/b+gIXLJSWX07R+BS2okrGf71NG+Er7goGjp9
Jd7bkCzcu/+JEZTIkr1czEn9sj+6mWbZQx/LuXn2y4jNSls8s6q/py62wSmgCOIJxH4X3XiL+MUN
lvVZLh4qFrxpWUXMyCJy22kMbkm7wHWqw+DdOos0JBYYtTr7sMv0lr2vBFnx1cveFJKv5In2Z8uC
sQeHQnwSndAXn2075sF5+FdvcAmJt+BlHiMgDi1c7s88gUT2auh3OqDtKKtblx84TT/PC7wFOUqL
cu5FUVwtnxzfq1c66jsvCOu5ZFrXxpbVYh8ptwjJ0O5ljkkVGAWWkA2nIDWSWxrAb9CchkypRUYx
IELpLFhV0+F5/M0KO9mVtvFckAjDfZFcNEExfRzThfZhiaFDiKY2BR4VlxPUHsKdKzVgl52CzRlx
Gsps+Cgkbysoqe5gAz47awkwCxxxO5lFYWa9Yr85ZqkITzBcfzqOV/K=