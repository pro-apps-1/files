<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqKVsxXmtp+/3SDEct2cyQVP4KisT3hPq/0huu7KoA/Opbo6YyuG1Eehu9pe7HAxts6viQwk
/jVYJInOm6hu7o/78dwedkLAqn6ffChUXlMrgpepvv9VTMGgboEnXMCRsSzwD7JghnOsKzK7j+GC
u9cWwwaqGv3iMBWiHsXeS+uts+H2WuPw7cuL+capVpHYrllz1r5ClGxB1lQzEKMAnLP0hcuKKARt
CVnSb/S7bNrCIjIeike43eVLk0MLJHFQI9/dMPNp7nWRo2Rxs85Hakb8U5GQAqXkERLXeG6nkjX/
Wy8z27bNPQJ7foEl5y1lys4eelYg/5/GHGtkRtqTOi4iZJkRNgGO8D1zgXtvNifk0EGs0v7Dyq0C
TuOxu5Ws5ULTouyAIJgMFnOIPbQdsy68AhNNUHXeY0enACsbOEbQ2bI5NpD4nhtPrhXXb/jicJX2
ox45eowlQ1tIz0h9s6kXwkip6XEKLDu/3sJ0/+BPPVF+Fg0NbqQNImG9VNtJtbcUM2DXDPpoCVNF
eO1GfXzklmMg+ekgSWvv91tupcimfhxKRCYWrMUyACMI4ftl+lwaNjTdAN9qnnhpW+I/YOJ7uSDd
0vN0xWT7D/U42f2IXBZlYQdcTX+kDqMybCdZEbPGti6psMslJoemHjwYMD9zsnN5vEYqomwq+Nww
1fprm2PalB55HjOaqjRU8LQDf12jCBgYxMg8oAeEYW9Upg7enIwB/uf/tOkks9/1CCYo3sJ5bF9d
8X78Z+q8yJTLeeNmMktRjAFGa/4RV+9O+4B3N0BQMBkDrvAh+ccWSHZOkFZe+W6wtFDQ7ruiH4P6
TKAchuZXaBGxcf4keHrp6ZjemVaozNuqznaIIx3tJSahjHMtH5/zRZ7tFpPV1uhvhRGMX0kjX3a2
EI0Ts4ZdzZMggtj365rBTh2Mw4FbxQxUKrRpqtuT+0VjsBYXZ4IwSkJ1cm+5f5AzxU4p6s0qCEvB
SrdXBpOWOSZTAx5rOF/qBkfFqb9P27g0BR21gh2/UGh1tu0EcIPrwXS7TKGUrINIHWGb+9YUnr9X
+Dl60zs5slhnmZRgzpemb6gezKDu2w/QTQVYhMvUY/8HcWxiCfBBewiXy+ArfJe9sF+A9Gq58Y0d
TUBioBEKqy0C0ke/zYtjgf3F8a0Nm+J9RpGq7Lh2T84V8CFWmrkTFQyCPFMCZcwHDZ0LXFZQXqwB
OHtaONTA8yybARJTka7DSyxuTXfqIDYtjrdt8yelRP11CKMffA4dCYsHVi8iPmmR0PDR8fdQAVya
R3DV7Iejf/0kXrPgDItw7udQ8nOB9BrFxZymOF8IuWcI7Gl9hrXlen0JEhq/ChuOrXyBwUf8zwko
5pi7tw7cJrvm36CnL1YbY7cBt+uxu4d0w4SgI/oH6AZdtu7BO4XF9GtqgCoJD7mNbBrrVmzPL1SA
uDhqmrwFKYPOqP9x9yMSd2civHd/pmiDE0zpAAUvm8j8HH9SA7dsyy/sbh27zURiOvVLVskbKJM+
p7LwNFfo0mA7jGSSZjZ2cd2qZjW8umBDZ5C9K4tGRcAa2VAkrGizSs/pi18Umcfpu2xWY3VC8rmB
KBLVrPQOFZNNK/kpHnuafYWFL+VDXmxJ2YmY/TfVGhifGMPdSk2CsTv7G/4Jb3XGN5ckz1jrq70Y
eVSm9lv9wfHDJ0EY5h9cM8AzANp/De1lepS3OwHdGlSpjVZbC6pyuRcqi06IhLjFSqf7fjT7zql+
xpe9N3jBuT9nR/lVerR/4VsNHkbLhruUAVnpQXKFp08H7l84KEfbVpMwhKnR7OPDKGuaWxQNEgxb
2Eff+yHtlu3lObd1e1JzTGQZzacc+gnKjXU/6ITv5RdS7iDtOYWk+l+a248LggTU2nouq7raGTUC
B/oL2o86MdOHEPeWQ8H/pJQHOoDYtM8fd4r7uX9u8ieiDlk0Kl2k52sgagUekQzR+BUpKCZTCh9R
GSuTNuJ2QOg4qgEoeamN6YYgvzwgJGAN5eSmNoxJ4LNZQCUawntMtrysxUfhJKtRHVzGMCryYlYr
6Fo+7bJeZfmX/WadYs3eXptW1Q9wJ91zZl7MbFp/8M5eVRQAghtQjWtIsm+aqfjlXeWjuTJKFwU6
N5DLs+tJiVuLI1moJzyeZCiU7skKkO8WsDMR10ph50GSMSoNMA+t6YFy+6Sm+XlWoqdBI8jnoBjZ
60Jir9ILPGfxVEN+DoAkQinGC3+Uf0fpMDhFMa/3eMVn5+kR+TbjZDQ1+b8TvKoiCfBSIajPQwqN
lvVDy/sepPFb5vJ7FhUtHeuW69u87SSvOyFMRcQgUraUn1PNDnUozgVKSJJktup44WIEvLhKPcYY
/5NZ4Jv2FuD/8HpTMSNLfQvj/yKE14r/doApXn1PSG==