<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrxdSWrSLqSZ6JldBcCqNi1K0Ex35MwK1zqFFy9gZpQ0ZUNvgWc8WVrFfgWMJs3CNmcXDTKO
EBJMlne6H+y/Jck5oaEUy713hcmGbVQky9MqQkXsPqozOVm7VAMlqdUaiVVwd8qUH+oyv1R5tdI0
OQ+aaRzJ3t3bn/4KfamHrsiZb+CWf9P25QoamS2PsLl27+wJk6w+t/xBiqqR/u9fSrHKBnKrkAHi
IKZGiL5TKg5xTdAV6CF6plD8efnifdWRhhiVkeKC8IEnD8uqrkWOb3xuv1tqQcfJ67JgRC3ZOmD5
QmjxLFyO/cws98tpghU3eDJBKwNp8thY5PgeLWWq3ztd6YmFTDj93vvviPVp9QRNuZ+VZSNtc4hd
T04abUXoYFeb3p6m+GiD3Ewf2FOfJsFrSigZOMPKvWCDfNEc+Y0g8ho9vFKSysKuy0SvyQe3yr5z
tSPy4ypFG9l7SIkZHqw7HnN62gYGQdDZQaGX++QFDRVb1hlYAganL2htDL5NXPE+gyTegN98enEs
9sCaKELT1t3Ik/CJ5jZQge6RmelLrNYejHluW7ASyGL7SGJhGj5MQD0Co5zYHfe+r/iY2xjeH0TU
7J/POXoDdilGTHpfhaVglGUa0+AQmxI671klVZyVq50GneIpqVgucQY7KdwffCW7sEi0t7vSRNuj
DNMqhBcbJF7jyDuEuoNK0R5HxUh8YJ6gCdN91wRcZgEm5lH5sNPp85xZA8ijyX7LKg4rqTWjYWY3
PBWJ8l1kuh0TOsbozM7615ofm8iFlG7yA61xoqh1xYFZNfehBIxgzWlUCHcsJiywh4B42Rv7RRI+
2+2l18epq+hYCfdQ6YMhaJi2I47XwmOtvLKjMftIB6304Iu0NJXVN5e2WNul0Oz0jdU6scLEGm5T
v7qFtf2qIJYgFy6UA0urguyTp8tWE801Hkt/gUvWmg9A3+sokdtiNJcPJ/xT2BdfLXhmRqONeCqO
MrYnDDmQnWmgU9yZeKzfAA8WM+6OJn5YiX2o56awQM4GNbgbngf7GXUpGQXhtwgJr4XzZ7Lhr2vE
jHypL3IElVzv0E/t559wwk3dhlovQxAH0+nEHRyN67feSERwq6omf/WoNsBJWPjGWR4KmIZbT/+C
5h5Ai4DcbDBjJgT7ShcgJRliekS2pSPZkzffCD7KczIunsRm9sgUqFT+4tGDWHm8OvCrH5jemh4X
4PeFC5j8omk9nFJDHROSo3OYykzV0kTsq9FcL6w1n1KtprJgEhztAofvGhTbHi1+NetFT6ZhPSkD
rOPTGTwlnLZgzNlBitv3ttKVgtmCbisls/S3ei/JTE0RQvz+XDhVUFzpnS/tRgbkdOe+Mh7KGwtT
4eEpxtU0EJy818hJeFuVBfj1BfmGly1ji+afS8YP6TJc6J7vB58IZPC+wscopDyMur81m/mg4d+U
8wXl4LksBQdtvJ4ttGUVerU6DR49SeMK9i0Uw7EkEk0kq+ZbcJHm7P2uPE39MRBeHcaOm7M92/VH
PiCam4tKgF9VkXa116CtHiv/efBeJP4MOrhPNY54UEcovQhgovmocmvzNDgl10KXv7F2FsSwsJJY
p8qZ1h2iz4yFf55h6g1BDYcaFwQ6NMymD4yHg4/xqacRcWIch55gJn/6RwWaGG39J/9vPS0V7855
nDKuFNKvncquTAOxRPUtS+7atCU4xLBSkc2E1HUIk6LYGJSVHMOpNBJZijNJZbde5kiWvmBgGnAn
Kzq1A6oUdb/ipKt/NxIIoc6yuXQuyx7GYQVk+8uG+neWd1Fv05grnitesC1RPja7Ad6KULTeZSDP
Sj4qKRztFGMRvLgHuF4Go0fi9oddfUB6XN3JiduKhH9QLdqEugwatJAJE5cpWHQKWO9uazXt2GnP
lem7SnA2NVlLHJVPnpqTXzUijtH5Sa0bQo4myRbkDiuFJ2wjcxXtgAFpq8uRYMCdzWCjTfG81ENU
y727m5a9knfurt4AzeNH1fS6C9+a40KzLlKqJf5C0RebuUZgvjMzmYjV6Xx/PMON4HaxuIdHmjkp
8auLHa8ZC1INzBVP7tdmvWSnj/0awmQFcdewuGy5yFGO+etvySrkhXcTyaLW0qw4/1QlKjzpgn8v
GwrD0EJyWOcSCy9Re5EqiM3I8SczS4yJg6VN0RkXePrjefkkxUKfTYz+fMjn8j3ilbQn8sFnlPXL
7bYGNZD62Y3FWKOOYNBdOb/5/v5I88ckxz/FjP0C/10X27mpCviG8DluvIBq0Av6P74HyRfx5sCZ
kcmXXrSRTe+frTLF0LLtVfkdX2stLxnQDAVbhvSvBOWSAbIxIquEPzNLUB0sYclEu4ZZgSpNUxvl
5MCizJ9+iRZN5jwnWOuQRWoJXUFxWz/XDr+LPvUi/0bq+G==