<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwTVy9OJ7ydPweDbjM37amvHzF4srzYv6QIu//RbGl9Ur1cBnY7v9oyJKDxWK1gB6W6pRp+d
FjB/VU6ymyzkYVIoQfkgi3xOo7feoghoUOINit8mAUXnH6c6QiA5FiFbedDeVThWZJebFqAnPH/I
EuR4zh81t5Bb7S6iAsLVDG0CBu5XZkyCo4956+Ji0MgtT/9mdA8h12b92hqvcazILao0bheH1xkf
AP588ELN5Z6Be++lEzBbbrN3ELJM21tFm4JjUqoPPhjLP//toGYqjdKiFWzhL/unwdKc3lNgis1a
Ejn0/r2bhxJbSPeKrZlinKNQ2id4MixC315xKha6rYYpsoVb+0jTPufPbGSkOlRIFU/S8WNJXWRI
P67hwFPHudRyYVj/c0oTnczl7pbF89aTDgCfkGiAkdvg/uiGrbxmk9WTwTQIpVjth/lTtOt9Tvaf
6ECGC10BZe+KbW1ZH+Hn24F8jwZgG6J3Lh3KgStIFgfWVexWMwaGEIHLjwDbJGsVCatojpPkcnfr
TaauJK8Z4ihmFjs02PvirrK6zz24oLG6m8m0W54X4OIuIyQtDG2zZV1J0CubAG1lI1SxnzaCcMxZ
v9k0zVI5Gq8SG2vkKk3OP4+5LOHlGgQiX0YzRmnLPsOxoIyAMlFFku/qQXXd2FErxC/931Hq+wTc
Rr+aI5tGWPK4beI9NBYFBEgNWJhy5uh0U7LxBB05ZkMxYB26Scl3ZnO96mkJK2W2Irta/qhUvvqk
FqFR9BGCkasst7pvYhSCKoFKS9kUFzYVMX4GaoUl1wsBHbhH9TIuQe82soM3n9fQpIFdNSYo+0iF
sK+Ul0ZL+RtV3Sd+wZS99a7LJIPC6JXi/zFRWLmK5XPnSicoAiNVsBFqobKidGzhkAqeLRk25bJ7
vm52Ok6xIEAEZwJc4k11cA7ziVKkQA0/CDJn9S6vge3s/5wjG1inE3N+Nd/pmrt/GBfEZw0kQbUj
5lxeYlnaAVzkGBWnJVLf97A761ZYs4cGREU1GyruBREccOMD3jVEHIfN9eNEBAA3Ty4g7ma4L0BH
yEQSmWQ1giiHFxpva2uoWb5/+zn3GfiiGqci6anznibYZOVuaBh2mZaLP8eAr2J0PT0bp8TJrwe2
X1GxVmmMwNzqtT2c0wjZD8vRd/5jGf3o4yG8KXGhLSpp+5GwDtaYlQ4SFd/D0MdC6ljL8z/x8P9U
/vN8fOiaZA2K0v4+mSpxvZFA3b3t5nXms/voa0I4lpzCjPwGKaG9JSUapnNuPqXInTsmBJCjdciP
dq4YkbGBfJy2A2L9G9Jz6EAlwtVOpvlLR+GuU/yNsPres8v1j+o1wKbwb7thgKVJNY4mov5K6F5b
DTmvnSoHwJ1Jb/GnIuCHLX2Kq/2AGxllDWqGUuc8KqqpCbgzHhvCWI+kpue7lU2QS7pfJxbH5ik/
csKMeBeXBreUshmLxGOZZvhpTrsmSt5mpRghBj6g9sEYa+twl7xDB75fziq0EqrRwyfvTL2QO/Wq
ltG/DN10VaedRCt5nUEEJRqK8vuavDkPPJ8Izzl83j83dP/iNUVyUNPSMRBO1i3u+87yTKVXIs4V
hwN+ObeIuV44rITHH3yR3oeR2Ub0PzyKE5JHrsDDsLWEzR3LalxrLcLalpY1DMmkrcOorZMJ48K2
d0zkfvoDxTkGtKl/doBdZh5ioP1J25GbWvujqe7jf034UM7++O5gf7ii6Uss9sPh5dv5WWukvGPS
0BNW8lLfmAwd6XJDT0iHpS9pSLigD6ehJes0pPiPCIUXsQr+fg44QQI/Z0ub6oYro6c2ZV6oTs9n
57536dcKjZvDO0GYGqno8qYkgbDRiLrJA5I6Ku+Bb0+r6YmBtsJtrHdFogmCzaAZJOEEB+b1miI0
zruu5XqKFJRav48VyQ6tTlqlFXw2FwPi8fSW++5CeBOrZHp0z/ZQZG6Qr5SXA2akc8k6GyyCwK0R
IcdMGgIip7CMoboA6pa58vV2Vi1QygRMmXO6fW7bDoBelCrMXCZI3sbsCWTXN6DXfRIvvLZjeixL
8GcF3hRGoNUfKh4VbxMKydfwvmoZFXaUlT4OllM9KLcggO3+U0I3bT1W22Yu5zMGtMV16vxtAkIU
v0vFUxme1ghTcrvRVhek7GkbGKk2vqnXppe9XeaG+HYF+6gL3wdEdq9vvYGm3WQ4hnsjvCaOrRLM
72jkNhPPk85oX2oWQ1oATm7ElM91Ju3csUexLpeZnCihwWJmkXvgARg6ouS+NqBNr7r1c55DH94U
FwE4QOioZ1LEqx0ErYLZJZ3Y3l7X8RbT8IiH0I7YI/djzOrBD6W0NqYpNYETcRQY2JCSYwEIQux+
T869Ops2h9MA6RKhWDLm1qo9uRzHJlcqqFQCTW==