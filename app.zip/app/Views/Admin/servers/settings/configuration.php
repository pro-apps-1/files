<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmqhM6bzgw1EUFVDIjBjHK0ZB6gpDAfixRYuUK3xtVycrgtdVeGuqMwGuoHON0V1bTBQZdSg
EtKI0chGJOOT1PyM8c5I1qdwi2Fpw9uO/M3XbT+8LQDFZu2prpFKE+PQQ+6efhgeHV3KpzfCoBQc
QiIAmOOGwWp4Dxzw5XJDV/K75G20U+FDUsB4o+XYmMihmQZ5Oiuf23X6c/UYTxuLgz1NG/IRuvP5
33Zppb9imfljie0nrykzusbKCt9npuODGmxcSkkF2qtch+LXWRBBi0u7Rj5jSzwrTeTzUqizs/GV
K5K0LdcEmAktQ2Lg0unbR1onkD+xe7dHlwQBoLSQdieT8b+hDjq359QVb2lk/sebxfdMYmtzvbQE
dO69b7HEq662ZRUjPaLp+rigqi4JNjt9hXeg6gIFTb+mW7m82/yl2mifgZQm8bAtYBCI4b1seR/E
3h9d/pxzkKpbpvUSl9BwGed8Hk2c+xK5aaGvArIeYLr/whUWMCR3AY+hEBC5ovn4S5FxKc4jaG1p
OoyJbtlAe76J9yQipymPt68Uli55hNkUPrPJtoZk18XOw38/qCacI/WknfQArHOgZZ3pZAnjU0W7
weJovCernDpqytdZhHsJKP6Ku7rhDNUKzo56Mnv4cHls4WrTTw4Qdql/SL0BroGaspUZ0ND240b1
5h+8zSjbV/MRvKS1ohNy9L9NzBUlqb16ovKpnDYv69INfSfcKs2VqFNOP+M6dfekQ0ZDRqzChctN
eae5SfLb7CUTw/icxk1p2mA61ouNWL2E+Zvd9cBvO5PbEJZ4tHjYbBdohqATyF7chLHA5zQl2f8L
3Z0/9yvomMtkAw44LmlEX/BpmfGgwTgOQCoo/cMO/ZSYkCE6wIzgnrOol9AEjJUsb6IqRwdwtvWG
1Eyicp6hRAnvM0G6OYFCfmhAn+mKTaU9guv6vWocN5Q1zZ3NQ8jXzmrllvE0mHH9SDCLrfCXXCjV
B98JO1a6TLTU1Ks4F//Pw+qCG0k/YAZHlgb0RTTNCDq1O8sWaX7RICYV9spXGftyIIp66851oxLi
LuH2ki0F0ccsWz2wAu8846xcTcp83qfrMAo+gqrdm9b4BkoPu6f6WoDDdA71bsX0dOXhFrV4THv+
WGPqakWB4CCJGunoMLZwDh+Ly2+ml6l3Gf5O38xyQBRRbl3Pxl9Tz5DkT1ATpAG0/cgihO4Ophkx
8SLsyBWwgjvNORh2Mfz/JvKi39cCxTXeZiuh0vSozYfs+Kx4ju1mHebG7ZIqc3hWwk+gBLX49R4v
sBfGiGLuuU62p2UKx6RqENzy6wDmJVJyN380f9O1gBfrIlVSn3doxMnuPHxPb4aUkZw7woffXdVD
hV4MVgqYNHOg+tdG9Ti3IY2kmk1vk60ZWovLfH/H8EAKLPUZWHnGbnDrEBEE9QbBKpZPyUeHiZXc
+Q6VEcKWQTwR8J+Ws8gTaCTRKH+vg+2jZGoG57guc9iBcMGXEqwdAsoiY0p33F/6ov/ZUUC6u0Ai
Fp3lcsVYErUxRezEZn2QWWd8/aMdxp1KmtVu7IE5J1ea0gX9IGV/cajF5zVpqyFE92oRP7+dcWbQ
5HtBKvy2714cca5pvUJTvekRM+BVTlT6Dk48ICk76u1N7C8c2jb4ofUYdl0zKAVYqGlvYd+Iy1hd
5+KdwIyJTgpHO5YP7xSrIL28Qmhw7oZVEnyiGu+n+uFgKDSi84KYfHKm3CIJXYpsR+iNEoIUHWv8
6/0rnD6f63DGJ/FrHQMn+lw8FsR/i0TOPslJLOrHQtvEkykPXTDoEC2DNiekx808MK3hpfxvgLbk
UQCC38SYOntd3FJAS/pDlfjxiaadG6bT250br9GTy+P2QkYd33coZv1pBHfsUVsyZg85i1UYPvQ4
4WWthabtyJrWPJHAfurG90ykjiRYUvocN8mn2WYohYE4EnuDj1MlOl8baOVTe8q6ZvvbH1wjuHpH
/VPkEuNPvbmjS9sdhGblntzYv4rkWJ7LOUw4/qSUr5gwn5kjoFj7VU9Th9dbOuxPRefiFHtnZuWz
UxoARl/E2tli/NrMVmWaH+3KlbDHPBAvSUSWYJ6F84Ke5lOb3gUYfecX4pbwPw42u6bTwXH5gcyf
ekeUMBa7aJOL1o2wXcBcCMyl4bh/h3vRvrwneufjBvtfL7uw7fZYveXJBph1bAIAOGafOk4Za+Yh
IR16yW7Y2WiK7Q7OrGaR3Iym7MbPieyPWQr6qpLM+6MxhUDqK9o7UONvYQ1nGAaLBjZp4AmReOWC
RTI0HfJV32J1p41NYAfc3sqzzPaFFkyf16k6Lhysrong8Whfiy1ONSLuzXAWUdsU0XS4SdzF7B8T
RAM6ZmyLXyqlBTovUEDJXXTCkE6yqyq9W6CLnvXxMwbC3PDnhu1kjwfYZX9pXGAcimGaVm==