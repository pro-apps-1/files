<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy/YyO7CKCgsYJvaefCxx1iQNZgJwMVPBe2up93wFpJmLi5VZnE2tWqaQZfciTnKvzsSh3Xu
/7AjfDmiqtM6E638azYRh/McySvHBZDtBkuG1OPCvqplSENAgn+swjVvwk1hdytWYcY7wJY8h4rs
IIflQ6XWYyaclCl8JCXS4letUrSp3o7c+N3nzd5iiRfLC1zxX6r4JR1Qh8vBEshWzVLMs0lqzy7l
RMChAp53QgJPcv14rtiquiCRd505iNbHoFNYbe2r2DXL8GlSdw9cbuGu5HXmMqPKFqkd34jG+iiJ
1taa+YdjVP2cwTXlSR02U6aRBI3+a9wI483Crdi1MIfHNpKuZNo86UILUvP/AFgwKfjBT6xPpG9Q
LQgXo8hDFLfJ07MB0MvTYv8eqMgyWizg6hpy64Ie/S2m/St5gRt7nTkeR/4/X9TBo9NTtfmpZaqk
P9D9Xk14FPFG4g7uOozxBHp5X3OHY3xEYUtw+7oiU8A405wFgXmZDZ9bGurPFpTHpG54dswecKcL
niC04Uctmk3rJrKzzZQk0AgHKRgs9PjiL2imVef2PaU1WDl8lZ19CqzFlzntvdDZA3K5BbV9G0a4
wVDydNF9qE/UtFrhUcXi4FWjkq5NqhEjO1k49Z44a+j58MjVmo82lwzB8IvkGkA4GCZEHtTDTTou
WH4J0Saw3tvcNYMqeCwSw1exgv3kZ8fzGxSTGq/KBnypiDgcqsWxS0qDvbLn3DElpJsaRBhaL20F
uD/QHHi9QyrJ89A2Vf/KxJ6B5aYMCUfaZvGm9g83DvXJONSZP2Kzh/I1rz2CsRTFKlf7W6vJGJxr
5RmB9SQtJG19ioPKuilHlR0waNoMXgPy5UwFmdciIAboso4+HnSWZi3WAP8ffu3RlVEaWH03ki90
n4ZILOLpgOOm9soyFdGtP8rFtBLZyiOI9KNgPr284DYMJcqelq1x5GmXBwOIcut1FnOIXlqhqu2/
Y9i92FacP06+WXwhDV+B8tXBFnyjfFFvOVX4YVk/4HAMKy55+g2NeCU4tmHNhuncO+/dhOhtBwUN
YTAVWE71hRJSr8s3SWA71F8GighOEG7FmkEjvFeVG+VQy59ZQ2DLVsFbxxl6ngWJuUA9u+cMMu1J
6VXI4Qt1/twxEFOjCa06J8OK4zFpjBJJnrSHTNQpg1dyiKQZ71kUkEIyh4SGdQFbbPb0eVL5iaBk
/zbJFcCGZNYwTpYn/7W379XArHZ5yL40nromr2vEDSPrCWNkgr4XsFl9GsrJn7Qi4vcR1f670x+5
X6BEDIWYNeypf7368218SqWKTFoRGcHWQQGAhShycZDNaoIx0wQ2GuqO/wF1WF/90byHfBzA4vlM
sKn4PmmsBWvbroyR77uUerp7cMl6nxxDPWDD6dfyXvhooKDZvT2/LzF94NW8ahCCh+N+A/DQgaE4
/luUKDu3/h1eOK99GA9XMYejI0ioeCUN/fV8UAO+h9sjzODIaZLirKPC8tAEpPanM/q5M4QnmtfE
353yqxEcXSft8d+ZT+XZ6bsG1uCJTYkgvckL3JlhOunxXaqnDy79pCVc0RYeu1q8noq0/W9mEQXU
tUDUjA3ZAw+VgKBWkcNl5P00gkDUQlw0nA+hxA/IbI17Fb39lfIqxZgCLEQyoRMNw/Lb5FHfJztP
L6zpSdBnk7PykbkJNIIuYtHH9g7/RpeFHSifYIHswbBcf7yL9DcJe0+DeAnCeIR06Xgj8IYlBIoy
LSXk/UvKxNyiJ1hRI/UZvI+28cqWRXUqRq7DlJqZgcDG0Fy+TRmtnGY0Ck3UB7CM0SYEMEPyjOsL
WSKmaAzhHLgTYqGH7hItDjrtX9ech784MM8YT2Q81m+plV2wbBYzCQcFDtCXE8JjU6rffwPFBJa2
cSRJnqrFwY9GBQHCIvkgebCbq/kVFR+v0Ei7xOIiGKQAeE8DQuTrzVdXmm+TbfCrlAaGukGTW5ko
yRsrwhjgfNv+vOQ85VfyAvyp8mDaevDWi9QytPTlCIvSjyIGExU89tl3eRaXA6fu1lggIIvysNyH
KtlKSGfkyTiuRuBe2QhXsIduv5svRTqqdtYBkHDL+fIin7XaOmPSPyYvpZEaXHTXL70u8ESaj/+I
0y8OmpyMa+54s6uv7GNhqDERpHkXaRYRqtj88568jAirxn0D5j50YFaOb4KcmjhgTjnU+LIlUNoR
niobjQoo0NaMcSKQB9Lp+PoEBZBWXQN2PS8RJT16WFe5a9EtZVzkbyIXZ8ukZFvFmtqrdkwHIk3u
sn1+5RS6tnNhVy3Rj6QSQLmDmR/4Uq/e/w4jPiy1Rj2SvHfLvQCn4t3WPElQsnMLkhJwlvpxrYlR
VDT7cpLQ2AHFjPG7Wq6o32UQyhuh1gKFs3yjIgWN2tLr