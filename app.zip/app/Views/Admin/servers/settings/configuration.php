<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqi9TXnuoKfK1TNZFpkdp0cxm9nD7lHFBzn9W8ZvmbK9PsdO73zMkkzckSUwPXEth6Dw0lUA
TVBJ1VsJ0wwKxUP479L6CZTtxzljtALCjKhekNmfSzKwX0HfpbJYkPUUywkku9jkA/m6XYvBB7Bi
Y36lmfIqQkFsITDKleYb5KjZjNZ8txhCt+qTuGjE1m/97kwZjw3IztGezI5nwB0/ylhxqs8XctZE
IwVENBlcrEuV+zAK/6Wd9f7rjL3gwfbLiDoILNdcw3OBYl06iL2goSIbkbawT986VZK+X9xY2PwS
g/XwV/yh/aAdI+BOhGDbuwlkPEd8V2a3/WUdT1ATWxTQP1awvRgYYmvWBiNz6pOJo1gsblv1xlxU
zvNkK7ZtWTgKoTDNPG6s4OG/sczHmt4ortC5FTfaOv6YLP6GhzGjDVDhA1k1cphtRM+70KAvCZr/
iQGFcrbBqTkU4Pz+R0er/OyF0cUPbO0dyA/HY1fkNQDxpxrkOulMOWwjxrlHeFP7EjdG1878WQlV
uTUWLzBgoEnIddggZhUrG7T1KtgNFi8kzsfOGUMXNI7VWI7BQ9OHZfHBpf8fbzRSIImRa+vQDRX2
3hNqxyBmEAfufCSzcxIRheEbHrIOwqxhGxThZ1xvskLM/zdOmEDkh93qoGUKPCjCLaB2FPRA6Yc2
yk3By8PpHUqw2iCnU8YnKWKBRiqzVzxauu6FePEzBdrPz2LUTOfMssbu/21JXVuMw6NXmv8AkZUR
uJUxR8mcXnNWNGy1HESK0OpvPHmtVexikkGMItmsMF8AEh+kA1TVcHaqMUjWvfXfo+E6Vn8iPGI3
vWeZwQ1pRBwMsUWIPbjaVr2dmDEiU2XaiFgu9D0lWrlySrqPVw/flo8X0foQsuEXqIlaNnIbuGzW
vRfsu/1xjGY/fF5N2f4xzNrDId4PofYMojyDSpMo36/WfCLnWLW5tsHgXeCjq3+/ui6EPolg5Xzy
AIY3Nn3/8bJKtzkTEpcujeX9YoDhZ1y2xDQChZ2YGE0YEjwZsiFnyMuD+mcJuKjLwP5dnW1ZGjdi
u3dL5Kk5yq9jkxp8ELd1RJuOBcE4QpVkQ7NHrwKcoU6EUCY0mzDxptmbvQutAp2pMaHpusFafQnY
tGJOR/JWfLOzhzhd3VD7dGSeHBDXZOpPLhNwXGB1VVbdTTWxb4YzHCOmMwX8wU5eASopbvMzS5lw
8fzYSmHGgIxgoj7x8yy+7LUmlY2ynQRbheY3N2di4Wf4WhJcj4TqMck9lN38i3gajQ+sBAffI2Xi
O4iWCzSL5hEHMMetb07KhmZWZkgKeInU6yMy01KVlI7dCFymiGtuV1qsc86kCY9hv96HmtUBOqSZ
k3M5pIeZqgunxcimXSOmYcOHtwVhXvIzocUPKyUxrcTM+u95qMCeK+w062WILRDDmvFO3bYrdk0p
NyssobPaPOCfh/Rjt0jknPSIcSPNM7JbtV/gxAa3vYQDHNP5qO2Ev4k+rlZ6NRTEKi+iJFKZohYg
Fi7JzGYnlPqzZVPTMGLWIfr76N/BIwG9ESQ0NYDG0yIIBKu/2ZOjyjYayPaCAnAkRpFy3jcRrVKd
h6bRQgVycR9YqZZ/7Ndgptw7Ilwy1s1cw6u8fFKzYpaFbuOEp1R9ED9Zt5S7dcospNCXFOpMLVbC
CaZruZvIQvy1c5OXLN9fX13L/zYBj5kXUPni/GeFcbJzxdh7XSziE0DB6kXwmaWEMoCHtfIx+qd9
RimYl6eQT9ePZBmiINC8GFupU0MLBCu9pFguFutvId4pzlsidSprUoJ0VXaDwndTybauPHTI3zlK
abC8apB6INt+l3sOdNgUQ5n0Eihltz/v5qnsZ1BpVnWVcaXOClS6LPQ7IME+iPfWG7JP+LkcOcKq
zLJfa47q1prYek8uUtCqxr61v1sY15EvFzZfkDsY5EhKspJffofZ1nXCUif09wWDdFm8ZZQFNTTB
Q7PKT19NlMwMm7LM0+2yg/daEbMbwoVu2j4w9tsnOuK5kLJsUGFFXKK3vBV7WmCLoS58n9OgFh+C
vLqa5VNRDdXMeHk91SEJ0XU6CzwqYgJ1lukxHjhKYYLwjBlHQQ6AcQBi01/N4+tk4LcBYbasAJTi
zF7HHC53fTyjq0oEH14lwTL54krXRlEe5xMznw8+Po/WD8CCMdh3i9lPV1MOQY2LvvVT2tXiGCVu
/4McqRCe16sIw6EYb3V5nxP7PPFQdlpnTPNPflEIwlFzpkRC3m1VaAblPkm50Q6vDhloen6fiDCn
cS6ingC/OuX+v5NAqcfvCx+VWpSQBnroneWWFJet8YyDnzKKISERCTHeeLr15XNaRif3t35ou1wt
DqRrklveHGYdZ0W7PWNSB3gbrRKJ5xx/cW==