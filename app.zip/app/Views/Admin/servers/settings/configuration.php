<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPndO1rYUcVoVPmIIU/U58Ru5+BhqyCwbSRIuivk1sATzcQZCV9b49Vw2/AB9Q6WlWVcbZl4O
QOrfmIA60UEwcMJvM25xAymVwmpy3CHGZ/LmXZ/1dpAcxxrRIIeVI82xHJuUc6TC1W84PahKBxsI
sg+pjVwXWi8zTTr9KChMuvNO2sVbEIkW6sP7Qt2VkDOg8/9CO0TxmR5K9bYEfKIaCjlcbrqshdE+
M4VSWRpXthTd8OOHS4RNG+2Dvdw9MdFkjcXb/DTf3JtsYDJIK7OUWvKJvfPj5yOxefT9d0+KnPlJ
aiO8/zsy+yBdnmDKY6IjlMmnXRgvVIz8MI0Pixx7LqJyE778CkvOAIR+vptDBflE2roJg0nwwoaM
oldjc84hircTir90h4QecptWHY/6EnliKi8jdeuJ4kZmqfjPv2Z4Yi/wRqA7sU/KfdbaVi3kAsC2
LNi5HSL9Mq97BFxx7bnxrlfY5fwkLZbjKxhD7XS9ARBhvvAqalse3pEtPaApFKUYkdDH9U+AboVg
2XuW8oLAamwgcV9TSPWbAKoxJCPbePzcChR5tz/9apMcUpTbuiAHsSamxTw4i8Jn5rSUvXh/+o0T
vgJqAPe3MkLQZTmnhXsqHmWXqkp7+35u/6vHXNBj1Hp/WZQkgqnsQSZbm/4KlvAR9F6jONMWwi4j
P4h2N22z3Mv4eu4mzea3gWTPfhdVDauBWZ0ZTtV5OJu6aM0cMLwLVDxFHJMQorI0UECPIYbPPHai
qmUCEVZK/m/NfYO7/bFn00GmyAtVcxcgmChva3+nijk5NmGS8/kE4MJolFBrqqr7qRG5R/yzRMfB
YgfqkBkp6Uge200rB2cwAvEKcXQrV9IKRyHSOIJZMbtT62ujcRXstmbctU3fE46RlJFSTcHNb9IP
AxQgq9gICqXfkW6gG1EIcE6HRgiTWx6zJAe3afMDHSHzPEA/BbDQ0PXQ/DZTuPsgshDe8xFQXd+F
egL1E//R8GrZhrmV/ILE6/wLEvtaeFyP21BdrV+BX869vqem3JtYHDVGyl3IYBd3D4X6IN9w9agC
Jf0AWtY8PXJ1Y2JWRNjgkXM5M0YZ3Zr16nV2kj/LwbGmebPofhNtBA2gpKqDMWlO2nSvUxzQCoP5
MBeKRzXqfsXW/xNy/DWNfXOaVjEXiHFHVoxE/teYgbQPTiZnb6g8Lp5DjXNh7kWvhEerPgE2JzyQ
XHdHZQB9s2LaWJDesDC+sjR7ty4P6MdBg72/2IKPS+rTZtFk3vFbywWnZqHC3HRrCiJGjgAg9PoR
dU0VnElmi3Ew0IV6mMpA9NUG8/GLtEXt0ej+80Fymg8pPTU9q95OoeByQbnOZWSsRE431Jl0G0Wz
yyEpxubWgpl4FhAtuZvFn/5knFljB0gLCh+BxtqYFIhIUjLGdiOTJeNJD1zXTqBPtZWEA79DxqUd
2ddyPPdNd7D0o4am6V7+2CmTEGDgaxSC56lyOQ5b+Lvdttaz7FD0zMevo/fqZ8uTJjuJUXRZaAy+
QJTpNdZD3VuBW6HhmCoyk7vlRBGN7SQVQX3r4M9Tj1jyPsE6/WWDdk3i2ZhhakUtdjUH7PiROfc0
ACI/kkzJiT37rURgMPsVQZNBUkL8fr9pR4Fx8q+Tck7vxuiiciiZ7us/wp/0X4CKfyk/YWg/j79x
aJUAY5PAInAdRqDxfdUY4r5aU2SrNkwp9QHdOmNupGbX9Qy1SQN5YBY1pwOVpifloFiMLamfs/9y
N+ZX9t+EaHzisaMN5GYh2CXtZ4XPyDOosnfE/Q/1Wo6Ds/mw52ewGmmfiS2KtVvyZM+u2Koa1htt
HLOjvDIDGjW/MrnY1mDzyFn9SXTAlrPioaEXHChXt0TzrupXToJcAEveEtlTuks3NovpzKbeEd/J
Pj5go2XEbuTINE7rfzsLBK3EmgfyQDdrNbdFUtQAii09+UL/1DOdRzPfO5NPgjqzVFqWMbATHaAL
3rx7qNlNYVIVZF/+WxkUfl6AJ0aEJurD5Db3GBxQfHyv7RFiBph33Hm+p02LPZHQwU0k54qYXNvC
b4fpQgoTRyXM/zpGFGUzkTFFyV3iscjOkLM3ZJtuERCr8xqblpgGoRU8XXbxkpk6rbb/vZCQkOj0
AFa8TfhFlDbcp6XfediFDqOI7iYhW94jkRqOTCXZkut2m1jgVEkkc1NqVgCSlecSEBRsQGAozYLD
TzuSak25kpVgRRr8J8oFTY2ByV8MGFVXp81t4GHST0XlFJD8biUdRtp3ixfjJdIqC0FwC2R8fBjB
YiiLxf+MKKRPCdCM0nb0g0rczaiirKREMlmrenym+tdyUyRjZDXP/uIjeMuuwUXMTOjM3xY9/5HC
Wu6nggwRy2eEefwCc17dh5MYxwQsUrn42r7EZOBC38e9nf19eLePa6S=