<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/NIkNlrW09yW0uiM0ePjjR+sS5QvJgFITvBSR4OON5SPJI2A4QorQr9RYaLLEIbhA2qpJDv
NVjQY36+jDj7hkpsCgltzcZ7tyfs0L6vNJKYCgH8guyDoy0kXRHbSE1Qf48iQi+ajcmOSTFmHMnU
XPCuzJUdSWgLPMS/wlqCn/B+G2kLppQeXie9CTk30WlePOG6a3UcSOYBjLJuKoORqvHuLQhUgJSk
kIhJnJG43iFQZ+gFr990/2r9lFvWLIzJho2zsgHmtXrmAIhk8KcRH1+1U5fyQHU19HWEMj0ih87n
Ba/7A0J6tSOVYDj6VwFmoY7dvyBA76Dclrkn3jQbXZ1pVBoMKAkdulv31THY0LM0zxyZJicDsNp5
pmyIX8ahQeMQHRzHK16iofzgnVaMDqZFGgmkD6o/6Y2wKYp42Fm872pTewVmP86GZFFY/nT1sYHE
iEqTEkMJbaLg88cgcQUm6GIij3sGndK2cjk6xtzwK/LgbsqGSI+gheHzZubs4YkoaSaoGRbmBu6X
L6UePeT8WzlMUjdPlHQm9jnqVZONI5v1ZZ9rr4eMuXymbSdUMrCcwbGzjSUnXPGWPB7+QQ1evj2z
I4a1XhkWXhL5buaVmuuRWe6Bisi2pinZo7IvwjY9cF/DatbZY5nHRgSIXRB3rwEXZjnQIn6bZiOA
KK5XZuzSS1WHaIP9qJBjp8ZbrRfZ8QavCss6Q8fQmm5mhGA8qIlVrR7p7PatWIg8iS5hMgv+gx5W
yBssKvVfXkp8yBo6h+maMiadC2DRXaAczn1RHQfAroUtAGoCaLW1a0Evco3noFFoHTS48/TzX5Z+
jt1xIDE9BeuKmrZ9TMlBr9o665hn7tgBgjQ+guc5nVwuniu8zDNGxzZcfCRFtx1d6T7Lh4z1mwGF
mnWrFNn6d/TaatarWfd5mFQEGHL7Q0FlCoPk76z+vdu0XOEt/AR2as9i38VryfPIOqStLHpStxIx
9amm1OOjm3so5ke+OJeXWKGwAVxziiDgNfGoVUczyNdElkw1+zyUQNuc/9Q9SxlicYr/ZjzNEl4h
hLQGA7cDaX3855DiIpLZI6i3kbDryldFggT1BBun3bVGnLMzmYz2c98wBzvzkAwFeAZJ6a44h2SE
ZSyIFHAqSiho4TvPRdQyefFC34viW9CdK4Af84iR6yctjAVkBwMNtxJtozj31wveTh1yGl3My/nD
YVeLaKa/DQrliYFSjME2PhJyQyIjR+sVcGnE89tVx4vY+EkAuflygrtJOBblJNsc8cfBQ6qWHkGi
KwgUSsuVdGqpQXquwoRoqNRP8CrUV05r+xtf/hyTD5F/zAl1Y+yGSY1SE4f3QnnQMdUdU6IXB8eE
INPvgoaYvqFWN15jJetzbXouKX1Eyv7oI8HUAx8NbRbwJEg9HD64SUHi748JvchC0rHj/B1XocaC
dDDBmc3jhkZbJFGLz2gPyAMY/YeijsB/9sxsP3lijWe4gE51awf78ALyqrCUuabQBj/kc15ab9h8
U8ToeOe0I+vufYg+1NnDYCZC/DPqqp/+jigyTqrqQl7kvVENWsn1RidnOp9j+iXs1VT/TYI6lgpH
3Kmsf2RO6UQPl6t8Qo/QUTWiSXIhwcL3Uu9och4WrDKCDfR8TUiGoh/2P23SQSpuNXq+JOdw1CdW
pLwX7PYNWJ55/HNvXVHJaPeqgq1+DOn8/n2o6h0JuRCJ6vyP7XwPC94SsGNYlJSpQotpb2Pa7CG3
irJlmOps1E3vRlBUFtCsb+10HWyQxfnmoyKZpdbbGHj4KqTw6/ivlvlGJPhPyisFmpisJg6bKPOv
6LDaAUPcjpGNOiwhr5nZrC6afDOnwEAmSBNuDY19+mLN2V0mc88D1YyN22D/udBAdXzsacNkqMhm
mcANCtsegJEQk4U1cR65t3SZQzR5wEyo8vzCnuLcgK6/gq3RxjqTHxOMluQFFzUDSRfntfYpSGTF
jFusW7FN6TGbdsIVVI3tn8dlnC3/KBDBVzyx4uP1/sn0tKrHJOf9Hi20QQD2ejL0lF2a+crFYS4r
RIC9CMRF/MSIJ6f5ruAAiZTyPUeEDT66wmQ5KBzrjQFzRBVo/nRKSLCbE5JlAXQZQTWtnO6s2lXr
WAQZh38Q9yrIjo78oN996gaLi8quVuS9+ptr5GqvnAlQetOsrB05PeK3FrCDl3qd2n+YvF3UBpIW
gzoNxbbyPckqpakIrzKtAZjnTBXFIyKLt7rL87/3Vb61TEi9QXRSLgJDkzMAz+2k+qAwU6oMQuOL
rgXd36dkvGwZnN5Lwb6znJe/BGbvt3Yqrs2sHgPdjogBxHP8EU8AjrsQeDIVDrq8ZLbD5yVBgPkT
lLqUYk6JjTgxvdH8v6KcY719AEjiLdGRy9jMQaDbVz33SmhySlrvcxjD6froan++4YKRqm==