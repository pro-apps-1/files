<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmBfaIgwQ6eDGpK42OovgUAn40zyTNpAVzTp9ytVSnOr32L/OL3oO2N7Z+APdwf1Mxu4c6SK
saAmC1YSIlrAKn0SBdhRjNO92/dq0Q9ni2XqPmQCkE1dfEcmJZTUXfQWnxkeBM6979qhBqbberrO
WsIXeX7NzplqiJZDmscvPraiRaYUnxfyaP7qulu/cTSWQNz6Yhx42kprCKJ6UjqJFZcPxYKfwhui
E6kHJSeB5c+R8+cWrMdUKMwcXLJQAUDPQqoTcAiXlaL3Uh/9X1QHvBbCUHysmcMgBidxxgMr28T4
mGdqnHLYPJJLY1JH9BcW//Q0XIArIeTxc+3enleTO/lnb9R4EEE1KFlaWR+08chUW07sCHRtk45W
sb0khJioL/O/Bwn8/ur+arbsA/2w950htmfhgyOPxqWTsZl8lAClOCQSfmgoCRQLlHUSNdqr7arn
VS5tK8rG+gTbnETHnqS1+lZPSHEjnjNZsoVSHqYrh79iOa3wGUv7X3DsTjv9AhIOiKqZ7z54drGl
7pJecHUZKYLkKfFyud5SlfUOvdKfs87zLPY/H1P6V+6trqKZFPlDeAAyzx1guSLanO18B5pOZ83E
U8R1mFtgv5cU0mNfywWmSALUR/b95Q0x9lHnvvWziG3m+QyxC+Ah1Sn7U7HI36azDqk3LoTczUsA
9ZEZKCut59ooa0YzoXYvA/WiuvBwJfoR/DVSpRaHAaqeimBzz/2dzZDqnmzApoZdRUoGUxF6CL0E
gBM5aFEe4b8OXLCjUZhZKU65giEnyUzIzKQpviZLUNI7GMyhf1tNlChY180hC6DhgnNBG1zWv/CV
gN/MK3Ij0ymdKC/+U2tDUZdCPl/lrIJON/4Gx3sovJjE8I2kohEPL8W1wePbs67fX69KYFf8D2T/
wXPPQ1bJY9HaDnoT8t05TPffry8B3d/NbYdqdI4KZl7BJMtXapyW7BNtrwbA2GLMbReD39xw8oLg
uXlvLmN350p3a0PQ6FHDlGI9JbnC/wacEV8Ll6KU+UYoMDIO2Peh1ERXWmxUYLfJzikUrJHTCRgg
NxK2ArstRU8Dzc3MHCnmpopFHyu3nJEFRlqfgU2K5IVxzuXEoF5Co35roNZCnuNU1hUbW+hI5q7y
QoBagfHfusLb1SAli6yE7hsyArokDrKrSK5fdPi6fN+o/qxbwK291XXsrturjf5rm8Ycf9CAB4wJ
kbb0jemUmlsz4tr9yQ2UsR8htzwPN1oBEeKAea9z6+Mdt7fdbIjVjNBpQ1E70ZzMLldpxs2+bPWm
YyAKjG4krXe022He4FvSMSo/kJ/6bNyYkDsVfNjQxHsc4aWOSbOWCMWCo23/xow5Jiby+bXHmEMu
mjGn4g11h7X6MpIH+B/goQkV8c0ORUGpfCXsTmoyz0McduLHd5iPPKYxiTIJKizkouO3Sp4e35GM
b5rJJj35tuQE4Kara78zBktX9waUDHfYTGNLzycn7o7EXgQb/Dea/1KhC6RKxAtCqR5U53vGPG1b
YlnHeBbOkQXkOVIApjmX3i7HqRLEbU4OY/kBqxUgHJTt43RnmDf4GNZH3gxxRMOc+5JwXP8mLKoN
Z44964OdRr6LO1kb8T71BAAzWQOffjRxrBgRSPCvW+I36/aQ8mxmnWTs6N5uE6kLOvS0nYGl/vWn
7qMo9EO5REKWDMSGREHnJZqb8iq8eJKaQalJm5iPxkfF+0GBhoxVhd5vXHaaR7T0yB8XfYH759dj
TcmYNeTHx81e/gEpryksumE8Q3qHZii+mLKbJdAl/WB2wShoc0jwuCvw5vwfLGtbLjg7T6QrzG8c
Sj66sc//XWNuVeKJqa4hiJzoxP0e4md9abNUNwdV0NEwOrUuwet5UR0D815EclVo2bgekkoSYw9G
noGWtTTBgAPAOhEhEZ0CUrpINFQSc3Ykua1hp2yjK0laMGjbyElLmAuUVM8HM0M+CRge3oWpyFIj
CiH45I2sxDTWdNgPp6bdyU9IzTSADs0oSvWjBD1ZBJZf6X8IT8h9diEu7UPgM5ydjoYcUtKg8JZm
iamnOE4KNpvLynzCEdryinOmGxcMMy/akH//AxXkKcuXkAsaXyIdbNSxTD+gbc8SKFFsuTgLAfVP
om04OV9UzhchcTUfwrxtLvM+/cQkt6sMJIz7oOFrYRtaG0LZyu+hD1wrvrgwjAl5rQlH2mDcaEl8
OCK+SzUbimbqDFyGSvdgme05lXKmkAwLVJLwTog8Y924WmMIcVYqOmExoAp/0nyMqsKLJflt31MV
cOu478T9BqSR9EZJqnXh5huDcyE9mwMMZ/bF3bFqQFZ12nP7ACyXGAsQ9Ae7kYUUfpDnFqtfEjIt
J/S+VQQaOwQVxyTH9O+EfmPjfUj6UN4BdwQ7p5gtxaZJWcAkMX7P90==