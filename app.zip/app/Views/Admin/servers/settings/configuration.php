<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvZdldqALmDoqpihNg6i7oGlHAquGh0JqVXBNwLDaQ/zOM8CDzroDVDnPPrRI/b4qTwOtZ4R
2YcGjbsIBjzfL1xlKrz6YP8meA8cpDtjqCzxhPJmwsPKGuAm40EySIb+IaNpfdI3yJ59yE5N0LlT
sn05GDGWpYYVXdsmQ8jqiVGSlhGnVXyQnyxp0WtfjLOtJcsyPjn5/YL9aZe1zwLebnwCHypnzQJd
zVRSEZbAsoRlIfgdXCxeizKKph/4Svu7lWLX6Xfoe6AR6gDy+lCcHhyVEzcaFsg15pUuRuGD3xjH
D7Pee7x/kELUbwbXSc2//IDocABDweJ7jgI77Qc6OscsASFzwpfzkNCEPU73bVgF6JWc0k/arMKd
rYwTTwIfA/11sOYx0WAYpf6qKr3qMv78l4A73qNxRLOBbwF+PcLAu4mXyqe7g2PvvorKzwVRXqzu
G2X7V55OMrKQ6XKbIfqbYpdwybjU4yFakjHCfBuC/JLOm6uMSRw8WndB4Zi/S2CJIr2QRb2DpneT
sgy+QUD4PUJ9ha2DLpW+aQNdh7gJ//QUp8X7p8rN+CPWgKHiGp6LiwIkRofLxaj8jTo6ODki/WSr
SI6WYosJ2HjF4wuQw458PuYFmQUOEa9mNar5FTzHo6JR9PPOIBougfVh0LX8NWrMofY6f1nwNa+J
4/m4xS8eUVEnnhiZ7QmHyBD0WfgxdC7AT/2DcZDzmlC0KCCp2kRtYSpwbeHWfV9Tkxgwnw1HV6iK
1zt9XJIKgDrD7ectSk+CAVgqzWqmID6Aj0b/rroE+ljw91adVheJmRkVHLfPNvwl72oS1XkpeqP/
aqZnrsH2O3crE/NRyRU5MdfejYuedwVSvBd7C93O4pMCGEcnWazl0EcOOxIcj7xo9/CE7HKYbWL8
E66HeN/O60hGlwBvq0ekpayOuIHIUvKh3O3c7MMFmhRdocels+p2hdLzbQL6q4QXZHd4D4PVoEF3
nv519nThqum3/xejUAKVrb0zsfltGVYkrC2weOEhEjLa6m/Y1mFk9gJA2h6ewjFrA+f84uD/F/oW
h0jV80ZRuwmPVuUV81Tyop8PTd5/RNn5M/AP5Z9fEH9s2RkX4sV3vKTizVn5uZWwV6KZxWqGdQV/
JgXbMvClROdrnqtjKnaqTCfUB3UZnCY5hGlSQVBYfINxtRWs7jkB9qQeDDge6j2IlHHVGYJ3t0EC
LYDQ4FyA86EqeY2Yl7OtrfSATecGC7IM7kDk1JXqw1MiEfi/18mTtth+ZJj3hwk4m19xvUDyDBFA
B5MV7iCMPghGY4/XMtuwkOVlcOp8IUZu4eQtOc6ynjJveOeYMs0FBEtlmwCO3g19DqC1ITy9W2PH
rh0My10GC4Y8noWGosj0t0iafV4uWPoa39kdRq/R6gBuoGQsdogwH0Iga5ichoz/impyeLW0+sUb
UD0+bwIt2HVXcCvUKJED2z+IvSz63wRKVZDSMEFRvd0qNNyv/8c1juxcQ3J0svt6N6svTOQewvA+
Ws7DEF78+gvLQoRHwgxXKxBotOpP0hiZXe5vkvU3U2s7XFv4YXrgbsenk7dV/DIfCVMhmaElupM0
i34zkGXBx/H3uC5SBsud7ckctalqspCdGmkiuTgnPMEoOb12zhsq5TdjITYHwXGOMUjMoyTfCO9l
1zTWyuxO1QRGw1we7vWi5Fy5KjEYHknHI+NDjQAdYcXdvQRN4E6p0Xgpm47Msg9SLm8EdR4LrvfO
XPDO/nKDvxHl0cu/jESzQn7PQDbNtJ9Jfi8ee9qujSJXVOfhYzBNWaijwNck+PjNv0gh7sOKpkRT
2RhZ2rM38DTbyBJMSfaGnRrAtPDWTGSZoofDjDsPYqYuo7o05CqT9xL/7elovF21p+XSuGTsnGgv
ACQzP3ZQ1LMLEK4qpYi1/oUHaNMRh6ILvrhAdJZu+LaRyz1eO2NZL7T2wFj+SabOhdVqy0/BLSwg
+t2XSHouXWEj2fEuUF6KtTEyXmPNmDX/DE1Z31nAeyhDmHcIbElSD2WO9ezvTA1V4BWu4o0X04Cz
prm1li5/dCtVDqo7evECEUZCF+1oDBIdnNyUVyUtMXNg8+g2fcNaA6Awt/FiICLcPz/sPxdATl0s
2RqDwETSsvEAkImQXnB/cw7cGaT1A3cL/Ai5qxhRLdGQykqgXWcdYUMMiHk9vVGzcLeBYXB9B+ft
OCKB2R55KV7qd9Qq/7ZOhIRC5U5IX5YdujLjvSy8PgXDgOokEkIhKoK17x0v4eNMIffUbLuL+181
FXRmyz4s21zz9uhskl/2G9pcvbxAm4+b/ZqfyXUW55CXWtaFov2sG+vOlyKfUxxyQ29QjqIUp3Hx
x/zTA9pbeK0O4YlWJrr1+D1yE6m43flmax2J5Zsk