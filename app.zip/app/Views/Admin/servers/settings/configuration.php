<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqEX+dLr4Tzw07rlLfLNoZd2yGUgxYkDyz8ZUDZAT7uFpvzOqvBXISO7zKpWqIC4Dbx3oCBD
hWpUP7YVfgk8b8MFmgb5s95SxZdmduJ6nVZHP6meTPLMXjIWYQFwtrv1cwRYeCI0FOUFvBUSOqrB
mIdDkwGQcur5kfN747qK+n+wKJZ0sgsoAT50n3+tjiHcwEgubC1LsoBVkQbaEYEMmyG6R9gyZa/a
gXgiAySbP1rBMhQPeRzPnxdjRwXhPcgR4h5VT8Mbi2AXEY+NIVLnj/1LIwgxScSCh9fph3loK9zS
J4PvPUp7bVbe6qdcnomtjdeWo08e44Fd9evXA410rNT2c30Eh+ffN63Yycr0vnAhSqLSrZl+cdvf
zDy6RrLnoj2Zeljl1XJ8Szd33cL/oKuJ/lHy3M23kD/bzucAHU2gHeCTGl1ZFTzBrlE/ZA7NdMdW
Gyu95ge2NO3cmlBwjDpfhz6U9++aGrv7BPB0xjfz4fCJsOONrs3kPP/pCqv6rpg7X4RqfwEzO3lA
eVLBko5vC/d9df6K3OS9VE7xlYgUmigXnvYxX7zMX2E287spANAsgMiidilUbKRq1Us93B+dCnC0
Nl6Jn6x4LkbMB1YHfONt4H8RQfgvmLwWmKyES9YXA8O2TS9qL7mbZgoR/lN1rkVoWnxrysbHJn5/
iOKo0lsdQJv3YuwnPxv2hkEqkQ9qWD2i0B+pKyeGZtkc68jh+EhBu7Ep7k/Gzdg7xIQvZwtLw0gk
JYedaPJxjfIxLY85ABjgC7PuuYh/OC4jqiCX49Y+W5lotMalYTeUjV8J+fK0bbTVJ3d9ysPYG55w
/D/FyFAJ3NaHHmYnff7mmmAL45z+2r7zQOtEmS/iMCMcCfZGpt5srHNVW/ab/uwJMnaD1TQKPwCt
SA2/t9w1pYDl3G2VAGWwoDnNflUOPE+sLjr8Xfy2Y1SaXqL/UM/bkrL1qf6A6uOFumBb71p/C6IG
OWWI/+mmSl75TNbmk5EkTNP0PFEmtbTNwIg+UkdcMUVu9oG8MUmx6ZG9X2wjauruhPUgJVFTY2YS
b/dTv8HGPxL3vbTrfwhbXz779rMY8PNsg9QRAxxJjvz2qZNFL/wwzhqSLEZ1BeX+SZuxWfooSlkw
yeOwphIND3Oe2OMKah0ed/r2qKjIsh2tm2JcPTNOsEguOVOGmp2kUef2/oM+m5LOHkIJyEX1AFmn
KCH/i299/7KH+CxpZ4/6zoDCSmQTvSQemhCE3qI6gvrGNKfQx+IW4CVjQjIChsn98bIB4PUN6nGb
nFGMBhDJywuud0vN/ns548+GMqjaWYHY/kFgQsf/MLSZWVoNWsQfTCrerzghWKHUGwsA+b4FTba+
7Dy6UGXyvcKziKx7Hi3NmPi0//huYqUoMhXrF/Aaf/C/zQydddgwqjzGLZGrdiQvJVHeNHj/qMQo
6VX5i351m2G2oK1edafqYs4WPkWDDC5B1Wzl1t+Th1OTNly9VLBlTkxKgrU2jOg6zfPdcIONL3Zy
sZgM7StxKeN+f4DH6UtRkmP8NbIagfnMf/r0y1be6mwMUKEjDA9RMiSTi0AQkCijXpZrvODPPL7/
XPLrw//AxMeA6cj992kiLDNw2yQQQPFwcy8J6+JrWD043Ur5ycMfZhLcN35lET7EM8GIussSyh4W
jjh5eas0xSUhp7NZZ4vSAnfNCX61t0DnIBDB3MaKCSQPluj31GIvM56Df057UI4OQasS7AwJpSuN
xqrqW2e96fgcbvlOJoX2KFa2SKVW5W2L4GZfwb0pfi8glspv3oAFov6uDROujeaRX8Tiiq7eH7l5
yeuMLoynylEHWUo81gPXxZ3bPwTrt0cKeiuHRZzDZvoQyObil0r+rs0ARAb6KtXdMdxL7nk3x6St
QWz29A5rbH577KGpRtz7aGuexRD5woqryFBVQRIdoAQQj8fq5eAm7xMZi29tI8ou6YZP4KYMGqX8
rwfgg5l4IToySszAT/7odgoufWJsJYISq3PuNv5gFKiVNQLiwxJbePkwCFc4DkTYa+VpVvCmBot/
ImoS74X6MJN+NhAl6AQ/EMQ99A/4gifo6n4tPTljaF7xJzc2G7saGZgfDVeKAd44WLJvtdgxIvtv
+Kd7n17UKCx+lt0CR4JEDB+iv435lYpUqMb2o3q2fh2s7tf1+/GTUbhNCgzyQiEb/vUlkCKg/m/f
CspC+8wS2GGuQbdJv7/CbvcvS+RaQ+qjHZENZfV+R298kWiV6NaPPMXSL3sF8Jk1qcX1PQPBqlYn
pZ3KBAOKcUVAqkG7qqZMGUrxasBXNSyuOyCcG753x0JeBMtVc8YaeVB6Z8N0+HuZPiFoWH4Ysk0h
99uj2mcy8J+gwPCzzGj3W6J4H5I3XIbpuAX7A0HcxXpTjK8WcwO=