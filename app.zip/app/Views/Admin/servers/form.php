<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq9GwJUGqj4uRRzy57T1ffRqrI9tVfcQh9YuZp4F2l0kjf7KV085tINFmBvcBzzxtFDMmscB
01XakmOBimK0pf5dWtdFBeWGOqksrxUEUwDUEz9WeoCudOOqb8b9SaATAhpbz5+rFInuyH20iP0C
jg2zt/lyR+SRzz606z0FDVmpktCtHyEDrCk1VHfX3BfXmFn8IuEnsmTN1r4jInVhEMOvZcEAysd3
A/zD877ED6XDYVImTP/CE6ob0XXVU+6P5YrYB25t6JBBuRV5iQSE4ED60oPbtOcmdX4gkHbB2Axf
kJj7/vl8+rZFu93+hQCEHvzgQKYLtbfkJUrKYdG8l5NTwf9HI/h/shJJIwOmqb1YDZ7HCRQ2k3sD
aX28G20r7ZJbi7trmDRruxykURGOJTT5kAB7/wphjaaNn33RIjq74mTlxgsvcTKlJisWgFE4sD9Y
s5mrcAnIEbvlSEpvPF23hprc96O/ej4g0X4LkB2tgg4pOpFJfhoC8cpK+euYOOI+mY4jYHNIiLPe
lnEPVUWxv95kE3f5Geakrb0l+8BnNpLP2+MsBadHo0U033DKEaSdKqNWdsKoYMfogsnviEXhGmuL
M5pReZkJv40ZiD2BtWEJBbPA0Cmtp9gxuYFoWNoaV4yQDOYIqR8frB5fIiMOw2T2k2iWM1lOC09v
vl2FB7UkFqikwXL8RVzxaw8392+4CSV57HpU4SJcSWrQuuyYXAou+mHip8yYj477Z8h9kn2Suiue
7XUTHyTwCorlW+xGcWPagZQ56GWU17akwI5G6xHFpz5CP0uZg0hRWuXV4ShGrskn/1NMgBfAcZGj
a9joaZ+Yh4ZOfMr0mYB6HNzfzYEEzOMMXiY2HFp15t3pe4xhv0pUi2iQEowXvsMnzNdg1NY2pMFr
JGwMtS46Nu7Rb/noDRAsyulxmch8qbLJY2KuKtD+4gegE71Uf3ub8xWRi4bwYVwCvflm1GVaN07W
eIJSfEk6tHVR2l/804V822sbxWlCS420ErEhSDROkc4JmbwiMu6urZTxxkD+ZAU/W8oHZOJn0/Q2
SzV/jsGrUQVwR3KImS+xA/tuCmACBucqtGmsaJ2wTUsfBa95QoOoPnlA94fJrNx6r2+qWHueFeoV
dK0RBBoTOSmM55P1XQew13cWeu1FzF5lnU9joY8VsDvTUUMtVf1wYqJ3z9nPjfp+l7EMJGr2ayTS
ljjzYaBSllqtURPrqJguY3rr0rXlaPtkhz9Mtg2mGDqY6uSlZRCtIXp2ApQZxmSqH0opQlSbXFGA
nfBspjZtOBw6uyNKK8x8exNdO4wP1f/Iaj1587oAaKwCUt9OQ/rC/qIwr+j22LTj7+CLmmxbPRn6
/45lu5kzDULBvFUlgyQQcntII8JGccU4I0silkTSaJbYLvxOKJKsR+kaB+bi+xXtafN9PNuVCUFK
8yQSqs9g2L+Yk1gPofRfMR5YS9VU0E0aUxkmp3WMHVU5K+5s82THNEuDfnHkP8OWGGpxb0JAPlE7
3uCYo4TfLO600C3wAzsUEUkxiWlKzFWh7DGGV6DStQzit5F//cw3n2BRwrum/+Cs4cM8baCLKEye
KvpEe0VcKrcUfpGgyfBL3EGOEpUZIyZkGWITpla7PByY7FGVa1L7FHcEBWhM09LOYApGN0T28Y8x
eqmuhuaqeh1A1m264kn4Bobt5byoltFiFV9b29YChzxSZ70dlHENuaj0VuSBrB33Rw0cue0xP55T
kaHyr7JejHt/BSP+21A51OYA+Wxewv+0dKA2jEoWETYaeJLEa0u+vF8qk7bF5npIceSNJuw/gfMw
+TjwgOtLkmnpYHm0mv6bhfoeP8667cyVspTTiUrXCLw0i4vuQwjnGhaFi8Yjwe0Tc4HV5hzXmE3u
AZeiS9PL5bG8+eHRbhpkRAEOkkTcv7pG9lNwmckcW1iB9wIAxnlD/CPltFUDp71x8Na765p5+VlR
HyEwGr5zxVgoiej/spXETBhZM8/UverDgxONeP2rAVVcYsDarahGicqaFl/H9BIb7gAbiDIhWyTs
9t1C2a+jrYYNR53sGVv+hWBZhrjKT3Ax7LPVGIF+SnUta7gPj87WEHs3uSc4Hm6SVjyFfBNA2sn2
ROeN8wncscHGGbacCjkaU+s7zpgIkeZAXEIKCoY67dufNqkdf3FSmK1aKrdYtZuzEaPZG6qNHctO
44fp5H3HKSNSWNjyILRENfOX0bA71Hi+/9DLKoM0i8e7Z2ruyVoD1XxfiWYjMqFlIilPm2xZhQic
+aD+Ou3+KSUpeTdRMA/B04y1kud3jLZEB04qt6gqhOrqGlHpk8bbwR8J6XB+2j1EZAaRid2kXuPG
v/Z6c5flJjBiImUmRibVPEByU0MpkzFB/olt4uwfFP+1YBVxhvyltStIqHA1uuQUBRl0dfm1QmON
r8pFuPooSfkuCGJJNlgjdPmxD6ETur1mjGCD9SJs8Zq5rhsPj1OQ7eY64UjOHHjISh9/ZuMeA+Uk
g/kVf5IQWf36qtsJAs+91fqs4gxVsha9HK4Nm6Yo975Q0MlleU4wJVVTPP6rwobAzRxBgTAY0rCs
TwJoOoDno8Z6Qz+PARDIOEIznzlCJgYbErSxwkzIgik8zbeHX3KOFwRkmVaqMyCEn+gSXoT0s/RI
xrp5vGlf7gIkZit8kgk8c60MOdaOmwKi1Ps64PjaOKLZAkcLW0AGKzWDXUDn80IFN7+GdYL4v2yl
qVc9+afxKG0EOjIhBSZBAhKbG0pCcXxRp2twqh/GGz98j5193Am2v1F7MatkeaibU+aZcH8iLOkT
7xzNQTDQoo85V8J0rUAaDqWo3elWqNMaX1U8eWxrMJx//fMZuKKIrcGmCE665pjhyigFTPvnCJjx
tEDV78maJHNOiXHIm/9XqT/4rmc4Kczl9VTMtneBeC9YgjlfD9Ga8/IkkiXslQtAamu3fYjxM+c0
6cSPhCMu1ALg095E+xktPJq6G0Fz3qY4nfFrndFYeHYlbSNFRCCMkeRRQr9aOnW0bKDGzbzkdpXb
U6f2P8BKZD2rkAWs7YW2OOOsCCK78YPMeq/yYWymWl10WDPS40c0WUmvI6V7ZZRZkbNV5eSX6U4x
2JZGpO9c7jXFYHTPM4o/ycbHcBNiMB8XaoyRsjnqiOjM68n3Hq06+g/UjTDJOTEfSX4U7cUdkJq8
0SOellg56mdUQ/M7x5rc/pr0JaikBkWzqNFIyNaMrAF4Ly6vZ5u29tlsHQvz1biBaZ3BNlsVKAaV
+JtouOL4ehrhmr94lvflcWWOGltHLMy+19mwYZUeRzlgbQJn7dhDCcu6Mx3qwb3s9EZpo3Gmqvjs
V/9R3mCQwifHoymjcL9ClQPsIZHSCotQq1tSM7hncdjNHBsGogheoEQo8ZuQCeO7t06l8FO3/v9x
Eb0ldSjMsX47zOdSAdLyXqws/Eq9jVfzzyyC3qtCINyu4iHVv57hpUYmv6lSXASXbRp1Q+UyRsgm
lAtVjEQ7qHppzjp4Cgg/sV+vi938Occ11vHQhMPMh1n3ONvKz0mbq8uacpeLM1LJ4nh/GgqSb5n5
RjM+fsLpZZuxAN8/claGvSZY2BZDqKC7JjOx0k+PXs/Xs0c1A0d8Odq012gvxXug7MpZYJ53s4ek
eeDRhROVrYzNr0ge+Zf0usP/1NeUTxqpDMgi5cyT5g2kYzrp8ivi+5y4t5Bd2FfDIQ0Bs7iugLq9
gecTo9+PTvMZpvpDwMpcXvmZYXtRFuonRqsRsA8RHZaFcIdQquBhA6msoPHGqcgLURMwlpIjXH7T
ookzPBgK0OPWbMVgIgNmlWeZcyPRaCeGPp6TlQBAOuKI5A5iHte412FC6UDR2wWF4Zv7kyjF0Fpx
8HBpi774cv84JYVWjBJg7amhXqqfzg6I3AAn07ibS2UghB2GzENkB3QvTn5QEqItjcONpXbXytbR
/+Ubb1bztdA2VGED/3uUYMUJXJcbQVKsE2vLYKjOLKqo3IhUcNhrKvAYmOFEddqnDSJyDEmhaF/U
MJ68wBtcCQX1dpA6j5+Y27WBwO0662G++lMmsE2vNERu2SmKE2xK0HA9EwntaRO91OaXEl0PYGy1
2A7abXzwuiRSNPTXkQyeARM5Q/EgJK3M4dipyNSS/gsWIDw99xMaemiuIqsH9h3pU1X8ZlbyTqvw
XBMhU5ZTHLwqGQvHuZZbogipenWTImmVfdQXzBpJWrCrhlURb59FBo+nCJcXqQHmRmg31Rjc1jCN
rZO/Mn2FFca0Ss8BYMDQ4dgIbVJp4BeHORZTd+HeIORWRO+OA3/LFtse0wnqXZYpdUGBPu8rOCHW
B07kkIFbS74FpBCoaOWujds7Mx4lkj9D48FKx4RD/7HFfKuWyAdC81RmRY2wuXDb/5yaJyXXHtSh
hMFD5UA7T/IlEqNwhadbvuFR83BAAVpdgU4EPRBxUqHMUr0AMh1JcIKIkO9QNCiOqzKpvBwP5UiR
VlNg/sQoAecw6mDM1DDMAJhxPA+bjrALUjHPUZHjTVIdx5So/vTYj9am4vygRdyQeLac37gJaqZX
PD+ZXeawpS/t788Z32Aa4NJXXUcZZy+Ouqx8x8P9TpVd5VRaub8VGe2pnGHZdgjL2ZhuK8fpsQQ5
KiEXGo+W6VHwJvLXaysPeSBgOf/ypA2aojJ7UsI9SNUBmA7kgokUKSt7hSB1ieLrrQ40J/QX7seB
agfeHTLFBNxtJh5EXSQhqOgjyBE4msqfNZytasN5+m5WufeGTkuKxN9KbLm8Wd+teqL1D80GtsH7
EwnvJl9VToLiqZx0kjUbW4N/MLCJh0POJkrq/eS2v9mXVK6EEp9pfPhKKMIwJ40/lcdng3eSQuGp
dICMivxc86bfN8cNsGfigdJUEoPSk/F3B9O6D+zTigTH7FJjP/PmxkbfhFhOAn8ICeeopD/TAnNF
x/U/rT09mASBrLJcWPUdP0TbxbNB7jTLDZNvu7slGIgLmfmxeifwssoRqThEzdUmvYSdFThriGrO
OykKAQ8V3yusmDMWPrBH+hojBlOtwjU+BThyYc7Fw0mIHEdijIP20IZHZOpAulgUKzn1KEaJCIpO
V1qIDzMZvvauDnaeOwE4Sy86wO4aNs1WHKKcZlWCBYFsLVEfuZSnd7R6fGK9FHyE70t49ljzWnIC
yc3NuMhRES5XtcxTn1/F45JvIba9dUDBXIis7JPnpS3NrNEMLlNSfSyQI5zBO+C2OxKeO0hqJOHm
kp6yrnKFjKdk0Vk2P6wzKH0+pMusmHmR5G7seTXjN7ThuVJYN+dnrG1d6doDlRveI2keHxxgNbrr
sHkj4GMsj+r7uyesNlz67EZcLzG8OdlS0r7JM87pwRRyssvtiUe/jYNYqlIBTq9PXwqqbUj3Ejxl
0hNQEu3ndeZrB0j5fwfZ3r3m08SVPhuhj6asCUhRuMUfVocMdVFdr4RThCl44oaMOp6FjnXNeTqZ
SNlFhCEUumlCf6zjZPbGKW3UZA+0HdbQ92BPO1XyegLEbUf1QJLEKjr4CHJ//LT6ANQmcseliAme
MfSUNfhvK1Zf1KcYUthprL+3Sl14JujxRDg8pJfr27QGc0V1x7DdgnBH/8iVCY2UQxG6WF4WfCQk
6mf7n9aPlZwpMHU0/JDz8zkrOzPNwdrHUQTg91BkoMdFnqujJcGCZEv4djAzZOImUWlz0SO14fCA
/rK8n0Pghj1a8eGN9HJ83GEuDZ0+UJlEPMqiFWq0N1/jsHulh76qZx+hshw3Z/LGxMKVZpYQioxU
EhPT1IKtIpMqb58XsnZNBIuMmUU8zcUwLGyU1A8vq4ausQxRsg9dOwjeOu5gNFJ4/zwiQuXoDhGX
ZsGFp0icALroDQq1iL5BYJuRXBOTMfDv/YgWap0itshcN0qCQs0QapxGCk/bX3gmOGMAmJIPjDw5
7nCKGLWvLS+Cyh4sgg+ymqst8rCaEXkdMf2Mt3aGlYYbKbOVQ2kTTQgc+6UGzZLfwjTgRWlkA9rz
EPIFDbjqHBKIOuoTvDX52Mpvl69L/9Jw4PHzc2xcN7HJVI4Wa2W4ZePqJh2K2DukDEStTn59JYIf
ftPDf1lHibWxry7Vpdls3L46nEoonWD2olDl0E6yFXhSGOhMf7MJvl1L6JRcotFzimALK7pTPnbf
tc7yVXvROCtG3vc+ToUcj+73jDwVw1SXOrjVNwqRS4ci+v9NNVynyC3Wkz2Y9F0IWe/+LANVOxAB
/npoDrRmaYQoAdcX7oYejp3xOV+giEgHPHaWzYrdjnzJK1MHPQCtMXqgp+QP/GSUxf+5PNYtRFlh
+zSCEi7BGPBICducC9SWv5tKHE8mlcez33sB7+ScFQbb+THO0dsQniBmrk8z1iAI2Y0laUMQQeta
dPhUKGclgAngJMNaLevf5OxbBNa7465R7+oXW2HsFb7dpbTIf0GXjhmgl8G93oU20qw2lMcTQBn9
1n2epL7PVUW0kl8SVWgUXH0Kqxwf2nPtmIA3YoVMslaN6W8G1uDvCwgbC164dhDOKXpP+5qmptM7
G9QHzqZzHhWu+Nbz1rzFarNTuBIFBomm82xSvOtN8BwZMr+QGZ+1KuL8HDmUyMVVRYVqPsuqAo+C
ZhQ1tTcOqpARUkjt7AReTzeC7lxrLx4BQKUWGclQt+5jp2/yQ4G9L6jNDxuFXh4YRbbEv1/v51+I
XoPbiJx0bF1FM9EvIHurA9sXHoQ7FmInCN3pQ1gKPzGTpRMen9fXGIn8maC4vU3S7Ae02KkbuHm6
7CpHoyjeUOiAD8fqeNqrlhUzXgAJ6pK60xjUES2wAOXWf5Pa9ohx5qBKTbl4zQ9Qw1xnHeFcI/9Z
UjDjolBVDkJc8tPpdIgzyime39Wdjs1Yb2ifka/5/PZVNWLSTYNTyG7/aruYeXMS06Pm0rxzYlpO
oPDn7s8/RfO3ooMzsT4xeMnVG5BlmPNRf6Cq9gpJ/KfukHzH3mcPbS8xgRdMZlXXaE8gh8wVU+7h
X41MUAT+QnfpNMfKGdDT+9hkEEO/DARU674H4wdX/VpaT7ZODflSK5Y8TNvfTT1BuLt91kiRN+2J
ufVoS4g3Zw0akOJCtdQ2Ciy7RtZKs9Zcee/L+3StXPfXYmmQwonA4pzDm55+dOPucVofKN+G2s6V
WaYRBOgNScRjt93RCC/u9FrStyzp3k8HEwVyK7j9a1Oo8P9dA+Vz0VHSbNpUE9gmLCJk6LEU+XoK
OGGNyHT1dfRjV3z2SVytn+Zj82HWtq3xKP5zIDZ9hYs01LiR4q01jfQrLAdFixQP6qq6C8x8IGTs
ZdrTuzMdhFnW3E9LXLkFQsrliI95QMwAgx9A6Yt88A1GuTHx2Cs3G5vZYcYWX8VvrIYZAcwgKRmf
jF6nxp6u9uA1itNUyCD1q9GAzPBPcBRJICSjbwUOob2l9s16limJeBUQQCiOrFgsnd7VpEsTVhxJ
6+h2anJXx/UkhlBdXHOo4x+/qjnu/L3MXRmw8dv92nVUpjmbbBvg+FQ5Jlml8rAysKW4kfjXENSg
T3gSdgDMPGt+1+SloonI6EVuSxSUVGzCne8g2S8xEaitEgEMRPW2N744/ySa/OGqG6J0lvVnURfS
6hy2wG/QCDj5+WsKqYiMp9XZ8Sdd4AHOhlKLkotAtbnmqFcHJLAvJVBDoeFTOxz2a3tzZbHEwVLH
DfS8fMOF5MmEkbO7Mux5oaRifBIgOTB9PZBkHFEYawE58A6vJgPOjxW+8jpG3r4V/l8hoYA3jxLi
TKsYdlA+r2lxziUpaeuk0gvavl3+RtKLAinPD6EVFZDdQ68lp3Xi7XFp9APXBdaNGtTEYwxQI2x0
bxWiR4d/PJ+UhqETKK3logVTwENk0uxtfMbjTjNW0siprz+xTzJJIDHN/ovTRb6iHmB2pDpgkztW
FMYpvFGYc4tAGA2HLdZ/PHLc6PK8SGt+yRilEosbvWjbOzuq0OVhn/9S+J75Ezy7vaYTi/RoppHp
1UgU++sE+/LI+3tr53kkN+OT0I+CjoK1yYKVS6zwEzqWOYBVQD6eOLKgx9jdiAL6fSkzvnuSb5tQ
eIYHEgQMRfQ1gGLuB4W4o98du8uN96NpJUNssilyCPKlgUpUj7UHZe9yDCoauRobEgIcKQ9nn06B
wVB4bFeva6T7VQELBbaNs7S70+siPsBcDnSbc2MNSc2HQgNn1K6zw98njqQA39rmlXAlbPEmeEJg
niW0w+nx7sN1m4EuUxPbTXWSlJK0WKXMbhHEz+0hxTgtkaFLytMwC0C5LN8eup+SJxz4sanoOiPU
Z4qIZT4qh/OXgPo0S63wHEBurQrEFkTojlG+/cJ4K/m3l0decnvXqe6LW3XH91KnDhaEsKChVgvI
a+PmmDwLfM7Yr6dEbbr1WNnXA6MseysYZNf5aqWBoZvUvzp6w5JfvZwgSBALrYUCEUKBzqjZ8eCn
TACBuAJpnep8QxJFTEAld6R4KNfIhDrCuDfQOr1FodDX+RKP5V2gmMVYKg4cRGvAEV64f8KquILX
qcNcNF98sWf+Z3g5i+QLe/kcTujWYGyJDM0AgDZSHnzVLAkKMNEe2NYCePVRWGJZho1tx1fi/iM1
mgmAoXmF5exC+qYq5dqexHuQO1Xn3bhrqJvN5hhpwPWdG9LZH5o7hckJrCn/SzJMTkrIkUZclvfF
dw93yJJ1r4tUA9h9M1t6GJfunyClErdsk7prRCMacLdyJBzM1HsY2covpMc2DqtAqMoEWfVGIfnR
v9euLPxuMEXSTnNRXhO30Iyhq6W64iZGDYzvMpI1U0JyiYAMw/IW3fSzo3x6TdIIHe3NceKoUhrk
IGDpKQRfMNIJpH+4SBS/nJRgMYTKZILii1PSaCj+gRekLTRq1i0QHWxMpFnGZnS1S4d+T+PjHdpl
rUvnmFwvDonaHqZD6bqQHculCABKlf3KGdFxfvJWtoXFr3rxZUL0gbb6UvcJOUiPtNuS6Mw7X4vp
fI2j2ASLVAvb5X7cq8AEhqCKThhwgRXnkuSi