<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnsxwlQcE+/vlsT/rOux9Jc/0uvvTEECFVe8B5x4W7gGY9RVQI7amZUc4PjzjpGzVoZX9Ak1
ae7pAJ/pMGedv8tRWkQQTZy65W2EuQ1eGpuj20/xxpjqAWJs8lA2/BU3aZkLMx4/C+Krt3Ge7XP+
RHFoJsvi5F6emmFhdpUa0gnPCU1UsfanGwkTVuBKlOz5MXwUSoLkL/nXOws4cvPxWr1pa7NNOL+N
ix3F3F9Z6ZgKVgdHpvDzFtEZMqrDuRKSPhNXB9SduPHCdVQyEGY+b4ss9uU+AMZ/cLCKghkGjNZI
ZdFCw10h1ZAHeqVvvjAxUkXVTTHkVNtDuHIYtJLMATgRiI3pOmaT/5R/NFbwZaVXG93ERzFciLku
WkyL77dQAgLUgCoxn00mBXGGyPj9t23C1t22sFQzT9qGFTFeCfWw3oGft0krVqZdV3xUOASv9MH7
2WzekQQlnTC/R1i+xQsOjNZaSh0oLMtRZ+eA+pNpe5M4q2gIOMMg6XEVpmUOpECaVy5+UmG27X5x
r1onL9viXto1XGd2lVyosweVgRHHLgPjOHdFVHBZ0sDfV7OuyaVX50JZ114NLFFiQdqmJzdIOUZB
7NsnQ4Jbmn+fN/dd5aPfUKFrYindqnmTn40nWMn/xYXuy9QUE26u4AtejJ8EBmZNiSOXX3vqlPuL
wY4JEi8QjE2B783JzJsOOoeanUoitTPkfWTcW0J0U2j0t1J6xRgZe1l0ZomKEhICDndlhIepYZGO
5rUCx54E8u2o6EKEweaJVfW9N26rZl7LcDWFe9SPmGK6Y0rFJFKk3LH7UcFqd4dMJ8sGmM7ptHGh
1BBZ8Dgvt5ve1C1VjboXYJ8uIODwQEWeU9Y/4jwZXJqolR/CynQ6+ojfrgSOU0ghIdNNM3Sq8P03
USZr/wD7EwbFA93swW1L804iHxdONZMrynLN8TlwbXkL2dAP2pyFzn0YC09rW0K3OvqJOv3itup6
urIW9p4CKRGUWtklxW6Ty2yT/xpyKzCkIxUxRsQ+H/fPgQP8KXSSy2yiC86v9BUWZXQsKWbClLFh
uxuM6JucUdz2jqkvMhq6Tn7Pw0QHwgQ5y8I42qMeN13BgNJrGo5My5kNlupyiWa6d9/Y1s/KkuEL
/MtRJAaZeSLMwNlMyyRu3aoqnlTZRXZHV6H3nAOYwkVGkuk2/s0a0eEFW1oL//0nHEkH4xOjzQDN
lrhzh+4p9JfgJRVHCyp9xeQOU+9UYr4eNW81QVpDBu5Ihmzy8/PbfITTdJJXNW8Nveukcv0gpeQH
oycctgLVTUl9dpCG4p7H0aJJW01xEzcok0LeaWHGNXMe45YTByWOTSLpWdupxpHmd6HlZZt2VXUM
qM/l76+pihjElkVuDp8Ny05ujwcRhhJqD/M9xHCAf18tufpN/Rz4QaIYjFqkdzJ0NPsSZWU9UYC1
aUQN2/sjG7AJLqwdHKtYQW746f690TNc2tIsQFDwS2qoGuhEhX0XBC/RuloT5vIB6GGEKIx2cPn1
YUJmGT6ygYbYbO8PJzbEQjmHE7GgMmcIN0jd0r9e9Sm7kNf+pLm+GYvC7OzIf2Sv0yiZ12aMOh9g
TPQs6LE+YFQXXJY4dv4FMdDdU/vrIaEPgAumJwYc77Y0kci9/4KQNweOpyPlti2tPYZ2+Oh1exRk
BcP4eO/ABTyLm6hWXtE8OdgvDoGvfEZyHnGX8arZVQXYQUJIBjdAyQ3i5GvpyuSMDc6/k+tBB6h2
JwbKV/qZFoX8OEwEBZXWy14JHqwNKU0GY7HJZlWNsQzlNgZ/ljGRkht6nenD4sQ4tdocE0Cpnz24
k3+kQGsBOAqw6BItKC/pdesbZp2v7SUg9ksisitwGOLirdiG9lEHPbaqVciM/MKBxc5GsgE2OMh8
55Ysy9cjDUnFmMy0jSVGHWM0a7OEJp+1DUVhT9NLsmzm4eJ2rO+6WcWxqbBkJhoI5YlPm8Dv5mq+
/LtddcwP/1XrSjJVmf9jfoZa2557NzzDpeAv+jvaPrV44opSwpuHMv8nptkEP54HAMCP5Ya/nzwJ
BLpzOnbM/ODAsfCcJ1sey7+pc2qCXqdjgT375JWz9IL9SyDSGLown+A6Q0I39FbON0h6qRf8ySx9
YJV6GZ0KPw0HY5JQQ1x8awkMYJLer/bjMPF/ZRxCPfwy/+xKjbNnkxSf62ka6M55ptKJdYLbXjGe
4n0J+4WNGQgTd5l0Xe0dN338q0zwyMCkQBkVnYXkOJN42ZqK2Y+dIavWv+2OytMR4+3ETBWeOMht
+wwXR/a+o4LOoC6WQ4jdPl99H8XsajlJQuzsIVprFT+AS2tKkgqx6CkaQfwZcTxLqVZD51WCrJ+a
gSpjClq=