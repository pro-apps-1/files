<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrT7LAHg7gsBSuJ1X//58dX8DCaFMzVF+uAuuF78D9hg4QsTP/5b2k23HZHEc0hhYRnmF/JW
1QBmO9W6iM12CZJ4r6B0R2i9R+FJngihRLlSgX1fvy5UYzT5Eq40XYSboSSzYBVnLmeDPWutSLYq
pds2C6f+Mh6o5d4+JxUULrQqgioxXX1mpNtH/LBQtem6OeCcO5TBnV7WZNHcOh2kgtZvcynP0GoQ
Ddk19JQYku3VCE9nCFEmWlagaSkyUYbrus+xjJZsJFEcll/GK0o4YwaYPLHh3yIx3CeP1UBK8wvb
B3bA/xbO1VHMSZP9ezyBwtlMmp5s1ma/k/Bfp+VRQibmzUyDJZSm3xleRFSdfgEeLnLQoBfy+DCV
Yuj9wPYqhmzBvHCEGjorhT96GQIdFzN7MdWiNelRTWY/UpaHxDmmT/91qU7Qai4n/KlQHTbDFNJ2
NYQn/rxyA8VI1hkel3WTPNxbcLbfJZeRCTZEtQpfiDsbmLstEES0Jz2FPQ15FL9hHmpnmVmNIn7f
35Btc7IrDbA/NReFNT8RfRK++N51Vr0uge0+5PyFqx3XhNg5HyRsgGcivhYx0GE1CXHw9Vx4U4eG
kFeqropASnifnLp+/BZDtmpvxXox2IIwK2HzHAw/B1LDtH/JEdElc4Hdx5SF2vjwnDgzgz9cLX9N
X5cVYyTzISN5AZMMeLCDNEQD70K7c7ShCSxg/CbQQ1UtI6K1JMSwSIEN07kId4k4L0rut4kL6a4V
qYGBKYAXasuNH2gQHda+8SoRZXkeK5n7PwbPkp96tO6gPXHJ/uICFu5Xw4h+XsgcLlnsKTNlkuR1
77pVcRGiBFNONbIWHLzYZSoj+zRSzYw6EDZF2On3x8IheDLAHjLCd/pWLQ14PFs2L1F/IoxRk2uZ
ZxBlsMZ1Ol8mLdQRSMBDYA1kOloowipDm57v78oKxh+VABehVp2/Qd1kKNSgc2MrjmYRA8Prcl8O
VDyrJkuSDPcr+LDEE61xCxl6HIZPzv/eUCN+D27e42cfUaXeu5WztfTt0/EKi409Oh/4w09BhpXN
ki0RoB7bVAYXIsxHMTF775b/jUXAbDoD4clTbW+SZAHgjEvaVIGC4N/iJmGo0xPNm/FAL02OlJLk
XQRXo6A5sR+aX+7NYG+7HIw2AjReFp+oTFCdT/kxGKNAP/kNS12/PyQOhstbz/juu8ax2TcvNwag
LsaQXE4PWAOqzPg2wV979PJ5E/5AALh1bTFOd1otuNVWVs/dg6hzCKFAJEpS31TDTVPKszgLoLil
L/sfmxALUaJcTK4Rp5ZdJj2e4hSkrid0KWA+QegsegBBmsrfpMXA5VapJMNj7X1ZFnhAKJrazo1A
QAsdcKvVkDGrSwDC6Z71gaDu5EK0X6Wxp0gYV6O+39fOFHT/MEpv0pRFM1NCNKkCi9kfsjSTkOC1
3R/L/EjH/zvmMOPwu5TWFrc5BEGV08gRx29qHL532x3Oi3AUdxzMB6LEG0VI7fntrLlKlwd+p1eh
IvYO1y7jV7WC1Xj7o2eiVwqq9+p7lvrOFkfzM7oriEFNTjyhosTJr2xxpZXwSBNo+sHwNIcjNeJj
PcrIImNGs3r3Ipa+lNjbtdC4N20Gfh1UCkP+zsGK2rkBgt3iAy64LIgepcq3sTqsuhFzcMxot43u
eGN7vEKcdQZxYb5MPpWk81cvUhUtcaoIhWo3R1m73rznfnqTsFUlGXpSegU0mr9e8tJvSvGFgo5t
7XmTTKxY0kdHjvHM0x6HX1sJdoLclzle64eKKzb4XxIuswGGBYqPcGyDzF23haspNE44IW+8uVQt
D9Vwy5z3AIc7B4lwuq9zypghxGyRLScSpjds9KOaYgX9ZPMkEj2vxFbR3JZTI/V6aavgK8ZJaioC
St1iGpSulcAWbiRbXdy15YyIKdabFh+9VWqjqp9Z7TRHzEY9yxRl+8ixaGnxxz2q6nQ2xdqI8Y5S
sQ6TJr4UZZia6lJ9/7AcOD2gFivwxTZHmUw6gbG5wAkP0UBE6PgZPWvRy2fHdj7U6aLXsCf2JcC6
b/z+2rwJnWznK5Fd2hQiM9iZYR3GrOhvtHcuCkHB6zVrNwQOls7XtdtJcmRrqWAYrCqOCR+3FlBV
StWtQV0Vk2E5UbCx72eeCVCHo2E/7MQj0+Kw4yivzMVZ9aSWw5pQR42dCiC+PG==