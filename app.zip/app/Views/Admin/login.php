<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+7P4TZzTEeV+1g4+rw8pVzxzFIAmc1pxDqWCg+v/fUi8u4WeIP65q15bF77igJN/xHL/MeJ
8g4WqbcZbwVRrcjnLJaAvYqeutr0LeLKMF3AmYzhGr2OH5dBCSix2wBGvnN+x9mmWtORSLGHUuXv
cZQQl+Lynomn6SBX8Iqe6jQm1A+l+9K7vCFXtVivi4iSUEPiumSVogbLYVyWmyftsvrzUhb436KI
Je74Yz+lEsy8dzswvd+eXIplrCEufrQrE7eQJ48UlJdPArgD9XhjxmGtTdrBRRRLtsixR8WqFaSF
e5MvDMON1rt5FOGHefkTNS0pzdgn/e8MP6Z+tNABoBHk88JpoaMg44NE+MoW1TMHyk3aT8bxwHpO
KFZCMJRIAm0OzQ26OwiJJsFiOOQ7vid0Lga16izqc5Hfcp9HK8kppC0VugiDCjATxegLtJOlcdvf
RwT7p+3FoeUMnLuMewheCEIDvv1prbWqc4EGguEwRQSH0wMaIL4WHiXndd6MBdeYzg6iXwiZGd6T
vvJsioMMjk+0cxZCXFPcGZEU4OP28+CwGveg1aM1AONtNbq1zYqTu7mn3Yp/PC1RZu2Vesbw4x6s
F+8TcRtJqLOcLFk0jBHpMoAGURlxp4syLc+fjteKRcYDwhIJOz1dnAKUljU/ay3ev1KXdiHz5w+n
YT3DqduYbUkCwyGjhzbNS44GeFOHt47UFn4OBQcLx4fzax8fiEuxOW0dkbM/CYSdDKEW17wcGvG2
t0UQZZR08wHEFYkaWa8NHWdsjVOKpmCcLPrrpQYWlvFo7fhUfdK/Mfvj423q/y6FCzmMizzrAAP/
Xrj17pTFBoriRZsyuRlEi6AXLJYaprwxs1s5w9/LoIneGMxDxlARuAWZd0PXKcWdj7e4MJCRxMdW
XEx6vnAUeJCz5y8g068NLU1kC2Z+RzdMFKHaJMFnO39ip6MaVdnvRT/fVvaTbq4h52O6qzsv/3uq
WWFjS6FJL39fNeNCMfFh7m95z6Fxi4qFdQwFJR9BycC6/xxZhdgn9Vy6WXkjLioyLPWiMgtmYmml
8A/ZpVz+GuszV2jjGLNY3R2G24VMcZXs6qsvL63eHDJ0HMgNXniYiboWureBpqHAeTPHhGcVXI9m
Hdf+Go7sQ/VhwhynO58GPUzAhc7x2gAu15XY1fGS5yz/LGLRCc5oGDCVA7ofizkgR6sBS2Ur+PLJ
T6b45Y63aLRJZi3OGQ3IAoauoKIQ+Aizfw84CUOrGeV/FHEjW2izBvBLbAtzItBclZTpZDJBMXmZ
tLeziKa2mkvE7B0oPIOdshjkvMxpBSTTm21DPxCazifLLH2VNNdRcKbAupU3m1G3JFX3ISodU/Om
x9bXybmO36Gbg3QRlW58oybB7p+OhbJ3c9g+Ylr0tKkvFtaGO4H52A+8ZIgdbD9HEZ3P6hrW5+ae
nNGZSL7Ocpytk3EWgFeVYQ9Itp8PAFjVddTI6lmnW/VsaJBjv2yxvHiUi+70xNAnXQclXqMfzpvE
/0jnbPtd/wxbbnJlhGEU2aNgVSaoGye70yq6TNelHNNmZ4DLN/NeLH9M24ss15CQmHBcq4UWKMM5
iXUj+aaX7mIWN6TBFLxq1/9Ip2xLfzsMuQnNWfk9E64o/0+OG41+Xp3nERgtWQu9lDM8CbWREx72
zLi5QCq9zAGeyZjZKe71vR4q2J/Gi6Z/LLWb/wF/0curlH82pnTA8viY6c2Pwv5tOjqqOHMP9Vp/
G9OJIa1A+Bgm8++juVXfcQ1ienE4SahMOeA+zqoBOFlVeVGamaia+XbPMBFAnSCsAlBg9bFPmC1H
03KcSW59up4kJ07mtthERN+FhR/lpmi2snjZHf+Jk2p/Eci9gjsb+mz3PL1d98ZcXtjCmeec36/d
MP4HJaq4jXJ3Q7683IxfpJSmu6TbIxOVK1TLyXNAb2YyOyIb0fc+4Qug8S89o1LKTb4cSL2XWwWb
Y9VWRl8lDlAS5uC/UlaNmRsUtwCmDdXcQaUaPkapj/ka6bJ5rX23LO8+3YviXUTSAiNSCnZzVaal
BBWDPDLgex4ArmhgORb8LN1YeGCkys8s4wIvlOV2f0xmDQzVh8gCLirfs5VJtFYad9PjEW==