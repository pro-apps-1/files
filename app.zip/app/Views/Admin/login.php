<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoDZTMFEqqrLbx/WG2CNfUqI2EkkIXwCGUauaNViLc40iThWS9Ms5UUWWXXQMzKb3amXqqxG
5HMpe9buUtwaKNYQeECxa/2CzjO1ZEfK+wIKyC2tVyAZ7rlNgT/vV963ENkyfxHE8nqJHyvW9dky
jg3rFsKYNSalFKVP1kKDvHf92dHRWvYTywvMnOle3HU0ouIJzG6ltU7iSMndgGeSfZX64Z4RUDcq
W0AYlzeKoTgxkd1O2jrX6OXL9lkMjvZKOS0j6QHmtXrmAIhk8KcRH1+1U5eCQ6/2AkqnuiQ8/Wpn
BbN7QlynTSLaVXVct4pfmcWVTOx6Enj+d4cw+FPzIya3N+D/qTSRuR2izPNmqsZJhevB0VWKerhb
cHvLwsDJNroZaMZDO67dJMDfOyhtJL3CYnBfaqojQb3xJBOsJT5RnRsomub35ymKgnzPIYEYgndw
Km2TGBdZH+G/XajVLWLvLLvy2qhaddLREh2r3+aiG6OEvYEfml8sZsj5yDGE67ucVlofmGrqaoY8
vBLMn0I5jiFOKlBp1M+GGOw5kvGX2ZLuIAowSEdLzG1iJu7I3n8YmWuPLBMe06QrD51BVoRedxaN
UK7h7NMk5POv9ERAcQvDKtNepqeGTyGEA8bo+hQrIbbF/ndXoNkdZl2h4jM77YBb1VA2x9FOY4tn
by7LxJ8eYCch+FPqT0hy8SUiqGEj3kBlFeAChQlK5oZROZ8b/O0kD+g5HiuYAZNJV30ZUhbJeH64
tk8gFjU+qbxrRpbkVt7WVCXEAwK+Mpc09UwQiF2rgeXIkSpUW1z8LtsKsRnKbnklqffLcG5hfeMD
HRvziZ8hwmppqoB8FS62mbmwxVAaaDtifwuMrCxtjfl5iTas6Pq+nfRpKn74tzwsZLrXIFGQlVzQ
gq1wvKVBFHJWYKfssujtympxVD1/X29Wp/OdQ2zMc9NdF+c/wtjaW1mJNuF2vcGLKgPcquNfYg+L
4oE04GJRNDB3gN+GXGto/uyHHTbEewP5X/i36NC2UlTvUO02oPKVvHdPM2JXi/V/hBKqtp+2CVi7
Fovu0hvNqQeeoxq0cXIBOehB57J1k6m0RXR2dTbPAw4R9nyISjQ+T+uYdGOB272RKFuUseTLQKfL
UHcMbUmloLdeJLVi7haJ9zIgqpgTWQGlMKZZPAwanY867Q6I5+JpQYnqUBCNLYEwIKWTCKmMreVb
LaLtMHc2G8vfsEl+wF/ZkIwhurRHBv/Mgl2B3MgVztm7VgQFtG1lz9firT709tZOTTvX+qTfX4Ss
8rN1wYJ0zSnVLNoKBi145eUt+hkUAiZOKiW8boapCZ6r4o8c5iFkmkUh9mnqEsxAOKaBSfFNDYOc
Jx0rAIco5n88YH1Mqu2yywc7cjk++9cCnmKiQ82mldwKgDbVVmpqgXd8bz0XtKDRQiKErsz1Z6PS
ALEKKIIN9VFWjdrhd0JDo0mkrQJrm52qnLovjTfP5vRN7h/m04a91U/YV8GOBqIAzz10s4LUvP12
sPAN/slcIgYQa6n3GqE2bGSt7H30DCnsv+RstvNLT2SBbKDpxsCJm8WN2lSGOy/r76mal1u0IuxO
IdqwWMsMKo41iO5AFZcDRjnpL0n4xAqM1ar8DY2/xghwsPDaluSmflZgOk4MPXFmG0l2GH+XSKmn
tJWcYN2fe7dYJFbM2/mT/o2kGUegFnZTtkXxLu/RFxPmUowi5sPXszeY9Ro3oiJ1Yes+7Lsh+1QL
9ndlUni1fbKMBOLjVjLLdRNAL/wFyH1aErj+mFsQv6toyKIofDXOCHJDorFuabrfB6u7NY/ltl2S
idYpFbziF/6pOPKEoIjjGT5BBVIRX85QIibrvN4EzZ+7ROYaPJAMfeSdaftXhDEfPLH5Imj2Vdtf
W7sTl84f4wLxh/3E/AE06dJN1VHgfY05v4tat6hArCMwVAAuAWpwsGy1pBbeOuoUTPux2MHQICU7
sqaYmFjcnYFsrKEq4ghWyphMzNzN9P0knfYxm3b67xtwsiRZJ1iRpO/QiY3UP7koTxDg7DjBLWCR
v0jnZYnH6Zt59qcZqMx261PHRME3vnl7v+IS3X8e2BoMSVYzmOfICvUVusVfBi/XBUasLK9x6Ds7
MjGgVKhBQ0f0kiBa1osouCwwO7OIOQu/l8zezYMAyOLya9peVO5OzYjfCMmPyH5DA4NYYcNPj8br
/ZlZfS8p/0AYkreDQOTc9bbVTeCTZt4knxlTfmZijMOM/T442G5Mfk3u+qJMJofM4EmHEUtzD7Ew
iR8H2GRbn7nuUDQ2jXfW/H/LcXjGLo8atibEq09+Atg1NmKw+vwrgQVuxtu=