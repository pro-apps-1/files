<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp3fNCwSPwNXMIh9xK9POUOOs+dLEP5TX9wuT+8Lkuo6vLN57rKzfGFH1cjvyKn1lJiIax61
Lr+1drcnOZtT4xyRVwaz26U+gbQFl7tHT02lytkA+AfU4YVnxYCamu2Ts/iP8nsa8W/wYCAgs7yc
76IPAZIvI/0X1IMtYtGK54b/iG1KLxT9MDOl/wYYMabQBFCar1xrjNlTdVWHLF91A8keDNvHFYD0
fVFXUMQeD79dAiyZLWTUYeQCDDa/SOcVeDFcTXGh5tW87FW/i0pF3kQEotPaRej/PakofFJ4xFnX
d5Wv+drJU2pxrAnEvKCj5XKHN/0mKbHPPt9Q6i5cjjR7B0CPDvLtf2dYptFdpWYtM+u0tnJSmq7d
wvmD72InKv9tgNHtQ47wLY8GQ8j1s7KFEAPZ5sYwOJ9USr9aLZ4uNO8czwUxtVbYcLDtMDYbB7Qy
ekK4cz9U+BWDmRvzBYyZKcX5x/DnxQxtAY87Id3Tbtlae5+R6uQ6omb7joW5qF0wwd1cbjHl8OBy
7M6wyWAEyNJ7q+rA9bqnn69gVYrphPY42l58ER3Op3i1uU5E0WrK/ZfyTFGJLDVR9l1iFi8oUYmu
k6CmnNZPUUhVPb9AQK4n9SYKAAd5c7gt82sPdoa4P2YKz1sm1Ok49GY9QVmb3N3Zr/QEx4oXTqEs
7+qxygUMS3DowDzYXi/OKJv5EMD7HaVJsY6rlGnTgkI/ciKM85OUzq+Q7n230cYqULWMwWATSZkX
S6qqXFHVrZt39FvuBKlr1kZjD4dGYL5aWfvvhySdlB8kUz/FfgDoGaLlPAPmbEfeQldYQaKeFYfE
UXKDyDv8V7/2MA7PoLz1NKke2kv2Y5O8CRww+VJ0WqeEPNorOQITZ7MT/cbEyTVvuTOYLstEbX7k
WVXuYY1jIvDJyeWBM6/NtehhByxl7ZXr/r+pJ4XFDFicYV2BSOQqkaIcW0Mh1dDs1wz1/jnCq6cL
zo+fe+yOqMCWDoPMppb3Obls9yL237YyRjna1fNJTXBsGWfUb7bDIQATigq8Y/kVCvUhUzXL+Ki0
MKrRuQwiZp7fvMiiDxZjrD4WwuH7wTbcLLl28FgkoI8szDaGosEfkjCbw0/xXYpk2KCzTYV+MgBU
ic5+gRo0PGjBadNVwneYBkXL/HBRgvz2T5So+p7q8WARd4cNa/h0GarGwj0GsMpsNsf7jxYZsN56
j/0PI1jASP9T7HaI5eiaxXIJsbHpdJSWWLcZo87EtLYRzGhmAbMk3aaCb4NHOVdnT9/tASFoXglW
cI/MZ7jk4MUIhjPx8Gl3OIoDZlxDflsDapIAriSYwPw3J1wjByxSuU4s/wa6xqoIqaYGTvlx7dwu
7hhCZfVKA1oLL7weNr9IUaAgp1RzviIfyxS3nEPIn3QM4NsDji6WQjopHslp9YMj9xmi9SMGemW4
UlojhvJG8DBh21WTSwb2yBI01pgF+Nn2K56Ft3sIuGSJCoCqGxQ70JytOnOXLUjbOPfeKGCQ5XXH
goPKFVVgrUoxc37Dx7GEVmDux3Pxk5zvIv5nWHzSaNYCvQVjhiIJQqgK81IaSiYmVgyDs2JOj1Ii
j4vt0o2LNaKZRZbh2BPqovTpaU3XURO0U1mHGDWSXMSD11eKk7JQA3Y5Te9gJ04hkMskb0beIB/Y
GgS1vAFd09rpi/CqrXh/q/yka5TZ6tZL7hizNxt9hr6vhb3NHSyugQDqwAwKB/NLUh+1dGPZcsgj
lV3Gi4PF8qqJInEQohegh8EoOekcE5Zim9LlKfOSCuD+ycOv4Oc7WiV3urg0lY9XWIhq7xreoJvS
IlJscbjsanCcAHL+dtyURruCH8PZjsEN3Uux5rdJUAhcwN42NyaQ8jBbWjUEUfeJu7MgscnbuOS9
87aAkPrm2SgAQ8D0PJWb33TAychNAhgofcmm4tcdvaRBHPud+Le0Gh8UV2SYaH8P22EMChwHR8wy
WBBEw/qSsno7+hyJqLp7obIz03RtVzxlZbYRYRU2fYEmDRfQHD93zQhf4YmvZavS65890UQoGZCL
vpkRpTibKAfACHCcKL49Rcv5htHn0vMEU/r4U0V5PQ8UZbd7