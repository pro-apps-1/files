<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrbtIOxevx6XzQlShI+PRzPhdSKgWMWtEecuHyfBvY0xlk/XFd0mgYtjsPUp+4a/NAVFz2SM
H4gAmXPpn+hAFOgqP42Bx5Dh1SpAP9melfVJOapbBgW+TnKQ4Xn1LsqarjD4DTnLWKmD9DeKRh6K
+aLqIN8rvhQhhYcQcPKGPdO6c3Mzz5VOeDiv3yEmG0OS2kD5vfrAg18j+ZVFsr6dbZtAw8bi6edx
QmKfuiFEGdnE/cjxzWoz7MUI3xx64OaZJchP1wkSve3f/SmM5W9QCEVAiejeQTiSl0VkQ7xMsKfF
hougUrxCD6kjmZbUTJ0Hny+PFcIa9PbVAvPb2ut6QLsbuull6J3rsosRl35EzHAQtcv0WIhZfjKa
AOcqpNhq4+X/hEPnHLLJSpVon6HGzF80SSf5JMEMPbA6rDynaPlzvdRE7frdSsfHqKqPsIzcDzBu
eB7vArtM4NySZS6kLeeD3uELtPcBh658wnz7z8oidCooGXRM7vlXDIjsjdTj/1s/echH1jGYbFw+
nur/8mHiXUA2/crDh0h5OFPFyLcuGu/upjg15BxRpvlg9qscnnbxqnSHHm7W4BsP0ln3y/zp1/AQ
sFOXGwXmIs+D5+oR1bCc4S6A41hTn7NtB6pXhPYcdrrG6ph/VLSufNVF6qtD2o59UxztMwVMsKL+
Vvp8PfxyZ7F7sIHku73n6fKcJCxOYyXI5F4OY/KOVgPRSHKwyGD35ltuqOM5ESOCWenSci61xWmj
xT44T56zbVvOyYyZWsHLgUWWSOvUYt8ba8HDuQGlxT1qouORr6TRN2ChD0PW8nsr5Ec2YMIfzbZQ
LOlLniwC3iatB0bNroK4PKpLqgVWUGll09uRdK/aw77J5plt9dmNgKkswZxf+bfavJdXgFnw9/g8
53LcQWV380Ygd0hTiBkT7yO5eZd2R/03jg3hRQfsiraufCjeIm6QBVn9ADZRjbFtXMZVnkAsJaD0
0631+7U9CrHyWsqZN9eco0Z+Zu3GYokXEC92NabLqS9zThOlXMDtpeokRAp94XIExooMjrZi/Uda
MLvh9TyoJnuosJG6hgoqz/qOkW+3E+/Hhq69TWieUa4KXRkJxIIg2LIycRy9jwtuvjSdWXCCRNjb
+Cp9Ke/JHL1M7th0Ms1WdhsqpxwfJ2nEpBwps17TLBuuk4uvE8NS/FUmngQ67F+VsIFeUr8QMuu2
D2j90+HSvH2ePKLDSj7r7hKxUCTaXK5HCotrN+FxK6Ge/3szsMCPENdOyPMgGs66KD/OmlVK7l6c
00vHeII88NMuL5ovw2B9+dYpUp+fXu5nekDBPFgPhjXmhCjkofOxwfK2uvEwMxEdku89jWyjRzC+
9NVFzNh651fYJQVyxgMynBm3Wg/Jh9PjBP3JbfppapYHcxDEyT3DwOP8WaHwCwVXNkcPmHRzpiqL
16s4EWmtGjmjPkIMaEvjXuNLn52xnFUv8a1CoAqDHAJh45X7sLYYuGirpa7O7P5sk6AsuFVS2mEs
lk7jgbYL8cT4m2AZyoeERdr2d928tUGhr6Uf+A9aXg8bn8mp/PSLcon0e+tiPAhm8tmjS65aeM1P
rrGVgXZCt0G3YFhMgfQt8QL260/UHQmtuMnY/9PixvjSD2KnWNJjqMyeD0BF3Pl75HGCCRCzOlX/
mfKBj6A3CaXjV7LYjZeXknf/5bOdVzQ+kFKdSJ/AP53Rb9iAX99OqRgf3BsXpM7ycYbN3Tc3vekp
7LwdIL3NR2kN5KwdvrF0o+QUUae3MndM0+eCg/C8z/rUP1dChg+lz5pgyUq7W5hVmDGjG9w0jgtq
KYN+rS07eidInho0KdlTfdVmWtIseQHNOvY4ugRAOl2LXKjJbZa7wAp2apeggtkssCtBOj4Nh3zS
3hVs4QSa6shyChR9ALwIaSqqDpKL8A3U8Zwdv54Ea1y4E75GhKd4fHsTXOOGa7M5hTJRVC02LOHQ
PYcHv+qpObIEeaGdhLqfsCCFltvxfAMoQyKi+hIGfW3ZuUYdOFYOncJB0rs00SzOoZJo0zxqpych
LMfyJSJHx4+f318i+m9yidLp9oK2h9BXHnQLdcfuZ6yKZiLKvBRHfvi6z/sZQk9A8OXgp5+xHgby
cRkp4kZ6hApgGSy9ZP2BHErglmeCmfpg/gHizMnmgRDC+9Y4/49/t+TLXFyTZqVM3CBIhQy546JS
RT3lXaXbgdmPeDEMPen9nKYpxjYlcRPLfYNO5q/shX5HAjhc+Lf1CvdkSSkO3cJ+beLaraRIwAKL
giVD+cjFkhKFu1jGIzi7QOyIuiTcHeFq9++B7uaQSkMmHqDV/EDjjZvT0tCDhrMX+H0I/0==