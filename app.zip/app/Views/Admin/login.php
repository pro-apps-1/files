<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzw7eIccNXeElqGq2cIi7ueEby377WCpxPku77UFG2aDomhd1ahlA4z9cd/iAWMzp0tLYIiN
Q+EK1/4WVltjwg+drk1mcXTa6XhxqCGVsXwVVyR/1rrgYq5nGampig2Wui0255OYtFKpcrRjCFDI
6tErSA2hba75MZCw1Ey3B/XtbJUgbguG26O9kX/1DhX+V74grOd6dbW5YrqicIWWGb5rpcBFrRX0
d7+up8KWK+JtCKOeztdIfueaUknJTn+d7U2QSg1YcngZVFhp9aQ/7plPf6bZzFKetrpLlnrucZHs
RA11I8IlCdCEkzwemB73UbYpG6JbcLO6/uzpIQ4xZ0uTGIJaKYrYwjx12vKtUbOACOwzAmmbk6A0
TQCsvhqR2Ovsp5cTHIrriGIFN87bG54PFZgNxSenTnqnTXpJBkIbKnUFNvmX/35L/GAB3/+cMCs/
1x7U1K+48MlTSgmH2X6aWHmuP1nw5zvZ2vzQOxFauY8fQf+URwF22mBTmU0GexA0AcfawHU0ukju
tybrOPGTIIaEpFedQHivLQLon7tSoNr20jO5HoCDhhRfr0fnoD4Zizipyun9jf2hAJ/+PmxeLGyG
CZwVaOs6qryImvTyzME6fi/+bDmPqqZBU0f4zkpXPmtflP/H/c7/6cwd1lpyXyS89Ncr+wWdomNR
xYr92D4dOVGtMwzP3D59jzlsnMvHswyR9ARSPqm42CaUrTbvykGDhraK682fo8pIezugCVd8qcjT
XxvhL7JKGVJEsU+zAKQ7e83EjqOa/uq08y5zMHCFQh3iMDsiV6s6OLbZgx95dEPU5NwykPz5KQQ9
8vA8dNRbbHsSybjs2Goa6UdC53KH3d01X6wwsiVvYcxBie2MZAw3TXDz4j9TTWKgjfpOS52F/yTN
sB5dIPIiVnwM7R+oTGOtDEBrD9fMv8OobHTLE+ZjdAH8n39bX8dazsA+PkCn/ohhHhPwecqRClcQ
y6S8/ThXznDORCyus2jjsAPZb0/SVGxjSwgwYx6bJMw9aR+094Lm+tOmqxwGMAaVLY0Lg/oG0kce
Z9dV9e00ZPYxUz/tySkzct8Jap5qReTO2UjbJFKwp9LGyjEmm1gUZGMAAzCP9VtBmiGn8ihOdIwf
nPTlL8PDoGlOnVrh8Lc8XIvIKfhCxwtDY1+vUsMc9xn5Wo2fhAlgLXGkufUCHQEYjkctvtbS888P
pMWaHSivHqZ0dOZTOx0sUNGLcOWWDekCPobi1V1Aza8o0A/3kx0GqQWj85xQyEACgculBK3J4prD
t9DNMVK9lFNudCrTUVnFGu6vyG11sq0Yk+IRLRuEV7MPOQxGFU5nAGfajOK2+WxwNl82Pl9zYQOW
N3wn16+oDLhB9bSLYWE6sYX4FMUzxYFOI+slW805i49Gfev3IabxLjNqvQdeueehRzDHr2lqIt3j
GwaPlN7iRoQ1O5z7aghpH3c6Zl7SZ3AVuOr+bvTHaPedeXgD5yjRpuZCr1lZ4e4tDMPJ/KlPfBFW
38uBvirNLZxiBwLUp/ZefDt+eeknbOP1gRzH1QuDbkGziu+whxoal0WAdUGavy+Tt6zG2nM47d8m
L9+576byEMbTZRaaEg5h4Imv5citA09N8CZk5R4bwcSV2UdeAnefH+nJLKIsBjd8ai1i68gUGQ2L
T1Q3fgsrf0q4Bej4FSJjZo9li2tEaS2twhS14+OCogbUc5XfKcUPeGLNMd8cPQ4OI3AYeWTXUQYL
s6fefYgcxvbcSIpdT2cRA0/7n2O8oGItZFZP0elbgk1q7Ick/r3l7RAM4mrdKT9y0JsWdh4UYiLf
EVwkf6KjErtxCBjczkbJCES2LmBZB36a1Egi74O4+pvAQBRpMN3IAPl9dxbhhzXhIUDhkD5CPPxZ
upl8N/J1wtP4l+7c0fbSlKy5rYcFXiGcVvkgBIM9Kr/LK8mNtjg7J7ft3CyE7JWVD90cTruCHBwD
is8mXaJ3cewIf+Nlpi1qoa6vEDd5jWYx9If9pOkI3zZ/uo+Xw6xWhLyKOk9YDynDVR/p8olqQge4
HL5cpckQpa2Ksxhy88plhHR/5kjcHjsEYgBrRNpq0qrqJaOgklFselQTqj0=