<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqklvTc48TuUKMnm+ZfcHD0iHo+auSBFKC0F13YRAs2S6MYB7dv7gL5keQZC2JS1I/eEo4s4
/uxP045zoeA/cj6CpLnT6wAa1oSE/xsML1f19KnpZJcISsTNeEL1sFBLFZM/831wXidg7A2DCazj
5C1DtPXIQdh24dB48sesmkLIsQXimNS0vUTeX+9bQF7fT2JlGfvxCnCS6GvRMGwHx3jiAbem7AzR
QyMCRVLzUwnpDmDAYJ3CSO4auzI57qjze0PCKu3yFzgvkwkOjFcu9tAV5dkNOntmn9nC8VqYqSKh
Ivh6EF/ugys1MaW6EwDRiwDEaADnkFUEbgCfvwdk/SqfLGjyQ6KxaEOxYCYiiFA17fZu9WXsVp4z
5+R9gN2m+lqC/dQUwdAx5rgoTahp/wLC9d5Y/NqaEew/HQLK+7p4UFsaNC11pZ/JzsisqPC9kwR6
F/ZYilqCJ9Yn74b8f/JvnT1XzJDNf4gKZUQSwNwYrOwvRP8EYSJB79i0b84RBGvR3ss3TPQhipf7
nCb84zLqBXjbuCWzqh9rrw4icSdlXyrHpjPY43y/v15GRSBj16faEczKGAozGQ7rkCU0PjiLz89V
32vX311K8Kqovan8MvGfTcFpapLqAbVKCRCiKz7ZQ7qj4uEjVJfnZBPhiNts9737vmWkynsD64Sk
KnUNt4f+GYkYFXvTXntXmdRWRffYm6FSkTTe98DQO5JKRBmNste1um9N34wiU8SYVQNupuDUCRB7
KvNZXXcaUTD6oYPrMZFTvCEXTre54e2TIGlCV2UaDym6lHYuTWnnvC1i8cIxCrGM/RdY7a2C/pAz
IFlDDVOxLvrEXEY7S6nlaeGTL858rg27lANHFsi9gN+ABknwbl2d3XoVsAA07UHQ4TxnP9dV06nv
t1zXl4ulGrCd85V8c+U9Yokgpwc14pcnI8dQkQz0JKwyrJwgsiVGZwz47jcTfYqMZQPRZPbDVhnu
N8l4gjFl7IVpj2jubJjvIs7b3qA14rZYBHBv+Mfq+dFL3StKENh2hQTbVbiBp6q76iUXI0yL+Dn7
yS8CYgFqTHa8KauSt692bBzfS60xBSCSuTO4oqdR0Sln1YesekzPoRknMM/i+GXjsGJMeeB41dPo
77o/DfNb8Ph5whYw1DJNlSIiJRZtWfjJR8NMp1ecV6PYpqM5/n5w1b3ZAiu0X33ycWnbzy8Cyu0f
waNPev5tJNAomXW0MOv+MgzL9Bp0Ue5CN68UX56v5r/yoPs2GzOma8FcNp2jamzOcC8k0BAEfbAS
n+7Zsk34ymEel2mIhWIcY2QkMJa/EdQSCdEqGnyXQ6DeYkcXkObRjccy7u/rBFJwH/MTxbmhlf6a
jD/N8Nur3etCjmF1e4QChaiCA8lD/bE5TLSLi13JDfYJ7dB5toHmCTqfIkoXSaCITM/X2hyFNQn3
phpuHslyEXlYNQNxwo2sYxvcTxdTOsKREmDGIIv3szbTVcUjQwZKocLojMPJ+BozQh0qn1JQvfBO
uhoR42/lhSzG2O+7DYKltVxoCpUWm/khkvws6I27hanh5C+ALWR0NBSSQZkFpuB9GwugUQfgy+C2
UD9GLxWuz+2DYFuhDLzWiJlogNBsg7FbbrUic/+v0W4CUUXlRszjITdtw6Lrq1BtinuJ9izM3V7q
Ve3ECfw4ZFCg2Yzorl+8YplvHpPKO2aSq9AC7Dq05RFlyIhPgfv6wmr7LB/y4GSekfvRvkpfiIiA
79+e5Rawem/qs8AJslJlWfKYuZEJVCoA3aVtxim++bAW4xPF9nQNgiN6ec97vNn8AnstLPxAw1TC
eij6+vHiUPv1XLI6r9nWVjKK2HGong5fYPUfydBp6bBOgG+5yandQ3IAI4+JdprdNo0KseWVn81B
YfllTF8ZWRU488M0ZHWQWhaQggHjl4/uzgKoT8s4deGX3ssCXxxttLr4xvqiPr/sOdOjNicKxrSf
gpwNQ29GYT7gvAQ4OYTX7QTdNaMeV1jeBYWTMCfgGRigFn/iPQLsqaJ4hNHhBah7bAWaGWOlsIhQ
aZ8xO+W3KVFUPKaDT9j/g6rW5oD+IUVQFu9efqhi/RqZfL8MMdzS9qXvpOEzIwIoom==