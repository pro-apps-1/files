<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn/53pJQTVGxencQ5ov70RXbybGrJnQmkEaVzQrCcEqGmFHNBiaImweBw4wsamc11sR5hEK8
c3EQoxEOEhqP8hOtXZSIduvrHHUPMs/uQz6Vx4xz+Q3jsk0+TNAGJa/EbAblz+0P7yvdcW7PZyov
Eq2X0viJBJzvTrR5r/+mZZvBexiH6hxB0t2kRUgNDK293PEoTCEq5nfZWDbZdqapMuIH/Gska24z
eJjlVF3WnTzMaJs6cTTSYMZfn2t+UnJuyWUamX+MgeT25D+EjpKkAQLjijKuQTVHoY66o3br2v3k
ZldkU/yoAULO+aATu0/dZxkUPrnmu1lDoSAswoMHeDRdkXf5uKdNuNc+ZvvRs+wfErXmydjf3BfO
5xqAMjq5ZYUWc2fxOeVPXKtJp+c0/hPaJ9xh3wmVEBSjnVsa5OwVsvTsjM6f+yUZJrvCY4z8RvYO
s6yc0QGxO9+ZRKE6TmpL3gJZODLFgQ01njxIxe8AkK9uHMqVuGhCD4R4zGO11XLLu6hwpguFwVUZ
kg5pC698RzoDEjcDW4CZ4v7SivEQMYIJOLm7qWbetdLmWPRaDw4wiIka0ZuBISBQX4uuyg09veYB
Op7NmGCahN3trbzpBKphJCBSIZgqCUPJvgs1hSxWwo83/pJMBdqhTiq1e0NqaipwAyu+Eysj+OPc
DRXXkKUGaFc5rJ1HXlhuLYCu8epFts9U7tq3r9VL8jhbnr4VXmS++zhd9dzk+71zOXAlBpqwGg+J
gK5/sRk78BojtXpnZOhQ0N87XXYC5w94E+QwXL+dvarsRtiK8/t1i80Ge8ubRhZ/hLLYYZxqddAt
/axJLJ+vm5001x5n2BStuiByk2Zltd3dPIfEUBUTer4Z4IJcx4R2cTMiMfQ5qQ6BUioFo+xZYGyb
dE5azP5JCPrP4F/o6g6S7zdsD3xXrpUZwhp2tzJ/C5jHDqSVxk+HpotCSwvOKTgiyleS5RhnXOn+
fj0junR/YVcdNuE2XQSzQo7NeGGUcj+bwZj02UwH0LOqCdSEXwRS5Zv9bH/4lAU7GvS2hI0MDbt4
2i7VXoCC/F2+LBsgRLYNffAQx+YqTL0Bn3r01f0d/9TDn9cWQLnNFvmlMX4FVElASwzNVlyAieVT
ixHW0/QVbGDDifje+UQk2YY9AGR2kWdRVch83TiuR6KDhciN4Qdts8HFd7YVQjCgZT2PD401TTq1
gNejn204NQTtclQGalvngn7RPKM5spskgrOqjLYH6zROieySFu/W361b5aysgzsUmpE9VdxR2aKJ
XyzO1wEmamS3HGTStyqwiPZg0DR4HJ/gAdXd34E3ryrMNV+0hxZ5ARn4NuXkYYfD54IpEG0Pcz6A
UajtRoo49P4TncFBN/ydz50zPQ2tkZAwbwGDV4munfLGo0YCq9F9MKimei7aT4jX+Rj/xQEJjAOM
q7FQq7AMxwBq7KknmVKGvDHW6G2LZ3JCV3gxdiLMfygexdABg6z6UE5tzKN4neWBxGUjYNsTzQIn
xKC5ZWFsh4o1vWRLaqiDOptBCIQPesDOshN+XP21uvm5Hyy6Vq0b9YABWOP9VYgJ88x+x0N4Lb92
pQkciaafO391HV+I4mvyU9fZs6j0qmrkkyTSm7EHIZ84pK2BMgY+6UCg0gD5GstYmh+o2sB0TJyv
MiqBVbn1JMcow4cDp/wzC1Krwidjt4imgVxawUAcCMrjsEp9xNYp1EHs0OSAVYIJDlGU7sYXmIkK
55kvjBNH4fyZiuKvccAnHQ2hVvp9kGSaRY51WM8DaARD1yzMgzxd0z2oxqpxdut/Va0VqbaLJWhG
oNq/ETGRotHhGncoWuKVKw9ZCHZ742UF2xow3qSTAjqLDenKtmZL0dfR3E2l8dcxp59Ar0KTaDAn
fbQypSLZz6hBWR/5dOCgW0GKcCKFabbApv5ASVrrQ//5Jv/WdSOI0jK8bOLSbxcpfgmt9IsTwcjQ
GPZdUOqc4I2mzcb5K/NdItNNc+Rt4lZdeRaGDlzegBAdg6+MqRT832BPWLH8qbfb05VipAZFr8qz
buDlw2948akwJX0WJp2IvvOEAwNET5XcQhhIax+rWnonaoeTVypFDYSd5ncNxcwxM1TaljWFkNyU
RVQhJ9QKHaauOXSBgnvfRJiQhn+c7yq92EZbg3VNgH7t9HY1KoFXChFsfZzwjWR1PtvLNZKKkuNG
i1KhZ7cEAGCw1cNY+6Jxe5z7T6p3zrxdYUqkJIeJ/zPCSWBfYw7YwVkZpCqQSqwRodxYzWOveQSn
YglNXOw2OSFkTpRltM3D+ZSXiItER2o/WngqZb0iaBFXyob7