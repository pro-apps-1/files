<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvxKQDEqXL7bGGZzy5wVIotVDvjNUcmwARAun6ipp5H7r2rW04hjXd8SVS5dQEOnSChYo2TX
XKLKKPXfyzCMBLT9A5be7nQb0gUS2PL9lZE0/B0D1MWK7TJSQM5NGYApNveRfOJuAynS3HsdymE6
3e6vMYi5WJynwhT0J37I7u799v22UR5XM9y9mcTiu9+KQRavnF3+dw1r06Y5qN4pvumItqcVpMNa
Wrq/O0bL1bvdA9BqhOVXnH7DOVXJbdo0PwifhubOxymazG/Nz8XCYKvD84zZi6fuRX22s0nN8Vwu
TPaJjpYmlq4VKQLSBYhCgR/QxG4JMiIWtQ17atJWXP8Ulu+bPcWkm33DecjJzWiYFsug4l1h6WmY
YTa6LLxuJohThBNDHN3rLm0w10rR2tRjpNKqc+44EHu6iCn0tB/a0troEc+UfGu4eI9yZ1n57AmZ
qfkALJTW87HCQtKLHOYYi6WaDKmhaGwFhj7jO7GKp2EuYhjf1afT2RJxXovSHVyKaW0TggIkLE+L
2kxlEnq7wo88GOKeejl3G9DQ2KT/ddcSy4ML+33/O0Ux3reXi8a1Xp98LgjXQAS6O58IHx2BLpFe
3MZIv2CzB83xqIGQx3OMZnudTIIrgCHbFzOxz9iGWcEfpdZ/yKe4LzG+GXzdGDgh1MFyJZs+9pL8
W3rU+Kk/eNciT/c0X20wAMJfr5K4w0aNpOoSv119UBsJZNBgKfVMfquBRCaz4JCbv18+tsnTeKE6
swh3AEWlVF3XaujJ+3+yoU8g2BcRaG7Rg3P9aatdB9N1byrBMRCvqFezgTYP16O1nIv1Xb2nGeWe
TO2e84awx/c0r9nqDy7vlc0TlwK+iSRSPCxn0MGj8syVydjs9zJeB7zXpkuXmD3u9KGmzOYVLPeL
TJM9kFWQnHv2SKcOC211Ay8Px5S3XuZ+ibOw7+JuxU8EX+rACuz/orUMubofFad67lbAQZBkwNyj
c5MojIPTHeK0u3ufHiG+FvXAkMAXLyEjQus8zF4gyk2CES0uk/+w/6wuLmJ8XoaszbFtbHuVKKnN
kBXlxoQCB9jR3xZInAeYT8nJ12Cd5Z4nzj2bmp1gGHihrvgrwkN9EU2IxgSXL7OUTxA/9UVdBWT6
q/VFVIo6j4pHX36i/sGXVeYlNRp1QSU6NJORXg9YP/ZGzPeEri8bBE+df+KcB58YxJML+LFSkiDk
gi7zrO9zxUXkwoEgBrqEYuh99yXq3lamJ1DEUHj8yBTOXsmwuhVtE0z0zQ9FPzZLMhhgrCLA1xZY
nafZrihtYYCf2bLMrLOTjZr33062fGqHgLQgeut0Fm7iM2S2SsMFrBKMAN+HsST1uT4AYOZk127a
o4CdV6OMSnfIpVo3+t1vebtzN9opC4yjPbjzbdLCcFvgmq8+gOx3QmyGelZQmlo+l1Lz4YcbXge0
Lg98pZRpa7qWRpwkIBrx0fkKfjwnZWTWLBTybjFeAY33WbglcLf+3JBxngoOuPlcXf638gceL6uX
eYRSOa5uDU+7DNoKY+r7uZM992FXnZxvHnTvVBTdpHSAsIjjKQv9lUFwQE0G3jyknus/OUeQGwrk
1/u8NGKTxHzktvMPZ1fkEs8+989SfsFhgFbzWTHSHEWdViwxkH/xN6wniWHjwDfSQdJYvufoFQLn
9+tqdN9xKRoqwnRVZCl/Q+FsNW7MGUtzWwIdyMt+a0hCP0RUyOrR6rSRQheCmCLVfTckPq4WyKme
CUBQXEcbkZHZv6tNaJuhRtvz7VQlKziIW6hzKqaJyIMfyAuG94LD0TRB77inW2YrXcSAXC/0Vl37
Vme9sEIEwO/gdregWZwj2ZLAa7/e/4kWgDKLFfftcOtQdy00PmRZx1Ra8TdEUSseKoleG8dx2Z9V
jVgV8WfooB2WPrDiGtCLuiXVHWIcH/0Jv7jtb1E29o2MFZvVvEC/jjehsqFhcpDEpffG6MdUUjEG
PUKOH6Z5og6tjq9jFTdIuVVJegocTH/2vKXCRYIqD2A1GJaH0R9oqmAjJlseH9LaL765sFSY0GU2
u2vcpq0vrCA7q1WwqgbQm2KMkXMl71J8I5dRPc7+gajuHAl0Yd9KQoMqGzvYZvxOYDD3FW1MKBrV
mxMHQkxxukLYQtChpv5CKQDGuxPwVpFjGgm0YXanq+uc6b3SLbO/FfvCwEiZ7kKJevgrf/K=