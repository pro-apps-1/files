<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzmIiMnhm0b3SiuaJq1KztzW5CSRS5FtUP6uTxbSbNlakQcrQsXEMhk4IR21TPX6kpvGnbMX
0eI6KkmOhFWDwMCPbbJo5RvsxjuMFdKEdyk5q/LzJYAZ0OFsSyJjJEbynTGxG3soy38RHegl0V4o
UVg8sxmKM1u4Hb/hwei4TNTs9v8YXW4VxPvf0eVrvQ7k9bAvE/b0GVTUerjbtnWrQdQGQBKwb+QD
VPszcNV1sAo2Ni1pM9xVSbUX5fDcY9l1S4iIB25t6JBBuRV5iQSE4ED60w9dRU/MuUOWKSILDgvf
4JqJ/ojfFaZzWBVDqHec3EAGrY/hiaaDrDiKBdHv/n9EOzO3crovdPR78DIWxkb1m50HBsvavRqh
4pOJoRUS/tm09WSJX7GbU0lfBmkCMXDfcLyfdwEWjxab2fuiBnawhAL6JZlevOD2b5UP9ET8PdN5
5c9cg5k53lGvqksC04Xa1NixnCneCZrsIaiEUbU762zzAP70jfrorc9FK188BiDHub8Uz/D8IoXi
BJfR/CIOnuHXquAD4ngwXusdNaJxcKI9kNUEyUr3UxT9EJQQiX3cQUx3dNw/d0fkPw9mcaotFIRa
6KRyY+phsGt85ySxnmi7f0cJdtFh7+6ffDfAbsLgpWrQYj+o7CT0aJ7eYgPDOkChVczc7ls+rk3K
UN7AeQDxCHF20B/wWWvbjexmRmmRmQVtzbyvcMzRPP3YATZp3KaYpKyoLSDtux7yoBlT+1Ft7ZKl
YEClKoPLagNtZV8xf0JXqYFbn86LBg+cZ4Az0x9B8joXbmsCacLxjHyD0Rv1sGSv4qtHgiyKwSdL
LH5i0DOuLvFNR7U8CTDfimh0EthVm6Ii95IAsSAVUNYBcI1/lx48ApM5hPvEV6eKbcHZfFHWhqz8
/rUwsERDXojDsSZUH9Lvzyj2Xb5A1Exza22txEmdxn/ZJ2Z0V8ybD33JlMIFyi24NkSSy9NRN1x7
eAaV3SulG//2lyRaCJA2qFSPXy9kNk3z7SkENPy9/8rT6ZRIUFcvpZ+b5A0Okqum2aBc/VNlY1yg
JPjJsvpyj5VvbMjHK4J2/quGBQCFmBkfuSL5e+vizmYFpknaJtncK9FfRU3MqbisSTubPA0d/TSO
uGRzeCy+KaFZNCuki/Q2JIekZXuoXv3Rd366/Wx9Q6isgC1a/WIU3ufEHp74yvrhy5wiE0JZSpJA
XJcmP3BD4rczCC+1GFznE38E7XaRvxGY1vgVxYRTgM8OGTU7kQtq49goIsTBOQ8v/IqiI1PK3Q5a
k10hRyj7Fl9niRo011cZk7EwmJvsm+23HhV0viJBbH4DItnrg5A2wo5U6tQvUYsKENUEFYU/flnD
ZoZJkeRmp8WkXxzVMR+/rTZ/eqUjYM8CNmMPlHNGil0LuD51UlVk0wMGpFUH+xe1jsoWq1blyw8Q
YOZJs8IQtpqINMxyDIBn/on9eJzKXpi+ba7NJQz2V0cHL6O7QETi9rrGqfQwmreHD0hEMUW1H9BO
Q08f30+iIi3lbPx2ivVYTV8e3pESCDNpiyI5saPSB02+D9L3HrOmf0vwFL9OQkAaCmTWUKSTNfa6
Uor5WuHai2KPI8Oq+19a8f0I9DeoDlIJacEJ7BOopkcTHRElWl9AE65W2Yn2s1dxUuMl1uBinKfP
2o0q4NG3zvq4m24Qbn9L9GpsSw8TunNrd8ioJ6hCCOSLGm7WQbw1pNOZWBQxWWI4Y0yiNSa1wN9M
oD07t2q54RFD6pl76/6D6Vy4r7UMPILZc/g7tJghBtE0OkYFyNBv075qA2E+qJSODoTutdzrudoA
onqeVor5H44foGkQJdavSx9eLs9cXbHUpwCDic9erVU/3tre/ucZYjTWqkVsgRx6lvrm6EiElvdT
hBNcg7pu7p9jXPrNDBGjKbQwtuT7Kq/+Wblbaqb45+AgsccIVVCSIeDnnhjswvYTKAJvIBBeZV/h
uKwv5RHqno2Nk3idmmP8+nVzdHhy4fmwzxkJne5wl0SoFQtKpvmRFg3D92Wm6XyTvTHL0Dosd/9c
E7urhy4XOG2tL1je/TEnE9lcQpj9OHLaDcos+DdoGzLX9VsSVJy9ZYlhHArDP+Sk7q2zqJF6BDJQ
qIqg+ipOb0mJ+BW83LPciU/Gv93zN2BkG9GzN9EP8HNC6mMZ7zRSzu26SOfXhO3P8H9c/OQBRxQD
oaIiCixxhfnc/QMELX1IC2UvGU51aCJ3YzT/jwNyBXi3TXqDES0P8Y/KBd0IvQDeTcR1WLsjYWUs
CuvCw/ZIVIdYgsWDYK1zU1ItUbsKh421xhqVERc5pnhxkq3Cu34TY1OU7bw8j7FiGba=