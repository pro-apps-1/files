<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzhD0R4/WFg6nWwKaWfAtOTsA0HSImYEPAkuvYWCOscFrTmYemNR9MOwx9hLpuTDS9YDRj0i
ruRYToQm6H3bCPr4KIQ8cJKtjmvF7cHrrQtNXWgg5pdakegX0PSm6dZWgFbkOW4m8dq50bdDGSlz
vKiLO6JEJNAf0YTmI4K4JgTGo+cLabDjyW6gEe0hXrRWw7IbVsyrdq2gPNw+2Q38S8y5Aoxmji2s
AAWgHXVNRGNRAp+0EOS8vk3UzShEzi2bIJ+rBFA8EKV1kGqKsfbxMrk61KnYioQbHKNVbHgEnXxt
ygKllZyUmyuGMrlkOBgm3vK8fx875xG24OoXRT15NxxMfvJGCW9zNAhqS8507NzDDeyD8nIiRVNM
n7AuOXZ4I/yvWc02KGFheudTmUje7nITOa+uyltzegASKO5j0/LIOas1MjXkNWMCNBq9uFCkZ9d0
cmUSUuACU07jD4AFPSGX83qrYsOon5TpQqr/yriuYMoAz/gbgKxhxBaHGQFj/mP5B0r8d/hIhzOR
0hACowsyNieHwB/vGqk6tQq95Fa45zkFXdaNPD0D6IKhwTzzpyR181u1Ec72jR3eOSsPeL06meJR
YGwra1y28RZJAYvpR4XTE1g8ttnpytuOYK1VDZ4sz4+r0pWtVGF+oHDntAlUpbxS4fV6AVtDPkCv
rXHdfLDASOBZ4FMK9A+XNDYwr6pGW8d/+9l5C9AaSTXR7R4GTWjNCTXoXZ6/S6jj000uoFf34sKk
YL2fLhYMGiRYlMd4PSFKUQ5gh0SiY7VhsNi2VzAAijNuviUBuETlynYJB1gDUfYE6x/PgnQJctaz
LFTpVU/2w3YbN1lMlBepiow3UALl601+I79kylv786xKKkFobpi8UFGfvcPG3Jecs1RQ5clrwKka
XvfEag8EJdMzZxp68aOq4cVZBbvWzJNtD4CEpIO9D7xKkhEmAgX/JyaA6v1Hap1P5jG47lEzKtgk
Slxu2/SCiX8X8sjGol0IJ/+RbMiRk0hYLWjlK4OTJ61woil2c3Q4NW5OYBidgKHQDF0NWof1zIkQ
BFDoWYhMabKNZ9HGdHQbbKfFZTY2fkPkwVAaLa8F3ZJPl0krMbbpyk8YWiWDSBrxlyzKCmRQ3K85
PE3QV9C28/KnUw2b9bSvaB8us9sW/EhW6iryf7A4H3FGLZM/dB8Kk/IkeqGCVoRuHe63KUHNJRmY
L2Eyyb6fsZHCxA8kx0RMp87DlIts38yabdxSTpeW0BnFxvlXIAcNILQPf640eFDbPyu3e8/9Bjhv
ZKE+ohqT0gz3xrE1/LWVRJD/j61SkFwueQelMzZAK0EITdAxQ1JbehLcDDDz6v3D4+1NVAB/QXPQ
HBcoQPH54TjECx/1xK1p69tQGUC+w0KLaxBLpnNjQGHlFmq8/qCJclylfXA3Mu08IN4844MKnoAU
rxd7t9eTZ+ety/hFYZgZnTNz7nKUiZRA9Tsz73e+g91JlMaeRMtJEuwaiaMLOvPKvI7T1Gt3xcSp
VH6LCCxhr9N5WeaVfW+RQ5ICMTG0dsv8J00Z5/iY26xyVLJHGN7ad1KQYc+XudHVnn0lXfePwuRR
DaE1LbbBnIwDjGkq14jCFd+lrbrHt0N4cCGsxRP+LcvMc+e05yC0N6Qr3iXJuPTxBl3WySi60ihp
1QxB0eHuY5sl1c1YvFAAcZkaybJ9fcvexBVo87MMIR67mi8mpu78MLAHWJzuQ+j/ikt4hrVc/H7W
99Aa6Q0SYGWNldSotgWptfgwu9xl+4mbld944WHxW6/kGzU8H1fJ27aYRJkHPMnSvq517OrH0XdA
vfx2I/7bZpIDVMNdvrFLSMdl12ff0Pj7PNYObMZmj75W8KnN/95uZK0vLlZlYXA4uSUg2Ug4aGPh
WL0P08l2zMmi2j4qtlhP40hMPPFf3ukl/R2dSlxjGfQwnIznq7vY0tsEiBOu3CfMG25Yb0uE1KBo
eOA8ZYugBpVo51Y8YPNjvtDyI9T8lhW1WgzzjPSuq5NL9Ak0V+NH3IJ2dBBBg70an7Wlmw54AYl3
p/gr5QeGETqXpevegbB+VJjkcX7YtRZuSyzmlSdh1MvagUw8M2cwqPOPi5MN39m=