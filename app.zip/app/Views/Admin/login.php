<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPquPlZtcsG8o/qN5AnxS5913pu6+BgiPxU0sC4uHBd9l+Txna0SJsl/HNwUoXenAX2PH8Emi
SoFykKiekhq+lI/SBY6nFJCjMBKPeSlLUT5nc87MgywbHQHiZPtase62ULEnB3Ld42FaM6SY1Bq/
3Ls3RSQjt9IsK2t0dNW+i2RPVTIse77Nf6O+JYm4H6GUIIcEU/+v8y8qrfMU0zaCLjzDJX9E7XJC
aw84yMf1Q7qeoqR9N5BwirrmPi9OkU9YJbN26PaEIxGeeVafOjSvwzbosPMXPTW1NvmKKvY2vC3v
uqvmQwC/O7CnyrgRfd6M/Ka9lXDCPBqB53sos94ermwUpTM5Pa/MJOIW7miBXGlOQIw7m+qoSMEO
J1bbk9YMaPWOnnzc0G7p7tyVugsCE9Is6VRjISZqx0gjC494nsauBEJRzMTXQxTqZXOlmoFSxRc/
UqkTvi0Sql5+zfBIheR7XuHraXmWWbgBb/RIcYl1m208PkynDdY5TmeDDHYJiIeMtut79/SxYxa/
MvcpJ6R1JlznHecpKy/GBuUkI/4Fza+ypxE3rBxUWD59xMyaURnMjU5M6FP8Vxi0JyGZ8ixNNz4m
QX12ECqeYDszYG5Jz4I319P1TL3GzTHeN34948E6PAKp1c5HB8lQ6R0HmIG9Hh6U1ydQIbG2eAt2
TPeED17g1ijfa9wMPRNIx3jXNu1OuS0BaOv8qlJ4kcAJHP7WHnhu7XEpEqdhUtOM8WtHX6C/g8Bw
vPsr8Z7lddY/guTzbCgmu0OYSMjoFIFJFslRnFHd71w7s0SIdhgCe+KoS3WsOny5omcI4hZYXFU7
HgKHf6AGcNJpam7c2RDLd+tsVfi1zQpRKIxSRmxjbg45Cds7wQWrjU6P9/vann6JvK34aL6G0vkw
Ds+hEqXB+j8SQtRP81OLwJJP5UmRR3fbrf/y4PlYuWvcQ0j5OB0gT4UVBh6ViHSGVMGYH4h65yRD
EwTmEzbmTbJu3aB/E80qC5+WVG0UPdSIK3Is2U6ZDEbVV4jYQ17hJVxOvT7wZmj4nr3qKr8joVtc
0SUIXGY4L64bPUtLp4RB5scJjO0WDc8H4Lcp1V7BfwvgIpUAdqXnHhPpUihxTLJWyLuvxII0nE9X
tu//PCufEXrXlf6ipw9FgmoZiOWUnjmYMMVLzToa0Di9JlBCvptbneRLqPxlIgf864/hGIeoAFOn
lc+dVGMJjhHqJNGECdOrwYYL22B/8ylq16Zm41Uuu2v63cM2n4vXfaAwxBpz1jnnGhDH5qwunb6I
DsomUTZSRuB8yT6SuavxquSaJ2QniXfPmGH4uMvJHnjS/5PSu9d5PpFBxMwoDgwro2Q6tnL8Zvxy
GxqSQz9NO03t8W1TS/rwKOCiFlFdj+NMwzHmO20o9KszT7s7aKeJp+x6cAvmo0ZWfNpO+sNFFasB
feeG2xU5/JWt9ctZO91GMoo85s0WIdObISB1R3XjK2ckFWEkMTVOBN2c/H11UWNblCc5ZJNoZlNB
tP2kDbbgpXnofWW3YaSB/ltdOzDYA1bJ6jDGWt+ZqeVeaW4hpEZtn8JXko0VasuBOqz7K0HB5hn6
8CjOUGu8SkOAaEf+1ISkXCXAkUlSjEdgsLuABsiSQbucBYtFico1pj+MLTfYXdfyZRVIJqVKG71p
AiuMMPi2J/nlekJV4ZC+lDa75jAqB2nxwPnl0V6cvejuAmfwfHYxfW+7vYZeuWNAYCVandsAox2N
e4B5c/WzBkv+AC7jlaaoovNkdWAYQztxjkW+7tal6E74/0SL0vpdasJrm9VJY9oxZLatZyuV1kUE
XT38ob/KxgIlXcymnMh2I4Z/yRxtElOVMZkauc6IDJ2hIS1TU+pvZL3Mp42jBqQwd34bh7qpnSgK
NUDD26SNewhu9KumKNtfGuD3HbjrPJQGeLdIqd++W4pZ8PQ5FuWMfUEg3VFaD9FaL9Z+rA1uOzd7
8n4tVLkaxno1Anyr99iB6zo0vOXgdQZd2rDgKaE2ovjdPqVA3XmdynCxv69mC3RsLtcRKGecilhI
AWh0Ua010bm0akJF/9uV/1HsXAzr8FC7+BgcilsWrQdrxUmG2fYxuqpQJ+D4txRxRXqAnFU2ZnV9
so/CAovjMIQaI9kdFUbj1uomsIWjifQyCG7j5rDUtoMZkTjiP88i5DsfgW8hIGOTsUqoTaECqWhb
lOtrNhkFbcl7mG8TxDq50nrzKeKhj2XrPjri7UWwuNjasxUPSoKxCJh29sgTe2NIYeb9ckHge1EO
Fzz8n2JGS3LLBFct7KR5oTJZNNfdFkZkGSeqvLVWzEsw9uuiWopVh9Ss0L2fHFAdz0==