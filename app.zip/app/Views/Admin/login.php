<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoaJrmEDpIiqID1287YyMFdZ57hgkSfHBC+9GyF5mgQLydR4KiWskcBJ3ivDeIQAXYzXAchd
EEdf4TWn3T0xKoCK7xWDVbfoVQmHD5Q9agFOvrBrZwRIZv6G/BfRoHRBy9jQzIIqx2nfo0FEBCTe
9MgPmPRX9r/S96crOQub7+u7ntpsMDvRn/CZWmgxhnRnZYebkap5BX4vZixfnv8Brn4muAYUBf64
Q0SCJZRy980hV1tvgm2l3O4XuQdMwl1CLOb6WuMbi2AXEY+NIVLnj/1LIwhlQ9EShOsvvkhUIv1S
J4fvEroGX14tNDi2SgYO9EQsfem+o96V07Fw2SsXmNB1mynfLI8FJmYWO3GO8HV1B5Eat2nmUg37
OQ5ttQ+ASwxCUrJmQJiQxfRD+TZL8goZUeGu56NAxpN+l8m/nI1pFfid0g9M519LUbZOWkb+G0AV
Lj942ovUJgMovJXN6n5D5jCN52PGiaWagNdHMZcTZD8qNPDTq+iVevcnevfN65oj1oEsPmu6vYZ4
4Se9F+stSKJNKi2WylbfIO7KwNmoVZA/eV8rl2Ff6eQT6HWirkW7wK2cA7V3IvHy0ZjLjKk0+C15
7uF0IfzOrJqzz/jYVO3kSRKrnq4iJCs7N1UZy5OFbjGtPpkSdpXd6vfghz8YWKN7pLQbpktTOWj9
WPvhgnmePVrOrPCt99Qs1M2oO3kUtImFYAZMXS2Jg9mSkhQ2GuCHdZUoBPTYEYpLmldFe4MmeGKE
b+rACYPxgoEsLZOGUtaKBNE/RGQYboQ6P7X+3vXG9Wma3Vmq9yyh/3jnD+o6op29IYX5QUG1ojyH
v7BpdinPGkbHvzLVM9YMZHNPPw707TIRE4TCSLj3rz9P/r3xLplaVZVlc6k86x+FrgrmINggp+4C
3JHsX/L3yLKQ9weLkv6V/VojB0PB300X9r/CIvK3rOS1Sf5ZopCFs3DSB1F9XlAKXScWgeL11LcZ
4nBf2eEcC+UqBTFaCOuhkedKpIYkt558TpyMkdhAIk7kit8ig/DmlbqHRRhHnVEHQ3e5vdIYTWKo
K8hQEL1LrWZ6gd7Z+ptBHozHqINEC6rYf0gmsImGNLPSC7BNigT0LsX7aeNUufkEHnDymWdOoKiR
J4QSzKRUeLhSkucjUCtkK55/nmYJYSyf2yFVmXUfRQgOc31LPdtxmxB9wGuztZOazY3f9n1POrW+
oXdcVkU7A++y7QrkBjPZeAJgH+pnS9cUZMqBy7+LlOj2G4IKPI0f1IZDv0eKNwW/rx+L1JwhPYCd
gg1o7lv1YgH1fgvq1v+BiOAyrOvFSS2uta7e/KfenSedSoFBd65IV6Q3HL8FKsx/ewBP8efadfJG
ikSd9/uNqwjs63Jwv/JWr5oZJv6w8Anq6J8hv3vW+a4ZC3KsE61JBsLcxJvT/EOEUqyKQTeWo8LT
Kp7b+F2adQqx3NjPANUtf0vc/h2uwkYhvlcRdIceo6prBF/CCCaJLEp+H4BMwUlPj0vVLP3GrYK3
tISt74G6LQl6UHpXdnR+D0JrHIBcCVJu8x99A5Pf9NPHYkHoWxNHetW4Sh5plli0SpRtcCxp9BKe
uF3QlezHD+hx20AUP+1T1thrx0u1aLk4jbE7gj6S9kgK4QV+tU07vPOAtzU88cas2tWF2cAJq0G/
r0YkfqSrIGcDz9R2JeDMvd4oMYVG+cvzAlcy0FvEBDuO+I97JjM/qSdGntVr673Ze4/EhYCw1db6
AjYQnKCLZy3UQ27bWQ0YdSqVqrkKIeUTD7hwWrCZb7J7ilUL8GokmZKar1rxYwnLDR8e/TMjlp4G
5QWFMDUSC5tjL6q3Gwc4zygZvAPfNAL1uw828ejHNDr8HLQx1fxpp6s62Rzf36wtZ1wCAAbh/wAz
97c5dXwxR8FdqYogLJ1EqmohLY2UD9as15/m8BcTANiPwNrWOQ3ciP9K9GbApH6so1ua3El3ctcY
Kqh6HJ42bIo3vL4iAv/Zm6TKoI2kFdqghQSFmjpomuglFOklExa4I5ws74Baz/UJqijg1x+CIG0H
9gUNAVktyzpMo+oiK69/3TBdKbsigY/tCGweffSqTn72nk018HDGlj+Hnn0=