<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpeNcoo7oNy3NjGE3utdKTJnebnY61lGMl8fbii6DbgxV6SiaizpTG3Dk+WV9dxYnQp4tgTz
jYBfQ7CVCB7puqDAmJdu5DbAh/1SynSxQxvPa8dXzwG0IbH7dNdacFwhMofbRS/AUuUuHLbtsxWW
cyveW7nxZgQqt/v2VXDmSiXprdoYq8aKxzk3cYyJz0WjTBZDFGE6FdGaxQ4/DA2i7v0xmFuxuph2
EJNkquW2FHtY8C0bBVGqi8G0QqvnQmbQsAZsdtJGQ2VySPNEKTQHWZMx5JflWch2VQV8YKY80Wep
qDgBEcqEQXfZUdBIQgrSEmQequgD1G9Ch9GhqPLISm3Bg1WtvSvtx/3crNm11Ke4Zbr6MJXFhv/1
dfE4M59/4Xq7UfeDyzV4bngzOSFNE19WWBwWnjDpiGsNCiSdGIH3vBbOSO9qTZlt7sso806Hzf4l
bIvwZNUC5/jmdFLQ8g4RjixjKoDc6DDsepFokBUoY0TMiwqGGQi6ry+r8WjH6s86l9RbFsT7vJTp
sp8ap+zh9s81pDdxxsBWeyBoI0CLqJr5kRhlcIqeb75pXDrn4z2KXywnkGnbVLSUrfXvKe/C7fw9
uA10FmbdHTgHeRzovOAoDMOzZg/oaQ3q56FHj3jmguXr5pRinPJz+3P/BV+EbaqCsfjQ6TWHk+wE
7qIQUgoSVEES4oSZaUSsjxjJO7vfsXJTcjkIrYj74JYRchO5aeH6py4IizauwLFYVJI0X93Np7Fu
a+R9MntPjMG53hUywcy+3B+wudams1RRIuuMVIDupyGOqO0ghDRV93EM0HAgQhK33c6l+rkNX8pp
KjQOvIVu1VIhjxx7qq6jg5T/6ffv89pl+ksPtAnLMpag1bRztVU3p+ep6m8xUGLgrYzH8ZrBlX73
h4qwjFRO87Bzap94oqPv9apLfFLXnj2DFnnCvz3/o4kF5VYo+mwIl6Gf6Y2c4jFyYcPLwbWLPRlJ
pvq5yEgRFqmbUOa+VMK6EjX5uwBK50YrWvxNrhSop4JZUrpfkc9i7tLREvKEJoxa6Qjt/z/fMDUc
Ok0p+wIkQI6FXoIGvB1nolM6hM0rSam917wMA1DXf2B6lTuNEcvPCjAbTK1Q1UqKG4kyUVWWAmWz
E5BT/N55UQgrG18wMCIUcVg0EbkEgU/8Stq2boLcOegDYHL8hkkcdxWb0sjiFqs6Z3D9JvziAT0X
FJQ79nQJdB34jwN1EUMV+vupKkHbSA7ECd7EqVsmgU51UeFMAIZiGXc9NFFWsbS5f3sIHtYkfOph
vz233ehOJ1hv45AMeHBZNGzxSPneDRJS1X+9xmIa83FDi008yRxMsML9pFEskozXbdJ/hXrwOv1Z
9GphUsuLCp57YnyZv5/LEicHPUnvlrdDRFt5R0EB17qzK2ukgltwQyxbbBI+DWEaw/TpXHMscfs/
MZhcIL2vi5bVvQ/+A6pLHndZYB0cInCNqivpBWXUYJc8n5FkK0uXwBCr92CTeC8hASG5Gqoj7hrC
fnkFyLtrc/z6MwFz7knbKXfZV/agFO0F210pQDQcD2y8NYqnHHlqlaQQ8yHJLqW0FtdmNG/SFlLh
hu62qo6GyPTjXqrrkki7y5TGY9S2Q1HA4RRg8kkQlhzZztAkFHA7V4MfzbxOpWJ4133QB+5+2dmj
84Ft7WTAi8y03YWYAZ23gxyzJCgwUH/+zVWtaSocxPWbb/+IVUek4cTVkuLmcFbXfQxy6OHDcGSx
tqOwdUMpYcIchyAhiuij53eu+Y1KMun8rOEihzbYaD3eX8IsYyaUTUD5cTz1e8vaTTn7BYrdPD8n
FPV8RVwZOu93k3SHJab+SFD/DnOojey49KU9JpB+1ci1BsGNyYKsnPtlOqVqyq+/cOtvfUWPZO8q
PIAVXM3TJ8SrQImWuXUOHIaXUUitabZuijsG5CRD5rzEd/uUoDIvIkmXdcTat0n9QE4M8jsO/NeG
2idtawYOWv2GxVRvla0w3H97bZ8UyPvVVZ8XfYl0JK4C0BNX6nG0DHpM60nZ2zjAsG72G/Sz949c
Q7M/n8ykTyroAk99y36kJ91CEWuabsT/MLrDRTQisF5cnALCZKfx