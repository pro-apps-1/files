<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqqvxf1JbDAdAlfxizPYLTNRrevxK//K6gYuSNTp9VoZ/1YhFQViYdqa1zwKcGd5ajETJgLC
e5263lAnR/WeVDTgzvRmFlsf/fwbGyIaADp+5pfBbSjNvZlrwx/JUiKT0t8HpfCUN37RPFC3+FnO
pKnboCOFCWb8lRGDOFsR3qNdA84LhLP5u8F+w4Ln8Lc5jY/n4UmF5AnAlU/QAUN0wUf75Yfb+Jcu
O4SGhQqBGSqvimaAypJ0UrvP9xcWYGT6hlBhyLvyD5SgexbHR420sM8EOlTixlPOYAwfGfgxakq3
r3WRpTaC/WNBm8pbq0takfMJO7N/0l5ltPvtKTapT4JrEUhB8uStOWZeZoCRbMxEmpGTkJVNW/6z
XfIThJUp4z9So1Wefhaw4ETropSqVZd8YwnPBMSloQjKi5QVYaAbcKUq8hUFv+cfan2sNR/zqEt8
IHugBuZMkVH3PSzBPr1nPzHK4qg2oyDQMbishQJwyzMBGC+caFq0Jihn20o1PQp0rK6XpEPjjek6
+xcgEcDf4m7WEpgLrwecvFgzv5T5Anil90Xay6WgP8YlOwbMdqQRV2mnIbP9cxYtVzocp63CH9Xq
WhWli8VNldNVGO6BDXMx4L87n9pShm/lg0RqCy6NNjY4U6CXXKULvzzhq6x/UdVUk/0Vo3CXZWaf
skbkWYL1LdD57/b1WnXg3OxwfqZ3HS5nAkgUn6oA3ZtF00ssM8Gh1SGz0Tw3C0gRV8wkfn2N+9IA
sY8pV+Qqg9ljv4mnDTzCx+iMEnTVga3qdlqBwHARKbG07nfRdJ5l6NKD62AANwObU6enGwW2kDv5
xxJxwQpc2Z+LEkYr+xBac4YI3qwN53tqfN64VK5S/FxJLdzBTzYNxWwL6CGo0ah4tcFFUwfuEhRU
WZvgVhIzf0UGrTu1flbqo1et1VHj1N5oBw5JpOI/PTAKWWn3GR+TSgf4uakSq0KhPxkQzZq3v8WN
EHr6IDSEaqRP/FLHPhS7045lDpUW5WIveM53Zkiq2VaaL3ji+yCTu3xReMTaDIZ86esNnF4UnmYX
nT9Mm7NPEXmCjSbeK1C7ncy7d/ohlZPP8IfNzFArcDlO0AKXblvc0BuEDCMi7M7obCcw7Lw9xyN3
d0WMw/wTy2U7NiNN98Vso8odWfj5+tPyMgVxLR15IhbR5gAJ7mYJ0YJJrk6o3YGYsLDyKzdqpzTq
MeplLV9sQ7QIhC9TH1udX6SA4SLnFjAOgXs6jGH7MyiqwF80VJU8z1gbGBrUJnieYzV7txarJ66f
TQN4VENuMNlv0z+p9q6s84U30Ki3m2dIp5b8VOiO25K1l6W8ReiEeuyBWJb4/qLI1FHsw9SRYP3G
ZcY6Syz2RTBWyrPEAAuhT6LgY1rDHznJcPn6QfA1Fib5iRDeW38Ylq7tYfsIbdP2rh1znkM50+NH
YkXw/B7coGd+7sMVbHB2Mnq1B9M0s1fNQFjzomwHj2mJIuNi/H0eULrjgpXRt5j64Ror9DLvrJ4Q
zeA5O+cowSzuPI9JckwXpkCQ+AyN0tTm9hfHyQ+dXsiZbrs7//WO9xj7vbM1ICrYGJHCpcY/NTHl
QWerS41rKGaNwC7jYWmNpbiXL+QrRk16UXCH27mOuerPZ5LlpF+9TVU3b3CRpomC9cQ4M0SN09Ot
Q31c/SWehIQH+fy7Ahz3Tbl0pI3tIKEh3umYguoBKrrJGtKp3K3balg0lOOM8YvhP4Kd9gwCuROp
Bqq9c79D+dMPkGHFwt42NF+49d3bGJzhhvvZb60qsO77O9kCt0uK7OPfnbEIrT1u9J2Qg+MKS39h
vwHzJXpWLnO6dmn0TSZcQz1+NUwzotAepXa+1AVPivVpqYbqsxEYyVqvlF7LgbaoQzK+LniCWXiI
c0qJThUF5iQMFzAxXDb8oCjEyU8Vit6snbmQoeMgZcDjRGlcAE29c/ykFfklXrE9bsbdTyWV6YQg
S1OdVM2MIF5x0UtttmcQycxukoLqhr5jTyk376m4+H6ul908Qqrmh9cnUjzhBZUaJYWLVm9eFxxt
HnUNwlY3GVmx9NwsbrHiiQBVkmwJJOBF8B6w5G72Uzgxim6IRO0=