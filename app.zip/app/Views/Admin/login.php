<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmaFpYj4nZ8C4SnR25eFTUV4mivtj7hrm+0v+O0ttkKChEn9B3NY3xVRYp0lyC60wUSrhiZR
vzpgHxKAlK3R29jMR2SSSoMxvqF9Hhb2TE/sAhtBe7wE6ThQ58m2/0yOBYEPCqKju1bg5s5ss15B
7kVpgc+3+rw3Fj/ElejXHJwD+7b/Qn9wuHnK+1bXhbrFUd33vGhbndmibPOSiQp0fShBFXoik9qq
HQvCTLlyyIxo80Ejq4ovBTnnD4Kt70+MyFyWRzrKlb1g6Cjv1nFo8DJn1qwlQ3VfezT7zsAcKV+X
YajdBYRowLgIA3y2Pwdo8IITuiisU+zL71Q+6q47VQQm+xpMZxf0/qUpJ8wvLM4ou4CKTymBBB3j
skG8bAiFjWrd8vIHSlAoXWvktnsdbhzHBa2X6D3Zv6aVGAU7unoHX2G2/vcxFnNDPTzU+1+271vo
L+AqUCEslCNEicNdV0jRJ4TttQShYYe+MaM+7Gx8bGvMI0jQuyf8tEmuaQDn5tYWKmbgKELSiPv7
+9iEoCh4BcKoo4/HCxkCZ39yQSs3QQCGvdz5EjhzXuWDLF1vN95f+9yJ3WofrQXqG9Q6CosifBhD
bKT3RzN9cK9mcVB8AKAwpklaibqWkD8Yrqdr2e3Q0l2DflD+emt+sI1woYDSLX7GZkZ/SCQVHZwe
ZGd9Xs4UFSBl42uDjgC2Lm/uZPkdKDXvS4eSd/Hoo6ZcAWFqPKNj4OqHxivPzzZqqk8WQUJzFVhw
SqKQa5aofcj6AO3wV8oRjGihAGSrTo0IAKrtT8upthYYNqODt+FS/ojOx/5+6WvRIxEwoJv+nTlw
SzHAL/UouVTKqcDcZxEE8+h4XDjTQthmGz8E/usfGPZZzMOkmve+WcEdLKRl/w4s8JFGU/WKAE/r
QHOuQFg/wfYP6KkBZQMEujQQeYyqLRaVXub1vkhCZD3m3Mu3DOFo7GZUTJMnkHXi31OYUCIfwv6n
PnsSgVW7vuriOEIklPuUGmF/055uXIrowLeVUKhYfayrxBDdPIc72lEQVKxhgATVYkLgYex5kx3Y
7JNDYCFBmGjBYChBYY2Z2pEJa2mzLoD/4SDBV8EUtp0EROI/26goEzQ7qn7YiCOVwo0YwrIU9GBu
nQ9VQTPgJV/3iwGqwXzn1BVYYlY2xtD/XabEFHxTL4e6wJ1EZy/J0Xf0c7GfiHyc9UbJyiFuzQzo
dGBahRYuAnbPRO/AJKGXKkm5YJDh/JAvQh7BzuuDxlSGyQjY3YkYf7hxJg1Bf4Vkmhh+izSrtygX
A37K2Dj2/jhBt5MFg6V+BQ+siUVq01tJGyPn+KRZNysnvmT532eUQlIxuBTDKBC7IOefRMvnpZSP
8shvpFDzdAucGt/JRjnKKz5wEWUfuT720Mx8frZz4tLi2uCW1v9RLv9J6N3pd7fvnAd8Sto2bEq2
YRkAm109laBZMv/H/zfCdwwxxWZKfp2qs2teYaOn0nko98L2YIwNtl9fXQTCuieHdQKrUGWSbNKC
Ac+RADVNfhFjzP8Ae62nzBSxAFzPdZ8wSGHYdJkTOPqQh/oxNSezElxOK+cosAMWPQ7gHELfL93K
V4i6WJ++PC2HimRzhEQ26KCTagxurIhT8I8gpWSlQobgtYAwqXVompLV6Q6SK8b2nGB4S9J+LA+K
0Yv/HSTB9q+nbAhNGMV/MtDy1BazV/aQcvPz28Z51O1G1RC7HRDEBGUFqJHuSMVKb8V517HwudBS
seI9cZcgFeoMnbbd6g+IE+duVMmGjks+Asobame8k2xTjN4FsmXqY2VClmeghRkzD5TxaXU8UvGJ
RlVO/RbybvnGh1BLiU0ISF7NUjF07TTzZkDkI5FURtZ9x16T+3r/IuA92gGczDe61Q5P/TJ5vDq8
d38gFSCUEYqaqL3nB701hJw18qPTM8fyVFbzXGCPkwuCu1cFB8mq518bnIvMm2+6iAsZAWj6SnL5
fmNqPOJ6XFjn1SUwsxGFgWbsHn/kglrBpOOh4T7Wjj6rLGXD7Gw/yM13EbTg72RF/rowS3unA/FW
WzmbZIUrPzWpjd4xRHB39/D4p84jDvQUMR0OJzwb7YA9oq+pXOZeW9NtK+ExXxgffczy