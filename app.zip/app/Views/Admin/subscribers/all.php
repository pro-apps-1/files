<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuTCrc1C3IjN2P53GqZx5Q1aACGPQYRqe8ouOGH1U7hdQGSTY4CfjKNsa0rEeKhYAIfVuuwC
xgbtk0Ivbn/rsy5Bd04dbKbpJ63dB9YWXWbY8dfPh5NdUJ7vt4m4OWFL00XuwYyirNIEgLq8Omlc
LM3way/6ispHwedbMOJS6ioUOKatLTb4WZ7ZD4Zqtux2l/buI9F08Q8lswSXvThYeeskROLvgkNV
NftylmLduEmP0vzVZY537FTRlJXUMWUOHMCn4No6JafnWqg7SusbEtg05B5ZFoK+peu9Vfl60bNU
n+vy//aYsvIEPbAebAInDlY3/Jq1aiQJmU8S1XajVCFzvl8+zWMhLMW7/ptSWzeWLVH6WHVFL1aw
WV9/rzzhwXcrlJLbVe4sAMmgaEDkmX4AekvJk3giLD8evO8E8pKfsL6o8fYKqGy4JpsKFL5RXFDK
ugixHDZObQth/kTIdJZ6jxKwRk2sX8KsIXm4kB01zeSe1vzASM1w841gVjEH/JlnKjnO/tKMZtFL
4VKqEFRU4EtWhWH4HkfteZNaksjwaaEcr7T21nlkUvOr12Wnn5BOpL3HCjYsgY8qN1/9nnn4uIim
i8OVJgeYfoJGx9dGRBUrvCb7gRqceDOMcWNRpjuhImqQEW2KP9Ln023NrmFOS1wsBTiRKLJRRjcL
WBoD0M9a1LjKu0n9VXkU2WW9SnVsi5wkIw1zc5jfmx9JJQIDna/aryzOjR/gNP354nqRtW9F/owC
keKniI8NWowDPiXhn023qHuHBYc88P7As4hnTBdKuUs2rkIa1iAzB/a5LvPjw++AwuAZMaavFkSl
7h8vCY0mmKQMxDPjVz9TbJDS+ejICx/UsyfBACREuMGbCe7ECAq2gCCMWE/H/JUUnw4BS64ECsp0
ZIHkCG1rMvZ9pWWZclC+DRdBKugjE3t93buktsBFNjKF3qCd8NqMtaNjWEddS6CqtmBVVTWoUIPQ
xwrkBW/ULopqpP5E8qbMm4T52LUnH0TBYo0j/FCi6p2nsJ6t0+13fHcUqOnWS2bu6A99GSIyyZCf
4avKpQu6mlppMnd271T71o7R0VeCnfcvZpJWzBSxWpX05c/OidRN+Pz3iB3knCHqQCEsgnRugLs0
dc5Fz0ooUPGOGz65iqP4ZkAL+DgXKevnWQ9P4lG5nX7AcXhl+A1O3veqwyyiKAGldTnOBJBJnP5K
GyW+AzF7E85reVSD8eavRko1ep/WHIIBcu5UO4wZj06zAIamMk+pMbwilSgs4vmfrR592Kvxjkkc
w9gdHyhC4QAB+Zi8I1/Evg3QrfQ/gSOwwIe0dIRrrTrSMJ8FYlKu0qEqjpYG8rDwb8bXN/lKYEbK
VDVzRHBKenbqLDP3tyevJNfANx53t3GgXqOzcS99FlE7dBVsgag+myGJ30fTAA2xp0vvHSRJ6jkb
NLuQVp4mN1UxNEPKuwUShTYreapv8qQDf80Df4SC8osKWPPU5s/edpT1s6wFLSsZ6plwnlFizuFH
43wediOY89DzFRH01SvId0qMlyJclvyXaqvilq3EsmJBwQpnnObdWdrwPfV81QOmEIULawyTL1HD
+lLYbMYnXQ+aRGSlO47Y4kmb49dc7YWnhVQGj4QHPuCYmUjpby7I+Qssfy8FLRmF5LKY0sJkCVD0
AYDYUGCp2mHP+OtmJ+z/Hz3hT6nIYCYUvISWa/Bc6tsqRp0KCHat50iwmjg+SB0BQ9YYf5QD+BbL
lYAIoQRLNakg6Y5E9bIwOSph0P7MIw6jXeN0bjFBPlWOsIYqVksRmhHXQLtQYH3opMKJ7R0Hji1u
fdTT6EmLGXnQZojKbfvhu7apMkfFSqO+jTXCt3t0S8aqQZa0Zg0jgc7aweAVt44Mi+0E2U+UI4ll
1ZlIPqoNgGL8wS/DR7KjVeLzaCjdvZUUwBtr+Kb0cDN2D1LsZu6XFgUtdPXuIe1bAuD/RlQS9hW+
aD+HiDEa5CF/HUVNbtM2TsqUZhEwYjkowz2LHuG2z3dGzZkt0n8NPFqWn0q7x4yQwzWJ7GlQWYli
9lSovb1uNGxQZGwQ7D2szGZzbmhuHPr18cX/QMwi9pvPwNqhcBunOXctJ31AWeX2QwtnbygLae4/
j6Q/kPmzYxVgF+beC6ZN09YUmNWRO4qHpqRGB9rkZIPDgP+eM4VCYWvdeyaiDiIQWdAs/Dsy6I2g
0ZseBLANGa0iwTYuNwOlFO8qL8UTqXdtmONcXf1sMe4/UiDWtRPqD0riwyyqmF9mrsc0CdXHzeWv
rTzhYa1iln4ihq2zvfBT8IGPZa4kKj//EzGDHQDjqK7Ctm3Q+uvO/0pIs38kMxF3FYfiEAa09FA1
SU4LVQJ02/8mYA2hnn1x5mhu/kbZ8dsz1ckknvwtUFIqhN3YqiujP+H3gOG7ukGv/T5DkXpdMxz+
r4EqnA2Hf2XeS1GzUaSBSjTGtAak/yx4/cXC9W0TqHcE7h3Y3jwfiHMDx4yDfA4Ge9iSLGoiJJQo
nrpYn8nj/wNEt4NmjY326er44o26sYb0+BHuu40toV1qgYfXEoozgGNoxAhggw4R9yJoHaj+UaiI
iRg3cXAtdgSIQx+4k4LErCt1ZTpP13U5lCClYNqkqOy/UGQjgdK23zAggcAuTG==