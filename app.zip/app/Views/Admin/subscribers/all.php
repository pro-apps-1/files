<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyQ3muMBCpYgKbvMfksy6MEHoT4CJ32Z396uCj5mkUmRJaZd3/pttc+2mgigBJA7lANAJPLx
9HZyyHdUKxBdThNT8/rchATUcaoNH+l33sU0zznpDJJ+DvtbgA0BxilqSRX4jBvM2Iy5VouB1aiC
9yXofnM6srI9dYrw/3CD/HybVrCDAgLhlEtUMJ996zUixXShB5UISX88WGXgJcXtTI0YiXdsuiVR
w/JY+R1UtNNDaT6g+bEtrf7bJZYSmhq2BAvlcGvBj2YX+IbYrpdhsNBPbTTgSR+Fw2QD0EguEVdZ
ENSM44QIUifTfw8kcw/6faDbX8+MJ1yH+dQrsMipOAx1KxoQwpgvVNYVrXE1IBekmONjqurRbyHJ
Ckj8gx+m8g53cDWONFxpwLgMnYi9rOGWihDiruo2+kFU8hydzTZoPQwlDTrZW6L2FPj9N7aTbhOb
JcBbhtuCo8feiSYdNeZ1JM4ivhAxXOnj9dPOBNSmbCtmEM3DJvMF9mVqdIGB/ni+n+jTRSovrAc0
nMpBazPrMZk26xcDVcORBpchpjGHySCVRCintRIiHfPqTGm9dyJFdUzsgj5oxw+zfP+n+n8BsmTb
t7Y9A9KxV2EhwyhJ3jgCMwqAHCvLksqYkA7PSyqAB75GSIip2gDj9ZT4jkzYowlOpYYnn5Xia/k+
z13HWrsV7ZGNnZNh4Ry3dnnA5tq7df4rCkgCR1Az+ObuJjuxfYdSeNisAMZWizAYS+cIG4YN2NQw
9737dd8Holeva73cEx/6HEAgZlh5iGcNu16M+cgymK3EJ4XT2oZJwvB67CidUoHE84kGQqJ7EBIQ
umzLjnf1h/51+Y69B30e6KEZyXuop8Ujxp6Loyw3OhiZvZZBE7AnVOhlIbq8sQvglmcXa+O779yt
HBDbXPR0xlJtqn5l3du3SCAKG2Vrt/i6cwHuykOnWGglhVu1i/XW1GnkImap5hQWjrAcAw+i7nyU
IxhC02yDt5r2+ZFTjMeNLgLjzGd+6nMrJJ8TWkHydqp1b6lKTS1sN7JssmD6a/OPjmw/JZxwJG0h
CXWnnXD/hxVVqA7ValUEQO0VOocNeuUrSDbqJ70EMbaAyFkumzzguo9xrowjEItJcf36IradK7UI
GgISWtqNBJ6AUgKqm512XlAh/Hu5t0BsVB1ZmULU8TDR0ym6BoEeIo+o57I8zlwwWCgKJtoGoc1u
Q9ScYRvn1Eudu/YMpIzPsU5HR8jD9c1d/eIUjJ3a+mwNT0fiPzmhW48Jk9I1BMxT3K41E2e7jd/v
qk5XQQknm9qw4SZpkv6As4ZRP/oTHn3JfNYscv6yEUmEcLsSJKJWTApDKOnPMPvA/muIEl2R0nd2
8qCY/PBoORSZ7CyWnMVhIpTEXx97A2RNMTsUTWDtk/UzNBwX3/egsO24z5QivSBbR+NuMpdU43K+
HfWXCiRkkSIx4lybYJJR0XysqpFom9r8RFtHMceJ+s3pAlniKSgitCNr4BvtxB/CFnzqXdzwLU/e
Pn+6agHQLgk3C5303FSAcOQ1UsiB1dNIU6krBvEMSWJ4rgVryFxihmuCR1oj9EdjzX0NmsgQorlW
Sp9BhzG+bKW5bkbWL42sLfsfv3THPAA+1iRIm36tA7OSFW54VIbDU63FoVTwlVS1sPIyLrHo6EJk
2fmmDTLDMJTLxLcmJRlPWAfMe0ToENQ200AF2ABULOYGGFBmdL/k6LBgZsL3MN2LC7TxjeZmCJ10
wNkYVWA/xsHkhIyK/oJOqU2jnxnOstJ5i2UZSy3dheq5NztCPTxwyTB21mB8uj/xsUKaCMTkKGEC
oUxRvVW/SObajwFV1KhilARGK+7aXsPWZEhqON91xog+TpW28dEixXyHCT28veReIr08XlA0EMRg
TdcwFZ9ZON/tggxOpypQ4LAYoSB+QJGYxbkjNPE3RNE8IvgeZhxXNc3WaAK4wC9nQRBAmICmbkf1
b+rXux4LUxAIERX86X088B31j7RRWvIfV64QBPwpu0j50dmAJqLCnNkRKDGCiYBTdQZ4OG52WRio
zGVy5gFMUlI2P7yuHbGj6V1U6BDYx6Rlr+AxsgMi8Qh3I4mh2xlTtXoysbS0DasCEen810dTFyB1
CkRRMs2lsDW5zhJuTmOKA2bGPPWdPt6kIM/LbzbLs24RkCQjTiVHJG4WKYZ3A0mmV3yaYRYbhCRP
EmJmYXOdZSGgy/1FTR2/B/CsS2Sd0MXrJg52CHJNYnk+nd7n/MMt7zDotiYLKtYQ356I+P87Xl5m
Dp6t1fpz0b54KK4Y+CCj4EFem2gF35DxYyBX9NC4itXv+urC4XtY1LM8j1Z5hfI2B3WPsArF4C6B
DMNwK/udAHgr3+JR+6RilBQDalSh1ve5UxNf5ujjPbW6tGTqzlBpkKwrZlm4JLR/pIu9HolpEFrV
CzztrSYXGmx9CX08sPV4hFS2yX5cyOiDNkpS3YjxS2PDCs8EkkEvyGjH7mnTD8gP44rE7cNwDrVX
sqtLbTr0V7xfLgtAs6Ayj6vsaOtSC4MFRPkyBjWmwRFXglgBzT10QN0APRTuvw109B66vac4zk17
lQpQoGogUCvM/mhifszrTCaiEeysG3EomxRCcqC373YE6JMu/6rbq0==