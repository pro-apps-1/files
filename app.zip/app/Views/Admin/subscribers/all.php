<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvJVHRdJdxw+gWFGcfx+R4Cz6B/rtZbHQuIuY1at4GPUAPfOyOOzxw5ji6XyLAx0i+UfFIwj
UglUbf/46FE1DFOvCdzHyiKeYmIJ3ojKYV4Kf91JEQXDqDKtpuXJ324l+KwvwdOAHoYitGTG0GcY
w1so2TxLwBYFHbrO3Obq2NMQgyJ+sVkNNlPh8wZN3iB5l18cGB6+pnrIZFBqYLL7xD/UbX+uMjfT
3X+ao0fYYv4vkFZPnFPGOe8t80HpioG8a0zGAWetD6Fa59t1nE8I/Q3Fmn9ffizNDfQYOeHhrURI
VvzCWLgqhBnID/3whxakZIIS0BJET3HtPlscLEYcot8TCxlqcq4rSJ2nbmbXgakBUM6zaN/YcWlV
wF6MBumUaqHyMaPM3D78smpNBH+7JHwOwrD/OMvlEsjsaBOEhb/hCsVR57qtJMKltLN5Dmqr5n9Q
VBsu869XbphjOfzSeWXwkoY938mw7d3aBXIVTxTxV1xIVHGCTWflfOKS6nJVj6lFFK02T4MSQy3T
VmC7L1xRUEUJygLfsLA3h7Is0WOjuX+fQoQmZUauqeTFq/eMwLPKisnMmVrFLSrfuCZtPlMl8wpL
/Q5ybrActnpF6IOzswdhqI+N0jyudebN3AjoBNGU2IddfE4HTnF/iAZ90mcc3cr3INm1cCe3kJrq
iyeKR4T0jzrG79oBBtKtQZCupzyqdKpQOxXQ3NEStVZfcFs+qkFuLX+O/khHWseKXrB7odtPcQYI
blYZJM2gFmu3zcsWLp9NFPoi6xTJ+JtUs9S4OwSmOFLne2BlpAvVt6gVV26sKC4RUwgbL53OL5Q+
t9mm6/TsmEdsCdZxGfm0ZBjqX8PWzomsJaYiq1yIghTov533h9BCPs648Zh+7933twO5/L7a5gDP
e7OuzjH4KUuX3GJsOXlrWdz9zWna/l6SBFLT3y23NBz0P7fclY6T0zMXBhaDvrpmG2Y3Vm3R/S+C
u7LGh+Z23Tbz2l/zA0Ml6wtBrBGBTQUe3hvWzI2ZLaEzi7yrwBhqj5AUnJkjqxbSORr9O3Co8j77
5M+2+0rX8WVqctzw1J9e5qYvY3WEmUvvrRqMuGyYpC5aAu88CIkh9hbOwtNcC/T9cxO1fRN6FpZF
o4o9JsjNn82w4j61C/7oclTewrZv/nMn6+ujURrVHmC0cuusVKyEVDjz6+alL/gRE2DWLpYlJ7Np
APx7g+3j2BP9pj+p/Nmat6IGJOsov3s9yn6ug76jCJYsa74SWvNlfdyzcbIAk6YBGD2cEziuq0CD
LWheMsPOwzbEJYLnZB4j/HqUo6nM7gBX4S4ZIwCRSGaVXUbs5RXo/yghVHtX7crPaEp7ack6Vmzs
KDLPQO+Heuqoevz+pMXiyAPh+6GFq6vgw0PxJIlbz/c99Hy/w7BCVx/5O29plL66D3TITXY0O7SB
jRoruI9ha2BM6BakpTNxi4HXJwo/NsyUjmo2gw+4NvmTKUjB3ATd6JtoWZIbnBwOgFPP8CzHQzVB
fs6jRZUySRuaBtcZsuIpDQjG+DdqhgB3br6c9fjik6kiKrOSFsS3Dijc0tmvXKDpb/Y7Hdobf47b
lj13KXBgNtPTfZgHxubUg2U2GOhOJvgPfOMGehj5ZlhDMGzTx7HHG3uF4xsDuqWoOTeRcigDgKse
Q/w8SdFehG8CKZTeubDxxY7nvdVIOviMoIAth2RTRwtRnmevNgOXCw3QbjU0E4mq21+qeCzs7qfp
3Dgu1wbG+bRhktJfxdVjcoXsNFLA0IFQfMd2kbWMiflXSk3zuSNFjXh/jwGmS4j2xaIn7DhMquSH
iEUNJYAMVmJjUMERENTtxFBr+tjcZ3PYYoETkivF2a2XaPVQYs6Q/Z03/vURJZzQGM6VYrg1Y5SI
nqVepWI4JGCO6YbjkkzaFwQiLH4YHEUuU2nlkKf2g2XupOT0mb9ETiQOC3Ph44hqqDslym3hCEEI
j57xP0JUyeeTMYaaaguogEMdV4LKQ6tXCpawe8IYJjQ91cZSKXonIm4WLl/vHrg8gZg372WNnII1
pkpOGjB54BRrX/0mNpuenIEORF2uwSDylyXJU+V6L0sEG9Ee7CZXMlsNOkssKLK63AZD+dhZpBiY
NAr5O4+1Is48auxjgc/pb5qocYXTsWTy/bJsK4hDxFtSW35I2gCrAw2CA+j28Y1yoti7KLd/KyiD
vJy+17oFTfEUJHtPgwmzrqpRywyv9qkS6Z+SfQkgwv1WVqvXT+1oZlnt9ZWc+nOTpJLiRbU0P+5I
T4ihNaZB6tz0+NMwcwv0AlOjSmVyKNoQjS9VVClAWLUf9S8TJO4g0nxbfprDkOwx4+q8JH+wS7uI
U80mxMTbjLiV/qoXE6LdHq/mHn5iRpbbGLEt4lJSbcZO2JI77YH7PrW+JvXmcRoIAv1vCDrgCVOK
3C/qHfuQL1eq2765Yu6lYBz2CSqNJ5yAF+z9pk/wXyy32Qx3wKoeAHxSdRzi9bss