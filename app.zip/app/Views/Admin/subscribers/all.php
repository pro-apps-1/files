<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmD7jJloz0t/fekQ81X8q73k1r9f/KIrhQsurD94pw6Z526TuLlE8PC0eq9IA6temXDb8kXv
q6N2wXQPGkciRNfxvS3Gzer5Ev5i6utdi2aIYKth/OBSy6IVKDbFOY/J2Aird63uX3g6RyHnDHdM
1QbM1DnO0wDaRsu/PdH+5yvLL5vQJmYq2PiMwNtvz8HHwuVkoGUpYiRbOPEv1glw2l/771ZFuZva
Mcmbwbe66ktmZnXIBxnxymb7m1NQ4CH+vSPnGFk7vgmggRGTeFMWIDFai8HhWFGb7cygExvUgltI
DeSXT88bqjad4MpT8qcxpHhq8Lwpko0C/auCAMixPqBFzhUHMCsT56QJZNN945MTkk37KZ7RoCIo
p5LAAMCXKE6hwrHlAlqgzKf8ySJhMI3XHk/yD03lIpiQrqUvTvjh0Lc1eA+eltDfUMgCQaB1xBo7
INu4b4DWWH1PYbOFXJ1aWoI9hbhTLdnjWGblLLySWcTuEUVn3CR/VYJUBBJxt5rjaSoyRbs182aJ
iEjRdl2MNWyId6gmudEfBo9pDOy744Z3iv/co+s8Qiy9GY2IT/V+N7ye/6P8TcrIGI0J5ElP2b2l
Mw+nkAZ7BYbcNo8QpAxt0yABvxpgJY3C7Tzk5WB3Rzq0UJvqcoUbxI2j3qFWHSqCtjhiQt5jgxNH
gaYkRlNKGo8MSsN5UTe657MJk5odNRPW/6F9iCSN4HBZ6uy3z1khK0ok6yHqfobj/bU4e+AeK5IK
a27dNtNEoV9r3UNqfMcGnOOQ9xGUJleRFwbDhRfwpbztoeKrAQkUStD2GqwkDocUOLnfBRqsvPeB
9n8JmN8YfEEZJn2i+CHGPGgBE7y+OrJwHcc3omcf4jC7+/vedjXxRxIxKUNrBGCC1U+MarqDHnti
bqnyP3fm8ZbaUy2pMk1vUlUkj7YGvX6A6D0RWo9W2fnYeoQ94z63o468OfHCefMhz/nK+C/GV6Bv
43fgpoGSWvENZL98DV+tMK+Xcc0LJAWYlQAaJ9SaRf7Wsgf8CASqeXeWkm9jCuvdQ5tyJbu5uM1n
EAr2flGiNWWEhyyYxNlapCI+jXZaOW7c7BV7yC/Lo/rWKVgZ+FkGIh45FWwAYLWx1W4DN5h1OFGf
LW7q+Mb3AwbHFtW4P7tdQ/kqn1cOoTewg7tk1SdSJYCt9S3/t+Xy6K3O27nvIZJpBHeuitmM/Sm8
ihd/MK83KeFg4nCnFur+0QVZV0rpa3rkPs6zJdMIXHzkG1v3/eJerzo281aqRqBZKapJV0yEZmkA
kGF0q6+j8pAXoGWvEifgzJjX/fUZBFfnwLoesbTRsXmHkuPoRdtAVKD5HN09LI7/wPKjtcDa4i4J
4X6nTgBaqZgCkYhhWWUm2a6fUcmAA/R9ug0cLbRjRIqU7lcz1fOczusBj5jZwbCQeGGpiLA3WeMw
BMIuJldoP+p22WxFykd72oT9ji7FD1VVWAmWtgS1sl0JonsNjwoCbNaYw4s5F/0uK/fv7ZtAZtWw
eUBljQe7rp1sw+7dSAPvA3QF3DS4+6NSSPpPbeicllDguHLyHNf/RMFBWbnFZK4LL6dyQbuvqzlk
77bbvXW0TSiUNv3excVc7bDM4g5eFSna468TWbtuH4n7Ah/OIwYSB560Yx2H/V9iKMwTArmilZ2e
nEGpy0dTdRz47haO6jUGnIJ1A6QCa+BGHSUlbX7Ynwya5upF2dHhvLhVfFbhgkYYTn6ch+tWUMJa
9N1g5xYvuwmkV3KTlsKGLAXCy6AoW850qXigD2JLX7fnLyDtVMarOhWfqhNdhI+zuUmwK6YPQnA2
fFVndvJR5FTV+Rfn6bg6zXEM6q81j0aCqZtdMXE8f9MVxONCKquLxgfCy3DccRs6uYXofgBRyBri
BK+c1y46OCWBqdiFOqqHQ7kcxIp+88UC+wKBwyT563l9rn+OO3qhRvl1/qm2/KMaxEIhRR8f0MKi
2h4vgPH87cAZZAgnfoT85yqTcL5oQ06uGO9MGJldFHjHzQv+GPmKly5ktlq7MpKSuOn472RHdget
/CrWR80la6YJSk26xSevTpUzLDzm1VK+icbndLkmLxxS9PoQFm+jP/jsBvbLHMfi4V4pk5wVYJE6
CfXcqOymQeWHB8Bqq41qqoj+tTmn3zimJEwVbQ0jVtUM7z/ndleC4g/ZXVgONvTRUp6uAm4jly6r
c1CHLA6dlVnZB+xu126WZ7iKalOXxTPgCUlOXB6TYENqFqebWyTRlSJLDclJNKyTyrDUWEmbbQxQ
0sjVJ6W0AdfF4mum+GFZE26PwvkJzsG1zOJT4Z+kkeIsUGJu4+uIzUZt9/b9I0GVflQD5/eJLD+d
rOkHLdWXCu8x0eE+svrxEQIoyEQTqzXLV1nz3uWVXYofOBCM7n5b3vWw8qLpMe7BlnhKRwJl+aFN
zju6sKenS9ZBNsAMYrg9R8tFlZjdODHzu50w0tTDKRSe+9Jpk7CjqfojeOyqD6zkH7s0tCC66N8W
zW8nmQliVZ8clN7gwKU17IQbGnZZZxBY6XRmHBP7shfI9jZgk9Lhv60eEZLQp1RiCRA6oRWvVkCi
e7b2RGzi4sqJqiuLwss+1PfRGXGNhTcmShgKiVMFRgukwhn1PeoQwsC5MjPS69oq/LdUn0==