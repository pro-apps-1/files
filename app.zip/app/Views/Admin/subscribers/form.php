<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuH7qBnEu2Yp5wv5doaKU+V5WUrEBDhaBy0pv5qcIpZhy/8cXYiaElJNZ6LOsUgJhhj+ZZxm
uS6ula6LX2BZdIga2Ts71+temO3AYQ+6pYQ1McI18CTL0RsO4Awbo904zV58l3kpu0yq8y6rKJqV
iITlprl+WAjT2ZHOtO2eJAikhsOD7XK+UWHfcHOZRA+dWPmmv2ewBXifg2/3Cwp4O84DXs43f1nw
dt/tQndRuM0x6hW9quC7+/AvdUpuKdkstQAAAr4HV8PEId63IeTpZQKxUe0KJMSKb6KWpWNUggDa
LLxAxZ3/Dpl1flYjp+dk2lShAK3kQ2/7MT+rNHI5M8GgIgVmhEG51+MUEaH41sr8MfHHtz8vpXle
gyXMxACuoF+b6bb2c3SKdjD1iXI8HwRfgqbGlooxIugYUBHRBHFzsFjO/mvndA2IR7YJDD+srQdW
0MjLElMHYqVgMCKbAoY1cgzlCma7bnPMIUy9LQJTL6wUVRX9nNc0hAZwWKE7qgSXvHUdngdCPan7
PgKYMbT5E1i0rvi0AlELMNCLHPhSp1O8u15f7G/jzp9r1mCZR2tKdPXbtReseYkULQ+gYQU2T+iB
soWXcLru9ohII9XLfZ8PmxeYLUMtlG3DEKUkV7FZDZWU7yHRXS+umCVHHhEXuAQT6jjtG/eh+693
xvSempGKbJ1Kq5JdYfjjDXARyjdNVMo2hkgVjOtF9yx4GpRTdcXZrVdt9gDW9Vcf82S7u+ZZc4fO
aSAuzC/S7zMsYnYmxG4DEYd2cFXx1ioneuI8RDSuOjeCCtfw5LniIgJxUcSzDQYCILxHaKxpNhuh
YzbGWCtzW3TDZgz1xn6Ii+l6fqzi7KmxvUfpRqOwUtzr91/JqBe5ewqekBd6JVrZXz2/Rz/LivDw
DbAkdmvjEggEPteieIwqnou7tml6JLY82CbGrzupmWC1vaHgAvbKsHWjYhJiNhSp0oXAKRBwPA7k
zJaOcZOO6vODyKyK7BbDgZ3Y0Dvs/0O2ScCl180aHA6ILAR2ufEwp52kSOJwPHfC7WEc+GBaK/Ay
g5Kzy+qEGCyaIMRi9vUomd3m14sWtdM5x1XKO36RX5sUQfkWGB1njHzyn/WeyCI69sWX39u92OUI
QliI+qs9+sv1+kfxsDsSGw+x/u8h9ocUd2JEkyPF5vlbIbKjnW2Os/vuGtoBQjiTep3ngb+KvKKx
vLXqsrJQzT2giV0KcHq2hA4LK3vHj0mV5H1OWI2wgkCraUkKpX1EQEbfwZF0lu0kTckhgrO2mpx+
ITVjTaHM5It08Qq/g9RutNN9Z+jj7iYDEWaDtVO5uAQ6zhp5kGkkVbp/eurZahJXhP8u4oewvYBi
reutHJvH/VfdSDBj8TSzJCJRAnNg5JG/XTQKK96XMtqc8DD8BgqbN+WsKaFKkavt94ewo4xgjywq
wxUmQzcXcF54zex/EyZkMh8/bguENSMFNGzXuqu9J/G3ptnpt1bPmLbUtfIT2iC+eY4NoCbV0Axg
lyhWMIyDQADlz3vzfoCb66TbCgqvOsjZVGA3phvNbpH/FqZN99NoKbPNXf0BORl7106zrCfUJfst
qi9MKXvFcvvSy9WYxRv4pKK5I77tt9fLQcE0MGw8L44FB4wdoGzjcvP6CezLtPiOqUimhI0JhJZD
by6nfe0aFzelq2bt2/+ycJs5gAQOp9YgAVeovJ+nb3IANtxUlAVsm66t+Rw9VUz6GNsf12i/Xl7W
u7SBljuPagfQfutIbX1BIBW4fC6YXjV515RgOOJ7TqL++5BuUHALEbJTnFku/8B34HfyBc0IPxID
2vPaqDQaxp8qpZB6ZNEXKteKCZ8kfXQYNBzVIoXGIdZKW/ktf3v/XEHmO6UxeRhY2M1As1oeI9JY
akYLsF3/sMpxABEVX3lPR/sS13YeKMBXCyg+XrlsI6ftXZGluwl32ipdyLVa6SaopzPOGo6W8w4k
KQimKoQvfDV0SRKsuO3pmgY0adSzhrYekXPWULCZMbHNA4t8TOm+Wz5p/+tCA7t12BAdnEpz2GBY
XwGGMvSZoY2PgEgJyBs32X6wRSOYj0tEAnjX/zxkM8ObxwsMCfi38d9iirhiAT6O4Eif6uECpsQh
HJ9jX6TGsjMWThA12+YoqgYX0QQqcjRyABf2qhPVv47qZ/7u/w42XwJ1tF9lpEIQtO/NOYBnSulX
oioYhuK9Lxx0aiI1wdQ5morba++b8ahgxfpu4oqUnCV2bVkY8K0QzJHUZww5UIwExoMAah9k21Yk
owzAeGpFcf7ZfeH3/ipefhNiqk+LMii4SL0HlsFkCJVEfLT1yGuEqdbSboMQcvvFRhg828MKB5Ig
3M0UlMCknDRmEkatlJZ/tR8GX2x10OraZ8fyWO2drdyZWnyHQjuUUrBW/RZlzA2esi5+wCfH95vk
R5tQh8ddGNisypaciFKt0TM52MRWWqHRZSFwHisNdJCJ4X40Pu3vSTu14FCVVVKTeB/j2spSRz6E
LtRHRPUT0oghbDEjFU4Fffbkhc2mqpALyVPc3YkrlnMSCmNAP5pAJYR20vwWd4qzmAoOPvInsvk8
M7fdPTJPivIimvSvi1kS8ao3h+5FJw8YReCKqzj2TZypH5ieuu+mVpANKk1pc+0+zbvZwJxuFNOE
Zl0nqKEEwnj++eqgvyUZ3usEoFM4PcKRSswu62cZOeXdqlxGsZhMVDJE3av9jGEvYhZMdyRe4SvD
mQMQ96LO9NWwfQBciGru20GFRcLhmePyLt7EmGUqSdROJlK11y+mMFVGnv7OOuGNWSl/6l7lxA6M
ZY6Z1y7qXGQEZ4m40iwhQuoL6AjZqpV0kWMaufx3550jCo6oQZ44AsZW/XajbQVss1v+uvXxC3MR
lgmmCxvAz28SAKrIFYx7AtOlbusLEdzJmPs1l7zf7TTTPCKjJOECQmnA7JXyx/yTojk5HXkSYXuA
EDetWQDZDyh53nZrDXAXW84m30Iy3QfZqrVOPoHKdYy++BDLus2SQ7Huek977BY4udq7O65RU6ZC
MXOdyL4U5+JUAMdrbuW4b00BqaveUN7tGstLhv6geY26A6sRMcwtXb2R0hgwPCMiEo4BgLNDfS2r
4UR3Xynn7j2e+mlrpY1jzXFgvd+N4oVgEOrm7xAFhXxWymilESKGKVwbGuycT/+9kSyqcITpmmM0
WmMZ6w9F/PW68WqsAuKVSvRtfspLB3etleV/lRs8cMU5AmW1U5eEKHJHfIZ+yz4fIn4Y2csbeYT0
2KFwOov6Zk+1EkXwhj06eH5AwQGB8CzNeHPPB0S80eAq3hjcaOOMJswaqINUrev8omKiHQBkGg02
6ITVtjdKPqvEJ38tuS6HdiWotgqe9DTptKyTz0eTyMEyuU7yQYYa0Fdf//4LL7e2dOjue1CLWrfs
TZ/LhjnTRo5r/pq6BkgeiD80a/S0wQ9MsmLzPVmGRqYBh2FzI6qpGx0JMlFMvUH61eYgsUXZVzjV
BhWHePOeSlL3EE7/TD17odLGaIzyX9qvhfAUurRhDxTiIwhEiN21tVng9Cg+nC2Wds81aebPvR1t
Z5fJ25fA+YT72R+4f4FSau98ef1dM82dyzjYiZ6gsiLolayf4bU6QktEq/KFWCEGpvwJUJNTgGGL
5xYPCHx9FasTsjtWd+3MkDYFq+/46iM/xrODsWQjmHt8zqWMJwVXMTmZkuLlv2N+dR6aoHeh8UsJ
/xgtYg3EzQutMc6pw2X1NWZXluzeNYswC6AxLc37EyYiGLWswi2oWVsd/bmL8O64K1TsXPwesk5W
E65ysZlQtFAJyYnOWWDi43WPzD66xznCLMyOEE7i5ZOPEQMhAXRaNuNa6GCaj0xgwZjp0Pp8aT4x
RxF6kU93vhVRl4IMqsSfKSyeTUJb8ekZratRQtER9gvdKuoYeJ+HAM2tYJ6O4zaFrTIQs1z8zIU7
kdfq4Z9LAoyxT/i6ytf0BMun8FNovvRZhGD9nKSj59u7h/XVwwEHbC2EjHPBenlXZxge/0nOel2z
Ly962UJ484i0XCr6mW2jwgIGbszDVFN1vtQ48hwauZrDuOWt7jiKOMLo1r3SOaIv314FmYwADohY
kNnjzIz5RuGhmGmTENJjIPCA7PqXElACuVB+WDp0k2Zu9Qeit+8iYKBDoEZoFdBUQHl2nUHEVQqd
2TCgObDEYGVt6VRhPsJGLOEtPcpX66CHuFrmLBSUPMFxJFkqxryuDpXXoHoAhxDawKJtWccZJn+I
VWrsNeMzNu+goentVcv2/D9KZaoXEOQywtuAiOz9m2xCry+NV1bOqw3xzcoegLN4VNwNiphpxt1z
EE2ZJ4Qk3AeFYHKbo1wjgLHKqSZPvvQnMjYcQfYgnXwt0gn9sVermUltlw+gisyXE79VvBnF2V9M
Sy5wZjGfjQqYmnAHWde2gOysSDKk1qdoMGERhir17e1xCG9g8mt/usBcQtM2YamVIsGT1szzrx6i
o9Y2WqRTf5qq0Nfb9Lvl1upQHnEq2dNIolpJgq6GwcubaKseV59JlGOtv8fIxTe2Xl3lquSPUziX
75lNIfRO/gYLtRl/fkkroOK7/Uc7/1lYrxmIjFAIjOtM5sIQNkGXtpNSK94Qn5puSRp/gn3eMBHU
kzfyAi0IBj+y7bxlzcNsKJlrKPjxptciIQd2RBpEaEIj3O4o94VE0Fv2sbFgpbYltaEgj6i4pV3B
KAkeiA80qpU3gDvePCz8NDmgveXjrjT5GlG9di8Szqkb2aO1LzYyxpKCBa4+mmDMJaXOJl9km8KI
T6FyZPJ8mLBEC/RbtkfyQ47gI2kkbR7r66LA2hoh9Hncf4IocxUx/0FxHC4a12jTDNiWj7AAIgDQ
KH9KfdSuJdqKVsVxBg6CsO9DMHSxpDSICcek7+yYZKa/JKl7piQFuDuowgv2fP4+bp+4N66ZbZ+f
XS4zU6i3HSNYGLrDK0pfz5Z336VdR2vKHE7ma5P1QqlpJV5ON1CwqRMT/o8SAYcxCHN0s8nERmkI
wsudG2yVd0Ow9NIdtpFtKQfjNVVqtmtwSPTofyo2TUIDGgwh0m8dFQbeXOlRPBn2gQl0BEXS2PCR
SVUy4HYoDcgdtFAtkZLMX0IoO6sXVzziVtgdUW6J/pq8OXmZd6F5LqLS/ul3Q7Ybl2oltqxxLPd2
eApBIlhJVt/QrV8TyJgNq1dTbq2zRkw+jmB3xD5nO9IX2CJuM6R2gIaqeJRfsggyK9EYq/4UIawv
RRU69EFdKXNc/n30f+dUSSNZAAnGNPmrJzucGV5yhfBF3qy9v2qfK9XcABZf0qvHgelHdlqBMulc
EWfIknx904Saed/QGiuMg6ZF0sSNG3LQVvStK89kiVP4EWHQgNT6apggq8WmhlwhA1XwATcibSQm
Nv1DlZw/4zefAwXIFb5PBhJ/PTBJq6pq8FO1X2VpT5zaxZCmLKuhKcmEHBa0FlPUwIa+QJvAGrfX
DVC6L+Tj/ktJMc0I62iA/zIWdWgBy0QA1elDCVJJjrF+IgVGoSt3fjykjCjQAtYGvsY2C/Zo+k57
a/JR/Ts2BGHdVNRs1lBUTjqeuSnj6dwCKCtweePD/94hCyLM6eMD64Aysf5KvO8RFcYh4GxaGoOD
WngUkn2kEVos133GjpcilmU1bDEkunjOIMUtxpKOKamje76U6AwYNuky2+jJRv1QOscxdg6Vhirx
gHNqiu8jBtutsl30OMBieFneqa3QzNuPye3sV3Tw+G9YGOB+CODt40NHMcHzkAZ5FdtIKCvk3uBW
eLsAg89TlUjC2wQwQO43x0pP4+yDMbkyFVIR9SSE7x0rdwjLEK/5OxWebECABuTZ7EERKibV2jUh
iyMs5c5zzF72+jv61X77cWUrQ9uKDYX7jANjQmG/kEE8Re6Pw2vFRBSm6XBZRvWUit6laNSrM4yI
MwiEQHEFoXThTv9F5NDHoSBuBDb8pAPFMbeqwalMVGYG11Vmh9YaRnszrgVv8wlewzHMR4DlFHya
7GQX/iYp2+cfQA6FmmrnggX5NqXI+jQndHGbD6raEAyqy5opox6Nrq36ptxPvaA80Si9zvokzq/u
PpFuWdcIE+1syRKAms3DicB4jdy0T6zvBnvgu6mRv4B7AFYIx0GovlIGk/DAUwbIGsl6M7D8vK4F
2OcxwE6s0Y2vRBZWrcgDPpq5lDxd4Aau/ogrmEtPoDVRHFBXULuVq/Ri6ADM7s3pidSL3V/lexwz
3+LE30oEi51ulwX//TUm1gY0gwMkoRbLh2EG8GeARp/QAjQYdTc7H0jbB4v0Hx73TMx2SaROjwBq
yZgtGcBWsEcbWpFcwiTbzTjKDG7qkZ32GMUt0oV7mZHA1BwFIoYoFSRJaiCGLpOA9IDaI6ko0Ic+
ocR7/1T1ZP8ihyyulojGI3PbC/wqtoRyBXWB+ZkUD7xL+1WQzIdNT2egkVPawUeI8qavjytlyud4
QI8lCG+vaJQY2Q8pqlIaosl5VYyMupK0Qhka1mNCaXns1CK7kllI/wTJCknTsu0rBxrXfmnkTt42
mCN3d9eG9hcUHNmjbSVd5QmJ8y+CxXM0z/e4uJsMbJitbd8g1n7XS+c7K4qJwBtyVJQN9CfJE26z
khIhXhOYIhTcnKPuOmbEMfwaT/AFl+KejQYcI1WhuqCdtg5Zk2VG11Hfz/DpxwVdQjUCFcWb73Go
7oLFhwbVQKmes40JmByHi9wcVaGGgZNar8Gan1s7KYNBnuYJOMemOFGEslNEDj9hmkCUTdb7/18R
gKrBbjxGOQizvFDZzlbSPMuNl9bGFn0AwKFi3VIkNtXVo8/FAlOCfZ2ZTZ/3NU8Q+YOK2pkyw65w
SuogL07GP9KsuAJEqDT5+DmSEu1Azc9Fybxo65hVKmEm2rYJTHyrTrqA5luA2u14kVYfD3B9iARV
6zcU9KBWQVWBLms0a/MrBhDEFS7024rgSGz5TUxpDA6dYSUV3b9r7GMjcG78NGyo5ddZTYv8HnLu
eHF3FypKtwbnNwF9jM4g0SwgqNoHCmLljwqEG0punvij0HSFCt2cnkrSbO9ytX2YfssEKoh6+U+n
mNqGZ9Esj7b2MtS1tzCwLrSL3SYWArtbARFlFdrL1mWqGDWre2RlTLF/aX+R7o0aypBORBD+52Q7
Cf3ks+ctYM5JTUWVp9bpioVUkBsOemhreULnWCG/AQQxj2QKncSIR3ZN1wGSMlJC/K+4JWvLImVq
Jh28+i732n5yjol7rQnFVp016suAOYiCFgKQrl8Db70vOxTsUV9KB/dr3ebpelpq78pdDgdda6PN
3fDSenrD6ZYVJoNEfNdSodqEFRC9aDwFemkuCa9esoBxGylhkTYpiNGv0FrJmagJJZ4B4h4e7MRk
Ls78cMYQwjhiiOFvSfceTowkJ9EwrOVSeX6cM5qp/IyIU23J5pWtk7HKjHEFY5tFM2/q6GkV6W+S
+b1oBaBhEy5iMARFLq6RHFlnp3IomALj40kO9k9d/sKXBrm6vIUL8dB2+qiFb4x/2z4Sh20q/Xwj
FdfrK0V7dijz4P7k1CYdojBOtXwwncrfmXQanwYBe3YPKKP1U6xa0WtlFbGR66P4L84F478Wtd+E
/G1dXYhQKSza0JPos4J5mHhlhVIXivfn/yRJyGNK/AAsBXlTz6Z/EVv6mnyBcrYVdFjAAio1rrC1
Occw5DKZJ8+YaUmeWGdHD8Mz2OHSVrsfzL1FU02QWQxBD1X41kErSzMH7S5qQK8otMHBd9hWdb8V
neebw7dmeRIoUS9xldgTay9xicNI685ApGTp4eIGY7Xjc4CI1VULT5HfEI+Y4RHTJAmgDRC5aDe8
4L+Ve2PCKCdt3dCXRm64sAKlVRL6Hiofk06eRjLA1Jg5wcQCDYXzcoCo3PJZa+bEhirzAUPrGnC1
y0cxCwupTyzCn4nwsfWl6P9WWYNVsyQH85gGU1sLZMB2NH+BMmpyP9ZNBv5SYNGWL9OFR45bOaFF
wpiE+AwO/Y+C1jhsPm8tHSS20eT013vw26OFVwDlAXwf0x5GEMTGQffQ6os9qaR1gK++4AQv/ZbL
c7bi+9iGmsoZJ7htntu0b7ZolfL3UWDPIag4SGiZpDI2zEUeK9d6g3Rdm+n3mroUNffCbN3szHhC
chEGitPjzhyziaUE+w6XkW00jlH7oW4hnnygIFmdbEZo0bFj6Jv/oLGx2D4d+96oCWEcbf/cTKjL
wkP1/zdgkktdPNNeOCP7xyVLhG7Qr7js9eJhc7vfMs0WSd5yb4uT7akTB44amFusdZyZ9lAEXpfQ
C5iuBBkSTFDjsB9fNHsxbwQm2sEWsF/iGPlgNb1x6SpezW6TN5+R7EkClNe92sL63IqEvlD/wSWI
sZ+RJnqKAH0M3plBH8/If3V5Vrttot+ewsMT2rOoCUx5XoZ1emup3SBqULnjSHnRhG8kt6bhbsvZ
hMA6XNy1kdh9ggf9Q/cCin4YQzi6jFsMq5f+qROCjLo4hhtI2V7fkgsc6lC+CYpCkULPjWxm6qH9
OSjzFx55Mlx5xvSxlra/DJyxq8+7IdeY4XJZgWkm9ZIEP4HF1Ip6RrPV3+D6GW+BMPa3hr0KOSGN
UX5G3oL7gUqTMjuQewjqT2Rm9OR8ZOppL2DqsOmK7QIgFQ70FdeoI/+AKkhy6P4sCKG/7BxntrOe
6bzw2ZUf3kH7W5VH8yeVtqORilmNsQOXMfRPfOYT9RJw0C+vG/dy2iOzcEXYfMjQaYSPQxsL+DdU
i62UPMObrjaeU/haqBaDj45zrLjLkqSRZ264vmdh2/zl2Z5OhLFqAb4x0yAXqzXPW+6ce5U1iTm1
N1FxOWVF3pzWohapeFI3jGW7quny0PWvcb366399mj57TLo/aFwLvF2Bbeq3hGVkGSsJMzVK0GEe
raQCcoYJuzPmOd8F62uG7fHMRohjqr9ntn7ulKrCnFizEJ0ahMD8QmIhBuxI8iqrG9SaINZag5Ak
fbSz5cAaZQvb6v9b/qjs3HnRNyI6jbgQrRkzz+vF3w/pdR/jMS1/utva5e1S2TmiFW5Mhj8gwwg2
z/+qJkzt39t86osG4WeCcAmdid+te6//4yPQ7cam3ZdfvDanExCiZubqPvl1nhYt5dr2LJ+AO+aG
l1pClpO0g6aSpZwwWVro40PD0AnQab6qU2ieA3uNsdV657l5xH5ZQojPoW3ukAyAYSI5/zYZTKAw
5R6cFZuW7SCSaOmeAHQz0+Psm/h8Joly6hhqHi8+dR66yBISrNFEWPZTb/YzrioPtluEcSrMYvAb
qNibfXuI/1GhpAg7JsJ5Gos5xFmEytoSbUi8tNnPDXKgIVjgWJIppKzaxeV5ID55fDRz4wKmGkys
T7ARMNz1nB8+VGWZ4VVV2SgsdUpj05ptmet+C/la2McyvSoBPEgFoAnfiTqkmCYVVjoXZ9A2WuDt
NmRwJPzoP9FP0sdgk3eIncE3adcD0k2k44hBoAMIMwrx