<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqCF3R8vkFM5nEQOaJeAvKGvodOsFruo+Ej1DTe6HcObWL8q6Gk6D35+6zPJINkyPV0Ze4JH
oMN7Y+9fvTjGDAErnjw5TAVHKUycBWL7ZimbPI3hWMRIWpaG3bEVTlAFT9xUZov3dny1mVP/V/iL
7flwc+PpWtD2ZbjXapa9YyFM0MvERVsu2TrgkgK40VcHVXZSpOl52rOChkicRCrtRg87Sp+0Tewi
3M7Io2AshXOcXOJ5IxHUYFJiYjQAo+9co8CIBdBhZmjDvg/bOO6oox0E1sxjPewA2s+/ySxUUDpq
7rgEMLalxzLkA4vxpzJOR0hWsu05Gj+4nrGKBo8R3kMFuV8vZ0b6EDmMEANplrRKmRiUr4xxtrHi
IN8AJndxc8tsteooHE1kQm16plmwnq2gzBHpN29yFiqjk6gEfvdkNdO+Sl9sHnJTLPYvuxExfe+n
pdO9bA9ZMBFWbWrhiGat34p0uZa7ImCObzF4ur64TePP+cYapek+B6i2P3GmeKjeAWs07S/9Zye4
bWqe+rGvoXXj0EQ/tQ95wIGghQe+gpVj2Ejiv/GWfpg/E8IAnSiEX89L+m3pdcbF2n66wPBxpGwl
3LLYZv4I8aUYQU0J6jm2qmiP7WCms56t1klh3/8wswudNoxsMjAO0Z9N/uBjE9gOvN4Bcvj/hPne
Evf0nXqnrjLZjhNYBNZoLy6vwU79ltsMoDqoen7NxBq5MQFbFi21h5onCVWYvWl1l9uufkwxBUKu
p4R2pAaa5AGsw0OJemlqDm7bQ5bjJCFSaWw/I7fEwv+5ygn44pHGADyoPAvitUP1QrWClRgaSVyF
UptiD32N13uPuROa+87B9Vs7/ob3hFluMAfLanPTNvamhYQfst9asgVZvx4d5qONmFH0/N25gPRv
uZIdXgiR5qJPjPIEpy+Qrr0hyUeJENjeoVbnmc7R1iEeL4ipRhOYcuWwTLEO6eOStWltuvk2SA12
7d0QvBdL7UsYQm7NMGNBuSWe3ne9JVUszL9Ps+k7Y1iKUTuQg+y181/+9h04wFk8kb34r2VbwQR4
AEepB24We3V/2lrd4rDB39D/gfuA3DcMtgoQ3lnJxHR60Vn6/lcm/A68EoDJt6jDtp/Is4nWJiWj
JYf7x2vsbErsbMWf3WJWcaoZqtnUuL1XHmQ+cqnwz9hsJwwwQm3c/G1hZmP7ugdIipWpt0+9s2MO
JnyT2hymYj8lFIA4ipG9yz8hau9VGZzMUa3JjO2OdBxlj5h9bM2pptZvXt7ign251WepeitHG7An
GPC5LuwH/7vhL14S3cnbKVn0SN2Pn0vjiRowmQiYECFUV5LbeY7PN1fSLURbL2Aonn4HkbaHWJXZ
NgZFkGlIWVFHvTX5ubEm2R3zAD0XJ/Iab80ftCkP9QFNbJThBvJlZooopR1QgHx1MTE3uPUIkDat
ryfh9E/NcUzxr3/i49R5e0GjL96OmdMN9B9HsnfTOPivPKI8Tzyv/FxW2BgDtQMtwb2mPr7zx0dA
rMTurwFMZhmrQE1uTBQIe7fPMBnMUQM/6zZmAkh8qlBp/IARsOVvfBWRQc0NkY/+9N5ZA0LHVI+u
E/ZnsD5QdhdrmLPFpmIFJJLxqErQ1KjEIzhwR1W9aCPy7Tji2R3xmUUC1e8C8xXxUBnET7jrzQ0D
cVtRCoP2GQM1koxC8jdh8zwG0+KJ/uR8Jhdw6D00Oxk8m6Cv+vMnEQWmyusNMNAkAFkn1NH9LMYd
HARf07aw6M1RcWD5TsygMS+KHbz6ViZ0Qgp4s7dDRd/7qlhWYaWUD6SFlqWN61NSsRCfhgpWc5dn
6VGeYFkA5DlZoiLIDqs87FlTBDw6IP2gkuZkt84Jk+NNMh7b2qIj2BTFJJVQRJYipjnl8P3nMNpK
5oSgEiyR3Ds6f0/AQtslXNc508W0YEMRqiCDmY/vwS51vyRL0hw82AWVLFL0HsUEpzXxnj5jru/h
9Eq8eAMwmBXStrgmk36hINGfRhASK4Nf6ofCPB+s+nlDks+mgmLAZWa8huC9fyW/d3R/UCTUlj09
elJP3bSIBTS49umd7/Bh190GwaK+h4WgVIbPFke40/DiEr2BHuz0IszYqWWpQqdbL9TNvcvvDU9D
/+DGJQdXTupTiOAshLks3p7UJzuzSV4cfU3POSBPTKJAtvqxnG5IqIwfRe58+KDKq8LTDSir6FwH
pZ04zGfQ7Lz57/ij9iNrTilUCo5uuypRUtyanR/GD//IyYxuaP75+fuKg4wL8uoBuRehnlOnO3Tn
sn8FT+nPbTn0hOksXznFC3TchPYZUzuKSoZyFJaui4K8EBurWjE7R1DG9jKjuRvn6r/W8Ucdpip0
xHtHeISAHeFGZx7lVbnSGGJIwBtTIQ6hkTc4cUvx0l/EVFVEpYMXSUBEumnSdukc2kdGBwRDQ+Up
IFpzQn6OsHsU3N30qf2aZ+8FmLiSuMezfUnurQ/ZRl8bzI6ddKrB3668M0NQoYs3su0Da4BzMwq7
08nGAhnWIMDM8laE7pMQsEUpegAvph3HRriLCvJXa4tprMuD7TKrneFfnbMk1ftf8GBeCR3oko/g
Ustm9JB0QW8rJPQ008dFMndpszec7BFq2bgYnrKc5lsYLXC4hpkmc0XLcoqPGqvlb4+3YZjDw13m
YIUlzsKTLWUpZ3OxTwVY0DIeQnZK75n3mmF64wBkS8ShL6P6iIxlc415KB5hnBgz1wDJXOZ6cZzm
/pJGoNF/9JuRrahc0s9MlgYF1f8cvbl8nOxf6lV9HLULglcu9K1ToymudsQEY+ZHKCilWW/eatrO
/ZrjZp151X1c/7m6FMkaz8a0Sn3mmHisee/aunyup3N2ZSPMb+/ewjkWmZlRpDCN79XWmIQwqzBL
13atcw6hMUMGsyKdbCfhaXE7Ay/wb//RXlmqae1RicYir56DqcxIOF/YWHEFCckNWSq2vTrG5CR0
R23uwUOjnwB8R4DZgeLvHqOOaizFLJNBK2QdjwyRIoLY5HtWS++XihgWyOrSDx2wS0WgtUzu/2dW
d+1PN4Oc9lhxMy8uQ3SJemnXerbT6dFga9rNbMb7NUiBloZFhj2Qr55WuCA80t/Di0guveJlkeiK
smnwnWzdEBv/oer09sNrFI4M7C+jEuy68dK+dygXJY0kYV62U1w4BArT/L+9Y6KQhV/Yupkj6BE0
EcItBKlyatU/WAaB1wgpAZQ5p0wSo6iNY/jjEWi+wgf5yvNuosam9xanFItkJOhUc+est6tRRmj4
n47uhITy3GTykkFfB0m1+z1LhOPBJMcjxW6p1s5oVCPmpReGTNg8B/bAXlehW5jNJ8d1xlTdZ1E6
S+MWHA9+I3TyIDjyKR5JobrPTehhEs2UFrMRIojC/Fgwj85oDWKkAkWpP6wUkifHZPlO8itioFSG
zI/aejWucPPA/fjG9BHoS5mKf/ykLtzHj4BH1xnkGPqVD2VkOAQYJ/4kJvPtUWXuu5vUmGbJcw5s
Isou4CtYE1qY6Rn6q4u/2B4NQq4E0HRrnBLnuJ8ebZIQxVbzSl8+wgtxXn7igZs3hhrBsHza6c/5
ryhSssDZNAtE+0KMcnS+CpGBgWJThsHYXvGXHnN5g2SIRGyZnx+yT5OqgALOIyN28LjIqT4b3wbS
pjqSbvoUe9HIP5+urPhuE1m77ZBdntf+JrJuZ3aRrc8f+kFtHq1TA/fRfWAoc0q02+y1SslY2sMx
xhUbSKA/ZvcBnDALWJifr7HuwLYVcmqEKgXSNEX7lll/cinSaJiiXnOdLzAPULzhTfKvoaM0k8MM
vhrqa+U1ev6CPBrbdbmAzV/QANpth85RLQOlTb1IZ0ySTKyvKi3JdLXDPCVGdFj7uLsWub1FZNbB
2hdAI329RBxhL8vjEQhHbGtt1/DA3H2DAh2f2jWKkXnn5IYqtQYJvBNvFOqp2z9XSygg4deivTvC
4U7gdunkTdQkz1sEY/njgw3v2MJWiOM5/lPctMQy4XFjfCXzNdVJhAR9YLsAn1kZ+O848tkAcvO0
8c0K6x4Qt+aUDOBUYueB6nLZXpMvDUj0ycvtw+HSna7vTiqmkgV/DWaNuD6do7/cmUf96R5vsSi2
zAQC7whIccjIn2lPA1aZSt1PaRTlQdYgX0qWNqkL3epNkIp7siRZY1mnDyUrToGf4KNXWGHFmYVc
5MEYQbPQJoipiC6HBUx+L40HqaoCOot1bxSMNh+PMze/AU2+7dOdDeoHObLXfLAHPTGO8oiScYYk
1UxOlOybRNLksMTjTpRHTbz6AXD00tUraAcaBPvC8/dTWYaLh72XFHyZP3NPXEn35D7+21721IOz
IniUo5cRhWPHzMMQgJkqx3rRytrKYcoQ1LltTvMU21yq1DtTR5vE3FqskbBuiOApJmnyXa4t4sJ0
Nxe5DQQQYD04AqQYYEdnf7AJTW1pqnVOf6kFOeG4mnKJxunMe7NKgKbGIM4K4llAvLqJWJXqbWmj
71Sugnl+yMSIW283vo2GQTVHMfOnSNZLxAbwdXlvQEVERZc823/kzx7qPB3HBgjgoYLkPd6F4FJw
eQunYUh3G0wnYbvNPXbPpEQCE9SJIcb75hVAq4yUB13tuqQuWITE6ULJlyEjIX6vIE0xbvKf0kdV
ChqqQ0ufvskyYndrBmYOmNb/3BPoooioClna3fqbRdAUIPH6EsXvxnQIBT7kNXcX78IpqyDjg8Bt
wSxJ/nlUTeeniW4hLRUNJmcH7WI7OYMnIZhXRNadPpe7I3/yHpwHfH4SsFpGOIBo8gFuVz4N+QN4
LxmSSu05A2++DlyQVhyfHkVV8KXqqINOaEaHz5Rj6/Plj3ZZhvIjCgN0PtEHKjn9YIWzWo67mC7o
iWJNEi88VMwfdb4DyL/uUz0f7MlDwUV5RWlPiHIbe/MXiOP2B87SSxVXMR05txhL6Ga4lrMQxpwV
lgzucEC/xJaQm4qu7SgpMGhJgPWBb3svzhLqe3O35RLkp2HXaN/N8FnwesVqf9Rrsp+vPnAFdt93
KF2S4cVP6rBnxHP9z7cSLi/kMoUKe9YrTqYVdLV6NGKhvBiCHuCHJaBjc+kZHBZP/zFLFyEFKjxR
s2Yrw5d+nKj0OrPMZ5sRAdFwKYrpy2HgO8GtYWPEEgo2dpQI232CbcKq4V3OxkV+T91yXpxm4kFC
9Tv06QGPRfCjvFpQnu7BdnZsLOl1hQm3eGO+2+DYZHoKC+VZlWi1XrZMX5m8RSYkExXAZIr1uXLb
gahbdtge+s4xoRlMBo+FKRSLDqn1+gVbC01hmE6W9F5AT8OJOZzIkC5oAeEyiVh/hXejhjBeJ8DK
2nUZicD4oWZ5N7XuQ/M8WvDq2e2PS0E63TDpegN7m+MERy4hU5jMfMnhRoU75z2GAHosOD166PcY
Qbf45yOEebN36yyiyXHwpPabt0pJYMWtm0If+mETInU/h4ch3I+X3eFWMGyG+N5B4S80U0jngYzv
NUgX4fWfgngHCEnMuRsRuMUoBmnBYx9AIf7rzCNKwcT0ZkDgsnqq99ykXFmdxMuCz1aXeDAzjOEw
58hJWq9o+/syTaH3dCYVGVCI6AbtPDZNMcj4ESXpmHW1RfhnYIdzRga4rYybG/cQiZiL8p0+qb8F
vnDWoCJS/mAu7RN1pXuQDS53Tdajw/K76hZi9PlnzCtCyTZXZqkPvlKXGojfYaCcpefVFTTlK3gq
C35PKJCQj9FoTteepkqmnwVtzrBBtMC52alQtNy0xvTl0kAm3jwwrAwukTGrU6NXycCuIHtUt577
jNRafa8TQ+wF5wMXe9snQkJhb3bmu7I8hQiatuflVIEUBUTBEmnBMWwuaiSw+DwaQ4iThc6Fu2uF
9oK23CUq3jRQJrReFVR9bwrQ10wd/1RAj4UfMDfyiFVDND2euJxQz8QIv1gO8ebbeAiYTLV9bhVZ
OIfLyzvqwbzBwI70cmB87QWzaUNxxh3bD/q0cbKK2kuo3AiOaO/CgbCUTDo06/olCQAvoCgoYcF3
sGZ6hZbd+SlEjT5+TKAJAM8O/Ost0OUY5JPyNS6xCmYjX2YsZwA+tX8Yos0EFbMdfm0l+s89QylW
WvEHX4JDMbcKbIb7haLxwvG6/JCN0WyvB5E7gEuipJf+Z6+O15jB9mAZ2CQVDt28Lqj7TUlL8JS9
oVngdI8XNXNB7aJ3Xc/txfRC0HOT8WaaTWoh5aR98/ZS82+hUs2eeNLLDdTVCJjPZcLSzKjKb4dz
dH2wX2shd54gEF9y0UMklfiYfkB0s1K+3UVV/Q/u1n16qpIAPqq03KAexNNqq77WyPVJhojfPVbo
zrbpUQn9m5uY47szemxC6vDWGTwged/dCe5VfuV6yIt2o3BXu8Xdpg+psw/WLnCez9RrB8VakHms
0z0051PpIT7V26XZ6zpD9pOd6Y6V/cTVFT2KWvelvh3qFY1eQa3nLrhuPqkFkCq5Sac/hQ6m11Gp
ANV2uWb1KMICNh9vP/8Y+TEuH7vNuntMA08eS7bqWFS3jmU0nr9FGBBWx+2mMmzScN3NBXVjb9d0
ozL15wEj9LDRzA8Z2lP/TivW/p9LvvPRahdxkpzpHqPnkeMB6m9L5RlRyGgIy8YagK5kfKoiy19A
ELxB6jftEVbJs7qKXZMSN0tG6WOqYxBSUB3wQN0LdHeJnT3PDdESl1OvDEiJ+2oJw7xU6F45AW6Y
Vq6BTPx4AFsxEMwmUjZ8GR2Ytl5SSbkEs7xABWQJyRsZruSvykm1u2e7hk6nVpcRd69s2ie9S+0O
jvijvia3ZNYrgpPNfPSk+JIWizmiNgd6dMq8MVDT4RUzifZQ3VdTj42ouQFHsYWPGWwHl18VGUqP
k66+gSGDRtuRP0VFi2eZ/o3ax4EvTlZ56vPsMRLXirz/nCzAcEfuDDTyNvQ5+68HcyKiN3gYO2V8
NNP/9hh5PZ+2HNpj7+Kun4jdeU5k4rXmV5JWTKWcWWgc+0lDgYheJXxRIEHiXXruD6OvHrFXIq2q
gGUXNSlhuplt4jPK/6EapjtpyjDBKbh/O3JsuCyqkVW3n6IFWN4YJkfBz/QERv4W2gWJV+Pioih5
8FdUynuM6Qozi/cSEBr5hnbIsm6PgE3Fgnpf5E/mDH5PTTd7robiMMjI9dodHkhn4+XyZGsudb2/
cTtsJtUmMwJ00zjm4AuN65uYTOgg7tb+jLV4f+d4bpzZ5EM6yDsxGfWoMQLT4wW1CZbglc34sUrh
YuzZ7YMkgmhHKYxnnEK3j0n4EZs2P3AUnQMmznCc3LlLd0q+94//5KEj2zrviWqLKSxVue49RNUP
EPu38wUJQiDNlQzD9HpQZuH68yn3bEyztznLxC5xK2t4L+PamRgc3WYgVaSkGy2473YAE6K+3hDE
jg/tOTP+rOiXKGjV/EdSJpyK7CKguFkr/mZaxYn/2fUCjD8IE4Ll8yy5q4EfbZUajChcFxq+utAA
CEB4GCL54FrZFId5+eH5mo2lPxgpfHsKpvP4daIRsoY5gkiWzQoGgSc6UOtRr4QZWZYY6A0avGMZ
YEGBmN9F8Ci43xdudOwZa71Q34pZCjHrMdG3g3at3kx751vJ7bFh8qn5qFXDeHiPvQpMJy0MVXnq
vvsdkABJtA00MTusGrh4m/9PE4cPQ7lnQZH4ipIMu7fD8/kO2bJO3ZG+NsAGbWMv50Derjl2lzz+
vfN7FcqlxYiXIRZFzF83N4QGLjyvEm1QJVv/hmuDmFz8Mj34+WhL1b7f4GM8N+9UoGyIKoD7vXoQ
uBnJLRwmNhZMDPR+9O2q109Yxs6LQExl8wkqdca5N44vUPNxu77DGMwwU2FziW+kb7twYp1nnW/h
pLmuDJu07j2gnQsW6nYJrVUxMHDAmU2nefvsHoQkCwTZuqHfFdbtPIgxy5mI5cPwEonA4Ao2HdYa
hTT+ztXMj/rEHq2mlwxutSXGG13f83y6LaE2maOhyWteehl3Wg7FITLhXOoKtio9SnriciOXWqr8
3nLpPt6GHtu34Z6GODlE/eRuO0eQCPELO4l4tdNoW24Do8AxIV/IZO7BnMUFRVcM/R9X4kIfyuFT
V910XvSK005mYpaB7imnJ33kOVAqfKhNHugU3RGdAT8BMqC0Ve+Ji+CFSpwDL1XMD7Mizk0GHhnt
JR7mjeYTXBSS+9iktD9TJ3BuMvwz9n/7wccyZ86NklqTebjwjb4fwlJ8qaC+c2y1EJdkzMtoNWqP
dSA9RIhKAHc4LKmbel3YpJqOIYDzsINSv3heQ/vpnpYimA14wASXIDM05K9KLNU3IMOL4Qc5+1dS
kCerR1EDTVz8iV7Rj9OCy63JfHw6geyzvGCzG7tta6FjbJ/5IVuzytKqtKwScxZ1haRC859mvDBw
J5DCpns53p0Ehn/N0mt3AmTHmlunWgnfN9gGDkI+kabduwopGwUn5Dd806SWxdIl7XqLY3HWgdZ7
TkKgDGchfPn0RI/ISgWjaFbvkwxOFivCdPuBWyWQ8F7VNFOg7hKfKinagObu0ldL1whTdnd9II+2
LzQ498YCaXJCdmNuHcOsz30QA5ePMqwoo1xmlyIeFgwxqzsNA6b6HR3Yk1le0sa+agSinaGI8LU6
hfSbOmiVTyvgM1PoUuGux5zAgb39uRXuC6MUtOF9RuGRvSLpgSp20yFfo/GvT91MiNedzv7FKIib
r5VBpLue60qHXs2/bRe7tugQaiZWkiwUHkb8s1DmUDOXomGTe2Ed5phwYYAYFzW8pCqo88Qol6Jc
U2jHmNUMwm02myaas5ONfikQ3EEHwCLXVmltFM4rjsmDVSqWEQlrHiuKKCT0illrsytqgGxXTJ+Q
U82QR5eVuCy3ugwFBPJcXAFR9pEXKaXtVpFFQrRkvxQbi3AJZn9L349OQEdxAS6F4txkOVJzojOc
Fvgto7+rylBy3GslTcpjlpUbpqSIJCvQlrFeMMu2P9oSxgfn5l6Zuyf05Apyx/D1j3Bnazs8OPTr
3CCcGwKDclM9SIJ/8WNJxn7YiqGYPhTWalxOrFGRUVubrtpvKwx5cMAa4ZAnLAzo1mWL9GWX4j/7
nLmtb/wB41LCgQqk6fQZhjS9VumkhAH4hkUcWh0BiwqL88hhz8PkUiqRXc//j77eYtLVOfq+88m/
9Jl/EzdgLi7GU2pjp0EM2ubxTYXvIQRWnFEKPt2me4FGt12cytCFNu2SKsGWVS6196rjvBrpf04D
41vl3hBgiwgJp/9bhvBo+1/D3gF/PqCEX7O7fowEhj+TNorI+X7gSFXrt3Zu1JGwn7YMgheiGs06
NBqQLP1N+sZSiMhuBsTT1jvASgP+9gDYQfXs7Ae9O33P5ycR0biNSa7o9Msy1dnOGdKu1K4Jzicj
SnaM1A03YxXbgFHZn2O6zhQRNpNaSJJstnP97ZkDT1d+3mhmawj7vEA5C6K0A4cs3PB33om6/Fqg
TSPqNuSfX+Z68D9IqIsY3dkAkdR6tdXtFQTQ3lZ8FG9hsrrjQfyJ+w1DORAu