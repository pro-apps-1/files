<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqkVy2uU8ia1vt1b3PQo+p5aegLhDq+yECIPp7IcPPZATbP8Xga4LLk5D0AqDwEogYtYH4CZ
sA5s4WOOa/Hxyh1zn4GPL4wkR4PvFp2+2ZsOiwazhPd4LWWkDRIXHteqaLb+up/Pps0BL3POYxVQ
adR0vvHu9xmm7znMl846eWk6NSFc9TqqtmQelF8fzQs0Kh6LUuEBRDd8PiU0Og2AbBfKEeCvBGyI
66FLAEAQuZGk9oJeb1xt8M2vjEYNVEOzIDxMlIeADpHZv1ITmSJY4lsWpyF/h6OD8TCBh2cVz/7c
qe6VG2zCdrzly9e0A8+ruVIg1xUtkqU8wkhipTnqFvRcFmmFZOShbWLOgBUp9f+9xHmRWO148e5L
L4Pennw+43N5peBGbpK9W3JU15PZ2w6La3ZLCrt7U3cIxMAamtEA5PsnvcB4NCDDx5bke0VL73Pf
EO6jVM5rZiJ6muVfndN3vPqs6pFNnGWid2ziL0MiRMe+KIxTiEk066d7KQ4BQZ01IfSkydT7Uvic
XsdtbZA39Sh3Jix1ZxY24dC3P02IaoSZIOd6yWIUONJom0sTPHH8izcLHENvSOKDaS36o9znHdAi
F+x923YXV1qo5Tn/7XZxiT0M1dr7uRA8BoEIDSyMpK5YL2hG9F1R0pSt/pqAphejeUy3SdxDXgkE
s59uvFfdI54TLsG9spWKUFYkUXDFyRAfEGDKQaBDjWkCEKWUbv7LublyWseHmkEBmCgbeyGBN4YJ
3H9fqZkeEpG9QvCRi5kpOi2TnL8gd8Y/fpjW25ihp8mrfKv6i3dLMk4QHXd9nPW0oVpRXtow1WKb
mVESEUaHrGV0vGXkLieXFGn0rOmKMBQoHS/9r8BJ5luuJXf4+AjwPvjIOsB500csYgadnLdPY9uL
7PjAh/zKb+85Me6d5NAu+QbhkmHFxQQJ0ypLNWPpTYXebNRMCrTDL4+mryHBAVVRe3rbCP8uJ7nX
AlSUFg3OMbVuqcMFVs//x/LAgLweofeHfe+6J5xLLfYzM/c36HFO71MZPWsmudw+FQXImpZZve2N
g5uWKnuQ7XpFk6Yt/Q+A0Rod0NwHi66t8dPqAv0bzmU17boRCSZGUyJpn7QWxDAmVfkGpNQPwNBb
IJzmfnBP/fwwjRlaYIRFogcuPBeCnunRKtbdZGhXdgnFXmhN4dIvqHQRD/M01S1va+j+p2DPTptr
RmiAJq5ff6zf7qu0M0vZyH2wvdmsDjEtCK8sov7dQjKs72EYBZ6AfQQj/GuxCIS1qaR21noJ1pxX
MjNsd4zF3bD28lNfld3HPr/HY09h6i0+vk+f9nAZsojzp2sbWsMQqZjKH32MDV5ltggmX9QIhgwi
PonTf686PE7M+lOOgzKkQWUK//8ZCenm+sAmPRrA2443p2A4AdsELauGnfwo3B3vAffIZwcL9bPF
T3/onUaLDA0rq+BWiSZO76sIjYxlL/YGs0HaNQwnjyLM3w8J2by/VVdicLbiQx+wDXoWMD8jQBHn
kNJAESO5Xp+TVOq3Yqlvl19dbbdsUaXv1Ex9fWDAtFLnSJgMdyYkTYz2uB7APXa8T0xpivX7HlEd
FjzdAEgjgV+b3Pq1LIsJDPiBRCwu1PN8LscqwvfoG8k3xeP10EMngjwYy+hT7dZEYEOQXKvk9zzW
6cULgt4HJcZaLYd1VElj8IQaO8AunRzkuYDvVkIJI6pcrPmiq1+NT9eSW0HoUK5xP9wON3leKzX7
Bbq+klKmRf1OReiGYZFi5Bw043s/2UXKnEGs2QMy5kDlmViZnl3CNY3rnZrE+qxzvbWts1nFko87
afuYQiGVDb79rmMzlkT19r3VAAispzckI5uaKVI4PBNLeu10enj+GRFmfpl/f3INnUv8kkmctZh3
2JyoMePa+2KxkHBq420SORynN/cuhK2exToJsdBbu1N+lVGhTFyDzgwRV+1K7xClrNfVoh/2ywlk
Nzg7rleuEojemjDBJaxaqKk4sorLY6wEQYeSiW87qSH5eySk9+u6NxswaI+fZKtHJlubHy+ej6y5
1ZT8BCAFAcijA7/kxA95ei3L0mQjtRRUla+soeWHkADfff8ujpxGUYm8MZhbtqUveg0LlySJY/1U
DJryOfYzoguX+v9Ny7t539BOjRuc2NsAHN63GHq4P8wAlJ3AG+KR5gqwtChN2q/sfRUEaArDdb8U
bJzbLVcdcvqhzfOlMTTMBL7kusb7lCTzziPbsi1CRm+c4xpTQAlbilbiG2sO04eKf44sFoiBHsJZ
PqkwtrAHSc2lhu5tRoYVFIZ7AN4LSx2U9QK7jmexc76HrbY3Z8hvqFNDwQ97NCZbW9hBLnru453u
UjSHUyIqxvHBxHZZrSRC+mhOQ9fvpHzuW3SaIM31shhYIqUO0HQEn4ksDx9WuFLRrggGg2XmFyWV
e4z6WJOiw8TQHF/RZ84ZCHP1qze9oeG6vIU2IE+zO1BLIb54pkaqcBzvcLo42PaRC0XKeZer4ufz
7Ys4mceO1YvtEcejl1KweM+Nqud36TSpD3BcRHzbND+ZIvzvaRCJHBZyxdKQWEDWEB9M+3uIbaf+
yEYBE4dRDoqeWGOHtaq1T2JaniVPgEjU7im+SvHSY++IDmM7bfhQoSjEK5l9+xLhWPZA4YZKHMGN
65CScBnB5dP4fIwb7X9fLBsKugNftmA9/9hWbmYDkQHWUEfhtN5W6sv26I6sDVVbNqT0wMHHZYuQ
3RI6gpiX8e9glbD6/ofWWUtpwaCW6FMvnMhysNIrSUKNEQKn41mzVjmvi8AcluWMJQUUE1LV7tZT
xTd3T3DidOAKZJrOEA2ePr2zEYttcorVSzjU4FCSt0v8JQz7ZZVQc0Aa3iJdfaMH8fPel+ltAAUT
6lniano2l4CpLSqvOfn+3hQQDk8WUo2h8iNoB2P0m1taxxEyqybaTPi4flssJfPNrJ18c/GdtXny
jLtt5DGDkxp3DEoaRVrSVJATEeC0Lku/zF1OUAIcL6siZsCdIUI/KwHWg2MJgbjFaUEooP9O5PSa
9AVuvTuUJOjZ3Fh3fapuvoGpgtJT+JgDh68acS6mFdHvtKsTht7D8ch/X+TbmfsfiadVpSwpMLfn
+t7qGS4jvq7Wnt1flDhdUGpHgAZMCevKi56UZP3jE5X+3nQ8+IJgTEM0sfV05nhoSUbFdLzIgPyW
7rI9ptENJXgm3CEFCXYrZGOxC0ytBe0sMFvnhjlp7IST6d41LQn8atrIBl6UestKxhVkxMNV53O4
kDjamhfnvoNPzIS65Fz8Nx+ZKcsw/4fuE8S7TJCqGcg3PezPrDGTFNaKpb6z1UOaYOTp7tNWr+5U
nd4FLmkgK8f2QFfLniFvvp8zZAy6sh5fsRNFQD+fm3wpM5zlAEsnG9JXQLrnbGDVAsio7qYYVkhj
2GQa9Ahe8r/8y1TmRl/7CYBllqrY5MQZ0RzkreL8WXZGoAtDOqVkqE8UURjKCYm7T0H7VCs+YM0j
s4objMJ5ZE32UKeCwbwoDJXi38sYstRg/IjtStqZBBKBJR9G094LYjww7F91EyJRhTi4ZawBT3D7
INJx5RDCmpj6xnAhj6fSn0EORYwUBLg2qTmNa02UfS7cG36eTn5wMcaTktn5FW3L4fB4rZvemayg
emo8rwc+hKmwBBawIbGbGccNcpW56jIH6qwBdgqjlv25mz9I122kL31Ger0S8f7x70lD5CJ3514F
h/d4SLQIiSfbmCUJ3mApuLGxnhDqZCGT+kEQ2oH9pHkwgR0oaNDT0qDn3hH2Q7Rkx91yLdw0SUNp
aGqeRGNL04zEyvS39BD+GsEMNh6NhMs4WfvatZaSXd93IV1eQycs3Bi6j05OEu7kDDAYp/aQxgFX
M35C84DepW4Zh7nb4YBsPkvfAGYARWR5Aalvb+MYkxjXL9AEaad7mGpcVXUuvU1iWJdnkzK4lvQ8
71q7rnv2v/O5Y9tBJtf9wDnPNYaXVC+ZyHPQ9hu9ddzviN25n6QQUiVgbFGgr/Jhu44uQ4tBG4sz
qhD37RQAEcpkJ21EV98fytwhKThXoCigFGFoCB3IUdBdySHFeF7SY3DMP10wZiJpTox3+zApLvNS
q1CNLiFbUi+eChl4ykAqI5YeUhfD7rx/QiYABXlRAvK7FzRsXeICjhF1Z+RP+A9UdZzWWlvtfFOD
Xl4LmdE8NGECpcLtc0zSUZ4f1aUaWvRCfPaOcpDeI/9RP8ZjwBiF3BqGqhnviN0ZmKQgIJxGth0c
GQAyFL7Slpk32+kCqOX4B/gl9D2IcXqXEltXsUB3YZ0/y/H6Jcdl4/VW73VFClEn6mZ3kwyrWfWS
ExLUbTqpzzsbuu9PzuUCXWOTHc8f+WWf1A8VRxeZbMYeThVCXwKr9sTOqWkk43IncTq+E6RCacl8
hGIh/kWvCvAiwcVQf2dU6Jy+dPmJO3VKD5YgxLoKjVQMXePAuKPNAOqvtTQ27i2TXffSR0KbXOX7
38o9B9CVegarFXMAl6H3dxWeInjAyM2E28t8GQLNdzYE4YTyzlHIbYUfXVaGE1QAhbsabNDj9GkU
I5bfh1T25a+sKuHMSZe3UU2kuhqW9nPAgv20Z/FFw996Z/UYs+ZoGSVhNvNkURe0cdYoRk8+SDsp
9wJIPRJfacKt+PLxe1yI05Eu8WBrEVCzoCoB7U6OIezAqNiIUc+CqIK5PkBx0TY5c1jVPI8TYf13
vqh1ZXYjmqJK72fSTxkUwboZ+Di9/TFyFchMRFEo0WoH220uFYhvJZfw/uLuYs4GJMx5JErQT0B6
wjaXQ8U9WvaKgmiohSxrbhaxfCWsdWrRrrwPbszJROjX6my/e+io/wVt1il2ewlK0ZesaMhFttOC
y+/b7u57FdhXbK/aaX9JgHwVQiUJt1vIqYUTqiX6M1C73U9RUowGbTvxw0/Zi70JQP8xfU3dY0Sj
dQjXgkskYVMWVQwhnnes+HeItcUXDRrbtLHhGaNXv0OpdwgchV7IN0BYwWjQwiWQnMSXS6lUbBhp
eGAV8pg/GRtQhrAkOuGPkvu166ZBS9GPyJO2iy4Mk8KHvv3xtCAN3dXqhOz2V2fHI00hvkZrqzID
2JvY37tE1ZW4HPQhBXZqf1KVsMeS0b2OPQuHJhxv0fMPLxHGE8tp4cqzx9z7QnnEA6AGnG8uLQFx
G+X7WbPenLmZxY7/czeoPDlY+LAUyZ8Y3OL37HxO+v4o484KY1Md24OLfJ9Ct4biH/IEwJKxHGGr
VqCKGKuEbo1R1hXMqNhThQCSBMTz0pLVVneC7QN7hqGGHO5B0QooT4QdqP6g1MRA7n8YbyRX8Kiz
RpkmQ5PitnyairROKRhJBEtp9DqJyTEkOu1DiTzdarufLTgydwgxGkyxx2mOnTFy34R6GhlBHEJa
Pyau5H9vFniRKtDud0EkOQKFPdYy01Pe/hY7dt6RocntClN//Tifn5kz3MTrRABTaQ6kdBOBAHvt
8XURdAC+4rSWtWX8/JG2JjA1Y+P2HDilaBmYGFVmDrW+aA1hy2Gz5sRV2R6+dA308cXRjlr3g3fr
5u2FmYjvbCkWiuxrtAb4d5VQ6OTLk5lDytd+7q0bGZ3tPIn7a/RvBA3bm8H96dfJLC565MPukPRT
U2s7LFUlrOBv2/chjm403Fw56OhrONc1HEn5SUoNUZHRdnNcWoC0gB89Qq4aanX9X8CuP3OJTClo
C/65zKXqN7MydoIFgumI2554kFTkcQfHtWhVxJ8gfVls+9QUILie66bn7Qd0W76jJM14y5FN2HLj
1nG67RJX8AgG4fGvUJieoH5dswDO8WxMM+BuACdEbBz9Cm6C+Mm4yIqqXWA9Rm3DrSwEoeMimm4Q
nPbFyKm78G4Ra6go0m7n8cS1fGX3tWutzbIcu1GPsNq1vjjeJjo4dWrf1vp1ID2zCblCBIlZH9u8
oXd1U8GgePtZmQfbQa6hDO4ssOmZ5zp53wS+xkrp5eZwFhkRaONx9d2sLytsPJZYVt27SgpXc4zQ
7E4OhxNQXFLOXFFylQqu8dL0P050xKVq40fCDAlkji0MGcloYixgSOBDkWtzDtNUk1f5/6uAokwE
nE8Oojl76xY5LlUgMcsruscdkhcHMW3sUtPJo6ycmN0j7eB9EOKaT54EvNz3oFSVHEgufSAzkJRA
+cxfLiq2Dv0Cg88t+n9hB1DBOGTT8ADPRBHy5fuYkuM51hm5p30WtHQ2Nvq1Y8OgS1nFEGXVpdAj
GcIgy9ceOXbTtdlhuPlqK1iHWt2PyfwjuzQhe0kYiKmwWcWpXkO345unYWZaADA9tx18JHi4Uz3Z
e4aLNczoHshe03xNp+Olq2qbLGQOru9bTws5Hsfoob+WDmznx/c3PlNQUI2UvV2vPPbV+q7mkoTN
eSkO6jVg6LlB9hus+GNVdELlweO8qIsbIT3avxTEDNpS8ETe9Sa7Nm5eUMiJ31U23O1CXvkNx/UQ
aomwLTDbwkDs1zXC30C37rPvn8dD7ro+biiSOv6MZ8EB6m5bJN7Kbck1FIj++xvoo4qLHmPct4rB
jCaka0ArVA30E06N5bzUFNzG8jkOfKajeAqQ/hCq5Qu4VuPevek2fkByy3aoLXvryvXzvRZdtXS3
9xRi6EeG8C//DqezrFi4APyhYedJHIC4Rx1bSG8FmBXEUaI+EN/FvNMnTjNPYBqXd2Gmb9kH0htS
ldwNGH0CrhTjI1NXVLcZLQzYZqk+kbzamXaaBUfVuW0oRMOgW2+ucOKqaiJGQLA4jGL/4aGi42PY
GviSOsWApjlZZ+EwqDyL8AIne+NgzhDhhvisEUOtCvIx9STchYuJMbgNymeVlRBx4z5B+zyNkCa4
dtSMcQLuTXO6Cdku9xNJeaXT7ShA1Bb5bhGkEywuCRXn3+lup7IotxQc2hXYN3jqdmdTqiK5WmgC
zE0xLtvUVYtXztgp6E7Fw6k9/q9E3WVtldtXB5/8FHYzHpCH0SJAYzgDfCLLgWS3LgqkH5ZfJg26
H6sP6bzbVl7C/1PQCmuYgsA7Hu34WTXfLO6Xp/ESG9AK7Zrq9JQGTa61YcNdOWt2iJc6UpOa79Z1
Thpb9yV54s9WcTQWTPsL0h+7uaxenLOdMymntd+lQbQvPere+NdSfXZ52T5Hi6IntJ60qzTcYO6U
22vWyYGj5ZLB5JvvZStqodO4VMzlCUXhgQS0+sk7PYr1a3UskALSsUq25a2Cf1uM1S9gA7gGgUly
DJQRHISjZU8X7U7zqWtzoRfFoQlWRreTIdQmmCHT1edn/6x7bNrrQdTXHeLXhBkEToyMV2I933Jr
l3DF3BjL9Zsxt/BGGTtCsK1wID8ciaOjPy01fhqKWPREzzQrSjilOQnjFteSEbn9Mbbk2CJ/TtBc
up78rj6FRDaaW5ZWVmKfRMM5GMnRV9iLxl3fUD2vGOFf0H8H9GAn3dxpIv8xH8fzQqFKfNyftq5E
oVFZry+1/b3aTXky996W+XgT4Pd0/KN3zdPxaYTjXU2zZy7zi91MjGFZKzimlv42xYsVMx93iOFd
rkCVYsyMGwZvR+2mQefY/lK3a9UmnlLcjGp8BxDyIYJBkGbsDClNwicskfMqc1jX5sBLIX6+yAiB
K+LXQry1T7LGH2KudIi8zqCKC9GTMQYY1C3fCanEDXZGUC7Amdboe8jF2w/j2IsYdUcrlQH9h0c7
xGfuQqvDAXvliPIRBiumvFzT2L5Qv69Kin6PfNXKggFR+iwn3WqCZ5OpTWCwVHU9FVla0hVfnsvV
shtM8EQlHwukeN6PjyW+ctltsWwHYc+504Vo5l5MpG96thz33x3Bo2zZJPLflwwCvkCYtGk9eo7M
hchfT2UlVnAC31qo22uQjKIebQNCwUFfkwPc55X0OmWm4oxB01octaeLq88+ylEOfEUFhxS+2hsn
Ozh9b5hxVcAVdWDcWtvsgif9E8bt0D5XfJvQVDwM/AE14hx4Auc9FtjEyK7WTdBi17x/kb+k4iL5
7iQGMPDClAvqfMHaUUtQ5VseXa+8pNkKOhgbEPUjrwP91H/lB4hCaz0KmXG2iXjrEIc3Xm6M0XJ4
Zv2paEtOP1OBYJ0/315DXAwgiFtqJIApOVTeP8M8RXec8r4fNU5FlPpd625rSabR7n7k8irkoXWv
AGPr4DConpWi1atNH1jLfWU88vax9gfUoswgpPGzP6TVSSUqENU+kuuT1sx/BbilW9IMjiVd+QBx
BFYVyoomh5MDcLwPoQvKFSG8Zt8Okf9mRbtEGAWEQWIUcSORs9T44vFuWEe+jLqaPKXqofhmHnFO
T0Za3+vAzMt5C1Mh5K0ZUOua+E/eNKtUxZ8+BoO0dP7LkpLVuxGFKjEldKjPjV4AOqjIz7IlE/3O
P49QYfkFM/gh0iOOsxl+eYzHLwVRnpEB72pXpSB0pbn0GoskyRjx0gnRO9stPR5BFJsilDg09uZz
buHx+NQfOxR5MNRijL6+XYGlDtBagkG1wV1f0qaNqpOxApfcxnU0ZCYRvHewMFPLdj9KCdumjvxt
h40oqZUWsMeUE9UjwUPVD8mXM+r2rZ9o0JJ7nzkcfYDyz8CxITXzMq/6KN3uy9W1XXP+8y8ttFIO
8EZQN7mFvBv0B8+LllV/hItursGaxl4ZnS/443eZcuoPqP9TZLVlmkLOJ5Zv2U99qopas5WnVLV2
x35tLvRilq6ycTtxzf7lphtDe6XqEuNmVf7+3oN1tH4i5SUyQEI7vN1OCdPN7Z3SE9BVKokv0eEP
Udw+xB7o/U6+cLlyBy9J+1F1HriXD5J7xKjo9i9RjWo3YrkCU37xNseIjJdX9NrA70vVD64zWKn2
YtDMJrKM1mnzl0H1X4C=