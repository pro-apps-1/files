<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyt4yQGOPigBvInaX+Dv6z5uKQEaZhWFwFQYQezl8b8JwskUO4vGpEUFKQ9rgFR3OAqed1jY
MWXNK+8ALPtdh4qpkFRIuH1V5gfk6UqDuteRFcOCNgXDgWF87faj96eDZA0ggS3F+6NP/2ORBH89
wR3ZU2uulhImN3ZUKMgWjc33Pve3DTqSfcGsIIKD0Net8xmh+Zuw77H2gao30w7uiR7rwSW51BBl
Q1eV4K/e2MVPPiM1E4DdWwK27fQcdHMFXM4+D83yFzgvkwkOjFcu9tAV5djWP5cPxyddelGXApqh
Ivh67/yAv3D5JYsi/SpUzvPk8HQmuK488G39SwPNp9xmuSsxY0291Y1G2vhdYEOKAqXKMiG1c4Lw
7Z35Y/zI+INXaOipzWDr4W2nfMjI4z0YopjR0aZGPTwCRJM/0DXNBN7TvnDhPTzazMON87SocpXb
twN+0DzerYRuOiSwHNPh1ZR3bYesJonIeXUaH5140PeiXDE/Jsdj71n/06c6TB06OhMgAeL+0CB6
d0nhAUzsR47OzPfr7y19cmfil0rL3M+D9y28gQP8s6qt+Entf88QWB/D8F9uzEZjE2V/Cb39hGUd
Upg71Uxa+/M7a6rLgEPUnIkG9A/QnDKJV5cWRr9dnIDtviA8KX2kr0YH9SiXLxfDlMYw5XLiMmvb
otzsxrS/dhLmkl17AV3NMA3/BWVXLZwJgfGfVzhp78QfOapcpID87101XSI/qObXbleRA7aVaWxf
PErhrZZ6syzuW+apRNmjdJJb/0nVMnwfVj6s4EjEdijOURhJNtZcD0PeLRh+1IDMqGp3o1/LKMon
uLPLVFBpWRkT8LZphZrH6bhUCd1GoZXofHxgRZHsAtG3hnlSqwD9+2btA8f+qd8VvyOW+vgyFXHU
FvFiJjDMeA0hBBbBd712ZL4c1tiRQyeQjihrDw/ZO4cNqlkfbojF6DTxeg2keVWU+S6fpLJdt5nO
V7djEKjKGniYJGrf6XacC6838lj4PTO2fHoRt5Ic0Ojsz1Tgdh69IbsTV9k0OzoFAHWTjvNseoa0
JKvBtN6GBPP6z52noibhM64veRO5keULnp/5blkiNAN9O3bh+6q52+rjwycoQzF1W1XE/TrKCDW0
MJVsun63n3Zap3AXjVYdQhZsRx/AkfW43h88DHC7lfkgLkYTMxyDr5LpGqDUY22ZEDqULSzjuIIB
NkiBvGHhf9JwdOMaGy1g+G2QLw2hK515mY6WZvSzz8nIM7ZqiLo5jnLOhedR90nv7NyQvPrf8Fal
jH66yL/FuCyLyqnBP/XdMIb9k58KoIDjcVTZkKI60IsnzRK/es8e7Vzx/AKQ2Ui40LW102xne9/G
9HSBbixqSlhWvBBdwB+nhaZYvBqTxCr6rSQSRx8HTTAcsvqZGpOhGTyFfJNXdg2njSrkPXyvpUGU
6TsA2LuKe0JpZLYE4aqr8B87ymYeGqFeUDNbMHwqVR+HHdSasTyU1BdEXLTh/04tCDOnYUqJOUmn
+hatwEKMddb8JrWQ9DcUaESRVtn9PeizdZiz0wOrtqSgUbjQAMG+BBeuo4q1fw4jxZO0huZlKUSk
B66MT4i6ddRvRtDIrtkxHJ8KfO5T+OIPdF83MQ8Y3/W8Dtg7SPN/9l3ztr8RTLi0rdcqFxQvx9b6
kzIoSOa72S+i+OKISxJPinFuk2OsnheE+518FPFVt1BJ+qWIcasNa8VQ9Nb4L6Tl0h02LE8eb+Ao
oc+nG+xz1CShGQ48z6LRA8tki+NANysS2SZ7kPUFlSieQvZi1CH56+LEtsTU2VQbF/H6sWYXcEyr
oq2M96ZU6b7at9v2pKgIO1U8GekDgcviMIX72jJx08JUH+yTre9lMl7705rhzo3KDRgNzDKSJnu3
ba9JKzDUhEaNU1udtAzblvvT30qsEUN5R5ShCYFf31JLp4jPgMYirD/CbDj5+Oa03wSuBbXQnnPt
4OlIZXc2DiyYe33OOAWcLttrbSsw4fmBgLWodflolyK/4igQYKcgP9SxIGBdCbsHhpyHEHMazkTr
XMNrfKK+iBJzBkI3scdaMytco+eoKyqomVTRRS9cRIDGGCvDNRuNHfx78Vp/AriRlkrlgdGkm5AF
8AYelC7AHDxZF/VwVoksZSU3txKN9lNP3zIHm5MXwN3xSaDYLokuSqpT+fu2WXwokzRQQpiRhZdH
4yPF4sld/71ofIPt2khni1eSwDcT4fseCMqIw15RkrPHSKSjaAfyMNHVx7WULQQet4jrXE9TCoJc
dxlzVXaPNUfiFgd4FlUMGXJlYsosXKiwLQAyK08R5fSOSDZxAvifj08J8eYP+DfdnTKOvEXrscLT
n8ipK+Get5plCy+ujIZl8O8CfFGmK1pkNBty0i3Xzsqd3JiArrjvyNR/SQTvdn5NGp5MaD06Blh8
ScWjqfgTw7eS3Y85bya9UA9qWpdtxlw/UZvjlXBiSjQ7WhBftitHo0IPUSQ6A3Y9la5i67XaeJq9
qx7Qf/wwp9XK90Pb6dR6vZiJLNgBnx4vhEM5c4QQCG1PIz9SnxpBxgHzdoXcS+lBv3dYRvUss2S4
LWpOMcH4vY0OHOBzLX5gjWmjp4JvBUVLBRBjiYpd80CDQMv4+N7fG1wVbPhR+sozOAjw/nDGA+0+
/f0LZTEE3W1Xl+rB3cgO6tmfVgI0O7bcIXaaQxO+/Wec8LOkxtFDU6D+lfT6O/hoFwT3YogEWlmE
sM5I/yohdGtpR/KhhhbAQ7EcgOKGd4z0gwfuI6i1M8+1XMjDkTKSIC1PU3926UQTFjp3EkS3pP+e
dKjpZOGvs4S5rHk4wn+XVgAVmo9c2NUUho9oUZMCI+pk84N227qAEudx196kz71PgusaEVwQ6h67
hLlq2479b4VG8R1Lgz1Oo7niYRZlUa/qXVFqHHfO4klTPoLe95tsRzXtsPecHyFig07HGIMyJCWD
e35W1+pQaaeMjBu5mDKBOiQzkdLB1F5AwVDD+EbUIXwSXQe5JleOn5vYDg5D62FWAPQrglJWU4Ts
spw0BBhlCitHYYLIc8LgWoENQVmTPEIXTfPHvMcncM3/eWHjrtS53mEfAJTlFrnuHvzmOULVLprf
Uiz+2cd8zh6yqg/AlpOgfiqEIe9uQ0V2eJhZHbtAxly9hoSlPj4Hm5txukTl6hUW4ZvqaObrZBtl
48Osfjj9OsbIzpMyKO29qmdvuvqKEHcDQLHSSY4TxfUKTi5ZJSSt8vCvkThzKFPgaebcJ2u8pPM2
VWZX0ibIjoMNJDji0F3DwkQBTSOEqVIsIC7itLM4dhw3jJilxdbZ8DwpunF1Y/pAM+VaXSkLsBGz
n1KxCLLxiJe5LIzN4RuqNSweIX+4ERBiShxiYQb6KOWttPsmY8hIzbAMIkpe7tpNkvGupIN/syrp
IYpV2smjiogdVI9ehZ4Hvi391yKN8gk2CBAcaZ1mW4dyEhONihZV7TbQRfvD5Q1RRm+Gbt0jUdV2
OR2ZdekGllU8YPo36jvtkQCACGugf7tb7tv8yiDIBs7ylGm2GLV4YxgtHSKhVKnD5xMBzyd65YUB
zNUIr3MfmUis2qBodtfeiqEv/xGz6AJkDwtsB9+CR16bPrRTH+vo2Xn9GWxZT91o4rpkp3h4Bp1c
dzXS83gA0DTgOu5ZdC4fJC+nQLxE2bkN5VHNJH8p1Dxi7AIwBswDVd689pD1EdVOqTzbBvyAMgWa
4j984u9S7zbmfxxzPkhxBBReYh/gdIq9wju0JH7J9tdO0aaSu+XDA0OnpbG3dKouUx/M/wRGeu+N
MorfOwhunGXBtaF3p7TO2w46AiBPdCT9dKraMRHrD9zNVYFar1Y2nL017sC35PlM8/fi20Egnrtz
Da9BOv06LnALb+5HbwgU9ApupjVwsqxoxyNDNS+gM8MWLdDSwfUJT3LH+fZgv3820oZ1pEmGw/gz
7Sn8gySYT48xrum/6l4zFT2qXz5IZftxi2KImDtjochzjoOcpZFLJm9mwyjzxDUsbLq0Ifb5+7ru
Prep9iy3OsMSi8ZDuJ6Q23FTNqXaUYVBPfqmIfkz03H8hbKtd9iU6pfaTeWM/FTOZbblaQS/NOyo
NtX9T0r0Rzb6HpN/5y4tEguMG0zf1rOurJPC22MMO+b8jpxE+9Mnhww7/NPP/AQXbEO0w5wpc1wu
uo+GGxBpdcWw2fPLRXaE+sRga5dT5dIQqIwlnGfRI+pCiuzpb5kVzXxB6GqFza6qjSDHWfAyVIF0
h7KZHWEdB/U4dttWZcJhrnlUUqCtnME2wwC7ObnwVFquu65u6PdGIB0PKL3h47B5nwpsKpjrJx2Z
IxTnpKJLQfCHtwpHs63hGk4owILu124/6zMV1kvI2CQpLNbLnZYlO6QyfzOc5bWFLQhLnu6nH0Zj
5/wsyLuHqqrhLzujfDi5+4nFdI0vv6LzVFpIjuBzovHDsA0ANbS+U69My6mEDfEono43g+crFgrH
oxSc52aqAYuBTjkZUXwz0+VoxisK0NBCLi5dNauhWVinBM9iwyere2Iik5bihghbmS8JmkOSqzO8
X/7tOFDo94upVpb1/qbXp6OYwyZduL6+CvYhDJrYSYcmg3CqJ9HEyX5EFsCVjKIrISgM3mY5JyOe
8wtLxp4FK3DPo7CdwEJPD35hOek7lLdf6Hz7b+c2ZILObIaHNWVYimOz75qtla1xc+C9kT9LH9F7
GDf5Wpc5tbh6ODf4GdgA3oeGwLlkNQU0CVY68gp/0hZY1nkDs+zNrAVlmLbgxCGCv7zyPGldM83T
MOTnlHm4gXzc1Xv/tnTjrbXVSyJOBMk2T4ANCMvqfBtlavdutpBV8iyz/GxuK5/sjAQJqeT7DNHm
jGXjMrJKCsuvCQn/nP0RboY4owN2MkTh1WvqvJIIWRhCe7tVDh8U1uTZ3LENL99eZoY9uBRoLp9i
y8nkiCOSxFHYVfrcNqh/oZzHpIkVpLABfAmQkZ+uGz2b5BFZEx4evxHtdiNr2voKUIEhVPV6IkSa
ETatxS9iUZUhW4CxOP74sTtN3N0ZsPq13tfuqB02JwSfUBZoijGHjSYdonN0XMfhXsRsdy2J3nYT
dU6znfBcBbtFhKTAIZPy240a7ms6eHP2r4ob3SrBoXaJjpdKWy4WpZ+Z2ZrmauyRjW4sknpXzWs5
KvKOVgD5iZPeptANKlycGdRWSSqcjR/WklmT4DqImXBXXWPf1/aUUzu4vQI5/4RiWTeKhJdKqr0M
t4aAIcJnpaOG2WsJD4tnPXd7DEzUc0YIf1x1duARdcy/SAgaxs1FG43QwiqiKfswcu/8g6cQNnLF
QdBXutoZSm1flBER5AzNhknhybxjEheZitjr8+1nebmHCbtRHrL4Yhk+mdysYuiKr/IqhMtwf6y3
nonMD7+WcA9dRRFGNBqROHVUNYETHM52mg/W3j54qEGKpylla5l4WuujCxGLCH2SPYrobZ9Jb484
6bKW4mlLmwWbvsWAXU+47rBT9Pti3vctiBdl8pZmzdHEMVXeogeld9dUf4WZLiudTLr1CVGWQMuZ
Vz8f4VOqihytYGS5dpFWQEFYTT8ny0d5N2K4NeENFiPMXEAkkfOj5prUKXMO0dSzjt3qJohQx5vE
gbXBrxNVBjnBONTL4OTZ+KLM6MoXmmZI2sreC4HnsqMJGSj1+pxQvK1PCT6fazkb3S8oNxXVUPKG
e0iHwVnkohQcRPDersHFEn8WbSzw7rtFWDnSDd9L79O6IxZLuMVSeeXU86OFQkhmnK0Xyqg4h2UR
0W4ZBx3y+s4h4JlSkySA2lG/ScK2S3Sm8ox8j4G9UPdLCzFvTI8zDNMmNqDhZ61WansOq0Nkbz9L
VHPK/zFyoLRLlO/i/kbHbXAclyXXno4Jn1aOtjlBnIcZTGT6RlHzkxCMHuCXFtgfL0dsrkIKH0HX
Je4HMeGYkaEg+nLT9CRcDxbIube5zj6Rl0mMgbDTX2CMRufpwdVI8uZ6xZlr6V6A8iZ87hAW1Jeo
GcXiNEQJLHjNNBnSJLmVJ309q3i4rWkGJiNSYFQqg4aBvGXBg/NOJ+JZL5ovw4CCG4i5Q0XD9oWs
gqQJ5ezoqAsEZuzpL64Vs4i26XEfu/TfwXX4t9JwpZDZvd7IIxhy47cbxdJQAsHea06qbo5Hzdon
nnCn1R2ZjynlrNpHKUA5OQiDTTjPfOb1Iv8SqT5bhbl/E4KHUbzhtExqtG01Va/edIGcioq3ok1L
CpEQtPaZwclWBQy1R+uIOKAJfb5UBbi/TMavgPIhYNmlVzrwBkQYqeQUHMBwK8rLRYahDeqDPFCu
iwTEKMefPD73OSooowlqVBhYpgjkj2r3R7kYAg/v3FV25VftTaIf7VNKN3X3DZV6lZj+hVHgGMD0
rwTLLw/7mHQwQqeBqlSSpEoFyfjY3yXGgxF5V3hB3p9ivFaNIkDp5eDfaC4a5UX3A2zLMHXXNtRq
RLO2SfQhLVmavGLEqYN47Jg7usRNXRMuoP64Yx+EY2UWbcCSe3u6HJ9Hyq2l48FdAgwBTnYpKfrl
P2Vl1F/rrPmqOSMRLOXm4yXqv2VaRmtQszChqcTIKPt61INv4pT5J0+lcO/sx0stttQl4VZXPFed
j6NrzuKfiw7sbkRmpf/FYIGm/Tf+9v6b63znYITyWj1DIXcLHE3ti4nSTMH0EuJ8AYAbjlAIzzhA
sKMk3orIQmN81LGefNfxBwDANIbjHENNLvqsPAi6VzFkkkOg5FgNL/94aSX1VX3zSNno3U3Tzv2D
tXH/iqJUrPVikvR/XGDaJAffhIre2Z+fKdI3btJ7HIrEsvHFXVi3LGNkF+W9le9T501ro3Au18qW
/G6ZaN3e0Bksve97bqmbQzW0GZMTmPZS64GqfhALpAP6/uE9/4dEfyqFudYgI1gDikloFg4Z5OCs
ywKtP+td8TubfNFJtRrvlt4GsNbNC0HFRTjlos+DgJFfOnepXAtM3yHTmDc1JF0H52bthrztsaEo
B2i/VHGY+P/oqIW2ozi5D8tyaM9JVWN4fU+1087YPjywNDLqozcwHTo5hQA65R6qnTAV6M+YYUeC
3RuFouS9e8uiv39O1l4NJnPzgob2Xq29Wn9jGUzMkmeBovBNff/aAh/cWGq9HhTxglrK1fasDSul
QIYp0qZRcdSZO5A3O9T0AuXixkAYWQqPZAWv2lFiSpBO/PDNVazMPnM053dHJ8ezf060AyErh6Hl
9MAL41J/abFbESjrjUJwqQpnggDDBrajSrCNx4djSjcXY+9UEP2hOiDIo+6VRJDXAJMh3fjyf/xw
M2vqB5XObiXjVL8ZhSNiNQVTH2MkJa7B/Xc+JfCwOKqseawtNhBG74dKRYzBToqqdx1LM4bpN7NY
Mr4ecUK7tuTohJqd5WBZMRqQ2M3NcSeqiK74JB0DlLPrKIBj0CJa7vUWQ8YSifqrJPx841D0qze1
zask49mGr1j+WDN9iMZfx6zgRRySn6qo6bO0DxyAuiX8bgAnz3eSvILnNHK2dWYUDnrfqXEdUiIF
fr3TwHrHotrgQdJdLoW3E468qJ2IihqgqfuXbVy9YhQcSV+QswiVQac6/1pqVnTOKbOjuOblUEoj
UhSkxIdHIrxq+mNccxcF7y8BFRWRA4Eyemsp3f7RvF5s/nM5QI0xkkaDt1AWpefICGkIkMyw7G+9
vfnU/ObAH/13A+a2VmWAIMuXWB2xipfWkCCJKkH+oOD8y0PZN4cU+tLG/VhlPiMETWuFbirIBrfJ
OQfDa5RBQ2sqYgRFc11YyC448B9zsc4f5qAKYHYZnY7oFwb8g1zIBYOiJq3RrgsUtrBSz534Yo6o
dsMr+Du12+JQ+kSdtfG62ZR8GIy01sYPqPL6XY+NOD+hG5lenxZ5BZWdyywDgIIfCA1lBm4bgx38
PxCEZLLc2I1hj/JCqIBDCeRbEVL+HYEUUF2zSkLAFMGdzIkXHtMw0+LM6OjEbkWEGcUvedHBcrU9
Pnnnr4Yc4nltBLnx3o4JWqwUdFBRnvPAlSySQowGTufQ+/EACI7KhsHsibuLe0QchHZ3FZ8URWF+
P/77UAGDmwVwhz33skOmIxxAhKJwcBAatrrtdyv7pri4zSKiH+cZOD9/tNzfxNvYeKS5tGzLdAdN
5FgVJ/M8+9oUyjoJrW8oV55yRt18TRU8xSPC2eNqg+qaKVtTQhOX6JvI5nqwOy2vjZwnoP0UaMmr
+pTvj15WC/yHdmBw8DI2swBB3RLUcYD7P2A1aeDwVvInuiZZZ3i5nTffc6YRzJLsD/zc/CodOyD1
VX5nQFyABnVaZULIY1rFDdRT46/VIwL6qn+GZ4LgvpPgoh/2qygoUVZ9dqcE31Wnd+/1BFCEBo2f
geXx7ZjRkgYleeSlfoLlU6/G6ddw7OLFjBxtV7XQGbnS4gF00fnWBvcoXtjX358j3oiiT9LyH7PP
nTsYxzq94ekAgLUJOvxet2esGUn4VvDh0Xrkcg0286ntPLmZI7H9PTWpOCTJfcSblO6rxN4nZ0EX
wtGowWhkuFSBMr1na0qhKiUoyie0Dp/XmmveP4tX25aGQHlxXlNrqFN9nvcq2WIoCAsNodyczGBG
/8HtXE1q2wVTjQbJplXi3sIq0SEDHkcTa0CzOpvwue/5zL1jxGE7NwSX01DVo+VIJi+O8pdwOhGb
MCryl30UJ2H0walvdFmpj1vmh/XPwL+JSx7LL2Ore/xxwgtTN0XGhL45mv1Zd7ZvlXmewJ9Ce7oo
HVaGv1J4SXyb6BSzO5KHYLDKI6d2rEojlfdvg57dHXYT91tJQ+wq2hCNoPr3u0XqvdpQ7PkRlBmm
RUZgIDcA60pVjtJnJA4A/cSTTbnLhTadI+BDZCRi0D4PtGz72l2MqYjlwvo1Qsax66+a2EqPrk4J
7L5kGfm/BlgRispPMDagXTokdBszBgORgVTCcoGAE2A96PGitkyhxD6ssLYavElUwtjd2ijwucYq
MV0zk0M71HGAn4Yj0KYpPZOSIPGAT0/7hCYS6g7e+bgbJXIUh4UKxMoRZ6RJxxzljIIUeiIO54K6
iG33tKOdpd0PimpIOIbqUg78NaPnsxXGHSynuL8PdMp2WY9X7FiRbpwL8T8ZvLhIj7+Qjd/bTC/a
IZ10P69p2lPePK6wp8SnQONJkqCf+U+j02jJhRMNEeEuD/5gXPXppnFhYFpOY09ZVVIFt2waAI8D
3IxBlk0ldFQcsr2E+gztEC3JCQ0NH5hj1IUCfquzXWJCujV9tKHKKaBzBtPWmQ1GONnJ1gOGHbqS
gHv8E9+dmzMHCIssXE/jPaUjAfrzaO72OwTOvA8GghiEaaiJaZUGWOUIOgIXcxdAubzV7BRmyBoa
2V0X