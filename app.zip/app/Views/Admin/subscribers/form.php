<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy9vUsiF3q1DrfFkI2j5IfgCKYRe13MyugEuxxCBqFbyQAHSfr1NYZdI539Qgs6O2yXG8WI9
jiLOqMkiW4odfnZKdtY1ixGdgO/I8pwdLSIrgxvHnyqfGp1xErUuUc+8Frvg7h2yTFYb89xjhhEv
llb/5RST/Hpb9wojrPCzcM2YIXyxh0Vg1DpWCIjTil0frbSXqse6L1ermzzQq1WZXwPIVH7iLDPI
CI8XHnmkYqmPaAf5+5kF7zr5A8lB3OJRgnEVLlQDKD5JiWCuRryR8iCogcDZR/4r40q5M5VsZa4P
44XHPD2+QCD/dnIJSo07YL2vFbgwMAYgVIK7u9Y51opVl/y6xRCt5YsTSfulb3b4IQiWV3Z0tk1+
1/ZUkdvf5e5CCW/7L/FFhohH0vJkfH60MWiBY/EHOZTg4vAXbA9tV8TJmRgX9lIHzLYQV/9mqGfn
7QclDXSzHrMKKxJzYXX/xFUCzKCHauOaRby+r3GY8oT4T4a/+vNWR/hpRMgC2D+V+BpwphYLCKKC
Z0X6CsL0KAqI7mHh9hbtzWmVZme1+TV7o/JFXPmBcNbSKOWVwgHNk3YkKIBQTaCn+GgySskZfYQd
Ehbx2cZErFrEUL2vTMQAzFTN+TxbapA1ALsFcYtBsG1lecZaTgZmejHC48gBu+JcvKJG2QpLMshz
JMwxapGNSh4YyCJHjFCHqB/Oj3hffi2gtjxKozn5pKtJ6N7WRnaLx/lSzSEqCw6Cy1hua0xhe7Co
qHx3C3/M+aOMPCWj4DsmZO/qJHEpL/yF9lMNXROcsAtl0dd4NoGRfhM2EEs7Qm86s+8Xuje5f6Yn
MLcgu4DsIi/qm2SgJ4uJy9AcLTn61qhz/X7X7a8c+v0JH09J6Od0svYhT8xcLy6ut/Vy2Ta2XtvV
60tD2+PfZYHHzmKcQj2gRvv+Wk00mNYJFqRzPj9+4/iYnGUlY3Pm6fJhHpCkrAy5/jr5B37QNaoA
CLgUNrB7WvotJF+Qw7/d4sB1G+Ew/6r9CLvRrKum01ZdS2RpnyG8MicjCH3MKeET5vMyLtt5Y8lX
yhJeKgASc2+Q/V7nnLI+QgIhcnxputHGX60RUNdkOkjSRaOnq0e7dpYITNP8SjzDrZySC5ZU2jC2
xaxJHtbuUQJq6YmlAHh9/wq82KP58ruG24+KqIcIDkQnTu/S911QQLK8uLMPptC6sFvmMzoaiEbR
/mTCNz3YtEEbP4riXDvu4laZn/7JThm5e67TSItb6kcl1lQulAZ5twp2QcEtHBCpd6eTfckc31Yz
CMH4Xc0dlVLxNgdaOGGHXm7OhfVyS47K0bk86jVFXoHT0EbrgfijHd2s6jgh3/HgsO6hcPTMbp4j
Ih3fJmy+wyKeJ1zFWmJVSCLWjCXEI0Ath2cRl6Os4LMOKqjrdmZCK0V+bRN4LexeERGn7uMD40yo
BsHoTDlAWV7gsGWjgkde8dJyxnNjmGPOyxLwrdBPTK2Bs1bikcYY7UCP/cXHP/oqzscF0sE5qy0d
dDJeFMoImXEe1hIeGsK0GWMhz9ZRm7jXHFRDT35nKcUTJmTiRka9mKVReKNI77KPdAHRWN0ArODI
KF/U91DeCgQJQ2SqDKe9GfDbV3bPybqMWXtgKgxNxSCTvV5HRqIurZ3nM+RxlIQWVnDUiArsJqCk
hBSLuIZ2rnAL5dMspjC4qX/13GoCdwCMvaohVZyLCKUTPUG7Xp2CiDP+9xT9M8ZYJidkkSJ6+IMw
0glH1q+Vhg1G+9XMy33t7cZlDpgnimaGkSeh+6J9EspzO8bYrsHUrdyk41j7rdPMV0/dB/UKMneL
8hvdeTqpUvFGSjcUumLSPMWq3+fuh3A5PT9t+VPtePlXfTFIRAA7678q6D7RAND2SjtA8gXKqKHJ
N1q1Sm131nxUsuAw3GqvD0ochFa97RNK5zdL6r5uYFow6l2O39Nym9+W4JrHb7ibjWq0S+Lb1nJV
SVLuxLYsLf+wQ/AeixkRteuTtpJVktfXS3rZtUn4Dt7QDvVWeOmIhXu688/14EUzEVyiVzgGCB5J
H+qWQ1kSK7OcYayEe/0exdquvSKzOPqGSV1sivlY9afQadbtSkH/7y0gRGFBK1bMEnNaQih33coT
JdKqXP84fDL9JZEVwqeWIroMapqpMgmCbFiLYB3cvFPep37ANJsy552n4+7ygGwPHsvG0Io66vK3
S/HWRbTPQUwG/w+bl2lpbX6kLksWESJj2NV4+YDqSY1Tzq6G42PdPpUkQGcGvSY35atVLSxlvnMl
xoZaVIhNg0qCyW1w/bGJQWtMkeBveMw/jAU1M4aLxq84XxNdGbJFDr0RQiaenfhmvpyM36a4AcB2
z31fbmZusfEcDIkJzKiI9h6GsjvJP9/i4Lpr2wE3kJUmhbWZMIBLJjWnDkXZgu7yEnlP0pLiu4ja
Lhm72cQea0xzDZKlnIaCXYVlymRUALY2jlMz8eDKvRYgUcG0VXUAGuhcW3XCGFqG3yKtqCV4qj8W
bEUh5qi0Q2QJdpTms83MALam6c/uzpwg9ZDlqKcEerU4qmX1nwbdb2U/TYwh/DejhqxkUJFGpEi3
xHNGdpdJkIy9XVEAmy7FFKFFuTeudVsxBoVzmB5HI16ZbnZpPKCAR3DTWJV1OZrEL/J+WRuzV4tM
fOWvK8D8OAyPwvTGEmV4TWe71bZacr148G/BRwphJN7LQYlNBQVsuWkvEqNyPyeNvgmrUGOjiMcD
LaRb7RyzZIvfR7KzcqFamKZTelq6vFkVmE/KS+Jmkkm+bSyYd4Bh+DzQxti+A1+NtH7GCVmVlRjr
gyVq2fIXlwUTcgkpvqGbL5PprZkp6AvDeKXLc7QvafruQIprqbt8DOS3yFVqi5UT4Drcgsf3RgTR
mLqqofn/KxMX7TNIEIeSnFHoNRQ+CwwLWCI0np72re9KTDz84vI+R4OVRklhsyfRifv6HhCvCVYg
Mm+C/KpjlZST80zUUSbJKKycp2Tu1ErqGhN6PAWAwZCzw5HGwL9dh6vlDbZFBIzSU6L+LXie0gn9
zXvMn8P+LndKZWjaLP9plfTa+EB0Xl0GXsUXdcjed/296dRhVpyCQJUVJSbMFXpspXTEuehvLSvb
pDTWLAHR3uEtNxxtmBZ4R5AFpI+wL4fEX4ROgkVynUSWYMsGmT6aoUVEIqbOgOJSroEcfbKeTquD
fZZDLCeswebvshzaAmykgvKJDeFIFw8LZ9/zSj8F992GfaYFhcvtcemdYDB9Vli5EGyjJQMbKvpa
xoYJkRAZJwodGQlZk/Bg4OZJ6no46QSm+aoejKr7aBth5yJZYmWh3nWqJPZtbTgX7Q0WR04HnD65
hFdSffLpxB3sqpOT8FTPhujCZ2vuKNLgmT74O0VwbfYzZRrHpM0iub2NwpaTObhgEIwtf32GT7O+
pTFQW5sde2OkZIf+aiJsdtYUw6yQbDMDVyn+My+un3rEfu4gEAQUYaLygwZGHajXbGupyfaCdDGh
wlczAHBm/LUjlKJ8oHJ1q908WxMlflercvpmZ4bifsrTx1GBGlxaHivdwGVHzqBDJc4bgsifs7gi
fSD+rcCi6rHJkeNSQJgA8c/ybW0CMk/1ZVWJUVGxCZgSizWdP8x1JN6PoJW1kvGjlUidTmomjLfE
CbK1lynO/kAuTLQFeRpWRTd5+GXfza5CiNF0wJ4YJoZVC1/I38+zfuaX2hIpubeCtnWQpJllyJFc
gWENqnicC4GqzJsEmqTOZHQaQE7Z8cIzSIeY2K8MGR13hew+nyfgfJZ/GYryQ5wBCiyJq8rz9aHT
LoDA8g/Daz5vPbhSeE+3fw0ahAeCFbER1Mmq6PDSTRmppsdUZBZm+y2cJmRtovZ5fiKxiebKmho7
QJBnzPPVtlMA02htY8aIVxO617r8GssT+ak9BrOtsUZ33S0EvqSEay8MP2izMFuXpxflfTWP35t7
LTWaAuXfcuJ9SgcdxNHtTvwJ3c20cNrNICsTuSvhnCSjH8Yhx8wbdhEU6/mJ0SOBs0UG9qPgV0Xt
fQy/tdPtMOzPYB+Jv7jNV3Hq5b7f4utPwvLAKD2devqEkY/OgqMfkqJMXBcVYy6JVoShAdrRKejx
mWzH0RVT5c+KkTLs8nngiHfS6wFvTCLFfAKrXXsl46TJwHX9zyZsPkdUWqDGudgnt61bkjpApj4i
HKVTu2IuV3WfweU3oqFg/jUDfGmEiBsJDKFX9N9mMrUXKkHx1eB4n1JK4MczjSMaGqZzL+5bS7uF
4xUEq979lIzS1dw5R8m4POrrUw9zNL5DtZ5PT4Uvf7SOSLUhKyZ95ZhUhXywc47tOSMkvlZ7VbQM
fDhyIWI3pyq6lcYly8ne/vTS4ni26ysPJAIJgWCrxFAqllZMGiDlr2ReVY75MStaA058nE7/bB2B
qEnG5Zix1uLP1bYvZ+ztUen1GLKoPlQqCatmPsIghG6TdiaZQRfYkDNgYP4mNgYdm60jgnUMnhWE
W8vdMDyvIwzf0IATl3RvH7xNHOA2Mv5ZvuSp6vnUg/3n4a86FyQZa+W+MytbB2fvTeta/xNSUmLn
GSg+ROiKaXJ183G6TzD9msiVr2Y3BRaA/lYGtM0pyVOlwXK3QB/z1qTiJJj7TRISjfY0evNQmoZU
9OKkvDUmJYzlXB2yowonJuXZomBTdLicW8j3REpZiK69sUwmzByn5lpfS5utQFwjbIih8thLLJsE
/0tpJESK5wSVgpiRqiDqZUSoAJsOCVBT1W/3TUjoC2/GG3hQoU/zfevnOO3WnQCtcq8siamL1MbK
MpZ/a+6ryWczneOQBnYcBosm0fgh1YR/Pf5lkf7Mh6+e+oY2zNs45WU+vJzU4GoeYmIS/h8s4nf5
yexhnY3I5eyQmROnpDm3WCFf93Fd2dz4a7cZFxuMS9faFohuawm/4OBqmmbeV/0sraAT1NaOevJq
b7CqR9HN2l2EmIuwmdp1v9b6PWYKLSyHLCJTI7Ffdje+hTQ82O7fjKf7XPpU1yV+OiD+YCi3np9h
ia3qmnmF+4HpqkuR/o+IvITUj1awrO+/uBz31h8Ml7O8s/FGAoly2gN3z0JAI1JlDDb05B+K6WZP
GqSSSZ+9VAlaPvcOg0G9ZVfgdl7zsiVXtufTDuY/qTD5JQvJmsrIl4XlEZjZ53bPMEsr04W++1W1
qBcA3acxVNtnhbb1458Q+ffbvZbz+8L7dbYTJF9uwqHTBEVLuj8UaQrjTrOF6Vhx5Gp2K19uvp6G
vcSwFax+YTboURY0OHeoDAaAs0rB83lmae+ynFaPjb37Wn/Kct+GBjuiRardcusAKFcFjrS5dwnp
5uGlL0M6NlIQca23dZvcCkU4wwAEt6Q+JlanIixXUUwGqXcCuphZm6i+IUC77APAgw4h5jb3f25W
zfy76Iy9O1hh9IIqMFzerT0gAQZ9TQ5iHkwR8DzLxneO7QaUVSiLfH1e2qRZ7jYOhCcri6zeau++
NrngWHfJyI/fxrXbynKXOvTDKMJZyOCk8flQsyf1NLqm+RcqRY6kBrntp8SlmeW0Jcs5HTJiBmb8
FGAA535YgS+mdAGRfY5utBq0rr0DCibuN7Sv6RPDl/XsL8eA0fgZKchG4fMcUbcPx1xVOUGMlah3
qDYCJw6nvIsvuO6X1w5HvkFcouNSPbE/jlhcKL2kBhTwULg3bEv1NZ51dz+1fmxYQpHB5XWCBvdy
jeXY5CjJJOgKgA6BIgnVaQLLc6vQng6wX0DM6UCqtbMbe/p3UlKoJhnM2jKGESwNNz/TmKutVaSZ
oGIykIW+23dGDyl6z5ziGc25jsYOut9GX3xdOwi7wSbClCLkRN6UOc5QPZsvL4UBl+DJMAlKL6Ux
OBLa4pYAIaPnV72jwNugWeZ7J/skTIWIuNn9etBzsVv5Nv2aYxc1n+VNrlWeLArqTwvmxGN58rGj
5/Fd9xC9WO+A3WJ06NEvVBj/mY/xQ/EZUoM5CqxS9iJk1VWXi8+I0wN+l053xemHsSB9UzWm8nUY
ES5ZhnF5alAL8030B9fzhgqqko00Gjs8XINxjzNdcEPk7bgPlDr0PYSL1JKZE99hAiw2GeGwiRn1
0bZQQW859uvCDXgP9ii/ChSaoLnlncGn61MMqO2h0o1LuxbvhPQPSpHGMMd1hIx/W9AUoIOD4Ix4
8b+8l6q/y4SO2ddcN2h44L3L96pdVDnFuS6X8P1fRAtevYVuapTO1UilQKLpTAPF/rkAHH0qVW/e
IMQMCtf+vm6K52MWo7tP3K8iSoaMXxoqepGRyQwt082LUlUPb2q8Gipk2+g80FKR0B4FxD6EKvun
RjU1aXGvn1l3g7Y0lUeVlBDhtrIcN6oOEuooA+QTKEVAvI/FhEYJfwL29TWkX7egfYycYTsRBstT
/YqXfKYI5sehuNRTqR12n3B6SUaf1192BFUZV1/FNb27eHWcXIhcqxcpb79/M3F18Bzn44qbkNig
8LGHsKc+b1fQyle6SZ9dVOGU48rS3TMinNZOQiaoLDyQKLK9m3CEnferu30PCiTYyQeTVp6b12+b
TEfqkI9/Vp4NhASKTr/KrqG6ew5R/okAbqLUEh2EVkxiT7tlUK49oHOx3A5iBVaNfhVb+K6JLrBi
OTT6Kr1rWwJ5OaPzbfdlLOQtLh9XorQCwh80NGEWNnF4NbS7bkEtL/chPWVou+eqdzKpSJV9Zqr0
YK8LzZOBIFoDjbDn1Af77xx9pK5ONML92W139e2EOSPY9FIDlitR2vCzvKcnY/TolMB5ExZcL7fy
UeIS3flzaeaTh+3h+0Xt3vFjuzwWTNxhLRqCB/tZpNDY2TABVaHAsgJLABTiZTKFBdqb1GU3imEW
UFsq4c13kacMWm1yVMWaoUs+9QePUfWv/L+hd5HrZ5AS6Lt6oGGAlSvt29mPBXRPDL7/QJR1G0Z7
Jycb4lYiYePsT090TeSV5B3ElLckXZFnYnQCbdk64W2RS+uVHptuuAZKGCWsaX5R86LE3RbaZeqY
yzCPN9NfR/8k86cVzPUnGD/bDDBzQCcw1NmFw1H6D63yN44gUIitWq2FXT9fdkzoup/xYQpmsB3v
wCc7X9Xl+iCQzycVNuLcFOM+KGs3/fgzcNY9fJqE5NVUGC0PovWjEvxAChfAPQvhbBIA2yttscoM
haHFI6YyX+wELQFugX15taViKEaGv8mkeFVVhGT9KCI7vhTzC05UbbDvCs92KFJLuz/pwKknNa0R
xVIlHoqtckeZvzSUqUE+e8Iqlk6nLV/wKbXZZsF1tWg3qqWvnE4WtPUoveX+JJBJetdfcZ+CEDji
opb/2YfXy57BCFZnL9u+JMzignwXsUsg9w5bxoqKfRdxUVTMinAmk/C2EH0zQN0//vImqDiVjScR
ridj7wRXuWbAiw+MHLCU2ftpjUx6uyby9z1p21EVh0ZtVFaE4zAjPX2/D1CGpDNiVGwrAjR7MCQx
ff2aHDqCHb2cLQYQL7rf73+ZuvmPN+XghKLOntTqLMSp6cnWhcmwCbArymmKk4eHa5OKxrm8o7Ao
yG4eZhaMn1L9DMGJTKjsqnRwUO0IfifhcW4SD7P7Xt0ol2idKWUvgYEzLzzuZTgCW/8QugNPL+Qa
V/HYZSwHZSJ8IwIB3a933B0wBvZKpaDjkY0jrE8CpbRFO/9wf+NDsFsKGLBCJTkesyrCEl1rpxzE
5dkbuUyObVOOy38IzKU+SIW7BEz4l8yHcUklMiH05FnphjOon0gf0FrAr6Cpsd49zKqMMXuUstnS
24vargjay/Yo59dCv64oLxwy64GOpQgdaIv6ciKuyFR2lX+F3I9BMcuJP/V9YDCSbouJD5PuwzsX
39ySG6eFKNx3AFio0dJiyRG5cFyjBPSjLeompeZat8OCtrNknxLQWU6G2D0oWSx6CRwQ6puSjUo7
FRjWKCpdUZV+GWB3etwgD21caCYjtw8qg24812RLIzb4rLI1GYXI55wF8X8zRTAACv+R//m5wvKt
NISkIsAT1njVa8xSNcs1gDFrYQJt029CqK7P7nYDEMndl1Pk5tAwi+VX08L2bJ5SNE5Fdl8zK2s1
Xl4YxdsIneZVBmC9nr+FarYVKucmW26GztBcwHcI2rRWjQM5pmD0PQX3iVCNQTNCXu9Y7n3n1TOK
3rj6M+C21BArnoARjTM+Nma+dRluizTOA+Jp9nu1OATh3l4rJoRndhTw7xmDhH491sU1AhvUjeo6
eEyJc9kjwg8apLCKyRCPYBmBtbWvIFoSoKvNDoqVVDKGRZ8RwwvwuJCkIRqWj1iKdJLCGqmus757
btn4hH5LVl++skC159swgPYms1gkAfx7QeR9yb9TrIB2obkCCOReQv93+8H3JnTNmXVvhR7+tT/F
ZGewQR7zesQ/lGM6W19zw8IG2tDbShSN4XQEGSttakGtWlOKYeNd7uk2SWqzrudbjnU62XSnmIzT
3o4N47BLz/Oxet+bJxDuNaqfWGhnB5u4J3QdZr+gjV2jO0tdp2Mo0O032CcXkPWAO/Er6bUSKZNe
Cdfp7OhL74/tjrgLW/tyDrFPsgTbtAST17f/UmUy2W3QViyUdoLhqH0tEMkFhCEhZO6IsIeBsVaX
FkkgDJgKaumNcFPtoADyGIXXrtUzhGVHlEpNRP/0cc4jCPe6D8NhlWhBKwX3dueHjBv+qVuAn29J
QWThFiC8gK1BP9nhOAeNbW41J5SbASDJggwZC09pJiE6yb7Ao2UuyFNBx/PJcEyS3gK2FxDvdJAS
NaJXolG27JvN/Xbtxxk+gbSe4ccdbtwuhtt5G/rb6TD5xHdmojXXmY3mhqrtl8dSxt+8JHv+Nyup
YrWk/j2h6syA0fUrUDA0gwtlwQTODvIXsycf/uolcMteBy0TJminQ+bclflUFhrWgtL0hOEHwwjb
DXVkGUMo9ztoUt1rVRJ6ixg7KRA+7haojoMU+FWiRB91aQqfWmu4s4YG7IWrdx7nTcyiZhb2mZgP
9T6L+4rdmAuVxsfyMCJObw7BVL2ATR3wvp4uv1AeVvopbyMYUF+YvTy8GeIx/8Lj6ezNJmBOUtFH
HFDfxeZgp77vD25oA6qIhow3pWtka7lntFDQYuYAYuFKfTyCyR8OPIddWmK1BjZtSOBvRMbbhybH
465hsHIXHvq34ry65g1UouADbPL6MOgnM8BlUduIUrmT4BnVycCp6udNi1HishfxiC7rnddQICri
OyGd1Yv4cNPe+X6FxOODcEljdkg5KAaGHYfg170sCWjsGvy5goxHlbuoPhcG/2UOmBNX6sZAhwkr
AUSDL5N79RxsjuN9z6u0cwDUI0o8V9sSLi0iRCJYV0pIhrUjEHduE7X42F/mj9ZRWqa3uOpDVIc+
SKVKCYSNiVFFpQOCeCR3AxZZvjNYNLrDBlGq6hMT8argagJz4eFcC+aA9Swxl30GTOtZZC2QKi61
6Fl/rGZ+6xLQE9jfOZuZxceQf6MbGuQWhuznjomqqOpXFV3mXf7VLn+3SR7pnMhHzD35ATUoBsY4
OL8TvG+xImoAHusMKID7tFB6nacB4WT/wXwxUSnTEe7cizBMKKdTKBaMNcX5uDlyQqezcuAyAUPj
axMHvzFmu5sJ2XsKLGCC2tj/bEpHtPdQbZhhDUFQfI6WOgLkfcPcn847NHWfQOApcrUPFfVSxAYc
rRTbjPvgX/psIVX+5KvjtcwfgEj13KAHXGljjvGWKv/tRMcjPsk+vdgWqCtSXfXlAbSj/KRO7U1s
JgQRK8msKYlwBslALp0drQY6/A0K3VNyX9TWvuKoo9Hq5e82/YhAWo1SjZwHKd5MLo6stdxloNEN
ArINMupIkQxVyXvd+EpNT7AZl7CcTIV2vMMh2zhw3/v1mr5T165daHjoAcZGG0NuCk3Yirf4vMLu
t36CNHdG0UfMkE7S1w5Wt+hCNaSVwNsW2r28Y4KhaWBecJOLvUa9ob+m7uvU+4sZJCK2wJNwP/x9
hvibT2LZjKHZJgrq7Hxy