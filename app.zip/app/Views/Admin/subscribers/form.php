<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr8RJvovhBFJHF7Qls9pJo0HgtP4INUqKA+u89FaxCfmPVzfOdoU7z61Hx4R+Oo8E69R5oTS
q6mMhrWhF+St+vgLEW9wbXnFsjb6sGIGrgxxUHbYNwAJo0ZOTj4PWx2gRks0KOMt8ILGjefHCD4p
Ue+PbmaqEt5+VYQKWO1HzeCHC6NGKX3b41AzEbHy3SmdFxk+joqVSSjHtfvHQb5SbWxeUaoWEPPC
Z5ZHzw0CwaUWlIyXv/tQqvbwwYIHI7vNA709yh6F55dCubCN2OI5/+0cydrbhzU0RCp+5RC4aKNt
btj1aswMbmHkPPDW5KQMenfhstR+jro+v9SP8wgTykMOBs/V91yOTJ21Cqq8j6JNgDKco0YY74Ig
txOXabsYzY0H71Oa7U8N94ZOLVA+KedidxxbqplRUdUJymaFrkGX53B1n4QFkszZrvWKj2wH3Dzt
/HPMIiAtktbHBQen94sEUfrENVs07L+jKm3M7k9r0IQEMbDqRO4COcjOtlbIGB/1hX25zErahPkt
e+PtAscaRhaDi6gQ3TszO9PT4UhXz3CO8JDL67jYnIRLEh5qnAgNzrQ7zbioFQLW6Dj9m8TeZLjg
MsX8zEHlZzxkfyBo5tCJP3Hq97GxrwndmnX4xe7XsW9H4tp/sYmDQNSZjrxNJhj2wOcTfC92wx/v
TYnKhMgxbdAMEGXZ4hrcnvDsdIGMBHlq3/nMNecxbcRswjn6rOEU1AlSw8rTZyCikWKmes04XrLj
CMZ5vrvgNIAT0OTUjrmJ/DAsMwy95wLZN+UuazgZYuQaERoD4KgznlFU4X3PMTo3WQ5Y5u1Ww2m4
Ooa0gz/LkFFvUA+QeIBtUbdaL2tk0MK/+fxtthsaW6I3fCPpNBl1ITOCXfWCpa5/3nTO1ngHVuAt
hQgqmsePuROkCfsG1coERmgFUjpfyStTlPkSkez5bi+A5nGBDzvOhHiLXA8izH01TglCO3CXor1z
jnIOdOawU7EeVybx2CdNZhufAaaY2WNDEvGqA5MSfnNi6PUvxxLcBpJl+CvRnPUoNaaSkbUzLvy0
D7S7b7KThOVgJ+8nsikrs+UOkchIj15WjgXXiMcnhLPumNbwVQm8zk1aPolLVops0tz8CBuZqS6S
fkZJ3XW1su89c2PN8VhNKZZBXUyNIUeCsYRfVqtx+ER8Z9rkg2rYukJlfn644vUyBcdpcz7rsePd
zxqPnKPfuswfNZJtuoywGoYZk9V5HEBvL/iZsaA53ePYn+u8xoLI/gBpdyDwwWKi0/Ubkqh6Yyf7
6J0X2eXbFleAlQfDL+U1Y+6+TN54iEylaBD2JrfVdXcwB/B4drgY4mSxExArMDq3cGG2HF2MFbxs
kFKDEGJpJz2ZGl0EY3c1nYrgVy4DDWaOiw0HTU89lQWsKnh0LYXE6tCe/p7Mczb7mnOH9LdmDj4G
5X6PcSl4KSVLehdipdeO692l5DoR0rGFbLDtXBZRrX25Hi/GxpyulbF3vgodyd+lDJuh6KhrdH9t
7XbF3wSpI/07Mq6lpt/VkUe4i4k07xan95A5YKKWg/Pz8FhQZN4Ahsebyw07GKEJuqzxGk6MTlUq
54UFEmrxm4O6pUoLX6UrXoBpBlDAv4s15/xQL6jkZZNvKitvqBHt8DWpW3lt1ckxeAYs8FtZI+2U
+BT3fy4CrY1xC6ZwtB3+Ot3/kspqDDnGw4ny6f3lgk0RraCnExzK0szbbFyi8i6+r7Sz3sD4EzEF
Gh16QylAslm4j1MIC+BbP7LR/SYDoTyUtbL92K5A7gS3gDuLoDE7KSJQzqRUh9J5/flaKwmKwFZS
SBXk+m7aoCAL7A47XjteD/7l2cbl8KQHJuc5PJepJZ2PhOnwwoSRjNVKq+T+XbMCBAxI64i7I7PZ
N7ybovBd7sjWHalN6j23qnx6QOW3Vonac3Jc173vbZgCVduqMMR+jCOJySi3/tEVhTLqgXkXmjUe
mjnbwmsjOPFje1qrbr8807ntIPArlN52qtgZVF37OKaEzgBs+BE1ojShYSvnKJX9zQtTDNpiMNR2
JT4ebUrOzkvsxImIc4oy7UaxIIcd8+6j14agRwz0HRXbpjAYElkfTlImg83IYf52ICP0urvqT4xw
UyUkWGFXg8yMKcUMpwulO6pVUDRj60db3kobZ/KpyTTmYl+ya8QIQhP0O8h56Xx6PKTpudIcX2td
v8qU+vSAopr+RIXC0X9XAtgbydOEdNB1b+wS8E43vUQdJRcT3xwk02ycV7TfUATtSZvt19N/7BO+
R6X0aqgLYmf67Ai4L0wGf7vPIQ5zuEilsAZdM0rQxXGQ4G8drDURxJh08yAwHeXZOsMk3eNZ+p5u
MLbyMIMJz2D9Y95M26H4FtL61bKrd1/2M4vu3hLvsx4TpyE+hu0DafszdQAZoF04sqFdfLn+rMRk
MRdYRgw7wiJoNJW4TkQDNjxuYaQfx2YSeC3DCuz2KMRSwW9hn0u0u26627YXeqfJ7qzdYwKjpP8B
Jc4gweKRR1nfEf+H9LIXOGrfAlF7r3e9lmwM2NzKYic925PaVFJERWPfVxTak2aqkYXeCMq3Rnon
lllaXRdYkfMMVcBu1EvIS0/1ba4MHLHy8vftKGz6UvWAYF8vIAZKEOH2JOnldKQzRa43VNtci1i1
vuPG5aZ7j+Q3nmzoDFZs72480TjEJ6JqeEeiE932KPp98D6UKaZgTGecQ6PI5NukUReNGHEyz729
rw+tfrXY0g3UDCbn+oPYIGwfKrszsNK2o7o4OBbtJPECA48MNSWm2faS+27MpPd0KbHl7WnmwXaz
ltwaDatdkhlrAATlqncu/VAyTjk2HCYIxRQ/4c9TBBWYEVOIXXkdeSHP2zPLTEwImOUDeFEf2DRP
PhSuwWe0UcJYLWE9vF7B5xRS5jXhuzYlOetnLmt4pSH+OU+VfTjiwAJ1RPY5AopsKtgvrurXR+8b
INoEvMvZz3P/Gix7GTYJCnz2gGvv3od9y1dziUS6VnjdN7cRnYHr7icTBb7P/mou2PuWOpwmaa6t
d27Kfq7UAGRVB+Q9W2wCtvlPJWfeZahHoWH+GV/Oifv+N6Vn36y5x4pLQ333+2Pgetw1cqUyCukv
ny5fIm2xxiHTSeYvHDgWE6e7G2OuaHSSBESqugH986GvgCZXAzVZu8gU0MnBjkwPfSeCV77KSPnJ
kf2TEjL5BHhlBG2Iq+sgCcE+0/7QO34noYXedFH7a3uWf+Y7I98rbokz41Y5IBKJNcI76aBu1YvN
LD5YR4oeag6qHasJ7wtE4pe9f+HtK7npTGOo/qMWcCfg3bU2PkXKGOXnscuKzvev/21Yj6L8R+Ik
mc0O4BMubTtXAokzLRuvdBiKicLOV4LWnU+vNOiX3LCs0m7wSccAkLSlTrvT/OwTzrAAOLNRIWPH
CFAxwamBitWOygXRvhvamaiwI3V7367jCA+1atef0Eid4G6u0LJb/ZDcLAOdLyxtBP7J2ivtFgFB
hzu4PJu2TlHGyrBghPdg1mpcBpXB+ZOH3qIPB+qPM5j1TUg6HTp0q4IDPcV9CgcVsSa88nYCFllf
lBo9AHMCEGQwW+RTUKLVVkZNIRvH/ZsmEmAuPCzJdYGs2a4V3687OwrO+BkP7wDSUD5hrqF9ES1K
tmVkAvG+b4N5qmRMx9dNyFs+QepeNLlkROC5PGdUJ1Xaa7PgBCYyJaQg3TGjh1egDkqrwZ6bprGZ
CJgZu7vKQ18XIisYTp/evrOPh9HKZ4XxnoHRsiMhjqzg4972cS4ZjGOgxvp8bLPVQ6SKDCl2g2Bm
n/Zzu1YWkrThstlvilEAG6ySHE0eZfvyrJgb4ovYH+GL7MQMDSOeXENV1bP8vXT3LME41hcr87UA
9eP6ScpDVLA1oKPo3pEodcdUWgNrLqAIue+yQPHqybeRtwGsbMOeXZVvI5ZjcHYN62LAwTnO2fcC
jlWGhiCJS/zwn5x70DlwWaAEwt9ywUfzJ21t4l+GU2ZQOMvYvBoMLJu7OapZgh9JQEfk3TCs0j0g
61H6RKcguN4TCC7+vn1j+hVBJ3xMLFBgCtqpco2ucgs/bgDKx47Q9FpsTX3xw9JmVrcleKI8OCJE
A3T3u5PaNt274Y8Cln4u11OzACbEOj3DmdG5cq3tKFMZZyi8R+hiu2kRDtr0FtTbsePiwtiTdFXc
20u8FVV75TmGNI5AO6WN/tBUpjz6fk4Q6XlvBUZlTzLh8wqD/fL7E4yGLbME5yCLEZBAawsyW0Cq
s3inZn9Qd+DsZkRMUcXsKo0BXBV0SPehRRmHbOIls+5E4Bi7Fez3G5mlIyI5qNxgNtps+efHIp00
tVq72V9G+uwIWV6LvYzpLH4ix92gVjfwHduJLX7GGsFaJDnJJ/L9yASCUScHrcCuAkZ5GsbpGWy6
ARltVVs3pNQBxi16qZ8dwn/xmNamj2UL+XK224UWBF8/9u3IVHSH4AaowbhTe+/vezP/2cEqdTQH
a6kT31pf5tdDQpHo59ZE7/83VrcZZ9/FVCRqpQVX8z9pv8vM7FaGWHilMzsYgauozCcvgY+/POl7
Y/7bYVBPh1y1aDQvFGKAIjbLCiLJFJY6MbwQc3iRn9uQzDthrEeNUuCGZiUF5HpR8ShSEneifkFp
FMc/a4ot85TbR/cZ9449YMfwu97Cn5VaXus3XtvagVuM5scETWG5tFpiwfvOAekUOL2/8wJB9Udf
nGGxq9yE+DdVB5l8QGrTrD3BKgmRWuU5REkIk+sl1hHAO3rPOD9jae7WPVFRSP1xPJjrmbDMJyYl
UJTZwcJDkyjM3zrKYThRnbnc+MsvXGtsmg4kO3qx51qqLQ4LQpiEmVOgg8Uk/DW9+eSNjkgFPO2/
BDaJp05hHnCMd3Bv0BUaBCyGwnQajmaWI6p46tcrsKedMPxb86EdtXiSbE50ce4IBXJLRe/j58dH
iWIxJKGEd0HZI7hNLSo/ZX6VccEbYRCHp/Gm8dJxbq+62ft0RJsuqdkN5X7pgJtHifcGzm6i5oi3
6x/nVD3ETaHD3wim3/DCr1Tv6QgqyCSif8DmFmFQ0JIV+7mIAEKUx5kHYAOuY53FQ3qUSE/Nd4OH
E7Ya4K6gEQz7XyK+nyGhfoijREU+zDlbYOZDjHruBIaNJWjqBQMix/URje/jfL4Tpy3X/SFPUBTr
QuJ+zHB2e7hF8netioPbSxaAxiTe7A3stJkgm13NPPC/Jxg47zVhDZW3e68EbDQRUG+Isu8QCOAB
2kL8/dhiFozmtzJhwbETzOfsbgj63NwmyA0L2V52A47tfuTAKqdiX+oIS7LrJyzQQL0JwmSddYSO
aiX3v9AAKOwV6II+G45mQARLDsQBwX9wxe3yPdTRJZWuqU4btMoOJdBeqf2esvqabSaITGOG3e3X
XhSpk0YBzccVjG6pS6tndrTg5mKcfn/ez9W/mdJ8sNMVDg4oN0/YiZMCT072YUbi7AxTmuF7yRp8
HJwBrB7RvXBiDbw+j/YMIqASOMZocP2UP2CKiiJfi44+/pt55qyaOGjUqib4oUJetGsakcT5yuNQ
+mhiPiXSbPy4ZENaG81z609xmzyNQYtHGIlpwlWEfTDjPJFfnIqU572Vk8ByxRdH9pTcyBv+MENX
6wsD9dlPNfWc7S5Ewzn5D7ixT2ZfRZxrH9f3CvPWfJTt0N7Uu8EPqp30s4cTn93j7FnNyvxwazoK
x8P7LHO21AQPMeigZlVMfF83+rkTKAwQV8e+vihGYjnkaoQWGYF1ceM7t4F8R/fb9dXD7Mbw3voZ
IuYEL+P2VVqdIvP21gLKTVGGjVExzisMTtxC+A963Ale8bCYlLAOTnuUSBQnKImKH9/21maZ5ZEk
NNx5DtN/+71UqFf6PjGXCfznngfOsg5N9QlY63yJuS4bpxcIW1Q6hwKY2somjgJ2oA3oBT29bSJr
h+Q8J2ClDMsnJZ+5xEnsIdqOumtpxryFuGUDaCrV7TiFA/0tHuPoM27KhO2vEsrWTAwadPKec3+F
EZ6G4TwgrkD9L46BFi+hDFhYSyikcryuBLK53nD7UT5qcKc1y06rD4W8mzDdd8xxuUe0CzNjT/N+
Kkt61Gx0Mxvxiahed1WBft/yuldzKiYQcwT+GF3nerfU0PZJsdmH3fKHYArx1AI9bdBmInsd9A3u
sNNZXGi3EVwAcedYznomfdud6+k75uLcKxQHqnchc+TUETVrjGWIsr4lA0nn9hZ40HSm6nDK36BR
7F45PJteuEuW1RAOhPEjTckw6S90/m8nias1fCi9NxHmz9OgrRPS1VSNc4UPXtq/Tkj5n/qNZuz7
6fjVhHsLX/cX7WpO406IB8nUCXKfcVTYVmvJj1FQV6Ht5zGJ1Kt4yxySA2xY8nJO5TQ2G8pEDLeK
2SPi76/6PJLFFmeInWoWbGcR6GDseDXoDSioRYUH+6jfVZq+sTSknHVEHnBwIEY1Kq56g7YNC+LZ
gpgabaDdKw7m3adAa7NUuNze5IRNSfc70ITTZ2Tq7aElVvRZAowlFG3DRvQ85dc1iYiQKs0j4Pmc
dx10LM0QRgb2OmvfgDM2+aEpPgS1oKb2TH7UMvoSsBwz+UWAC067/9Xk4OS+LzDlMIlxQSygRI/6
P7KSg6A/2atXa3BgTOdylzaFjIW+gwYDfbcDfF7pkbxNOUXXNgQwaUxqSsARkEhHUjrfxu92GvlS
yq4Z+LYAtqNP5WQf9rB7Qed699Oef4HD9Lk/OJrB+qssgKmK3Cze4Oa4TicLvP7S66vjVQMh3L4Z
MtuK3DeoDa44kqsAKCr1luB1Z94Zn/w3FMETlDBvCsjc/Z/aDELNa8XdcOIoYOJCO6G0CbhunCcy
mzEwerp4GXlnKQl+v8PMREVM7RPvMexluPgO53/o6BNwj01fgkMzlnZ/lfpE4cyj/4BjRTaYWrEb
U2BVz8N7/xY8JM8MnZ0Hu+M4NjSI7DIcJm1zb/Q/e/Ktqr+qf/fA9GVZAzV1M+V9qJLEvmyTj+qi
DU+DajZdBW38IDKASdmHQwOEwLDKILjeelFTPcgR72jkj+GG6CynVbuAfIfYlhX1jqhT1yeTw5VP
OfNlpbva1ZzKeaooqYYiDwCz7g8rjeqkCBoET4R4fSs+OrkezWNVEhUZLa4/Srknwvcw6tqWq7ig
zVbWckWfos1Qs8CD7kQ/L28AUfHdPkc2e2w+yh2UQpDKdgwCCgecguBs3Uvfp+yZ4Pko+tVAGmo/
K2jBTBCv8HY07FtM8uz4t2FMn7H8VKQ9lFrUIuR7SoZHcas+Uv8fBVJLDO27iUpRh9egVf1noOgb
S4HOAzYBiZJXG5LkuQFrtJcAaMbC/+zSirsd0IUpSo5ncAe44iKacKLJ2TVZ5ewDSBxSENVLaDqz
TUgReg7t98csGdfg6E5ZgFjuhoM9HMIYfABFSvNo9hyjZVKP6+I0RZb9TuDsU2a7fOCZWtQ3YKAJ
QH8x5ToA8HczNFuanyny4+/F/3aTv5NsTxc4klTrx9ZIFpioCK1iljrxJ0bK9e4I+Z4FdB24tNt+
+aHtqWOLFugJQh79K/aUnET0yrr4ncoQ4wp/vNGxpCPwSal33P/s3m5xZ/ai1pk4e8VakuWC/oAZ
Wp/tQkABoG4p4BVO9PU1DDdmrQte1m2IES6eru1xcNcUGOT9g4s6SH0ApHjkb4ypyMPJQEfq+36n
PvQlL7JiIqFlwKXGUDFQMywbvwmq6k71NGNcHEf1xAhtzhJs79F4Di0UCMK+rjbOSRRUoaTMnJdU
STyVpEb/n2uY42y6oFrTisk5tdR+mUyJUOgaGJQXiFB9ObjQ3355HXNxqJQS2JeGRZ5vEa3++A0r
3fhHoXvKONktI7jAht6s1wlVZuoxWtmbYpSEnbnzVSaAYCoDSKo9FRkmoNEV5YJM1m12o7NsE84b
QSTGABKzRDaFi+oaaamBzqVexqn+374tcrJ/t4G2aoz+6wTIvAiUO5RC7EmvoSKtiAb11hZwWj+v
3jtqXbQ1ugNmIxFYtue5COkOuy2HmT3WL0y4YrRc2lf2vYsxKoN0KoaSzCiHGSrx+QP5L3JQwJ8r
Ny9KgTWwbLXQ9amOdOM/dd8wQ4JbAYYwIe8J4kbD2BlHfxAXkWyCsc46ugwWRfGkVBR/Xu3A0SnC
UcVgljtGmlVycHNr+jrza38mHMjxuDMLGU9fMzZoLcVIVWr56NiVQdY6qNtwrwdu7Hhwf5wAob1H
00w4U6y2P1paAe6ypuu5CT0NO8Ad22kV3UKkI2KXIufRjLpHvznNSOCcpf0p7o4F51Ps0MfJ9RNR
4ParDWXuIn3da3PcIf/7PAUAss5k0n3xt87M9rmCxfYwzFS+3tyDmFUHozKkNjxSLS7UyPJabBjF
BcT9iOizKOZpzRiNjiX7VuYF5pJeCMn+Otd93DHGD0SxClrvnqX6Oj8vlyWQllZuCTxtmEKi4NtP
RcDwumMgCNA2yfegAVmHWpUv78YYuFBwLLgwG1MEo74e/gdmmHbwwIFyQAO9EFMUjxlhAbikx2m6
j0RwD884mvUJXLT5IHs9Db06c3vwtBJVT9Yglp04lUX6WrWfl2bujOpmNL3B9BjHmr/sLxGAunno
AItH/I4wEWws7u3zsIuFUoypa+NujGC2CYjWvPKkd1lJya6+kqKg0AgRQSmOC/0vySW3BFNhgZ0A
ucbUDwQ6k5BMhyyfq0HzHLGHPSVcWTHRRz0VwShV1h0XSLOmvY5Am6ULotFBDsPB24tdLa/mRsZV
OsOJqC8LPZe6Dn30ib2HtqOsrt++/57ePML8+xvmllHAQXk85wW7w7cqGHg/NcIW0rX1Ahsc8R4D
UIyQTs904XOKvcnALbDw2uv+GsBIw4Sld8l4AVSl3wR6+YsDUWy7frfTcESCbwpfxI6V1NjFTVmd
yX/Bu4auZrmpSgYrEx00UyKwDU3ophFqaI6w7ukUahvrvt4Gl+l9VHJ8iBkB0+1XiAJhY6FN3kEQ
IbI3+dB/OxxVXQ/7gk4YwUDSPIWMb/yo6jgqe5nZz9Be5nl7y9JB75ZYXTO2b4LeK4z8uu6NzzA8
2PSz1RcVtiE7x8o8exeO2+IVuk7fVb7fYQ3MMdC3igwj1b7RG5xv3a6SrfDmnEJWrSBm14ligvYU
Zlos/tkezxUSXaKWc5oSsLdQpfcImd2GTgnAlEug/gMXqjhYbMzOkFt7n4J2fGSIecd5nLHg901d
COxupdnrHcQFxj15ovmC97DHjVOY4Jfuxaqx83Vj6bZQbKXeg6tQNkCULdMM+QekbokukYeQIOxl
vqmPig0Os5h9DGwtlyDDyqzzMFlY4Su7arnwELN2MBmX9nea57Rh8rVZ+nlyDjMg0jmsuRtD2hkT
CpVsC8VzNeWesiC+WkE1KnwbRu3C3NoshhsfPqZFWxPBtphdAwD5HSNo6M3QiMISDuq7uJZdfsQf
afWQEo4TEson05hj90/K4tkA8MXvKg67IOh8ZrNposRsewYTHbiXPKWR+6QYNyjcXvgewfl2JdNS
/wHI28gipnFUx6ALx0xmmiIgJulA02/dOunqfkaadXCkM+k3Twar/GVrilwflk7W6ofxxgXAl7LD
HSOOFdpcaNAaVETVanbP38zziNao5Lo/LypDUopXoQIc13gEg689HmYro5GMx8yxcYC47iFc1iXn
D8r3++vjlJxsQ2qLtj/+20ULXakOJGjgixnTuEaXlmzM3/OLoYfDVW9xp+zddE+ofoqdgdDPuIJE
Dy3/WBXpdnpd3hjEu3MYi3ivQXoA+95GL2M+0fKCJIPCu1FO44bMRFHcHJOIfFZOfgb1/IuHgKXO
NvnPtPMphAL/QeuAkridh7CPmlPNzvg7UZLojFVJDOY4SMg7e24WRtxeII2sjTwUtmPovybajoJ6
j3tsQrBZcH/vZv1j2A1RYjwJlNENKvQVEfp6+POgv0TM2sTeJl7w7GBsMENbfKvJ8yEwAzJZHyIq
GoV4a7oFjRZX5l/HrW==