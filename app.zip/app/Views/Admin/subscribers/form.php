<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzHzyNya3ifmCPHaN4Li0N1kSlP2VX3nthEuffWHzA0qPkhprgQmPdV3TohfhpgcqJyx5hcN
9UnjQQdNOKjuYupEd45oR0E8R6oVcLb9X9prpsrPzaJ8MQ2k5nAA9tOgx4cOaovXdE1XyvQK2XJN
44vw2hTngXJvcCOP7zgEDCLa+VgaDOQ0wNGw8pTTYqYtAjWWBCTJ0rr67ei0IRVAIejCod0eugx4
EaDA13axNuBAJD/xi/KFxAkB8Cs2MKVwii4SCEF1x2Mp38X0OBGOBrINoU9cknu/lVxsS6wZHV51
Fui77dHq56oyVT2lkQ3QnJW74tjtlkbaLdrR8H6XSRqQfOS2AZPe8KHQQOKlOb0ObVPooYVXpCN3
kOQnMzgrv3eku+9rCtRgK6NNBwvIixdu3ghECAUgt1nCstQANNsfpBTqK8IRwZZ5nOGpxSE+SUYO
f0OplK+1OTcn5oZd2MeFQm6w4OO/ODYj9Z2V73w+CCDbZDHz9PsAIB1y5HGB17uIwDilTmObhVbn
5Xw1AQ6x/j21HW0Yy5e1WkDN2EH0nZDLh0ALNrvnDATv3Ldqo9IziUY2KUdBSFeNWXs3yASewtiB
hYlHq9tkKU0cFT8hi3uvhS0F+BDmi8jHuVNoVN+VqRV0lWPQKKp/X91GRqcO+XWgVudQT14boLl2
nHj6RNLtZUpwpuJd5Z02PTbeONYWKG7ZqOAAxmPDaSacoQEFdave4EXxUQoMMx+QigbP3IcgSlxO
i/8/wyq4YWa/Eb/K7MURRJAogqi4TfW3DwK84uW5ZlP70irwtk1OXqicQ5FkLUfbrmPJHcWlSOfy
Ouu7JX59rlLaN8OTk+CjYWop+5m0P3SWGm+Srn53oG/XJ1W37qziKO9XJsxxFQoQKBiw9MV0g1jk
Hn+zrswbTkhiX9tSlr3WhgYonQ5o4zycCsOV4JZm8WbJ/9Yn7rfQA+89dGF1hTtP1QCoYlErVBpj
ZzKnUUMX87JOINbzuAfYZm1JBke9My247CLGLFgplzT01ETPl6vqW1bTRG7kGFf8bOKlC1RfDVJY
KI66q4939+ZUOmxnFl0rYtfEs2X1S+ZGgTkVLdIJjcIDSTFNO0hfPqbCzbG18t99+T41YJlmgPhp
G418IErdyLhj8hZAsaX5JYHWYJvtCgApMgZzrkXw8xTIOx17CQUfDfELUn5Sm4oy+5k0Ca+7wAQ9
SK9ZZjVZfpNYMfJ+Rw98bmOkKd3WlROe8e7Mnuk65ZiM5/fxFJaJ7dMLuFUopJORWCpqP6/Jv+oe
LAedOELW53/UBslNZuXGjMy8V/jFLJW8LGSx7bmHInU7jMMxzQcEA+KcaPSQ6lMp783pblQm42iI
0xk7PmgNYTnToacqsFDWce4ztOmpAuiaUTPAzMcPsqHCDQWUHHwsupzFQnVP77ocd+qsyoTY4Mf8
uRPPpM+2zWkKN0c1e4NeRmah5214whMsTBgYzrCW48DaOTP8ZRkiCXbgkxMtvauclJDZaWISxx1i
Tu4tkJN5Zf4pn87bGuU1GvktLxDEDAmzc/WKtLcrBW0qpZa+awvzAnJaqIbBfUmtE99GiX7HCk+X
hLpY1U+Byv2kCr7KbiJqlygUQWQhn/am4lwuTclIG63HzS9xqxFyswwQXnQGt9/ceut6rCORKVQS
/U3bMn57A5EG3SecdPLv1fb4sqYjvbl/umbigUQD5iWX/y4LOXcTws+wTTathBszcJ2D9dHgnE/R
vEs8kaplI9k/7v1QbBlTC1rm2TvCJlHiR+33Vp1M2RKGZ/9DUT+NHhBsj3yovxYUwy14iWdNr1IS
W6wU9oLQYZV32re8pJ6a6+T6y30fEx3XOLhKveKMd4YxjNTZSfHG9a4+Wl6wB8T6NVheAoccN6C7
6UIZfJ53S5F2KgoFcKFLigo0uoSxWZfD2y2SWpylo+bdghIH6p9jXkJRBGT+93vk2okRbiWLGoYh
Gtwe13lRjBTM+C2DeFZpt619KjGKeEzUOIQ2ZFWmJvRbKbkrkpYfz3PdQBVImycRg3rw9mro2vlz
7ZUF25lSV3bmXrvnT1I6iyKtSPiH5Qbm5Kj5pjR55N3UMbOaIZw5Gq51QCA1HHAUXCtdvDTOmvuw
eGx3pbLRRzI4tHkPDYh7O7dfecGgBoI4YRLtoy6DiP0zGLEFSqJU9xYPr0k3yG5CNMLqE1BTkZ/9
3JGlhpv6YNHwx+xxWMUsaUD4V0+Pj/VcKy/vGlSRJQaYtNVBIdqDmLMrnOkpNJVq/II2D8pmiZPS
gCDqgB5yhoL0IOdotzPECeiO733HkIL9rx/5oQHDWr45ThqsXED/dEGRcfZFe06Ka3fa2pzSLDlC
AkXVRpzdI/JGb8zZgQqWkuoewS6LfsDk/s2+LQDAWMGBS3aabqnWKzPW7WSLf8jLb8Ck2M2vAX7P
R7m2rWdQijFee7aaLBj/hTSnUuQkp6Hd5H/2Rkpn4GLcJbKh2MblYH4s9l2vHm9apdBwS98uvgBW
vOqWVsY5YDWmSmjAdy9ghJZxyBO7x5+8BnFxloxwY6olj5YVChm+PvZpusat0eec7trnXyDV1tXt
FrwNNiScCfV3JGEsnjGzGSYfEuwFl9UZ63QgffnPFr7XnSXiaAD96KTxWwrvriIPnAEpcJv1fvIe
W6au2AQ/KjvdQX60adc4KDk/rnt76HWDpcdRrBzlrWpJUiiwxdNVExVm6DIXrHGOn2kzfN80KBa1
vaDF4JeH3NIDyTYLJIkYqap5zWhBHWgQ7WZjI81Ksfz3qM42It5ffMPPgyY6y5kfemBoKpTZ7sgk
9mrFQfm/Yc0s+buDcfF6pJEx6fOLu0dEKjkEK4X0VEDNtHtHwzCUufl+NoC2VWXQZkPTOjDKqu6H
J2BOk2mEDTsWJWQar2UceBoWT3CGG8EzboOqW8Z9kcLQRv/Yan9wscfbwtmZeAmr/1S5TkvZdhZc
FtfPJws4yY1N+ovQBeMn1VRfOwmcV6sRZTFBj5uhBwTPbAfYAhkj4KOxBnujLEjcoAeBAhB2JuU+
gMb84qrFAOAQcta093JzqPx7kJCRKM7O5DClHdU4sy05eI2y81tR4bbDEV9eIiFpv9ygjQwND/h2
WfEp42p7fO1W3e0k6HUKW/oL3Knw6O4AR0GRtkfJUTEotcNQ1fae9icYz89Jkn2r8eAxay5V34LU
JLmBUw5kt8Ik6DeHNcz55EzPVfxQ/7Ksg+Wj9vQW7cZAlEdwMXgbEbzqcls07X9lacBjq6FeX+Sk
sSZqS9qpp1a/DMZORg4uU2yFyUi750j8EqNjunYQks28bWUFK19Tr6wLoU0ddGmpoufzC2m8vUKE
REsU+kmjrz+O0zzBydK1vUsp7qzNqtjqKCTAOk510E/Bh8QRt4CIXApF46GpVqNhLUFNf7XTMlMA
5lnWDCZppbCkxIBqgFaM52c0QuZgGgwFins0hfaaQ7GS9OrlbYqaRPE9fCwPzaiqOrjX/+rFHLG+
8MYx8++TbVxjR2h0opAP5wvLRyLnQqygXaALOmkA0DrwRGgknYglMfkIpRbkqBc0Q52jw8XJNye8
xLHfVBID6HqnMzQSEeRULTxQU0/jEYouAQdUYa7GTzqPsh+4QbryKHQkrvi8nAzVaT/6+taqn64R
Mb24R3rDJHJmi06YXxozZg5Uti2BZi4U/Jdd5NJCYNYkDyRB/dKeJJcBT/fhALWxUJ20rF5duy0Y
5+shoQOTTDHS6zb7L1iQICE7lIPIyy/nLcGoSYaOPk4zHM+0wnCIJHnis59ODYqkbYR/K4w1oGP1
LzOeW9FHVRSAP6oSYz1wSXzywtRBjW7qJVeZxGkzg4rZ+V5a/8qwbPqvXcqN9Y8rHLnNxlJCzZME
RYlc/gL3yr4LH74uFPW9OosWIVnzhQ4/l2FEApRTPSVKfL10Vtff5w/Lgw6dz9IQurTdXBtIbedi
1BcU0piBPscUA5ohNmzivUpnvBi2JE+6kpEtKrmFC/CvbkqoueT4VUkG6hulMjq06LzR4EpQq+pH
KUxrcqRgkdMcI0MwYvmGbruRok3O2u8BOzPQIVYO1nIAlhNrvPZSFdNy7m3MdvEj1FnAxDbmSpRk
n6oFcbdjBzjshMLi77Uo8RLciEiF7rBaFR4IpzDojn9OlIH6K3O1umFrPpyfbk93yKoNMJqZSBtl
gBdWiNZBkO6gU7yG7XRkICnS0wNrxMoEjZ14a5fdOYvymVjxqyZaEZK7juH1ITqJd+Lgh1hB4vM9
P1+v5pAFqYlVr+sia6XC+GpBhvsvErJ2DRagO98x/0h6/BLzDT05s7L9Zzy1O62eDoW+QhVMvQOj
HBr+QiGRw2pwGZYkvDxLZCjmRdEiRRMSecdtVzOMA4w6jp+qVJLaiCWcdzYsxxI93Nz7ycrr7f8M
tSAdJhdx8Mru0IDHAA+T5AICDSm0DWuHbTWgIwMfP5fE/BU9jmZyDNA/fEXuryeYobdVqJaN/oJl
/mceZB6hGQyCOkjFdyZ3leG742WCAebrFObQgx7YaOT9kKeTru+HXY9auoQQT28l6Jl/LsWAYpTj
D9CnUoH9Lgl6H0LWmBbiW8F0b8NnFqM4nVEjMSv0E0JpLQjltkA2rLpx0AKvWdjjJBw+hgR19XFY
9RH3Ba4gUwuE/01vMiLHmk57WwZsYq4Smq2P1OzdCRm1reYPbUn+gbBKnhowb2iLQjl5hYysy/Ic
BQ757Bgsv+NqlZzC4zlmyhSvbrYIEJMCnECU38+ntPkCGlu2MC61g7UvQABFm/ZKArFbeZUSnV7C
gGxD8hMd4tZlQkiksT4SvqD61CCoWg192HV/sNqcoaq+eXYK9FJyp+zQ/4wlhWrkycac4CaHsT0D
QTXbyO9LMrSx3hqVw9XsjBvM3DsreELJrjU/s1RyNNq5hjbsYB0a3kqG9Eelbe4lcDhHAclLyn2n
KD2BgS7hhUAwLGaAZSd5+Dy9aTYMH42mwcxSBXQsCy+RFyFSdpcB2YDrOWuxu1jtZb4Eystf1uCR
Wd2W1WrlpPazKLd2gkTHpt7R+LqNbJ0+VfFWn+1UP9IOS/msaFZghtebLAsC1Sr2sA6Te18sbAhA
6RnBFHtC95TdODLfIhQG0B17B+yP9jggX1kJppDmK4+VfGl6E6LduqOhe6ah02kfqmtKr9AkCur0
lqSk4rUcdRr4z5+YB2XFfN3hKElohICBSMQCVFwRK8M1npjtGjnoksoD3i4eIf3chPJNY6dMgPGU
V1Ab1S2K1ik+CSpB8EzZqUFwIuZfUby91oZM+STuD9vN8mpLooNDSd7tkAeFjDKuUdKRvzmXmB9G
Nv93ucYWAgpe0/iAf+w2tmq8SVmQMrmt9DEJMarnkY+jbWfiNPnJAViRMBreJTSh+weM+Bkqcax+
Kzgw0VkpvlnDIP8cA27+JlF7YiS4NJxJJrROQiyg7YT6kvy2dYZac4J8K6VNKrMjjKr+DlJXfoPC
lsTEmgNRxXxj5aKragf80dOwGLreusRhhk18/n4a//wcQCODgiHNW8PQyhrsCUkvYwPTGusCtz9M
G/DXdqF86Q3WdxIiIXDxNp7S81IuxBG7oIzSxrDZLgegBuxncOLPoa7zzhs2ei8/VwPY+AxxNYza
13Zny3OGyogeO8+tqS+M8+PXQa8vIf2mRQhSlhBWhkFkanlFmSbAvWWIBPr01SKCS/CAn6d7ZVoP
IioeW/+/UXCDo7S6iAcYqNnPpMWDGyUK3IiSxn4PYxVWjeiNGqE3hZagfwZZgeYCc16LJ+KV5Omw
gPry+A+fPIHWC0bViwhf4zsTGVwNyE2cVOIHr+NXNCzw95tOvTi4hLw7G7/njZbjR+tp6RGN5Zhp
UHp//ISiam/3JtD9yLeWswYA/9S4810gHm/aoshePLKpO/U2HK5IF/Nqlv5xvE9lHXQPOlbZ5MFp
ZPkdV9dK4S4gElqkL5fRDdy2wsJh3ElKZfWiiG7ZvrkjybyXMH36HbuorYLKdTHqf4k4BE57vDlA
a0gfY6cZAo39SldzkT07hHCZPG3vcR1wJi5b05XI9x7iKzwpuc3J2tgYLSEanHCmxPo5a+mH+oO6
0D66Zdvf6UxkKrBjNq1BBGiuU23Mzxxgc802RXBYfscSbbmZioon4Ip8f6U1fmwZcgLRYvJDoS0e
G7kGv+f70J7wYQEOIHSedpWrNzg/ZQvCXt6eTdteM3ciH1SO2wEHpjYJ1yinavbvGrEslrDoGHTG
UhzQc2zRNbmd67dNqvEeCbywLLljEW4S68AqATvuS3+OxIYP05ACjrzgd3qntSOALm9Y1Kb0XA7W
0YmAmGI1hQRWKGeANdfgCgAGGBPX8eawJahQnSnEOZ5QpkoxTCH8TuZmz/bwmHqI+Q5OTbgBtF5r
4K/z0hF6SvOQGR/k4K/b1PrGkhrWKOsKy3dTwuEUbvXX2ZtOJ5YD7VoHbMdJCOGRcL8lPMDJK3Av
0QC8Vw20vCdkSuaR0LQ5p1oFY7znAqckyqJLuuaVNH5bgkHh+XvGqP4U8yXp+dBVkIlBmbLUNoeW
LrZZvGDz7VK/fGN0QMGEVEfOlJCeNdTLC/kV55nhl9rGt2i6PwF4oYLbZZBsw3HeM3rLgx168q1/
KhhDbz19pxj9gskDwrBwasxsCThYgaikPUtorCY2+qdRYC941qtTW5tJrCscnkWp4yNG15qt9EbJ
N1Zee28pS/g84Kw3uZXQkJ/6gFU/yy8ja310dWZ1aineta4GalOanPtkvD5OeFIUNb2A3rcwjpJX
T51M2v+SG5dUebXZnnvdFnC7AzWzh6e5UykpI31Ce+7Oh6dOnFkOBeGCGuVUHtc322ytvI77akOl
c1DtW7dK7jFuxYPEOqw1fvbII2lbZyc4K9PpXwiNWPgD+JAfrRNKHIh/INHvInbi+IiTAUdmdUti
OrM/PS3b/cBn17YKjvFnbMsW4SVVNCTc4z6xEKSuD8dhqgtdarrWuVaRAP0igjqoDIJGTqWGpST0
C7VcTdEtfy//wH81DKL2XnIFDV19jC5aNBswMJ4MAqB444VSTFdtgNvpfZFOMMOg8ivk7MNM1AFL
fh6t/A/STCj6hOrewbOaWz+WtT5AGBWzRSWXgken66eMeUENFQkzT/UsxA7aon+g8pR22MdQoaEK
cWKxAgLmZZaQsrfsIH6AplBrAwhTQ2IPALPt56CIKBYvjK7udSfiAsWMcnoT3ev+/N4+iXFPcPdG
B6DA86H4A9vZy411Hl/Oq4GrjTsZZcW8mkJkJb1oluMEju3QTUSukKAWUnAzdWXtRHqfr6XHZehQ
Dd0vRJC31Vtcxopfv6D8SOnSgAlxuvKKWNe8Nlcxa1nS16RBBLryk+rt4B3soxbzOnVV8zQEppU2
yXvdARSWMeSoYkItxsmWljuH76fHAJ8i9bouL6pTpUZyLlM7gS+AmVD9eFIV6lzdC7AedJPvQSsM
kS/65CRl312WkqB4Hpzj5oFstqk3uh1ClbyHKrJ7EmcsJcIE1a9SJ42FWsnnZdV9IwSSXEYTmFny
bkbPaCc8WWlIl61KRfkPrFXtexKvgNt1ymXe2jK6gtapuZrPojLttFTu/ok6AgKEapVrQcMcwBBm
15VJvk+T+obIU8O9XWj7dpySaK+GiTAxmE9iHhIqhM0bmRMkGv6yj5TUEyTF/ubhNd1bMcGgv27x
utrZnB88ZcjXb3XSQLTAj620/zXQDNCGeyUeTL1gL6Tw6jWsfg/hBJ+6PCpdcYPHGc+jRtsN4L6w
RueizQi0P79EiqZSdsf+2IqAuT9MQSf/xZ247iGrX6+aQutzXac6scUZJxw5NUyeRvSVy81qGI2x
HWXw/7MxniOhufmXz/hu13V+k5GkaQWi9N+9X+2zSFHa7mYA3dq0pluEZZlxnSAG4neluO+wgODq
oyNwaI+d/ncvgOsN8dx/MnU7FxddpvdCZ0MytVBac8qgIy/bhyfydUeXJSQOJ8y1z9m94hSigCSg
Uu5ZvP2e21Dk6shrJkkY9/qStyVmnGvLwBTiKwWNDl7kYD4JKAH0oPBR1Rg6Fp12a5jlAJzZ5O6l
/ZgQAEMlhEDwiZYrdG513kkMzJQNA4j4ZzwX736blZvNsr/FKU8MwbZVvQVVjKfFhuK2zOooGjZF
g8RO1Eu8ydqPOpe2DHEDKIIH9+YjKvDHvCZU6FhhIm6c6QvhQxLX8OzJVEzlOkJ0WZSATJf4NnsW
YEWb9lrGG7LRIUsOKXYfTUZws3Wg6DqaQqoO8emaW5378AymfBA2INgOL//cjgbblsPR9q9y3dDQ
NBV+CZXzQhLctrbvYiK7I+S5vXFlHim4xqcDCpeofTVrGEGDIlpXdVCpua8UXfKzNyvqtlUjMdqE
5byd4ckYY9iF0oUXYdNO7yAgbToDvFj7/LzkyJilmNKQ3ZxOgeQ8PwdfTKPvhtGRrRRGJwNvYzmv
+gm+bvtH8P1YI/8Wm7Jh8eP5OiqnsfUIhoTrWAX2/9yavMHwXs8adGUsyHTlzESnIwBMa0FauamQ
qcP+phqz95Dky0DdNYYLIRETa+Ym3py33xUUTFToivS13jn0EWYhqnnjP/9AlYy+a6+MerXJKVV9
rUlWuQvISdeUSpvVpbGrY5wkSKjRRJ0mEPO2I9FTaO+LMDLeBnKgDBwilw5Z/KGVADH8SqCUayIm
RRAsYxb1Xmh4m4ajPwXCkWOvbXKl9fZkss/cNWowuwjB0Ua20nt/mzGpXpW/SFghwWylVNkpLpRv
Y+miqs0Oe+lCOSH2YlkcUy/K0sNoejwCh4agotMly+J49iMLJHQLDWLsdMkj53fYWoBbdanb5+dj
H/L8coF7Dwv5Ui+q+LJ40J9t1GmvIijCqEp85glhAOLuSGVDBlxT/oU8buqHuWo3H2F9hxhoc6ul
/SVlO7TFxo4TUACcHT4vIQhZTv9VnLWEXbt9k/WljBsxSp4SqyVLxHFHfYyYrInBT49QCWEXXSQE
T1QmLFaHeYl/752JjdjhaWMmcsg/n8lf0MnkGbXzkW6W4ygU3d+WQ/c2oQeaNjnZ/KpciwWeMwvB
D4yWY4/gHsfeZ7aa9wEns7XNcnJe5VCjDlKKNqa1MMd+b0G+raVYeQDc40jwPab2vTOCFuJ+J8lN
7TNY/5QVW7B1VJ6O9FNRkdjzbrqKKtVp8yfSi5DgzuH+uVQYwco1b4c5zOiFc+KCbDXm3oLDlxCm
FW1sCqfyu3PT+0N74g2CfTwb1unJWC2O7SY2aC8z4kLs41t28VEDcS3HGlNS+NyjmgyQuJAvJDSg
0z5eb9HL6MqWtioIVzGAsz+QxMnDZVZ+FIWBE1dNJtjT1rIwhq+CQ3K4kv7HraPjX7QKO0jg78vv
LMe9kEJwOKO4dIfnDfLioE2yBHqAVQBncVBdECXZ90GGSHfST+OhJ2q+ZrHh22KdLpMfqZ5o64/v
zdiX92pHVPNyIAChIAyQ