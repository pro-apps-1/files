<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtrst7hbzIHzy9b9MLt78mr4Y2VBU5O+hk12/CgKuVr/J9vtUM+nooUF2zgKR9NtcEdQYJ4Q
BSs+Nw4KlPm8t9Nbq0p4vHi7wQ/RAAVSpfv44ZemV7Fy8A050ljDWNM7ldSvJn7CvkXmGcJMpvR2
dTfQOmC6f6juE67gwPkcMEmWIiZfW8eqwMKShT6xZ9YR688WpEaCdhYC1/YhRXbNVbGikJYqE3V0
nuQEH5MP+bdo3qos9IGcLBBOib+r9NZEw0Y6HnyO6yWc+zY1KPBfI7XK6YkaQfMZ8qb83at3ks72
FGnvP7TAwzSqNYbypFURQD2CQl3K7xj/99jQVTt/aJO5jVd65sXNshBC2fU8zLRWqs8RvHDGZAIs
6BwLv/yWVwAS4oIa/57P30pHvpB39eVJzVvqlBjBrSpHzvqD2QveVi/VAa9eUytSdu6s449t77MW
dVfK1pDWB1LI5eHgVOTtghcSL+0l1uwuMh0fKWbHLrlBRvZ12LcA93QC5g0SRyDcZRXu/wZbm3De
G7f0o7M02/Bbpk3lXVKB+hQ4bsAuQjFWHIdLTMRTTxWFmX0czPyFVgTOyHUXjSEMNJGsB8YVHol0
UOUAy+3JR+876pkp4qRHQU8oId5e6gd8FKR/B8Y0kg5oIjHY/wmYqijSxZA72aWHjtONJ8mJhyhj
ebyLD9H/CnskXEaINb59MDcBUgHFaO/cjtlogllh8m3lEstkL7WjDhrlW0IZXEriHh6ISLExaAXG
2V5VejW61aTiJuWkmajPV/vXkmrC6Vk6vdys7LrXFUR02CrN18vflr+cMwXvSxMU+7jvp2cCUBMd
7lkrGQetUO1sAUwCC4e93TzlO0Oi0GOxdSzSRr5xPZ9+VGUZTigp0TUiwOIJ6n+dIJg/oUnp/73g
6TKJ2k5p00MPoE3iFWZeGsXxWEFSoT7Xi+nOe1GDdbAkJc7ux11xSAjJ93LcgTDFfNkP7DZyMTlI
LIWgmFDls7N/gMNAhFA7DKOcaRUu648l9cc8g3ToN84EPO03iZqC1ifbOxVdo6WQdH7UlQbx5jx3
El9Bent0RhjWhE3vXvmelE0bZImPgsz3VDXa7zlFw4rt8EkT+RVV2AOitcv6K4gjZTO+N4U9+Acv
IaAfhX+BiZQwlq77vQWRrIiCm6AXEzFl7cLIK2q6sJJ5XvdcTJiB0m/hNyLHf11/v0+bJlF6nc70
Zzk9hIoSHdvZImFo49gYyK9BkB1ns0sG/UTlYa+aj93raXCkPa8p73t21HJc0JaFkoKwLwduI1sG
NbdzicSFaPT4dutA/5JStgD7bbG5wF+BI+biJqEbUsNUYkVNCFyXGhomRDG70iNHNYMV1ecQQ3KV
zXThzhKlOtcbGY7ZOtVBYVx5Ms59/2q2JhbhsRo3M/1QcPiTZ7aXSxaaT4++iNfbqP07i9+tJT3A
+Yv4n99wJFwbwnuFOOwL9ZVLfcH6u7z2sllcg3uHsf9rGaaeFs2GpLTdhVCIqSDnrCRoSTJVetAh
B5O0ixjJMah618Hf9qyhq1WtY9c74XJfciRb+vkA6bUo60l1nx2WgGCPSV5+AA61P0qcZgvi55dD
qgM5eUYO01Y7mi/DAkklA5WPfQtT7SCYXepMT6furaglzna3lL1p6oRsa4hNLxa7LnDzQx2sEE2Z
dnoqG2AgwgnbBlldG2gWDzkinl2tmysQOagkkPygLrjMUmIjyL64mXXpqfaaQ7hy1nbMbjTFIys5
y0bpu0AkQGTSIUv9bq5MdWFpVp+B8N2lBg525LoEMbBpnQeviDbZSJA9BNjseYeg/rPjI7ZFuI4F
8tuimcPJEqgX0vbxYXVduXn746lAqo3a6BtQYvCA78OffQy/IMYPa1u4SsaH+0KH8uVogiUXu4F5
NrV1HebVObRClXFfSQ+BnnRF/0d+SNjecLFqgzSaHbaRL2TzWAHt+Qql0VLyIYDE3gbqFwibglHC
mfH5wryUlRdmmVAicTAmlpbIsYd/eAfn4Hxv7Q++uhFJy5B60eAHKmN2tiQxFmd/VziKH2XooZMU
yxrAL7/FqwsfPAq3ffxuV93jdSvtkQUKE67prhDjN4MqaXmBVwk+5C8aq5klFaRlNps2cjeAtNm9
e1cd+f0VfekaSBJMNlmXGSQRthMF1Hpmln4tRF9WPYP2+D9xPPktUoQ3snbF73wfaauOZexXrRxv
8tASu5BgrY0zNouKOGLeIXfCzNPRdLEq5wdPvQQCTyrxARPlbFcb1ym9i1/bqXzC7xyJahXD5KI0
yZv9IT2EBTk6m+9CxC8MXMs3gmCn4hWYN50ZkkNThjsuBEyN/FErEbLAt8wxIWvGr30RZBzFVJIr
YPimjgefX4IUX3rawPy7z3sbOmdq7Dd4SLKEQms3j7M3Q6oa6/ofSKePsjYxaAI5sQ5WCfrlh1l6
o6LISH6qJT+lCQDrfr5zVr+pfNi8PknOpVJESlBX8kOdq7IHgpWm220siybtHripNzGfot1uG3hL
f5RUw/SNXVJEkw+CNXVTU6DGDYXp95gaE7mtqJw8kNQvIH1lqFDivedjpruJYzkBqMYLhm9nUNQd
Y7Q49PbOngxnYK6EQoJQ6UtqJhB0l+bunACRnvTaWNiWX2p/xAPiUG12l9Nnf5A/2mFdirPqEhq/
GuPtOhNtUxqK+DYudvEIRnWJdU8G2X/CiDVjXBcS+mSA0AYgcyObOz4D/9wZFV3BjXaV7nWK/+Fx
C2Bp2veX43fDRpkyTbApSjqxC95vN8muzR7ifqVQnetOyj4QSPvcfXQ7QVVDlMSacObm6HFG2YSY
RPn9cly9jD5PE1piB20XwuX9Zh+Jk7YF/vzEg8H8o4jUuBMv9u9q3Ozf8Afon1AXwNG4i3MQGu2z
ruabXPBg5y7gmzGIGFCnA5Phv+Ye5Wqt8tVyvwtybA+q7kx0p7tpdTgergg4Mizhdq/I8IAw/USQ
rUd8zonAxq6sY0mRPw+LdZzCEZfB4rlihnHvYBxYWtVGGPFUW0OC9DW/DXu4kjqJR3Zbui3odrIN
cYJOAYD2G3siKbFiiVhw+RB16D3TW/DeDr0bw6w6JJDgpT2qu9whAfgfXkzxvuE6RFk0fvfnyX8G
LPY/25jxYP2BMjcaoxOQsMAs9uGBs15v9IOpKt4wsrIFFlK+aiH6cKDUKERY1rwvTRPldviz0Knm
nWlnDPe+wTqeH6jSy1NVgG7JaHq9ybF1DMhMGXIKT0Lqz2RLKlK9CW09loqLZvJg7CYaUKfA8S+C
YeLnhDLfRcXB0ijZHbHGOM36t3F9rQqoWYQXz+3kpPQMfObIfQpO1FtpIXutgdQnrXnpXCzwGYwT
Own1YW68t6WH/fIllnrHtggkWKVf1NNDAJbbR8LSN1iPG3symwsZ9VwySoXLuhz7dPvrQKuNOvRw
C/zkNPbn2AHa7x1vHru4JUTZwpwFO4j9t+qovSB2+Bp5kW/HlUPfX7HkCEyYvV1M4NP9LoSmrHgt
uRwMoYRoUiiYYLUZCmCxeg+r3HxweNMcm+KS3Gjj2p8KUkcQXbZde+0w9n6nM9QgDfbpBOBhOud5
XvmwWJdiEs8K0ifiDqbYBXAR+prVQxxMLAAMft2kxGsNxxNaUY7jbS5J8X8uEnKzY35fcRInlfWO
L3OdbFW0WzeAT89gHa+/4ABsmELidBK/sjwKMJT8ao8wkcVUaQGNO4BwFSsIbZgI6uxrOHRhYxIj
0MWz5puqwv1ViyU6878InjKaBkTcBAmrv73b598aVhv4HNq5+94SEh3PmqYM29X5v3NbURHc0IlT
ET8/M+pN8JkNqtyPmO5AaC07DjP2L1NxU0bmlk2sIfBkSd8+1mJ/xImCBzkAywngr/xHHCzTBS0L
OoJQwX5phuPbmSpbulByAgVAtemX1nP/Ru/Kf2lVpHM5bQjKlwkT1eVa4eIb20Xs+yroch1BWeZd
RdVbx3a6LWsEgL5TRku7rINQ8n5kt8iCMudNl0jFBvmhKWaE1QRBdRVOZb6WX/MG3giNu0Pjw312
mF3K2qLBn0dKiNVj+L0wfW0d6V3PRQCTDQre64bsJGRkZAQDn6hQAbrCadwsH/VU40mQAFse4mLp
SxeuaFOTb57/hCxKsRVCgw2ZSDgF3P/rYYcUT8GW1SpLfXIW+RsNd3ak6CggY2TKDqcLuwRgctV1
+Iond+NAaz2UqicHJlLtiePxtmdIRCCsEuNlwWk5GUnboYnZSNzSKQq0LMP7PQgtx+sIVN2YfETf
Ox4+l29FQzKg6InmY4igJ+S3/nD523N38WctRMhtmKVqr53OdQ4l7TjM3GHFc56hz4DRAXjxbNiz
Op4tgJA9ctic7O6s0MAoSkNvqUb4uy6uHgLKDo5dpp6y2ODaUkHk6ZW9uxRwb5UXtUM44kvXzjMx
MUyIwBf/tUzsezf5vRPYJtVeY9HGESYNJ6BpErEIgRlmMwcaK2ymRk/bM/qrX4/1C9eZkn/a0G1e
zKbyMmJlNJB628yhIi9OpnkKduPI4BxPQGkSk93KSaTHLWOQCMTlc6oixMC6lN39u5fwRpj0Nnq/
eVmViDgO3bHeuo9Lmt+KKGNDZ6H3ZfROR1rC2rcBa1uPXE9M8KWU2MX1OgrYUv9qDeVaoH5kkhoz
UB6jCQ342vnufpA8dUXsUL5LqRS9ci2r00/xNjmqjkgBj7TWgUNvWhIsi0C5x6hNCyH1CFw4XPhX
kN3zR6fotc7lRvXy/sG2Wse54k56afsTXgLboOrItYD0y72zH9ROmIsw6+kSi6RJJn3VqHP5NYN+
BMPkVQag6C56Ryqv2SGB25SBIyV75LobYoOEzdkUEFo26dO+vaB/gm1mMkqdmrDit84NRwR2zxjM
po9inYrl+a7jlqQq8xMAFjUFgc/rzjvKThgPxAezJ9MWun3sfFOvXf0aWpwWA4Dzd1/mp4n1VtHd
8CxP9LCPK/G9WD7Q2stx7iM9+ohxL9Ak0tyXMWZgtY5jMsqKiPAzM6JgDof2oTl/A9yzBg4V3sV5
qXnikYOwOB1OoQWJ/uVgYEjokQ1fEcSlOQcJBjoK+7Hq6ofi2y23D6TsiRAEdv50JCHlrwt3Sc5S
vJ7c//Xf5XXeinMoYnMvuZNSv5nWWBXXgS6T1e8P/uw0G9FW+Mgutv3F9xIVCdl/bvQWc+s7aFBB
2weDUblReSfhI1fUifsuBnLaNNI+Wdtucy0/wjwWYk0Air/aCF3IKiGMte9zq5xRWNgtl1C1wjap
rs6eqIXrunjh3GKeOeyvrqskwi5p0yWeJ6w2FwJtqvgpOFDeobzyCW0ckKut5unWn1fCJI8BnZij
qReA/RJ70ZaQTAVVInAxA9xCsrEODujiNWSziUniw1DWm+2C61SiHVxhlFYIbxxuRAnqqWu95lU2
EEikmtj50LWtfnksi/xxXOrfbZ+HXUK2wjqt4qGKV2RmpYZY7pueXyUgkbiGxF5imLh9tpJpm/KQ
32O2KnW6kLumwMQAEljuomSD9FzX5Bkh0/RMtV8otN4IOfBn8nFmZjneNTUwwQIWBwhdDjscPxcQ
JI6GxDdEKQjBVgfznAYJrdGxiLVkL7IJtdeiQbfA38ng1zG/n4P2hru3T3+1y3NtQ9FW383/RY81
FfYNz/57IELR9VGuhsB8wnKLzZcruYwCfLtBY929Jj0QEm3/ZHYQ8dwY6KGQ6+yCOexMlwbvjk0R
rx2EY26AXXt52NsIXXV3jyW+Z6sUWMdCc0W5riBuJswCDnpvCnAosrMOiO//r/Xp8G366vN32ez/
XIgt/Hb8bPSUJ9DrgpUHxQFsBCtTqyQqQleZaND8Vrb2JVCny7XlcLOlwK/WdkWS/yuh25XppexI
yEbyzUMHmBOYfjW2G+h8BCYnYvzjxZAfRSq6zkTjjY0S05BE8n8sNFfzZY19DOU34pTrE0Fqc3Kp
ri5Qxe0njYRjojTCeliha+BzVsurI0KNCQcNcr5cTcEtwR2i6/xaX+XZRaSVt7PdbMXaGPGt7joy
hkH+9daNgM3FAmUbwTyB4YK5CIZjZ1xfm9qj1IArcNLRNPnCqMX+ZJY9YSZRojVEyt/7Pm2G8t4a
hon3AITswTRtbrlYxekMj/yLty76Bci9ltwJeYL1YVMILiBHQyZ9JNo5s4T7WypTbx4fLldj3N7A
s5vtJLN5yLZGS0H7S2BhR8/kf3b8vedMElIBqks3hDwgqC3tvEY7LsPXUU621yONbQhEgNZ+cB4l
+69Jh0n7BYb76LWI4obOA6kUR1H+khSl0UkcQt1SH7Q4+l4ccMG0jYlWfaCP4TyXLfwc9hTGVhWF
cmSriY/bM28nNwlvJU+zzrZ4+5l7wgBxLHn93kljV4WB6TbKgXyLVk0jbkGMqwq9GZ/YVOYpchaU
UtTz2rXsjvJuLUEOVG3gOrFprhDf8oUURRxGab2+vvnbj9OLxKTM4beCAxK3v+QHQP5RZU5fUQgi
K5ScpWjnUgDAvTYziOeGIsQYDAbj01ZTULlK+t57lOvXabQK/WSL+1ypKzruPtwRKqWJE/+YxzeX
3yE9PEAqgSTZnlDd1IpXNKC1woBk/SaaLOv6566VW/CPTBaDzc8cnNY2TykZOTvn0RX3iv5xHMjK
Ay7ZmAuitChe419xvvRLRX7j2qt0fwCq6FU/8zhHSkEhd3Yu1F5mx1XBFWTrZZsfCSHpiKoWya+E
R7h5IiSqkb4LyjSS8yLdLyGYYxHqNLdvshfpXuxaX0IZY5mODW0LO66b6Nds7x/PK2b8bryBUgdH
pr5eu1YcSTvizyxCw3P69ybw8VjHxfMS7GxHOXqbygDa3MRel+WtLjxQ56taZzhk6+po/FYH1Ut0
k081v3IZCIjQ1MWIuhvCuEMQ2jJ41fyD/yNeEH83v7+nU67zXcgRBs9D+En2xZlznZs4fR8TWxxO
AexmxYsAQCIEIwm10xTVU9RDW68r4ZcepDgBPp9BhSjPsdAXPGiE5lyQK1FIjwXH7kKTwYIH0CZ1
t69Nq4fUotFto6U+Cw/vEh5tTzzSSVJMNbHE3evIenONZdMsbSyiJQBn0nY3rZQyi3whQYHQq9dK
gJyjByXzG599BiQL3htXBtXrpEQIXMg8JcDcr37hGzqrVj+kCH60QzfDT/I4QZUuuQlQhlqJFzI/
Fgmabt+6UICcXBT8CW3c2qgnR0yPpyKQ2veiLT9qZ4SAZO7VLeEX4OnjlZ4x/ef/YV+huJTgmXJR
yQGtASOtSYgMyGcr9mNUaIUMIbsXgZKq4baDaKXjs1jKcpVO7JbP9XwGMmtxx74ZVtBnkUsYwCY5
+IB6XxNMMVN4sdPI7MG6krmOPTbEYSswrVJYomsWeYV9wJ8o7tW0kIXBz3k9XPTlOKd91ubhX6nn
lIXdiJ6OdXTT5r1tCRUsV+4+HNa4xtBOdpcxtoqYYlLAuVSsieZ8Y8kuuig7Kpg8NyZCD6BFhaPd
mnanwMSOdLgVWSXhIZzYhJhEit2yq8AbOQjPnn+2N4Oug1UPBos4D2Sd1uD6GHvbzZxi7ciF38zH
D5j76JUh/56LnFZKDvQR0y7ssT7MXq1aWb4rhENF3XwDeeBmimPkB7P0iTmo8SOXLf6rUmDkZd1/
s+iax4ME2qq+GskaxXKx355HNLwfUOd28IYE+w7MgcpCvs9nWawzp+a4mKZcS0ZClzwOS2IJgQzA
wvoEr1ahJhJAJJJGX3cDurvoUqrAMD6CwzAQOTGgm0xEMclXzgfJbcQDZtqQwTGJJssUkVJNg7g3
/RmoLDMbkhG2xeiKApgwVvwNlkmqdWUnhOJbpOMcocFZKNc4pX7kNcGd7yeQxVAtfHKRnU5SIaLJ
VTpQf26eBoyPsbhu0ax5/e7idd4RBj01QYvymh1VExjXzBinoIOOzmAlYkCtuUi3SQBMYPp55Efv
uXpN7lIv7eHPERvNhShuFipkgXmcfFbWKlmgvKcGsQTPvq99Iivlai3c+CnsMY9OpmFKqkGE5gvS
v9s+dRHPRZ0hHVurItFboiZ8J5xJcOHCbA2MKlg5di+BPQqhPJ5g8h5KFo6hJsLo6E6GdCFFm6yM
oEPDpBcRS0CG6ImLL0ydEp1lPEJS3kjn1Zj7MYwihXQx9hPLxZq6eLiKmS0sKYh86iYWsAI39zxl
pyyrkfSlL7ImUt/XBwmgbxHFKK+3hx0Dk9j/W0zrPRmLLH8iLCDnAXiu7qdLWRwvIRSr1ghDimqc
MXiUK1uvgz5Jy+ZpvhsPj+Xzm05xgM+DmkviU4Hn9ynMzVyNHsJc3DPrTI0u6h3FhwZhCmi25YRe
XqIQFKTmTPX/GEU6bIcT1KmghpQCuV45t0zf1N7HnuLWcVMIeptCJEVmk9k08MN6TKpsASpVCIou
N0OfsXoLkR3xKZRnoWsCExCS+nu3vOjvREBEIWiCxI1uyx+F+XXognqLkNghqQ+uUetOqWdZvNHa
yXHx4s1ymxNTIKJ6z0iVpQanhHHBKc3fIpfTlea67PdE5IMRskB5BEcS9WV4RT3WDvqwJ+a6wJqw
JvhpWaFKzGMXAUaOyymdwQMx7JGuXxZSCsfIdgVRpdfUmS1xLimMwPe41Af27WX9GtbBPLY+qHin
OCut7xENhr2QwkVmCiuRtMWLKu6Ap7GzVRLbLIc5g42oaCb9GOt66cavvP+Qdwg2PKl4syyuyxFW
yHN8FrYe+TOGY1nx4aQAqg/vu3z041kAoBSE92oWCEEWt0XD61C7Pat6ympJxiS4p9BH14epMH8z
0rEXD9G7/mpkA0N7lYiLZChmlRG/0trQ2T/02M656DyJy82qf6J2NG==