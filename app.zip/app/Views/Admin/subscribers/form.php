<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmj5GH2kvBadjwhKCsPciyKKrs6PIlD3HTq3DzzI/rU/MhvrzQ1zQ18MQhiFSISTZG5aUH0E
2hrJztMTkWvY8uFKHml7npQ/jNoPbPiK8rj9THwK9CvJxVFEgqUZvrJxlKIILqflEP0EavNSh36v
0l7mFc9lwdIpNCk+C/MZnCxJMTVWu4Q5+MZ4MpdIAagwQ6188TyaGpcM3CsCnNcy+3TeooBlYDZN
4RZdSc8gzpw1DF7XYBASxL7ZemdwVnce6Asi8OMd4stHIYDDfEAKa9Pgpab4qcfC6RRSJb3yewXQ
SQshkI6d+x1dXN81x9Nja/J6bYnDK3yp/1LiV7zOZJc9YNRo6NLHHdVfLkGZLO1XkONj9D0ViA4I
iOBuPqWGzjoAlAzLtj0WUFQSUYILs7X3Qw7Jmo4JdPZKNKtGVFrWq7e7lqQHrb8aDu9GJT6gzM/7
qfwS7GAzV0EugTNK6LZ4YA2uQvG84jGoPdTy4sTd0vzHMI1i9S640s0YgHRyoKv6jvJGBNb8534x
cNc1X7zNgBEBhKex6iCoMMaY8WlJOg3xhkQej30qItRqfDGuYNjHdRoO/U2LVTSr4ofJ3jTxqv5D
+x34FYKzEGOBs1rJ4ZIvtCpBf83+o3jYH6eiX/LA3tYAf5na7mL/0Q+Kpv/95FbltMM85J++9POo
vRf+9eUcRETWpkk9zGwwL9fEfHh3NsXF+r/geWYth4yui0nmhxGRb1hJQtPaeTw/p33VenZbAu4p
U8ejllySdgoVjtq/RhccKGZji1QSAzsAyBd9gYrt6SJd4aSBZeP5hPvYmiaFJDnr2Hf5XPFDG0rJ
wBMRxAcMuS5dHnu6TnrpRRUsmDedznXt1Z38w2rAFbAA+TF9KhYnUn7bd5fre/azNzi3C0JKKVPr
KqqwXo7B8kvBeB1lxBrLOylYryzMQ1X7znQ9jGmV1bJd63IPDO+jP+/UTmEjLPAKiSy8x6+qWBfO
2FUtH7S9BG1yyU1RHoB9nL+asFDQozVSVWzoG+mCGFIUY8FoyJM0oJDArLy6JvK/F/cjeH/WQseB
5K0sfN6P0dagjvS2NuZo0tpFU0xft1Ko6809cz82XJbBB9wa4OJEmDK3Mmjt49ijOUperELfuQmL
dFzEA9hbc9MvjDiP84djp0DsU54LsNPQwI9W9WhXddLaj1UsAAPtO1e+dZG2iMW+aJkzh6L+Fc9I
sOrlovRE/xUEdUAd/WwsUPfcN84kCSeluEeR+4TFmE7C7BnJrH1Y5aZ/8j/f0KvapaE2SoSnJyNf
9iaXkDX4ELHVDlsoYIcZmFeLdkM7euy8qjxKzcerml4PrAouTxKlPeVs/1vr4XUnLdJOyFJiqeDa
Q0V/BDaLii3xKU/Ml6Y0H1RtsMdS2VcubVkY2aM6rWAhf3k+xhtz0tEsbu8sx9YchrV3DugooZQt
TtXafYHv+8gVdX8TdzWD8mj4oCv7BRWVDgB+apNyPaGl92tzAHgBK9jaGIa0q98nhzIgZOY86zRA
GwNua5ROH86TXO9TXAY4PivnI0Wrwl6RUDGusAc9g5Ttqtqdesjh+6GUJ5APEtb4/WLPa/blboLU
2lbQ9AJsGxrxOtAU0sL2ywK4TADb8/lvs1H1/4wKko0C1v/tkWl+vYlgrHxKamlRxEIT5GorNQR9
FjQ8kHwUxqNK7OKQkayg1Evd3ANf7GA4Fv+cOB6sRFXPNmEMMCEb465aNTJREO1NGvHv3gX/BINW
bNo6/G151ktDdjCufZ62R8v3XqAcXTxQnzwrZsLXmQfJ8+rrakXBQO4U9PHdDE/xPc5372Locgp0
yjpnPp/4Q0wzS1oZ++LUmPxDR1V0Dk/oVZVGHX83EkMFZR3XZOLdkUrGvUo3YON34sJOmihI90o9
e0vx4hXhmsQuZm19RBtVUt9Vnvl+6VoXOb7wgJerPePFCmJ7gZaI4gAKWY1m8niDnEsOD3WWbCSZ
1dZXJPRfTbSYktT6Z7UpDxQ7d2bWHr30HHhd5FlMY6aoOal81hgWsK1+RqHuC7zNHPfEw2o1Y4zT
//rB+KGhH1C434THsjV7yWoRIjwp+issnb77pAH9xlC3d/fDolL0CPFMndRYp+cQ7jJlBnRGTJE8
RQ8q+G8TQpQKkRyXeYx4v2swQyEB5MVUL7KEM5N/6WoAFv6wfULRix4+sI+kZl0ljD8T6fePduUa
6vyaOV+rm4w/kxI7desoWRlgFobDKUnn9xEjO80egAEzHVjdZeyrUHkZiWUNv1aWf9F0apUU/WIr
sexPjAxLRwuSDmCs7ClKAnaJ5Wx65jqe9y6SwLnPTDCHXlWSk14L6JXSTj9b1iu5iZ4fYwOQmF4s
kHMp/T2hMcF0Xoxowkte+z2PbOjHqBfz/MdZrXN/iys/hHHQ+zWNe8MDpQMMzE3lfUZeLnEC5WMg
3vL6kwVJHbpnM01ziFa3U0qql6ne1i5xrcRcfpiEaKX0ZECPEbZTvMdllvnrWY/G59JL33gXP3Jc
T5BC+Xft0ccz5WXCSmxassZJR4c/wJ3/Y0bUa2gLDEGIxCTCOgWc75ylcfGZeojTuDIrGJ8lw2UE
+99Gi77MqMbk4R8p1oKrJHdDr9IHWvqwPyqFNmmq41cv89aG8gGrJmf/f/HKMzcrFVXLkDDzdK3r
IXaKmzDZoLkUbTZXhv+rjI3j36Lda3WlQm9lKzHsMitMOh0zqRzT07R9yi3KR2cJ27wcJjsYYsQg
7S42G56a1jc3ydnEVI2Lb8E6PrshFV8MHbRvGtV5mcYt7xVTffooA6GJrZje/JNmufMWOretCT6L
gpGwVIzxW88IJ+u7e1yHa2cjy+LdjLreU1qa06+k5eWCdxj2KIPyL5TiRvH+O6vGIs6LT15fSSkQ
NBzk3epnRbn0IeDjrByDAl6k42l4RcFkCmv90q5MmiwXDHR75DkvPmfAZY0t61rZv2Bxx124nLXz
+6x+bmGC2675J+ewiGUIlNkivUUfW4fOdOa/FG6gLLUMWlL3cyl0xNqMcTk0vXhMDMotnz6XphTh
mZgc5lrxtE9u2nGWr75yn5GBMq27rY5Q0ZOKN/Iwedvc/wfhipOnnpXIw5CluUD5oEyKACxMk0Zh
Jm335EmkfmtkapVImZqD98zIEtoTwHGlmkHbi8mCfGljSdxPX3ab2aA1B1qhhN+TlVl5LkI40oyb
bgXPndltmcXu9p7AqatutW+LNvIStac8gUKaTFd+aHtQ3Sd12Qf0ryH3xuLvIjQGtbTG/CCwqrYq
nmDSWWkeJgrPrRrsxil1y6Yk9W1uTxau4oimfAhCe8oE3133+M7vzK6fBXzInPvfAlsfLmKVQ14m
sunHtrrrApUVVX+OE76SRhvbuJcRcR8fHoqvzNPIgodb1KUCGv7uFdqfnLti7G9WvMRA0egzc+te
Hj0h5WWR6xe5+vGQeLx6KyBTrc35JSJtovt81wFXNW+/YDKSVynPmEVBNRSVC3YxlN9rwhmTLhDF
2dFT29GcjQtwlXT+qW2oUxG351y2sEtwtKhtT52dyvMR72zIVZMAY6JNtxrJb+PKd6RiNUR4w/6a
ZjiQTUtiz7LsNUxpqjVHGFj9wUePUFQKRxj2mMbxdZCceVLv0slX0+nb40QVeCqXgvMSL7zZsing
Zad6nqDZhQs9ZhnRqq2Ojoy1qz5RZkSRaEYX2kQkBjIMoaHMZ1/gTE2H9kT1RcFRbsvUU7MItGBt
9U0d9CJszsgNYw7n53DTK4hsPphGpjtqRB0IYzN60UdkNF8wkskqIPWvtwxC3/n8MoqQIxy01Qep
kjkhjbkBrAHyHfV93ZsKX+QtEX+XOiSuAtfSf2Y35hC4kz0PRZZCNVIb7d8YylU/2vsBrq+nTZze
kd1lTvdEBvveTIV84d/AmR8JQD0hEYnQtqS3E0M+l0/6D9BddoabltLIEWrJrbeued4PhrwbOSKt
XSO5nDYr5VkMMGaOXSB/NF9EtM8V6OaM0IzBdUMA2kVoI0JpIHoVJLOQ0MwpQP9CofDz8oeQe2GD
6ukoNhYqYH/iWV3b5MQEaO7IDJO6NEipa3Eb/dgDBSbn4AUWCuvDdK9X8gJPdzBubOOOCQxV8TRq
Ji3JINtgBIm57EJwgXQSOWSt/r8SITZsu51bKwjXQWK5GONLCmcaBBgJyUk+1+Q1uoohbxGm/Ai2
0Y8BG3VomWuVwwU7BGm90WsYt8sX+0sMh0QQdUIDx1Ns2wbClFSAyikILPYWK/Tal+vKxzvlDzAm
YzQ//NoqNamSIJi8W5AS6InjS67q6v7fqRCrPEpjvHhp4R3WdDLM83cjg7AG6/tHta2X0B70XlWp
+lX3fAeIcIl5Zw5dFRjOZ3IxeZqD7DUf0OfOhyMnMZKn0IULE5ZEHvSVAmnj5nlIg1ExFHuRrtLo
I8ZTad3LkxW253taqLCNP1OaFS6QpuF0H1aUfe2lidA3s9glkRiQ4phVqLhVOmTGban1ybu5tXDh
6obroQWRc/ZhzUNcgoj//0vaqjCUborCanFDbOnztOCZgZ4lYquUrqeiRisX/jQkMAEQRJ+M2JUV
hpW4RnQzzDisp7W96os7hMMkP9xtGTgyQPXcK/jaqa4+vm0Oq+DzuGtO1Y1psRuBb17+x/HrIpSR
4MANPp6RN+CdauGL1cGuBK16ielzQO3AOafKh6QCgcGdId6o+SxJbNtuD8bPCga+aJ8mZmXnD6l1
APtqawpTwN/pjERmVFS0sq41r0XocwUyQnTBFbAIaxraWcOO9Nu+vznRZ8uQOZQDyxtozqs9Osqe
xbpEpmzp9UAvSnf6fXFvYsMaMttM6u1nrtZpsaQMth4uRwQESQFtl95qHXJw3qatB9A0nFqzvOsU
dfq+WuW6CDvHAu59hhW+LaYjGoJxBcEBua5MT8jt626GIVJUgTKtw8ZkAeDI9Qn+M8bl85rfNBkU
OI4GKZPRpOxxyGORZ+NwjS80kaxFlwz6tK88UZvxM1S2975oLfis5NuJTJCin4C+NIY4INMNo4cD
zdqGL5bmvnjpfOdV7/Z1nIftjhgrY/5ded7Th02Rxc/UZvVhDVWQ9k2xsLYEo4+vnhU7ZikSW0xx
JBkXB8fjd5FxrvjoiDvKAGb784p0LO9MLdhyOIERweQm6LebiwiwxInrL1pU3zEWu6H3gxOGenB0
iqQWZfDoDU6Aui7k3ewc0u/VMnFAdk1NoRj8dsMMTfU2Qn0AfLs9rfDeLjBgPMJkMjAQo6ewrbPb
sV3wiOlu/NkI4wSV4EjrMIhkqbtXNxD5CEpXvp5StAZB8yHYP+atZK4HUr6LIGjxhUQrn0vLdsDs
wrnOcRjPfmDen7xhqKQ/rW20TgPlDX/FEATFBzziLf6sS7Kfb/twao3YGwy8IdIG35PRCNLFlGHN
olqivDE/JMaGkqPFnMaKaIhB7v40ywjcKcBYb/3//Eu41dE+BFSuh1ZS6vSSv0q0J86tfk7rHiRd
pYj4YYn71WxbzG1/VO7LZxZv4BTWbYT/wfMtfGB/smUFsL0uYR454fpPVPnhBIThCifpNFxXIomV
6tpwwicR84HoU8ZEmhSSLo6syhBvrhA8xHJPJuqxDh/g5k4hGghjKm2avzeUh8c3hhKQIMysvxJN
1Wqn3BRtEMv9gkA1Gnl/54JIKENN7+hj8l+4faZr640hhaaNkerBMyb5wHQctgZLdnvP5o4MhMJd
n3V64hdqExzcBFTKhZCcpmq8hiwJQKurVUb4eapdM61JYiT616hHvHkJTbUQYDKWUC5sM9yzPXLq
sXDhhL5UcpyvWlgwoUnItty8utgsp4fregpQ2YkRLriAlHJoa8iYWYByL3A/AOyUucelC+r0ETto
Mw2Jmd0Zgjl6vY2fa1num68LjD63jn+psYxCqNWID85WVd74vur9A6dnNDAox2xCQ0OHXG3wwrQ9
8jrRdr1ZP4s6OaCIaSBa+y4DMLuzn4hcij4PsB41wXmir4d6NRpbUmjyBtk0dzl3A1DY2jU1vhov
lFbsCnrybsxj4tIYXb0qJxYyW2PUHFKiy4Z/Hikz+bxjP2Li0xAtrHN6j2XjgcfmcpasNgudbwSl
Jwm8AWcQUUECzqu3PLyCRozldWlvk3X1wFfD9ORwRT1flpUDw1ytZOhgvi5XsdBhRh6OaO9U+8JQ
kojam4WFkEJGqHYnLiw+qC1DnC+Y/FohhtDF/KSrBoCk/uFnEKQoXmh2f+hOnn1DbrPsx2kOnYTr
plJYBc847XX7yK6sjuKVO2fQwVKncgQTu7znYb/u+HzuyBhAWW6LRiyp7XUTmc6v1hJn5w3Daos/
qHEFDLSQTZzHZs0BJC6f5EIWCEq9O9wz8hWEPJXPesagDXdQnSA4MdJxnbR8wYZ0yqtr+qi/MpbC
2ciCfD3g4vdIfiC+/QyEwNQ0stss/xSstzlfH7W8pchcO5xM9zPPWvfqGkEDdgM3NPq4T/ceoERd
E313HbnvknGmMws+nN6Qp0i8fuzUBlNjsbTEFpIWFUFWTJMllQLUs5o0ovESPaRgPdhgwcxCjulJ
u2+t5ZaEASJhNz0WeUBNb/T8mFcPp6TGNGsd3Y444ajlchh/StbgQB3HnItfkHxuAXdw6NXQ3b3m
afBM3TEOiFERL0cmc/vm7x/3k8b/VQ6ZVr4u60Pp+39o8ZjpUnGlPLJ97Amgqno7E7GN1b//xiAB
sIMSpQuPIuz1jbWfaUBD30oKQ0eRheB6DhZa7Bu9NxLm3eTq9wLO5cTcZxiDfDDQYjmb3x/k0PqT
jLA94T07nC79lONF2Lk1ROk+eA2scIt91wqxI85IseTWoDvmVhtCZUmcKev5+7zvlDd+pTgX0Kwj
z4iNXtO+FXMOHT7mp3/Q8tm1RItzg9i9RnMXft5olLgGwzLnfNfBb1M8hw8mnpWsASZ2nOeLpjhd
DhGc9+BQNcPNIbFe0dPQ3y9Nlt/DJCl1rU3jwALUmbfWYFZ0kmec34ble8Uwi/+Rk64j17oDsmtn
9Ocu3ox+RmggK4yiTRtviEiezDET3DwW/Kfwfa8uBv5dCsD6D6/n0EYbNniRyPgfQLi1JmyQODSN
p8vfb6L3ltmm7ibkRVQA5yTW7IY2vsKaHoWmTvjsHcPb0xKl2BPFawaOYxrn/VPkp6iXoLsVCS8t
8ucxG2tm16fHZ74k8+AiUDYj/BqxcOdf5JQE9hmQkfdlfL0cLj9hcQ4NoAm/jsAfnQpggCWvtnYL
83TRFR0nfihblygNOcO3iisbK2d4VaTJ/ukWUFRB4APvYCP2oi8P0kMZK2wSE8FGOZIQ0sFdeHil
rrYGp4iPXxEnIM0+O+ZxhEEBUoEFd6djqtZ/WOheN2SaElBjbtfu+X1XmKDfipuT0mKoe2VklpYo
r5QBNfsy6GpSMm95EfJn1wq6Z8wqRW2kGDtqFVIl84DAn4Q7IAM4wECFCCyu6bizJIHf+cybB7Zu
3zOoyMb/sIN2RCBzymI0Kx49v8aUCFbiXizkt7siU56jqACztSnauTpvGY/F9zO5HcOrqgH0Gy2r
tQy4Pt8EHqaOUhW+rHRbD7lS83ItveFfhCk2vdp/4B06kB66P98nA+EW8/eBtOtXSexUENG2f2wK
UJJw+tfEcYW9zQifhiTqihYTalX4KR/Qyi28eBiPCMzULQflMdJNzBVX9uRJbXdIFsborqS1CO3G
VeCwBDuAbLjE7DpzzvwT5g3yVWs+4vN+aidd55OqnYTE7o41KBbWm1jkmc320J08godNuY4KerzC
phwIHKixNWi3+qafIvVeZ+/wLQNVWjcNhivF23RIftHx0Piz8CSwiefhrnRx8jjApBgGi13xrbkm
Qq7fseodNg1hq3ZmH6MgaMu7O6fWmWKmN3fTKnjWqhgOC3PSLDduDOqTiOgtcdJEnyRmz/pDg4bn
VOrkUDhHOATMb08B0ICHM12ALrNQ1NKF+9IzQW5bRF+mz0UapOeo1jcI1RXCl1mTVu+ytPLcp5ql
SsHXHKazfQQELTr9ee5Z/eiuNri3BCBoI7RAwtzqi+TTuAl4Xs2g0NLv/SMhEOBfZIgtWTPNuHib
cXAVTIXyADHP+ci1yB1UjGNKwg1/oZk80jyCYxDhE2tyrLHSRUBN+K3R0KbDDapmLbxygE5ZEA+v
ezSPJoAGrzAkjB57RbAH9969/cFymY01U39cMSHagKH6EWcxDjvnOFIdudDmw0uLgHSOawH4bMfv
AquzjCtZ4bv0o8mfd40GmIRbQyt5FRRCd56wbwvmfBHcyrNMMY9jOrz3jyYe9JLwk4Um7MjOl1d3
gtiWDcwEIXXL7SL4H+WTEE7mm3TbPYdtwdPzs7uGS8QCfnw3GhaedhkC9xHGoNb2Tl4vPf3HVTfV
n80D0O3LrsRNLTK//C9dHZKXuYTwEvf3kfqCJDT8UzJe1KtAeoHEkV1P5g/aA/f0B0LOsLMqhC49
58dbggFL8ljF4EttQg76qvWblPpfKH7rfXkEwVZuU9qN7z/PitlBGmBl/fO42CyL+bdhf87zm7jv
TUx36gdV1SVVIe6OQeQmPqau3O7m4aTXmrEDyH7zNTOVUvE1fCDqpqT+m9/aXpEVgTzxbsxk2dnr
cH490j5d7u7pDhLJePXXGZkWefQ7h3DN0D1dv07vBmFIM6zIrLzzUASxt4oVTgUEyr9P8L6HJuZh
uZiwTl2MJEr2BArmZ46lakR1tzFmWUWDRFYI77Ut1x5QpxyRBQZ6FGt0J1FC0NKTw7L/DnuVzu/2
bQOJAwx964Lx03Ve3/cm9VO1WDdta+n4aW+sgTbwmyD+XJrQwtBx4vqz3xfkNC1nDxEul6dLyG==