<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvSYUBVasa2vySZjbBqYCWx7y9bfzk4L8F9x5h9ZrlxY4T3tvX61RKsJWw+/UHj2iGV2Oro/
WJ94n0/1rYpX7z0U787kEseRPM2jcKNfj1SN2K3ou/igNTTsJwc8oy03Ru0zZBdTVrOsPEZeK5GL
XEjAwOWqwyp5Ymy8gbGV5xxyy/64qvvNfNM1Zv3vAizAe5jzn2IFcZiJvLgBBbaalWVvp3/uKoWK
ZUzrN46oYLAkxGkVrBSkMLgDIftVbWcpq3rQQQHmtXrmAIhk8KcRH1+1UAi1MYvhctXQXj8Hr1Kt
iV6kKyTO//EILXwkFtr7RNYo0jAQe/TrscO/iSopomeCW5n7ty3DCb0RzR3rAxlxZ/JNx1pgyZHe
ORyAZbTxWE9wZF21tXmW95V6PpZkGBc6HIjnquBT8flWkRM6NIwhnzUe2pqo5lPV19c2hksbXAAC
krn5kKqHspgKHUkJCfvhTb3Gbb67C4rF0FV/D1MET2c/WQ4KEiMM8KdIOHe71U0WeyNdlC9p0MB+
peULsKvKtnzf8LsPYCoyeogIjq9qgCAZgFBYhIGIQ9Gqgphhf40G/WK/qVWYiAU5L74joykLxi92
FO/ipvOzdLVsMcpxjNeIdACL+NbOiy/OjrsV7tXM48UUy6J/yS1UyG9LVVVxn5soNY+X1qzWt+09
itFnmylRJgbfOm+xHzES7z29jWimZ6EOq1ts7SGNF/0KzC1T5xrLCfsm4l4ZqcDuZ1TLaEToxh4H
YfyIgS347WwKcGpEXdFIp12s86C1h6+qf5veg0/KtvX8pH0e4Lt50BC5JAJqkqDanA+iuNcpXJuh
MdJPzQ/ZcTY/POPFHaFU992vSOirxbs3CtYU31FLMRgEhV5OWd6q5ccqTEBsNlpUhee5QKyXH7Ye
U0I/hTe8XdQ2qBBdOb0qLgtL6WU86kQVavu1oLwdr28uKeUt0WJFk57m85E2s5q927W8t54kZCNf
/asdZBfYBQ8SCwJSHgnr3pezMenY4HIsOfOzxu0ZkwtyebnSsqUMs56RqoGaYMlxGmBqiInYIsaA
AcksSNJH2q9MDbxJ5M5Qtvjn+WYqIdk3v+q8Wuqf/XnGZqXI6NP+t1JRp5eFcGyPJyf1DfKM8Zgx
JAHZLY00MlRwkee9ph2tHV5Gm5rANch96POCFpeUoECd6YgmI8Ex9C5vZzecn5K0KEqNO9XgilUD
cIzSPbAxFic1mCBYevGaHDVBuUpGotzsEKOlvewlPZNXl6wfK/ykzMFy06Z5FKFMnLhkF+lJCYn3
bnhiYCAj6wnrxedykdQp/U7QyHtlv6oc09XOR8UIs/S+ptCQlhKg4WTxsDdhzDYWkSPCEHBq5EqZ
N8fbEEoPa6sd+FnsnkMETH8gRIBJGxEEv3SNEH+lKfd1jJfU6zi26g2F4QNFvQ4Qb+U2ZAmJQtns
ujfnC3w/UAvl1RijBaBJa8sy4brZCLVeA418j3LDhy0eA/hfVvHx0cUVvJMC5zzPV2zEdEMJ89lD
hF+hBodYJsQ3qJh4E4ZvFmonNCfzsfYx8dFS89itZa+SpJtiGF7/4lPKCeMq0J5hOg2o1I6Bf9+s
t095sLpdFajiSI3hwfwb0H1n7hEPBe5Ujh9VHX3MH58utkYDS9fauheJLeWSLDBrVIM4IahzKCbk
88bumLxKwF1bx2ttl72IEFuvh+t8ILbcUc5+peYCtoaPanDm0gahmvXrfQgrOP/Yk2ucmryad+eW
8Wv6y9T48Pi8R0GETtl7ojxhuzI79e+3/rPBNwGLOM9eqgnrfqaTAYVg2kgbD3bHxn/0K6cHl4z/
kbg6Qe8zxE6f37aQpH8lK+NvSvSYiPZHdH2ZH9LFkbQ3Kph7IRVuPlY5BQTMZEAG575iI4u8DMwn
Y64eh6hg35CU3T55/U0EVJtjT/gcdQ/aI14IKSzqpz8vH4badXobe/+O4tTZCOhfpzOe6q4Bq/3k
IEVHSxHeqhXsiaXj8YoOHCYhyTB/q+HGKfoxWQnsW9CDP1D2Gr5LZ4oJAfGC37bUnrGnHY6uhBm2
rUs9eEIIzZgNqXpUpcX+GXE87pQiYcHBXvzTESoz4zWPP24hYNq123d68dy0NKfTqqcX/HkJQtru
OojQL8jYZJQnTI2+DNzVWBQaZZyLeU0FK5R544M+/DZa4TJ9NMBN5hgQxJZEcN4kr6Kmm6ChZBm/
XNqGdef2KkbFq3bkOkTuNAwXQ/xh81WuxLvFhaf9MI4A1BMTtHLnaQrczMEFiiNjaVIIyaYRTn+Q
y+5weqSOJzK1GSJZHDDW1POMFTdN1mOu/bbGK7aRvOk2l9QFjNUEY/u14McRpcak5vqf2Mo+1cDc
DzIiVPmgVVeCdz+weFos70A1n19+cxReE2PDOf9oG0Fhumm7xl1PyU3NUjyCIULRjz7WGK2jcHMW
JgcQbvOnnhqzw2kUqNB0BhlI/qNrAD1wsmlc5zX+I72RxLObrylWbmSg0hxQDLr1arkJf6Cla8iK
2QXGyk5SYEmwlfVm16ZwWOPEtjqkZkbtdR9fXtfNnJ6XC6tzgggrNR6yWIJ2zelh3ItR0yhETY+y
mwjMf1TadauJOoD1VNTCPfAbaNQeg92WvqS7nYzEYFUcN5gdP/54liauscuGy02j32Ju8j72vhDy
104leItc/EfxmcMelYGGV+jWQVuUp3REQ4OgoLDQw+pPP6iVleEiygwUKvxn6XfophDif2V/o4xz
AsrQeN0Z5Qk0pejMup42Y6rcYtwSARk5itzefeeqehKjdxmgdCahIYRPzeSPaG/eJKcTSVhr4t4n
JlgcZcSe9CVm/RvIFvf0uGM97J+7busY+/xp3G2afl14wBH/ooWVe+TG8KGL9/3TTpB43zuMIL6Q
R+W0NloWmbb40lkV8ualjiy5aDelobuV7AAJilHE4BJrmTDXshKFe4vC0zWSJMmiwSECu4wGYng5
C/CaCNGRvNBUx8CLi6tcetTGz1HN5tPEZTdOPV35UJ16HUBJMHnOzt33Dr+vXgYV6qOHlfspTv3D
sZ3ENecgrdW0RrmtoBRgBhPEEicI5/2vNAaUQKNnm5VCYVb9+wcHwkAiM5fQACmDHE5YIZFi78oO
cKcpFtuoAXJnr0ZqsC1/ltuJHttrLI7wCGXPn3llOIO/Xl66ef73kMXyGUA0GYFzdcbanVmO0LYx
h2t1CASQYDWdXbSnOJ0M64BG8hc9H4JJgUnBqIYXJQhw+pfJLlaEaZ0mkDPtAY1PbbxXDpS6Reab
hVGJk0mbtWlmhdmllYbGKUy83pkGTQgtdAf1LHbI/S14wIZkJirURXlYN+MXBG3aP0yr7YyJKMSb
nqok8a9w1prjVoUcAXIvq6hD1trgHaqqIqmEt+7Pq22Sy5D6OXBq/H8VTN/LCjc+1tEZzGR07Ja4
gbuRB4VgcKpial8wflBiLoGBliPAY+f8zq341qIywX0FRSONqIG6DH93AbShA2Svj3Og62OjtbdC
okWd6NvMBlsiLD0wsDve+1qz1kVuVLX23M1kOp3y4Jb9CkQlDcH9k+oeud9WtUYyYvCsd8QEaXiG
u2qm0veSYCcHWr/+24S5q2DL4m90JP+xwlEo3jJjQnpwYmxtWvrXJYH8BRCs5okzkO2UqoVvDcDd
X2iJ38EdJ/ZQ6XIa888Z79DlEmbo8w8dMiizCpARZJuzwYWfpU93OBtCUJsYUuszP5ikNjvWxwAg
4hZi1/PVXBcs7TarH4Yq+TJtjkFHZr0vBrBrK2P+8TuJCZfpVnXWZ2cWFpLe0y+bIv0Px7BBMemf
A0ySpungxZ7pUf78Zyq8sOC/3PZq60kwdOGssUadm10m17FeENlBqJyZbAwmHGaenxS6IdkMhSDW
sBrIwWlFOGtdYHFza7KUj64IE1TXc38x8kqjxu4d/+0leNX08KkZeYzkahKaVEZq2Sb0G1CqSDIl
zDgRZWLNk8TQ+3JI3VAS5EFv+o490U3fAyol6QgCKAUo8ooXk4lfKCTC53Iitz11jeVvu3Dh+kS0
rNi1fHglXnVln/JUfYi/QaO3/NYqIpLrUjShgUsWsI7yjfc1XOms8ts5pg08Ix4qqm5enNQs28Jd
EbM1qWPsNhvQpYx8nQsoVSDFEl+6bbOqw+iNn+14SUN4tLNkDCV8ps8JAKIJt5R8B1DniC9gM07O
ladxFHXCwGQEDEpF9QPxRX61UCLR5esFn6FX4QzGBMKoHCNhIV/vNsQOhkVcmPe3SutezRIEhEg1
qATnSTHpDcgOD2MA7flCsoAOF+EzNVpIi4FsIFJdBa+N+6JJ62GLeUjxOTjkEDUN1PnzbtwbLFcq
sTcfFSVVxLlU7gMZD58SJT6i6kWDCi2f1p37o/JK5HwcefhnYRREsm5EuniD6rpFLLQwQ5go6O97
RyO7+/yPGXGukLGhZl+uKbP/4Ow0qe4i7HfnXpRXHmBDKQ9wKGZHgP6w6t6VexbZ/wuYerqeT36p
AGeHBmPZDGQV+wAjMA0rVwlsB+UhUStYSoUU/KyhxGHVIAACSDEQ9J1N80/k95Q+Dgekm4fR4abS
0kcP4WJ0rvgtcunpcuv/hVPSInhwKQ1XlvNhgjTM27j3/HhLb+hLYwPTE+Y+2gKC9UfNj0lGp5Yx
57mK2Vas1AaTySkETEAN4hBUIHNRAjCjqj4DRgY6ROXCJqVwHsOeP+HtwpqZ4a5QAFqHkrToPUFL
ObWlrzKS2C25GvDzf15Y17tQFi4oorW1fvbRX/t6JxG3KjIL+NOaKdzh5oP7fARhpXFJPmKiE+yG
YMEHGosfpQjwCkAfNSW6eEUZM1PEEt8XpJZeNGxkak9BXDH6rUOSqWhMeQZ0CJ78FgcIfGv6qVFO
vVn7C5JcWMiX21WrTyn4QNKkQwra0m1eqsRi+toA6X4LjCbBP995FuiBba1Vi5Hcy+RqBISh8he4
kr955i7LKB6V8YQP+Uy7R28LtFC1s07S3T0rzo9GOp0Hx7zvYtYYWaV+z1Z4x2xd9nc0Qtk/6jDb
OIALnreOU3Q6Q5vJOxJ82oOqd1YLR5abaGGcj2hTKh3R9R2FOzu8mC6mmjEqpQgHkjsWCeLMdd/o
s63Tw8TstqRc946/NPrgAUwUX/MGxTl1rHuI7pYDaFQCCDRht47/u6usYR7fP1Cl4WWa9V//zOvf
UJtd5vPHp1VtFXrDI5c9NXWgoyGaYP5SM+4ic019NwP5zkxccLCrWYV8UA7ATg9vH23ghPLiK3Df
VMe6Fce60u2cTbxC4K8kEl5XwapKTukRtrdv71vbnwKvY72xyW+6En6wZnLmaYLENGaNVns/kmCW
v2tWfWmIE4gY3Qu+SHW8jZUVez5c6j+kNVoMfXEE9SahfK9UEMCeq4F1yIkghrAindFy4Fh+UpF/
A1L9ZpxFfhL7x414qks8kD+0z9rBeDwpIl9uHEwy2YGm7DGKRlS6W4eDxR6mYZVCz2yn3LwhwT9J
tOwmSvLl1HXULBb7CsV4Mr19WMyxX6vOHMFmpipXiJDO1MrGcmqJpTyT9dmM7B3viJ9TyqIv1Ho+
95kVXBkjTqYudWQRKRM0/qfnEyX1e0qgNrqKuc+v2391/U2Nv9XJGxasg2onxWafDA+NnGihwuQj
n64/qARgu7lFJvkdYtbCH3PnVfHSQsctvbJvvnQrelN9eXy2b0e1DUWSVFZW+0rDhAx67qy5mTJ5
5nrzlt0G3zfCM39aFndcpfUyDanqJc3oczdoOl5ieb5p/dTcENmXGjhFBuYEWHOulkcjpDI+SAaM
5qMUaQpvR/CwU6Iti7j+6wyKKgn56p17Jd6BZoudML3UOY/5iqanwOMMZV/S4EHHdkA+ppFx7nGg
eA80MkBfSx5oG6ETseWFuPy74qevJFZM2ak2KC7Vkm3+gx2DQSALlg69b0vc30/9FcbWO4fWvMop
ruRi2P414x4pogYcQaALdhGgdsFD4DxFkHzJsvwIHteqwLf7NptgTffEWqzj9kGI3e4VzovLOsom
SeoxqpMC3Mi8jR0qXYc3cBI7Reglf2PWo7TTaCwy99yPJ7Bl+4eZi+bS7LtS14lOiERCGuZMtHXE
JesdMmP3009uIw7NJFXnJLXvy1BaUiCfaniTeEvkolOENvsJYN1bDUnYxlX94qJdjCNrBpK0q/lG
cF39MFVJFigfOb8eUtFhSvocjQ9BekwXNjstTA+GDb+Rr9mRHFy5MwmApB+LCEeOgyicnI3C6Gd3
0o9rCOe2lYkL10i8jWzDfbvhPeK9CcRhJypbA92SdzxhDWZ/kRKxqxhiFrtyypLR9/I6vC0TjCW4
H4qYfgJhfkE9lNuoiro3ANCioJaPH7GFs2acuPoyYRiYg1B/pSNEddFS8bFsIv7HB327KV5QbMJZ
id1dGlj9rdiuxTD/xA1yBaaMBuxaYHjcOvWv6h1kd5vX70nT2LStV2RxfdWcx8RyYOf58gLmpzKd
zXjkgv+qY3UsG9S3B+e+crhHZBDcJ3M5Dcgyw1N0lKSEzuZJiLFM3GdHd/Iu6Amdb4drGc1Tt9kU
sjSJJ1EaU90B/p5EU0aMjgTfh6W4sN3R9NQw4W7nqp5o9S+dz2QaCmRmSaYKPhyJLhZdFev/NaJM
eM7mf38OjaiSs8GqsHQwfh80q6R4+xZr40MezZtKpuwpSAXEyKgg5AHiyh/PL9W9AU2UDmlR+Vln
UEYfo3hu3DcDiBFdEcUEp+OAZjmzg8iBwldDoU0xIEeUDEmR5OeR42ypNeiBHD+uWXxTnnc7JRMu
aD5iE0uAxe2dLMjrUWKqixZm2BdJ3+3s7Ehm+fIMmDqDsHyIMhNTqwv/ufx9cVVnb9nX/oscf7Mp
nONL+Ou50Qz+V4bnY6GppY70q0Q1DiMt0emrgV57cfHya+A8q6GIHJW0LIo5zfR086UL4uovbaNv
XFjex1Tc1up76gHR98QNkeMY3zQxnF1PHwqrPerSJ67UmJs02s5nMKAM+aRzC9iCxrWVzDxEmtfc
2YuhydY55EoTCRq5eOebAofzaqVZ+eKZ0uEju1o/MKsIoq8NTlrJE30Gyk9YqLrZjqvioPE9jaTg
TrwSJkzQEivUzJz+SSs1KNUcTlFhZ/sCkPrvhCyj8+u3btFW/J7wU5HWAg1wr10JYH7tICOeeF2B
FULNe51nCWxnuJzB4EwYjIhppw7eG3N1K9o2fzt04x2b5zizx5wfTyj1EgDgKXnv46j1HA3jThKP
ZcXI3/WXNLJlmAz43PIqLycZW27Qy1UzI15Www96UgflTaClA68l5mCjjWBxXGggctJr90Gohcoo
/8ocOIuaycOkP5f4vJvMkINjerMGk5ezz6+4GF7Dlz2AzBVsux0nK/3xNb0IJ0/gjiX60BSADJUY
2fed0dpzHtg2owK7rEIIvqbA9WlBtNFsQLx1RmBePJjEWM4fLmj71hUoQRoLju1hZRXWLR15eIvd
0qIHqzceWAtWcVwaC1e/ul0/M2jwDK5yroRiyORMtElcR68s0aUaeKKL5Nll0mmN618KBZJCO63J
2YAOmrRUG38I3Zb2aXECHrrWkTQSP/Q0K1GK4CcaO2CHOFXlL1ajqncKsHS02bmB/yjKz3fCGAjg
o6rJ/+h5qp8FWUONIKJjUQDJW7CjwjxADrxbkhOmj/ZekE+3yhJWvP8w7JCYeXLGhDip2c+bk+C9
nQekBkEV450/bO8/yQ8WZsRRVxkFjbumOczG+LcAcE6d7GK8g/b0RY/nRv1shcLy8d7gBjHK2yOZ
XSc8iXooMlI8hsH0V4QdNwrHRxsBAzKeHMixUedltcLNFT+If31Yh+8Tydeso3xglP5q9KqzYcXD
pA1ZHGdBPq7fylX1WRQPcv4HT9uHUUaCm6e25p1icXVKDcGN+pkxpR9jisTzhmpDtdQ3VoiIK202
qKtP/KEf6kaWUitj9VBsU2R1CmG7RiHKmjPY+eGEFVSRNIaiskn8GFzd0hYk/uPRDPtbiRIn47si
dihFr9Iws1Hgf4sYL+cJHKHeh5jF7HyweAPoqMjHbc+9jxPWVBB1u3+WGTIQb/n9UbKBYlRNUNfM
L7/AkVLx50dyX9Shv2LT2yLC+0oN3j+IIglC1A/+/8L480R6VMVtHALXwksT9PfdCnrMjktz/y7z
00yQcS+bZZRD7CUV8VnTg6zdTTRg5W6UGDvf2xKLE7G/a+CVdQ2ObfSNVaIoTWSLS+wEpnQJ56VU
Zb5fH6vjBCfwSDzEHyzzVxdoOWEMdPp/b8cODgGM1RckPYGDZEKZPkGw8JHGYphNVk8xVKYpci3A
f2ywWHPv+yXHzOqUGZgIhSeOuNIsvxz+5UV+06TyESreaaYq+MUlsqbNzqQh3uRKOVf7TXVrpOLI
U16XixIGiHtB+KEThpgsu2rLvuMTN6Xoy9SsthAStAMWl1xodmaGeUqxHC+gH4LH/jKtLr9aWaAQ
3gBcYiNwcNfJO6wSxS1K54jp6GgaiFIyYTpRxibsS3MhBOV2LDG5VHy4vv4PxdbDiktH78ZVgXRQ
h+itoRa1ZnWlVdKNTOLrUigrHYL32eW/rcuhLJbX0zNWxgb7Z5BaeeBXNZtXeEjDOjGEP3RdL3Up
xY2uDkJnRhF4iFkFVUzoevwVxFSdzIgun08n/nS1gBeY/m7Z4hp29i9DUztSfrKkeeYkhaITwURU
9EzCLds8833bQMh234zt4gVPXeGj8A9fjsmWT60I9VMq/Vi4O1NmGSsA/XxW4/5Q4cWYuV6CW1vc
0Rrku3izNzvoFgtFhtNUpzV9CMQwF+4XFOQfWEEGHj3blNifX0yxSNjouODKpucyu0+JzKIZjva2
FK4XAdz7/621v46elAeaVEVWnVHQdTk9Z+dyZ/lwD/4fKLjgGrqsPN+ZcZ9dHlDjt8RnxliPMUSY
+m8V4yEdQHBx8YgHS9x9KROeRs3CwRfTllm5sIEYUp2qosSwY/hoFPDmhGKCPJ2h8tyscyYzfo2n
RCbZL3abKYj7PSH1rEhuIGtWAhEW2p/f41tRK4sECwc6n5yKpARoll09TJFa5Qxfanmau+UVBpZM
zt6joag13IJ4Rr5yFc1oh+cJ0TEqmZ+TkSXzjCBB40wiylQ5wjZB/tI0lz4HHTxRAKqP9P8FXSQX
4VySoQsbNAhC4UqPitsn9MWWhVEDp7Gw2wx9Bt2rCRFpKGTy1BnIq7+IxEHuZjf2fVPu1aCj2ogR
BXJJsNClW4LRJRjTbJgJr7g2urGlz9HfJqMQ6ncWhk5PZc/ilzYE8i7dKPogC/hmKBqwePFoZN7m
cCdQ6hgXXsEHabes4ZxuVKQD+rYVdp/deMdifvL/SF+DquSdbesj0iDMznDCpdg7ZPnG9VoWTg4M
7Qusk+NckshkAPH5BYj6IpC63U1dT0NEWCLmTraZtUndrxcdbdosqYQm/Ualz1d35AYsEchqGHxh
02YGCd1PA0dZAlE12ybBftlxyEXpnJcCM9PWS0cFhcTBKtmRkmXzS2CAojdfHqomCG8xp4sM7KQf
56RSm4R0rBJgNDlIQ1kAThxx2MgzPDZ9kNoVC9nifnyAnNJXWIUc2ksbg4W1XlD+oyNd3/jBQ9Me
qUWrDkGrxZQpP9ZkszVxMZy6mxS8I0kzb6g/RQ0UayBq5QhTBkkLGJE8TbddalEjGjVDOMTF9oZx
sjyAsABKx+2OnIpmlYCjtAbhVrjYcPrDhHSq9N7MvVseUJT4ADC0btz5b1chs+1KqK+qWnoaKY6V
Rlv51oEAJjNedC4gK00mpI0ctl7cwtYP+BVn5AsWYqd817TO9ab6LM1EQPk7ejEph81gQeCYaiEv
4oNiUImYQZN5uEGSXk+RqgCTKM2rdmcE5mBt2lBPAaHCQcdNCXDCgC9oFmU+saEVIxcQN9iENdZ6
fQGLgheRrZ1DDT7mUxWcuvkRAaR2GJ2cGfd9IcINID7eI9vjlJ3lHNq63M4jtp5VBAAv/Q4z