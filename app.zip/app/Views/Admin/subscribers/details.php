<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqrLxSdcrDNk/tMwUEgmWvzWAVuzL/KXAi8CEY9ASlO4dW905CZAawlkDz93L7dytY5DjN3w
gycDSvs+6FKiKqtI8F8ow/2vzy2BJ0lqu1tI/TJOxlOsE8XQeEvaAicf0QfwEjBf0MPVeXPusV5k
fc0n1gkaNk/lbajBXa2TLTsTZEQRAixuh8ROaGRjf7ShN/s7rZ32LB8V62BoIFEnEVnSngXyzeF7
+DPGn+yB0Oo0BwNzCIK1GrWtfYFHIFzZ7umZcNBhZmjDvg/bOO6oox0E1swHSNioqxyOSos0Koxq
drcE4V+fhm619n2VnAU1vIVDSEuVM9BHDF//WezuG2vx9AsVRWj6/puaQu52UexGG6ORfuQ9UTeG
ydLy4B652SHV31HmXIGFtfKCf1PxIed41CfN5TnDxnEMPTJByaRPTZOK8MNnJhocfuCYWWdbqRy2
w7KdL38B9Zzb5dbq8fWUnWMns+/1zlnlAI7/4czLyJTJw75Jt6scRfIOLKpNeOKL+slxCZMw0RWo
/9u8Ovw6enctRavG5ccuMNpvmkrhpI6UAW99Kkqcj4OGwi6wltcXl2Ewd0FVkL/uzIamv19bSPjg
WIZhKPl+WYBhJYJ1t73Y+a4UuG2u4SYd8rxzMYBRCFiv/w3sSqwZ8zfj2vmPgjB0SbKPb01UQBRs
9ZSRQvJz/kCJvdkGBYkHtgrgOMMCPN1vNMqbAlwFY2YTn22pUex40fR5msiOu5AU9cM0szvMY9U7
PB+qcGhR20UJR37BNS4DsNE8hEjPz/OtjiT4SLvVJjSiSyfr0vJq3G1vnDcVDgmPLuGVIi5EZ+Sk
EXRaBtDsszRB6SiGFOcKfy+IOnW+6qmeY+EQgCf+z1+KlFHXlaJ/o5wZIehHt5yJgUbU04H5mav4
CMtmr+ojuY3BASGnUeqJGOrG2GfA33qzOhLkfX9wZm8DRLQXNsHJ5X4db/PTTyo5uKB7HUNl3IoT
2/kJCNyc5vFwliMvlEZSI/xV8ijrVfkKukyUUwG3qRy79ZMsegKEAhxxVYUVl3i4Y7iutPkZ3NTj
7PgC3izNQ5ThVe52bJXyT3MlKLMLQqDh3ihhDwCqn+H9PLS2pAMDGuUOQLt/kqCgVhQJjRP1N7cZ
OBCfBcMr7zG/CziGkfpYRqIkEu1fnnNCD2xOGHpOWIf/TOsHW3YClawH7dez8OiJLq8b/phIQ+yC
jYDkLur0H5j5UNOEBqaGNIskleyMsDrZbBMO/ruDSu+BVjJwwRvRyYH35efDtoAvtVL66WnxptGY
xxdJaCueckGa8560RsE7OFexyK+A493/GIHoMtwOll/kmC/BVJQvG474I//fnO7AYkMxQOkGtv4m
im3yMKBuriANQxM8pW9HAyOdV9vmUlntBKGTkzsqz+Cq75zvj/9qEd2b/jh+knSQwEyBUzRte0BC
2V2ByUrVCpRQQUTWhLUY3CUUfgC6lF6S1iRrNuqYufBAln06feaFZETqTMXZZwedeIcRmCPzmuKw
SykvvbRpyqoEygAWE00OxVEkjd7KLgt5SPor9He4/nNjxBfdJIRwbF3+i08tPNxY5GFVy2HWUjr7
wqTqNAvPEzYggp48ILRi/tbnQwkQf5l3zlVYbplGCwlnpAmmWWDUsXknEyWYk+vV9dxJFN6Q0pgk
cXq9WAF3KHx4bGk1B58T/zDZW9IGI3q/awKdBRE2K1vDsnJqbIWrtjHntE0AHGAfE07i5xNzSMsC
7JJzQIdDj+SpRzCn/RN+0XXzpDyQJLsAbp7P8hXxKVAoRvkdwRuDtOKG4TDM1Cfi4bCB2DhbGOrr
p8tT++TcPPObZyfEu1utF+5NlVvbvN8J6LeEyxrzoBL4dHhWsJ40xXVRP9X/KSH9hAEhGp/iRhe1
DV0JKlmhtavlvu9gf3QoQ1zkg9Kuu8HYIGvHtX8H90frt3kjvpe42nbK8+1fEPG3jfuBv9/jq1am
Ie/slRXBypFhlfVkBTm+OlfsoWFr3duN9UJcKsfz7FsyOZOnPnbZEriovNiRrsltfaa4llKfJqaA
uDjglPHrZE/zb7DCTJU2c/vKMDHjyiGP0MplKQajrqQxdAxR8TB+nujL9Xf77l1Rhr/3n4lUqXQf
dg2KC5IjExOJgxAJMGobZoaFkzSl+IPlqoOx9DxKeK4YAp00OOCFx309+2P2hW01fFgK2Y59phfU
HcH3gSFuoVbo4OZYIA9uWOcTM0VOHWr/AVBLLqUZzjX+dSy8s34ND+sN3f+b1r1/7vKMW3XC4Gow
C2M5IMvP3A/p8X8GL84OI42FNyQl8VkQybGlcUTKC6wMRYgZEvF7Hud4NvOjlJgiqcgJFd1GQoZ7
bUJGIrvR8zzgx+YmW1puaNFmDneKk5vECr5qhprigqHDY3rOnOJNkyAaH+SC/sp+InYBxHD0lH/4
QAmGoZNkJgIr2gX1lnmjYVg7vnNLNVDW/mVfl+tgD/urQ4ECMMgtEm4hcYaiS2GbW4gJlKjW8QoO
Z6jYg45DOUZUWUacuBU6+f8qdQhK/spD343oE4PQuIsh4AdCVi8rjSkJ8Xl+TPs5GZ91UkVWz2ki
rJHPiVX3gaJDhtHcjr2Bntu11pd5qaqjp9asQykoBtyBdrM9Yxz6J1BiofiBbUPpahvfYMuSBMjK
1E8hRkRz2BrMYtx+/bydyz4YA15c7Pbac/ftwJZQdb1tHUgPuFDQSNfR/CDWEK1zM0lkXdJAdPBI
yV81CnVPv1g9RNrzvt6P+q9Cx/kkGB5zr1D9Zjwi6kpvcoqYUIidt3dPRTZESOwUeT1b/CL83869
QYqjVJcP1KLysP5oQTA+E2/amBm2JDKeubJvBg9Xp+fGOWx3NhFqFlhY9sIy66wAhnMTXwduxQ3e
O5iahVq3ciCK6snL3cAb1G5W5DV0pCsS6XuzWxvdzP5e1HXXpPhO1kJPWDwFGLmODlK8csI9KZU+
sxS9jYaX8D61u1MvUN75wWKiZ0uleKsoBDJfO8NRGWenaI+IouKEjiDdTM+VLPYEmATG15X/jz0p
NnubnfK5Rt16W2piJlVj/JvHstpVcpHTc5X7cPZwYeGLxESsvcNzfAQSRX5VplvIhsC0tdkESZ/w
/THGQLZbXzK/La/UN9tNSdix8uOCs8/SWwlPdTwHppNH6ZqpmrREJUIbguwBm3a83ThE+r5NgzYi
gTmoZbu3yIIMAZ4PODe0YWMAqIOaxPHg2yRNThwZgXu8aaXqS8qAbm2R25/aboWHoKm+Zqyhu7Ep
T7VnrCOaT8B+iuOExt17c4VnUDjrYkzJovWcVGFJ5221Ahtwq7ek3VpGiwBi21FGGuzSAnqdH8Xv
NAYRpdixqVHCc9OQiKivAqMW5TNwuULyRYtIGgvaDflDwqd1RkAMN6cbE1hQhtyb9GoP6e0MTRDz
9ONaZ0N17ON07W5wVoEqHFKJqFeCaHspk5sAmRTA+l1OUZ41J1O/t4mlHnx5Qbz7pvzRQs1LiYTP
EDsbiP6EqAwljNBTk+9o7JEDNwBQIrwmfVXHv0k6jDq0q3T3+R+8sXlpAF+BHMPFfFIC4Fql2ruu
G0pexuBzDbNi6/8MZvSJ5v7chXI4SQ/LTp95mNrtgac+kFsBYb4Q8NuU25BmEAofnb+THN0mrah7
8YV8vIynfNwHlKC42shg58FjNLYWxkCNOVLUi/0gQjyrNDcYdirkNoBw2bq3uB53KPlTb8zY9abZ
N3c82Y4+VOj4xlS0PRabq8IkPidEXrYpc71jsjA7cq/PZcQfsyYEJ2w6rt9wY/JV1ffTdKW+0I0d
p+gA5DEqen4fa5RN2VZfm3sGZ/axTnxgSHfjJE1I+5TR0chI0iaFjYuoaakIdXrum4437W9lTuHi
xkqeGE9hkDg9eXl9TDP+eC3yNXgawQOXqqjdojyg4j65UAjSbAwwXm4qqGdnnmiv4jvkr9jzwhfo
CuOOfop9tNKkZzTbsLrDFXaNgBqHac/Mzt8Q8GeSyKChMXJX9Bj1VG4GeHREm68WhDicFXGMYVv7
tiR7hc0TROlErxjzn3OdVEWtD1zmvu2nuNYNUeYiahvvL+jxEuTWGo/w9x1J1qf2LODM6kbVOBzU
adapDUikhOBxFiPljTmbTUWR9Swpa5yLVpd3TiyWkbEFGaquhCwrS9PamSrwUFqT/QltRW9wxPBW
4EeMFhEATw0gZqmsQKQK/mr/wxlUmEi1c8qXcUev5v2iOugGqtEoiTPNu4qN+K2xTFDXv89OoZv7
/2F26Hft2Z7Xs5qjUgTCZ3Ouvhd0VihUhrxVAba3UWBvvUpnSU7PYQgQaWg6y8MCif+5Hx6lnaXG
aexmPUgJYdLlI67pbsmmSbFJoEZGJWeAXDBzE+cRBd+O0n+t0QP+JyucoKMMeW2qeM/hPwh4GN5J
xXv5v58IMP0W4Y/Ukec/IID4R8qqy18wm1XwUON6Ns/8WszBmr96i8YDL45PRLHIry/OusbdRcBg
OQ5J0TICMkaYg9OVIqWGU1n7E8SfXNiqtOvMkGZfBzKDsJ3ntfb+yegpyhRSgvK2uQIFIqZ0M3PC
+5KHbeKnV/9Xf/cXYYNqg1h6tCPafZkh8lAJTYbWasmlpTPOi48CDrw/ODQpcAMtDrgvdE2aj63a
4WvFhDWvrDB7EazeecYgJAStts7rIJrBmsNa46v3LRoD9kRSclN4qjYcwNRuFSPvdrncPdMFApxg
1Z9QzsRGWh07tG/wYElYjXXohRYBZkb/Ycl22ERxhAdc+4+bssFXdUxV8cS0LheHpNZ03dLfHKwq
MAHLS8tlpRhBy/yJfPgo5HNu7TL4w4vDBTfrexMVreEX9CEneGe4/vctyxh0ss2PcnARN1YKg+9E
oDRqJioC6kA/Z5IMPYhLNxHfynYUDnT/2o1fZ8X77J+GKt7KGwBN/cRKR5l/tFXK08+XyXMP2COx
YJ3cQ3+G7dMSw8C1XlJ20HjAiTYQNg5NShbW9Fas7zbOWXZIYPbiBmYLpyERwYQEccjUxnEyHQE4
ygEb+FHzywfg6XVvwC+uLtsn7eEgnw7c/zUz7zRPnKsS/iMGk1dWKNwGsSZ1HFeiGs/SWCXAAnDj
ILg6L3NCNVAnZjUeeQzu0Cl8YS0Sf55aB3sAAOZ+2j13+w0JvvVxHe7ssVQwxadlOtTctSFjEBxi
bAHTMoAk0bpzS1Hv0ANwu7NSic6Cb49JpCBDCZt0IODYhabenQGkpnyRxQp+ypKD5HBeEXZ9TZee
/kEnOY9MI+Wc2HMSIKaBj4gWeqrlEdHNsa3ZBfBb8FU69z0+Gj2O05OETx/o8CFFG28I/rtc0n/d
poxuMKTKXb5upkI3iQ2qW95L+fJcKbva/szFqp/uh3yftsN2VB3Ead+CaP/RUGnP7qUefHM13CxT
KFIzlBFUJ0pLe5Tr0hSuzvqoszf5teOZziTT+RDNvuhQP9xEjJVn3s2lTxqb/FHH9sV+ghhsKguR
mFl8aXLL9Z7y2vvsytcnFrcqGicMBuvyHv76TdHjGiiZXsiNlSXkCrY4LYR7U/+o7QaYbxbl4TtO
dP7gkxSNZMy848zDqYJ1JHElz7S/kzorT2ldEJOCyxQC6EV8kty1kmZoInPggO7FVPgqqb4F+hX+
klRjkq2DSHDQGwturQld04jC0hYR0chQqF/venG95EjLT2Xqu65vlmr/Ol7lcEoh1bP1OwHWsnu0
VG5imcedvBNr7US5Fgv87ypnMDLb5XGZJDqAgNAvywMsL05vfjWBRf9KXN9O5G51SK7N6l5O1Ru5
vmp9U3DiSY08uJTvQZHelcRhdvXvnbo70qKnWQTjESeJZNCofTKfGWcgAUu1HThUwwiB6/vsOP5e
c9nKP2twdl2j3qnqfrRCu/ut2Xr3t5ZaeHtL/BgNK7jvQW13hZiXSg/r5xCx5896oQpqh7mANkNz
nhZB1otaQgFKQE1A5FFkehOL7ekkAogD31YjFeM8lSs8mKVHGj/GlqkrWampuyR9lTBFYV6jzjDU
wZ4QCjvsg+MD740JXdi5OE9vWMDrm1PqtsfOJFMel1y/ydkNTUBdjflCGdehqyZJCoCgkl1Kk5+F
SJSgz6FpVYMvQ0EDm9AQYnOwwUDZaZaNqRd02P4pTU82o0lF4zQzru/yJg4a1qDhLi89CSa/Dvru
6bybCZhzHY+Zmv8YMDEEICix+MBYWtBuSiLz2GfX8VrZwVB6fvQXRLm/QlW22nQy+PaI5rjEQHse
dzFES0HD5EEct7HH26zpet5V2mXJU4ZHFryc01go4utYgtYbcBIcQdwLzXcKyVnpMBp+Fgw3TCKm
R8qHcXz7sXzk3ImxVY1ba0ePcvCBYcj628pTzbZ5EClzhmQrhqkYPEwgE1vGhigCOAoN7dfykBmM
PS2BI2z2Qz98ODooXnR3X2D7Gqy9eZzisgL/Nn032lmbW01T1T4T5T3Qc9i3kY4Issqwhh3tYK9S
UlxokIWGn34J7cOPaEqCCuz5vhlK4qOIEoVpRRZifveQgfRJN8g9oO5HeKI14ulbGILg3DkRPvMr
/RxHFdNs/Ss2Mzw+c/7RMdOBle+nXLar8fDm4GH3GFzHN75QY/VuN/MEHkZtdIxWy2Z48hEu6Sbs
23D4rHtG6xGeQMd0KkCOSdwRhZShethHnfMuApRGMo6drWe7PAqRTxpPf22XRqMTX7RC12+uJE1G
FkHqXD5YlKlR0dKt/+xlnwcSnXJZRtDRmfAAGyYLrnawJwnIwy32MXaTKULT/Xv0gjoA4RPgpMoo
er20HYf/EtcnuE5rnWpBIYZqqPe3VbMGgURSyz5GVGtCevO6FHopD0gwf5aw3rwGL8xSartvXUUf
Y+FbW+knNIxJEKkGQBJj/T0dWmpvoSWRPvle8bmcI+L13M5ZE3a+vOdTWXkShBEoyKoUjw8ZTNqO
mEmH3YHJORTSthG9amgk/az1aSP9WfsMaj+DIn/sALyPcbLCPVumqowUAgVs9vEIZJuFMEx1k9/u
rcfGGUQ7Xh9Dd6gMtaKeNiVKkkgLkprqKOuDzH+ClxhNKEY/O8AlgD5ng/kkLXc+zdyGendHrVv2
LUnmLcRT0K2+klQphnPcYle9lyDE3KU2R6qZWWVGGK9BJTgwXtc9JH5j8ksLFH5ScVXhTvrumFmJ
LiUcae7uD1U9WoRJWk0F93EZtEh9yhjOXeFNreIZ3MSHbikhos1RZKa8g8rM99fznJ3ihveZvvVH
Zk3TWd8A9Z5+L1MUPQhOsf1Ussq8KSx3rAJwKIj3oDKh9piVIr3Y0MiA35ckGGgRs203Xtu21uG+
aOGnWhpllRQDnh9U4BhGdE15ureWH2PTID2MCBsLfj1g3VHj429xE4bDN+V57etlZlWzr1d4XkQ9
EykmQhf1gNlKqNYU/p4hs3dal8YviCNYHoYPcunISOgm8ymOuBoE3S5j1aNvRmi1o3OGopOMNOPS
spOA+1Tu/BKtRk5eYwjJeqa+q6nLuFPO2+FDwjKb2AyYMJ/OA4Kbo9U0yvl8kPQlujtdgQQE4FlU
LXy1gSLJdkDnwlAznjHtUYCTU93gnV0hjWk9DVAwvqxVKLtZ2f2UBXmEKztmeYPqhusFL8A2XT2X
zEfgzdo9t9p/q7LoL7VLwZ/gnjoxM50uOC6tqmvzp4+vxr9ieNGwaRna1hbAU/jRogp9Ji6WHrIu
TmsR+iNsRStfDmiDuM1OZ12kFPw8rYT1OOkobOM2A887vTLZzGtKkQq4TXgeN20CCJF+/6M54WhK
QLKhl/FqZ1+8bF2ewKiJdrij8PJJ8It0PQkmOJ/19wbAzXk55nhtHcauNIgGOikWbWo1dRfLR8db
qwMvzZvfggI/bM+1AMrPAJz7UETvSld8UaU09AtcvQzjXAjnJDj68fEYI9cLgIWWLcICm170tgza
9iOvcMUpxZyqw8OP50pDtatRWDYNIPO/nzILIS6TFfodeHe7M9f1fIHi5i0BTsKokOKnGejRqgRb
coQ5Ts1Pn3V0wtVOk6+VhEwWHI68/2jVfqpsOzIDyq/CjCjW6LE3PfQC8R9qPsTdRW6YMJbMqsOz
vHjOLlZeJtv5EQHGaJUd7DSq997nfsq0QjjZGgjJ4wHY9/PqxI5y2f+x+B2+ynz16p/NOmklVMsi
FRKY3/lSPCxhjDh/ZSFB1ATsC5DTayWGb3u/fzwKOlgQYy/eq4hiWO0r2XFy1j8baW5TPVez27FX
vlp9LNCxakXEHK11sVmJH4nBtcZSjE8cHOLZj+be3WabDUb1WE+mSgFB117/S+KJaDslbs7gzZNq
LUWgYBPGjv49MS6+b5fQNIUlvjC7hKSpNd7yRwMx3cq2WnJmMuM6udchFfskiWRE2/B2raBh0OE0
nf1FFNpPLynzHAzzeIKPKi/UXzaMlXlwp7GlyTbYiIV5TWfZ2smVW4qTO+ylQQXg7j/eMYR0j1IK
AZkD8qkK/2R/XIhpKRP92h+rMD2ey3QKAwxUvTMl9psENl9fqXuIv/A3Cw5EZatyIUN90e6utKGB
XlWpF/Pob4YAEttz7E/lJ8g3NOE/KaB0oEM6uRRD3EoLAtO2PNfHgtLT5h3wdwSeqWDqdVnuWJ4e
k4dT4zSixM51fdeHtUpbCpb2EtrAXPbPtNAy1U6pPDx73f+A9+unWdMMiLaCQrgAJ8pN+oS8g8OL
0dFTP89PxOh/l6etuuLaIyFShXNmrBbb8xCVwjoODnFW85a8BoP3s/kVgvh9O2TdrjVw5r4CG9kh
9ypDPCwpAXQKNSiP0RbhtAi2ndLspjunwWm1n6ei04FcXa3EsFHeqK4LdIjMjc4Ir7ZCgUpG3GJu
a9ETe6k2gvy=