<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvAeTjPuMqiQ1KVZzPe4i0daQHJbRg10EPIunG0O9vUD2xxlEAYBYET5ZKeibhdo0ayWyj3T
/ced99mANTZHyEqsfGY1nsyz+KmIrdpUbgE7CDxAFssEgzHMyYDyuYMK8AiRcs5bqqHg7TJrbrIA
6CA7CRGrHaJa0aOwfNHHfzY251FfV4TwUEnvTPcCOecYkpFp+mKEpSQReyGDkMT1cOy6AQ6JRwRX
ETbsgrjiT8Ub6yk2s7Mv5zEGTBpTeZ+S3rk4B25t6JBBuRV5iQSE4ED60xDdNj3zgr+0uRh0Igvf
3Zr+/yWq8mno0uL+qP1PwZB+os7Z14qdTUvJp8BojqAa12DZFtA005wpMOOAbX4NEOmkh6QuW+a6
FNW72RLotsbwwyG4EPb4AbGFza48qkiQYEiANCwWemRZDRQldCmv1eXz7BT+YFZbM1RPDXMHAE6k
8X/yfDv39x1Q23g0eiobuG2r38GDKOmHnuISgTTX815ejzXC9GBK/3LoCkj3kzN2b4ra3+PJrQG/
ir/b1UvgBy/GmH9ZroNr8T2dB3SezklC+s0l3gpgoILbzklMM3vS6OSCOAg1trR16K90MQD+rOWu
aNu22e7TkM3vTDklmHNucaOr2Cp1UeXvqoH/dr7Jy4KkzU1wnqNTeKcAYmv2YZskwrxXJQ0UUo6Y
dm53axH+ZjK3prdNb2TiHe0awGvN3eKsB8ORvyMWySMOACTli8q24kHIOkKxe4fMAtVXLtkxCKZr
Rp5JucggOxe2reUBnUCWldr3wa1vgZ1Mq9NOuLxc6mpgI7SgfbExb+SxsxOGFR1EONFIAJMA1GpG
DfC0UngTE3TmoPNz20pJqbjrEkqFJQ5zHu29f20WYCTAO+1PhCJ5cy+3qQlHZeop54dWuObnXzX/
dUjPJ3HdbP9ofZtsotrsjhh4o8g4ylFm1dBMjPoYcKKUD1SNIJXz+k+IlaYJHaP1TWGF8/E407Dw
gqa9vGwKy92q6pZlVPwopfqc2G2Rx1StX7XeOe83onpxGxtiWZQ4EDtEIdr+eOnzZdzUqJYLa1UG
0nBNfQTYkv0JX9lm6iQFTnySClV4m9VRWWdlvSE2r3aZiMcNYp0cT7aXoJPb2I8eirIv7ghDUijq
AcjvcDI4lBlofXvYhjQEdHZRjtLCOOR13TC/JWWJJIxvqo3PbPQIu4xYPISoMdIqIbe2qvsmZ6YE
Lsej3084YD2u4ksv85tOKkRuT/YEuS5FcYiEAX/iezjvNT/Xth1YLQ+p/2+heIpz+AHq0+7MV0f5
IVaShsqu85uK6glAypNa/l5PXDw3wOBMzUwXAlmO+6KgkuJkG6INidPJoNuLTk7E5vTgQjthGYSs
gGoI8qX54dRW7vSd1r3Gth/nJ3SQ0/kTOJWQV3/5I+oqESX+x639WVqSdP90Z8Aql5F7PSdeGRGr
+AbccS/tK9r41eJjBqH331WdAdYT1dygDApKU0ZytA+Yz0RBeemuryZaDdT1Xw7ux0/zSz2bnIfz
EyAPDqikqtdCc6LRZvpDaMBViNSzZwF36vJ+DzoDX2Lu6gEUiaAJ93VB0WCMx9tJruebEKL/OorU
suLsCELsd3e6jjOI+LW2qPDNDIegLDm3HsOBa+sgZk1y5fIbvy014qxt41MV0VFHm0vV/6VQSBK+
nzl1CH+LV4GAOyHLKl99owtK+NTFTqdB8hW3jD/NNjzOjGQUbhIRJMDPTu7jysZuc7swuOrYmrsb
tzLRpCNmtOsCfc50/jAycjPDQBnGbO3/6MPvILNgi0Pppsy9V5XMIfXn29Us8wyaNqfZEXzboqzr
x9wfzxTpSW7gOnUk/l34As/buaMJe2cLsszasM9ITGrf/Bp2itFoumKBpYqzydRouOQMVTt30stB
sK31zhXFlu7xNcxDcDl2YWXUyBkjEYxxW15q4FmpJxV87894vJUpDTEpH2qAMu4knTELpheZzNpM
1L04wvKcWCeBqRU7sKNLcqql9wgi4b7ntv0HaCObXFKJSUAbCvfoJOxEuFMLITLlK7GQCCeIAQtD
eobc8F0woPStMWTGnA12pizi/ZaIEj2C0iinXVCrfOowoPvtUqL2b/ofndeFPDJFB1YJvMRTe84X
ORz+gkQ+/ZIQguqeDZAcOmntVPDp4EtXBy06YsA3RjyECBGw1s8fMx/65V1AGjLKe9QKtMSggJ7g
+kZF3wJvA/Lo9Fw3Njq298d+pvxORwqNCeb8MRARaMc2D7IXLDZjppjy8A92oEu8kaAwT87mc6CF
R84iRuRJEA5tAqEwOIJKDrwOKxgpD8B72rsRa9TxD5PTYker/s72ljjY82YG87y5e4JtHOnLvwC7
/rBJ+AJMq8M2WoPz4JSmJcUSIbGTdMORpSysjJi74BTg9ykFTm52vRvftwkiLZ67U0Rjil9dScTE
2UyjKjPHEmZXT9cqg/AQ5oR/FHByyRztNd0sLBv2nR7uOFY4M8c3nYPjO0tINGjzk3QY/CFVa8eT
sDE30aEEXskXrklcM+vD3JKqMbyXuafbelE0BVufA13Zc9eFlUoiFmO25fjpUwAWIm4slhwDxVdR
vulbJwRngVWNcKa1/XuSeP4iBxjBWJsD/IieecV/6s7KZr9bBqEME1n9ePW4YRP62V06/gobsFSg
mnMCAdXsnt07ma34Z4cMllwKy63bqh54zkhwNTHQQ00OW1tJ+Y/1mob5o/hsttTEIcPNhkvlQrtv
527/LXIzs1vIOqPvc1EIjdD0GO9Gkx8xOOQ7mCXnB2hI9rrsUCX2tQWNtO3uiJ8BeHIMiHoNe0Mi
Bocg0pPWYKlkLfl9E7J+2lP/AdL5Erk7bMBTcYn5vSs5iXMC95Ug8l51cC5yXZDmCG1DNjaaUcJx
cGiRHgt1IsHTcO74/krOQvpLADSlrtdBtgeGS7UPmqU/UlnA6f456YAdxk2Fb0wKtRwMVRSUz96J
AGKltc99NX+Wv96w7/zORLnS7iLR3o7bjk/gX8JO7xqEtSEDV9O1mc3BMIIi5vs4ELbFFn+DcJX+
T7V3xKJZBzs+1JPFG8SHh455ZOrQCjZPsqHRPL4qLix6qE+afkdYpGkint9e3NQzwt2iscISY5/U
Rh5A+SGA3rOILNHh4FwVgIxwSfZ96/dtDjcYAWiKHWr32oYjjA1R9QUFjsZEBwZ2txtuzenlYNBO
adWxrt20ttJLS7OGju4jmTEm/nBmRSttuFRrOyzo3ZSJqtwFj96WUaga+unSFsCWpcAmlJz8feaz
1gmDlKxr3UKm5F9MrBNVv1NqevnTNifk8+MlRkZ7sGdbDhCTiqWP/fjMbGkKynw5qqu98HZMnddq
90MgyRw4eNPKu9QBT32K0ulTQ7GKguPq2/m/jxpHA630LosRlk0s1tuH0d5sXsCWBpl5/rX+YDkI
ufyUIU8h/t4SobjAfgrSokv8wnihq2e9CCtIa98NwcRhzh1TNYwavoReFVrPO+e7SF1a8Bls3V/p
LdZIAMf57kz4vU68rULvJGkeM02Xcd0z/uVqmbYMRHxNt7C75vPzYcDcUPcUVL7SY91WdFACET12
IQs27I/9juD/e3Wa1xPz/uIbQGoCdeiR7YvPMJLaZW8gSB4U133nazLKjpFEjMmfMJaYPUOtj8yZ
EnqfM8ra47WGonLe6U97RKkemUQ3BAQdBvazflMXSC1uOGe1pXWX3ys8IWEhY+tr2TFn3/oIrPrv
bX7zGLs2y8Ne3wT/qp5H5bB3ifrBp3AA3x3qY1DjyOvR22ufHg3+XJg7Xg2b4v+YpGj7Yh4Mr4N7
YioW8LFEeNsmjtHG9EBWck6oiWYEHLdLjIMbWSQNnHRZes3OILHCPohPp0lJOErtYxXfNMHspVD/
DfLwU01rBVMreoZ3n6kal2nCV67uQGPXvelL7C4r9WQ3vblDTwqNYJuUIcJfOQTpihWTYFtFxizC
yqmLpd+BudWu65BgGqx88JZ2m6kRPFyQlypENr1bkX8wQo8Adhj8KaPtzrQD+cnWtLKHKd57YPB/
ltPOFhBiMURo5LIqRDeHc6LorInmV1E7pEherc8XtO/FyrKwDX5RER0m4l+FHQQuWSJdAe+9B415
CiLWxDm+3oI5JQIQp5MtLWMln62jKRPwJnCjPHwg2hnFbAfVk6cBe0kALW3M2XNBXYc8s/K7O5Sm
5+VZVdXsmpaBGP0FxjNiuSte5MISdSa/DKf1gnMeb1FMlbSQ53WoacyhO2anQ9084rFAEc2Yc2gK
9Hn0JozwmJzcYpxxhv1PcFeY7TcsJVawUUeRhBlBwrVkzwyaKckJvwrZZ9bYhG3CvyBtdzEJJFfi
AoeWKeqVO5fB9WLYYYtjI8sZMr+7QOzKaO/N5vguW5wP1PWlD1eOOGkzGCdsjk8HXDzuM9ORQHSp
kldZqMh6xKyevu9LJcoun4EawvfjLmvco0kxLVuEbtb4Do/81W6m4Ivb/vYmNI/XidXqQs6DGu3q
IrebT369JaZGSyWTSQEAz4Zz/UBty7qE+QiSNV/aOT/b8mydajEp6tBCAF/jfRtykM1UqUm+YL3V
lLjjXG3wB07moQHocMAqVZB5J6DjuQF1nvfMRVXnZdbc6L9NjRucphf9HP2ZTsEcVAiMV6cjS+AI
EBngtgoBrFLtGaTZCxh9rbb4E/wEpV+uAUBs9sjajmAGdEhi/6k+m2h9RElKYhoCE05oqBhEEV2c
sx9IJTf7BmJF5MUAbERoR/iwVqQnq3AttwQlECTlvptz6BJMeThdb/g9bZ+X+yKqZA6I7eEzMzye
JEoGxLM77VQCQA/mAocvqx2yFSb3bqc5hBJFUSs/uD4OyPAtAQmkB51AqyQBOhQD1ZFAGI3LGCri
P9kYaaB17ItRQ1a64WOgVIZvpnXuJ44Fhd2+wjs2YOG/lVvIfwltd3XdGa4qFxyFdZVL8qE1hZZ4
Vq6zKMm2z+JJ8E4JWmwMRq0cK8jo+VOTp7E6GeDo38y4btZWYvFA67vcX6iqPKrTZwiipqxVrvzZ
CJWIu/mpgSzVFhhav6qkbGftpPPztEL0PlBjAtw9HZ15bYrcVNH4Ou6DB5eHwWdvAjsrok2pQgWW
uGC4RPJpdT9EynWQ9TeEJHXer4PLaYAPNPEVs9wEvd1uY8eSuuoih0tp78oIJVzglsO8AGsoJ0bj
P61faU9plkVDZTM3leAuFuEjZFf6dZ/qN6GClMRgVIC85NeCzSd3uxHUf1+4z8o3rL4C6Z7iZdGE
VQaWyix3OD5cJKRlzHwj1JNeSU861axP+zK9S5ihm+F6WVjm1tyUGhOkPGu0FmaQ4AQWH1oLFJzz
gH2G+uNixvkYIT8WX0K8FVvssKLuuYu9KP3eSXWiS8CJKZIR07NgIyRDtn3zTIKkjHkcDMBRWMzU
tQzb7QpqdTllW9vAwczpnNNIyjLvWmQ706OEZUObnaaXuMcZjTRc5c3AUqRliXzmU6yO34Y9WJy9
Lfn+/nDLExRzp6Pbh3xqsMn3WWbmEY1dqLKo0TLNHGl3xZ5Lh0UFa6B2IWoX3fm7T+jlyVaNkyIi
nZNL5a0Pxw/zvuTIobapqKCjRNZePnAHS+6kUokm/1xcHIgCof8jnK1vq5NpzRIS4ADIUdeTsS0q
vRIlATsLtQjI7J5mSW9y5oKJMk6fhtGfvTmTMFIIj4U3o2I35pLyOUip24Wtuq7bsd2rEpHD1QJL
Rl4tnSDhOyFJ6GOi729UZu/9JXCXjLdKPFAHeZIced9gB408EFJD/fJ+bI1AwyonNsSoZP+VdUL9
PeChZ0zM7DavY6bduzIMOLNEU+u3GqVC8gAkQaJXCPblp/AsIxRgAVleKKX24u3/dbUFcV+H6yWZ
Wk+I3swV+iv5kEPkTjVEoap8t6fKZiPK26TTNJ9sMU0WUKLuak5c7Qym2ui6oiMVvqmZTBApQei6
5iwNIofBFNbHgEjWVgEM7bsosyvHlHKEII1IgYHsBiolKcANcXTQg9kKD7CRIq6pWlo7MOPLTHvN
219EXamCU1C0oRNByNhXeDA3o1uB2sYNZqefeJDBpjFT6sleIJ27+HhbflP5GVFc/xfxaZ4pPv9B
bmOLyM5sv/2/Ca6Aeb8A9AYGNUTtBmrAYP8623Aj7J0oukEo5gLtHMopGsWAmWD7Dkt3v/1Kun7Y
c4Wz+p2XX5SAyvkXtDST3twBYSlp+8X0N0UR9zmYOgAm0+hO1S4bZdQWmQJbCneHe3+xxjXAe0oC
2jjWQNnwFxj6z/KYhHKv16poxkzCjES0HtGKKjzQmUK7rMvIPK4lVTJ+65lYQ2U93pfB4bnsLCRu
k+G7LKURPAhXC58CyY/ZWJk/W3OAMc2XC9indWW25fZprS7JLdlqc4G0HgUeFk+MHs8IHqj2PPSx
oVxb2ZXbmqkv6o9XfBoKI6NQwuAl/I9KhJ69TAolTctX2hAZL+dOlFQeOb8M/gQ+lXEfWdSCZ3xd
qKkUf5kLHC5oiVLOjxM4eMYS73EW1SNU+ky0l8gyURRC+xyUWaUeCx63QWeCtlVHCYh+Vgu86Kcc
YeCw1/H943vAaR59/z+mrxhgpMOHQoqXD0CCmpUjbLz4Ob492bHDDTDPzYPZio1o1UYEDLBOpjM0
nEVK/mPCqyIqHRf2Zdn6L/13Iy7nMTGWMjdQUQYeWEAPMjHMerSjtDIRR4Tegts+rI9nY9FZrpQF
ym27seySLyd17m/ElI6zkKOk85oQQqyP4kgqAYmEa9eD5tUK/aiGdq0Vg2lzUxZhEATvm2aI9xR6
/Ym+pHhxVgQWT35POy6+rMoWaXbxj1sgSUZT9gp8HMqP+u0aSsjVZrTlYaL9Ho9kv0eaQvC1yS/j
RKqcpZaj2+/eRtlAfxT7wF2Sa8HsDRPl4RolsjfaHa+DHEz8++nrfMl/Wsm7Wi+IKOZpGAZCvs+c
E9fUP26WGjSxphvUz0H0Gozh0sqz1YF7Wf3c7xsa2khixG/IrqkyJ7PYsg+/3APSCZwo3JLnznAp
tCbWbUgM+uS6us415NiIQ29z7sCeD15BFnYxzoMepGggFelAv2Wk3thnZxTXU1SXHbWMWTY2LCOf
dAH9c4c7nGt26KC8hCGv6ZN4g2+FegNiGyTvsAMlHjpHo9tGyR8741n5DBEgnLwwf+7UKX/ymqTg
y3M/qfU9aSezP1OhwOsgLDjsBG2Ru0o3ljCuEdAR3bzE+WV77sY/Em/z1zsMYItCBwWGRbnANrw4
zUhKNuKW6TZOsI6DK/yiJloJAfe3qC8XEXRZ43OBR7QVwY7f0k0EOGZJCP2HaYRMH+L9dZcmaI8g
RzcCopQ8N3EQEkiARQdQEBaFHoV6n1f8PSZ+xH6Z4gG6xJ9fSM+JbMmtH/+JEBzfazUgbspG48NC
GMoF5Z9RTgpNPhEvuEaVkP/jDIAqyUnNetQSeYue79/vJgEodpiJ9LYGP1fLp8uIg5Kawph45Goc
bSW51t9jUPwC59GvL/uruP4hCDUTr5dTk6DtpcLydZahvJlFjf7OGMRE8QkQFdmEeiIyMSvpk0D+
nPfUQJu5n9Mg8fvNbYpN0Ho5nxI6uwE28rIjL2jery5iocz/GZhd/xPr/pMfe5iixUvWd7axmz94
hE6Rlha5EeBiOfZY/omNYxQAyPdgHBgoPiBqTSI+glmD/7ouPouuRWm0U++jo0VsUZyLGNzjkknY
rJHSE1lIUTpGXu/O0w5+Vr8vXKp9b9aVlDaI/NOi91/tw4TFnYCkNOghEqBYCcb0rJQLNlfhbdal
2eF1eSJuoDew9kUMXdCinmvVwwWlBBCSzN6ikGZE3L5ZLWFa+a7AGRrXK8//x5jsKPsTC1aVKIXQ
VZt0rrQBAvcB7YwsjfZdGcoPR96aAnPicRp8y+AWDsdprPHnKRSL7dn/RBJXWbl9phxi+Kk1glvF
YIhDHhjxUnICZ9dzLbN/jkAMC/rYQQU9llMKXh9HJLjEH0sfJlWZiHhSHtw9J//q8v30bKsQa5bP
lODMxuEDtd2SYE0CAVre4p0PaAmfhmkq4RDnCwr3v0jmm6/hJ2JV/WHmUUFIzt3oas2i8JXu8fiu
BS0LWrcWGIwM0vpmC5wZMGdgTIr9LKvkMjmPuzY9xZv+p5rkabqJBWUn+iE1r4pMeuiwsBlg4RP3
wOIyViifq80k6+egV83MXgRtrFB9qFaa28qfHZgIGpfJpHIUKLhadroEtqSizL61rsumCdZ7NQip
mZM3OHILphO1B0I8dNlTdSp7VldjWN5ir0/EAX/FWQ/ELn60HQ+sHHMmJv6efmzaaMLepAtUiLwA
sl5M8n/ssCkvLwwpCYvOsv2lfbeqU+vrH3hyu8ZTpWt+DyXCuerkoJwDtQ5i1+CsAFZPqUpKmZAI
cJgcm8kOOMMFvS8Z+bO5Sit4uf5GtbLrRwVOGk8G1RvT2W8QW9xRvMc8HUoRNbrqimvYgCJ6+/tI
0vHkEQA143P2tjvbiq6zW+ZOZ/nLRLTbEsp4zbymvXrGRs6gLsCaNKPIweHjItgjjLTi0ftJBI2j
C2GTpAwaoxYhcOQZkLAzLvXUTmUu7JN6F/h1AhQjV8QnyNfTf6mgp16CdkkUvpQZIopewrMoC0xV
DLXlY0X7OJlbsnv1MZLSK3OoUBxxTCo74t6gZGlFlwnDfiPvIK/v3/uOaDP7m/EMKLAmnNMDz+Pi
J073armz/O3HwC0aWEvwxPEUnRSuajHdNPIHUVWX+gDE2dj8PLJufpv5UPTpAhnLOyvQDK0E/CvT
7s2PdCqqa/BlrqYsf7tq3YWT/WWp5maezQGKNOi4