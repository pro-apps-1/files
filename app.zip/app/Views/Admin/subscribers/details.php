<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuq1KYPTeAO96Ex71NQ49Z4AfCXWyJIBYi8S5GxwpgXdwhvykVFl7lCDcrqaP2SdDbojQE1K
Ye+RidrWP60VioEnMX9DAkQPjFoIWYVzSNsX+Gvhsap2BRQVNCstWtdJQXYX9goVHymUvuuZntZa
kyh5GneZzO1KS9IqlLSDOHPLgr+uV/aM40H+uo9Ck3132jT0kgEz6w3cEE7RguIBnwx5fyiQKkcO
f9qd7+J6dRue9ZlRfFPBntY+VNLdWEwxhRSaFUbziC4aQ0LNW/MnLNDSvRLTQaM0aSPO/swYxBy7
UdhlHFyFwCJkut7H1mU7dZDLOmft5zJbvOTHrSwkv20VFp/kIjzcCAKQWycTWS/Rt2hMZRCIz+ZK
o4FAzq47e9oZUQGN/gi5MQHPlxlcY0useOlZtnTGl/fsOdS7FRNr4G4UBO6KmYTptUt+bCimI/Rj
aP6e4L6q4mUUwoEGw8u1CAz4vT6lKSOOUJQZizEU5zDWE8kEVoyYJaW7AH/ooASsMmGnbXZR1oxB
DOJTZtuHLyYXVjiNShNTu+DaIIdRQgLLpsJd/7Ub0ZInsYyblDreFVmvsLPWLU6L2SZO653HJ+us
N+PDThRYxhKQXXnpX1HWvy0KxKoA2hlXkvmpVHaNwPzF92hZu9HYrGl6BtA9BnCn8whevWJDM9Bu
L7hdiMtmtgdHc2f9g8++JDg15VvJCKvkBzh7+71yatn0Mjppi2l0W+VQalKg/FwLt0BYM4qgLq8i
CtSUmFUDymgpaMCt+B6GbXkmB+mXN90KMTvzDXUxmnwoXnZTsWm0WPmwSPOIaPLbQznR0C8X1jq/
yaGIRFse3H7+s9rZzzAG0zhs1PDO0m3u4o4A9dG9x+LoYtwZWMWE5b6MJ3xONDlsB+2BAG1ti6eQ
qmj4cSAsk+SM5lT0tBom8D4PBo84Pv2ScpBlgBH4PC758azeHiISBYfjCkmnVWvjiU/NBT8GiA8b
ojOhCEdx8ql/K5I4H6EJRoRp6DwbhotoPoDe4oh9Ss9T7E0wbLpZs28Ex26+DouS0Prydu4gWGa9
l4MBYglu6PLNQuO/hpho7MGB3DFBxd+2LZ7ghs5ff9okOzsTJn6oO3w7lJgven7izzzheY+WvRt7
zi4JV8KbxFd4XByYV2nQgQ4BR1bxE4YgEbYNhhOc3rvRqbgxBgsdTYffU5/GSfOO6g0/7qFnKuEn
yehN43SczNPrf8n+QOnwKV76tk7mnxGM7Zt/nbV8W4K1LDOwrTnnvVdy7gUU8g+9BwR/VuD/lpWF
LmAYun74YBcqAVEcvyPs0AxMW/BB4mcgrZ9iHMqFSCQsQv7hAJNnd/Riw8MOvZ2+DcPT3McnsfYn
WmE5tsYPtybGEWEXTVGuaD3lBW/bOfLv5DOb2VGN1rqqjubiVG82pvt05iOETdmrYFIusAAG6f78
jPIGq3NhjpsXY8BOBb3Lih0iLsu5jJtT0PhkyWoWHot8BGxBqs9hljdLedip7C9PxPXWp2gi7p5/
cLtsu8ksh1E0IJDfzMyw1VGbG8qw9ToBqOyIzddrbrMJRl/rnN6pEzQVx5pnJtYDQdqSYtbD5r/0
CGv8NLxnpWYNlt1oNGV2sXOn/T4FAROIoDCFneJ/lVpduvWt+M98BQcOooE6RYfOyXMAd6Q2fQZt
ZT92dyUnnIrIAbVXQju+8GkDbWmSm+ssr8j7G4oRnDM1/wmg1F4BEEahDiWAdKrCsvvWAzre0vNE
r1G0WhQhdZg2HT5ZbVbSeswe0zna6b+8wm0WKiUpH/RS+pJo2x3KxchuS5cLBMFnnNXFG/A+6Vkf
gKfLhb5jRzgEPkjJs5aTT5L2xBo7H35NL5hXIMKbruAp+wwh/O4Ng91S6t2EVp7tEHlehRcRjMtH
6opqRhjc6knRBvMuw0xRtRhTJ+wv5ar49LP229kJ75C2ukJ3nX1LiY9VQyrOYM565CBIrWDKBGc6
JEVSdGvow5gGzorXPbrKfZYyPWa27voP/Ce+iHLxb+FcDedzPr/VwdgnruIEGX//lIczksAbmyk6
W1Gww82WtfzFJlCSbSjyJl4xvmpYzuFfLuzgSwdyfjN9EpsUr4uGrYDN2wYjoRlONh64y8HYmyBJ
xBMVjh4qMPWrJu3X9kMLLh0Am7Vr/g5ruNmwT4C4h7nHJrqSCbroZzTwZUF4dcK/Q1tarDDPwEaR
UtDpgZG1OcIk4oLLgAmYBbzgtOx8TW+T7LYBu9o0Pkd7Yfl/k28/P0FT6ImVzLTiI6Yqdyr/lzNU
fwT+VWm12yRDbZb2y7Wbl6m4vhHc6nTDFI76cHhXESLrS5Li+ENdaFE/tRModbp4QyROeQC2ee5x
EecTDkEO/vE+gI7DpK7sR0nPP3FueuLplAzac6asshN+OIoX5KxyS5UYVo/yVzRDB0ijTq9SkvgQ
I5fEbpX8ZwthPQX8wGY4fabuEF03iCSnEYRhksymqN80aBXku8VmHd1wr/JekfJoarWcM2MQXbC4
J+K909ffYXMXeHeqXmR9kdL5HowPjApjUlcLcRAICFJ+fG5viEzktcDcCDdVJqN1zstT0b71P06i
Qz9cTBLn84fTx+gt7lTSYpVtDmdN7LRhYQWOKbem59OBRga8d8TEoR1M9lvGcXmpNvLNHL69ff81
alNId2I5+YNl09ThXV825aMHZxGDXLp/Eya2lofFCYLjE2wf/SpCuvfvPcFpOP5ceGerWNTUJG5x
yjxRmp7bEqTk1y+Jmh/1PY6uPY9THe9l5DNpc9SSOIR5Sq7LXbA8lRhRZELra9ApDhLCmgO2EG13
JPOxEs1pvU3kMk0eagWm4Z0adfCbBQhmMA4DgpAdYJqoAPlOi7p8UGfT53bI83WTAR15uAYl/ApT
fSlCYn1VlMiZceLwPeCi/mm+qremQQtM5bGJhSoyn1M5B4nIvgfQ80aJsBWAapNfAaAXXaoDR08d
qf3yTTOo5PHhnEDb6NjBEH2LjWA1LzfJC/xroyguVOfp9RnE0TymLRfSLFRktapYm+VMzTicdL58
r7gKWg4roAlKq1TW60G3vfGf+h0KmirZVvPRE8IgJrnapqCBtOdxev7XvqpCGgt0GKi80bicKeAT
ArtScRwZR8jAyQYUjSt+1PbzJsT9RciD07PXif09iM16XjsGw9Y4rRqFCy0niq46fxy1zKhEEtLC
88F4sFzp/DS42GmGO46sxsnkSfmBP3FKqrRTofkzH4BdMk8gERSP1g416EUsJ6bBdCZr8sCXg9Hj
bwLtvj12mXqdGKkauzTJLdI4BKrcFp2I+x0FUlHFx5z+jT3eAhakSICWt+VcnreVoZXq+DY3Nesy
8laRcH6wnHTzvLfm1Qmu0IgNL5YChBEN7YCcXJPza8Jy5qItgcQ+RAN1Ixo/jkjYgoC8t7aHSlOV
diPI+qX4PgoaFVyX0g6YviUdMCEiDT6FWHYSqS0LTyBzaiN0nzMPUGw35gshmXQQrO4uiMjiMcyD
aV9Lioi39JbTwIDtLXAaJq3G2sAa3rBp7fKYaJc3qwAnZcej4/dAxpFwoqiUt3dcL5ykexnsIBO0
8jzx+lIVcFZrDG3RmMTJwLysRd3eGvZf4Q96dlj0zJInGGPzLvufgaFzl65FW9/3isvX6L1hBLRX
+PltdV2qp8Bczbwlm6zFx3864Vt1rDbqz1pfc5To9nBYTooVqQAVzAUcrIiuJHwtDMc/RJbmzvbD
SVcfveaX52/EhJWW7I2b8MBgxucAPnQaoChl6gHoCQGb4+g6MqbRRZaqWCZhHskxukAixNPmUfMi
xO18c3DXrOrxlpHk8m+CMuA7JzbHHxW9FepaANiC1hvJAaconEKvTuoRx3D/IDwxPNeCojfBPvNy
CN9hO+zC7GRb+jOAW6tvtxpBf4jEgT1/YpA/UOoEZxTeVyTVcwDwaABiFLGrkZkB85IVCG8rOKxi
bDRVv79OIR3fZuVymJMJAa6BXLgDdzSBYiyCK6zaDL4KAgqTi+Uoqwo0LQISJUmZRyGZJ1l/Ix3I
47+qa3imr7ssXXUXI3VBN4CkwPUSeExlD2zUjPDYOeNQWjQdFNhqWNeogxp1YjlkKS23PJuzszEO
3P/hk6UYdRH/vNYhk6WFjHrqdcIj6RjiUKijYcEfY2ykxrdca+BXFSrAiTLLVZY0C1Dagf41U+/a
b5vrf2ntl/PXTt9Gohi6G9iUxTg5pzpSnGZNOINB9cGCifrxSVYWi5trfYm24hHAj6jcRMrTrgZ5
TeAFaMZgvHa8P6DUHb8OXnCHwSm/kwWdcjkhYzkG7m5UerVW/rOA7bvDvXocGjkYRl10h6xvAnfL
w0P8SzecKITc4ZJG+FyQLmZMzdm9z0y2oVtaCgGcisBpNJ1nonMFBEWZgRd8UbmjvOB68w9RhTl6
vlmtWKU+4thNMR1DsW4oojTMfzMOaaSlJl2U5m1D+qzkgOPn/fwmBEDgYqLyIcDImujP5MXLkdKZ
28PstFIerqhIEFTAtYrMT261K0Prk6uRjR7q2LvAL1T6H8nOBqaIjATQtXbBNUWKJyr/fsuD9tpN
XICHZvLr01b+UVlSevO2Ry2e4ct5Tv1Kcm0e5WwiFcUAi3sRWVceVOzwXtftwCvv+24nCH0YiI43
fEC4HzGgr6yw2Xf3W0iAEOVe6NpS36607oWqlmo3UUuP31sJw8xXUz5xTmlr1kNWZPiQlcdY3DWk
Zd4gMyUV7OktdqOhuNAPInFiDTeP5qQ93vo1JQ60ryVtoZR/MrMmurgGexAuWbYx/d7Jn1IOX3Fb
iS67XPjbZAPE67rsD+OTQg90R3T0w9hC1ezPPXdIkVMLm4JJLcZ34oL83qkXlwc8WAYFD2CBJekb
QKjJWTCKRgme07ABd94bdb9TfCgmNXJSPAUNEkWkISNyGPTatrPcP1dF9qkraR0bBRfAPzGAhSpU
jirr8d1UdM6gir/1t8fIbzkJ9ylcCgUkecqkDIb3DooQ2+cE7yH/Wwi4+X7h5jiAOsAZOeBbklMR
0fQz+Y/jvSYxfslIMqCTBNUnrNnJeUPA5bDevn187xngIXcl+kRNHuok8zkrGnoHHRwWnVuPZ+jK
E21NhSW+7il7491FgtWRqfpXi36Bn54WGjo0d3KMANcCMNIYYM8nki8sWy0jlXKMzYlwvcx/fpVw
Zjg7ly6APjUocJyK6DvQxrk6Eg2oWvWzhyqkr/mjfwEkHvYUVnDpaTiabk2kAslIshRzjsqdhe3o
cNEDwJeJbd0ElmkajQZ6f1tFf/dsbVD0D7zY0uAJ1P7XlIRhE88G2CEL6jSmkPLTpoX9ahkeuhrM
CzfwczDeeck2nJ+p3kYSZzaIK2ho47dzVwcy/EQtoV0YUPvoW6Ls9MVLIhl9EdEAgIp9Ksw5oSiv
r/1qKzZLJy/y1/5MfQ+9UcbgqiU0xG90/U8MJ6LuyIUR/POxFnL+kKwyrMaNNLb5Xp0UUxMpAKsE
OauVIxQLuvLpuRnFDOaHOsMG13l33oB7N/zYi8s9vA/ZkJ8uHr0swzlgEsgl9LoNRqlJMmFJ5BaX
nK9Co5aqqPZTljr9y2hRWNVYyDUYGJ+7rFRmS7nlORdcGZSsPiVUYuoEYup8syBdYeD7+krci1Sb
siLxwfl7MLUYD6lsTfLog3+WorV5AULu4Ge+PXReyB7P/fOGvw59GW2SPSfVxXxHg1l5y2GkJ+lB
sssBY3wEWnvqH2vNq57cZ631OfjVLY3YYTBk9eD4TkytTHMEzrqT5PT+zv0JuH4oLi1cZOt3XZH4
d2Hd1gzo1Q0YaY+N5MZ7PnFWj73PfvsUUIpL9Ms4cP24CGY6ctbwK6/X2rQxR5vzp9V/mnbLvMXP
CgIS9hE4SF+UfiYC5TKgIMHBy4VffKQ9K2gHCW3ZQU/ungxZGjgV4MpBNZqmdouqyGsqbPtjrcp2
Q1ntiZ0CCb4mBjTrAsU4cPyByRpquqmedoJPvqjvyZ8wzNd9U6e4XqxUCfo4rXYywuCJXyTR8I1l
msWdS4gfaboQ2gZq92AaS9RleH1pn+nAj8sxKMVd6uuQe67YAxccelmLftiPZZ8Z+oP9jDWuPK2d
11WlfzDDRMaEZn/aNZAl4eldNErKDQUFzsuQjUL85jELiFgsPR4JOXr6+v251MrHyYc1LXPm+XcL
gW0PVBI751Wr+ta1P2ACoyB5ghgb+ghCyp0M/dwZFI/MqL8wgBvUnSBk34QVlaQebTdhuRyoR2+S
KO2u38csZjDgNr+IhJ6WlYIyJXNNTpBZKCbhZr1rMe1EtIhjU0uhCzK3dv1k96bjdKAR2jtRIvQO
HAkAA4SNPNCnHxIJLKhKOpqA1D4lkuXTBLlxG7TWT0j09WF2GadQvQ/jLh9z0n/PHaUTTF9votxh
HCNTTdULnLqbMQ7lsYy88peL135rjvx8Un9ANwNBtau6mutV/SI0CdnIUikRAnP8l82A9kYIq9xX
qkrqMcfPRelo/7sGi8m4MxumWqCpObd6gkrxcVYLJVUCYUnbZ24w2UbMFYLuD30a8o9kXSFkJAI3
MY73iUAZ4i3BG+8mUtpydos3puFU/VXab+zbNJGK4BGjgMuYxHd58XspIfBcQ34itWsrCtNVGWDB
p0aqTidHdM8JNazqxvADe0+nEdkPc+pmKb4tNWeQsXeP44/fRwHGc1IoBcPD5YI1mpktq/pZJCaq
206aKNe8BT8A8KB+nieoxGg9HGVnO7VMef314V5Zwvbbje+SU7mjh/n+skhG7LLeXODVgw2ghDAb
+W4M7fB6tNbAGLdvnms+Nf0zqcNCUM09NHEwSZYIxmO+28Hq4hRSwSVpRRflLW9mIr2L7j5OLYGS
GaNQvbRBfFW+mmGQzNd2X9dfpvghrhifg9X09i7FbMWLOfA1XLPbQAOLUUgMQfNtZQ03ztvVBn9k
i69AEUfQvMcItwePebxDHVUEaHgTyfWujSWFHqn6KW6hsEjjuBHNMY+FodORm8KVbDMYAv5IA8+w
wpNwKGjTLILdh4j8Gs8WsjvZssf+UHQ06GGGOz9jXJzrbWcJ6Ey8rF2zfBb1kwyOv2DI9ONS2SgF
elI/u47bWLxEfmGM9d7TeOGq4+x2pm3CQzRAGaZfm8+o7Za5VzvQd+YDw/cYdptK7GZ4cXNCP4k1
KoK2X8dwVYN26EzOSqoPMoL08sfy/VaSRZ6a81TYFLsTjSzK4NGCX4c7odZNvshsBxwrQqBhpT9P
lqy6OFmXAWAEUmIzS1f9ZFTv6iwP9aKNxNiwtcV27++U2TFtJjB2SgzCS8flUi0H5MSorKLWkWyG
4aT9Vgi3BMg6D9QBw0IdU8W1MEPrv2Z8frxY96ABm9gR0RKx8cwgi9m1jiYF8Da3E2lkgBbThEFL
KiDucUkoMjSXxc7UalV+xD7oZA8vUNSJB2bip8+5XQqWLcAAGL+KSJ7+j9J4tlZzJ3CTgTn16oJM
es2xN+l/yhqdSTJp0wqZC4UPDkDgjmDP7CeM8/ONPC+6Jsm2PIcWbj0dDD2Vneyu4VEgXOVbHjRh
MxNXvqV9UMpSid/607gJFvI3D0gJhRHm3vgOeUlaclN2bkYNj9TDfboAfOE48brLGYYUZbzGOYNH
ClfsXrsTBMpl2nawQMMmQHV0pGjzhnBDJgyYGKuDhPVWjuQf+ejqaIkbR1kvUqptyD8AUyLT+Viv
c+bT+LqzBysedzhOaRUY1zytuH9+IFsX/eM2ep4dmsyvFyMqTeabZpw8P0SPZr/u8hBA08rqN0j9
TsJOemtUCil6DyHoaR0+NFkgPf1i0vG+MmEkCnNr7YhD9AJDjenMZShJHuRQQtOhlCnvCeU4UQPh
qg4ISj2EkvjvI5l1O9jw29OkBchQDhI7Yz9v+uFh8VL7ZIBfw9DwfC+MfHaPyiXAGxU+djif71fd
BHpyJEZbnHlNPEwJl0HSppEYa/OkLTyPlXyT/tgoe8B1HubrsCyIT2ra6KLjeUvcXVu4ikAFVry9
QPlJn1Fz3zJfj0c82ft6fKQEn70c3/gHQz6YZ5YvsmovxY8t5CXLSNBMSVDuvif3Hv2tHgT3iKzj
mFfvJj1TIPzIdKf4Ug/+wzg2mt4e0Gvw3ypGe+Nt2vkybJJN5LRQ9LV9a7fD9RwWjuDg4NZ0z+qf
ZLz3j3LwTfUaDWHAzin8JycW0kPOTIrgLwS9W/j3ETeb2/7dIb3dgKmAfTtOBy3es89kyK2W3PDQ
C85lNNLMu2QRjbHv5bg3wnF7pEzO/GckPUIGbNDTHVW+mtS60AA6fwR0K+y43/Xel9alyaPM2q2J
1xm+hJt79OqsIChv3VGtvBX0yVuQeFJDFUhq+yvBpCcHatZ85QQvgeWh+k4VH2JLzF/rAapb2ntg
fUfUEBMM6ZE8FgJyhrdpuQ4vo+UH9EInzfTTPGjhYcn7ZXzyj8/f+wpzHwRFnMMg+1whJ63+vbkZ
RHrl6eb0qLWnLCXDXK5A1mpPztFoAUXB+TUmj0zy0sh0W5ugQvHFxAzSE8YM9OtWIoYsPIju6g0w
UmdQjeKmLXnDgePxdWxh+SKvAWqFuHPxntV503HRWVLklcMKkhVw6+dywJDr2aKnX3YVygXArSzT
6NPpP6coOJNSzaJjMbG9Rs1FQQ7IGOSaJn6o/ydZNMtlUcrVSXEVREHaQg3sAJcxBpJoOG2E9QQr
zGeFOUWe3/aDmY8w/GKElJecoXVsKDqQI02fE282qmW284CJnk4oP319KvuBYiH3LO6He3If9QxB
y7OTe2SjGxNyH9ktr72B8gOxIJ+CsInf6PDuhmvWn6m=