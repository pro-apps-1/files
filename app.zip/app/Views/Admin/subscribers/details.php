<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/flsbQa7J+PiO5FTPUBXlCO9N6QOFeuZCvK6LT01hZ3BNrwjokt+i7bvxWdRs4AU5rvN72V
ZY23YHKvQYtHuYLiVILoZTYEXS279wBQSXnV2CcRkNFpc8LUZK+bThn27T9PfzBpAtd3IZ/e2OI5
b6D4YDR59KzDuRxTB1zAC0kETbL7YVNTqnc1aR0lEVx6tyD20Q8usTCiqcWzIizBX9ZpKFkAebMG
HvjkFW2ZRO/hSugo3IxMfkQu2g8TWAcCcGgXnRKuzappfhx/q50CX8kf8cNIQOiiqkty73RfZvok
vMStMOuqC+6zMIS4jDSPZWrr5maLCTwhOaSrwxfAX8Fd7R5PNpg5CsK4LhZjckcrxp2opmPQ1ngS
cD0H4I8ZvzOsY+I1UmKfD87PB+pPOU7VRtazTLkVOUEmD9CDo5MSUFiDXXoEUmr7whzexGPTU7Q0
OO1OquhFAcOoXbrLKj8ibTU/QG3wGwjJVdu97rc5l9UbsNjgS29ZxoXyrv+IRxXqCMR8WdXFy0x8
7LEeMBOxrpZ/Nmn7a36v8Q/9IX6YXhogCJASHNbVsfGUxaXFKEhzSoWH8R1y7wPcY6/nZ+PJl76c
iO7qr5kk3YSvguCkl0Di3giFiMS+VDX4VEWIrZ6fBtyV0bnHH42ouI8dH+MvrMPjN7GpaHVhDzJB
5P5ZrjJNXQOGZCIDwpAcwWb/etPLJ1xrHKq6lb9oBvBA8/PbYD/pmGjZTKjbfXbEaHTXkgGIcTxX
osuLZ2xtN9zm0uOVK4/V/K53rqp28ZDFgyzsGHOozIn9B4hmSACphYhRPgXTyq9e8HDVg/pGwbLY
A4v3zIgXfgKPCmxAh4vxUg5sPdeKjW4RI/44105ymnCfrU1zM9odQH4s+++diDvZhswoYOIKuGdC
im6AJiF2aqvyS22J/f+1JvzxvFLge5fZPPUk1ungx3B6dA61NiCeAmmV77bcfp09tH3Tokcnp/LT
sCskhH7XGJ/NHrranDbuHZWzk7Dr3FuXGsVv5L4uj1mCa26fpgBzm1noDUxA+v+M8J4h2WS1RDQD
fAsDNamh8DMzyXcTTK/RS5/fW3ioKKwIw2du7/fXvjSFuzxHobxl33EBzTUreyeAGhy8PgVQR9rc
SMXPppdA53y0/XzqqLSw9gLDDg1nzyOJRy7vNc4FdwUiOX0z/AlIA4drn6+Qb18cIwUT6/8Gx+q+
g7FGbB6jAHaHTyb44g/MvSB/p5ErI7w81/SbND1oQV4MRwznSL5X3rZe2c/QD5Tvt94EFJ5I1NYr
xeK6SrSkglPDS8w4pu07K0LVk+ThuDqVQ5VrA02kfskKkbbQSgLlhinVPRMaNoY/ZB9YHED+bdhc
A4UV/JzO2iDHUzBJGN8A0s5zGw3393IMAbVz6QH2dm9PrX1CH50c0R5eh8+ZV2bOsF58Mf+bUPk7
VUFRvOt0dSWGyOxRV3eSBfaDOQnz3Fn/H1QUkWPBcKsQq9rgfrd2kJgBEDTUvrhvaQH0ScO3jxOO
1ecjPJygrvfMDBcWI6SGeLzsdXeWLPvMyFcuK1ahJQgIzbr0c0JbYpWYts2pOgInzr39hG5s9BDR
stHyQH7DTTvKAI73UbXM25HHmWp5T9D7hjCm+TWs5yUoTXUZtC0HK/DJV/LF79cCAXdWwBgn0VRe
Nqm2KyP3ldlYMbGiN8pUrGZ/qoux/yCvC7HmUgiDc15lNVH+BX6rtcMy16XGz7IzD7zA1J3pn+pV
JZYUKIdA3uJHFNZufJAlZoKpd/F1/AnEkrGxL6zJAaxrbO6/TDnxW5stgQLt2bkRhVhPYW/0yKlf
V/q9jSUFzCsbgIIIDf/wfbU6sheR2XSU05+1gxhmwp4LbWn9WCboPi3OPhdLoIOj7EiH+k0SqRdQ
GsHnRb62nep/+K9uMBsBrX7g4FffofIq2ockbXH/JIxDvvwl1jZoOit6fdQLiSIt1mRQmzpD7q2P
NaTwCTfhM4lA7fGd2m733grAkibEyx4Ndbvj7EK0S0Zjs8gOkvwTlctTaqjdkp5DiW5uDxbUhRjW
eBZEoCPjP/lZpUtUXx04R0uE/M2FhvAIr6v1uakX4PqspuClTez3hrK3Z1W4c5nVAOmTxEr3BgOC
riSdnNOrx1pADCCSeCoy0SgE+Ok0ZkoSBH3/4Q2DVm4xcNT/c6PFOfQ5HZG5leq88o1mfwQlzW/Q
WQSNXWrLiOOzwdcsvETtXwnoClFQJgPraQPGog1C1WxUcv8Z8oasBwckbbheW8CwSaFezDBzcy8V
pQl0LbENwWyhkLI6vC0ZXEt/fp/EAtw47jpX00M/7vupW1rbx4EWyqXqBgCgGV/9oAKUwxR8RqH6
zhmK3VD8HfIV9ePHYSMBuxA76t+4ROID59WDTDAZtpSm7ziHKxlYQgm50wUTI/7JVSmS4uWMlU2r
sr/QkBmxyM8rqXWJI8Yafz7N866IaoyEgfilKf2XjRfeP5X9laOuc3/1Uk35VIPp6KwuoFVJN97A
x2uOhed8htKOBcPLk5Ir8zBd/E1fhOBZnuK59OFUHhyoaOlCV1bP+yZGsHfZwQzov1nZQX3Hdw0W
uvS90B+WxPGJQMRSoY0pPGbZhE3yKEsSdgzl3ABW2G+7th41sRMR0h4Pk5fjYJMHMP8tM0hTKtg0
ZXQNAmJ/8VQykdOHFSAsvotAlf7SAcCPdrgNj7xPK6Ebssu1KXUb5mubwGq6el5xg5cHp4/AZzbS
B46pmwl7rGX9NK9due/YZzVCeEKLUrH6xO36Iyc7qq2yheAR4UabdHFygRZdd9bsLqA3R41xLNgw
Uuysdli88PwXLeh3jhRAQTNBWkv+i1ujWXY1Xx8nLWR0Jw2s9heAdT2o19Tbp3sjTYtcSV/UpF/r
ZfSZWhwMuYwgLfA8nIcq/YAPLdfaqvP1BdgKJL0xA8i7ThC8PkAU/DSnM1Qe+OtvEUKbqbsx8HUm
I4VNTl/V9uP3bzADLWmfy/h2Yk2qHH6ml2UEUpFNHJL1jMRtsj98P5D8FX0ubArg5soG3P7Upeue
s01/blRaQKoDns3bU8EJxcgwqQEy/hitSSGES9NyCWH+UX1ixh8cyx+XLYHelLGLu9dxMGK4vmPq
u8ewCZsEyhfFR7RjZ9aMOidEXyxfjjkuRVf3tgmQhIJntx7Oo0vlirXN3nijr1tFrSKCIv6rZFHn
hD7JOHjHWi3knDcAUJCl7V8RQ30fWGHubhNwXVqNa4jVaa37OpXQ/B3f24rLbL4PEE8Xj12IR/QA
7PWRpUF7OJUeSYCslzEfPuqKHVkhDruH6HdrxKwhm0slCkIyn6IppnlTwEigV1ny77lDxEeeZVuW
IudWE7sw4c8svAVono5YAsc2E634j29BKME9MVdG5xgEkc7PY4/btCYT9tAorvw9f8OcwD4jKRRG
9B2/t/N2htwIAToszBIipdAw+88blVGooTnE/SSzQa457VC5RoyqUZHhMFBcn6cJfNE8CwAQzLN8
Zia+5Tqj4V1rkpcF9Fn0hNR0AlLshBJgWfgj6CRwQPv+TvBAycAQ1rIIHO0/CkVqcFQHQlxOppt7
uMz7RkywtbH+cELDz3XrNAHtgFSIN7IoVMPSQG4f9YfSlG0bCxBhN0s2MoRTHfVo1NW2cHcbvzz3
Fk6i2NWalWgkdOHSK7xjTEaixMm0xMp7DJWuul8mlSKpMl/IPj73w31HI6PQTTzFOGfs+mhWdCzk
keTWYSHH8csH23/r3X43UmYtWVsFg4sbBSmUKlmrW7jDCvI2P5QO6Iu3/orkUYGHhxFHSTIw9l2J
uNKgHuhXbk6aLpIQve1wjucJazNs68FC1hWWTicjKi4GYnsvB2//OyOtxg4KZ2mzJ9BODr688Mev
rovka1CkwEOflbG18czJcM4DQ6+Y3SVOXXfw6oyGCx3G2N6yzwOpPcK5Tn7XwOG/pckQc6p3IIbv
ysHH3bLRk3xh4orJLeb0f7lwuU8GVK9brzNXEdD4JwLuH/6Dx9hByG3UpDQtIh+B5qnjsrVjjgyG
dZ7YQfWlxzue5eahiZGgTARb16HOE32uDiE3deaxWLuwjGPZS2V5nyXeQyy8ILmmxbvwris8FfH1
QOee6CzMTjoHNjrxSL/lDV+3g5nhGCK6T1473Co2qg2IHm4PXD0T8cg9Vkmcu3VY6DwP/rkTVmrY
uQfl8kI1ZyjPtSx9Ql/MQlt9Ox+byywdKN0jIDxvFh9PoO2UjD06fj+p8l0Vm9K9m6fhuUAGqyZg
K4omjop8PkiT05Qs75zzWhKQlFPZ95NE8WzVwIwHENm3bUcXEaM6nlbfBis+aVePEIxj56mpabfN
BKBqZSQdHm8ww42szrVJkce3rOxAeEkJuXsI8ndW+njdAJ5vhsUUUHQNWtG3Mo0zmuxvkeE5CTy0
r8DGHlipYQ3D6SpZvzXUUrzE90qEX4YXyFsVy4CFVLiDzi37MFm689s3Y7OpBl+4LdmePglyyEeU
EOXw3sNuFhSWDoXbL0q7nIPbnNfi5qu7aU3zUgWLzuzBrO8AIUsLqmSlApsOfjN3ubOuqwpNhpu3
cvt8wFD6SncpebXhbt0WMXY+DuqUullSVK/O/AsdLpF/7Anft6QGvMyfbI0oDwqsmidCzbGmSSlH
uk0vjkoHvtLDH//fUrX6hLP+0j8VorVtxsJ+f2do87+VpGk6zrBDkp8qIYI+OOC1DeJ2GCEIQD0Y
6/Y4e3F1QxEuuPyq8MSqMysASRo5TRPwLOlvHu7VDAJb+t90jV2nKLGxJY+p3tTZf6HuehQGR4rB
OiZU4qtc7IsCWr3nk5lOq1PqI4NBVZNmutm1oyan+nJt4VEU0ZOt9wf/Oh2wvZdNwRPEaPDnuLDT
BG/+U61vwImzbrcFAFGUs/zIm5w77X8S2lvlIkFsjO3Fr9J7IpijSCe+UN1CidAvKBVDUqICVB0s
cNB+KkOu0JNOtBQHGBATWq7pm5p0jveNGbOuhN0NHvZHH2GaSafMAuiu6NfzQclnlajZWVkJscEl
Qc7Jmsomtyqn4UMX0i97hOPb73Ib8d374Ti9I5rwUerA6uQ3QEC3yhw0eHXuxgUye0CkcqjJtOOq
W1sKsNhUZN482dbG/WQtJKxPwZ3SqAjVI7vrocYcsUtvAAxov6RSqkQAmWMKSUfs4eopNplaM1A5
91B4gVP0jE+lks7mR6vHtdbPStYX1HxrYnL4IDsyBKQiUbYFXXxWrlCxttPKQ8VPIuKM54XC9Asu
/ElZoN3Dlc6o5d75yekK9QeZWs3TdRZFzj4zhyeNzPqZPFURht/ObgOjsOSacBnDwbpvjBNIgJwF
p4XNq79FQ71t5cIVsyTcqzvkL38b9nDQB3Z/nSAZt9YMphP5DNW+SfdTilpaKgj34s42s0v3Ia63
BOcDmL2ne62kNfBCtOm7bDP4ZtrhnCwBZILXz4ecItswVa1/GhupadbL0VpXa4qRkMmruxopcvvw
6bYmOCOZkRfwKD2DzwOdlCG8E+yX7iRqHzyJMF+qowXT/JR9K5wqJVaqHkuPLbMiVJ9K5f9Xnn+P
ZNN75oJ66AkBeaaltOqxbsFTx27s8lz7mEwwus3ovvUicOcUbikmSve7wdCIdrMesDTFXnvzB1mB
tPY/HrGQ7R9q3aR2dXEXbDf7jyPTXR+A80sHP8NEevIVgBMHWoT7s4BxwGu1R/7uXFe2mkeUt0wv
/gT+mm5VHpGJm8au61wm2MyYaD5h9XjHoVKFAS9cMnutX7/bTU/dPiZF0Mmzv2TqOiLYAJPLNDcC
V3tYqBYzeEwkmiQ+32syzqizV76tssxST9vhaoXL7Kq10U0+Sq/6OGHQpCjAxjbYND/vPC2Ac0rH
1d/ecTrTmf4hLZe+IGAYUR/FneBV/ECpiHBS+YJSq2FASIJoi3f1xpdvBTyACSDiRA3Q2Y4Le66A
7dlR5nQc7VitT3WbbXfbOWVcmM+LmryaQk9+3LBHdNFo/ASocbsr6symLCUbRLFlJl3x9KlY3QgC
O/HaVxxkq4fs4svT64EbXG377H1wdcztEiz1+V8Ms2nX+Njl0h4YCosnUP6260ROgoyI8skjnXYS
XPq4Mc2MJXK7mHB0AXo8UdW6vZSUQScnJ7WW9eIknht4WFsy9NlOKthFNOzi2ZFpqL7N5/dBLewt
Z4J0VVxwksZo2ryfA+7kycdsvuSjyDXJEOCcqXqDN7fLm365FansUBQ8mEW59jI/fZ1NY6aTWpUO
cwp6G22JcniYFrO52U3LgZYiIQ13DFU6ZcDbd5SeISwUGeUanXF0veoa+KlPziTyW4PYFfjciwYD
und1T1TTrc3OOp5vDUoMIesooz4rUDetjxV8P4vXVhMAEjX3H7P1/TU7yOp+L8ZFJ6Xa1/ppTjRI
mACJw5Lxh1G5eAx0rCzxbYDMdqxGYxyZyABEqp4oLeNrCy6EwrgAL47IDD4NAeWnHZYaJkNPPNqF
akdZ2mU9W0StHjbckIFhws3Y3f/KVkI/zrSULO4Rc6t6eQjA+SUmdaNkPukGHR5DApCQieXHb03b
TzI6pX1BDXz+68em0V+EaTgb3ur6UY8L1J1FTJfEFSE6GWOqWLPRKe3mL+pVv5g5P+SgRuLCw8hf
tFYfoFcH9KX9EA2CLJJybpJxvfdOywlsaRqnWDc2BB0R1Wd5wyt0FYEyXxvDbuADpWHTc/wM96Jf
Qu3wOld2VflxBwTSCzfiqvbAPAuaUwb3Dpa48d06u0gU4/uqrRHK62vPg2eI8j9k47WFRsEs0JdT
20YthlrMDAxM5T+/FzslW0DbOVPrbhUIN1g13HI8MO+jVLAPbP0riEhyZxLdOl1i3Q2Bf4HEdZ21
DiqSUJC2dyDjY1vvJn/pYaqTjweBIkK+cD9IwHtIQa+qpE3X79ao7h8OK33l5T7uoGrbywv1ZFti
KmwiB/zgUOabWSGPcacmEJhpBiEbKHX5EtXl4aBnLA1Ex+0QspqbjT/DFlWoWz9C8ETt8BnW/wTw
3fQQx3OtMUDxcDaQ9Xj03JkVLcWgMPll7mSX1r5XrujQyV3AM6QhDZ1DwdPU3iN+HwBTcbvWKPG6
AMjn+kxqgJGqrqLXdIkhUhLgiA8e3Y1ZPjDQZusc+kYNe222i/hEEZIRlCPdCvPKRu/h19yZDRFy
cucQogTT1UPFa62QkGjQE1c5m9E50O3V0ZLTBjPHL2xNUKKKYO0+GruNpoM7cKXTGCT+fgU4DPSz
/AicYO2Y+ZdlN2XJC8lsBV2Fij83eoyUKKgY9bCZaSyVNUGtBiRTzp/vXsY/XvOSbn0cyUoWZoj6
lUpFdryZEtXteg2EEZQeuRBDweG4ud87XiPe2Gk2NmAzR6sbVgyHQ3+11jGI3No3yuZ+4f05LMD7
L1ZE7GG+4tJPI+X7+OaaaVTLjL+4f1r9at2V9x6xEKCcMDtk6MS4gwFAz0H2D3rw7ZXeI58W2p90
29B/LO6R2PJoSvBD+WJ2iHAY2JZQRpM6OTZrOx+NzN1mKuerEQS7A4H9asWn9WlPxQYK7eWtPt/E
iO3PdRixKOD2BWX47OYumkGg68R/HIBLTL1ufDBLUJDde59cvkMOiU4L8kyeZUzicckidYd4TRvJ
5Wny/hHmu8Updxy1+8wMyb8INso4oB2ae2qn2Vm8n8mmANC7alTCtm1CIRpwhpOrKXaCqDrtpgzQ
q4FYaWa3f8BjctHhbsOt3Xh+A1H9IJUqEY1JAT6R0gFLmnmEmmQR/qFsD1t5ElE/uTMOQ4OPqaBw
G4S6a+dsA5z49Twf3ub86HARDDa8RW5zxG5Y2bMWyAnaInGVqP7JE6b4LwJyFvVeH1rvl66Y+E9v
qQPYJqupQEnN0Lqod5sNFseSsYBvu6Jq85pNl6Cvie8viNw0YbYS9m3q8gX9u9h+pzqVaK0F9paS
e+/hxb8S2TPVaaR56Q7gcTETPYwtmkbbMveMAQZUY/L17ZSnZ4qIlzgcek+PypdC6uYwvv12aluA
ddX3YM16rHJGGlG08iA4+aFLaXJVFwC33OP3rAAOBXKOfy3KYIaNXsesP048f6YLE2o6EglYBJCE
ysKwbPAGjVCHlIzsyU4Ux3UP10hcQLx3Uh2ABo/oAxk/zuOY0Fp1PNX5wy20CgIBS7t7wSDkm/Gm
0R0MGgWsaSarA3OAcqmNibAlVFxhqDyNb7ttke5cBx/edEK87HFhldBKLVL4DwGQA+QLRa59qdZ9
YNlRrRw/sglNgT95JJgForjTPcJqi9e1LlbrqRtsKdMUB1EcW0r7eCnSVpbq831XPDJV/9mB1eLi
r6euGYNkuGvtgxhN4bsifH6+fNfFXpfgi+Iz9ojpECy2wS6mCjKAWcqkNi0ZMaYeyC+Z5xvfLehL
Gr/0Imgst0OuaNqKt/hWMu1+V0z0WLTX/3TjH++f3xpVT35zPm0apr4ry78SieenyNDW8Kh1QWVJ
adnDyzQYFGaF/Y6unA8Sx3axwJzfGEQUoGqAQze6weGiejvcAKOciak9nxpqw29NC2rWlnrx4WUu
OwHeJtyA0m3jI8hwTCHeahTKxh04