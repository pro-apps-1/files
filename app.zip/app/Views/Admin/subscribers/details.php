<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvz8Nd8z+A95EARBKNZWZ5lkveBT4NsDxfYu7z5F8bkLJsW4rTXXx6bAHBG3YcYx+E5SzUKK
K8ZVUUuqT4Jf/xm5vM/JQyNoeuxV2h5xyCe1+jC9UqXkRu+x03ffdjETOExhUeummzhoGcdvey/W
qbrnebSa93X5uj8wLTqFWTZtKljtpkpQ3wwTm7zyr9agMPljegf4U58cn5t+REtEk7v6BvVAtQ43
OF7rYMpV1zTMR2yQ7z4koB4DYQQBGcc8AXrdXQMm8g4wBvT9zN6ty5LBgYLnIcq7XTAAUNNZCLnC
HNbA+6LMuJChYxXp/4Xb9cohv55dBDwPXAhvVebOVEzdCY9u1DYMY8ISL02J/DbUbg6WYUDM0K2r
iFwH7UwawPezjstJGji4+5yrBd1lz8gI+/y2yMRdZjCnfKHAMPbroqd0KOGoTF+5qCoHfvMV0LD7
Orcb2P7dYPDkHjqZjyLH6AMq6/7BtMf+jeLjSHEx2aOcqkDZwKrzA1eBZVQ/3H/V/fkM+NFe67/i
Lv0ZSU+1cCbTIrxtaOiv2xWWvHnQqDogNYqJcyIxuJMYZ72UqTLst8LBR7PmLFfNUeUbcFbAbBH/
4uLzc8b6N6vUetyCx6YwbDBXSlHLPW0jYcet1WyzrTDSnbUyGyvQMC8pB0bsM4oWgLP/yYkRkWmw
uapnKeUgSLWtFUmf+kSjbBuBnhgj+Ekvdrq8kWhiMdMjaCzg95u9r/iBUO9H0T5+KOPo4E4KgUIv
aO8739EbFI+qyYL3QvZwmgT0uGtpzhHXLc6KM6v5PGgIWDxh7gygL+T3RMqDIwWnU9u0e2POkoqH
83cwBK1ZZuLxTq+/ka6KdIIxkGjubPXVXfx3PZwZtqAp+kzbJLvtOMNcj80jai13XYKJcpINMLT2
LgNQfqcGbxosDgpp/YMCrknrhASXaFPpbocpyQgvT8PXOx2JEieJuo4x1eYLAQu77AkPOyBu4sam
cX+/6iORiU3C2bvHWDLJP6FmpJ/a/t1sZ2XJwkj12yCmItfSTIg7YOHP30yWrV8eGT0vO0vLLdf2
Em5aTkCcFrbnlcPqL1W5QgwKxY1g2b2UpwXQdqLW7eeWyFrvkq7Nxwvadhc+ekZYYW8we0BTJrtD
Arc8M9iI9hAR4gxCZx4OEFKt5nU8l6Kjq3LR5oCZ24iFr0+TG0RuQv8aoxlFejNB37WCfTPZTGUe
As+zf0wJoCN201JXN4K/Ao/itE2I4wKlSp2I/kkFrpYi4pcUu6pFSrtn05EZkHQYoqBQvhZN1gMZ
bUClixPDjzzJLdYGOZUQelw3D7zkOX9/qgbmv4ehKNHtwl3o+czdxuvKbb/csHP9Z/J6xfUzSCXW
MNJ2trvyTcrKeo0JkvDgfUMFsQRVNCOToDSsgY2Z2LYsXkynqHn2pC1AYfVZNgH0ggoo8LoYqD3O
EYpS5Yw0eU87oBQB7mlHedb/O7WJDdTFM6XCc2uZLWxm+RRx87WM1Ss+uVfgx+cLzl1qzse5hckX
3hIfP64Mcv8OTMe3VC2RsTG9qtsw5vIG6MY2OdkMzq1NPJFQ+HZU3doVB7BPOPYrmIyJ+8kEFsSR
u1Yrc9H5B27Cei7m8JcX3/7AI97qdDnJ6HMx9Jrrm46/YQtB29MRYQGpt0gUx0IZ4iwiqaTjaX7g
fIM3sSWztbV306C0rPdgp69NIwnrXEBa3O/dRgRNEjZIMS9jpgKwFnVUlGRX7tGCRjfcUWqxxr4p
R0qBMfXu2Q5fNvNvEjad8k8333Qlh0orTQepHWF4EFviOFWmyJqBYGq87CFgTQ5wWcOS0W3pd1SM
f5RCuOxKErmWuG51EwPLayBW91I0BnnyXcU7EFab74IUvnyhZs+RRvaSpdwslTLO8eYf/fHqJOwf
5duULwmVFrVs8UJeFSLQB7ENu08iOOTIs5gPCMgYsEDxsbeXCNyuQ4mQLJZneNpIbPHq0uoGz28A
qgmfBj5gr3jt53THLb0D6c7TznuP4CNbzQwMGpk2NBVI78aPQojuiuGnwOLE2KfuJaJ1L/yutY+H
aMoxR1fti9mi7tZJbZZb586LS+aGcqE2VpXAlQYoYUMxhod52tmEYoGSiMco6SdKMQ50CFQEDBWc
E5la7FxFRDcFaG7WlUzzLgH2nYxaN0qCeqZgSxHYzWirn3a6reZM737mdNfusbK5HNlrPRMAkDPJ
YJrpUsR736cC6mlTfimlTrRxJ8lkHHk+i22k2flqdUNKa5tmSBO9J4x/dg8uWg2LTv/oMoXI2OSl
MvMg9GlaYfqdm6AEN/gJCdpZnZRHof8Q+677zNAug4jAy2nzJq8GjWOQGb01I2lTh6wdxRaqhR/u
tGavCW8EkND6rsPil+shoW/iMtad045+/yY0VDzkDG46loEpGmzO4+lEoKi4vd0LVvgpwVbSq9SA
3i35HVuIoONHCJVg8TIud8b4kdIGJ7NUkdoAdI2FVDIJDlwmWPMJp54eFpz06dUZTJUOym0lO3WH
MW6M/1bD1y8LH0mW/zIuFSI9OW+8vxvWi3XejWg2X/yeKNdC69Wr/rakOyNm01nXqmFcMovctqP1
8gPzObArbwcOEOIBu/A0BVY5q218mOTrMw2yh8d1fgH/MjY85zamVjRp032pPZYdS463mDS6TnIw
XL3wXZy+0chXatov0g8ZfHBxgFSmkV61Xs2HGEtvcQRDUpfHSAn4XPI2qiiFIEpBkKd5t7V/2hQO
/gmGs2ydPOTQ4QZwZOZySaty4EHR1+B7Pxzjnw8Xk2fOIzEwliPREDgDZ6SMQpNPC4pwMd3dThFL
CnHaUJOSm3LXlGY1wzlHWXYC+eVDqDif6KzHKmaxT85pMuJQxWGCBHApl8NNuu4Eor1CQVEYGHBs
eqbtS9yb2kMbFPWk9/aHi5NAyWh/lveCYIh8IkZvQ2zh8AhC6bn9vinhmaNKY9a6/9yrDHsPLUFV
FjiqQ9qsGyELXVBl8coiwI8cXKB3faGEcpWNHqBoxdZ2B/qNOc28PuxY/Px5i3XmVMYKb26Gl8bJ
cT/uMydOxqLxFS49NFe/nKPFXlRLjiEzFPHK9KtJs5d/QAOkne+Mzoktn3x9IDiHp+aNUV86n/1a
nh5xrlgaV54c6y9hDFI0sOvr9pl/rrqfzRtSA8FOZLPQbnd53d6VyZMx21rsEYdNbR5gnpErTVI7
IqReuQsBHY+lT59KRC76NsEhNJSlFqnhE3kvup+LRzB+WlhZSi3SmXklwbrBr5g9n3+5kwS+QGJs
py5kdL46QjTIl/goQ1XVyjO1M0/AR+cCUUJvVjluLSOVVv9YJl1eNLKkCDnQ8XFK9hPDzE9lGWqd
M3/btUymELQXadvkLFemIjAi3odvAG7DZkv9P/OlZQycCDm1Vw8OYgJRrbd9/RvlSYlT1Um8cLDE
V/rRLGUjiMtkMDvNxShgd1ZC0YgCRTZdzbIsotRZ/umDiubt8kELeyDeHL4uLrRY9LPgytHJs1Zc
Dg6BIvgLguqsJ0z0940Hubl+9Kw0DnL2tZYDIyVxYPJOETb+Tf0igsqqKsaBbE9XBOKv1QB912KD
jskhMLcs9Rn2nLSTJzgEqILD7cMehg20AfvHk8+N5zVWSqdrbF2KMqwHatxlB1zimTPbilgCjGk9
YxV3uMXVXK4i4TxUO7fyuSni2HyWsndb9xge52pA56FqfmVg0uQ544qncEEBqVrVZJiXgYUuIfGh
ofQz4vg1P4el+CL5aaTgZ2xeyF/q0YVqUQvklvc7Pue7sqk7t9nXFoszK4Fapm3DTW4Wi9uZzdAQ
vvFWsWrI8zUPAqIJMzJz7QDm64F37CONpsB9meV1GkFboRfZJajuQ25eXd1EvT6srucxsoJnoT2X
u/5ymcHovfieCVK4s2wHsJ8LQOVy/piM5UIr6TPeiGLmURgqJOqbJUNFkbt0eR2f9N0HcSn3YW3a
YsyrTmEUYjl2R8kX3nfeT8h3MBKmtzbZOEarSL1jAKm5uVKtlRkPTpKFxcrP3AiMyEuH4eXPu9Ef
MhMNw+GvCRjSJ5HNwEVq4yCEZoqdighNhYfqLSQ+/6BZ5PDnOuwqBBSwu0SM1mJbNOWbgbejsE9/
qJzEV4TeVh7S64hRYuPSUfxXeTmB6bFC/q8hng/8kMwFwIbX69Grz6SMwpVykyJw8IeOSAXb8l/U
LgsugKxS3DPk2BJfPg7L91+NmifpsFWSK7clKPX1L1M7EKEuEkahwK4WXIQlN1CCB+2xijIK3GUU
0Piz6kcJCYg52CFvNvvyFvvQ5G3IBolqMruZNF5fOFbhe5eo7pteIIiRrVMDj5vC0okBKMfCiLOw
DnZ5RUk8QgA1nYoNLP8IHPfA3tMKMnzwQjhTXbfJ+xbQEIe2ywpFzk5E+oQYAC8NPC/fop2txgTf
4XWFa7CNeOdwGyK7J7qfzlB5v8Yg4mhBIDPO5NMp3DmQamJdHHeFV7WJSfyO/vL+O1ir+hZC51iH
NEV7cZbo021ifQTRzxv/zwbZqTNoHcXwM8HKjbcuS9uCiEic46et+B3Hb3OQ57R4lm6vsswqxAF/
+1PWtGXGpjeDlwhfKSowaxyT6ZcHP1v319qLjcgTsUca8TgK8wpz+xbZVcp4MeQDkLNw2uCPuU95
v+FiI8JyxIr/rVS8LojDIuaDH2aVPvnpC2QlS75n1y020ssw62qqMCPJATnqxBb7ruNmfPiGgt6U
qP8viP3gbpFwSWf4rCZo8pUpGUP86SbKcV7D/0+MiqyDMQANxS9LSaPSRwhOhQoIdWfWGcAYCTqH
y8uL4jHHeEH9ZlxJH9bkaa//tBDcH0FHzPDZ61SRddy+HmzcLUD4TBqHAKY5VU/6PUG5d/f16Zgx
H7x9QScQIaiHD6VjCCb2XKdFmBgvy9o7hzNR9HtSTicQcsVYROsURZFzMYsg2dFXmPIq2COrIHuk
iHukRlH75dga2D+btO6UrSJdOqQNfxYiW0kqrNiRxUeXyeZ+RRTqeVDIFvua5cKiS/5KN18qIGsW
86YcJ2fd/wL52fryvymo2biEA2FrkSGL9QUVsgPbBFO25cDNrz/2vsHcNoRXL2URRbVSQihX1Al9
cY5hWOzrTACxwjdiYspdp/ix6abnPe/t7g0euaiCEo6huDMUQc1KYhm6OKAXH8j03vH4vdVkIjft
9NITqAaOCSiOg+RttVLFmANAs5d/cGF7B/XJ1WfeutEEavBOnuJIl0Wau0ilAPdvKvRvpVzDkoVs
IL6e80VrmCescnFBTC8We9y7sMa9R9gTbKudqw6wn6dIAAMcQjP5e9SAuALxdL0pN96rUR7ABBSQ
Ok+AwnSx4qspJeOTlBXkXAaBS/zYi7MQk2rJZWsRpRSRgDgxN8uiYvZL6vW77BzLMoowRNzZSTvM
8X+ggpDM8H3so2Qbg9HHUFNwYHtP44O7bAgJrt9eUPF1McwhgPH8YWcprroYomIqabPrNE6KwnRA
YIv4hjPXWY1uxUDkRI3Xr/tJTxPH/nPAay1EbLYQEIWrcccvMqVSlWtHgdTfpyiN15a5+zQPtJrm
EGPAmGSZJ7nuOEi+BgLZKnXw70frOvNT0CQlM0YuoFrWTKlInL3vWBMdZ4CMrOEgkTCAlRO0oAvU
tT6aDsJwmkXe/BMyauNmPZxpfhph6tT1WHtZgNPgVpX0Rk2OH9WEfzx6Wc/A3NxgP8OFSLrFIwjA
NFT/kGytW3Lxi+BURnfToJIY57x7A7LTw/o49Xtbc/7UmiHO7NUesGy3KbokGKB6HxreSBxvgAIo
5G3NjSVWS6wRhbK2z9riJ6xj0UI2zmwNYu1nkLhlJzNDmhmgfk0WO6V39cWLcuH3n7FLXphkCvZT
NNX3R3Mz6owXP4mFD5bE5ILqmCn2OqFHaUxzMS0WaIaYsTn143u+RTzM4HcXD3GFpBz1lJBtJNPB
IssdXySGTAp6x/Kon54wy1ATUzeKQDRvNm6Z/hPNtWsoI70PuJG5OBX8/DgST7TZ2EVbAmF6UnuN
8KV7JjKoUztEyiIS9lGgiL17WrmArj7k+Rz1SO2EJJubKXzQUDlxrpxAG0iT3TNJYnrjcNQ9as5p
d/j9cfXoZTIvCOlqX44F4vxC0ths61MXEsLxyWsujAVCEhIIasqoAIcyX6OAHx8+q8y/qgu3AGjg
/kCBHH+RtCPY80dJJr5LAB3sakKfrIuQCX+08yFVp5AkLjyVCKQUOEyszjrP3HKl3gvfyywSiKGu
aZyStp0ni8g+Z2LdgQ27V2nnzo7PFvDqj6WvKgkL6dACi07T7jBTlVseMhY+6uVMrMso/vN3oY3Y
fg+tuCWHq4V23hNYrFkNnMxQ/trbYfsLkwOWN4XBib2ExRdkWbDSaRTUG0irVW9/nolzAzA/6p2n
lapGy8v6QyPU8wl/Xf6AoMHlApSf70Re6tQNT87dwxHqKlUMLAPHAlZYaWEzyfsE5jmY7nkJ8sAE
+dFvGkrNvkL9asUCBHFkLfsGCG5b+gjfpDccZ1Ge5Cw0A7H8NBBRMmxiyraSrt+k602WaQUSXM4G
ZPXzW8OI60kLhqNDzrHQh2Su9lUxgulKrYp04s5nphpRlbBODMONO5HxXIrJ06UG52+xvAN+OrlN
SCZOlzI1tVwn2LjlUfwb75ltl6ULBI9taYfd6Xl0upZGhETLmrz5ISAeu00X++WVYrZdlhg4xCGj
FaNHoBMASRMXHcX8P2OWtI/f7Qwgw/fW2Oa3xv2d2d6HY6gOmGjR+BHyQRSMh8Kh8nZQlCnt0FoD
ItAznpiaTvGewLNIOXBLQrVb5sqB7q4fiIepeUhA5ZsXiX3r0BaKU4LdH0hyuHCP3HjfJj5xqfmI
RFkpgjFSUJx7LQzA5bofWp9uims8ZgKC0VY5drKDcMev5Z0IcjBRz01U/b9oFzD216icKGQnbj7b
P8nbroDV/i3Oeaov9vDFXogKOcy7IPFVNBAB3Fw/x/7tYiLWEmTb64aIzgzKNyKWgTlM3FfcKJty
mcuGZPNfWHwYRK59x79gI/bD/jSBwmyxKr/WCYyL76piZRsixvDsOW55WeLEYCPfINJZZXpQYEA9
4O1W+fnxm70iipxfayangBFN+JNlLqi4dc+55Hs6PkvNLu8ki1DZyFNYr2FevgB5RSkqwUAoKk3X
x/zEP25QWfmdyJAESfi7UJjotQSouxJ9Uns9yxONKmPgZMW2QeXlnygWDJDnqmMweiAZ+XC2ZJW7
hcLqnO82uBkMlgeWdbyEHr8oVLWSp33gRi3L1Dv9nwPPWgPM8p6fZOoT9i5JNCHzTzlt1mNsXUca
A6xDfw9RE6KfGuQJJoQUV5V/dUgcgKDvypE32WaTrSTt8VuwCGoDp5RWKzqnPLK/Agl5HxPc/y0Z
87DfrG7iXXum1Hi8utcaI8FK2nND5HcqwKPKeWnpFQ+JmCmLMGJCs+xelOjWvIDsmN8hLiUP+ND7
W8CuOADFa72okbPtX8MSCO6WPIspVZwiWT50cbZavkis9+/TEZ99ARR9TY0z+ODXDioFbqEQhcJ9
3mZVNs7iFGDb3ylKT7xKAChEuaFqHcOxSmcCAsHszoDSYzds/aJVHp2gIHR/BfgYl20gS3VsvpeN
IZ5hLn8qedNxEvQwDb3vAZBWYn3vWGbZriEsQwD2DAS0b0ca/kJhGzx39lO040KbDwOPKDEPSZPL
ix56RqEfeVb9lZPmLGIhvb0SqUNdXwrsHTyURFQ8ku8F6VztmitlGapt9JqwqpQ/u4wJgTn8tPmK
OjtJVVGP2TnY3+n+sUmwW9+QQhmadLTrVuvq+SozHO6Vzd/DesNNFH063/F9Um3jlKNlLiH38D6p
0M+FTK4rpxJb+bLXjCrZ7xT0Jrz3yfEc4Ah/lYvtbx2XTXLgDmMvFgPd/CjfBfLJnMiBPPIQvyX1
0C9YxZEPQOi3bf4fBJCdNGq+4kaFtIGYCUuVVz71dRW9sQRkHkgqW2kRVUHfjaVlAzFYKdcHabyP
wSre/HeZah9WUKtIEMu2CoWgtWBX/kz67Pi0sLPW1MRl6uRU9O+bmugYEu1680zh5fyLEs0EDZrp
6IGr/rcwop5712wUU3E6vptvdW8PsMBTyFqSLuO6CX3DqwstEgCikcuuiNs0rZk57St/n0vGlgd4
jBMTsR9iexeeYjL1LX1sQwPN0YA+u0Msxzq7vDsMPaXmMo523jSYh8x4w1BXigoJTXgjX+ODrJX2
ci5clYpKgEY/kG0kxPpCMHmgXPRrdvA9U2uNgJwSvkAw89/zJyJV+LL1i037uid5i0b7f1KWGi2g
qcqj6XCjAvbFMBmoGJjJnMradLtKegmASqQ7cBmcTJHQRFO0TRLLnupgikl8tb0rZ6Ot2b5Y60Ay
1l+rwhV5L38lABjaC6LVUn7yUU6UmV4bv3k03spJnuf2Uqpt9N/jWS0H2QDgrrCjaSAVYV0zSdx3
iq/MgmKZgRVpbX+hUhLnuzITarUPEEJOJLjL/qlTB92bkoaN+PtieGRuc7VLgElcdfa=