<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPokwiEsZIGd2kbKbpYqEnydNB1SAus2bmDvMaFj8sWwkLubNMwB/qvJ4R9A24KGZ1Ur6yVmE
RWR1i9988y6rOrsoKxchqDuYYjrGiN0eH7fouOhawNL6CDDoYl4jZAboDe5qCvonr+3d6SdnlByC
0vQSOTDDPDZ2kT+7mjIGLF5xdbkdFM9l84nd09mZRiPsiBP65dY/j9415hOgAFaToiG49THxe1u9
DtUxFXl3BlLrGmG7xiE9Qe/Et685xNWQbhaUmddcw3OBYl06iL2goSIbkbaSQw7QGHemROZVyLYS
A/jwQF+gIqUaRsbUcJO+XJtblU7+br2MRq/NjYvn7T5AEI+fbP6EdRwFhPV8wALW+NY7sM0u30VE
Ni7jMLVBJ5MezUUIFnBmFwGHmO5JgXBO8PMcL1IekHH27ZzSR0nAJ/ysQTs5YxLT/FMfh1Aabz/Q
NH9dotViwY09eynHU/6rDOyL217+kqwCxUQsGDmvLckDuZhAEEtjXFCiSL9vLc/1Hm3Rvpxp5hUg
MZHnmsgjbnqYnj7YuwJfzOmguMdBSgG9ojm98sLMcCCOXj8wwei5qD/ZB8v50JJmtkyBY1fLoXoc
Py+zGHisr8VKV4pVsF1b7rDeVQxx+0saxrbeFHpdss95/uv7V8nJS2IDlxfD/ekjzLPukValfwlH
ShZUnSCODlmEJSwOu+MWZDJoNUS0LfEKldachMA6GPubOdC+16wBDO6iD8VjhxFTMj4zys4V6ZWK
U7MTP9CMzs0J7KglraTBWf9ZHEEO28JKCFWpDtO8XWMsLASrOLqEXbtzsjGFSZCCMEsCP0KLwbP6
t/FpnAggPeOwdfepvHxdxP9YwrWjH63ym+uJzp5FsXs1qncsXjRkJlt5EKq79PD5R0AGaKhtIcMt
SWC2+mn1LQnqYrJUszAnEhvsKCXMWlJf3Ujy4q4jEXxEG+IgRxaotnKKgDrDVrkfx/kmQGKTOi7d
ml/9qNkmgRnFP6uIUNWTH4u8ZF8ktgYX4gVXBksbIQcghRvdUzybh6sPR97rj8GEB1cW++80HBFu
UVs+fl/h9kJdFm9go6+GjPVitSinIvwFySnG2PPtfjoYJUNoJbqxOzdM9eJPILsYOo/2scHmIkIm
9LmERdW449n78J9cN+1orVIrRBRioOhIcFGVrpu0y3iDzrmjrhv4D39Vl5Nms8z4Eu4MSy7efXRA
I4z1WbSpqyMrmzMRHHbE2SkEI3YohjUbpm4I7Bep45MgeNFSoUB0puVug3J4DmeHUi05Wx9maDP6
XxvVhWTyhbaJuYosTjVi0kUo867zeI/gB2QoRK/DOM6gzbmEH4Fz8b/ij7yEeKP8XskrjEMvpNqS
rou5mcaI+lMHeFBp0aNQVovnJyKCjdqsr+BEZcmGKu8n/DikZW+ioQJc+U3svAJRX90Y5WlHUTvU
84BefSPp90cjXVV1605II3w2UWjv9TQInfS6mkgR/x+m9DttZB59B6vfHDkGoizPjj7aHkKz2JMy
X8nVmU1IGQROe8HiGblVw6+55FET1an/m2qvXsH9wrQFJoRjq6PhnI+4KpDlHq6tnG+CUiKHyexx
LZQuqEbTypBQJm1ZweM24ZlkYvwgAKM4XO9v08jlN2gtnvo+O9BdpTKWACA5tocf9vyxWV6sOJJV
z49MrM/pjG7PvlLYHuwHvNTwExzoKdjLfQStggkccq+EqmYP7UCSNiAr+OGZIXiIZU9xWBhDVCkQ
pYV6vU5bnIgorICRG+xps8aYYlp/ca8VI+7tEKaPBa/3HGPWI/3c90hEUz53V0h7bXwBmQ5RQVhM
lJSwp1+wV7w1aYDfTs8jL1C2p/MUwTU9nd36U8pLgwK0FUhXxs83Kf37hf+y92gAZ6vb6tlvcJ+k
ISuNe+NwIvmKNDsKm3z9yqIo0Rtpd3EgjWkm+0iI0uc4CK5CKjekD6crzmCsc/uHDrLaC/agsRzk
GbRQWcysgAkbECXGiwqLuGlmUohIxrpPNXqYKLAaEEF+UNGTkuGbdUde963sHuDayTBo1WtctHTw
kr1rVQZrmhmHXT8ETFRj1afsJn5lsIjWq60ZvN7n31wU+NzaYyTryX82LkCSIN80OyGXR4cc3ldd
z/CINWMyS7Qy7YfKfn4djX2KxaUBsWXgE5UKZgd7X/3B9Jd3CjNNBVvVwKfXkeix+khyTa2fUDwR
J4c/4JjOUVENiZk4+TKtykyTl1Z/4hrmp23fxDKKOc42AMEzbPvh2zsg4lyWIyc0wr9m3GGkSNok
Zjn+PDPuzEJOysJq7a/5GjgBb9CpC+ik0MsMxnrncwAFI8BBeIiwh7H3cmF/t2AXI/sFcQUVP2n8
4xqIPBP8hW2rgyqTUvvQQXHKLXM7mb7hrMOo+z1mRC09BOxMqJuD0goJEZqUop14BbonpYzqVrH3
NarhsrqkiielBo17XSJ552fL3QpcQrJQnSDwg0j6w6VD1G28rQHnYBPSA2+uAKmsGHxC/h6G7CXj
yWr+u6LbV6N9E48pNfJIM6cCv73gK+0hxnUvdgwIgcY3e1+DJEMqlRohNuJ3F+E961mEWw/qG7SY
khJvfMuaAmM4uHto4P+p53IJMqkZeTFvxww3pxK24rltpx9BsBNA+O/EGRGqORmt6U6Md7ACCmi2
GFMBn7Wxn2TWq8M1m1OY7gBLK8GwU2AabsAuHv0glE9tG2iZyVB2P+iRvEO8SoSmN+jHBw9dyVoq
01S0RxZVEF1W/mdk22YKdMaOBQq8Jue6g+PyQy9v4TwsPkifK1oidBr58cuTJskezg5oWz1Wqi20
TgMHlAXMSkl/SBJYabkWss0W0fibRSBgGqoI3+duM1WdMjVyM5Lc4CFC59RGLrtV2Hsyrx1bAOv9
lBCOVJFIBF5wNfmmFmdGV3ewiT5C68YMxICzcEnBlWsenmv1dzAe4Ww4RWGs87or27RjOrpmIMKa
jW4Gd4DvJ8TJRL7/AV3CYOO15UR+r0YPUth0lkjdrcp9l8MifSKfYybjCujTGDbiZZqOC6U3zSgv
Z/1sT25bvfuT8M4CDo+zTnW20ubT4D/V/Wll8iYtIaBfQhZHDobTGfQKaPSO4xjvH4WI2lgS+F1W
XxDg61CngWJwd2PLzbZdk0GBsAYiYP8Gej//6pvZLpuK5QngNn5z1G9dkyINaymlrAeuzBh5dQIm
p8EK2x8qVWwkQau3BbeZhEgGYM8cNRHCEqb4yfOlFO1xkFazAy6m08qAYqfiJq9lvVX3+yNeyg0l
i6cO01XTDhsjd2p98PK5EJg0ZBIS6ACKpvJP1V/059KaseC6Hq/eH5GSlc9v5kOqorT3o+xlIvch
8uPnJXVQkOp2rVAp+ybyEM7AZVdVseXDipfTcOuwSokdNgSBRYNynt7PHzG/tBk+eg9itI/U9ff9
jSIvnwhvYELRu/K4o2bmh1ABPV/VnGGv26zjTspNOHE3iAMnP0/6jOUCz0fvEqVhmHBUsxY7+UDU
mEknmvcyk8JPYtd3QWhcKqDjOnFcmHq6eV6nn5DmR0oD/ZbNsYYLStJU6ON7yFeO4oQDLjtGMTWz
UJ8kWuokDME+DxaXhq9RRy27beC33X1k1MA4KR7k2Q7S78z5JnlR0cSsiC14bTMWPnJdPXWSWeyF
Kagbgqgkum4xEoGzrPxB9kbT5nMx2Zs2uDAYUoN+OgMN9ZTZolHQCH/dSgHkdxq2kI2Vu+oeeMmN
gaPTY8ze+1TaVbeSHuEVXbk1EGhdZDBCIb+H1x8hbhnoqnhtwhvsUPgNHhFXP6X4/yuTBkIe9coa
U5fXazzPrS0Luzi2dULYVEQy6bgdL3gx9grzrSY1uLPbOUn4eOHJ2SG8RFq8HbPzYM5pBwFMu4Dz
4uJ/YbfaPO11kH3kQ0ZA5WIwVcBkNvQLcK/V4J7rlzIOVA2klPszXKoKeAvGQhXmrcdC2CeeKR2Q
SOt29x38Ce52iIzj/SFxZfGPTZuVKjshKLWGYm9WmgjNG5BcJTABB7Pla1X/CGgiFOtGwfgrP/jX
p2JgdKoL3WRMBBvkcYOtGikHxswq7azb58f9JFp/IzN8S8u0NidOvQ7ICplgUD3gExkYU7K67xF4
JwlkFHgygldvYZ40p+1fLkhHK7uMRo5MhmwTtdgR6ED1AQGsEhmWt52OOvvmBqcicccYmKX/H5T3
o5oGZaBHeuHvGvXiX37CqQNkekCkEdF8n+iXBOrCUHZ/og4kDdl5GDoWLQggxpX5FLTfKXHdrj/w
p5nQtE88Z/0Rda4z1RpHLee0oWbCH21wt6td0TLidO8fJJAKLL9vN4FEqnz1pFq2jOCuJWaORTbb
GM7/Q04X0oregXfFNcDwk75vGphfIGiRuTOQy0Mh/zgaOUpwA5q+aJC/2QChT9A+2cSz6RGHg41L
RyPJNuOWQE0iwXZIb11scagqIakuMfehXufW/8rRhWs5xzWPALq02jd+OKpX9gKHyd8MNGjuU3OF
C6kymAe/5HA+eMcDs+XWl2kzLTQ/1DktyPjcj43nzs6lShz2ZYRtrMXjzpL1FbaQuTApCV6O/LYR
rm2jMtFT793OJbMDCRX57zc5Gx9jwLxdKRNXh5GHxlL3NMcRPDXfKIuwZT2EyGh6zGKlYBVemDu8
wLpLwWqGtncQGDpnyLDLM8eNRh+RktdmmgQyVeVhRU4Vs6KpDbITvrrWggmpOsPdx3FlGTtNeTbc
zExbjIXy/FXlNqnUc0JYarlxwFP2Qbc6r19+Ox0IJwmtUylqCpPWGNoOfYaitQl9rK0DyVY0lFf/
jQkv2f0odN8P5Jbrx7m9I0jGfIDSEogaUb3cUudjM45R/r0f/312T1a5f8W1mp/+aiEHhBBv3jgU
yQScplbhCLacUCy0NSGdGHCxmbuDZ0lHYoFDo0+fWBKO6vrJlKIJFpRcWj/46yxPr3D4x7jmainF
SjXohSbSHb7aQO8G6EeLLpLAv/N7MzTQVoBgcC0fZ9q6L5GbHGOlvVKj262Xmw8bLJvvlrs+YguW
RjAgSXEmjEg3PDGfOPWHZKXVUBTFFV2Ykqoxjb02HKpIP9bV2D4SKxxwFVI/qPW/YP9DDsGquCiY
A6gMQnIfMCbCZPHXZaY4COZnT3grrYZPkRmB01pm+IgPhDSfCLDvREa8dqnVlTNuaSdzDtQ6Urqm
xmxhG2Rxpfoy9Bd1AgHbYgawzfPVP5KksWvpMUC1g30V7FtAbpYvj+vSZ9q/H6bCo/CGxV1Nu8II
nEkC/uIVwj2hlqq7nzLRNXyr/ECO5oJnVmZToWLoE1onuIXgg/TouqRJV3vJh2LSAzIysrME5IlZ
CRDz+QQA39l38qNjIbcrrDAl4qMZdiL9NqPWPPwsBbZ8Nbqd1CYKECnwfgrxfC8ZXGOzEhdH5ELX
ot/mAflsI28oDLTpd6FF/LVaRynY7KnvAuasnERvbygQ9zSBygQYYKMQpeq910kpVsv9BMJxoOmr
O0KxnOyHmNHRDYNIsnNU5CIxfNFzZMjmnlNwZEw6k2u3Go1vQDcC6LqzyuHGme8dD2wOW3kUgICY
ks93mGTv1F9sAXAMMyOnfXMPLUMFc6G4jL2rOVCQlcfr3BJx0tL3N0E3x28uRsloLcYLiDqxqvgW
Wcfe3/9xjVAYeYbfb/Hn3dSol3YAUJ/M+ERL936aHUVWpDP4SRVnJF9O4alEOivoGsBqWLoR2vW2
hZlmo+6qxn5AfPjdTNjqa6F3EoyBmzC+YCtBOzbN9mZr1u+5YzO/3fEhMlgJ3h1WQNeDgZ4Kfa5U
w29fw0mm7Qm+3DOiSvJhZU3EDX/0fY40Ga45YF9j9KKVlUYA9JI4PAw7iprO7uiC0APIYdDgt1L8
CDmgEQoZl3t0LGi//tY7FLmu32rn69IWvFQNXlFYYPjL5Z8dT+QGUUn5kSssq6Z2S7PAEqId2Wni
utT450r702rETQPBpq++FQ6j2VFX4mW4W8ZVIeANpUj1cEBTqwMbsV/gpojwpym2GQT3nv+q/kS3
fH3T2BsmsGObzagob3T3qK1p1dTFxTzhI12QrzJTvbE5svdub/6jLQgh1HQZ7dCec8pFou9GCULC
oIuKFdUrcNaVJV95FdSmV0vGU420cr3EdhNpvBNRedR6tedhJKwbiG2f5fQvZCoEvULRrSyL3c1N
0IJ1bJ/fyZ/Wy26uGetczv36y0v6A9aLHM+SL/rjJ3+Rr/b7aHsAdXzhfR66YpVSv5dzCMPWnYLK
4NXpfgz7EFmRh9yr3ttSxmFJNgcMY+bsEKwgZ7X5K0JpJMP8Y6mC2ncen7cam9r5L7OiXKwjUl8R
QMJnTi99RbrUU2tstw9kOrASD3clwxBvJYH16aKI3XKrQMwViaMJNVBts5N1CxyrAwCYil66gCr1
FsBTHcIW6TqbX0AbABzfb33e+88IRtm6vHIn52k0vDZDphDp5qHQfGUeoChY4F+w4N5vdjd90iHS
3C46y9h3AxzBKgh5nA0g9JO14dQQthBRxhs6DKwIvcGMMIlLuyDNMQstiD4r+8+zcEsWKAsddiZs
k8Cmh1IedoTswKSEZUsJ5oTD1devyN6kbC66ENMGLKnxAfQfxcGvWBOrJFsEJ3BNmKcEMBSvbBUN
1G68sSq4ielucFdGns/P8K0qKWCB4NRyiwYcZKTP8n6vI+aaLlmoXfvpv38Et/uRDiFHEh5rE5N3
i7RPzbw7LvrL4m17ThQm7bCdu30ZUpFXc/HdEA3MWpKgOds61A2yzl0dWoYWwo1eDk3mss3fPTZK
7L5+HBD6iHCP6BrcKC0mPoyLVguYxefRMu5b6ax7InT+JTY5nja0/z6/35si633f30kjIBke5Vyg
cxRjtYvaxoxztL9Lxi2O2o+sQh2TG6J7Xio+Uncu9drZEk0DgWufeNFhg1XSYyRNiUPyi9TrLVcr
5C6Txafvi30hGtoyONVacAu/2ViVZkP/dRvU9ctSB6vZIf9q7tVCSL9gS7I4KlmFHsG+Y1FB+XrG
k/W/tZZKbwNlDJR+mVCvhX2OfmwGhIFRE1Hiygsbz81+AZ5va7q1xUDwAzif0x/BL/sjTvQH4Bwb
PiX+z7LQwFwL1yI/Ft6Wq5Hb1BjqpbsLt0k3QsiTCqRIFr6bmjc+3IwC60CHTkpdxgXadKq7uDJg
dCCB4JRVzgJuQmhw9bO6q9epo8rPYm1aEtEOWqskrAcEBbv317wuJTZ/EtiWrZb7JxaDh9j1f7C2
d7tN3MB733LfqD+j3QGcBfhK3eIKpuEte8FfRG4K2/zOemOMLhBROFGqpHsd4LylBp076XvixFky
/9nUrXKtGyxd1SczV5iuCU5yML9L56BaqdCvOUXv2F0JawFT57CuGR8kZgrxvluj6h/T6AICI9JU
vqoHYRRZx5pTO2s877kAZSSFKfUnEC2/BOW/7RUfW0txFJVtRowkgbRREcyUrlBhIl6854dM8RVi
MyfVOUgjVgYlU74TE5M+JM2J9bwweh27H84IDM50zDZ+hK/ZHsge/EvKTp8BwoQZBfwX44jZ4T9p
KyAOW2+OExXCM2bv2oy9dJ6Anv4Kk2ElmQyVv7lH5bnkMb71/VJr1wA1+FR2yAZUwAFBrw3oXRZ5
Xk492WYpFMJlimcarrk92YyLUGvhWEPjL8QFw3Ja32q76asKEmNMZruLlBnJKorP+FKBwdYDlY8N
2ib1nUFHi1T24yGJmaFmUeZNPB/yIBETA1CHb/hklCtDjNNC+u/GMJLifHcWG8CKsWeTo1E6huGC
FcEF7+yIv/+nIy2MdnsluWESgSQfeqLKP/EqBM0pnCvya89zfgEm/PBAVEYpc857TadPznZCqIVo
QQZOMrMR350wGmE3YMAZQ7niGxof7T9/Eg3vCEcHVb2dr+4V01YVZGBLf/6dZkrpGgnwX/Oihk9A
jIGmbH8z8QlMUqcNpOPGuoqeExDIBA4ua3HQldEO/Zi5ObGb9eGYZIR/Eln+bDOxN3egR/QGmpGr
Ilm9CiCSifwhqmEXXl8GDIZagaNNZp1Kw5lGGO8ROFwxklsawGganCvchd6ntdvJqucqEbrpC5lf
LMbBpkpadGJPoMNtLMJVIx85x4V+1ejWK2i+LSU2owuEsYZJuZSxyPi8MjC51v1Pdhl7u4nbsAms
csij4QlfchixvZq7MkeEeI6nhqxjMY9yLPrDDisL7Bf8JwdNrZtot6JdBTwZqCkRl0ozgAWBBvhP
ipsTGiq130CIHvfzEzCH0ZArzTKtZGNKZWzH+H5PqPWtyVGwIYoJhrD+coWaeuwCM0bcPnHrm6TL
VmehLrPe1L7qiCoz9aSpWe2DU3eH/FBozQ4dipUNkxhkoVXBjJZkASUsWjO8l7J7w8lDQzvW3WHE
adorQtz7fOjnUkoQa76JFO+SrZGWeCVPRDaqW8Q/RBM0/9Fizg0NL23JfRoR9W89LT2CkQ9YNQPa
WgsuGETuFdMFhrgYM6ucHOSFdPzvmD4AuuR8UGo3iVaWMuImnRlLHIOrU8jImymAQu3ragdcjTYx
tchaIhr1uQc4d/Sxak2LilYweFXEDEHIVPONXDvOkO5Bo601stGBFXdY9QTlthBoNao9+zd+pblQ
MMKiFRqYmpwU+zmtzOosh9C0x6vzTX81TNEbkI49QZsdkiGYG1QoXVFWZ7yO0Q9aOCryrQnduvAO
UuGJwccn61dvUhMlxfQs22m/7HC+6LrbJggzIuoFSN9xkLIxO9gBvLgCktjZ3V0omqr1urWZ3K7v
zIoP7pVxS/Oxi4NZrqbrsTN3g07OZEzQM6WqGyUuNg8DP+o3