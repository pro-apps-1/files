<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/j/ALMU3PAQPv2yThTIfXTGJ7hzFqUpbDO1ugUsNChpKdi7VW2uxltJ+aN02VMfZZRwm8oP
SVXDX3OQnenxS9A+td9I+dLgxdao8P76D95s+qOHMWTeKmXMNhqRdcQ5D3bddLmljVpSzdm9Wtpp
/i1Ar4v728vbToXwJb4XGcIt5rsAR8Baa82H0eGJURYcT1Su5iYJ3orEcBFkYKo38vbSN5JpCSw7
yoRbhexoVQkAa2s9OtZu6G50IcZj6EoFSuslNmUhdEQ0wVtC5XO2MZ3doh9pQ4FLx2JExIYA34DA
pwqk9qa13f4W/FsfunMtvNVRzep4n6MM7CN5nxulLP+qBZ6OA8/e1J9xqYlVvEJWyNVtWxjF7lAV
WiBHJHI/ke/vJgQR0sPGhq3ac0VNX+ahjHtrbqNjo24XN6XzcUKHjB5YeqcJXVfx6uC8VzTvdV5f
dWXXIxubZbnvRZ4CBQyIFZNeANKaRpgpRX9LsRb583hELYGiY17GoN6na9tdGUcZeR62IEK2kWD6
cai8SAH/j/2W2BAsy/XYxXfNhqgEC5qqDYp1YEQwABcqRZz5e/zuJdp6+YgvNRvMvwtLXbeEz3jZ
dLwPBfWrWdOA++Llh3SWYBd+6hHb5vbvnnCsrxU1yhJLtrqu/s02Soy3ngHIgc0S0STXHhZS36aN
1yvGTZNMSJd68sRfqijvzrA+VabFV1j/o/VQxM5PWmCkrUwRULSz1b8QFvCiO5etOGAfkY9lvzzm
T+dKLaa/pNCMGGNbZlHgzJGKmoB4XqFaxJY+/m6o0IUDLCzTT+O3D6Qhil8oYsuvMHbS+426nm8b
ZrLNTGLycEvujg4BObN19xd9H5n9rqsqoXzx+sj02U7wRmYbD/tRSoig2OnY8ZtrcKgaZuhuvzRQ
Eqj8jkX0gUSUvii4CAjtWupeuzdInJZtpvoXWqP5qdwP+NG6s1Bk2C/fhfPFijHGxxxSJqHv9aW9
6Kj0KPO6o4F/C2dqG24miFhWr1rIfwCBjtgCuMp7259pLMKR/AmTylNft0oFor39AnRVUIVYKUXY
7+FRQf71ni+nc4qFZGggVM969Wx8Q+FUSAIoG942S1bsxY9RqPWeSDIBDYaQn3SNpuEDkJJqL1oE
s8btoPmORYA5O6lyp/AJJnnFjV+omkVNqj9kuLeCnsGGdCx8HBhm9T7Xa9RagXVUvWhZNE18zsv/
lB7WCa6ws1tM2KU5QEStwrVO2H9tGmdRKCWEg6ZC/JJx3WlKg+YoZ+0WKkbd7Ix/EuAC5uLEFHO2
x9Cnbs7V34sxtOvChldvtsFIUdSSifOtxH1YCq1Hkkqa7BDmCF/VAj7bL4LS7NXLLjA+NgUXaqYR
ZaKfWZiXdWshMVx35wK4mHHNPtZ1HthtmWBCiz/asp8AOwaWeUtd3cmPjYv5C6k0ysV12fdOl/sA
6GWK46JueXMLL6ZVuS8vF/5Du+oQxvGMuROqbcs7pgsyWV44BI9y52FJgNIrp8L9gDOdukwBjTR7
8sdfP9Hmwts2DIB+kD+OppUpkOF7tCpVX+y4AwHKqeIN0mYY9WmYdxnSOxq50R1JhTRhL4m/Yz6N
jvU8VsmNCCkrLLL99ipjvI8qlYCTGEQDHQ1hg+jkMIsz4w6tzkH/NEDPns5DoZfOGCFKvp7d1B8q
+UnsNtB5o0e3/+SfjBFCgwKe54cM3zE2DvJqFrDZhGwxbJA9FVHIVA2euOT/lDNy6S3ySrtavm5r
+VyHTK8MKdhNJk+tDehIL8SNxA3DP423MXzmnh52/WLvfDK8JnxWQ3WPqcF9AGmt7fILI+RJtdAu
uxTrSrFw9nV+itBFYLMpNcQ7fE8IzoLg3c2AriV4nw7dPSqgUMogKfi1b8aEehrmBZHc7u3Pjg0m
2atXQmaYEphMeC7lzKeoEkM/fKc/2+KteMWBHvF2zWy78VBEMVXOtAJGc+K79UJfPrq5/Te8w5Bt
kFhg3Do06PUjqrfMcnVZvc7N2au1FzEq5LYn6NwsHAMcATrIPLLNhly+E01O86SdR0iLOLUAoEy3
nkbJ6MpXcA+HIK8QkzOsPmuvTdCYhllliFFsJxJnZtWYGkxJmabJl58UpcGC99XSv9QjoZjBs3B0
6FKFDT7jZMzNSn4qbPnHfynWTRftVtVFinLOrFQbcA77Mg8lWRY7AiIz2aSFsL3dhMnhEL4PCJ4l
kzc5EqVgVP30I2P1z//QcF0siqG61lAVHjHo9wX0ml5EPsILrELVi88qdKLPdKCFf8ygsZRbjF6r
he2DOfNBPyx81bVj5sF8et+x+R5sCEdEbKf+k8ZTZVvE2zkErAoMiAfzzIOUwq2sxapE+BdQSWEp
9B+Lq8V+eoNBvKSEAGFCa069GaZxtOYI9oHmtV4sYkbeHlgkq4zI9pX+dTsIbLXb7bohqedgA5Zb
UXipPdV1yQlCNZ7QzP9hohiKGbgg8RuvlsmvWym+mchzawJqBFgHiEA31tc4g/0NW+92hzR3eHsH
2Gk9tKvGG+iq5z68Xp038ZLy+xtXVHmoXsGkQKIIOkzY8TWdI9zRAXr+tk7OZ5oED8o2sa2dBhrP
2Tr82kwIxUgo4Bu9/AJEauLkfXe9KR+QDc6z+Bpn/aO6j6SthLS72b7ZtouR6pHCkxtwE3smjnvv
GAQ7vRT0l5pl2ZARveSzvxMjzMU4/ibAuSxgshCPPx/Bu37LFT2gt8gTVwqvLX5pd2ttk4Yo0XTC
ysZ5VBP++/BqAlSKJBQJMQeN31vYlXdOx0Pl4OUPnmJvuAY/pWi4AM3zyUfov7v0+BW4eM6f4LU8
3IKEvnfXixCpABnMYN9OlOvecL8GX4wSjIV6x+AGV59zYJ5GH+NEV9jca5UrRSFFR9m0SzeCbKru
m5AaBmDXH/C9Xe+Fc/FcNx2Y815Q+zk8vwfgCFZXbNqE8IEezJKvw1ZQiXFgf554LbdYKg0soF53
aT4/hKiPS9KwWH8kGfW/3+QBqotT25lyUpj08KoF6LV/DudfvrsM1v3SIYDOlnnTq6byNwJCp/Zo
amt2ZnNXTX0qyeQ+m0ufi4z7CTHv6sy5Qb1qdKEFMt/vSb3tHeLyeVND+Ctjjb20d/vS4LqrxEVp
IbxSoT46nG4l8NvlEmuR8S+V3iuU3k07uHMVNF6VWEOt9QbEbjcxUUiSA8+i+23q23KBHbitCyss
ZNy9V1R4HfMP8JWlb5L07xdUE6JAwIw+xds06OwGCFTWwkTtUty5GocuOpeGq0U7s9vm+2tWNaVv
RpjEzrNWLxqXOYuCKuWmNMZHQ/ZW2IY1gIJP6U3M7Es+RuuBkMtlhjQ7yq7i/mkiLFvaA9cpJkeg
kflSCTyoyDH49p8JROcs5YA5Vc/oP+jtUkUKet+VPYTNuS8eqdJAEUosrCuUhrlA88BPzoFjLvrA
691OvTxmA4ktFLC4yL3ZkN/ioSVAbvTh1ZaJzlj4qMyXlLGQ7/L5tZHAD/EVWgcered1sNJyGf6Z
OXjl6xdt5k5sGC74LSbSex75bznzGhp/gvtkrxVwiuHi0/8Qt7tWidIXh6LpX/fmnBX5uSXYN3SG
tztcWKQ5Qinnl5/1TvnfSf3Zp/xGaUmfKOXUcMI/YiMKsUQG0Wv2Un/kbs8MORDRQqHUtecigoJz
3aRvGV9Tx3YP9VI31EaNaMdClP0Y7uNswNLdp1iPZA22vScIOhniG0Zm/O/7OeQtsebeGjVOqYkz
oAE08nR0nigPuUzTnIurM5D46PWUJlNV7SbxaCjw/xw+xNLbehueQy+ZsUV+qHyZJCosLgD58CMX
8mRpDMB1rEYPTi7hL02wLxz9g6+aFqqldDPiyJaF5nsMZfCtN6VXo2gCWlAihigrCQNLuhXx7hGG
4Y/GKvDi8qKuoZbw8cBZom2tBBroD4i3FlONlgw8LyRv2wx4VbMuFnGeUAYi5xyfrwYGAiNKPbqQ
dAY3cRKS+kVsU3ut8/mk40SeCXHTgqYKbYnVbngJUEkd/1bED3F1kbWiQdm9ZytOnTQkrtmFokA2
kNmg7vZUoELGtx35E2Uab9Y3FvuzBRLtlSm1oqIPq7ARe/YjXcnM5ZcgpkCAR9s+MbSKu0OjrU5b
W75BXCUXnbzg/gYr7eIW4nNT15AqX5v7Cct4gl0e9IEVClcCSbh4t6HZiUiR1caggWurCEHoRxrY
x3wy81pDw+aH0c6Yt2SLvc4d/xrXaQ8lQjhEePvauJFpqcnqCb/Uk8VmBDRCVPHo5k+Lhb5M8p0h
fKa/+gmsThoRKe3wIMwGCu6vsx+njPMu1vCA7CZ31nom4ep7aTtCfetykf9LnHaUyf/ILlzRNjkD
fY3j2gihO43o5I3zs77Ri42Fnc98dRHzVpEhgbXD1YQDHXfk7WysvBQzPGAM/mzm8qoNFX5mk2dF
a37+DJgvG4EJPJP8cUSxdiSeHFxbJvENeK3ouM/7iVlIWgN02y+monnYCU8KIh3G0iQjwtYFwQAw
/zs/DA6H4QxBuiVd4atAYzEMwL+Wx8grgVV+CvzFhmSAxHfeB+dZ4E41TDP/M3EMns+0Eb92WWpc
nfOMVxlDbG7EFjBwVUY4niYYKya96Ao0IjsNiUtBtFTaOyirHEPUejjdvrOCOaOccVh5OvjLSbK2
oF+vMQyTsUcbTqI6wz0sOrVQgxi+vpDHSmCD+vfnG26L6sV7C0rK72Ltom7a6jdQ9F7PsASHAAYd
+i000IR3swQpBsjPXSHY9m+BkWaZQmazQsn8Up619aDUJfERTtP0745vIrt5hhyQIMF7ee3zapU9
baGBc10L4w7o9/VEM1WI/y9wfsmeO5VunoOgjkZPCC8OcX0tLJhYd2Gd4CQ8Ljx/dvWdnHX4Rskv
4C1i9K5yX/HHfNXQkuCH1AIH9EtJPiPLg8Zm0y1rnr3HK/i2rOkC48OAsUtnZDM3gHNb4N0utPV9
Tq53d0nPYY7Mvm8zgJcV+zBguCuRkykmksnT0o8haDo44M03oD1v676+3F7fIn0dIEsDWleG1xpr
NxkiLTLTm6OYPJQRyF5zdhG8CI7XUW3XT5kXYWJuhzF+hAO7Cy6erCK8mqAAM7jKM9Sp2GvS3Enh
RKVlwoE2ShvFhLIIVM/K2OCREtewZTpkM+BW8LelmBZwWoo00kcoMOrvXXzXE7opgmhhtwKd/Cly
LGdNDLPAO0wkNPiVOdRQm633415FjqZCWPjrNqnfCejrfopogyfVwz/nkGsVe6rOaadOZ6F61o76
izqzBBAkKNqsuwfMf3GaM/NA4//VdajFlvpLLf/p7Zj8nvOAOZIyuhQiIHRFy9e44TvEIg7e1xML
G8iTWAscuwKFJ9oXcnu6srUfLDyeOYwMB4JU9yPuPQoB0GC1I8EXLM0IcMH9CUJD4HezThBBSOec
qvfv8dXYEetSmxWpC5TZ8ZSiv5CdJkXs7s6hOwmg+s5yXkHV21jezLIp+47lCiDdGyUl7qM5m09M
nOriJEM6TuUAgZz5ttnSbbLdOvIsmhWLf22oUbyCIEf3UJf9V2IHJ5K8qiuxxBn3iUXpR9WwQkEK
ohAem9gq1cEOuMHRHMMCUlrY7qeIgP7+Tp906y6Xylu4V0YeWhftQSc5n54CcdqNbUxSwI/Cipg7
oF8xqKLvPMg2rBIyTT84U+6bbbIfXx3t5L0NNy9IzE91k5HAC/tlOl+TussMoK+eBvzG7FhuVN3i
9EB/EjTKIhPudNP08720vDJtbOKGMZlvuYZdtv22kc9ULT4c9Gcf0w3x0M0nApL025+XZfwJGwDq
VTUIY2Uhtp7qXWSmdVPAgUdlFMnfvGIB/vpOpWiAlHw/GnAFPcDx/niDoapFaso1zZx9KHFRZ3J/
8GJeEnluYkgN3D5gVPaVfAmmYflPNkosEyj+Ml9NyYe/Tl3oPPcUWjTWVJQgWzk0EFmEGvKWmf0E
bvW89KXqYAjXsaAWdr+IbfbJfvDRGEXRSEZJvfuK0Ld6Z1DKKUDkfA9WeFcqSrXIT7lBRiUEIIeA
pmglLlYliwyVEE8p0NsW/2oJiKb/B5JwbDPWDxKVtYxLK4+gIBGfNaN25s+38cQxic+/XPw+cn8V
8fPhwciCAnOdocglNoOl0dTQerQ5NwiMCesGVKyIX5gNPw1+pa5l0tI3xe5rqTA2cXZ3rlTbw/8F
8HE/SeRW6R9+0bms7Pcn3rzBfOrA4yzD+AMDCFzotAWDmZjXTLkBAnZQA+PD+WCGwg0uigSJqc5l
uDDeHB/rtAYTrZd/pR4/oefdExcr7Sk13A2HAH9IKrrcugln50adObQ6aQXrlzXM9rW7CcqlL5Is
W8+xY7RpSQvn7n0hEOPZkkrCughE/Q1RfHciO2PVDLqgcIlIX0BEwYnbh7a1RKnvG9ZvfbZT4FFh
65SE/09/2J6IJbk1eMeHmDyBo6X0nSogV93QikmUYb9Xs1iGu5BHbz3ZHpxjhpBAPA86GA+0QqGY
vMsTdJNJd+YCp8DFkoC4XeNVnMXjxvNimWCtFmwjLeH9MsqKUiHMj0UB4AMzj2JGBSPhjZI8EaDZ
aQEINlxbQKEpokkKAsFRLg07CGaYOI7d5TRfLdmMGgnI+tPAQa70x7lpWqnb7vbnKjywauN3ffEa
h56dq/FmKB2+DkvPj6ds+5sJIlWe3PX5udSmy5gaQohFsBZrrqdn56WKyMiYALEe6uuDxOmVYi+z
QITeAeAfv/R4T7jifC0jKWLijh5oQTvwEZlMeW4g60o35XTDkW2n1IyQYTQGX9q5CFBiVA90Rc/L
kcbY5Qrndw7FFf2+vh5UgbadVC9FA+9qu/BaXPBGYg6NlKxe8o1w7lgRrFYvFc/KySohrTG1ULcN
N7SVcAZzZQsBA1In6mqw6DOiJpgP+uR+Wqh9O28UBA01BXNkKYEIK2d+7X7J2yBNhal9ZKkJq67I
SOO3kRcbSejKPvlaNPOeiBpNtT2M9cQk7rsNwl91j79hBmanhmde5EF2WXgZ/0hJz+tUJ1eHxmdF
jtYfTgi7F/4FroP0kC1xpTFpti8OGQ+yemHadpIMdAxhah3MryuE1C73dz9b5Oe0KlxyM8/KCNXI
BQ0zIGpEmdO7v+LZXK8GaOgGsJd70br1BjbeWFwm7sgldsXu/bxgHpGSkvKvVXs9l4zE8kQew2LY
DSb2IOiC6h6k56qZKS+yN4qgRBj+TJy9hSYkRbgAqV36rk/2VZLamOTy1LPkNvMMI13LQjLIeQM1
VVDA71fXtAzs1nL3jw8cT8gOr3RuJtDV0Ln1SUjXiQo7Ct/fvsWSEgVdnWZ8dGDb17f6hxQI/Xbv
dFkzs1Sq66CzEkv0LNEpELl9Fw/ptXCspGTWnxmeO8A5oxIbdVxyOcjgFRp3Bzv5dfQQ9vgnSlH7
Wo7VIXs458EBeRb8UzuJ/iymbms6C8HXxgjdv2pslFLBKsLSgyvJw+lG93DFpdLYMn+9Y0sx55+x
ZER52wbA6HI80QFS9vSB0L5gmAYkBEYSLQBo3pYA8QRUReabnCRjl9vMT9M83vPLg7f7dOk/CNMr
nfdIZccbx9wkfzWR56P74RVvkLsDhBbVCiUjmSrIqusOB+b6IrGPGmeM8YMgrurlsAp9gMEYi8Sl
umPNdyrOAuP2mNC4aYMJcO/KZw2MUI+V9tz3kf9zCctLhAJtPFufqTXYlHetKUr+P25xOvNsfsri
apLLBGu0udWP87TsCYpqDYhYO6nNodwP5Ri5jGHL4W4jkHkbzVpH07/D3VmU5VmPEXBYBo3k+SJR
ECObAYInNVjwZUwg9mmFzd6uZH9OwZA+tI/oR1rKoF4jgMfzD5vN8fAR5KDqarbsBftXcoKh7fe1
EYkrhxRTlcfANmEcZovqEqrlZU1TbmgwGaICJphmzORVhZvTu7jSifwKaSPUOyw29GMp3euWPa+b
BL44ufWh6KtJpSDQUIiBPOFQBm4MD//zP/3+mbxnZ1jtOmp8UKZtODV+GUhARAKxp0GDPr9wYjTx
ml+oGfkuFZZKInhSBxXgFff84Nr1YvL967MgS88cMbqeKzuN/qcs1kMurArvIWV52grfIPUCYB32
065Izkcyj+V8uuzx9jJDyL8C7zWAxpLf7uFOw3DaPQFkjlHAUJZ6YSNG7q5Ocf+0tf4eiD2bXcKs
WVkmwJbuDbU85mHm/tAczXS1kYosQWORZp/b0xY7Oo0YAZi6xAbvadI6ul3aKYuETqqlSF/w4geW
Uptqy4qhdMWum7U3igdGDdNAAYXmM5zp147rgLJzmZeUtLAIx1sbgWApTiK5bvvqzqz//vGhw8Z4
M0Y7v73wHcKmZEHNLkdzP87JteVBa0LfzagTKZz42S4dyjljCNnZH6TJ1zOUJq/0feD8jVvTilqW
iTeYC1ILr2rnXHjdUygTWWiGYAnNQDuN5c5SDGw+VFCJlWMPZNtIEuGQMlsbpx7b+iemmit7ELre
WqZjxv5baMZpMQVXxfyOzKZP5GDaZ/gSBkw24ddFmEBTQ33GfsY+nkonX03qG7OoxJ5YJ7xNZGhn
HxOItMCjPqPkA6xbUW80qqfa4gM1teit+PNxNLAylsaeJmgfhCe7FtDH+RT8OC6qa25UntaOzVdF
hKnfEPXuTdX7OmOjhZwVqwYYVjbYNWTiCwxBc9zbHPk28Y7JXcmuZ1nu+68GeiyaD+M+We5Mh/hE
dgIlv0a395IwHh/TfMFFkCR5yzC7u7F9leEvPWOWDRUnA1DvKXK7RHW/JxxkeNWn9lhkV9Wh7thU
kbThynVZqWQCvDzWUqs5aR+JhZzlOHu=