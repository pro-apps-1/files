<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPucAA/c1E93+N6M+sjyDXL90+fyOjpu1chEukTQmHHGNCN6TP/9VmXemTR69AMUMjtKqZvLy
uT53swjdfnWc8iO8o2zBMmPS7cJeW0wr4YpAkUGFYrRG41ogi1gMQPkfr8cAka0/zxuNZECoUiNh
AJa2tA11tGfvcf7BB1vLJut2V/DYGI+Dikoq8NdrOb+9RXhyDuIJmK7KcIg2ETAxnWHed15ThlS8
j/TPm9I97Y6ybzbv5BsVTWoBLg+9URdtp6m8WFm/shcxgvYq+RWdSfyMUu9e1YSzmyURbgQzSYlB
fiTP/+FhzUnleIb1uIYGbj5dUT7b7Ck7x7uZ5IHX/HKE3wUOOrULL6SVP2TIxv/HhCS3gAgqWlsE
rnOqTxbbfcWgDvUupcoMqUaCKdvhvPL2bwAijk+R7z9Bx7GR8NcNA+eUWrTPU6qmOUNl4LR5cNzi
r1ojQQNLfvRvWyl7Acj5UbH6Jx4P5tDl0F9NX+aU6tnR9oSepIAFvyWoYhjuBXeSPfqZsPopUuQ6
vJ06OpQ5TBC4JvBDV9O/hpiWeoTbAKNRkptdJMxrO8tQOUslkGEv7nhDfJf/JCBES1d15ScTVoI7
6kkGiURQyJhvtsSCAKJqSGmlR7lFVmxtQ5irf1hdLMPjG8ukG0DDJiEou9zgXKSu1W8WZMPGwSet
3FSihztFHZSNCcgW2wMhzN2pW2+FbT8eZtgIY7sC3cLpjxzGxd1qZzOTU3wzyB8a148wBVMaGI8P
Bzu9jfjM/qDnQLJVQWxAsU0JtQgIgAHIKkatSOOk10UyjH32rtEcX30QYI3GMEgwmDK+Xn7CXd0+
WU+uaq4KDTf+3Ly0vZCtcUuU75NG6Z8+8fzuYHMeP2PjGZFRpW08S67krDgwWXvVbycwH1SVxf3G
TYFR27QfDLE9uVGEWQ5mTEgdSvaC4zMc8PoodN8MTu7E+lxNOlZc7+ASfMyCd3Sxel1jpg4RY4nR
MPa/g0DG6rxB8FzxWLbby29eHwNnPHQ3py6/kc9XuQbNr1IamEOtUHZq4nvDw9B/JHgRy9BgQZin
g2B3DJGlGIelonM3HrcITcVWUS5BU5wOnL9bVFxK2QsXso2iQOkka4bhMKNmojwcQh5lvkGhUU2w
kz2neINhR+wfb4JpRArbiqaFFIbirR0AbyuDPAbP71bgK9XXjjr0w4DSAWgQn1XzahPq8RE2o1Ec
XNFLcfRB78rqIG/zAdNQJLKLBCtiyuEVsWauR4k39sr62M1vxrSC2MrYPS/7mGdrvoFRngk3w5sx
TtaVIGlr0r0fxgm6aHvLZs9TDUslCuOE/cXHd8wAMkGBKtYWOYPO/+P0/yXGfbF2rA8KG7Hpw7nW
EGW6goZvh/AN0aHPp+N2Us24CpYxobkM4PfKOFkYxoTgTbHBZYaxkc2yoUkY4wJZUua1r8f6kTsz
gXHLn9ptxGdpNh2x4r8z++AfaK9BbCWKcohkm0ePkQmi4T33EGcM9ZsBwTfr1J40O7CmBhu69pMp
OIDZ4Kg4LfMI9OJIxuSIss1ZkR+atkUja4fuT58HwOySypCiDOUtgre7MXGtUNkdBGyxtv2sckK/
zHM48acT/jLtVkBt5MVc/8SKIT6v4vMzQFHN1gBCVmIG3qST8GqPdnfQxBHUKYYRgnxnxlkC78wa
zZR2MNMti6l96cvpgW/1U3PtqdfmY3/IZquVt4F6gCxqKqVEqVMaSuXQUTzuORkcDuMQ4LWojChK
XepJbcSOMY1WsQmsrqzLHPYLzKLVXWZ4xyZbhHZKxvKTrEtXB2LzFljgHgrFZfzpi/+XfUvO2VZL
pmdWAYIQATNpzjOAbOx8OOk9Kb0dWZ2hlwSmzSVQWmhN3ysEXJ7OMReNCoWF2CFjtyx5EDRYtaOQ
lBfppHy9kdl5PDiWGoqWaSmgaNsR2DsUvNkFVXPeGP0rWEK9JZbVayQ3KRKOweA+6oPrUCQKmhLJ
xYIBfOeinDqBJbDrksUZjOGnIyme8LxhWIzNl17WguvkkgC67EX/5XbOSlzdohFZP69QQan7oKXT
PqEkZ73vUSQk/9YfB9puTHBjl89WLpYSrSUYxB/zb2JYI1qAaSJGdXy7wq8S6d4c7TDkb2Ab2vWd
y+wL2fjGtAPI1mZY5XtaqqUaU4nfXB81yx3XSzWWgQRiaE0Wm2clgplTR/Cgp8OoQt39Hx2Vc7uE
JXwWRqF5O08OSLf0ckm6VAzAjHME6jDFKqAhCKrOHyX1/1PD6vYKZMp5KSlamXwOqDOul2pmv76u
RqkFZyOdfFrtG+AhuwjQhkhh9gCWCy684DI2HKo2AU8TJLmfE7UFqZeAeR3mL9CGbpyr2ddbutH/
Q7tZC3/W650AJpdr6w4i/pE5cpEgiFVO3xknXtt8dXHzQL32N+wtOp+djR29O83BtZDBQia6oA6p
xIF3Bh2IQTTreUvnjPnLRs6wv59wKzXvsd4QCE0P2d1qmLjyu/Juls7b74AtuTRdsZ6jqd8Ni/Ip
c/lg6tLWSUmSh63xJWzue/uMjdyQZzGYMApc/GkgacFAZUrRmkDPnabDTtRCVoBfDFDubz79wxKz
X65xfEYbYBrpS5BVFXoL9RQlsaotL/cSKxMf1mP1lYqtDn9lYjllrciCcJvdnOLcdAdNZRmeEIJQ
Z3q7cRBB+hTbx6FBmXvdeA61l2BouUlIzZPAp/H39YNC6BDtuRXxS1c87a9nk2MIT/P4puMeCY/8
OS0fUIc6i53x6LkkRgEZ6Z1Ab5jXioQvm22yemFhbHoLEXEn6EOeFeLf3rlqb1DePBkYshCEMaTD
lH9cl9UHEvv+1W0zeXkpn4dD0JBnnub+D/Swo8p7G97Vh6tFgKcbhU1PDwg2GbfjvqF5PU2IVZVO
V0j1n9iNhIyaxSMiCEVYmTX4dYNYYQaAJImFZl9TizFq2a1gGH9enQ4gfiXLw2KU3Cscw05p8kOp
X4Qg6HGN4V0xpKQOCtpeJnhjOsmWe1B9sF7R/Zuuffh40aF46OY/9wvbk9eqO1y73oFPOxa4s1wE
g3XOqWNWgz61mxnjwymstI5wPqkp9r/r2M0zC/WHUX8f6QIv7XedQOc2EcwTztQw/KZKq0tm8yuZ
2WGLZDruuvtJAcacY4dNXRRwxWX0Xn5UPWKBDRFg45j727YBSz+mKHlbVauR+6nB8UsWPkM9HJ//
RaYDzuTEUfr2cF7GrKkvrmMYmV3D0MKYGaOk8oWvmyvMBzx5q8qKFlkpsFrIl5kr6/zkfcYr2OQ3
GP5PgGIjHAd9/6XBUhi7ZXsQ0+seGFOR53XcJEFEYFcsVInb+qVhfyANBp//chzZCT/8pkCHryQ9
1TA8AFwaMIEAvfRWX3Fv0G3/SrdfbUZMMK8b6GAEuusduuPldvOCmADQi1YA/GzfWlaZclGg0Nv7
FpIuGm6QURp8stG6Rs/jRox2SrqolLXf0SGi+6nCE9nOpd8/sK1/gIxIkI2V+D0nAQVQXx0XK7O/
sYH9bcUgseVFRI+BC0G0GwzAkEphvyO1R200qxtMLQKrixzHMu0OVfl5x9jX5PMkLvqVljLz6/k5
Germ3uzs9qoNX7lOfE4Q+Ufgx+BpUTHnEOCO52qRPIoYgtlHJqEwyyTHnPR3gX98bTXjcUy3fEG0
4A06LE1UYgptyR/4b3smhfZPw1bYoVwxLZ7AavnK3pdXYmTwH+ydOZix1yV5/Mnn4R1Pw8yTXaMO
cNfFIdODWmqjInhPkbbN6T809KBTNrL30+wOaHSNRdrf1Im11OoX3FlEAte6L+dzlC4KwBNrwgWL
/IIYqAW5bxvKmFKHDTdWR2iDlUKYXKAy4/awOKpIUj0IEkNisEXrfQxI5y56ZVbpSPSUwqazIMaf
oqV7gQYLIyEY0jAhARup/94gzW8wcXYs7pk4lBCVCmz2P2oYs3PE+AqvLO/GbcSnqYnApN2hB0dA
tPYxBz/4AMe3mgjOvYaf/Yruh2fInneR5khCvEyslgf0ugcf2NNL8m+IN2bVMcjfvJBM3VB/DN/7
MnMPvmFjG0laIjDfMzUj+n82j/zW4Iq5gzDZvgkytz+jbseqpxhrtx3d33lNSqL4EZfzOzy32efW
hua+0s4WGun56G7F3F+Mrw0dJtC2uOAX2u/oz4eM1utxmB8VE/o+seuNIo8URR0zRic9XMC9C2IZ
ade+PftsXbAiOzuH+OmSmPm99V6gGxkDCwNvbsr40g1fKt1lt6JSnF8lhY+g5VKtUdDYJ3lAnt5p
GCeGNHRS9C7aKOHPom+0jukWKhGva4Cw4/oOLueQAQPH+KZdYhOF8FkvDzPyq6xHl4lO6VCsPs79
Y+5uFK2habsdI8x3jGI5JYwZItTCvIPPIVwwdd9W84SpXJjlnsmpphNqaiIyJn5SQGijLgerDphq
k9hhl6lTcjdPteKUUUdfxa/EMx2G5sJTz9tnsKY7Z4PWp24lJs9ymHn8/xWSAt76vrEe4DdNhwLh
twqx643yMTn4DD3ugERIEmnxu7rwtQ7IRCe5wFk7KFssWnC4kmXTyL7ddzAOA3dgf/Aix1bq8lkg
I4a1Hh48MP6PekFPlpYXDHVlMcwOM0kGjWZozp64mZ+uJVWEVuZClkpYc7KoK+SMPdz6JihAaOIL
Y+BgWbBYpdMr8Btj+ty8iBHszyEHUkJGEehWqY7FSRVy1T1MYCGbzfDoc1jQzUp57jcQ9E7x3IML
CtJxDsbQxnDfY0tOfc+yJ4nEeIQs/i4kP0xjnHEOl02fDO0QSkJDYKijAAT5FS1g3sRMyPuX5OZI
DLS6/pXmbt+FS3HIYMM3aeEPKf2GeI7km+5gCmVPaUNGvmCp17Rd1c80Q4ndR6j909jbgvlkhmHo
50yNjYzYn6aDnfFRIu4sInIMi2mj00ozQyg3xZOiTKt8syskQ/1dRNfi9FnmJSdYXiROFlVdf8QB
6MUerLZ0Mqj3RgdPWaY1PrmIy4ExCKU5C+P1xEVIjA25r1HxzSVcUUj67KTaI8yeIS3bSEhV1dG0
+qHNWz5naOpLWQoqETaUHNKxnwMMyCEdGmEv+O8IE9pqZKdAD8SpNWduzOwiHe2xhwlekLA29pbl
HXgo90R7PpFQZTX9a7lV0l2Gx+V5mifcnAkGOGuF/fc/E2Hnjljc/DF0dloGK/yPMGdEfYFd43Xd
a6NeIkYiJVIameU5A8rLlSIibGLUPd9LuSFQDo4Qmjk5zhJyIBz22DNw8v0YWYBX9xMzrk6XbcDk
W0xrUuIKIX1AzeMecztTCeCNJGNAJBStKSAKC1gn1/SaMoTDKYPZhMPuRCVO/8BQXFs76Lisf+tg
OlFlweoKDQiJcCAYBg7cbPdwCBzH/ea2foahkcX6mc1kraDYNEFNL90D0fzLdxR7LWyGo38nzGJN
ktAkz3l8V6VnAzXzFYQY/aahrbtFtbxctYtRoj8zux/e7J7PGzN7ZvdEfE+kK8sCJlTJggQx9qPo
c9SHBiGVE6V0SnoPXpGT87qz/us75mSqhqUryETEULOohjARyFLCZy+WTDKQn4jwQAMjylDJUxUz
RVRW/RUnzWzidZAmY1qERn7V8IDQysd1KgjDkSCIDaOZMB0tOPQZDvuzftXfy0iH1XWpfgPrqqch
o5nD4cdipnB+QXX3QwZ2a1QVh9qPjW7um8fBl9AQvdrKZjC7cM65a/5jPqbqsvBmZzR9j7xm8quS
p6NZSlt2gjX8ZT9WwpB70xPRZMVukXByPnLi6fZxGnOLifPqo+eOVqjFYl7M2t13Dh233U0iX0io
NdmhfXC4ojRQ7L8+VvPy9H1ABKxX4qPWGvSjFyHJD3S7wBX+7dC6miX1NAN42t//6QTSZL0cxREF
zb6hvQbpTBvZuAYs5KXDmA8xY8N5MGFHONB+60a3rtOmExMRAqY6daO9f7tvBYY4hrEzgw29ZGCV
3+o+1i+ck4mQKfFRyB7sTj0DWnQUOKIIQnog5KgyPzn9sZPpPsoEX43xzUT52gcL1BS612cd2qvE
yBl1IBLmXQ22zn8Ho223lRJZPGJ7x871djdPgwzELRwrG/nQm/4w7UkPf1WSTaBrYiwqpEmxM+es
akuON2PE4aCB4rPg/I5mQiUSDmWPclXrDgr8ikYxB8iewosmvS2+X5sEJhD5iMU5VhnnRz8vSeQE
ENJ0pTCluf0mkA2ItxzYkxoO7j44kLiYfRyvX1vI/ePGJFsfyNctLOs9YYvnIQWlAOKa9Mmx/1D9
Xt2e5mAFmbM23AP+DfgsMvxC0my3cHxJU+Rg5NW+NFNGHektIztsfXihQbq+jyTKZj3ZPiv8T2Tw
fF+9M3J0hGQRr3yRgvF/NTf7O4fPz312XqRy7+Bm0kSxEYSwLkElQ2zfulB7Rt4mQKQhmR/IAJwO
4ZfUKzgidaz8BZW7uBxWADbI2GGKvD0ZTD16T7+wKIpcZI+MLvAqzLisykCBS46ocEbT468Y30px
N9xuUIr/wllnsBim7afpuOnai4XKEfnnWb/SRrNjdNURd9GiNviuI/BwOhdSxXEW5aDv71VnMADP
9v2RaEMnHGcHk2YmCDhRvRxNJ0UrlDcP/6BYbrq5clvvPK1JBjVj7H3fQnYOn6jlm3Q3f+goRi/u
9LuViPcwV68VJeALCOrAQL4GfXqpvghVNEb8XtU7pm7YbADkZB9wuEDNyEJpy79rZjI6c6S5kXul
nP9IjvXr39U4DHhKmK3kGEh7Mbre0MvQAZr/JKDF46Mb5Xq3d9zEgg2qCTKJkdHpHriCok1z2pr6
J0J2OruajRc3j9W2BU13+ZShJ0ly/QzEiNr/1x+8uA2URXKf50MjX8wrRPkmLX312/0I6chYxY5D
Y37Fg4iEXIopL+tYKK6ty3GVegUxdQAj06F/lLM53wGJpPlzukpb28YUk6iKMJBV0g5vr4+mJOPS
CcDt7CZZmOHWje5B2ZTCxp4MLHcH7SUEUYn5QmBGg5+yS9me3cbPpZGi38Nh+rDhjmVNHu8iQJlw
i4KE6R9EBSYUDscPckNYGbA6J2nWnpKPBeOjHDEjeQV61+LrpfXANgkrP85oz1ttlUbINGd65Ae0
CV/5neMms6a60zBW7DVVFruD7nCHN8Yd8upC2ode0ldU3rzqdxefTT/gpJBxQlX+6Q1rFJux7huH
2MOZAZk8Y14Z7cgfbJ/YXRF7sbJNUunJh4FaGYq+6nv6RwksfYI7YSWYmlrpGEA1JDMe1OAt5Vyt
kCheYM+GVcmhmtcgwXPzQi4sHm43FMYYy2rhv92PAqbirDlcwk1/G0VJ0ieQ1zyooOHfaif7TYDV
pUmeEjsa/fuJtaKUovGkz/Ya+pUBYdHwBG5bzjwo+QT9fxQWWz5U4x7W74XPGVBauvhALouMvv9i
2kwjZAW5MKaBpZ6IEllliGoRwsEH+3FmISzp33Qx5UADn1QkH6BB9LOuEeUmS+RAtb2y45qSaOas
tyz6zfTCmBKGMLZXvX3RVQ3CHlS93yq0Nce3Vm8F4CKPBrwqdVVxUUZJxdPHWyWLI4Dx9gd7o30w
2NamvXIeAGrdd184SNmLeC0Q9S45zpbUIvzMltmIbLy6WUqutT1HuSM1JGoAfKp+Uf8fvPDXLP43
CLWX/7WOOLKWynO4Mcz1YHGB9O/VZkG7tg1QnCQtlqCwXJEOnWmrc7uUx5XH6/dvLFNFSgRZNscd
Vkm6RqP9r8YrwOCP7pSKDeyv/6mEx4B9g47vmqE01JaVAEDT/evJQaP1P6W/4Wu98sRV69sep74V
5ktwfQi03Y6d8+8k874q435HSOccgtIOgBdmgikgY+bOhF7mTrJ3roifC4yimfH4bhCMFsXwJmti
GEKj+YAInJ2LU1i8j6g7/ItoWfP29+OFX6X4K55HA4O5Qg85Z/GvntLzZXUIQU+0TOX6WJtz1B8j
6oCM7VCjuTBHL3Hhhv7e5BTvy1tN7j0bZeE/0r4LTvZBUaq6Ek9NpOCRtFUDbfhyv8bWl9Pe7ZOS
WreB3LbLkMA2UV4ZiWULuZXWXU5qrxSIFbewE0skem8F2iZIDyTaNvMe1F2SR3/uv8zU4SI3l2AM
1ZOYGoXJNLIvcXkxyNAAQrSbiuLt9DEHMePIHhxrQ41jdhi5vNf9srivLVlQjE5azWlNw21jgHyo
+7OoleO4lDvxl54fEaF0ir1pdv+CVv4Ah0B5mtcOacE/hwcpZSg2nh/v2PS905Mtnd8mhntXKpNS
YkqFc6/nDBAnX21lHqh83Pb9Ne03MXoCJrSqGXhWZGgFwLuBIF+a7zqVq8DeRRTf5vjcw4vWZ5CD
FLCFcRPtNKibNj0kN2BICma/KAwD/Gpyg7x0tdICgvNdWFfwMR5znCAWh9NnE+k3FIn0/5JjQRbB
uVGORe1kvgutHD7IVZ92Ln1EGJyX5v9sKPUofZvqwGacqJN4B6hWB5MdEHREvj9GRjgsrlkXaOE4
vVNiCWu9xX+rWvv5AyLkODwNdIY3FcAaSQm5sCDwn3VfW3r6R7zPSHnaULr7kobyQ3F0dsEjcm1G
zWAMudcCOi6QR+LLNLyvN2duot3hULAKj8y7oUDdD7Oh22wI7jRPUik2XLyjgeqkqqq7HMdfdNGR
AoIcCIYfmTi0GwkPj9efWp4NW8LNiFO1r4B/BUf4faTylAEaFO+f92dH5FduJrhpf+kokne0XF0P
Chw7mdrkZsHZIlTlc4MYNlsKf1oXEHwpPG==