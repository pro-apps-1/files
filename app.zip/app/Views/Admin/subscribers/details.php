<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyTxlcRs2GD9ZvKhHUJ9DIhceKH5WBoNBvAumym1Ili8xiBi8oGSUda0DPcdVCiK0XoW4rCj
vB40pkTIYngXKZNyXWiV5LDiyTlBEKhIFryLcnG3EZauJghBZ43xE50V+yZPg/Nwt1zkiSmOPq40
am1PSOR6oyIHuP2N5iIp2PgCSrgdsvMnOuAKkbH8s/7CKk35496W72adtxVa25Pf2jgFInhTeH28
1hcLUh9O6HDzS34s5XAGru1CPPODl1RJ4nJw7nWRo2Rxs85Hakb8U5GQApPXc9dgcEeQ0VfftCAz
2NaYRNcY/ZbWmUAFrlezQ9chk6/yQ2SqXPS47wYaOZ+0Sc7EzTdE+ZvmFtTMjLNl6aPoAxP5oeP9
UGGGeD3EZjPm5ubz18EV8iB7PCsYhsY7CDf3PSvaZyZAyu/4Tmt1ZQzzrR5VKewAKk827nS0ZBs2
dKAHM/GG0H5/HSskWyes0SdYIF//oFjOm3b1xkAOyVZN06+iu5aYhb+/2FcTMiHxK1KLzGhiauz4
rQAuke6BvP0haAJf5Lcu1BzXEm0JdhYbP6wSuznZCck2jt/9Kblf+YFU/uynYfbPeUwXrH0iS8wj
Ywu1N9DILv0xROt2+D8UBlT1OZTcFxXIU8mahs2risKscc7/0V1sY+VrOYumLeWEp03AM2VrZbs2
/NjY9hY0YYsp7SsMssry32MkZ9rtJw+/NMHCL5cUUBKDhO3GWAtR550ZPEUdbOQ/UYNOzVBkE3/s
p3yDbt8cLfToh/ShXmJEWNEf1ZyPmLqgdtNcQdSBSdjUMePd/hFN4vSEdEs4RUaIVTmTZ8jMp/co
LvYqHcWWU8gmX4JdGTspayAT+5Ub4UBInyEwmi37TQJ6sqKhLbniOpHlnqtIwxTXO26Lb37PHT8G
d+RfZRk8B77GT/rmGs6xcQvbyb26pkjjWz0qYk16FsoTYOfcsRxeQeRVvHE2BEX6SaAYsBIe1CzZ
HYZen2dUODI3nQsBUy698dhpxtGAw5jwbyK5201bIM86pBwuZ7ADe9SppSySVCldjR/9ghSY2wcS
mI46pGk3xhDM6hRvDNSRArNYbuXA645g37rQSboJFwUy9IEzI33TnxBR2WJ/9JO/geJXfBAxia+E
Z++Kc4isL6dkAZX5MUFjrPDyp+fn5QrFaUHiTKiMjHeabGlvSEXCerLnlQGVWMOt0jfYhQ77VyFX
1RoNA4tt7Q181LMsCdtmSC26Z8j/mjlOupA07nV1gwhlfm5F7ejZYqgNwK/JbAiot82GFofJudPB
IkHCGs+4Wz3PK5HZKqi43QQkNbaNBqNoHM6ZszZyhfXESNuGRe98ES6Kl7GjRbLzBSFfRQNAyyC+
OzlgoYWehRE4nKaaG2FbABXsnOzDjG+ToG72Fr/eSQhQkUa7P3O3AuXfHSM8djUieDNWB4h7Dtuq
LHI3G74ia0w9KxMst7Zxpf15woRnrLvZroUzn2nFdpsACoFbNubPVDJ+LdjjohqgeO9eFH/tYeB3
IzZRNxrUdwq61D3SrOK7vymvJnmIV4buDfSWir51eBFn4HHr/QxtuE4vOHxHzs9Sjzekpcrdsh9K
Ncg5mJf1nFE1syp/MYtKswCBQUtv9/uwpp5UQNy5l6HViNlOZnlyS0ppzbW5vxoMtSePjk072HEM
Z4CVlhJ1Pe3dg2rQOJh/TzVs47+/gIrR9iSX0fy8fnb6dxC+2e3DbVde45Fm7kS8MvUhT/Ig7hyW
S530p6jJPbtJSAxp0NA7nxAH9+vICsRfrujjUdgsjrnEyvHgpSEIFcGSmqHaYqI/3nexMpCSPzwB
Hi1X2xDLnw4p8SI0+4GDRVh76+MbbkVdzLLTnFsu66AkHBJt+2VUmhOYgyAANZkfSNqW5BwGRTOg
80OLmqd3lvlBnt3HG7MFCiDWrK0eIcZknYfcwKpGs3spsAg8hfSi7OwUiLyrqzN1j7hc+Jg9pmKF
JsE+WJu0DDEUt8JH5f6bC31/gcR7lT6hiB0NcZxSucmISfkI47YY+0DCQGtxqD/sPC8GOy6s83a2
YQ1nyN6EiQidDl486lq+OGUbbbUlWlnl5f2DT92MME2guf2DXtal1kybGuqSQQxho4AZZ8KGMRfQ
xUXVCFQFxDKQgrwHFmoyLaeS+pDVqo12Cw1zbPYw6xk1O7LVOHGB4QZLyIb0NZSNH4TpUT2IjZ4+
nQLEU8XgcgpwRFv4+y/SqH5zQI2N+qynH+ofBEeR7vwvrKDYaCm7uPib4n2/SA/GiHCiHknesn1Q
cZvWrhrVoGO7Kc03omI8pEkOQZWWACbmbHzsfjB6fRFDOwnU3fBVaO3OgPmwZYBPItKcvfKz6TZa
giTJIFUbRYLRLTFyE2I5MIGLCcTYv5eGAgo+ZcB7etGaCgQB0jRSJmEjthTgle68bG+yELlz8+i1
dfySe/pXsfiJKV4JbIyh6mQs+N6icrz0q6Dd6rAEIRIqMoBbYME153enzulZ1R1pq6D8smBXmXv+
G4Lu+pC5NsA7tEz+BPfE/fZT1bXMah1HTrCWJF8Mrp7WU1L6o8OGSBagiAqictApnNlmu1X/OECe
CTaV5xX2zOYq6smK+LmjlSCvSGQUfnijk/IsSSbi6Tp14TURXWg7OPzmj6eu1uzCAG5GrTFIU481
Dw2Lv1syIVd3gvWU8TWETA4/SLGYd8qgCc7eu4+Su5Sd/wdXIzWfcUcLXDspDEK6LVaJ+dZ/cxLX
Fq7YFUED2vPTkXYifTkMitlp8xD35j4cQpkGdLZED4pd+v9qV7f2TZ4LCrYsMnBW/9k5hGSZBkvL
wrpyl2mBdy77R4K1WnqEhsibN1wXTJ9r6PqmMAgDSaRWhzJ+ilDojJRSXgoC6gX6/f5EqO7jI42J
moGokIwi0fmAx4NdRFQtWluLtxmLty80PNazrT3lP8iJE9kMziX5mT0VWE7bAwd+GYtqKJtzScZF
J+6aa4bX7K55DgbvpaFNOir8pOww5ARYEgTukN7+UTh0biL61bSPnnQaf4jVAdbkEFnJdFxaIfLd
KQ2aCRsXFaQsNr6xwMrrULPyXnLb7eVxVuGjscQNyEbHDy7sANgSO/BiO8VLOp/HS13RWukZjjM7
+1jKuK5kaHRjfIjwiiZm+s9CRuKmCZsnCYTOCkdrHqsI6ANrPZ1Sk24M4VNPRwbW6k7bNn4L9Fvo
zD25jAB3uG2B2mbkylA/mKNKP7jzDV9Mn9WSaPZG+9dEZEl+rwuXqxtrSrcV5Zq4OVIrJvtz57M3
1AATAaDaUMKUp7LjZm+kAmoKx5I1mNTp2NbzsFZdnYWC17d8DQLTOiyjajD3/sbeq7Oz37x6Wa5+
XhIBp08eGXHUYDj76HaEEN2ZP1Inm54oVeUeE5lW5O0tP75d1n820Y3OzBVGk5ZfmfH2zMs/1Mwd
I8vd//8+hHFohaWcUzUTfLZCjFAAaoc+JAOb/L+vznjiOCaxVp4kL2TWgMHJBGhgmukF0buRQ6Hh
3qYt4CPArvv4Q3BpVqFLZg79hmsQYwe4KzgCMcX1RGHaEhbasTVGlkNcf4rwUXznT/2NlkY7qggK
QH/XqXSjJqjBDDfOG1rziajLSi93dRKf8h1rB7/OEsFSZLeFrgyHf62oN9K/wTjF+94Z6K7/v1St
BQ6lr8OtoLozVcTgZPjOEMcTiIkPpPixUKzTK304OSNraVwgUIFRjpNcq2hh/F/emNjV9nHkOKRB
R7k8rL/ldnbY2/y9caLpAF6x2xwOwF7RmNgs9GrdpWJ/WclHCFhg/5n1TZFSeWnlFx1xsSzW6OmK
pcUy1IBHZGzk70P9dzN/KK6/cxlNcXAiWF1udRCzRskHItO0O6dDHENgvTzQ2BJlVZVU5ynTJkLD
QjKuNGBPb3+Qm18lbcS2WJUXiNimf8SAIssDTU9fkoykRu0QzQfHRL6BGvoyUarf1Dlwr8LoPYxZ
WXsWkT5TH2o7DG1X0cREE+ZOvWrMwdovFMI84cE+8EtfGZGbJYq4dvQz9izTIiyWdOzfRPR0Abc0
3QUCJQU69jTxlon+qzGhndQBQbD2t7Ny6mTPeYvoXOFT2e+0QV71mYQxdp6aEy9AKjJC9ywHlTwK
0gmIBlzoMe4k3DesWX1SwvndqBXwLlPSEeWtvIbqIKkqPe3+2DdrpIIuyLekeQNfK5LSwBptXchf
x1Gep8AQo8fYJcgsZJbdm+37EkY20do2XAASnm+IijxzDjVqLCKIZYoBv9uA0skkoXLksYGgAUbd
v0G7QG29z0XqaODXddFZMuJOvawpw70TwUWSoXCmghhAWhyUQv5tsQy4hDs9tjJmHWEmDrCeuaqo
70pJBe+NeFKO/EVrX+M2ubTqls1yDPO0dxs9mNABDWdemewUBBpwp2/Oy5dUACBr/5J+DJOEFoqS
jgSGHeyGr5t0A+Tw/IhN0sLNnI2oHUFMD+AlMxawY7CNUXWwBoqv+SzX7LQo6CSpUcN0FaFp3azf
yp6fCaB+ml0FTp+yhgKZbBwykiBkt48Cq4vuxraAq7m5zMQ6l8mbpZ4SsKP2L+S1N79D3Cgg41xF
xS8214QCwBaUTQkCFdp+mRbBXqAbs8RPfED4QA9zj2b4xATkUbjTwD0ebsCZE1Zh/4dpTiaLoA+7
v6Ur3L1QJhIhgQ9qvJycnd1oeBFyBBkf7jPhJCu4RVmlLJ3PsTD5tqqzOgvpWrzxIxi5ylOFf/bk
z8tqnHPp6fMirAiQEK7Fgc63TbpGZenZc+UdsC9icC1xgmPt/89qrGYRB++4EYt4vtFbZGs+GVAQ
sEqTqNYcBTlvi3ZZe4nhY2HM3li6RI8wbiu70wYDDfSff18p1E3mmwHz+dzalistnsjUTaf+i/Da
uUoex46kbC1LKzaWRbG0XqxIlSZo+YPa0QsO4nbWcb12tjB6rqU6nqnZauPbO8byHzyjU8RxV2xL
6Q7ZPZJr2bCZOokt18CWjWlD8m7aqMgYqzMsPzBfYUEAuG/gaOYUFTZf9YkBDMk8Ue38408qvpNM
xcZuFgZqKmksJpKTJ8KpbWILpqEKqhW4cUV7HuBN+EcE05D9KRFe6fKz7sttl2cwnSeFjf78XPjZ
o3DRGtQ+vECgvc2OU44EBJbYkk1o3T0b6Ngokpw1I1CCzERU4wKr7s+wYmrcAefMw5UUAMwFzQ3o
6dMXfxAfgWF3kle+KEZ7A/ujXGhAZWpTWWqST/El5oJPRFIakqrX0Q4zvGUG+wkHNoLACcEahf0i
Fjlnqomn0BiQaTksHGagNAuxHLXK3GtPE+u11YbQhi8VliAHc09hVH8Hkb9vRvKj7dEkUQ2OCIQn
WRNFhzf1R+EG2dqtq1sAW0PqWyEf18Ma3JkSyBruLZup1aSn4ADhMIKuggj21r2rxdDUYm2wxmER
U+eo4948IcAiGiFUvYChkcM7ihyeUSPWtqp04rFzTx0QkdaPasEq17rHjcSEvcoHcW+WjvrfRrJ7
f8Lvklmh23ri0QTMB8JwyiN+bvXDuzuY5+I/QLX2VuMBAlosTUAj1Io5ZHgVYEGGpx9ZdoLn2ROV
RYQMa2fsvu59gzMbIKKffMg6uI3SnvrDKadcPZKfeBAcl7oOY/l8VwANhLFxD0sDCcKiMe0agzk4
IzSaOhlLNPaiysAFQadqN7ptXVX9r23OXBkL+UybRw4phP7eWerRCDuFECM3LRQTNRMMa8kNSapS
9ozqhwv7wgkWlg4SiTXGmwm/OPjHNoct/bTblZMXcxbetvYpl7ZPi2D9U9ED5RFVxJXvnSYttX1/
gJUZ9XbnCELR6gfWFZwWqTK6yjpoZGDb6uveuimfbFXRQdxidGfzJwilxE3bCEw6asbrPbd/wZKv
PY98lspmjo9VgCE3+YOpmRhPt+Scommwaw79k31i+Z7grHAQ17QKuEPVMWgkaOXdbwnCz+UtvpeP
qyr75cDjGbdzozHSjBunwo2mF/tYwxmZRykTdw9Z5uqa8YC095ImOq0oxCsfbJUBHeVoVTT9D8AV
k9sWhgQS4lp6kK4E7RIGH6U/1Y2b86Zk/NfZRCzjDtSB+ZZemwglX9lkKPLO+3LKDBRkckElSyRU
EIAqUdkNv7QJ/LFbINFQy9g+gTLYLEPgeALyrM1LN5FIfGwqgsLgwUb0yiM/nmvTEL3J3I50b6F4
n02bU6jsMJguwNq8c8QPqwWpeeJ0zXpMR46dIgaCsRKSXqqAo+3KU8VuSEEyV3wn4l6wXlk22HeC
AvMsbH1hFsLAcIFrEhG2oMmT7QeNoFA0ZjbtuyaaSvp84umhO9Few4JzPG1EZ9lHCZiJaB896PUM
QPATj5wIfFC8NRffJzL9QwDRosmnRFSpr83GKiNqV67PnFVitlwt3qZGcQI19NOc/lFWFexT6qoY
8yPIcNlm4McldzVrrawKrsIPEFIcfgpEh+olSSiYTKyYnWK/CVDpR9UR+yYJPjKX2s7t0CLPWpC2
nXeG51mfSe0W8046KdY09YqfoeWPyB8CThW3TOWKRYPsXc/Sg1kyU0P0xzR+l1bLQ7TrjX0uGurj
220q/pHe/adZ6ocKqgDgcK+sEKW01acJ22IheJ+Y1e6wTuwWdaF75wkjX8eOKPmuDds8hK+diYfH
1Hf6Z//91dnXpJIld85FEsyGrn/ZyLG0DjhwSdc0SN5e/bZIpM5I3jIFYPnLLmgJr6+g/pCTMtaZ
AjvVH6Gejn/QOG37XE60abcSPakr9FJRqNNt2zVyWgbArh9+NGUuMzhEdg5Sjiyea9rv9bIvvmMh
Jn8XOvCN+cwmFYJSDzB19lpoEDKsnPyCIowABJuBHUIkBr3MKCZMQLxPAduj/DSn6+eTzVT+C2gT
w8E+mF1VbR9rkehRNRuajL6aQxW30yOYJY+dr71e1sp/79bSVzXnovlovr73v5Kbg1W6A8cxhM6+
V+dgmqV1aPwRDINuYCXmqRuJQupOCOMU0OyUlxPYNcvPlSx5oQ162nA2c40eEiVJvLK3Ien44eiJ
02Zu760UVO1l+e6NY2hZPoE6s9n5Lk8CpbN1BTc0UPTveWriHoxizWtLm49KmlAEeWaeWo+xxHHp
bdSxXYf9vRSGA/woUCMvIJV5o71SB0rSy+ikvSdcdv6fwDAKdweME5EO4maijqb+UK12MJ46bGNE
6x5x5/De17p5OPDS/ZQy8GjZQIxZkNUvrwzObZMHU4mdGWMzRQaEZsKZjs+OU3UO7EW+uRW7zs2z
13jzAHt3ZvAr/gNlBRw8+IsBpuZQUrPziw2K20VNp9d01uahVHRlD8NbfgbqzTOv2gE4Xxdx54Jd
gI4WdMesllZQ3lKXPcC5PBC1OHZUubEUk/7t/tcELfDek2tfk3hie/82MlU+PQXwzzwpQGP/MJKV
WCLCvGx3fwGUBl3YkhcycNsoSO6bxjIWQA48SYf0Piu+Xi8oEEv0k+lmm992vc6w1Lif5YMlrmCZ
ZnhObDuiEgOQ9rV+56I9jOGN/Z3OPAL+3Pg+02qgvASk+/aWb5x2CkZUZj3z9yBPVgeCQwWbp0QU
zFbqUufYBsD87UjOPQvDzkke36g1Co8DRA6M9M0BZbavjd9ABluFBXbx0i0rcpfJ/DMEfgqgiWm4
HcGtZusQ0YEm7HGfo+nk5P/sMSfZgB/oVXt0PSwjeZxngJdUZpfvn80dfA2m2+KUtde839pb7rLv
uvrmCmFZKBGBhCjLgQ5NSDFDmYOKaBe7ut08BcB034mxurum4KSKB10W0mTNrYQ4GiM80YElG9dK
1ssbQxjgmu1F3Tk/5MdAACVK5jHmQgm80kTSjcaEDtvqogRSIY7nOGjJ8y+n39SL7W0HTtO3+Hyc
vowo2absbdgH9NIZUy2z7FpUY5DXgD7cABvkyWtzDzW84BD98Wy8GfeREkh+YQes8fJ3uMrPtrdK
thlD2an0hugTpwCO98yIt19Jeg7MohZEqmXZt6nf++J2+wDV58C1BImvQ5bXr3xnbln4OhEWQq/P
ZlSR21AUgQ0gSJP6xyr4EulzJ9PQw3JEBIVBUQ6RJJw/GY+pSL/qaqCGDXAI93LoOJkTYVk1zOAm
Wuj/kQr1uActCtf2BayV6bU5BafPRsctJHiozZi3LOoHWDGxqPlPDPvaOYUGIr9N/klnz79eqrPu
YplJ28c1mSJhw6IFaHccpB3TQbTDJ4pC+83NexNFPfjKiXe/Ltf8mYRvCmMc36KDbLWuE8XbeDBJ
MZd4cpWuSSrIcZf1JpE3IGKQym8kIX7xS/DqNv2CsBgMsim7Jeur+NZLQsdLUea0QKQpI0tPpJ50
m/RJ4iX6cbo4YFzdhstPQaa6HtwJpLhU4sobmi4VqobQIqWHm/m4DzumEZfhdAYommEUnX2UHmis
Uz+9fO/5NUF0DvFLnizq9d65TuMpgAilPfFTiP0QIwVRqJbeMIvlg03yJpk3epQOMLFMZMbN5cXQ
6+pMjD5bbpl1TzGjgGr0HkLuyyo2r1o+B82fLNETKVq+3oEnHimqEUdQkXBGM8yVrFd1B9OJXebE
rcL5WZ9Re785B/dGgbGCoygW7GOB+G==