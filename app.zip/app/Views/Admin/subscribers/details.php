<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrRR3ldNRlF+hZIRsfwlKrR5IhmzUwcLpzcR5xe1Q853wGojKNrWcFUSo2A96nko1JujeWRV
zvg7x9EAE60sxp6mLG5XgZ+bBHRx4cXBIL169nl6DEILXOFqqnHE8SMrZc1VPlsk4L6yAVUjxP5G
3tKOiPVBDGpcmGTo4kHhgri7LSSiCiYvMrpRDGGYB5dhHgETuMKPM4+tSQ+ZUcRc/DZdTFybhQcP
bbByJnbsUn8Q83eD246476J4D957fdGoo8VY6o6+HKDwlyc45f7akKnv7pPDPDJUYozvYUPpEHF1
YVR5BF+DshuUX2lP7JTrLfM1LmztKC82/V9QjPRKNSbJyYLMYQDqhu7jEVkf/6rRx9Y1lMyZ58kB
lxBZFr9tEdRoG7cwc9QiWbN7ZV5Q/l4Ma6gsnSyi3jWZdA7ikh6zyPhLZIjwf3H+kYqbwR/uEvOC
H7BitcFUWl/DMUUkEF4wbw5wZ47MPVZV00sGZC96PuxjtMDrYdvUm/L3+QBIwUZFKFSoHuvF8qla
sdmmCV+g1VflD7GkW3Nfb2qAmV3wSWn4dmFLuXU014bYUoX+QkuhykJyEx/kEtANRCGwALIsowso
rxpeDBNy9aI4rCy/uVXnYZvkqjMvaT1ZkH7Y/2D0nov1XuUMfJTeRxEl+ufyxe45ZMnkmLEv/zze
pkaWCxhuHF/5aMing/qqlzflRF5JxNVHqHXa3cvru7mxzWbregvx+gZRnbSDj8COCZYMlhvHhZS4
9facM0djyNgEI8JyClt8urF/zpGBK0MU5Rs+y8IkAK5YlM5ajuczlrlRzKM/XwRnxLVygm2iHe7l
NNUu0GnbIANRaVLC2r/dDc7NueiJC8Cfr6GS4oIVymoFwhjIrdmMNWvyGHI0bM8G0PQvupW7J8zT
69IRXakZHm4e8rqbGBissL7v2u+/L+BOPsWkRBlHwEOVvfrI618a7zgEp39pidjQTo41QwvZwBf/
5+vG4e9KZc//AdWioFM5TfKSNItkdKSrS5YZsR/yKwff32tigDfAfVKo9hPhhS+z/UxG7/Vbfjy4
I+CZzn2Mdbv+FM+pH++7wgxqbO5p1ATE7zOtLfM17/zXxN/cDwKCnaIIGxxtMP9rrrg8iDK5HClH
LbfNgkGQZIioWao2zUgZ6uZBMV7qXqe18jE4fRBaGVzfbAXVL2aNKAknEu6On3GSvmnCZUrSpHgC
dW57W1a8kBHqkhu6WwlaL3yxCkSbu+anwAjaMR0CFUjAER7XUAMLyUbDZBvLj6K6QBul0IRO396i
esVm7NediclG99yPlXMwn8Z7+6c+TfbFTQgebIyY5ZrpAyYc0l/J9mSWUlTLKIXl+WUsqd1MQwUx
wtsgMM7ILi8/tAqIRKM7lifWylAShjxtr6dVymN2IgLVkRXl68/r9F76yI4k4eQRs/DLM+9wBlm/
95K8jdfHQomupVoPyQgP1utfMt65hAzy0+jBMhZ0+p1TZpr5XKnfMluiqDMFHSP0M/DdrDD8DtIE
qkRD2Kwe0U3YlYsd1M9YLk9n8CwUFfx7p0k5D5BibxfBSNJhy+aCMLncIskYN5LDaX1+AEMWpKr1
eGHai4B7Kdn8sTkBysaNBsu+6uLxMAjzjCb/0UoP/hqEEmM/RhwktvMOo+Kfx0zUG/JZ05MnUjtQ
rwd/MbXPJ6X8BeqgW2Ko8fFcEaAaCSRNKFqAHXvJU9N4XyYwJicqQL52ujR5781lpSTwgzcEX1E8
D0lGj/ROuPfCb5NQGuCS7RdLacBXBRRwoYPl0wE8wMqf5aOHncAOPuPNbfdsgv38uiixpMZhofm3
x5ZJu1JSyGxasOm5tKjFiJDIGPbIRoZzeQ3v6nnHKWQPDIPQtpqLV4Q+5OGsZ8BHzcbAmslSUWZB
WhNSOkTmCXl7IbzCzUA4CzwHUIYWIDR5H9r35C9xHF7ggRHWhvC7AXf+IOVHsulmkJy+TscAnoft
y2u96QO5UYL60vAyYbOYaDUv24ijTm2IZ4oRGE0tnSFjvpO6Zj4Hhsp/6lOL1OhNd+/1wJCE7smv
SjlprLeHCYvtTpYJtpVmoqGC47AtoLmV2dLXC4yrDNrFrF18hBwPMYkDGPJAicDKmPJgtp/JFSJy
G2SHCm6EZ/4pDI0+MgHVMdUBx1Aw7RduksW2zOmic/+XLpso59ESAZukRyLdQ0pi0PTVZCgXp9OX
pDSNuVluCBwBvZJDhbB+yC6nNfnktR+MmQub8eazCVYP/Wn4CPBjxx31V8+0qgUxjtdR2wdkD47N
SKctHJ9kH6NNN8hfwi2xxCcvtWD/QotncI5N+K06Q3NySp+IvH98NJWljxSCp5JmjYIBqnzrSQ2e
S/+/FMGs5z/0PvcRUXLvnbQ4WOpAXS1EsiPqMk0hFbeFP5kQHpH2tNaJtJ3yBgIy3rvb0yo5fntx
Keq5bkQ/Nfmle6rAgP+EDDpGRT3EJ7ktQV67HpGiVZymVUDoBC17O2yKqJCh6ShlbESzfX4aSJhr
BHwPFR1XaHfFnr5e8ymoKBJ1VnxEG5JSRc94VgV1GmKjn8c2kwy22gb+r/3Qj7ioIlk0CspHHXPk
zu4vW/LO3Yifj7gcvSXhzX7b/kK8J3ILsOr3pHixx6ZUEdzdQE7W727qmYdRxuAluxNRMSGCSMNF
V4W1kP8aTaSnrKS8r8UDZYdxPsgvZYvGk8RDw+6mK51yeTJcRbtxW5RHVYi6m/Pt/xKAOOlD127j
LTA23lq00EH/38ygdhfeYuyIYWng1oF0J2e/g+3esqK3QRNslOdYzJ4D5GQ6iNRIlG8ICGEQCoun
LS+UEW+hLH9B/agw/M5INiiJQM+X4KtO9LHl/MX9QhMS43NASdp+hlvd4mymAfW1OZ4u0W3AJSTy
6mNwyd7e7/lW+3AGTkXj5je+sx4E0ePr2es+7BgJ4qVjBGMjxP8emfe9jAWlw0ALdsd/xsgpjbH8
rbNtRo4YAv+vH1aHkD27NAaTvDUFaOqbqwP67rfPHH3QYK16jSSsGGHsVUuXhhMSnaM32uQE/gHb
BdWuEx3HgdDEJTg+h85bjpkUto2/1Sc5SOlN8XGcNnPpXF+Sj3xaluEge0mNChlM+QdFFZRqUnjJ
VDAo95/K4zvfFkss2LUR2uK6hgSrwcr6yMzXoxDVMmxr1ypZD3U8Ao9EcD29HPW282aQuLffAmNe
wBrShba0SLPagN8ejp2IbPAKveXUkNVzKp7eJgCMhtpzBMNHX0WlDJup5+5hsuWCzfVH444IEWWF
Et4kgugiZ7YAJVuJWnLzvUkEW1a9aQOk745vqt8ijuQN4hyAsRYzkyo0koOXrylvK6g76lBnQZdb
HFDE8zuLSx9ZQknBSeEzLNTWWMZCXamq7HMrOmBfIlmNCPbXUflIhFyW3YG6S9QpRSV6vigkATwD
9kFWAH4jH7nuejC3Bp2Xl54rRZbhFSnYEzQENbutZLNy1+q91RLeaADquo8Cn3aJOs2cUYpmtN+y
xcnCWxvTziOR3bXhKNKeT0KEpMNQmGlB9xJ+7emq5UEWIZV3+92+3yS5pd2DWWqrKeETNFhglHln
wdmTapPWN8RJKfe/rwJ2YpXMQaVQFINL/jirox6x15kVdt2uinSq9VEJj173NdoANWkpFmG3mC0w
rODpfZ8Un5Ndz6FFgF0z0eje08UqzadgfhvweCKCupY6Z0a2sxbuu/iVZV5XxOgONz+9j14W/2lX
ElPm7DC0JAqlmJJEVmgbGDgz+YuLBUK1xy6y+pv6TN4BdxMX+YFyhdm1L6bw+iZkfO9KbYbgAoal
dLzQOtujHMpnJh0D53OBuY0mvjjLtSpe0nQjqvtZaXl+cnL5JWYzK42/6I3j831kyZ0ka0rAvSmC
Q2FOh+iCi4nKBqTHZEAFmsZK5AdKgG7+qjTK7yUvsTwhyOOlH1Db5NGXe6fl24C4bpCPSA0kHUuM
X8fB2uQo7O91av2GoqLJYv8OInCMoL0pKnG4atc+rznN+BcZGCKMp0PjR6ywMR+Q0512g6KM6aH9
7hBjhxmzkHRLTMdE4ENjm22DA3xzcjeaamauOsGv2h2+yXwkp9XvEHqAj72qt9+ZpkMLBXPg5A8X
kSkTMqGCDUSJ8zXQSo3/Mp3mxhs01lHCMcrK1EaM92cn5+7+TZ2qXGFrGW9SOVw+FwWHEBoV/uvK
8Bt95CxV6EBL6HSX+NTPZEXfe0FR0r/p75JqsA67fZ/5Eemn20EOBA/DD7cELoznsl3GySZmo9E6
o9DIUAXqnp3tG7SGDiKM+zGOIs9dUdOKBwHHiowVtgdGvqgcYTyqJo6C7hX4tIwy3VQwmWTcmktj
B9Tnv20hHurlsvg0XI+kSWbcZrDUKc8p2BXeDmJxK/jWXT6Iuvv1OTc/8Lxiisft/72jMGAXyy+x
/WeQPRLVmmd9VN7MHbXbqKEUG3r14bogEOJSmtzSfNXHho9COW8D9ewO3WPrp4mM1jIEf4Jupflc
pxRlyAP9r9QI2JFF+JtnrIt8l2gcJFLOoJKPiagb4KQAlgAOG8Zq3zit5jLEedmEMCFkHaMdsDaW
TV4AD2U3f4EvEHGEnnNODWjX4STg37bZrqpTWFSqwnC2vi6rkHxDloCqms+6T+YmkFvGLxYw8WVc
u/HTvqdJAWhrT4C3E87H/MS48F8ltKrAqngYuDEOLL9ESfd3TXlXw4703PGsqmlbXOL3gbHRlfD2
wYIHOmBRp75sE2JtjhLsypcF+o/Ipjudv/xaaJsyC2ZJmazHsYIjQqeeP5adFSgX7TdUj5kaVMho
0+3PsfQz3C4lDziLiOZvtnfVEWRf7gLJWHkl2gpTbKPHYgKhSOu6n9vbmc5k+ce5Eu95IcLN4iRC
Y++B0Rv9wxxbgpWFR0LlvCSwEfgVM7h4SIy40RlJaidbIpFTdpEmRTxHyHjJ5SeQr4hmjafJWV9H
KYFpblZWi1liuv6BJj8ilSyD9cwdQhf76ujJIOkfhhL84mm3DJTwYD3hWg+aQg3iGIX9xj3ZQquV
GNWcjCrK184Lmkh6PykabJF2m+mvh+haJ6ibFcd6M1RQER0gjBgZSpKmcry07xGfPUuBKkq9sSeE
flw5jg3biTOHwEMJlr897OB4GyDkyA53NuBFHPpnHKDonS+rPedrzAYpfzeUUMV7H3N/H06gXlhO
d0AatoDJGhO6C+GTG8AUlYjG3RByQipO301FPdliQxzScQQmQaEIj/jyht3l3Obj4l7SqcPPohDn
NNwwifUH6Q4vWawlTC9QagG7BWEoL75C4BSYUZPi4hsXh1eMap37Qz7iAuFyAIvmdZrsx3/rKGv2
a05SPXh4ClOgZ8lhKklcd6oBtVbsJ2RxeC1AwN3QJFMoEDdf97fa7dJUg/XtwrNQ9yN/LqUe5Zi3
CKh3yS0Jr/aDtCwxokinbiecNO0Zg+UbeTrgPIzlyVdxBQrJYTPFkaCUkQfrh8t7gU5hB8DWGT0k
/XO18nRFBhmJnvVsNGU0aE4ozBFpCly8nbFVEV56zBSNzKep1SnWpoGFDUX7wvTFIiosM07Ux9Yn
DO3qBK9Pj9PNYpvk3z8BnvnI0CseqEDHSw+DBHSvpG1odqSsXPyjJ5sHzWbuTprKwqPi6frfDG1F
tfSbR3flxK8d7A5Xpqw6qj3+abAFe1usOKFPD90xNlRHiqJrDKpMY+NJULXdy6hEsId9qw75UUer
S2oO7cUCymbE/uJSVCzPKbQ5GYYO0p8uKBlDvr1qKe+d5P6vwUoSBWcda8hRwoRwWYb2/j7Vi5kK
zBQ/+ru70RTBN457RGspoxMN8yM46xHTav5qq9zVvIc92g1ZRuJvOz/B3zlmryfhET920vsq9OBU
Lr8FzuXwQHAwDAHuVJZfmY7ty0IqWoa5BESTe+77EItdO/aS4BCcJXa75dtUDaUGwNLDbO/5VPWk
BoQMyELxAtvPQ/8apDK4mGd5R3gbpEUy3n30bwKugDQX7GWTkw+r3iLuxIiVOCvMhNnVqiL9Jsx5
XicPHzz/mjWJNwyRLP2K2IaaB2anOOqCNKOcx8RaPQYIzOky+PIbXBDifrNAVPlduQ4EA46Ch/Uk
w3k23dpehcT8bdxKjVwKOXI1iHgqUq/alaN9xtlcZ8mFaRf1Qtb8QUB0azFD8NDkjg7vT0XWBFWq
Szi6xdOCgOYC484Uvhyt/BWSms95IN4eimNSFqqDC/fzA4NdWs0gn4twWOtw3F5vvzHff6VzkBFg
y0D7YvsGonPqtfRQZQ6u0C08tzlLVsdGL4oZiW1A/Sj1aEL4M83BHOAnMGldhx4i4M8jX99pyrZn
+QlJk/VswW5XNyMj7cV1nfXlkYF91QN0aSLZPJOhtxLx3mACHPTLzXoMsFZYjrq3HLwsFxlG50f5
RwXcXIfy7Qh6FvPunsCtaRhvEnpc5stmwuYWdyjsHG2SzizBRarHZd1TiOI4WKZM3mBLL/8f8MR6
UdRl+4GAEAvMW3ZZl7X7n4uw+KCBErsGIK999iuhSFX7sK3Cu8MkEK0ny8E1u77pE/PTR06Z8KLU
37l42//9O29udNlJ7JurE45eIy3RSs3WQUHse/OE41h01P9yPVtbk/09DHGBFh5hdf946dxPpgyf
xYLS+EXQjQaHHdohINGQ4zIBlf6khcow55V8j3rctecTzkqZ0fvRUaQSevrEu2jAO2KfjB0ma8SH
om0D7tdk1cEGva05ZCw9XCzvtTX/l/fXz9VsRbVXzrN16O/RVq7QWLat2wfLrfIVeOjQuyYrCBBf
B8lH+lrL+Ls7fvSnwoM4LRPkdhGg13iN5e/tOKYIWVlAWYuCd3WJDr7YWBpgrYD25mGdN3yHODJ2
skHoIqs9Ig+1PMB3yS3xjmTs2KjsgwrrNB2hJpugO+bd9ZFgGBgCteJxQeCDuhe6WnG2ALo9pTjx
h8rfYRjaHfcczQzTve1QX+85s2oIt4NZCUSZ5Cuc29vF2/1zGRjZuTa7zrPergDmNIqFJGeax86u
Nv0HLMeNURnoBtbgaQF7qNy6Zvl3vE8mCEVjZgzJMpE61RePhm4jKA+mrXLdO/yr8e28Ei67AQAT
awuVMJ8kosmX4fI2n1Nvj87MTS3iPu1E5lteM3s+ZyNRVQ+fV0ky+J7jQQ2gUsCCQd4L7FPmYhNz
+IC6i3gLR1pve/pQgUNINhlDddowXioaEdn9RMWkgUbZ3gjr0TWkgEE6i/RKThDmq+Bs7l5CMOlt
W9j47MmK21z9OeOhYQgngIH+9BoYkQ6zD0ZjEVsEE+r8SkcdDWpXwuVEwJhYg+Mq2+ID2BKZD0ki
7tLzeFS5TBSLl94T5ZYvWPyScwYQHzXzT9zFORLMCvrBTMu4mlO3JzGcAo6stAcETf9VwUZfp4ER
D95/eua0sLBnQLPDw6cIYnpjmZRRx+GpVQTESI3N61fZLrr8+0/Q3qMmx7uSy1Tgzw8BUTi1c3Px
Ozg5badXAdF3/oPR9W1nbORvTEw2x2kNd/pnuQiln1i+CovAIdkPQf+vj21T9rlGCDSNQ5jFleTA
rTj77FN4uezqIX1p2gF0qhTeRundfGWxCbTUuVXP09MVStOcuwFr8HRu8tUrisKS6W7sHKtlE6bK
H0+5AziIWPC6qbpxTgpnwc+Jkdk+8E3HQY2yrLt6UaZPOkqZWP7DnebBcQ9dzzGUY9Ttj+MK8fG8
vjBQTsT/zGfQ4AEH+BILDKJrJ9mZRSfa9CpdEjSUJbhP6dTKV276w4Zjtww7foQepynlSG80LCzh
aKUHZTTm8a9+jgR9aXbeHg9g3rVAlQ46HP5AuLH+LkTdtsyCRiQf7nfQ3eKU2T4FXGV8rsIdw0jP
SBDsz6y10KS9ejLywM1gwptdk1NBA0z1KXNrtKaE88Kr5ck5izMvWtW4YZWWdcD0beQs5HK5QNj7
AHHWH/YIf5Oekc2IqjO0JRfX7256tlw9K1hFnoOmQWZe7csdegfyvLO9gXkP3LA1JcxYrvMDASAs
RLQelpC0Ppsnx1hKfuM9QqoyIAPfkQeK0sEzjh1HFsQBeq26432yUkjSG5tQuca0Fu6a8UQtu5lI
StvHZcaA8IEErD2AAS+jchcRUUUZxSe/qIIuNjUt7j8LS54GnBl5dT7pY81ujUmaLU27R8qunC8N
Va36g+L6DESoPBfJt6awaPCVB9ZWxtf2/KCxfQ9enio2KraHiITSRPovDVW2vtUQPGOJ42hVFyJ3
Kc0G9wLehqnI8ql2mbdtyFwDVbIQfZ1YBb1yaShe+XPYpdlYB3xDSv2HfLdofkCG948S1vVrUiyH
yGM8HR0pyIZUULpTLRd+WzN1ZP828OBCR+93IokXWhvYkM2ekN0vnVuLKHONVOA9S5NsZp51q7q/
rtTqFH7dC4INh3IrxL7hKe4nlkrPHjvCyeovMhffGUQRksOjRUec3FseJAX6gzVBQeTIf2pQREDx
BH7KQBQywRHJXqUU1mI8qx4j9WAGTuzcrhgKS9lGfkFWWrRdmHKjIwF0B2clNtoHb1Kb+QMzhAk9
uYFspuBuUCSNeqpXfMNhUjfSt0wjpXGqb3SI30Tomt5pUV3aslCQcfF0QgB9Rc2VtJZU4vYafbRc
rumWEOuGeP2WYYARISoTrMEThQIoF+HRBoNatYBcH0B7ktoTJw6FtlvvsnEnfL55S3doB8oFIU2z
58KcRhU5ZoeV9Uzgb6XBP+3fXr6nRxnnYEsHT5Vp0kwki/598aDRvmHt+h9DqeUYHb6eVG==