<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr7qt4uqToLXmHj9RRBD3M0QsZ9VFufU7SERc9QKu5Oa/HaLIOSH17u4sHZDv3/Z6E2j1TL2
b5X/oAoUEv04VLbWGcV8Anhrpjht+EnJ1gcQz7u5SLd2XVw4XbGJxFTES2eChi+Zx0LTcKzlIm5s
d/oQlY9OmK1X1hmz2NthqOPYxiX4ixk5d3K5e5CR1WKCtCIOx7dMiVT3QGB/LmC3k25AN8DQi+kb
SUVY9NHcnNwkbQv/zjM+71kKZLyVQhr4B6irKK3xX+QiAgcq7Q3re4ZJvB1zPyMaUITPMV2YPDZz
KZg7Ep1LuonK9zSDL6cIE+qLdoP0PTN4knmrR0K+zmtS2vKn6/4i5kMMpEkhH4fB5tieziYRQXbR
5fDuuDTUMi2Q294UiIpcqkL0zi7Sva6zSj1rBZZRyTa1H8sCJX4E3BDBKwM+lPLlY4mtLYwNcHD8
mOtqRkDItUajwualxRHMoO541WMYtjMZ4LMzKHrMRw9vN9dbMN8mkVlNgQtvDW5jnVop5RxYVbPX
HAIv6ZNPZ5AscrT6YuTlu/xjuJcG86xm3GP82WTshn4tCKs5ZkpcuE9hy3Q0yHPXZj+KCfiY0hnr
lNQjn3y7wCqENuZQyer4tIkugpk+oeDW3HUaQghUrAeCJlhw/j1h/rifjG3t/SLMa9lQbG3kV5Og
MQZ3jpHIrfkMddOaWENj2JXAxcVKSVQOJQTYFG7rlyD3alE25oTGWYD5OWuiAutiscZcwOptKJwl
l6RgzDBx/6WuBc30gfYECoZREgGj9GQM9V3WmQ0Hf2OT4C5BM8bOUnBHjzvYxw75CNKuVJdTxzn+
HbKmdvbGpbzDBc+rcHi8VirjSGfCnhgt1guB5tAbPqGonWSvk9cYpmH9D7wnRO5OJ6wIosHFKNyH
dtOWq19JnGq2l4E3YBG29VW2peyUyoiINNTWKjx6sowncJaVejHH+NW3AReT0flu0b5W+qMQcw5N
JlRgFrqk0X/ak6iPfYVW6VWS+/wCwI0SMIIjMPs/3HMZat3zbujWC+Lyojla9xPyQAQ9OS9EuYaS
qB+Ok3Qx23Fy6dPSP7TKIrPbGWRTqeUixjOfmEQd8BNmqvkMWWA1jwFBqrqw7BElkenpRL+O/ypr
4gpSYBt4UQolbH4wey7/uRSc4db28Xpnull5t4BDlHoxMvES0QIjbMjSv5pvIiyBwZDH0DmiNgYv
Szfs3NdnD7hWR5bgG7E/C9xpPUxjDjg+WK7T/4RKMMtDmscn6/8/V/JnSerOopFwvAfG3H9ea0NV
JmBeEOZxM2zRVsb7798kn6FgiLda1zbU2+c4/PpCnfChbvG85hnigFKsSlyXcq8DVWH6Li5Y+bbN
4QmoFwqAl33FKjOuZqZ1RWU5bjYVeiRWTztPvYR/8D69iBDCzMbNzSZSDZq13tPup0KCrEj7IhXG
/AC6LdHalUovrRVT3dxd6voogtL++tLElBngBaoKDGE3MrwJp3qrTFp3TOfCQyacYCJdfSWFJblG
9+NmvlyBewNe5R04eAdEx3SkKmWO7bknMaqujNxo3o+KD+CfuYnqI5FyACAQygh37aeheJU78xvG
Urnqa5dIfKxM/pSx8uLFW4n+Dt5I0Ls5QpK7WTk7cxoVhFEu2W3LLjf4k/9Gtj5NW2OXny5SHxUn
0gN3cNaimsUHq/88V2a/Y7MHOaAdXElHvD+YuIojbd5Rjzt9L/N6VAmx4+boq2z185hotdb5b2G/
/BL8nvLWRIsnEabhIOuc4xZ9iFPCYEzsxghyqfi9PPvHY6QxCF0jBVuaIiTTxPfcykCfELJzWsNR
3HguNg0AST3MzjIbFrOndEtAHdm+cGGhgquHNjl6VSJOTJTTAEQVr6nE1ZX37hUa2rMZltki9/fV
ADvQqMKAAetsEf6KseF/v0XfUSlUolx+n4+JbqjtzLzWCSeKMRkhIVgX7JP8Ne+9rJlIGqvZ92UQ
150UY/bHZ8WH9nVmIeh24/NXOFCaU4niAvhieOGB13v5ZjZBrg6QWnoRTRTOz+UVHtKvx7TqXXCN
fl/cp4Jp5dhfUsjkCfwC24q0Ig+bukiJyL0wvYQGjII3Y9FtaWeQoe28i//Y1EZaBk5wbUHUnRCQ
jqH5SaH5aLjg8e3InKewBtj6ISE+t1tH55plKwYX9EE2uhCXbGyJzMCiRopu1jNqLrJMGfgQbl2u
as7c77kEZ53ALH6yoNC6j2Tzvi8OcCx2C3iMYfpuDV86JBal48luEd0Pimf2CGz/2tGMi4BMbDz3
tJfOvlIWV+Zimh+Hl5/fOO9J9gt5r8BFuW37QSmtdFj00syZEik3xoyKW6PjhGkrWhg7QriK0gCw
Rv+bNNWzLBP25O8GVfYa8oW6T06lX69u5SC0OCM8wSZ56EXEEkffpPlYhidCyc8sepHtX1toxTqo
iWVk1BjOHthMKZRWJjdnjE2E3pRN9fMfjP9g2Cd9EAFRTaqTc1CLnoA6Js1uDEjx/Y3LMO3PRaNa
bpDAUFAe4A5NQLmJzI9A+Iz1EjlHC1Ka0ZGDfXli+GG764A6P5je5UvrMEJxCZ2rKuS+/2UYS+MH
8dn0mOEo0I3bW4O9mvfl36J2MwJVkilCDSh89G1a0uxfbgYU5+4gA1R+XaWg3AbDo5ELc2OxcML6
9J59A6ff2Lk6sp9aSJYYqoJ81ceZMGEFguM1ub3Z5g5r3bQM5jUcJLhsMeneBrro8CHJYNVO/nfI
b3Hz2doZW2Jm3O8Jc3RTGDvTZG3z2vXQADPlMCdShQVihf1ehDJQCejx/R5fm1cuUlSCAg2BdEtj
grqG6luhbNtU/SCjPmNPDRY950C0OOq0uSIb6uH81Nk++Ju2g6Y6pb6FoYLKeiktv6irBuOXvm52
j+9RVzXVhx/WxUxBb9nBJMUaZSs2+PLELS7ywwcazB6WvWwIPWWg7FslSTS2ZXUiCxSAit8Bk1U9
W6Urbh87kQIYB0gZJML+MhKgRGjLpWVEY9OaDB2U4VDn9BQ+nVMDjX7HgellePyCiZ0aDT6DXjZp
1fdIshTT8PkjeIeCHQmKn56L2EJcQ064bnWASN6SPaP5GWSwp4CxMpPyvhyIQ/ddwAm7auRSn7Qc
SdTpPb3t7UradivyTrnU2PYD3w5grI7tsn7bXsVFnz0TqvB8mlCf9u23pZd38AUD9smCOSmCQsQS
a9JbInBra/cjAupnKGT22hQoOtEDYZfCPoNJpSSe55TGPLAQiDynk/F9iOM7sz5MpQgg2Mk5sWlf
M1H8yseqBVtVQLA2QRJQbE7yN29PswmMdGkWwt/kX2t+I9vXRjR78HbomiqZyGbjtLPrmpEWKupJ
swILPrmmf4uBl3vq3ZOkVRaZMMjA2b2jgf06W2YdoBf8Uasz5Bowztz5oKCIaohVW+H4c3HRaSM6
vsOvVi3swVZ9crcAUVyNmZV9oXyJx3R3S2WezFePdBJ6ZKS3u+ZXwr3ofhmrry8BN2SAmDLbAe1G
q7CIufz79aSWRXI2JcpK1OuRdZhGEzHKSMC4x4yWTuEMce4NCr5HWchEKhpxSbG3KGKKqrp1gEqX
P/cpZAGnGpyQaG4gu1kDm171qh8i6wCGKss8EtcGNbkJlYPv5fkv02ai5k1V8isdcPwKFtuiSvqf
uBR7m5cLgNs8PEEnrvykscO+d5kQoZNWxosAveQD/tKOHVWivnJ/x9JqyHfdP4xYosMBX0WDchO7
7fOxol0nqFrCygdBsCWj1RZaP8xkKfXAaufLwqYFbNRInEyDv95GHB46AZZ1wC8insa0hlHe0fD5
xWidecgs8nkv42Fsv8k59a8Nb3X8UMAQxQmfr8PzNYLPO+p8dRF3GO0ZSTmvghx79+dDE9eXbSLs
QKxs5oAJSXugNntcddzd1FFjxbk7b6ifyq8O9K+RYb2xSkzB8rBqfUBcHD49CJz9IEqb81VkFov6
JK0ZCPvMrpQBFcH/+2dQeLUn+DDN+j1eMoWxwCBOwMdxzUiRbt1m+Mn+S3DqsZShWOtJjcvemP8z
8kztIrO2X7PpMnoV/Jg/70t/kdvw+DXtzxug1cmXn8JKiVtoxT7oW87OsTYRXLgQCV2ajYUJxFae
Mit6WHv0QBreeWh+zvWV4LgH73sBvNSlPn5uvLab5ZNv6Ss9Au2Z8L/Wru9gbGX+5H+1nTRyKHm5
llqB7U3GsCRufEYmaTtMw5O499Xo7F7aLy2f1qidYlML2c8rBeNWKVUWaK1ndro421ljZn6ESmQq
acpKNK2tsBQz9gaAdIhcyEEch9foRLbE3PbcCPFcqVnVaNSqXd0ziHrGQoaz04U5njoUWj+gRRDH
tkYoZlt4UjUwSP0inFraakFYwebUzk1vPckAaj+hlGI4rd3v3v4ANVtCyNyujFHW/1fxZELDguqV
vSiTrQPKJWyJRzvgHQ9QFGKhMttNIsGc3EY6WfTDInnOTR/rwEJm/XZjHJY/VznGmjCWVHSfZItk
Px7yB+RP2tgoO9V1gEtwbHwD8gX0VfV9rqvdloOrIS8EUfz886AwaWlh0vvKypMEljOVy6uvpfZy
zSQxRHJtgbqwvXkNFPPIv2RGxd0Yi+DMdAudWjLiIj20HoU2beF11zv9+EWsxfhP1jgEJpw73ZVm
eOeDcFK1bkaGZA8RDZOFShJSdccnKE7C85voof7s/eWeWs4w3C3JzaTBJJVNpbC4q0dYq5BC0cI1
ep8TSUGcSKk7SaXDjSZFcq8mutTfN7G9mHhCKN3MBV/imaDf2fsyDjfXDbat3v6Ds+/R6bs+ht90
D3FADtagthiT3dCqNnxPAcgdP76LVsuKJqkeekNl7/Ho/urhMmhO4OmYjTO6mCP06MBETzxetDMD
r1zPxNdR+fsrSg41jpN1Q6P10j1yKNJrbKrQkle6JC4hrFa4eS5dvKZrg54czPU9FMwAxQ11rRAf
COnFQbgR5Cbv03S4+4n7hzo1RPUcHQmgrzc762j3YdPtGXjqK/eFZFQ9DNWm5jarEQ/rRjww1wJi
NcYQfEp771Ib1vZPVKALZxNOx0y6KqGny051P4CwIRBHbSDOJNLFoWb6kArfo2ytyNWdt9DLw9d1
yDUlSjatfnLx/QJZcw1VPVXlXoTORQASOOYmpOeP+Ln1tBGzfNNWVoaWxif2/m+32yNclZsPf1LS
63/enWGXYJF0QWNxDALiYG50CwYbKiHxidzTayd1kYs2RgnpQF/qX3WoQzqYH2wGQapckZCEXs5Z
kBcE8xBbiv4H4grL4VHdJWnGINl1b/TAmOKNn+4tkHTwewgytHgd1R6VHPlVJP02YMW2BrQdFWr0
JJh4C9A20093w40o8mNvTJEWvXB1o/Zk0YghEjlEvPmZPyH3aYqFSSyamWZsJ5CRWpCB4rAw01r9
JQPZ2Q9bo0TQtbDFuDR3U7akGfo+zTosWg25NIkcJ3lFIouuOoF/I0ABhJ8VnCGZsYtC25O6kipi
zd3zmXiXSHBKdSQh34Sa3IpJ1gRnLr0gZwG+24P1N+YX7ATfsbKPIuCpB111r/2bLd+ZKBkCD3fs
xb/00A6B9KMDM5PFIUrFI+S2AwIXnOO3YYanS4hBQQ21GuQeH7A1HNLcRVko5l51/9eOPpc/Z+ap
3U25rQLhOmNFIeVR/wLY8VefCsB6cgaD7jPPwRuTsjTp1yma+6RLrFKi7VcdE2/6oVBIuxAu0Ufd
4ujvNNiO+X48rR2qsFymwQcXlleNzugcDJRvEMrFCS8pqjzd80oNa6utUUxUcUd8T9FM54gYeDCv
NcP/rF3lQ8Pf7qmNGJ0mlDl7OZW322e1eT+BTOUt3UEq2FsvOL4gevsy9Z1u8v3XG6Bp9ZxX5hjd
QmUyzi7MyUsC8Pw+yfrkUagi3vzurG1aIFwy/CiTHniIru9rSs5lu3OJ4tAZbWPzuU3N/erZHrLF
dPa2TOM8OjZ+cuL/vijJdS1zEwq6DqCe+DbqO51+Usckbvvkz0H649D0c/7wWvRDdsU0ucW7puwk
bBe86yPtrK3Z1PiS2szkhKK4kOQs+uMVZdKaFPZ81iO7woS8zvtFc/w/DZzh+A6BUuj7WZlELOd3
15Gn0AhOuoQNNOlaiQqKYFgikHWL68/W3Rh0eV8ms5Y4E2H6SLKLLDu0NHwFm1+p0BgqZ5phuiK7
Ubuh8s35SPC4kWdKQ7/Uk6BqMfMIaTvvdY0fjkLAfYTJOrbqxR7ff20ZgsrYRETMvnl/xjKC1BFW
2LF6Dt+vUYhXSy/oKDGXcj1fL8qIAEu7MZPtpi1eBDBzhuaFd5kTj/47zdaYUids72aG2wIYShM3
JjK8zqsjU1x+lFweAsjSef+XDRw4TeeJkIcEPsLqAwTaKktOh5TpS2Hqz23/jM/vrfh7EU20mct2
taWLQBbcmscj2oERwMg3fE33JuZ6UwHd/41gpSFde2I2zq0UDTKlWVqHG+trcr3uN5ySwEyYd/Lr
h6DEMlm/+EwAJHu/uXAWbV9674EhSwzl6j+L037FvAup5zwNFRa+P+JDDSOgIXFlliZJ/IjrL9dl
Y34Y1Ybt0XhswcIIHX3GsgD/Xeuh5WSm/NnDVkK0birH0m3YD95TRVDhfrneaL9Qv5TGkLRJ7caz
Sz1gPeM+iBDiXUkpHs0YbyZuy7S9D0l/Blz84oR1DYQobojcUnc9my5GDDV9ZcYyBmIE80DMBr6R
wGDubcIE0VNdChIQPqD9obvH7OgV7WC00rJGhua+TZ1MrHs5lDX8Qd1tt2T68CcxOl/SsdcjoU2L
I9nXLV+qjV5D6DeYehNewxfTWRLLqCl7s7sHu8flKyPmFk9AkRd03RyTCVgdrwsVRdjI48zn7267
XSRDZ3/xsjP3rXFwXAoxl8Edo3E97CCszCSurjTwxoLSbo0AR7MNRyVN0r5FKKXeWDRC/7EVCES1
JgOC/JHRyOLEQU6zYWSPqSPtjFvSBIYwPwHsZmH2N41gdXZ55DJrgjGKO0NecexrR5I/7LPvFXrr
JrC9yTV+zsZ9j2EBujcK5rWxfeOvN87/TMez5G394Re1vYX3wR0QP6s6KoAWq+seswM1SxDg299W
csmG8BYl78LBIDH0+7quZ5pIxB7Xy/ImSk+tqX2l27XKpsAxUGjCxyyQZdVUnMfk//8G+uMzJ7VK
Kt7RMyRzwjspdTopKgeu3YWLbTa2HQE1da4Vf2QMuR0Ucf3kQtAmTT17zPKwpIi3UWW4LCqE2Fdi
bEKA/317az/61UYZkJ9d4+4w5evqE8eu1szTrK6cmGykssAoe6mxvMO+C9fEauu3RU07OiRlIcvv
t/acTsoI7TJxbovg4UyV7BF1HzMYvJtZg7tu7ZOlCU210A0axJftSsWZEBhAePT8DfVIs2/MGplS
EHAGEIHFKAl45zJ8zUnxJ76a7/qYOXzWJBoKLHtG6+BiQkgot9Ny0jaEWaS6iTxH4j6DYZgE+/A0
LX31Axe1w3v/a0dBSddmeK6zajAfjqfUNlV+RIjZgzVWjnJ5/ojjZVnRp8BuPKmVd8m4zQcnt0ht
/6ykVDAYu+OaUzUhGZAek94C5wd+6V2aEPktLwMtWi6kTfyxZOE20ezkzmzjXcEP6p96P4LTvVK9
Ba3mt5p1+Ob39sRsNnvjh8I/F/4PxhU8k5q0L8J3jqxeM0mh6n3gIfiO0Wdv3ieSya4IrYYknwRP
c7Axxn5WkNQMwbYw7H/Wq0UeAgOmIsR8KoJnAOWXcQR/bTuaNPmMl0aoOBGX7W0R3RpOUeAG/p+7
ks9XYXQGamf3oGmhPTTGXry8Gx7bnQl/IcWiUAdUKiIr2dIiiUTe5+Bun2BzX9OZbCscyBsnYAu9
Kkcxqlivu5QVAnQZXauOLdXWifbHI/sxKGeYMxwwuNvTh2N/G62AUtbcZOAVEpQyNfxrgjzSJ2nf
r1y5AvYUUVtGseAREx/oJDnVah8UOarD4ZWapoghRByCsYVSoqNd5G23IMfWGU6ZcuN/PdK/SFHZ
mYhdFc7P+EZ59fOtq3KWtBw+9ghZjjhVPUjssAxzD+evpix8YWrrQrFjzNpr7Az5I14bY5DjW2no
73u6apbSFzPxADdfZY6MyeMZ/J/iR45Ivol7hVsI64gWite4la0JXOvNokY/d1FmTIj8fnK7V1cj
b8ah++eVnlEakKjkjn5G71fo0fwENw2G6LGf7Z1eXKx0nvPjUP0KGh5CD2kr3NXze9lLYiQsOw1u
1oohX2DGKy/g489SUFFMdIoYVZ/SWNfHdKCiqRUghxm5hcX5jTaSbyNIjckmIL6x8BgANvUNe/fR
URAoj6Z7T1KaQROAnOOfdgWgiX6NBnRe5qhw9Mrm586K2ZYG/z6+upVoD6i0JUvmDKhzFT7XjU0T
SmzxS5j0bve60ODP34mNbqYJpk88CuvkrnONBCIbvwLyP0LwFwFn1nr+49IJ6/j266p54FxcBB8N
w/dhyQVZ+HpsKyH6i/B1fi9IPHxAWffirD7bp07Qn7uY6AVSqJETiIbMoeHATQi6DiXQs3U5+waE
5x0Pvsz+DwqrjtK1gD6gbTqAYyQNC4qdIuQYOiLCcavKyzFKsXhNKlpfBD6I+V/2qD470LMsApZR
T9xIuHisblMdmYYjA9VNsROZnd2nHgHRtBYcfvOvJ1PCXTheo725ei8eoUkYo5gGIIGIMKJUN1k6
P1UW2cjKDbPtUrFguIFVgvCKtvSd9+U7gx2SD6uvLPn9P49oB/0eVfiFZUDmpGQECykaVZVS40kG
NQWRFzxQxs6mG78BPqOIJplYHz/nN6V0s9LcCho7gDTYKVe=