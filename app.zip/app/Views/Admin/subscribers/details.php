<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPraXgsNYmozA+yy+Hgo5AqnEQXLHrhSWGk4/pW7I/57hgYVgrqD1rs29uoh/8SWPyIWkqbhd
eoYJnaec2uNgA80aAYcyuuknkKY1pUn2hV7hnhTJZYZzbpw8htYjECoRLB9KK+JkJg4jqndUuuqD
tiC/rkgwWMa749uHwmmAU+h78bqO4PnQ3prEn2euyukxbG5DAWXXzCQQvd5nwx8RKsqHtVNB3haL
B2yLvpe20mcK75nCM3c4w8H1Bhn+PvDfysxamIeADpHZv1ITmSJY4lsWpyDXPuUQ7ARLuVpveeZc
KfsN7eO+nB7XKCIbBib3c3/6MZaHMCWtrKjtf5UHDV/oWoxf4UJeq7SzD68z2F0ccd7r+1t/Ggir
1rfqoL2uFqlFVP9Vp1Vp52QBVfbY+gZc2VvcLx1ymGMsC4un1fjleMvuxAy8KtKZ5S6seoaAKFLz
fN/I/n5qtsVSIWnZHfGM4dAPa7vEVIrQb9xYNNXeT+Qt+GvIXgVEJVM4Jy+iKXwzT67X2fqL2Gn3
hSQ03BP2xSOzA71C4S2B6roUNqEERGPPXg8xbypEPaUrtk/9WowZZGmdVQ+6ukQQPXyVQMRzyh/u
LlsiLD5EW0R11k/EuH+7a+BWyWQA63+M9TLuOnHRMqUQ8sq2O98YO/yZxchymsL/aOFN+MgCgkgz
BFxTY61Zuf90gcqztF/qXAoe2rejk5ivUAVBxqw3Ahb2iBX8ydL8FUOcj+lk9WzcQgAQZjUYVs1H
tfVOxYy/8DR5su/K1SPiVOod6O9ICXWZ95q5RZquouMQ+triucgN/pqfeAuxbbkIzav7g5aF/naY
aZSjlXXHXjTsNfI069xBm+ggcF5BhBAHl/M8ydSREZSue8XRz2lwX7gGlNDIZPok1f53l97HHddc
93rmkpAWwCUEYNKzW74fu+aCxf0A7mJS9RMnAETrx4tmEhbXXwM+ijsbxr6DV2sjkz1kLAuhwqgj
tvHIGxGNUna/Yts1lf35YN+L52GzP+tyFGdtbz1M7gMxwNd3dmDprDYxFMetrp4U5M4Qd9W/gdl9
h1/ZQX54LNlW46lQI1PdMzyPvbMdpbbZgYtXWAa/VGJo/YF2dX5Assw0MHYIcswPL0ty+hOhSq1i
4AH7OVFFMnzfVqPmHlw7O42vBzmH3vCNL/tpCB0SGqO2S0mgd4kqGT7FU5bf7BRmDhskwo6Vl1rf
oLWFU1idtaszVpxyLJzIG29klXeEWh82GVGDXeBstcvOK149v3JpLCsAdRk9TcHtB9Zh9eTxnTtM
5mU4mfiGze4fAR5guqA5gB8lTyTYq/thkzE4JXP5NSn7gqHRhXa5vsNzfOhqkSX8QX5bOkL9uq+j
t9BSaOZbgLqSgee+VUsAz+rR9YBF/xaUslYUGQDAVI82fhcUXOFKZq23br1qzIQu93y51Xaoi6Oj
B0J3IBdZcYIUCGLOgZwZdWmMy9DUHkY+caGrCOZg0u8X5IsxbXe6ppEsHwBQqbkvVihlt1RvrK0a
EuO60+gafPtHVhx8YYV2YegS/ECHRJDc+UCpWIpyyy/wjoERN9miNDfEyRhQutTFTsh/6RNZzQWT
Av/BZCv4fZl7g6YmQhOeuXAWX2vDCTGL+JTko7eI2eqHs5o3mI45HbNUXkRXscHHWmRiA6vv8NZ1
nCCDDHL2AwFpAwo2OJQ2hfE6QWmrrumD/xULgKrNIoeIT7Lx1SPlYvHAjor2nO179j88haAqQUnQ
ZpFRiuQfwgObsHVlZ0uwc3M9z4UbI+fWFrLmWTlND++XlevpQ/dTXqzvSz2xzoWQEY8jpzHhrGLz
FPpltdtjV2Fr5uf8PO1dZ3ByBR2yh2+V0mUMrYUZm5JHBIk1Dq6RZE4Xk2NcBcXbZSoBQdygZyDG
QwN9ik/ptEPLT91/qH8XLazHe7Zyj/jwahjcK5V07D8YdLB2Xcr/vVLCk+Jg+Ncyfz/kcfYuKEFL
bQO2P/IPqdbEboBkuQFAKTRy6IpQoXJeRl0mTxi7bEuKxSjZMuIfs0zZB06N0dUaMvNnR3Qkfe2d
PNiq2KVhJ2zchiqTjiy+SsxDLGgMHYmlkq3FLCuxa0gRb5OL2xNi4N1/+N6uCDYy+d0tk98r5ir9
2JEqqNAb81X06507ktFkjwSAxevkPWTDdR3c1EOkhebaxLd19MYpLMsPKkO6xFshvbB/lDTlYnd2
xOBp25js6VjHb/sZVdPLIqWorXDJnQS3EUAvKdCWoUGZpgRubCzP15MAId5DDaCExIgXr2pdlYCK
baHOBDxeRKCkmAQp/gLElLEHds1YWMjnvaQymjUBBbpOXdMk7j5Omd5gYkcAt9oPcEm38rmYmBIn
khYCBXc3FsnCl1jdj0Z/LPd05gCchPxYyLYVy1TcN/ziYWRFlX251yJmtqjOUuuZ/fZ48Q63JcuO
RGyR4KwoLF+kyAfRFxGjrgeOYWHKGrF0Hi90y1ESCVgQYljXs56/o8FXCLSip5aqkf4RaqNlMfeD
XnJMtyHDV1BghAlKOeAWIDkJPkmRKmmanlbIwbh9kOkJTAfO06AQ8sp8u3boPZjPKFOYl+IUZdIn
Mrunn1Xnlkyupudzy1SH1UDLuGgwt2KlgLZvfYAw+CLAylrs30sce6ldIAMoOazFkQ5bv9/TAM2o
4/gnlh5vS0rMwtmO8sQlu7u5UJfHtir+Cxu/h2pRa3OIdsjKjDz4E+QFCoOI3CckMp4aPl1YsLEb
R69T/nAD9gBjuGWIa727wNXQEhqSy2+CXQlzTUZg513wWtjEkqIL+L5pCes1nq5FLU99/VVh80NZ
B7pEz+rr6gcSLeIABBwqcZscmGjibJ13A+laxok98DNH5nrUb6NWlR+cJlGK3yWedWch29BHNW7r
8EI737+2++8E3eyhex6hae3qSnJqnRdYqYQw3SWh9B0PpOtwpd2xsquAPzwg5qcECzZUf46+EzH4
4aW3cF0KgTVWOPsEgkQWASzW27jFdWg2m+Uzb8fdh1NHCvxevDJodte6culq5CNVqZLYV253oVA3
I9xgnbkK31v6AxX0BneXD6fmWUWIQ2WBtSlfK62AgdyUdVdj/s9W3nyYNLTj5MTdn+w+Ulw50cua
CAAogWkIdwrZKuUnKaVKqXSeV3kXbl5mclvnA6uuW2OeRDSKgwddoTA7jSc3c+DtmDjkcnFmYzhI
2vLtZaXnEsisWEiNTnN0moKFWgDQEPVct7zv/n9Da/8aSi10Wn9yZEHH7yvlGqB/7IQeEvyU5Cc1
zHlDet7o4P9gfVEvMjnRDCKFIcrfJLadH52dwlO/4E7Eaek4OmZOq7SjNenEp8pYS044+tgykdJO
ISKfBdwMqTGNW8cga95xjvr7l4JmJu/DytXmA2Ar8y0cgUvLqxg7GHEIaIAjr8ExBej06xPbP5OA
hZwjjejqQdgV2w+cwZRFbFfZnBfE2moPPqT+enOStIFtGMGeB5zY8orBC2YNUYqAIGcxKdVDjsbz
kBC40yKqmiVWfeCfum7578CTJDK4tL1bvINWqdyV41FdZNqQpg3iz0JzIF+HOE2TLaDpY6JWqqQx
3vpDeJ27X1Fx5ntw77oEhWsfAx+o+EaVQRAg2yJNT/LJD9NnSC5sZXvcz4hB9TFhE1nQ7LwJPaiO
z+YlIA/R34vBYuOE//jBYzj5Jm9ZCuRGrv7C3kK9lDrbhaixmFzjcUXtEr09hIafBR+HOuJvPT2s
nIUNulGlQ4yZBulXAGKMm3TNZWgHFhKkvfOfWINsOVrai+Qvy5xOZdyx/vibWwmVFmtiqyBUshAq
XBXDA3yUgKf73PzhXehe0dKfJ5Ay3aFSjVRBSjv9vJsrY1sJBVq8OcUVFl2q/UwAmtKlVfTeVr6O
TGa/DipJ4hfcjnYXEpPpx4ItkY+eUEWreHEZl6Z3GncHuYKrOqcjzJDU6q5O+OZnAilfCkmiEQF3
YnrlTbVKd5dj4RaZzQN+/p9uYyMwkL4zbr1yUlYTc2CosCM5UK/eGp7MlOwupFEA1SENIAIRwSPd
Bf9wgHcTZH2sfUD0DziSvoeOEnxvGvYRjNrbyiaFTlirlt6ZZcEwpY9f9ndpjAPgVJVCxFINv2lI
3nMCDjQcps0CeaK7tLJ/dPsPEaTIqGr88syImN5rNrevRuXawB0/CGMLKQDtJm7U29+FJztYr1np
10VKH2xTEL0FI7LlCHMhQrLs6K3In23fB0Y5YRzpVxp/6oVUfmAFPqXqbxW2V4YTjBpKP6nmfEjb
3wqJUZPSecU88w4Qu70mtzmqUfttuWiH0sF7dzlHWRVh/CiscMLl2Ch72zQNU/wqWwuuJcm18++1
9vA3AYJXbq6A4lzHaOhQKEFGqEHllovE+fYRAoCZUfZGb7pk0uWSLKnLNoZfRotvPJ/o2bmQPuBl
cbbvbtm+MV0UScvf6rfhg29dx85NpQUfoh9+EoqftpE1h1I9CIKIm2CrDlyQsfnj1U+utinF7b33
wxFbvSe7dmv/5Jw9Q0md99QPVR0vOP9dRHMyyBY8u9J78/jTr7iqw0eWiJ5tQV25xr/LlxD5FmJ4
klGhY53bxiInusUUf/2QR/hzpYDFoIW92iEK9DG2uOJid4IpVWer3pb5G23+5ibN0xeRPURtoQEE
fIXSg8JBflMzV+gvps5pORX110JsM38wSttVlTqIBCyLA++fHLwHV0tn4gHg6zBFFiftueYD+qLA
TmN5C6JdKKvMlwUtGl9iqlUHNDG9jrt7nw8fAkiATvlW/D4je8tRikIaojrqFa5goPNWytgoNnvA
eOgFdq9MtGsIorcsC31A//Tb1fHFukk+kzcBAyXMY1OpCa1cjiHuZ22TbNwMcnncgWiFofrQNABS
Ccxwhi9l04ocjhzWAwwHtvK3U7KSGwQyg83sGe43jclJTK+TDPvBmxElc7PEqpJs8S4aeLV1OebW
+HXBHdVs+lm73MNvJmVnMh/03bd2zPO2CDaK3Xg5mMyZubGQ2oZ5LpPg0AnA8Cbiv4VVNI/X8wVi
0+eSHINu2MABvt7ykYbg0d9EgDVPC33dBDjR+/EboNEu5rp41xv6uaOGBJgSlS2N2yt2bFBwdoob
Br0VDIzMuB5J4i+O0OvfUM7N74ujsQVciUqEUjhCdMshfSbLq0O8jF8XBoOh8Hczu40zfxXRe4ns
HFdsorL89kYeEHYli5nUJ88U8UfFd/hDqy8pHYkGU8RdGr6AjgcJwF+vDyA9rTyBSXqYTvLDIKwj
2nCk/YOLAyXPonm/0q7zU+tHP2OVOq9Ap6MDpz0ZHgjMmP/UReqGZxzpT8mVaAfLSWhSEk9ITswK
DrM3I4A1hFH/54j81uMLKOTS6B8JenP7EKR03CSeL14GX6GV+XkGc2j+QGSe6LylCAyhdfz+tGem
Bj4+MjisGqTPL+9JVAt30KejmxcPh77z5/0ItzXDNaL04fiSbvR7kWqmeXeXs0ME3673euKbTerr
+XNBYxSH6w1ieSN0Cq4lOyFDGUuaD+bTUWqTfK5khBw9Z4F9M3vK99X+84tP0t2Gnh/jygOeT8sA
sycnOfWtGmYMe1vhrfsz7o6ueFoNgIWV6SA20tNGdmkTM0/DUy411LK+BhvwDGz4RXyiWPq7BkUQ
YOGN4Hxdnupjt6XA1WRVojPEkz90Ido/O7CtpU00USmHMOv9OxzvWxK47h8OMlGQlTVNjmGtXtbS
yt3RlVNRqe0OZRwQ3h4Ra8R7dtwJyNXP9aoRkPFgThWsN3zcSfYiL1MZQLs4Wb52be7sAEdb6JzH
auAAmEAMUL53GRoSbSNf3UzlnzkfbdmtDPgHR9Tg71KzAdbl6Ze+qZ9rls/41hinu5KHp0ni//eG
YuwYH+PDPU+U7WhsllI17NjOpOPy21E+iXPPsdVSIy6diJIlTe34CnkCpwtM7sYfXfUme21skewg
SSKq81hAZ/pQvfig6W7Cfr6bsqZlh4/LuiVq5jMTUSW4m0G+Ua3UwMGe9quwcH7eAPCVXMRxKaF3
+1V2xJtP1wF5uv9wts64ECvDa//wJQr3yF5sCBl/Cy/YzzxFhe7fizjmyr7L/jei2/bIW/tPA+DH
XFfUcepwtbd5s8Bwnhtd7IiIfXGJztW0AbJw5py7Lvx8WB8ksp5SLQtxq3L9DW8T5y77ZPIUcY5o
u6sE5svCVO+431153S+Othpzdyzwj6AU6Xe99BxodbdhrcoNcbeozUVTxtJJdxBO157uCPJExk8o
PfHAKNwBvmnJjenhdjUQ7UUEfrcLSQO1HN8VxD9k3wT6/xWvOZkHJuCs+0NqYYQzdJbeNZLqByUd
sNyGroqKIF7ZlSbzkAqc6Eei5NrBuqtnUwQl+DGGeB1TQGBclEPUPu6JReTYYx1lWlkCIuJB6rZC
B7bTfhoV2GqRITliSb0Dw38EvKJQ57btO5ckLgqgqLuZnDrRMtTKwHu3cStZiTOff9/6stNBn3tv
8ox+EUy7R8/MU3Sx3rUQTmg2APdqTruk1dwQq0ClIiPd83TZshz/MA8QzqltL06L9UA36EDqZoN/
F/znPHPb0ny7Rk8jSfWz871Pu/rAxAPiYmhIP4vobgCwlbW+4tMOVZ9D3A8LhxfYhIUatM6QPdp9
BQYVVwuNybudFRI6diUnJaPYvWDtSxH0gDiPX1MpWH8brdUB3j1C5r9G2VX2U0hirkXR5dIQ+e2M
lV6FlWm9y0S1SGxFAcJf7OpEfJskWpH3/OUT0zuxXzgipGKehmklxDNB3v/ZvyryXEtPrpgs3mOY
D11hL7LITu82hSA/Qp7LgFRO3vKzCIm2Q1c4DHwYmcS/52pJiYJbhsjXamNM7235cq2TmEie2iGc
Dd92wd8+jlSBBkfRPJ0aVlMjE7BJT7LDm9A43bDx/uymYJIwVUKDu7sFgHbA8IoS1xG/R7YearM9
R/9r5e0LSPVoVMgG0LeqWpV4gaIOUVgYdFRQz8YSV3G/vNl94XwmXtJyR0gEu+68rF/c1B52l8Pi
TnUJKiC27mEExP96wgJBt4piGIm/78mvJytH5LJpMUyGV9ZBJVLC7JKW4J4Z5WZTTD9gnxid0790
1/+dyz4W7V0jGfQp3nfjkhsJDNRGAWfcD8YP4T6ZpWK6kQRk96W9xQ/lhvDS/pfbABKMUP2z32Jo
d+JQveT6HFGIC5u1rg4zvKr0vS/50F5U/vKbY19RMccaZMPyW/2w0swIg2gbTd/RnxfudPkZig1A
ZXd/02E2DCYrLszt2XPoC+jQRGwEAMnEa1aJegwZOdVFbh3Rau97mmzMDg2rIQcMII04Jtv24qJD
7Pss6ef10LcP6SA6oGZebSHVt5AXNfZmuJVc1s5ySlUzmihbaMB3nsSi9kbDHyWIDe7+/5ADBhFl
Tc7vA556Tdn1Db+ha0793ynd5txJ5OpsRwuSCQVl+kim8KxYyziE1vEXzgKjFzUJEoXkiYo6mCla
NdUvob6ONuat8V6thTlOTukyMamroV/91sv+6X9XhA0jHt4P0raJCsjSQosL8QzzOeEonf1kur0E
WEg7szFZrW2zKIz2ljvLKfL0PhPSmZyUuuXOHWY1B3VfCqW/Z18aYoYyED3roTBsIXkWEExyK3dO
BOgP6DiS/56ak4pcCPJrZtPPjhDBC+LRxWk4tWdXZ3adnnl++Bn8zkhB2plg1myUsHH14EiEORb2
nwuQMn7K4U5flvdVQNmrcTZBcTciBjcjFhB0kIh3ikVhodDX66sVDyNjBuHhjcYpndfl5WiOeyI5
shQTKo0wDz9uOaD6y3BNhFOshM6XzURCE5TifL9oOY49WEAKy1fWnx73fTKR1meMbsog1ImWkvJF
1WGm4cMczNzVJloYzVsDAxvhtIgFuHm9cEScRS7A77kF5cUqFmsWovl0sHbcx5aqoR7TNfKAjS49
LiYYO5Gp5iNotsP28VHQyhMpwfpX5c/5YSS7wIYJ+cwBsfpQxrXl3wtnoTBcmW9T4ObXeqbx/lY5
Mkq2KBYRyFpw/DTVsPK87s+t/vscEjolbheYoC6AzXMaNFNG61kgdffus1GvBA2F9fu/TXjNpGFw
ML/UR0Q/0lku4iVIb71D+sPRsP7MFyKWUwVF72+JLBCrFt8Q0jr9YNh1CbPANbY3od8fmBTi2OwL
OeuoLHcbNNyMnW8DljuFE+y7SpujVqb62vqI2YqHbJzvGXs7Y8KD2SKXjV2+ecAjyElIPVPk1KJf
EnTR0bnyx5zu2Ml6tfXWywDGK/TnPOXJ3FXnpF4HP+fBZAHTXzEqmiGucJUkFgBbJ+caW5v3n1fu
OTSUbUVMrKj4QkieKpaegU7vm8u73dpMptkZLV0437CoEI4fXlFjAhOjhy/wnA0KulL+4VOtqw0Q
6UQgXkDqdmYzwxye2eOh+blfrx5s43HJgSej7VJ8mPJcSj+7EoF+xSc5pM50EPqT1yqIQiH3zdTm
DngxaZ0PKrMjtqfZ4er1ftjimWQFmupCIWkrNLbwf5Qw8lDJiAtgkUNb25fVl2xGj7RaGUe=