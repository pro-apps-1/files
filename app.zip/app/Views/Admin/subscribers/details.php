<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzZMFqvULOHX9pcgRT4TFgrLA+IsS5fP6BQueh2XfalOvp/NlgVvW4xXV4vp/GuAc48BOktF
itZg2U+9k9tCAdbb6agjwFLrIg223xulnu5EsKgAV4G6AlGwTsewHCihSzjPVorIdplgtciVMlul
lEivq0FlPTvIN6apGcV6LNbUczBolgmF1zmzD4K2R/kPZ+lRNe/T8hnTl0PR5CF+DiiuvyPykii7
B8YE4wF/o8Y5MwBaeEXkjwnjozlvCe2+N7aUzdiIHdElA4AIKOIlrzpiUnvivC554N5e6eSG0aXs
JoLZa+zSzBm8hzKAbaAnism8I8ecO44z1UM24AZAQULPfndyom3EE4vXthnaNvLt/InyAgvX2YVi
lslNqVrJ15Gz2tnrrFwOTVtDAwvqp1/sZ4/SqqOxlJ2UTGYG96De7UsO5dZrJYj+3iYOS2+3xH8F
4gcoKBeuafjcKSiT0zIMirqb6ezSBC8TLUKbNeF0seDxmuB098C/UnEva6Gvvs/+k4iaLiNcEc7b
00Jbcte0L/bG71K5FKA3Uu3Z2tBIt+84Al95gbNcgbdpbtEDuVsesmxmCsHl7gF2blZw+slhC+89
sONb1JXy/xFGeUThr9hLzhdaowHnQu+seE3uDXhaEToxOTTbss7/Uz8VTLSlkYRjTWlSDIKNpT8N
dMUm+OVTCWJ72/7KRbog21wZQ1laAbsf5PyPYPXMrTsWlwoahh1RTs8Q3S4zqeJdUL3Z26Yku4iB
7x/VG9XTUGUFwFtwK3YCrbNdmZjhJhhsVsLCrw2Q7hAx/pXQYjMuOSZwJxcDkqqjVSzKEtDSypYM
XUmDcFH7vM/hAsBxkgXiiIhcca+xygcMSiVrp1bTFcuYQTjYylNG0k5K2UsnWwd/HA8D7+AVPHXM
0PWqvJIRwwM224MIuDwWK8cZlnXW4xclVJ8ZyFP7LiUXjchc3jqZM57TY7YYEDnS3gJGKQFKCR/W
B5tF4VIg4v7ZIVzmIOhhJGpI65J4wxt946B9Am9AEPPUDkEcSrvn5gMLyuVgm+OHqEEFBWJpbczA
ZQR6tUGNFuyA7P/k0Y57W4FnWap4RBMBTCOtBN2yGRF8e0/uTy/GYmXGDaInrF1zar1PpP2WxIdh
kksATqg4HNpyo+J3MsfzT6OemvB2HGibZGVTcA1XxyDrUfBhBBPlqAJ43r69mFXJa4C+2lTAijAn
g5hQySWXr2wmTjMi5SbhTyAqcu4MKwfVtsVt8NNFaZtbHeJOUKzPIwrRQigl5L6oGXz1carimZLT
pUrNQ7bIzHYBoASBIlfyEg1+01hremvTh7I3MBT5FzUOkR3BEjzg/xZ776WJLlhWPduBUr9bUoP3
NBPU7mLZ1Cocv9AR8rChL6g0Ivpn7LQqYokjnFNjWYsx2SY8P0MzbaOAedbJU7cIHXXAOmOp+u6h
bXN+WNypI30FH7Y9B6LiPK4jeHhTXAhx+z5iISXsAx3ZS2nHd9jZB2TXn+5sc06THTgkThjnFhxj
ujljFQrBfOezqA/crET3pjWnA7BMdBg77jCohHpUIUQQ5uKWIMOAjlS3f6V45zp7pq/tNb5Eu6G+
d7aUkkFAuZ3ysHN16ze7bl3trwS3OQeHZ14ZiSMOeSzKrvKaG+gYLr2zuy1FxZAVSds74eyp8a9V
PxLd1VxdOMTfHWWxSVUkGGoFX5J2Pf5XrkFE4prqs/TRcvy8mK1nmh2rncZzkJ+pB+SFL/zGMxnW
rbwsKjQjJSRs9c/s+pA8aouWGab79BlU5Y52pdI7N9WsjymsoWf7EhCQMiMkCl/bD9sE6pKoMiQy
jv7CqXn432KQXD9SSKjxZYSF0rUYM1yoJ+0aCiMkIVeWod97swgPi3GPjhyAwHEL6IjlnGnI43gs
ZmmYvMMKLpVhZftlEbrBpqkkL9en9kW49uflAzbzBQkUns3YOtbkmFuuhusVxIavLRZUSNSNt8ys
dFbPbZrytgmstEjFbWH5NmR+lfxt2J+P1iPQQF6xuGqrX5YoIaPy5BH2NGlvzwKR7//3+okvkjn8
oy+p4NJ9CKdyQKz6n58FgecbDIF7ijnvaf/uv+wXOGkScfIunBZRc1bdRhV4vL2q9rhMzL5Zz3Oj
fJQlfEm7Ycl0X8piLMrchfLesScNwhtiLIt7FuuMjdJy5h3v0BfgETe559sW80ErdwdTDFnCePyZ
VV/MtKLaH66oWxeG9lhkaaxOL2Rpoy4/Innm9bX9bjU+fqCEqKIeg/rLxfx5WERRjru3FQu40ePa
33GXp9FPLrcrY/huM+K+B3ViJdnuSQ+C+u3FRUPBE8xLE7GKiin2nJdY9gTIluIQ9H+GLpJkzY7h
qobL9q5/TWX8i6ev4/NQzGSs1fuo/nwwqA66sGHvyur9nYoGfJ7TjL+FOrngfSqb0ekVRVEK9hYt
L8T202lOp8va7Q8MJu/ERsgDKcxNN09eAq47yuYADBk1b3xQ0tGc2DtFfwwEQ0dEmWpyl3E+yOdm
bBndP5YeYpwhx01nKcIY1PTyt8b00pcB25nnYWZ00kHkqfLlvvtMGXxe9ZX1vsaa7zprZU4X6YXj
pQPXD4fPyuQR5X33HYkA2GaZYKaJ2pkm1WDMOUVCeFNTlJInwE4UhI4+eFf4SSnXcBWudbBs0oiC
6/qGOy4QrD3j0HZ5NuHNK7RgLCVat1h8i3QJqiEOATKOLsyRZkLUPk2dMHEuJ/jTB1Z/QZjFrXI/
aPS1H7gENC9F97DansxnfM/tQ0bb2K3hGM/69ZgGjXGB7vzSDziUV66iPvJhXg+9gQW2x8W9Pco6
7vSNnJ8Hw35GEpAbwbSoqIhKralx6BQUhslWZnBsyqyG1z2YpLSO+MiWgQtclb4x6F+LvnnLAVKb
SqXLMTQSyjQP8fZhoOEKU+RE0T/2n4ZLttkolU31CTwGB8gNQ46gQgHen3TM37Bfb0/9577QcErn
MQEnv2l1MISlcP4A/4iXn/u2dS5hMM2dmH7Y4P0jY9VChzoM6MuaZYMf4p/0lPMY19+7JgAemoCm
IUU3dtF6/2RzJckqE2ObWgRRObuw08XqK35AX19ywZ05RhpJQAQbXiFzDm+uI19YGxMMOzIsG7KM
b1wxnATo8Shilhde4PFyR3/bQfHrZ6No5r/W5w6sVjKhCjx69ozns/NLcGsqQC37QZ7uT+Z3rQ/z
jTc+Hmk3vBP4yjQ4vgPZi7Tg8UU7IjKaffZLTIeO1eFrhLGlvDjxqFgSXRMdWE9FTZqZdi4d/dbK
mPTAtZIlTOh3IyP8GIoL2siNsNu9ajAaJH3FXZRleJ1gU1qOTIIlYkr3QJqIOZ/QpwScFHxH/ovz
o62zoyUXH6g2DFNjVOt0kVa/8Ox6DR7g2sOcBlyjMdOQOkaOQb4rDGdOz370ywWsWlAQcl5v/oCY
4Cpl2tHeJeeXPd3lgs6w/ccs3fcO+tq+v9zD3jW0V0HeoaW+8XeOCVmhjy5/KwzkH6tGOgvDaU9Y
Iaqup7uY4HHLRrgkGEj6K1LZvCamgRVlJGoqKOiHKsSTJKM7VTBwweU6Dflik5NK8X48OCtcPdFi
rvyHZzoBJDahJ4OZyiLY9zMK2YpA5dbI4GnglPxROd09W2GGsQI6AezA/tictr5ZfP4luiTnAy1y
jm66W1nsFm9uwob9I5OGYm26dGjvOmS58zF0zLNcRJJAYB/R98s5Hsoxuov5ulxADmDDIp1Du736
jwLfSA9jM+ewHNJNCCcvpRittHtsxG8fzJW+PZ9d7MpyWK7bIQCQfZ6e3XGTUc+It5Ba/XWfPIkc
WuvUKMtAdimeVp36GqkCoHTdYm8sR5kLxZwWK7Gt3J6Oro+SlYv0TRBpCZifZ6KdgEbiiC5XBCZV
ckFxEI6Abeleg4jypPvJqKhzbdUEq876/WEwfSDWO/cMkduSfpurBOvOZ+iMLGCvD4TPZM2t9YlH
1E8MOam2+ehkqC/+iILqX0p80MhohyOtndwpZcmo9W4HfLb7Ts2liZdjZ63zJiwfZNffvvkApyb1
PPP9g5R/IvU3+cPeUr7zKvCpDVrtZwqU8yTOoptFVwEzr14BtH+CcrW5KeOXnryrPt87M/fRHMOT
qoqUPcGl9dF3hXytR8GQ2dHKtT/JQJk6lZwNDxciTx3V5UUdBrdGfovnIiGOjfaOUp91KZJp9Qh1
Lq7L6GzZO99Wevdmrs3RTYpU7mFKAWEfRHKbOcenPXQCQYCkg29tS+uPTDtt/vZkXhuEQlCDjZaI
CqUyKMoXga0bnoCYPvfH7m0T/xC+FuP3ZZYlfC26rNkEaSzGnj2kB8rbEnQHVG2ZD9HZDq8fxSR1
J/QSPyJ+IMDSw+IDVDo+rpjr6pKejTshT/E9/t26nQNyfIK4igpF4KTU3O6EMoOX3TLCazfa2qZC
uL1cdFbXHIGJ6w2vcBUDOpv9u/xIZ8zUXeLu3LJbdS+Ec59q9rpXBx0a0tm9MuIvOa1fH1G3b35x
5s4u4uMbQ+kZhllerv4FqUr3A6iKHAq46wx0vtvSw2AVMxgHJLkhWUKA+GTlTgDCWKm0zN9ga4IL
Wl1Zkf9Z3aj/kCQsZ3VnOjPQUhKEYhuQYrNOTu/GeArnSP70ka4RnhxVVblcgWh+9p1p1DlG3qjj
tDd6jF378tTzq8/t5b5oG9gb9VElikcHOpWQt2KJlPrmXj4zpcrHC45jonERfYOSlPxKhyaOpqI/
S9PymQ6jAM2YfEbSzuTYloGmmFrB2mWUzJheSK6vWULUtm0LCcOdQt26G+hzfTNINr453r7AyY2C
VMpc0UE8tLOkOCtk93kc9it5gaeKdEsC9RIZWKeApr9+mCQJd8ny9ogAj1tYk0zKKdUwJCg/jHs+
HUkYHQmQTTw+rqrk5GknB6iv3Zv/jFvzTIV2GKVHvMlTu4WHrWgl8IhKPyC5JqTpvPBk7cxsUQoK
U0QZY3jcr4JmafoHYa0cjEzisMOxfQlSAQ/2JgG9w1QnTbANTuejL4sg5RdrCGLaealKMOem6Dhj
K9CsddtoxAp51njJnuZpaanQtYOpxPXoQqu/+aQ4eLqpwO1l/MBaDSXziM8S3fv6lB1ZQmNfBMYu
MX4F5WW7nqlrHBgGZ2GQR+GwTvkhPgUSwtP0fHQHuf3AsKU/A4mvLh23JfsPPGTzT6DOX3T7CF/N
8K5P2rXS+f+gWQnXvpXJ3jWT+rgOO4OtzMXEEyjUO6d+ozUlERyeQAmpBnQ2TJPSYAQ0jDgfUfGV
tFeRD5+8818UxQWVQX8FxMmzcmbDZmurM43t3jRStDj9ddrNAt5KvS/rLUDh+C3GXGhKdlbLCEIh
9CzQ2v7NeHgPx4w+hT5JgAbV4BLPdRwQuqV4TIuTFNlCflpCV6yS45DMW93X3dSR4CxnJLmeD45G
7EVeQlSYCm5wqRIzet82+zr4jklqG0pCIVgqSnIIzJR6ODoiuaC5RVlKm942XtyY1DUXP4rvWnth
s1DkQFZBKXcWDWBbXJWvjzDyCckyXm5uYQ93B4jK9uvJQQCPwUgiuCwCYqdm/dYVjVJZL7ATcTtV
yKuwv8iAzog3hFQ/EGkAW/W8qkK1LkNaFPW4n1d2aG5qN9/7XhbvodR7k3D8POprazhnqV0pmR52
6LrI1Q4TwvkjLqPxJaBaU4CkIateIkepVOc8YlJPN8CUl5xi7oim1RkM63tteDzBRwLgE8adkPiz
5MqPII0LRxEqe4b0mVVA1GrL+2yDt9VV9Amj9EBVnPCH5Y7fWg16HrBXXFV9HFYebIGf5En5q91s
M0TikmusBnL7rgJ42L5ajyaClHjvEDAt0TBkIRu+Kod4LWI7ZijD4RGURxboWSPX9KXex83huzBv
YGrWvus1ryYnh/XTC/TgG+EAb36hfWLjtb93c3AuEVf3J8RTlCvPSya5Dw/gXBIs5n1M8w66eu/Y
CQAsu1S/FxblYX28U6s6UMU5pMpkcjomzhpJUda1AitFdd6D2Hu9q8bZZTDjdk/EaNhmeEpgOMl7
REdT20LQRvSjewxKnF5h3YWBbXgouYQwpMJ3OD0EO3J8WvVSB982rLnaRXHoFNIVd4KuQlaI8MXJ
Z4zyhVohlf1DDyfo3cxx9BOSuNxRbUBxnVJxpJDtxuU3qrD0TaI/AYFpUmRMRDeF3MOJu8ndSqiV
edAuxzqGWCqUNmqZ0WB0yOwrDZ3kD/AgoGZyiOgNGBY/NV+D42yEKzZ3zzt1h8R3lSmJ4Kv9pe1l
VMmLG6G3PLxjIZZie4CjAPBL3YD7bsikp8B5H38mxzMm+xl8nuU8fU2/29Ov35pJ9hS4RKvtkc9h
xDr7mimr3zbFov/ENxvw/vcUgkNvWwAFsBbONM8zkkDmUjXt+hzUhyq8b3GFh3vUSk9m9gJoov1/
jhZkTIdn1uOnnG2UcjqYBFJnUPvHFt3dV7tONzAMl10um6KKtuIUg26A8X39YerM+hUEfGRoHtfW
TfqR0SGFxN1DOKTbokTZrX66KijqvjwuuTGF//pxhZOokLMVvsWGCzMVtcctfLNcSSAX8o2Sm3vM
dlIA0tCF/otu0Wi5jWWBX9nlVu79w9rpEDwo69IJkEl3d2ML0+OTt0scCXOsJPUa1xaRJBEs6F1f
FMH/a1wjfNV8vFm9r4GpIs1AVuwUVA02ObDPSzDZycKhzGHgy2HgH15baAydHTSgp4a2taBVXRsO
WAmlOaY7PHQpYIYjjGmB2mBFoa0DWCuSdaO0sqSoz9fbiNdschVna0DzaturFUJ1LDHwIijtUsmr
0ojevkC67bTs8SDxEixv/HBcbAfjdg5rD6SWjHlCu5ulqW19eL0sTuD0Vt0Q+Fr/3lZrwjNRd2s1
pL+4jMRpipT/6l79YyJ49ak3Ugt4EGd7tTigYJE5grVvFsB/+4Qss7ilS4iWUQYkW72icg/GbMZd
5shbctMbttwLp0n+YQKMQlzWeEqWyjXkes4HUH/KK+wTWFT0XUgx4+G1ZltKeon17wDk+efmveF5
+EehwhpAL/D61Jsb/wUlFZGU4woyNn8pdjINctgWxD4wqPhObsTNyC8ojbxzjuszL0xEwEg0tx7R
Xz1WeIDdOuWodajU/t5cgGZBME3G/9XGGbQyNZ5pzh8u6GtxRg+Hal2PmpdeMOro3YINYAmJe+xZ
6h6FsqExEcR8Xf9Mi77zzXI3zDvoXBzjPulnm8IQE4HbC0wZm+Gf1Kvemo7jmOx25KqR/1aJ8Y/v
JFLEUNzmUly/ZVR7DJIXfu0KoojmV3JRKascGFoO9y8KjabKf7JvkRsET1QpsUSLl5iUwLY41h9W
p0ptZD0+lqBMllPMqPGfLk+jX5x4euuM5MfGf5UBNM4q7SsKdF8BI6MUsY0PZIrQhn9ayCEDSdoq
Xd6Qqw1NnNPT4tYazPrzYt1Y7SqNB5+xy5ZAmsfDeNSfrHBekZPuL3OrSqzpZUbdAFHSMIRCsaF7
B0Zc7p0fTFZMrTvtAAxrUA/rtHfbmkqk0ySqm8cyY2YSsTNIDQRSTiAVlUICeHFIv5o1CIMSQWG8
ICDrCWjKvxvq3wDvEBDNda1Z662koQpmmq/IymHcwxerBVms4YgP67y+Fzz/cd3vIERX2P1MafQm
QUpHTYWA19j3kpLaq+oqfHtmAQM3wS9fNGPR3WvXpHJZRCrWU9o+bcyMgrXb/QkT7P8E8JXTbchl
QuhDxp0I69fBe3xXVE549V63VdmQav4sn6rYoK//Dzt5l+7zaicZGOvGwtipdR6RKE+X0CwTPRRY
53WMmBDSzBX9+rKa4pP/+5xiOyF4vOFii3jORyeoEloYr8JBZ2ZuHr1XUOw/LxYfQsW/Pjs3hukE
XPi8Vw7+ZNE1BGMyZVl4S32JsLWTeEB9Xc6fdwv4bgzSdRcmY8o0bv/QC9wE2MyVpuyCxd5DLT8/
uztBfugKv0WGC2JZds5vdUumluMDYMnvE/EXyuqw/bJM3qjm0cvjHYgOeqtrbDeAYMz7xjADUtQQ
IfXZ0+qoUVu4qm9HIYLnB2p0+uHz9Kdr9K9w0fEci6XWia1G069aId/Wjr8auXtqaX98rWbgvot9
M9dMivpp2SXnZm8Z2PU+NKpSlu8ohAqiKpCN4JbX8J9sAAR4PWsJFMH3EOH806S4+kuDDegLRTHo
6vEtKJBi6tmeYH/f6EDuH0aY6Eq+1dKJ2vCHhrYF3dgEZTqON24pDyAKG2iGMzEmTHYkNcR9LPdH
/WHYKIPFRrIMTF+4oq0R5Imesl6p2WSljexZtQP6IAMHDODn0hRyKLmU7a1tephMOa5yuWjxcImX
kbYlC/43OyEnaq2jerOzjLcwR/anra7UTi+B0oomFbYMf47Qhms39L5Zgu98cOrpOoC7dlKwlYPn
VsDpUQF21hHYoiUoufyl2HjvXjhc0pAJSq9AZJLqp79sQkE0Eq5cj5Bog/B43Rrl9kOWm7KGgZKH
R6ySQoEyeSQCKSUn2m9xcPrchZYeuetclIzU0OpOjZB263ahXbaCinW3adQ6YqlToDrmNwjf3dVh
TucMhflCOLSdpq4DEHjkosXNnWMdFIh9rAZTegdzHFpv6fzqQBDWIjDJzmxiJ1QB+7LEp+p6vom+
9zeFI8U7f0Hw4jINv7JecnuAJu4ls/e5gNgpN4+We1d8QJTj46T0qiKKcZc5sNrBoft/lbFZjw4w
QnvM8uiL+0jX7PiD4Zur/M49U85VUHaVjH2JK1zgG4w6ins9PN/+5D6wAV/TaQe=