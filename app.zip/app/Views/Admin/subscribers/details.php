<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyv2FPh9veNTbAoekHNDKV3tlqD58M8mnCW1eQosvvgcXQzm0qGa11fmVcUKABjMgwyWCT5J
VgJDbcX62+vrzQE9461f+nAqUWjN5fsHX1GIFyifkOOm/uzZrbjT8xoqzP27modVy+uUft/bXIC8
3t/OHfqaRmYsKGjn4Ydon6CYQqc8iBvrBoKDKWSrsebmEyceOuk/27Turmv3IyS8WTVWM7d77rPM
aLgJ3gg3CpYW5te5xpf15v/CdDxtcEmZS3RO4JJLRuDc1MUs9o04TxIsCj+MOWSzgKuUxkjx9mBL
DNMWDuZTVB1/JCKrwdGj829cLmF0vlVlD74knKrF78vUEU6EWQ3oFH8uMpfalPJqUTY51fa/kity
9PctgRGJbIGMQ6KxjQv7ulbZD59iXk2FIODkHiSVlZIK8N93Ts9Dof5I4NCQopJGzk4E4pvpyyjZ
L34voU6x7VDabaPoklLiQU3QY0OiBmo0Cb2KbqXYTlcxyTbyXk9a1yuILhD964Ea/6o/dKnCLU4K
Sxvx8nYIBgIpCBZn6pS291U4ccy67/xXr2zFFQf0L/PZPZAS5pf4GKsgpmAzFh5G/LQJ452WjiV3
biWw1fW4Df+l6/5+BVtWpIRgdb4NPJ6DyTf8tmGG3+2slTevFWSeXXYKBkGCGkZevUumnAc+ifVr
A8ZKKHsjB5T4PuelOPPv0t4DZc++Njl5jg1aji9eJNfxJ5v80tNgsySxcG0tm6B1iDiadXXdgwVK
mzGJTVQHd3zs+dPu9kTHb/HQ755M6fUzgmigkjY9J9V7nr0Amc0JclDKAwILqGACXo8SD+daaho0
U7TH3L4aMmM0W5CR4t897PlfvcrtuJQ0myBVUU+3HujRShqnLhrMMH+5i5qWUlRtpvuF65t8HDbZ
1GKvMWFoK8lH0Wef0kUiETkPC0pHewM/19pMkFUPVN4PSzirgIFm77ZcUtBRrn7eTIfpfdxhDjuz
tOqu19h6SIWtGWrn589UNDvahQf2/gTcU8aw/VYoKlaNPVYArW7Pq+kDEnqvNFmuTjNkZgGQpevy
kwGuzAhf4+S6Qze7uW2VhCWN1VNYchOcYzOJv2fu5ggD+Cj8Ag9VXbN8t6B9p21AGuxHqsNquizh
Pn/oIcJQcXQ+Gq6DFqADghj1UM9/pN7myhixj4/vBHEpzSa9bB9TPak405HZZhxH3JKn9C3UCn6S
7Im1ZqpwDzRGqRNItKqXaCnE1YE9r4UnyWDEkcQ81RwtLnZkzZ6mzSBiWL7K8ieN2oYD7OpE1Zvj
oZx8x7fW8SEDsYiS1BtQVSItt1yXOXDYoB0CajhZ/LVOu9TmKzOIWcbE50zvgOdBPAiE9THIENHH
ICkKs2plry6FJspALYK02Pmnmypc4rlYZm5zH890CjY3aF0B7J7ozJzHw+Nd/1rAad62AN43OaA9
2230z/SWlYfCovdBvjpXrqOeFaHlieeVxwm0P+W5KivjepSgg7rA+0XZGdoc5Ww5oqBPzEeI3c/J
bkySbP3+69h/tnpA1Sc9k1Qnid5UuDI2TR2R5rHvPgK/jicvvuTxhYUYO9wRcNsRu++EjTfAlLJh
wnRCph8cVE0OI8lgQ9WcgO7V7dDrOuqagV3XS6z2wXT6S4qiwpFIQB7wyY/gwT4aFW2gf2WZ226Q
lDzKzK7BqrNkwjcwQ/Loj/6NvXrgiX0iydHkbawA8jO/azM5CZvAuwRdANvUTRBawwCMm2Cb1CqP
FaNCPfAqpra9I+OzLDwXfoX1lIGJ4ZMJe2v3hks8lZ2TYRkQsyQqAaPKW7ejKRJ4H7MI8h3QOLLI
+Y9kIWl4fjs3MrAz2vrc70kQUBTm8PeA/F5XqPnz1MTas+Y+YCmbn5ukjARtC4w/WPD7FQgxYsHe
gLk8uCvXQYhZMN1gu0kzFs7BBYHR0pcrmR7ogz6eugumbuLGWImTk2ZpRDreQGLS4FGL4wsz5vbw
aLH3dILJuntkeGNrVMmGhU+SZD9bXL1p7sQvkAQ3cu/1QCQnML0SX5f3tRKZSWfp9c+X3vzBmmPq
0OsKr1TyMVcRXatkT7NGQOXsoJZQbDvjAlBdPqGe94XL9OjNOdTK1idem64mDEVXn5PJUhnvzzAS
nQx6n9I8TaHaDeOAT8xWx8n4wFuUxF0JxoTWkmeo8TcCE02cgS9ZJnu/AL6bQ+PCLMV/YFOIdU2J
z5UTv7ytrUNE6gZWv/+nLfUc53wVptAeNYfMyaTBqlIQ7qbm9uVN6VjRbNYQqYM3mqVZ9P/bYHO0
Zj1tl3lqueugq3CQfz7z0sxhGIXuaWVtpPIe3ocI4Xxntw1oJ7dGVz9U73ij9lwKnID0WtefBVUU
+q2mm9P4y9mggf9JV8+6VnToufIIK/7OuCdbaE32JjeQisrBfnYPN64W7W9Af53cVAsb4CtJOyxp
hb3hFtpOliuuanUEl5qZd6E1L1dUY/H4XphZuZZ1LEBY0l789dpiIguX5YcG7wFqUTX90yhc3UOP
lyqUuga92Vupc4VCq0XxjG9T7G9t7tOGDxYnhBe1AdN60DvP3jOIyxxqJvBmw1WBzLhmfB8Kvlyg
XGKaBGY/gtM9fCIqW/kHNUa+mq0o4bwg1IS03SpUnDEKpStZ/CxSdBaC2SwTC64JFm3rKqUFMkfr
J0jNvO4LXKxyZ5KM7k6MEPewRbpAl5HkpjaWsVTiSVd7SE7p0ytJycX1hJQKCQiLS/RwVTkJUcUF
RhJX67UHkgmggfjF9GAVSpZ1QRtFWDEsZXDrDyJ9CTH84Lk+1E1kcFsVmFQNBE5Yr4SCRYfUuIZ2
NImIbXHGEThrNzNOfCYxtfE2Ry37UV+COpz2AYmRqkBeTpdgeRHCrgsCLGQH8SnGymSLQFhZhEIM
s/OK44eTW6oaCBql33MniPWk5nB4q/j2JDf2AFWJIMguQTwtB4KPq7oDdVvgA0NKMs2ajz2DhCSa
LeAnMfzdOqJjSBc/NHYMjjw8Z8FzSlzQy2ceHiONzR27cQDlRa0Qf2cVFgCu2MYPcTYVzo1QcD3A
nD6PAlen4wb6ACsUxGScqwTbykUZ9v7T7sli8sOig/2eAV1JpfkjxbUFAIC5vZqwnHLceJNKTNcG
bTEgQx6nwK8g1hC4yjKYuys/pj7r4y3PUzcFarsxQh1CK5ptEUY6L1pOGrHuTqquyEUgxmirXdTh
4H1ew1Yg/pSblwtGcMiGave5IYAq0tJjHTf6opTEqWl7s6dmmPUV9Ux76FzQiNI6ZbP2mESsdU/a
PGnWfTegZpVHGDPKKcuoFt9zwJyxs12GtupEwWkedputX71Ry6+1bKluXeyBNSLbPDBNFcacMLb6
8GlQd5LMoDQw7te/ZDbUFY10AhN++24RjrSD+wLlubA1miIfHizTcGajRNIf1pfyMW6BQ/fMbiU5
RU+jbXKY+g/oNeswdzogB7d6SGFfy5Jy+4lTEQTnksxtAAYEI8YPeRa4l0jc+J1bKI6STyNKAk05
36g01xId1n5oGcNSiT8B2LLTeMBu4XKgEWaQVuxC6dtWz6fC8q5Fyc0RWjr2euF+f3kcBrfKEBjZ
XMVnKGmOM5yAJkupRVFFySruwZgitsKQ8AeF4UpGA/YsmOFfPOYtHsGYsQOuvl+NyPJsMdDn02p3
qCIoNe8hIe8sMZAUI+tnwxeuhZiqOg8ChPYaxjUFEwgmKWtknhhOn2DLb1bud+M3XpKm7HezmXhM
iaOeOvjZsHYLMQq9Ss/asjWeBiIBGKSSwyshcAKsxD/A+gXhIFS+9E7yRJlHRK7aM1f14OU40WHT
AlfXB99PzCi0a1b4B7Z6HIKhejq1pWOuaQoWXCfUjNbKm7038SUaeh+nJ29Huw/l/+W5v/ifcOSi
JBm94gyg+t5m/QUQ2GXXnB5z7FotIFgyATxDEj/r7SxAu8QUjuNAHlzBImExkSypJz9NOAhVIG5g
ZzexaEKhiBjJEGp/6IeppSDKLZE7H1BAx8Dl30HnrdjUK8+Ov8po7MpX3F+NqBgnN+QZ3YYNJE6y
khpgHJO0FwH6g0LMV+LhCAgbfxVw+Y0j2wqjpRdMwVJ7g87ym+ZmvlQw1GmMdsT4YqzxjL2QM5mA
SUAU5I1Lp6t+0ZfAUzrU7w60hG6nH4rSKu45MZ7Z+zv8fkXMYJ7loh57P1rbK1JkCUYonvV3hh5Q
IgwW2Fxhg1vxaWCND9a6srmlHIVZfezeC79kjPPkfzTHw+OH7kuOVBioMb4pytOozc96BJzLvtam
bm3KEla9SwEtCGFvSayJp+kdmuZwDGF0XZKLaV8wp03CpqqWM/qga5JNxYlkJPDBsWeI3nnFKF+T
hox3bWrkTHjIfaCV2rN8LsPXQQsxJeBAX7lo3S0kZ70A1VCZSnxF8YASRxaANmM+1NTE+B/E3BHz
vONUGkUjXRn/7FJd94R9zh0nu/uISE+yeQMgdhZhtgLx1otFnb1BHecEtOxOtWMF8zu8fRVDhQKW
ZkpgBanuvi9x6pQ8Do4UKNhS+cXNSgk0j9Tlto04NPNIMN7FWhq/Ha/fbNHCG+Yh/gxKyYnKEe8M
Bj/VBYMKW9qR4pC0+8ffi4EBJuqr0JWBJVNKMpvyGmY0PK9PqcxJu04h549PoQBc2eqFcBnRU8oN
6hml6pq+5gJdAL5JG9qddqx4z9+BTaydq2LyIOyiJd+JP9QSOtQ7GzKqYatDmtkskrsJwcyMvC7f
md3kAXfe0Wn+MS4nVCYNCfrFOP9gb14SchVunEFm0LHXaDkSVbZz4vRY/ZUnBfK+SoNbqgXApJzK
QOEs1piNZUNI+sn53oaDUu9LNcJQ0JzyhfEken2q/iRjxRVqV+8XO5SgHuqQ/cEw2zPdscaXMW/s
8f60fKTnH4FQg6rJt+SOt8hU8+7z7cxBKL2Pq+1DEtYbu23Rnc1Ob1U7vH0XRWdNXdKuQ8YhLnJ6
ulv4qWb58ugtT/PYXw7i1aagU18DXX5Z59MuOHY2Oko1224/6n1Ya2ACP8gJ2xvWwDzA+SXijCnX
sr/M87mFPJv1hAB404A7BJDkekNuqKikFuC7H8ggNd9u71+B4RT9W0I44ykk+J/4ms9H8vcw1wFU
yK85aSmNEHw/VoEfwbOnrD8OpoEUI4eVDg6ujoN0WY6JO2wsoO18cg7TKX69VE4PnTbbfyA3i9lb
imgi5CO5cT951i5oYOEJwsG2udigEvwmpy4E42cTIDus5Cjzm9VHCmZDfHGtWxu+OqZCfCWdbuWb
mhzlLItX0vTAsH8pB9LTCybGaVikB8B/YeiVmszLcUA0qlX9bOZFh062MK2VbtKDdSEK+MdPA2td
//choODz+qESzxu4OPsae/riUNwap0a1BgoNwZiss9gYPlPyomejrKLPuBDZfuMZX8QvAfNWD+h/
ATeVgnpi5W8JMr5gAlR3W05cLKFzEenxJcE1z8TvfqBwH1icJ8nBPXs7rDo4caoXyQA8gLyI6DRf
KCYgfMiwWWi6yfwAShz20jL7CHR9HdmNJ/oqMMvP+0rG07nWDXafgEkhnt4ImeVerrACw7Z/BWqW
37Fht7hHKRO7OiX01rz0h4l09X67LL8VCqLeAaC9U4+E0VM8ND5tG+tQPLDKlnBIUnO3Crxu6gVI
fXEdhXGFGs2M1oJ8RObV+sLrWVgtJIvgQjV4l/2yVPrMNo/0ZcwrS9Z6Bg+eQhux6V7abDW0KP5K
c63r+BF0Oq98emPqeRGO3BIHmXecUMT/0m4kbco0KMh8xyKLySoVtp1KedwwJGZkUVexCnGBHP1A
U8Oiykp3/CVlJHYxnJ4BkzCww56mRQ/LQDc2sNv9BxEy7wuQyTkwPBG8IdClkVrHxCALiWHmNT7+
6oT9Uhi/4OegeyUVQtFYJ+iD0RBnEmK9KhZ6rEe27l+hJDcE+qD5Gz1CFZHhN3EZfZlXtXx9JlBZ
5FAFXRpIT1D2ULpQcN487IRLT7/y6KdKQj12vrfFJHyQsC3aPCrDbl8xa+XRMM+7jO4ZDbn3bZMi
/srdyOB3tBByewIal7vXOxNvkG7x1d3Zf1fx9mcToqJXYQUtGf39dWFTdWb4B0OJQ0JFSc68WmwE
inMMzCSAm/vVy8YPY2HEpPfATtGEAxB4+rvHKnTAs1NsXFfCTpULalrfHczsg+WRSMF+wX4sbcuq
rftCtmPLD1cARKrcDDBTGgZp3G8leAcAIJIH6vHAf90eOXn4ag6dQ0VxQXgkpIqC8ljhYhwdJyDl
/ulzPp7DSKdUc4Dm6ZsTfOSxAR8x1GDo7MtXU3wFS/Vhbs3ypmu5PxbEecA6xpR0VlTCR6G5ZMha
+GOGG+puDoEFVtVZIEE7EJlA8OGUs8ID/RhkHuWpmw6AYyxemiJMINW/cIeFP+v8zWh6sbPiM1xF
VQ9OJJMaQRUeCPGpaEMBUJQUgGO93McpUThvHGJoK4Ma6FsyMcLzB/6EB1mtiKtK415UksCQketw
w6Eruy0shsfKeVpc7QA+cD6CFWIBF+HVxn8DRVOEjjuMCu+IFGx2EL0CSnlL4xJjlkaudWxYgNkS
yBohitdiwzIGMn9p/xUyNS5rl7pTVra7eVpFw3k0mCUFhPS6GmMsfCFvbAmv3BWgzNeFVvCbN+6C
sxA6cPNbyaAFn9OiTXjc/dlUsxW2eIJ6aqwtmLg5hriRXIkXIWJtPoZO6H4omNuobTU21gimLVmA
DOiiHuSd18wQgDq2S3jRECQPGIWXCHD1Cz5peEK9c53kWiVgnZ/5d9ZK6l2RotjcJA1swQt5cU3R
uOHtBslNOrx5GBHfBUP6kGnSwEv8Hfvfejw2c3O0VH7CozgOT5EpKRkrJsqEUP37gYhfBAOqP0nE
wW1MkMBvnPztgj5DtcFWIoDe8qnC6e9B04s+Iwo1GuyHl0Ugc/u15ytXb0BD4NS/xg4Bc2hCdX/K
QOTodVWKCl/VZKSFiQFMVq25M4TC6wLnsML3Ynvb9CEGdm6DpL9NG/+eEjRC08UzthT60/YYdwKb
7TXBFZ+EZED7hZO+SnomHQ5qcAA8DMHNcP6xD2rOqxf/R6jQAep1fCSihGUmgrzdlEIJpaXuKvqr
HrYI7Af/IKTk60WbzYJRqB7v1PjM4+OjBB/UrmOPLsMszjjtcsp1mexbZLkjR5Vjf738piEX3oHi
uRa4JCjzEbH+lZQdxPDFJcW3hpVMzlfTDYCFuot2HZSO2Fv2TuSh1FBbVr7bE+G51iqnwBOUFVH3
gOOLLJ4r81w2BxkqBrUqARLXPAptofgNuNitNowNiYGUuBTZ/wwiFwAn2+aA8ZArUS1Q3GqTC8qI
slwW/CnWbrgQ+NFnvxHYHv16JC3Vy5Ap5bxCWhIXq4wJ8Vvg0bdeupjbRO6FEZ1va4emSDfXdhtX
B6dI/+Vy+gjX3HWLqjvmyeT8FGQ59uzZ/q5jsNMcb/34ML2qBpszED+ZDUdMzJZi+U0zKzu961jl
lw548luk43N/9MqznSclnhCfeZ7hkHWMmnA0yqLG5EoR1FjbT+yD9zAO0TThe3ch81Z5f7j+S3bU
wFIau6t8X8Rx0q4ZZKV/2nqqijIm4WRlz6/GGolp/bQEQHjWf6/kIlMmtjgtVMntkAelMk0TsOVT
yNTJXvtYeWZ/I7CL5Xq63bIaId00s4hoKZexRQvth3XBshngHyxr6yS1hxNchhEFC+NEvHLAbdEn
P/mobL93GItnCGixHvdxHjokaNazfEtW2X+PQLkqq0iMDNiCdZhCOQi6L8JwE7O/WheiwVeQ60bc
IMPLrpHtNoFt6OF/6HYsxmj93HOHBKb8goLDPZkY+9XqV8bhtZIQNIV5jR3tatzCpFl2+Fs12dYo
GMJ8Xojo6PLIGj4xmQwqm48t4GsuBQmI2/DLYllXk8ZAmHM8pb566+A3AYXybW5gP9Ey1rM6aYB2
xBW8sZUdf14wfI5OznPPrQ/5jJIXAYcl6vZ0NxKQBYnJPmcpKi1UgbHr5h614YiLcUTyg1sa0Rx5
UotThkSrK7Amrhe3VXcS3RdBIf9drbeTATjJuMBzDiG+0u4T5Jvj8fbRb6eUT8jWqqlPja6bS3wz
ywhDv0UwtUQGTVzmpbkfCbJnNCwYeGoD4QF/UYvZWtd1Pa5QKxWSu1n/yZKny0XMYPacToiocj6v
T2jy6A51O3t5AUIeMvwVXaEjRm1ib/KXYeTsiDtZRj2KrNONIIVccRfhaq6UEuua3yjnA3LFwIex
cToIJcO+BBIPlShWzFBFclCvmmUh4RXRT6QxWxGDWNQMZSrsx74tT3Jsbj7D35u2EC90UUSKaJrJ
6gDKMrbUBOwdccUTG06RW8+5bUSR4+zujtTOTRz2PpKFzsnwjP4pq1L6OkqlnfD/D6ZGiYPHLiaB
BGm/NfvWWUrpblqnfbcHOIgV/IwSTkTdSGDfZXZS68BNoLFAb6JyWSwqy91Ayrafl7uxylTuEU7s
e2zgHCYKUIjgqZwJBLa+TD+YQjO8ht1UMuyMj7byPPr2nWZBzX8BaRAZNyJeVPJavvlCmnCO3CAv
iEAYK0==