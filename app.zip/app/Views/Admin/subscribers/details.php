<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzFmeAwCSXc1IHyrZPJ3IpygBunkBuU6XecuJyciVaq2NMhstUfmTLVLi1DTh2FeQItdfT7+
/0vPgrP8X6KiAAPW2Jr1NLS5385eD8270Q2FLb+pHesORLt90JvmDglEWKmvkxsYFd3Ldhk2Cplr
e7nQAddrxvE+D6OV7ryv0H8RHwQvJRj+MiezirTtnwbwt2+kaBuIq/N4Qy707x/A/zNEdr4j55jk
6hCSMcMtu5ztRUsIg8RoRjOR/pMLVCTSoIKPw+bf5rxjsEZ1L4EK3FLilLfdHo7gI841ty0FMTYM
EMum/yfh42vgIhfGIwpE33Ei7bKfyk2Qx54fBfmZLt2rvUdcfFdmTVH8Ju/CRFp5CsgoX9voVovx
GpM0V9UkcjxXe5rEG+AspnKKeTaovpAnOTQ92n4Jzcw/CsILZQIGCkqaJx/DgWDl3uoDdBa9heOu
+izHfB8Va2eRTP/9tqYbcKetpdfAuHTMHIdtpA2RckM/A/O01kxWXOHFnUW3Ik0z72MrdsoZ7mhJ
c8b5weFTjGfFwgN+DLquRE077aB7lTFOvN8KABIErTuEZ3JZSHdpg2UxtmV2ROWSB5EvitTjah3o
swW+dJrIVjUdBQGeEkD3vgANxbFLgMwVydQjY3xf2Gh/7bVqkuTujWvquACMNO47ZPg4GYsuNetS
6NHVxvNmTEtl9DLzeM83JSHlprcpUVvALfqin4IL/orkguIJy691JRql5ZzMQqKGpsefqRsjYy1U
9is/ZXEeYXDagfxcqCOD0Um2A5FFJRmd74By0GSqMZ2/jLNyiGaKLCrJqcQiUXVu3kRGgx6103TL
ZOUT+OCdlL/djHFJDo2ROstuwvhyX3siiSJPr8eA+Hyrd1XjtgOw2h8vqeuZZWv59JcK9lt0GDHt
esVYTahy6Sl8yu9E8Y/E7ho+wa0+judyYRubkYjpflLkqx4fiHragJgPlmiYc8/mjZMY+3O5YjaO
hUKeCJ8YxtFWs0Kr1GhsmdivtFx2cMHe3Zyh8v58heLyaQSto5DmrWaQFuVd7IwCNj53VSb5Uv7a
0ypTcLd7CpwjxvxWRvLUYj9ZQM/SHThXjfMSD8j1x+hsNo2EFmeezOzhOv3ySPQfpf17uDlr5p+/
LxpEDslIzIgSpehSjLyfEQFKMgAZl879TF7dGBQcpHJ/kXSCFJQBIZtszcUHEoZSvuQ8D3PIEwzm
rd8/sIuvpngjqCYKQYJL8GwS7Fuaxfqu81L4K3sDuawpqIhaGVXT01/3b6Y2JShF7z/FkWDA4Yfy
VPh6h/xBYH7qfYynt06SiBzaTN6vvjRz1zewsW7LzKWzBFGk/oC/ZxMoSbQN2thI6Dh8lp9VjZfm
rOT1qWIhTbYDmtHcbC7C6gZWr4CDHAkc90ujz7edgSINeP2nO4OUNFVMV7cbPNcohC/923zLZv2Q
xhPyFai05XO7WLZY6gMPw+LBExvIQAWR7SSEsV1qlrtKGswyScxPxSlyZwCIv+exnzQd9vU46fxq
lt/eHZdBNFkUdXpRXbY+fKFlDpqp0gIlmLdRli3mJRclXi5FkbYNwhePovGhKAkU/AHjplUXgXJ5
m2tTDrxh9KC9Yhn2iUtkMQH7vcSbyOLvB/GNyOYzE6/54mD9tgLQx7kfDDGf8++wpsqrnZIHTD92
5JklSaj4ErYTSkpjqo6/L70EpLvTbvphmpjsmbOAPvL9P1tcOf3E0HpUwF/blOO3s3BfznVTbZg/
pc+2m756r0dR0JDaiLLIKFU2Y6pl8l7itFJiLGzbq1FlX3tjtV5KXCwUd1gO+6o2eApZH1o0ESpR
9nG4qCKZQdpgDzOT4nbK3I/24PCYS0BHKmCCQKsC8km6tYEVavIdBtBMEO66rlnRumrDnPX4OYtR
Cine7lVAAN2bcEUZ3qbjDqxl31MgpZ0wITh8yttlAlrdgm3fYbxdNyp5nSA22tipnXxZ1QoSLv80
xwclk9IzPPoliUsPTBG2XYrRgdSKgWhl8ao9gg2Cp5ILqbqYDp8P3orvP/zldv01Pf4xWq8YoCzi
qXgcyCWeL9KbxWGx0pw9BMinlaE2HiDdvkEpThxHTJ7PpN50HgU4Lh2jKN28ECZm/Gk9uNwOy/CP
Gb8ut0Qg78XOzV3xDipJTnAya7JXYfZDayGNOgoGAf2e66Tw4KzpWrlbRTi7NhSKOBv0gFmmVpNw
eQ846PaUMX2RmGKBJRirNBxVP+PIwC0UKeqcPjP6GqgjKXHs5zeoQ2EiJPvZifEqRiONQi5kKIf3
RgKCrNhlhogs6Po7a2q8zgV52n/7M+qkFdbv28VYqbQCvEpL8j/m+l/6+Z8FOwkpVt7P01OrupvJ
BVfb1+UlivpgMKTIIMv6T6D3l6UmBND0KDzAr4jTSOA6PxGMczzLVBs592ZWM6D9JWSCc0rcna32
Ip09bnjwtIsLxTaAjGzHbSmbuswRzfszCa9/RVWOCkqX9GNwU+4fV/IJPMTyYWS8JzOVKDZNsm8d
lXpF4XBHAvZvHL64dk2DvunUXYzEE8eZaMhBCiZIGs1RlD/eI8VYTycXkLSh5BsOz4lAoUcHsmDV
sPwdYBehWd2XmbPdGOhUG/K90AjMZgX91YPObvtfSuaCDZEvOcDy4z3gEu9QqL96XTf9BIj1PPTa
VquJ81D1KM9e5m6XW3ywqqOgl7fHtohILjuZ0kIMkJeMJ5E0z5yXa8KF8R1CQW4npzGkeY2bLdUW
puLAhyUMQtp4I8wd3qH2x/UDVpaeoFG3I+I+GMeiSTZTDgmkiGdUdDojACWYkVz6uA11ZfJutKLZ
nV/xuihQyLPaHgvdHlakU/KoDgRkB148ueqNRAbmUhhcxTyZ6RQ1gyfVTNvtie18rvLA1qsBO5Fn
VE4W28rjymHqwwmPN0dIKpkgCaESQprp9BqmYbKRrJjS15ZaZJNPDnlckSqE0PUiVLjSq+8Mayxt
rXcgYDHtHMYUxMhgPo7frL1vaUai7Rf40rI2seJvYLqveKfZQegaAVPKBpsrm0OZ6hLcA4B+1ZOq
UdyiPtocOr7mG3v2qu96XPI8RdCvdnEYSpsJdRXB0ioGPYgPior4Eel1RhU4hxGrE+nKpUHaQ1Gd
zgnb19Vfpu4dkQ/0hQT4ktk5IbM6qWtKOzYCvTSYRdiB9pHTL021OadmdSUnvsGZ/e7R2PHkGZz1
pFHUcgS1CUrK/yBoaA/4Q54ibYzcjtMahVkxcLoH2vloCVj0ObAJSXrSdnmogpD+Qk4MZHxBB3Hb
FPvZYr+YeZzX/2zuEvDH/SSiD12SBgmOPWPKgnG2i87Bdf516aHih3qG+RNA75OHuLu6w2/BE3a/
O51wr4x35RmEOaeW81KNUQWVr4NhbZlZJvdv/qT0cMsxnuuz/5oJg7erBeu8A+GMCqO4neh5gpcS
wVCPN2euXVbY/xHIcQoOBT6HgSmMCsOH5g4G7uxhok4QNUaSSYyqNRA2PyNULNNigQTsCtSQD2f6
y7soAmZvcx/iEhJiEr9FhiiOZ65UDC2QohP2IMwMOJTVf5K0t4e1SjiZqzlKy2gMwbD3LxGmA43d
I4yjpx+5NsbQJ32wVkkK131aEP8MTMyd5AcaD31bwDmC23AwR+7wXfh0bCaQp5XXcJbXOsU3fwgC
+dOTVz+BVnT+zLRsaHZJiFGuNIFjhtIjftA58Mxetg0ijYcLpcTrvfbyibV1ar+M2zQynUi8v3OJ
5ghu5WRJzgDnEF2JDSZRL2RsIzUbcRPg4xR8nA5VRjL8NNHjiaeFtm0mnBWvfDf/23AzZM3hYhOg
XNYCTcx+GlO/2Bj5zzcfxcmW6Ta4QtilpqAPWgCEdvoiFZ5xrLhaayAEnB4BHkU0m5VBnQDgoMOr
cWqM+VYNC5vRE0Q/j+03fjaKJ0ZzKOb2X0VBco/JpTOvHLy2DBeZwYp3GJXD+EZ7yQ00kBFK4xar
rkgL5NbecULCRArUgL/2KAQUhBYAMqPfGvwE8Awa0Mo7qaD19i3QEVqCWvl8ORoeLdTZJp0DUZ8t
GY8WoXHaJ8FPhV8SsaT+j6XDX8AJyF0iY9QEYbC9h1Kq+hN49Vltt7GZ2RD3BXs3VxZ1doXEjXfL
qzA73UepwA05XDt1TOSA0l+enQv23mQhVPQxWWsHL8NnPVccR41aguMa47H2TY0ooPL6R5l9SD+u
n9psd3he6zd2iIy73gUsAkrvFXc1cZGeUkCG6lEkir79B3Bk9ROjJrMmC91h0cLEgJGkHfdxK/Ek
ZQ+rOeDBpErOP2G44eM4xyXdgN2JCw7vLHnoL8jZ+sBNsy8Uvi8Ys9YT+nu1NxFEfTtv/S3g27DT
eR9JCMoZR2MufvsYDdowSjPGYZk4YgyMHBztdS7wps5Pwqob5lauihzNXKeUbnOpd5W7Eqp+UcOG
kLXARZdwH0xrKfwd5vpiBSAJKl2cbRsDEmqiNeIZ6IpX4nIN6FwYx8VlLVDn/rKckL1a0EQoGa1Z
WnAykwHxM3V7NqBsS0ypvwXZ5dNzDSgBhQ/ntDLiRx7n0PZOoIqPBy5mxOP60lt+hdk8CvkjSawl
v09aJgrWd5Ca3wnXvsw3ZbfYywteT6EtIoq+q/12b5AFqVB7dw225xd8FUW5UPzpD19rN+QkqY8E
yPR/Al/LxMUtwpKinphExBcb4YZcnoueWX8CnpVq3IDHPH5hg+GZFzHQ3L/SBY09+gy06MwMoZl/
b33QS3DwDXQHsyK8ltfJiqu9jhgOg7/OcJhrgAWhb3FB5WpiO1dkYkpIZGYKJ8XxFi4ZmtSTPs5C
B8GBRBcT4+zDrEcikeMratj/N/tZi5EIVO6JlnKhH8kUicVzIJdS30Sxx8djfHIv+OAQfuGs6HG8
pOUhFRhcemHmZQLlWjMKfutj6VXvaTRsQjDxfh/WdkBkY6vY80W1UpIIZxnPfrdqnCDf/al410Mk
QXV1Rif0LhubeQt/auPF/BdI2ygQ5khoH+XU33jgKPizAqcex3LG+kEAWKArsij8CCb7J9m9yzRs
YqsoTEr4EBZJSAx+qeNQW2soso8nhyoM9pcM4mGFzmp4O9r7P67QTtxk6Ag4oSudZi9yYn8+DO78
uAMENx4T2Ti4fFvVeTdin0aWEvtCe8Wjl79RJf0zulvfNq8tVkFXrfSOTxiszYdAnXNNMScQqGrc
Vxo7hdWBJ/gNA026IsHU0YiKZH3dTxiPuTCXhJEmZ2V4C1z9A5zQQjWRPpUxVXRhorwWHwBASZJS
GIf19byEIaq2+hMpQBPouOtdte1TdlbVNnznFkZyWnBfKm6uM5d0NdgM0xoUlE4Uda2smVTzgwVM
SjKVl50hqvc88WQnZW7RBvpwHBZ67xLS+Kv3rOokFrBWjsv+47/R1eRl74fKK4cwB/2ffKRH0tNG
m/kJur1RQiC7Inaozt937061zHHw+eQFCLgPptmearOjKRRk+OOtDN+F2Ddp51tbYcxACN+XithT
1Rf/eFPZnaZNBbBpGPoMImmwuyQoBtD5ySRWZ1DoLeoKlSPU1nOvjOE65YWUDeNug15GltpLieO9
zikCmutdfRootHqeRqSQKoSjebNbhdNwItjjlJisjGcpGL0zTNrpNoG7ZzzV4mKZyGedrkkw/4w3
9eYIak0Sg2cerWj9mHQBLIwBC4JB6G02fs8JpfivmXCLVRBovJQhsgZvoUnLwj1XG4NnTwiti0SD
arKVj6KounGYCOQ5drCYk814+2ptQMEUAPOKCBOpC7OqafYbzNiP4giGimcnPziv3gcPXJA3n+3/
ksrT07p6kuMZeoMKST4rltGRO9sS/x1VYMlodnltN4dyp6S3dRDVsBQMl1dhnYiQS+BUkAarRlxr
t1n0PdK+IOsMrthrCIsi8SOdT619yfNzXXr9r3Wq0Ti1xuHGaCaOQ3g9NaSbkSIXLuwYV8kuJZBd
STv2M9pFksaKKosLyZh0hcSmCAV45/QebkU5OMihZKT+WEtTMHTmnCwdhmTEo0nNqBbxrGqbCF0S
Y/0avzTwrKTzfNibUfLeAjeC+8AHylMTR9svuAsNyFi5bsdWEk9crEo4fA16vQ4tzhyR4nhFP9cK
OIGIWr6mY494rEXAc84sdDaRUqYSCJcuzBYChAUNMXJMzYiBkJH/1HZ0WElLPOJl0UVLDdRIqH0u
NFdp08sMbT3ZVXjXnHNo69LF4M5IFG7E0SVaX2oKJrv77SBpL9+cfmIlzNeHzFohLd2/5GwjLoKr
ElrS7685Fzi/71s8dURqSy/55aYYa65Zm8Og7mHRhCeQK8K+nTlUmwH6br6pEUwrOAoyTykJdbQ2
Ob3vezVLk6auJrXgwIWjbsy3f65x3hstQ8OvI+2+CVd0BIaUPdmSvi4XdfNLcECSZbYgd+mn3Bcv
LCBau4fII087MBErGW3CARn5FoSax9EFXlsKk1DVovVPrMK70pA1T8/VlpBbj3HpLW9ox0HhOKy6
G+ij2EPsSSYrUHF/n2tC+zBbfyLC0/zMYjRXE5ZlfxZN8VeR/dDOD+qUtFXEOX+VPno3sGZ17xwY
LRA6rEQCUH+aQ8HzgKOxpeSKpSjeqob6T8K5iy8OxQGQwayXtxPkjETVmpwmV+juWIMy9JsJIZDH
3TL4ptDD1knhYKJlKl5SIUW+f0xRb+OG/UwICVu8Y5FUpwjxMS7znM1DbGZTcalBu3r+fU+wnjwf
sk9OpJyBIFAGhEZ3B7PfkEifScpkASkX2s1RvHfQqnA7ktHCjiUtHKcmV13nPxt8NN4T9a7IAUBE
Xas04fEEJEUuMuETdpLLK2YuweHHhjTvjP4LlZfvTHA2vGnOFbHPKzttJ4J9CvTmfN2U9lqnF/Ff
aeFCria/26LaSLoHxCl8jL9MXvMbgLlS549rKnI4mCrMrQIEdeCHTbEKQHfkwcwSUgUQLDv39NFM
ZN7H960G83/YnCGTV8+1UqBvgoOsUgMCAe/NGgUlZe2aV0eCwYnvdG3vMy8YZADLWEsgm/nHzRpv
yLG9aRcQiPMnTIo5cGem2sbW6QsDfJLlH5HGJ1xA0ixG5G9pS2C6HgQQ/rAGxM+ix/mslUAdiePy
ALTKwf6XLwPbrlFQR/KNn4J16SlsvsmPLLXG3uFZHFMxE2DTdfmMsT733UBDZj1lNjKPLDkJ1m2y
CGfJRawt5XBWAesUyXusI7jQzdwn1O8k6CGCSlSQE9OcMbTnXkotTd4S1lShfoegAUxDrKuaeDPh
LLDQ2zlCOoQ5A0cWVnrqJeaqNpe9LRBmBz8WHFY60KBN1lO53kPo6Ru0JXHiGwkaUGGBM1BBdpZ7
bH9m0mSPBEIv0N0Y31OufWa/wpGIdy0Tn0L8JB7ouRur8GLknNl/Bthy8WsrVo4KjOtmniTU39Ic
T3abm0IGo/+R/h/M3jDb5tvco9InfQFO+oWcSU7MQF6HO9YgIshJLiT5gPmD+as367IxLIJ2qgUV
n5BV/HH1W3CaQykc4kJbsNCkYOXMA9SuyDaIN81twdDsTUXvBkxj8Jse1P5ET4ZEO5fVShwLc6ze
OuEehl7Wo3ku+6DzSTlqUzZYrbp/G/rdxmPegJLC1l4P4LhI4BDH5WRwbOFPMpwfaBeC8eHOY2Aa
nXW3ofDGD5O1TShXQVnEhFMyQnP+3ET5P1xw34kCKXaig9VRIxAG5C3hyKVx8S17WPkVsJJ/03QA
u671SWW0xv1YyMl62gAnWlqY8HsPhdglVSul7T4BO7WUr16STPaTq6e/0m2E2btOCBCMN9WnGwZ8
X1whswfEK1g1kRsrPm8jdIL//6E5WKk60+MYLIaAVyZq9huSOKXMbTJAMfmIXiMkWskRZVuJY+qN
/qbHC0zaGdhiST6RLfWqUG3f+/cV4g8ZwiJfDNGvJ8FE8Qare0yZLKnCKPkiwvAzqJP6KXuLrU1A
0PUfasNzOU91nHcrt3O6Zd6g5jGLJyBuMRwq1X+XhpMjjPugK0wzm5ozyrWGr+IyQpZ8NuwZxna8
ZiDijHOH8qhSuqCvPuCY1xj1cNBLCcKsVvyQhJzCHz3QoegsbodAnBht679QrOta2feVGCWcZJUE
xH3mHE4SHhgpkV95s99Iy9b6wEQ0M3fgANEyNSvv6p99eKXZElXBqP7pMBueHendaPjoxq1Vo/Aj
fxcFU/AlqnqalV+s4efs/WrJkU+V1ISnZoZP3B+fdyxt6N1QcmPho3vRWciPLEE3cg2Ot3fDxDQn
SXy41F1BNS0It6SImjPgM8U50oi+5PHyNacOyvryNQ6KAVdO4lNGf/ZmiwYWnG+6gYZf+/5cd2BB
hGGnyGu25riz8DcHi1/JwVJhAVri3qY/ukdTH2PbU0G0MGEnv/yzK1q6qVcAYxSDh41cBeeR5S4D
XGAdz1LEJFds1/yBWn+Qg4Yx+nBBS5XVY/qdeBpksWhCXX42c5vCkNJybvGxerCTCAHO+KDf3JsR
IrprrsNTa3B1zF3SJc4xiNd2geHBh4ZDbwlCf+Orem98NXtUkef++ZtMuOb15bhRqlfO6iDj9xu7
9O8IoMUtI5JuTAEN9WEXjWrmWz8IDTpq6nQInloD5ISFTUl95caT0beoOw7qi1wdrxlI1GRPJLkV
4sxIrhkZYiLdMeEm7mxY2vyM6bSm2x9SkZtL/D6/0XEhqqEETMypNWJB/NtctRj61k4E3joMuKkk
rs/7XHwGBU3Oqw/xj+X0i6CKr/5obgrOp1K4lRdPBJC+fIk+B97Xb8/Vpb8dY+s3TFYZ+7mLehim
Mw0p+frwbmkOkOkjlZ+Dabvsy4oe14tcVG==