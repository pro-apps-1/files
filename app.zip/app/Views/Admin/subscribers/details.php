<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/CSZgwthtA1Jl8RZLwKNq5Ewm/tO0x8IA2u2g11pvEV03IWdinucsMb4aew3nh3uhfGtq8j
Se434qvwi6Dtql+fMx45R+U/gtd50tIO0BAoejZb/haR3WHZ8Pk9p3F3R0ZUo/n1+FIb1952Gdo8
wxSzhxc4qPnbQHuXcHEVkMCF3VfIJlV9/KQJzwrU3jradYlq9QbZ3FKLHuLUbOqpzu1wXX1kSX78
DykkVNUM5WelT4CHbYrzXweBwex0ZPyZxSEvbe2r2DXL8GlSdw9cbuGu5JDcwut3T+Mz9BqwkiiJ
1db8/zwB5/uIgI9cmocwDxRG0takignAC65jGPRGQ7bmK8OMYRqrnA2/9z5VEyxyqaP34IA+iivZ
UFXNFSg+HlAO45BD6uSTC+19aCH3G+i0sjYPec3XBhRp6GAelOdFmOjxFiNHDeQU531posMnAF+n
fAnHKVi3DIBL9kskckrWQ1cc1kYxmbA6QFwz7KRmeDc6THczt28MYqf/XmPStKCXbylqMvpbKxp8
ihc0ZXtoaTataj+pIWaDmd4D8azuvHqwCJCKJXoQdEIqpre+yTXctD/BOGMQHgRB4osM58hy3bI/
EZkynv3hB/EysJR2SoHvNWTBOTGiNu6UjT6x5G/JtJeKJB8pETTv8RdY/OY2RWG7cpKd51kQFqPs
M+dOM09rtnjauQcBUf3siV03xXHczZcXAC4wE8ljJs8iTwR6wE37GUaIIeU2fTT0Oxuojctg7eLL
PEMsB2F+waOz/bkbocxwCsVF5EoXZdKdfnnih8aefub1QP+v9/q98QHV9FD7tW7kuI9uM+C16jIy
rFKIWORsKNC6XOjlEbFsv4gY1YRNmSG7rLZWLuCfY+qgloDa8f860AmDdARH5MriXSyd8H1gLu7w
MAfQdX2MsxfBJJ078RipLrvUb+evFP9xcnnHoOMv3rZyLTK1ktfK/aRikGVDCYa2dyKUoyRt4EK/
DSPvBnm6874YLFWbvpOcuPZM38jJwVJVuoWuRt5h4wUXwA0sUaJj09UbQCCWkGDxQR0oD1IoN1fh
EaMpLpKPH8+kAGpq/1CsW8MpfxiMBCw16BpIk9B7CQmOQkvVEqLqN9pA9/rxyEl89A9tClS7DqYd
oFW+q0VmKgPUqpi3SclUK9JdD5u70xbsvv1AItjnG/ht3wqXQaV6ncYCJaDQo+5DzQIZGNGFnA/O
rP7NpNiPO8lb8UTXZrOZ5F1pa5qpyo7F2TZ5ux6jDk03L6YdIx7vQ1QWGZMQ+Nwrv6lr66eIL1Hx
nXQfxcWOa+FJkXlPVHhY/qhqf3bYn3KPYBVUuvT6xvGSKWPiNsivBT86vscH/dcIZNG/pyzTQG1w
EOZfNWb2KnE0ZAqtj9Y3+nnv+RbgGeDCxeZYHMS/zmUGgr7OP2/jw5diuih6dWvCRuGZGnJe3PNM
SD4veYTLgCt+gHEA5jNnptpeBJUeTSaPjjZzmeuxvximov4BkMYkJpcgAhCWMEmTqV7kS0qpaHgE
2w/Ssz0QfMc1j/dwHmD0DM5JJRACBXkeKNWsjHjaPjqvOza8wyNqKQf7g152FjnLN//WpizlBlwJ
i4l5rs1JPeBg0y1R23GXbT2HgM1rUXWCVirczAv9cm6IJju7H1liCYdFc/U+O8O0RHV35DHynai9
rUxI+PIVLtIlKV60z22ZUtIOtgiMQ0CM6+W5CwhwdR/qMtGABzqMSepr3fTXU2pV0J5H91MMyNaj
vQRjtJNxzrHyxuccySA54zBDxS46hc3bJre6cvpy0F0YD1atgO7MOt1mTb9Q8LLPrV3FMv2pPEzm
Z55w0O/YkekgoFYb/KEfVpGKZYsxlt9MHZJsX5xMvQxiMqjiGPUCJ2tV8EjKAmbKvUXdsj5HVVcK
FMbcbRqjfBQrc0TQJj+LxzlIq7yKqqiYJMEhx322XDH1sOiONc2S1tz+AoAtYJdKzYAIL0Dva2UI
10RBEA3FJ3x5Cr9IV5rCqfet03e1LRYJFjqLtRPxjeFrtd3IIHSDwEpHWZuAayvb5F+uK5Ah6nEG
h/jiAGursEAueXM5aVQIxu3tKnm/BlRS5yT+1D4szdlG48lmrd9SDoz4FqUQzlBl9a4i6lILf17G
xsnrbF7Eh1wM6wDSxzC7sf9jqzCuSHKsClJt62LsvHAZl+K41W5yy1NgnQeTo3Vz8JGXRpFDrQfC
G8nMQUgWAdMWXmminM9EVSAI+5naaSODDpMaE/IJTaxrThs7Lfr1ujSzD7/daQLE/y2hwNHYs7Fg
uQ07OccKZOrXJm1OqMmORXp8qt5xBNz2UVuXK+3XbS5IsjUjPV7qipVHwkBT8bhdQV7P5L/cgxKb
QQmYmtd2EY9ZcLjJh4ZrTm7mLCPB/r1UJJEBfHL8OdjCHZBUT+MKSrRUJvh9UgFfPEzoPgeI0cy1
ZewCCjNjHk2NwpC3dSX5VckCZUJ8tjCH+K5bvQyaPHgrlEjjt5zdnwUZPcdQg/tQN+qNpQrfXMzg
gRbSeJsUakHE5SxgJSu63OMVgw30coAKLGeugHGa378E6OV8zd2cwejEsqWCBCh4Qh0mWwQd2sZf
h6tchOk4esWVo/Sw6QgddCTdRnXsOgTUXGFylfeQQO7F0uKtu41k6mvBmP2waJkXyOl80hqdUGMX
lSNxUsG7U8ojhLTrc7ktiEBvHvifM0VVxMSRCpgLRmKjB+30lmqPsILuR4ZW6InQV0h/5hwuPSrg
xAPcfwBvLLVXyjySxhL3BGf0a66nQv4JxiwyjslySbzFUsjN0Y/ET6K2t0m04ubrfD67A9IUFfYU
unH/CwGJX9URPGSU/DQf25BXs3TPC6oWN3UHCYn2T8CV8IlYc2n3pwsPgNEN2YBEZ7NBf0GHgDWn
WgYPXU3NCKgXoXmUzGN1NcDLPQhf+COINCKEYencRttgDVEWfxuVT0ECbMsF4Uk/MysIDiroBWjK
bPvG763gZ0XVWzZLmhVqN2IX7n2rePXEanGwkPl9e3FtwhAbAb9qQWJ/RGpTZ5HID9iDJi5m5cgl
OjXypIITUqD1O0OfQf8zkURhtSpKV/+sy0/d/3VBi7H+R8DZo0O9L9SqknLg3OBmK9GhR/LdR1b6
kDOFg7Nm9O6PdzkEJrHvvPwDp+SEvP5wIKPy+Sc5pyu1LpY82xZoEJhn7y1V7JIX30KGVXLQA3Jj
l2AddIuAhWNz5LCSS4epMdr9FlshAwi3cuy0HZzpeW2sg/s4JhR8/BMJHSlU4+sKvTnwBBx+5j8q
z6dPMup9chOeSLzvf2dIBrr6raa3NKVTpMDgxbrfCGSzHHjo3ywTuh7WwiWeebDGur3GaheB7xiw
wc8VQYqho6Ezda4PcNBjuZz5vhHUF/6svkR2omMpi80tDeaBpD3D/SdZKy+3AHV2NOTJWuu20oPB
9vwnXFL6HxAHBSLfxD/tWRFnMorDHytWVVlgPn6PGQnNy1nrsG6uHzIGxj8PuEz1e9qih/MOgsn+
x8uUusJGkX94vsN/RJtoEZRbLET6r6l2r00R/RruvNPcJrF2ZqYosSQuZeafI5tb5MogfSyRo5UL
jIwvLyKwdLZMhI7EaxbTUsrUcYFfSn03o1cC6jKrcf9cKYRoSXBvGrHkk1igENTMrpYpdJ2qQ0+N
Me/V6nTDKfgM/dN0vhsxghL1/LmLkBcbVreOg+M/AyYJMO5F3/3kvhJ68p72hasuRW+1cpxSQpQ7
j7t+JdPnjJwJJDSpkR4N5jiWvM48+RIKesSC9ElgfkknpFCWoxQ4Xm4YtPCDOgkV2T3wHCaJ3gxu
pII+23RFoYNDpSc7PPL+2dnQW9Y3ardYFV0jodbQdZdHG/55MzMfRv+Khh1uYonTpHcRbYV2muLp
ovDeQWpGSShFIIlDa/1RgvUkBO01/NIIfq5R9rhd8+svRaZGZzCzfmcExfZlKOOPaFJ+SsGF2A1m
TCIEiUVSTqaLdVLOlTVZuSny3NIl/syqT+wqqwrUpGxm6XsZCmcIxqf9sayfa/R6QgTAwtuMHtGa
ZdC2Z8t5br1c7xpzGmNd2+5XuI1sXKkWL7LCPb6SYsRZJgXgWXTq50iMA2ImcZVwFGpJ2iBZZKbj
9vc6FwrdmesRczrRUh2qI4Fne/Yd5pLB1GuH3gAeHPD9FbnleCAjlGV2VphlZnWqtyp9NLvkGvTC
VtxpVO4e8Eehpo8me6dZmr0MOUk9xWEGMBgsCNrpCj1me3BYDFIk54rYkQszqmODw2NS3ZcPD96q
hXjLkNb+V2v6lJEjDbwQxTJ9MaKWv4JLG1HCS+dfG0N8EmO7OMDaOdarS2zzec0GJv9YnX0JyWkB
aBpQow6Pov/9Hb6R8j8iEMEpXgT1ZkMfEiC6Za1PvL5Dz8YPOYkW5cxhokfiQBqm6eEKWVF++4Yg
XnGaumodsRgq4JYKVx6PVysr8Oc97WA3PzpUUhi632hNENKw/+MCXiyfpjLh1u2lIo2oNhzlUXob
E8gO1EKjGfr9hRib5DMs6I9YgMG6okJPvgl8ni9/0xxeWtXF4IM1s3afTP8PdbDYwPLUrqMc/Kk2
Ir/1uaudBZ6hJsPt38bNkw1x2PEFG/vvrzTIMSeFxHBASKHjgI/AsuoaerdoS5BVhxruHbXkASLH
eh5ey/DDS35E2qgaxpBNbgWNnaq33vapDG7cQ9UZjg3gzgd8bfIaw/u6KSOCzMFnnfjmTPJZRYJI
qBna/kcjAKfgFp1jtFjYIA2/Fp5tdjo2lOSjR9HfgSLbcN1S47stZ1/GP0Hwp8RrI4EiL6AWrOVl
VqmBYuH2FrN/Ipf0X3NcYQeEJsKb+z91EALd5d1qQe5V1Z+XWFa84I0Z1rQ0PyEY18qtYr7Gmh2A
im+bjBaITtSgD9CCVYUsQhCdXBrq1t6rNXsCDsoIxdGYUsV9QYL42ZDqmFjwBjUnsSJU4dcxXTOa
Bp6Z2c6WC5QKY/y50B19Blwuvca/YT7ICD/8x3JY4fi/Wp5Huv5vie89gCkALHg1d3RCzBo6nq0Z
PRF3sejy+7dtCgBB7yJeIGbX/4fr6bD5Jc1G9usxPWav1dauohPRUcFFYfBrWA5u/jfL+izsc8Ph
R8uphe/Gs4kFs+sS81XuoR6WtlqVxopALjAeoBpHEMChdVBtBVzLKTNI44u6hn5wCHbGs0zSvwd7
h/o/85SnNkaPYAVckmgnFHNVrKKk2hLObE9XV/oBSvQAG6h4ZNV4ZyX2ZzAlqXO6DOkOLdDaYU7J
AOCFOqyCGDONAVMCGrZCLva7VMSwS7RibrXetSxPMtauZUxeGdkB2un8gWSXMnMiJy6AtKl8ii5g
KccWyOaF2oqxa6dCf3guPtkHw4CThVz1B8qM6kKi2NxtZigtKhNTpPlaXOnnoof8zPJdyyvTCOCv
XqZc5HmY/4dKC7Es0hbBfU0Sm0uHeZHA4dm+h4YD+b7JvYtfvKAjdmT7HwXpMZMqEAwUC53vS4MV
ugkkt+6i6+4NdAaTWH1Hgqi0NaNOzam5Jyz++NCCz8e+wz5ZedugFpZOVR/z29rzVcsBcx1rQ15H
tBt9PMtpx4OZVe4OLHKliretlJ3EoMrAUucmX/lcfMI21/6nej23UDmPoej+VTQn2h8l4NlKi4hO
Smf2/2DuNMRFrTNRasnwUL/dRw0iNkDdOONyB2Imm827G2QASK+jVHFCf2ZueGwAfK9HE9VRV691
yENcN0c7D1DzbZZFRoi9r05Ob1hvKD3OJdWD5+dm90v270tuZQxGTGDajfeRKrDJyLi5cl6dxftM
JUaSTuZspmClMbjrhKj4sT10/tf1YGWGfTaXsyUftibvu/ZkOm665mXd7ykme55NFGEiN8Bb8HPu
x06JXuRyOeTcziJsesSrLdjAcOp/L+Lk1RgAAZsGO9C2z+MMKC94e/a+wirxh1tuTpcehu8PFyhn
bbC4YepQrCq5KPXXV9Wt5UypHL8HcTOcuXf1EHRHWuXUKseKgRpXu573JBF56L8z+J21iZWq5Gd5
Kh/UGuUOE+PZqPmG8qyFHvrn3n+gEtrIpk3pUXRoivopLnJYQK3pPaNvLd0Kg0zJR2FgA4v3wA4L
awyu4T4z8aqwBwucmURAqLfNHGmuZJWw9X0tanmxB10u7gOD7+lxrzyFePyC/0mpNOTTOws2NnPM
rrMktZKebokefhkGeswidTWn4lzLLnB7A/7NPD1M+l63Qzh0EWRj6Jh6I9zyljV125R7IteKGQJw
J4YQbcIGD9qMOqZsFRbok28//If6OYzGMUTBqq3b3uLnEFxm2w9xgwr1wC23iAhZlAFoy5rz+y2N
wLuggSuv46+tXBTl3Nl9lARqkevVdEZAdC/UP7UhXm8KAA9Vh4+2qdysCaCmQViiTDHN8i8X5cfa
SCw6E1MtGze4HdUQItJg86Y8gg6T+/Cp/luxgMVnmgxcFpST393PObNzH6iJ+Cq1GUIVaEdksDvZ
+tF6DLrK7qP0kVpGe3GnWFFGL3C6sBlUfbxbdYJnihgfjUajT4sOg+9IQMmsyvKj46QKIYG1C/d2
+CQtq6ahZ5sDFG3kh9BZyr84Np04yRZoK5ZXyNwduOetJyyfC0m6sZVuMHAD7vTJm+rH5wPEm7em
qCk2U/us+qrmv+ql6eEaIuNdX5nFIQSHnOP3k2hbVpzzbEbE00StT81lQvUbh2Y3jb5MPNf0iQpM
m5orME5hS+dyQXWgtOc9L/wKqcz0PX753kCoP2QqqarH+MimW0SicPHDxQxq78utslnOxSEb6h/L
CeFOPo7j5aS9nPdChUDHtHRlGd6kxeS8ECsi6SXFfoB4vf5NtjkdPiq90EteLGVq9QtyVapMMaDc
bGMWOf6fb59CBi3gWLyos1I8iM/EnbR/YXzfXKcbzBPwa5wLb170yBJ+MEH2QHWcUB5jtwzyBIEL
JyU6TgMlHUzP7u+uL7SVhCrhMGav8JqICweQAvR8/BbFjlCbzcR5Wv1iLR5hMmbHfNb7l9JzO4c4
8UXkCgHlDyZjXNLJa+PIgTOSmEkpZU8uOT+5H6VKtx6gJpr6zC23IET/naB7AWR0zbcA6gzGMdgh
a97bgGbvDpFF56dr4ynLynl6yTJ9oxta9s7C9DqFxeRtSJZM5eDwUaxZpkbAZ71Mv4KZNq4YTSYE
iwpbZNj3ThWzeA19C1YcAEabmjGn4Ta4wVbvQ1Lfq7FNYgvtVuYXfJCa0vBgMO6RfWSdJl+FccCH
0ccjwK1rErLeqnhIexxDa3SqmOduk9TyxWdwUxFa/e7QKhg0UlFW7A7F1BuaBYy5uSllAaoTYxZn
cNnMaAbeKAVprwI8HUyLDDRUqoRrI9ZsHwWCBax1zQS+1UQIdetmw38GsCS6jrhXBlTXidUhMEQU
TjRjLiSBQ272OKpw+Zi5mIK7Q485xhb+oK7tAfX/B6K6QBoMJkp4auPp0An7+gg3buXBiXDEa6T5
6mqt0zMW4kHfZxhw0lRhdhHyvDSveHXGCAexqFMG8nPjJYojhocoL93h0GqL7BvPyffcEUOtJ1D9
iT8xkpz7/LyxuvezZa5MXow/It/qUHOxmF1X6bS/a9cV3338FOSUsDxJCHNbTzwm9t362sk+0FPg
0N6TIB4q1aMSylAB3xu1pwJKO0kb1s/hInaVsHBs4bcB/LNMx+BumSbDZbasa5fWpyZy8IHCt1Xp
gkupsuygcf4cSWWk1GIAxFBdcVgbXOOlzmxfEEYLOLeQneXw2OLIODKPM0fmS/gPqGhA/vc8Zswp
WaVPKyy3i7BKXynpFm3V72BFhONqyAFLBm3RI7vgMYos7EWBatZ3pvYc5zs0VPjFH3vnhEyBlBVr
a2mxWW/PjZbI8x8uG7zoe8nQvhGBT5h6vUzYismskod3pMl1Sy5BX32lHwSzJUfCi+1J59xcE67/
g8AGNYMiiTVdiPFEuNg0jZYscbz/vOy104b6wkPkzCvy6bxPSoLn/kX2Dv4A1tFiIQq3WmiOTyi7
71AlURDCaQ5qX3MxUBcmBn0AlI6xpAGd/mygied1DAeLnDuJ6UMFnM6om8H8/w//4cG2TwgW7QVD
+YwaDNj3GbeGbwe2x7KF4ArVlkmQDyLQmy1D2qmjmXPVjhl8NY7kN7IoaeOg1WXFQo56SvfUVLq/
SfrbfEL+eeBmb4oUaO13itwM5+ZsKu+wDPOqgTheGcDoJN5jvmywQmgxxK+f1MLH+P0fBbXDJYyn
f69dXhrsft4QAtMM4h2W9VYSVPJcao5tk/mU0QN4nJsRqYN/fume5iwsclcpmd4FjqJPB0PAch4Y
lqMbbnUPm32r77hePZPJomBRV8EY/nbYJJO3Z5Jx5VtkCeRRRRAk0wG5KGZ96fhHuFBQe1sKyQWi
Ahh+y53pTZBYcpCC2xMxBXt+eR7DcaQsKSc30gQUhIhsFtDOA5O4LGOelXU5i1QPUN2gCCS03BoR
aQuMYVgrfCJVRlojpGOIb72mN6I7YTcs7UaZSm==