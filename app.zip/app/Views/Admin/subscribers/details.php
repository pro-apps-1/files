<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+RA2+PiUV39QIMUnNYRGQcOFnvS75KntxUu1nfU/4XalYnDDMEjKDmuJWv2wYPL9RlbPU9p
1pjZhdz6gwVrzSIJt8ewAy0Ub4LlawGCJwkVFwlWbCiwCCvlFVgHrb+TqWpqdgHlOzJTmYXSh5QP
2C8vXVLDAU6TrJk6L1RzTifs55PfgOhNQ8Ns0lP1XAkAAGMQ22Au5BGpMtVixDvL66bWJUsXFJPX
6Z+ZMXwGjKzfL1X74gO/5bBgVnIrIiajqeNfXGmX8x4qZZJMw1YKFlZa7Pna3cKT4TnQDvTDOqNh
CurNCq9OOCpSe1q9AHvN7Zvyb2zNFdBDPORbsyogJDAAK6e3nEdPUzHpiMktiehJvRpFpJ23KfTO
9y6KunW/Fk5io/rqoqcC8Gjy32GILxpzlTfucHMkOVLTyCc9SgdGRwPmKyJCqk2KmTirim2hZoAi
C/PPSI3heazkbe7C+AD1l+XpjsIkLQrJHz6W4ZfalA527mijCZzOXK8Uv1zIMeoUJp/URaOJmYdL
SqGO9ta/zacTCesYTkpw+Lq45w5v9CC0Hd24E3f3bbXb2YfiBAck/aKTruTb5LEFTPXy2m+Zvsku
+IO+GThteVKUrvVtH22vbSny0FYxQ2ShXwWx2JbWbLi41aaeEH//6IpjwvN4c/PMl3gVPCdcxpu4
9APXUT6BjBKMH3QFOdM9S+qHY7PjLtkZ+gIZiRPxK2gZyZl/eZ+0o3y62A89voY3agwOfrEforRs
HmtKCfgJb9Pt1JSc5XKivwW2swk1mKLOXcF7EobslGG9v0wfoSWfW4CQOBPl1Rfdh2HXXNMOLJS/
RuKh2YXvhRye50QI+Wk9iNoqSlrjhsrvwJJtNOsJ2N2OKJQwpJC7+qJfPrcowaR7EcHLu4DgUxQA
kD/hIBF/pJa9d2zFcrFnKf4DYM1kdd73RG1EPFVlmLaUO6np5GnP/mgc7hvQCznIwy1PvbU4D2I3
t3vf1Bzj5PX2S8LXeDu65toPaJdgHkO3rOLQK0Cf0bxnYOm6Q5JC8KcmY0VBTNwOTXSKcYaQrDMY
aVNdzsyzQKNW5xvJgsURFY1FudG/V8XiYq/4UVYui+bYJj5TjThNgkK1UieW2oaAVxDAzTxsO6Rd
dpC3RYXJtCQjXmXcUhXyya08okucS/Bb2W5I1ez0aCrJUN71AYe/Z2qqkpsJgkqMoVhyC+a9zjlT
ahi0kN/rA+ZvTDqXKaRCJA4gJzza6d22LRRVv+PQ78zCW1opKLRq1DRkoUSArgSfI1ycnnQZmVaq
XjWoqzfw3snjhKcTUSxSEdIi/QurONgL2UFFe/IXhlrQCAef8RXEz4ules4wd6ZCPHXJdj3OiEtY
Ptgxq7l75biuuXW+Z6nZRDnWuVWP6CR97DCiY8qCgAdqO7CKAlR77H1CK4jBQXY91xtxbQiKIgMZ
b9tpS16tEfzN3XohOVs2MGqE3xNkuc6ZmXzQoMbQElW6AjgKCNIUgnaXwdT0XntYNm7Z3f0FI4LN
nMCknWVK7BhNbd2yBJKmcOQUV6nmC9jg6zlezvHMltAsUKoFaI1R/0RJR0FdDPFtJU64PNPMRbHJ
4FEqZtkyYpHieersYjdYz4zf45G+KcOZ0sbP2ZTHLbtHG02XjCwLqQiVoDLMEq6g5yxnk7co0hQn
YCw98uM8h4v4wHYsRf0ZeLS6ax4sv5cgb+Hj6Af4HOP9Y7zyWcASxWLYn/SQfpMSdRqixeqs7X6O
3nwGsrEUDnmRtmiQp9ueEfwoNmw3k4dBHcpH67YunNeGEf/D6NDwXU2UDCz2rt6oiTNAC00MAiwe
8ebyTORWBu17vH1xXLX5eVxqG9wDWBBnzOXzFe4Ntn5e8ZZs5JU5GaOOkncsiGYEadPxExhe4d9K
nHTZImzcvYz+8KKHYRrbv2ZdXytkBUqeX9R5/ngzdIiDWBd8f5i7cO9DIkOhRuXg6ZKU3gwUoote
3Zer/Y3pcMre9wLhH2B/7hn/f9Bcl07v4FizKmPoTCDW2wwRgNp06S/ykRuYbLJzsAKwHu8TWxxW
4Xt8Ryfi8vi3iDdt5V5lWgruP1gFNw/NzAXmj2IjWCUXCSa/mi9+Nukyfn+6znoj9+pUpjBi5WN3
jOTb3BYi1ODqA0YhGnHtRg1yATVyOaivW6+yeGs9Su5iK4mbZAxZhnbZrNxr8hgAetqYrjxI+5b0
BbqoBG60jE0UU0wj1qUWLJ3MG91gCq7DFyMzJaXw1yS3+9+DlSe/AcJcp4X0lxmnMTwBPobx84ut
wuMTiQ4A/w42S4imQ/YrkURerqybQOZjkmbGyB88VIPIckuqZ/55DFXCfNr2Q+wvCMll2jpeqAiA
KrGsWYw8cG+XSswZWlDY/OSCx4yB29Im+g40SWH/cKxs5OmPnLcfZwdg4DL1vccmohXu2wlHqtJY
bdeK22S93SXCQt+/co5F9K1zSPBjyOOq4p9DAWB7zjFlRo96VbFdNjGOryxvTAPaY/riLdauPsvM
HcMBqqt8valia/T+rQ9fhncFJZUR21+oKcHNTslJSF2n+7ElXCP2I58PaUE38R/2LlnwHi7Qz4sG
YXsLtq1wb8IA5ABczxv+vDDte79XOqCT+5cUOO1L1kAh1AGKYRISSed3tKRq9PIfxr3kyUv+mFi8
RjGgt5oKcQe6ESdaOt3k5e/S/uCvuaDPi9uFPq9bH07FU6IQGM+ZbBtD3jVJPRzMVPE2aOpwsmWl
ooGqdovLMoO++5+vaRbPN2eVvGF8aEUBtk3d+uwLAgN3nTOIPBmou04rzCvQ5A/zbhAILJy0yoBG
WdR70uotLNlvuasiufw+8UEtO78WG+k5RlG5LHr6INBZkE6TPuFi6uSlIxZPfgRq+WLhvi88wU5C
d/4wHkLAxBS86YtjGlHhltRkcwqsPXdmww8pbt4Nap8mJBoSLuGkQWXqrpRtqi8E8AL8L66T5Gx7
d6mgWfi5XhCgjNNjrmno+Ky/9KpyrKyTk+wVt555mwYnopfIc+t7hoSG5DbcO3klMMmX1uy4HJWS
/39Xe/G7bcolQmcU/mZCJPeNc5062Cf+x0mTWkuJc38Yz/hGhGDsZCLw7302+O0/lwWNIYIWByyP
s4NdOoa/vnkZAnS88tRa7Tl2qOXh3kXKdswF4Ikg/DzU9tQS6t4H2gsTv1x3m2M+O1T4ChLf7VIH
eZqWG4sEA4TEnaTmmGYq9ze0yRpHt3NoGYsjBcQwAd95besTKN033ZMVa8v+b/1HKw2D+r+sSssg
CgtRi3Gd0jxgzwY7xNkTH0KBr1QJkETOaKaoNB2Hl5zDVUMtr+ZCddpIrP7APYymR/J1Xb+ULWmf
46cyIrVsgj0nYmeCYCm+tibv4s6TlvefklorMC+XcDFcPxB1J5386xV0MhMmsDJr89a/IrNsn9g0
uU2uoeMpgBlHffNfkMIt3KLrli3dU4wcXIq0IJHiaquPSkl9TKedl2hyWMwjACNVuRNlZ8+gpG8L
9wVNDzBTomBRqb83BJ4ICsfGPX/Q2pgObX7z0k45yArqhtGNfXxJL0KdRYg0KH9U5xzrgCw73NJI
4ilw9Rjto0AVfJNH5fg5Iqj+67XdxW1iMIvul2IEDsGcbbbH2fcRaIj2wWVf72pVxAomHmZsidEH
LX3p1/eq7btUrl80wGAb4FvalbteyoTmN2c7AfABFLPW6HCXXjLUy9sbiAhR0wDRCGGp5/ILt0XG
8qc6HhuO+Gn3t092nLdqvaNS6qrwKtJLFHWC0iPaXU8Q/+cKt2i+NPmDVpbn/nkdam21G0vCvnMa
h4kahZl/FUVFlVMs9TvZOLfSXy+MveUnekEr4U+ii67RviU1+MoytMSCqWC9zEvRO86Y/BXR8uM3
0Omxo0VepVMQ6lYUT5527+4Ekhh/vdzoii7i4rBs5lgem4mgxFP/oJfpr2aeFLlBYhwKj3ul4wQ5
PWVrj5nkXQzE1amnkuilylGGLQOgM/Zr44H1PXFBtU0BwHBSzaKwo7j7FS/Vxt3gnPtGdEk5U6hC
9iGvl6mEq2yGDOixlfom05hHP28PVlvQf6iCUON5WdO1uZiXt8YE2+yxyOx1rz8GVhtNr/5OaEcI
/wN+GIzw/o+q8PoZ7M1tmqnFYokzc4p6/0V9R3EGuR58DhpDlye7fNYi3gLair9Hp2X2Y1VRUUT3
znx7ZTod3z0fiIHIDEoJYxOvDLPfDvFA9MAGaFqED/NJBhtLadAh/ZAJEqyLcIYRHwAEHXZYRkTZ
QJBogIIUyqLy8c68S575kMYvjOTZwtWHDCAEl5KjZvoeeCLUySKOns/yjpiwhDYOOf4hhraSiT5Z
dfq4m2CP6p6C5VydbtIF6FNHDY7oxy/qjzOFG7tkqq+M5mzSr6AhMaPbrUHm3wedO0h8kvRj0K9A
GtsplKDLVaKRH9EQBymsqkM55q3s7OSiXdibRHGWVbT287yrJU+hh1ZG1FBBsjeqUnXatJwazYUt
SpBBcmdOBBvT/vK87eixVv1ELTcBqvTPRYrpxuWfhEsu31B0Q+Aj1/oTR6FKQ49EFJDEr4Jc1hWM
j7k929z1l+916qBJolNU9klnU7T5oKsYyyZzxAkHOOJjbpWpJM0vVA9mbEcY5vZwtfmagsTjr2fd
dU8MC8AVMIMt/6UNA1JIQ5bV4gEqN8LjqhkeNOjFi43acmOXqc6qtPf9x6B4wmTG3xkDQcL8Hg6S
e4iiJu2F1g12Xn2iP35yX7P5QDVPr/fOef9QiaYIEWu4+mUlZw+9Pm3vhICSkfKNwHj7RT0fkMW2
9KSExbEIk6gQ+VD9ZclRHimfmzUFYdXTDL0zjmTYxhu/M30Qe36r2wCuH8+fbD+D02T0YvpN7PiQ
AWyB7uNHapAgWDxwiXxhTt8Fyql5/+9cGGVH2cIPadl0pEFMenfI+cIZIy6+Bdl0jWK+7ePUl+zJ
SNA7n/xcwNs/tzaBlQPv6HFjHJG79JRGaw97yvDNAw2Ktq7X3MGjsA2vpZdUUi2/0VAcXpBU976V
8bqW45snWxAuOuV2o538MPKx+h6rdY/16Nn1zV+VZWWsZi8OpiAjlIoB1ITUNnFBTP5t34bysahS
7hTP8dpRbmGZUbjoJfTlBgltRV3M3q2iIEptfEQ9BELxf2oNsxbHiikzRU+OGJACi2P6Ym/J6I+k
rOhh9SDJyq7p5aU7apL32EREBB54EGmrWsadzMCaqlXtcB8n3OaRT0aoYHcWnkyvGwb0bSpMYRYe
yeU8TQx3uKteviate5Ld4jGHoDMgC1RXcm1/7JKcG7y8JUhM7aMD1hJsykBO6YF9nGrn6VXg6jqx
w83XljA229VICe/Bi2ZKgX8G8YdTzSLSZylutAfqdD7b+tjUo2kbJWHNyQLvARo1y0WZKmZoNXg6
Jw0ctMAJ6wYnHJhtI4yb5IKphHOIKno2od/rQ1Ibq2DZh6MRpQM48I5NDo/rrv/3/JQ5orU+KROX
48FIlsIpoGx/MrOzENznwGWZpA0iONFVZexCS0P3hM0JxCkGHOS/uADGVrTkE/1nyyOUVwAHOdvn
XdrPcpeatiWECp3FT4TufSuTbdTFMeh5oYiWuviT8SCtim9qGgYkqCU4EXFYb2ppWK5G6eXROaV5
4IaVqmOioq5aZ61i7uDDjZKCDYnytoQjd5MFonoUMQnk/DAz6actb79aYi5h/Y0hspysS9t235QX
Rjj8k3UlS33pij4AkUlAGniFL9QAWxG7atBYxhDAHY2Ge7k1VzUtsw6X+5607HYdB9XEbd7vrwFX
bUdb6lzrozsU+K7pwonfTAp3ES+QAFdHgpWMQQft0kw2uRWZmrH9WalfMsmUjBCCMej9ZRNU2eu4
q3kRnsuEmaGctp1rDnxlImETvv5p/yP/VzNFwbk3xH9ADT4ZxHa+8sywskZ/qOXemVkkhRidSYMs
vQlnyOfUQtwusvvVdLrlSU+iGSfYKKOjnyfjY8NXCRwwaIo3jikT7exEkQ+uvweUAa3oCRCA3a8A
WYVvP/lSoKrcWiDq/uzckR8R6iW79IkWPRF/2X4/N5TgxmSicvz/ZCZmorAUneKG8zaiwQzRhTxa
JQnuFKYFwbmcgl5a1hxO70ksCCiVz0dj97jBebgCfZd37uA+opzY7aD8+Nr2JBismME+idaLJxSx
fxEf4Z4C+hjThgSrx8tBv7J4zZxyuG+NMktDRaYxRACW2NF50ry5dcgJSdv2lUsqVde3a34/cegU
Yc8xrgUU1HhmKCXF41tTQmXokK/pQZWP6skJOPKPvRW6x6Y9P/vkWFC+oaNgNdRQcBT7mn2SD1E4
PS3xd1A29NHaUmJp3iOTI2ONVjNZ1svUoec8byVvbzGlXLd/lK0Yt4SwCiSBjF6vvsbyP7eccec0
GPEQm91zZaNGIKHPznjRj45tMymMv7T8SOuBRKDEyJdcAtmvm9DBMHVlv2LSwyZbpHMcMfJM5bd6
YqWuLUFPS+icvUwB/MG653z4PHBV2SPg6EB2uX4w0fFfll83JrkfGPrSUMakwQg7ve55PKacOH3k
wMKYyW2ELsZRMLSeBsG8Z/TL+Prqd66tw/G7E2go9MYQLi7zpdXaikN99u+R6wXgpQ5B1HB782Gi
/qHo8SezgPGDZMZroR9f+SFjzKkJHHe/9hwwZD+FfyGpLArSqth50EYAybDzk9XpX7vG3oVxParj
ykInpbcQJPjOrbxppFW3vzbkXHt1UE8MEd0dMQT1Y41V/OTKz7gmzaQXHn7un+04H9GTj7kzBpOI
kWsEOblIQPl3a2gLJW7KduZFAMHSnIH2Hg6P/f5zNK8oNqqZd4mvc9xdJ5Msnd67hGxw4Ct28AG5
C+g2VpTkkwo1Z/j91RHDFrxXk/02q951vf2+A3J1XxJOvra5NGf12vNLqt30HCXauYEuVU6W1+gP
eCqXzRWZ4HiYpkwPxQuTsACWd4fG7jNIX6qGVnU5VPl33lUHE6BZYTlG7tZlWuOzzerjPNKXV92n
S8jArHWTyzzbGRgWxHSttLfUNI97OweAlypw6/n7qTJ+x5t23JCNaxj2/S6B0xqJSdcU5ymV1wHu
lA6ZYkP7QWphrq22PHNPMTioDURllK2as8bVE7AeRW1z/F+cFT1m+jxuQHGMYC53wuHvW/js+G/s
X7ur4LPm9Voexzjud/aYCT7KugQvLtdqmbLfDt54WvSGIDOQghPPOE+DKBK0albn8x5D+YMIwZc4
HOlRUSzEuVMAmPw5inuuPq8i5vjRTV7galXtASLWeO4vhWpyvyzr5zosJHyJrTiUYITKdLqkfEpy
3Uv7HqCdbL1AvvG9qpT3rvJSoCtBTRy0ZICT4NBbP419n7wK6wLre2GGhalnAIaRxuxykxdr3bKC
HkjdgVLgx6c6eMRBhvkcyQLMTvCOcrIw+EIJ5cKkNQ/S6enE1GMkt96sOtUNOXCcJWAkb1GFUoc3
LYT8kgn+8CX7kdvSjaoQPpFvVa4zXfuOy4Mj9p6IPXV6xTesTFIjo3NB8shUhDi7ko9Nns8NimdO
/ChwxQeuxM+qZeW5dGCgcqSkjmnoR4eonmNIJEoWQJ2l5r3Eg+GjBjV6VibJldrIabEN6EiR+2se
3iTwKHL5xA0z/73TAK//vCt2MM/4hdkDNaHClt6NQIBcFRkhDJCueOjTHOd/oZP7BdE4vTuI2YS/
36dqWSOvtxiWu99sipbfLW7Uc+xeLcsShNGZqZZoeKNZgdm+H+vk/I/jjQraY8C7+zjQ+UU/Jeqv
x3/gdnURaiUxIa4AeB3DAwkCHVOTPCqApwQ5G5BlieJGnFOozZWMINmQPL7yN9JtMH15j84l3Wvz
ji/VEYCh1cimEmn3jZhmaeXrD+Hdp4dMlcZozxrTuuQzjceC4LzvV+8Mv+/gSalPPj2ePtoNLHyM
GdEVf8YbnHTfd302X1qP/N1ZfuyCKb576PQT9x20yqgK4XDMZN8dZtSzVHsuLdR38faIh2bh7WQk
a6DKrWKtpCPLs4w0U3fwQvsDSPixfGN/p9JeqFgyD/FSSevhrzHTHvHGMdiKg/7c/MyabNUETW02
FeJb1jDSeKyAQM6D4wn40RKEUA4c3lcmvavdRA/cRDmKzI1kjTQjiCyhqUsA+qKNRmPEvGQBVaia
R6EcRgGrVI01Avg9rTFG0I9940p1l7okKdC/nbHkcp5PqySNtROnU47HCnUPbhCMPPo3EQvRkk9f
5XVS+v6tFqN2JYJhrcqecRZnpU+7ZAlSJQ777IGeOyjS+DDuVeT1+Z4mDTXNpYBWFoeI5c4StX7a
FtGujlCRzDjwya4iywr1EC257tPEgUrQpwL4VTOzOBhAVe779BVkq0onQ587zufJ+0k7KCJsGQqe
wvaPr1YJ9YuYAQSJY5xptd8WlbD+MDxlNwDd1FjNrKB0pYC1C/zQBDe/fCwOe2gHnqb6WwxcZggQ
9+2X4d8ePgxR8NeZ81louoLh1lFF1IJ0IRXHu7EUSnLbphQ6Flar/ILfNKVxB1YxQBIuDMl+jE0n
nGK5Li1MCtcDGXxyApcjTo1+DVQEBGDLo+RcWkZ56wlZ9jG8w5sDjl00DgJImT9WSUxkuXQWh+lq
lB/gq2vlAYIOgdmauUewvdeipRKHZH82XNH5mxW+3n+/fpgS+bt6u/7sZQYGA2HZeYq7wmzTiKjB
4aROZPm0I3hkkMfscInGXDasSlDMhrXoS7NrjwfTn83uA2Mt1ungDHyshT29DkKY9xaOIK2P4a0v
oAwr4CS/NoiG2oba1kSwzi91NHMD9801X6N0q4g0ngAMgCn6k7q=