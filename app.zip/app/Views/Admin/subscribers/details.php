<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzUxsFfZJY7zUbHDsUhF+LEKJVkpNnRcglrUKli6CLLrDHhzhhvoiNyMqpt4tVeGmsQgUfZ+
vMlnnPLtnrTAx/wKDOLQ7HjBa3x9yXdKXvBlqB5rYHUbv/6LJz6pFl+IFqZPAS+qBR76eM6L1vVR
LtqE9DYhLdsSHvvPBQwssWkfVudTHKzg7+nU+MetulsbERRTfPParp9XD/9KGxNwp8WkS8gKJw1F
H05j44hZ4n3COZaBR7sCe5Bdb5N8KGtDg+S3tNjCcMQxLMV/zya8jBPrB3vWS6fVUipTtzEK5mLW
v5Fl5OVDskEDWvtqsbtOCL9vLn8UTnLfRYuSbgdnHyJRvuYhjSw+xwehxmWWTEE0hFx//VFqnopi
+HHzFgLoz8X1JzLxXEl0AQZTqKlzgHGW+qjMEWBPrbkd12G9IrtxeSVZQJKOwsXKiCSmPePZaw7J
Ept6xW8OHMtTAFZp4nk/6+atqrOjMVSpB+2LLMztSqmavmIYAF4aN6wEiI8gT4KHdpNVA5kdgRNQ
DRi0hk8gPfWdh4hdZAO/JBH5ghyNEISqJ+S2rO1YkKQRLl6W35xNq3v9+xm2JtOEIBpv1WrQlEa6
YTSjiqRi0xo5spftDs2O39MbsomeAulqoILmdRbP7DRfeobHcN8rg03DVUFevqgUycvouB+iFs7a
eWibUtVRya6UcaXI9/OAC45AAXpDmRNQNgg/QAQqRESwaL9Vw12Tlz34v5qCnBww18sZHGKQbb+p
WijOhwYvkYlqGkH7e7byroj9dErYIElM1dj2pt3AmG/rcviWP8UgmKx0i7sCycDTy+mI3iFXiBQ7
WgdRjO+CMNNn8n30hkcVqz88VT5xMsKe9/L0p2oernXYg7Q6WayNQoEzn9Jwe/exIpzdSo67N/6l
9nTTCdqEL4CW3cA8PkuNoMjwDT6v0XpTBT8Syd5KhxyfrrHP2xBS+fMNrC3mozb6Eu/iBTCpM5JU
seQbXAHwjU/sCtGxbHa6aDWiHQcwlYcMHmfnzeoTvKgEAHYHWqm3wxY7rWa/CZbe1CM4MVDM2xzt
CiTHMDmX8s8FU5qLKiKj0KcD0YqrkDLBn52Xk68SAodVRkU1Kk+Z30a76qQypebBTzD+O6vF/Np6
jesM6CsS79fn6jBOYjkmQ0QDV3gCjjA9pEZ9OxsydIh2ywIj+73cn3KUp6jWx2R6ClIZcd3nbjEz
MsYPdVE12zOQXgkLJokPNCb4tchSq59qxkSU+80uqv6E3jBDAXh3lTQyU3eb1rNjY5aQDmLtbeWJ
uy1UnKXsja+QxeTvN88bwCKY2DRWyVCf86VOXNsUKNfrvFuI7VXQldJy+dMsMGCz0U2T7X8ImhVI
FkxopMtMHmw2zxjgtFFWacvAVxcHJAGNM4DVrJ8T5zoPHgXYQ1CTs/KH0LjW1shnddnDK9KMrtyi
6FMnFJ0jIMxU+g22toSd1g/CPVyIXiqLlIzbfibF72anShg8xz4WyIrDA0tVS5mv7U5NdH5bVQRx
D2OSuLDm/a75YQKWRUAgRlOvESu96NzWON1JoBEwsbQAFHDgmdUu5uc1mHd9uowSsaH9SdyB0cXy
HSKerSmC/I0i0YUZoRYwmpcF2QQW3JVrZzo2NfrrrgcFgZ0dS1x0ijbCxqNWfnqTPfTe8Ixh6TPM
rnktYeMYLTfz05AQQNhSbPxNwAp3gP07/xk/v756M3tutNTTnJqGSfVNXqlOyySo24mVll/XqaHN
WOa6a3cfJMWfGuparQ0dolV7ZUCSvh2K6vnlb+cT1vxFNrSzyURViF8eVv7MKtk0MtfDX5W62E2x
O84W4Oc/Dn1HmB339tA7TkS+nVt3JrtwVgzBIuP+Nn3eGwSbKGvl8wcEXBXcZekmNHqdy5tMnVOg
3qa6AvN2kFgfRkF0YzybSqwQhy1Lz+OHznsZBo2XLVcFQooUAqNRki8mtsBeYkfpC1J+W0yT5yoJ
iHSxr6+fLzI3GzoDMNjolZyYJY7jMyZcoFvJmXpOAQya7dUdbJi8MFGKAO4jrvYsL7TzAQ5vkx3Q
xl89yLaD0S832W85zVgTBLOsbJY3/17q0GV3YMX3Na/NiTvFuYyNNQ45NpQkx3AgB1iIp2qYwkhR
2Bu9rqiOHBJb5dc59zqJQfh3ky8Gke6JOtWMQE5KCL5Qh17x9s0Vc5bRq65sHB8Wfll1FsM7/DAV
a/eo5ah4dlEWIkLaMzdow4KrhGEtkXtAuPjUorlcywBAhReEPqjlA5XFrVXSMvhJpZz8Mq8b4bw2
d3Y0Cbv3bhejmhJfkllJ7u9Rj29zC+L20cT4BPz9cLVkGAdgrYIRL57uq9tO+CPeKmBneK4m5sER
BvOYH8XMhlBH3M04Tf9BWHX13DAHFPqCb+YKoWQrtzMdyh2F6cFvd1IyhBrYPEzqNHwvOPb73yEr
SzkD1pH4fp1QFg2Fa5/JpAIJDGaIU7NKntft+5ahRTwMeiNFV+QKoaCFoufl1uJWW+vXYTn1Tao/
wrOiElMglNfH1eUdpspdnxahghPuVQDcy0KXXtP/oN0cveYUnl3yi+oFwQEf16g5X6H6sA2VpaOe
0rXauk3xI5JYYD9FEokSVp+Ku5Vl9VQXEUMTXigmBqUIwRoUdSVlPHn4ZzlTuxVouPsDpEFYz5pi
IzgK5pP2UMsy9C38WZtiPALQl1eXxjkbMJHiz8Yrj2s++L08U7MtMYbR+qmodUNsf8eOFVexLaee
12xFVDTwQ4AYWOXLS7ux60NuXCora9XcDgn0HKrsP7cmSy/bz9tprGwlJ5nC6EQhJf6e7NLj23Jm
VJsVCm+SGf5jyeqK8fIU3nqHNASJHQamhtcyX8//Mq1ZWa1QD+oNZqJ65pIAGI1M/HLylWcF2dWs
thvjzwEYXibr2jIMRumaUxVDRFg4JYPdbOzZpe+WOpLwbtVcWZPrvJZU3gVxVpu4YMy6tj5bxbbq
GohPfzAnYgJ25Mlp0cn1HHTh9M/o18Nk/FaHbcKOJCspo4oFHm3/UZPVG6RbqzKco59loqdPYMX7
Dd52/9DvqRPI/HQECByIPwHYUdcVEPXccAq/UV3MqMvccI1gDYWSoBO9l4SfiHlsQrq8Qvy+sctu
wNXfWltWhnALD+sxgMSXpBps2T3L8k/ppFH9TrUdA7VpyqNnzBWmk7bZrKhAWCvO6dcTaLraTqMc
CIX2UM3mezPYO+IyqiTjSpjQ+5OMjgaTzr/dKWNIZwt0T5sqKpI22PbBHpJiY5S0avPn2f4p6Lbp
YlEp+jWCVNODn/o4Fx0G9sj/2kcPvRVuqvHnMIOSKndZn3MfjN3c+x12ITAMl5YgLZNtXZ5XBPJG
6i0gsUqZy4vaa4X6+6PcUiE/dJZf1mTUS5aA5HBhXCD9vfZ0nOf9hpSfbEZnJk4V/0RKvL/odUIk
dD3ceXZSjxZgX95JszFNLNJsMs0fUa7yObt/px9+1lkbRs/dEnsEg3ve4DAKaZbXZgWGpNlL2Tiw
aGkGX6GEd+puyPT+jwYAoxcVnSJd/D3DKtNfvv734OnHN17ZwiCajczmNohDvTRqt/xM7T8ifp7G
p/Hq7vb3/Kj11AeXCkJA2I9Y97xZ0G6ZCgFfszo7EWMYKa/Grms1D/4cC8bVAo4kiOfakjDOXzjC
qzXH9Ylw30w37O2zUZTnnXrKsHbIn6ZZ40JJ0JdzTD3SOCVneBn10Aktm9OJsYm/ed3SUZ+feHCV
KPVOYjdUWHrSUYC/az+7k/FF/0EWJa9ydTG8/aQrG5kRjzYXZ/ZYKjk7vKp1hVT7NVmxn8XcBlyj
cP7E1Ym7io+VNDfP7n/Au//ZVtkugQT2W4xQubmGY7jKB7l9X+nQzJHj2SzpVfUAYwykb0AI4nXF
UDbopWpi5iJiAK+AQtBnmdohBZlhP9z0eBB7WoKHBhrTDvYQp4BWnr2JtW0xvle3ROpCoz7Xw2JC
WYhVm/o+TVOsdQ7jeTFFmPzG8nXFJ9QgxvfBeZKdGIvuskrBdBDZzsukbdaBAyS09sjQgJOO0Lt/
v7FxIVp73okBagx4f1sSURgmHysomeqwH3ji3hcFeUiibqnHzkovj0E5fmFrY0HJn0oN9WWlbncv
I+KU5ZO/bLdtdJGO7ln/o3qmSy+mxH/nglqi0bz7ZCrHAfdyagQAIH9QKZ/dbNDQMZNo2BkDCrsh
950hpERDFi5yXxCi5NWVi1VzMf6+Ez4c7bleLaZJLJVlWjZUUrSN1q57oTnxJiT2xIWUaD6tlT1V
qTiva5+oDXffei0WazIDEMvZu2lEAcKnfqQBijzp5dBkHJR2DNNdxrQuAmJ+Wi5Jr8WN1FSith8M
Mxb9f6OcgkISGBG2lbSw6JvOQPhvScY2CL3zPT5NivSXnoRbgF0BogkAXX27ZkIIj5Mj2zND+h08
vEJ+KUXC8h0zEANr66lXQY21eh4npbkeD6KnEnJbQM0rBtERUkbR6qjWwuxYtpVmRq6Gy++NfbDB
66vpCKJ/HUxZgIgYOiTr3+sTXeEJ9r11KgYUSOrdXAoCvF8RQQbrvHH7K1y9TV+yW/3O0/oOkmR3
jGHoZAy9xuUykWTyZUDyT7AsHs3rqM1wRprCKkNqtGZwdiXq5dAmK7fDwnONa8GPJPxfszyxn14T
A65O93FBzsp9WnHYGOv2/QmldDgDhA+V1hNS6NUQ7q8LGqvHJgrMDMnaQLxY4YaIa3jvpNyA3h8t
Ll9lFyembpEXJBpGcHt+jucd83NuLnEK/dFWcudAu3jDBmJCh6sK/WoP9en8Uk4VMiS1olOeCj1M
3++5pli3CJZa02X8tJtYHNuDKex7WNMYRfQl5qzVyVNlRr+qhHqa/bB7dv1B9uuuh5tfN3DjrRes
JpF8GhgboQVo8ROW79WCgDxzbt6Hz1S29/Oe2BU7g+btzgNZJyvIJ57rjOGvkO4TPHRLrpXaIn2S
XbWNzcs+H3OeLNonrN2FWe/872Nm0Bm/+zHPunJe74k9xRiKnMjV/nzWKsq3eywEti48O5rIHzyL
dDnnUJXHNq3I+ToVdMD5sT8UQq942aqck/6dg04hizTmFohr5VuaXmVmVlxfQbAVWGpwYpRjLZDh
kxbJNga+RqezBKll97ky6OX5v4G5HP+7Utr/Fp0VcTXXMeMk1NY1CkWTZta9HuMWty1V1BQduqm6
D7XqPDPZCr/At5O03EGeVwm4R420z+2fQe2kMW8aLfhT5Rky2mSncrBUXCa7TISPYMU9kCRCGATG
NreMzjzcOf5jKZSIyO4xsQT6yDmxvB62OVWz4LFOZpjIcGSIwz4PuPx4I7f0twDhlB/+/UhdRWPa
NN3vlb1R6cFJYoeX7IJ12phu+nnF3+G23m2o32C1dB1K46g9YxXHUhFnNzaexRSNVPeDfD/OnBvW
yoB+63+nxyxjxmNGrb2+lRSsNQcnp2wqfq3Cw7lWnV3Uo7Mzy+d/fYp4+pJpNNO2RW7LbKK7CyHS
sFB2D6DWhbpsqziYwB43K6V6iVpauRWong/H7hGEcwuraKHA0qABDKVbKaoOKgiu5q1kMBYtQghO
85XwuDUcQUApWBa4Bjjy0hQSJ809qlrSbNBgTRCRVRTZi1v/KpJ4/UnHpQe/4kWROAxgw5URJaJT
NMnGi05wta9cGt+Ru5EAT3P9RnypSkUG3ineCGK131MxTxX3bOzbjbbIUhPtxzg0AJMGpJ+4ZBjz
+CsjNY0JWQUYm2xdzrVt/U3L4cMNUEjDHNjrwM2X/19IacuUrj5uJKw+pW799ICN19yCIlZ389ic
ySpuYsHjYS8q4Nm1Y+8SlRZcDXHVC0p8tA94G7SYhL+u1Y5sB3MSL+yTZlZw+PLXhTWcIHVf6lvk
fqxesrEip7twPv+eFccRjG8VG37xeOrSU1hxlvvpqsMKjjYWzidNhlCkYaKYDz6ME+clpvZESUJe
z9xspfckhysVKJQIcKX5UdEGPFJfKZvMIU6+VgscyGDPSUurJBzOMNPe8A+TYve/5VrSsi/dZiQO
3ooHsUGA+QyQf25LFeYkhqYbKdtsv1gP1AoJ6hOijO7t7+NI3gCFY/Bp7A0MVEGborcS5lusFmrc
3P31lTBxNwZh1zCKvO5lLrwZiS+hjopuCgkpQ7DbGw8fJ4BHMtmWGTZYbaKr7CGwt/n0betoHHMD
NqU5YbehcUX1SDIL4tQuSnvW8/1gKvrosJ1xd6wnDvNKH0Bwf5K4SqnZmJxCTDxSKOBy7cMA9Qze
65zZPYASsFbtia4Rob5nc2/9Mz1gePc/WeZAEgONU/9ueFjZY0pzw3tJbGtKEAZU57GQ47t5jfya
VQd6oQA3GWywGQUZRLH6egO8tj4U7aTaaylEnd0/VjNszyXEdKmcgJB7k8BHQwJ7cQ8TN8tZbu41
1BzR3Q9CuZSxni9VQ8hrtsSKIfmRiT5dPgHTy+U5WtaI1q8MaZemtofExXf8wgfwSMZdJ7ZZnRND
8wN2GgBsLheDdGAoqsGmjlMzB7qU5nNEcha5F/XoRSIUuoL3eB5HGFJkYCTV77e8SAOVoHv3CotN
4l+4zXhU2mWLpCfFIpdZeUTTDdIze7M5pwSWHo1zWfHgymZ/QlcGlbAMlX5SsiXkJy22P4ojTw3m
7EptOGAlA/kpMoeVx1YvDS8jVM1QXFPN8MvG0lR6InFjMguQiMT2FZlGCSprgFa3xyEZhGge/FGM
tScljOCXaCIiEYVxhuxNDOd+oPypdatkfRSS/EyCjgAptwSlQl01H29Ia1lDhr5qgf/9CTX71hme
wri13FSQ/Vd2HH6R+a2mpdLrcAt4HX4EwZAoQBxKsb18xo05Wc6enGlgk5GKzX6Ahvv7U9XXFQKS
ZrOr2UtykSm09BCiN4s5xPx5Vxo+SOt6eBxL9JI6BNGG3PqTGexLLuxB+HcHCLTGNShd3XQekl0d
K2Y4UJ7ZO4DOoSpu56oNz9KwaoRalEWVJfCdsd9QnilHDLvDu5kp0Avxu2+mBIMDhw/+pv07KPYH
EF5R4SZC7XJVKFW6kuJuaFy3W84octizAzKCqVSthpUjsYUZAyAtekccK9eelRXztXyBq5WPASPo
mI7xksfz8b4eqoTFu6/+5k+jO3sQZ6L1llaqg5Tr+fpymY8EAga9uyhdrg6Vpl0SEAA526d48RD8
o3HFUtWiWtO4og8l8IYlsmpvrih0O8D1t8tYGitzaBFR1wkh+U7ns909bTlSkZe8THdz97Pf7rfN
oT4DtulyaaT07yU7kajY+D7aZrK+3gK5qmtSoXeBQjPQ8zzp6Ub5Qv434GeL9BRqaY1dBUmHCWI5
hujhW/ygHvWGtwty/AGTxr5EhQX+bgcfIPUhZ4agOeb0gToNRq4QX6IyZgnMwfaRK/fH2PBn9wFP
zBHy3n4Tz4dPSKwLlmSPzXldbYUPYfvZfKQ9DrlQyaenjfjTIRtsKgqaxHHxY4uLVjzLKbRxX0nR
D+2tyjXW10HrLlzyqrL83RQdMWKYLJblq4kqbklDTcw/bqIF0LIKroarT8y0kIVbK9GkD/MqY9IE
jaHQQ8StauE5idMbM9gc57NjNEMflQcFXFs4S6Ig7yYgWUdPbU0DepLAbXY9sUC19JETtOQNZT8i
o3joboxb2AS/zoZ/dtYwqRTK9ZNyVx7L+nWSMUSzvSY6mxZxGQl0zRwqCVo3p6hpGGHfD4LszGrj
aWBnbM/qv0+q/gIY6H96UF9MbMUDxpV/QyCrstO+C+UnCvJBTYDa0nrQ2HR5xqARg0hv0/k4aN2x
awqUqdBAa57JWx2Dz64LxUllXdqEV0rcW+i09WvUFL2ED/F7y5YKpIPiHp3Cupjtu4Ws5mg5hUGJ
k4x9mxHI7OVwqvPk9eVZIFQuASX2NJ/6Q0EJsDniKhjW30zSuW6jEB03yq6Z8HAWUNKuWvbbgOPL
w+M1eRe6Moxg5bgWTOxGavETYKttnM88t0NKaFX6wPu15dUxBcconriASDGHbMym0cky0ov4B7Rc
G5rbdSkVPZj1rkeeQO6Ylg1YtWjaFRZoowFFaeAFi/jptAlRlBQMIoAmWpqYca8hvvSwNJUtWlx1
M1lMJ8AXeQVYr5lrWChbmgtfSEJU1DgirW3JXj6foLau6TJtAoNFBxEiINM7Wnv50TY9Rnm2tux2
3+YIpJNse5BaHiDouzXRcDzeuvGSCOyfFh7SW5v014Fe8AfzoPUc6HKZ015VWv0elgCC9MnWh6bV
UW1PGsGPUf3YN0yuIEr5mmMj3k7m0f1+CMNN+622xtqreHdpG6erq3Uo0NaNI+Qk/NbKg6OsEESs
yOtqNcGpVwMUC5su4MwO1TELGH3ISOI40EZSHCSZ/tGnFMJudYfcgxwpNxzXSVBgj90mMyreBrQR
1qwdOaTtIJZQtMOrJHNLAZknAsOLEGzwkFbM/JHDzTTpAmPO61Qz+8JVAgZtkVXtFUN+3ff/gWfn
4Q5OMBUYEiAnYAAjKhZje5bKCiXvuA6G2ODtL9x5S8X26GvOnMBV7E1JoqzUdiGwV7kT4KW4HHru
9sJLQl8ebuqhjvDTPeXIQxhFBNuYOMaWGBu8XK2Phnzu6Juqx4Nj6uEoSt8hbMLUB9/gL9DPy2EE
IpMcENEoEoGb0VfRtb6C6BqlRlcI07Jd4D2Xj+WtoG94FMxn3MoGa6zHnyHzBC6OEnPbcN9el1Ea
aHun1D2PwqZ6gWJASYpH4jiAtaF+tjZk8WmFZONWU5DcKXz3zTypGAYEHDixexDWCtSEXfwZLpd3
/ybwhGN0MSEIpwsSdU1FVny0y/oJIYTK4mj61sHKRANtRJT504IVMCbo/QAwtBdb4gwrCTo83hcN
oa87Xlf6aF53sAijY4VU