<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmCjh6Fxt1HKWi8vGDtKh6+An+4i8npZO/0Y+pi3e3DZ+kF9uXJgSCh7Nl9aVtO486Qwr9L1
n2pygT/Qa+fragJyxzLvLCXBNFSiB1ehApdiktqA/r3owWXuzC7H1GrU91coy/jANO4P8Xgwnv3l
SiWHpNvHq98HEnYVT5eom9kukuApFy60Mx6cL9eHoKnNrLSIobdRcazZvPj/xlQE65wtv/GTNnPY
4jQggGFIyd2p7BouiXyfjMtquWAV5EqEfEzj+4EEb7DkMzWmxFyeSatQ+elV5d1VMFw+3Mq3L7GB
p6goq37/8SiAKGvZL+SIkNFq/jo/a5D2zzGl0BZFwiBOwuIxj2rJQMs/ak1K1Rv9sHTuwwQ9/3QN
EcyzvdGdX/KCBn75IhKjIr/iuNDr789Bet0KDKbTk4vlSbc1rQ6415WDc+VYT1frb0HFkwW9qYB0
DRlnNHqER64Pfk15S96jCLcAdGuhWCf83HAsIhc/o6Bh3R9X8p76gS4KR6NwXhj74nPW4sgdl4f2
rXQdWIPDzGI60mPhHyfTMUgN6m/BUw4iZ/HQp+PzH1qtdKlfv/1xi4gkjHMazeZUFH3+/dTQWlfI
vsI+KgEOkQSQEta2x8Fkdmd6v+KR3EzoJYNRARPvyVc3Edz1pDOXmuKl6ao2EIfoJgl192ehkmxU
5dX/6YBF1hfIU3lhOBPNYRxGjKvu0dOavSiikBTEaB9XeUcYN7Z/lWmRRuO+GCr67LD0zFrTDx9w
xHlGBKyg9LWmzsbtw+FPAVVxZZzKZvsJWo51OcxkLsKj3TqhxNZBevPYQuPybwD+ceDKV+i8GO0G
JDc6Hi9UxcqBa/KBLaI5cj1oVwDXqgdPyrr9/VBvePyANZfBOrdHtrz0cCNkHqx+gMs/MA49XEMX
6f+T2N1bLy9VP44ty5Bwo9TKYSQ1zxeSANap8YUSOrLRNP3WcgGUd1ztJ2MOPF6wi38UlTWnNYiT
yZXKC/nXIn1x2oVcrT2rR7BYXwvRcnjKLoEXJdjzqdXDDoV/RumYPpssYu3+nx+G6ThJVHd+38vK
8CGCjg1bsuMCrwN4Wm43l9eO8FqKfSkgugRVbu/w+jVcXF7Akr1J3ydDZj6V0c3PtHKE5p0tQfH0
79i3wkadNyLKhtRQZarKkK0urB4qla4OuX6SINxrVg9bPL09KSK3/9ykuEfKmdahVyYEXBrxh0pg
U4pZgD5lEXf2aaR7X9O7NatSEqalo18qHftm8lsd9BHhoVXVGb0Na973PklZGE2AstQCXH28unps
MCyUHtH1Edh0XooXjexKR6/Dr512tVjXwxNElHWBwwBqiXgJ85Aexyn15s3/637Q+Mj0awTgNsUT
UHndKx8To04EppuawR9FNwgSa8lLb59IrOAfEUM7mjkYwsfdOdURIJtvtaPzLc8tObdKw1MjhIFd
O8v+nsG/hEAmDp6vhyjrEspTwQJ72E7B+89/Nm23hRtpZMLt71NxdhqTYH3ksMMJvOLSXN6cdrtE
KbZ8bY1LBwm+BUn1mX+c+612gSJCYQMTATDCWyXi9tdp5ItQu6SlrVZgHgSYzv8dDJSzfeQPAXwU
W6LXxJJ1t9RjIRGWwVYpjLn05StTe5JdCgUoCU31VXGOZoZM5gUtrqfh3vwr9IPI3om82mDiOWcf
m31YXBiDN7ZpSqeMpiKv7/yLJX/DKQBAyI4OSQh620mqzai+uEWdmYtbck52UPSq8+4/H3Iu/cMN
bfpEv7ejdXj9kviESeOcfnLvYrB+f6uAP/C7ypgGRGqQiA7D9okITPEK1KFj30sWrNcWNQ4ClHj2
NksygmgmbNk6vJq7W09BvWORfw3sFeY9Q9v8E2deHxoey/2LN1GdN3v39qu/r28hsQV7/UcaEruR
AZ02Klq2jDPymKLfp+qN7/mvZ0dYhZ3OUH/wsOuorIg+FGDj9Ftm4mWnC0eOu6HXTnvVThzM/ro2
ugKeHK5+zoQGhGg0I0ohGxUnrmigKxTA6T4A9/2LzjxBZVltPP9Ak6VnUvvb/mbzr4Veai22FovY
FQ7EUqUIsg2ZE8E38+QbVgZiR95fAzQcIxRymAYm3+qlgAeMK9aZe9dr8eQTmTK4xMCnNkhGvRXZ
P2iHv+qapd4eDnNFs0KkcV5/CC1p57UGyj7o6uMr2r84yyzbD2Ek0Qx36X3A3oEtuUqbhsiC/mSw
h1KwEbJi2KLiZ9RMkZa73QDqNImJr4oLVqXOGHKcjGx611ZEGWr4K5PM+MJazYAJy1CBChNfEFuE
FfuTikDsR60vlc/aOEQSjTTndciHE2+7swIzynZiBWXEYcThP4V69zXI0/cUaXqRyyhtkMrkHMbH
Nue2tb6RTFax7A/V30Z4xtazToHABXj+HbTqzAQCPxHb87XSO+2aesFKmhMAZRH5umY6NhnrOWhP
SRQzM55ND9saiJlGq8cqbjugH8SQc9alSwC0Sqsj6p14kcM1yhFjM+yWG887m5chPZ8q3Obnd9CA
grNXx50+7ktB5+vGd/gWBfxftkGJn0sMhOeST5twjsA1WWyUO7B1wtJH/tb9ZmqFxmO7XhObLvFA
HnSRkU9C3fS9xGpFfW8Fq4Pl5sJ8SRjaGg+Zk1c4jrEdQe5A+Bqxqe64w3OI/kOrLYRbuQ45wzQv
o2Y8CzKvcNvQ0gbET3+Zg5+Paq0L7S2SRubxkD4udNszs02dSR2dzsmw6noUnJZfazsc3/t/GZcI
JomP8RJwabhXyaG/ZEunU0QS4xlo73M/936o0ZXnZq0rwXe+UKylPq1Ns39yxhLbZy1i7OL5EpOh
tvhkZrqOuFDD0lX0ud0Z1empscV6EJYbRqBX6hnwrea7a1jQedDLL+jG1VKAJt1FsuOSUvPL+Mwq
qwAFJnRJSMUCELQzUFxQS8legR4TI1cH48bqVUKjxjyQrOv8o377q66vhIfmtWtpWdc0EK5m372z
qeqfsTc1B4QXYAJnuyb7t9x6/ngaPVwYO4Rgl0e7U9iYXWKRhR7vUD08RApRBi0encWnPaPV5EqJ
79x9fExsna09LkMtAZimbMkH+sYKZrqu0PrfHLEbSXQ/Bkx8+k8O+UGEnu1iA9iP+VsfmKl7HQj3
AlOOMuIAKGbb2rPy+KzH2/rhOIKCWCkvidPeTMPYSTYCPQwQ4DIUJOd/QxJlBmi3B47UCTXz/MTO
87B35HviqP6kGrXB268Iq0hM5Nz7lWuJp269R+UWmDfILYqsSbZG0mCWgK6utz8bw5IVhIhhB+W/
PfTxUZuiOmbenTuKY8k/YewJP1O/htZS4OP8VV7b00b71v5dP6mCP6z+Z3Me+bpPb240zgJFN4Kj
hdaG8p8ejnJIOGs433FlG7oMNal122uudTHQ1PQpWeSapv6vuUoAlKCf8mu9kagqfi0AjtwBB1G4
7mxrvm3/HTUl0AE2q2KlR9tJYPdfW3sexcAUk+0QA9ObGVbjVbOp+bqaKm0U/qNoqP+fxi2NIQFp
/gFfJxtY9vK7/028D+GPOFniv9tEMXjrQ57ld2WDM+0OeQlRfCakRcFJe7hyE8jS6UZSFIhaZpjL
pQpXKsF1pE5mVAl3MowmS8HO6ywEukGX+b9YQVhqK9925+zI5iYeKcsK6OBk3xsWkDhqi2zTqPQU
daCBw3AGUz3hn0im9njA+1RQZLrW4FUp9ypymTZ95Eg4cNTB66WzDuZmyzFbHKnPTLizcXy77yh3
UGjZew3yONsRckHnwfk14L2331U3QaBGw87Q29QPUUd5S7U62okVdMFxO5h+eTb9/LIVjjIm6e2L
wQzEJuDFcubRRAwYGCx2iVw5h2dUhGq9gxNZZ5r4HPUPbNRosRe5//GJLlbdVt84GhnOrqT+A4k/
yBpiUoEWBASODceA1ajeWa9k2VhsZLQyro5+EcvOVEql6G3wX2oA092sEuVtrW/b6Cjs9pCmMhzn
ZasFdEv6cjmtdTqCQEbSWNfum/BHG+BnBBVeS3Ltpo0aPnThSKpXq5keWo1a/2nIqAWgf9aR2HUX
f6zX5TsPKq/vUtFKGMaZC2KJHHXoMqBt57cyDsfCGjhYl63qK6wGvKQsA10RgVBId1RKe6YPHtrz
/JbgFHVskRKHilJDd7FmYJPXPgh1Tjoly2jd05eKFZrpgYlr5kqsXyUqQOcvkSaO3GlDFcQ/jLva
4vxU4QuzgBDI/PqA+J6fpRQvoI0e0v4A7OgALmy0DRCPSQbEUJWjEbYDzRzCjwa/rkkzSj4uo17R
2ZSo0veiYHuFzF4r4eecqwydf0VWfRpxRZ+avn7hNvnZRMWttB9HQyQGvttwV/xqn6Zva9JtyjUq
ZRHJmaLNItaw6AccOwwcIZkHbtnCCPWIEAJ9zNv93l8t93O74Aa7agERix+z3BkpNTxiWuawLI/E
YsyN6ts7MesUVwJYCKFeiMJAQ3SbkKPDg16UAyOB8SUfdVlx8yc/l1efX3DCKT5c5VTFW1Pnw5T+
dMOwDr4XI1TrXwzkCJ/pcG8+SLdGjInNJA6QPm2OmpVQiLOoaRS7CA73rNgDSc0bE9HCe2FqG0+7
oAyO6EvlEtvl6y5K2HisYal36wmk9fmxSI58eO7DUgGGZ5LdoHAhpmN0lCHldtmnVfmPkp7YyXlO
e7Tjl9pjZmLPvGZvYHrH5bLFZ8HfZTQcJHuKLBmzxlZXrq5gAudJ4OQlFtyhUJ8uYXTfm+cF2q8d
nTyjfsVXocw6OqU0uZqxWwj5TOmT4IaRQhLmn1DyOUB6Y61mNParJd94IyVqB5403bxVp5G7CPja
frsy3ryoZoWm6a7ezPguLfGt0VKvAXw2zq1IZYRKjgHM4iX/sY2OIawBEdUQPf5td8l/sfJihRoY
IPZiHehYA9bgUmMdWMD8tPjKDCuDAx9S7TcPVdrh9xEbLcy+I208SAfwaLyVykVCDjwjfYwejiY/
XKUF/Y3Pb99Ntiyz6HytfpW4Wq47hs3KlTqav03WWICUFp0bl8G5CJt+UBc36YvEIV7bG8ZrhENQ
fD30TnSc8FJNMT64VlCSMdOm0ll9teiMzkbbZqojxH9w8GK4d/va/F+GMN9WgAwrFr7M7mkYOXnm
OtMuGfptJe7hTdG6Gv+dFd1xxVhwL8ctlJhntGbIKH9J/212Ek5zG+NSDnVw+VM4uWWJ4kfCG7h/
BY27ApucV8I2QRPU0C/fHZD6v2uVA3wfzf94N++59TcKI0JfTxjem2ZwZtZ2ObM9x3Ji6XTYhBBL
HTqWNFRTHGCN4gxrp41YIhp57HwSXSA057dBlOvdTFSz++5t0wShuA9cCzL1j5+tUUfr81rizonb
Fv2aN8P7CE5zhY5RP8TmFz1rwuJZ4MHBrW1k4gL/jwU7ND4Ku3KRXe3aYGXW4dfDrtAUJKqlhhzs
dtrQV3k3SOzkJyhFY6q6xpzQSVnJm0PgcSpAM1/BE145oGG1t7fYqcsohPO9X4RlQF0/KJX8PMkW
Z8YLGYUTGyXo+0amhXaIegT/0LEKLf/5Qy+IQYjaOuRRp/NLp6z3rt1lRh+6lUDjaP7wydO7dQhn
/Gon1Y6t60xyPJU7Hd8KYbPU1zWzhu4WbGoUL6wPibJ1dunVLYrbepgoeYOXETvfGdoBOa0XztfR
oYLFgEHfEc94wjDSFS0qN/aKvCW12g1CdG5JKprhqZFglp/TMOHHyTZlWp0CYDJqWVELRs+ODMpz
4S/GtM+xiv5LiSSxG30GrUX+Soa8nxu9eNlA0gWYqrHTYUettSt7JcdIvK4fYRALM4G7jlf/um6W
WJMY10LAtlESEnuCZaK0CGe8HZuUlULASNwqBL4EFq2PT/cDtnwXtaSND1mOoS0vNVy4/PD/InvL
4i1F6Uppl+jeGraYFgP/KSvcDHWv7N8Y627cuaWmXLD4gyWfK2snJh6H7wNLg6yOTO8TtjSMIdGv
fbsLTdkizy9XRSAHOwWPVQiVYXU89ae1POgs6xaKbvRS8XZEnTASMjfu2Sg7y3QyA7XSvgvLwjXv
/x0z6q4uc0Vo7Z74bh6aDgznX0TH+CuJITUE2lQ/kfhSThPfflCuQVrt/Jj+I7WGP00RMNWtMb3E
ixVxf9Uf30lk4wo1IBiqBGzMxbj6OvW7S9pApBvHCJjlaHa1iKPmT88dIMZu+ick1TAFud1xPG3H
QEPfXwXEQD81UgtU7FDPY6K6HMfWy28HX+VqpCTrlbALk2PFO7ZskmiMyp3/4+NCmLM10EcNUBnn
nsqrQUF3FYTuhP2QpuI/lwi6BYjMjLubiDqnLvNaRsYhtrXajibOjjCb5fVOmI2IFcsniJ/Q+qPd
ykEzqNE/Otr5K8VbUtCrjveHfV8AEkIPzdCdbxQB9IS0xGh2q+D9O7ouIfP49UPqjAtzqwJXTGbE
G7HGP+phEW3Njs3hZ8uwGEWVIysVz1oiNYq9NbfKAfbkYQiCj7hNgQmLIopndrKshpc42gX2ZTZL
iufLc8uapd52eVubBf5eYAahOnmDQzKNQigfayOmjN4/WI/KPkMeU3UDP6yEr1JFIZPZRuD4cnUZ
Ds7qH4cxoTMCMWXcaVQU8nuxS+A643auTiSC0kCoT/l5+mNC27prQA5u3c5t0I63GGCztXi42nLD
31GgfWstu6NRa+MfRQAEpoejZb7iENyTkwcv5Xn9Ln1KOYhV/VSUkWbu99TNK4tLXFhMSCVuB8FO
52UsnaAL2jtuWZHiH11hCpE6WoMZQgeOFQXn4yc/gl7ekGd7lxNOqMUKhMiuSe6BQnPkNfyNZIjz
XYzy5YvTpmnLY5YP57OaDIyuWl6oSjs9KAbIWX8WnyM3UZbrmd2cdPDkMAkBSHb1qt9ehogGGvj1
A4CCfu47MkTp8Mw473S04W/p/JM7HrTR66bcNoH0Dm9aQ33emKw89dN4vQYk38/eCVIPLuQBLwyZ
/wrFrX8tGE+FVWCRZFLUFwOgSrTTZ/vY+XfIfHAnhabXms2hqULdQ+5XZ62VEm/atUj0QXKAy2rl
iK76GkYtKeo8GUzDbOKtA5+5nqAV9TKPm3MJoy2/txishCyZXv4Y13qmoRnZ+IsHr7zZM5Uq6e51
DQbvd6FBzutSybGRVMNBq0Gi+xfa3Vema10VlLD1Gy2MioFgSMiXO2b4yXZBYSboRH/fi50qgCBO
OOgtn8Azho+jCGMR1kjqB2jKlNubPkBuuVqfgxZYdnMqmcsTmOn1jgyHxuZWBJj6aqvKAK5eKkHJ
YGRD8f8SWD0+HeClKOnwps0lRQ94RjvshPZqc0Xee8qDC1e8o+fRTE/iVdGXAJxI3uKo7LrBmXUW
7XWX4VvM/0zw5fmkCQ+i/zIDJx226XIfH/gmaq/9x4WkepB42mwd8VVB4xIkcrR4KDi2SVDRvLmY
O4kwfPAIsDTZSYr2H817DR+/Y8Q82M+MwWyxSoEvVpxlPaq7fMSN+x0FCNkWmebYJpXtwNbPbvyJ
bTRwbdBhFwg01sT0AEGT1Uj/idIJ0HkjaZWP7FuzNt9i0pu9t9LKoJyawL4gxbZyjAHMAr+1no2p
GquRf9fjfzCJPc/aDNAh/xOQbVHhsrglog9IegDZ71ns8pL2vrU37aFCoUfzs/QhwqsV9pkII1gx
9qZD8mks0PV+TuJ9HnYIeeFlB2M2p/Jdl0RplWMf1QG0MN202QiR1fiBUUaUmk/bG9pC7HLfCxdD
Z5vZpSSWEf+ORnBGBhJgsrDEe9igvhXB/KVak9vy8JbYlbazdYx1Hv1IxsFhGCTsR3l9Mc2o0HEc
M4TZruwhJ2zC2h1JYBhfY4NoiKyxg0xsAWxqOM2DI+I+aeOmeQ0cOHzVbKoig3qlvni2iaWJKrrB
+utwm4fRAHGHDR4EwHJidz/gdh51XzKzfyB4Cq8EJQzrJsyJvRS2BsVOFiIf1QmiSiL+uSNRsmd4
Gk0P9A9LBJEPZDF52SOP46W+QtRX/bA34H8mSaB1H1QBrcQ/IQCkanpUB0XuVTA5SVF2mbM69Nbf
m02Qeb6l16q6DZal0p+wX/X0LP4a14rRMvOHgLTsm5YabLmNhV92fmCPZ5CjjwPPq4ng4JexNOlN
2Wf94qpA4aSPgsKIU60GgPSd0ArwGUf5TwafAPx0WwX2M6PwHgEYgl1/YFAdLuwuINkbrydYOSdm
JB+9YlNytsm3xD5pzPQDduwRLciuz6ON/ZTL6Mavs+I5DPQ568refQqjZ+4oj8Z6yEyjAAx4VqnK
DJ7QkDvimcmm0rcyQPuP7JDWT+hl6FUnrsG481Q5OFHla97Zv1WM01yYwkBOWe5Rl66j4DURqql5
2vWcg+H67i5eTtXbNd+X/b9t43Bg6+SOTzTO+6i+Uxoka6nxZaQhBUZoMODknsIgR7ygVOE4TGtL
/ziaDpg1cKC8z24uJ4Em9xOZnqZTPhcOc6n3MjfZXWip2ZG3gvh1PzaJdf6Y7RKTWjMCo0Br5bN2
IV7NeOVt8K/fvYy8r94oZpYIC5ZMp+lsZ1wxAAT4Xra66jeJijoq4vJUPSG15p9FCxZTnJ1vR+5J
A7MtkasV87y8oYtkrBdz1JYVZbzKPQ0RVsInJ5if/EuXoT0BDy1yFYfY9YB897MmhtBrfhT0aw/N
J3rBGdS65eAC3p0+QMM9+Ezx5mKPwI91fnIKcO/KDPaLFeJ6Y6NflT/VTEDHK305JcyXrcPwmu3d
CZYQmFO1iK1DNkj7FtZIpsSCrJbVhqbRj5nTzyoj/2eUu32A+NI6DJU6t0asKQlWPkS47WNtwGNt
Wip0fJKWB6o5jVpGkpIbOa3hLZiDLWNLUvIoqCtGHYM7q66GFck5/3+DIXJ2rhgcKm8H2G==