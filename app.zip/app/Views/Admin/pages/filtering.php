<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoXOsqn/zJzZ1fbERmyv08tIL8LIktRjX/MBsmPzMzEbxaNvRDA0tXLjKcOqX1WhvcKwzK4e
QlAOVVG2FkQMnK3RL7m1jTtOSRRMADpTaPsGGmTqhZ2X7Yw7/W+u3JJek4EPBiow1UA4VWlA8viv
qBaVynpwjg7Tzc7F+l6afUqlRrUWyQGBe0ZSfRee839v36qJRZ9bk/xhHvNmXIpo3aaKCKjazvGi
aeZ5PVz3vQIVN3T5Nnu0qH5jw6Z01iLw3zr9K7dcw3OBYl06iL2goSIbkba6QZRBnv82ek1v32US
AvHzCVynhD14oW/lCnD51XMayUxNHB0SWBfBxmE++kE8j83F1uw+Yodoe6QLFvyIAYcy14V87TuB
is559exP6VtNZyc7/ouV0ombJFjRKYHIkwP3NaTzIuJaeTYbolJBYz6smkGekfPYwMv7OIgEpGd6
O7XzGMSG/gaJAAECwCvUxwlL4IxzKFymV4h9RsNkb4uzHhO07LLF6DOrerX1LFf00Jfi6vFxphqi
+WTRqQMm5xhQCWpP75IhCOY88WmxoePrw/rs9oOT8EGHG7qamQ8Bhnjgkw2aKr0bFr9pDciJRG8o
s7ZXyK+Lh+6NhXZsAF8kyCV69Lnm6C7ZlRz/wkVIqO53/vaG3fhcLZ5tHvpnluaPL8ZOp4e54Stk
t/anCKk4CWxmTDvabADMGBHZAU4+dm8UM0nGk70qxg93mHqXX7IJtzbOJhNYbIy1mTUZ7cL6blSb
Fv1vwCXBR097drhYW7CKGG7i1g6NEusBn8unyox//8ze8fO40d5Gm5QmpB4J0Md8fr60X7buwcP8
tX+OByiA8qhAHfNmV2Z5hwzjPMjhTB6HvFvIrRZLmtb0m95IL1ooYLO2NZHuU9wd8CsJJFHgSwVu
mXBJ1yKtzu+y+K4qPVfXdd1UuGAMmaBZ8l9ukKFkZLF4EHryhZNZJvTXJVEd4tpVjxymq/fOHx+I
L8k6nrN/iIvdrmBjow6ZRT57iO23Ob8lhs+mnuA3iUwbkj9+jXEpuEkklMSq9uY1DhxV4bhhAPsc
JxCR54DlCGMpOudYVltWdlpXJDDfDfZoMnZAduIHeLZ5P7QKucFrfIW8CRRcLsD/7swv5MVFch/c
gvjVabXe78AMpSCj2CsKIvEMshXAqSTs7Oy58n+NX7S+s281annoM7Ul2uwPJ7STtQfL9KdCK+0/
YHSANFz92L2VP35fjRyLPNNjQgPhaIurKP3pt4CMW5ehqzOvP6kIVqVO6J5m3GXMdHHP7e2vk3UZ
3m+ROUqBnvJ6n01nFo15gQkr0G44BsRAsYwrRAY7I4/y81++WCuX6yJOcYnkdHIU/YMupNiJpyS4
36wAvdE/KdOgW4bYJ5fXg5lbHU/C2LgO6qE/dJzwJUrmSC/X9qeOHfB8j5U4nzZ3ort0DcCraTu3
kqTM+FjTglRvsAKd4t3lsROpsotyzqBN/bmsI6L29aIteh8MMm==