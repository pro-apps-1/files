<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwzQrDFrzopaW9j1y1gtt4PN8WvDePznVCkTV0xgcUadD8ktCSH6MAn55iwJdoYoMlUUWHge
nMDI1a8Vjv0WfLUlLi4j3jok1rw5cMmT+jVZ4YvAXaMXJ0mZqCewkb0EOLmX2cesdRbJWZffHIyM
E11NKgw4RrKz1bGCSSLtu76Lwpqkixe5bYvkiYJ7GvFAXSHMAXXmsL2uiGVWIq0imlOlNbQSGpkB
5TeHiSIcgPwlcLqkyOElMROQOU+tG1fVj2j6T48UlJdPArgD9XhjxmGtTdtaNvx6gs7wkMILCz8F
84kvA//lSO+Srtk7jEWeLRB4jXNf0rWMDKjadJt7aKux7V+A89NrYn4zmm01ATyUJJBVLD76ZU5J
bTg2a+FnMmrCGsF0n+uO53v1ny5WdUX5oTUqtKT+nI7DsojNpKz/ASHkvfBtcd6zhHQVlfxt0cL8
XqQ8d7Ab6OfsO0xGfzwM6GhHPx668DGFIKPuanqcfEM0pUizkYLRHWPawXJdBZV38+q9Lcnk/B2Z
ehZz+83ONyVKv9r3zJS68Ud7YD846NpojX3WXE4U3qttq2uKGoE6jGXrUFReUZktK/WUNFb9vnH4
48Sg+V/eZg71jqNkEzSSvFuCSG3uEb9iX7ywEwPtCiie3YjTesW67LSXhC8BiKrRY3PxqLO7yfau
MfUV7/MLHrnNGdeE15Nl2LnpVLwz2IUQ/Q/cwaj1fkVvtp6EYudVBgC6MGA8wX+BZ9hzCnpikmFi
x9D5BYMIRwzY5JcXe0jxjz0OkQ9xvkYLNoS+owZkehhACaSqtn0SvQVQmF1b8LPq59BmI/cfWgBl
xXJgRBtJk2tgMdX3oIZ3ZNwOVkQj+imYTR6y+L1ga+0uG5F1C+J3dnuh0Gv0gFttG6EnemVr8Of+
vXlWW+qHZUrWKq4UGoxiIbeJJ92SI/WrXuVQXcEtIj/Ncv8f7a7WKBWuLpKQXXpS6w+wBIYtxKkD
jABPMyECSqfkmMS3UsnIXnnc+q2eoD704c7L04C0RryvSWagJfgRAfrLq6ZvR0QSfxn+TvWS8j3P
9uLRSwfYX43D+yUsJ4EgpzbWhtPU9ySkycTPElEKgtOugUst8bKcWa4fWmZurB+lhc8awKhknTpl
M0uGUP/o60s9MwvDw+RDRsksjXwFjAsHvHUl2lEp5XO+FZ5AyYOgJRh3PGcnuxRdbXvPwdwd5C9+
Qjt3MKRkaSZlhqcfpj6r4bLUqe0V4BKqrnz/Gu3QV5eXT01/pa/TfyKR4flc+57NIZCLaIhPw542
1ZEiRonGS1CEB+IpDbziBsQafbCdYM6WicwMVVew775AOSbrn53Jpc1526TYGl1yjwZ36B4ASp9E
+9NLO/sXj1boorymndjJELXPl8eaW9P93jxcuaRWf6Qm8I2vuj8hv7k/7DQgkCh9ThEYztq+YRxR
lWGtv4CVO/1lc5W3twnyRVVQt7epvxaRw6eoua/XXjHXhYcxSja=