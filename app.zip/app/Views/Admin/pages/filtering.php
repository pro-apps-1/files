<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu7i1DlJOVqSgYsH+5SArrMSInGUP7ZvDAcuBytLQLsQ6VwLn4LWAi3H/whjKs5od0iWzWkd
NtSD8pMjXYfTXtlCCX6f3NQANkOTBeN6xg3NmBj3fC8g3pZCIwWDGXMws3S4vRboQ1VAr3ZKGde0
ZbzANY2gu+i6A6CHU9fA0DL6oD6PVyw4nTPhN+FqCF5Rf8Mgs/SMxh0EuzRYjBxxsOLoL2jhdoF9
TJDzP0Zhgnd9ynI8UufnWMDBr/ngsyvBuZAYRXD+6Z68SCA7rRq4bKjocQ1f0UX93eT5Sv8D1KUQ
ljqu/qSECTAEZyfhYjq8k31vhbWe8vSsaMBUol0RZMCu2/IqqTmuCT5nqUgTiuCatLIBw31GBPB9
IrcQMIukpF08HnCG7wlRnkr1fCDAy9Fofj5iDrpqY2lz1AkoQ1Arh1A+5wt6En3mzBj+91wB6xBr
3lfAPV2WW1JRYRUaGlkLsNnANu5vWakGEg3QHLdDl0KEPlZ6Eg7PR5iD9VRYij4VE2Y09dUE4rmC
LJVDyFbYU4ACp0jcwsftSftmYBSoXRMbnx9LHVqBzbw+Z350zihffT1mbkA8MfI0ASwsS48Pr3cc
JuUsVLChxurPSQpfyC6JGRtzlNRrh/rRj/XCOz9hYZ18dRqP1yYuIyq6GTEaK9NzO+JjkUKtvLps
cm3lhqw1LDGuPx/7EfTJYAn3CZ/aDiQsHYM8Hce0RQY1OviXM4qwfluFHNaVN0CUa2eeSbBeRl7g
cO++puNiqUNPABxs0BlctfE0LnCbiCTig/T2BF1Nb+IHmO1+e1Ds+r5fYEBDg5jNhBzBskp4WvwV
butJkgziTd68ubjBhOOT//8SlL4D2bh7HEZVIBc5t8wal5U8nZtKoGufQDR8XYTbeTVOSuZdPnSp
Pf8sqUmaEtqE+i+RAtXJmwoKJ1So9eVZPYjIIpjtkhjc9TW4cD8dB3PIX/Rj1HVdIKRt1Cm1GTy4
04u8VhR/Sko0m4LLU31Y5BWGT7W8hx2CAfsLFJuci8r0GdOLcT8zkucNW5nIAi+L9fAm7bDgLa/w
i5fh1IcOxNwmapWCwteJIFa/X/KzqYQaI/+yNNilVWnCsujo6tTOT2BxzELog9kABowiWO2V+xpA
5ttHSj6sL534Wt9Jy4nbJ3d69mXoan2vueknhwb9P3EraYZ6ZYpm7SzBfY6f/gJMSqqnNfTmFgyJ
AynH0t5ttmOe9jFF0EZIu0v4UADH+Khn3ZhDh32Dp6HTLyA4ps/g/wds4Kzs4McdKNWpva0YKGFO
O9f+MhAWrgWjDwOVh6MUj1iTn3U/OasxEy+sbifyTgVrTEeYPtBF6en8jHypIH5HPhm/Qqd6qv+A
zPiYCt67WuLOy/UEp7PQ/tD1M3O7UroDqW7ORMrQXIKLykxArY5aOvv7vsPJkjteVTviy3yiGfV0
rPBijO3kXNGcBta7ejuSH7USorAw9jUeUAJm7KdUZ/YV26qg2h1DmSL6