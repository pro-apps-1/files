<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuVCgBwfWH6nj0qzdHvMu1sxiGTdRVcizkOamRwyk4prp/Csxe3QTrN8U7moyEpu67X4OuEm
X2TxNyfzLt9Zf9Crzf9wzOUKu17e6Ovq4VS9kPpQFMSi2Bi70O9nRVHv9GUeNFy/xjUhXeWYMtCB
jQpfS8eMh7FnBGTVqwXcQFQwjjuSdlJxslHaw+ly52s4+yfi6uH2K2SvcgALY+MmnCjkf2YR8r7I
O0RlNL4b4LNrWibvKFRYveSA31aRyrqVYFQ4Kq3xX+QiAgcq7Q3re4ZJvB0oS8wbtcLE39O64VVz
Kdw8EF+wngzQoSU0Y6BSJ4VWQZV3fij8hP8Ma7L3zeZ7oS5TUJ0NvpCHYDV3M4A5E2iRlZr3GMLy
CMbTbohpNfLo15OWCKtyWNlTItl42Qv2Qch+E4FdHeS18VEBBqM4z3/ibcEwv0JSgwjxQtbAMxjl
Ugk0Rf4aHVHM0NywTqIhkSlajX0IerTttz15EQPYUlywOy3Z+aJSxX9NkLHMtEniS1GGh5ssSLwY
+hAkDLd217EdZYOmiwejDLRPelrIKJcjoj6cs8nckAyx1JxFQ/8QJukR2RLqTe1m/9N56JYg5l6R
XJOlqhTuQqveskEOLoNcGW8Yrc19J8j8Dr2ulwrJfF59/siqdNq8cnbDaEH8Fwb+Q7Ln35MlVqg1
SzkJhpV+Rs+QEEvQN673UWvI4LJaO2ckZY190fGhV4/lr95ep2mAB/hs9E7YAGq692DPwS4otrUQ
7lOv0r0BU8QN4Sy9+UdrpnlmYLLm2OaaIbaxEht/3xWMB3NSekDjn5Rjo2YwZysHo/pG65QGxbHt
ck9uc2VobfPoQBfWAHTHW5VNnMnbgKIQIKbwcjJIvHsBB5NzLgT6LrQgzzcXTQcVJATwKyN53Ckd
j7K6FtPUL89yDedBM1+La3iWMQ8ZewVhXbu3pXsIWZClP++sqOL5oiNmb9BizIe2RLk6WzRbMoIZ
ajWAPHV/wvl2lBlOshrcni+I54bbP9rI3WQ18PAE/t6s2wU2GgWvxgR8iM3xUQ7swLhOdzZSulWV
n7Tdqk+b4QAjX5LbsooxRg6NhjyZd4eKf7141Tf+M/DIVBi+mCEnzj+uS1QIXcFcwThcbKEJ84MK
gA0KaxKif+TtSZuKhils4rQZodv5YtuRZEiI8ghwySFbUKaMEGfgTMnr1jUUF/Q9nPIvgzID8yQl
MRu1SqPU4KurdZI+JunS1UTN1I7nKARkx6gBld6u7cgiTFgMOWVpupt2cXMxZT7Zlp9CZ2E45evb
1VDrTyLvhMSko7x5NjtHaNZfztONAmfBMI+kQ1H9HGRHU6m9jexMnUB5wQ60AqtJw0gbSDVfLn3N
/3L3Fu7To/iEXe8FBI4FzolPNwGnoF+mMuHOQW36MDJZCBewqk/jPEXmhmwVcechJLSJGKGMIC7N
rTW35+5ub30fakWuqVGzKMv56jOcVo0ApmK5becowxchm0==