<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnHPV6jU2aLD9vZfID53d2TjZ6nHLcmN08guA0QZzhhcHks94HLwm4Y7BoH2dtoKvBgP6d5X
UziG+6IlO8MPnxM0xs6MW8PNmDrL5TIPpBzhf3ltOWiiEZEqKsyAjpIWKJS8OAskIXVQcR2robnG
BrDMLCyvCZ8NwzD2LKp8pALXvVjkzK4sxUOY1I4r4T2KE+eEFsKMoLxEpkT01tTkH/l3Qi4vJEwa
rfdmscSooy5L5PlWOykzoesEyQuJPWAjDehMf73U7N0fAkuXIPj47u5uMeTaLcH1zLh76Ae5UV6k
6hnr/vBIxbR5BoHT+q8oURPMeMCMFxqf3uoUU7y1RbwJ4d4nMBewkIETisW4zcMefgFXmXCLVjoP
X7smNq+Raef27ojeoHlpMw6y2lGhsoULO5l/mi/4KmLnB03uipDOv8gpMptY7tPJ6v+XDNpCZH9S
13JD+bDdsn+viyhfTUYrR4K9hNa2Gv0oUFwVLEY18D+S9tQHoPMg0XQSZ2MQKkgCmwpUG/H54nMj
tKLaXGY+NmwZwIITZTHFMPyhznUcC3YuOEU4HfKFEtGHds7JQ604ctXtuYzb4v+WEe01lhOjdQOM
ziYmlPzs5wwj77DK7HniQlyOclrTw03Co6fOc7KWqoTt+a0cl0Z0Rc57HfJQfq9h1j70lJvgPHgm
FcXXhlkYUjQcJVFp6uI/k/vrSoWNpyG6Tn9ZfBLUscFWwEmJKfUjnTHg85TJ9t/tp3Sfdy9WgjU6
RwELBHH1NvWBA3c26DWnDsVP88Gvz4vtFVm7YWlaO7EBAl/lX6Y7raY7iC602DVuZhajmCCM50ku
5bp07KMQmR8MtGgDH+0/y6JdmqRofBzGOlsGwPxB3b7FhG0bN2rcLu2aaUh4gR8UKgIsvsymu281
eazxi7Y5Jn9p0tSZaKD+CJ6ofOhHX8eIFiRjwKlO6hF3fed9abZWmf7GBs2xocDlOEhHVsJxQ82n
D8ZExSX5AYwixZ6IafU5IWh4XYrxv++gtINqOfH4MMYBd0PwCrU7NxyVOnKvl5def9EvOcJZYhik
q8y4+izl0nLcsPBF5T3HcvjDtgj54WEihi68MHv9fkMlRVvnd4OWBDG97Ia5PStI+LGrcmRzJox0
VLA1I4K9Q8LEf2QX/5IINqK4SPepqIKbYRcd6K3HaUVCKKqaI167y+ELOY4CaowQNhnhzRG9qeZP
AzdMP/fjXAT0R/hw79HQxlo7bupb2ECIKNxWh5/x36okHR+GZN6jckBAfHMqkYpRjYwTueKAzLxw
y7pI0ODagZ898RsaJBx1/YCu/0/QsNU37xJJ//gYoxtubnAJBzK+Po1HD2oWk/Ahwt3eL/BIufne
M1DiHyz6TJ8paZSYbwWF1ltdzu8MtnqbwcfTukxrmN9k7EmmSPBA5vmoOGrjprXT1V5KY7idmwm+
SgILThJrQtVtHFAWTLy/+iouuCKIqWUWVC96mxEhThcGb0==