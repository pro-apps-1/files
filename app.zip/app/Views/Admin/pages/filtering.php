<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqsbXScPENxkP6GGwfnpa1NdujCnQotrkjWqb/oo32ligAia8cibFTwjNbNJD35+lNMu52nk
r/vgjkDGX3Y7FWA1fa/CAY6Wujj+Bsq1cxo39Ss/+RDySxeUg9WY9af1o00eqep3zm7iFoMrhDoH
lkZBhe0es2qbu23EFQOBym/dp7QRSFkzkkA+sZSFP8olwrftRdjgHRpBRQgkjrgulWNcsj487WuZ
w9kUcxEbY1oLSkD0UAALJqZ3xe+r7mIHoCXCwxwWm7ezVyeNcVDbdJI9JwGwRceRprrDdduqvUg5
8aKtO/zQ1/ClTZH+Rj3BNS8u0+nsWSBjA7FpXTrnU7Xh5WkDyxvxS0GA7ukqqnkUv+Z9NdOe/maw
X/rvv00mnYcNuJiNalDsCX44kpEMyVKLhidFXwOQj/qT3Dq+HtsR/0qeG3QrN+WR7bF41oNf4tkJ
xpzxL1YlH2QjWs8KUO0WIh+rxpCvYN+/jNtKS0vlYKurCdiT0VEOLoyuMFzmGpEzZYiPPS42FPAj
TxZOwgR/mta4MKtKB+h20YZBGH7M3LkEyv05s4Q5vpU5r1cpriaxe8KIP8QflQ7VwAwuiyZVrPX0
7qBsRVKB5V7qNKdm+fx0afPqTIxbu935Ew7RsY2YvU0f/+/jzGq/s/KJy3VeDGpBbr/5N1+qSJYE
84tDd5MKq0e9GPAcVivE+XOF194W6PZ6fz7yCKywdzbVaYy6f0tJSud6O/5D0i84uWElxafqh+OE
sBnGZMk7J+L8E8mlFgd0UCaGPPdG5eUV11m3BPDJYlAnGrBFzkikeRRh7zD2iETTBtir3bOcYIau
sCsnI/hBH5qXwTqEc1mQpGPE2NXjoylnVWJxggKSIXVMoo7qm1qb3fA1Pw1McqC9LC4qcMwpOfdy
UruxVULn8Aj/JIuN8nthTYF+9MPG87+YHBMPeG1eXPfkh8dkzWrnbtELWlYHH8di46Ph7XEvjFDJ
Vv9KgcujXEj3YecomlpeZ5EcdNjGR34Aj1tKmDvrAbrxv3S4PrKLYv5rWjkXeEVbNxFXZbflLFjF
UBBwt+YwxjqMdkWPas/4N6jRJBzl6OGGBQGJnruAOjBFo1pkRmiZqtuCEugoX9W1VM8YZgfQsQYe
tZDEbG5GTDY7xnVOku1PykHbyYXC0K9Neu+tAHn1pjczfQW20pGGS/8ewY7aSWWUE+v5Swkqi0UV
YNSzNo3jLefWQVRSzzobon1KMLrdO9ecLelNEQsROJv3EU3clOniaBYDX8WOvveU8vm1pBmLmovq
5EguZyZX26XS+Vxl+czCRDJlfdUjXfBS6QKpnHFkNXxr61ybyRsjVyhAAMtI1GpBuhlQWXgZ7iYm
NmuWeYOuVPJNMQZLW/uO2dDd4MbAMXfKVx8PMcV6sPcfTShV9W/Z9b616+PQrBVvgkSFuqA+QDLq
7TyOwu3oKm/A3b0kAK3hd/jQUFTHe5jfoW77fXq6nPmF+LPR1kn2h1UurOu=