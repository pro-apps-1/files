<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Tx5n87rEibthg2CGaEwsrD+2/14sE44U194np86+siaTKA09OS5qnKBcQiMRKRY+1AvcpX
2845gIUY4arJzjKMfUCfAlwmHVc/5QHWxgmd2tzuBiiUMafn5lcdXEh1JM+Ds91k6fiJrIO2lGOB
Y4h7fwQwMVGxpqplLhkNleTX1h+T8YtnXdCMuoyvBpLnaAR7QKq7hwc1JjjdmI1vhaLJl/Yuy1cz
HCvPA8gUDZDCZUr6t8742PErkYuoYkmAlCHPUBKuzappfhx/q50CX8kf8cKDPRrZrStQwjwdjPQk
PMGtUV+RWHF/2Cw7DnrI55AZsEWwS7SH30jjLFMGrFaIWH0Si77FBv+Y8DOY7yYr6tOg2drstuG4
gbEBvJBhv/DNcNVA5RLH+99XPbEBjEp9ZTPs+TgMU6Nw/h+ddWnEejzSsbzAdwo1xKqsoR59DTkB
36hzfmvI/YI0ivDZmVkYM4SZFooQw5UR5lrKgcuKbhOLZ8TXM9bEwedegIRbnvb0gsF4tmhmRQSJ
TCHD0wWKZ9h4WrlLpJeQwjgoWLx7sZM2xrGtJZUedBvqw6pcLMRxvAoO1PMb7+Gi+QvATl18P39D
jRAB1SQI1zVxRRHuYw4vZ3EGf2w7JU7h4ciR8eJu6W92DjWM3McxWnh/prSrQtd1vrz/XmwNjOli
AERm1osL3XDH5TfJA5E5YXECV8MaUHUY+p/bNnMZReBINyX61fc1fFz1I9wAYy50SxpXcg6Ht6q2
V3eWZX93VR7u6iTihIk+ZOROmBHNJmJD+DJ85mO0dFhdq4mKUVJ7BbEqM2JhaFM+SDeWDZwJyooI
c9j1jPu7zqhGwempMHtbLwUIurXkDdyXcWAjvJicBcoeOizypbmH8z7U3rbEiyMyqiXZl49ysr8a
TSFV7L1sVso/3X/FlsyjYw4Cr3hHyiQqAm4Bpksp9No/CmmV6NpATYRrCPS/sKIOf8gagrEjIrny
4L+ZjVaClqW+D7Gd+x569i/R38iFQGyFIMh9NRqhLIbZJPaPYOk1keAWyh7kjAJ3ORdEoNXvEdcw
B0dMiEpZaKl0H+cGboA8bbaLOHSiBQxkOI+Ys5uQ5KZRZFdegJdJcGOGHIfLPIhzOQwe7Ag4oIpJ
2EB8sGGJq3qS88GUML+EjWgX6R5bDE2ClwvbIUHN51sjdzubdDjVIGW/dDAvInmPlt8pOCZgAv0C
Uqj8SbI8i7ppzspg8Uq0gBTMm4dA7X+bjaTrKZNhoFU7DBWqkwoabgguKJ72AXKcfm0glTtPc8D3
mx6NK5yAGmvbKJG0HFKrGbCnoioRwMWOPiqS5A2gDyHYyjj+QwF7ECQd0uZktsoY4MTuN8JFVRdM
RLROHjrya7s5LpusAemNj5Qj/WQPBylpEtVxf+91UQ7WgsIqyjspFjGoQwz4ePSuh0ybIhoOivCm
rASOtzjit7Wv0aUjlOj0lyo1LfKAs1dZUnxenjdOk3iaZ4Miy9J5kWMxWZ8=