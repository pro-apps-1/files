<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoMThejoDXEi2rmxgEzYL9Aj0N8DcSZ2MDMdsf/5kUNoexu4KyaOcnbN95H9krTFUMRcgIhS
9rI1sW55bymtRfNg10F5FeTTwkTdJ8VyaIrox2fXxUIyaHx9qFW9jVNfPbVZl95yCXNh5cJNBs2q
cfRlcIQnLLvL/8qqY2WV9lnWq0hG7gbegTp070mOKKgAMFRMjThZ5SP27qqD3k3k183UexW77Wqk
APE1zb6iFXWsO/uQLvW+8PHkfR5Gc6Bmyh6e42poY3b7mRaD5DgPUrjRXWMcPezFIJejSV8GLVmU
TzYbVIdPImnsuFhEgNx0YCrBFZbnneAmEljOmL4EBkN+4/3zDgfta95YibP88vtRJtZEsxwjgNVI
SogPT32LffLUPaiAAotNHJTv1Vsjhs1piNph3s33vIQWaWMWRjEE1Q+U4Y/TWHlzZ3fWO4ewjtgb
A7pA3CQ6y6HRangiZibOXQqgJHD7E626CFvc3sGwXGuDU0y/jxKfwEy6LwKxy0Sv2SAWQv2xWToF
Pb5SaXSrS37hAZwbC6vyMv/uPPFvwDc5ANtk1dhvDcZiuFYQQcFKg4nog882cRid6Q7lUHwadldF
gRaWyTDa6PM04T8WvnkukHamVxz3I2QlHRwfXvcCcPBvkvCL/R8t/sVzX8trciBqR0AuclTvBBpP
C9zhygcH6jH3xezTf5eJwwXDgEAixGxIywPB37wi1qilvlcew2ciFyLefXYgUuYVetti5KURBw2F
Tm4lxWtkcMn+TvccmjqxpbywPfG1793/UTtkKTCGhkzJUN52HbFTdlo1MrxutVrGc8SgBmi6vvqz
GhdHa34JakJ96qn6vMHvHwp6gXz7QfyQEfIeVjfaZE+iklrfJhxJ4P0ScHkiwrrwG0PcS/TiAAjh
rQBzzfQYTN3r762T+79g3aF62cf4cQzOGBmxtx83j+6X8jLZ0qJZtiR3IdhINGyz75wmDJEhmayx
qVw+aUGGirz64nQRbrYeq3SlYCvAxreolVSvvMuLeOG2YwKoLh0rL9QU53tcmYGCTwPW4fUpUHg2
6IxFSXMtoOHNLIkbXMqLAsSvDWWTUygXWobYwY9IyKfqyCoAv1wKc/n8p1ndwC/nB5xdlID7EkTT
IbjKzBlkl2XF2LMsylr//LpCRHoO8Gobl9lJuObf6osf2TDc/ILb02bMiB893koUiKrM/PQM34nZ
nxaFp087i3yBwbzI6weKprIcL80dLLhS0Rp6yujjYdycyMFZBI+pBu+bhmbtnqgDgEuA03AZEnjX
Vee9KJegOlNxpJxRXh0bCciWfAJe7s6tZnP/RIyLEgulSI5ADxfsfQXQUcRsd2NCmhbNcf4fUrYw
NAGULZOlQ0QT14XjyaSNbuiY/za54kXv2dDxxQ9HvwHSAiukOG6kKpO3LxSsL2OZ11is0Tmj9U7W
95lexDSjB0fbdzNEhNXcEBmSrHhujqAOwStoNA+gKCMrXwyTam==