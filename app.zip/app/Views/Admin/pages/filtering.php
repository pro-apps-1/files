<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpMeprGI93IRwsfQTygPxK1+uFgghUSSdj8GRXdF+K6B6X92PKLwjnbzkDs8gq2PjqlRbKQz
fdqn/G4HZvKQ75QvkkOcQlfAW/ZqJAkPbAuvmSKg9EfKpOdB5tPkBxSWL1PRw6+zaA9o3DFuDPlk
UPrSIi5uauwyeg/0eZ1ep0WJa1mvhPOmIo52sE2cKcXLcj2rWM6Mu3vScHkC7C4zY4qJAZr22FdC
edjT+5Pv/cmFJqNWigaUSgwwHdX+K4I4J+Og+ecakEXNjwAn01lZhIdR3lsJzscQDVHUyrbD/iku
67xN6onca8+tvbaOK0xJ8dRHWzbOHXhqBUyNitqjUkzfCdjcuwqXdDVYfRXfeNN9hvECTmpmT1fA
dby9FURD/axlgcxhe5cS1AZJIVLGDmAsr6E8IbVzDTW7q1qjQKNyeWivJXCjIJ9vkhSEZ9OCc8z4
V57FQmdQVdUVXyGCjTrQlsTSByD7zh17hzKaiw3Ni1fZ8s4A2HxWV9CqvRuOCt90B6+aHkIB5AKQ
oYyeSsv4k2lWm25urnlZeRAhTGMcvkXQHWfi9l924wdsn1vdG+euOG0zzkFfx7CxSnJccj5ohYLU
rbrp8HlbPGIS4nq/YvSnsWGRzTRjYyaatTXAqsoaK8o6EzTFM/zSFYro9LW16gBGrR+hNCKbNGDJ
kEYrBFvjXyGia19l1No2SIPE9eNKKECG0s78DSHThVYWsvkMeTYq383YAqIcK77KNqE/eIZDB0eB
2SWenlxoyI8+/BGgIwPNAgG1rqvVCM6hGvhwKmRReBgpm2oQFa0TJuHczQGSEhneE0kfFV6EbY2d
v//HhEynENXqbJAz8OuSLde6lj79wt/k2hhD7nXJCEcagBCi0m3x9WJ/Uhgpxf7vXqQs6A+0epZP
9tM8p6dtt3BZb8oy/XQp6OvCiG4TP2q31FLHxalqgBP+gFHIFJR2/IA3q5vKHmIVJj2ro7a3JRJP
5XXm7nC9ifP5J6xzRjy0/WDANCehzxwmhN3RahC6TzXRcoKfS0Gds1uk8zQjYHFe4SCtd7Bi0zaU
5NH6h08RMvstMSWn2HoIAnJOaueCoMYLhIIH7yE5FdeDpcUH62H5HQkZnA+4CffTBZ5vnOWDK0E1
cKNw+i9vJyjJPSy7P9nD/dUg9jt5arW7YT0JG+e6zAS8B6Gb77z4LqrrZZD8SXY08lIKbkuRGPXA
6qfPiYywlkQZEQYf4B60PkaDWKNVWn7wdVtZ7eqf+LYkpS9y3DOw5w0zTojV/5F0x3bsoPU+7DK3
aKeTFUwYHHBWV79l2IuMhQ7bvtBUem7zPWYFCrFsAfe6btEG2WZzJDNGpS8eEGHoLRwfFz1Nk5Y7
i1PkXHTG0QaHx1Grrv+mhvb77Twla2fySZfkk78e2W0DDIEn8oetBsbT75UBaL61qNSScMm4AfNP
EwB42bDL4SXDnK9Hukx7Nz2YkqBwasdINeIYzE0wH3j/su9RYPIY21K+1oN16VoTf52dIAK=