<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPybVUENay43ByPxjnbvDm15Y/0pUK6fyOEmWSFq3NPEZJWWDbHu7TLXRBWvkqXpN1vS07uDC
o/Xqq1ojbo8lkbxy2Ku2ZPsQ/nZ5QiC/IaYv2juTvA2xLkhUUlD5KOA1mkG0i4Py5qNtH1T3wvZU
j2cWvAS0g7gHNaMlSnn+x0gOVpQOM7TgLHc5mwGUZPTTsCpoIbsrLNkDVg42mhmeKOJXHugW32BP
T2bLdr2na94nZlDEtQDH7e8NieVTRYVbXQPWWMxKLL0DZptD5Sss9lVne3BrPaMYxFJjWJIZaDY2
Wlv6OV/WQon0jpDOGjdYLFySikCwYA8S0oHKi+/qx577ofiuRZHJx+7APSvFq7xfeTc4ZVX9KUqX
0YWq0MMQhSUAqnpDjot6GOrDpOfNLkrr+FWRFZvqmg903BXS4fkBx8nPrskcVUze3lliOsFQo9i3
4dMkSBmK3rG+6TyET9nUlHfEG5oHsjQraZqu2bnnoYHhAyLasHWWKHGMVgLqqEulkDZP4dx0w5Ce
Wo5qKTkFpeEAUS8jjZ/1rkJ/f7AHbzgJuLO88YnEkuOJA8lxbVc8pgbMEfaRBikk2TeWT29+eXab
SG1KJC07d8HKaOAp+NhbcwU5JmxGX0VCY+JBN9rh4q5T/mfsDteNcYECuOimVEdMN5oNkcH0+T2M
n+eN7lmLdaMTuU62p8+EjAmtF+/Qr7QzgepdXhE6/nxLID7B2FKksBSsCew1YRurRkKrpjqh4bNZ
7aPktyqGdvgZyHLcxgAV8U5aTIcXn7JU1NB85RAeBp4prt+Z5PE9Vb6FsQzWjVBHOUZXRgDBtwhb
zl4UQSwsurTiQ3ALdjyJYpL5N9GUkC3cBpNpqInhSjMX8nxQvksAnyldeLXGA+/0XnnkGYcPgknC
etXnL5Qc5ehjdQbUcTw4W5LXhqyFX1b/kDvhEB+GwkG+HmulMDUYp7JMGHjfb4KuGmgHTcyttLbw
Ny5QzLm3ZwBHdAj/+qFaTe2BjWyxTa2mDByrPrsiWe5OAwXTv3IHOVse7pTx2S1/k4rTtwOZS+Dz
n5Ngn8W7XxwPQ/e/9ERde9N3TMNVNhRbkzWu3MT+6aOtfjZ+Xgp0c29vb9mbM/xrDQXsnOfaTgh1
nC0vdUkN++UFzhSK+cDpK5gKJ9ag8izqwoOO+hM1b/XygnJjQgi0EiEONcHXybAldgkFN6bh6hBq
3vgt3MhcERb7nQyAnxpzDMFqo/Ue+1SDQyjjIaJffOncMkws6OqCAVa/ndzCTQ9ytLwnq9lOFSof
L5YVy/WB3kOhZEIrAOiOnW8Vqlmlov6O2KMWuZzFu0lTxr396s8m/6oKgKEkgsjlGF3Aa1QnDkPH
0wvdz1Dc1qS9575IEDDLk5tvzcBNSSwpsOqw6qrGdJdYWATaY1SLwZ7mdMjw5dLMA7/VMXdb//IF
AnBOkfiaBnue4HFTyrm3ujt3+m8noA6XmMnc