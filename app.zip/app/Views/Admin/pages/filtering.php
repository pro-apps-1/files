<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPykaTJ3yEKuu+MNW4rBZgvuv2rOZ1HdtsjGKq9VIW3bzkvrzYMoUX2Au898QEqBLEOUwtyV0
j8QeEokVwj+C2EIxLMj8yNr7LG7mbuwH+wBwutsJhxSXoR9HIbjOs7LrbDe/PDvtHLUhNePfwCDt
x8DT6NRM3xdDsToMDwhAFlz9VNtT+M13lwrpADcpzSUMRH8oG7ZV/EQ6NeuOTgvO/PWBsp5MSTur
m9xJJKoKKfHZOWpzkK85j+vb21jiv0h5t+A5pCqn6RP6XlHJ5iRjwexuwUnLpN5CUZjySqU9MGIT
IOApXLN/Z9FleUhqOjRSlPwjet1R/vAvJxoflmGckn5Qd9D/T2OFxSyF4jk0ff8pm44UN8rqlOb/
lH/SgPmSG2a1ckSZDeMOUsemIoGnoP1tVNA10/LDynFH6wqHlM4RYV3IaSdGPJWJzz9CyfEaelpF
xLRFB8Ty8TcjDHB6qlOXITjhdWOon8bAm3QnaEBzLL9D7UMLCZDd58pvbyzBJhEs2foLkUtXH8NJ
bcgBpQPj/73KER658xQf+zWDkWMUkAAfMwkYkdFolJBp4iFQwNuwi4WtjKCi9npG6zqkMEDi4ESW
Rd2ufz/VBxcShBsOy0zeW6+k3vcfMETkWNhiqZ2RR1PICVyIsrnLaBqXvAu6ozgFIBpz7VL3uHlQ
N2k4hFMjIk129auCtJ772mL+KjuSm1HAduN1azZ2iGyq4v1BKfueUHr1Sp5tuQf4+tWFK+p/4lM0
8XIav89KdG6A5SfiSt1TScnRV91rEuWjRy3WE4MuFzLZW4a+ZPxBbiEuk0NtzDkCoyzK1uCDaJct
jZJ7dtQ2HMCeO7qUEkTdpnhTmJ83LD/Bm4Ug5aMsAqJ/7tutVB3S6QYsWZvZK72s+t4tYzxuxmRe
KIOmc8GeYNFt3xpZGzKOC1PAJ15g99tmS8HLG/59B+6FN9TWB/6ieIg6ihONfceJ2KypxPZSjGwM
Bc9T/OOwAtctdF3f8QsWKrcT+djU6bz6u7LZyyJdsuMaksxRJVw0cn2Dff5cKNjKa9kQ5dtJtd40
0RmzEv8XDTcvO4ePLObHwPYQP7m31zas+HNSo/YIUNfOTkylPEK/RKmL4/CXozB9hU9N+K5Qloig
AqzHuyaUQj+EIOAI/+QtGCvoTIGtw8/EfkOxE4Yqxek9adZ0vPIK8k03fKKz4Qod+L/9ugr6EMoM
wg0VSTujdDMncG2A7vX0Ymosgr/6qEaAH7Iy0idscLBB1r6RdjWI6G00cZ0ZCT3pEM8t3K3rIS1M
IfYA4G3kvb65pq1mb3WnynsXo48f2GcdLW0I2ttAjEBq4eKL+NPdVuOVkjuOrCYSqlTybbkexvbo
EeRBFlrIaxsafMHaK5dT/oLNTDgxV77jn+qSC5CZ8zSQeu+hBU+sm9hoDxvfr/gtMh3aqhHGxGmK
y5vOcreXW3fshbfDgaoEwEny1y5krGL/sZ65kgPyks81