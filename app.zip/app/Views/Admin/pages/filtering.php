<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvNqUzoyQK0KkJNk/pAKfSj43BWLnzzUUhYulLQebL1yG0OvLQW/gRpHtEXf7SboY8JznjRX
fBR24+nnQhy2jhVlfKxzu/itP4k5BeZYlLAn5Hpa2+wkxfMzgr8nLKUpWfI2dqDFDsjsMd5N+s34
DOwa1Pp6yJOmdteDFKxKt5JtKFvSshpaYTZUdOxsYmMXSKaW5MNo6nWKXNoiqKm+C78VrKBwK8z1
H1QBBrBREbzQBm5hisLADw+z60EYipAaHZ8eAWetD6Fa59t1nE8I/Q3Fm+DfDVdUcaYKdVBLJERI
cPTe/pYv4c2ZDx8xJdC9JRWPxQ94Ps9uQb+2m5fR8cUdeSO7QH/632w+6HY+MKfLYBUOydU9fZNs
dVuP4s7PxHkWc1hgz5H7PhNgc2KDzwAx76BJ25si6pgqM50FKGEgqb+ALvxyIaSTUjgf2ca3Nk/2
mHQs/K5eKjMOfSpJu9Ca77lPQLrGcTC/gUaYRpb8nEEkNJAFY9dbczbapX3WirIya5vspNbRABi+
ZntcXHSIhR8SnOkmlAuW/a62MrUwTnGsRXWT39sIDdWTPGsFQijW5bXiU7RhkbJJBpL4D3vxjYTQ
iuYFMCwErbK2eijSjSX98VV/szGD3DQb5swERZCQ47cN4S36sDy+ap6y9R2NTMcYKJ8Bi9VAEarI
5CLWadNZH1Jmlp7aUi8Hg0ZnL+HnG1wlofIe+p6dIMnnERqmAuZcqIsK6qzy55jQrmoBwmKvHj/6
jBkQ8tPul80rx1hWtJ5/yLz2p7kMmVz3fNohLplUCm20usrYvUbXmUNRfht0vGhG0q1R5ZFrrSMS
vNghcS0qrPIWh95ZvPbKQsV8yqZnlhHf3Fcwwhic/+jKLoeLQVd9A3CFxYTwDDwtFLJwJLRBaPkK
jmuSgZqpCa3p5zZ56VM7qomC9NzFOsGcNf054FF5hWgpWQU0faJVzRHB+q8cKCxPoMdESZ73T9gB
+w+SmUQMSKhGfqzuIHWrZZck4LDV6VNt7wMkuHTvWhksOPd2jiVoTeJz8IGVDC0iUYNwztWQAgsD
WOxmCSIUcTsRjdfreAgA/Vr/vWU33lIQqv5eBaes9D+qwmsmJtbPX4f7pX8RBLuMHPcHiO8cLuXe
Az9fKzULJvxwllzw3mmDzjpTWwc5V1/nnkx/FXP+wrphj3+TlPPlVxjt1yrqLuuQH119JCgzkdcr
gnI0atP1hOBmXAiuM58k5JP2H4qGDwvluR4Ad3aDodtsB5XjVshgb2jNC8GN/XK/FtEXj/BaRfI2
QUk7hcWJ9cz24+z6RHhDJKqfOHsWfD601DC1tv+Pkq/C/oplBlz34u2hypG4Pc66UnJ7G/t/gyqZ
gFqHmbaujuJocqIvCYe5Qs7r00XbXmZ8pNzCWnc7M8bsa5lLMyB1sv3bk3lEd5irUnz1+OIM4gyr
fWYiaDm7COupzMANWWukN9IhgKpjCCPg2Vx++19DCV/Rcwo9jjiN