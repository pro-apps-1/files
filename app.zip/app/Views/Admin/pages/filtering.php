<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnzA47qb1+boC8k5NgdznDqc3lfq/QuMrBYuwOoSTv9ccJCnsKHnievbwgbG5ORlm+nEaQU3
ApTFncy+u37McIW/uQmwO/2+RlpRaT+IsszMC408vzWnnegX3RFj7Zf5Ue26ZxpxZjQsluBWJuf5
fUx8n5KNsQfCyfq2BRRLBZYNPMGwISw5v8J6jDYu/9zilqJ1PrzXFs5p8rfsQ3A4UEg8lY7EoHDK
tW9KoWGkV8vPKbtBkbw1ibOnqnGJwl9upsSSIdpduDuQEICruOA6s+HRjLPjrriOGTvu5BnKCi4j
rBqq/t51OMN01/gFbeKRXyg2CJgiqJFR2FOcVBxDak6eXP9dLz/F8/yOkCzbwgRJyFNId5Y9Qn1V
vqWKHseJGiKt8u1jZW1LJ4syNSn0wY0zVh2Q8gMa4pHx+FS7H19MzIPx11Yq3xIFYIPE6z+BACki
tedlt47x7Nq8O5/I6o5kiC19Kh4w7uxUI5n0zE8lYEKk8sQ3jsbplNnGA3WkzU2xOjzyT0aMOr96
/+zRDgkhxMBp09XJJr2NjpMVfVFVO5QhGFN+9askwFwiLwkULz3l0dQfY0VKtg2yeA9eXl8+I54T
xKeGgPiH3h6a60+MeUerUmqEkhbKaU/M4AnKAVqGg3Jzn59vyIHG6jelhUhvGqlpnCCwW48e6n1d
wD/AKnIafUg8a2riu1K9ZNDf6mxYX8yqeXgL8BY2lVSoYjJwFSQibxvOtT/2ox9ghA+Tj5+5/xMc
mIDYCTLmwuwx/D0DOGEl1K0G+u4MZHZw7+BPPisrq52wIOpJxgTF7QxQJlkuxX49nvexSLbq1zLY
0/ir3kz1CpN3EEdq93bXHXE3i8dKKDIa5whsfB9e3Hv0dJu5PT9AUfhN4HFvJdphkvw6Dxmvnt5x
CVj5q3sI0Hc9mmHLhy0qOVxfhw5qiyERZ2l3zEaOewUyBuAi9GZQagjDc/7oXGjteFT5fEOlPBN8
f9Hr5G7HUEpI/pVg/OuhrfKxhlJXxjdUcGUgyOMBCZsofmbffGh9MrVoq8mKblr6ooQDL7l9EtZj
uPkus6wOXxgI5RoXrDHr8Tvpp+RW5yeLVdTB355Z0oPGlaIaLTyquKZpEVzdDYA9/AOEEOFdN2ND
TCQKZb3XsfCOwkyGqI5QDSyo2HMKf9vGnZvaYtGBiRRzviRBQIJAAtVu+BbBk7IytiOFeKgUg1/Z
TMVKyDolfiwPmVFVgkvIw8GE+Z6MDcBhttScqQWLBUZ2PKUE2hs7H95tevAHuV79dx2jYm9qlTWI
0nN4t7HTSUpUGOu0IysoQfWuJn45Lr+GklCrSnnSCZ1cD12ope+N86gjuA+hhVPiQ3D/YAqsDVPm
gcor7z5+gXUHKJ9Uk5YgK9qwkYxJC+DyUHSAqwkn5vNHX5korw83u+yxofrlDAAP6b3k51IydQa1
bNa9/3fQcU83PqkRR0cxvDqpSDEbVCTIpVeOKUKnzAJ6f0h8WCO=