<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/JWz3fIVCqzAo9X6VgFKqoEqXEtBE7qylrY3cyeccIJTBNJTog8LpSLNyQEd76g2/I6WBDX
G+ixnX5Z1/QN9PV11lddvbGrKkX4tCuqzgnKvB5zCn8vGXmfMMdMKBtfepYMFvJgLbi8xzgh0Hkn
9xSHQr4No/0pOjOHg32tLVxPmQF2JWpBrg5Aen/xyLUo7wT+oasunEpQ6uicTBu42c0e2eBuImnZ
GCbqCAhYZ9ALwC9Q4RK4qOADplFZULtb/l4BfVpNQGqzzeZKqb1s7eEL4+OSR1SQdB1BmJkEC2AR
Kut6DAKYTtplItO9t9TQ5kKnkg+G4ICv9GyZFRT3ltCWXokykzP6fPNpM0a1LJcEfpvNH1xcDmES
7eSQz0stslx95O71TyjqmhqE46UR8v/lDtwpg782lmoF0jLew2r03yu/1ulg/KQ62spSGbZsJxYs
gbv6tgh4HQ7RA4fKU/z7rTX0Jq3+fVtLiGmET1dA3kTJ3GploC5yHxLVdi/s12b/30CNF+OmBv2K
M5nP0ahLrEF5pfvLECbmmBb/V+wy5Vtw1Lxei9HTsqEV7WeZwmPG7ejVXMXPj4o0EYiVzca3eC5+
6jwZoYNHAcrKvxzredhn4fGVsiWmRTRGi1lbKisQQMsBf5fhSW75/au5mfb2sXI/AgyXhJdjZt5x
meGtPgXJSnk3qqJ7WGVlvoT+8Wi5eONIEnA7iV1EO3PIv2HuKNWFCkqGzJC85UF2vBm8yYQ1x5Jx
1I0i9ec395J/8rhshq+7Uc6mfAABijW9SkHzb1xHiw58VerYTejP4bE2xoPiCMOgudpxZcMeDpBK
i2sN1ogxvjfuPzDF1Mprjz4DugIkD2ReLQVXpL80FxnA5KGfHa7i5bDLlb9jJ00ccx7ACgMuGebG
CWmH7eDZ8yURdPAyRpZgXyE5zhuH9im5ZWKX3Oj+dDcylYKNJa0bPLogdqhcVLpCV5RHGB8si5er
PoAi1ScdcSseea58RcLDmpUkZv0U9tnaynWBRdCpOfM6dEzRi4A8CQ/u1GGrakEmaHSVYD1vWkBg
FUiXA2uRunUAOAN5AWDw6jI+RrmrNVgxncfcjr+8aM2As+U5trriQEFAsqTCcTUui6srWVFGBKGP
/OV/+Kx492gn5LQlVOVmWqVPvfP7fhABGwdVangkZi8l/zuosMasR2bJlq2lZJ/AdbdOkeiOTY00
eCt+LhG+EH8xB9poYeQ7mmsGJOowFZt/IlxfuT8Nykn7dJCeHCrfLBr1WrDpTD8ARTshidd/rfUy
RQOlUPbHPIRJAztUsih427pNPC9wKo+qVK7YeQw3FN6uMIH+2sUK0volgbRt6GZ525yaLOuA0B8j
ofXnA+3M8Kr+gH5KvHA781/cLh1pwBAkak2Ad1elriR6FsPDwOJd/73en0y+yk1lh7IIncxkqmHA
Qqr5ICoxZ8F1ed3xzyadrZxl5vRRKkeQCLJc8jYZ/uXQEGv4uvXunLT5TTxx9RKRRAijk2y4