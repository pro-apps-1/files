<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoqafs90kHjL7UKoGLq0DV5dWidka4v3cBUuXasjhspWhPyqk/cRi335UOZfT34qAIts3Beu
qiedwdOrfy0tKx5NHXJJ++SpM0+TcIr2c3ZuzWtVVREtHYXyg/esb1HNMbER8mE92CMfZHz1t7qm
aX+MLB9R0DrOQQ4SKQYErSM8GZEMQ6/3Q5fP9cTTCB0u3bbZfQ17CaTXaQHLry7XE9fUQ0vKRyRK
WdW7zDVbVbsVBIMRLaq6iAQvH6Cp/BdVZZD8cGvBj2YX+IbYrpdhsNBPbVbZp+xKLo9Qv7nx/FbZ
CNS6XE3AwatbFTV+/A3ubKuiw7h5UohfIc4YH2U4HgRtFWeTeHk4n8xd6KUFuyrjE/cl17hVJwEw
g8G8BJrlo8zuU7f9hgVcMpz5KYkKvQ6i50ZVBFO1aDFy5YqTS1SSmQnAxm1l3QDLn5YQL8lI19Ea
nozo9GURiYQn+d9ts1K9xhDxBbVWb8P/2oTJjlOSQUj0bDjVIP9rresVtWYBrDdsJbUtMBqIV+pH
6Nbt2Z/94d2BZ5XISLORvLQm9fQyJ2ljUe3qmHQ8S2ac0n2fl1cYUobK/DmbEKdu+YA7kqbSsCZd
kX6AU978bylf+NXiJ+enu5g/D1lvlZ0zze4pFe48WAtWOeAIXXZ/gGoZe5LTpKaQHd8JWuoqboQE
WLckZy5HUd53nTgacLJGHsMnC1SbLth7wa6J79xg1+VoZVZtkacENk5qGUUyqgOBINgUGtnzvWTt
aY1kMA/9MyKlWrvxnI4tNXJ5raKlHrJ/s54utVOtUJLmyO6jpDAaAciwEFCAtK/0tfXv6CLytCDn
IKZY/e0+bKEWzrm/reywHObpddh827UoqnihVCbkW9pZvn6OtshZ4q8xRQPET8rzSkzD9nXdd/+j
9mHhO46djRW2VUy6NhTA3BfmXWFAWBneyy2SYlxsBh1d9mYEWRNMabSZ5PIIxpQvZZOpnXXouLMQ
jTU2wGCTgDcwEDtwSPNZcXZixjrQXyY5ktFGaTbeYJO/Iu2kxIpYcQvU89CE/HSZA5TNX/trieEL
uBGAyQOezpUA6dLv3omc538I4v+qpNjvS6RGe8kJa/JqmbGe0Gqt1WBpP0dfRfgIu0a2W5DlajDt
2AwMMYVczJJ4Jz5ZMMA0a05g0SctC1jAbd6/rb1xLOUlcumoyOSjPUXt9jN4tPFdBBXs/kbh7lBM
lSZwRI60k+4VUP6GPVnCAtugwpEuO7gR7kNjY2Lg4HUtKOystRaVgk6Q72/YZDry8RWv8Y+FLNJg
wZlFmvZZEI6wg2J7UFt1weKxLrwzKKGr/KuBQT9PVHKsleqhl58LmhmePGaGnuJ3bTfRkFLt3V7S
ZqLazt/bQhyUACsSrhEE/wv2UXhWiSvxxWS6qBUUf++njWeXqzSxlJ4kmfITEJLENMb6bXD1XG7E
L5MMaO2zYzSmXv0pgL+Wv5SCkubTjMePiMojawOclyAw6Pu=