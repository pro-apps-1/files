<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/H2/k427yFMsuDhmeb5XLDiv3QTv3ZHROouKzbjRlDJY58aHeDb+p968tn4u760KLpesQms
I+vLzI7Gheki5urh70s14uWGp4JlvSJovjsRUhlMdxXbFxA4XKGsBlMndlRTePJhPCFJZXqgCsaw
O2psL0j1C0QaPZIYxwlhHn0ZN2ZaqbG44R9YkrvZelGj1C9XMKN+HcdcAXG4Fuvi1Yert319iRXp
y/3S1ilVlHkMdfMNckdb45Cr7k+/MmEqEZk91wkSve3f/SmM5W9QCEVAibPfksbWK8j+hNMADqhF
O1iMx6T2qlXIWG4FTMM0DJ7ZmgOti8txcNh3TLic+uNbrxbKIx+nZ+AElB1UQY4ThfvPRvnTW/8x
Cvu+Vn0IdSpMN5JsG7iDrAWu31uFq46Y0t8zjgF3GcoscQaUMG3o0q8MGACnZLJGhQb7liNEbnvZ
Ihw3ivXdmeLyTQTRjfnyvjrSUoGXYk6yBCsnPj9AENNpm6xZUnjv3TSIcuwPfHM5tYVXje87HIFd
xTgo3/2Dl5sj4hBrSYuYAcifJtm4ZRqnPyfn0MI4caG/hvDZ4LD+s0ouiAuxfMDggsJEOTMp6raB
SMWDg4ohGGdE8MCrbcLj4btL/lBBSTLD9bzB9RaxQwcarJx/U9+yc9isBt7b3bq0Tm+Wmg/SUrEP
xO36hLCeylEXKcwZejj+rAkC9stZ/6sCKyuaDrAoHNUwKrWfRKMtY+oddxwFKljiVC+RQqBLoSon
PCXMG9kfEiRnTYKPS1jpz1Fv4B1K/alDp67eWfpHqC3oZOQZL2TpAPXGHfgQRVQQ1b8642UCMyms
J2AYtt25n67Cc4OGZdlr06+JSOwTAqyJYTPXcw1vhtzYER97DMnXDHjTeNeaQxkhyi8YRC1xFsD6
8FbjIsifushO0+zdigHbOPFWDzVJAUd90hkQZRGN7fXyOAVXW++nLqCZGwIEBjt971ddNkSWNkTP
QLY4mzB9GKNRyzDL9kWNg+3HgQ3BWhA6BZK3JI6i1H+xY5O2WdfNLmlgXENM8XX6ucZpu4w/+0dd
TqlSw9YUs+HC2PNTLOaIYcGz/Aw1iWeTcVv7Vb8DTw2UchqZ+pVJyouOtsfYy0Zwheg7p6wAoI+R
dc16OI+Rp7tC9InCHDqaLepreX9BMurx0l8FgIBSvMF2f/UWp24SFQosXHd9iYYFXIWw1rMS3N4O
hiwd/ezQ987+u1n943yvn3NlIe74rPa/mSlt5/4YqgTfrXGlIXwyau55p/1MFpSpVaSryC2qcqoG
WaqAN4h5FQ6Z0wshixkJQuFpFjXXQgjbHkg7ISQECSc01OP/0mHlkzuQ8Cvk9zexX9U/s3WnMP5I
ZLftKvKY0Kc9kZbiEruCs6VIcdr4H8XV4imfxVg7BMKHEtPJIKzdkH+cav2yK73AUMmaMiNY9RhJ
W2DLdSVAwE+RNqBX4jm/ZlkON2neOsES9qhSL0pu6R4cfycp97S=