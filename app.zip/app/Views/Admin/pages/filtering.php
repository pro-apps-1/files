<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt/7FT+0cuOGNGQe/1RPJEjaDbRZV9jxQgku6GcEGKYVI5in3zRsWUnCIp13V5vUfFz6Z872
LpOdoILBa+4FphwRrIv5XxfaDuVbG44F1lLCRuYQlFP+XuQpXAXLEcN/MXMhKzD1006ZJpvv/gvm
0iA8WcRuxBNmKwCR9oxLFUYfWRvBwCsu7N1dB0/UytftNGS5jh1qsNpKLOL5t32Yy3Bh3kX1Lq6x
3VmbJC+vj9WUsskjD3uMi3FYB1xCd8oRoGA9XGmX8x4qZZJMw1YKFlZa7Sfbf+WiayJHdNNNdKNh
1tigVpdr+Xhvnb1pAQvEt3VoVdCXWFUr0a4Y9SKzxDkcX64EbUnTxBAIKZu7q5JbhgxZiIg07+UE
G2sB+NxHQkM0uImDrEPCgzOqcOA6W3+u8oFyy48a3BEY2diRSEc8VRAb1DveJcZUXLP/Xz+Li7Qq
wRPeIPt7xevO79AAMMQ5pbkA/Xe98stj4OQNjAeBce81CG4e7t/V6qTGigWGApV2K3u+tGxalFxK
hstGPc7SOMucRl8NYE2Mw2F+EqqpcSJGetY1GJT33uLJ6LPJI927rSiB1q42Yy1uKOafFqHWcYwe
Jh+8szbC2h0lW5aZXaOTndX7mhhSWS30E0sLnhPhIKtI8BQhyFDHeKF//4XNr8zhbrXfQ93FunE5
2Zt8MI6lrR5ZkC27HMwasSaaxgTaA3dtqf4SiWhYs3/3rLjZFUDRu6JfEGpfaCUyVm9KolUF1nDT
OWA6D7VT30mosg0LpBydlwSh/xqgRMUbUGOYyNR4FbxmkDfpm1K6SwkaHWuP+56lhfdToDwyz26q
Ut6Z9S9SOCYZaQMTuU62H05gV+8J+GFtYfBrPsmM9TRMPKr8c2cdsJhIoVtdLuZODt2L2bsJNOiE
o4YgKwqqwAwoOpc/HfPePX4cZU15zuglMJAHJuYbd6Ea7z0nLkjd5lp+kvcrGFQOEun45B1pZ4xE
AzEwP+Qy00XHMD+CVXsLAXVbVK+eFgRcq1fmowv4J4T3Tv9O4nfveEb1hvuA8CPV61ZTTxjqzFs9
xUPug/K760sTkSHc2xq57Py9wDdeCV9a3ALKljyUn8aune91LOHs9vfNdaQZSfSiBadi8Uit9iIO
ahq02zKkbxo+fwy7Cm4lm96l3JdDXftLwqUIrtrjbw+sAsN3EsYrMEUF3hHfeg7y8dsqDlxieutB
Wgk1rUElOwUBJkNqr6nJMwM+VO5XbkNz94h+PiftuZHNN2QtdWTaJMgleOXxnq9XYgeaEWdQT20F
ne+7DCvfSXkS0igQhzQ72yg0jcmQUyE4tmVejHQFrBW6V9z13iph4cSGCcberyChROGAqPtlqR9P
WjVmwhjNo9ttEcchviLSzAOEj8+GXI1YQYkJXVeGjVY7C6ZRv0OMhUELdOdv8MMBBAnjKEmuZabb
2tzNmICmtxFQ4GuVuud6Xe6ORoUKy4UTR0ssVGjhnxEbMYZrOeFa8UcGqF6YByH470==