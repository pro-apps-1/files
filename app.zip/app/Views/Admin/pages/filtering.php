<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy+Z+uqO/wJ0ekLYRgvrIuKZFofZMrVobTbEvw+C6EY+qVOQCfCHOgZTe003Hy5UjMvKBlDv
ruFY9O7Ada3zmjDzKMK+zTa61k84hGF3mx6CZaUprDWNplcoObkGDr9I6p2c5EWe5krKh6d5wDIW
8+kDNn5Vu+vuRgeMTKxjky3OxgfoO3inrUD7MX6Faso40jC0UxqfLg8Uh8Oq/YGFRElNJGD05AIy
gjpB6sWLou3pAHMC+Lve/mu6FnZFZumwLB7hi3JLRuDc1MUs9o04TxIsCj/kQVXvDLOiIvSI5olL
DO+VO2BWp7KA15fCUv3X9O1DdhmCP5QF5jpBw8X4Hv/K0a108mI5WBWr2xneDuL3BgumOKGXbK0b
q05UCG0dYN5u2sjk6Eu68rMEyYmda34Mgzffx9ENaBo5ye8Qc5WS2HV71fTDRyyYmpNEA3Xf8UG6
rqw688yOjllSrLsYkvcZVtRNxjAb4XOhztsI3STP9cvqd0XbBJbjGGfgn7RKyIqkH0+R2ZCYCeKu
Gn5ORDZO+3kdLmMh0Em89R/b0o+ZlPr2DemNm6OXnzk7C9vQ4a6cqQBPGe1EC/M5sgsw4a/4LA8Q
r6aWFZPWkCtToSJsNagTahUt1Q1L11vQcnFZBb6VxF1A0YbwzSDUEenxlMJrTlrGFHuU5wo0tJbX
StZIX+aV1B+FaYCo3qbkB4vBFKCtGPi8O3sLimnMe+livPb1VcwBZwMUc3F4ykkdnysgWjm5fgX4
JH+7Y/DHCMhgigoNAViWqWmDE/sFjQTrKaxTrPU58QqOGjGLf/NMiTU/EJVrW6IPVkDm1nPtxn8M
00Lw6KbbhEUQhifN4OlLC+nAVYTiNXf6qoXZpqt7sGvOUgsFPG2JsbGuOuuDryCldRiiv9QwpaEe
wH4z7Kwz26//tU8PDx49ruiFyYyJx+M5MigrJbGWGKjkZ0k14bY1f9IiGeyBQZFCBMj/2AjpA35p
oUh1XgxP1ZtTgncktny64CKFY5rsdqn5+FCesAY3wFpL82UlK0AMD1jaPsrdTPbFWUsizLx97o9e
/2LYicSAmDcC55+mg22mgPKkeXARWGW4aj9jhaNCID8q5oK4ZdIi8Q5KOeGMUEVxBIDSdqn4Kj/N
jhVqOxhZl5on6gCalX4N4xUXvxp7I5ZMDRInzwO5Tx8FRAL7fDsTQ/m9o+QSa64CvUKRiOUWqJ36
CiPjvQxjFf0YN0weAt2fkS+uN2W5sERcFYInBEEhRbk4OHeYMG9HqLOCglg/gXNdCh1jnm/ALcIU
/D9Ae6bJ11Z6p6/XrMX0EoNv2/+wLwRuY2K1iLz8uXbelyER6HppN0CHQQu5C6UHQPG8pKQ3hTWq
bqNUeyuQ6dCAI6e+5MY52Nh6PIHyeI2NoPfiMpfh1KTg/lFkobpBbSj+kB5dtxkyFH9WJf4n9C0U
yBQzEncn6QZHShk/1Ow4BXC4HvUkfVOY8iAFZ66zR+SBO5AQj2YWV/G=