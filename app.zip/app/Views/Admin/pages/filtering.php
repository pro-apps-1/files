<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtWDltQ2mGDvMymgLUNKx9Xcuj7MLw1QYPEuD0LtxZch0dkvAsHh/gHC6NJr08YDWroJrrug
xWioZvX9GjX/+oqR27Ah0+H7PUspyF1z/WcFo4tdq6AhcPA/39w/w2OT1LNGJX4vY019eaph3DHc
IvSzq3HmU+Bfx8DEqW1YTMAMgeOQozjnZsw/nbIXFQJLUxTVrnS8ZXZ4w1KNc8Dx6BznJRM1HSpZ
mX73WHb5BoJDbyghDR7vbrFp96T15cL5TpCt4No6JafnWqg7SusbEtg059jbNXnOB8YrpAv75sLZ
h+UQZJ2bvD3X8KnKmT1cqoGDCDTW8Se8dpewzhlrPwaBG9tQ8+gAYugMhNanWTHrn3hPVvqKMN8a
y4A7zdkLXoKvLGKzB3QPM/iUNvTpsClAhbzft8KA7P7maUeSMdtLPBLs+753I49m5J3y8kb88Xcj
RLbWSYW1zIjfJ7VUmor9U5lqAgWb/Eb+58g5qfeNT8pq8OfUo4gH7rJNf0dZ/bO+ayEeg1okIDCj
a7z+M29nVxHIii5DmVWZ3Wn1pkpO+3AuiokldA+X2fDZVfcPxYfIVMZS2af0qLKpeYn5BzFElRG0
BHaobcxtPyPomLi4ewYDNvb9n1K99pj1fzCEeLhgKMeBqfiX//7NzB+FdMSMdsV9XIi6VEB9y+qe
ujs6L7THUV4cHjlc/8TyRPKoW4xSUhmv/iok4IwQXGBrRYEWrzhs63StUMlVTRzydfuzYH+qryxO
kZ+AfB91+KnCh5eKRLaOSdfpmmbVq0OjgrAVELcjCB7T5uNwq5tmzW/LdUwum/Lw5XH5ulRObUxo
oHSYTU6zEsNAJKDBLdGHOaR2KYwle9PY/lh12YmeHlV6vlSwSBTkXcEJXS7PmFWDYKSgJ7LYmG1d
p7XbLh2MlS9a9ktVeo/yK9iwJd1L60rT2sjFRMrfgZ1xPT2fhRv2JkuZILo9nRYPJd0U3fRtaXBp
S2EyRRNzKKCTFVIvYtDrxGp2UcsI2tfuM1Kd7j3wdMTOwnKGLpE3SH52Dg4OJ2643vACzJ22HP5q
2cQsJcONmkTC82cfpbM8Dj8HxoeYJxxwijn/p4XCPEWCM4dDgR46tZlhzG5oJ6blxFxAaKvCQfYE
bEZAxAHpRPErioYe5V7r8GE6xgbELftpY4qjNUQxZsHcgHs3RTDz+B70twXtSMZqyO8DJmIoNo/u
iRvh02t6FtvKVYcA12kCG351hAvzwXrUpqQVlRe834vJfeBZtxn2JolaDpWl7V+Ckoupeb0xz4tG
u6AK4UeqW6Pdqm6NA3tXTHNOfK2kw9Nkql/wbhf65qtxWsuj5a97cedevzqm8YEkHvNJptEqTeAi
iFtfr/WhEoFrxj2uFzYme1R0jfgwZ6hqu8BJVpikg5f1JDyJqcKXhw9+YfgCpxTNOWnkwxE8MXjj
XPCUkux1QMx+akPb3x1hk8nLbQRdHGNbpsBI10qGJNG1IvIf6m8HFfl+Gm71h7g/BzS=