<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp7eVm9TPKGs62dg8Mg0k8jE23givg9xLRAun5Y5OeZWfW6X+mGjN5i/JvWbeCw2Yqv2C1WB
kgEiY2SjK49poxxaPEjPv6L2FiKomns0HsEktlNEFoASmZZyW2lgRAMRJQYdMX8abg1jze7SVIzL
a5dBY0io7Beqv7EGkj5knhqSoHmocMSe19R83r8n5uDp7yXYqQbdNwG0GkA3b1FCiUJNkKjuKTeO
zhwwNfmp0UJI2nAopHhE2YgsKCJMavkndZrVWFm/shcxgvYq+RWdSfyMU/rbpfAntnhMBErHgYjB
dyTi/m1rzL28L6qOTGDgzFAjXG8aeDXtkMGaokQi6vOfKm6Qa46l7nJi019XjwDG+aiWkCeYMVUx
yy9qkKMlhE9F3YBD/eBiHDNvOLKneYoMO89l9Hz9J6lrJk5PYdnC1xeV3uIw4VCgcqkSXw+kvbaH
Q7OGpNFav9suYNTD9RXXwaE+TsPNAn4f/j7nSPKrdyFefc+MmFgJgXkxEbXtpJsl5Dj5stWd6DCZ
FLosJlUUeO1MLGfmh7Jh2FTtxBZuJ2Uov6Kt8LbpVBx1/FNiZ+2+tvdO6TlxGDZFAko65o2u318i
Fyb6TcF68k9Fb162JWcUHtaEMLkAPYE/cYRfG3fVNqnkzQ7TygInMokfipxq9eY98excsLqxJRPc
Nnp6OTu0p1ORHredFdIOyTUKfhecOH19WReed712MHPsqDYp1GQvSTI+Gdi64kaW4nVDX2DAEopv
iSjaeafF2zEQn8r0VUnHwmYHvHB9bbxON4toso2Cf208uExO29CnkAI0zN66in/fGM6NU0LGIF2a
geLrCaHgS2kwORe4X47ROjXfdwRourva+XCMZkt23hL14O+9b5nhOZvXmHvpOQCSVAWiXgiV0d2F
ReGZ6JNMcu70jCbJkVel3wC95dajJWiO074ta3Hi/uKAFzdpsVhUeX1haGrpAZfRqeFTZd76u9yC
hKxpiXt7fVAH81x/D6O/2jpJ1eTDXlIb0eVp/Eqz9eZORezl2VUJYnxdEAxAgK+oXbHj9rh7n6Jx
985V3Srq3EGF6gg7qE9/xP5NmghWRAY6sObNtYS470Zf67MzjIS9cMCwMHnIKVkELLtUYLymrDv7
cZ9KqJAioJVxJQNPs91GUU/R2+YeAhw483FeUb3s6TXpwTxwlYpIZNZ2RTZUzPTYtIr6KloDoHZi
Z7WqD0XmqmpMvD4DUoYJvSd5VaNqWhLW/KkJCwTgW3zFM32BXtiTiCDAbyWw7OJvjG1I2Ze7qd+r
mmhHmEj4LpuDixa4HlHnJ7LktIeRGrir72xW9P+lxZHAMpYkiveJ8Hj+pdFcd0ZTmSGaiYQ1CfH2
s5Hc5Ojl8RT6YjI1/1rHEur2RzxKN6Kn8HbzJP6xEv9daZ1buNlx/8A/skp9kLOPZI+cDYHdP7Q7
xxEqVxnDcOaALmhZQaJJ4qZS7Bf/dVRpDXFoCwaVnHA5zuF54m+Ze5srqJW=