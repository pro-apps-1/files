<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyNH/YFhWiCKyX1h0EEWoN1qpoubu8cDZ/jEqedyKVSsYGm7W8isikm+gykX2vHd1+4chKqM
HQ6fqxo146hYJjGm5DctU1FaltpebBVr+4O4R059yDX4YqYK05zG4OQRcukPNf2Tvmr9dMdWNKbO
HQzJpPik84xAxAUIV5pdzGMbvFxlQ522X8wT4+nCR5QDqZQg9oiUp6UyjRvdH2YTsmVYxg4kv/vD
1e53wFbbxO5LLZ26DoSVMjwsKHB893ROQQkKt/5UV3HNAgEvKMn0WDbY3cAXQZOO6mtMu83PNx3j
0/exMF/LKz2uuiJJ/33D9mzYK3Yjk76MsEVq66KvKoElOeQkqDeVx70eMlMvhjcrk1qTpO4MIbvD
xAC8mnIu43sIk1p5lCoXkOmYeryPEs9DgEDhvOC9DkTFIvGRGE9cP5RqxbnOxyYrjL3z8yLbBNak
g3yH/CpU5AK/aPi75I1zgByh2lkVhyQoNwXdsO9sCcNF8SsNT2NrEoBF3cwGXG15EIcbAY5uvIx3
NHe2xS0A16DJIeM8GmNsRV8rzX9mZ5ZTAWrLpNPqB1Szjhlkp2W0xaVinbJqGjNMsPIAKCWC51R4
gQVJ+8xWT7GFWjkuHGjsBLPB4BErpcJyapXEq5ZFJlrlK4ABH98WPIlHiwQV5ClwHOMxhhr7qxLg
9krDgQUrjIw/gQO4mkBeuDA+sBQMbxI6o7AKJkd7qG3bopkhdtZWrp5+WnwGgUoRTOP/ZURCqR7k
ZzSrhibdgwMEY8Ko24N2bPGxNyf8Iv40mBTmXnJcGmugwtfBZEIyiraOQsY5NtDVys5NfIoYbRj3
e3YZH0N+gK27hp07qdxBSIPM+rCm04R0JUG6yi17TeSNyQNUe1gUVegW4I2nQ0zs+eIq/QhQCrFB
uTaa77XvXydqqnmVOPRCkejYy9aGZBi73NLVyYi2evL3PwvHNl331AcA3oLGft3v973IDePSEBmH
mga3LiGKzN3ucFxP9oijPspRpel8f7B0CoXQqBbaFM/HMw8BqsLIDJ8/vUO6C/9GiWDRH1nquxiB
FgjQt5o2sFgmKlvNlW44ctlJYTD/6zVLqf2BXaPWPJVJsV0cHMeTobp/bnXjxOXkA9z0wR1Qz43H
ZHqZt9iB6lMbPP6OQWEIZwPJ1EDAJip8TKCsak40+zy7pid3YU+mL+7xT2qmLHu1jliOy8R5eQ3B
amsz3hEXvWQWGLO3VCffsDoutZXqTeQg8wVVySXU/zRAcuW4ebGZpMNxpEyjYXYprJ/LcA6QTtm0
eHPEIXl7IXDA/bFJZBnlnMZv2tJX9M1d1H2yfy2Geqi6ScOdEGVYI6BgqNogDWMt2ynzIyp1C0wE
14VHPmVtPFPdfLRtSUSxt7E2kqI1oox1nasNfLVzy5sQPpI+Zbs+U9KAIOQH/tosA/UJWBYOc8M1
zgF67DRAaOJWK/dix+Ww1n4LdmH7nM4/MBxilc3p