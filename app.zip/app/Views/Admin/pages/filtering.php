<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPorv0sHCwlTB2RYMHwNqwCQT/5oPl9BGmBEu8rrWGkmspjqq95KdWgO5YMAFeapSgqHslT1S
eI8CLAu4aZrOLEwu1LJh1LrLt8FkM666ucr5OQpdMTAKBLQFOAs8UtJUKXHPwWsi/t9KR+TKO1ys
Dl1FmNJ5R9/9QOTojVvEHKLnzl+8rlzG3QmtiGppT/PrMxvemjR20+ZsGyWF21JIdtwDfB+LgopQ
57kH/JVhrTH3zpes8lFrxEu17m6P58gtgkzoSkkF2qtch+LXWRBBi0u7Ravj8N8A2Bvxh5FCZFIV
J5KtrYPwFTV7gJj8tyip33Uhn4bCROk8I1yUuoZ8nBmosO6U882DlTHIRDJEvZd73ALNQZOG6cvN
LbQ70tNcIVaKppBJlu0cwYp9tQQLt7Z9FjDUy/ouYCOXx/bkosWhC81bppbcRlGN22m1a3/DVvx2
JTfBrJNt/Ni0cuY9YL1AjH3wGMQLkJxdYo9PiPP54hSt+p3jY7y+o7G/JuGawEKYbYm2PfrZ1WVJ
OB8XvaKbEg8DrzSByiwHVORqjVvwm0m6CNIyIGRdeIv8E8/m1/H43nXuIgV6JdYNkW8ePfDow0kX
yxv38d9C1FPKR1cDvlfBqg2DOJvhod46VJL/kuWsU0cw4569FHHtDNN4A94pmOA4nUgtwzHXVciD
YPpOwVGkEy/T9fDuR9HbuaBix05/JDZBJsJ2zkc3ipBp2quqDXIvt6ykD6D8Es5Umar54Qf8gU+j
5/p1SsrYKzuL8bMlYVCIP2FbkL4N6vEYxw7DpoLmDdIQp5QhBSSfhhSmk/buc63Hg/SOVfdgt/bq
7pAHYIHrOxP7jv0uskO8jpJMllCcFdJ1Ugy9S2+Cdhtv4cGgZFCukLkUtTVB3AHX0g999uzGpeNS
x/j3fmKhS9DTzif1oz5kCcPX+FmHFJjv7GSK0coMVbhJiwqLXVPaLGXzowEKqKyAz0+BiE3CxwRE
9YSqq4OdKBnw1Of9geA6vkYFWXsBRWAPERsSYA10bysMQmKKXacDTyvo84evrc5JSKEaJ0xiiVqt
8oyojiZ+c31bxW5XWnaxRPD1LIuIh+4NR+B+eLNv3aG4s3r8R023LDsu6XdXzGqJmXpCsChsvOpL
iQrWwU2LsAIpRpU/lX9Std2vaG0jWjqsxtvEu7LCdRO1C8Q5QpieVf6IIQNQ+539aLu61W7SB+jy
1cWjCMAgP2uUuym/XUEx5mUGUHnlT9lB6GhLmxwwrukq0OcpcMKMD0xxNRJYtEANIm3fx+5rkkWV
w79DHwOwLMlazG8P6dFOiSWYTotQbyWYjphTaRoXYO1mAkQMv38B2zAV8cMh0Oc6NertQ5k54Jrw
TloEjbLTZnwiLo+y6l2DXOfrYWKi5cBnBPVGw1NBkzr5TVYx4Bap+FQCml6y8TUHHR8jk8C0Qd5b
0OD2Lv1ArNmgFQ/geZXulW94y9dfDroRSdxkLhxT9zS9EWEr/DNUpa1OjTQuixa=