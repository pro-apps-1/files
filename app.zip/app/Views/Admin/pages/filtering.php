<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzfIQlaM3s//3++J/n/Q+zzwPrKAJOzlIxAu7cvM/kTJY/TrfcNXfDQVYO70vhgO9uZTiCC1
R1bQe5i9DAY4dPq+mgwrircEnC3H9fxBxTDSdAH6Nr1HuHMz33ZKjB2VJ9eNo9iNdwwi5OvV3wHM
3iwRn5Yz2y8iFkftrmJYQ/wTJHKGjBrzX8NXQ0XF+zqJ4+/Pwty1iBJDRAs0y1EewBiSK/+78KTe
D2cSBgVzTl8GV7iCh8etf9NHyaFv4xFSFUT1nc82gkQCyqV2yCGmDldWeC1lVle2EHl8dXFaBf1S
paSzZA9SXF0BIHP/E5rOgXFbKD3TXxGlLEXGAGdmt5LDnTlPuYGDp5ULHQQgCO/kM5d3u4hPiaoe
4cwQvpPNbrrZ7mxg97nnQU3q+C9Hz2PV7ws84eoyp7yRguEV7GmkD9T6snJDZJOLFkrRrjCHLI15
GtkbkROazRB8jNUmz7pnEX+D5d9yYPqWbsnbvnOwdKiLSXHvpz24PyrPGwddHzJsC2yFJyYcR+LJ
f9IPCj4+dAg+IK/CG+S+gzalhBMbg6rfGNnz0YcpHWENx2F5Kp3doBYbC+O5jGaxRqw13cL4316S
/oGUAWcyUEcKyyfKGWyNn1nFVND+WQ3vNZ97z99n9lcox4vsFgl1Ydl98GG1DzH/wHBfKUb5S+/9
Vxaw2+8Iz/+MeaNjcHvNIldt3pXrXwhCSUaAnxAAKuOCQTKF46MuQkO/ees2yfa8ixgNtseqZ4Gf
9Gqj+2EU481KNk84bWM/0pCtKeH0R8Nxj0oq4bkgU6Gfc5vj94Eqxew5S8X3IJAsVnB6OPr8v/eB
rdyF0hr8M/fvAn5dMNvS2Au4JB4xYri5PTqFoWt6zsAuJNAB+/5aYF75Q3LOSIB4AyEGjNDFHdVO
JBJnLXujgjA40OCFJA2BU6QFdVLzStFk2fm884LSDv3VNfIa3jFw38jMTDQW1Fl/RUQIaG/UbtTm
OKUxsCKzsEY8Il/fdACrhC5hVF5T3MJlhKT9uG4G7w+es/RhYScuFOJLR5uqnQ1op7kz7kKCHsSd
makAEG7hijByiF1n59dViEFm+2WibXrxaVM/9b4zbtYd/7idmHIXqBVaLkhvHnJCyCW6P7QNHC7a
9Eufa1IRxNgWr80xuQy+Q8e0hJ+vzhAN1WMco7CiYS6V3L6kBTEStu1Gl/2Ug585bV/dTfkzwjcg
OKtRPa+oTUppycr+XjDEs7pLg/bSq8g2WEsPW9q6v9qqvCHX7pI8A4vKUXXbeNn7PJFJC9Fcq/yU
quuxXbD1Ge96PfRVqFQuwGd622unRzTchkwbXrATgpH/J53JWbWdPOQycU7KRIwyNfqrNUILzsFa
O/bOVnciFsYh4B9tTIo17pk8ixp4uiGltyA/tpkMpqnmT/VFaJR0kGxOCBwBxbSnjq1mUNKCRmiS
1Lx/kUyEpeDPpo5Lc72KcT8i9BSHbbkDBJPskSsu6oW=