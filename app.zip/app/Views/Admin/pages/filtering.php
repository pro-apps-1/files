<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtsfbuUp9MoeIcW2f4KT+JHyVTOsRyqgfeMusTQZYFvYajWiQLTk3JxpCbgjpu01XxYc2xZ2
QAjsH6V35wMcsiddTyBvd21VzM7YpCfeu45KwHg8I3hC6W1pesXWNzQVkLRSl7JXVndCADhUoB0d
MPlWzrNYfZRrWhDspbhbCvesQ1ue5SleAcaBm44vSMGcwTsfwr44x0jMSxxJ3hpnp4YQ4c6G6SbD
7VnDmPTOb7jl9LSLy63T6uw4FVeHaYWO7kot9+6KJ9tsl3a8lfHDjYU7lWbhRTCzqsiGuj/U68xp
OEOSKZ/sRsIwmjK9qDlOwq6hxT/MXgqWfH5humo0gSIOvSXdAQMLSpJCddvgYPegvT5XKeOhdFZ1
sW0sRycc+XdBo0cemfipgwQuE13Sss92bip7iOkSwmQiFTGsVgpW/jrqsXvtyIKu8ommlQ5Tr/jS
IOQuY2KDO7xn6vSTtEDl+OWuRxdGZpG+StaU7JdgzX20tspEhj/9+0Y/G9btSWMG9qr5CCHv1LSC
+FWxKa6Pe21nY2wMhI/moibN2wwbT15uKcvwjl8ZQsu4UPaeJkH9TZwO6OAWnpBdABQVgucg5tdX
l+kRo6xhpHSEGmd9afD4bUA1X14ksAFLIzNz2p4ajvTvam7/qdENe4kcy6op1SVuaipBlMVkTjoX
9Y20EzS4ZJjkz8fZloAAIKx8IdjxNP98HC8fBcqRIt3m5ZZcRQNwOFDq5cH2dAVbO7QnxCsRHpwf
5ccg7Mi/at6hrMk9gcOqUqTmYdjAgscAzjyE0IITEs3l6HE418k2J95EZYo9qSdl+msDP0V57EuN
Y8lSPVHsfJHmilhS/aOSCSwsygu1lpIRD8ss0/QC+Ng2DJ9EYteSCxBS1MqDPVEFq+4VXyJhnRe+
4KSvJTINPislqTABBu3X80oztGfMg1wK6rM0Jbh20S1o7K4F8t0AMKRhKj25yCkdrNqXvEPgcT5q
hUUuoY8CG/yz+1T6aX9B3JWaAFwaouOS2GQD14pWWGP16fllntUzOkkcJnEl5TcVY9++SHCGJhys
kbbmfTRK9gYbnYsOTxVdZalirBeqRcjSRvcH62fx33dohgJfjn1X2R0VUbNjHrl4JLA+27an56dV
lf9SEVJ8DSX4d0uaSApZaut9bGH5YaQvwjijwuWZBpzP9B3voNhMZmnBEAfX/h1e26XMXeQJy0qz
JmjWd841rrWAIw+zqqufGKMm5s0vqQoN4EpnGvR+nF+FGDlZavlkijNF60sQ0ifO6+RcvcJrAFoV
FNdWS2Stf/O7YwN/e4VQfOGjxj8HaomAV+Lp9+7B0TXVCPnJASybhgUVVGOoAxltGoLRSPSmEmLe
AVTQd1Pqwv5H1bwPBc/N/gtH+BPXar4+ENAu/FDT47FoiJFSwP8+CMTFzwd3fxB8niUNFnVzp/GU
9sE0jHhLzSyYTIMyffbwVQYxzGUZ4LoBBQSekAk/