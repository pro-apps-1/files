<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwLyHIWFqRqFrhtG2sfJJ//2cZ2hdNCSNyPQ2VpLz1ngDDy8jKa9RR+qvbBdMYSilkhasZzD
11oG9aozQR3L6sAvw7/lJMfp0KBoWTJiJcbfe2kocEkg5kyTCqC8UcVcJIYRO7kJSeV4cGXGyCyQ
ZWE/AZlFebthwaUw9Ii0oZdZIOoUyb9uYK4/Jg9EuqK5UBzUoiXy/cLwai+VQU2rpjxkoRmJ7bJH
khk65wZ9cWaa9A8NvgwOtgOlskT2kAjhpA+EHpJLRuDc1MUs9o04TxIsCj/rQUnekPzuIrYhdtxL
jOsVBkOs9GNk6YIVvySnyEvhWqk5uQTbkIDsSsbCzJ325TsRdP1U50WxbZ3qLukMxZzjJwoo2vrD
Rzz3+WG7Y9UPPL0leJkzaZPmvg21DFQkmKYLpvXQW7/NdYSq4DS+Fq/9eJwVWFPy0e9RFrsuOcGq
d3d3NO4iyEv+Yg0lG6XHltgCe5nEaKScGlFtrDuffavkvXUIodAqqV01SkjDyFvqFUiu7Ttf9S3c
tvrkHzBIBiiSmdVVGUiSRYFXEVVlpQSvje0h+hWcZfLCgilsaWHsADAWPK6faM5xzIFGXe9A8PON
zaUUKmY/XeuzQ1ZZOJyHZy4gFewTTzCj+LH0ebEXjghZJsDY/pFZD1EmMekNgb4YdZjtqaL1m7BE
KhynpPYPzq+qx7+HZylBOV+pV8mCUWWMHCrx8jneXKLC+PU/LWDwlq07iRN9E5o/wDfAFlkJzSNQ
zzgcjfTPFJDCZuphjSIczGJInE50vmYePpWE5ygh1QhHhI+uBuX+dWpOVuLTv1+o0BJ91kxjmc+a
D0HqaiMuHAlI4zagHYWzpQ6bAoR/FXgI8hY9XcRzKGJsAaG2j/PmS9XL7xpSNKKqIHKkTQBIIJ4t
R+y+XwsDSZ/LGVEZn8CpA2WhdgABomirgpeIMmG4O9YT9RUWephRj53nNu7ipyM4xRExQNHs2Sbv
+he3BPI0vN0RIUL5FbvPuRW/u6oefqgKPMdr/gS1EfC0Dslga3iOuzKKcxaVx9IoQYDQq5YQ1WL3
6XBMDFDS5XEyVhtMyDBFA5fl/SLOhrNNHXhqxbsW4AJhlY6SmTQPzgvF/1GfSA5qKj589ilvcj/i
38MRM9hjqhTyEFkwJB609tB7YBCfk+yGZQg86QsvhlZOhXTr9aPW6p/ABv90xxxtdFjcvedc7DCB
O6u+dEqEWgwgbpjUNBAry0Irty9Uq+zOGLvlpCrKkd1vuuQqmTiZsiegRGvvTmvexwxu5xiEu6ja
3t8r11NHrAc+157HoGZB3bkZTW+1jVNq9QxEknxWMi5Q+nI9SOmzCYQwPta9sxK7HeCLZfguuzQ/
AngS3vgb2m2QY46bTMbUGYGpWO76gBbVdSgB