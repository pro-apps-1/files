<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmkWaCYU/+jfxsTX1UlpBaoZ26v079G/GieHcCIu0URmlqjerzVh8OAd3hsqfZQQTnsmkmv/
ruVI8J0oKyGKwh3V2lHzDoirhczdiCXur4TbOf8plMDx81XVokTwsczf9jr9oM0KsQFM4tXjrFnb
DrJLBBDoWQttpMPGWMzI7+H7TQaQDYsRPY+hHD4eLoMHW39xAhD6MfIpVzou7IEbRuw3tFrDT/8L
KE1F0NCxX91mzFr6AlSIb4uZrq5jj5MJSXN7ARwWm7ezVyeNcVDbdJI9JwIuPqYJYdPNwUnZaW25
eaCtSh9ItCQZxoe/xFpnCPg+JElVkZrp/9ZXQTwiIrhxuuv2zzeaPdmhAmmLxuMWDcLgGk9yBVox
sVUkyVnIKWOely9DQbbAw7Sp8M2xqn+I4Vam36sN7ikbJiquReTN50Jw3kmnSu780hgZjvabGSU1
psh7x6GWCWk0Fp4qNRlVUOSF0i0sEPLbDXJ+wbeYOZ1BzyWdGdyFL1/d/MDiOfQH1aNsR29do/fF
92zJcEIgmJj3cZSbaWmfJCJijptpepewJ7G6VsITAhAwAoSJh9iErVZZz5OVY7isbB8s8i/UOrA+
Z0iNm2MnLfqh6AFf7sAVRF/gtDpf+3qmjGlcmEQsacbH/mKe/q2G2uOm77rnSSztZrN5F/7bNQt6
KeW1cYsCLi/wSNHA0CLDrc2YatqtwGYPkupw4WZCJdw3+HtkuizOGaidmCQrcU35Baoa8y0/73Fd
OBgm5f142hUI2xiY8GODyRGEdbP+cp+T9bxP1DcQO04d1l98jm9oVhdRbIOASwKYNXiBaqDOoAoN
ha3H8Tj9Z1BMCuH60ImrMW06IPpMuPyqr/4xeWHi/Wlq0jZsUa3s32n6nleJtI9cG7r2Sh3aQObw
PS3ct5078viMBMfyDKPHH0cAmmpu/0dVdnOYuU3giHqV+RSpWs+96lx9+MDYJc8DbnoxDCIDFTYs
OwYQ+FOIzKJ/exrhR1jEnQJxhRn4WOeRfzK/Sa4B9KBCupWzdWcDGQf2aSd020dBE1ZzuFcUF+6J
fjDGlXWZrjNmLmoEzNn0yebmOwkmi1qIufyKJ7cCjvL6Fvp3/qSHMItNpDYR1/u7MwISSh5P1Yc4
/BuWmwP+e23/cDdoho7MqagXhTLHt0Z5th+UwThPu0srFNmNOiKgm+Gu2Y10zRPe7j7n+Ds4vTk/
9Px2OYkzQRu4rNeKiJlDTmrKR1Tjm1jA9MJdMsZMENmYarz0aVUjwpSAPR+X5hUujCJVs0FiZRvA
AXDdfrEj7j55wW6RCK4Q6fXH1ZXFLBrC4+LhpOIuBK/QUcxW9IuIAi3klfZO01Bslv8GNqRUgtrB
YmoJNasVDvSX6ij5VBDEBJ22lheqr+Js+CUSk0kJVKS=