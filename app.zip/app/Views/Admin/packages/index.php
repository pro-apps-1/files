<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtco+lgLBj/zO7DlsU4oTPGQ+Iol6qOikhAuBXioVqm3zSqUiH/1Of2kAEQkJIx33X65wlyC
PmqFjhNyzqKvzyKqOT1iyEdACazc24ivuvFTqwQ/jcRUjOEPBOaj1Q7dNZPnkL/2W5QvRODc/G/w
M5KiJ+sCfQv/ceYpt27osTs2ZenrQFJSP2iiB626m3tFAI+jTlHn142b+GbxDpJcqWf4j1RYJ+8C
E1Ek3QiMjsFSTzr8EEEMipFbxY7O5iFmc1UmCEF1x2Mp38X0OBGOBrINoV9gUwelEXuftCkr3V51
udH1HZGEUgUHVJzoML9/51bz9R92PCdnr1oFQq0F3X2AyX5ivEY2ufm1902hchmYHmxf/h6BgB8g
nvUlAU3hNtBV901Cp2f5Yr2140guRcIb0TwCMdA7hNglyffsfRHjnE5np0jBtkJSZowmnDtkDW06
T5VVKUE0bHEbrfFELDSt7Okjn1Cmarb6ZxNequMd1iqlrEu3BDkLS/ma0w0BC08/G2JpJJ6jXtTv
pznuLq/CnPOpz3WonHTOFvI9NMrvLXS/s+PYVJh9EUaLkapCeUoJhwBhsCdfue2axmEGS0GXxX0g
+0pvY6zPTrb1H1xfJq+WDpzoTfoNQml+Ulj/JNxNnQbh+2b4W9d8BTFFTJ96CqEs1zNUafnDdHiU
J0jy9PN/lUZ6LKipNSHYQTLTpx+BKLrC8Oh7vFUOYtBYS68B5R0vD9CVS9jPQF29XbAwsVkkV0ZC
tLfQ7nJJAQtAurRc08bpyirUL5QQfvKMu7rr7EUD2AmFGvsOY1z7nUG6zkytJAbis8WBz6rB4fva
LTe8wil8Cma/+EX/Y/crQ6NpJw+gB47YBRCgaivaGS+5vIZSOAQvUQzS25t3PyEPvyqpNAf6bEn6
AkiM3U9mv3NjEkCc2M4LPKYunIRaWvb3hUkiFnT00SUbuUNN2/scplvpqOC1PGJokJFBlC9LValU
lCBWkhP5Osyh897sZJiVcOf/21/xwkXNN91475YB0I2Gba1YJMuzaa6lYmIH7TDy/LbzL9RRB2+g
IZu2N5KCeWDoBfReJ+e6UmaIhE9Q5nTA6YzsCdiiePM/bI6J99LgEeoavTtY6AjV7jq9kLl9hCs2
gYoEjhdTfHd7UFDx3AWocz6THbG50UL9c2dv1UXUz9IeLLXW7SmnVq+WW407RSTSULFYAGCZrOzK
0us+zZDwu0Y6SzltlkQIU6Iegn+jYq7ukbHxpFLvXKmlWMpeWm4Xx4HwNOPQk5s7P1fgzdyCYEBj
Bcjxs+vlmXu3YRes5ORYkGsfaPEnxBdw1mtn9v5/s1EM1kNia5azPafEFepJAQmxvNrGFMMqyhS7
ltu6Tax401XqECDhSwRQlB1d+bDpwKThETM///5gtZ52BrzN4w48BPdziT2NWa5WfWUVJDm=