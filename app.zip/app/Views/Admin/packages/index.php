<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvZu8TRiLPePwJcqzIYRUcT2OS/JWxy5Ayvk4qYso8eD647NDR2OPmdCBcrHUj6MhU6WJhNm
RepNjL7QRXzAfJR0JCctd/Ynr6I84yHVmE26/LEYZ9P30ISuxZyJ2+KzWy7C57n9G08223FYvXUY
jwB+R3cy6Q5EyO4vY1IfYQRmXqs643Q/SDd71JGvidnjoYwWVMgvhhgS/Q42urIZbbPMmEkml4F2
1++K0LIvSFysSPVxAziM3OBInxY2iVw+aHJk7pPsCHcsHeRqKnR6xUgE+EdiLVDjy3zlkUgJx0/r
qaa2iOLN/nyMnXjOIM9PaqIrTh9z8DwRIUAKVZ/d4KaPMT5WSiKC2PueG1frEec8TnaGdbt5lXgT
CC6sghRqWeKFVJ7ARY5sohX63uBp40XXElHm2galirjunB7cPoi8kyGCLnDNU5AbcwkZki9ZYfBu
uraq9lbSasuFhZ4SmFYFcB32XLAsl17R+ZN2mhm+4jRBpB/5aXMx/HniVcvAXgE5NlvTsDHr/93H
4PfjxrKO1HqYGIHrO7D6DSKrQLV4U4XnAO/qfi2ub6tvl1RY8gfK/mS9KTHdkgl8eYRI4EBV2fjx
r51r8wqvR27/GGofPz25f2BvH8oQIK+g7OoNmZB+OtE/X3HdEMPZuYkl3zWGFcJ68uMroennGrtd
6gqz13DsJ+TnO1Oh5yjvjoW8RWpm47AS2tL5AaF9+jQJzE/0k2cOg4JHYPfkmJQT/dkAj9odbVNz
+SBBmLFlWLbjg38edvw5kGj7K15/qP+HJfIQS9UyuJlLi0TW/LYGUWoKCX86eBhw58AeYWgtHqis
tB2GkrOYzBGkLt6wuchcj/z2V7o5SLdG3t07UOUpQc05Gq6OpWV+2uDSoD2uzOtLDp6kww3EMzGg
oIqGazXjuZd+wSvZZdxNRbE2ZKTllXdbNf8Jyy+yu2whN/rk/4Yz9tnyhZy9y1gjGQPuSLwbmCX4
TPDuxE3SrgPp5VzbdLQTrNa/IDU5v9fVWpils962kXKXTUsUbHenajRPIjA7XcoW2RfkYJTdUMSo
BdHSrLiq4aetpI6Rn4xINLLaYWpbn5K3ry9lJOvYi0xSyMIvV3uFOGZD2lx3y2o4UvUMHlPr3on3
5WOipTLsMIM9Z7Ba3nu9oqQAyhPfBU1TcpesH7AZdLlLuqHg6qUV3dS9BykgWmuJVww1GTeC14U5
vPPlyi5wvGKVm/qSVOP1cvR6eakTYmMYbEdqr1y9NO7SsC5R6H6UJ1tusp6SnJ7oiN8aM2ij6rs6
81ngHKfRkX7IEOJwIOMwwffajXMIpdm2+9bvzDEoVsmR3LgtLqX777XZ2ef14EsdWfUGA1UPzjee
D7ULbkoy749kYag7ure99UFcrqwFZeIEkDsF4XO=