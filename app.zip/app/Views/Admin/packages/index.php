<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsJ1i/51aWZ6700cqlYVwMuVIHgDSncIEj+B0M3ctX3Rb7tqZG8D3fpcvvtFlLloPhLT0pKV
gPVtlJzZ44qvoGEGXAehTWvNl0u4lqgMAeE7MsRN6ZawfkaPJcK5cRJlPYvAg09ltX1HBXi4Fnz6
AbgtxlJRH0pLacYomfbILaxgNvHCtWgBk4wxsKoDYUwKolJ8oV7BOGcze+FvjEp5Gp5QEtaDrwOi
kpjX7xGGXe47vegmxrBezcAfbv2WKv6uitb0JBWeELB5xncJHZQHAvYmnUykPzfZ5TZde78wj80I
jv6OJF+ST9lQ3Oqj5aws1uUoSyBAh2dQDxSEGrX56sfGVmrEcLvva+gynmUmOeO3/HBdxA2ef4qx
nnze7hv/qIpi73l0jAHfdmL8lpQU4Ou6vR9fXfAUefNuA2PSJvDWZjOweRPhT22lu7MoziS5D33E
Xjbczoek5G7RaQlClm25Amk/y7j/NBPiq27Hz8QHSW5XBVcElqHbOZEV5p+6WuwW4+1psA7wXjKS
kX5j0eeulcdfTdly8y9RLiHesLM+xXvOy3Il0fwiYl1SLhXPpxnVJAGcATc8PtvTtSsSDYsuKKRz
9PrRwXjuFYQ5043JqZS6V+7+EHj8qy40e2obiAjr2meI6UO47Tkz82ZZsndrMkgdNfTJ9gCYPvq2
AjkIxspas4YbxyHe88m33a/fPwPh3dpJQfVGT+eVfHSLaUuMFjqd48UDYHsZvUh8y3goLDQMFtDa
BH7M7RhcEW2HwpACcNF9JHeIqoeX0k8AxM/KEOOXvZRtoNms7cD6Y3YUfIvDe/GNsgN8qmUPdOfJ
BQlo1ueXCJvTe+v3r1WRpe82V9C8EbQaN0vFh2fdtNveRj0BsBssGH2xUPEusRJP27rgqLGAHr2s
COGlsRqRAP0BRPkg3M69niqWG9GbkFwll2l+/EwC7TnPId577xoR8QXQ+Bt6S6T1GNzyyNhvDYlQ
kTQHkFqNZ6Kf/molRIkdnzNHHz9Hu1qlnUxtCeyLG2zq1OdftlkhcfEU7QhLbXuvMofz/ro5mBs4
WJ8aJ4yEoy6OR5JmVHebqvQ/GKNuEu1LjhOGO8sRAatauKLtITTIpUhDMtvqjTWWknHu3D+f9LuP
10m1FyfXIhZyfjfMpLbtGAVb/WdHuSTAy+3v8GvyFHyxdsHCbrptduyzmWGigk37tyZjxo60K+Hw
UvtXjXA/cyWJ/gJsj1Z2aUFeozB4mXsk2Qcw92j0WS0rid23keNK8q3My3f85fkQSNc2Yx9gyb5M
yBju4Br96Y/s4RB6Mzn3GXDR7vqtA3OHAVWZUSJapUxqh1gHWXGXQi3O0xzxwDArKP6Y5hR5tiVp
DwV8ZODUjnPON8bYhQNJkyEHD0q=