<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzrI1Icd3/uElfEG2kVFegQo2/xY/0ONChIub/2X9DC7DOj2eOZ9C9kVIqR6k8pO4G1tLNHe
1TwKZfMtyuBi45RKNHZ55kOgop7b+ztyv4RRkuaw9ob49UlKtIf7KMblw7GzlNva5g79tll41eQ3
MBCGifSaWtRcScCZmcl+LGyiY8huoC5Zq0y9lNDJldmhFI+5HwoWg6xEsaWMo7nxXDmPD4wBD60s
XfDABvlt+dRxZMi83H6PeBFEdCgUvUyHRei/RXD+6Z68SCA7rRq4bKjocHTf4+Z6UXp6po4C/4SQ
lzqb/tRWchgDspX3AtOZaQFWWATiuDwYkAwI+hrROfO5Q7b88vLgO82LTqPFr7QSlQmem3N/g8yk
+g6z8RhAHbib2W8FL7+C19BV3TUESO/VB9gut5YACckjAXAqZmFM5BrFe9ci82VINDsYhcBe016k
oRovwCWlXcsjH5P1udCkmxsUXp9TVgkdFl7XPYavJEcZlG5N2iQY2fY/w2vSSgjVpWhiJ6MMUU76
w3TZ8mvxufyMp+yW6o1mVpbQgEwrZhv544KFp6xIpfGa1FJEzXnpQv5h584mJrR0VKfLnkqAVEeK
YWn08RhrxCvMdVuSjjQzgRPzK4MqwhU/6VFp37gn2J50EgfadC9hmex+5MtgMjsgOb46PRVqt6eN
cDy9mxq6w+qoMd1Bc+9BsIIgU67DMBhFV2mGjAuYsuYKbmhrPaJQI96e0hvtL3uhYSUoULlJqEec
oCuWtn7KlezTDDqnXzWadA3Cu+NGJ/ldWGeP6Wbi8p8UynnTUYchOWaPQoJd+X6iZmxT/s8Q6xuZ
+twWpuz/7xZc4uJPihLKSolwte8DrX8p/RXmpzA0Yw6fNnXo+rC/KbfQxex7/lJXwxHz1W07Z9Pv
eiprV+zsAtTGwViVbCtT8jA1csZdq39s8jTj7D/WGXJVUPBCjpVTG83xuRfkYOG3dTlYhFa9WZ6R
8HN5YmAYVYiVCXV7Hb/xIgni70QjtLdyldLfksNG9sfR8bs1IszFtPmvatv3LCK3tqRSdl1yqwTm
D0Cxmkz+wkqVQOfb+7IvA3jp1g02VcPkV3b5IfN1vSNwlA44fdorHJSaaQ1Cc0cyVNRuzqxy7rxG
mvoJB/MwQ+03Ebs6hufWHdYrwFdzYe7Dvs9kStcywWULIYQsR4FUgpvPPTjKd7mSPRtBmi5iG4TC
sTxfPDe5DxeSbHN8GvUQzQaRfG6a3tuAnNfsSedBgJNOT2PFU37owsXIiwe4c0kB7Jq30ZkyLwNX
nRWU8AhaEd57GhZT7DZKxpEt/WXYEW0gRsiRjJy8WlqVJ8lSIDOiDujwBilquv6tVpqvu8LxdO9r
+LAhS4pU0Sx0bmcnd9sU7DZbeM88f4ApYt8vJVuurmYqu93BeDIh7ATRHW==