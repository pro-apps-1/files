<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/m4eh0GsHQ7xSKta/YlDBUgLBVm0y7J1lTodCzKGFLPwWoAkvvG+KhQW8yu7O0vi9GPDuA0
xSd2L8Wljm8D0eS/pNMva6WTyi32G0g5zrSDTeGM4RbwLNiglS2lGkNv0Qht0/i6X7C/Kd8f7JMY
ynRK6Aa9kP5OMg3c4eNOwkQKMamBNyDIFpM8+30wiqLFrVS2I30aE5vqyk+DgvNnbtu0I4Skw70C
ZWdHEKNoIFcp81tUDAAGO7NifRN0lWwOSYe7a/Px4aPphoX2ab64hzVSx7jKP/DWEIf5SPjKutb8
zaKbL/yhddm7QTvrSA7apt+fbFNvlXXvAcfb0+TETlTnZ8Y91MRxbViRRAXWw9QoiniWjbMBgxXd
XnsV+d/XHf+3JkSINiasMe0lmJ91OAZAuz6JNQ914BIYbag6w7AEhQOeutigreVmx6Izooi1aAXZ
gSp8Dk9U3u60RpbRbXyaJYmr0Gr733PgbKbsBGcXLoYKG503aPEchAknE4oT2d1uuMSozBBnXahm
baVjBKN4oXTy7k0krUfOHEc8mpxste0LkqwJmO/1Tv9ox/rpMSE/cKFTgNp+l0aiOreqbu6faNXh
7QR+3OUOTd73xBBs+ft2qDC2UFvdVoLNl+x1Xsfv4Y4pL3VdjR2Ayf7QGBGbvinDBrdETX+hsBna
3sfE4092cum7IUjJbTAUM8NkbpTGQZ6PH2skA36bb+s8ZVM3qD2HD2xx6O8cP8UiNYActaxXes4A
ZnpV1PCn5QglM7N6XZMiXNG7WdHTZNvZtLxHhT0Maa3fsL+sYBtZNaqXUhqftE0Msve+pqYRm/e4
ydoV1mxRhIAAD6Me+LBCaBjMOM1hCskdA+dkqm6KPyYOcMxJnpzY4jjSgFGULjP5ewrRUsdXc8mc
fMU3280in9JUTxAK9lWLhvFDxHodR//EgzhYD2NLu+IkFMWBERqJEex+M72GrQ0Nejw5GWUZ3lHJ
/w4MqoYktXC5RQA1r0UJL1jxBThF+t2sUjb8IeJ1lY62Y1g6z9iH8W0Utak2IX7Ndv9XjIAW4Hr0
ZORKoqGfDqBl1j67K1/m6z/Zv2feruW+HUoLRLZmqd9zxNx5Yd/SvplAyjFr/MwPk2S8Wa13ED6h
Au+hWPW/ufOsn6kpOAVzSuuET30lzSnxN+AScqmlM0ItkTxyn440s+dLWZdWaqc2m2aUmtVFeSLP
ZjqIzM44n2hjKtMB93t77Ub0leE3EynMmO62+hbPlBaN01SPiV5/GMb9n0ailnaoDRiPiaAU5p0/
Ry4tq+2FyduRyXux4VT4CnbXjTeLUyd/EDyFFMA6dDZy6pvTdh8a24rAt5Bcts40DYCeNfGLBmgx
MkLPkwX6xmYik8jmi5r7WQ9hej8MMCLOC6I+mPOIJHZDXvdtarvGxUvZliEfQpNgpQImQ5xH/62s
FQvHim==