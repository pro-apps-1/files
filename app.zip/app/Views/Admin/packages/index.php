<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+L8T8hC1KskYOdXgJrL3+AJKvYpfbporBMuy3hFMW2TQTtXu72epgEZ5SSuZ0HACOhOhk+z
CB0VgLAysPziHdp3q7zUdCfYoOOALgKof3d6jWUf2q0ciIuZ14l5rr/Hmsnao/Uv82dJKw75+S6A
DsMAD3Enm0HOR8AVROrjawYc/GSwXq2lZLTqagoqmDAXTcXErRe1y1LAoXc/DNc/4E6g0bHIcGXg
/uUfdGNMn1r/MgLZJavRwVbgRg9kB3dLBW6h7nWRo2Rxs85Hakb8U5GQAo9fqGBPIBtPi8s7Wy8z
Odz+lj4dUSyfGviecJlV8EFbIwiJlqKrWvxvV8xLtmQTXqtGWgK7rTsRDkoEyCEwTg+shybOfulE
gFapL/HJ0Ova61nDsiuGX0JlW7qWLwHLHBBwSDBr8zuUIsizmoHJH1h0VnzF4hfqCh5GfACQ8lrQ
3XjWQSAdhFjEbj5+XFaqODnOBkxcAGT09rSeIbRkOwFsVvruerQZN2giS/2eUOv05LdT1UXLEoUz
3zBNk+BtyufiqohaTh4q9Z6CJfcygzYU7Gn0xaXJvpLye7ytd5IZzWVr5nNCuIdBM0JVj4ICiEW9
AtLsExICbJQT5yDl65U69WiRNp8YtvghXAOvLMnRdcrfX0x/+kqe/P6PWt9RrPYzoUdig68+P4HW
zXPwn8QLpGIxZ4iHScu7rHI9pONcqzQmFNlLwaGPqAmN94n6L7wVbbRmZuxW0ngiq0XWbIHYd0M7
CMr4ec2eMzj/9flJ7L3BwtdWUhAECNNdGTnhpMlSWVmlJX72qG05edmoT54RrwgLRHUcVnjlWzXr
doxcBET1cFliSzzI5kBxqdqcn/9jlCPFehSH2xJ9ioTaB03kJE6h1Q33E9V0rj44vdDI1dE8fyfi
L80qNZd8O9MDM170nOwEUtn7YvkjPP0f8OlhYoOe2Gnt+KilOlwboRCZeHurWCTi94c0Ltm3P5yp
G9LY/N/sC4eERaUytXLJSzvWMLoxgn8RxQi8g5xeVx7SC57+sXGpdaDSh0YaBixvjOE+PAhh32ed
DIR73k3a8lqPaLhItE6APb5kjQ9uN//9of367ohJbRozm27lKMDpVZ0/cPNOM4IfTXOrXVPpPq14
3uqadAjxOfmrr0dWXpUV7Gyn92FUAAl1miT5qb8nAxll6Oskt5/iW/ov4udiWc17ki2so1EFawdq
zJDHoAYbQ10OQO/4HLTRpFT66cZzsaiamhwk4MX8T/lToA1hJgps/VDbDUVhQP/JldRa7868FoGm
5KF8JRuaYHTpMQ4bVH2JvQjkkl2dFtcPUIIhIxBh7NrcxRHkuK4oTNuh/I4f9d4pPbfFFkjaIZMZ
DoO71PbEaoG2oqLoSTCLkRp/uzrsyLj6FZFSjHENJFa=