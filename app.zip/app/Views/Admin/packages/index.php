<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxLrQpC/xcy5nhJ+42UaL47r99ZT+JTTFTu2PH+zjGb1FiCNp1HUG99hf2fz9uz2zZMmnZvw
fBdMw/Y4gGnip69g6H0WwD/DmanNKqzcFaDP6YfP5SGWaYmYujgJjjv20mnnCg7LPkvjkXYLvk8T
pDqvsiL2cNNJBSZqrJDtQMXFHFIk+Fl5m1F/PR7vVEw1S9dKipXIxxYT26RXZx7obChzFR4A4GHQ
zawDBjcYSdPh1k7ac5YnEcXYWoGL5QC6tA0ZO4fyv+3U6ZaZDU62XjlaMxKBQgdThocI7Eb3IcR1
hTAz1MyYnLRrC1YH3J3TRUGOc3b08s6+9dYwFe3Q95OU3FhdQ8Mix71O9yZzBQQCFg97Md/XpLPj
kpvNZPXtH1rh68NkI4d3ort5BrTCc11SfnFJjIviB1ngczHOrq//dtddJs/sksmfSzTVKrI94O/k
Efw5e6oFB35seBDMHEm9Cxz3y+g/uy1nYossU6B4p007tyWuaQvzZIs28/nrD/xaBHKvIlmCqIqE
q0VKdAoGZmCdKFTXB/7QkmXBmmTHQC6HKr2uFOrVmOxOfDF/WIXcvJ2vBU+DuxixZcausfR22M4/
+DxpHwbdkiEjqvycGrFr3S0fXGyNac/zssTSGszMSXWY1BvN/wkvXF60NlnMKaKd4qzxwfKRFXN1
HEmngn/DQoc+ldEMl+C1Stcv1v3bkQD0C4Ax4V4r5v0iFx8MpJ73lPlolgy6EJlcwFrBDsMXIxjY
cFHyDSkdb4fb7H2AmGDf67RGmUR/u3TQjFOfHHHgMGMO0sWFflbPjF9rbQyKojGDVRQaQN83iekU
E84924eLgTSHROwGWgHDlclZYYknISQs0guwvfTTy/qMKYgTCParXHzdou4NC8ejiSpSM6/VbnAK
Y2ZrlKYatRRRqdU7Bh1WMj/b9nnk8aDw4uc9qY4K2pukDh0qgvgpGGABImd7Mn5x6LrAqEGbPbUt
VqkJ13ZqGt3/boIE9OZLqwp2fZXEEgrCxJbhCAgI89IqSx6kkIIzwHHHivvsI+t6OaAOG1unQx3K
4YyizLbPDFU5fQPFT6ThevtedsoRfzY/bdWefFQhWFfqVRiid2DmBTEOj4SipECaru10M1D7Hx40
YVawamf9fDHjS0qegGeocnB/rMH821GJqEbNvrQQbm4KR5V+7QPgibs3A9N87wvrOuUsDvGSr/wr
LSqTxqM5Gj4SUn70dHDA4k818jSTk2bfHz6HeG+NLD8w8V81rE3jp8ZTUatWQBvpd6X/Bu93IgZP
XiEZx8iTCD9SoLlccM2m35aYJ0uDkqyzQQnWSJdZTmrI7YWLN2bT73NUI7FAVQc6+KSQyjgomuJH
J6U4Ot/3W6T4JP8QPaLOI8e311mlTAGVXNGB