<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq6YnXvHFpjHB6DJFKhFBy+81YPxQewY6TPjIbgK9tbt61NOyT6clWmTb7i2obGIpsjFSH/k
STL4l1NUZlPFZ3bMg2zMImSdC1vExBYPUddtr4iNYYEHinPWKHSAHNswrnkcamu/ViwaBq5VCBqc
YJQlZFLLKzjHTat0LDfcfMUKT/uZmfeHevXAxiO70coPliw/0MWrYBjyv0cNzSitNS4W++o9sAeo
Y6Cr8wMa41cXllsJW10JXtU1i73UkAH43Oyw3ASJRT5A8qsaufIGbchEIKJdO0B4yT0W/MMGXKHn
BKB26G8mcPbFBlmR6zBvbLxW8LJLprIO4F2ski1uhRB/tyAp5dp+WdNCDI9+/0/0O0ZuxzxNkIL9
0N+nEuPgWT7mI1CtPRZ3GTwcdrP2LEhMJYZyOYjJ/e5ts+sbUucualqlKAcjbdJwTjz9u+Qbwjvs
gETDidCBID7Nmbc26d9wVQ7xkwtPKYcNLnL4M0M+AyJCdH/QRQtZflpWkKiVHKATz46jIb+jyB54
umBrts+IDThjemkxmQHhLRrc0Wv3I9vp9JMCkih2K1jv9f7GNDKDTKHqScG/6Y9m8CRHRcrDKegt
DjkXQ08xS5xJrEXdh4F/u0BKyK24+6JCLiLLEtI1vupCaoL7/wa+PfZnEKhdWzXrN3UuH6aa46nW
hQVy9bu1JkBs8v5R01Db6TtyCD47oVhH95nRb25A7MwMixb3T2OYVzWzg8fdHhmuzjCWtGqqOYB0
46f5Bufg/xcuWqyDjs66fmq+nnMtIl4btlgliAI9QDkQpDWPVqkp0T9cYKrQGXE63tvxNKAHcpSk
VPTIodkpU+ep8rxMS8tWr2HIyZ75ONXljz5fX4g6jrEoejv4Ngl1HXOdjuIEnsNgPTQLNsM9zu0F
0lbw9I3OtYwbT4+AJev7S41l91caFV9EbLAMGDFof/IWwfD+TgFYA6PS9ze0XW350cEfDtd4nByr
E8cbwrP8PZd//r8tXom/saDvmFlSLP7FVagvvkBEtWvcvfNhJ3wKBO/bRzc57sraRWx2uSlOSHEk
XiRPDJ3xJ2CxlH7nT6JEQHb72+57qf6OM2ZmQVhh/9yTEvoQ6QTRBbeFAsjM9Z7PVzhYcKAaVEV2
Uy3iHXVXUVkCVkC+k47ndhp+uwYobb+gfvakNyvBiDg+DF8bohqrHCjjFcXkq3aEDKY+zW7ko+hP
IYxb8PR4TBpkFXB5dMjZ62PY/GfG4Bl9OJJprY0RQJZCNCIXkFfjjSVjT8mYcqHPCU5bDL8wJl4U
tzjUbHyl8AW0tIpptQbUhFl5mF3W04V0Sd23fZerNZ9zYs6cHoyF2Ruwsp7CuAKnXlwieXdIVLXK
guamkEO2+OasK/otsxw0xfMBK3K0+yAPT6fyJROWfI20