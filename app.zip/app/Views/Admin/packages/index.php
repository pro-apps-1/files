<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrAZcxAvFs25H68EaU/ommrXiNHhbhuJBfQuYjrBEt46i4lZe/DU2154oa76yvq1oou0zv3D
seEeup5tY2Q/t7tZf0yBxDMWABALwSe21s6kJloCD0qPejTDSrbpED7zFN0mabx9TGos3rvUHxKe
DPAnzMP+031SrzLCnBa0/SiAQmZuEXs96E6YTs68mJ3tu2kxxPImkKIEZQ1IuU87m+DdW1xvdEK+
QAxLaIO1SYcU5NRCQz/l8mLgK36UDPM7Hj3of73U7N0fAkuXIPj47u5uMZPdLn9Fv5gte6AIJl4k
6hnWwPjnHREmssksL4vBQfG3ekVTkwyK0ZxIGcBRLDsLfp13LotQ3VN0vDGKUGLtUPCny/06JzdF
NRMDtnKZ3Mr1eCqv67jzgzGHXf++BCwp/umj0OI46OMNcrUr5REJClnOjPIljN1j3EzHbav6uZA9
KXyGNjicVEn8eR0ak0gPw4Bg0BD82Cij8MwwMTgh5OpPnQHKoSJZGKPJ+IqBpNG4nQMWKWzpDp6z
oJ0ADgiAzM7JcXS84uMpY6Exq9AH76iIDMAr31iFcV2AGWo8q0GqEKSzR7U6yknFu4rirXCiXqW1
6IIm6XMwZUplW2X15M6xgeo1zFa8bi/KAbJHaHUfDD7zsYPpm2VIvwKVOcLwykmV9NEtP2qUDROt
5EqIqK8i/AuKUTdK0gp8S7R2jAqAZiGRu9Pyx/D/yEgr1N8F1/fOZjcVuphfwg54Aksi0h438GS6
zbw/UKvPQWQgT3SZUm7Y23g1RN2aUItq/X1wS6hYOLTwRIO42eOiO8i/lk6NgHBQnTrGoN322fje
qg++O4gOuJuuPADV7pKLTOK/S3DQcxtUGCE+8BoItN1OKye5iJjNOitF+5iKyPE2eVFagBYq/M6x
Lb4BQUBBNE8BVjKiMszUX3ElPBW/VgksAgxNRGJl8vTGAkvg3xEvkseifkggdSHulUNnZI3mED/N
5KBimwAMnsVK4FzPeCM0mXRdy39MrxxjwmaizibSuhrCmv1udW6oMyGO3d0tatymvRAR65RqMZ8K
7Vif2+QiAJDHed12Z0rATZ47nel1+PfKnVU5suUDtQPndMAzqJ/Tf1qSH3OJMFDmcNTsIXUS4pvA
T1QFENDydzokTaaOIeEuYOwFwts2GX+nGBGXT5xvqNV+xL0k0f+1GOj4jArgdcGN/zoiR7ewxjof
q65ziD21dFYblVCs/RXN/tYX86YCmX5ttSrzlY6TCIj3JvurJAndcLEfOJjboZ+pZh4kPzI4kD8O
fdlXGG7NVayQD3/fTrabWeLT1MoZBF/QG6y+oIuuVqUW5dZE08DCGZ9AaYrXhjK39rvTCY2l/hVN
7K6JZZ58mdMVYhnmimeQ0z0tk9kMOUGEns+iu+NslkhVQvQUrHVfkEYzIHj8Wjl9BhPIe2UE