<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyR/fsyQsv5JNgBz+ZcDdfcv3iq405K618+u15GDPikjXd4a0JF8DkiRjKqRF/AAVI0bTtwW
HSFsLR3u8UdL1X/sWtZI6qeV8M8N7veS56+zwsAQYNHN50vEmDy5ueU6fTKudxBEvhE2E6cEixWF
mBwmAdTX95jpd+HnZK7w8d+0VOWlQeDgwEQ/sbca9Qxjt4na4ya/pyOHPasI7uWavbGgh5IX+H7q
uY5W2tPG+OjWT5YbkCFJWOQGsDNolaJGGXZwhubOxymazG/Nz8XCYKvD81jeYN5omeW3Jk87t/uu
3A93rgB8twCkGXA17CyvjBtAnN+z7shNIy4aH/0H8+XaKhzPr4KBf40MmlbaMmoVhmZ13rqaLjAq
BKY7oYlsKec3o8QL2jW/tBM6YriY2glPiMOw1JV4KOHZRIr0oAbwllVWP3vyKsiRYURuYrt9rwix
8UAfX3lS02xgVVTOSiH3zf/sI+UjyxCHVjVaL0fpf5uATgMTJXAJ+VyP4t2/Rk0dSl3xHmvg+4VU
A6mXu6sTTl9NW0tthhLe0Nn2hTe57tnI+TxUAtRvQNZUWRjCO60a9Xx+v7UuRgk3YYeeK1dl1YnI
aoU+7//aud4k9j1+VqBPtxUPZqlAxpbsfVfNrSMUUMBY2r//wqSRBL6eh2vKVSLdRR8ugDQC9BHk
jbSXI+N7jf10mKC3AqTfGuxIZ7hjDIH7rFebX0Ers/sSYsv4Jgb56hSM8ZZSGQSMH3il9nVwUsla
A7gKFp+DPPkFWcc8mZbBZFBw8axUKRZAm+Jek4v07PIAOZhNAxbvtfC3oi43d7wxoRSmhx4hk/Lv
x5lJlRlMxm+sAR2YNbimOjrqouSjMUr9H8kLomF96tvSs/Mq4h1HuB/Ku13XlDXNvF0XHNhCzhWO
CgZS2/pXoi5dkrXM5x8gMjEN0gtxu9500b2H4FaOT5UOTXA/xYr+hr+35gypQesRUaWveOV3ONzc
tOMzY3ZqP70bRurYGiNTZxwQKMGR3EdOi5lXye7bNmJ3gYZZzZvOAQMwaJx8lHF9QpXEMta6R1ow
lCcbBABNjMrUnC49eozKeMnoIjLDMQZT50puR02Fp1kDYccD8Av8vzcXRQnvfQQAXR7HrggoiluU
uF86XmhVXAbA86Cb4gspgGXNJgSFbrlebDfCWLTjDwmIop4bno12YkuIYYXVBOiOm6yYDj3MaHQP
PFK+u4TPsofBAIjZ0gNbqcc5w1TJoiXl23TjFjn/1yZoVvyXB3z3jJ3x/M+7fEJlyo0liXOmdPXd
f9EbI3T28g8HxiE300rVl0PUnjnPoDmlBuo5aQl3pSxwF/8jIsPbfIGIjdrnBfLr8CHWHvRVUv9G
ASV6dqgZmfTeHt/MiVqICiVlUBP2v5YWf3HYuLk3DdDeSIspzQ2njW==