<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPziaW4qwkNXYm+KLRgLvmc29brZPTVnokw+u465YnCiWUPIQ8Nu/3OSiQkrlqojYWkvpJYhB
hMhArCD8nWcOaXX1p2qBq0fMo2WkwULGbPoH0G0dZ0Ow3oNVKuylfBLBhzkfPWTCvK27jPI+VNwb
7CvT8ECh1/HWdYeKI+4tsf7zFWD3R+NA/zY2YPH0bkxXJSOHOMVB2xI+w8tYXHAg/OxHXrDQi/Dw
uGj3G4/UowDsAxdeTqSKQdnwObg8kbzi+d9BtLI+K6eOota74/8WrF47JhPdN7c0ZvuEOZrdhw4A
VsKNNHziymqhgri7/iYa4x/OOxtV/SIblxVII2bAWRQlXfDfXbGF+PYKeyML8XbhPXA8kCyMzO4V
bwLYRsmWINivE9v67wtfg44/7oS6sMwHiGMAudJWTy+LyzriZWcw9fTVHqEHOiWPYdKD9juGX/04
bEfOb+9oc6eLil1ioTil8GeUcqC5hCjxv/v/R+d1S7CMFPyqoLn+OE9bX6MSuB54svgunFK1Xn82
NK/ResoAJGK3QyGcbdlTLtp61CKK4HLI4RXLnZ9VlTY4KACtxjCHaAmATaHgYU9pca5nZGG8NK/X
Hp/YUNSw++JdSjuGZhIKrzpBNrd7XwXRgDPv2mDM2sOkbd+uDpR/RCoAN7YN9XBPBvqFhQplMS5x
EGxuk2OwBxflIUL7D2VgUAMhN+49nGgtkiGN+5zqsLPWchiFy8hpqS5AfgM3MBvcCZxJRLiexWJ1
2J2MmA3FLdwqy7VpwEJXQfS7R1T/h0uJAu5CfhTE1WOWPaZcTh4ocjAsBKA2/Uri1tLcoDRdn0BQ
Px81yDQ6lS3JsAu9S6TbRYvUk2+o4z6L24PhBb/wnaQPtD+cAQjLq8FY2XnNPC7bItLYrkTjjANq
RtSbb/gfg3Dx3t2CVeFcbvY/STbDsY2d+Ftty6ZRn5T5q0fWl/39SeUqpS9Em6sro/AuDqJ+OefZ
gVB3cvvrrpUU6VHwg8S+UTnATeYbkIeIESotV5aaL9YVB/tdahFbjgalVyYm6IJhHARQ7rrtOoav
bYo6golD2Sy3fFf4BQhG5NJHCebaPdQPTfeD5ODUEoSoU97YDMDe9MMGDWDk+vaHLy0rXzzKqhgJ
vQimTWeWUyv6uxDxX+hiOUIU9r01wWqpL6140+34E5xb8rx+dsK3RBvw7KAZW/1jidQ/KIhAe520
+b6fJk49Q3C5PrGnZYT+KhtwMncmzLPogyOI8mXrM/5m9LZDA/9EveAR/aTWPWK9Ci8YNi11Ujcn
+O2fx6wjhWiLPlb9yv2R2UGH0ToxzOpVnMCucVnA2aTrC+wJtjGe7m4wFLA2lXQwpEwNNH/0tehk
nZcz4Gor8fEPrc8W+aWDGp0zVcZ8DWwuEPCoLp0ciMEALpyqnIb8nycrlSHjVM6fTg6wfG==