<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+pJwOd+ZDAkXn9ygajcg5Hf4fJv2bjdKyiWtD51PexkzxNt2nvqhROBTAwfsD9nLdjmwJM2
eI6FnGo7bwUK1a7Ib95SRWNHRtapxH+KY+HmJKJ3Y5dy4SO/n6j0KVuPwo8k7NJ/5Ws5KiNu2D94
0PTJG3rUkF0BsvKFSg1UQwqf+IMR5W46il8v/FLqPUsPfUlaPpGepeaMMLGgKv77jx6YwwzQpVj3
Tock/S1wXyfG5pkE14TR2aEfzH6YQGFyicPmL7OKAnTu21puFx0CpmxcZikWPpPSyuabkM6sKHZy
uN1S16go3eFR1yJ+QmY2qQJ//4UYwBnCHSC7CUZSBsHSq3vyO9qCU/VMSzZrTOzevWD7vK8mM7Zi
S2ACx6+yrTtm89Co2fsIAgA2CJ5vnPBbnxQr1tDCkEdTAyW3i2uHDmeLAmdQwE5HxZfQDGM6X8b2
8E/oKqzqJsyLV24zX0cpCVo1Ht2x7kCJlATHlj3pU3B7WjyPSpb5VT2kQhUE0qf9B7WS0wSiQAxy
aTb1VuLaq4wFfl6jVQlNjEGhADF40H/2ijj57LVTeZ8kpIR+wllbiDGS7kWnP+XCWgVNBtsdvMGt
H5T96AfsLx9pUM5zb9tlLF/mdZhLEBk4NZxk40ZJTskSREARd+mU/+nqmc2ig30LnxBVyL7ZQSp+
KePmx9EszGfurGukngCFrDq4vPP+MhtKQPhXJrKhW/DRmjPEfApQgssx3LdPaOJR1v84JbrigHaZ
Fbo+8gZI9NYysi/H6lfQpQUZkiT8916Gc5vP81QN/cGVVKoaEJ/R7ESxLgBSxNQic33Eew9c7r8H
/5OvgEiCV0BMxNaDG3aZ6Eg6rRkftaAKwr66T55p+UleO0Fg2KMuYHL7RAm1c2W+egUbfDBHf9Z5
XbbJwb/Xy43C0cpqXDERemFtRyzyzdbJVudC1VvqdB1qRyk+sFvwRgq3joRe0pfT/x/dl/5FrHMX
9lpmrQ44T72fc0GOJjGL2Ws8a6Qn1R+dLD/442Mjkak61d6tX7W/CVyr+ctdslBfqCPFwGQJ30Va
UvxeYWrgD1N3Fz566ysaTw9Krjg8NLokLz2alxkbiSYVT2MqnRfd+RW3wkeaw512b64wr9Rrw7Qd
jfxEQPJbQEREJCGrwNX7yj5izp5xA1PXfbN6a5DZBBe1h6Fo7L5es/knaIw6blaknAdrEgWKUS20
j3DIYPb5VeQjqszV0wJ1oVTNHm2zkm28TGqSoZBlVaQE2l0lhxDwUdOrmkum1iM5SUsh8Eyl+a4c
JArWrKI1i2+JyaKLaxPlLOxttML9NSqrB3ryNKUkg5IEXu/hNmnQ5XXQhjIyLoX0eqZdWdUDoS9R
/gCRpoWmBdwpCV8spyDUTpuPcwGIbU8eS/rVu+4Gj1sf1Rq=