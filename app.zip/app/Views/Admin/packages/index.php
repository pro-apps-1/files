<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxputpa6LIG+tpbA6YAfFrFlhdReRgANtgou57NHPQbiP55osuh6ad3TARWmajWGof/k0WAD
5qORGVlX7xHpk8L3bNLAStzNeMiKgWAEWgYLZBGR+HUfAH3bdFm2sQqByjsbHogfnLlRjZWtNAoz
PGTQGB8C0DB4zaWbn0pImjnhqOYo63aKjismeDHg4KERQ4PxYWBH64w3XmFgIiKpoP9pJ+jYDmpB
C3e4opeWpZyxEUUH1EnI2vosryab7bmb8Dsnnar0bIC/IiIrHvjcnscyWoPa6XCWKXk4h7iol5oO
hxbp/vUmoChQrla1R8IjsfSiZGDoQrWpIQTDAF3xW8599jIiYQN632Ho7tLusqlceaycafb0rq4h
n1ZpP2gtltnntoAtT7niefZAyIghT4GAgdJYpq8cKP8nS6pad/fKRCnbCOQ0ea1DS+w8motwfpJL
9l3WB/di1lYCqTNbEvV7tEUm948Rr5MZWFllzKjm7edYNK5Z+bIIAZ36H0Yrj7rTV+gE2VQeUllP
82ghpTOzIz1HNJ7O6aABYeSe3QhTIy5CavFVzGjWZZ0Q8h3LHNLYN4vMSHt5HgLrt2Hu8CeHq0Q9
xr9QnLKAj86gFe2c1aZHSSFJwAiNIROA38PyxknSAsd/MuJ+SWj/StJLWoF+oJJ/8800D5OxPmPD
yhNunv/9xQa4ELei0yVyCe46raIQajptqMtY1GxYCejdG/vu50oEhWi5W4sk0c6ilDYTxOLAmJ/1
xEIT94k8kJ9b8/8ZXJjADDGNahaTfo8u2FCBb1Xf80iAMfJBGiXNGW3NeV+Hxy9QJUKNq9IO4BV7
eWF/nQE2dHcrFrxdef0G7IIGJNlOGqJx7csyKZO1qW0GevLgCfQiR84p8FeuJCdLIbDle8Smi12E
dpw7t+PHVn9BywZqR6xllUO9iRsvgPpzQU3E2WB9TIYpk3tcMNGlqFpppYBFQjPY0DcMc48pGrcJ
NxqdBF+UALzfe2pUsfhXSYxH9Kq+SK3E+xEeZrsXHAlgpIUJJfzOuJxZijlp6tIrdnc+e4ZjYw+C
4KEWRq8f6mgsaXEIsTot/Ks9W1vnlaA1iQah6r9VqOKhs64Yjh1lj8DvagEl/FjlrV6N0kmMcMY+
tT7p/PlcsHWECqScAZGRRZFP9SZwbRxjhKEEvU7PuQhYZ9rZM49kVzakOgu5lPWC06CpErH7MTAv
W/gf+gjzGwbvKIOOpxGeatwhmlhlzcneLpROMyfnFbLpvM5lMpA+jnpJ7niHTRSYSw2HeW8PHOnt
Z39pmqLY/f3Dzay2XAUXPuJgi3TwVm/9h9Tbqpvi4y8191CA5DVau5NThz06F/ydkF2jwPHIC01f
vaPfKXSPnuFYyEGEIe4201NSfsishpRkB4dPksJXyWqhGK2vDzweKQ8xvG==