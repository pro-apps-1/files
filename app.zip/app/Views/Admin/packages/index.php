<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmvFWA+L0tc0O8uLZAuAtxulV0unBQRAITmTWVtrGhdfr0W3lcdquTUO4JCfNcKd4UPAwS0i
kPc4ckFFJ9rP2Ag8LOmQrrJja2UwxOLjBw1lHDupThfLhuJiSah5xh7CRYqVHwPn5WDB5f/y6Us3
g36Np/ZX5uMFrpLcD5PXktJ6M4UW6vbHL3yUONgTgPXEM3eCntg/sYdxS13feuHSj1WnUR1FWI8+
DnpdbA/1GqAEW/42qHOgVeTJ5oZ8By+l65c1pKEGl3ILk7yQmJhQo+ryPEpNPJedyIbBdupFXG2A
jhcu7l+djvazYXfYQgs0Cy0nNn42UiWX/zDBgHJPmOth0BTS7eyaQ117wrbnA+IPlc8oeEb+vxQT
yI+T0JBkEQnaVSGeA/ZWVWqGooENYTijCN4Le3KopMBB1lZwZRFRa+2Hqf01gGKA3jWXjPrXmg49
uIP0ERzpIHhpeLN4Szv2kwT01Ubv8aVuf8B8MD0aecH9w3QZQl2f1X/5RlE+Fdb+Y49Dw/emkfdC
cSN2IaOqsNRhaUNkEOxvdjzELzf/tCZ+HlhRTrNrePPGb5gG8uoCrdzXwyoTINM1p14mfQNFGVZZ
bwPE4sI0Gr59GeJmCho5eq62flWnc5Iw64GoBRQ5tWqF/wStjh3Tq1BXd4mQV9XUftoJ1kN0LC5h
oat4GTbe8kJI38SBINR3rtpdHZbBnrY7LpsT/6WCWMNTNbTfi/d1XoD07BkOiw+rVCM4PKoPl9E5
two1quI5mVsTSs6kxX5eq4kp1kxsTee0gNbEffUTAYv4atbd/bmGHf2MFlfMgRIuSOw5DhLzPcOu
0sBkuldnhCHoNPVAL3tbCVUMM+mE92ExN0EVzKxyMY0OYF5njq5SffmVg3VfDh07E2g+2Yr/+uIw
+xGv0znlPxMHyO4ajPeiRHatfwdVagXHKDuOzxKsJykW4kAc0Eqm+/i4LH2Ek43MnTkYf3dznQjL
IRPrY2W3KKgiY0mp+nNm2HoNq9cTEYxMSV5rAp4bip9MWKM/tKEWQEHPX2E0zJO6NebpTPZXWLcD
WxpgPmLiWaNJ9SuXfcZm5yyTOQhQTrAy0lgB2PolTWccBMS9IOrLSeOBFozrirsn6NCNQqkb5xId
Iamf/otPOPTnT+7LyfIladNl0OhM5hJwMv/STFmmH1z6cyi6E2uTTP0G9+QF6keWOUw0vZlK31VM
airj6AN5Jp7hNhJuSLjhG0LDnL829MrLrW7gYsyXIeViBEG3Yg4U5EA7Usmgpa/ctXIIQUWC/B/b
T/ojsFq1vO+Z+jUm7IXcZ1Lzpzsp9TRZyHTS/sseWOs1ejaJ6Ym814HdeyDlRyYhZ5TBSim4rpwx
petvMKPWMoDrDXV4GeYMEigk3CrB95Hf2gqMcbIs