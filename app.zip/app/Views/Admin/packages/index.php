<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqyrgZ4YhYu6E/G/4dHuWJ9lHKrVWSrPAlDZtBSF/9Vtouovt7o11HmPwGA6no6VyeaqAlOb
W6I8eZzANfvjuSwixMXQhfFjnR/j3G3FyLwbc3kcdxcLi7MEKcQrgOLJkKjNOzIHR9pe8WCqh9uv
XSGMEavEgTDYhc6dXkl9crJoQDiLHni1vv7N9IkEBxbWStgLhpMdFX+wzacQ14L/qpc9C3evgd0x
hMOpwlOMQ7Ch2tCmhJsjrNUY+ifssJ2EjCBOABKuzappfhx/q50CX8kf8cNMQ3IxsRC7KioWtlsk
vM8t2zJKWpRw4aXowh+FQv5P+1/IQ8bKDzO4p4H50UaGxxSTt1XTESRWszvaGD3J+nfCteLNxwiA
vAL93QjSvV3KIrOP/pgmlFmz6opL57xH4s0FFf2DGCR0s3rxSou0Hd9sG5/SZ43jIGIYsu4PMiL+
BqmgxDVzXWBMa9Lm9KXuyjKztJFxxlDYy5aX+ti1vVVBI/xmONE/ya1GCOmvfjK3Ad95CstX5ElR
ag2WfwQxZBKsJ2fsP+shDg9CSJeJblnOALJPuiZsGytp3g9L6w/wIdQe5Vm8BOk+H2hp9tflz7gv
KYKpnM7tkk7tAiIC8/T5pqcn1nlFg+IG+tZLcLnVG2Y6qt52/pPhGwlZaqZ0NAUMjQ8s8/scVwqA
6wY3b8kYU9qFPFKE9O36WfJOCpzCeu4XdfuFmkmrXxPYBi7SqeaLiiPcmTgbpfqvFZrT1lI20GVk
p4ziE0XaEoPWn1HFd/2R+YpnE9QkX5V5RKIWq+rY5zciW/jXEsDUExUyLOyNVwPcH4LHdqdTvbj0
TJR53FGz94NaFyO9j2C1V5DsXyhe3OwR98nZcarjL2SE40Fssz5GCu+1FRXYrzSxISY0/E7qMRYS
bIU8o+FHyv3o2eiepIadBkcAFLyxduSYC0T+A0lHsUJAQThfpsPb02266+sqfUo6nexVSq+F2aG8
nvx/kUDfWY//oSFnrxFxHbXzLOlr83dcLzRN3LB/tipaD9KiJJafYuGmc963HmLOYgmFjAa5GeHQ
rgq4OH8kRPRkP0NVv6grK89+C2/+BmukMJJn9OLVR3FzTcxHZQMquvbTaJzrKEGSjoG7mcV4uIJq
HV+Ggk3i5f5e54tW71LoMLndc5AD90GUIAcj/vWZIAJdLprC3kM1mcRFBsJ+XJAQvypPEF50L2sx
kvekBCzooUAmjorjgsbs+mAQGk1jd4QDiLEu48DHhAqtMHD9PRxOXQnE/Ur0eVVOJQ0jCBdihTd+
hmnjfsy4KuJzPG6sqyyJtRKGa/cCtyY+zy0jxlJ8a/Hyyt4WFoOSpQKCZH3iRuYCInKXqQA6Su8O
K//8EGCJJFOFJAm7t5mSMczufQcYcX/m