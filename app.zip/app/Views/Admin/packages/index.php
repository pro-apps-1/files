<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsOepYP8fJ895UbR1H0iAXYShC6qdZb3hvoudUS/yb22P7fNaucRyH6ksbm2NfPjL2PKe3EY
4b9EUh3CIPt0ZAUjZMa/iVvZlApArScQuZOO8tWNtis6b/M63+/NFxdG7GFt/IO3vUsksWMbnbrY
stQtM5tGo4R+O7U4zZytota+aqhh3wwrnFGpLaKSpb3OZCg7HT356oXlQcXXUU5ukmfFTKBp8PQc
IySkl4uwRTqZcFs86K+VmR44sI8Cppe8p0HgyLvyD5SgexbHR420sM8EOlLcIP2thEbc38kVyUs3
+3jjFcCvWH14DObSfJUQ9OScGMEUPlTfSAsO+3DNSNT+B1d1ioX6hBZMAy6XnAbeR5CkYcyCwp7L
5LWSkDrUElgdZHG0mCzuv8rX1NY9pPQQIWVLphOYqcEG4MYYE/gII/cn8HcauycU6ShLStpnkckr
n7oHyLcPNlT5p2MRBRx8JvHSqGEDb8wpfW+oUV8EDe/5c9nEfI602AObnBKJSeUTuCBf0kDsfG3j
hnGE826z2dsCPwMUUHZ/Orda2LcoMGFLODhCZhoxNI7xQLAG8VcP9r9sjJL3bw4IjPYDs6wYunuf
BxWosFzr2ybelkpazU+QUDLHbFYtlAwM7g/PKsh38h50O5HW7jQHxr/r6PKGzWH4QdXTDVcN547g
dE14SwB3O6HjgV+tgxXbNwAhNPqpyhEFmDvwRQPmsAmcLEsyQIgDesxTJHEOVbjf3RSqlwgyur8t
2wn074zhXOi1WspnMRyGmn3qb9qbdcemCDNl76MiJ9sJYBaspEPb6z0hSNjYqnjmwNRHrOA+jK5G
QT14xa+K+PaSXajW3MKnzaHqsacEMtcOx0seCSqdZXwEXgkq8C5P9Gvs6VxfrHLgbudjlfDrOBhb
e58vahuGG+IS2xOxJmmmEDiz1f+kmkk+2LGIGBkANAIwL3VPZjWWzP2nCJ6jI+Llsx62x6LK2aKJ
xnBAI+XEjyh+DVyG75DX0PQbvGaugSRuqG2uHcMEDcJw1nQHTjZk6zGbUSNEWkbv9kdf2NZLJRDC
N9+kgPDAspHg5WCjvY+s8eb9m459i6QHi9tWNdpgDSVmiGRx4a81ycgNPFPqQ9vgTd8Z5SMWDu4P
+sOnufMltfTj4ZCP1bTSBp2AHKuSFjZ9/JXIWVTx1XCc8AFkqn/VWQJL3K88wDi9W1HXs9I0yOKG
JkuzZWk9GYj6+Od6O7JhrVY5iF3p0sgW47+K31U5jnA04Oi/OXwHSG5x+91QLoFKLjtr8olrJZib
6miHNkPqTiX6LxV8QpPkvsi5RUNpECJQFWEtdrugI9K/A0iMtn0H9/M+fcQv12GiOZh30Nvhuk4H
WZioyq0QQwUdK3xjIv4zh5tWd6nTjwsbZq4i