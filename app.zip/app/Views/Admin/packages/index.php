<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqymYGgFh74jLl4SAOCwibQHvZOoJ+OjbPgu6eyt3FTY7j6sVZEKuZCFVAN2Hhprf9WULwRa
pvY61osWOuCSsS8DgF7faJ2imxNDD0LxJzYWVfXx5qUnmhJzHsdO4R7qvQUptnS95prnaSpkwZxb
qBkaOP3UmaDXEV+KxOBX36F9AfU++U1gfgznowNS4hjFGbX8TEGOrnk4eQ+xk+Wxlp834Yx4beJ/
p1aLkFPb1Z4cnFGUv5Q2xzsCfaZjamp9eWgL4No6JafnWqg7SusbEtg054DhxURJcyfDCt1zs4NY
h+SIDkbAz9omGhCSdM/kUsw4A0wqbALWb0ZoGMfwq4HpOEUSJyPAhypvs0YI/AbRSgHfjOWT5N2G
af9k2Z1miSktu1O6udkh5jxtsxTTUkER8kPVPCUlOrPS3qdGyo5rvZ7aL/7ITuMFmpU6xRUAnn+N
yz8m+UwwhVeHDpBdu7aq1mdxVKsrWpMl3qkdD3FfiHbmyt/eX1RMUCwg8HCvxmZwmMAYQTJ8MqUb
zbJlQ3eJjF0Sxp/Aves9ByLwiGa9OtkjS4K4qnDoKkeLbAo9IlcOn4r86lAF6sU1shPkUrLDj3Cd
JA3gpwOo6hwhJ3AgvnIDzZbx891GgnlXg3fG5BA9KG2fooYqj5l/pcrwAqZNQaVJERp1d+TpQp4g
FYHF5QS/i0MdLzDq0F81ohWEmaloDgvchLtsT6BGTPdTQ9Cemv28MYvNpXTFMK/hpjIcRPt+RqIA
AG9ya5X/o0pcKuW9RqmbEjNdL4tB+iggzs4x8OXaJdYxBhN4suRKNwrZFu+GJ0XJ22t3uyqcsJl/
s+hE7X8+v6AcPbeM353mh6fSzLPr7hdNgkRm2AKdbtK9hoF8lSKYyPh6uX/HRmtzWQM8bHdThUPa
JqQyrn/WsOhwuDXotnujInMqzgX6GlUoZB1e6bt/IcnnBTOLaeuTyr4E/vTeimakgPbr+FMS8FGX
effq0pZhRcpK7h841T9Olsz1OA+Ipx1+NqlfjVqeKhpxA8K1AxVDJ+5LIA2cn7GJt8Ga+6Ss6mqG
HrzNr9M1UI0FhAs6370dd62wekw4seNut47wR/NJWCMQmP8/c5eiDEtYbmzGfPSZZusoymu8YN9a
vmsTny6z87ZXLTsevzOCG7nAQgQT8jAbbbHwEoHAejQrzfBoPI4f0MJKVAAgw0JZUeWeIC3mtM4m
gXohbi8kGu0so1wssIfrJXdWdcutJEH40MR86BxSTaW8poSi/QDQnLz9wqKHmfWWVJy+tr67YykB
fPZjxlwRltBkG3x3v1uDfe1irOtxVSDkRaakwXdExXfYZyEcWgle3oCzEpahVIpHuKKqSzcMIJVM
xu0IE9Lcb3QBJVmg6bXKuFE9NZvNV2mQPRVRSqRS2YqTOhp+CfC0IrteLjw2O05JipAfVIq=