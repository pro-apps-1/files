<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv5opOuLxpMXuBDOhLJdQ2tsRornezuz7+fkk5HRoBxz1AzBRN1Ok4bJxgwT1tLYKxHFVkpK
k3UQmLDNyHT5XtNUJSz3G4LvLBhK3rt/skrnWTXadGAJtgNz7XLOCdKQI1d5jahnyGQpGp9rlNaf
Xkd7TQlsR3z3k9nKycPuJ8IHgdoUQDd/e1kKIGYKGKGeQVARGMBc374+aQF5KoStvA+lw3z7AiAs
341CFipgqhLpeATLIzDavXIH9BofPZ5bvQn6yjn2WgoPKlaAU/XlrUmuabPlRD3cknyNz7cXGFzR
Y5CzNJT3AYUdoc8LFriDyE1Dneg897h4ykiAGm7KPDsqNpaNqy/Z7BztKkT0a8zzsQhGKmarZDqX
qnQddOe6nuIhFmJZwwCbuV1yn8rZPRN50BbHPVGcgfzI4VIhQG1bA3Y2TLhHvt8Sn625ew7Y3Ots
vAQ+M69BvXeeiIk8dvaAYlHT3LdDNV6FDlN67QaIbQA0L/n780ySUGWETEfAz0wKJfYult8UvLwG
UqyaD2PmUoIn976fPz4//huv72EpFmm/yG6RL1Kj8qSRMoKi16J46TvcKQdKhHCwi8s64gm2yBuX
jqX5nn44GHoxdhqsm4SQglA15T0sopc1aHA5yaB6Z0ZB8A1/e90kjNTC8LYlJzjfHrE+VvkWdri8
HNuLZ92R4II1X6y6qHNnIXA4lgamIzUbG5rd9IugA5d4s3ssLCdhq9V+91t1Nz1h97O8Y6Z2TXT5
N0oibXh7Wn9VYSVUPHdHVyQlltRU9+oL0i1Eq6PLYI8eEdktrmc+NCUw0UTZmUbbx8xmtAbg1jT9
OQsCLVSvX2Qcm28O3nNQZzwqR31VZde4XIsVZKPUFwFBDQo11pCdrrX1GEm3hYq3zkBqEU7Ykmn7
wvOWL3sHNfU5wlM0w1dVRGOGONQ1JMudPRDs0aUk+oHowHlz0O1NIXPIXRaIR0HDlHUtUWS2x16J
OkbIwH9zPqGlqs7/x8Tv1GAWJLq/jUeTVAq76NBvauKUJXW8aBJNPkAnvLY3WvwPHWuhgEm5h4K+
iGtw53hyqNqhtDMW2Nmr7bm/KvOjA/mLnM8CK09Ct+9Ek+CvJunGZc3KsqIzlARxCfOHBfcQaMcW
iEKkkV1j9CDzOcGiN5W2oYNJMBDa3nwRk1UIIfvyhhw4DtexlWzm1TUfcnFBQKYiKof1sTvbaiUj
DyqRyS/HH8WFoIWsgMPjvGOhQwB5CxRwDBW2zZ8xqh079zbHgvM+aitAp9z5otLBG4mxu+NFZVnv
nE68gUtdx1mvXHZreXkXzROY4ovYn8eBGn5x3GnkCZ/suN8BynX+GoQMPmqOu5Egi/ovZmOf1j0D
bQxAXD/SB8KnHP6A5y2XouS6fI46JOC5jaf/VKu=