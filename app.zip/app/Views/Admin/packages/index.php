<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoZmMNYwRA9/Gp7CMreaUSsqRkY/BUX8vfcuueCGnh3TDxE67x1AHjlDU9qJjZeFZ//ySd7C
q0dsKSRe38+1dclQ0or9Hx9DX8xeeyfoosELUz9ABcOnKzIOuCLEjIAR0Zt+O41z17q5u1qmUxFp
1ofNwoV5Ksvyj7i/zi7K8cTqqA4LkHEBZ/mX2MKBG4cabLYbvPZgqX7x5wxJ17sW+GT6y3h2VvCt
BMPqMfk77fNXLuTohu+h2lMjFtecYU+LzlsY8Rv5Gtg/oOGMaUIvJ7aVDWPgE//vSO8jNtT/2i49
xSL8t0CryZVAANMm5I/2g8MD/oPHwi/wGMGI7xlX33inX0JXsKazackb3FcA7cgpCcqtRkb5RiS1
yxCEHujbbDhfzGeed6kDaYQj+P8KB0sPgb/biWkH33H55QI7eDqfHqNmGeTKIvWAaLc+S2EDLWYc
t6QdJ4pFAfU3CdoO9aPTZsNpwwXCEhaa//bBB4XRJQChLyzn2YFyZcZNl0Cp6oQuKUgC8EBJWhRf
AF1Z2GWkR4z4A8N7DH6sTv6Ya9seVHHzBMTWCVAheAjAyhl8A9B5fG3RCQX+8m7Dfz1j1dU80Je4
nDH1N9eT01tbMhbT0yydC42GOq99BSIkCxn0UhcY/h+PyDc6moj5ouLQj5hTLHq2v5dLxqRnljEj
3sWpYjH8R+nQh4GLJ81zoKlAQ7Lg/Us0Xubkg40kW3ChJgv85AxYipFcYoRPxOvZzSF1YmWUAcAd
jtzeggaOwTiIxdM7M+p1DMX+c+Mo0aRRr+iYUtC+SBAelYRUC7/tBfwl9OuwWj7iHDuWYOZwEJvd
sK/C75RIW6Lpya0Yctx/a9t0pTsgcj6QMHv6uUAJBIrl6Xfxyup3B+0QrZZK8Wjy+Pi0hP9lGl5L
flkekSl/vdbTktSWL8YwTg9CPYee+Km+4lZ9kT5dnPcNyf3VXmehTp8A/i1lNcdJ2kA5revZ33PT
KI9JGoTBShJKDC3u1dpTBqMjK22GieJT7hFLHzjiFxZkDKtvAFGTf77tlKWAuhZgO9Fz3LGlWEVI
hAHex+CZ0cK8JK1LUM62liCnRdnJe4Bba7Ns5kEF3Y+vo52D7dx9HWModYX/Xp1gtc0ckJgaFxhn
ScsAHGVZPl2Kkv9EmL3O+PAhxQrg6xn13G/QkhAS4d0gJqzbFI+8e22awDQ+nqu+jO0G08Fgls1/
6kwdxm2NWGkhPRrzcSwJc1aw7RgM/+5yMtiCjnbni4YyjkZA19jY3/POiZvdCdir5OPp8jT4vkCl
zvbNm8eZ+ZrnZ2kRJkS91aBCGjUpvHgtDmmLBLCJQfgwMTh7dEJrrf8LLBJra0LN9eSs5Te43opV
GRM5gX2wJRDg9uuK3QiWB+GOp5rxe4BETcjN/y2QhVgJsY4=