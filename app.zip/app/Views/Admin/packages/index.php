<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPta9g6r0sX127SWzJln4d9EzoPjGgHJb8U6HIyNXpLQbVIktPd1Gy/+Ju9nxiEqCOTGqYp2A
Udw6AnIS1qnyprexVJXO4/DiSv9Kx3Tkyp22v4Jmvltl63q6AnbLbOlpuZP+FqIe5V8IosUFvFxP
M16/I0vPqgWmp0Hpcswb3bqFJXfjBN49JmozTe9f//sVDnyP7aW/oZqJc+/RuRKxEf57jXcR0zFU
AHpygBGcTRTsBYqlm7me43FnIZamrpchh7xN7oeADpHZv1ITmSJY4lsWpyFlOpqROTmhvlxXBsFc
KfYNC+Y+21WpSAPPXxxJt6e7t4sRjjYEyOW2X+UC2EvyD12QTxoJkmOA16JRttpmKVA95UgNNrr9
wmsWlOTaXwN4uTRRt0q83m2le1xH4wUoiL58j0uB7jngStTFCJb6xvgh66RMZDZASDAkJ9fpXBLo
9xU+vayWQ+vo87SitIRjUD64d4G/paAJf1rsb8g8nKXl1xJ4TnRa/09Qzfi7qiW5+ayeLmvXM+l1
mVgYEXN+9qpv/xL+pchB/bmAR7aEMZM9HVvq0GoYlJxe1DrFDJaPbC7hHMVH2TdwEQ1oCKr+0co3
9YED1LAjmDNTau8O4UyfOhJlBNh7Ksn9Sy4k42x7c3fR1E2u1+jNmZhxDSyOIEZ5JjCnpFomSf5r
AgxtfFIXmlK0I1Jmgs4heZ4hUrLtmwy6p42K+6V/cBEnrqc+1mG/mLc9O2QF4tMMKjDx18S2mis7
TLRlQebDzsJE4cYbgCjOuC8M8HAVf/H4CFs3PMJ0BAF/1I103CEVgD7Dgz+8E22YUHdvW6WuYxej
wlrB06rH4iTufd7nPncZxZE2NO9quwl4O0K5SKw2+qkKJrjNn9pi1J9OIJklyF49KS3rKQ5jiHia
LSCkRE9gb+1SEwjpQZ0i1wv2k+PPmrz9huURMA+6TjnyebUyfGil6U+7FrTqBQifzieGtTpJ7AS+
FWTc71ToTDAcZBe8GG4MVpt0Pb622+YixwWNnJAJ2ZKDNSVlc1lIUzZ6toYG81HWDOHiq2jiecUZ
7YWCa9EAa/7lSSuwA5P060XixzmBdqCCLqdgVP58yWeOd6+hcEf5h5Hy1yyP4LJtbpTqZPLXd7xq
6snTu7qWZkwGoFAeKk150a9W+EWO4AGKrOgE0qeh57QmNTxJupQe+FghhQcdVANNJEGN0hKAC8n6
JsaAm6DaZCWuMHojdvtlPkDtUX8ESKWtS6ro3xcnG31mltDZVFOMst1dovCsygHFFc6Kfcft0ZJe
lPYfom0RuSu9UXehZpfPBcGOAPDEcTiaKmiedXX/Zne3yhRrfkix7ydYrdOew7ZhhjfmA48dc2X4
wxXsFr7ZQSpJbltuqVIIQraQeU6wvBXRynBmWs0JpEQZMu+kq9HoyW==