<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvlQUIpCTq84YHli3/PZPeRg1wsw7En7M+0COJZr2mpipnVgdhVBdAjoPr46LdKOu8x4XpIA
Zoe4TPZC8qWDD8B6PNl0zLzlyMyQC7Id00hdqUEoiYBwX9jl6aMk70oJSSj1/NeiJ4jIk9StgAMG
29FECLs9f96aZ7yJqIFL7Q4eivpHXQQWb4QVkBRXVSp8cBzt2auxcpEA5BoXRXc6gBJikoFropcb
3WVaR9dp1UjBbYhX9DWxhat2ZqXOYSauPgY51NBhZmjDvg/bOO6oox0E1swuPnbeiqlZExxmGVlq
7qrL4yv0gg7I21fJ0jBwExyAdE1pKEETPE7NnSRKDUYZL2PV5rsZ2T5nmfdGzRmudg24mlZUx0dz
krXQ3vjYT4qItqr/04IOhzPOSp+japjNGHWzKNRVYrIXYhOg2tXlc514vE5yzdJL9b57UHkyObrM
GuUC3MLBpzNL0t8fYU4rN+vbec+iFWrCuR4Wxm8X/zDk4xxtEICWCPJaWFf8HKg1+LoV9uszlY9U
hc0J7klBSPdUUtbShbVVZ06HTL1IrkBvxIWhAmRJLNBofloaQQfO29CEOGvrAnUlvXLNKpHEIMOp
nu7WTo7JuDkmCQmJWpMWroY+ZPeBzLD5IbNjeRYMWR7SvFHwtnS6q8/OIT8R++pVLvLKk/fuwCQJ
MDtJzu0Wav+l1Mv+7MwMtd2+w/9JkArD7zke3+djhsKxYMVUALK0MfzRQj7aoH70lPgq9l2vvWb+
o/VMFSpYgHQ8RzrXbnZprdOv61wPkk1//zWNRnTOuAbMYeeWO9OgRkmSWOUPfloydP9jA15+SIaR
Qap6b6e0TeurNLt9gMsAgPbvNpEhNJv5TOLhK6MMXN1LM2b76Xog3uvCJtwOhxkK1NP6YvUDRJKz
FHPcXyY/C3rrrDNCML4okKTOu3g6g4uk3iotkOi9rDeAAFJYh44wS8ofj/Gr/sAF3f0b9uNnhACA
VnHiNxOwkGfQ1EJjZadJw1QonKyFnHHVjujh3GXJucM8dJJd5tbYZxDXIvKUptSUJalpy6psfPnR
lyohPywpZdHpScDJz1KVPrE4ttFhA9ngHP6j8ehZ91mDhMxQdyKm4NF5M3a0ZJcmo3FrsPrCkU0s
4rKDV2prHY4EwR9/PiMSYDHo4eE88WFHO6NOgmFgwCCoTZJ4tScFSfmGZfnRQW+EslFGZ8Hi7bZw
giHBy2oLfE4epupQL85NXN9ScXuYe78dQsDVyaGvEPlU5ZtCoiFq5mFG71BSKoPpIsNL+RzvjecB
UIkHMdxz1Yrs0H0axeALeg+fkOudkqe4l2nxwS1JoY7sEAMipVoNuap9QH/iRGOspB6m1UkDJs4r
ZPBMtmr5humdO02UQnWwuOg35qNgkIAYLZvNCm4cidQF4/ZUYun+f1UeZr/LmOxf7cyA+KkXTgAG
nm==