<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxzUSvlKyqVTeP/ck24TsNpeWl6RzzU5hEjoH4c8bVy5qIrJdI67Wjssajc5Be7EWD+o6HMC
coplQ8c+N1fD/qbV/x1xqtIHVqJTwmUfacz9d99Tz1mpRsOmLgCHZlaRn+5X6V3AGb0VELxunz04
tGMTg5BvGm7JHd32m3f8z5YcaPpFAhelvVYzBnx2WaNWdzULSAM+EdHU+moIsnTOKEZmwm3Ipu+F
RIA5ZWpO1dgbM4HeNcXEvtdv80ZEL7WfMc+4un+MgeT25D+EjpKkAQLjijNsRRezmLS1mPhmw/lk
ZglT1FCtkkG7izsgcmatUMj9QVPTA5Bj5qJ9SGSCBkyLB/ar1AuPbh9aK+dni9tLREUDFLcc8hmP
2tR2BjI0sTFUx1w3RekdT7ZiQmpn8rVQD9kIInqJu1Uz4JHY8XVgZczcl+VbzKWDhjyrWZ1mh/uP
pP0tmmsemN3pi6ADPt/xfMkMsnta7SvHDN3xRGO5Rlg3q/xLmDfIZoz6pY+Fbdj0bZfBihdYuPC1
N1PxkhjoXO2qUqn3wh9YDXwfNxVRtSo6120VsDNTABIDctzcZ/FC5dE1rk7zgoWpclN67bZS14Lg
//o9kJvLEVkL4VVnCK9KxIF6O8E4YX4BNPoJDuUg681ed0rzLMb7Rs9QD5reZ8ln30v6pVQHlY0q
Ar7RvqOpcJ2nYnOMo/yjoXgpM4Jg8ISaxlD8EmPUiOrlE/624n3+9RzV++FBVi9U1SIwiAU3WADc
RfMaQkkerSwTqHgf9prMGV7kpy6VmaXRkCZYviDwvQ1qejMeFN54DgaEhafGR5M9Rru4AQGn3xjs
14eBoleBlOG+xITCa1+LR0fvaBrkej402DP7abMsuzDmLEUVqYnTO4iVpei7s92enBaSHKLBhJ05
qdrcPF95Cpx/OFdXciLsD6h4l4hdqHEuVPsj3MQhgJX5Cu8IW9BTnfCVzT4nfwEIoed5U7z2IoVS
/jYi6F1PeOITsWJ/fPz+c0B9HEdeCpxKIeaXBjE1BD8F2MmPCGI7+3H3csPtVi9l/BesBHjBDSZN
lYZdHucckeg1U/LxjtiXppRCObG/COfEVc/v05QjOg6h4ieA0fVxqsCx53MlfbtS3MHGyAdQJPs/
Zrq9bW6UB4nO9NqVPOlU3U1lYxlfjptd1+orSaOw6VzDmc31l5iD39O649rPQ23eqaWuqcy6ByYX
eLgzvy/yfJxDLHdkykk9fnKRL9BR2gQ1OwVNGhiwqa6kC6mApxW8XgfWvSEI5+G9tee9nW4JRk4l
NAimXyMbesGKHvpA4lKRRZDVw+YB2tDl3MydkdTLj1+V3TpUGhYU7Ja2CgeON6kKdsmRE3XNygtK
U9E8JJ67CxMyAqzwjmDuIkHAsd4ZlSC7czI2TOoKpUx6hDkO5VGCUo+lkfloX0==