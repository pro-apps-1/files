<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsDm299rvF2b0AgTiRocU4GsFkph7N3zIPAuGxIIYvNvW+yUjPEnNrrWk9DCJcSfi4l119Sa
K709oiklZahdaWGQbhacYo+x440EVQH7yz5LWIf93QECdU5ckga/OtMmZmEg5vmdpA0uY83UmqzJ
VdsWYf0OUq/7VZzAr6BVWOmwLj9xZ92AS9rxtjZXESut3AnsanWknt5TLrmqQbhlbW5CxzXow4Vc
14eKhUNBfgtD4pCplqrs2IBe5NOho+mrnYJJ7xeLASVpR/ki6MzQ9EJRHRHc6wfxwqRlkDxmkUmZ
i5iN/pT2AdUL3dLWDxmblbOhmO2qG0QaSHicjNzOYEnBi9E+SM01mshMrI9thywA20Bk9laKVp2T
fr8/jNzCQRLW0B1woAJuqmQhTFhj71hs4C6XQwtvQtQ3edNUKMFtBmsZM4ONZzvVuZunzDgsMowt
KjTX3Att6Ewdq1dvuMm60X/4pQNaehh95+d+heGh/yQuvNdEC/xyYNLNIHUBkfY3QgCe3kyFDHp8
MDLzHP3LzPSwAwQrM0UslkTbrPgkrAnBoAbfjmFWtBLPicj1aWVZuyxdvXYyoSclxSoVdRRTXEel
BjcXAoNbQ4jnQY+vfaOHFsSTDEVeZWyPe5IXBqtQN5h/aoYq4ijGo8/w8PnT6Wxs/l7s9MT3T18u
7b7t7tgNAPmnEW0Bzfa5nto97ri3+6OhfUWm0P+cgLXqEmUlcwz2RZJN3pHF29VYZgGLbDCWLmSz
zx7av8wOSoJRci6WbR5qS6cuBd0/mK0e6YWEhwGAaqeB/VhEmkiL0pO6yK1T/R0gWpB6KMR8Cyeb
Cn0Om5pxXGgr4YY7QrGst/upIMoc+P1HPjDk/VX0fNoJjGJlCQ9fd1p7TgokOP3HZ+9mByMvxEvF
zLnsIqYoTWmjuAX1Susj/dafWoTcEv3sDJ/mXFTsPA1yDYx+BmpkP1isbd2TMrbQBNH1Do3Gdkrr
3NcXUHijb/BW4lUBsQIahtB5OjhBrNGf7ZkwbvbiRKsPeY+fNhmwxRAUp4n61F2PpDsF8htRw04/
wV3jG/7azYQuxsvuZOlwRTZ2C1PxPpXLyvKmyvEyDUnI1AVl6FRrhKy5ue96mxKpqRSovvFzXntr
isFFEgIdNHYXlxR3Hsy0PbeBDJcPMIG6QWtZOlHlnN+/0opp7LwqHym6oGrtIZFio0zufwhDKXGC
extNtCEcON3Sjswx/v8MAyXbInfrzDUAQ1lG02iFdAgJc8/PNJdYUneWkA6QvEhFVTHslO8Vmp3l
9948A1MDcdjeTPhFM4yiS9uDP/pdgPVoVWA1cc1j5k9YaWmshc4g4N89DRIqzKxdXVoiWL5jqGyr
YeaFxLz6N0PSwna2e4ZR6bXp/6zR4OKbuDrDCrNdZJ5K0iFlaXgf8wL8StenNsqPMYNfxid+OLeb
mBwCuUcS+xtvYHsNNoIzAu3MhtsdNL5uov4hzXvVJEIFk5IpzXpo7aAU2+5XRFBPfuceZ8tD2TXg
zmK66V5qYLI8Nh+XxXfHurqjjpJA4sIc58QmC5rCcS9+uCuGKEfM26HBvnGM/PZmyvg0U9qlHxix
z7l6sYRRvnZrnl5oHtrAc3rmg0DhvDH48ukai5qpulT0GRoOujfPTaC2dnzT1SMv2av1BvibLrrg
vUDV5/RK18NCvsavAof95jb4KPKMCos0ZpTH2bfcEefR2CiV2lHX452iB7WNUhbXkWYWII2JEQpl
CUzQw+Yf2OFumLvf3U60rYIUGo6vuR+Yn3rt3pPfUuexNBMfnBvGerVisN3FWNRXuyBJC/PXvegW
zsmnagdvvP+ETg6l45P4JllfFUm7JRrD23sWIs9Tp1CFexcEyTDzcCPP8tBT4SwQ7k0DbfMB1qhH
YFagBHiluOW+HyLgcqzT/NLp/gavcqkaBmk43b8CPqkdHB7ti9FCJOq+6w9EL1R1v+6RqFpKTGdA
SSenCZg+W4fJNVSPt/v8egeAqHOVHMD/8N6nb7gCZ7i30EjXz2NcFIeKuI4F0zeMdaculwmLhthS
hbSZ0xfzfxM/QL/SKJlaGH0piXIlDZliFplURQPYpfh9pCJtfKNqD8RX7bhh366DJuv4QbTx2uJA
YHLYmyZ7E/ijY6XIxWOod2XmAF7cpCLM79M/pB80fWYpE8O3g9Tnufi3rzZ+y2wieMY/FmrOHyHR
2a1N9UCDox5qwGEjlolYop8zEEBe7dCSY2JFGTQX6j6dDcJrNXICOupnynxzHoYOBiM0ekL4k/Tt
VGO/mE2fyc8BjblFQQU6ofvuCuFF192nyU8JTURdcUsw3xCsXuFOJoIs9tLkIh5g4ygp5Grkv13N
yk5Xv6M09naP7peFcPGt7mbnWzCm/xrn5o3X+2QrVN773DJrqZwzfuaPos24w2c4g1TgHROcW5TY
4mg2R92JrF3vtj+6P7DnpBmn/okhN86b+cYRQqngs7GZUBBspoLaXMySBene/g3a3V1zd/QMUlFX
C9xyQiIUiBwUiTm62bsQeDnoTg2cHeap9NkMxr77dOtBACWMjtDhf+vCSjtzOrdjbOTR+s76VUEJ
pu7IX2yaM6bf8yG11rdunSxP64sTz4L5rFNHAuiBQuzco06HrF0C/FRYyNRbiq1FYC9I037Aing3
E842i42fI3Y6xRIExuUIT+vuhTceUG2SOZJI3fj6/MiV4jZ3tmPXD9IXJ1taOrepzpgU93em5Vf2
nLeRV2XYjcxixVH7lX+A/QeGgvxkPTCb5Fm07NjEAxCgaFYjXRT7ZHCqSMJZ/6TaVophVCtBWgTQ
9aXwaKMf7g3odRk4SE0U1c+TUg0TgDdLA1gdFY5+x2xYw86Cb5bpVnnISuUK7wxPhOmEdVmWXkTU
m96TP7ROiChxfhWzUKt5CxRT7DdKEKq74A+Pr6WbYkHcq4279MwQBMzWl6Y51wZV3IBTEYFdQORJ
CXnQrfxL4kAVX11Df9+tjsFhYz946DPdJysSRqLOcSTcJwDotnu8rUwre0IkP8SlePQi073Fzxf+
EdTL5ROvKUtvPRv/thaWGuGoO2wAqsJkI+rSs60cAfmN3iIG5XyDhhBltADXDrrbUzZRlvy4uHYn
jHgWpMgZn5NdPKp8OK08ytupfhTTbXi+ovjiglesUmVniI0MN1OsCXmed/BhSDrR4PNrdr3QCs/N
Tp+IvenJZFjt307AsqJ3pbBOZhW28/tp3GUiBY2wc5KNSKnI03I5+pzeBL/+uMb0Pu/PnxcLyEhc
gHVRS9FY61Ed1NFpZy68HSa+CVZAsoQTjrHUfmcBP1FgP09X8WA8eDIKrcDmrGFivhOQUsObI40c
EcNyD3Jvr9zw265peJipdH2fLH/sNIdQPq5Piwx/Do82vSMBLXaHX0gb6zXNE8tL5iJ4az1k8B1V
QDMBXuK+jPgrEzlsGZd3Z+R+m+JQILXDgOcX2CirTtvOnNOJ0kRjJp7wk3cm7iavQZrUAKqUOxs+
aVOTjGhYJ0SmiQ3gEfgNLozWfHzyZ+fwc3vGzR3LSu4R3xfWZQN7+A7xXB3kZoytdviCbbiVb2R3
yTqsZTM6NJ5MSmu5q/GNM0FFe38wFzAzfHMOuxKZdT5g867K6oWkK1KIET6IjxavUqHZSsP70eXq
knJjPgfix+CrQBm64PeNxQtDerwN1IH8UTEgU9+Fpb+X1QA8o9Sxvjf8KgPrSS1t4s8m5fwE5DVv
mn0f9m2zvy62vqAq0ynMQjzS3xkDWgqjH6vVzBmspd6DxV0egTP2N7pajABljnReHCJUHIU+3pwV
ANTjrxOhkSABxzDKzYh91fAYI/YvM3KOFITpH+K4st6ybNSrNs4Zx1h+XcViAARFFG+eb9gXk9UQ
gKfRdo1zm5+0YkDO+ZHYeA7ak1EyWopjA6BMXurT7ZtdgezjT1siHun9fHS/Ej6qTKRaVHjhkP/1
gghHaVTYJW7ie+gtO+G/bXcyI46FfrXPnfpT7LUjn3as7o2f66qOGLtMJIVcLNzS+ijASqXgx2oN
WjhM03JHlBxXqpgUZkfy2s+rg5ye4SCktlCch8AE2YBzftCC9swrFRuuB3wl3BQ+KBX4+kNxPlqc
6g8Si97MTlTV2mY5nYNpyQbPZOiDUnX7Ki8ujPDpD4Sb7UdLKYn3jN4FZf25P3IRSZBTqC/ekEWh
089xYdSngLaAMeFuRDhYLcDw3u4IkwnXKsNENEdUZb35ZV1/CeE8rdoETIxU/dItMq63gET4/k9x
bvu+XRoX+R56yJX3L9+3vAwrJtjgfZYhoJFWDCbpJKyJl6n4bw1Aew6S5iw/slcynZFCe4bwweNb
R/we/6dvwKIVpJMFr0Z3rgcdMVyxULIW23iJqUYsD4RAvDcz1rFiIvPs5qMjCFo27sSmJBjc02DE
vHjxIfyrbCXGCzf2l8hqzFkiMX2BWJxV3cOYTb/Ntc3bTzi4sBq8j+bWcODG406IQMDxJqdt83GS
xa6EoF6u2YFQkm==