<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr3QEHijae9SA02iE1gjJ29bsDhusmU1tRUuH1xjSJkGkmQudkq05lev0D6if0jOwyBjzYJv
RmLOa11tDuDwPbjB5nDr3gIw9mtqm4zkhHzyVkVspQxAveH1f2iUWt/KOQzFpcglQLm6lZtKo7as
+0W4lhycUZL9DkE2j8uiTh7IryDaNdc08dEMZD1VpSa3NCR0IfaV/I8ZPPiVTWnqnRI404B+v3il
BBppDXotxMuXv/XOWc9TlN2ldb/s2eKdI5/9nc82gkQCyqV2yCGmDldWe95dy67SjIWm3CIy0v3S
q4TJD0MDCqGdgl3GACwb+2cENGNIj1R0ezrzu/xAPMZ8+wyYPV760J51cOg/1pgRg2nSkusr6NEJ
naqk3hixYSZ5oOqmpORK+DH6dmqzK8KWFTzNJ1Mid7S0PV7PCxOFTcGI5Eudj3Nkl8tVSYKDKgeo
uikkhAKmfoTLtGOTob1F94cmDMFEo3+TThLPriePQ1PbadSATHZRgBgnC6Oa+xPhI9gB3plXcgt1
Uj9xKgcftV/ScOvflK0fW3E4EynwbyxT5XN3YAYF7P+Yu1MIYEXsv+JAidWien4t4iEqTig9mtES
vhaepep66kUG5ZscgGNjmIUUzCO8YGdzUnQ2M3VJjS3zpzmscxtjXKos0iZ8b0uNpGyC9gmtQMsC
SvS6Y0XxcQr68z7SjVP0KedCo6YvWkZPtm0NUMU88AGbDoU4kQ0P3ASjl5rKbum+X36XVCMvwc9i
so2GXDezvh6QfuvDuItjVbps+2iFR1XMzXOq7WvdOktO//QxLtnkglqENAydggUnw9JuU6XlhgP1
cwsJlvsuv47obi9nDJVKWt8q0oC8kp3g5e5rQsbDP/6jVrJ9rEzewhYjhRFpCw0k+6CEXBsCvr98
ehR0G1kij1/mXb1h8xD27LTh2RSAg2npvKZj9QSSL6HNY+JQYUASo/f7ReKfe5jkap/xY+Y7pdJs
rUr+Iuys0p8aUWRWhDxlHcWT/KjmLKuddLKMku3udhWtm4oIdNST8v6ny2YbHmAtXru7XXOX8v72
HkFr3Ror39j7LSitva2fNVpsuI13ZTd4QXpE+puPLyqVtLUMgDoKEhBDNo/JYl3XL9qh1qQgPQiz
kydniYTF78Qw4vRJGTLN2aekvH8Tje4BBmlkJRjiC6EHrPfN/O7bDxX+hN5lKdUXyUCXxJkMHh6l
jBmUwi9/c2bpBtRg/mke1EmluuEXSw68erKnLOA9bLw0NdTIHaMzK7zWiDHYmKQ2lHsmLN+0Nw0W
P8fGPj4VjhVLvJ7/s0hYFj2f9S6EgK2BFfeFXQ1iPn4VQDEt5fpyjSF8Iz2dUm1u/shTPHaqVozh
HMtsxrpySKHxhL4FOlgsclOOMQ6JxBNVLXbjImIPt8G8ip1crfAqsrrarf+sgdNCiASVsdilNIwP
/mg4Bh2bPm3uQP3qnVxtAmWfJlE/AfdibC55ASNYZ+462R05Nv69XAgmEXoPkV5l6JhjHRO/huPD
Blu5LoXeeod6ZxDwaOMp/YQzO7EDuimtyIcW/mw+fNPhvJInar2qnEt7+Bo5W2/mZU4NQxVXwEyQ
y5jGMuVXccF21uiZI9xrsOzrgEBn4p7MXmLzMp8PMUldTPAwg4valhaP7IKO/i1nL++PuU9FvCUj
8CK1zo3n3Wdogr7KhezywuXisYhB7WEDh5vDe75cTQIL5HQJmEcey3YaGvdfoEM5cenH1migDK0n
ZQ2kcFlICHx00RPW29RR0KqCgB38XNOHDe3uUmEHmbpkvTv5p9t/yvfCHOAZrjFTwSrC5sMhgO4B
gHi3goud/XpY9bATNJL3tgBBkN0SCMuJAnX+y3U6RjcQb4X2LjhaZlCG2CoctUfDcFB9zl7pHgt1
on4VKWoG4MjClx6n5Sukk2X8xogg6s2rY+JMxgFGi/YLgaL4Pd1Bu9ffEAWVIQAEkW2AVE6AFMCp
XaGfaI4KZqDXaDyH2b1UUtlydwodOybOvhIyBxfK6YBb17DK8l3lkSxTcynsZ81fNzxgKdEjtzB4
cpAfC0ViGbIuR+t4TfR2vQGjHp8xw1FKWpQ16zREtrFBkigKE8kwurGRafz8bIKRfnjJYm/kLdum
akCQ94F9HNsz/1Ds4x3ZcFw3ee31Kyr2NEoIVGP+e0pcDD2GlGqjbnJ1TGKmGNp/bLzseRwiakny
QGTc8lfxZtkXQuBDDqBPan3Z1tKMIVVFV+c4XvIFy4iV0YkW4IY9YKwVbQinZkjeykPKjZH3iNoM
OIU7Do8I6dJHg4QEVu6kZ8EjTDXHfuN0Ikr8rmSC8jNyMpc+qTdr+uuz/+K2s3GvqvpTNI5pgt6v
YQL8vV4KrMYxi7FbrQTS/RUI9z/j80d69lQ741Kz/xS349b7uzDzVctJIYZzMPRkrb9AS/LjCytK
0Utr3TYfxu7bJ0An3VPseMn3LkrHBDHZ9Ab1RduZyD7xBrGhj6lLAIeIkfqKZoOERGM+GtjFgIgK
bV6RalnJk+/krRgzrNT7hUoa/WnHm/Sn/vzOSvfH+wH8zvOoczfBTkXDYt2CJIcRsKRUJ/2FcYuO
vCxpxCe+rVvU8IdWuX/4XjpROjDEAerSFJcYpbue9toXfxB8lQ/Z+Lf7afvyJ04PX/5gl+//hH//
Y2U02NUSAYxYWa4DzduUwkRj3Va43o1ITrWr6F8Oow+0DXM/BwQxFtFEYuUYfXSZu2R5LvO7RLQO
ANJ/Y/EH2kaUx6YP529l9A/hEMpAlIJE/y9vtllOyKHPJdcDqv2QfVIfHxN7fiaG9KCMT5K9mveJ
0w6sth0XCPIHS9grbm5jlDBR+RWIf+oOClWzMfi3z8TIBuJA8yFVAx/GcxLfwlh8WgYMD2Yy7iCj
HEMEMmIVGqWbqRONWNVqHAiQbIHYLuF+rP5GFYcxWGcWTWt77aU+p1iiiJyWZS2gPYrJTni2CkUt
Nqd8SjtwECwGE7BbJoBXcPMMIla0Du0lvS5jYhsKpgRgJXcSg6TY2bGWqJ+KPEe/zUztMsrP3KC0
Zh+bA0qdkinbNANTBM8fH1ewaQ6ue/Ks1Kjd6e6t5J2v1sHuxNy19MQNj+I4HsxD0CEExaujZwPX
LE8U7w10oJLHKB7Rjdr2OSPE6Nd/YlcLBNA6fw5Af1Fw7J3ryx2UiVK0RkbsTjrUt5dnnxHQCRgO
h0pKoe55P9CzBwyk41WbJDFEs0wS4ZqHFpK4kyxwPRkzGsOh6CDFTOEIA9Wv4sZ3riwz1YbktUBN
XLK4a2lWRzJ1JwqdKxoJ8w8cYDw+XDRWi4Qa4EtrJFEeSB/zc+gnUIcMuWcdiRAIk2b76W059o9r
9jfMuoNNMgH8fq8BVdZ/RJADKkZ7l0lwxbU/fs5afknrSLpznonzAfeC8mPZGyvXi6IK/cCFtSw6
sbNb3hhOQKe1/o8jnp7KxLC62bkIqjr2lvH55zj9IBypPI2ghmYgZ3iH1Kvry3z7ODQKYHlizhxd
W5USYbp/HUZnoUoTFttv/GaN4dVU7j2IhiYcfQo42ijwj7w8qKynMemvUMmLcvmumPFrtHPuXbxT
TPoDNGvHfhj++rpPeLw4dtcdzefLihwoHjhpjMZcpIa9AqTYCXQr3Ie3ZHuIlDbCXvY6Hb++Plyj
ip/atDyJ5bOaWiMoZ4gI61jg/5Z1tBnpyjg5XYEaXmSTZP1HFdH+A82z42wLOFLlS8iDrF3kh3XO
mt/ClVscBa5Y8QrjQ0T+gcmIYV/ae47oOEm0zWR1uB/AcmIK25DVEPA7CfgCRg+oBD/Z5f2e1R98
qKGehS2+465rdB1WiG/kBo/TKERJkXswwxzcm/OxL3zX30RuysweaZ6fjfCcqCrU9znv2mImRmMM
xC66K4iUiAOdc9MWxfkWi0/XjvkJjWcV+uM/Kz0QgEagxtMBMDrjZ4LBfRjmjlQgyZ5eqWF0E2r0
5y6FM+t/yz9Pf3glRqBVcHU0MhA/vopITLc7SUd/lcoRATgOy/h0ZVXCBPZdciQRUAXkVlxDCzut
U/4bU/bK9cOU1cUBAcPcMvhRZdERooMgWS+k+E/LAU/6/csgDJ3iXBE+ooMv3VwgJhDp/Ub4QukC
maBaVPF5YbkCrvPkRAlhugVLGZGGqg6LhxIQm1d9OwsOc63iLPYCFa3jYOLFjznaGNngoniOjbdv
wL3dDjp0dnQONyvYrKB4F/yINvlesW3Hx+yRHM/DDwHnybBGiZ9pwTzG2TH3CrJRweBUkqPZtmUS
fFQ0uHib74OryZ2xtz8zfkC2eH5uYO4XiWz+Jxkawa8sbXLf/OgMP1f1/nMJWcSJAJQD5ISUyztE
VtQhyDFlfEm9ygyGmIAC2tjJnXbTQc7B2PbkckHwJkKPmU3Mw6i72zTZnOmrk+25JNx+KktsnmQw
/iOH8Vw+k6iC2uttBeSCx45h1lVlz/ddmmiGBJW1xdVVR62hKaWePUs7bPK=