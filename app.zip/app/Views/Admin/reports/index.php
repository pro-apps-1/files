<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzbqww9UvU+L9wb+WISnXIv/5s8qCYT6YP2uMaszIzVubFAioExBVK3EBQMPqVeSIjk2C2O4
Su+X10Dl1PzPFZdqe6SrLbquw/JRpjAYsXeiLev81SddUPyKdEwAhbLXiH/NPQimx/WWTvNVi3qm
TB4Tkgu26pC6wNd8wM7Z+AcNs4D+I4xV1bx5jOlqvcAV9HqLtNltdrP/tDJmrh0vDxPmwkoNDNm+
8PVVe53WKBIwiLGOoS+6ySdyBdHYU136sAy8UqoPPhjLP//toGYqjdKiFirjts2h3xWdp/VPM61a
ETnN/vtQp+STzRGW1H6Z2XrBYMpqBqhQLSW8ii1dXm39CJfFczYgcQ+V+/SRciyqr8wZsVIpjiPB
VVlL5C8tLRp6mzT2Aobd/sRV3TGWYAgFxoTpOjK7oadhHgWfcl25tdFPKqHTJmC7+/8NYYegT0NY
1JtCLlFAUxBsPNNNfdrSU1nfhlb2jm1xzzG20D63vo/wHs+QsI7w/75GWEJFY0J7znGqQK9NWN9k
xZgf4T8+RJHw5o5C4Lfl+5yRbcMqoxtTmdmKva6oJM85dzLMiHK2/necgsxPCfhCNV2ZSRSMKF8r
Vy7wxSuFtUlFf/4aycJYqWbMgU01EiaGw6ou0KwREmogVKn/snjU9DDVnjNCo/Adz1inz8qAaV8j
2mz+0L/BeA8363Wt5+GGi42awdpvJYvMcthGIsjkbthCflrYnHUPX8UA4sa15b4uvRrfMDooyGC9
DmsS1g/96KXsNU9mZQ1v0HUy5STbdYciRgDeHLfMCEGWKU9vyq3dBu5o+UkrqJ4TKhNcVhGTv1bR
ewshi4IcT6owa61wBi8Z/XusOq7IOu+lWpu41omUkPcC6d9KQRZudULpD6LtbmNZugpiVaP14P/s
ZddONLpZ7Xiuxfz+LZtTRQfcRedDS5JqkXByZgQNrt8s+eweG3wDHL+4nLsei8LIQ5k7TFc5pLod
XZXKg+zd4nkFYOf5QPSuqSM3JBNK4kys01dCcjPrQOTZ+IQJIWvG3z8TEispZkAioGxwHZC6gpDy
jlIUEGiElLxouI7kkANnwHfYuSRQhahZwqOrYHn4KyUs2kSlpfMSY8CkalQIBAOtYSgciXEIgzN9
gX2N1akEcG8iSKDWtJjJSS0NytupNuL5KyO4yr7gMCPRorBZLpF5p8/LBKyDjjLhwrDs7eA2/Zbb
nkRYqes5l6M86zVS8jVD2I54NTsQcfeqfvNdMcReqAIR/E7eoyMUohxjIK5czEzCr6wFg7SG4A1S
O42E8cnVS8zbbqzdoy5auQmoGzFGx52aIdsjX+qUc0nWSJwg3qvw3RU4j+Dx95kK1GMwzlu7ib+2
9AqZ0oUmfVOtY48uXQRr1UFGOgYx+AEcb9ihQjfW5dd9ZXgcEKILkfzgNphnyFd0QC5uNXaMx5vl
0UyrOl5XLxccXCBSOEQKYJfTuOiAm2GdJT0oRqCcExXQ1nyDFVuJVIfY7kPIPjlN/6wuinIk1r3N
2nxhnyEGlK7eP9j72WHmJzsadrbrKZVMJdSJ+Q572iKZ6qNWIDILlhur8TLUm/1KSov0ZgOfgNQb
vPGGdenwgqJ9UEWb5OTkOIJlNAj6XPSMaFPW+DT83G2lBs7tQi11R/2xVHvEZMpY4+pNPLx61eP4
zlHq6p8aClXcky8mJPT9YDeLI4l/XXPV4qxVYAOMoYDm6kJCNSTC62453F/H5D2SXAeK2b1mNOfM
JxPb+8n/XsaFOqDZyBE1sqkT5LPZlLZpynALRd/C1snjglXWnFfOl+OIyauUcd1Zqjh466arEnGk
tuP82b+wqL0b6db6lNnsYxtKpDXbMOPnGnWxSVe/DgoKgcFMylbAXet+PoRvqbT2W9zZ5bahaRIr
rshRe1UU8tACBQPRn6YSbI+5VBOejOsyXRpb9sxaqTv5p3MQV8qJMLPGst6siffnnJwdFYpyzw9z
NACKBBMLsJYy7L2a+u2XMZZOSxh1X0JcHJOiUfKbYJBNdUZ9FjtxGIplXsmZhYGN119wNA1RQMD9
tmixpBaJyA2X/zk4EqT/GWQBfH/u/l+fWzU3ZqvTrETigChexle7sLdjW5Y0gllJb1w47MsjChh7
TSPqFH+SEdSbx/tjNvT9S7MjoOj6ChW4Ir8rd8dhWQcDdurXKAVX4K1mfL9BKn7dKCNh5mFKgXHd
vhViAR4YoKx82HEUu6t525hRsTUInEvkoIX25uUvVsoGCUIzsdKwVdUBt2KPyIaKD2pJb5NVOd+3
yH13YfC0b8oUPwHRWEl8BsdT6K5g2QSJehdkD32goN0esocZi+BXyZfmsjY/9vL+hiewj0VtEhIE
EoivNhQxMz9O1O81SruTTDmlQBpP3xv+8jrSYASGhG+fuAn3+td1Zem3eY0KHoRHLSMRmCbFAGSp
9qT76z6JR2ykLreJnkF2lLtrowivkbnZ/Q1GWvq11EQgjk7rUE2iDZJ90mAdVU/c4CyE3vTx09jP
X4aNO9PAyCDFPTsClWxQzUTq5ft/WnSNs7K1H/CZ8SS/5YumeplU0M0lympmLt26pAAZyb2Wz0==