<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyS7tVAbjoN5iDj8qKlIFGM/3xB74XYxNhou6tEf9DsA2a7K9PzEuaGQIr945N0LRjAlVAOz
Jd1wBxn83FNoQactA3eSz86HhVrvmbXYCuD1UC3ipMsYefVtFJlO1hi+m0QaUC/wP8UtcMseFvuu
kLGU6Wvqpztzj89DkjOK8wUsz9H67kIvEflb5LxKV+Ig9erCsN72JZtFdbys+VbTb0FBcxwVtVKn
bymMKz+EbF6QdD9H5yi3AzwiT64CNauBKK0rfnDjqKeZJQJYb92MQiv9H1ffO3uvQSpbMeTxiN4j
HS8V/mByRtsATOcz077d281AtRFhHKsFWODWb1uSst/w12L36jTZ0647Zw6EZo90hVyF2jf66nzV
40kgkDYn0PcEEbAQo6m29yLrrGYK2YceNuQ2jRpmm8kW/B+3ulC8fIgSP6xK9JyjFVvVHLoptSgF
hjjJZNuMICrVH5CWTojzkOgOlT7jzXFTAYVMHP4LjodQ6UPbHn0UESs1mcQmjbeZ2p+VGNW2UplC
sBOu3Krdrc8vvItQtFB1UgBLUBs72NnIOEn1sP3y80ESJPCR22paBOjm8IN9s5+nFRb54zx+Qrph
oAMl1N3ZNqpbpfpCE4SZD5xobTNt7G1izHmQ48JAcJvyBptmgpA4lMWE1W/48e+Yja0NcZ/Z08WV
KqtsL7osDxd7X00zxLa9ArBel6y4ZHuxZMrNxHa05TNOahncTDV8/iJ3m02Z/vYQZ6Dl2YOO6zPd
+LnNB6LSyS0hjWz17CtnQhS+bE8mUd/q2oQmGSSmqwSH8BWDT3z6u+jkDvw02eBX/L4q2R3H6kdx
A4pISDSehJavA4itCQpQWdxCQz1oZzy7m0KEPjXN7D386i5piF1H/NJFSpPk2LFoPxFqXgzYI9vR
Y9SuTpG3xZqLQOSOUnyrh3NyxanD+exVjDzUWRjXjUDjmCxgLPlJs//Nta6gQr9t/qPAIW0GTTlB
fYew26qp2EeVku5YKgtlH5xgvwCbSPwNOCrM33sIMwlqr7gpiA7sW5LMYW5+8HGV3c+UAiUFw1wp
oDikNvZ20WAHZm634TpLS+aoK5QtqTixhEF4pDdL7SgyMivkjfOf7XgBAetga+5KyWCTfPKfzsmH
5X0rM/dQo39R7AD87crrZDmQ9kx9vT9dXMr2Y8IcOEYIkH8j8CMJllAMFNCxdQtNWCYDWmVtnLgA
nr65kVbQc/7l67e1m1owwLUs7HEuH727lDCeXuKGEY6bM7biieqFrDdJk/ft58Q4Vfog71uWHlXv
snq50OOPqDKRpRHoL7Y8b7mK8raOZ2vum6Prq/ii/jry1AzCarPqM2hNQG6d+Nc74Wd82gjA2Fv+
mTTav7Axi3hXPmZh6T/rShE9Ku/2yXqoeYQij2JOA682LKYAJdFCFRYuzaA0guzbtlCM68EJr/ZO
QW4Ap9/1AKFEzKpXq8UK/MerN8g8yfIeBqfkHbWfuq8ZncQFvhJa07eEdLUUuaio59RfFjudETM0
jWp9VNgaPdRB/imYTgEAX4HmtM4iWQcV8iOSrYtwjkdQ+HmS0qLvj9tpJ4U9RC3y3PyopjJWsXzC
B9+ZxlQLt4rhG8yf9SUyQ4H9zEFQQ+8H/0SvHsbQqjcPZFx5Ekry4Qz6MyUWLvvtXtCi43gDxzzp
4bWb4xQEK89Y7qP10jwpx7/9eQ/0tMMpuhOefVaEO1P4161vZxqgoNdw+mRLYv2Wlh+rUMIT8a/O
UI8NQ1k1lssju17dcVY3+Yx/JXWgtsFswoa/X4KqYdHbqxnoJxmmu1gVrxjgm8xliGUlanyew2nE
AH2y/fKPrZaneZBvQDJlBj9qNrnHgwtSLE7QkjByb9irwqGuCPVxJbE7HiFhvp+HbB4f+Ss+3ONc
hXd2S9kNP4mRWrsopg7SxquslgoybBq1qHkCQp57zz3ocQQknK+meGd7WMdtDRUQdyeYDVd1xAmI
GeHPy4aTpL6olSoRUj8oIEr8NTmB9B1dV0icxqGFxahxiRYx48f+iRIyMY7riCjA7GmOFt8t6h/k
ke2J+nkTG41w03V68sAGTWBXX4Et2YnqPtHNRby09Zj0U/2VtaNJiAvgGIeBCGloCL7olOY1ZcJx
YhmKQaSUUh5FZ/4IqnPXx0YVcDnpnMfqumuHBpf68EXmxsleJS2r1IShKKNwk6fDg9spHiImt2Uy
pUqbb5oR5AiNYf3uB98zgWA0pL5t6iYsSSkmkrRZBUxHN4+QeFu90vfMa01peYL2LLSHCpw/PMZk
8GWAprUpGgImi5jlogq6aKmgBMOS2U+0OHqGXdMg8BFuok51cXpY2lAa8fdMM0EwGQzUC45D1aXj
SA30xKfXo7NPp/B65J+RQbKtESSMkjVISATR4HW2ZJ9RJYs/U+tvMkmzQaSjkkGBmPO=