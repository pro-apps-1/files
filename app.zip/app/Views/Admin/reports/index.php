<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvhTj8A7dGsrNW0XeGspboo+f4JA4WJ+tB6ue5JIRX9pIWNwtVYZxcmGWJItIYxR6ADx5FH6
4Y0gSik+J9suhuHUMAfwTdPkpq86iFEsnUpWEW9vz4sbK7wS4bygq/z/RrrWiXBP4VQIWymjLxbB
P1ZveZ9CWlDSz/Hn5wLORzNZX0o3bYnc17VtxbUOsYm6nlpMRmPEKecKtsBCG3x1yG/eGevLNiFt
GMXhEpqT5gjLUg9un7+jicHXB8cXE+63ORXuuTwEsDRsN/vT7QbbsKtlWJjh8ar7qrghTN3wo/dO
gTq//rfK2kN/mPz81NYDSBIJbeimkBuGsEH61TYCvsvMKF6/2+nOpRcqNCezvIsQ6Oi07Ig1x1Dn
nehVccpVp9YlWsvPYM0r2TqX94yQd7T93Kyxi/bi8uJrgHa2GcCie27YuAuSqh5rQQsRGmDcP/A0
2LOAGCvhIyG3I+3Jho7Oj/uYkrp76238SCWDK6uuMda+LdmmL5zsZgNtJjIckI2t0aaR6dvNkmaj
lKwEcuJq9heBf2Oqd9yY3CRG6uusfnQ4BfHMnBBY5blvHAFUwh5n1OmMDqbafD9HwrYBbe0cVBp2
cjTuCV5cIAfNW+gPlYSCOf0wIPAHUAUingBpnl1b+ZMMXjVAnBr3+4Rqb70wz8MOqFbzxr6NmVho
HMlE9Rv/HZ5y0XHMAK1x4R4CEnuPfbH6+1sqS30QElONQm1FNp0smgktxg+Bn4zz2rxjJ6lYJv4B
2SdC9RA52bQ/QJLcDwV6gwMiE6xd0pAT3z2fMmUIRzfg9AjSNs3l4ZwuDCQSHY+XiDdA1lHwoWVB
96ot3DiXwBJJeksfbVv6POK3WQgFv61umFqmtHPBCBhPvQsgp+gsf9hcEJznkjzIPUoeCukHQl4t
vmlN0cL4n4NebEZOT1Uf71dQQR0RGVva3OWIof/T+BvT+gpwQ45DoCulygBnqy9SdIlYW26b7OVZ
mBDnXg5J0bcgAFzGW+x44eZy62JqAtUqIy+7KFKtqcSTJ7WbmbcmkwEGI64DOrcp90jjc5KSlGqq
NzRyXD6UszgJ/LElZ0E2CiTye+2a06/41rzVJkhgucTfW6T9ozEQ9PWxPk9nXCsE4anwDtrc16pQ
Vw7WkOLmhDMUtYMS0F+rv5T2yUboqODLCgi5Rq7EJqxLaPLNz9aYTIHz7HfE/u54n/449OV4oViQ
grc6xpxSmjt5+MIZWobmPxCtAZ91ZIYHY2Edz8xX2FJO9ptj2Ykb2FCDGpgz0k+HSHuT+CAjb6+v
JBFfZ3UaPvEzZyXoqYhlzpw/Wko76CKvMos2K5NezQoKvDbHGe0mxzsKGdDsCbM1V9ZWas0j8BNm
VeF5FNA4c/4KDvd0FhjiWVUJhyvgkmHVSlO7JnY1Ro6j2gKD8rLgDtbV2bVIjvOGLTBL8v2R5YiR
GNITZXliIhAtPIitW8EzRgu2WJPxvqOhhTwG3tRpYA61Cx6sVtleq/vKxFMyVBeUeYp/ipkfE2qz
STlfjXPa15Sp67uud5Q6fms4U14METnfMTZIesxXvK44gkSpPnr7GMKw2aQS6UhCRPIoPCqQgAAZ
qdXaiAzlZHaLM+nOJmKOjYRFXo4mwhkq9cetPgD7cj+nzTODAv7a8ViIQl4VlsVbosi7a3W73oNJ
UgfHffT407p+GdZQA0J/kknWK+gIYLtyxP7xv2wpXKlM5GxzeL5asFqprCixVOU8lGcHTFd5iEKp
ZWOafpJr1P3rw3xCnVkJJeqP51sMP0+aeCO4rznqjWLN2YnAGiSBSbtIOvmcmKOdkyhIwQgFYRu2
Zm4UWkT8XS3VEMCqZgAZk4gQ1KJyQrpjc6ieoOSjdayp5jBmspg4prcJaZqmqgZLEQPCYLj/ejRL
D+yb6V9jnMOGNFHBlp+uMTkb+giUuq+pb5Mduuh8o7hAoZ0Yin290y7xuyZA4wRNQILpkL6hYQ21
W5hBoLo511HByzfHkYEoYM/m/HuanMeTvtdv2oXO2S1JHOmObgDP1hWA01sbo5fnEQjjr4U70O07
dHVERswmvv0B1dACjH8lHu041MxblW2OH3FHnWGlf6GY1Ihj8HhLywd/M1rMkDHLOfWJU5XGVPEB
vj4O8B0WFWRvjervwt6nfdnayZSzu21WUDCJuqzIDhZ9PfGnY5fIvlNqPoNkh+n++LU9ekmamFPF
3UEmjS5VSbDvsN54eNsNC8MxR78SaNh5gCHTXVEZWxHa6px8RZMzK2TVI7obW0lYdkIRfr9Plm1y
UUo5q59f7tmepqgdo7lo5PQKWgzopyeTv0FfKIoYsIJ8KaXDQLDgmikFoOzXcDmkyCXbiBQY9f9E
zdCGyP/w0od3rZKgUO4TleSKORTsY03pmOFzPFqWSMYaQR5TQj/NHEcxRFGR3TerVeMgA7aXxY0V
bCTr0sL83Op/5dhQe7e6eM6/+aX4EhMoVzCBEs8zpa1ZSSXYWMR0nrzPqUvYwhXc8kqiMtikQn5Y
c+o1Fs0t+ndCKmB7jn9jT1RWopiNEIO9bLrsj6JazrkOWJxzpCP+ykVax7gk2aqmXm==