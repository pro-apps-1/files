<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmg1vqJhDjnhybnoPyOwWU15nORmgwI8jzTPvcRYe+fAVoFj0PQjIOWeI1DNc4YlB2gWG68k
7O6M8NjBx/tqOv00eVT6I6hEpCQeiWLBDhcEgSHkQ60VojNs+LWUKPucaJVa0hhD2vJPcO5lTMaB
b0n4flYONgZUqtd10VMLTkNE9mQ1LDlPAX2jftlRwR1Gco5pSp+lxKIux9OOdL9Rec/097Jz4QNX
FP1bWlCTNa0kCcr73FEc8GIUctPrEYfbh4sNDkbziC4aQ0LNW/MnLNDSvRK1QWB5ZZW6JVoXpM87
+f/dMcOCTt0EuwA7tkQ5e6+PHEn0i7yGTsCeG2+11IBik8nULqzKaFh7yqqpLFjoVq9351bHwHqq
tV2n3O70quGnA7I1b6FVPPwWI8MMgX42VA7EnQOYtQK0TG1yxHYNXJ0bATL+NyVsgj6QV2PuiueW
YINZQdQZuAUmQsAbZ8v+oK3cbA9e6h4MflKVkJB0x4e3d/L7MPVe2NBtxEd7cp45L9IrMPT7eTGl
GRtOwuxRgtq/EZFg5BBRcCAf/HqTP315hwd/JwtmfIEtk0eGa/vYRF7ZhAhrEZJbCyg5bE9aLApx
a+B8XY0I7tvzQOv9v9EhJw1vTsQhMU/NSKMwu69cTV93FuucrPy6v5aXDhMaUVpB+gXBjbO7Ki5D
pG2Gl1vUS2sRdj0ctYj0cmOHFYErhsZpNzWPFNK5+8sz03HaCL4CuxZ1gOwtVAmij5SpX7l3GNKZ
hBE2T2ACe7SwSBH4jfNhRMNPmSEQQgbw1iLXjRhWul/e6EgXWt6U7AOIkA9Ezr4vTCCcVX2K30PO
MDPuoYnIYP9LgD8YrDVXFdAyi5VrA3R2KJK2uNoixHiJz6pQ5XLmgs9NUCB/EfDVi3V2TWLCt3X4
n0A7FKpnSf1nLAie4+5x10GHiZKsXbIi551bim09oTtI0HbDcp3y28QR51fWAZLIXT75EqW0/5fS
tRrfaR/Eoch672RKt7o6WDVr7QquLdTk9OJo0ixPrjz8ouJ5H5SwDPLsy8qkhtCe7pCpNVyjTtSU
lbQMyvElg929nsoXR6qpRV9GP+c/QGqdGaBP7NWF4nLgQCMNlIOVQl0xJ2dDSTyjH785RzIHiPMb
ft9nFej+/7oBVm9LxqDeWY7XqW7FFn/2CWubGpxItpEgmqESa6q5FsAQ0iED1mHoPWxv3K4MW5RB
HptJH3cMd78aoz6n0FGKN9RjoE01SnvaTISbXr/DBX2nBd3kRElAetZiwuYSEvBXdqi/5UuVv6Ft
BA9Xk4qxOdr012qdzaiJTjYbAdiZEV3q3I3wZSjnOzFjPXTnYEq22y25tVIQpkr0AF/lq1KePoO7
4VWex+XPHHllzTylmJTxEBrUGdt3qPAYQke40ovZDVEdBsAhMSk0lThgC++7EwPExfEZEGobfgzl
EjxIx/OgSnPQPQfKtJChi3+kp0WAfl88ERNWtJuIZ38SjXgQ8NPhiuznUCkO6ez/cE5YlKtEVXDD
GmtdVMccxwHHOOqthMF1kIxkxj/jkWWZ9DUVLKj6xzemLV8+fqBykURt/DTT93+nR3DkKx9PEqru
78R4HceH5lDg6YHW5NPt6KvrHP5K9OuWW20vhBS1BqZLEBxtPqpTRCnzas4RtoaSaBDtCs1LYyEw
o58iR4q61tp+b2aN9Y4mDVa4X8P9HAN4I6aMeyfTik213I+Ijg4deqMmV7u1P09jiSeRJoTZjyy2
I8kGsGUXxPnhmF1vpSDi0J2fzNEYPibLhNlOiiKKY1HYYOPXOS1PChDCg3wzZsLDurnxRDS0vtZi
xmMisIHV0gYUYutYwPZzzQUO0zy/fkq28rrBVgtDLQjGyJjv8bg9EcmzFbvE/EfU+8hlGNFKGW79
2Vg3OpWOJ3CFufAzBFD5VrvvUBA1Zc1OJyoMTYlW7dOa0FsNLy0inQ18PGfarI08R4B85J6u9O3v
R7UiSdz9d4UPPHqzjoK34M5APkutCmbbMC5tTz2OK+9yPKzOkadnMc0gitqb2TB+NHSuluwcqnF/
cb9stvflmo292ovZ1OMijDOXmuqaladzzvP4NGwYBMUWX+8XrF9nUFzWJrNopMbi3kb5ZDQ6EZWV
9UtKo811Mq8cOBrZ0ZsdpSDuXA0xqRem1yN8To9DsSYBTAe2Tazzz5yKdj2lloMu6qzAogf0Wuj2
vnz44jpvsITaAsYWhW4xxy+ZQeBGnkH+B2Hri0PXyvstArCfpsCddXwSkTAOfptmfEtPgpR4/pjF
fCQd9SvHM6igC5GI9yzpuKErXArvdCmMshB9pOt5qbxybdCUWIMv8Up/Wi/lUQV2oeTeiSz7exXe
VFfO7PN54ErLcey9mxAMSk1kfx2RH/WBB0D30mctIFJiHFRvpGY3Foe1H8eJINjTs0bkHRdd8y5r
HKvN6y2yvs1Vt41O18/PB3Ylr2AZCqp8CIkZW/9YTCbVrhO0RRwsLzflrTA0zMu7l+nk5PaYttFr
EsGTvadbuX8gcEGn4Ojp3nB3HkcbJT/4n/oH03ao/NcF0svI4D/8f8buwczly3qTTKaxkM161WIu
63uv3W==