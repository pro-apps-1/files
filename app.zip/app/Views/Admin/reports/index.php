<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+k755FDD+raY5k1S1Khqbf+Meoj6jx8yyLiT2H1fyJj8T1Ftjb0VSx3xqioagtojvDyjSjd
ZBzupZA/7nRASMi9Ebuv1XFEk4X7lMDRkhu7ALyrm1ZmZiL3CQF7049CgYBlYbnQH9aR+7fu0rXU
pLumMCc47qEegfs7b49CgA2SU0CL3/yqe4j8WFzLdMgHLHQPD8UW0avx5CuIFuZ5XI43HTCYWHYy
9Anbu93Co4uHtasozGawAIHfmzVKiBXo9X9eiBwWm7ezVyeNcVDbdJI9JwGCP2v55ZMi12wnLkA5
eaOt0DSL8qODMWySR+MPSShVlu6QkPkW9X5597f6b0Yh9i0LsKWZ9If9S4EljaxQZr3wMoGg36i+
ONZ1qlk7NzJFNxRxaKjsSs/+EccRqJ942vBx6/5qh4sScONcufRw8M6GewzzYobTLa8Do1BILjaz
be8fsCWlSBi63jkmDoOaWGOZ70iNEYj6jT/NRY8Ca5FgMoxIroopntwRxUNykdeMDXtK+0Jbe/8L
O0M+ftWYRknYSsfpU92fd72R5MN2mxxaYiSm120X2rGFoPpvXJvirRKUTeygNA+NQe28FITxGpqR
CFsGaqAYhglTXGcJPyqBOztxfP4Hq68InT7c9Kg0l9rbqdHYjNobCRfkuvePClKEj/m4WtcEQOoP
OB3BtF44se8onaq1n9fKULnRTxXdL27LlaG9MFAEyqFQduK1xcZCZCUO2TiAWsQ2RDNB2HZvp0mN
/mbW0Bc/IhkOrEcq7BI+NP4fGrC/QfYlPreXckMtNuaWGcqug2DNKAGZQnQ3zmz64N7hZNxll6KQ
+ftxkspQR5+86kohNAqsuQZoOVQH7dfLqFiR2TMFjvGG24k0zyl3pQdvScBwPjU2hWr9zX9JNBKB
WTh5ojdYcaTJV/Y6y3fRPmYZYLESyW/ZMw532ODXbEDA+g0svuvKU28Fatjfw1hcvvtl3Dh8HIo0
rbkfipfngwmdNNYaXNU3yKm0zXPNPPhOu673B1Ld1eGgRXnEau8QdwXzNxzyG6nsasPvJcJpmnzs
pYsGtXxqeJJ2sTioDAUTSugi4MjyKCS7RmYm9dA6E+RGrbuEVO+FGjd3kKKK2aCtu/QRawellZZm
DzTavFYRwZIy6gK6W7o77eP/J+RtZrFokts7qPcetjcYvSI0egwKkpfBiZwrC0IQ3Bx2iOFIZGhE
bNOJ0KkORJ1QlAQYeopgZd9/J7utAq/KkGi6ysV0Z70gEb04rAhFq5J707GJUwN1QfJqA7EeSlEv
gMmDmTAGS0T7mVV6rR7elg22U8Ct/24nynKviIh24QhX5JWh/y5TSGXL8vi9uSqHBiCMPKKp1Hya
l+/aPutaUDLqwhncrjYg/idgNy+i2bwvncVdwbkjoc+iGdFWMjndPyclBh89pV+LJofVj3Aqsxsl
Nj088MdZK4y8YoR6dIvEwFzwWPFr++gDXCIEWm33oj3wPhrHovInTgfxRsWs5UOZaNew460abfIB
CNU1Dpj/UK9WEyPO3FMdu1baFPtfxL0A8siNeeCNO1vcC0r42/ihcbfpSiHK4hz2G23Q18AvqF1G
3YvhZoI0uXf4XNjjVIOJ8iw2DcEPnyzCrM0vJnIg08ptqTp/ZWBA5G5+lqRVceSI9+hCAINi4xhK
QLos/yi0S9TsYmc0PD1a7rD4bAmJ/mL5GMW9uanuO/C1+CtSk9p5Ou3rp25nbSRyYYR/s1uBxvjk
LLAfg/CzP/t+A65gDt51/QWFpxAmgAuaLC+iH978fccK1K2ERqKPz22tUXBT836mkDIBowxxiZAF
5Nl4Vgpy7gVl9q5uD0ObYrwAp5TrXtqN9pZ1xzn/RtXl3Lc6o8y48IeRpJepzp+O6FH7RbDiKjca
dmxRO4n7vqVhqaItDSnTKY/VNXmokio9T1Y5wBP64ULThGugsPjIH/zf7LSQ0m8l50ZL25ygh5KC
epsyJga7fniaXx6zWzoxB772kkoKf1xmjRwoR+FESOW2mFnll9amtEvg67u2dmNGr0eoGxeYPSUy
TR7Iv/N3mm1Z/2X3kVi1oO/HFfySjMKTw/0tM6lL8bBni43rFnKwVE8+O42Ahn1+m0/1xkE5rByn
hMy2ZusyizLdLyaM0XqpJ46Mwi4ErnsJhMYNwh4tURcPFUV0aZHuIVCgxwCQGpBJWqAhRYppvq/q
/sgDGjQMyxyaLd56Hcs6dnYS6PinVRSN8An9A4j89H9llXpjY81bb6mjirzuNxOdP0sqiXdy8RSt
Z1Nga7TOJRWYk4VT934aNEmKPmUnvZcuN3J6HDTBnLK5SF1Y3sHpcq7cZvwg7henfrh4FOUCX2/G
bbS+vPSJbO5Ah6hCEhFn8zP4wVIBuqCr0EXN10ZNwy9J1MKgAOHxI1ZSnS1nsA++kaMfghGiy2dj
Fwis7/MJcVUbHHHqNG==