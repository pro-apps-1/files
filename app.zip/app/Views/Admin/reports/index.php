<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrI6LUT2MQx86qN0nDKQOSfttTdQM1iYv/GVEbsXl1it3L7EX17+zHkY50eAmk5NBeJ/PD6f
mcqDyPcOYZvWi/uiZQLj+AMJJTX35XHHPb9RQwOmU2L3StBk4O0aurHQvVy7rDBvsoP3d9fdZFfL
KPQcqQlM8CtQjHhXomLukfrSd7Rm3wFYSyuOG1Hzqfp4CeL9rODZnEjTHlxh4uteusTnQ2OxGutA
7eS7cSG4iw3D41lkSZgpvhDb6WHJ82QJTUpMVlPx4aPphoX2ab64hzVSx7lYQcCMI054sss2+vz8
zaab7lz/xi89hw6m9wftuYettp1jBBmuGRS40Zs5jzQn7tF5l5+Xb1SEZF8VdAuk8NLmuw0b92lK
3VhgB8+6UiNDk5WGALxnH+lAWz+QEnMlBrL0jtyirFKzKbacwoYMpVOCxfaSBuYtvWZTrAkZn8N4
f+VJYKklosU0Pxx8VfWGqLnB/71Mqrd02YKuJkrfYBDXEqMbU5LuLVYG7OskVh+9z13/65+YZRAc
IsM6U84A409JPHrkMsSrY3R8fhO9BiPOaPQrRO7UPMPglQkh0PybFo5aZqdKtZh/6zZvHKcJYmfA
OL+tj4marSOUuKmz4/gAuaUIkpqhJ8qrI2d8AlBnkn4U/xSEFKKKsdeSd0olEy5ukG+CqZJqk48B
nw1lHO2AwpOA473uIPRo2y6iSPRtmw3SXjKLWWeihmMaSkVIOcv1GnXhgo5SSuPbHoJI2qEnMe/y
Q1Q9FbiFOzqfU2cTCfrsnEDBL/7uzilA/LU5C4zPVmYOXZxgG5+jli/b3uvrZcdn6zFxbhCnKn6e
jl5oJT34ptEZkg+tyXH3ficRKLCx3jbxQaQhBujFhSbcawwcM5317IUK0or4CXx960Wb453NrkGK
riQdj7GZansYxTWNSzko5yvTkaFMtV8lQ5zg5wXJ6PY8QFPZ7IoJ4SdY/jdRVLtzPTf0SNK3zs3r
0yYyxI5ejY+ZWDLWCUVAGWrjhrPc9l1vyczytyZPyCkixUY8PUqhewTQslSCSpg9hq3iA2K4PRgF
xcBzpQZ7qb+AV2AoYcY+ueJOsd24MILuRS55IxjY8rd0SYPKZQZpdmJPXrMYLDEivD65HPo1or+M
VOiUw7udj8Msc0T+5XaS9p1E41vLtQESIj7SE1il5XR2dPXzZd6yfZ6N3kDFWosuNhGgOzZHaMJR
MWjqBdZ46wYbDMeHxd8+aVbhaDbW6LcHy8whLkNeaDa/RtiVR69Wfn+KLRaIqxysVUx+m1jOy7bu
yqEwj1Hc5cDgzkN8knJTdLCTksGiJ5dHd2vapd9JAu9jAXy1TVBwR/ynKl93H8aEjEaQjns5+AK7
8TEIb428OotQnucuyk00gANuOusaE9jHFNdxdU2/ZdTDAsm79xSYxMNWHLPcsKvKC/11msWcUEn1
t/PO77tS/USvhhzxrZt1ppMFa61jhcZp1XmtEIUE2dvZResbiD+OUINasJ6DKmNU/+wsW0DWrb/t
FcEBEQ7Z0ZuN23b1LkRrfc+bes+Nxzstd/SFfQ2tKEF7P770x6NNCI+Dx5ui6O7DsurQbJsgvKWx
8BRbTwaFQ4YdsJjqSDfZAENHgEKjbIqqlgUiv6mbCOzzPO+MTTemyJMJto5/E3ZHx8UfT9Nb8Woc
HwOrdURRFR6/BI5QZbQE4zLBAj0qjW0LeciaW8YJmKQpmxfe5v/0ntSsPcyeIzM0KnbwImgJvjGl
80qfVMQANHnqbIGRdM0TGpK4M/VGUTbckbFXOZO2Tnwsh+wfm745WklSxv7yzjMzRYgDpNfJeQHN
9b3OwbfB97wglAs+HUzyylt+NvTfJ+BfGOxdcWx3Zt8PQWo9bNybgFYQqX5mBsM4afSucw53dvYp
QESU775293AWpgEyeI05mMgcvgC5Qj3r2oPX6qmw+PF2V+SnDlbP6QlbxmfNcvmXPhyewE3L+8H3
PXg+H/3tIvMpCMsfVyPUD14CJTeT+YBl3yaS6eUuSJ40tb3QqLQAgc/jN0u5kP1Aen+jb8YqXW==