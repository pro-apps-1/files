<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwqD5r8CpUjboT62SKnswlS1NAto0lnVTxIurFqiHBjGePxh5EOWjSkhg2NzsYGHGe1XusHr
3shQWUcZhvu4vHe5XEsey/LIt39tvs2w8flpDnpow7lLZEOpwOdD5mcpbCCXcZzY7kJK0gRVsj5+
nzL3ha2/H/R9hyF8dp+Vh4fpXkq3hEJsUmxMO8J1VkFUdSzsGjC1t5DuhNFCZDYu9PFsFz5DHCTV
YMLGRgFa/5sfKEBw5prsuMloDWoqJk5OWe9BBFA8EKV1kGqKsfbxMrk61HboRes/j/Azv5CB1Xxt
sQKV/s58WQeaElqYs5PHepHIb5EwvIkm7Cp6oVvbWitWvwys5q8CbbVgpaG/qn4diOSmhguZRexP
7SAir8Pk45z/CexH1DsdwJyxm9HjuYQNYuendaPIJC9trLMHU25ZNigm2qfrmqK7zeJbDjalyVrC
ag20CYm0vPv0fK8ooOOuAUB4oTfQsind541MPUPBykQay+aA6lYHsqVYZC7QQrJ7YL1fX/mzePPo
zzBCdNH3Jhy5frB6F/kNVXSE1gXtdqvfLwbUavZqMPxxOq/dU78VvWyR0jI+W/Ob+Vc8HeIjSzxc
qeAXb8ZDvK/Hy51MfinCNrivoWruD6qMjAJtN4R6WdqjQ8c8nRSnOjfEyEupJ5x5OI3InSDSvKTw
m8wxsx8JBj2JB15jZBbYCv12NoUHdIT1qHz9fOU8rDRW2Rilv10C+FOoG1EK5VnzfjjnJ/+Mwu8i
2XEv4XNwEXU0FXOOa0ZclQ/zB7oQFdtF+k1kZpzkpZ4Pk9XcKmulmLUw2NeSpgsRYp4DrdLPbARh
c5ZWZslHUgof/+31p+TrS3bKSV1lUIQDGcfYMX85jQezChsBn94WtX6dm9ZhfjzZSBeeHEgnPxL2
TeqIMHD7d9G1x2r8AXjVcZHbmx+05bm5rPjCKCRNEXOeUo7+JDVcP5d8k9w8mTOMHxcflBh6psCK
VVtEP4Kg7zJ4As+E06Cg7gqDHT7G4xBd5FdkfG3eV/YugIW05Fykf/rkswZ+9i1lCoWtzwLhg0xY
lr4vaJxtbbnjBNPkbvBlYwDCNRL1g5s+JDVQ6QM8zNu/7nG3I4u2VSDs1ngMU+/KUQASAtaiFirU
g9cqHZcqylkdovO1AfHSUTuK35OQEe/7cB2MTs2g7Z5BOWoht2Z+dPzD64sGbzGlxPrYrUzX1MS4
mDUZvj2OLQyXOosNH35zFlOjJ9DmYKN6gh1/TPD04YoPUGtTtC5AbP352QNqU5Ur7fz8J2fvmxeI
n7iSPmzgPP7b8FByrjhP0SXUS4rccX/WrMxrriDrRFcOLThCvk5QPrPXkW1JxhU1vF3DIQsfYLQe
ULHaVoLZJD5M6pbL95RcTS9fqkke2eEBYIEc7s/vlxwbQiylX0ly7n97VBQvbYaTwyWDJtrwM/aN
+v70SCnEc583+uNJDpTdLuAfCpBtSFbbJHjrr++QinULbSvJ/UXxRIeNpsNMnNVMR1dYcWzXD6JZ
Yl+TYkTLHhKR6EO3D2aek6Va0FHA2jyqBM+5Dfk76i9PnD29JZe+xf3SMDQcx5aD/fM2rN2tk9pJ
YvnSzT2O0pJEVpSbmwcCkGZ/emzamBAXbei1N6PBnSkpjNZ314RVOwd+u16AKo1LhjfXlibeyn5u
Dm0gNf88Vhz/ZFgN91u186dtNfH9wDoPI/OTAwTuh7cnLRL9/TZbDlsg+1/eazgIuBM97/9QPDaB
9Ky6NMm3l967PIyCo2saHbgWD2ubTk/Y1ICGlmLKUwb2aW+Y5kGjbp6NYewHh4NkT+Bw59Ap3uXT
KLIreg7ZDva2ZQsEpVIWBSLMIJgKZ9wwOyHv8+l4J2Mg8vncROsLn9US7CEQKBhSDVxDeFVC0e9J
H7F0N2KnVKrRGTFTeCyzqsEP7Y82YA0WUIAXAiDsZtTEVr176ZwrinoFG902ee5V/cqDuoyNwIdO
GM2vdopIjdkWHU5hdt/4qQ37iFhyIS5NlfqAmtOx1i2Q7YWx+8aH0GUsn3UOtCqKG3DQ48gLNM6k
TqtWsznm2excL5eiscfoCWTpcCljTeHBM1hj03NEIcmCYKJPWo5/mi+9dhY0EY+IoskMQdb15wSj
VeRy2NCMTCpVtn4ntBW7An7acikcaE1QQ42/vqjqyBzlTuEWS/KLOLOZNYizSx9iZS6PTY8QPWOl
/RvtXhrEN0AWT5uEs+C3UQIvjo14voCH59s5ZpZDCntbIuvR+OsGYW3RnpV7tbcrk64F5gvkIGX7
J6S+uLGPqXq6qHyhdb8BroCNQG8gWEMF8rahK4GQ7OeUhOQQP3swdQ9/SoZ5Y7LZwzun8T/aEHSP
f6NNd34Xvb5fyC3AJ9cJE0ne7mfWfWY/Gh5772jv7mRtQBGO8O08R1e1Abqz5UAMXi5zstnJpPRX
LUKNu6IaJn73j0==