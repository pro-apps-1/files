<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz6idEPEBMN95t49nKRJMF68+s0mchhU6lD0jrEvaYI6qgSblCNF/6tv57gsWY9xfwiMlkDU
TCa/ZUtAECFE6tDDoT/KkrMK4/TvEMbD32mZ5w3WkXxbHBKCrzOhPsHhjf5cGMpsFYLWTi9t4acs
lmDgyyQYLhFV0XOvh9tUiaaOODmAhLbYIATBCmstHZev3dxzx7244EGvhV71Kwfz5RlBVZxptvxC
FWQCTaWLaIClkI1kByJZLT49OCEmshI43PjZvIdhwMaNNktOwC5KGvGCzMozW6kiJ5zjrRAbUfna
s1OlDIF/sHquK1qlBZfOEqKX8Kh6HsGmlKSgjCrOfqL0EUPj/1HBt5tnfbypKpGJNemCKIyNfKix
1VjFPYYUhUzfF+jYzIg7X60+W8EygTNzZchZHm7y95S0aRRNJZ/9Ebf1fJ1ethRxo9NssRrLLu10
d4FerfDNWbKk7KAMhPyNkqMXTJqvW8noUeECNllWPE0p7RO3Q9PihM+lir+NeNwJ3wafvFk2fG/l
hLgKG5+10K8YaodpkCW/VFO6fsE/Ga7axg1xWdujA2ATWajdJLi0EsxKN/rF0Ruv9yxlYGC878Y9
MQyL0dBt2yyXaOfZrUjQG1wrChk2rB/hkFbhM7E6Um8ZU//vRkW/yPUqBbQk7YFLdA6SA6KCRf5J
wD7wyOxlc/HWC6Yfsy/cV8vvVbaTqARgWOPPOeKqltdgWSrvFRoEE4L8vGmc7OSba1IUZ+FjQcat
uG793KUNogJC90tdVJNcMJQYd8AFGx3X81wSe5QWJZfB1fX9RIeS5wmUd9SWrMwLzQic2gn6UVTO
v28CiinRUt/6jYXD6tPTpIaUtxUz1q+DAXb2jGnlXhBpo0FswzJXUh0Pth1RBsFA+IOMlyAkg/qx
Yz14U9rn3+7yuAjfCM98gHc9d9RrDHykhS0RijBm+RcOPiT9rPC7OaBWseuoB/hrr53chxvegwjI
Pw3V6WOUDemfPb74J0gbjamBYNgNgVA28MX3taKFwrG4V+suzXXDt9OdH4y7oUkbdrDfUv34rGfX
+vR/tvvB8Qy+dYk2NUynKbIPLncoYNcfBjlMptSua0h8f8oDmZ1R5aG02ebHl5vR/XBi9Kcv5Sqn
GDBu5t6zgnMmX+zxk0dUZC5PfyTULnmpy8lF8aMxcv5tEwXJllX58tYkHkk/U6qF1wJwEkeEarna
do5ihP3WvOxymLpsO4BDdGGaIGmQpkGu4qd9VL1M23rM/QRl6yolMc2qJMIHnXm7LUo8yQ/DruO2
ur9DlAW3itsTikrTWILG6FeihFjXbt70lrNMbeTnLoEgvl9CmyRSecE8eYZv8/6Fw9tj96R88Pff
RRn4ZBVVC8Bm0A2NHm4iwTxHNxw9gIWUuqntv6o0kprgjEYfbnYFdYEV2g18HlS9dcS2KM+fAE+k
XtzT2JAZMZ6cwScP4V0ewpHl1cywv6jGKtGwGe1Enj+67Qd7SKCgGb9H0brKaee9Z6eWQW3vPIHi
s/39Dakg8ODWVtO6q+Y9CEAoA39h40DaFYjU97Gpe1xXwUNE2GiWU5h/kX3ilRWhznEZ26PMV2gh
8LpvXg5HK4X//seERtBHBJOEozsdNPS476NhQORmANwy+bgqttNl+J5J4VoipWvfn/KMXO9dUaZ5
oHx/Cd5I22QUpDq2FOaPLWW88hWqJ68uSvQm1FP9AsFPlhXpVhcKulktDgK5e0POvt1VMelvNjBV
NN5v7FzupwQyZDEh2IIJSTMFJbD9hzAf2ljKrqtu34Pl8NMAHhYlVuxLMHdN9PMEl9cTgaCaL6ql
78u1T9bnFjiLekB+3BV1f14rD3hoblg8Z0n7szvEichD2tEawDpSLRmlPe2vxdT1VEuzlUuXXxct
66VJJc+fWXFm6ewU/eiGY/lY0sbP1I/2T7Fda1URzFqmzLHlFXJIrL+qxDKv+laFvBh2ZC8nV36x
lvYsYdM3kpPM1MI6qbVyjeOYDDsLwzyhtWeA29G1BlgxSGJI6NFoOKtLxsQQ63f1Jfuc7GW0Tzxz
ZCUrnKRBfUIriAdx9Q8dCAvxCNoBZ12VvsdwxRZga5XsfYo2+Xbs/P/keH//fG0osICmI9iXoLft
WGckVUNcRc2AsR1t1O4HY15shrZPLdkPyxnFdCa6YO7xGbJrD5EQRFKf5mgKG9/1LdYSChCu1wVy
rIGKKx/a4vv2H5s5/Qv1sILwZUcIPwE873d1lL1JeenJl7qQNWx1UDkatiYwao0ZYb4XtWI85cQv
rHBnyBSc0wFJKcIvUphve1n5TncGg8bmfEyk/eQ8JVD/YZhqAaJDbnDTSktsot99XkVjCKBl7dNF
nkEVmdGLP0ffAwYtowx1l6kFHQP5m6PtWneS6iV/ISBFoiIInaeMI9ByxrcxTCL2DQPycEDx1aHA
uCJv0PZtaOqwgQPFfM2e6NhvT6WvolBMWQT8/ak8FbVlzkEvSBisx1wAzvnb5yJiqhwdtByw99Zj
dC/mG9JR4J9O4b5EaILcPiMAvuDVHmJN/BBbtyZv4RMYQEklQvBmzcI6iiTCJUm=