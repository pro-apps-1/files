<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt7mm06ZOJaskYrL8diCFbKfi+SjgGGn8BIuLxMArfTHAyb6yY1YCLLXLYQrmvkGkUMoOXGl
vUS6y4fNeFrUwgrsAnPjVAMoIyytdopbc0+/ppJwlw6NszGv1FYA4u8JUvXNG89pt/HrKEB0fbnZ
/QxMNkNBOaq2dRDB8KIGg4K3Kg6/VpD7PM0fTCdeFSEjUSmat18dJI1KyejLCEC2WO7Np9w2vwmF
3RvGSv5A7fUKCLUThh4I/QnG+VxCZWqnK5iCnc82gkQCyqV2yCGmDldWe2HevTZaUMtolHn8L93S
q4TI/orLcIMaUmZt0ZEXp+896dWAfOF0pmkfHLDp3WdAPO1E0/HcZieVJv84xLZoQmFegmuAAoDn
ZS2DH8jxDRs5oP/QIqo7DEiQvnSfxmfXCOhr5Z0Q1PxbXJ7hBx39hn0PXNDai+1vz58F3D6nSMV0
4CBGuMzT7dmovq7p8FoxtYQ4ktVqMQYuwelyPpWim/VWf0+BgpIx+GBvhV4I5TxI+fVLn7AeoRjp
HsUlaWfzM4xZsjB3IlmV+2SgBaMmG1p3UfJ6387OKOVIS9Lis3DW5kwqOQx4ApzecvkD4/kWgDYR
AGV54+QRKUZVOkXCrCsCfvmkCMtfN33Ua6shZLYAp441N86O5Vs9COEwh544cOkJXed/dmeWpFea
OuJlbG7yeLzMKxCr3pVsjZ0Gman5y9xjBG+gDwtiNRMxZWQwcH6zfNPDWt+1uWwpNruvXA7YJk8r
KHvjUqZbyoS4SfDyQzjo2F4CvKjJmPW55ZNHilGrtZ6Rosdm27xkTYDJV9sduEZr5YlOHwf/1myn
qc1mZ/GBPKiDxZy5GOxJxe4B4Vo+GPFf+iKG5j1cPa2NZD9LMrtJ8lzT4uf6ySAorV5ag7w26Ost
NDy/86V3GElSrMD8hAfmYUzz/UbfAJLiOh106pyem8GKO6JPiAEyqZNo9bnFSzo1Coec9WtQNp+P
n07+RY2m9lz+dIWQ9CDEBLaZ1CVBB+6l169taNCQbWDaJND9bUG+QHTkKSOhTk0TC5Ue+hYU0hdJ
B8mFx2dkgqQiVGYMbkjjNM0/sNOI7HyoYcsF/P5NNUG/xc/eaq15ahrLgw7OdxbC/UbFSLxqIjHf
SgZ8E13+6u2O7FqNvohrf8KOluNAveASwn0r0IyCUejYu33bAcSjM8arXbHSNrmEfWA0VdoaPxY8
SGsnDXw1VjER20MOerkcvFTTN8o8JjOf5X1MlaKLs47VK93y1BeDGk4FaxqlGDOratZLqcHyILMU
A7NSX6bM5mpOXCdLSi6QyswFuMPrtGORZ5TcWJwLSKoq2EG4/+ndKPY4Q0QccQcq0hqBVkDb6BFR
ZfoCeUtJFobkH1gT4NmPRzRxlfCxK0cEmL1jRjsEM1lnVQijedJMn2zxxi29Hs9UZQs6Wu/49b8a
lG3ljM7doCuViBmSov9joTb7JogrNWDkDGJCLgPoDZxSBiNasxfuP8OSD5H6oNeayqsMNmwT7p/N
jWSmguTxslkSOZN+7OU2a/hosKdiUhXFa2RfnaSbnjnOBs/ba3JWFe61zX2QpJGKtvw/jg3SpHnu
q56RM3CNLPmb81r6R8eU0fLHFhA0cbhHbZ+dfKEYZvdAHcvjktiKSAWc9wQjNJQTo/e1IqPOdwaR
yFXA8SvH0cSlAQDhsoXuO9ks+hVTCENePTLUjynVtqTWCJka/5JFISPp9oZy/HFW5+6MWmK9T5+7
XnoBlQG5sUnCAvh4JFmt7qbtZuflK3qoa3O8aXnZrH0i2AwAgliiEa5z1mnnB8BKo8lzhTcfQqT9
UvWafcMxOmkO4+C3emvtQ3OLZ7CzECZilSw25SLRXnf94tl8+U777T9uSakFfN7IfYqdqDnkdDgX
YUPoShXCZzIVowROtY3BA6wRkeDWu3KUBqgdLPpTGKCbQO2S0Pndi4CF267SpfuPril6geEdcmGb
DpHFE95OPLGiLMJBU1oq64lCK54+Jhf63TGEy5OF/IxhG+hA+DorTmVnDVyTIcA9QGKVfgQc6d2i
xngCZQ/zypN5lfRhomf4PqCV1qL0FvsCFYLlTHUPyoO+EAnPcwoJOsWOG7jjoirf4rX8TevUXNNG
GKOBJzjm0jOmpwmginNqRc9FUtrFDU5gMDhGFOiPxKsUIcs+Jx4LnmLfddQHnz/UNmXdagPy0d+X
I9uOf9KareSge34Yr8UnQYRrik+gIlg+/A26A/nFieABBNr6y+e0kEE5ByjyURfMyz3ktAiM8ySS
2goCZf3xpmSBAIRP2xsHwQ/bOphJDeUgofoQ+gOirUK7WJWbNqdazpQS7cuLvY+AnGwCx91VsA/u
QKq+Mu7xc3q5M+XK2GalYIEbGtzw89c91NI5l7fTTiUP9Z2iHrNPEazZpTTZnY4gEvkZv+ZsUj7C
ByHLKCEMJ58r2EMyq81mzqogFmQKuZ+eVxwL11s9KdTMxSA/ftqglV6S3tD+QdyqH9LrSWhixnzg
Y5MSuCLUDp6+DnO+QebHz7vX1J7V+qxw47CuRGYldUp6MDDJ3w4KidetkgK=