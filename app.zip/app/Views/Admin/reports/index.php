<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+d2G8l6SBcidnxLg8J6XIjSCFh+uywhMh2uAZchLdIS2sDlKNdEvuNTgNd7L5s//N4TXGJb
VUjb9fJ6YkQzZlPCqOUR8sR+YKvi9p8zPPmnkcaEanxiBARItMkojMSWJU/Ecg04lB7YKZSd02KC
r4LfzVVV5Kh9sd+0G1VOMxNuhPk4MEheHob/zz2WvWJuhAtzVmhBf3/b+evKHiQv5iRFICQnQ2bs
alFkhQgcmE/8Y9Fs4wBY8S8EumwdROR/kRKxXQMm8g4wBvT9zN6ty5LBgf9p14yigV3ZbfqC7LnC
itWouQrlvw2DrKYt2MWkUwDkpJwCLgINOnVoXPxG4FEadfsrfg4FMlYFlb21W7SDgS4k4e2kXdqz
hmSEVT8XDg/2CdXizkXCcIhEmsOXc+33PqXLntLrzPmLB5wNW5wHuTW4iSI1avmuVTv/5j4C/dwm
eu72ZrYofl/+th2Gpovsyi0oP9wR2CcrFmXxkOpl1C5EIGKXi+UCXj1lx/Z/QNHQacvErv11fVJ6
KbRguWg6L9oZw3+7VPG0EQ3oGFfOWHr9RBU5lbgN72APopSBSv9paXB1ZuYe3nYkxJODijjd1zz/
/vAzHnq1eKb3my5XUcjgHpfb8OzHSEA51wqvk39slF7RgmTKHZQeSAz3Lb6yHfqItzmJiFOPNNMO
GVuQsBBmmXEV3Eu0S63ki3i+rXdaXwotTKL3dpCFx3j5JdK4uYn5AJwW8vcIIiLcbJLgq5uhQHdh
teC+u5+FXsungd4a65LFQAL1ubE6LfavrDn03GKYIrQrmlE1PsbNH6pCfAf+eCNanZRtsXVnuzRq
M88OcmfdAEwtnDjp1TZTMM9Y9H5Uv3J4QuFfKUWw6gsm/S8RIh0nkwjp1DrjISYUjyacDtV/vB1Q
2Z/D8XealAgioTVkGTQXw/v2jQzhsnTI6C75zrkqyS8c8lL4uFvAcIQcQPqClYy+g0uk1HDtA4Wq
3GPzJ8zXHbtVTZb7iFTcUVdk1Ys73YoXd42JpGxhTX3MWbIT+m8b5OHcLddTklMdP42E7K85CI3G
fvMoUJ4KduPXGLgMmsV5zaNbtU/lGoW26NZQrmhi+5NZ9yjKa/TQMqw7GKbiLk8Nu9AWwNJAkzU+
XPf+zsZAVT7p5zbZq6KkpJGwOOdKRAIOeg1PZyBKg5PiYotrxcqiGCuuYR2aRwLRJxolw48mdtam
97nRbYB+xcEhDqoPsGzQIzRISD92pFhRAPvx9BmwTYxJ64gf2CLG9zSbr7e0wL6bVwthsN9SP3HC
kE+R9qdqkY1FduAURWHiVOyhJ+axdLDNuQ/iekaNgw+nxmAuNrzFwZ9yE5osORRPSFya42CCgNpV
cJJGYx80RztsDYoGrlcRqPCmNXHme6H4h/F1yMmVcZEDi2LJDzJyv/34dBWQnanYVlLyWjd7bjCH
r7JmcN+SBvR+X5GbbIxMaFAcqSlzlpVr/rXzcmdHs3UJwFvM1NQ43WGPmV/0CVGmXCe9Msfyonv/
urDGBEfj32N3I0mr+428OBgzk1BLt72RmwV4lkjZkqhiG3Q3jqw9M1zbhb43cRK0nFzm9iKU5WUX
zNehVtai4GXjWvKbK5V3ofAQRBgtz+BYljx8WOyff6N23BSopBpvRsfgVcyHFQOe9tEPaW8H9Rqc
hOUbc+AbS2qYnnK3wfvsbMPeBU04qlEqKZfnBurbyCI2ISQ9fEzUezNAMmtZMj7YXS8l/8gDqNDZ
vIIV0PfTvYTCIwDUqUd//HmeJOvl/RG5y3US91Jf4xV24dtmVGyi3gnxexpWwIbU7WA7ec4aLKAy
ayky6PrWUIU67pD3ndo31FUFg6I7B9m3+y22cu95usgtC/0ITySYLkUpEsYsYllcXUw/LY1HzmOP
5miCCuNGgibdA+jt4Ht/gUl4KnUkQPDnO58qvtRpePLHumw86vCzgso+fltk9Dvh/xG7v44eccag
wyxj/b3IUZDsfwbJS0gWAAdwLtuWGEVlsX7bsGZKOkME6kzGlyvKkmFE2T7Mc2u4hByx5V/yHklS
+S6ZQRbr+ooiVY2gQSSGEK0qnJtVEc4T2+sEXypw3c60I++rDJANHAqu/M8diqo6NYGeiKy57IvR
gB9VAAF69bRdI/+AYvXdvEBLEK2QbJgU1s2OAzDOSB3K6Sm/fTwVISUQNYKhhLlxMFhAWRX6yeaq
IBPptvuzKFOVFMABUsyzC/s+rRZcsbvK2C72+X0XBQH7NABJKA3qlZ1NYaCWhjwNpZh2OueAoZl3
7L+0TWgUK6U6Z/n9WjyMTyh5hxMDvWaTC3qdMl3uDt7ki08xfegw7mDXd8VVRMXqVmiq0586Qs83
f3CE37CYCB0Sgn7Fs1Xse58c1ldJoELN4mhqUfzy8eVCeVL2A3RrW2heG6AvGXeOFG==