<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsYnycfx8STD0crdIK93wt9491nidheSw/a/NkVZaoilKQlgoY09r24+6YV99Ixzja2CzagK
t8x8hZhZfaWea09X9+iLqvyGatSkzDCaoF+5AC9tCt3xpXmikNYPA6NMYoaOE0+AYeI3C76k+yfS
dRmdpg03xWcNSnb4oMw8nW80Ocf9bzBL327NtR7bp5Ej884ETfFUhL7Kn6BdYffYTugdu7OkWlW7
DqT4hRr2L+vGpLzZlgd3tXxklU4w/BFUQMtnxYeADpHZv1ITmSJY4lsWpyEWQYX85XWgphHt/C/c
KfkN4JuF4U5VBC8FmcVBfns0UmQ69/sFZcZ4RKrGrgP+FM0eA5riFh5IlxZAOe9VwkfzIw83K4EB
2I0LETwSlhTsRP53A4/kb3NdI2JrLOd9XSaHQIqc+gEz/RY+ay94fivXYCXgcV6guqN3d2hyzQcH
TjVet4lkSeCWtYnDCMXJvbEnWRShm6F6ybCN9m61kqiIqvcZY19rS1s3GuTMb9aSW73UZn1EuSnX
XpjJdg1ZNSg+bk1rOtX335TqBEzGBY4ZadqvRIjxzLhlgXFcl13nje1WO+6SAKvnqpZ8p2yj57ZH
AcYOJ6HQrDTPznpqC7iVWjZav/vTme/FIzJ+QeO3+dRJKqLrAbzg/tdWRBXStKf6qWfsduFh0256
tKFBmpu0/1umBtOMT5WHTyLWTc7Q5QlzY+O4jfdYTQjRgdfciTcu/WBPv/yXLvjpjvObNx6aTw76
MS9npefZJ3yIJyBSISlmMyqfU5/Ejh7WrqLzdovyZa+wlYTRHXCHr8TlkwgUOzRMHlDEm2n7GiAc
k4j1mwsMsbUxL4zZS8QUVH5dmwqQEf+/BD71ga51UjQnJSeg+LjdqJRq3EGW1jJlL0eCUNCBYMdV
QWyqVanOj2lvL11McB353f3KTsv4GmG1+8RKvzQvM0Wv2h+642cuC927HXhDEZzwEvSBnqX2Sknl
FnYYlecB+rcwQY9B4yKVcW22g/8v8Eo75gpxrF9xhoGPH0lSAoo5QB67easYDVDIzYYr7Edpz4Vp
hCRJt2KARzh3wdLr/rzmDH3LQrNEG1CoAPPcvHdaWj8jiuJMiZsH2rkTW9Q8QebcOQaUd/J5hV45
r3Ayv3fvEgvcOT+3YZq//1uaUzTdDh1VCag/CmTd2zILtp6037ZEiTDE+NEG4y+UFfeTQ0HGE4g3
O3rxfrQY/6+a2hfLHzf1BOhj7dRYm2JUSAqQvEN5KzGSOYclQh0c/EXWqOP+sWQgAYyj7UrndWKX
1fSM6HUvs5S4R0IO1bYQmV4mi7hjXYQRhNIzxjevzEwfRfuXJfB8DdSnR/zSOYl7K7J2W7eiUZDb
6BmGBFEht8nwhcHCPVFJ4ImoKqFZnBsMppLEFezlMoBHXBQ1UFfcEIJYCVo7gilzOmp8IoSuPj19
IyhcUGjQnG8RjLw3PXBKBViUSDiANAme2OqI+JHkc7l1k2PBKJNND3jlwrCTlTc/ajRT/3kAag7j
IdDInk3N/lSGBuCir07BEwUUJZCDCw4v98uMM7oXpr9mw7LjQnrwdmtBFeuLD2p24tZ3YyHgzcaa
cfVj1rgAhi/E4lWO01QhS8cLOx/wfNWW8eePuQBBiOASnx4hDv8S4uNZJbsbHHrax6xPSGfAZmDz
eXsmYTcaS/XBeS4Jk9yHT/Kih/xpB43fva2mw5fq/xFonnvPHUI9Qps6EqEQ/2XyepaWM1WkX1nB
J9zx8uaL8ByM8VTBaY4LNHq6TvYf8ZBbVLrVmTvRYkxIm5KCUxvdbju//u1j7uwMahZ/aQ9lG2A5
icv/qsuWftYS2k/qIBYb0x+2n0bzaNvDXnbhPL90qpARADyToETn5cH4obMDHpOZEPDa6p8Z7Wvx
29hWr+aORWwA45YRw8loVP8vz1c3GDEhrbXMU+suNX0Qmv5O09PL40BIuNrE8lEHUyrlHfnUGbDI
W1rD/+OMRxpzoxfJWgIYD1vIBcxbKr1fH1WE4Nfd/IaPqv0VrEAv53anLdvjU4X9vZ/EwDT0pe2p
g6Ls3lHKG8gIS0RfGAiBWZX7aqv4xtF1U6mIvhA35FkgIqyCueoL6+wMjarfC/Q2wFNR8Os4yT4S
UXdu3W3Nq8Z3NBLWfjdUV3ZQ99g/4Q0vqFOAsqMtmXpTdFe3JbfNVAYUVLkcANFGC8IS4YsavdO1
qpZD8AUXpu/KW4ylAmpS2/LqYChlT2q+bJGgt0tERLOhTjMbm5YDDcyT0mQIIkYvsRUeZUPydv39
w6L+u21h4aN4RJMYzHnfRXtQDOiAAq/PyF9YWI10DizLa1IrM4aYq9OCEEpNfAxWJgePydlmSaz1
U9V5Xh6EQ++6HzFKDqJMzifiSDmlNo63OJM2Rcrtn/axuNv1hxs/2uDyGaOBSKwgb9X8JeQnXBYe
L0ZpNW==