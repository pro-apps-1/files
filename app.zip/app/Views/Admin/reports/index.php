<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwJzum8sVTWrpo5s8IlCpmvoy4TF68JpY+CGZAv3vdP6nr2DrBjVtxPnSTDB+GvqpUvm7c2U
DQwsqZz/U1SvH/b6ASjdeFdqAqpiLzU412erW2bvZS2rdm9JAWE04wn/csEegPpB3zMLOezYd0rP
0RPWslXdRE/6kLipYBaOak1LQGzG2qHb74KZAcs3r13Ih/wUyXHCafOw6z0vPo3ob51i9ify2Mam
Ebaj8xMjWGn4M3O85imqMxYKdLB0fGXJDFQ4aN20/3/QkRkhcBJvk2TodnPx06M2vggm7DS4JFQ6
AykWnmd/tKQxOnfdos5spEt/9s98EPOnDjE6YKa1qqw3E4XDNR90rq29/mxinUUQtsIYPqFhmbuW
S7KZVy1oUGIVE8MGE/yBFSmCaWB2m73vCah1vQHSXSTs1+3P9nJw+uHjdQ+mKBdCV0WpPCNmymxq
tkMe4esxhB/6oeafkUCnn4G+2A47SUMyJSduVgxBC29eBykenH5VBhG1qw+uPFnTRnzjbA3kc2em
map4doa385ggUSQE1o9zHweWqNLbpXPGjWoQYKzYfC4XywraQnl+KjTec71LoogEOveHAgbTKy5E
RJW0gQGASbYeRNdC6868nKDhqTYAn5MyqGf8ttoBkObN2bgW8N39/2PB/aFtIX1Lwd/mcXJjOwGe
nZNXbp5GlwXVkqjCvyfzSWAoYxFSaj8DTahoWTq0N/lQ2CHU+eUbIU3/VJPoBqiNPuA6+cyhThbh
q6UCLKKtAbSADIgA012aquOakuR2bABypoUjpnHxj1eZsPe77r6cbXZ/zJ2ma0HKavWnxBAfcuhm
SprTTmu9qWVh11eVPsMwnMWrgQDWh7sg2A4E0QwB89AxsPrHeGFVZq6gFJ+1ras96QqWKp5+tQtp
ZWUsKvcRwfvVPK5ts9SDai47pi3wH6bQqE4h0RDzAGJa4UVfaaFiamxbJ8lwW2BAybegJtJlKiuY
mt71XwFmf+v9OpvUGYG4swwUTK2lckb71sJSWKCMgJ/6qTs8Gq1jWVVQ8I4n1RTDVFo/QejpkWAl
A5sup9Olji2xrUSvo9y+5/GsXfSkdvTNEp70VdOiAeCiWQW55ZqsPMxbOdtS8wPGo9ehfOacMfj9
zHujlgh0yLpa15MlVq57WPhcPQZPuIXHakA0Jh577V8Bp1wLf1qaprFenYfasPEb7oZiGFrUZAYf
JrBqVpfTwd5+OvKWNDSJOtf+bqT0yL7p34Mr4B0iASijYujk2o4+S22T6DGsciBYs3cRGHybk333
rm4hYs5UqrtSDtL8js6Y/xqoLWq752N3Soz2DAnCURq+lM4HAG2aLtvbHCPD4LEqw4mtpj24k6Yu
eTrfOVtDOmVEkeXSX8TNvwrkz4dj6VFpgpipxPmeQQsDyhxF9kBhShSR1l4a9sSV5o8kLYjFW9vu
MR80QxfjOTvECtPlVpvwHx8E58w1KS8HSh/F07+Uk6jYt7JVy5dzFhT3ui8PwNHH5YcuuxPoeAPc
8sgRBeLuQmHiESvAMDPf7NwadBZDEIImc5ESepEbT1xCFd4ZrTIM7ZfzEARPLQbxATyNUdKQhrEJ
ZmwqnYLE+d0CpLH2xwgRscoBS3CsC4ftwzNseXYOJ7Ajh01yWeIQDSegMGec4qXrZuuzfTdmDKrh
fF96JMelGtKVqv3q7N3bRva9MHFJ3BAt1ZWoT0zfZiPs4ZhNE173cNmEsq9/QLx2vGDxVFY50UUL
ObFKzBOtrPV9uTQNjRCsad0UQHd2ZXTTUzOY7EXcbhwq3VbTAUGan7a4Q90TR/DRlhS3VsktIjw/
w1yvkcpFqYaRd9XwqlkBO9Hw3OHvMXxLvJl1XJjaihaTJnDbr9pMCwiVpYuoahzxlYTs/vF/pk0p
WO91prxgq1ndcaVqtCNSr4lkpyfQRtlIZIPkp9h0SlcfbqnFFpyJ1lQyHTBc8AdgYivo0xMx4lPu
8G1XxAxvT1HFneON6lZc37tMDFugMcCRd0RI9sQfcYfiYuxWOGyozJwbZm57lz9YRnCCwBKP/pBq
vDcFY3wV1PfwkKAsZypckIxvhLAYqPs1Kqc0i9BOHyXssATlHa4YEGB/B2iK7qn5ClI4We14MvPE
I+RtFP/VJ4sfrf0Q3FBQX2+TWphdlsJ8zTzcihR6Miw7q+bNsbHOwlyPCWOxoOb3f4tbXZhxGkOV
noozxa2WnYpDhG33L//yDHXgDWU0APyiY7rkl9D8qsFAcPDDX7nEfyIkV3lWxIMpfJgDUoYwJZdY
RsOGBiXmwW7KOECgXAC0IqWL7TSukEiJNXwwJ3AOxpfqs9DQGnEOr8V46RhAh/BNd90kMEoYojKv
C+tLsmdoUi8wtMC3tzazHdMkm4NO6w7kQ2iUiDIurG51Xd4uXtQgV6ZYIRDcOGPlYOLHwhrfe/NX
js0Hpa0=