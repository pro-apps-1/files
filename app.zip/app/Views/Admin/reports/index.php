<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuY1GxGGCRYxxLtMb//Oryjyfrkdgi75/eMu92SjFVSMo61ZreGBCewUT/G1y2+T8Q7b3ACS
13JszQA6l0nHVUIWq/OX6FtuTng22ZWhS8M5YBqckTw8AtoPDbO7ALH6ky+YhU/TxBl9W5JjkkWn
REJhJ3FFtbBxknNu32M7HdYUWhPfQ/CPwmlRzMGMVIBqCUx728VKCBnTTOk4X+gHJO7t+Cnx4fA4
rWtahPq9je66v69mMIz2cXQGl5yNL5PlTQlwSg1YcngZVFhp9aQ/7plPf41k1ku6LIIKyxxG5ZHs
XPyP+rWxdfYjJs3jVj1t6ziREmBbFPrCnWbN/MlllbbFd72Fk4Znn5Qid2DxdxOOhrnM8wCNaHvx
GYwF0lRa7B0nICjnmFE8ytvVCyixD8LFNAV9JvGFqnKTNPkpL2ABBGEuhm0sSjRlkID91rX8TLJ9
kjLipOuLksaCuTvGB8tLwamtO6k1izAK58SLdFmZpIggy5gHvW+kkREpy9yiXcW6GAlcPCZOCCAm
vXvO/je/S/8O1JZ023bMrQTx3i/XmZLVPAUEFfUF+OmownQy6KRkeQ2ILWDjP1bWbB3DWlSCeQrh
rPw33c5JRon+ONviK0BE/lQ7dZPrebou3b+vcHnW0r6yWspo9gNZ+5P7MIhRZsKHAiXwczC/oH61
2BUznw3IMDwfQnX0w83TW63ySCl0FrVCLXVuvG8arRlsd8lzJ/8Pd6IuHiU9N8iAZhQqj/CosSac
BeBRInAxPDAOJ1yOo0IzXo2o+Mu5MrJ4SgAATMj46lNBWyyCzrVEm7gGpSu/f1oIxgvsRojnKIqV
Eh4bJRDfxrKxkJt9JiAjfM6xqXvdT+KN7o8Tc2mKvBkSNyI55+VXide+Pn4z4jihKHSIF+JlCldQ
ANPyOFYcWI17oWAwupB/JLg8PK7vXciYVRRUb3genw+bFQAZ9nvJdJe0VyLzRld/MgkCv7eC5ELo
aSqxIhZ0K94KPVzx0xNOtvNf8knVOr3Sk8L9quskFtg3x1qMqQRddBKxmKolO2+GVhfX2hUDdqW6
ihVXsTt94y1LBD8njsULdK6q5JvXmXwjZFfV88aNWQo686IDmJB1/B4sYTshXqzdLnc0T5jZ17se
Qc7AQDtx99mzfKoWadvIXQpLltO1I0tw2ETlsDje0aXG+bAkrRZhWTG1BJzGb2sPqbyrcI58Fszc
rFu/YkrrrXPjFHlw0WEo+ggJ0/QQpwzweBlunM2zpKfUWxw57HXvv6/2TmWLDebFdF6N16YpflQh
rztgFsSDyyT+SUWFS9YzNngsySzSTShW7D+4HHa7L/iTg3Sz4laUPdacZf3g103KABiLzj2MQPH6
n5TlsKY/7TmWa5DLnXHZnOHqWmGwAc3sTAKu5sxn3nK990/Dn/uEUn4CjHpVSG233/bY2M3SKD6Z
JR5NPu/M+WvmUS2cGX+GQf1+vVyDkH289ldNQ9vENo5n2UGtkR/SN6MlDgRiQmFfIUUciPUMb/7r
qjkYSap5W1sVt6GCsYW/GOjrRTn0tVEaX7HZ7xSOmdXaMPUeevlTytwYu+3I3CSxQ641WhV0MBjS
9go3rX59ZFLuGTCMdw24hOT5WR8Ys8Lf0/mBWHPaTHKNOsMaasTsZQIp3/MWlh1Ug0qHVfg9ezok
v33FYNjUGND0WqjUnnWmcXKgksCHN0a3T+q+YH4TiL6c260QUHTZ+117XoaDAXbQluce0nU9sSYq
TTlj0TdCWTHNZninkmNrqj/eUNoq6r+ZPTH/NLAxLifxOaAP4Qp/jbwxdzFsrZrE8r1Wzt8au4Oi
+Qpp+d8fiWiZoH1zLjG6IE/Qv8kWIkkx8pTO2H4PRZ4hQMZZ2+fUyJz9tHOE4dPkv328ae8+cCnW
49S93py57t5RzdALL5/AA3VlL4BUXIQ+PUx+zNrqKADmoC+ak9toI4agXes6CBl21IrnoODT/UUB
uFXB5Gq0RZf5RWNNdP90hYnxfNLHTdhVkSxspOFhxs1qEv9B9Em0pOBceYtcxDIFXIAXg4KqgUFv
MnPSWR26rBw1fSQFMvMmGRbJTNDWwT60cw94wE8IYHJrzNG1IN2z6vnvS4pwgzcb59dUoxjfP/mD
RkgrId3wE9Omxo0SxffAbjlQp1I1FGTlCJTOnC/EHY1gywE+dcMHsmtHo9FJWaJBZo33GtjjPKHJ
+jCXMfKXaQD3lGVV6K5hF+NVds2efiN7XO6h4BbeOiQv+Dhi+xY+vtMNEl+hEBKaG/eMJ8i0kKEQ
G42s79CRynCU+r5hjuhfpPZNT2ip1+AG9C30J6qWNiERLbD8Q1sm5szVL0v5IjrCrySJXxP7N6lm
2QZj02YlAxDKDQbp4a8aSHkLkH0i4hgrZDXfXFPhN2CK7OTkJIUZjnAZ6hUOLan4LrCBdfvZeJeT
SwVXt213fsGMp0m=