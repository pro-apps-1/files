<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwrz920ZrfmNEhon0+jh9KD+HcF7fE8C7UeOXn8tS4F9XHB3x9x0E2IGawUgWhlTbqD4Wf/E
/fw22zbVgCPWBWIQSYx9dv3vr2g805LtrH7oRDSukJYoHXWBQjZdNSznMrnOHZglvp8KSkg2NvPl
BExJ0eVGsfz6qZ8ZX3HPAmGRIiyomrFYJMroqrRvVhxxHQ0LCTSzPYDE1wDhXY8wiy3KEinXIdNK
L5cLEYNkS6OcMGQPlH1Bb5IKcQPILK4Bu45P0FpNQGqzzeZKqb1s7eEL4+R8Oib8BBNiISt+3dsR
Kux6A2PRfgJtCGZc92XEDR36iyF3ucHTlBVjZU4Adw1r/v8/soqYgf8AkeXZI3A37cZR/q1iO9Jr
KLr4qJ5z3WIeb9eXQoSIBHmatVymXr0T/XbXOE9Ugd7YkxsnTk7M+eXp5QMuHLUCQ8oq5sQ2tPXn
mQBasofePR8Brr2wawQS2I9ZT1pwKa+QKacFzwMcA66PoY87TQRccg2RrMhYknMDWZF7INU2Hxkr
lmdgVf76amxNQoDzYyaFfiW6kn/2DW3j1fiZQCPpdSlNMi57Dzw8UBVUdLXQf5m0jwns3cpPROYe
r8fNgJDgx5b2/0p1hMcqD0DSdAafnCp5w6lzrBaKg5GIaQjVuvyO/wmlHlcYJe6cIgXnlXhF12Lg
psvRc53nls/be4pbgAPdEfJkLE6LfGTPUw8dFJXMRJrA9Y/uqLt6JTbP3q34bSW3xW7/3FjsJZxr
wyDJFck5SUaXt12rzSBxSaTJv43BLG3apNoBQfeqtFlAvc6b1x4S4Dqu56Vf+T697p9pBmiOkczX
p8b36Fx9d8pyBr97L8piva7h6MrEiSRUK51D1vaVVCjdMaY5gsJzdojSPVg+8EgDMb920Ibi9Sti
y5/N32/VzE9mf/jjBQgrE9O/HDe7+SiYdWwZuWNoxYxV8qOELE70TobmJeGoEAviGZ0MZgh5xB6V
Da+Poq9u9kGC+ZR3MVbUIShZuZrtkj6Ajb7G6c/zOOQOTN9l0ZAvnXUtLfnJeNbo7ulvb/OsnPZt
W8lSeqqtWpxfn9GHwtIgUoz32+UfkiFLWOXg8m53hQfoJ14rzG9YU4WMrU9ZBIFZW4PEmc0eVPnZ
mZXTngn4a2O+mwFVgWry67MWV9TN6+fmmmiQCD5Nhnc36tRiQwo7wzpsX8d5FoA6SV2KhEnZ65Bl
9YPYx5K++MVdUfNY/xCWpTgWA/nwi/SDYlLET5GKsBzUsgqwi8TgziK=