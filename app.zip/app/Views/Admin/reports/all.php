<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy91buSJ7soeweC2fBJOitzj8vPIvclVkVimJufaI8CquJBHgQHyisJRtCcKBOX7aRVf5egr
seGQZWCJx4bWEZxNAqbvOSC3x4lwfeVAExNZlmMgmEic0MU1l+Iqh9p90Dy1g3YYLrWp2Y9L8gZN
yWWIsuYm+lyB7fgDE7FB1sVuyRHKmFvwBQdlCgBXRGS0BvzMzxdebvL9R2JPT+TB+G/eIZEV2zAr
E5Ite9czCvhOhzLQW0Y2GUeXPnZp0I/ubcGI5Q+9ME/C9FKFr/I8J8bEJI3NQgh1WnU4aTZaOKh+
E0sYFHqAnjbXxFbtL50QPMmeFkB6Wb22MaaxJLkpUQH5A9sJ6k6dyJ/lSrjFOHlwNMQki5voPp3M
KKLEnCqLCwprnmjkv6FrgnBcGGCVH2ICCetMDUr4AURfFuqsaGHsiCqJ3B4avOVkxnKsG7Lrgs/Q
t0BdgMfUD8rZ9MY+bGZEUYrOnfGqAqWUuo06Vdd2glQUyez6p/Oc9KH5W2pGfbZXGBg+4/PXZLnt
5o8aGfIEjn0BZnOA7YCNJb0NwF9yIX5uUyi+7+HOhIWFRqyxE9gD0bzaxwCcmVeJBHaZtBPIE6kb
b4g1S0edgaQ+oJRgCsz/xVC8eP/QCm6vn/fo9nYluCkXaEi7/tEHbLm9ybf+SA+GxLhE1/p9+qdF
Cx8zzTmpaQOIW7q2BYUTfbHL4wE02iRGdnA6lLBGsZSEWT5jogS0uJTtvoPTWh7Aa1xZOG9P39Pg
V0uNJqc77nvOd6THUyBYPN0UORxYL/V4bMF8Lq7mbttOcPWLlC5c94T0gfY+X0sp52LsRNbnej0C
YXx87wH1HP+89Zkm0S7dSnrRwW0urOM+1afb9BahnIEgkIlcPrWnWjigULNqCCYxxRGB0HKf5nIM
ggTHVE1fz9IRx0JJG/TZtLLWBinKGWaBoO41Dd9XmYu05kS0bUGC2JYmaderV0jLfMtRD436hsZy
LkJ8r4TtyonE/2whrpeGUtSppN5rgU8qVZdv1h6f17cBSuf155uQirxYDGMD7kL8oCxtym6P+Wjm
4BjJdrsdKfn7k4PYJB3AK+Bu/0wBJFUw8g1QClHHZ8C6JoupxS2PN60K+MlvoZbz+GieKdhKiXJH
UeuJG6UtZW+yw+ViPTCkNDyZtmpoqtqPRKKX/02ynmQnCiVoj88vs9bYRWPv5ZwwQFg3lCiEojA6
jc1WnFYVpJAJVn4Rg8JWR2XXKj9RqRJyZQcaOUFrBaeLJcKwpVOH3DNAtrevvvjx0jpJ0fIzDCec
kZPznuivoogNOkI6CraYUWhPpdp1UYOrqSthh2DSa+x74OVWmY0uu16QDytY7ItR1THhcb3ml/ZG
zVCpzUUs0d/YVRARfL8ELBjuQhTmUG9p+57VpUCsiNHEnZfg7rsXHI2Xd9CE+GtK/Vr8T5WSGow6
XiTA9l1SD/6dZhcsl1rx5GEO3lqtM4v7RuzdvL4IYBgjPAPk9Xr6JJ6y0KsDh963sAe4LRyWbFg/
0nlwReNMdMudKP8sJy4eFtIIWSuSpgkrOGwDJoBvGKNogYgDCRwLqGQA12+w2gfXiBBzjHvgXZa2
URaPblpXWAFMM8Ltv/onc6mB2brKbzasCHeV8lVXaRBgm2r/WPXVPOVJaZc7gMxhIIjxh6Li1gLS
1s+WqiIM51MYcwMcFYM0Y5GAQ7vNqxjp+oDO+ctUOykk6dhpMeOPvsfl8KEnLGrrh0y0B/aO4OMO
HJgJqCclRvAnppkNjs26QcxmkzXqUJJv/l+lRmJgbKNiYzidQJBK5jQ5xk0k4qFJr5hARXsizo4O
j3F8U0FOfYoqjz0fOZW=