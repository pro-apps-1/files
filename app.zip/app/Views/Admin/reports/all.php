<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyslD1KO8OrQvMsXDl0LpI8TRQ/afks99jcSLFeD2MbRAxyESy4Ye2Ij0SFLUS9k6WbiBHeY
w5GTkV3MMx3zYxtniL9vVgRnNw0qsEJOSsoxtr91afM+VjYtv8ZiuLGhEvJgrHKicY6V4raZm0T4
0y/4voWQJYEcLKwVkM6YJupwohgSZm3kmjUSvkMMP+TBmrjmgEOJzuM6KdujB26ktiVnNB67YHeJ
OBlU6f+bhS0oEQUvSi6blHj7T45rq71LOD8Gs2poY3b7mRaD5DgPUrjRXWM/QiS7ulCwNuK4kaiU
zzUbKYJNDFz9SgXJwjtGq4JQN20xUVs5VbQtkNjp78y6ZKZuPxBP/MwIuaCkmK8627M+8PF/yfSg
bxT3yefZyph+Q2/AQ9ulNgSMCMuJTmgUqWCLNfXlDyaYxeCaAAjWtqr1gFQIzjaKHW8Xle9oEMTf
Wzfrl6+yyCN/YU2iYYi2hqYwUforBerWLPMN0V8gPKxPfnUA9ymbHZ/Ii96iJzTiyTy0Z32RXlfH
m55799fVBGx2alCkWP+yDp6lgu8cf147Z62um+e7Yi1J2rmTDgKqDzjL2fgqGGg6g4dcTwUura3J
oa2scabcelpmpEe4sG3ToRABqyuDCdDrLVKZI15PZ7t8gHcQRjqw2TuH4BhqqO5D69hE15AAww9g
gdfECyKUmh/st4g4mWzQ60BOUqaw8xcWOIFNQzm4wmfex5uBSFZJNhpyqiTY4n0FVgrV2HGwVn1Y
wf2uZVtpV6JZicekcx8bWV+vgJapX6q7eZd+wHlwW/Ran+7+cIsGily+D0M8YGWvRZgq4L3DUXqQ
Fu4IUYs+9DvPpnsKggpMy3+EAzUvQN/yGnT3LB5hRarRM4JCmQ6KECvVmxVcTaxiii02QrRh1m6N
sfqH2mJC8HjpVwe8hpgRKjDS6AalZbcUsRYt+dQJOYxYIxnTpPFjyO7ZLtLCfWoJcNyhCIR2X84v
XhZHs2ezTItMdD2EoRlH1Xt/5eHyO3hKn8YEFcYsBZWU3rbiX1H87L7mM9JhPEvN3Xa735XAzqzV
ug1QpgorE0V7K8ilDy3jmPCS1Eqn6Vn6N7wuzYTuwQJmImWQ9XNJYJkd1Y8PmrU+metUaG1Lv3YC
9sfqURJu9ESslGNmDondi56XePpKuo4qSsQSrSITH+0TMbiJ0wQTBkvaRiA5OMvrCjXCPRsrzuIo
suDFbCiZ7eFIAztjy6Xx0YAZ8FORDVscpCFvTVTr6qkVUxjdChVCxwPVugLihS6M65PoWuy9Io8r
5NxI2e0lTc06f2sBgyCU3nIjdPfoKKjXDTEdE9fQqnamfYSaggSPoPlRQoqXDV+fNbwq4ZBcHUrc
GAKSTZLVGj5U7rAY9HdpqecMeHuitnn6NFRScT9xlYlvwWv7fNvAF+m1thqs39v0Yqhn0EcDqY0h
CSXiB0kOacH92588rstpLJi8aBw3HS8FfwpJa7Yx/nPbhaOfHLTN20UVv25ZvEwEUqPO+lRBt4q7
gLQWCPZ1ER/DWF/vB9iVBU/95C8Mcfn6zNQZeJSSeMZRJ7lzmdIe6LCpC4C5efqrXmC/Vg/+TOcs
cSuxhKnBvrXGLEwAN9qcK7ASmZjlot3DnOvBzlcvOyacr5lvx1PG7OqgwrDADyP8IxYkbDasY6F+
gmBck/XiMn5TSFEt9DyQuA5nQ3rUg2Osfowlq6seRqf+GxbeSypIkl+zwlBR8ho1x+MrT1fcoqG9
ksVGEKnUHkNaH0SZL4Ew1twcqqfelpB0u/OCKBvycfIYgWjKZsU6L+0vmnQt7LkaXdyuXkA+/uvF
fn/onEOAFnOYjx8nXli=