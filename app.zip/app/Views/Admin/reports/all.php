<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqpntjmFOYCJrZ1B/pEbaX/1DVHp7CkSqREutkZ/zpDq/SSZp6sfOM68SISXK6NlBTfc05Bc
yG45f15ccmGPppPWmHMmqvx8QMGp8dzT65Un/6KOt3CSf0znN6GmELBpJbae4sUBCUgOcKbe/oG+
aOxYNR6QqD5DfBcTO04NOGxy5zQe2BRU9SqiDoL+PNEVSnrqYKS4eUvk53a6pD2h10sVrmb09N9C
gKbLtAkEVZkJVFwMAaSc0GOHu8/CrAOI1svDuTwEsDRsN/vT7QbbsKtlWI9ZTJd13Vf51XRAbVbO
gDqRN+mHYeHGJKqDlX8lXoUnUDGm22cGPglFLNsJZ4EThO7j3NBojE7GCFQ1JvURwqHrfKAQszM4
DRMHnhWpW8NJTQYexFYkG8OBOQZBGqjPyGzup6Y9LrGnRG0GuyTXLE4ScoGQdmk6XlTt1Xv2YFuv
Izqm2i4xFw7k5bEDGSg4/K7N8gEXK1kym0CkOJzjbN62cKYwuIevVEW3428oG2CF4zNF44UDbC69
DPBQyKESo3xFctxioXKIzjS+Xb/SgTVYnqZdA864qBPey8YZnrhlVmP3QwP7XRrQLr/HS8arIfDK
WXxDJl8g5YQgvMCdxQl0pECSpGwUATq0Ah4ZAvvBehEdnZB/Yu5ZuQRK+RbI3zI6O039V4AR82rk
x6mmnCbcsPLwUyrLTk7wEISuvL5i4mcjcwrTzR/rdqVkDpL5HzUvyEOmoF0uuXsSx0Xex6a+KOrP
aIeZ8feQpCQ0rYisd84a3o3qv7BZH6Wdn+l8NQewM9rDR833WCnuN0urZiYAbk9WiMczsyv1xwI3
lOrG7DNo7gobtrf4ShESe5Fd7t5URDYwnlOwNNBZhkUx4WN/Kzg7Ify3bv2NQSBnXy3WRjSzecoD
l39Wb7A2nnZ8BNa2EyudyAlXTRiKBLIVd7E+7IFLO8PnUo+I5T15OQSiG0lPtNO0HwnoSjGcS/7J
68/1VZfLRS8u0savOwcLquShiSi/HGr9U8W6gDD44Ndv5BEX8L31HoArXFk3XgymC6bqAqfuvOfW
Ee4Ob45QTiE3RWn7HbPH+qwBXC4wCl3IzkOlDuS7WLT0l3CC5zgtCzJqBFVcFgRkFxYCMv+kY0vm
G1iaR66ep+cnDoZcrtMYoH9echygoTZuY+D+Wzh/0mzbhFjZ3ql9XT0MfUlMWqZbJaq8rVW8EtP4
q0cE80gjKfND09GNL+KDIuzBEYrDgGxAlybOwyxcTRUhO5Bb