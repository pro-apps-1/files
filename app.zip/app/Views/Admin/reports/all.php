<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuIHJ9lPJxNSf5FPk1OMYmoBtuFSSqojPS0NvLlVyv/uxkwtig76utocoDa/9rRaBnYOe0hK
LAFjiK0BvQW/Vaqm7izaVDkscrlXCLq5SITkuDUpyBXM0fA3h3TziiALf8hclmWKN2eIDZRSvNpi
myvHDvB8TC9+u0J6Kd5IF/nc79Ecjxjy4roVvDz7XDqrLwRp/lpIoIJi6KGGNTmFlag44r3XXM5J
DhqtojFa6W3VRRH00U6JUr82XHER4GTvZAn5ma8UlJdPArgD9XhjxmGtTdsLQxV9ObClrpysxBqF
e4gv0EZIFQWSzFmnqkMz7qLAglWHNmTSTyn55Gdqb5goXbD711IceOxQWgKswzRabQkz3UxK4Bj7
XuBaRAPCSWh/L6np4RPELU7fOq4FxdI061nEivdHuwmXiLs4/kXRZlmTjc3+6zEbgnsPej2gWCJY
nWTrRlDfP4qMRlWrMaAbxUGTpfXVxHg4Aj5x+80b+lK9h2PRl0bVmoFowfXEHQvaTyOMTy73Ju9I
j/kSOmqY6MoROr9pGnJKqouM/zXC2DpIXm8OTaZDDM9DJsTlni9ek6WxV09EsZJVSR+OI6inzlYx
aozn/5Z9Omb/W1Db5ZY89PlhShIPKxZPNI3SlGkHBytYwHP+/r+ckimrepDy4kwXxaR4WBuMJeZ6
VntyaXLGEesjJPwN/DpQEwQeUVkH0/Bj+ADECLSZ4YWmFLuAlzSLR4wfMxyAYWUWSQgtjoaG5Pe/
54v5lzI+9UdUCnX3YvIXNlPUXSCq1q8ugAxsYCi996FxGUrhMEC9Hu3XnBALKxpkVc7Y728h9Ygj
uZR1oR0SVeppPnDgt7xNBJGGmWNSqfhB2N9bIk+teRtXS2Mr4iI0rpATCWTRA3ZnzK+rDHlNujgC
B6STqICkVkac8guLHLKn22FA2T1gKiNARgOMUBmB3Lm9Nxo1Ds8cgPPoO3gqNvD8NjdCR8YiQZIt
V/136gHYbauOjWqvMXE6S0va5d6UoMKzAx7mS5JZn6AXZgPAvgfcwKuvdTFVd6FSwBMBGX2ghaw7
paQzf5QzwmwkYjT9rOxSHVFb3tdebyt29vIKFnQl5eX36hkx1CLiMp1JYMedtFuYO/G+d4CWNUfe
D62+qtRYhg8XI05mLZH2jkSmkHpEQskZCgLJJkUEUqzc7bZkX5spA5MA+sXXk0hW0+xSdtunkG09
blIVuJe3Cq/OFPteQUWHZo92R+2bG8HP7v4pbfvwcJ1CTDfS13tI7khN7jzULyyMxC9SNDZlSeKE
lUKNhwNIEocgf208R2bARjoh24Xk4sCq4jm2SgqOAmFpbWVTBEJkErSxwcY40Ryj5kw+VEuZlGia
TJ+dz2NOukKq+xUBZPsPJoLW3sn/LeOEcBHHqqB4P0HniKn0YfmfOyAbvVEqJvUdxu8z+NNiVZ+f
MZD4xZ63LFht6UcguS2RKIYRxjSTmN7qgV4ZMIyNkZhIGVZt2o5My3765dSYGGmA78oRTKgHu3TY
dNax9lJcGJtZ5PkSDj8aHgV28an2sx9gmlMokJ4FaRCQB4R+JStYxzVWHxNG+UuQgKAOoYQsGxBb
XcY91Pz+SN5IGp0Be7WXAiZipg9iDzrQomcGBJ7LhdJJno4cGvDr+57PqUOSokarjIo90yLfEQAp
/Ek8y7GBA4YKDw+i2xwInSygPouk/dPxMRp4p+ewqsTKYLfmkAUgqMUpdUJAGgnxbK1NWtaQ+mVs
vkDef5HPRmNKySyfWYH2wJ8j7JI5keUPNU1mW2IpvHzbpHvecFBPNXE0Cjg91lh/LMRvMKBa484H
WdYYBqImZ4EAwNy5JmW9VWcZvZTxcG==