<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPm1pR7B9x5H6bBBvKKy2rhqx4Do+glsTPjSLf8ED0+gIzOdJCTW0MVcMOuHUM6NZiQAeNRcl
6taqyCsCjLN6CyQMHVR+csB65KPoooJU1kbF3DfCwFJ9wrU3Fj/PjCKAT+yqZasp0yLhhyQFxA+E
9dGIgzz4tDQjptM2V+l49X9Tf5KhslgQlGAumrblCDIURrdvGSlXCBsON0DPcCCZshF1URpsksvI
frJu4s8UtPHnU9x6B9ldjXs0IYDW7fRjkgn4eOKC8IEnD8uqrkWOb3xuv1shS9ngPaQ0vMjnvoL5
wmXxUNi70K3ICOZl3iz8tTk4fKoJFilNnhqAotmLNsb12SEFj5oJ9d/cEr2KBZOJsxvk3KhaIUOV
AKeC431x5PaZ4+rI64imvKOsl636c/iMzhBTzGLNLyfhwOE1mBHnNcLGTbGSWv9LFVY5SXctiZTf
XjZueLvzmmMobGYBEYMPInvB9fCn4YVk6st2hp3SDkTpbIAlrRRvDggYdt0eXr6yNl7fV7hpph+Z
uNOAJnxwm0BMFa/vCsPLrYHb1PRf+Fp5nfB+CLkhK1Y6YBFddg5kDzMKBR31ngBo8L9IqHa21t7b
V/eaOffrde68oPcoK7cMuErf71Wi8pCQkG6/TgCmJ8Vm49TXhqf1/zc3eeDPDf2dqDFfLVmt2W6E
V2slVblaAOX5D7FQ1YL0nsOFRUNVGeEatiMDq+wr2gWqCJMXAd7Rz+j13TnXFvzpU3cC1IojACOG
/RW4MmCDeUH/x9JZHsRx1pUKGr6qx4YPgDQj+LFzs01vaHT9emQAYAgOdn/l148bX3Ph+DuiOx2p
M3UwejKqyfH0MZv7iV5WYbh6/wCa0NqdWMqFBAY2P8nPw1oJLs/xRmZMVgtbZIwLbUnp81a7SueZ
BeDszRdOoWBsa9YBUB7RaF4xmqPMiIPbZ5HguXcKeyOAWamP2uDiOaE1JoCaCV6cmlC56+47hAI3
2pzV4pQhOYppL5Egy/VWczktaCEFXEtgYBwfx+2+JvGant4b7/hKlawT5wYliVaznnj59GwOzF6m
sOnBqrqZGI1DJHXhLdDOWAe0ey8TUI6vl3224t6xJEp91Yv2JnpfJuQ0w/F3zc1rlJK3LD2vEkeu
YdRr2C0fZi6hx76LtR+c2NYI52qlFJdTBEv/bSlJCu3ShhMzPtuz+9GXS2SvEG4oK8bBeNPg6Cm3
1PEcDZhNu6ozY4cJttiLBfKx8rMfas6NwBdKsY4i8d0A+92QiiLTgFyx