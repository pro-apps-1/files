<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn9D/usgA0E5ZJMFgObqe0BiN13GLEcjaOmxvoEcbrBu0JEHTehEEamROhzrMq8+qrikHRND
OQBbhJRB8Bp/QckjSfh9xVV5kDi7dLv1cKN/ukQ18AR20NAhUvO3E0YAB0xqDeEB4LLQmL8L/iYm
bgui/3QZkMr/NmMBo1n+PNkcsSJo0yrb6Jvq4Ua1+njOBqhnRPBf43aqWZMeK54G5r8FqWqYyah6
ZxXnT8R4T+37kVH8ZFBjw6CP9dRot5ogOLfRcNzLz64dw5ckNa472QqPOhgG+rXeN9tk2PCJ2Tuv
bxA1mfSr6dtBtNI5sumgfBfYWAXwIPckch7c1BBQ3X+0bTabvA//JId8psEowoT83nY2UaaoMeCZ
QRQtE02gIrmmHoH8DOUhn96/izpTaaW3luIqD94RPwWU0Q239ZGEXh5bEeEviHPNe+mdm8/s1069
vQxMkDAjYkw2k6hb1kKs+0kOCksGFo4/jOs+jEWxQlITlgb5mDThm7eiWE2Zu9awMLsoJL5cIDK4
h7tB+ROz+/qUpqfqh9oFU04fNECVvav9PU3C1bzrwoBgnKPM/kn12QAfHqYji8aLdtbTXadFcGkm
BWjokO2spt/1ZvPXbJ9ScWP5zWauIHrJQCXwZ0k0t+6+9eSHT51JV1O2CjqZIk151J6J24VSQu63
KxquRqNMUPntiIS1p36yjy2Hfm/9eY9QOigJXGuzlkmR9OyiMUHK5qndYuV74TD7xijBx5vq5UBA
H4MUDoa2xU6GlHQhNWkYWlecMlReqDHJOSNgGDwFrmw/ulw9KwU2z1eCj/nHq/rGExhTaGwoeAsk
ZKIXTKnPHFGmhVfWWrn5tptqAK2wgOhjZH+f6DfzbMRQwvIj+mwbkWwvbOP1N4Yaie8cHxkqYYiB
7MjBWa+lUglt9oWDXpD08VDLDfEtUkQjPtqjqBsGUgCcS7Rucm7/QdQZnUWDTSUIykON6sbC4ENF
80X3uNBqBawe2BcQTVyDHfe/+/5Qs6olJKthXrSFrEWbhOgqJPdYvMcutpUujtISFTugFvVY6hQa
aEy/B5/qaxezK/eFj9QphJqMRCYHW+j7ZJiu5zqKt6eZDkvb3Rp5x/Ku/mfeHneVvlMavW7Q9dJ3
EF3It+azr///mehBSrqNaNq25vz6RFYHcnKhfNoog7V/WJ0JVT/TFPT6JHOxtUjYQUbUhKgVhVyU
QyT9FizPH4XW02Mhw7ESNIxsUxTMdUd9uCoH32e7dro8MPWgnNxkAqe+VyzHGvGfTA0XeqD6Ifsa
XRiOj4GV2T/XefW7n+T3ZGi8eHdp+C9abA+ZDpTnDiPL4dFVPlrKoY4z/t1nJy4TlHWrNHLFqL5K
ArbhNXZyR7WfarrgjFIq4V0eZVdsC3ThI+UzGPTlDIiEYQsjT0OS6whVEGfD8eb8SujvImJFhDkh
EhokRYra4F1qsIIR5QFR06wSlcMfjlsRGHrhjy90ol4IEPEyrl/3RvxD7nbNne6nv0rSAnwGCtTi
Q7CRKaBc3S5Eh/6a5Duo6UYTQ0KjIUKnwf2TsDD7ljMkCzfgN40PY5em4pIyL49Vav6rZZD7TQME
xwcW3xDPqfUQlPQ0yd/5YK7AmnBjrT0Lrj6TOunLt+YdYkgeD6RFlwO3GxObJ5x0MECNaRPu29PF
GggGvHzvsqug5TEAsWGOPhYfHOvCNVvqPVZnhDqXvfblQFhb4VRQXBjmBtNO/m/Q69DjJdaE78Nl
edR3IsUYXSgQYgq+tcZfqyacQTKqB2NhcqR5UukvPE1ZaB4V8Adf1b6Lvy8v2CcGuztQfvek8tho
vcotBsY6iIpTbOk8fry/knK=