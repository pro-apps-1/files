<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy4x/xWbxPM42kZvgGPgn6paPHO2NHBOJPIuQidT98gy3hkzczee+bfkrzDzlqAy+apMYdhO
cFS/bERHDMhG94yURJjcA991PCTBpBEEColN2fcUNU+E4B7zTEVkIjZPFUDVsxduFV7B9CpXMbDz
fmRrkY0IvzgudzbOMKx7NcVyNmDPzAJoynZ+6EIqnC2FDDup426FPnn0htr6Sq99vJY71NbK0DlQ
IsBzqhk4Afr/CrNXRrHm5rBQoE5frGowFc0cDDLlWsO5PxOd80HtjBOoto1jWw6htLHKWEDQXzMr
ZfzQ/pbpVWj4qNkrk63+mcV2WR9BZOFBpvgG9Z8J1f2hyVwhaa3YOQOBiknnWD2J3vZaRvRSnVFQ
huwb+buISzyzHDdfP4x+Iw4ZCgGoRmIcz8Le5qdaxvv+Sk4GVEXKZrUjm1+eafii3sLK9CKuUMiJ
alk5fdCNKU5RbYy0LrPzFHwUU0AXNkR7ryjBGLYScMX70kEyhs66qOu6eAIX0ixQFgDSjgXxbmYl
e7wwN7UaDJkoO3zUPynIoMz5SZVEWTCX22ONXe2MZp22Vm3N3pY6lJaIx7EhBqZ90fsO1K7Q33ka
Zowz3DkPhaMBh6rE4Z1ZxDf7XvI9x0feFhJ9De78l26QwWg8x+7RXqSZ7Y4BNcSWHdNW+n/ddGNl
HstgLtHJMI3NkkF4mW1AbIsBhGIciptgRtOAIUvHfGnEcxO3qMIDsliEAFVPQ+XPGZVuqIdbMsjh
S0sJXhJsmysbFxCg/GxWNH4+Ql8M4SHu5bWXfiwy055YPev5MOGbBc5Xg1sUTSEwrT42AFnJ62qY
pfOUwS/v0pZ8QjBamcm5fO4x1pZVScZQ138XZ316ZV4XirYlZJtAXCEQQ7Tcgs+NxLzmBmGhfovj
STlW6NuzyRWiktBdL6PRiwZrNeUKMIlY3aFBsxa8GY4KAjhtO8mtn4YzE7uu307yedh59u5Fw6QN
ni9fA22vABr05F/blzmkRYg8YxNNxBgMO9dw72fVYWwO3Nvl2pSBF/neUx+iRZ6BVDTi+Deayip/
l8q4TSucPDlwIjD+BXZGg4yV3QSmsXowaDtWsh8UcHG7aeMsqqfB26y/AABjdF5vnMGtBiDDSXk+
EqliPK7bd/mP5/l89HQZxWu/vDTAWk7aDgGQfCSel0GqnVyFXI38QOwPiCTgwWBBE40onnFE4KcV
u4yP6vOsSIy/doDk9+y/qfZ6zwQCQRhBIyfSBTKN0ggmm7Qwi2hhsGdqWO+331rOowZtGGLvBR7B
ZShjP1Io8gDM9FmTJ+WF5ONHLat65oD4TB0wAEZR1H8IMNoZr4b1/oJfFOWoqioN2F+RhWvHaGHM
d+301oPtUO7LvCUuCSo6XonrnTPXznrEQlFGPljbeTSfZThtWm3X6kcIE9JvL3acqvR9v8Q5ge0g
0v1XgOrwhSZDV5bX+ywtTYhxfzvuZW1E1PpGKTXBLnMYGulWBadGHXtXZFP7DOkVu65oylyj74Su
5mAfnnhKusESKT3wt7j84IPOn2RXfNbPkcQwZ1d577j1z/vSw+/YzCJLFXLIlqiYqWR5cb/hFwia
pZgoDqHDjJCikHJxMBeGiyNzdjzYc/xpGW4w3TT73PJYOPZ5GgrgunEHdz4Rn5lMLmewxa+rLm1g
DrnPxf7fzH0zsIyNZvaGhdVIas3kFNTC8IA+gb8QERuxsVUFx2DLrJPovMxLNPq/XY3k0P7xFO0N
9UV7WqfOGSssLNkzaeb8fv+8EC17N7crbQ77e9D/5LCiDJE7hpFAxtrjJdDehKTyqUCCDHNmH2cp
QDkUDtad2ZsXgx+NDC4c