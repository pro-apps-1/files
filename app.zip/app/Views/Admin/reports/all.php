<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxsjWwCg9dYKCsmMW0wvrQBOz2viFGQTJ9kujgiUzdlZEWojO+mjvH1hyAgGaZc2bBqiXgot
530RIYVnmv5ab1gYxreEdXmBoFh17dlTDUs3r40q1UuB//5UYr9TwIPN59EZTL/gmJ5dnBJFv9wf
+ftWwUWI0mQD5lNymVjnUniHjQ28M/snh7/ECk2lTIQGYpMGbVQ+9tH1gwH2WIVezZ+Kz1QYhDCG
yDqL9uZ3uneeYqR3QZWGpSeVqzOMCtkK+ZqDnar0bIC/IiIrHvjcnscyWmnh+/Dtu/rLmMua2boO
hhbK3obr47k1+z3RGPJ71/4tn9Gf7L6Tso1JXwxgPjgOCqK0vqyEeCPnTP0YvLGjEQcM4TRzAJOh
+ribpxKQZ0ubMq4S4gUW7aWue5FLp761/NXQ4DGmFyPe6wbA466N1lixXv+bUeET05LiODtcpEbh
7UO2dd8N0N8K7FsUohFoL2r00S4SKFwAfD3+PHtm2ZP6GVTZlNZC0640wHiuqMehvNva+9jtdkAw
kYVOI8YXGyoaJaCouulWKiykOQYMN8U8/DIQ8+5stXQisy7DcTWGN5TTnVVwbQ0/3VMPUUF09+Tn
GvJYSlMVQ6SYM+QW+zDFKwLYqjQIRhfxB/ZsNGfVRGBGvNbhdvuIgMzPEtN/3cRJaVTb5/QLavLA
0Ye9VpB93khHbQ+xYEaW8Odozwu2wDvu4GQc/o+lQuGlKXHx6MPq7YAt24ovM2pgk5Cp/fQRiDT0
1UstRUPXdOZOYgkWbmSqPPlEbyXeS4QPHLMJb1ra+R9G/Vh/I1kk3xF+TCsX+5+cJhUtEe+2/JUn
lSTAgPRhOFixOPsern0HqjcGzSZfcDVwNxILla2NhD1NsA7gNVeagGoAtxPj1dwJsdL2Ph9o/ryJ
cUnCenQJ4YuHfR1lLXdIGzK282Wbgiac42A3sieNYoUkQQYaS3/edDRkl9Pdauf6XjHv27dJyllD
L7MJJKE+cYFO1u9gH0j/Ga06xkqBPJgZ3IiMcg8W4L4v8Bg4FJJ6JMBxtCqHkhTkAtePMsDDnkE/
UxiK44WkOKeTrwgUTONjvpRs8rI+YM61WX9kSLFw4BSf5VfRfsztnS/N08OQHROIHTpDH8F567gp
KxYMryeecN+wLy0InYSTzsedzlL1GcfuY5E0H+d8gNSHsGQqjD/TgFD2udLdXTJ5X5HbZvhi1z1J
ez3XVnTDoNiQ4tdf1h8Ew8VLzovlzxuIUBWxZi5038o+cdPDnSoDpwjA8AWzRN1K