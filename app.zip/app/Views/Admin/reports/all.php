<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnu+6kRna/x9ZFyoZyMH1zIFOWAaXltkIF4HOk2El7LFg2AlbsOXOcHWaSsLfaVyJc/wDiCd
WWTh6x/wynxQ7uqv8uv248/3h8dQMAZImnIF6AJL0fCg5Vt5oDX7B+ZL8SMAfW7DWc+KXGd/ItdK
TJF5ZibHVzJzwp6ksOG4/ikLSjGs+Gaw9JI9gHIP/1xSEbMIb0hR3Xv1kw3xQXS9W+ipgPNMr6MY
Scyg0nE+ubCaG0aIyeO3VWmUS5/kilz42m2PRX+MgeT25D+EjpKkAQLjijLDQ0FZEmp/T+vwI37k
3gpTJH2FjqY/vLc/0YQkKRmqclGpZHDDwBUH0Ac7wXsoXpwB7uk2FtWLe7sm2gz7rn53h367D5vJ
7AYvJghVzMpykApzSkEaK5iPJoJPVxGc00EUkl6zTsZTCIc3hWWD4Bp59YLeNDGcRTokzrqh/uk9
NkvkACJv7QZx+yfciD7CYW/7oqbYBkQqVtMPb33Eoruq4DJHkmj77lq4ACvYDU9guiboFfWFHGVv
+oqd+QDVK9OeLmTmtU2Y8zTY6L8h776UdQYFOIKVLetqLUGmzTfVlOuUaYIAXmsDrtI1EMmr03KY
ihx+kPNtWWr/rTGNOucCZouq55y0faMewozEGr6DQGG5OGTQSkbPVrmECGOklSwdAvAjki3+cwUM
CLHbcqTTO3QRy5Afqu+k8W4ehUJ87wgQo4ArVgKzgxDy1zNWCdXzoXSuhc8eMsC1qKNCBCtw9GRO
KdXodNJPaTFwSCbHdyTVVntKXCtgtwWS9pweJPXROBfD5Z6Udn+CH26E6yTJYG63UjL3IcEPLpb/
6dxD662E6GXkSultWf2Q6blnGVZp6nfdFPGgsErnAB1ELalOAQOcpgp0tFwdDzcrz5h136BY+4b9
8NEnk3+bVkvaeWnbMovCAbNomKkvvsA8NHpe6gToPjmMf+M/1tCweWSqVYDpevYSLPnnfmIaTo67
bwhYHp2gpVFrr66mc073A83yPb2BNxvtDKJKgDdMwipnzFOwycJ8VbYlE+HS1oO2MaNKd+jyv7ng
CeIdOKsBYryUQ9geRkHm4w+i1fyX3j5Nii0rUrJj4ilh5mt2B3qRHm+YHmcsHF3OnO/RTy6Q24U/
im8SY1yRH1WqgDzHNJhz2hd1hvXo5ImvBcVMJbJm7fpFQws6pAxIASNvSj9UJ5WQFk2oExjM4Z9V
8JWmGPQHXRIauUxR59a8jJBZnCwaRjb63hIVFktTqwPwCL+kbByqehjT/P0=