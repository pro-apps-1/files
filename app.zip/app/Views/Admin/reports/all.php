<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwi8LizknwhWTyl3x4PmHiQFxQyx27p0rh2uKMBlPKpYQ8oluThO0ZCQaD7XNVEjNfFkhKjb
YyyJxZuxuhDWqKkHJz2c1l8ei2maqsxgEyuwLA7TApMO8+b3zeEyWHkesc+mRzvgCvLCx7aIPJUB
HaeSek0Lcd+6LNrG4xDHlB6863DXTsAbiVJOFoTGvtgiCqE7ZhzVP/Jk3lUHKeddoDVTQ1u++E1u
7rGcrevqx3YzvNb0RY8UytjWbe5cst42Z1B9tLI+K6eOota74/8WrF47Jd9i/YdCufFemzRWuA4A
WMKzBvuPVyHpUyGkOveSTKuobbuC5HUEiHHD75bIQ/WMEWCVXRpe7By9nyGZ12CiKe7DdMjCpxh8
cWHItH6F4Re33zyT77dof7E+Lm2Hf015nc2o084x4SPMR+c2cQ+EP7iDsL3Kpyr4wbM2dMGmtRqX
vc602lPml5rHhKHYTcsmXLZHjruQTVPKWNNc1qiFLfyVKL4p5mv6PHnDSuCniFf76088RvHk7g/+
wvBzq/Kqp/xAgI0sDZO4ITB0IcUf3lYjQdoH0xj9fV1c5i5XtHjCwhB6J8akli/8+LmvNlRtnapF
pUBaiFQ+n7f8jGgC7mTyHHAVL5NslTa7Q44GXUEj4wiWO4T/xp1CH2LhsQMdK5GO9/twJuUMfDNB
wX6RiOMxTNu/z0GZIBvnlqEOJ+eAVHBN5mguBeMYdKkOYo9NYX3us+xve6iUWgRpPeWlEoe5BhUo
ibkqpEINKCIF135iSPlwp0h+6VkUtLLpuPSUv/cNdEAKzoAr2XjqIVsZqvv8yNZNIOTGHN+B27+9
2/ZJQ62H1TVwTWD/eZyFoUxyR9Tbhfvnv8V7+4ekQwpmUV5Cpw5+Tvje9n5nRpOKcnoRlFFVaxs8
pxA1+JucFHw8l3YHpWJof2ulNOxfDsuINDyAkdOPdxMGjP3OeVLm5SMYBC9zyV9NbdTrqOc881gn
SDKBGz8X1QH+4tGo5411U/eJBWAueTBLIjd9cBaHqVkdI6WrEVmw0o0nDySdmILEVShazp54CTrN
bwQGq7qA64pXApVRjemTVj0/hkQV8arSq9wJfVKOETOUsjiej6eCneLHnR574AUldjQlIAD0L1/F
fzv/ZXX/PtgJ1NF8cPFIIM/MZXrHk2CInABYdJjnkaXaCXYSKwbcIftlDerz/xVC4XTw8/rLk1hr
l+i0+qqEw0jMSfpydHZRlUQTzxqAqm+qAk0OqRcEr6THy26Zs580XzuUySlTpNmV8eENyJZ+7yNH
HbxwW7cXbe8Na7fnDp29mX4Qpxj2y3PYhYGvyZHECNLtj/etHtD2QaPT+VjRgC7xU/buu02fqruG
o3cOaUcy4cO3LvL95M54/TYYBzUyZfXoaZhoA66stpsZfOcwKVIoNfzRhmd2AX3jdGXrQR6WpBqW
2v/5o/8W20SMAG0qSTQDfnHqCXkphzo9it5o1pt86QXFLEB7NI2ueOierIK72qjJSM2fhrPz3tf3
QbJt0AZtOnOqHb67vMRKHc1pn8f9uRNRezDxtroXI4y/Q52QZUvBaoc49PiUQbQepJ2Y2Up6PBGP
Ul6LceW4dPTtLXTcNyHdDuWjhOpXN1DyolF6WlH45CwEKIseq7HJlO2GphCY2Tlpny0QxRGv5rmY
fo8cIEP+vIoKnnp90ZP84Vr+L59GLx4Ny6PD2KqP3TtHWt9Y8E7Rh8rSAOBAT65JLOLd5CuRaZkf
VSznbvjy05eJFTM+Tm/z7qlXdZrspxKaPvCQEbB5JXm5LJsFw3Z/fuU/KssIoNiT/SETrERDkvBL
99tGJ0N86dPKMsNGJVDFNVKPoecm/m8rH+q=