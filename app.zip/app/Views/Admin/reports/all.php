<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwpOt9zcToNGVnj9lDNQR1+s5Cfa1XqBgPwu2i/G2gmz2jNxg9lCqLBIUHlRgzCkwOCNgPT+
jcJhJrNu9tw3yXNukwgOIBIbiPoK567WR8HxyFdm8+B5962eUavWAPoyMwfseL8H3sdhemOdZaVc
W/TmgCRasCdicm/EECKB6rCDnqWu4fE1vFRva7ilD1/Wlc8cdOf64+VB7iBR0bRKZxChzxlzWuf/
+noEQCzYADc/ThpHnkXgBh4hOBOlpRD5I9RhSg1YcngZVFhp9aQ/7plPf4TlUin0LXDHZBpQ4JHs
Wvzu9BqOl3MVxzza8/c4Tpq+7OvDdEyXLCCQl28VfbVjStN9XSEEYvXfIj5QKKy3+XMmUuBsMyll
2r1QfOMAPL2xkk4v+e6rre567g2MrmPqgdFtStvgmiWlL+9F56Md7Y+nJtWQuOESYHao7DwWWZSW
xEPtnQgECeYhnTY+jLmUVTQUgs5taz0IjI/0AsPiacRL/xYWVJXEx/c08bb5TM/Ojs7ebHWCe7k4
MqickC1ODh9VGBJo1oNy0bdyAd+gq8TGgD1DMDvvFGUGJogdBMJyGziBR/7hl7VAcYBdwhzp9Ptp
ve4gDN7Ouzk4CNjlQAJ/AfIR+CNkqykAK8fRHGYdbdktJI+TtJG5k9pSsewK0nmWmzoZhRVfkPrR
q+or77LRtb6lyqYlDF3yr57hrKpqGQASE3NOGPVoT3U9l4S4Y4BoaOVnvafCd5hXN26f7SbQWC4m
6sx8T29PsnWT3CByVFF5uQjKcx1401QsHJK03Ly1Js6wX0g2SnEHj1E4/lAvhoF5De92Kfsx108s
5SboUSstu8qp/FA700PMjWjb2Mu2MjYZGt1W/05tdjqiqQVt+v8zt8F/jY9DkwGFgBQsLfnGoo4P
xRhtluM6xcUW0Qt0fEbD4isVwvxzjNBDjGFsCxYHBcK6iAd6MwwvlxzV8gppxkkAtGf9FTFHHDKs
8MUnNyvR28kSmdpWxw87AmuTiLKLWR7TS6Hl48M9L8iEHT94Ji2pTQ33QhCmKPMlwwD0J4kgSLAq
xHtmKwhYACjRQd5WcXiK+E+JVdDC7nLgorcKlz3eiOzT/fCJr+pRe7HoZgp3zMw5Z2A3PVZsCvq9
cZ8GoE9p9eX3Gc9WNQ6R9rKDUky34l1OYzCYNWFE1Ya/oC+rSaDTAx0K4SAHjy+BqnC0fuEu6JcA
f+mKPWzMwHPOaL3nAyYC/052sjawDqzrBYE5H6LtN1v9jOQUMN258/LeIZRY47XFZx4OYvYOT8UU
eHUelGNnZ3dNGO61o+uMmzM5M7aTZpuIvQMXEOjWKuqYfQZoWA3quzPnAumhZHbpUmbR/rwvLAgm
7+pHoY3NIClyCIBRQjWf8VgTelm/dkxzz0Y8zXwxr9mw18bNyguYqK6zbyMg6G3kSIMBfjUCijTZ
+btTyPN0PBxg83ZjLLXI0kLFKyy9bgKmugmGtlyaXL7AF+ZipQ6/YBQmuh33ckWOZJ1V+XNCfdUp
AP2Ki4HletB4uCofyZTT5UdhH7oZOlMB5ns3XakOizXeSIkWOaZvj7ZyTVHB7VIBsWMPzbNoflrE
dSQQOuMJsRBXGnaxxacLDKhEc17bkHrbdn3UbEw0X8TjN9BWYIlxwShyXBt2KoIFXEbpj/IhIGu9
mq08fh+maBcl5LIj10rGU7ggp6C6W0ie5W6w/DeNkIcqpmJDFuPIWHBPgz3GpWOFy6VVnIB6qgRw
SkSgkuf/SOkV54vixPmw/TMvx+1OQlj6ZLf6nIQ9OT07tkXyOhKvtMbv2tRwk2MnA1YAWBl4ECt3
Sitlk5fFSowDZGEus05QmlcXZZ1AhqJBUJxPdTrSsAEjv5nwEW==