<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs+pCbQwB8UPGt6dTKr6dlJJWztByF6MxiLFy64fxYX4Nh0gvqj9tYzVVudAq/MuMvIvUfhm
VfmAdBCZALdPfnV1vz7g7iDGyokPfB/aZzFSIWbH2CU37eou7xmqR85sez5v2NsCdaODfe5ea08T
VuvujoXbHrQzJa0e9DAEeGbUzLFRosD8+OWo2v3aMnmEqubj4G/iZcD8smz4VzmstCHJ80K/JL57
aOITwgvQ8fCKs9VsgRTTO3rSk+lqAGL8ApOhilPx4aPphoX2ab64hzVSx7kkQD7jh6WzYNF/cwD8
zaSb3h8mWIoaY9S102A5b66BQMLCU4SJbP+25ZP4Ygz/L192hmF/N1EJJi674Ee9BUlljFf+SaDo
LZjMqGbbj+ZAUE+xnUxxzKjqKvre90wWsHd2r0u2ZQh6M37A9/+htuXTVtA4ulBD5V1lVXQMfLAk
9xT192v7aW+8q6nF0EN/VGEbGcYq5yYTPl7tPCofVFL8QpOFxICZoEJUioMx1rbYM+Gw0SBfo00C
7i7/eOp0ULaIpHdMZYKGJCGiLZyjTGNyMPJ4Y78a56X4UkOOQDSGVrSpMp59hylz94qs+g0Zmlj0
OeM1XKLkc7MjfOrz5Y5S941IYnJu7uyIj5ONl3+Y4sa727mN/r6p/HMBjcnPtSHRVGKdtITx001l
Hj+Dni/062XOAoiYbI4WKyLLCiIrZ4uR5K+aGkNeQ5oFAFEPxrJ28LdhSo821HltwH5fh5oPECq5
NMal1Ft8KJOrLM+nDsYJjyXrg6EfwZdRfYD/lVPfWCsr9Fx/4OPaJtLcSWUE2hYaVxNlHqwgMh7m
rQocXdxmzTgNAkvNV0Tt+UeI3gkBAB1p4oJqnEuwQvHhYNjrIAgT2NgpT0OTK9B+BCcAfo46Ku2n
oeLihsiZDh8NQAkD9DaX12b5lAbxgpguaj7nxNFC0hqo61gLVH12joQtygfizCubSiTMTQs2jmke
3ZgvySG683V/NbicTGZ8LUR1yTWi5T/Mhu1iHmWnvu6MkHK7MM//vyxguAStMQrAXsWjLVW/ipjh
vSRn0FF7nA3YXsDuTgOkNFbSWeX3VTyXWHK8U5xpE3Ya/+hEVocsm3k+FrX2GWAp9rpVhyaZNILP
OkPS+B8MX255OtjC1mVH6l/LN/yOI5b7ZDlDt5J5t790p0eWZap8WGIrVSUKNxFOqH5kbu29jwBO
LEsttzEzBmDkMNlQsUT6koqQT4zdElNq8OQ/7bwmhLPw1GsnUsHSCivnWHZTKtJxDxyaQRFWxgzI
+TfnEgX1CWkIfF2EeOsPXGGehs+yhTuLrpRfGh0Nu1d+AMUe5AYWEY8vARzOx16NJk81gcaDJ6Rv
JPWwG/lVZjnNN3Eh3cscC3rNgZ9ieFRVMqHWQ5I1tcTsis3A/px0Iw/WVAsLAJjim6y5cvMc3ucs
75pJxK0gPKFzYhj/U/WmMeL3EO2cLdKijBtbAE/7uW0NOmB4jUmZFHAn5HW+ap0iTjlrpuoilgd2
Bl48hvhrxl2yChU9JNraSp9PJpZsgTUFhHYIhoCXmvWphnkK54bMBMuTA3KmlydB+NHRbV8Katno
yEUbYVW8pg7mNHPRImTTPyBSRw5DT5aHaZCzNxLQIMiuqPSbVvdURlcIs2KW93KpW+EJb2OMYzit
ijmKje8W+4xcBynsQjoOleUD5r9r/OjPOw+JRifUlaB4OfSTUuAjH68xVw1fitn6NuZ6oa/jE8K2
Y+UsSz/pG9Uggi9dD8U4EkiHsZ9FSxheAdeY87jbTRF0lm8DXHnHHNdkATeDYmENaDk+WldIDeRL
mo56Dmgv62cb+0==