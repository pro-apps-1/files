<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrecwD7+kT3cX+Lzybf7NDtRvu2N0zRVy/SEtVvqGwbr4FdI84Nh2VNe2g6q0IrmRMZcW2MC
djYa7skk8M/MUZdpiXwLlhLTKoe/gbk3MPWLgbq31yNVljiAsBR6cYxFSCTyWSK3zoAv5dqgxdAm
Pom2onGj4x6iwcP2CpTSHd3XISz01+3uJ4KVEg8/jZSfetd30THxvG09TDB5XvIGL85L4N2iaRvk
pAFIm7XUTThXuCE+6LR8aQzr2YlL+Sk/QZBOXpXkr5LG3OyzpHNDjYRtyQ0oSctOe4FJlf5CRNeV
WWB+Hd0XodGaZ6yRFcvvscIXA8+AXOSTQFuJpqwk2WI9ceWYINgKa2P7tPyasygsNMF/B0pb6S/O
oz2y3RfTbeMh69RidqpQbwldf2MV5ldjdm+xvL081kNdZqwe0wk/RYGlQzecmQ1kJIwqTolen8c4
bLQt0buEW7DoR+8D1R15qSz4374O7zW5rswKiKBaksUFJb1crAC0Tnhzgpe2XSpfaC0u5Y/5kuzl
OEy2mT0SM4X69sl2u+0AE/FtSj50cI9s7NNu4VVPoEdx/ylj2oW0Yg2v2IDynWD7njwCgIXC/vop
dpgFwNdi6YpM75GcyR/EZjKhmpQJZvY6HmDqY9DxhV7O+Z4OOXiPihH9c9vYm6CQXXn024CzYjsm
5Xe7eGBUG7629WXK6BpCSK2z+jEEpAYkpIhniZwpNdFCzgrF5obHYA8k9BgwGgCZIIb4iXdJLAnW
yeCKZwrpNQrqyb4fiHY8xwU1xnw9cN2YfMF2NKP7pKm5lQG2cuOzYCzu0sr3LPYb9Kwfhk6RPkN7
85I0u2MOXKE8KrYR4yjlUiOkHT0uDtQ5yC7NPVI1ydsSQVsp0kqD50AONVhTEAcuyFU1CSv7krTI
kP8YX6tCtemZ6pM45HQ5PqGxpeWg+hY46oyr44KFkuK0SDwc1rHA7q9/RQVE/5fbN9m0udJOcMKY
cY95Y2uUly/BzttynokNei6R8Grs/yTQ1agZxB/kgzH1vlg5Mdttne+ExEBMxxXjjoG2pDX9s789
7fCdsEuGJKGxnjscqcu/AtYnRO9LQrsElOImUtJPCBQi9dpXyDju2qj5pFmKMVNHV1K2gKP2r9VQ
or9LNPCUDZ2iSKe+hzuzzYEnusFGCwcmg4FroVZ/6w3mDaSP9eM4SbwC4XANytzEYSzK4/3TL5LT
4KJUtb9+jTBLpLvWBWURqSAXHeuMzVVglU8e5dpRe/tfmeWj50hlh/o/uEYsZcW2ohKg10X9cDYF
W9J3NMHMn3Q5XaDTO1ZauVF7KTZN9qgNub5bGGG3HueTs0UHjyms7gTUdH3mSuDsHNx/8DafhLcf
vS/VTRgFokbFhmjGjStYhmtDhmscr9dPH5iR8faY3OLQMwCG5+oUUv5gXRMXGyrnaw4OMXUd7mIJ
fHht6Tyhq1aRqvQqMSRR8LoRioXSA+GrDixTClsTjFd0XmGHo8GbjXI3wOMelch+zYCeTVvauRnd
t8r73OWI8zMLQjlLGqAZReku+SsaTz7IOzHG+yNNSGLWeOZJR6cUWQaxg3/UhhWlYPs7HPVQSwDr
RT5hWHosd9R5WM1OeJ5qCMGGpCOkfq5XRRUV5q5iNDw2JoWNmjZ/nCTze1KW/AaM2PqEfNeFrRja
unSv+aHpOSNEa+z1zaX97Yhb8vABOb92snQd3vzmMce9vWRUuHO0gF9RNbVJboB2OmkEeUHgJL4R
wjL2NaahIeOeeFW15tOuRDUf6C8KaOnYBwtbw2uc0xr5UPCx9Ybdqh6G6UA+h5oiWi5n6mJY3RUM
UrsyP+oY/Vu562Ck3SMrFdprQmO0uBRyF/Rz