<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmz8c/t71M3odeaEtkBq4eBmC4LLwn+hYViNbhBxjbEZnfsktH7rc3xaPp6B0NuWzN+qe6aJ
c5//yIBsunQcxuqcREHZPdsE05BEKG5DpHU3BUICHelJLidcQBn/y+GC1LJGUvwPDXS59U2guzuz
m8NJtTHx9Yc6tUZlpXuaqgOHdT3K5I0sEsKMawBjE9cJBUnmS96iwmm/Ni3HU/5G+zi8VCMqG+sl
MCftXYaskTjIND+CEfdJmotdlsnkvRZUEBzhVFAnZnHPpE9J5mc4XV/W9lBfSDnSAmDYx+cHF615
Tuvx3tcJ9614tlHwflTpfQy+r6B85y8hO7fKX6Z1dv1BIT9baNyxCTdc01TP21zrBg3UO51hzSRE
ZBLcEPD6QFhBDvDs+TshJVvkZuyMg/FNco5WAUQ8XgvllOlZdaQzJ3wspb3e/2XmMO0ktrdw+sGz
0udw8iYAPBZ6XdSCZparK4OfufuuOPHWpBO+kTpd4jODkiwMbNEKCh4V1yumLqIc2E4+AA6mudVO
+aVq0Fst1vlIM8++AHvCR1Tx6AWTIqQ6J0Z1qiAz+XK4NW5ocGEZbNOrD6cKVdaHfhzN3LpTSUgn
vDcIhllM52d7Qv/YWHUmNZ2WeSBZLrQseHquxQHTRNGjfg2T3G82//QoUI+6XNkbcG7kw3uzxuEI
D/Gltg/8i79Ot+bqSB59Pbt2xaizJ+NRNYbdl0x+g+OB9lqXkFuaHD/qs7mbhFm1wf9zbRYl1H4T
qikEqx+abyyAO2EhyMvdylpi+WJbPXgOeOPSeP767OkPfqEy8gONn/RZ+ZxxdA1WneTzdNb6gqwi
fONVvgh2TbMMqdM7Rah05hsTqqkeoAE+lYpDoID7qccyq8XK1CFn4DO2JELLY7aw4uVDj9ZcREmG
TmTgs4lsA+CqZt660R++9Wb+cxMAOFnGBlivCDBNOy3DAeAuN0dCUq+SG56k/nBcDYbsbBi+T8MB
JI6GqyQSFJC6sJN9mKMPwjm7pbFA1SovlaxzUR9w0TQaoS4IvvmWBDadNfptlc5Ir+5ZmFwZJ6in
ZpWvWHIINKQ38BmzI8T5R1FQwo0aaZ15Frq1KXs1e0MnSBzvfjX5y5skqYZ42/GLryzZJVe0mACd
7aYWnzx30b+RonXEUleoLcKHnFli1rYJtDRe4fZUFTlObxG3875pwenTv2F6HDxsP//0gT5dzqc9
ZNLvSi5uusMPfdR97WJ/zfry5kLWXdsAET3puXYnByOdlRBfoYIhyS/Th0numoG=