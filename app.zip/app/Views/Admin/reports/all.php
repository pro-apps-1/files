<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoqMpebspZAk3zHRgeJRQKWByZJBIYG1MhwuLUJwVkVAFSKp/Ie6O8oV9O1IQJd3VW3kGIX4
VCim2n6GOiZ9D3i/ixTvc0Gm9PKRuWhWm6LXxnAAv8akbDSUVwctKZ+0T9Tw37MyLG8g+dAPZZ5D
NePKxe5cqpdv7pqS93luVp8nwCC7PUjQL6CqZgOgCao91GrxTWTbX50UCHM4Rfu8CXpemNFrJ0vB
WOv0ng2lrl+ew6DN0tsNczBLl0SsmaV5pSoXIdpduDuQEICruOA6s+HRjR1XhMXnzZamGvbHqy6j
qxq2NCOUcVOWI4w/kYjsWEr2/XOoaZagnhtRUoJUAvmqnYfFeTcVMz3EB4g4fHJJaA/KCupWbm8n
JnnfRKcUe2FHJ60ZcUd5KD1T+T2dotKZMyxpj/CDmfSTyyc5ICvoWeW+Nxy3XUemFytS4kZHp9O/
2XT4MrX8MIMACL8KYuBsbIfQ8GUXBTkCs9+8BWZnswcMaD5LAHYkde2qb23RTQUI8aXgilRqfMNa
wEuZjX/vW3I4ldWXc/cyhyNWtR7k0L7zdfCCGYmPIcBdCTteXw8D6nX8bC+9B1uGIN2WdJrgyeGb
zcImlJd/igV9xZ8KiGkCd0Z+UGT4EI0DGMlOHtvuv7OFC/dcGJd/tPvDi+HHr8v2HK3KJB2XKWRq
bH2nHzPzXCeSCuMSJcobMDUX06ZqG7fl4/LO42Md5cs0um5CoQlG9bkzaP2frrR4QTXK08VtutXR
hk3L6nhVD8sp1oCqFRxCcERpTofVQtcF6Phml8sqwwcKi5ctIkEL6MmcNntY5ZquU1zF9AxWUB6k
Wsm8jF3S4rYF4FMppse4b4t4ZzrnmE/99tGHi5zCTqI29RQGLKYOJLHgkoDFeKPjmke390VP3AVx
MOQdYqU6olCBzrETzMx+sk/3A8f3syyOoNJVlw/W5PVrTMt31k/hooKUk4f1dX0m1byHueOltQQF
Zc8809YLJXga1nMjwskHhYlpXR4acOC8TLs9CcY6/dM74q7f6ijnefL0LeIGRcDjM0yvEPLosxa+
zoQsvJIN7QGYXVIshToiFik/ifvuuc2xyvkQVqTqMxE1Y8lpe6ZK+HJ4C1dSVe+fsxGQBpqY2Toj
buLg8Fg1Nrun0qN1v4NHRJrLo6QDXSf3fV1MK4/hhOXZvid04ZTJSNUbfxpgirYyZtxcBjZPnOgC
tBVrsdebqV1OKMAbboERhMfEAetfvDZkDj6ge57k0pibRbzwQLG5nY9UBx1xNzwgzsp3IV92XmoN
uBAdcXpjD39g2EcOAWtvzyKTPRpL7guBnRQgYyHLbVko8ifvwOMoceWY/Ob44/Wd6ggm3kKTcYKu
x/ziGgJgZ8qt92kP3mdAIFWBpoO0/dNVoce9I7E8vaMdW1/qq+7kH6YlwZHKxvQ1/7nov297L6nj
EkioHHZNp8Zisttqyv9G/tnHUpzftc2bH4oo12LMBJI6ERjR+mRHI10wUQfK/Dqz6opYmF5vvZjH
XHB3y6XeCbDkO4Mofk/an0lhV8A0Nc8wTVOSQh8omy8kAmMzuV0Q3STS7G/BiJdMaGVsOVvAJV+J
jmtTecDZY62MJ757E50kM0TEMRQuiZRt4BwmicN/GQOOn40fGvKQpUEmLcyKcOJ98dQfIin+GS6y
iOM392SHEIq7rq+2wY8142HlrUcTXvoy1DTR8L6tzw3rwKNCd9w04SSvn1AvYbt6O8GdvN39R34U
SZkyoaybjiHVE9P5O3uXdYhBi2IcobAgDujcAg0L9okMC1K9vRQhhJes+6ovkxeaQz3NweJclxJx
nU8lYgPF6Atnzw4ZfKR9jGn3g7u=