<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+L+28R/sj7mgJczdQKbeCeUgxHZ0+1QXzC39zUuhhHzX4obWJheMZTNL4FHx6GDFWEDvnXe
8EVSZPhUMbwCEPS9e63w2VwZhrEF2TIc2QJUebIR0TMoxX+XmZbeVd5RpkbqWNWLBlct8Zi3YDx/
8XMeLYiqWhp+tpCVFyUNGKaq7KX5no5gD5VpptjT2Q3byicrs3svlJHv5i0TtQ1TEXVS0RrLZ9k+
ZtBeKszOs5cnK7YaUEs/MgECvMzh5kyefqv4+8Mbi2AXEY+NIVLnj/1LIwggQYzaYq0GTLRdjVDS
JB5uLRYSPPsJP/LvIPoYRLM1A+2LVAaYLjYiLTvsrywTe6zMhUlUABz9gfI9EdIDfXnGWrCHqGtS
b+BmjXNrJWdvazHqjUenKTCw+jDuXU1DI4jMXLfWVuecrk4Y2UBatdyljxhRxit/JQXC5IK5UHIs
lAlRtNTPxNCYntP90Og9w0d9QwAO/w8YTavOkBXdDxaRLLjAtbIYPxu7m57/cGWLjifogympH1Hm
wz+MOomnJKE2tkbUZ71oppbObHv+HhVyKCZn68M75kMJQ522YRpjUlfM9wUBbCdn7Um2OK+TUiRK
B4TBOVqD9S8qZ5vbmQOxx6s0oYTtc7vvBfy/DPC1fHQwpfnT4x2pBAQXgxpNp3tCMuGfxECz4bIT
Rrvz6aCKfbD6est64W6WNceEfCrZM2BrKfvIIOl0hkbRqdN5VAT5XOtLJfx8FwKNC0WqDCZbTj2h
cjse1aHH7LmptcRclwJKkVtY0HMKm0f2isROdjkP+gNYGQwkspxbwAFIwyrpVs+ayk0noubJfQMB
u8T59y5qJX2Jw3C0PZUUxbrCixVtneTvSdaMxeY/1zqK+qgQuVEgQ2bjugDt1hZYaHudUhr6T39h
dV7k61qZ2k8t8LaSAQBKVOSL/jFl86gxlzQHZgDpy1sgEX3E5PtFLI34HQnQSroXvq58YzHHDc6m
a+EOaNBsmRYhKU4BvFPHhGnHMc5jLMIhm0iCRpB725o8Z9jdl7TKVUMELhlv7ROP3jRJaJsF1Tz+
FVdi5axDdSKm/t4vpna2Hl5dtA/qHh1HftwWZbIUlEMFfVhk6bOvtnx5ZAOVhMcTwyT8ar23LYGs
O4lotg206KPRdjrKj3Nyxr6ow+W7CHQntnVDU4b2tSy9C/VaSELJ9SmKSfYbYQvQ4NX2TDInWkUB
wseDNVo42O85VtA0mLdkY+Mm7O6J3sHK+flLTblJyVTo0t3zyBsv3348lQTqD9rLmNc0wj+7rycP
YF699kgUwu0oyPIntlhyJXXgZTsJ6nKOvrtoNJALm2Lf+ObliuU/M5FCcIO4+iwO3/+/5KTfX84K
FH8OsBK55Pc1UDhd5FLfZ+/+t7mOm5Ij88aUzWj0qp3KcQ1oCpVEvsOLfJSIIQeJTGD+oucpGKhK
JXQmNFfmnckcn6nXxVR1yNrOqanyhITcPIP0quDiaXo622sVpNH+EN357RZYrso24T44JYuoKnpK
e8HVicaKnZ4XaTSgwjQy4gtAb/xbYzXpAKM0mJN+DZV8SgP0xroUVE81m1MSjJkzh7kPII8kX0hi
U6X8gn/b4OAq8rWhVN6Kb/0mrJYXROIYB6/ARovpyPyKdEFN3E51XB3gA1IfLT9yQtm+PYgkEOTH
cA9S9tEfgE+hUsEKoOyMY3qw4xaQ8rQrdh5R53hLbH3rEXRkBZ2B+mR68FAWE4wDLNHybM1gW9XQ
cfLf65j0GcELI0b01SaHV1xVkYtVqdgBJNed4Oa8S2xIpwnT+DL/GXw3NHIxAOTLZDAKcFRRXWJn
v+nzADcfZ0oFTC/U7LwE3t7VpQrReVvA6Um=