<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtnMD1E52OqaK9IXCA3Oo7RQNb/i+PUnLDeVm9Ooo7zW3L8roSa2WqyJrP89K7ZV1EHZh9JC
lKv0hBkOhsngBwut+WPcAFxzLHXVqgArASvVsYWaoYNlqjO4BBqM/5+Jewsw5B3m1wRCY9Rk13Le
C7aKhhcuuwl02Ax+hmKDZoXMtQwJ9519/GM7X4z3J5hq2jj38SFckeuAS48YHF3pVWFrHWO1orpS
u49cV6j0G72/mfx7wADAepVgb249LTwGHdCRrTn2WgoPKlaAU/XlrUmuabQHQB3h4RZHz7xAXdLR
Y5GzNFyTnLOXEbBbMwDS1UVhEB9yc6k8Yvg88ObPK2HRLc/3SYP1WqQgEHQeEHm1skdIG1nIUPBg
bI8FxLEXGGR6sf4gVQfKS4og87s8pHBXGr4d6xB5CswKhgAw281+8dmpDlQTV4MP+4kc/cZ8jqJh
hjR/QQS2+3S3XuE4mP1VxFIDCdDXPs1s1w8IdEISoCcFocTiPDf+S5W2j8F2Jf2mKBniSoXguMTU
QR2bRssLqncml0E2ZhgczfynNA2zUxgvXSf+VMsZ6DbB9kUzKB5RM2vBH2ctWKPqrm1ORROMqeNQ
JyK1JOr+K4J3wtkt6dqq2G0YRSmuaUpj97+F6o38mKim/+4cOStOyWruv1+sor6QpTPoqw0b2Nj5
pQtEdGjP04iVTJ5VkuzJkNF++K4pCTa6ZftTBvDHtPEDd7HyLOymMNnTSUpx8i5+uazAI4hGgzG4
h114hPbXKoGMr9Ms6KekRA3dTCQK7nbpWLh/Ul+Rz4jzjda5Wl25YJfBf9CaxdWRya7NL6h++dZs
q5a5/9dgLeEo5MtMxYM+edb8hQhmh8cR0T9cg5POwSem9vsBBgptb44aJFVQIC2tuTsY17bqWHOF
2vVZaq05Z5BJiBElG84OPYDct3NztuqAJDyDcE8zb238i72JzjlO25lfvs1MLtkNn1RIGUkCvuVa
KWE3ZtOFMS+RcVX7p3We9k8hMVhYbcjXxrGRseqYrY82Qds6aIu8YbJMiautcc0Md+Zb5yFNLat/
uzmsIZN0JNS/5T2K19ZIE61xGVVIS5/+TTNyHE6jlkIlf9wTX6eJ0CPsfQRMqoCslrCs6ODgBCV7
VgrqBO7gaSKj9HgJNe3i7yU7EUweNgcBJWi4XFKlEj7Wcb5tyLm2Jq/poEW4+0yV2H1AjCmp/w/l
ekVpAWNDGGYmtI5OCb+9/+dTx/0eSB/z7ywQ5o9UPei7P0RpOfjPPnD/eUmQ1Koq/f7Nmo9+yyKx
gMkKrM1xsCP7ZVvXduJJe4dgcYTGAiNbNhY1NApmzZRUgnZr9lzP1eJ/5VAXRfriqNwOzyJ0PcSO
Rk6U2FFKSovDl2xANuVUA2B/Eb73ggEVkX+oHWvp/LcyKE8C/Hd8ZK25bvDKJmoiBw6WHCHHLbqh
bMKEhOUw6aS2g+mBnrtJt/QM+K25L31z8Y1PGjNGZyN8fmAMHHzsXSkUwy0CU+2oMlRg1GF5uj/G
V+8EmJYPLRB9c5xluBVvVmEioXHlUxw9PcWTTzdY4qnL7mhzZaK9XW9oMc+2y1nrPkGKfDqYrKkr
vRfH2lAZHoAnQBLVrq5opzWJbxmKjFIuSy5lOZVBgdXN5sM08nuWLO+W55GBbhtGtJhxMlj3VjcK
6R6BzICOLjqfRGZdgysdsLqueKUpgdlsrXJ/ueJeFrN47HFQa5TbI9DsxAyA3YHN/JF5iaT8MJ3c
CAEbiE+y8EZUQYMeGVvSM3OpLBRkkKloZe4i6y2PonXM4G5wO1f3HxD4fQINv4SXGWzaOXjDnhW1
/Er4rhYpdJxnCm==