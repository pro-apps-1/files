<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxFN7ejVYEEi9XQBgDGLJxEJ2K3AjhCeZTrYt2FeYifi5rnsjfh8ZINdISmtQDnB2WXvHOFA
9E2D4UG5EPa6L0PdfeWWC3XwvnlcFoeUCKeroORQqDy9yGyofBHgZ3JND5y5JzwgH9fXF+08Xr7W
pGZlWZ58yX7z+p4nmDEfLMYPigu2nuegpqrs2Q3Aym0bawOSg4L5LvYMmue/5SMjMN6It1r/CJ12
10icCOzBDubGatY9/n6/zq15lmmXu3yluD/Oc7jCcMQxLMV/zya8jBPrB3xVOhJqFttjeKq6ndfW
v3VS6FynFoAJdcUyBlsjLP6IBnqsf4E78hIvmhOiYJdi0pbF7jdh2ck9C9Be8TWJ+2fICAh1OJqX
7T05vZCQ1XHvJWQ4+FsRdojk0dchvXJiQfUsj6J5cH+Rm5dquEXkfZlfW6yJe7a23oMN7k4dcXRs
iQhlCr5oQ0ZCdOwQjPjIuOCTS/UD2fhYCdLwXg+E/KPoTuZK6JfeRnKeWnjUI0D0wW9a2Y4QK1P/
PdWTX9uc6vwTt6slhSpTiElnBcpXLdZQdVqgv1YUc15rGc2esPvZeiB5uZPPeYB0P1PYJCMzTzcV
e5f5XiZklRCXUxW6AwnF/FmA2caxHFp1WS2DrSODKobPs1yA4Zqng0zR2hgPw1GoqPUpOo/RU2ea
XAyGh2YH5ayxhYGoj+jaMoulXnqjwnhyPEW/q6bvD2alWnJMagAj1h++xpOf8MHqnSxpSPnF7c1m
iEN1xiTZhy7Abjl0k8x3vcDDZnnHOifPcKviE+b2rUPRu/pUn+mPu7t4bidkN9P/lA4kPmuEAJIi
pirOVy5x82ZKB10lcnKFbtVT7o9qkgIAwqOKtsBw6bpaAmFgsHuSkdM3D1O0W3/go6giU9BhW9ta
AoUYUKVAIei7TVuStEPW5HpGj1BkDfadJoQmlvdui1aos/CqRF1uKlMGL9HHry05Qj05XOr464/W
T1XLYlASMIKtqEqc11gjzLxwmoQoGnsPKUcg5zyCiy3ry+nzug72yqyHeMYMoWrg1zYiE6XMFcBh
y7pdhPh+LeNeT5Ct2bI5tt0OttYrvXZFN1y4QL+mcnb1H4RYoUL0EQM/SVc/tmvEIbVdsDV/idXn
pra2DEzGYDgohm+876QpDn3nHcOjBTlQ3aIx70RDmoXnLHJ7yvJ/TZRFCEAwrUKv6PokaQtRB9ZA
eiXpdoOagVlFCz94IDwKaXRM4iFgWNQbnoYnTBQXeoLDOCLo+NIu+68miW==