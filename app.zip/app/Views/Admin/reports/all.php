<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw4+h/nzaHFpUFqwtvGCBAPnDgXtLTo1cE50rUzAEZKjo+7lBy/t6eiEPXeUz9hZVEMQxGWe
ydCqT6cJAUV1e5JuxnYBl7JotX3w8xS3Angyuu6+8wKD/SRd4z4hS/+FmkLs5Eq9rR2+YYAtvw68
Tfw4SsnpXB2VH+6k6Rv99he61b6mWJziqjupxxuFUFDpdbBx1vzzm88sxa+EO12XFZ+uu7a/E2UN
sAoujTgebg5JK4FlnqsbJLhs0C2zYnTW+w4fTgx3q6Wd/76Lpb7MaO8rknKwRqTmjLlWXnVDExFJ
/z1QKJrL9XkyoIbqZgt2cu2NfC8le/dmMmFjEvkuo6IK6Xnk9QCbq4EmOOLFbGGiE91QUjUUY8n0
Nk1ni9eQPleNQWnW22QYsKsjz7hK31aTD8opn40t8qfOt44GyPHhIQCQLL3EFbUnZCGW47srMSff
qq9frTK68Y0Mt8k0XtsEgoD8EYmNgmS59NiFXy5zu656VRlARB/CBDbwVDnfZi/x/B5p3JLvCXcy
Qvk53vPfl9d6/FLK/tyg3oFfzDKezOhen/+jiUH/nTxBkdYTcIPS1GAtZHa6K7MGIsm8AyOfa/Hd
663WsaZDAwRGPNoreCXahG+R+SIdQ7YpIiqmQjuswC6LpdhZ+vuatrMt15F/6q4m2nfBdTptspsH
SvgeJaXuy/v0+QarQyEhg7vlvkLm4zwSCtZhqOz/EV42vBW2iFDtnoE7cTdtCptpmIGK9Bam6E8B
+ikR8XHwBsb+odpGIu1HdHhFfc7fPr+EbC4Uh4r265X8K83qAdL7MuNrZ/klrKCm5IBEbjIvnuA3
QyTPgVkWFIdMGpV6vdc9bqmKCMcooqG90KiOA7pE4zGlEczTG9IEFJOGZ/QelB4NsTHk1EImPexm
qNA1HERHvvPWQoJf1j9cnBxxkt1/JREEHw1QKpOP7aLhgZ5bnZVRr5/QiUVSSvQQ5nXRYMdu3B84
PINYJMoSxHgTqtHleH8iCLEDbAauQHXpb5RDjne4LbLg6H33qOfFACr31+KIVlb17FLWJt4OUiKr
4gfYLghqjfaqWbw+Pfr8rGtyh9+ihNdOLO87ItGZ4KCGKx3hGKd9jIhMwv4tHAlP8g73ZT+Yhdjy
TyxcY54km/OKrowKThg6ZKqiakP2QA5h1uhVhskdixqEtNzwa/u86i/njJuG9TMx6CA+BxWhg5ln
4Pu3AcewrBnzjoZGXjbziaAQ+Nt/M7o2ME4B0bx9ds0zYBYUwUtg+WqNhTh0ja/KWIGr/7R3EgDs
p+B8KnMzgQZUGf5BkH2xpHPmhgyKeczzdevqLw0EpYWX9LIH6+TOvCg171cKL456/vGMKwPdULx7
KjQMgkiEq4N11Fbl0H6MwuDda/eTD3whgYufnjmfBIMQN5Q/PFkacHdmQJzWomDpifkAcZREgNaj
0e0gahhsSdi0ogqaR+l6Y5TKh+y68J153NuU82QxCXnz7na5HNugB/C3mQJS8YLiyg/bQ/uIxmwV
PI9HFgV6MmL4W5gZQfw0ONcJ1HG/WT5k5FfTUJYmkAkUid3VamEKUyKoe4x3bA7Yp+MB6og+JdzO
oWVQQy7KdCaus39NUw6HYc+3johmBlYI7H8dRBh1/9ltawq54jt2pKGmDRopK6PtKPA87YhWDwZS
GRhuSc3LXOTXYDYMSdTmUa2CfMOb3N8e37IpPgilfi/UnQGcUCeqJPbnRFuCmeuM/+ysAa3kKF8N
w8Qy0IqEH0P+dzTokmWvfeMSd+xKBivfcyuobFMcrI0byVod4zPmoF/lGDQ+uAcdlV61ZbmTzmUh
Rsac7LJQY5clrBrp04oFePTgJ5Qz8ky5RmoWTJv5Q0==