<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpaN5xFMoEk4hzQ2a1Uflg/Ypf3eDsgjfe+utNsnqbygCc/PEhzFQKk37KRsroKtY1cp066f
b4Osjkfpgz41mpAbGZxd/XCUnQVD8EQqCHQWY8p9/gsJtIRZZIxSWh4+cUZJW4DEP38S/vRfX3in
K1AWQetF7004rHtY3QusIoPbPCLoijFT7P8wk5+mYAObs54sEGLPrqZVJ4ml7ggGsVeqvI5IFd2c
m7CUvMvSyPemL0ShS9tdsB7t7IeC3P26eJ87gTMs0bR9yaI/G9MPSJsk0aHdqHWq0D3aSchrM5w+
c9mntDx00wZ8wTvTB0kP/7sZnrXJkoeH+4Ai4YUQ4sWHPYR7By2sz+5a2N/KAglxXyFokiw5Aclp
gQCj7wj6i0Se8uuF6GkTI7I/kY69pMyiyiutySq89QNQSWYASHif+4sQBuWlSNeVzUjJ5ljumUXb
XwuokNkbna2qhG1j2T+1kBZwYAR/O7+8JD9PQHHQ9759uOlMKHDkttlhcaFOoSsjeRTb5imsLgYj
uBpzcYhfqL8h2yEFLaU4XTpq1HKLHTla04NrBiGHNwxGOdO8N9tW5KA3dM1aDCUciEnHsecHnWiY
/1cjfXVX/6YFTpPxlW8iiKTpt2NFTb6cGAtLtF9fR4dYBIx/un9EjjndVWagi0ykKgZwTeRggeXB
qWwP/mly0sh9OKxPmKoOylSYROBh6v5/IFeq7w1+omv5VXHb057tfGrtPO0mK+V+/5PGY0PRnHDK
9wZPdN+eVgmLVlg1iJaJJ52WlV4ua5FyRikzk9l0dxodwFQokEYQFexBGT1+UO7W6HC+AYxub/h8
LGkYUZZtgek3DZ5UzOh4yiObB4xqLtZNivrMJFgxjOrtLPn1kJ5evpeZZz/lbXylkgO6bcpyjakU
th9JeDnApK/MO0nXbQ0d8YotaXw/c+y1jL9tqdfPvjnYewG1jnFGLAbYBgIXzLEgkl5tPBQzxaIF
49F0Y8VPOwlO4PXSQNzJFu5iY/RC3CTc/YV7tCPwVZcA3PYw6pgE2knIuMmMo0Kkig/Z3YjxCIJ0
etbSCP2UCBg2Hw0n/E+mSpcQ/krnPCelTs3K4sw0NqutUBUbHV69n23aCBGuK7rUk7NYWXK/DUfq
09cTSkFSPq5EqUzdyHISycmzOo8rfI/C7fYcjvW8oBAIPd43LTsL6Wvt2KIr2SGf82w59mkGBVjs
funTGIWQwSc3CriN/IPFSKD1n1L5W6IUkr8qR5IGEXYTTroiCsQrXm==