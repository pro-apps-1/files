<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqnbl1O4/WHPqQGfDKu+e0IXjHrvZtNg7SzHxETATB0Jk7BOK7dyt6DRsr7PfWRI9IxOl3xr
zU5dgdZH40IIqvBmN6mxKk8EXzcZyf1JwAsLaknFdVwqB24d0RFKdZ/LMZY/n2dued4rYzP2v2RU
xdMIH+d6HMDQuuZqzQXuL/wXP5vFZIux12oqM8j8XGXnkbRvlP0/OzjGC44IAp9vXVYbdBfPGM6/
fLr2mYlyLhRfq/Njo0aCl2z2oCR4pcOo5XAowoiduPHCdVQyEGY+b4ss9uU+VsqFXCziXHLfvNYk
ZlDXvdYhTvr6DpXDDkiKnZltXPF6PNpcVKc97jHBjksufIAsQz5V5cnmEuZwPwo5JgzX0nIcekiC
DN6D7WJFOyCTG5dBmAjHudKikdngeycZrdDqwVhXb6IeVNI5H/GLl5lH7PIfn4mj7gt+TXwpU9cK
TyZBIRpvNDFjOa7JAky42g9lohpPdDAwH+/OGXcLw80zpvD9HUqmXbUsvFVQpujMBmsEjsOwkcLd
MNznYyK/c1CwKxBq9fkJKYVClQogJ3MpB/Y9YKaVWhyvLBmiqX3+Dns1sGSQEm+6QiyBsM2idjAk
UenQDoCus1diUaeDNYOQXb5yESmAd3TGXGTR04xXJEYzeSGz2FzU/XGjpLar6GcBCM8kiXOVuRl2
wsf/J1HKhW+bfeD5PxavRJ41oQ6M1yDIa+0bA4ERXcxwfTiSIJMp/sKRFt+0I6q2QcdHEQhsC4X6
kFfr/THLh5uqN7CtSfChpFodOs0CQMFE+LmE3aEBbC3b6IxXlWsjx1KkFOeB2SOcmGEsQCbOmF09
dqbPczpsYOVgr3DHIiM4VMiwpm4cpH2JFPhfkUDOlQ6TISLJoSn9fu/WLRG0wKEuoCC8pP7pS7z6
/sduZuVGnPBoFuLChY35H5W0GGh3q0uLUTjSKDKk9td5JcIrWzpwFaRAzM7fKB7A2MJPqXWszY2V
P6xFTVGLbKX1luq1HiQnnHHyfKrdsx3eRC0c2vxu6Kx0F+iavyv/xK88Qt45EiFK6nAR0rjd5v1c
vdeowU3d8o2JrSQ/ZVVpGe9v/LWvY+h348De4shLYUE09e47AIQTauTyOJ7TtjbhaOMS0thQGkCx
9t7dnpZcMiJTjq8WpSxdt9S094yEKvqLKjzHdHao/5bAKWaQoT+oVqo672rRrDlzh3A7rabSPTsA
1HPL96hyOM1AQhW9MWYyxDgK4oL9GxSurztzOEedhJ9TbnO=