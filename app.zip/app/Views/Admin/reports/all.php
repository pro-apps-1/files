<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+Hu1BixrFoymhgHc1VGJUi01L1TJw/xUyuvG/VaswSFOP6ji0dGgf/dUPXUb8Jl6Gy1lDp1
iEjZB7jPLnPdsgOFgH+92XhmG1Obi1SX5Ou8htz0oMt3AqRlLTHxwJ5jmc9QXvDW9919+QckOOLx
SpjMJr7oI2UCg+sQZUsMXETAyIH53OH4HSRWhKiX446zhjkTPtpTUbip6JOfhOmGcpsoWfbyrCIU
gBngpkxfthCVcpGKurOpGPaHQIkjMyQG3QGlXX0XlaL3Uh/9X1QHvBbCUHysBcUmxepaLW0Nd8z3
mGdlnIy/NUMoB1eWYSQjg6Rh+Nc535MZRprkShHHX1sBI7tugPfAnPtrzA50siQEc3sYtLZ4Dv75
nO6OQnT2lHqaY6SxZwKhlzmS13FDNw0z2NTl16yhL9b/UCC8FyV+Qscls8YxmmKVXtMatzlJYq0i
ZPDaKez8oX4dYEPTv0MM+q5+ZgPdkfFWTk2XdAvMF/DZZ88HI9eiPsPJAqo2HAY1n8JPc0QDeDkL
ntxTrJ4xwXrxc3HC7RS0R/shR16hh7lxvRKsabdsOeukJnLWuZj5JfvgxcMyobD8J8OOzmridNsE
CMOZ8gtoCrjoeV8K4riF2AAK6qYC4wqQHASgansEAuoMMMKJHV+0wAsk82AsA2G4jvOG6SzgIDBn
PUyDRqRUnVrAsWmJDQYMs8WciFOKd/H/feVFymHsIn7JpMAqS/hj7x3DRcBx+oDyFjTfb0Z35ms+
48D9XHp5P1lWHRJrVbEP4tMV38lKLE2vlFPuuEE1wYsnmh3vL8RCmwVfZleoYXEStgPeCmqUoQiA
/0+GrGwyI/f/QBkc9S7kHN8/G60j9o34wzQa23B8dg6qnExSD0kZGga989TROOTKoiiOLSCpONpt
4C3wfP3VN4ewEHGXg4E3Ls7oYv7WR7KvjCCDPOBLe8iCRhe2Ue2OgPkCmBMb4BtJC91f/KFLmMFf
Oev1VhpWAKz3/uElvLtml5IzmD9DykEeStKhuD2YZU5xiSNHo5v4fY8+J3t983sSgpRIrUshQxGH
xgOfbEzNWOscsyb591PMsq954XIBnXMxX3TtT+lrlVCGmsaLc8YDpGxPv3dR0JrsLYKYx97vlsbc
ZlWAJV6Tig686FerOyvyG1jtP2aIXSeWL0kWE0dQyWaDeNiRv/1Mgf87m5gWWsqZ7cxpFpcooSTA
LMX3EcdZHMdMQIbEbIaUD5auDyhoKTnh8FatpW3FkmuqrfQIeZP2Im3CLXR3eKGjlmCSdmVCAoeA
/i3VZTBiBle71vFOoDz2tinBwqUnE4/2OEBZUPqt/qmKafRccYC6TdSXgJCwWpaQ+DUrhBQ/zemw
4Hh2JJ+hbtFAh72SjXWX6O/Se7Hw/YztPUjWSgiCEhejGJfE0FRTH67R7jUjV2drUgOQIH1PLIN8
MCvGTkw11bZGZaDwG3hr8yt0DFSmpGDY6O5A3CW57OXNqxIQoarzPp6vRLXo2tWhusFuyZUHB8TK
g/9LhbwhFpM/gzjTi/yN6SpjEqX9PWvgGtaI/ivfDHnmVM1J1IflC6M1BvwYNOoGTWEBWNpf0cGa
/jczBNSN4kfB4XzCt6W2q23ak4DMyy67ngX9V4suwhXe4lSFEmV1V+8FbRGhcL4XqD4DdmQbUWzY
gYOPh4vafy3tBYcIA6yMRH4mui1/dHvCZNWAX5YItnCAqVUOyHgdP7/5B0UQv+/7ziNiAvKQhp5j
U6c/9xpw3EN/j9FJHBoc8BstBXIl4othtVpz6Utua1wTdIrbzfS+rVbEMItF29jNvsWgWxxLFl+G
9as0Y4NpCuuSMZAZlp6aum==