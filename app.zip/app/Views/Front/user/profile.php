<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr1zzz6a3ypciPDYyfdlaSOsjV7MvwRPnFrifaCF+E/4c3AWAB3vzChMAcpLqXLZXWk5pFuW
er6SYK9ihVXIS8LAywMak+brWwQXgjb1fmG3R/jA1l3V/qqCAs2YTJ80mBQ5bNo0vZiJsbaZX2nH
j6VCPMARHybdhCjc4rj8/De4bQpuH0ysX4lIcNlHhXBqYVfAv5hPWrz7OtmVPt88iKVxnb6EHPRj
pNF43UpvbP+kESDegRxr++YvsLQHx1prBoi1z/AnZnHPpE9J5mc4XV/W9lB0T11QXC/rzwCi94r5
znfwI3Fwutth1qOO7RAxeHLgWR5YoVz8wEFMn7W6GF8cnTMwIbnH0pCL7vvpmRGLzQv2xFXYUM+8
4Gx6tAEkrihZWMRmo5CeqngfjHG7p/Y27z0FxQjNf39wDUZLzZrxqCXfRn6+k4R+cocVSL2GiSg6
6FXMdTYkX707+yRY9dkY4fKnuUlU6h+0fe/illbsmqT3t7+Qboq1ADm1hlHK4MM1+/g3apIJMLLB
l2flrl7Cii6Sd801D9TwtIMcLBnSNae42Ml3pdPGuvLskebBZqK0bSeQZBs4xG1/YnQSMUonfz40
4dx2XGuJ5r+gaKDXU+7mjhZH12dndC0qsoQ3C/upZaSF1Am/Hy0Yv4HlCf4cv/0GjcsqvIlMwtfp
9ucBqMWwqGkTrFqEP6wb9mLb1c8wOe4UJyqxzvdYOSd4tLCzpKiVeB3+JLyjhF6ruNL/Gnn8p3Oe
Z7bjAFDFxFlxXzdCRvV7eVmeZtts1DXHsVVeNLA1mT3ki6wYc9YwOuYUI6fQJjs41CXfhNKXTm/v
0UK79OSb8wXAgrHlzbwKf/mNQ/g2aZrrjqWM3jLg6HNgHQXJ75i2w9suNiY1+hi/jUsM4KzSaH3t
X+jhNiRMWwX86ANShDbCHFjzTykRIH3QULiOEBH5ms/dnvKbrSd/u8BQGXeCVUQwnS2V/TcykHJh
SKIrcLWtCZPm0r1hVbx/JxomGG+0Kfss06K1yIT3KQTpZs8zB9xGJEN/1h4/Id/7b1f8QH1ONyWg
KGU8OZDUoYhMFPVAR/szlZZdH8pWV0w7QZZy/NpuqlMv7IExEBUXvq9aj1lPN5IA3ZUIqsPOhfYi
8raBiY7cnLMthB2XEc5k2aQ80FsuQ7g/fzJiwh6hEsUsCOXhSRozhx1UWaE24a61clqhiF7ab/hW
r6gRt7O5lUFUcYtw+VX1rC1x8b4vGVx8qIDteG4+GozTnFXTzdGdJ14GW5Iisv3ACMMqIYxMhY5d
1VEzCssI9/pkTu0UnLm65AauLSX02GwT+fq01w22HpaR9d0SQqK3kzD73/y9E8z9z0Mot5+ytIuS
Ywb9JIqYC3bPFeqJ6NkIA8O1fbgW95j8lUmOUmzC6duZMHjHgfwK+peXDgnFe6txh5fJRNqRrc/W
lZevGuSI5Wdsh7iWPIBb8QvrT1wPINOs8LZjI9l6vIp5+JAtK9Z32Rz2LibFVm6Eo5/jB93LJ/nR
dSmGrwhnboiHmeOEZRGv/k8eHXm2SZOum6ZMX0/nQlqu9lZUjGACXE3u/24gAluPnCLig+0BOxnn
QEi6B+CxLN7Rwq8Zm4SeRFAt6fLpATLdlJ1kLM8fXWT98CVkLhLpq64uxNOLNisfEdOKwcZ4GuJZ
HJyNQWB0vv0x8Z1KVG0SexZa+WG13zKbdQ+Od/ILheMriXM5uEdnmwr5RH3l5khPyFWQYTB/hP3i
1BMgLoq6zEw0EaA34LNLpH5kIoY2EDiRmqhsLyv9A26gYt5lnurWmBVQzmx8DcdLXZ0pSJBrxtQM
W/xL3VY9xaGrC+deNDg3VUPgyVs6I0xDW4TIbN/3ccrT2v2LY0dwKzNtlkjjfyUu1qp3plw4Bdg+
xlk6xnEKJVQSaLnRVfhzm2SBp420UdCMl/AjXAfo08Yxzk0LGgDagzPZh5GNexU649SD8OFuuxIu
T/SJcX8B/MaXGtuYQEo3n88Ch/TxFymwW2gV1UL2qdeEbWCZWofqDxfF+FV2Z2EAk4I+NG3nX1dD
OIh3OQkswV7KKhZxtq422qzKRjRyeiLXp0yi0JAcwPaJSMWf0IM7yimDdAZ3EB/MEYoe9Nx3pUVp
EiTl5jXU/LnCptUx0QoFCHXa3embp8fhnhAdFvy5XdFiErMNahyTL2NnNXRFgZhUuFFMl5b2jeBi
B+PTAR7GS0u1cmP3cSI4WwbpRcKJfPEOCm/5KJPbCPBqUlO7sNwN/607U1VKFxgHpTo1LIztUkuU
2yQRltqf0MRB0JYxBK8UfL9gP2FOMPim66yhVDRIeTqqlOSuWjy0TVB/amVnIvfzTpZ4oP/ZaxDR
u4YVqwxCspM/ik+6sInSaoSf1RC+0+2C4XEIB5ZIwxt9fy90rusNZv7epJGdaYSOwzrfTB7nK6vf
U1Ds/n0mjna1Jya4iENgGc2/v5dWs/a5z7tTJOIwgm8DgHIRVXjad00iBY/B0A2GIJudgYVUeD0v
j0+iLLdMSWcG3wGcVvajA1rZ43UwVsq8IXFm2ErHt3Do1MjoL1nW7vwj6Vv8Q2OfLy53iqdc7nN8
EB61QzOpY6XES9FsE6pB599TpS7NL1vnyBMirQDjBFqTz0UnK8q3pacRSoDOYHqIboKOjroRvfkW
t4haFtH6mGvVWknWgE0OcnxFZoRQc2HEGroc9RXOFZJz92fJgIAelAbpnb9AN4uXInUkB0o3bOO2
/zOm/65uimTYCF0Jo2iIygw5jcx6HxFD0jEbKbY+7/CSRy5Yiuuwgoit4sNhMJTR51LxtWksM4Vu
07kb53LE9Xmth/V/6c1nvKRR34paU7Dt7CGNXSh/bD0ktdYXjxmHdH3SjqMBx/cxlm2vxGGCaoez
CqidGBzRNCVyK2fd0sTV62/IjV8Bh0Ho2J5f7QyrUhlUWDaW/woalYojyJrqJzijGtPeJBD1g64Y
h8z5j6Mof4rsVCluPgL57jgQalpRlRVdMrz3b2D5x8d37qyv+fOPet702jt22lQ5FUn+2GOZk5VA
bLh4aeJtNbvpi6NGTgF/VMqH52ptveLRXdT8qZSjn+TOzFmjWi8tPqcpkdU8GaAJxi8rezTA7bQd
z5UdrxjGRnnZ6G/L5BBUdgs7bmSREMxvhbGunmSRBYu5maNJJRzbe+POYl12DL5U4s1HAcZR9//F
6uECvQvV5igGrc9vNR1YHMw+5w0gGfkFNvVZRUFTeoLnWusDFS93Mre28WJHoauaBk9E7fnpwHWf
aRCk0oEx0wTqU9bPJNQdr4fE/CsVeJqbJcwUJPQpigO5tUdCAAx97wddD8WsZhaxaAPT9mGt6WCR
U5VzgBluToPpofSF0dAwuR+e53qiKkh/5Yk297hIZYe3UUrTYfmJoKxlwfd7mm6/N0Cu4pSvBbdW
7TD/xHkZC/yN5x0OyT0lRDCt48eWp4sal6BHXHfrIwnXTsNqvANOH5I8xb0rhAq2b8Kt7xJ3XUkQ
+68cKdpBECTqZz6HcYLiPWV2a8DGkzl44/DTrK9zESkqSxaxLysnSddg8KcPDlsNsW7trDrw3PHH
wRp4R6JPM/T593COsUa+DQP0yEgcbj7WAuGn4RM8jbWFXQ01vM+Ef6DaGc/D8Pezs398g8bnq7x7
FkLRNDC1BzyAriF4wjDIbe0ndyhzXrwWhnKCwKaYYt4l7fCabPh0/noCJOkBbuaBKtq3DzQUsNuh
HD8jG0O36S2wEShpTrrbKY9x5RsWhzv+Q0/4YXtvfJcWIgCD9dTnniKM8DpKNCyzTAE1shuPSZPg
dMpxht5PlzMKiR3iiQMD99MCZUKJs7PDcYRe4BbOEdn2iG6fTCeoHko+x7iNVD7fUWMX8aJEBoOD
lqTg4Y6qrTrKnc/MRXJD6FvsNN65GM0S4LUDT+HCBKaEbpEPLAiFJotytumMM+AbADSIqPoTvZDX
2AJOIo1CWGqrijYvCb+itT4T4NWgvYT2EsNeDbKWT+a863yrMp5YgKnF80nbl8DLsvWgHsP7xxIs
V1ribzXcB7E43bme0Fb4WOk7yzZV+tDt1ifbsoi2CoJloOKfda3Viw4818EPOZGlNwe0ySGHxXt1
fQ2fs8YsJIll44sivHgCB1n70dENmh9XjSajfFhYOrT9EXiDcT6hPAktLRDoV7BtYdi6NcOS9BTJ
fSKT8BYi7AaoZW5F/tRmagZOjJWfib+Cd79yWn7oN1eazNfKewJcdTB54YbwCcf2wT2E93es04gr
3axbDbgiOj322sHzKUeGfOsgY+5ceCawbOhYy3UsdWDCpOskmTd5sZ+fP1rRBnRVQIbh6L1x32Tx
kP8ueOct1OpOoD+WXutJ4rA6OwVWgXR/VbcS28U6W8O94zrNeqa9PX4z253YzDNMoyBQciSouS2w
p7OrT8OrVX3cQ+sm7PYXdzSxz0RgqcMKnFkZaf1dTxSuT0GtIKQBrWnZ3/y4lAJtJnSmv4tH5Vjg
ecfTy2EhVlYRh5EWENFWrgUqSTF/ilcXP50RwBnJi3v9vT7K7kHt/nkBvG8WLnK4yZbaoCYEdktv
g7OBEY55QhyZ29wqT/REbvBJzzxMtDLrtWeqOqN2hhYp/MT6Jywv3cBmU36M5alZAy71FQa18Qwi
slHYV3sKXS+rdaJitpq+Iu0qq8Fvv9WO5J2IAPV2xMbt7ngIV0YrOq1UKxiO40pyNJubi+etHqXp
4ogRpadiy5CMRv7WzaDasMbM2p2nQ5QMBJSuajrhWWd4THIEQm8AhJbHaZ4emNshcBom1wwZPPnx
EKpJt1OhTe883cwdAPDs/wO1Rgr/IVo68K27BJtwizK2gpjEAowxy60dbUHfre4QYpATIwJM01v8
MrcRQ/afaLSE17HLSg4iFtTz0pa0f4bqzMbwmeIurcj1fBTjt23MtHLdgoRAuLHUiLQACZxeH/p3
xyds+EySp2zCDcjL/QK472Z9c3B38rnMlQ686tC4luQFVnArxsIdCaA/pqN9Xl1IERDZ0aOIlpXG
kVqFgrcy8h716lXQHXj5MmqoyDztd2bNQx0ber7mQRea/z8CJWz+GbTqdGOQJ+8AgzGrnlkR3+CT
3dGdGceQeQn6K6NG10597ZbYHWIc1t0z8gHjHDQcaty2fRPXKaP1khF56XrmBy23zuf9qX7DZPqO
34VPsSqORYXld/cH27dPY2sFuJ9+/0N1zSig2ChiOIvneSWhN8IdJNhxCqHFzrxg2XZ8uDjWt8i7
06axaAdnQELwOoYwv+QmlycA1JyjifvnDMVQjhlE69+GSlocEvEuKtTXC9qBXmjoZNyYpWOXbJLE
sjQwxNYjblX5Zrd1uVbqsCrNtA7641582FzeDZI7BzZSWd6HpvXaHqcusucd2praJHlEAdUDy3TS
KIDm3f4mMQy6pxLo+Ob6AqH+M56mw8R6rovYMSr0UbeliIFJuXXXe74Ew+uPNTSt91b052C0O3Ux
ENe1PtPtxag3h6pGWLLZ00NClqh/8qjJkHwnLsGXX+K/EB+0H1O+asiIQPo163BKmsSd+KVPNPsq
uhUQzDzxpbFKYvRgnXhqXl4XD4Oa6wO7FfF9N8sVySfz4ku9q/ofG8dSy6dheKc9GyKPrckDPerU
bCcH6Mbm8o44v/G/KyBaaF8iHUUBqYULPtvxRI/3L+338H7frRitLg7luJkpuOBTqKu3sEQL7YzV
L8BGek1YWXeC4zmgT/eMJCkJB58TIg+Hoib0Nyn6xD5CZp+OZAR227FItVU7p4z1vwFdAsQLD07z
BVJ62jo+JlfeQav7yGepDZYkmLRxI0J7iy88BRtRUQ1rq2Yq9swfOjJ1pYchWDXjVdyxub6KapW6
WDUqxy+gvjh16cUtn+vDDtAR3zkyJdc0XbkZLbuCwsysEz2IWlwR7lZkHqVYJcN/TWgUseosn6q7
ll2nxzFfTTaaCRNpVa5vNdEQl1zTSHyaU5uaA0TaKiqMQewJASEc4t0fqxFk+gCmGEZKuvU4hByi
sN04u0UYdaHgLmZLH42ZaYtSXP/hue72q95VpCbGCO4DTs3mT61prVkenZSWn0dZ4v7m7Dfz3YjP
1fRVpmpoORH46v2PNeErk0rOk1gynWn9Xkb5Q2/liL15YHuB7aexr8eRBYUDm+382sY2+Z+NGkvi
6xaIixagSx+jyj68ypd3BOwAQz1cpgRiwkmN61SE2FvZhed4rxpZS0B7lIov2KpEHskiAPUvSkPL
A0oUBtIcLb/JuS+cMru5EI0T/KyG+blNICWP9pV9/EpTrUahyvoarIMtiOg3b27zNDkor8RuQOou
HvrSY5y48xyV20PrKScto1m/qi8linlJ9L7XlvE6oJlcBWtcKaVIbXuLw46w1tBL9gngnhOWb71y
AsxfTfl1L29qKHxy7RfR4QiuJsUaOgUfIY7nm/5XLbH8DLsND/7F4Y3bxh7ZygkQME3AWW6yMQpv
OmMxbiLqkrt1ib26Zz2XCTUxpMcxxTQPxTWuFfI+VwO4hEeYjy9l01NKjTMMu+UqcgtTlC56z2tt
DNoLqNIde0hOgU3s9UXvaEYxs0eaxzYSiM6jj7WGA2u6sexR22MLzolWcsOrPLnj4JGqYhb1ESEK
diNw0m0HN60W6hR3klUagagu5iAOZEcMO1iNIp9ACoLI06AcfTZVIXCYdEnML+Z6ziJhtJzBVGhZ
ai5ZwcvIh03fGPLwNs3SzyhVJW/ywmVpTFh2xcOJbimPL1HRBpcSlNLfYqZPsuz6UknR9GHVwSOB
kEbsaJ9KZ1f1ocL49gjto6+YaZblkQphk+3tSrBepcY7abKm0ZvuCBRnz+XzG45qKHHVCdcGzbGF
/J0bv4ZRPuJ0rDvdLRFdzRNfnZ5CdebmMfSxGtdX48paVagyI9WXp1L1bYcWULVyRgp88FC99gNO
mclxBzHmwzmBy5Edau1B79yYKToIpIl6KZg4fOlaen5Euk7YcNkIuF85VM+2vUbAJt+DtPu7TBGM
dMG8lN7DAxlim2oS7o9ivuJmEeqo5okJOTN4byAdLNYvgyZ3H7oRzcCSE7JqXDnMdRiNbdQBnNps
aruuERvGS58XMEHoCUPzPW/C6OSzcOleVku89de1s6RF/q0AjvlOykAcu8CjBbSR8GC9Jmr+9xQb
CJtxueV7xFhOHV6B7WuhInmXlG2PlvZGaMDGH1+WDPbdgbMfob2cy+L5pYmzHDou9bX9QBStm/PW
upwlTJaV+MjJPTPgHcHxn+CFojeIlJKuHhr7lp/dGNbl4bAJ3lrGDBeOJa6+YNWo6CWD0LpHJz2T
HFPripil2wl/QDpId+Cqfz7IYbv4gxC8HLo/utn6spQzsyTXndJL64yvmpUCCscoqfRBOuhyanKw
CSu2dTHugLMusDsqlG1zVJfkKiNaqG2Z8hHBoFxJE9IJRo861WF8omtEvPlpkuaHg9cQ7qrdmZLp
fnccMqfAWNUmgrxzYXZKPHI53FLrQ1BKvCk98M/E4LkWB53j8BgnEjcuBp2+kxc2oKnWWAqHVqB3
sXmMUUMa7HVfIi/HBxCT8eDV8rmCLUazBn6VH7irvIsu3x9gm/eDNdei15x/6qkyG+aFfnQ47SXt
cBaWTTcBNUM8BKjY5xtyMIlzNeJrf70NuA2BUqt4b4xYizsEDl9By/20T2M0qVbheIPMPXrGVs62
08hwDs6OG6jcwTEhd12g3ccRSLsIlam1tOyCsVIjB29EZVPQSd9sMbsNvdfXvBNDUq+L0y9LbjDE
swRNvPR86iqFlxw6ONWtYJFKmEzGqpiqP1G74axXe7IRPqpYCEBJEXW1BLoBvhbV+fN5800ePXPD
0s5UxVaE8iTavjvAiVUwEo5Tqjs1bo7T6rN7/fQg5EBtrhfz2GacaaskNbNcc+9mqEjG+Rvj55XD
bqqpW4/hOzHrpEXlIhfzFXCi1uRpy2sqaWEHBB6JPrh2y3fRdWK8woKldeoBcyLqbEcGkN2nnL9B
WpGMNyDdhDRR5jZeBWmAPdhlocgWkr+rO0kQ7d6Fl3Kb+yvi1Vp+kmZV4mrMp6Ni+ePo1HKomupa
BfY8O5ZTuF0Dm1PMCkj3ABMxb5XttN0C+zalOw51ljxPz9WLXe2mgrMmIqZmbETDrxM3hI6TNLvQ
nYMQfNEPzMiUfOPApLXOkPrkR1w5zO3R3+MUd4fcxs/qLjxhbzxAXCL7jsI3Fzj0uIIgerIpzyoR
Ljpf/9a3n7svWgc4Ym9Xe3ZUxUTwsuvc6qKjNMtyalCIJ9fGkeZlOzKYx6wSq4LaRGLMCAxjPdS9
/0pTEcBf5s3ONS9FLR7cYH31t6Ki5dGTV39aAgsvoUhVh8wB1qVv6ASD3465C9Rf2zoM7HPmNCm6
n+Fd3UKJDLN3cd/OWn3UuMN7Q3/DAOqIAdZX7qkse9w0iawAIoULe7DdvUkwSiECs0==