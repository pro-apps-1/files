<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpgWf2dnG1qEZ4un2ijg13el34mQejnsmAoun2AhfWezoQsjU3OOKwIjN6VsKfm1AtdWrobt
kTqFjeHiDY+p0WeDyzqaB6YIK/NtehFuJ3qBvrVFDRSZbmhDrUwqxN2gjzA13uY5x28UGiJkNNBw
KiEp/84T90CjCu19GfWtkN4o4m3yRX7Q8g7LGX/izm7ArSSRCWdIKCJw3YbJRDTSXwtI0bvZeD6I
eWWbVg/HIy+lmL+XrZIeYQKpEZiDh+Jm0H9/f73U7N0fAkuXIPj47u5uMa5YQZ7eFbXJyNl5o/6k
LiSV/m14oW3hUPJ60UG+0ncRKrUpKp6PMUCNkYXJmmM2p/HltHO40kt9MTqe2TE1Tj2uvu1RC2PJ
yxgRcGMVUTrTpceo9AhRzcQtINtyPwpPKDu7HoqL7vVnltVehHl+2njviRNkzmKkXA7BuG71VD98
xVHvnYvzfu058t5vGW5UzocJq2XcYFDpRerNpgYRCgU4Je7GDAnWm6AX2q9GS5PoCOsiJKCaVF2o
xi8kjOVZPZCudrxCQ+43stn0CA+JbeBwXwjoGG73qQ5YbS8fmdvwwBwIKfjtuVqOAgd0Zyd70HJk
Em68jEa/mmDiwT72d6+22G+nXTm/vUVc5PipM0bykdzfC0Rcjms7mni6UDqM52G//22wB9kZa0uU
zPZzRK4Css2vV9lUiQ5eK8nrCE6oZYbauKxbBc+H4pARBNqsR0NGnEEC/kBcLU5wNGtDO6V7qLcG
hR9GaSz5c8LcHp2aElP7Aa6tlyvupILldo9fHs66PyUro3HjEKYIGoWRbXOpasl5JCaJti4orIeS
lqhcocBkiO/381WSGf7umjmCwtVgKY9ecGBCh5a/A29CLz99NqbJLUF2YMHM9CqcC8QnVHZcgXkL
1v6Rkc9C/ypd/ATzVp0mAQnASZ+zK3blnvOB52Yg4HG6H472qz0T4npkCXrd5nSoYS/gte5x1qNx
axDAbSHWaXgoFvCEVlyzUUEzQpznAYAJJaS544flqm0OJELmAYuCWFQI8VGDSUuXR2OrFd7+5AMq
ZUm/dzMG05Y4DrokkphPIO8UtbSG4G/3iA+rXIgHg8agDe2yd46/IyXep1zYs/0CEIKktpk9m6Ge
PO1fyOG3byisS/jdcy7qkLEUksQNpv4w7c8ilxNJO1mf7UJLw78MUqZl40UtxfTdWz1dKIgG5azR
2Wi32N1BsGgwwHbkNUrQ6uJYd+pw/VedEWKYu31uOif4XCwIoJSiy86vfsTA2Hn5TNmWnK50a3iY
svkbB3aXAi0CMwIZXtow3re8mprafAc5g2Zjo0Dx+ETL8hzn/kALzpqj/uPbdFpBg/Hzej1ymNlb
b/rcMXNXxFeVKbPoZkgkGog4OLvVSVLe5lQK6FH5zVjwZcipD0UzThkvW3++LABvRLxLRN2LVvjy
5/+xNhqm4FkpYyyPU0qDT3aqE3wKjFpmEtd3FIKOAskJXeaJYAcDn86a0bE8PHvxzfiilxpWxvTU
2BSLnaNm5cS+aTwOtURKpsPlwz0K6Of6sThGmfbzS9JgHUllZaVZXz24+iw6Ld1kCcPBg56UpFuH
1ZASLKqCaYb5tNtT4HqrX6MjaqRZL7j69bQgq8lTinQvL4TTsGcV2Ko/f0J94kIBq0aC/5jbMK/q
xd1DAgSmN8t6PoeeKr3/MuChrKJKQW7n0vCmwVI6+F0EMPVDQ9wofy2o3iB+wqvo58M9YLZKVHE+
WTmmA47xplwXVeTWe88Cb45QfKBTq31SuQaDvCw00E8uQuJnDYhZNnzbeRv1pG9++epUnrx9+3fU
EzJjeE56hZfE/rcnPFBpkby/rqNLW1MgkVEsiGOM/jw5B502+HDCU90iLHPoXW/R0INaJ0UvwLwi
ryxuxMjkva0/T0vbvf+pQKYAg1jUEJZLYY4q4EdynpxYKsUW+Pw+bwCT/GcgA6ZpFNSJBHC9xPBd
1fYo+XEiZ4kR/m3l9Yn06v5juYFUMxCZiDPiqSmmNpNQS09uMNgDgKhXH/yv3rpL/GMk4qLJt7Nw
Et2Jr6n8huU8+QoAbMfgzEOvBq+j8upKRZaBDHbxeXFd2hbn8WvfAu4CHf23s6R+NZ7pbWpuQH4v
h80R64FbqiQT3J3SDzjhGndfzgyGKcSO1eKAAyPI0bbKeieYEofI2SI7ABj5YJ6YqEs1ch4gpcFg
lAyDngmAjXI+c10KZUkj4tPTSY8nGnqSi9yizNevg4GZdW4cky+GDZ66q2jiCh1hlOqUuY7bh6LU
yhv0rKS4aUzhzYwvkin5Ve15xJ2ODvF6D6Ev8l3ndA4kLegs1D/uH8MpdSE8vA2pX5JRVGKZiYKP
+Jq6YD40Md6M8dCRORX2icATtZLK+/sz1Cus/iz/HoqTy8USjHY31/ridADmRVCSsYlQd8L93QNQ
A8eTCMqiIUCY0L2RxK7ASMUFRZU1wO7HzfwRn2iDmv0TWlFl57onvy4atIGOak6cgYzSf9ZadF0b
ZyPgePS0yjXTMlhKVGYHrqdCfBqpRkmQJ4k7VK9ni7U65AedyMEVeDhpj+uqVjI1MFAlGXAmcVhJ
HwNuDqIU8faQmu+3f4H+MfJrUXbvJaI2tMrC+U7fE8xrEC+L5QNxoMIW12Q49wE1CAarD+Rl+jVC
uNLxhy5KGe7YlR0dQv9HIZ7S7M5gNYAqkS8TPI32LNaDRUznbA8z2jhOiEIxP2vKnBKvrY9+oVZT
zyH0m2P7BiMtDm90HiY7GDPnlyQtEyy/UmosI4X7LuUgV+vPAFwOCOAPELPY1umsMdTiIoj/YIIz
/0tEkrFWs6Y18f3ovMFolDxRZhW/9gB2BXSuzBWcMySlFxzwjb4s6KII3aN5CHF9PPWJG6dFyQyZ
wGiuduviWpjtVpQP0If2EgsUdkHOKx2+Uu6netXDPtUykejtnHL1xG9oHH6g5dXa6MafS5btfuLC
CoqMvkLwGUBUuLf8rbe12aCW97qCjsQt8f6AgNVA4+TTYzBBYoL63mrd8p18LG9txXRKzFLXPtwf
Ll6Z2eY3gaZKULDkszk/8/YVgCx6T7auTVyE4Rx0DBwvB7kPsedbs5GG/WLutaUsB3lDzl7VjOrv
B3IQbqjArTm3TYUBLuEanfgQSi01f0gIl5qQ60Y4t3qW9bb4XMs4yz4mhceuYfeWIHC7cmPnGBct
8voHex5d6wKRUMfU2yEw4RRSMKlJ9aJ5PL9ELF2cKyZTMpLQFct5bztvTM00ibtEuHIAHer1hlAl
lA2gccv4/7J9CT68OjEf0qHR7iE+nm1tFmsgZYZrRqQSlF/9ck9k6H8HSq17xIbY/oikH2EnnDMv
zwfG/sWjV3+fUnDgetD40bsdiJ57itsZAomsGY8sK30IYLkehWvD3c4tkao2+P7YSO4T6Z0QOUgv
nZ/fjUTuVGibGznEmB2WkyTEiLSm4+RNx+A7hxCEX/YOf+ydFGq4E5jAAVJZbdxooUBqknouSUI5
ntQsV7IN3l/jRuel7P/ICgXPzjjvEp+vm8luJmPZsRWdUdHKibgQCGrvoKhefLi+wSDJfEeMz5Z0
7aVyR6IstPmzR+B5nixVJ4+0MWN8hh9sQfkw5PpcAzlEXCl95rPmgNGIa4pextJCfPusLRTJuywR
hoG05pNwIjfe3DEBa5qSPYTCOBVdmsaHgbvWZAAE+de7ovDqHQti8Fof/BNG1KKgWess7YEB6Kw9
j+vmolZ9WMRvdWSFocj1xBGWP0Vve9npPVuzsWcf+KOT6+kzFtnTHMDQVib+0u3cFoatq1J+3uWJ
1hk7EqQ6/sQsTGXKf7LcI/46vQYrc8W5RNwGcBGsWCZ/e1KDj97p4G8mTsbbnWO82ck6szCsE2Vi
UqaZb80QtQYQ6sgF/vntpmURISDlXTP40uwMufXRDtc1Z6cfWKkyBBGVx+BkQY2Zugg2636cipOv
HCwJQ4G4pQpBJlBMGZLDGX3Tmb5fjU7VNm5FOXvH8oyblFrZtEUVKBAg2BNB/s5NPtmnFUB6Kvpx
rpY1kJ/FztZWyc2QaKAItUPudn+6upegxGFuLnYsRAvDY1VICSJapaKC1BNUfiBb+QV8I6oxPmkn
buCMYZsrSht9ROe8b+IijWsOanhg4B2xltKRnUvYROjPMxb6tiRtD7B3UrJPhuTSyXQqmOuCAIbt
0wA7DCIEpol+y2Jb69z5FKRFpwT4WpeZXC4bxqdo9VsbZe4H/NISKWSX2S8v2FIdtnPX5+BYvM8e
7xZE8REJNmv8PV9QuUpDEbP11+be9k0ROq5hiVMlANg860oDFImHp+6g8aTKm30um6teTWIGtZ+C
LIb8ZE9wa/KXXzbqGGMd/KKRttmo4iz8uYwOgWQCcRTGHn+UkG8QjVv1yfFZS8xlwhchMHMGJ3UB
9AjUYHkdP75NxvUpFS0Tu+e4YKXp6U2rGT4ON8TqQje5f1vcytPL16MT6ZyePmnOeTu9HH8ewdCa
J5OfCYUAnteD2Ru4ES1lCQmzILhdXYpUzz2Qcf6EO+xWycU5L/lpeSzM8z288b3VIi634Z+obL5T
OIMwn3gA2O9S8S8D9dCW66zyr0TwVrlizlSwq2MNjUovixdFv3X7oACa9oxVRZqJQhOjyiLdJk4D
WR6QskhM/v4WvaYlY1BzGu1kQvJTHk/OnmsysgIJSY/zJcClqledc9XuNUl+1Qfal4mjsRNPOdIy
+/Ah8Ykh3ajOysT7brEDm8weFzDgGB0C7J8mec54AV3mYtsJSQShem7VUf+JMM8tnam6dCo0IQQH
48zzDI5TTUyqgykn1FY3EMIIlGiWMNzUkcy/2KGqOqqO3v5wKNnShK9eYztAkAoo9JiewSxEv2qE
4R3XojxS3e//87egkE9OWxS8pQltrFqp0d5vvE7EGoOdLlEj7PfytSBRktf+ppeOnqUfzaAIFGEZ
Jud8RPzaP7nBwMJsxOIkCut0yQ2QiZQk9HGa4IqaGbo+pcdF0WcTJm8Vi5SJgOjlTtP/eLoZBj9R
dS8GJX3cOx/c0YcEgCsUMoqlJUtwZJ1q9dMzhC9ztOS0cHIejgKuJUVz2vINkNJ8y1pVecP3SZAH
jXEIklpVjQ9dQWW7UyEV7qrIXEDe6luS5sC/FNtDsVjl1XRgR3daEj3I7StKclrWY0jz23qW1vwv
7l8wVLUXzkKK4PmQi8zfm5L2bC3sdzKSNLjQZj0OQFTCVhfTXVJt2DwwbVcyR5mzhRLDDe80GM5v
43Bn2vpszvXwEeybzHhNAc44vs/aw/4mohdZMb7gqFnm1xUTXXEdEz/9jSiZkpTGqcvE46pHoUp3
he1Tz4tViesPCqYiRjEVLTn/L+LPka7/eqx41St0U9XZRBb0pXOmXVX9kiD2HWhezGO2wv6HJrF7
hHXjbhRBjsyeB/NVZuFXTh/BTAyQZ3rKm7UfuxFU+x8v57y25aGcR6kHTHFCVO2DDkQU0BwN9aEl
UDIQReDgpPj8VfWjOVbZELXrPygGG9oWJ+1uc4z21VbJhOvE/pcKUd/52v5qTSHlxFAf/yxFMc41
RRY49OIncvYAfcfxEAcq740SYbO2PlaoQXwMr29HY9kPZ6juCaYQyd2tuvWhJYKPS1yneyjW/Bo5
s73OPbtk6/UzgvDwPbXia5LZlJQd4lb7alW4Q+PM9749zI27oicT2uAz5J/mPe5ypjR1o2lHe08h
ml6MeJcAu4RRnOblnCvkUY0JBlgKDB903vDQLqdDk3RjtsX/utgUnqKf8lq58y83k0ANfveWLOWv
/1XRP5S1HbHeWij9Nr5qCaAakof504uMAYQyzlhAeImISsIO2OByD5bgFPRQcnubNSoWTSuXuTOs
AANwpvR2n7WCeGTqeEMB473aDJtscAP/5HN5XAJnWxgV8hceQW1LnrJTO8hMavytFzTp4bFEbIOw
zxg8jNyThJ32KQQrgE8tN7u0Qi2zdPdVHym64a5eh5+bn/A840CvHR6pxG56y7dP8YJSWgt9TYTT
d/RvBOMpNGCKf/Is7j9GCR75R7h0ZY04Oo3nsiWrT3+8FtJu/rTxwm7kw5egiMon5DblE5qVUO5N
1UYm3+Q0fEYGtTdL2P8myGTCTXFCrG7LCaTF8I1sa56sRAn9bKkNT8Q07mUS0kWxzYbBlRC6G+Ov
Uj+c0fijr56xzPyvmd5SHOSVLfRfHn9W7eHy0+Wq8IPgCEfcPPyDQmJMWjUe3V7IJHaI/3j+4Zqc
eIXoXdFdilbMao4IlnwWw2sv4r5ECe1AA56UFhz/sAbwrVTITla+pCdiWPUHAmnA6OH/Jp9EuJuq
Ss6k6o02BhjgDwA4QD6zmfBh6lXbi9W1LpkYfvgVnwAX7JCsern4oY1X6K1JI5tC2N9CzSazdja8
o6PTnadomhb+F/oWc8cQEqnvi2ptSrDMI2Et+6bZCkhBReA3o0xXTHPBKgpxhrFOQefz3ga5edZn
k6OZmbp89jyULsntoPA3l+JE9fnhxPSBkeImRdRztfqUbTr4rVgkJv0uRTdZ/swbIGP0YhS19kBL
HKiUZPrO3KA/gP/DL/cDrTxCpXq/YNDDMM4dP5rjHz1IIksrWJ2a9ghFxbLdWAsOWigTYaG2Xo7n
A0KXxRDOslXR6T667yTHogkbwT4nEn4/z26bloUyT6vi8pej3zRHGHN+kC+M+SKvqg1d6FvCJ9Zc
7ksFzOA3ByeaZHwaTy/sFQhZnC+WHMlq1egkrTPuNKI9dr6fdILZ1IyKVChjdvrsTV/zPkeCjrm7
BIJwuEdLBZ8OfyuaOnEqUuoSa5nJeJTOTfbyQqJso/eNdBz9L/CP3m0o2s/swM3C4qsrfDZjNXvR
RGlWfGQ9NblwiV86AaitYTTj2IJ7eKelLOt0J/DqSNG/Go3p/4yFlvpRH5OX+T+PRHyCoKvN+Kx+
+BoqvFHe6kSJo2ipv0vasyWKzKDPK+bEcZhV8DqbPwJwwO0beik3nbNIpEComrWIn1dN/pTP+SQ4
WpVOrnAPNuyArc4E+Ekm3G9pA9CfA5eUovSeZkLmfyR77OIcj668f17x2azCuLaBHN91PfclF+if
cKH0yXNEVW5J/bzLEAjCtHYspqZ+UBdPiU1XkRd9kGn/+EEuhVV4TXV2Mow+UltwyNRLtEmlHE1w
A87sl7L8SiT0YBnTEhdITbSC7/SvJv6Da1m4h30SsZ07Lc+sNxrgbdiRjywS5sFAfPj13m9q5Nwe
h6LL5e3V/rGwNOrqI19iMWaNJrUutm207c3fE0Ot3BYh5JYOi0Fu4YsD0RvvdCcLZuYmItPLlM0Q
egv/rMpDR6fb5rC7rBSwGEG3+gCXIyDP15BUHvj+i6zvWSQmbhzUivNbBQG/Q9Sl5hzzz/f0zVYp
UuNNprn7vGWS9grGps7WDX3M/nH33KpbdH0TUVMW7G4/lTJkkh8QJ+NMQxFP/G5s1JxbpyW0qiO8
nsmdZmz888LDFmWC+SO5vQ8aTREQ7QAL+Fpbtw12lMXtJHh8HzyFmb2AMgdSkK5sILs3GTKwkGBU
eGLl1pTg+Yesfs2uBgdoB7xN5sVdPMHWblWvxOfDNYS1roFTZnU+pDNxL+TzTvXp6pHbpy+r9Q0g
8/icrNHo32RjIQF73QJRBYgGpcTkRGAb0nV/QQKPwKTSsMrFYraiVxPaglURmH7BjHNmIuQGpcPJ
DEWB7Il6mcdkD8M46ptE9PiTxlalXUERlL29JyyfSu2oYzndOY1ZvroHuUpc5gpoXKYxMG+jqmv9
+iguS731WkPG3PDW88E5kkVFjsDLnGoyyZHolGncJXuYhZDvyN04ePTE0woBMv6z6i+O5Hnww/5p
GzThwSD9Tb+eQp5G2LZVob7jLbbNpysp8CRSdL75uwDsMjEv2DtU04FnMelqp8Q+TIdnQ7vVtA3K
VGDwvBXd2MyZjxA9J5xhL7dyPzqScyrN2DdmyT/YjBX/nH4mo67M53MbZUMBbZknuq4FFUT5KMtu
DHNVZHbu62mV4L6wW1YxeX00aO1iYi5T8oF4aNiFpgJSU9bUacd4Bhh7hE2CJF5rIHN+vbjvkzBQ
Zh+ybBJcNIUwuA9stNxsKxMDuhUikj6fc4TRolFs683vgtaWrDfgTO9ZFbupRvSUmXo8mye1kCXA
3S97o3iAf1peW2QHdnckLcoHr04YbC0sQUKOoN6dUTkrUnFwhZqsyuAwcN03BHUlKyOrPMngSyGl
v+/JBtvp/okyM4F9tsuBn05QWnAxmKNEY45rtWmG+wtOHVNZAs7h3Kw2N8oqz0JjHBL2XO3dkJIj
I9PZMC7ybvQv3Z9O+p/QQWKUQB578msnx403Fu6Jdg0khbedRGjqrnNqKcXdvKbRm5MC5sJzp4kT
s3NpxexPFHutzBeFohgn6HcSV8LZ8wRpC9axZYxTZm1t3BSv+nkTvn8Wy7ckjk86qn5c71/5XiLH
q6RnXirUUz4M8V3WjbESqeIIgLC7nkBHB8gvDgN9rl1R