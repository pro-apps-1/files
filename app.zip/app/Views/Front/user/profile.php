<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyWvCM1eoubNTTUaGzAp5MVz6CVCLSo/7g2uyWvpkfHq58qP4vI90FglxaadLFBXodA4RXvG
9bm3y45OKASCM9frt0C5eb2T6B8b6Ko7ml8GkNBOmye/GvRHdKLZiocMWcYkjXguEyIWo33IBd1W
4mjdJ490mdDV6ne8uMQeOuSkJQ3rM1XouVNd7rEmStXfIklAC6ARTWS+Rzrx/XMBiNjCInUKMLGM
5gDwD2WgKprNoEj+GdQrihwkGPUQrATMVl28gTMs0bR9yaI/G9MPSJsk0bnZC/qotd3RtVSto5w+
f9nR1fSuPbDZD9kMK6a5va2oZe7fUR84emQDgBKSeHvMKbDoB/tYg7KgeeT75N0QUCdWAWesDaCw
nT1Fz+Uij3CNYTpWc/+8RYPt4r/9yZaeNE601ObbNB2FQ0sP1vvVBAD//jWoTAnLmmk1FS0WWssu
Mo2mAykGrNMEHEJqaPpXc/A6HVD4A/deBQ+baabSYuFKiVfm3ye0wVgwusHyKbGR4Ng4i/dMafbK
wssGFapebJY0PTQkNEAPRQLk0lqMvErT6Ah5wlVmS/HBITck0oB9roJw52XbZ1RAsgb2eOLCuXE+
Yvea3TFUhUJOXBk1kIXPUAhTfoZjQHeFuv29O+6IGS+QR41lunvkgCX9hqhie6QcVzxWq1+PovLH
eFbKf4qYJAB+nMgiZ4Tk+oGUv3+3oMRt1p7DHgoTzEvIVU1C/O4u4fdfSJLpuiIkLFxH9sQwdmp/
IJKGSk35SeXnnk3yGi7BHztxR4N42C1FKI7yFXUQM9x8utcUI2SxTwdMD48T48ZhzkWRXhrjEqqu
cM172stuVxSgxrnyNmkJHSSCcjm/rhFNnV9GUCUSlZQszXZO2XHf+p8O0JQO22vJqXISdNgss0mQ
rKg1kXgUdnBKBPapXtFhpHMA7MNcT0EiviNiZx+Vlx5jRtereacZyZZsG4qLhd6+Z2mosxydLN+8
6jDtIuSK/wyJ0+FlKflLBdKi0aqcZ4v2E/W/Ehd/tqEilQJWMgb41aX0uzoV3WJ5acwA1cr99clY
RebNoSjmMPvTV+MtRIYVfllpqsBs/1yWIKcyEG6tcKqYlr6eUFUyKpA1JL8XwxwyASv/HbsILveJ
0uMS+90/0eySoYINVm3oWMm4EozxIVbr1+RSZWh0Fe2rMKWPlzjUbnsE2K7loqT42kFcM+vyQVaX
IqY+8Q07Mn+K2TeE89CGwRWLarhi+1aNeiiGLpAtnXjOFIBcnF5K4G+VxvCUrllGL4CF6z4qDlij
20YGLhBp9VwDD4UgzVeUBKGXbYuGvkaMNcjMuVzEetS0zezyZqvVjlHIN84ru3CGu6OM1QJ14BJV
es0qEdIkIzlK6J1aganw8FJ/Zcxtt3/GZSQu/lJhdWsu18vJugxhVUY78JtZMZX4iTuueaSx+dcq
sN7r4gbVtvG81h+5+n/Nhd7ZbwpljD8bJ/035mTD5wxta7VPJcsTrpWaeolsoPthcHDy80Eyo5GM
zXo9KckLWmWol47hKK9ulPL3WIc84xhxcmBNsyNnMPe636OfO9u9RmRAguwkrIXH3jfS9MP16fms
QfG7J+/xW5AGqbDAzj1aQpz3IYqwQSTQLGSN+NGH3YrvOTRafkVj/lng+dgaKlN9g+N1dk0s+M3/
NLY22whhV1RIWC5LpqAScUrTNQulww5DqPyNHZ1G9ghQJ/TcTBFMMPNfgkoVvbKAHcAHBMxoYXpC
2Who0Txretio2urva7qzs4/x4vmUvGwy42h01Ru2bMjxoqPIFPozBbuVro+a8kT3O5nZB2h3+C3b
x0cM8wOOC2lPJ4N0mh0pApsWjhhcEc5ZcTalQTrRynyFSk5zR73GVZwagz0HsQIgrIQX9iciD00w
0Dc/TqEXmH9Xnm0gToyTjhfkmNv0ZZyoUK7AjnvHXXoAW+fyLwurxgCgAuHU0w5MxCe9crRLvKta
IgXcSi6xrMSE4ljHS0vov4tYd+UA23QLw+ofXDMQEXocN5PxdTavovlsBSs3BN4aysBQGtXhYMGO
OVugq6aoWQVj0Ycsx3wblKkTVA0QCMuE0nNPmQYen3VEEmae3XSh4NezHOUKzTTxB6R0JGCqjpA9
KchCiIyc/PoR9zF1T5Um95gVesanaVvSLUJzluTB2QybdZPA5MQR7y+UkVeNsfRvPyiJecntK3Sr
Gche2eL5c/m3ZDfW0SDqqgWuMgBJZntQgIAdm78VzsDzSqDVtnL0s80JkI1DFvJos8tcktSzwuTC
6xbO4hWmMT6wyA1HdraeKKBmTwr0HfJTVlS1dFpEaDqtnLkChHTkn1yGs5ka9U9WUSh+Z8EArXYD
48+1Dl0UggFwGtlNBBZm7aDs7mUVputrDGVGCWQLZ/BWbfLW8V+qBIVqLGMaOTMhmTgqKTyII3ib
EBfOttvN5NwS+AyeiCbW2JTuCNW6nRjWk5t84s5Np5LtMIdIPWYWspInH/6Inp6bpDnh61Gniiol
XGeFkPR3GCmcR21ljq8U3uss/pfqXU4LgVv4VxrmSw190k2RMYL+/1MbAFHe+RM03epADqFV6bCj
dHD+oybq0JyV081qozJH5y60+C89oC9gEVMsXOQTuCouSOv1BD3/zan9Ha2xnYybEsdm459LsCw3
vjF/MqKRPfZ2Myuv8TPXaDNcMzELOyn2DbI8QlgZJPEYgglSj9G3cDa/YbATDtWKq0GVC6GigBt7
vAZccT+B8lDJs2qLFSaoEPgt7zAbFovNuT01PIP14IlTpHPljxf4MfcYVZM1m+Mvl6/VhGimXVeZ
IuiqvtPISgHFqLQR47j3rim4bDf/WEKi52DbFgA8YVgaCDUAxji0FoEP6r0k1R84msRNxD4W7fsI
mjg+E7Udjd2KEuRcTlc/3pvFVAYfN4EjmDwqKplbcyCrxIbcr3TbbutokrENi/w9+6qvhhKwZ2XF
JhYgNAIynQbSjCO7vFSlaAwZRNsPYH4D2+HSIfJngc3IdxrIKf9ppcfSxveouQGqVmaDIn2cFPCf
PGYbsRUp0742tOLPBXsfUwrTdprgS41CijcsXre/HkVMQOizSlDC6n2c+LDoVtX9zsHQ+qGYY/bd
QIAAUxKgjVjvfkk1qVy1rFRfySSOEGPKOBV0uKa2W9RjiVkRs1ngYYm4KFAiYpC9Ob5M/PYAEo8R
IpIqArCKFSX+/d5bdbQvbC/lguOiQ7nQSjEqIx9l9xjj7HRzUzYlKjUBgTVuar1RGT9EpffkzbYI
ZmMMJm2chxufuB7XNHh1O1b/14aBVAu6qxlz8IVffDPuh7ERLDjUcBHmrueX1ZVsUtfBZVVsBZGm
cs9/IYddlZxtNJ6P8Udlr0NcCOhSEvvJpa+PkBImNxEOuMdSnkMq8hF5qz336juh3OrpXb+kc4ed
5nSIdbqsk6rGrqEVr0+5e9tmNX7wG3kz9iAt3Jdp1uAKBV2hz/8/qxb9//3uZ9Zo3QbO1RC0/BSD
gp6iaOyUcjIWabwROf0z0UyPlganG0zLBu3MCR3527qR3SBQyHcgblIfE/IZGeG+lC9lHiFkxjDU
56THI7CVQW/vX3jIDUjyMz4dgO9DZZZVPUtwY6+LonkUyM9ABImDjggHtmgTSfjK8R6/Azo+4eXs
WjQnaLL1Lq9K5hJHwy65TRN94DaB+OVm4ICbmo2dSsXRZU9+K8qBZzDhjjdG5DWw1R8odKj8BKb8
W/xyAYiXP27Kadz+QRw/2mmJpYxuECk7hkQBiNb+QrQWCP5X1HBhLlhKTXGsbKAnnnkJvL3SCUbA
YjLNm36mtO6tYl2fsgrogL8lKxLe2C9hGUt4ibhq9eGtKeu7GwEXHjqXG9G66NQ3QUgYYRGv6hfD
MJiUdHrpYV71a8no9hXMIWXknmvne3RLHmaIf2BI7ehS0qn4hhPS1nqW7VsHnthrSSgkS7GkLfdv
9QmOBGP3Q8vsCe9eG5YGlg6x6Q4zc+kLj8hs77GjSO8B64wZ/p60Ye0koIpftwAQbZbwUyjqHqEm
fgV21e7H3AYDYcC+ncsibm5FpBt2WMxidzWUDemFh6SNc6egfe9YAAiRL2H6E2CEtUwcB59cQVE8
eBd0ucEMMuUDmqktlCiH+jhnfvHJp4SFBl5rYl655nA+7XO29MfMyWSXk5C3N3fhhmme7KQR/XDe
jBfdZbMQQo1C6p7xHV3vlJE92xHbfBYhDpvROcp0lWNowoPbSYF9rEFhORVa6/W6kvAkKkNUoZTJ
H9jGKQ+KAGGhmOTHVcleC99mAjTPgZLXBWMvLlzjYWF9oz+6Kx9s5u2vZN2aQkVVc8kMrcHAvAnx
egeStJ+nwb4gGEjyiGjAZR+kxbVqZRRMBLqcB0yjwkWcjfUJy9ULUH/nJkEaId08GOBcbvBf7q3X
axUe9l0qzQyIvp5lvXxqXZlOEXeI2P9HNk0sOdRCQWMugYGZR8KbqseEnDeMs9n6equqmFLTjrHZ
lxECTcNR2F+E1+0CRivlFUwxWh5GxaSCMWSWeBzgnIX7UsfGwJ1JeGwNHRMynkTZAnYPWTeVnWqg
SKQ01BRS5eVDp91eWMj2gR6f0SsWZ0BSfWafl3VfRYLZ5HmZYwP2GerztB0hM98wxFRyIfgZrDR3
m1TnZeFzW3fI1p52jB86fxDLbZtUY0/TreopnOOtnvsp7rw1B27BYkiTNoYSVqogvU1KJVGCcFah
a8gD0UiRTzVlt7kxK4Bn1N8w6Syfs3etNqz/1Y6atj4VL3RzOcYtQGGSOHT+o7jCTwciqnUt9wYr
Qxpa61dQxrx1vHlJTjS/uBfCG1//2vUGITZSBSo4/+GC6Je3pKhWMZ5NmNSD6Hrty8BJDOUCynFQ
biCxRcnCYSIncbIt723Higa+VY4aPnfejB7qUjU0EZ9VRo9jM2bdJ+clnsJ6aLyIvXnwbcrMeFC3
oeo/6WBU7gdoAL5iM9CYLd9DpCTCmm2Oea2L8mmpzXT5pemKBkxnyAsonOLScc7SseK4P9krJJr1
l04WaxMG1byArBh3ttstr7dZY5AH119x6CPPe7ywI54c/wMUxhw5x9IDOWdl2v2NNFiKSrkGzP2O
hnjq0Iom+EDUM+TEXHs3da0nL9bcix+eDaVcErBO90+54Mgs9tq84pPg4pOCVgrM6diGhj9uamw9
jmhkbUhlyT9BNtMkkzEoyoEBju9Isp2O4CUbI7YNt73J3Ss3a7/b89wjJYbZ+azbOJxJS2vVM5Np
QieMNwDRmw0EM8888DolmDZhYfp8fdv57Wj/0yClpNpNhpsf0aSJcxzkQiA+nbWnOUXZkZIZidO8
Edoj9jttViClBUP2JzZwBU/zlzVWWGCTNy77U3gYKDwMinEh6I2sV2syHVUlPCES7zwFn4NchuV3
CJ34mYu+vOxfgkrVxadZbHPIKCoLSXuMowlXhWrhp7aVMxpNO16zylNEQ8ricuwXt25MRTaz4dUY
tZXGzcObWRHXzPRDC9SK51TYJ9D50FnYOgP+mVbxy0tLJd3w3+Z+o9OpJl+ImFywGFSSb5wvUXG3
MJLIqKSPId64XPmstk2+p+6W/P++GSIeTbUrvTYvt+Nqyj0bL1qNx1rwlomDTU//6DsXlQUM1eAJ
ujcfQmEKMVvSAGATVCYNlp4gfTF9elVaVKZN5oUtAydYyP/furG8xp3spME/915lCXQtQ2iOiKan
A7sYzQglaIx1wjfC+FFJMAPJOF5TxiD6zTQ2XQ5V4FItA9CLKAF968oav0IcFkV06FgYZbAt9IP2
c9Jfc0bFzM9OyJPLL/7ifM8LsN+Hs96+Usf8tRdDM4zTLSOFuPqZwDNA/yiUH0emlL3eTav8oQ+S
auRahfMe4dLOz3x55sCZU+nRy2qguMNKd8U9FQI5YvbQARHbe6asTmtFv7N3pcgiFHImtcqFzH90
0be5d49tw4PS/P9RnS6TNmQCjy0JYq5MdNrwku/BdluVc0319k0XCxgVPqVo1r4plEqTMQmYSJei
mnzIXlRer7UaX9a/SjAmOmXxs80DTrovwuFF0oI1ZR/uffhIWdQIGRpgODeDeywGziblMk/wwbIv
/9KqJz3d39E3Qdy/CPFkWnG/Wt78AIkPtZWqEc0YdKJj7kic3+8iz5SCZWWxC4hfjGZOKO8ctmMs
8UW4bgv8XHokzvSCcHg5Gyaqdpf37fuS5gY0bBhEYpWTlB3BvTNLiF+DHrmPR8cE5qxzG3d456X+
ogvdGFkuplLeGnx5FTPUROZYVdungGJm/AT91+iYSAfqRpj/k/4AY7a6mNC+SYd+VvAphp0tlEgm
Se8nEHGgloAuIxR/mA7WS2AgTtylE3sXm4v6OeiS3WIonJkUVnZtEhRgknNzOLhLhohT6e5isMjD
6u40NAKYpTf4U/zC5InQssj46EwVtX5bErwvwqm5Qth5FoJ7vgq7shKHeBP6cBglG6pcU8BBoKVX
LM0zhkLFbHYGWgPo1gFlMPg4tIwTmfcIOJfD4itUJonXRUzFiy38URUO3q2DmkaYiQXJJnOmxhfN
V2cHnQCHdBLq0YgM3GnjD1oV2cYhX/olHIY4M/zF/HvyL/8gme9Uv6W/5FCeNtM897pLpmjcgoaD
bcPLaIOFm9vtliQ6lwKa6a3lb+JwR9PsPFZZCwA0Z2nMHkExdDxZ9ig34Y40pXe9NqWWrdVnPiDb
JNmigavfZ7tvHgQG52eQoQWn2upiRnj8AzrQQsQRpNHnEtBjB6MUc+GQ/Qzkp6k/w75oofT5Z8Nz
p/+aBEF08xo2BgxYv4rkSgebqV+d/rndRTnwAeCKlcTaXlE9JGY1mHvzmp7WqT7yCA9o+HnXEZfU
4749Hib8B9wCiHo/09kEoi7AHnhPuiveDcZS6NPgH5cG8PtuxhSIIwnEYYXgutiwxZuKKJMJQEKY
/zcN1oEdc+aP27W/dGvk5kduABMrEsYmJtW7zMLj1GuJQR7oBMvPRBCKBWlIVuPM/A3CJsMr0G/K
VvQb8057zbze4PIDtyX4Z75KzmjGlzscCfKdPffu1nWM/EcnQzmp83zoSLbC9dbuQzcOaxZI6wRh
1pP8b3/zaNsHg7niGrFujPEBZ/zAks6I6m5QI1AEfKSjAuYYAibdqrpkxiOrQ03j/ILD6U91DM2W
FGIC2OYvOJipsZKVboxo5hJIsaKnDUqs0xMOj6l7VkF4ynBmFPcArHswPNmd48cDOWeSP1Q6P6ef
tp71ffdlZJvhMXaVPb7i+q30SRkSDLtTLK1a+N3/tJ0dtEmwjaxu7oMmNN1z/mdpC/UAg5EvtMTz
d0SXrynh3p/wf5LXvUAXhc2gKZAqZgxouRMhhbWw2WePcDMC/XP7rn4w9HGmEwUaMN3ywEWeeD+c
8gZo5zjsPxJlJahlT6dpuy0Mgp+8+cxXY2prn5l9ZXPi0kxeM86rRSg3KUFQLvf+PUCxahuWosVP
07/IMMxR10XYi7YAe7IP9GRofdeQoyPBk5nHBbW4tkAq4Mb4indoB7idNROI4CqBQGCVilcdwm7v
YaR5sXVSsWX3rhOVVNMrzo0f2DBgA+AnKBH5Yw/jVy4iBaww3ydNDGNtf2OWGeUoEQy/xKfBImMz
4TXdmTtsW46TLiDrBfnYc1I5jZwXprP4NT5Qx/kcmUtJDK0/WBReg1bRPV13ZMF2/bWGijkePyHQ
p0qI1jQuEa2CMtuRhIGzYD2eEX9EEzOMVMlPujL8NOspPMMtOYuJzdl9aQZpUzVAITxcp9M+gaOd
pOIpt1YRGmtdEycEG55sqZVt7HvC9s/MNDfJPz1Gf8tKOX4cQaevaodJntra68mLWp/SAKL3U+zM
WskHV0Q2pXiBPZ5T2wPXGo0/EIJpGctmaUQoy/5/MMj+YdTnnZ4hVeUwe8fOmT6HQsu4MQq16Ou/
R25tq4WshaniWXdjpIFc7/4ppKs9Ktkvls5dwPw71SRTaQ4R/+04Yfr1/SXaJ/qabAxFOpdA3FgS
uyvgLzF6QFdNVsoE8LTYYDyl9EJvqAx5YpGM6NbPj0iqc8+OmqxV+LMYv2rhY+9YASuPH/NN9nF5
K7YMUvvvLJKTaqEfDZ91g9etfh4n9JEYmnh0I4ujqsQMJEjGMtBLApyAgqyI/aiBoZIodE/Douos
Ma5/Ub+xyhhOihXOZOQSlZ3oCdfTUpWUxZq5JkO6j5feOhHb7w+EXmu4MMSGr0gF0fAo3d1WiOEo
T9NJ7fWl27Nl0FVCRXw/UGheZxQvp5Z8H986BM3RBCo22JbKN1gvk8NYSAfYPX8MLLX7Z9e80xKr
OGKfGEaPO360WOCsPardUa8Da1ArRVw5JZ+paJFgMemxZaqpsLRr95I5853Zu2xJDFD+Vdl8frnW
TL+pkayYuCuOQuCTGLmirDdyekzJkr1xVOOHOKSIlLwv3YJgCx+gS8T0fQfdGldLqYm4lD8i4EAd
NjgW70E6vnmd1mTIuqvQdrGbvAqOtSUoSj0/yW==