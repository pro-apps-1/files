<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwkXJ5HzHxMRU4lPTzcVCrQXgHKn3Bv4x/Kt85lU0iH5bTY6sbG5HgxNn//iDQYHe5DAXvW/
KA6Wj7CNv0Cd/3OrrH3WG1m7Y2zLwFWUQ/aJAhY0mDfi/U/3wAMwu29rAzwmyRibuBZhikVFMHTZ
XN3YHflpYD6hJydB8etzGMmEBp6MjqorBEVpRbfZbdWCyL5ELoGIzRzvazw0F/D1AdQaahuvmyC3
eiGEf9mft3zOMr9NjlRGd5aE0A9ejrK86oImV8wKSsvRs33i/oXoJThwYz/0RAqKkZwqa4SewOhC
QhRGR/+qRpTat5HOusKQg9XIGO6XBWE/WL45AR3VGV3R+kH9M2vgTkiwK+NW2JMBaCTtuimTxHYH
hWT1Sodn6gcs2Qaxs027V/LKaF3suhDut6wcqVIzUSoBqBJgmCV5YLbcUYcjfnZjoIqbDLDYdB/F
aK5psz2d9gu5yPKQx7KkpBn+PDdd0CmSPTD/qLvVzovSqRBKop6qzzpFmb05s1HRYpXIZ2mX27sc
Nz1k8SpEgXw0RMm8lM6Y44s7sFu/5TFG+8+Of71t4HBdHhCF2dok5PK2J70U0FW9G9lDZS2o6Fkd
MjCuMqR8OXSVh8trJ3M5N8mQ/N2LYjTM9UdjqyKblsuXZhvLIhkPRjdXJfbX9/Bh6mFrAgLmiZ5Q
4JKwwfwqahc+6s0EcOHFx+4IPn8Rq/Bx6kRuC208oNeY3Ex9P9fkqRV6cqMnDEwx1TGtibGZvlo/
d0PAoMQBQSdx6I5CFWdMaFaz2ZMM0YDTy+bumm5MonAwpmcKR8Riuuzdq/VDd2p4EK3wJnfbLhDU
kalxaWU11NDmzUWF/XZ/U7rWUKocXQguJvsKoJsmxm1Vw5dpgH9MCLcYcr86I09CDM860D13VQ/B
Dxufwk+0S0f7Zd3CuudK8yJ3ldYicxebMVZISIcyftomefQxYek6b9cTpSuMSlLKSHJo5LQoyOo/
y4R6iCAqQtFXR5S+l/ghRDdLyq7YhlvgRKgZfWCsswYqYX7IPHh5fcEvHkxG+2IDT0GCUvhymc6F
XIMbeWjEUiMARB3Qc6svkyiNWzFUuwYTnoLdwUJ8+4JFRXj7kRZPaG+YK1PaMB41FldKxDQu5gOA
nIFF5GulP1AXkZsCT7JW/XeS9airgrCGAIX2nartKlgRWGjqzVIV+k/9ftzzPF9El3xScX+56nl3
eCRWocr35wGHedMaf00uIKOTDSZCRUE6Ey22ew+v1x9yeJwwS993k/wPyFuCsI3MNkxoUvpvib3L
Vz3DnwClamuO49DS4H82n0OuwJCXALWbYSMO71aCQhymDmjYaAaXi+zV9MOnN3fA1PmYlVBMPogV
lrKl0kqxZsLCwb2FigM7hnE3VwntKgQDY9WuLfWwLmmmmcZms78TfoZiaqQE5yYFWuF3RgNzwO24
l80ZPoYtb/g7PVF0zyNdvPqYC8UzAp7zPz8Q0gz7JZM5BckO4aUpaNWSqqHeZO6hPzCUeaIVveLB
JsvhbZPAlMS7yTgVCxLNrvmjrmESs6No7/LasZY+pzLeajSmcAgly/feaDCZ16fSyEIyjr53+FIT
r5qarBwU9aHOOPLnH7ApxLSPc+J8Rb8GCWpxUGBE+9hKMnweMQve4CpfKw4sc8I1IX2ijbjiSZgV
IxFsDSRUWrLQGszgkCoXtFm6/rvCuxXNp/r0ZeI7DTkm7yhKxVdbxgbucWddGv7XSbYbOWKAU9tp
vf8vYKltclCVFqN1fn7z1ZjxrjV541AklXmq2pBUHnuEjjoeQ7pyIgCzJ3s7bSlivIU9A45tPe6i
mPOD1YwtQp1El54+dQwBvO3WUHchxuHW1+NDbiGst3HYXKO73CikdGPvT2KePF7UFgCnzgC8WJ1n
JlEkeNPj1x+a96YzVNgG6ejUKsyKbTLep5N6+2wtsDsO4yKY482epe0+ixcx7lq8yTld2FVXo67V
2Ip3BG3lTdkjx2BelwxZKo8cXEQi8maH7/SnDA39sFEKNCV7+OqL9E6mHenRG2vha5j5IMSEFuc0
ack0S4+Sx4sAsmmlS5JZ5ZJ83Vz59GDXHbuRXjQDdZb8jx7o8Jhbw+Yw1a6yTOitoxkf+M0WIqJK
3nc7mApZCRZ8I9irmFsy7/cT617rLkUdcxFuHbWQ2b5gbJggtTtkACgEhYfq1OGW40lbdG/wKfAN
55ygiTS1LnG2ybKOXuKXxkhmLyAEH41CiNmLzeGguhb+3ecsSgEZ4Mhl9xelbmjDdualL3ZcYFed
lsJCShP+fsfYrZB942THaqmrHDJ1SnF0b816SszNOmdq1sJp+JMD/ZyeKjErgP+AKZ8Uo8kpitq/
qXK47LYXR7yiovIDKHnrc5vOLx7aRgujMl/Gd1L3pErXa8zpou8k0fWaYG/UKgy7vhT62ZCmYoqE
LJYlIkUJSdJdggCQJrAezXEHlNGH3HRy6n/opJdpzvQCMQZYma9UaZjjC0HnfZh8AxLfoiQM2iY+
KI8PC0YIbJNfOOTPaEAwVePS+IeGymy96Xd+Wc0oBkVVz6T3koh+se71cEhTUp1jx+zCrOkcSRcL
VYiVsOfp8BuJsy3AvRBCR+Qv22BH9LfdkiCpw0DoUb8EnOnjPLTcmlrpdHQs6zMNcQwcQIB/isNg
WEDpSIlr4n10qn+5wS6drUBJ8+Y4YRmY1BQEpfdyXLG0T9AJQ8w1vT49TGV8I6rVMuLbrzOO/+SB
1rYG1fzVtK81+HT5LF4BunJVtcRTjxkoewFN4Uu57yzAsRnh8xdK6kADIp/cH+y6L87t1QlGgzp4
l0syL1mwJ+UJmsG3qf5v3SEKNdakdOseBDQoA5r05R6XSYl4Ni49x1J9DGfGVKLm8WPSX+RDJy92
zXublciO1SZrVBwDKPnxxFneeQ1y7rIXR44mcIUqn7HMecmG3SPLPRP0vgwubGiZ88PeDxggIjOo
aHsbk9QApHpB9BZat7ycmEH5jpf4YNdA0TbB4Thv+KGrK3OqR1bblam+8+i030Q/tWS7AMW+Jgk0
Rgw47W+dxUKp2MmwrrTFTk0jKtOicedtGId/2iJL779jLOEmDpuPYTOcX6IcekASLkBRhcgCqQmi
SAGKOBT8ucWZrmgkVUMOR2g0G9AswWquQ96Gg7mHXmfrn90vv+wBqsf5gb8XlYZbyNLJqdvsXWCa
7QbyoOjTsR6Pdq2LwtkEu+WInzydqewc2HUWXqtjYmUNbOI8EiqXyjDn17QeNwmMvlWSnCJDZFvx
Odk6BKC9k9CB//TVWx5BnErQl7jdr2DFBraQTjZIUtjSRCrQGueinNECZfX2f69FHRUm1fK0oraS
Ert5q/qanJWp6T2nipWSCplyH8ZdvcmuUpBWprmgsFwaGhSxI4/0Jd54f8jZGWjO/x9Ccj608F+I
nnn29g1elkLl+lDCy9ea9Z69hz/uDClUifo//RR6DXw7Y6j/iWXlGhA6AHWpiSEho7LVfCYSqeBB
oOovNf/cWKjZHj4JqT1YGY2mu04ANIrP0hZxm/BOaPNkmmC9FNVwnbcL9DWpcK9DM0xchGPZOaCQ
S7m6gHgj3Elsugmk1gfzk1bUagNIKWqRgfTfw7GWCM+wvb2v8ghnAZxqCx91Zg9U9dUy7Di1PjAU
81TNzR2YkEQFYcA2JNMKowTAxUsbMl1FzkfeNsenFN1QX0CKcRqoOwwsYxyVxGYzq5I6CGXW8ATp
+PXbVrx6b3M76XkAWy3st9Qaq3STfm7ZOBifV+eJsWKKxGzKSh+pxi2AjrgmOMDolVvOtmnGbohE
y2OJKnbWrjQ8o8+gHCD8HBSgVf3FKHfXdR0GvY/S7GubxH3YNAy/jZONd6XDzx8hjQcFSUDdAf9G
RDmlz4ZvGVPSB69qxvEd72rI1NbZV2+clhFglElOWeoZ8b4K5eA3WfM9Knz/0atnj5thRloN4dzN
j2aIW88fATNxTtNf/c4oWRCfqbqexFO4bi5bqrYzO2GWPy9qPjPUSiva5X+zB7L3thOlxHmIlic4
DubsWa70hiKYCVJ7WA9eGDhBDdj97kzwUNlkw/tnBWdJvAeCHMCMSpv603Ru1/Pq98UcqHvvBIVB
znT1uqxoTulNd7eYfhVYxC0rKihbbHBtIFcpJBhiSiNg4zcYn2al3wKzPS9zi5eeGOb/A8jh2O5b
QieQH8qDPAtAhakNNqQzSDhZT15jjxDQ3hwcCnlCmV0qmRCY0sm6mOxnLf7XbpaaZC4/4heB2Zad
Zz8dPvTPTuWN++Gi4x+2GcZbhc6dRYaTEN/Vf0mXBqphaPh/+DsP9nYNM7KAPBcB365TN68/zlgr
Y7MRlAonO7UPkUelMtFw420/hRZXpiW8W8+4Zy1/u2iiRgol3AWhxKWZ9MMgoKHqxjaetSnvG9wz
Z2zhHEeOB5m4iC0mdueoWo5mYpO3XQJhiPE+dhDZnImZTlydHlWXX2ggpjwOWKCmx++e0O29LOzu
pK9YyqnarGZdBNLSQsAXKpBPxiOOdo7FwrBetC0m/fj0EkaZUPby8mKziwb1+3PgxuWFB2r88uMk
ebXfHF7DHheL8M/fBY+uoWIasg6GbeTLGj+ZShJmdK5GaXhwt/K6wcHZijPkaKCcSnM4HQ6kwq0B
XYc1T9EvSrucKHD6mHcNxCKizXIo/QpZW7130ef+lRlM6tDQHyAz6mkDfwsVuTl6k5r6GAIlSRhz
roIz3Eyq8obejzv/mqWC8wwJn6xrxPOt+kLMb7sF7xrT9QQCzo4gx+GAEQbAoEg8zGUZeFjtfh7z
+LSgHdPFcrGAkK1+TzI8eiAJMZglYedsc4gkDFYZzCttE9bsvFa+vYKszKJANAuLKkXhddBlUfU1
h9V3BmeedcUZ+UU2CDFawAhCwmPxQzR8y12yoOA3oAPSOSFnJVsf5+S4LknYVWOj9UINew4sIXrX
G43HJxYPW8I5x0yj6pBvp5RfshShA6CAtpib5DOVxSzqTn714DPfoghvA/kHoEz4ZsSNOrtnjbm4
4wz8GymaPfaewmU3DCGrYg3cOGkk6+G0cvav01HXvo+G7ZQEq97d/Rsb/E4SVvwJGdA/CQg9ytv4
OVI3RsHwVZ5v5gSVFcy7O3BAI9+YEUYlqKh7lOcF7JSlqT+M/ayx0/dUqmWH+jen4zfqwqvLtOrg
qVBsQKggdViF99O4KAPbfdGNJD4R/HBswS9JNC7UXCh3qPwirwmgOg5Q0KEQUX5WI7JLmXwY8UKr
2qtVsXiw5oKjMPoVKmxnwIOvRuYIlxMUjqHqpLNgp9D16NknbOReHuO9fqJIk0oxCJlXtGOrbzJx
oNeDar21rp2pxTJZChM8oEsUBdHWT8LnzbmO64sUaHfIBk0zBYWqBWwgyb9dSXRb0qk1FdWcoU/z
L9MCA+j7ku27RvfKZL/7CMOoXy106QEIDHWop+0IPOAoFqtMPPHNDWgY0PBURFIjQN9mRqE6XAZI
9faWee+eN2ONxQ0bt9Q2/91zUqqrDnC+xEeQ3nKTi7Qm5giTH6nooFu5n6SFlc0aq91K2SM5/Fk+
MW0gnuuvwbjrbgqpOt7cXyK8YcMLgIXOPJSjGWACbnk+FM1a+KfBPs5NRUEQFp/xWoE/rxA0t+ST
zd8uFiiryAmCs+D9opsRWPEeUwjA3LtgOTY3Wai9+zKZM809cS9cCZyfdIugGlTfpiEhwW2nUeY3
9nrpq9AjUzL4VcexmzBwrSIP9WGw3ipkiUtZbcBlCeTnNr3oMnbtfyvuagr3pLesWJ/zhlwtxEOB
3K7EggBgvc5gyPgvtBAPU6aS/BSDvxNjxlHzxr2WytSG+C6YPW3h9S7A08FyH35NeuO70OD3CZWJ
Y37/rdTAH5cOxGVnvhA1zCRCE6JEsO/nw8hIwEbY0mAvkvB5dBN9WND36II4X1U7ryTZayHDZSWW
TGaL9A+ayY2l5oottlMDhEOiKFsE8yvcDAsXcDjVqukKdQSaSNkmJoufCQSjzxIGXW2MGk8UaoSE
BQOQbUHFiHM4BZ5D9vXa2z1Y4mtpjB3LxR+K5V/ZTLAXgXbz/+hzw3Sv9k+27jokujFwe7xHmhCw
5a1EQNhuqadjbE+eZ8564NdsTlO7KXYXgozo69pyMltQjzBgNQflBGaOQp+SUztsDHazwDcphy9q
EHMdMxpaDjSx+krhpWISIEyr1p16RK2y1Mj3fyEBES47AjivqK067X8k8dRkoOpfoWiufIIB681r
wuhGV+b+h3YiIyq51lHHLs67kcnXOehMBhTxIpWRwe+lXRWWy7+nEbcVpCd0VJXPUHi/Lw/phoa8
0YRSw3UdnaSAHWhinkwfOo1t1EzESOVEpYUwJ2erMxX3PveGQ5W6ATCiu8YVpLzNFR0/zYAOz0+V
TvAkgRZB8KdRBrRYKklGBWbVXsvBP+JELAie+qAzjDbz7uErGwUShGpsYbYDFv6MImJ+DxqmcTG3
FGVBPGxrX2VsX3WA+jauzuPzzXbnxSq5r6cd0DFheu1wnhT9pDFLExh2U4TpZZUUrWrRpwGVCba2
3pJ+fWrl/u8+k5B5xgjy+2IxqdVu7E25AeX17VdWzYiTMQ6K9tQSLMi2ghzjBJK434M0H4GHXOCu
vaEdPkpAjIR5H4W7Kq8m14UaZdKl/nEiS6ucameQWndH8BDBdHIprOKotlY8VyVPpZL+huebZ7Y4
i7pXUKeWylOqkH4hBhsz25B5rO8KhbUC6jSOxEbrElAvVB6oCKTDOUJJZnp26sjgv4zruhP2M04h
ue6UIjIfBjKn9+E3wkSdLCF7Ut0DDBYUFdSW+Hya70V1Le/IAV9f+RigmDo2wqv/8zvE1pCqQ5/A
bzUTLUxbbLRp8gZjIvyC0hTHDXkoyPCgGrAvTtt+AMH1cM//kw/MbFzkPR7P0rdAvL5Qpoa58s4D
1DW9T31Qldf54PvlPe2N/a9L9B7j4Q/Hn78qa57ygBuGFd0Xd4Df6cw2Pg6gTC0eo5MJzNsoKCQU
jfQYEKPp+qCK58zBxRk193lXjWXHjogYk2iLGyXeIqFKUUZCHIeagN1Kmlx9wn18uF9iP3jePR02
QZufhY4UWC/RIxj67NhKBxmfg75o2JPcuVtbtZrZjBe3+HNIXzSMrdQ50rL3x1i/hsTn4hGD8xTG
aExTULqlizKcWgM7jnGTo8kt4sCa17ltURbPd1TLNWsnJukqHp8d/8K+1v1xyOX+mcIHU9LQgca4
RSjZZwUbH7OQIND869gw3iOWE7frQeAUPSV1iPeXBNTJu0MHMDOA+dWRy1ZRzvTa0K1DPRp9ODqu
3mNjpd/bE+KtgEaOy5HrfxpywVvP0V3tgxa8kv9Ic9KjnpUmw2OsmP2VMAmnQVu284bV1ZaeJvKz
ezuFV1RwGZtQlgu+X4fG7B0+CLdLIlbYd0++nZ5KkxsF7OQK2B1GRa136tsG851hvzmb9psnRxxu
+RdHgMIsOhXazTX7CHiSpccKdAiDcjtB630lUZsvVwjSpYaJ2HdrimCExx+ovU5zkpPHCqcvt2n/
NesAfFwx4OOMKBxi3psE6G3djp+Dny1ilQ50AnUmLOMpFg5mQBxCZCaswXyw+DJbXbP0MK0n6lsn
DAXWOQHTuqqzJncSs1PKQhb2hetCtBfRekRZukD1Sy/VGr4YbsoyYbohdkCWNZFLcadujuQk54vt
/C44xsEAfk2HtZiM5r2ObaNanC8MiNzGBClP2QBZ2aqM+HZJbY9LrIHWY5JPtufz0COJrgSZ3UnP
uObk1YHstEtNS9YAesv7eYmlM+5kUvc54f0tU78gXuy3kdEnwNpLNQLgZ4Mcid9D1t/X6ib54y3o
JIoGRmz3/ZAEhm02otPakl1jsv5WkP/RhIciTTBnX1X5ePcPvejVwO5f30l7veg5nfPb9HGKobq7
sWE6r3NCaqT3T42GMCv2DNx/yNMmXwRF1XBJv27HJ1Cn5g9xUFxPSfykm5nrcXRi/ACf7OV5iqsv
XWWhHK6jYPAbMmStRmb/e9RQr11LBPRu8U7dSkDPQS6XtkZwVH54tKHf8JYRfbPn9a0r/B3ofSuO
eTMc4QEHBl55o7sW+rRNLWatiyh0lnmXNZw1334cLbDkZG7Ye/VOFqHXJctYq9lInGRzowoj8cQ4
Kupq+3A0yb/XPIjCgHYFg0jYzBowYJRZJQyp0uPpeRxS+xzDisWwhTyR5LCZkTe6Zt7rvOJnkL//
QEbzuvvABKi8hM+dYXoMlygd+HrxNZDzBhn7CHRoVr/DFtRUuhoo1c78gVOA9V+RxzQpSPmcPuCz
Gkk/4VctYbvQ27MeRUMisEA0jXviKKTuGfT3580PmSvMk53znTB6c6ONfRJqAk/tWnXMUaNSzhZq
ytQv1CrQnzeYvNXYiKQePJ5o208oRaW1ZFqV309fGvJy8kHL4EG1eNgMh/Cbe2RYmgvwzDrbKVBq
SNlntZavZLkH41SZjqiNvZ4cnJsOLpxl/qArThqLZp3n/kkLZRIpB2ndxjzKPCI6NDMd31nwrwU8
oiRhmJb957n9xch3gZFKj6327D6hzxeJvHO2twmQ+dPGyjNlJfQc9Y0tarL8/fLK+6ZodeqLNY41
pLMGW29MZwR9Gijn3LPLDWLvYTX37BVMl/FtP6xMzbeMjc6Lgn5VkZkdO+8eC+rD/MVEs1vRwKbo
l7PGWkmea0pIOVRZxHMcYF1pC0RH2DtkP+PtxWpERLog4jG9Gy5u8LgKCkAyoPySuHqseTu9d0b8
mjYv9W3oEHnZr4bxCERGpzT0pLO71htd/KQtB3Gj5hk9qYFxS3F3xLLgcSLCTMZwujHNPSQDxKh/
gXYYVvJi8ntyGfPzxZ1kUSh7ZfvLIXQmEmsuFwZIDWOmRPVrZsfMsFroLkXX2tQF5XFN69ZSZPQP
G7ldmRnT25gpGCVS3l3AhAOijjL2c1ut25CEZPub9hnNI3YE4YafhHZZMBoPEv90Uty+vOd15AA4
ByB83YZWaPyCZZa+nlAxY1dB574WzufM2FdIomTLnAi8sZZxY6vndg1IK8VIv4dDDAjOvBpPpeAV
YY4J1gyM2w1qtvVrVa20oI8RFHcv1O7aNAoF+e3IaK20S1qDgTOIHRlCPG0BqG+j3zY2RRtkEVka
44B3mpgTcyZEL2lO9pL2G74zUAY3BH1B+o6dljAmZhooY99ktxQW2kr+7StE7aQZaASpNRKGbeGr
gF2lO0TziS56Vf7ZBAfSQ2EbNPE2NwEF280LQ1u+XD++W/st9Lc6anjutP5GME7SMRRLc0PGxKdw
h23GTuvoUhOe754CDOI/IkQIfbHukxZM3/N4DuvOSvNcsxShhoXoCI/J/wTdox9Dfwvr8TOWwcHJ
aG3XwY45Wk486p61NQhmnj5mjmgoYIlizvY/7EU/V1rIyC0xQVNHYeRYFnQi8G0mQhzAjb2FCn2Q
c5ja85DkMBozSrqxFzVn8oBzBr0x17APJB+Uxki/paQokh/NY+BgSiFePCoZorZSlv/9Et99Pkj7
btWSS5DtRwn3micvHUim0nsJqN29T98KT6+pDQ/G39cK7wRrEi0k0r6kMPpMaVa6Mc0XwXl2dHIf
laM8wLvzhNYOb08bgLVllI5d9hfXgVpHVqvZhmODovmRPo/2yq40kwW+iWpmMlAvJCU7dQv4q95F
UYa6BPVxLDfUGunVKvYVu+3iK6/oxnNAU74gtPhKVxCCCUIH4JQ7TA5OO8Bqcfa8oQMGn9tS