<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp2JPkK94LlBr7tpnXWh2CErVIYGff3WGFCK/1Um2ZT8DYStHkZ1ztWllhk/eboMesoVmioE
ulRHpML+XPpK5RxpReryrAF1+32UtT7ndV6BfSzcgE9TrCi7L42M18xuJ50eQbwNQ6f6DYEwB0as
CAkLVzP3+MVkcGOzoatKHlxYPANymqSrQSp2gsesP0jza+CuAWFJ+0/apbaeV2AptL16Cw7/7ZKD
szySIyqfwrp1hSkhSGIyn7GAYY27n+4DtGs8eX+w5Id7ys/xh1blMYJasqKARRhb62dC/eUXYlNi
e+fcFVzcmH3VAIJxIRwEruN+f0SvrK5+lKUJb5Fhy8fkvLZxI684QdxnkZhUmZUIvSxiW1d4TVso
7+p/aYQoLIssu4v9tKJqJPgwYbnqnvg57aLEzoGh5KsIdBOwKM9qVBNfwg6FS37aZzZHzs+OV9/a
Wi25Yv7pm1oVKAV+jSaEhG/wrR49MducU3jY+aFDFZ/N7IqM6fhGjGXYKoDEIV04Qbw5VH6857wo
ePhbtrItYm1l+YvXyM2zzGUKAnrKr6afwYukPmGNTUqNDpLbtMW84uyhr5vTmGgOyGndFQk4qYWq
y24aUqYSiWNbrV0UH/bokIzaDm5GxA1T/r2EZCmp7/Hms/PFys0EGE1E1qFLcF98YQvbe9qcDLRW
vwpL1UMGAm7M8HWcCc7cGjHMjMBG5ZVzFPl9uXVQtWVfa4ikxtLJ/UKD1KJ/b43Q7fGaIjSafezq
W9p0pzSecWmZbdTYdvGuQW804LE8K5DNY+YrhFGfc1U1G8Ry7kUE+CZHpHQhnVBY6ntFqDGmJ8Yw
u0Vbfmbf6ahgJhQ1Oz2c1Tt8+5WoG3MAnEXzKvQBY+k5We/eJm6BNErvDMtoD5lhB6aHemy+oW3W
TtzR1fVU7C81C7g+Igo3vteI0dh/WXFc39350YD0TIZtDpJVQ2f3auG6251ji+gm7IDoWtL/mbdL
PZh2pNC4vWt/asf5iID2MLynAF6ISJJ3q3jl2MhCMrP4upaAcmPI2IwyYzK0mR6sTddFv0LRxt03
6CBB2+4WX03qutAJUD3aicCPTNBKcLvJJHCw/2kR+3UbTyXyf9zWqwXPPUsgKplbr9z35Q7HtzM/
8OSpj/NlqpJlbNEnRqL8ezm9AYcsr+PzhxzqD0puEKC5QxR+rS6E1ojBOwlBalKbB3MNVjR4MLdF
4vr08f9sbHnbVGGORCYQTnrlJUlYHsY4LFIzwZeMQbxIl1ZnEzhSEgf/9QJXdKJjAywRMXEiVRat
OItpbY+sYX4Is7l9zYXoEfzUfBu0syzDQvFsy+ASMmTbZ2mIR5oRgoCSlY9emSA1O16rF/7Y82u/
mjrxvFoTxZ5N5urULDbVMvtl5upBqyaEnMHYHd1Ml0oW2kpmh6lFV5vGn30z8tPY3uY1AH6ZDnU8
Od8bPs424of7IgqYXGgNGem9MgB6HyyjS0i7XaZRaSaKaOTZB62TH1UZy/VnRU/T9DbrMyRKHaeB
Hkasi2HmYyaLJtLbqTw1/CgNXEQT3Gd8awD0rWdfHQgZecDolXqEoi6dyNl+0HrM8e05KWzKkJs/
+N1FNrgoZRsvJE9HiqtBlTPRoPHsln6JOr+fNt1aR/Ehb7F1y6J3ndXZ1ov7mL8ptCgHKgOQ1qVj
Z/uAiEXc/OaWSe9U/u2GgvmxwrUAnthmma3yOacrXEQOVRcD53Rcmop0O8JvHS9mGbvVPhGmZuJV
ehzF+GYBZIUH6MAWpCIMXEBsbx5W2Tu0pCSlPFPIi8SUPyKL8teaIduWPuPGlf3hxLkUjwZNKiTt
+v7TlOu5jkxWaQdGQtubM3kZTkILZTYmHw0K6eLU6LQ3swdA9DbVvgR7kfYQeEreYQlRjjzM/feF
1IJk7+hTUwyXcLfXQLIrzdQE8IWeAKAcyfC4MR4ivnbZWMpER+gOuQpst74KWjiQojX4wkj7cdQk
A6rj9p7phdJRyhuIsZ/OA1ipdmEERga6XAEREQF7ZUuTHie+95KGDYx/0pWAoJthvax/OaIiKj2M
c77J53RtWYYDRLZafO9It6NUt7ryRPtaoEPVMOAZqm2Fp4CBxoQ97FK5jbYdtYZ5sG5d8OwtJLHx
CrMLYNBnEze5ZjpmQU/fHdaei//cMyi6XTXcQWw6vfpyZl1KcmlBN6SGfFoyNHU48CV9eGQLXNPk
X5Fdy4MfS0yWjoiE9dQd7Z/TZOaa6orTjzCvDLXd5q2ZR879+gdu5Uunn64Quo22yM7ubObtTJWS
NgAmstNpE0GZ9rOF3Gw6+gMTB+lm1nRQsuQmuIrmfPy2X25bx7SMiReZ8beZ+AH8Dr+XbcsPNV6S
9GruAq45lj2x07C8G3cLEPbQXM1ZvvOC4ys1Sa78lK2ZgVKJlI80fnP/TC4N/5vSVPFVO9t92plh
7hUIHL1tiwpUO2uYE+20GXwONMveX0nhlLQuuFVZ3du8Dti8OSSlxS+/agNqCOtNdNSB669CZAKe
GFg47blwH6KLfuQXdqhgwka5zIqwxBm1x7+hCuEBJY0asYUv184LqA/DLaV/WtApObGiPkrKNRK9
FyTzTC2LjCGtsSwaYYOqclYPDcfmqelqUi7JdkGi1wc+dOfq2xGewhEYuz/aibmes+fMZKXo7vkU
4qyitE35emI8E8Dxp0wwNfWEPDsDMXAwpJ82QY6WE7VAshhZAsOP9BiXQSt0Vy1+/tB/0r5AfeOG
/uPEoYFgjkp9XtiLHmlGy0MbzE6BkDFSyNjszMyaXaQ98j3CwEXdBjK9rQkcf6SW95EYeC2MwKOA
ig1NFN/+e+dbWQlhhKYdMp1f6xGnws4sX08qrs2p0HH1E4oXpMMcWWcUS3A2kcU/upLMACqPKA4t
2lWSSDpfufZrltfGqQw6JfobPPwU75EfsGIstowtsBl9SkG262PWt9ahFOdtNmYno/dB4y51h5fx
lzUaTznHXTx84CzbRzNXauXlr4YTz9dlG3wfxN2YJ4aFM4+QD8RNTxrnWKo5hT0L7Y3pK1oZL1PY
arTTEznPAuoIPU3+aRSKkZQ9kKOJDNXN0KckWFsiR2UIuO74833KqeO83+lNp5zKF/dJ0C1vH14c
EBzOzInzRiJCHgsIRw081I0gvB/I5xib1hGqU4gX2BX40RQcTopoI2VnhWhQoPqszZiXqA8VkNsu
stWvkFYm24MyHjxp8EOCExHMX6/WjlGbKf9of+d7T/anWTLx1joUurfilzGUdsZK9g1BMJZ9BE2s
enyZN3JLE9boleMVmL4kwErbp0Fv8ls3c3lcPKSHvalQhl+R+O7uNmj1v4SkL4TvSjjkQbsmLD1x
BP+HkLEqzjfmKkt72cJmIeFHdj9D7PVUv1fkSJ2FG9OutdG4CRVB9q+u3zQ8gELAoGOvT/+z7Hzy
0QtuhoDbnRpDsRZCaUQSPJTpR57J2A9H1KtGlZfoplfq6vD7AXre4v0coMF1NJgPdcNHMzdBKtWm
H59yW/6jb00Jhd7PZDWgzRm6CVmwLOaB9XZKDt85czeitaF4riOiHlPPIckCirjvDQrTobwbEdo/
9USFAFmJnK3ZOQTxEOOei9cjO+8mkcKXGtFYHhG0lmGh/w5R4w0jFakaO8yEx/kWnAlfEX1P/CIA
KnURGdX1vVO2K7z+IHUSNJaqoKhnAf9zuCeCCW3iA+ph34GkPXDy64y0o52cmjE2v6wMbiBpCFuA
G1h1gCHEtEl1QePO4NCVxTwTpqLi3bek/yi94SYJgevwZOy2Tc2PjWsuEQm52gpyhBUnO8+zXilW
y1sEWKr+ckETFy0I0e8rtM1JVmMLHXtw+cdd1RtfGLh8nIXZ4fBwSIZi26dhJ2G4oNoxltMI94PK
e/WT3s1mYWGonh1nN+gIe+qnac5fhkf9xI5SztoEbFCx05y3TwMYd20MlUVdsfeGrelFiDpCLaCM
X6wN9zrjMpNQThYxArK/0K4ZHh0/C+ubnS4kL4c5j1c7XXfZq0BEgAQ3eLgczGzCuhx/ZZz5hIyz
WZQI7FYE+xRW5Eo9nlkJxCjrN3I19mIb4Y6WwvCnKMJMYoXWQsilyExL8VN85v46uJ9vIN7HkLNC
GZejvfRefCLy33EIi/MQx+NqY/0Esm4cNA3yE/s5Yibu1FHcnqCgRFeBQ96xyUQRBuXtGFh2OlYR
v7DRmNJMMWvnr8RiOvzVSEcMc6Fd0m9n65GEJxM7/M0OG8geHVGQEzUngUmMVPVoYczWtH4HyOnV
ilOB7IfCsAP6+5BWFcPPu/ue1IIKy+nzhsBamik7N396DZci5VrJbZPAJZUU0NWGVm+4U4Yg1Xi1
RC2Ky8Nn1CsUXvrz24+jKy6d4IN2ajcr+nygB7DJNwqSCJUHFoKjZnskvKur7D01rYk/ev0lSKSg
T6fMluKD3Wz6hQ4PRK61WWNnks9p0NlFVqrePFznIMdzTzPapLC+p3WnaExwCnQGqhUDIwSCthS7
n+fWewz1iE2E+Ff7DTSt0epWEZdqfZHNH8uNKjPCxB6Qc37Dk+BMxIR8+t5WEJZdTCn3cXLAATHV
63BUZrrpdLQMclxJjH8Gpz1VxiTyabN6pT110LT2+f62oqB4tBfNdFGwh7uCoeDvtoOuP3vSsh5I
t4waPUXTvf6xNQfMpm+eArjWBwUos7n7e4Ss+O0PTQhPeMHGDSwIXmon5NffHg1Tw75NDlllIP2s
qB1kiF2awJLKplx77INrvRm0p1/P7Bb7NfDLJ3LSTMbHfUxEf8XxV8ueJXbLXtKqXgYxLa7sveOp
/obUQOG0CivENCLONuAmtDUCxEsEoQHZo7PlBwaYrbUWjnLeBfXTk00qfV6kUlc6JRoFiEtRM+ue
fqSAIqkE5c8ZnogK4wgp1HAZwakn7j17Vw0+qB4M0si3+Fj4n4a1PvYZe8vFAKZvseLo5NYJMxD2
g4dAlEtdHyZjGGoCE0kkS7uSQ0865mA76ETNNYUg23AeHsG5/FCB+YDYQWxql/HenY4JkLsFUQBL
S7HiX5bDBMAwsq0PyULF4neiuhcqCLoPmM83VVa1S2k0Pp80tC076WEQB/kNcN4rxdbpam93raR6
eOYtfj6nT+a615lTZVyYgbH6ZW5HLKfqYVttfc19gh1SVbjRYnWG7Z8qEV7UEJ24xjl8fl62pkL9
L3+Ox/M4vWGiSayn0Iqzdjj3RH8kQ8h7z00flZBH/6LMRU2To4CfM0ejnXeLd81URBGQkQo4ZYSf
wnWbTgGzNCq/o9HzDOcmTMyjXSmUlfERfiKvE1ob6+pC2WQwmCOgorFgsmTJCWY87hBHfaHidCMr
UFdiAWnrjvJcs+uwot+aNLUqzIx8SjwBSkeh05XhHF6aGQ8mPFe9JMb8HqwbKvqVqfGmVGX22mii
hGqWv0qrjQ2LafuzxQT5X902rIWGIBPiq1q1sjFfnPCQIxZQRjsmOYOojxicxo7C/3CeO+KdbZ1R
PgoCfrR/R3EmG7rb0WQbMBIlWwGOkta4wPD7pk85pwugkgwmLMMKkJ66bN4qegZk/STkts5vWvpJ
ZRLXFesKcU8d1tHq/pFmphUnehrzsFWjsDUdw6xu4Vb/m8b+4rkKoldJ8u5u72n40iBDPj0hTqBS
U6ZgTmaiMlDu4cQ4kqXHzm8CbaKd7e8ouhJP0aQNTK/F+MP8vD9ydnNvemYx3sHEBVHeSVhEAGtT
NKk8HkJYES9b9ACDczd64k/6bWbP6IKwwpqmke7I6X7mnasEqjLUdqGiPcGFIPo8uMaUcmiHWFSO
anfj1se1PQ0VXfrifleMsIV72wAbsDAfbZfFC24gfdrS7lz+192+UelRNGeM0NgaGpII71ID3iua
aYU9UWqT+HWCpPWD5z2mD5HHeOInpLRURLwHcXqZvqbYsif5tZD47cEX408v4sMUaPIxtfLxUVrC
FpqAufhCpcXGzy9Hqua3Rwdq1qfGjgRE5pbgYOSWrNrCW59ym77OlVe4H1cmKrE092q4v2eFqvXU
xeOhHpB2uOd3xRvZa4mVgKFpck0lLLlt3mcxD6ATRJbPwr5im2HIifw8A1w4xXxa7khiDsf/MWGr
hEMjz1wCHm4VD63+DQJTNHNo8LO1jQFLl2kjK3aJdXX3BAWGxMKOCVINrJ0ldy+Dz/aWN3JBbPHc
ikl5teTRfE1sh86CllM8L2mhWBaHXvn6w5zxClrQ51XnFsAE0cGYs1BuuTO/LTa5mJ59IXAn/prl
H80ox5dGpenTGk+9uikL71k3Xa08C/VHvwvKpgKLQ8gWJd49VWrTo+Mu+io4M5PPTrVTbgVaFwpx
H77EQ1pN0uprZcyeQ0nxvGjBE4UwybxvBSVp65teykktLf91WUErx2BtsxHgWb9wqI/HvB/4fjVi
cmTkEpJmjSdnFjmxfScervmuEd9HdO8f7JgHaTTfkgYMK5V09WdFq7dDD/WU8L0XDom06tU0eeJr
k/azHcGr8m6GW/8G7UAPh6h1WSZj1VXN2wc50nmuUpr1yx5+IGbWPd9gRYEUm0rRZqpk0RY6HnGI
E1doUSX/2rG8r4Y8E2JlGCAHewEhCOwM5XWIxmsI4439WbKNNfZEGnBKV0dq9QrQrqsM+sh2oRKK
/HtqIb3RKzNwrqd7mFSAzJY45W7rAwbxiBRBohI7syxDBrjkY4X2/uX31DbnCDqOadMj0xhk+QqM
S+/P+e2wuJ/IQtiDAy9gBkq79cIfOooAKa8ulXZ/TT6+gmrRXdN6YQmvPFrPjXf3COffjB4zO22O
gir49oyEUStYHVQauDPfGjWKbnmLWKNBIgdQGNdzeQHcVf7qgJPGpjBETOHLwQWIf3xtwKCMTuvD
zleSBPCN3ULzZRa4lgOnOYjsqrmIK8a9xY1TY7Qj2B20ZhxXuTX3vFeXIRycf9mjxzV2GCsiHQJy
zgXFELrmjvRxZM78l21+jVCtCoTXJAJgco+JO8M3wBxl/glv15+OIEtXW8vQaln6OxXwYmFgY9Nt
wHVrdju548jYIt1fYIBn/cLyso7KwZfbbVRF2TYsxba6dpSkV0DUBCWTV5bui00IpSr92WUlYGUL
PVfag3NAh9KZh3P95lgwkVQM9fTA3q716l1PDHG6aqYNzeQsS4fgEgHcXV9UnB7nuV4FqTY7Ykl5
jtU5TCIl3RilpMHq2VDnqgAqfJNg677Gb8XsM3eL5p3efglojKOE7H/KSjpHGtBgnboH9FZzKnN/
nDZlJRVJ11L5c8nsOi0dwDC1yTf1QVf+dsfOCeeDbAwkrc7KlOOKE16tWC8ZqifQpqNuCuBeJi5E
dEw5+Wc9lyoJgL35doQJIsIyse/7+K5o5cs9bwT8SuVkrLycnIYvC5ZaFs+SaGn4LuVENNNTmgTc
HAuJkJ0Te2bqUu4gA3GKre5KiUrLqP++wE4ZWbwJx/VHQ4f1pX51LXi8DYJ1pgcDbz2Jiw2QOZVq
FyGV2UYOVQAsd8snTPcy01ovDBiqJHfwUo72eBN7WCd+rRj2sXryvKdU31eljDgOhJDFEUB59GQn
6QPbD0W7eNv2s/jqv2O599g3ZHU2paw+c89MVl+U2uWkcPmx2fTZ7fBMjzEgiEZtRiLWJqsFQAVk
LxGo+UFe0ieR7IvQsI/iO16Cla2BybBy207mgYJ5qOQt0bLFjvMAZ+doDS2nrsaSpRciWdW9H1a3
NkIpk206QPi7FXVlb+CiBYsYc49SKs2Y0V322usJ3yknQisTfa7iKepmp7RHBII+buAF7MZJjQUP
7yK2V1QULfjkLEbzQqLGsJ431q2vRd9aAjbHIcLwcKONww6MX4vIyYt+mlOdp0kFP0N+TXJG6uFI
k0WWgFe4s0IEUqJqTOLnb2gV4yvsDJ3m8Mn9MZ86vaUxd6aox9rsO7xkmyZV8TJN27E5aKPiWBix
/xvQmf2IPlNvBICP4759Ex0GrzsnNz9WNPLpSBEcSjK8MKH0K1jQBdddd1gZgbMsA5/m4ecxmllU
pdrg7Yp1nQEFcka/VehRaY/UQM0foevLGuw2JjSzkKF0Rul3u6ytrMpKZcs3IwGPRpYLmnGXTe2o
VfXoB+7L5zOWWHfI1ZXx05K9L2BLVuVgO3l4sMgzZkHnFp9ZNoSrUhkhsM7PVgVNtPptqpsszCVA
xV0FEO7bgVO67xAm9MWVTIwJLOrdHq457xG+C1TARQASZVVlhXPF51TFwIvsuKtDEZATu52Goe9+
t8E6LqoKFW6zfdbTXEiirUuzRgCA9Jyjd9IAObjx3NVI0YISV3BdPkMbgmrr/WxNTQjzGP2XUumw
b/PwZIkkOiOUCmqwowohfzPRIgKGrN8h/AKZlpuNIrPGyD6YFLekn3ragPtXFRFe0hEk5nXlJyes
3jw0JnhPlNZz0jYCrjfglFB1Xky+ZhJ8u1PhpnSapHxvp7xXSWsrle/31i0=