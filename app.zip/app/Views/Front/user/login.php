<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPskeYVyH02ToyDrh7DopJ7EWPbrwrJHmgSDkZdsFyTmQ06KB4FQe3TPajcgQLJGrI6N3QIPH
4grhr9ICfHkZsDzf53K2WED5ygRbWibalbDtH++kBMaKiKiZoGHgvXXTRQbLI7YJsAJ/2Z4cW0U0
6Mi4DdeICmEcNdalfmP1jKTPOKPxmkpUr3w9IHWHY368jDEv7jkxmb8jU0qvBLlUozdrHTzd30jg
P/NWNiaPg0sK3AN/UUaGFz4HlB9Q4vgzrWGViGUhdEQ0wVtC5XO2MZ3dohBCOhIxHKTo+gEZ64fA
pwqkHV+KZr2xnvwHf7sgf9hfLcVsodpH8mfZpVHy13fuMKYDJ/A/1h88n8R9l46BmVHk7jlKjtxQ
wuZsJDnmRAzaFL9M+FTeSHbqdATRirvMI9I0YOefMcnvXXCv+mULDczE4EGqpwwbkPrjWtjYTw57
t6+RGhs3PYhIL5KFHVLWwR2n2arQddLe+F1k6owAV2/NrCnQCYjB8TOuWkNJlT7AAH2nd6dklYWx
DTT9Y4qgjB0dosV1wcsuGtOQgIaIUaoe7WeVxThI55AlIfCIrwlLBsVq6T40R8f70cxQQXK1G69n
vsEoObU9Mo1NiMUWDnLzSeJZmlxH7tskso+NbRqtVtyYcRa6BV9y6V8U2zCkuI68nbqd1/Dm93MN
DnuvYZXpkJl1gvX4OM18sN3hbl08Cm9vg1TEbq1ysxUSjISJBF4OSoiF27o7OC+Us1O2rVpENr2I
mt3WaQVNPWMI+gYQnyjcm1+IG2zRyhDCk5k3qe2U2ctsOe4JsXONMBFNvmmF7A1aFXghau009vAm
zFgT7jB76hWelP4k0eKrRO83HcMJeYeEwW3XfCVfIRuqmAqBMKr9v172G8NpxAe8h/Mq8yuvbJlg
ouwn7TRSUHpXR9ETbWJufQmjk/Dy+3SgmV2HvlWNPxF/356EP47qha9621AHhvxJm26FXsmWrrRr
HIvQEFjffZORsvlcQSBv0lZ8gCX7mtyuKG9uBnhD8wuCUNkkbbyH6n65q4+8M65x1UkwdlM4zWFp
V6/dBY3EtmUfgv7ESiV9PFNBT4DmG7p95YkiSavrS78/zU5NWch+PHQEjIikEScq1ByDqzt1TgcQ
GTWD/d7yScfyDRH9cYeZB6QhudEI/4vEkuuzXak8lLPCab1W/Ih8z0NWRnB9gfJwX4NEZRR1t0ZX
L/SUUPhgJS07PfwH22sTv8+InypwY6fqBh9fcE5vHg+C9MW/2DIPjPO8+ViIOHx7pHEYBMxTlDLQ
kVfO4Upf7xMzT15XKk3/UTxChJ/sqr2MC6jOiTFwKGqP1nPQxHXMK/MhOhOT/3g5SAs380uiAabo
BYUX/NTEYKoqZaeHhF5gnbLIThJSzl8KTMtZwtCF98oAKhrnQ9cTn2jzzVC5dO+MptNWXyISCGss
Trhu93Um7i7dXklwWd5YrC6d4JDcc0jfK51PAaM+fsJP7WkjNHNyoDYlWB1G+4FPX5OC97F3+KyC
R1zvfpAmXFaFgfuv1OT33ckbxACbWg5VU1sBoYHUHnltxLbzZLQ8JP2DFNU3PFCt9h9s/PvpJ8BO
P4ZxOA7DmupwfSLMnRokJMyWwspJVtSa+Y9ZJInkwkzszf5PVGHiS+P1itTFMMvc1zCd6fU5vfJ+
7lahb2ZBBU/qr7F+4f0du0DbsXNyODhUebNTLQW3En+NvWPkGdoo3x0/fIijlOYLPz9+15Zgh9r+
hAg+W28B9+ku1lOi8PhRTk67D7zlGFvcnPT3U2sH7y/nBVh/RYArSeSqBckvzPRWk1PvhTDHulMu
rLP4svs3fBCcMz1kf5/5fS0P1cJ03OW8JFCRZnpz5LFfYA5YE07rXyeuv4iOi1d2t/TdMbIZQ0i7
JXIINRQo89Xu1LjpAMJ99w8ZHMzk0mNI9RAK6JL14UPagCxzizPdoK5UxTR/5mpkMZ5IKY7NDkHm
rC7X8jk4yUvqjg5qR80=