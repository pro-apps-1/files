<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrTS/qu75/F3AEwVQYHbcthkFtXIPKaqo/k2jdywaPYCcl2CIlUcPsYdMsCjupDmlRJ5dqkn
CvFplxnRvO6ieLlCk2HQfHm/hlkUDTTnTSKWZclYJMeHnvWhSFTvsQbX0f4hGT1PXbq9VlaHVfLz
cTLzQGns0h1Sh+8A3jlutnONsRXGDL0GtwJTG9OTvCuhwcCzbehg7zCxVa9BMwmr79EGj3/f+Z3e
vIsg/4byk8DWzd6wYV57soPFJh/o54yHT2YQxwHmtXrmAIhk8KcRH1+1U5ePQZA/nOzjfepQGIBn
BbF76yd4O6Usjq5Rs6EJNBD4DcXRhK/9kbXdbEm+PfSGtTBLKo3fqdoIs1KIfE1PM2SOtuaP2SAS
rCuBfWX01DT5CEbMGg8e8FI4EC+dAu6CYcY/Ny7AaWagaT1rG96kc+w/13rLjnie068m+DvDVR0J
CvWYc5bzcFnxfWRdy74W8KVqCJ8rNFq5C/RV+rsM+WiMJKcutrFhlerzG/Ztgmorlt33OXNvao4B
zFNOXEx0FyM3+BJq8mquinhhiq3TIFQKSUzwpBWHewY0NnIR80qro/LelaA5vWsjx4Rq+5T4Bn+K
4jVISvw8iO2bYEzWaDgBU+qcKpAgl+9xS5iL72tdzrZaQlLVpLQO2dKXzCVH+I587YBMPPGGZYOv
4gcqlT4nLmPwG0mi07iXP9Pz5msaFfUFFT32TSNR4hN4+7ebFu8QSLYxxtm94XnC5l0uzwUMW300
0grKHOjhjjblgDfIGNB7QWlNb9ZrUK3ATSrzxXOO7TYJulSn/zmWYjUnwmWKyQK4sd3MirY4yi6P
YSb+PGBvqJO1Y/YI29wrfHKgXw38agYZySYTy0wUuItVfsG4CTQFMHx6PU+sLDhTmCNCwGmLlpgC
S4M3sffaPwRJmPZNkR2VrpynskFRWwa9T3K/Ea/sfeQ7/pgBpJOut6fknQpQdBLS723p+5xelbI7
iF2IGtPreO0igrp/ivcNe5BaOC6trnQX3huqY5ue+CvWPFc6DI5IRHKalGg6v1rer2ccjRhuWKb3
zLv3RFB9w39SRerKAYhoC4KQ/bSzR0/Yz/Om6UBQlPHbtFqI2bOpBHXJ5j2byI6hANqqrW0BzRvg
lZROY71cYPiDJ4VqL5ZWfSMS6XYhYUijqS17flDBfoE4Q1A59STU3LsgWjsMlbMpPQfI5RdzrdnB
23tNe5aIoTRB6mi34oFtvzmrFT+4/d5EUsDFx6EJHYZNDdX7QkldYut32XqFMAWAjnzXcOZtb3BG
9EuwMIwOziHslxB5neIq1aYsQI6cjW+xXk8COzRQt0Cil/VRgaWv5/yaRwB4zTq5SP520JBvpc6J
lp3CTM98iycx91w6sL8SuINYHS92O5PqmJcKo7FgCcpwwUTTfM5/bZS7p2tvX1/fDoSK6LWNFPlc
gcnqYZVGrW038rJYM7KoGqTyQD6bbsGG6+Lc/UE298DM8dE9OQZ3kYqbUdjudvfi78XK1AW9PJNN
tuEZwiQhKatpmVeQfRfz+dnbM7IKF/F1s0zGVkZY60tc/WeASDr5hTfciaFaKQNXRRz1ufyRuTXZ
N5tIZXkzcXyHPofcqw5mD/A5D4z+h0ajRjNfLHrMgi6yGsV58Yn8H2YRbrEKsUg4aaN08s7dj+ah
cSAkYv8/jDpLwuCIttDvPwPa6ro4y3W7/LlSDBJa1P/WUV6WmCxjzMiG/U5z3vGZvvQTEbTKEheW
NfiSyGmpcLZooj6HsrBuHW2UiwrQcN/JGIT+zbO8v/juLqLWVoEtwcEwug7CsbpuplvBPuK+vPeN
Mbn6zgJWdBN/RisBE3fw3qzlEB45w10eYjAM9ojIhq6cpaAXbtjGbbjz+lcqJr3bpI6q18VYjhO5
WE7jrp5l547bdfWoeh6ueSbSPQ2KG4pYBBLEaJie5Ubv9271YGAiSzbqPyJ2n9fT+5VFCYrYusfC
KCcNAomW4tknDtuuum==