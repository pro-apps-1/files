<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnBzCkkdK8VClZwdo4PeeCdKWAQdJUKYlesu1+7ZNqyrqUbkLQVOZdCviOWogjZyykfMmdv9
UJAgu44KVSlQzXU/FVEiSxxABhunRSzWgFVfIVKTBOFCafl6too3C6Lu6h0k97EEHfAXVIAVVzSQ
SFyJ7sWwQdgnrEBIS30UPhrqPcKtzZ3J6dF2/VBzCdvU9FfrjSDUNjbTLSkvkOzf3p/en7Y7W/Bo
a/mnUiKI7lxmA2ucrmbD+O2iDofggjThf1Q28Rv5Gtg/oOGMaUIvJ7aVDijkNn8D2u1c3wmSxS49
2yOBYsskufLYhSi6fd3Z0M9iWZFeR2mxehr1NZKiZQe/9eZD2eatRUENltPsvRcG2T/C/LOgEMMP
c6mBdTAeXL/CdGykTnyLgLOB5MVPbEff9K14SQzRNPHtqddViT0pAra+Y+gAxcMATxngJ115qyzr
PFMpSD1sM+HkG2PxWVFiFvV0ptkeN5btW2CwHuwBnLDpXgjJF/09idkbMrqnT4cV4gPw8RnWI3iA
dTV5LlIZrUR5mfTiEUxF4km/h+5vdWdIpsvepw0tCniem7+RQ9d+npCK63J2m3H9kwg8ljdNm8AA
qpkjUzJ53fSueeX3CFBLDINUmkqJgzl9QqkpKqgE80edGnl/SzCt90MXkyriisjjAEck4keA02Rv
da7eFP5BS76fIw/LPTTvNadGp6rZBliQ0HQO8BL5o0e1djXLSKAbHreAKdrvsp0Pm14Pk5p899v6
czEuIg5cx/Sh4Dy3KJ+lB6yHo4AD2h3AewACWJ4qeyO7fRVER+HklpMwkcyOoSf2pMHX7w0oMDoJ
EEGQ2tW2O07Sli/tEiPDYC/rME/Cj3go0xc+yD/k91GB1kSBrw1uUdKSxqERCJaXWQiHt/n5mTgV
Ned65G/40MPBs1IJbgdsnWKqUXEnescFIl0lAco8XmoMiLtLLHeaEge1Oi1PmqhE46OIEC5FJRyL
RqLik3FdIwMI/MuN/jbosSRqpiKX8KhJ3oBPYAZzCzqZLIa4iIyP4eYPP7AUXWeN9M6JSsrguagN
3IxpMHZ6QtJjK7ERC8MsR2L6m9GwC1O0DhbyYDzRNEw3mvffKTMf+Qo1IjdcAYnnuwnQzV5MEEoP
QXeiwCndAWtha7KeQhvqjzSgct1F5/ZCCIF4J5XgtDnfA1Cpb39B2EP4uAa2ZcF3GIUOrofoq0IE
0UoBX2jP+HL77CkZVbo5H5Pjx43qmTOGMXwBRADo/hlT+hnpe98V+K85/Ph9d64hx52KjmbONJ4/
jWC5NV1n0n1UNryPk3cTXL6SD1VzPqCxsCkNkgDNdNWdvbeqcl8o3aGnAUQmQwmIHTV7pxzqaco3
R5dl77gaqdCRAyUsgnx8YnlIFU/t0fSsWr4Af5mK/vXskT1737Q/6+2Baf+3Ad5saeDY3AJwMb4E
52SZbxuemV2SDDDqQjxb5uFncuwtCD+P5PaeGYM+CwBi4wn8mYBUAhjJhU+7MEJzFHle8Ilgws8d
Ujso+dwHUOhP65rTZlFJJCi66ma3h1hjl4P8RC2iwAdfeHpjUWM4qQ188wbAI4LwQb54SHIiQh25
GKCNe4WnWTi2FQdfShKqaSFZ/ls1jPu0DzfbyDjZHg23FfVf6kkfN1iEbO67rLWqoNR/uf6zWrtA
L1RNoHdiYu0N2LDUVsaT5SwQ/qqi71RkxJAJqptnt6w5kvWKY9qVCa5VweEfm0Ilrs0dIztXyD30
f5/GQ3k35QYo1j1Xv6dn6HUjlIsRBr7yfpZpbBdkBFKMWtD6zb6C1Xq4gM9vOcZKePASNuaBCHNk
I3iw0xLuuRqMWbK5mBMfef1+LsTxt6POSS+yZcd+JCnIkCqSNthILk1DnbGibnlc2wjgKI+UGtPf
R4AiIZYvDTFghKOv4feKP5X/Omn63TW5Os7Hqbcc+L75PvzysOSXXVv9W+o6iuRUZkDB9oILMmHw
O3v4NVI98dBvBF6wEOIXCdylRBdvQ7nh