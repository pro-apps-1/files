<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvppkrqtOW2IpZ0kVhq7BaFQ9l/FhAw3jkrJVCqbEYEnGgRyz8eO/g3u5icpbXVn4VolCThZ
2/55q2T6GRSZc5//BZyo/DjFGZqe1vWsEAu/HsHFLgfeJEjWVRTV+/EL5qtvWJO264sKgczrOUY3
PBIj/GFo/u7LW9yxJVIscNvCTLwPRTnYvWwDR5XbJimvy6XWUUZ0L/eKyBZl6zSe6D0Vh0PTRCgS
/F1OshUCK6koOU3DoPIFTZGNz7S3XnZnAPpeHIeADpHZv1ITmSJY4lsWpyEPR0LzT03yXS2tzwVc
KeAVJ76kRAPcVG20xnNMmk6JNUP9BV247Cg2k2/AaZM092fCcXaz8mYqrV4Y2FvpbXDi4Q9O6C8x
YZE5bst+ho8c4eLWX9KqFKs69YLC1Lm2v+73Mol1wvnmcjU1i2zhAOvnX7nJKxKaQGirprW+eKoV
gxS8JemXTOrfMGAhQqOO9tQMcJd/xpEbepNWT2rf2lB5i+6DS459WyeQ1uaEFodqNeyoLH0Tn3TC
uOiBJ6TQOKsVRmstD9bPKLMGOivdNT9c1+sfsZCwfKvg1SeNERGk4OQkOfqZdmsNBSSn7VrC3dhc
JJ8DKNdwbl3Tk9PkyRweu4mQfjSK4qz9cJKPOET88/5YuRHw17f3o9cQAG3w5FMH6/MnHVQ2VbOx
TGsXy1yw5qOCSjYVfTxUcecUyArXQGszAZLNtMroy8yvIkT9zr6j6Bgvd1y57O8lH7oOgOrXMwUy
XQLkeRwUvb7QwOToDJl/99UKAqKVoyhfwdK1sFfns1E2eUFsr6pd94q6IdDhzGyoSxhZRSNAE1VW
1znFEr3Kn7Ey/AKmavIc/JObiU4ackcvdQKUz5ulrXxM37ibSzdf9G25SzaVV7tLVKHUEKWae57t
dGsdcoRCeHu9Bn6OWbcxo3lqFtXH8XypqwpPdzmQYp1aR96zWM0XBaECdgsSvUK3C7NQD+oxmh3l
4tHLkrBoEKyZ9nFkOsCZt9+wMcfHiulTa8cRT2iUgzyU/TamSAaLpK6IeeQJUkZZnfwRi+R+ehCk
bPu/O9UxOzJM9n20JOFqbURNf/Atzsc6SooLdVHvNNJ/rNzpPQbM9QVe6t+g05WczTpG0oTpl8QW
Q9i4Ad/3os+eO71/ObEjrkqILKLmFJ3mcjtjqId+Hql/8pauXfD/NjukVnMcfe+DlzWqy5h1KXlJ
PgWDFteg1OCzprUANg1V5mB6Mommq8w3k6vbJgHTb4hNl0PD9x8dxXe0DIIsojnRldrZcjGOgtqN
aVyKDEmewBubonRR/DFSc+/XEX9dovETHH3mOe90365CeLqVNFpqYHgn8otZcrAIsbKRXr29044O
ACwejZGb8UA+2nDB7FVfZypndFFzXhYMAXboiMmOttk34cpHlHjMmpI7eYVX5EiXUCkebUf/8hho
JmogZaq4rPC6IwEZfMtdKqX75Eai7O+z5mCc3fxHHGwCQGvEEsqfhttSQFP1/c8sjixOkQdaScQB
OaS8ckY1Wh5FdDRxGAyRQk5q1B5EvlW2juUQTziEu+RJUOUrl3wtV3FSj+FUHq9hmXvdeyI1aHiu
OQG6tehn3ccIMx4vxxWip63SIkTzR74ZCw3al7Xgta1EnoDDPldDz9BacZsRlCyNRz2ZymInYNEc
X0BVArlG2zfRIx3xwPDRd41XvgPc756/DJfhc3NSIViPs73AC1G8f9uE34B9QHd36CCv/m6m9Wbl
BKr0puVrehoaK5WA5r0BByt3ESMPQyyLGrE/9KpWQsBWqen0kQICgTOGOlmOrXPvgWnWzFbn9HSH
5ISx6yb/X2o10kDwRSMMQzasXiXdvH1MnC/6uQYsE5KcWnhC6/syLrSW/4RYZQiQsFbFQklxQqD8
4h6eO7Xvu1wnv0mRCoYkboM0gQ7ByWFE9DnKYdrT5pGrMitjirruDkg+ROIBm4bxyYoNrK/OkV05
qi2MFgnqASFrTT6gMB221BYCWUwdWHSI5CJ3hg/oup3QU4k11C9fJQU6pyMbe19xdNG=