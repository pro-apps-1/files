<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPutunC9ILptrApjHuT6Sg7u1s+zGsqs57gQufvqOR2D6bQNePVRaEoHhI5uw4IqWwWfUZnvR
4Qv5KfizCihn6X7mQcsI0hDEIjgiVgKD7KsGA66X1OHvhvu0Lz9Qg5I2MEpOdbYWhrQfjzE1Ni6Q
5a1n5b/q5rVPa+rSJEr46ibjkvR/3qaBrrmOzv1brw5ueN48NoaQuoOc2lQ6Uk1f2oXkBMxooBj/
IEIKO83LtyITICTCNIlmlRYzGWrTemV9eguDGXwzETahMeqc6ktl13TsVRDZ8agBxQFC4ZyZYW+W
LhaqN07IQvwAA0YoMCKY2UJby/i4DK2du6ihftFu60LyezPzqzl0kLD6elyUA0A0cjYG9JI2N/LI
1zvepmpglGwKmDZhGs5/bZXrYGUdS/iTlPiFKPrIRQWLX0h6CUkJb5ijSzfCTh4G6wJTvSvC7YWf
S8FNbB15y29gSBZEntTsFm+R24ZIc+lv9urZEZRJXt9By7k4zaXalC6aWjwqbxvGq0SYJXA+L/9d
PhmhGl6L+h+hpUXfj/FRFgJ2fBsa1orhkr8TXLJcmIPfsNtdTMCbQesilToDzpakkPfiovyINjRA
oSxDMpQcxLUPIBIyNEkd5d2OvWusfL263T2x2PZwx8eNAjhlQ4Y10JDtrsK419rT6eXvKfazf2bh
TKKaTlGCfMDH89HxTo2F398ryzJq7Td223yxIRa5vmHo/08el4hQ/dnOC/zNj8D17ya/lbStWtLh
kaOZqy92xBh/pAlgmo1WTtfo+88v37h4IsiSvVc+irbkrA0MmcZHDkeOZpRr+ibZVzuM7tWdY1vm
VGwvTxDNwtPD3DPezhEFNYW+EOw6zlg+LTskarSmf7YhFSKUxLDwmXVLFKHvPtYm1Ev0DleUlfnn
c/K/9VLyzbKoBmiYiPXiIiSH7CuRHddK/XnEwN62Gx6N6fpH7i5gXI8qGeSzz9MBzDQgOLfcCov9
eKDhsEMeFf1ilfSf6V/fOo61jVO+96uWJDQVL5cQY8hyEIH2bijI1fJnaxDAP6aefDpEmMzzj+Xg
Z6w214IPMdUTGuW0tu/JjhNiKAs8eGcTme/SZyXNuC+4pAn9NHvLs54TNDUb0XWaCvCe5kxKIx85
/34ptvQroWpm0qx39uNArMdhN8m+ekwdXZ97+Ygjrt5knnN3EdEgUoVuu6y6+maNk1XREsXOJLEs
qtdY6bEGmG2K8RRIC70Oh+wihPrYez64w0rHl+TwHmVxtudGPXx9xzOoAES7TfCUzHc1KNUh+a5i
dFtAm4tx9VgIbVlQaM9YbwbHPYF+20fT7lPSZzLha3hRovhJuiVYVeiVCAlKxTHJDsf8d3BNt5P/
vXqaJfyzE2QG1ixcmupgWytQpNr++6H2toMn6Ou6Ua6PYfyg22+rGNL0dUFrrTJevlfS0UvIAH0n
lr2C0GATW2OXxugMs68/CY+77C5zyNaAqwb1I8ZI2nlzEDFiVg5kA4qx7RSBiQaDJ7yebmxHuIbf
VDEBrm9ilcQAGIsjw5MGw+p0QgLkrfnlJpboXyVGct+0PCCRiWmrZcPX2k3lpIkntb1SIZGx1ksb
EiHzEsIdGUw79waRAGx2nr56xqyE6zP2qwvoXdrdYI2yCMe3PH6y3El2IWy6R2udJpJeJ4v0jT5d
WeqT5PfAjPJLv1CYlBO8Dz+wALvedovdW1+be+MrFGXTCGHRUhydrjR2i+nGS4eY6onhhobTAJVr
V/X8+Dk+CE2a/Kfv1S9Xs9jkCnt/UETEMA3F4+5djNh2N/cfV63vs72xOMFVWNQwU/r8Qk2Hc8y1
DFcq5LswbRJsqGtd1TdpBjUIxIgDhrTW9FGBplGeuRPvT8t+/tk1qn/1Lnim0NB6aQLSR1EJ7k3j
BdhaNtjKd7CzmWFuryYFzSBUGacJdtzYENdsQ4Wdbf+TVxJRGg8TsaR/eqfMrQjd6GhZJQ2mFy0E
RohYIu6wKlKfrcv1H99zeqYcjXrxtB2qMgqbW9ne