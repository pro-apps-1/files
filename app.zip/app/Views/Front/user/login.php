<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmbY8/Ib/PVxiA6srqaRsyRQfmFPuiudtwIuLiBglE9AqmFvvS1kGjiToKfKQ+DlLw7RMcet
BuYwLAzf1TvmyvJZuouPqZ8b1RIBI46kWKnU5sCsmkyOvNj7WVKPsvRZak2OfXDBXLsWGkTbdjle
2xLmxerf0zzCdeldEdu8ZigIqZxy7WLXWgpGs1u+sXILSnDnQfPN87Telvt+19A5T9iQiWtXjZ2E
4DMh97sbYPoy3KsgwB+gKjntta7EQy2Q47Mmbe2r2DXL8GlSdw9cbuGu5HLjS9VQhez0MjffdCiJ
37bYwxq/r6+zZ2ATr8b3YUSz0nD42IXoxVCHmtjiG4zJp7Ct/ocwBiHKXfaNdqIqn2bpTj9Y02+g
ce04oQAvPDYnt7ed9jFz4g3d0jlhSUhcvjP1ZaqC4U3P4oDSkhbdyjqsbRPnGOhEYEbWsRZT/KRq
5d6tVIg3Hn1DYpJOMV+qaFlxI53oODAcZIpF2T2LeGFIQlTD3MKCpmKGOzJrnetxEz4KjMGt1pry
X9Px/g62URDjkgMEPQmbcocOgcWe4IM8DVceV/gv12SbAMoHPSiqSBnl/MxYRQgcnB1eNmFfYrAO
lxWQ5ZY7FV9HqAA26JqJwE/crmrUcGRiuDQnm4F5QR2hs1THJPheH6p9/oLUaBplKNL37sECZb33
QM7V31q4fqZKR2X9PBfI1AsoMyDGqwAx1Ygs5fdLBde54IuYoc9y6EsTJwlHQcEOEcVIXE2G14NP
bhOHby4ChPACD/0SFGd7jonePIcjX/emAO+b3sf5mGeNW1avuxEH1j4OpXAsx8Ofqy4efYmxMcap
PMJ1o3VZQpZVPHRdjt0tC+RxU+vbkOQYi9Uwf5Ip3ePVEv7o1r4ivEkKXJJOyC3/I8LnKCk8I6bW
1x+sB3VDFXTaihlJ7wGERnGaJWMdQBa6pob87MQ5kaLf5fipDGGT+f2KUTq6K/lXULAaePwYYy8T
2+GqWEwWUohD7mWOrL788cfGw9/KVlRCKAElJDKmI7vwnmTFD3VuVqqoqK97CBNIJipzqygAwFGQ
7f2bjuDewcWMcML3CWsfgrxNoYUhxpZYtsLFb2lkRwSmqGpOXmctB4Ot2IJB8LZDlywENTdGrbyW
xkrKdWhYBt+jv8bF4a8WXGeaRq5+gVwAueHJYHGdV/wJRVFr5wOqmcAt1TnpVjfw+3761t+G0g2L
hli27+ui+yExtaieTZFS1eUuPBw/klqeitGCISyhY3GMUZJXw7j27kwrNLFUTPzb1+1z2+Qa/+6W
UhVjiOWCAGxMXWKF5GFrZDo6cfEZ7gV/DkFRmB61dALAU69ddUBhRlSoCPWYxjsxFY5Srl0bvhJJ
NSnVza1H+DY+RkRKyx3CgEPJRmWbRaluWTtXdTJcdJw5GgUIGYdD95eeslr231lS4xuVjlCK78iD
bNnwl+e9VFOngMNKSpZ7KoEp0tvmX8nwKKkk/tEGRs2GBU9qHY6n5klqVWHx3NLnKYMKJ2h+GlpZ
dUT7DNTtxUA/mFulyCLrXbjUkQKDFHNBT4VEKB2G9eLXB/IVTqOiIFcU9+8S1ODEdDLj61bg58yD
Iyjac27uxj43PYxOHDnNqz6FPQ0ouwFMXpbvEeL4ISHguRJHTrbVVbpMHuVRlfYT6p9ifkOmSMZv
Ge5dsiLg1HBXldBML+hZfrVQVNZX2pK5az0FNB7XQyOFs9Zi4Qc8ufq6BJA/qp/KQMCeuvIdvn/K
lM+sjIi3kUTF9J4P1i7zpaARRWF/PG+x1lrsxHP0YK+Sg4s2X4DkK+abCVPyLTSwIboN14f6ffa3
wH6vZQtQWHpgIQPNRJMV8f4TSfh8XayGV3c7fdCkfHKRHHX1e6L72Q7keSTmuI4RCBhPqngoFZ6K
18GD23EMrnwPx1dGb1uCTPtuv+H+5HYkG7xqaawuJoFtLUo8E8vtjOWb5FzrnM9N0s+kE3uhmHEV
x2q0iR0o56Ii6c+pfm==