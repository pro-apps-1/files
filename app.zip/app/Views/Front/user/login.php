<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpZttMZpRYPFYZH8InW+cQTiba7zuziL2Rcu/zeO/mFBGRQxucX0iBpu8P2Zr9OxVI3mBQSP
Bq0UXwBwsKgdYtEI0X0uPE37IxR+bMxPiRSkBSdOAnKJpsOEUXKUaYpzC59KurKJQ+tzbhguGr0C
UsZxXfNc+U/C6WyTBKVALzLW08CfYyYjNDCpVzKzpAvfxTPf6VTLZStA+cdAr/DF89p/2ybtQ7d2
efcSH3yYVsQBnFT/z4fFk+1//8tkSJFsx8Z+gTMs0bR9yaI/G9MPSJsk0eXkcbFDS8bcrKt06bu+
ePmJ6DKKkxL6foQUcOmrpOKnWAhCJInE3xjLR9FiIq304q/utsBA0wnwNn8uFjewX/4oFfxrEkIY
PSA5hwynxQ7nXjcoy+t/Kv1cVv/3rhBY5jRdacnVh91XS30LbtfGYs0H7Jhg6U24ckA0H5r456TV
pYT6wvFPLs6UBjqCv8I2aNvyXyhz4tM6RKe1NLEx5UCt4GvDGHmW1kedv/NYm67Wqq8sOp5/Y6r2
av22bFgpUsXmYRbV1YVUeA+SGy1Ta+TOIfG93N34RbEB6+fY8+ofMIIT3Cd3nIU3wK4NNdfTkyAB
/3Md6uZ99u86ZIBmDSgIlGsuxZY5ACloyKX/QbNTFQoUcw6UG01piX//FPhgdTbJO+ieNKtAJTHS
+8MWlFIZS0mwN8oh5a5uDZzw2esKUEDWLvo9e9gAQAYoiJiJ4crVqHoNrL6k630KHhUPnepTcr0U
VbG0l0WjB7U2q3+XNSf8AnsuSRR+s7VvQ+E8W6DJrhmttp/F98VO7fJCtCef+6Bl50nJXltUUiIb
+GPmrt7PycHUgDVuAg1WM7qk+QrwPPHFVoPr7qhKf5ouGwxhp24zIUoXTi5UZRESPw66no+BiLX9
kz/Vp8igyzzRpL+Ae12h4b142vfDeVgnXQjo6qUNRg/aZxddZvbEI4bMiTaPh9hDJW3YwIemHfFV
19zpyi7u+MmL7ew51zDJT3JwfbrXEb39uNNcx+/TSsZykG8iLvfSzF4q75sPQ2jjxPMSJJ4AM9z2
FnXOhDxFKYSuH/+GJHgw5pG1KY7Ii4rKLulif5YKbHXknI5g5TKjO2Ts18k9D96ovCGYT5NksWn9
Pt+/V0ZQ2Z93Py62OWqYWU6TPEJU5zX21HRkvD7eomLHubH1zZYC2ypO+P06ZNh1TNS+rQpGi+So
B4CFmKm8YV1HhCR5yBYyR1Xhp3Bx36GthKbI32W+NGSgPsbq0O7GKtLnIxMOds5jSwO4xjOiXry7
AsdPRPBCPXrStkrNioRCw82hNxq9is3E79dMX6Jmz7a+w8hKSR24uDkPToTT/tAmRPiAlykZhznB
U4G7hCWgucPW0JTVgwhyPw//TVN9zA4WTmSGW15XANXjbokBk7RgfOSYFa5ppgL2KuW/5rY1BVQb
scUa/bHDL9g7Xa77wNtAzP/rC+o/Vcz/x+weo3xvQ1xPZ8NzRggJtI0bJOc9d/Trzep2rCD2sdgS
c4kSjhPtHOApPZr2rGoMB6zLc7DdksFM4vRasMZljCTmfzjLDRccj2d0P6fH5KN0vbOCj5fjiapK
Y/zU6M5binbAZNsaJzFF3exRT+hwuegfXViL3f9f7jvVi5SBpdYzecem/6ojh6xSxAX0fu6V7UHE
cwufNZ0MQjMsz8igZ6aoEa3VdsfTILYRomg1GAQfedL0qsD9p/3zGxtddcHMXKY2JvLjE//pJnCs
ERoNzoVVLVy7lxX6Im0WzKEgXSKR1x9qSZqSTgLzoFYnkOYZXtjROCz06o/TWryh/+WOi83TVidE
nouQVRjsf1x1noCzNeg91GRKZ2U5gMNVQFKqRUgwSkWDCVJZmXavWyVagbE33M+s7Frt/qiQ8aSF
yJBdAe0XY5wkhZv9xtTdO0nhzggaQDy92cEX/b407Q0borA2Cp2S+9X9FtMMP4AYQZVHX3a6xkl0
Sf8AJ3rXtXGJIwFPexclUpM9