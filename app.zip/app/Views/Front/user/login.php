<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqtig73fOn57z2yzKtoAmie45qj4o9BjviPi3oSSHl2gJ4pjAjlxQxEw3L5oUUA7AzP3wdJE
ckIWeGhaPqCIJ1LVdteifjFzucaz1/J5ZRRXhBbe5tF5BiC0tr2ZZLln4ePY4vDJM2IHmHEzoV6z
Xhp8MmZ+A4MCxSpSx8Pell7sVygk1uSLnJ9AOy6dKGgs03rR6ZiuHT9x6CYY9g7E9L9NZOHPCo93
4vdDow1lBOJawcm8Crh7Yw+F4vyO70lXdtW0BB3TLBvGQXZBUGSJyY3KyGTELMVvPvcchd0tza4D
eOgAPIF/x7YpiWJHZhbVHNfs9iB8bQKMREwsDFZHEh3eH/Tb9QsNq19khowI0teglDyZl1tcoKDU
2qnXhHTl+9PUqMaChztmtNHwgcGImNkfiwUGrphfDreggvj7c+RasVZW0lc6UgLyDA3mNsi8O9qs
BDBwtcIf78kvUYEPYCQIPtfriZhwVlht2RGOVpQWvJ8BQyCbz7elc6srWAOMbDF1j0PzRFkwfYvA
gJwSHbDzy8igbIkKziSagvc+LhcHJFjxN0OgVQ+6EdDuskjUAs+yQRskM0XkQwHXm98qCrQSy+Gk
PsFSmaB4nYX0iruZ1PkDAsuQnwtSDn1SehSUHMNhK7tBNgqs2J2OMxgK6gBESyBtpObDZ9mWIfhu
8XsGDLuus4NdkgMdjtOGxGXbXP6BAhOAFqS5A7UBZWH6yHEweWZmYFCr1/rym1vkg6zr8/LQYPGE
VygYZC3MdnYhJ6sWfdCb6z6IpnFkfABnc/bpHoQJwfVlwZVIYh9aHQyCw7XDbSCtoLiZlkKXM5oY
mSI3gVliCjjKsBlkwhR04zB++rB/l6QlSEddQjaT0t3SCS14qPwEEL5PQ3P23G6ZSr1960Q7h1mY
+7hA5WF4exiiXRPbTCYQNY4RBaSBG1Zc4z7A1dcOGv4I4HXM7iepCq6X9GCO/bI90C87A3DMAuig
dS94J14gkDnnAfspVyT0heoRtKz1LQaj0rCxpo68UmQ/ADtyiKHCLxzt43qRSbe5pNvP+971NzIk
wbFhwO+mox0ORyKpUJeudbk9RCVoCEpCMYmk24spkpwhLbf/fHXtgxw8s9lYp13REn9vq4T8og47
u1UPEXXWxHi+q939hCcYBuJpbw49Ewun/i6wLai9uI1+YnJjWZCS2S6psc2rTfhfAtmv9Cwx5Qcr
L3dGRPc66aLoia4w1hhvY4mHOfQXmnmcrYHUMxMOLeNkkNC6BlMUHx3/rLgAlJ1wo/r5ZOfI9odx
com+c1qFTBpDPm9Y0PAH5lgn5Dz7J5mVQTeLMHmblXLum1Z9iOY+YdZ/1oaBfrcwobEjs2oLmcQK
7xCIbPAUtTMt5iKziNi5v4on2YXRCyK42X7mq5dNFRE0b8I+l6AVnVT8+zp1i36AfhjsyFzWlwAu
8euCrR2PqhMlB8UyM704txo8ATWXn8KLrsWGHTaMfvIS79U701h/aoA0yI3Q577Zt6fWIchSWO6I
lUR98oY6s9aSLE0w5IOi5GkriG+1TdDzPHASSKccmALAZT9lsRMXUeqGYXUQuqjsc4ZfLDjlcFj7
kz+oqaNsRouj0c5ohg3DJAn4XuOPJorxpfU+vA0qrJPCujQy9VbVnX2VmEHngnvqp+1VxWxYyr9x
gOIAUOjCwQLgzLngRjvHA9rM2MgamcEjLlDX+f7/VkV83j5xUhosTFA3UDz1DbaU9NRdP5/DKJqs
//BQKmy2t2S/7AF+2V4SazyxL18Q9iwcvDLwEOlUWxfHjIee/Uux3uNweqgpOmQc29o4OPVjqCBh
THw9TFcLNJyO2B2/8CHec/CM0nAYSahp/uAys5BR65eQf4Z8Jkoz9+F1L+MlMpzbCcPaforjJG6T
g5996yfFp/LdcWdXchX6N29DHRwDoquETmTBXqKOqq2M7yeAK8dTlpUk93bu5bSJbcl4el1SOV6o
cARfQ1PqWo+Zm6vp2W==