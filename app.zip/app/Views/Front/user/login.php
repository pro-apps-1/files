<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+hs33QvQFKvH3MP5T4KevO2kvS8NYZm7+OCFGu3yXeDriLGyioumsTnrRqbmV48bUVmcK2j
IgSAbd3mb4DposTJWYvzQczBH1cVhLQ3m/HKJX0LD7KoD18NLVXgrlBslrHJvQSCKf0piKZ9nU3N
2SgOkxR4d4I1hwXPKueb27k+f7e2YSPyXYfN5eNN0s80eqD9e+LWgpgnb5E2qwgb3D5pSGJveJXY
p2/lzkDA4UBrwGe2Tra6RsJ2m7jKayzAJ+2AUAA5324ZiJIEDDRe69G++EGTxMQyczE3/kxEL+d4
HUipZKl/jlxNU+73+kgMyQ16tvTN8RbYVly30p0YVR5wEU2swa+xMedCQciHtZNaHycjGa9EK9Ni
1lY5NpVmO0mMAryRPIt9dKJ7aNiXENJyWf8vro341WUVQ+oiIxERgEc6gkj3WYAZIZAeNX7dY4yV
GHLyFZQp3dpAWlIyiha8CV+djG2JU9/SUcMhhXZUhGdacnLkdARCrwVQouo8WYNU+ZkM/sKw4bqF
11GwDQriBlkaSMQrsPNVEfkgw8SRDdq0kji+X+MXsuXUGdgLHByjepAz6umFrYNfJ1k7npfa1Egy
yteiw1Gef7W4l78Oj2Q5n3RTkKRSKjxC15wxAw0kylL9OF5XdYYyzhbbP9tUu5vzRcRKm0j3vb7a
h7uQeXNc8p6K/tBpO6x1482QSX2Xb0O+ZKrkivUvSGaqXqwfRsaB2TyPM3vlbb9OmpMNRmZSpMIQ
El/7RbzWdiMiGXxHRTywQxfeoA5WqfIKibbr8F17Hqg8qNlRroIN+BYPkw/9/1MxTrKfsMyLLflP
b4KgsggrPWkwwyGzXZC3atA5zWkdmXpIqABram87ct5Fuhivx/BEnFRQz2pqpRsuhclHB0ChA0j5
B2FDoVM0O0NZHqc64ZPWbWIydovg6m7P8MU1HTQyGu/jitA2aAO3Yyexvk0QdSTmW0KS3QkA8wD/
YufwjlDkOWuYwtztk5JePFmpAJ7HRvYkfKKarfe3gG9UWKj5SAJO1U/0KV8dKRtAIDCFKXWOd9Y8
NBLs7kZviJAHQxn2grAc0mlaE8KEafMFV8wEessWsdFNHO7SiVhP5NFCBi+3Zne1Secbw7jEDAdV
NrXg2vgMKEV5ZzHrWl2VW/s8aMCF4z+yNel61DiT1ArHNgqV2f+1ZcNCdDQ21yBgKST4lFKQ6FPG
2gSNqF3dzNbKgKfifqDRWzbtd9LUlyrJi922ZPPpVe1qyVkA5WQBo6VaQEPMp4UuilL5EA1FTi1r
e3fwHcx3CDWieTf+0Q3OMLk2V7WJAmH6kDVWjmc1V8wG6MZrH0znmt53rjQa9dYsILTzTJd/2KMa
RI8sdnR/VPp6xy1tXUlIupCtnbJthytfysR3jsp5rSsaTqybSyATorwP0naNmYlOLxoi895zDxlY
3aTkf0ik+CG1UxxlzJ4g10aBlDniFvIhJhLGuAxBMaZ0JtiuOKj+whzfvLnljGfu3DheZbxKoBxC
SSIt+IdKEW09Y90ZML3NrCal9k3o1PCkh62m49Lpugf3rngLzyQuSzqaXclc3DSbGaIAEH3QovZf
AomZh0xoxXJTvwvOj7ieXTVmPdSIvc7D1spw7Vr8dBLt8ig1EXgaebqovevK8oWDKGSqgXpI+IuJ
hFVjDyJTypbYEgHpHbqPAgLx+AMrmC35i47IZ1rRxL5kqswAg4nym5xb1LTP3Qa/YpfEmF9IW22t
3HKFW0c5BPM6Bu9KG8yjj8kEYomVuIgLBoBUSu9bcXNxJ68QLEX2Tu9vjzsSsjhVkH/AL/rdDLUw
hxT0zLJAgIMUU9ybRvebdDsbeC0FZ7tCsOEPXrFCbivw9dwvuGtL8MAfmmBCXPYHx9fJ+ftMrfg4
Eyypo8DT32LftB2Ae7qxKt+3RauNSi92MebxD1KTz1ZQgpbaIzcHpp0OVrllmOQW53+z/Ngk6mBW
A5ttP9rLRjz7ed2J7e1SdDoXJNqtFW==