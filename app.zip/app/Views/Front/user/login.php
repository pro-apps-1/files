<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsySW48pitXrojyLOLzekF/YpcI8IveToTejQleDVMAwuOJZe+2rljjF5Vtlb/vpa0G6+NOG
aKtziTZkjGDty511QJV8gp11feefguUMpKQWQeVXYe0ZxO3HyoPCddo1C0P+RsWUdirjoG01ydFd
yukfbxNpDJzX3rVdr9EzJ/Z3SF9aJb/hplYOR80abt4kInc1OEI5vwQw+H/KBaoN+J2sjAe/Q49i
AykaMyzGyrzbPbgNHOy4pHowrpgylc9Xt5NPr43xX+QiAgcq7Q3re4ZJvB3VSU71ElLb90/xmRlz
KZg7PUINZvys03HAXsobkVcUgCNMlJTfJctGkxBrJfEfdWlB0MoZu7WAbS8N3uBCz56VZdx2Ub9h
wDijE/ouUw61ufuvxij+DcgWvMGwYhnRzpaz0BxNY+bU+4Wt83RnNA+4BhRKNYB4i730lUq6cJYh
T1p14fqLJpzBclMv7/dbhRt38gDdqSnqzoiQvBQ7sHMFU0TdHHF4L37sK6FVV5WNxK9XIGTDQHHR
Qz97t2YML/CSn+v3MlYegIR+iNf3bc5PCfVbJBZcu7z7calKr787H72kBQFk8hogKEesNRCYaaCB
PYk1Sko53rGQa/dsPgP+lI8UK72lqEXTL6fs2Qz8+2p2SmbN8/aNjlVwWNLkGSINV6QJDQ2a/a1D
IQgE4Nqheo8i4Mhhc+Bkb+CX8/9Ab4MhQL34hXZ2nCvVjgWYmyXNiO+hYVRh6OOblt75vyb2WVrQ
d6We5SZLyt390F0zRIXoH9vt7/J40pbkXItYEO5Nmza6Ec5VQiFHz+jH2wPOSxMAuRTukrhfEZ6g
6wK3Ipa5lYut13b/Le5ekLASz1W3xbvNTA5ODG+DKPEYtFSsyax9L5o7565ygX0VwvGu1Xmot/JV
uMpkL11jldB4gaWK8DdpGYsGJSicoqeIEkNDjvBOoTL81AgoYwWVyqOfOfhKOXhEW439tuWwIw4X
Y9ssLcIDvKARAIVQBu7ZlmVAchQQVgBobdjonc6TiGogAPAPA+am8HSdaRU7ZNukmuoNnB9EErij
qUYhNgSu292uB3wJIgz/jHg2oJtSlHRRhg2LiMHcFKgEaM1d3uI8bApxxGoYGAJN7QtDwRVTom7h
jbfZQp9Nx1Bz++oktrA9bE+q6IeVJVBWe2HXp8pvYu15mk/ksimSpVTdRl+6gLXafWkTRfCYl08+
8ozo4olHBaBm16DnpDr5HhZzjTBoyc2AMbahw0oP0V+iWHb5WMzKSgJLrc8nts3jzuVFHWnb59L2
zi8iS/sYfiQ6KHmd4YYDlLo1r96FEl3csQP7USnOtQ5+b5wSeHg8iXxP7AiDGk/vXzjCG3A/OvoX
6tatITc7Xk/yVreoN0m4rR+jF+S45pst2hQam8hAMxoX6YSHNvGXXvYJXSzEAu2gHp06Fwltmv3f
DJ0eX3I2hUZleTqFbmTNVyls/IlBB9hi7JgyO9kTYxzibYytzEYtuZc7KNnJIr964+3YwKDADWpL
3Xa/N1GHLbu2UYJHRuZevYEciQcZvZCuKBC6s8sA/23r97huaRoKvHZfRZ+sQimGqCJUCA+vH0cP
Ox10D2xkKSTm7pRMnZwSp7n74BUlcLrbGfUA316OueFC38a4GlhneOE5bvbkM9vV9HmTRdyxi5Yp
PnBAiMLxGRmvhBE9EmACTno+spFnQ4+p/yea4IPCCR5AtiakduLUyx1WyD232TJQZwTZP6u9ut/g
94c2XXnaCWTqFz5i5lWLLn3B27956ElD/Fwtd4xrT7t6z6VI9tS7q8fbOvA/t0lgbvwDHi+wWH3t
sFpsaPwWzSDNvIAIIPoUbBRETmZz9Ek5r5sw4jQfCthQIXm0kCcAb/fynZtLcX0SJsk7VWzCyavr
XBa0aGBzGjhIfDbB9IRFnpqn0jEyTLocEuh6OpEOIiAcmrQbKy7Hss7w8WaGOBhtxC0gJ/A2rjhF
N6Mg4uYblP7Ei6pn4fSZbCVWqdQ8sHCU3HC0mBSnXZCZ