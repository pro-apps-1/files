<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxTmYpHqxmyx0RCU5pF7ntvJdPc1yx6NmOMu7+AKg8e8YQlE5gY5PcifHgJKkbdwWymTilKu
ZWdTXWSaU/XCCz9ei+sRl9Zd6f7aZR8CoG+jLEhAZ7upoHoW7YlSrTsKsUA1nGSF5viuR4ces5PM
eurvk03sSpgpBIL9AS5aUloSC/gftr3fjPl4llrD1wLVGLOJ3xkD3/cdHIUQqX+UGZs14EJ4p+mP
XUOtdt2lGT1Ha1TvYCTBmOXygydc+AMkb0NQB25t6JBBuRV5iQSE4ED60pfh+KRpLSkPCC9Zewvf
3Zr1/nz8xdXybDFodJX8EC5Q4NMwOOyM5o9n4Fem5fMRxM1q7d4tZ4kLPZU78/zlNUYzG3Rmn1en
En7xg2NIHkdU11deg4CZccrDUqPt6F5jarucdmQUdsFVvA8Y8STOKSvvqqwLxAksXGcPtN/cdYWR
NR33slu8+jZUofVzW/+nL4tq0qJbBgShu3O0ZX7SvyPBnmHaJHbiuIUE0mhJHalxskWwyYghMI8z
OwWh4Mc0UUjQ8uior4Qji2hXpyhM3cNuwaQ5rzX6KP18F/VKqTV02ENkgN11s6sIZtEwrcApSzWJ
tVsVBpBNAA7di4gaSRdHOFRPeRbtjQmj4VzYMCZyMsd/OfGRjK00QpRPFYuYeeJLLbucKFBY4dr6
fburkXn/b5s0Tw2dbpzt8tSTLDt+29/gBBq4mE+V5kjs/juiSUe4haxqWbacCsK3ThvZ2Mx0jrG4
Upk9aBzjWlV2QUv5l6bLy/+xNBr9M3WsCcqnlflrMhz6RHmNHbNtzUHC01Cmujus0KzWlvfO8FYS
REg+ewThr/pyH/ivSElSn7fMWQt7H6YX7ds6JY7Nc7lFLhwK2P7UPIIbZw/LaXSoY4OI9pX+sQ4u
2KQcIMB9u/0/Om7XmtGszbQaHNlVcrwv4wSpTu+ICB3Qcf7+Sr0aT/YQEJG71fXkA1f9xRi/pATF
gm4P9D0P9cu/LqDwhHlPldisSUjdmvDkahaUcof2yc/Hay8lsAKT/F08xL8NhbDJB9egJpsKH0px
trHJBDX4PoEk4SlSMv12X/POOG0kyFG9lukrqTB9jPyePujuE641Qu/rhFuW1ufaP8ttqewyNa9e
tzNkkraxRehTtYPdOLgz1ZKYAQG5Pv2WLBA3tDtJGCLFWh7DOKnfckg1R3yFDopRxN/Vh3Drlmvn
Lq7gH5HfU/YN19aK4LWQiirArvAC1/jrX/O3tIxhJewp898c/qN0d8ddX6fABc/ThV4hefsQjxbL
eIvUnfpndmAD61zrCM3kXZceKtPMRDjWAZlR7NjN9am+jKzzczRVoS9VHkySBDlKkmEJJaI7cvpo
zCv177imcd0KB/NTKVsVevkdQeNO0nDYyya8HKnu8uUI33x/S8+jJ9zVl4QgCNlSPAfVWLPtDuUV
0gu+zze5+1rGmrBQvbiV2rmsgVHyyfQK91H4yGgIzuXXvV65AdBYg4P1CbWYa6bXHxCxbr65uzWX
8BK3xHGDQSXsROceOBVzV5bmAiXndS06OqpWFsSNi6Uz7GrsykMgCxV44vw1d94squOUvDKrVBpt
6W7Le2YWqqPeXeOEsWfFO5wTZ7XqqwuCypkv3Dkvvqi5LqFWhFea4Cxb2FHEwwkd9l2dy9S1FohI
jGUYYmNb1HZm97Ho/80Y2lilh9WZ8gdPXzZP+R9OjnPff/UyQIySLRLNecZ3EG7LAPWBIcVwlx1J
rUm/LccifQLAWe2uyJlRGt5brKLHzsTaKlyXd/ZeoMT7u1zROGsrhbEnZNXAOyOlNGMFSRd6Um0a
4D87t68nO/ndtfMwr7jwMnvcGvy395zcWe8zEs+Ep/+N1pSJbCynsHfHA6jFLs7RVJVlGCqOu26b
ZCEw9d9O1RDhLVwWur3/xuMQaTP+SU2Zx8rGq82ttwTELA/lBdKcTBOFetbyhgMCJ+YQaJ4CuBZM
KLzseIds81TqjDzoN28=