<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoh2VSp4dKRaaG7extLWqIz70qkkb2Uifv6u6rv6m0olISwXfhFgQ+WadmXQ25OBzi+GXpNk
0hNLRKDnCo8ggNGU96wkiVBCY2cTKLnuU4uUCFR3WqV55tRWho2xj1iJA0HMBWx7hZBI5Ye1+nVm
m1aeYMmF5TzC3H59knfSGqgb7T7ThE4KmmCBKXWNKJUK4XWcvVUJgMd70NcebYIzdstdPASOdJ/T
UCU67XSJ5lrtY703+vwd1v0aZqXSecoIdJdhscOEfIpv+5PatZdjxX50aw1VRAqrgSJ7VgZ2EgGH
M6TC/q3EsKpK+qx1yuO2sHM2o7A0kt6OZFoI8ewETJQ0lGjuBfvbGHW2jMQAX4carmws7HjTOJBN
uL+HjhZrn1x865hmbyUUzgfiSIGefKF5e+gp7rX6DQlxXgwhznWTBrN5eWFpcrpMG7XzPDx0xEwP
quexqPoFkGrlI81W3CyhcdpfVaIL6wP5Ma4KXbaL9W+U3ktuJK/pigDys79C19AsBBeOgxjPIUgl
VB7tJVJu2FUayRbQYMTbW3UHeWD0M6884vgWJCsk8UEsM3RklRolxrkTg7t/69apQlk7gd4hDfk1
NZY9ivdcHQdzTLicz2NSh9SEACFbTnzOjJyiGSHkVJF/gNusBK2GgdSfBwbxSH0Xkknvnrpgz2w+
CEeHt+MPHf54ezW4Ovb80fMi8RLhFifGPUehVKyvFqjaaeqOjd41hqDFAMs/X+9koYZDzL8R5cBV
DkB6v2oNEFLd3/XavGId9EKQKdAN3jem7BLMi5+aA8seZXXN3f/TTp9o/yFQ6J22ZZb4y89Pxcq2
D7nvoxlSbqdd8l+b6fvLhZJIhAYFVE0JNX/SP7KXfQ19XLJdvsiNa6i+0ZK4GsMrziL/yH9aFNZX
Sh6ei8MAksiNvHteZdXgQfupDWCDgU96L81R523yEc5Cez1qZXN7x6qOFLhlXwF51cXDnQuPv8io
rEdq2+MY4B1LPTU1ZB7658iUzxQUvFisxwZRley7/cWCsolPyV/nvj3A2a+ImEe1XBOGSbRGPKTD
NtR2WIW1jo+nlzrXnASkWeTu/1S6OcTkt6umm8TIy9+4PvtkOvQEUYocGq48qu+o/P1qdfcbDf9H
JaK9/JiMIaPhay1ewGOCZgc9rNF0nVBcLILx7ibG0xpAfwYUzbdzWaKWjI0uynNFYf9tMWbobFHN
ycjtYJNQ0/YRCebcmgCmcTaP1MTezx11pBnF57nToUvhEwtzalUtdkon1O6wcII0MNdOtuJHqap/
kck19RxsYsnQ6HCUB9lZl4FPeSclnl7hzCLN+Rhhq9ZJR6eA+ILAm0BRtmWGW0QRnuxj1G7v6/Uj
m1yRG3NS804itFsoPuleIVVHTvtxr1I0fguPDq+2BxlBGprZRkYYUUi+D00CupAAu7r370er0ju3
yf2hLJaaPvVF4atFp62LT669YNnVGLm2it0gUt4YEYc61ckaWfOnV8SvNf7d0Wc+U9KqAVfj0tK5
GkuhtZaBtR7MbAQYFfRgcqlO4kGgbLB6cepHq3yUHSnuQoJMuqOo3vIoDfFvnib39TPg+mE46efc
HDfc4jfVyhpt8ll19J72mNtCCNXKHTqb/SYq5hakS0hrnfClm1IvquN60UjCiJHCtxsvqbVmT2ll
Gufm0mM/1NY2b3VU5iZsDDOmypq38bKd5ZAJAJ5455u0nVYrm+N9HG8q6sHB3c+8X4opdvdJpPtS
X40Xa81nTQI205QOVJzsWFs0dWL9UcRxKyyqYVqu+kkiZpcDKrSE0CedjWqSOP21l2fTU99ppwGH
/KhisoDAz9JHzeqPBZ72Lh6BuMpSfaPAJuW4Yg/OIekBxKik+xixvCx/EK9g1DfMNefVf3+o6vp8
30WYKhfdVhOt83RKfqt+kyAsvwYmFoypNPr3oTiwXieu6nbX3TCgXhhJKvD1ts638Wr/zrahRu4g
wfKRT32afMfmUhe=