<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtzSGmemyxSjpP/MAJim0h5ByfMFBit76O2u/R9FYPNwZaVcojGsOOTfpP5GTtZf8ucjcDSj
xm7HeWXnNlNgDfY6zYourVKes4kEPNnetYBKlfByjMI7xatdg2QJkFMZju6dc4kA+oznfUTha625
uVbV6JQkTHIUKozEQGnAbR7r2f+E6eP2hqV8Lj/i71crelj6uaDO4QzCV2S2pT5rtE8bjdyMUj6Q
YWTBDAVpLOZ33+2UdF7YKIBdwtXL7MYgT9qSIdpduDuQEICruOA6s+HRjObkLk4Lvk7RnxJOWC4j
/xfFBJB64301CZhw4J85JMhOa0HvFKBU0pUjOTPv6nNupaw6QDygQNkv7zB8TYpZpOy1Jwh2ndzA
Ufuw8tVqMdVIy1utDoLhE9EWolgHa6sI9JySGiZiXUKYHp2z/Q/mYbKO+qdLyn9G907DOPLCKA69
ITzQ6FwngDAtai+LqbuK0ndg1WYEM/u9SbvY37kiYjpEyvLm7DaaALzyOtasCMgYooDzOY/jzGdG
lMDbW+OVHil5uTkbDIhM8BqLmzXO8/v1SE1kDFwPIQEHzt+X0jpResMHwIxuUCpQhEvBFey6LHS3
x+z8rf/9N7FeURxzuY9mj+pHS1kjufMh7GxqABUtWEfnlIbm8o1U7N9y2AOnlURritB6ED09C/0U
5KC2BTJmWqSnV5BV/XQFj4lIYh0fppv7ZhCR8l74eLm7MceP9nzbv6VsxAPiRplcYp+6XjIdNhmx
tCsbQx3Nx6SVQIrQadwZ/k+pw01yNEADLT5l8G+LTCkr4J+aApqA1vkZzJ2UL31elo7ga9AdMaDm
jKE3adXtZlsXBUigHZU5V2IhMwhf48z0AdCPxWcNiWYyIH8fk5K1E40cRHO+YE5wLgf06Yh8nvdG
l7aBSN46QR0ocZWHFXyLjohBpmM05JXwArQy5eIXfRvVT7yA799g2TmV4ObpKUg1/PCj8FhWrKei
hwaLZ+2lBW1wXpBFPJYR1u7/AV+n5ItbLAD+UdKbwDrPryjiuo7clpexqy0gfre25f6kMvPu6Hu3
GtCSBPK55VW1s8LXXewmfs7GLI4rD64A4QJzfcrZ95Hc/lIABoQ2iqHoeROLJuggDc3bOZ7P9rQT
+VxttuMJC6JfeXpVYkuHjHpaELvSKJFEITqU6BMejsKVRMk2e/q2klyaZ4AiaF5+hHeEIrvGLg5b
BYlOCgHVGGpSHZcMBTKCV+0ALKqEtejAVCR9H6BsdU3G3q+49PeevS96pFeRDV5g8RT0WiMwEUKz
sNfdQBO8h2OYh0IbtlG0J6Qx//S/gCIT7FdPecvf0vaeRxghToUz2zhr4vaELIuf/+9zleTSGyYr
RPctAAM3plF82PoEnG7FXoFzeEKO4Ddg1qic/JiCpPy8bLmdSy1TMxkbUpsl0UcGUcTPZP7IcP08
AnDjGkRZsAaNN2OUwMb+/18+bcG19zTHto3yNeMNzTh7Ijroredj3EJbzG7ckCjS6D16QIku7oaD
KdtbrUjkHKV789D7wp80V4iU907XhEA9P9Kzp5F65XSmpobpJ5KpHt6eIgHG9EUP6aUCHHAIWU/j
zkbI4fTFisGTQAjIhCRvwJHEFYIOfzNfnQZYjNomn1Z19BuVQZjruPXYaHfYvRXkCfGtXxjg3ncS
RVpmN60Shifw+UtWr4v8A4fgZplSorkAtnEwQaiOuW6EU7GFE8rnoN6UsqVlrHczhWxLihRJDCpp
d1qFGnPmtWw9v/h+MI8MmEYctXV0HOceUF8Xct88H3uXRcHlfZPVwlrmNwYkwweB9mCcC84168TA
PIbflkPCLrVSoQL/hauoyotrH1pdqHCqh2YcAL2AA8Vqke4TtaWwEgrnWE0vJwfMToi3gHOS/cUZ
t7VqYNg2WIJ9m5GRi495G4Jt5N8dXaH2C5V21SB0ixTWTqVGAQ8/5nKece1iDTbcb3le3DHdWQM4
BOhegWq3UReTO5zAAQoWNhRH