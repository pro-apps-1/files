<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyktfJfgBXuzStGm6JKbVWeFG32QIlefEQEuoNanescNScQXv8deQZQISynnKUwbr0jLq05e
pBlRMxgLrrjNp+6omaDBFq7+17h8s3cMvuob4X7zH/SxffAI88NLAhpsVO7mfqG3jcWqtIkSwOtH
o3A2a/B+H040c3TYSMa02eAXvjnCEFqYWJ3j8FUdFz5Rjtq91d+Opmtz6960EVnX13Vx9SsVQSjl
4iwYctpODG3LUgPgHvgwaDnpgJ2Qu6YpBe0OfBZeLxUYiG0Ruwqfsmxza+rewqq3S2X5YrwYlXZ+
u1iK/sASA/pujuiO80WGrRyTzO3wdBCEGY8UD73DQxjrX2BktcT3EJLPVQVLpANXZRDIvRnJVKdL
p7vjESAub28kmBRHdwV89QVJFoYGBaHUdrDSVyt0eirZAbvap+z0l6oee9g1TMU+i+bHdD1AIokv
+pss9JIZ6aiasP7WTh2i14elq+7EO0zCDLSd5wHFH+7s0724VolviRx07/jtPxsaoPPG8s0F9Tmj
4D+bx2moQG7BEf6Gvy9NBfzkneSchfN0iVIG7Qt4XOyLCzntE36XnISJpU2MvkJnPtQSbkr34GdU
zp3o+9S9jtVQToXcJkD0PRElXsM0NxV56H/f1bHIIdd/+jYNEjMLZ3+ByxWsa4lhgHn6RKhiVXjR
Tp8HZ2why8cVa7tKobGqGzbuqfzAPdtjTEyLBA/JiKtfFzddXxbwcpqLMA1QN/xTUpqnaTODbHYr
jtqUa/mNUxLnHTyY7tmaBJH5897r+xpu/LRgasFQWgsYJ2gdcGBVuXfwLATQRvqvELYPp7LNxXXP
1GEa+vumY9TTgwjZ9xupLKQjd4aUdiD0B++66DgC5fkQhAwUzzlu3yIgirHcDWprCi9WWZHMllIh
k+5dn1sMsswKX2mxXcw9Jl/3MSeFJEE2P0z88TxwO7MKsFHewDhJYkiYfwGg/BMU5SVVvRcVq+Ym
ONqE7F/TJ1CDaKCU9ovMZ5UyDrxm76jLxGqZyoYHWK8NKp57NtZI6Fa2dP96KMJujcjD0BMopljt
qfnvqbgvbWIheGWLLDtX+mjkSmAik6crI1+liYJKDodbJNDHnnios3KRAD9nnpfI1nCdDrIfsjzz
b0RKAIFWtPJg5jTkcNLjTxcKTD7lEtKloFQD/RJ5AZEbOoa2YbHdpumdavvikbj4uz04ypR141Nu
zUqGeN9jJRtmx0FGomFZ253aRUHmhjJh4W2II+68DZfJkg4Ep+W7Gr31YMYC+an1PVWk9vapYXUI
3KJzAq8XKLsDy3/6RJgWQrarazNSQG3YZY4qaWg4m6LM0KYMt6X8+0AzLhjA2+MOpUPVOA6U5qZt
oAEXv34sq8NCDR5CpRBapc9IPCtyH+ZjMRtdcJ77Aj4ix1yVaXjSlIKqV57jgBZYIEa2+cdCY1mv
jB/6hphSXCi4oZjVoF4oKGEUeSAc/RMuYL+QfbwwrJR4FdUToEw3XRX3dOCqb/M2WMkI33VQzRUn
7Ft7Htm7sWGaI7OpKKS7vuTE1Lab2ND6uEHQHsD07DAdsHg1RKnOjeyOwi/757Raynorcn5rliB0
hL3gVHhpomcsXhm27vKCRPUfpK0lbHviojCh3B3PjKJRYBkeJHt88MoDI5q3wGp8wtlWT06tnwIf
s+7Yc2tnpkgZdaxVXBoIouACYruq88nAvxS+fK4V7tjETekfJPMxVsIxdfGgcNJcrYtDPxHKrIGp
zB1Ghldmp4uu7pq97pBkaQsE48Qngn1FaMB4bXX/sdjuiUCxPns9ExU/x3X+gTAHu3xC5bMSaZ/Q
K/Qjjqda9/5nt4XpBoYz6jTcNZBSVTrx67IwmMCEx0kGZotbHRBMs96mDaeB7DNAbQQJLMPWLHlG
lsgskC/djYMYZHjYfdPYoI1la8rSWS6mxpAFueIjf2aoBZUskGfC8uXzS8HBuejbj2iDw6NG5vXj
nXTX5/IcPRYWV1yw