<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxMgg3Kf9H4wD6az5b4+KTleolynbOgGUVc46O9TEvgwhUTOIsSetXXSvkL6jVlyUGGLTjv8
5R/9LcoHQRjB3fND+N4Y6OBs4gJGK51YrtGtCM1qOTa6zqHW/PFWRMRYXiT6w2CHEmVr3+FjO2N8
T7bMWnJqMK3Hcik21KwdHWrYZ+eASnzK0EpO5PH9Txy5xqbYSXTPlL7bl/Fe2f4be3EpOBwD5XdB
I+6AV2OiY5tP7goFteqQxfZfkq16/LkGLiN4GH+MgeT25D+EjpKkAQLjijKePhZoXRJ1JRy4Vwlk
3lZkAfJ1anjhEYQ4UuVDB5RWtx5JshAwHnvA7UJyqFja65mGJIiPepywi9cbYdIVFX9ptN4jWpVH
bGq2qyNZPeogfnVpcbugZNNScFKqeeoKLq/2XncWHSgDmqUaNJDIBQ/gQXOJGkB5vx4KFU4ai+AA
7vK/qSLih8uBdrrK5APmrb8r5f8NBRuCQ43+uiGqzKC1YjWM/Wd9YgbyQWLYHF1HkU9LcamiQU71
fZCr9X4ITXuO2sxQEYxN6wz+ngHschFzkQbyyO/8j82ARcs0C1hRBh+uLJNf0wjyDgC3nPFvHYJf
p4Yi7F7upNeJdyE8GJkNSDzkvvK7O5qzoGGV6vktkLuFlMX6/tZLiNeEZcp04rpknOaFo/18UJr3
4pPN/44gHzGYWgCUM/v0RFOzK5Chfgw6avLsqgS2QwuhU2DA3Oh+U0pgWQbLndYtRU9/E2tp2YYt
qm4zYojuda3jQ3rdIPLhx9DuZoZVSDijvV1ykfjyj0aalvh2e4WhwjvSThPPN9qrf3xucrRoM7eq
qT2eXONUhF0AlVKbf9dDo33PodOXRgf2NjR4e/yECOrs+KO/GKREie/c/iXTXvI6Kip0nbLXL5Qr
8CpCz0OFyZw++y8iZwysxfYubpeVsL9mm9F7I3zS28JIlSuH5/3EhEtNauhXfaoerNbxg8uQftMn
fy0QlW9hCWB//wYb63N0Vg194qJ9yFiUD1l6X+dUFzKlJCFWvZBssCSYcx35Hp65z8iC8j3KiUS+
JFqK6RKkJqRsaclCnf2tbi8ZddepUx3v54lEvXC567pUYvhZqV74loFnctdgocKEGgwNvZhlGTFi
zlC//9t77WAfcYZUGQdiY54OgfoZgEwPp7n05gdX6MlDW5vUhrVXdRKf4dYDTeh97hapX3EnLAPt
x513nCeNi+Clqp0EadtGRLI+TTSW1xCgbBsj/u4CkWQbvRnc1t/Afnhjl+H4H8rZZgSdUJxDU8uq
4aiHmQzNzUIeIpMa8+q+2WL5SgBu7D/OxLaGGyNNamdy6K/XBT9ic/Efmf78XCHtt2hH2uLb/pus
O8+fAdpzwimvxWaR0dNLq/kzu+LT+WDJGwt1Hh/eq6nyutfiIlVc/Sm7H4WOMYajNak5mH6uElaM
Zenhwac46MydYrD6UqNxR4QxUlsJ4T2HwxVPlyrLd2WjRicByuSLGU8ss4usUE9H0SvSDVH/n9rP
hD6oYom28HSxG7B/XiyhCOUwp+yUMILgp/PLmazlCVwtA7XgPxLsaA2BgtfN1MekHAfZX+ehq/8p
PDiXitF08QqUKdXOTcz7d2VFwSgDzpCituoStAyEXjIlVbgX2H+17x86VhVpwbiCs2lGuhteffzO
yYqcaTl5FZh1cIfJfFO0HveK1VMSH/qvXeOpH3dgfD9/T2QmJxwU9NVQJLATsYdC0VIF0XogL9mW
J5Yerz8TjxI+N0+7ALmK8RO2x4YIcVxvTCpv9n8QQYToz5Or5KF8AFzhUcvzogAzpLVIrJT/P2bF
nSyGlD4NR9RUv3scySn5AWAu+yin3Uo/cxqjCcYBBXo97sbOFXTYVAhLh7nJU80f+GsqlIj80ZYs
0La3imfJavyWBwB+mVTPkBcXfTEGjfrj4Q7wpIIRdWjrfd0dp7/+uHnpkcULd4W4XAmJqEqvqKg0
iDPuxUW=