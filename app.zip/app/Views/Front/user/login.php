<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz00pfU4tZBOKSDRj2qC+YUF5G130K1u9uAu2r3Xxs8/DCGKnyrwyYdRQ3UrNOv+2phIN/yd
0DvKgpYbzEZu4s10b5IAEZMstYWwZe8DkoRFBaa59PaXCTS/y3PvBlHToSf6cpKU6aB19Jz6T140
hJcVeojXmQljE7M1RebSat2gJ3YP+9BWyDtpBxMnc3xsf4aFEcaXL3BcjA/awUfiBXDYbnmHHd9n
hNFXbyvnqnf7GqNkfL/ZE1nuC05OIpy3lRy3UUReDWkAy0QnKAh9nAMwMGDY/jOpILW+zq9fLvmh
/tep/pjrqUqqnMEwqO6z1G6/CdS+oiD9O1iZDDvszBpxnggmi7vsaJRKux2g1o+J/vT5gANZuuzy
M6RO9NGSPubrOuxTkI5Qe7u71wQdJpS62WequV01T0wpzvihT+lH0+ukBiJYPwuiBrh5iiZHO6c5
Ut/tfT5LYpG9W98aKWXihsBZikk+bPDYDT8M0F51RxLH30MBv6M1dFADBPDSQrITrCO1C5xq3kPy
FjOKqx3l9WMv0vUrAUYDa9MaCWDe02mi8eeT+IOjHpk5/3zbtC2zFnDksTEa0FPEnXUDTgzECXOz
SdGoJ8qA6Uf+JHIaAOxbhF9pk21v58byZvew1ZLy5Xh/RcTiS6eKZwKepAfbYQUnS6Vyk4mhsCOz
5NkwUp8DB1HC/Hi8WP1TlNkH+N4lvmm0SF7ztQltAy3rwYJ1TZZdS0bE2HLaOHHlM6ew1NmAEk6O
lLCqZIsqrEG/OD63OgX/Wz+gxXg5w93rU7/Cs4S0rcgfxG+Zz+vf9cobP4CGGaq9FksT2tuPqX3A
z5RSQE3Ak3307qA2zKQck1hxPNxz6HG0ioTqauYbMWteo9hTBVd1x2BWZryJ31GtSeMNfao3ador
DpY3xCEIWQE9cOeqlNAux1zcCO802GK19TWfv8SiL7Kjb4fYnUiP1BiknHCO+Gqr3mhhQYyrpIXo
P4sEQFy7a9NB+J0MtY+z9ICjmSGBVMkcyckKcnat+8q9A0+H1iNKKoIofMMSew5VtCfAtuNDeKkV
RAhx7JEvgkrcZv33Ume36HbNqCmKzgBb842MaJXRWW0uA5Cm4iJwZzihokdiqlIpsPFJ1bap0NQm
FLKKZIgl8ghkcgIDfI8In7lAugnS1MV2c6lymZquSiI/CT5V02DU8YJxRo2DMviGZTCiaj0eGkrE
saTHJtO46fu/TN4uCU5FYT/a0B+ol17aRBsrf52Gx8QEgf5EwAf5VQQWtgkq2soHaFr8YjBL2DB+
7SPc1pq33+Sr968d67ynHmRx4MxEFqL80qh+PWt16zHA0RsAh4BzPG/L/eGjCOZgqcjMlIxiHcRM
dxOTwu7fUzhuWVVYH9f8pajkXX6qqLMHKauh4uD4T1m42D/veb7Hw+a4GUut8rSXu11jkgvHW9B9
yLnXtyriEPz9dMPQjxqG3GDiPeZtU2s5yXSuvXFHXRP6I7MYwniZR+10mkXpaKBxyvbxMUbVBlMM
ZQuSuauvX+5fNwFEkDHDK7iWwijfhBkvkE9JcMQ8/UnxKA/zVpASDCgglXsIdIAZvO5JQLpK+0M5
3gh8CwBVjKvB5JaTvg+yvhvuX9lxZSoUM4g0eTsk+rc/vfqbVsJ/GzvLV8Z59V6c1gnNb9IHMMze
B5aItdGGdqxR/mZ4ZOMNJ3OAKQKrfLUNi/x9xXgrl9sv/k63knxEGibuQ0ZajokdQSA4Cb7HxMiG
p2dy2Kiq2jgmLGBq2puByeFsi6up/OygfyJA2xKIlXhEOkkFEke/Khc8AuiS2k/z546eEoESSlnR
U7w9FsQCe2UfIRHm+SG2U0wlWxeisaMVIOFmFTI/v3YzzOYJ6/LSoSlnjg1HbkeL4Jc00ivYj9Og
grdcGvd57nU4kfrAqTB/Dp5LBzMdglZg1cw7/fqQKUGm0jYirEXIdjy4NiAEsmeNrnVEsSIIcAH0
gTnf7RG=