<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxYArVnqHIxp0Kb0trbRXQwIe/jh0WuPSRAuWorLWUipI2y7F+VpcuWZUeMGEW4EiPmJRXux
5sjcaLo455SQy8tdjmP17FyQRFcFtQcmAfFC/Fwk5tBcOMzajkRzHLnWfx3ecIOFMY483vw6dUf3
2fjSt3tDnP8wytekrFYH/LCNt4MN/n0+1nXjEIYuf5dQMGtWisqEcXA90IHKosHxg/2wYpvya63i
vwUUrES86Zxmjb8lzsfq53Li1iwUPieD3DXDBFA8EKV1kGqKsfbxMrk61MbZ2HJrbprRPXd7h1xt
ywLS/oce1oDTrCKhrk6zk4I9FcqxYgltdTH5+HgPdp86/w+DwPHcM3ZxsMC77o/i7FPmtYIj5+G5
kp2Ju6l0MAataModuk5PNdyUGOFqLC83X/eE2s3UkSP2BAm7nvHtr8D9+yTzYYigf6XJeE1hx4U8
j41l2+oWB8hzHqqS1JJxYFDwVUkNTGxc37pimgKz/im+/EB4hMAuM/DQ0sMS9QsCeKvHtwrZlI0f
cjJSpmml6u9cQf4S92Kdk77L2NVu8XFLGGv++q53D9kZ873yYKyAaAhP/kbHg8Jz4/7cTFl3YAxq
iC71CNfjJ2duzEjN/4au5gH2BKSZ7iuDjNrMZFYFB6wU9llKMOg1jTM8ZTBbWF7mHe94TcDGVw6o
h1Gh4Q+panDuD4easHTI/VMG/foYU2c4lGusyRguhA4+jGhmp/upWh7pXeIGZPpYUoIOtWetcXDY
XZLRN9msyrwz1n+eRPhXZyXqQCExeqfqQ95bnbcgzEMQhNMKGKiG9O2LRHytsOfgqvDMue6k2ZVz
TThR5VKt8p5jDCIDjVFQjpY88vAEnZbWjIV3hpz90FGeh83DAlu05kGUG7/1LpwkjeGSttrFJdwI
44cziqaIDDZYLWrTprCX+GNsLOOAxDFqpisPb4Vi/z9DpHQzwr4z+6YDolRHqomE9fXxLGCX5F1R
8spNvA3T6kuBjaWR4zd8mktV3TL7pp6IByWWC54R0XGn5dkmEv21jQPIar7U29y8XgG40DvBFt6R
+qavEqteu6A87hn3qynKdwU7EQXeOxm34LJnNxVRiVyhtnIt4W6xc9FyH4OzSJeSvNir6rr0EcHK
E1phX/DH3sm0aMjzhx2X1chTaxDB0VOnMbcZ+8OLhqGAuxlHYG5EULfmZFtgLE2SHw2iaTcgCXim
4lidlHdjhtybAVtHQEG2IvXv1VmTSXQ8o0cYxuBUm2D1eNkuWreVGuZjwxbzxLKgEcQLsvE7KI0q
zx/YZ+qMzWCLZk8oojkxgaqnciKH4CoV4trP9wuIAy+LHWcfp9mNiQH4jbKRShAexUBs4C2SllyB
GVgLNShCx59ePsLWnv0bOlVtW8rM9MIxwbsw8oBcGQccwIjJma5dtCjQR0OzLUTbqvoQtCKt9UV8
6ADPrAEbM+Ampj78sAO0x9545gakZmoYvw87p10MHBH29odBohP+QF9AzOw5EjE6r2kygUEI170a
qZ1URxHgLzKdBiNmLp532TKSOtBc1vYtxU+O/G2sgB3ObVWIcOV17Ij3by9yzPVPTqqaLJzi1g21
/LVW6lDB5ivSAg+WYJgGY17TsBeR3MrzySiVCj9kQelQzvAvkRZq7+oVrcj/rIMr/Vex61sWUCdR
gkne4DoDxabzO7VaAdxTG9tX6iaFtBRSDlLaD7qopsk368txUdRvN9osgm/1InnaytViffu43uJm
+aDtsqIQSPlbKISiHs9HlZx+0qgGVDiZQUfYelvEQxrTiuAT3dTBTuu6K/lbbgxqZDaoZ2rWm5pS
AgBuL9BeWyKFEq98PTvt/2I/wXfM/OJ+t7fGFG6RE1uRqt4cw1zoeQ6nkYCVA6w7SQzal/HSyLoc
qz1jXecpuYo41pQZfpyhyfB7CY1xQsvTYpDzvLsXtWfLSPTYkbKZe0y4DClvHq/CWRR3pLdeXmfa
6qPExlELU3wzSduizG==