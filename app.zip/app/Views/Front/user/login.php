<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrHN7GWK3kOluPI8Azwsh8+sO0n6K+dckPcuUSY4fkVRp/ZrmbSzpOMwk51YdFCO/w4TMT9u
KSN6avDb96gxkP1XlhN477cN8zlp/GkQkZM02hO/SLFFpZcjPifNNDunMX64VEqcrtApdrGaSCiT
Z8qooUQJNTpzXfZ/xchZ+wPHwBAs7CCAS+bZ8BA8ctF3vmJVjmPVjC+9+ZRRFmD+QAdSG/cNDewe
JJEDRjh64/FUi0hzZKnq3GY5DOjER3CuMY8Ut4A2h9bI+Gfx+6/Lx3YILd5lmxum8PKZZ50ok5i8
a3eS/pkVKwGlrjqQsfAo3k/f3txw5fMcx+zao6Iv1oltR5XtyhS6MBKvJN3OTXz+LF+gYUjDIdN+
6Sp966LwUlS5IpLbigd9dqg9JGW+nLO4L0PItD01VsEX4IcwZRi/1TDtBLiGfGQH1CIr51X5iZsu
CEiQbeyKUrPpRlF2SAsilBUavx5yS1mOYiluwIApTlrD35KN4ztgbOr/SurWs4Hv3qi8x8urLYpj
joq4QjElOk2LvwSLste2bJI1ZyzcVQ3OFMRiOlU0Q/b/K5WzuhPmEkLzC2Te3Omho6R8g32QuL4a
TCUNaQIBHAK+IT5u72XpsCRJD+6k/vs83zg5jJVZvXnHWyN4mazoLc7vwii5V1qI2fvbFnRAds2R
nVf2Vb+0CNrGtVs+gi52GfooRkG/WKo+GHZCSvkHpDtPNXFocOpaxYO75Rzgc4R5U3hCHJjnem5K
d2W17vYu38VotmLJpIkb40OxCvbNMYX3YmXmOQNC7S+yoV61nasDq9SQPr4pUl6b7gadNIYxa72P
IlsuBuhBB4q6/z+4E9NfCLn70VIyAsWzwHWw6XhDm9G5ayR6Rr6n4fbq3w6yaw5ltveqsjI6k+JS
uvjplVNbFfXQmpwwkiPcUZ6yblrLlGOc0ySwh1QvvoyUWkPi5RROXKF1cNDr3WgP0PLEdyXzofyQ
ZTUd7uAa6M757G6WdQvX/N0e97SYnQUcGd09pxisuVKJvqQ1yAg4RznYes7oQqkGHT4RGq9XeHx4
/X+9mmpWpwP8csRUhkS1/reupWEkNfiVNNFIzbtI11tlF/C8q1BP0XLFpFEX8p2FumR+D5E0H16/
yyLZeY+oGFSdshX35DZxpk7bfRaSTDv7lNhEjuPuyqmiknZJx5a8mTRHxsyzXFgs4tifnA9qXcxt
9ErM6qF0fnmGRJvZezHxTibQAe22VZu5x/wrX/OxypGILpMW0W96Gd0S+TXrO0PITJZz/29CN2Pv
rt0ksfPp6Vn2GgzR/iMvsDZy5SuQRBENJQybwu6g1s1AJlRIqdzbNyirk7O/+qQp63/JY4YZuWQB
Kbj3JHgazLSpBkHmgvLZYMqN6xOaBI+D+TJEteTspW8e2pvHI/ToXkWZHbEylkE6LeiZZAA1bln5
Fo09yEd303Yyzp8vqKoBhZ1a4YSH7xQzKA7HqAWZi7rbNazDvCiZHy/odTPkumTsP09zIOuHjaxg
RuE2X5zXZR7NQtr6GURLGG5DcsiIONtBaRWdZ1Z6IdAtY0qK2XRMv/sFYmjxXMBLXBcRVXkMvKEL
XYeY4T9kDs/AsvhZGRPLWafeOOGc0nufFoedi0Stc8Md1N6tqOfQOYEVGqaH5vvnkuzZDo4B1EJO
NUMQX1vp2NYQdT03j51afGRS9shRn200vt25GGdotnLg9wh1gCUYbd1gitK/CYC4Fck1o/hI/YUp
wP9nmZBtCv6/gQA3KQCEjHyxOIoR3Nqen707R2/3WH21/UhoWb0dZzth5p7qthSEYrpS9aTKRDIA
IcwaGsxE47ssEioiqWbdBk6LDK818wfSJsNw6emOv3X9qFOEu753oVwLCW8bMfHgxjeusYn0DEn+
04vj2P0stn0Jhet8aKIRVSAArrzW7Rcx0ux5pyl47mlM7s0r6muRrk1RqTdwPV0b9t3CRhtZXsy0
wsHdKrxgcRc1M5OggPXdAl0=