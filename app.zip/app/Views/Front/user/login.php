<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrpMcqmMYM1ZxnKERyp6zpbhTsc5T+0EnDeSx5W4Q40JM41aRqLm2uKAOLv6SSURCVgkx7xl
/FWV35aLA8/nupW/amKezs4b4JsgdhLeOrCTWw3mFSoJ7ufxDFqJCEukTgS/YV5pnDreCiPP2afP
uqdK18NBileAlmKCGDLHPbBYxmVf72aubk/0FgOefEiFpzWZQ4D2woGL88UZVWsYi77YLbIA/VAq
Gi7wW2hvfpwBy7aFg2F5KJSOWyD01a9Hx7V3S9yV61l89llOWL6IwKXuL1ehe6F29AXdNbi5KTCP
mZqDUKi6AXe8gh/KYnHgNRQ7+25Kxp8B2PvRikAldo62NoaDzrqCgbWBGMGM8SajXxrmM8ja8isS
OgHXihvox8Bt+0HIVoVQtMLM2BgwBlgWz6Lubm9Ont2kITJrPrErOiQROtD3hOCb7CeFyuhU7Pej
p8N9WWwr2YwmD/+QfGSlfEEDYpB05xjhI9lb6+CxeF5e4juSHfGe1R7ZDiQ1OGJQ5SgXnQFptEae
JVBuLsW8BSql73LwFhgjGhMyYtawB+JkRKPDZ7c//vOPW8atuVDKjadFT4tqFIfMLM2q+/6yjv3g
4mkmTILpBRaEy2/iGlO9QjHmBmn4cLCrsU5u3Db75i8BTwooEYGDXO5C7hIIom8QBYWJJgdelDuO
luWxATymWcFRU7aFNSsUj8p67ZxFdt9qANyH1MgJZCYqHbwE0yxI21Eav80vCeDPZ/n+e6uerCd/
DbmbPW4RTCzmtbRYBqEngGwxUpJ34mMxmvusKQ1JjhMX5rw9igW4IqNwDuIPHjnc5Vh10irNkmoW
1jbmQrGBvdrG73FInL0n+dslfKjCKjzeZxi2jXoDp2k4amF5vI8U6Psa0/C6xT5MeJz9UH7u666U
ACkzinlTeqIfSVRT/SFBvylsISmdRBAP4lti+L8Tz1T1yZbAZ0FpQpt2KoMA0jTgnYM5eS6ENVOk
j6Nj6sxGnKQkjbyI6aI11bRzOk+Vy/6iX0+b+tcDfiPJ54kPOiyPSIUI+Ph2yEZq92GwlYXsNijS
J+w4Hev4pUXfLYMpyCOKlLZ5pY0DwEPm+vEKmV8fUwTzP0QG8pW1STt3tplyc80rBV6LhNPixEdH
sm9DtqQy7qztdksBt8MQvqCKdm9D4ybpvJiW97OB1Gog/G85PnMWQ3lGK3gnpuF9/acr3I+s7sti
SOzxRdpZzc5lSFQC849aBT249fZVCTF4Kz+RGzVgVr9Gi0yhsQWDNHyrsaoEr+6uDgA0SHd4SYha
K1YZo2k2I4JPwcFpnXE57A0HWC581i8DPX3tUEIne8BlDW+E6GhKs3ZMOUlr6Li3EDP3/w0scfry
A2Ho1REjH3z0s80bB3UNzJJRdf+n5zqODXqVA4TyvEmu0iZq+aCSpf5JiF1m1PExvD8vcVFQ9EJY
uKWzxZaW3inZziL7e/z+iXWpX+bXsG41W4WX+J5VozpyCI2+5TYEFofcsEm3jgsrb4ZRK98trsDB
cWZZxekEu6w8h4Y9ynVbLdeOxKudMKTNhYgyciM1lVH/02KFwZK+OMplZGUNlEin37xq9HG9LYU3
Srie7BaW6cr+CTO7r4OKgUN8cRJZPnEBn3eNC10ADx7AlIqlhDiOYDJ5VRbxKVruHQ7H4Pk2ngTG
eUugYl/VSUYHzLVoaKnipIuptIWuGGhQ2byeJclS1jyjHtfhjr7xKY8oG71IFPFzLgN4bVCcT1G5
TfBouRGcl5FZjvH5uIqdKc8qftzURHCIxzpKTjQDq0IH78L5LN6sPmygbauulAcXG8XooctLiBHV
7GMT/T1t9/hoyc2mxL+NMo01cbHvSmgwfpzC8TySeKVdG4v26v2isZuSNfgZaP5GJFk4c3xaNHGF
XDunnDPd7JMl0fOG0S0taaaAbRyntwMCIZJ0w1JLQ7kLU2pFOFedBi+1Z2m0sUznEvLb9lk3kPCz
VGScE6qKWBSufbKU+CgeNsN53G==