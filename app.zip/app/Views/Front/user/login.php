<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuK5xM1RsDLN8iPuGnfNuVt6pe6TzYjNdwMuOlopVSsF2bV4dqcDQZ2GhF2fTBKO5TAx8jHd
7fh29g3ZQJ7J1X2w3/YDE/K0kVH2dsespnBDPVprToR1biMh1wh2FsCI+zx+lZedtQaIO8akCOb8
+GBYlghbEj2S45GVhHePttasGqCg8hPYFRIdZekOoMMTRstU8arxzHIKIWpxOLyVwt2/yIkClPrd
y7/9QquCVwmOsTl2RtnjQxAh7Ac0ujkviArcTXGh5tW87FW/i0pF3kQEovXgLwMsiDo6iwpCkFnX
dLXgEvK0hPk25y9ZUanMvP3tJ88Vs8d1Y+q3J2TnrKH9Ye0K2mu2DN/pbQt2I21l9u3YVL9euAKb
1ocBciEySm73aqjemgL6Y4IOvSVk03hryuJUEAbkcUrgMRWghwn8NGCftAKj5Fic/xa/YxAU79UF
0i9GzC27HphKQeWfptT/NDGuTyU0Q5Py9HoLL0QQtivCAU2ibc4urIf5Xe7qXaEO+igyWqCrFq7l
Mujf+37FTIae17d3oF8Y6n8hS/jdv/4s0DWatlpTZ0Z1WeVJAwQvO73tu/R23Dohd2EjcxIahtVs
yiNheOhUroCJJoNPjcAVIT34npyUZH7MRnEvMpKOR/dqOOUg1/yoQFvz1A0cJsVxu4R+yvfOGnl3
uBogEcIxUu7BeSQiFQxnkThaR8PxRqKBFQvrmipF+XRTWYAYpz7MzjRH26hr0iWL2+sfhkrQPKmo
ZHwHxnNTafw4wauQ23H/nRaFV8yr07wr1MM5Ke5JupZ4TKaIlxAXJyXx3KupedS+sbh5GZNX/1yE
sGnZYMCH1Jl/LP9FxHS351idHZSAztKneXQNFHDzi1VU1kQoDI/RRZfWiL9b+Jq67jGNKvV0RiZ5
hi0r8WbykXt+NQCdFnf3z8pr0uZOwDsn+0fjb8XJRVG26OokNloRNGAxBZ0MXiT1UJRNHg/I2jcV
VNGHVX6nlWffDXS5qCHUgP3kGSUpwPoqfcLr/klcTreE1dl9GCM5N81FmrMre6b9sBS/FmZ1MZVz
zlxrQZW3becE7CZ9bna0KoTjVlCs+bYdkFRhQO9UzFj50RC66/6PoNL3k4Xt3IpvPZZY6Vl7oCYP
hpcLQ40QwDk9yCO2vpAq1sz/SLSZwYOxY+BeadXVo5doDyHje2QEMUgsT39tYUnA4EOdhLxvbzdK
d6gS+ltyfEy4xwFoHBWCDfylUgJb1DLnnvmOe+qk8xiD5DVzn38l8VWoxulvFbKg+ceoIIHTwVGk
4w0rK4qwzkfmUhLEDLKu/SUKgr6DIUZIi7H+MGIcwRhCSJTSPEAKOLHiIc8t/IxTGGIHRqx6lmGc
+dyBaznJUlY+mbYZ5eBlMCzEqcj2OdLer8xvWh90P0d9QhPnlQhevlqEmiyvlaX7mSIF9MlLHEPW
fEbuBU87vvOaZEQgeXwRoyopB8WtNQTC1+xFjcENjVgXrevYb5m9FHMZz1LFUQZMZbywr5jCYHbI
eIAJiEeLdx0jS/Hf8Bx1yWW+m9ZTFd8shbF7e6QIa95HsNmqoOclctrqClY95HKXxbd48D/zCreV
ADE/M9e3+DAQMV36ZQO1fLBSLweQ9EOFbHzK7zQRFMZMzCYiE2GIQBnRG7/AKlv+sdIZ7vhEj9hX
79IKc68I+Idfc20/fOq+xqUl0bIvjrUvKRsohRMwxGm04FaqJrFowUKP3JdIkKZJull1Tp/GE+bC
LdKgRzXIVFKsmnpW9da4DX19qlUz+umtNk+zNccEJlLvVbky0rUFbjZtHAJjdIGslMfUbiVwtPMw
uSuTDeMD5QyXpqd+bOXHJ5qQaQq65xOFjX3Xes9bxliQIiJNMwwYMPcvMIjtZ+nDgkq0YDtIiGth
Zvg1Rw9D0tKUaT0kyJQerIHpar4bEXQ/GH9RUc0gqii4xVxqqy6uL6+8MVIHsZuZW7CiUKGK/SIy
+UL1M8r0Fc+lWr74rZke6rzVex7y7s14az2rxOVYL0==