<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqL4lKev6mPjn8SeQTvmVThdaPyIcc3ShkS7VvsAjNmsjCyAZVrXuDQaPF5ueT1M2tLj5u9T
kVsycR6/WUpW59KTRmSD14rDJhh6euGZFxji162JRqNTRM/5+pX3fXBLD6ETjOP1Go2KmspwjXhe
Bsz/WrPwpuBbRzol1u9iHCYoDDb+WBE9JfvWTgBbPdMnycL+lRIx8KDYbJLTuHJn5RuZ0MCEqgBT
9eoi09ByDnzsRqZ32RPmvTlHpi4jYeg2oOwYxBweq6Wd/76Lpb7MaO8rknKwRrripBc8c4cwuJ5G
gT3QZ3et/vtrhiw2z6yJZ1sKdSE2ja1WRhQ/eEckl8LohGpTVfagGDl4re/LLXdWcQz8gT1zhJzB
0jVLHFiHZYb2q2EJfA4BmMatg6MUQypft/waqr1iIL+DsAlo11swH+0ecMJ0kK1QwE7c/i9v7PYB
uObQjJREyYI7TZhY3eXly7UN9M+KPGkLRU//sAUO720QRwyS01lLbW3p0GQA974094uQ8kTauudi
zl291kIh29hNNKQaGzYBa6f9AGImLyJB6M8Jz0VLIV7scsaO0TIMnag1N6gk17yvdYiKH4IzesAK
/H+bYT5MvFPI9RNokyHi0T0WkiWC/FLnY9L1flCmeJhdgHB/sPMBNgvOwdGb4r0Ynptc9Ed/g8O/
ns4/EkQSAnFA20rPVuum+YkP5I6ioNMqHug/N3Ony+eOmf+zn/E0Uq6RBSoOiTlZxmocbctzifo2
qiiDOq0kYLulggBmoHXbnhq/T1tFSlwcoYP0N158Myv4Q8UXU1OoeDklrmLtDFzYUPy4A9Xmno7p
ZR5EVh3St/PIm4NHVFOg6h2dL5zE9UTu0NoCGXdn8ko91K8qHYoxHmHMAd7BDpb2QhqDW+x0+49R
RC0jg3l4iBtfBPnd8tokeAMnIhAF6YviKzR8trl6KeR93dWIPHKRf38I3PWThYX499uYYhcTKirm
ayZlVNfEKVy8PXowIC+exrrS7/TNBaj6SYwwcdtQRBSX/r9QcpGWVThqxZXDwzKLkdF3jVaR/cUI
Cb4aEVjlxp8AFTcqNe/veffXVlqDxcysQyjG3x7O53MzowKVMiA3HV5iwM2Z0yJjQgq2+8Almh1Y
I4m7o5w5O2L/04ab8yIng6zGTPEXMJUbkhwnvy1+vDdIpjAOEQu8fXbm8w0Nvyxr9ETHNsfrzjlR
d9UIO4HLMiRKo7oN2DbhM1nDtiruwPstvh28PYuP9VaL30Em318s56JV2o+F4ZQKO+2PmWZxpxxl
CwRWLC+swvlDk9NorQiTWoieNxWlk29TeyHNZuRv0RcoB5iF/q6XxXQ5kCFAV0r4OzWFJFeAvJ0C
wpDtN01VLiA1Srj1RZwju6zVeXoytQQOZFSRojkBY0Fc2oV2NPj8qCedWYSe4mStycNH1zw10w6u
98zPyqnPDRwWl1JYVg6tOf7TB8jt67WrGnilSRlvjJcc5Pt7RvaLHhVkGjyZuY7Qni0fVanE0n9U
1tPj+mLkady2xK/WxZ1TsOcOGdsxl6KXDMzLdH61tgM/5jcIKFzHGyEAI70jvUrKOZu78pRExv2v
x6st52EGtsPnqvn6crzszIQDi1dyYG8KKVqfvexs/ZVI4g78escaZ4h4pst4NoNlP7UAxKwPQR4d
dgVFPBJbrKhRfe06NBzFg98FfPn1zgDf7dyGEL0FvL+bUkfANFTYmze1wCkibTVgyjSisHiFIvLJ
KZf0X5y3j5gLFWMqwEw9/aGh94Ocp85GT68EUWtbxGY5euLbgi3pjvvSlNok1oaItxfCDwRFmH+G
Yg06VgVHhRP+vnrWCBUypd6QnSyd4METHds6eRAsM5n1uYJg4fHB6LrpkSKho38Ku/7Ga0HVgao7
iLlDHNHK1dBKIYxLbQkp11zOzPNxx8d3Z5dwiJFDOwTaQmSbLftsaJTCaTN9UotkCIsGO8IFrAeX
esbolh4=