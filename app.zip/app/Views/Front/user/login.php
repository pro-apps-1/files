<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPs7iEEGqOu7BmI+jnusOvoKqCDDqS97pZSaM+DLo6Rd32FeP2v1wqW5Nqxk6sNws0kS2iOUz
dk2Mt+D6LhWNMAoSeazyTa5++0FgJ5NLNWX2bgJP1xdW+pZHWwyHq6L/rfovBo5giwTHNpc9QCVM
ZswJUww1IRk648ZouC7LU0vFzem1Bb713374h7kw9khY5N/de5VQLs28p+LGOocEB1Z0fy34CdoR
Al+JHQehQdcWZZdwvDP2Szsl/cB9aN3+USstDqE0/3/QkRkhcBJvk2TodnPxbN7LiFZmQU6riLfX
AqkRna4mC8lbjAiPE4aQvYsq6wzmDvOkKWCnmjHbbBsbVOt/knTnXaPJZ0V5zq+RihYq2H9hWNTF
5bnhYGYVKTnRmJalPhNffsS14RHfxmYFY5aCHUL0C0mCbhvyJxk2cT9bghbjvAWiv3sUj/mqVEvo
xGPpgUUX+9z+3MisTHlyFT3rQb/alhA0VCtgwpRRdBSB3gBLDNhQadWvheLPMA4qDZiu9hW7dYKb
vyGR5TRjUEe504xTDURpjNO87k3XqmB2SHj0+5MLesvwvDBn2e+TCN60nbFxkKvcwa2xIANbBJfM
GUhbo6DHL6y4thBg7LtQWTBhVNxyquaAYY6hT5BUVmn47v7XRRPZXak5CFzpI9Gg/qPtXza77M8K
uy6fHKrP3fzLlGCWgq9FvKYB5KRjsiz7c3iVArxzAxZNtEsNqwxDXIW89xDKstYhV8zyUy4wjv3d
Js08EFjuxdMadMjRMGQOv/jeKlGpcabfXLpIytNuZv7gNKkcvB4kn/ykQEIeY8LTzLuzUjZZcYwE
RS4vjQMv9IEAdOynFvfraRtv/sTigQRJJuyOdI2wjeBPCMMoV2lAUeSH5B7fGH5z6kmf21D9qIhI
TlnROvYcuD4GWdoBhEwIwn9ms84tQ8veZZxuwwn8o2M3Te91+yamI8JpPhIwDaHNlPnOuBOQ5LGH
p++YMtj6DEGchVHKFO4l0LsFW1IKVdpjc8cNXaC2ZWEQN2D7qUZ/j5IM3O7dwrtVIt9uf/J+YNRx
D1ThlS/V9XFiRZI8B0Es7P9M1uKPi6XHQyy9u18FfjZK6XUx42AuohBvBNZkS5+vjTYfZw/q5y5w
6Vrjq24mlOU+XJG2IRVgS83DMA56MeYV4iFP2woYVUgIZVHFcZJEsj570qCzuorU4NTtgFeJWvGc
6mhwHejM6nSHqHEKcx8nNOgUQeg5/7c7lVH4kxGAKW0bGolJCOcPgf2CwcMscaCzwB575Ktf7cOw
/XeP8cVqQOXNgUjaSvbCEHSlNwC17uAjqwMtqeaGSHmXgIOljaW2n9g9FmuI1wXjDCFEQH5JRUxV
/rAKWRAh6pM1FiwUYp2dHYAoRM0UaPEAxpK/aRoZJm6f7XP4pH03jRmYLarsZAA2G85OnRBmDqxR
KgWUThVKi8m2kezxZxKLol8+EDieJ7lHUtvpTuGXCYi8CwcLx1aVY5P8XXyKFwFnDvJYK9aDM7nd
eQ6DmuHWfcNXwA51SkFGLB+Yl9qO3Jy7EFv3LEiDf90/mpvahugbBHCpjS+aj9shMFXSZd8wzBaP
igXsKC3ZMBwAF+MJ0ob48TLu5WpyaAm4yzNskfwW4JTJO5asLcXAqkYM+GIamdDONLLxiNUxeQzr
QyS4GXJBmTKgOjnjmYev9TXBRwwGfgRXLOK8dAPN4u1IKGzDRYboOLJXvUJf4HiwlD+voL9eu5qO
HtPyBucdR3CUWxRpnaloiEXyj+DaBxPHh5sdbpkAndC5ZMMsLoTdQeKSP/wv4+IIB9ObaNZMfwNE
L+62bSOJ0In8k+9165sxH1IiBXNQyNLCxsvwlZX6UdGkiGNS4kSH7+gEYlvJgvD/Lp2S8yDvGIEm
Lv7pTKoFWOh3UeD0h+BfDnW+Ka/qUPwPb9vdh70fNZGkUQYGQpLBkvYNdNehnNYKkPblUiFG9pHi
WFMydiu/pIgBjzXS4wj2EhtiTfrsedOOE1tsErqG3xxlSXe9