<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqAKpEDSIpNK6LTPm8aaQ8bQQaiIJZ3hTl9nxxcaMvYs+tmrV5xM5DRHxXCVJ9KfglqUG4Cf
Tq2PKEYioLt3/4PBjctAwMhdXUw9KqjeVmSBvLrAGwCk6mInxM8bXg0dkqJ4V7vWx3+GOqKwd/0F
/sSdcHFqtIS6/B/apd5Zv3bV8tOwn+pmWLb7w/gsHj1GX/hhC78SFjPPsYhoLO+UKYWxFa/sDiPZ
wfwBDxKDghFwcSbvYuhzVVq0BmcBjJyOwX4KbQSJRT5A8qsaufIGbchEIKIAQQ+I8HGKpTpAKNTn
BQovBF+pH5UfQNBWJwN/zV0UEZEIHWhO695+owAAEiLElf8Xat2od8CZ+gu17aRLdveISyMEa5NR
blsovkBckqRgiqNOQ5Z0OOOJSth9auMi8SI1zF8R9kU+kHzU/uOqH5HkHgGWAemgQapnwrD+szoC
RLEIqI6QJPZwQRgyRFOfBK5KoUz0rxKGlMWDOoI3cfQLQ/QBQTpGCSxv7s7EFyweyGvOm9X98R5E
01gD2vkCNNS6qJ9dTJS9I/qq2SmThJjUNVhiXkCONbFYQLvdZzz7g4jWPb+5LR8k5lBbn83qIKXN
riZyGPo2hr/5gv4tTvYPnYpD5AjUAxFuxDftsexcoxPL/nrkkPnNEwwGp74bBasyBT0PfXBe9jg3
Put8o4ZOYN/sQaxT2v1zdrU27GYyj/DcG48j24QqAywJAnRpYrvcEMoAk5ZmgQEKqfH74cArI9yP
SIUgCzGGQ1vjDhn4fXRG8BzEw1wYFUcjtrUv8jCjHGfhaxULVlHcRm9WJpFCgQgLMs1HLiBAWVx0
ulHLxNPn9mUPwA3a2F+HILxQspO8fqlFzBKk07Umoo2tlHiR7UqSTfvhgjvWqz6VhTVlM8rO+dlf
DOm0I73LnYPxyIT7aKdQWLz225ExPjeDvOYmgIlEeNcYcMFH9TaeO4OQ+eABB9s/mB7oarB7PRbM
M4uOx7WNnyWl/lHcAwG9AdEjetHW6I09tvHs+/EONMldfD3DB/3FdsX1Eb5+bLQ/QoGOhj6st/SA
INcMkJ1E4vav7M6uJ0mA/4PdyhUB+BOj4XDBCRg0Uw9n3IOopw5UIoztI0maQYpBHLbWzJ9xzBvo
VA0Y7RF6Ffcg/p4ijCFVp5WEOpxwFti9SAmB/hpyt1clIgeIWNR+U7/0h6CzUOZlND4VJFWh6uYq
mEi8zotWCrN8B2fQmhh25NRO2uGKcvs6E5j6gC1vCd1Eg9rwX7d9IBUz2RtM9EWONGDp9ec6VX6a
x70ZqaMgEqsUflXh30nBbuHpyPOBcmJpfO13H5Xkzk0rKvocMWfQ4p5ZAhIGrq7mcdTKzFl3qZfo
9mnfB7xD4U5oIPJXfqklZcQT6MktT0PWVX05foNG6SM6DArC/BzgEzv3itqnfdWrzMriIp3ibICg
DVZLztlkVAHhM+UtCzPavs7KhbPzU0fbwot5WOOUcSL+VoJbNE187POAt6bOuClmukrqwyNCVPY5
O+qerwLAPlf0PzuZqmVTeHt7Qa73nKhNH1kUJF4k5LW0jxNYtbQIoXmqiw5mo09GUKdf2u/6DQJy
H0UvbtLIt5exyf1E4ORQLVzQBzwDiWEqq8DTbUczYE3lbM1tvesx0lLlKd655omVMWxt2Ekvkkio
sTycqWkO3xI8uyuMvXd7o+vkY3b3h9cWyHcOQSAaUduIoxPllD37b8mqUTUkT8/KNUZ3WLaVP7+Z
L+RxvmsVrdYdW04JQTZXr8rh/wc0nlItFgYenH4qyO23U++YI5We6/zn66JUEiK08CxAXrLcvHAW
CUYktpMLfj1dp1OeC3AxuXt/45feSxxVk8INA2JDe6EsP1yoTBOuChM+SkNMrcPIzARddfPpC2ic
n2vuu4M4qL5pPbH5C9aCZoes/fCeLM8WBCjrxYLYJfJm7vpPHOB8y0ggKJP+T0ct7R1FhE6AiWPD
/zwaGDS/Zjp2NB6Taz1LbkDf600C8+f+vaaWqHIAqFgdTnB9UK/cVhpg90==