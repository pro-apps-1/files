<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoExjyRFAWpfbdWYvV9ezSOOZ52OzAOORQouXq4OHKgoX5S6P/qfbuG8HXAta+5k15Su3C15
DGPUHwcnJDk/zPiro75wiwNvAQG6nMagA299yCA+EDc1u7x1zAbfujl2iTlN+EQ/sJEnWmfF9Kqg
QR/lRCQ0NMn97ZsKh7aTQdWwk5WAWndmaVPI/x7S69gPPOZ2ha55jbgX4ZGTinJ5ZWQb6nrz0Dgc
4Ngh/7bayAPKYm30AnXH6nt3x9qbzrr7VxJAnar0bIC/IiIrHvjcnscyWwXdWZRMLOvRbWewq5oO
cCXILEGVSZixG6nUsCpRBv5uGzHKGRKjNy/R9x3K0N0Ka68XwmEeB9DNoqt6tW0lCJ96Oklx5s0X
/JQwSNoyc7scDucwz2QtIiMF0orcHEnHd5pYuWt/RP9JPQfIY4xQxUFD0NithnCt3IuH9hmj/6vF
KFfOLeH1r1jaDp95+FulgiRF2ilaZqu3UAaqUBvKfxxguR1EccHlw28Q2V+hzUZtcKDcWjWN9WWN
jNZJWLY3Ydaf3moe+xL/kGD8hxWBbPjZITG/3DMRbtyQyr1QAQm9QgICtB0GF+Ad1gojWO7mWyiW
jlLRIY8e2+ME5EOR2m8tebm0WW9vhZT/5LsA9QwQkX8vRoJ/btPQik83jVYCInKXYmlLdRVnM2lb
zYYhcH6ua9ARn7G4izW4qbbLjVH2OamtjgRTBcYD5MTDyho+eJBCbSdS3NJsaD//BJxXNlZkrrov
Rv28hYutFRfSEuIi7MoUcTTjLyyHHKuICRvijzWz/XB/qk9VS1wQv1i5tMM+IjVF+4ZhSZROoxUv
odPPapIusN1blSgilWg/CQIaGlG29gpBte9UQSU+Esr1TYwsciDR50uhp50iq3hf64R5X3jbuRwr
nj6oI4rnKakZ7zuN9t7cuMTEH0/2kq2KbWSN03GP2AxrNM0CN3IjB7iQm5vfTm+LOFbBe0OY5Ipy
7oTJikPCAV+RwNfU11wBdQPrGfUobF+b1z7GPPCk2E+EejEOAENwQdgXdUAYoGidGuS2nJDkgjjG
LZ3QOUmJufPwmltKN2ZIVX4rBAsRiB4vq38iqtzcVqCWhjYM4+3yHraPxFuOec20OsChFrMYShm0
lSG/wl0xJ6l93x+ji7JaHgSXlCIWp3QiXwdaVqZKLgDDNd16iVro0rR3bjgvfKlUcHwOXExz2zuS
YlT4rR6mmbsl4uhN8BpQ5p2kiXJKGxqqxLmhYW/D88rwIJ9cmrnuz43f7+iXzuuDPTJE7iRbymV/
wOPxqUev412vUNm7DdhIrmgFiecB0MXa/A9nowgRc1YUQBfYU7o95/6T9v+2tG6ybnAD6DJ/y9iB
0jvIgpGeIFrXoPasO21XyjvpjNHKKq8QMtIORibT7fnZEcBfrw97z43ItiyCMzo9Q42G+mcu+rej
iBSHkKE0tjOxhKECC4aiU89dxSv9OMwsdNw9mo+ovhfcWsoJQWMOFcfRXe87BOQPbixOX9aEIKbQ
eN6DBM5QuTDuwJSq7PaXjSytti79a2ZvjrWuobIhujNM7fS9qadA7WPO5wlGLLQCiEHz6Yikw/MO
w5H6OtGXUXmzBcAWJfYCnpdZeibgHxTeSTZAFn1hIDSUQGFdXhBiyYtmAbw8Zf7JYVIOutgqqs/J
WO36GyM2DrfkqYvcswcyg8aXDUU2/2QnBtGv5LyXvdfRmbcZyb2JKH7cI3+xJeattLCMEKioc7W0
tOfspgx1smkA2DoPEkvthDo/XX2Q6xStO78pU/J8/k8I0qgqPDhKnAnOQg4VYM+svnz529DDG5nW
ZjyYUf23VyUuSUI03BrQO6WHfzq5wHv+H7ThH3iK5RBvjNLQ8TYaM2Zw6s91753xfFQUIiUN7zQl
J9dU+ey5SFL+f1RqMv3qHtUnE5kXHUoc+mcFBvcJMXcqengbBoH3417c+3iYMtocUV3AOQfbUC18
TffJQ8/53qco0PQKg2znWEK=