<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzDwhr1YrHDdUxawSzCbg4xPOnICbrYzUhku+CDsRyTn3dk0a0aGS2lSkrtZmJCjAF49FQ5D
+JSEbypP6kxX5OTOYmpGtte5+KVmGG/vLmSa+F3IV50VTtThZ8JTtuRKdBPsZUdbfKwZzsqoQ4W0
LLQkvNkAzziYCG00B/QHSziOSk6So0UqULUEJZxgUlg1ejC+TBV/ZuEttmZtBPq9qQz73K7HKA0D
tg1ColKWXp2htHnvs+2N79lsqfdtZp3uZianyh6F55dCubCN2OI5/+0cyinju3AXXdd5mK+pYqLt
btil/v1WiaYqTs2MjN2xA+2erAs8wvINxSkRhhrjavweEvsvaTp7x7lMfS+G4gIzu0CZRP+KLSAZ
N1NA4sC+hBGfxpLl5Hl7lHQxAn5RReCciAjn56Ub4a6hl6qdFdsCen8dfgQpidhZdC1IdKbYGcn3
FIjSsFSDRf8bxrs8ECVVJApgzo8xBGUZ6HPLVqUNL48NTZPMNHi057KZcG9NnVjXeFPDCFXK0E9E
KRt/GwuhlsqwtgRJgjJxZ55xgvzMK66hESRxDyVXWtDlQW3dUfGV7Ygv2HOMgWOp+4vfN6MUfA97
JZ2r1bw7LSZqWvkXoEOFJMIkz9Pv4TJQpamZgf17vbw0rpk2iov/3npbDYK34/3q+m0QQ03zQNkP
SEjhndG6FnPWN/7i+SKEBG/kzMp0St5XqcDnhYS14SQHTwkYCjqYMb4tcnb25UMT+gJ7DZLDQWiJ
XciSlkVMAwBSJtANkqf0+ZBEVfxD/g/htMrn0bzGR49zr9Pp6+CfFSaSQhyKrJAUf05+bWUESrFg
x3JMTb+IofPUFhQGqs3itDW38fxmz8VLzZ+TnoltNFRZDNkYWahaidWH16lbeZLoJd4aBuiX15Bc
YcZH4BbKy9f13As+9HoIW+VfmVCAKF7ZuYyssT7aKTCe/gMFCZZJ5ZXMy/CJh+RPl7bxr1dwTBva
CkwA7XjyGssAXDRsg5z4RJ72PiqMjLrGSVkEr7mbxB32LUFgjWJsn57tr3+7sgCT62g+wesT+dQY
jVtUQBWbe9yezqa4T/pYPV/0MpDDE22al6eVfZd54ELLEI/htZsrozgdTkFJOQtNwz2/pODDvUaS
VMVpWzm/E69pymYsXfPs56KzJwN054HmPzT02flyb09l7XUX12XJODMfAZjp7CgPSlXHzEkksax2
VjRcccszdniiMB5ZlwwFtLtTTFoaHQDSNzNNYHR+XX4vyMMUlZNuGuaKz/j1OMljasmzHO48pTkn
ljgGji6kod9S/GYl73BYgmibEsx2/SFKXxrFi8Zr7+2wax9dOjvZlb0D/pFfooRnmRElXO+tKMFp
VbqO21PvyOZbDtNpIntlRJ9Xz83qcNtagNMaYB8EFx/LbLLnOzfV5hOatIO3ozes8eDV4/qGpDB9
kD5jx9cChfAdFiRZXKsNaLPmimjFjIi0rGG91WMRMRpb6Vy2yX2iljzMpF9COvq15aN2jGe0QS69
NKOttfrodHK81CsDiX6r6L/sgYxQWV+OqA4huBYo5ztJR2atJM43/MgzbRE+QUNxWONZUtD03AxC
Sn/WHDohmReQBUt3hR8uewYta/996oLqzPssBsV+MzMQLDUPvVj0vjNJIlD+6WBoiM0nNIL+K4qp
774OeVmNf2utIS5ObtOAQQdAYZUfCKzdmPRGGr4as8xc+AQEg7jlaosiTv9a2jFg8RHhC+MoNNtT
iFLm45ILooAJjygxIYVIlUjMI7IcCEk/ME1cobXe5HnWn/6ScbdsOo1JZvU7rUybzzKFpWA3S1WT
4v4EGvD7rZzANZTOQNbcgzU/yTtUNeEltuhUyIsOy6fS1MwvolaAHoPflaPIGc2o3nvwxkBFNgKs
PG74st09OfA1jGoSJ0i3iz2tDqcTU9vvVuuEJMf3Zp4+7854Z+5EQaXDT8iFxXLixn2TDXgpimYm
eK2BDeFbzX7Ek1EA6re8H7uhk1bAqhwe4uOZFW==