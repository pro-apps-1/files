<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpCJ5ZNrmkewWD235fNTg/DG/0w25byOw+c7EaYuxM+tz7qK4ithxHS98G0ledPg+pLffpFQ
TZR3yLSBZ08v6X1jnWORcJctFmxLOVAdDzZ7NesFbGP/HxNxrugSrSX8ucPCYsYxgifIcKqef7w/
hy4C2oMCbc9sCXIReUA7/TvfXUXEMWxFiQMtDmZe1lmJKnSACvCrySj7P4N5s+7eNWu/X33ax56Q
y4friSN0LUlcPHtSe4OZjnMHq7Wex5rJblqoPpJLRuDc1MUs9o04TxIsCjzTPmET2Ia20aLZNr3L
jNYWLPpRvi+nDpx2ecL11MmIozoctViVZPO70Ezods/EQIoB6t8pwsNhxCzvyoe++oLwVPkOGaYF
hTsJEj6Y6vF8MHQCrEblmRPwJOwfufX07wdpYUAgO6FxXvXkO1c+f4/ZYGG58T2hTLdZ+hYzM/+d
uN8G4Miq3OxgquWlvhz12UBBAa+ykZFZH+3vEWpomR45h80f8F+EyA6AK4WO642LL0XIJb2WTRhO
rxOozix68kaSofrB4/S25FlYuiZ6x10oxYDMfgqRHol3yHWFSLvYT8WkIoA7H5G2Y1fT/DTFEzVw
jHnLLxFruHm8pf3xfDrQmkRDguXE00+8PXFq71m4f6eZe4RxFx5ydrviA7JEh3VnvvfoxqsrQH8W
Cx1SlzGOjC1XlGAdGE4BN2rRY/mVy6UmRjyruAUjsEyqII48YWUiMXu8oy5wZoWSgEPM3sY8U1gX
0E/sml7U0TcxQpfmTwukdeZe+3egY9tgkPSPSKErtDA+lme9o0PAhVIniOPKFhEr8D7YGdfQ9pKv
LT/TAOrh6wK1DsRKiuJma/g5ziIzFc6ZzIG+z9nX136YyDuLX7JKzSBNq3k2+ANwidJUP1r6okTu
qkkpYyqDEXllN3vq6Xml13TO071A2ic+X1sJ7Gii3nNjgZMr7Xhoiv4SR1d/fU6kYHgQROuJUCOd
Xey+FdyhlbtLECHFb6WIV8Cl/tzzAO8M+n3qC7sPhbwuysEDqo9Xu1nyKuHou7c/jHmu319jJXjr
i7RoPDMtU8Jv7gQXse64Sbs3H9pacFaI5Rnzlrvt9nYYY3EyIVw2IgyKx764GysBr+2lXSaxQu1j
7vo1YxC632SM0VknYB8WQTe3+BsobAPT+fzrYLBrhKU0AXF281AlnnHOPc9aUkOhp6bnyHNLE6cZ
VbuO2IbTw59Fn6GCF/TNRFZMmNwoKxpstdBDgbKdNbqcvRmTAw1Rnh8OODzdtMuHDoZVkMI42lP7
8ONPGUF2ukUh5cqTRJXcNItMYssE5XRz5v7IBUJ1WwDb74ha5NfDOSBi9W4uKrheVe1WgX42ao6t
gDPdtFCPr/K41pJmLIafl0FL6efXDUQX9bh8nX7T0aj/H78vMZHRnlIH48cbkPUmN01s8YA1ih7l
or74NOZhtO5n4ohKQOqt9la/qLor+F0MNwDBp93KAHNDGtfHEKlJ/vwpyOJkFGTm95a2IBRewVKf
Roem5phkESu4Owb95QIw2QDdyuGkkmgzV6BTnZScVADw7mZ+g0yEWugiRNd/oIUJ3OUEs36QliQe
TkIxdbcOTYVZ324CPQfm/sFOyzC3IMLs15hSww5Wuim/4uDstJVAft0vDPj5+FSZcIal4fgoTnQs
1ZBYlDRhx6NcsfHDEVBltoinaKHECjhaCd5j4VkG/09rrFnXEjAnWtqqCXg5V0UlTy0LgNrO4f2v
9XnaPZk7CMBG7w+wWnI62vICu1YvPL/zV29SjgZx1nM82yKnCIRae2OWNphLOOsfaISjXXzA8UQp
N8AU2vGzsCk7VLLJxCFvJpIbsmPfFpBSv6bEReIES/jlxscX6ATByW3EZWU82n4dZrblJ6UvhQgV
iEbPtG+VL5f0zUcuEqHfXD2BAoA09Pw3+ndnUctaAZ5K0Ee/nO5Gfzv0fQuOQ4F+b/CQcortJc1O
/UxV5u/kE33B2oOQdBh/GspI2G==