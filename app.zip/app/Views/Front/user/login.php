<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPp/Botd4cZ1+aGXUMcd2JuTK5G7dUvFf7D83llPSqJOhPVUfnD8KrxPh3Mtl2RB9Eeo1v8CF
HQjyb49p4lHwNLnIiV/sd4bSxc9S2R+Ivz8Uwittm2UwVMWZOUf5AQjQkk+kT4r5POxEMebgZO1+
PCQg6JIWVcBaXD+iDd+ttN0ECEbc8hW0T3MnwoyiOwh59qiIElkEqOAF6PzxYnOc5rMYZxzPkSF6
BI5UoJGfyCMQ+e4ZR5DDVC2Znr4QquW2l2zjkWsuA3bInUyPaqOsaIkOiCNlBscdOtq3Lxa9qio8
ohOicN6HHaYf0by6WRJdG+aBRb0PVh2U7KJHsLT5zZVKLJi2uNEMxFBKOCmLvrseCC+FUFO42b7R
PVmkEWgJggJoIDSSANbjxwEHyUzCvOqOIec7S0pYVg0vlKf8CEUVISn7HWrESVrVX9EAdEMEm0Sp
XiE6TnjtWymEN3B1XnNmkwpjID7g9nyYRF9usom2Tvsiyp723P60T6qPmllZ4TSW29DMOPf5ChNr
2A4egLVQyorNNdCuRq+Mw1FXNIiuHIT7sCG1D3DbPPBp8L6gy/3XdtncbWO5sLRyVmQmPygZWVYv
TwyIgTolm7pjR38UhmwTaEcV2awVM6clJuqVq4YOiWvrnZFS8mGdfkD6WrjSDdVypC866svT/VKP
uock7W/byp4+BxX3Jec6MWO7foBHEsYMovkXgeKdOYDtKtyg2Js7MJj779n23vipIWHrPDogjV/g
JFZWf6I/NqJ4D/eW4pMKMFE7K6OxxOgaSHNF/hUeWRg2opkjs/bcfXgrXz94Ayf4GR41I4AjZW+L
EEDW8deEahfwJJ8vWb9HrPizn/+wODg5LAwLUyPppjc5HVw6zQ1kOEkd9WO/8vk/VO+RytdebI8X
KIhWS7Yp5ZPIb+zF0S+6lSSLmGXyVxX1PEJ/BoIzBu+gJoTSlDUhZa6kY7/ndVXsprYBwA/j4vgz
Nu/RtJkzD4LCRd1GAeR4mq9Z3E1meA3a+0f6bixv4uCiRT3a+jQ75Hn9s/uBXi1v59SL+jze51+/
/fpbEWnHXRjr25Qn8l6zabNLK5HVuGvFFcXxKjruvK8uJ7IpIpTbl2qR4JyfCTVRvmGYl3BNAtxm
SN38FoYpRRQF+48HftgBZURp8clg03xxu3RbWd4AfxitHoZkgUBcwqfK2STUrugGSWW63tDggENK
S8gdnbASrVDi0yXA2nY3djTqtOu5LxU63s2zk1i9pcN7gjuvWv85J3tJlkHqTocspV54lPxFfsoB
DSlvx8bZQF07J7hLXKPKZKOD8SxNBcgLzw9mMO0PrRTzqtj8K/qTmf/NElUeWqI0b+GTyLEAdT3A
mDldakAtcpk56Rp7OKwyexO+57z3KIyX/3vUmU5knZvqrYDAHxOa+2SpXaRbmDXx865Cfc4hCeRS
4cQY+vVBxr7ozxmG66fUuTgq7aLjHvEMWuqg41pm5fD2cV6e2YZsb77TuQGL1ThdDN2Nouill08n
JOxsopTKXx3hqqAVdZEjRuYQRN0BanCFTE2C39ojN8rdb7OrjGq2Yc9xkCRHkZt1eEZugBA26Zyc
0FphGQvP2Ymms7bQTX4qai8j7ea1jHTzivo79I7lxU7me2qUUc7jowcjIGJnTr8tw31jmEs5g80F
AunX6bOecrVV1JMwEGElYJrjHeI3AXILvInUEjXtFLTi5anUtLueIphQIt+bqS0zfcX4AYkkhysr
xwIdj7uiRA1qX1+731t2kn1JHKH42XexD2FVxMQWTnf4MfkAwnty8C3Bql1F53ZnYUfMnEk2nnag
PEdo8YG1fBG2fqVOQl5Rq2Fgh1sPV8nuZTKLWAZDZ91rwkkNqwVfVtBqJuv+EOg6d6VMKqHoru+a
AnQ6U/oX+fTzSnxetKNfDehwUas++6mcW1NctTpgiLBsywMHJ+Ml5TzUuQAwksLFQWVQHweBFUxC
ks7Cs1QATN2vDhsqM80CJ+Qw+dQvS0==