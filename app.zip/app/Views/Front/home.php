<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzv+H6sqqhn2GR/HJYu+YXpFdFJRn3/idvkueqCdSrIvdv5Ta0Wdh5P5o+mjHUV76VDCxTfz
uvpf9j/gFQyqi/Dxwn4kTsenrjTWlqsk1CWdV57BavbJLN/zG+5/eNoCqvdJWm/2xZ3iKAv4QcmF
s6b37ShdoaIFW4xgzdM0yBPgrnyi0ijqOQopBAdhZfAfuwfpgwkyaqN30rntj25ym3Uk/Q5s5p3B
76s13sGAJYdX8hpqcnF76jPpA0NQAK/ppuo8lg30UZr/oXUPysMTD8bFf4Lk46FYunPp2wMm0eMY
3ZaHM6gzqcPA6GYY4kEU9q2sJnLw4GBfJywVUF0uJ+hcDktj2g/l1LfooNsRzL+28NEndkfM8S5w
AjDtL0xNQ2PLdWwxPRD8vvM61vK6nEJc66atQdPwJ+GxBBMHlboAvDaAhWyEaY0gKARU8kPj8p2R
pmnszN4UX+/t2rHnvKO4CRBBDZr++wnBSFVfEhQ7JEG/K69q9lmOV1jcLjYlJJS6E+M09otXk+bS
hNSkiqB44NrEfL7aquO0AXuz/j8HaakCdr7VWCAHp/XcEZGhMeot4adluLx/Jcc0Dp0HpaCmv3kS
TFU3yAzkd2GK6vgQ2hRHyJ8XMJAadBP7c3sovM6qGONyfSFofKcYtOyKiO9/35EkKWQe77ljyWer
5ESxDml9GccbODBmfJObdrHVpLe5Z6p6LuBvHw6EfdP3r9D6EuaUk/sofGiLnGa5x++CWFmRPspA
8JcOHEQ22tG7zhH1WEsbEcv/1SgxCQHfn4i/19/fUZE3l+lLXRLeCyTuuFo0pkwRa7H4un9aZXzk
OyJj2vg3zGpGbtKVZYAcdQ5Eqft1MF6yCWM6PG2NYLzrN6Mq6kSC074xiddYfdPq2wU9OBN/1Gmq
lw5XVjbNCKsfr+pbWOsAvip9TBGqPz9GbecR+nPpmic2HK8NlUZlafWrkN+BEhPe8MxAUu/gcYU+
48lOQzBiQA6baozOR89/8xX0kEAPnE29C2SDjdS1qGDcmhn7sl41G0JsjZlpWKemybufs1ak8NyO
Ql2A9hxMWYublGeAq8qDIaZ9h7KdpC/1b704HPyVmq64k5bgkU56h8vcFvvJ+GhtwxfeL7a5FJXK
9mY8EdvvTmv+39mbTXHf/qwU8GcjCD/45VuEBL93ZCbMC/v3lC8NAstYw1p7XnhFcWL6ASeV8sG2
CbnzMZ5n+Tj20XrUot/27K34tLFcvAwtn7TEHRt7Ll84