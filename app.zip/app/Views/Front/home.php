<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/BCb9EGW6saRGq1iERGVlbCB2F9TF/1f/fo8Yu5Yq8oczb7Jmwv5/iIW0hNTGObQzpc8vmC
A63/wXoZk3NMj2KwhpHfxBiozc8XCVJeI/sQ/91fqeA0rWZJzu6u/TA4M/M/ZannXfB4GL2rX6al
ghx8kuKHTWwC1FoXiiPf1pVqLidnYbCSmPk5MEJjgKNHpeBVZSkvOL3THJCnAhdmpeti8GrukJs8
NoMz11PCVH7vSTGU9UyFCDADYgG9WvV5SwZXRp3ZmUmbimo8G62q62zKbycFR61Zl+40k6BQzyBn
GJwB1l86PqCE8Bkh9j2TWGnwvfxkf4YxAwjTBLT1S8IkXTZdAlZdbCgJ+EEk0uempQzchVuaXaWc
4hlKJuvtAR1NsSRG4kU6Q/yjez+kQRQ8Dy8lVy87Ia1HYdBFzcR6d47y3ALYcKI/p234VxUzcmNA
kzwMP89MUdtZtmvUfG/poyer9ZBJNd8173xno8tc41W1aM2uHXpLUE4MSq7DPOSIuIaQTr1RDSFT
bzTwIwasLH33gLKkObvAb0YjlZQ3Rn4Vk0W2T+0iEF9l7tDh3AcUav7Ee/bS/HUJoz+YqyhvH5oR
SaGJNTNndjLUPOsTuTonbWkcG8PK00nQULvktV+Ju3W0H5eb/naWvh9ufhjyDsI0j/1lqNcQVQds
iuDE/8oHnkgFVx1au7dOfpEpiE//GPB1VaWHKJ6JLvJSi4vaopX5VeABuKPl4bCoFMKcTKBYPlys
Os0x2iDWhICMX5uOJn2Ko7lIjn71BzwPKlCaMW47rM5ii4EiUuvwRM1irij/Ijkv1bog46nPq4Dx
dHJtu0Ib2EKP6++csOzx0lqD6s5e43OjkovfzC13KEez9VXzM3c0pHriok63avG5xjsy4XCXjP7/
HhfMvrS6gK4RHawaNTTNGi/1ufP9mTwiHAfcUu+G+I8GxO6d5HLdgbP/Vh6yZOEXMN14lKffzVan
UqTpHj3wJ6qZh3YaBjpx8T752RVrTA/hdOyOhuOLbF3JWsiGZensCMEgqYMD/NXqjFMxcrbSPWAI
I4tNseiPYG7mZFIafW3nRhURdC5xE9Vhs4VbnCvIGV/oI/WHG8Fbcdh426D5TR4s9oEXaqzNp9k3
oOcU3iF7LZ7+Hy/47UW0Mbb92rHdZEmB+S+r1XLquv3hgiq/Qm7TC6nEEtF4lvDZ9DcOGXOVkZtM
fP+qTBoZ/1PdpH/+NNTNE4cS3qm2MaaB18Uh7h1oO7jS