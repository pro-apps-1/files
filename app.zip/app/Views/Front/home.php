<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoHVjqy/y0jWnfuYR6eji8jXCagknEyGdUKjeselHur6waTT2xaB/cChKsEXc7x3IkixiRiS
5l48ON5iXlz2Uz1d8eMnG/s/euhLaotRWZcBshnCxhe0FIIB7Vp8MFzSZ9iqsfVpUVLeZriiCbc+
kJMUHCNebT+qC/WVDKaMYre8c+mkVT040NEzhgQDfn6r7SrqPtx7H1J1/m3C2mcVhU+vQsc6vuUB
zaZaxyqo+NaJyyxMos+wYtCJ3KO9y56fSGTm6BKuzappfhx/q50CX8kf8cN/LMawxqBN11Fb336k
vIqv1/+G6E8iocl2ozmrkznErraZHwk1rF0vChsSsIPe2u0nsMKWmbi1EPIqHtlOMjpt7CmpAS8n
vMYUDNCVMUU+dqK+ikAH1/OMIzdScTjb3KgpY24F3qmfMbYDnfYa5dZ5FrFpM0ZlNaxAXC+WM7MA
J6uFD2I07At82zTCHvfn7taYxVmQfgXp+7M9cOnsd/8ju7BqvF9MUhSR2Spoovo7COeS0bkSU5IK
fVMxytyV5y7K0QvYCidpCtEVgEu3E73AmYYeZ32bUyK2gVSNR9u0xCdYU/YfcfqM2BPiS+StEiNK
JMwKYk1+3NT10Bw0shbUJS5sYzRiPSL0JpW//vw/YIWuKMipu7MdQ6XgfYWNfTAzWvph4F0buSPm
W3vh+GkNlZfMI9R2G11T6/iSop60t59Ja5iHaPI7SQPRovF/lgD+zokCBiQRyf07Xd8wu1oUaf/P
FPXmRgtanxIUzOgsqJjKNTJMODF0q9zt/xI81AQyfJGiOPC+nXYq0zF9rvVzFYL7A/8WU7wm3qGC
01SncleacygsGkl7a7YU96DQ+Z1mb+DWb6pVy6fsSA48Pe8hq0r8HANKHb/WRGIp7X7odSE14UWp
2JLeLSALts+2tW8WuzIe7Sqz7Q5hlTV0voS/5Lt6anESpBMgi3NCGrJZaVD25LFoyapi0TDEJSu9
ffEwrvdBC0cvHqMrH/C27qNt27aOX+GMn3YYNiFkaZvGgBNPuhGQgYV+fpk6vKd/Mvj4sCt3nohf
gR7m2wkrh/aqJwHn770WUEMI/1Qn6Sy3coU2BIFZDecIgjgQcZMcNYs35PvdPvf4pcAaHdZ9Avl8
XWnTAOi1O1HDwpZBEoe762DvzgcbUD6hPtg48TGv8qceFxFJBWKTefjCrPJSKZGopdKKgW+hT+xH
sKSewGPfsJG5hk6vGD0cDyIU/JyvVo6dBb/Q+G==