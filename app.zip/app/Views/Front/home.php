<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvLApQzD1pQ028jOZ9PIdrHq6KUTilFIHDqAonVh0ggWd3hgpEnGcHXwCQZWyLLlLpW65GlA
xqun5tUaW+VnKyIYA8+lPwxI0F5jPhMJ1iqJcHYzXIKHaH6VjIMu1A2qS/nFBFjZBl7uWDs7O2HW
+C/nnf+DjPIXN1ajFJz1fheT/Kv+Om0VDtrHlJ+KShlHgkCZYz5Bc9psCdPEPwT7c7iJkhT6pzeE
wNpKvk5S31crzuISIOGr0nYz+T2t1fiV+H/I56a7gvpcWEdzp1OM0bemvygoFsdj8ntGoW8SHCwB
Ia+jBZKkuyQ8xGeWS3x0V5ksQs+yAN5T0Vjj3wdOtfR6kDzDufcQ0eIFuJ2nVdkGI/epxfM5AT0R
exXdpPalkIVY64GpNpbT8RUWZrkjQif+Ldrc/+ChiLxZkoFwjXXDlx2TaE53tTM38ag6SG7/Seb1
A82B5DjMqmctk8ZYbA7bklG7XYvYt3OeBezpw4sud6UBdb4fTxcayJ3Pj3S1suKE7hg6z+8oTN09
n4p0yq/JKM/ROMgLKkxNk6SA5dd0NdIYveJHaqTWroMzmrc4zicVNAmRhiW6moWcXdMhy1izW60S
5HNAu274DiOdCleGZg90ifkILbhZY0wof95snbrkmp+g2BG+GijSzVF3DmQMur5OTNc8ol9REa+w
r+AvVoOAOtB8VImmMCvK2tJ1T7+SRpYosZYDV3b98nyTCaAWBEwRM4NZKDijEcjjG1KMY4dEVSWV
hgvs5Je539t1TYXVK5a0fPv3Yf7ODQ8zQUJ4y+sV1BwV1tILFRqsNutRo/hcAH4dCd91HBnAwm35
0tG/1flRTYVzNDmEEJV1pqt0RAuf8k3VcQ4X2Zvnf3D85Fw1x76uaWJ7jWOpuHSNDtgoED0JTq4Q
3nItSEVGm3Zah0L9T8BYA3COk2xF7yNSSJHecxLe/gDbbufPDCRN9EaALkyloR4q7Mo1iQzvQlzd
1DdGdnTkJl5uXfDH4hKoOACBH8PLjI9TuNl1XVvX1P7uMgRV2TJaeXsOmU0ekZtxh9u1PYiDtXzd
YoDPU6yQPfej5kU/o/MGke7Mi40NXyzOz95PWhST5L+AmouIOoqtGOYmpVhPN6YmqPw77TI9bHgv
J4BJJDdyWIvc+87G+R6UCwKn8SZo8T7C4inaHawcPvEoV5MjoEDeD0LCgwjn9Y1ZxnUP/pWva5eR
K0yS9Y8xTz2YmeYB0feHOlxcHZAhabZa81d2qqjdfcbPB88=