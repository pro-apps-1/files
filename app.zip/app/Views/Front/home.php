<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzHEh74a0nL6COyvKfzmBYC0V2H0+XkeLDg8p/JkLZOUalmAuPHON/53vMjL9/cX4qkKyLrn
6QzxwyoUidkwOBr+B505hQjX5gU1gvg+DJhqWmmQrOXMBpKb1+Q7FSrCw0N/QkALeZADwgIx2KS+
7mqBeXCh0Qz46jtq+CpMAeNwD0tIMDpcuYA8LC5vP+SPlBoMWAZiAKRR6h+qpctBCkQYrxClNFim
yrXV+Xx9GVquOgu9XOf3dviv6RuuSg/oM5+uPn5yXavASODAXtEDfJjwW1JxPKUGz9xqJE4hIVsD
uilk9l//I0DH6htVn/19oalrTHL3+y2Ka9xwad7ypbtzJgQldZ5w214fTQJ0fqQuPZ8RQfOrIT9W
N+vtGAogb4IbZlwBjQZHGQFS7IpJ9h4CGZ3R8WL67vfHRDtfbRW8yZen7Bs58BqVnGOH3gSOFGQn
tpL2w846oHA/cFcaYsOiJj4lC0A08mfHTnSKXo6iBv7xUQIGAgVuv6iRRysnDRpE6iFn77l7UhNs
lCcBK7Zdv2Q0r4jPp9IeEqQzCOrFq+yOxWTZZCvJWGbhFWKdKiIxt09qEX8JHMOuOy5E24X0DRpc
7aZhDqOPDX+csNTtQxYEZCGZ67j4Ddv/bLC3m8X8Ds5JQTZDnJZfINL/axZs51eD3SMUVQk8aDga
NjrH6+ZB5vA+QhO421irkGQN5mDvijKansnMreZ7XjMHmsS0JnavHBuCkv/QOPDmELfVc9bnxy0G
xJyIjOL00ccROLThVnQcdFh49GcS9oUSsPEkIvK9HEzKBrQcqANE9yW6z140cIBf0H85Rl3xxXW9
MVBKpxe5CR4wxuRShmZJBpc5M8h/YabFZUHTYaFYXS+LmhE9WBZ73c6drRthE9n6obQv9h7azpqn
0bqvrisi39e5naY/Agzwsp1m0ARmpvTqHixCrJv7u7bRXsvAKf37UucnXF9VWFC5/5yv79ooBmjF
KH8D2FB4rsmSKkhTrEj98XKEOsb6e+Q4EEwVtBxlPzFyhjuq0OpU59WDgY8IeCvnbTxxFVpWNnrU
VxjqEMh0vbrE8qDqskXRX7Kn/GWE7+aewBoo4PCwrewtuvcMz45sJDDKBWhSex0iUPOsBo3KhlM6
dTEn18EmjoQ5ivJLGlMVEA8Qi8x86q025XnoSMK5OyyA2y6Xqg+Fpz+gNCVjBAm/ecnZcRkJNSKO
qP1tpy2R/ScZY9gTUAiSPJkLX9r+Cg/iLeaI