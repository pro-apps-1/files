<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmJWzx0PVSo7v25YanI0s0z8aafzmd6wqBkuUNB067RIH0V+6YRZjOw45Q+OUFh7SKJzoM1L
/0Cwt60jElLYvFfucMxJE7BUvrjUBbiozXLnlrnI+er80MhvnmrvdzQvrZ6FV/7I1z4sKUFrP0Lm
Mls9H7aXYTxt8+Ym+usA/BwS0R0LSzYxFQ/0X4VCAmnsettlaq6TL0ZHreIFxmVko8GJzytYDL+j
tdq4lwicEoeIrDOfVbDQvFCcuH8FhsW/CkDRscOEfIpv+5PatZdjxX50anTkhvl7eLRVg4Df6wGH
MsSjcHVeEmCj6wqCU5Er225IOyVvIK6aLiGbqhGgXrqaha2yS4cIAESfUn4sfskE25/V+BNgqPPs
MGxFR1ZskvDGmTPyDGsFwVJI29CAGEMy161q5/KOaOVG95ObgQRAotqZmIpgD4zTOoqjtr/DEbWE
HZxpceIaAhG7Oek/qQQDnXUWwZzD8ripkH7lSd22P6HmE36W5rFIzcMZFutm4GrRFijSdfX5tCUj
T+oMaULQL+ZFTIafwiIHVwnqbcdcLl5nvkeX7dyaKYP9Z20q55MkzURrzzaPSu60iS1VpVxMPcqK
CvtJ+NPBNhKq1VwFeZrT1daZ6QSx4aInOgUF5n4Smq5xCU54M18c32imEJbLhpy1KdN3m0JiYO64
/nYiSUrlHxFne0mUy1wC+jnfjEQIPK7Oofh5JSsX4/C/iWXRsfdp/giZNRxJcRl7VEFcQkXpsGl9
ZreeUap04N1n40D7+gWwoGsv/4kt//m15FjR7Y7n8XT2HF5FC+8PGWHK0/CodLPtIwSJ8UW135bf
EaIq1QnhxZxexgG0+DQ5/VEZxlQsG7yOByU8z5RDVi8ufPQ152AkwNk4O3PBm4Se8BGMBqHXt6NR
TMmDLpXxuFdg09jG/RZik4M8929Pa5qYsA7vGgI33gqpA+wqnhjJicrnUWMZy01L4kAnS+jsGG7D
VYMs9CRzwDN6AOm5ChR17xYYkQJ3K8fJX3+/MMIwq1CF+EueQMz2HH9jqszcZmX7q86Jg6j93qRR
IaXlZWjhpCxxrx9f+CD5N9iZHHu2pzNivmuuVp5ezEIJGRb7jybKj7/VuMvRuSCnTYjqyfKgo9RW
q16uaQETuEj1Idys0ntvPwFhPdu5sqbYpHtmfEHDQ0W2LSGQ1FP79J1C/cmcOa9RyLFDAFKmpWkF
d1/FoqzW+zZ8DJCDI3JNSGdTbbEYdzOCLADbM0eV