<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuVXEPkRVOBSOY2ik59T347SOsMoIiU59RwuZVHLR0MML9zb6JfQ28LYoXHUB7OIuUmzZ+Ro
IRB2m6u2EV9Q7sGjyUL8pmSWojk2FwhiuBZA7ZbI5OOZGtfLaU8QPdY5+BLTp9ZwbmU8CNC2RNZq
iX+uFzvXDqS7UpEvsxDpqhyJyfrGthKXzTxFnlWOkIw+TsSXk9SD19xLpJdOyZl234vh/un3FHI3
VoVVRXMdvBhIbh4GWuOJzZZ+ik6Kz5i3BW21RXD+6Z68SCA7rRq4bKjocQXdzfKGyQbASge1vKUQ
EjSP5ko7BYd/ipDtrotLpQhc8a+7pV2qMx6PtMujLUvQcGyTqdyjZwRwJGwjio7SCwiSmVyewvze
9jphSZzbdRyThGf28J/gsVuOZWHPMHUwmNj0zSd0KPFYoE6WiWF8IPWXKdu3QnE4VdIJj88iRT8a
Z9zr+JvcCsOMgJxxLkrLHMJmgNBTmV0Qo39iOgVWmssP7IJyuHl6+QIL2z4P1s4uthOJzJsccLvz
O59YLCmKZaffKu/RrRGJD0LuVTor6NSBkvfF65RRcYs/fnffRckkrW9vzWVI6bHftkT3OwqK0wtz
mMKV5251nm+mbLe/ZJz3tM9wyPbUwdon8gUimKQbI/XsRKdEH8eZQd9VfqziV0uzzICRR6tY4+3l
xGPuE8nTMDYb91ABMBG2i+sEMQr+U0xJRFgQBCibmNyEhObpKjZz8f6Q1OQ7bbq/Jr+MCraH+hpy
DPLd+1wI+IO/r7gTEV3PSYOty6Yj1aQIJNQVzcZ2s/OFoXVyCp32ojb0nc2ivRoAdZKcaqEz4gFm
xxj5ahRF7OF/wH7i4D6VptToBvl9OhJN8S3zrpdI2CJ5e0o5GdrvRuQjDO/7chIc/or2tLW2X/pV
1G8JbViwpfgwtDpAJ846ucPjOWvfny0hYVcU2mk6CKb83dnW1SxrQpR5l7QcqG9pyFbj49iwoN2T
KK/ayz1OJ+v8IpzQpojd5R3IRgY9b9No5Cav2VyXk0MbUnUnLWoN2m8p8Wx1LBU2jAQKE11oLMPX
C1cXo3HSS+TZRQoxdX0prFo756Of0D+fhmXF84yufMEQW/L16BChULBISWCSnVuwcIGHQGVPxwSb
XJKNRR/mlKTjMCe7KcyhP3JbDo6I+MRuNncmIMoUpQ4dE7xRZOHjRm8uVOaRXnsbvzSMM9O7EdC3
8vj5vL9QgFWL8iq0fOc41Z41MCNKZg/HL7IS