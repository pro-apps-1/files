<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqmfqGdOkYakfUX4AZuWs9LMHXqRbI4VBvguMzjQh3EJJKBjZqDakduUieMewG2h9i41kwtG
qvtn6SGkUiTr/LcI2XOfFtfxTKlWB4Y5P4aOBdG1JCFDBhjLNWFTL8NxjzFbKl/UZ0QzdPBJXHoI
fF9eb0tHCGxpVVgFQbLMECGDlITuQdK1fHRI0Nu97RRnCctZncffSg35+JdgI8xquF2mPJllwIeO
8CXBfd/Wpp55uyo7104Nq/v0zBbVPEoaOlk1gTMs0bR9yaI/G9MPSJsk0crdszsdDWYCY6Ic4bu+
f9mQ/mUEvJQhw8yA8MrITy2Vd1W6/nR3gInbxsqGUjSHPrmk5slUD/psWziezWAO/B+7/1iVqoha
yKs6BGWjE0o25y0c2cAiYvbCvHZ72BYkQsqijfpLC/Pr2nuXsZZK5Y81C/GU7et6AcnPbFeVTYDp
ifVIIJsXXvTaFb84nuAcwXvz5rdC12G9/ebg2EobLysFdiTFUJtTVtUy8EjnWw2Sr3fVcXyzgk+p
UU13T8gdp8Mu8W7+NTHmi90qs5zv6WaHuVJbBFOEVqwB4aDyGEpwCVT1mF872rVqEb1ymfWS2y97
yfljdfRSKoyF537JS+mC4TsjDr31qTYQASMpsXCbjpR/+4z7j6AVNwM7eDb4RJQv97LUSaJh+Woy
hXzBeuQCTQ6cEuywgfv+snXJMSMavOWaMPIIfT+ZgE2zDrjr/I05D/IMBf2MPuMJAM8Hyvw2RSwe
683SuqkoZMnGHLGEoBrBYtXN1Gc4AlnomaYvor2ZI/SuopfrdX5Iozg56pKWVtSnG1RrQvYcJz8T
zGefmPg2P9uTjKOYbtmCRw4IKaDVJroNZdjeesxexE7EWZOjvwUdHy0mFvn87P+NJJKxOG5nQQ8P
Xg4U6jUmYD1l4pxAALrZwQhNl6Oz11bd9KNR1OhjkQ5lRtvozWdFJcmnI4cpyHKTc9VgM9SdMqgl
MSKw58Bf9fWcVs6i5S8OQb6SZD2rJ9zxtMiljGpnB4V/JYDy4sbprJuH5jqRdjX447NOkLzPgZyF
8CX97i+FDdBn5cMq2QtvTccR+kNp51aTTgXSpwZ/SYr1MOlKoIq4mCH5vnvSIiYRgo0DymGR7qFy
4SHXKYin6fJ7WXKEv2KQrkWJaR8jbDm2Cexy1IJfchWh1cRrQ+bL1Vy2lLjAQ42xfPz+YIAZaB8v
4mFUkbvxD1Tkzhp/TJEIpmeah2f9IWm=