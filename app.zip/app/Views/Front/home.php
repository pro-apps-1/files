<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnN37k3pdEFNYWABm+vB1Kq3y1F5tQkCuvouQdzjVPVel/Z68/cQ6pe0jHpja1Vhwgp1Jv2o
lzMYLeaxx2Vz2Q9MwncRhIJYx03Th+Cv9020yRDTFm8PrE+23Wd+MVX/wu6VuGlnPJx3bKhY316E
9kfbToCd+faKoLdCG0+iOqSFNe5ezr8VV5Cwqxd+kF206wU4Ky4HEcid9DOegbLkokKJly+D25Wd
TIDEaQvM3/mEZ4UuBcR/FX/4TTqL4qV7+BAvyLvyD5SgexbHR420sM8EOhneNYMhNXu5V7ZOVEs3
rJWs4Eta3nmcAMkLL3NbVkOMvasMed/kkT2518WlgwVfz23vTJlyeMw8/hmtbSVMX2pqoeAFGul8
biZvD1p33+BPSIF8WNp2wTm0WEmansn/Z8r5zy4g1qQtGprsb+jjBEmgSt3fpE6lq4HPNSTYhspc
FpK8rH6CBHNswmwGwYYxfj5qJKWtZTNAfcsPR3znOKIB7fwMt7zLhl/Bnw/faCk7+uspSvubFpCp
NYo/gPleVjeqnsotM27ngs47bQ/dT1PU3xFNLYOdtSAncDzrn1DECkKTgD88HYuWaghkVlOTsvwp
bjssNsdHjRrgCPKJRtAvm6eQIlgOgqjbCjwhMYfl2aIayKp88F+c/6n3oikudcx7L7JXGVadvWqN
YuNe1V9RTk1AletnudpjLShh3zM3p+m2bjmoetCR4OZke7th+e8PT6cDxPhumjJ20gd/AcviKztd
8oYlgfrATN6u0IdcCv8KjLM+sa7rvwHNk8Yq2q9QYhGoHnlPRIxlsrZDd4XMX6378qWqiWDPkJlo
SRJjarmf39kA08f70dwDCOo0HRXADqrPsnu2AmPRw4HTp4vQqVZHgG5f/3WjN6LcmBUIgCcJzNPC
L0fpR2Z0nbUCZHCsTDY+TKzBCWav+Rd5xCoathghB897pdzlgpt6VGZ5eb3wekkFcK5YTK8R0act
iG7qB6wnZR3sCf07SGqvfQnfFqqif7WlGQQShZDB4zO+tT1BL05I3GWtzA+NNkRYQL83XwMpgrwG
TbGX0dhKLF9WcTP0nZyFKxVEMU1fSo3YcBU/k9sQX9NCkDmo+7PRDE3vZzOF/7AHJPh3xA3HSbZt
CRy2b9fbKFu08uAMfizcm8o40NhgSco0qVpk9uFjIQ7bo3c3wV35ldUIGcu1G8u79oD6w9v95OU8
AqxhwhjxwGXcV33hFtFCDxm5iVDYC6bB0snx/AWhR5E6