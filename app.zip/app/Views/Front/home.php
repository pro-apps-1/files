<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvL9dtnp6cHp2eWAN+CxMN6DPNJEZ6s+D+AY2iBkC8M7EKmDPehu7j9+X6ypnCON9HA5MTck
ZQBznpKCXbeoP6O7CxiinbsyAPCZXfY2JXacAge+3M7qO08M8To3yXFq3ntu7E/VU0kf04Moq4xl
XXXv/xK3tN+SJ8s4iSPRqy5eff9tyY/V7T/j1j5lwu1PfOc2fVoq+F1PuAfB4So2vZcXfeiniLGC
NqGKIF0cGvbmCVdxucX1rvGSwABvhXNMbT6AtSPDG9KZFqh4jKURPiTfl8DyQ0ienkfGutEPXFjS
c9l8Gpsal3tCpaSQNKuDBqiMW4YfwLLmIACPd2UR4PBG9WHWcAKQx3/qQON92U/DffQTxEDiNa2X
Mee4MSPbu12fWnLcmJZnivsjJFMCI7VQnABqhh0T7qJMoSXKIN0In+4SwTEAoYWPJ+01M7l9pbNY
wbfvnAiuCLZ0KGjx8xUZlql+xuc9kokVKBLhQYRdke4f0UJ47cP8YsXHiF1fuL8j4SmqriwPvM2X
+Kz/VuMV4lebo8MXGgCERldcNE11wDYniJ1DdKK2vinq9+6wdocD2mjEv45GVruFnO4ix+NGeuAV
IyPUOvAowmTtMOwtmhn70FWYJ8hs6Wi2fbqQG2BmNtT+PWXT1Vc2T/DqdRek+QkdVmdZzqxHdGvd
DbALUcxBfOxMdoHO8GlIRs7trPcGdOg1zkpn/v1snanQdg/6EfqCFzHfGoD44reqsziUACz1s2ER
D5Vck4JSBsxbKD51FQxq/cGfaN+/lkPKKuvvcRh3S98c3ERo1jfMCDrcEh+78nSb8evB3/Y3DUa3
2fq+w9ydU9i/bh3n07Mi0J6uHKw5uVFiwD1k3q53vPKGEkO0WuJSnv7qhbYo4cBjzj2Lo9dHHI9f
qwYdRkQgw1Q65bKcppiqPGBgz/mhaff3ZR+kSh0NwkD+dlxB3tYPILxLSJAPOU239oUjX5I8JyB/
3Yl43EJNlDaTJKcx1duTNBI0nkyggA3hy2iR8peXJJFznmm20bzF8nU706pGhOw+fu7aDSB2py+s
MLgmeeu/FSHehMGrdU1n6O8hRG1a+TIqg42ttxwSh5ZH5+WGDLNctGv+u6Ju/Fs9pyiWL6c7aKpD
hE/YxoFjt3C29Lm0Ix49CSoKkUW98+nm/IkQuLk3525ga5w8BwmEYjSfnliebZ+qhTJzZ8dqL9UY
p26cbscKu5hQmNh9Qo96451HoT1/DaThKs2RZAlHPhIm