<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/GV0PQMi/dPRzwKjT4pFjzpRtwBV3cUKeIu1yuY9LjnarnGqXiZZmJKQgVxwPN9mg9V8ID6
h0F9z9+WLEIRvbvhqG4iXS5/0kOgbrHiU9FckO9d0q0Ukb995Q+7ZkIr3WsmfLhN/riqNz0fRVJ8
GuYuv6sC3lIk+bLrVl8oSKAoFpWHftAR/M0cccjn2h3gFVJDSNUHkbwoEbYBuMc2PyDfIyTAjt6h
xCgdF/5O7+OLfuJsruIjflVyLD7SsqM8hObZ7nWRo2Rxs85Hakb8U5GQAxTiQqrjQLeeVNh78C8z
3dbL6JOO4JVuuljFWHBtOZbcxLkbBVL6EswoObML5daRCWVqvqe+5DqxRTsHPC1v+lzoY7ODCXoX
jxlFcVvfEKFcktw6kDNLGU/L3ANUFslQmNXfvERR/f7ELmk+7cj9ZAyUNIoYJy70LPuAP4BB4yOA
BUOb0et1hOapFKn8+YLZLWEcVr7j4H+V8eLbdoUXiJE5aDsPOTJqgXPzZOz+fEydEepA7DvfxivY
A0lih/Spx6VLl74oQkuYWAEjbPsdRKwGrt8gzlPRdG5DGc9v1akXrV+kld42LMlsgHI5LobBABxr
e62/xeNuTT8WbY6gnyCmu2hqvSy5yI1pMpFU8i+dIo/vhoQGwLcoxrnRAaQkvMrQEzQ/B9kRoReM
oEZOMoebwYHa0E+6lqxIccOTqHb7+/66TrlQPKkFlyPmCg/t9/Ssu4qBD0+hqs8YvUdMaU2OQGYK
syV+U0ANVpDAllJsaRwMFn1RJ5rG7ws6wIvLTQBNYrJNzhjW9Qxe2alvepexK0RAY3PG8GpeZ8gS
3DSljt+Z3+NO7GdBXi0r378x27nJEfpa0wWNt9tZOwJNHCILOA003ttvM9LFgBS1XXiFKB5+Pj3U
b12L1TWbN4hM4r2OgU+Ekqj+Jkk9S2/J5bUbElAcGrMx93ux9CeT2CsO7y5wKV1pc2ynAjUWj5nk
PYdWxBdzymmxHXRUtW+upN8PQxU61ecqeNov9L+xJOViL5mVZ+Kmu9vdOy/LXJVu+vD/T9Xm4Eth
a9u+TLbBG6z1w3ffnRJ9hi4Jn1PMqaZF1V+9P/z0drCcX/koCqCROkLdx0RnG4EcORMuy+06dW4B
Af3dZxflVJQLX1brsgoGxpi6GAVd/SPePy/NhVFYepaYLoR6AvUe/bXPLBnxQvR/pGiSn6qF++Zv
EKMXLFdWkuLNVXe+/2BsauNgduRkoAgXANycrSuYtvEkTchs7W==