<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPm0qWCeGgNZjxVKLwIy3O9jra6KctNXyW+9Xfqs4xup0GeAhdztqVTGO94CR3biXHb2N2+r3
idd+mPFBxb9E31bcvxt6AWsAfzdnfJ3xLPJZUIOp2JbpNsiRQTelJbaNtFS1688dRPiJETB/WkP5
gE6bEAYzHVtbROTv4QnMExo0+Akhm4hp0dqq8fP/CLg45i+cMPuhaJ0oxh6qLfF0aIgvkxS4wg9E
VMo23Cn9C06kwOwTbCOVfLTfMrpa9mYiLCwTaElfQHTUxTZemLH3b0prRBqGQH//7jQhOVytg1lO
5Zbk7V+X4sNZ1H6muxaE5iYrwOKxZycYE6AZZiUER3JiGq/e4Egj6FVpUXLhPBGGRjW/xkitIoMM
ZaQkZY58HdRJATlV3aFa5X+AmAQFv099WlNGCsgVgMgjQxTbetNRk8VxcfVOiX61s40noouwbctO
IE8eKrrL7XoeLayqiipczcrPq59rQAZw/YdKCCK2N19v6puY4WyTpSzMHXC+9GrDM8p5gAsC1t+6
Mkc1nz1lBGvYS+PxwSBp8jCFSduj3sqGNcRw2m7QoBuMqczLdeIwyeys0gejE8qzQob6wRh/jhkU
3cYU6MG53fVq0J7RhjJMq/fUkJv1MaVzTut0EYe2j704/z/u6N76co7rNW6/NKU8JvR9xKel3Lm9
AE+A5gxQvhSxOyzLt37mR28v8iR2GADHQBj4FQJ8XrV07a6/+A2n+EU2VAZcymcgDNJfn4b/nfoc
Lb7kfF/9YpxDAUaWzjkjgwpxlcU5VsKFyYU0bcLWPQpgP78N+n288YwPZiT+SD+JHGnfJ3OpgTZN
m8FRvXUbD9/1+AbLGNkNqBZexLa/IxEY2oiHxGa7d2Jjg2RIrRZK6/rq0rLAbrnbcmM2/+KK4zbI
/N4MVMa9gqH8uGdfbOyZO7rWZq1HXdWKgLSUqSGUwT8umweZZibDzabHi4vBh4fCUjX+VKKebk55
suwWlXopbxYnUevNFetK+tz76RXb00WT+vN/82g0r07yNAA1g4L1uwQ/3B/fnfYlttIg113UzcAv
ix3Fu9xfc8P2QVkrKfvKBjvUu4CsOo9okb4W3El0PIrRZzub3yBgNsz2cLG3nCEAa5g95iPkdEQF
1jv+Yx4xMgGkc1hfJtM6tzGoAxIeS6HRa59QK9iMiOqtAt5NBfUW9VJ5afWQSHlvehDT/J7FX+Na
P/h3ddx/jBOAwC0hwGorV5rph0==