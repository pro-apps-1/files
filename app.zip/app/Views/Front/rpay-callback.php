<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/dBroPocYm92mX21RZIFyrGOxHM2fZQyDLqnpQ5QyTtD+7R5VuBZNFFywbPeEnEXVByUnAe
1e5p7c0kYv60suXnlf80UNHF2etRXc6OfQBoNHdbUWV7OTNTakBh7YZO6UELOGIJ5CPJbEMKHtUa
pRnPLY8OVEoNXzkp/ZGkrsWiZASCYl/MnBW7MMBV0/cJGmrKdUxjXAYooSJLLacX7xR7oK3v5Ix3
R9UEfSYdgftQV72VbgMenWRv5gbo74xVjNCvPdjCcMQxLMV/zya8jBPrB3vzRiWRC/9XlCLXVOfW
P5RlHYu4/kldDSfUCcB5EdbfQ+5yKZca/nkFJYUxQ5IGum0urmhstmBNgBJeuRm5dMMzXkvHq6X5
kWqiFqB1FOQRZwibxV+0OYwPtrB9O30LBeXov3eTRLoxdKflkvBm3zCdez2JIvVnXfM0vmSAUnIn
RK9SVPaQAas5dQyYc8jpL6jqE8ce347q4PObxgie+43Cb1UuZ+pXj/FdrjHcRveh0vQ75VD5GRmJ
vNhGai0qDk+getgeY9vLbP/FcPL2JuTSmu0DbsPW79RgYf8QDs112BKHvdGl03tAWt2FufDDccVt
7MuqFzBR88LmEBtyWY3viT7SFVLRGs21fbnim1L9RDCAMxDV/m/JhrpjKd6zISMa4OHIP6roB8lK
G7hBXoNi7bzxk4wSuiCIdLkZLl40uuRZkhxSTzjV4YrhFLiOHJiE3QYYtRg7iPsVR04iCTf/1i+I
00O6Kvn5hxizVXkBmB5iHzMPYhD4xYcAUg+EEDPJUoMcoEseNBdSEkj1tsmO+j7GNKFiU5i9UDj0
K0gN+391w6e7dbRL0VWY85mFqIGGxuVst8q/DTJV2Gu/O+d1u4Dc5CLhgSUjO9IRiCCTvh6x46/v
3w21H56IDjl6+EBGKe4vs1eGhsl8XBv8qWkmcawS+Q6yO5z9MXSOYoHmgC+R/sEvaePgsr4+gnih
z53C3iMmi3c2q0sdW/6dgmBptUwdfVZHw0yJn6ly+ug0dUcUGtV05sNyyBGlHE+2h3CWsk2S1ZI0
d+KrAIBSYGv5Fpc0taZqe/FndacxKarKm3BeKi6yeetUxbv3Fckpy9iFCRWsWDhdKcHakcrN/D4q
Mbt2PRgQ/6ezxM0hNPdEonGu8yzD5c/TqPbV83f0SrpL9qowMEGMWaJfNN27U1Yk94862CRISSXs
h3IUISBXdyEm9ICiNkS0O41JYg+J+sQyBMV+cryMW0X1GUDmRecCzX5yAhq022Mo+O16oMnjtPkb
eoB8KGGDKdYn+DQnbVjGND3TJYIZFMkfM++160F2yDAIGf3mwSJN5/1DDVzozqNAvfQLphiqK7R8
Yz2JIBMOafmgIvRIOrQukAG/N0taENgQ5eEw5aqaRkDk2pWdyNaukldD/FzvD7k32ak90eCarGCN
g32qhf6Uzsy4A33MHJLSy0BPhTXuiNBlqnYRhis/NNw+GpBcumk4pXKSA9mPKAM9eUBozpDJ2x+W
0cAbTGQ7vWlDbBe4nEUo0a/fpv5cRLr3OuHVISeUQ61XB+kFLEa9qvCIoVzLVgaYjQL4KbZvpIX0
4VOzeN8PXc7dO25YWbt+uawJQXEXZjK2xPFv7YjUmZ0Gf8ih2gZwxX5TgOuggQ8BoWgU3MfWx0Ui
aQT0W6963qrWcn+9umnYeQNkzGZTPLZ0PoOzw4RfJKkmfxRcRryFfq4X0COdEXuvy8yB4rbSA31j
+FYMYd/6CAiGhxpvT0sdFNXeHyAw+vf98iu1lyb6UKmf4K1ffOyph8h87by230G8A18mmSg0NXf0
hvvaTtEwlCEQUA+GG+fAgWKzR6ntGQ3pJKIQdIcVj7S6dNMRQ8z1aOFTVYar/HKaFub1X4sqLV0D
D1DskkHoeQDE30a=