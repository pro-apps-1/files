<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyysSpScgKSvF/Nc5FwO7Wi0N1FFKsUtIOouQ4+g0zq4Qma81AhSJWJyNVIRzMk0ESf2vilT
93JtkjUHp96PNjn00t4n8uodYG4A6GaIPkG0bkaODwrVhs9SQHGqTYole/2I7CE+CqilbCxkyKlY
pmvV8p7NE96we5P0SNTb7ziLVubafnYnjmXAyZcFFsQi6lGDjKySXwW/OPn5esz5VfGfUO2XosV6
2yeNJYt6uwJRNIdkKraN2sOmD9dbi0LYH9a67vQgXq8KtuwtDIuffMsorPTUhmImI8tpfcrSL+wE
+kvS/vUyznQQFkQE9RaiezIraTpud81h5SFCiDNmNIMKqPBHIV9PU7DqCGL8lj/DnJ+cuLhzMgyB
jq6GnX8n49AAAvLvs9K6vBy14kuRe+Cb3di3p9fgO6nejrn4q9Nj4WmwvgQpVkfHIr60kwmJ9v52
a9RXgw/Jjoz1P0WFR80FNKAsTtELiJ9pKA5Z8Mp3CbEFXY++lnnpObbZ+X8LyJUdd9pR1C7n9PhT
d3gDZksfJwOlIQrAzOrbKVfR32A7mRsZ9vN0i3SYDfWdYkg/vcjI/wVZGFNrppO/NEgS5UwCM0Sc
U6StP+/RXZYuymHg5A9g7/u9VSDOQpinoyYIpQILZccKckRix688eH+URLUVo6PmrRMjPP5qG8J+
bo4xRPORwioDRRrETzkT8G3xhOTsUaIrxXhchEMvsXjBFea4lsI3+pt5Q77Zr4HiECHcWDjq4Uk4
YCKV4ePobZjfW9+dy0/0FZMuHPUbYN+BmG0jBLXRFKd/C3C8Z67woB9/rzQFXJjCp4YIejU+wrkX
CjBzJsMLwHUzIecu11NdtOkF30TPf8SbtDKzfQ0AwvEuUWg4nt1Kyb3+X37jaD9lXSQm7jkWHkrn
EXQTroCRCXvNxKNXmSiaJwAJPYlWv+WHEO9Gq/ZuWCZbmqNx4XwQMD9WTFzSbda6pkm1Xar/uC3H
SpUemxtkAyJEQQoKnULmPThH/enSLTZrJ1cnqKEcbztMxiuSzUR5+qwjbLgOxRUjuCHq+oHi+qgb
IDtKzg27xwRUmiAJiEP6qIJfoYifNQiFWb034ykhcsHt2Hp/Xg3dCtzDnMNuwgzDgSIMEC6Qrj1r
JLUHGJ9Ath23QRPnGSstfrrsh8oZ6uQSa6ll9Dn8xXFDW0shywzDV4sIK+o6UlI2jxN1C5uqcLVD
23VUpr4TvqSSRE7DYTHDKiEZdiXgdFcBolj+BJhkmuDQwh5zw+T1V1NehntVGcvpA6HIMRSXV7Hw
AJ1I1h54w1n9NYALhE6GU6OWhPmM6aLY848QrqUbyoZ7GJVyTmIfJACTJjDyH/5OS/JHPpucsjIO
EEK0uhoggYlHiAnwOGyJ/ItcFPyHtFLdAafTrz7zAYv+uhiIllLSLjR2xn0miRKFQDfyZxy10Zfc
0Wxl72uBIvtCAdBcqW4MtOYcpkmtKkA9WjCJQgVM87HAaozP94/9wJfSx8njMg11GT1Q1dY5wczo
ekWbJuivaOr508q1PCf3BhEJ1dQW7Mqk4cKasVCgjLnWBKg07pXPTL/FD5p+HUgmNn2RH7Is5TAf
nux5nILogRkR8wAAUcmzG50lsWJmRRD/SKv24ECxsr1y5dvL6XcskDAclGFXrjkSLuL3/kcOrTbt
cHYJvXRomtz8Js1YHdoThvyqdIAUYsJ85R+TKIweWdwCHrLWbHPCr1XxLHVxL24GRBqOSPTOJ8Ar
aTZW0kmS/2PZImt+ky6siwmbDu6J8e031Bty9H3MN4MM0xo9t2n71I7MpDgg1Fv9nW7lNzTFjR4I
fAMWLiOR/0Cu/y1Pp4u4kxy1VSACe6rhlTzoIPBA1QlxSuzcmMqxWMaqlHI51AqmNkStpTeK+Gmz
YZLthBB7rcIi7sEWXm==