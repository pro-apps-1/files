<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsQkOoB48LWMaMts0GZpyuuf6SEtuLt3We+uc6sbRTzTfUtzRCh6ObCGgU06T2a8vu4zo0U1
lTHHkY6WH2I+MPKzJKIzEAGmnogeE5CajuvkNC13Mde0LTLy2fK9C7EM303XDQV1l238pRTqh9IC
SOVhjH28YmHXOglqVkiCEfDY9TrBejOTKC4JgTllDjeIzqZXH7UEN1cQ5Qd8Ok1wBOW8B6ip74IE
DU/R0VshjGNNUkvlvMVk4goUjKom60YCUWY/w+bf5rxjsEZ1L4EK3FLilRTcuyjYyrRW7B8CvTWM
F6uS/yaHubxwiLeVuKyA29MoqtZHhvp9AQy/e79p/R0IjcgjvtfUa2hyPylz2ktCVCwaDMUTZly3
MRJvMdF5n++9ekbtFj3RGZxHsLL5Ez7OAz7CrIuo9cVaVNji9NuGC/bengBsNkpfb88nVi05hbo1
PR3Ya7+5aR+fB1p/W9VeQbfBBS2CMF+XOqcIvKWDQAN2jIovZMltSjbf2HpDZfcyYTZeconzIhX5
kKxI9ocUdxcfHDN18zIgaw2WEOiTgmt5PJbTUb98VpQkoR4fJmgFwDCIssIXiEvp9Fj8sB+BHYQM
dGRVQA05BGbzLqeFCI2IuGR9EtgywMcB0p8oSZhCLMqAtum3D5rdVexf48r/25ZecxGOl+IGaGHo
DZyA2OG6PBMNyqUUl+P+Ecfa8+muEasWeeGqu9I/PvQpj7Zvi165t9ep69hKrGicq8GNMXf3ecmJ
+0qnP3ZLpu8bUE2aAhJMKWYdGGPzY4OPcnBm2GMl87tzpvnT9f1qZOoFhEpb7m7TxM0SSU9X8SpK
hZTxV8/4S+9qPAzpIq0tllgYjFm0cfrWMZVzspZooOCgk5T0m9gCeECPhy64RdA33X4m8Nnl6glO
rIop8TWPuBBr8CSH1P2Q9BAYMzvzGcxV2zfr1a7ECQ3mGnzMH0mQcpYEExoQmTAO39X8eyXKpWWo
o1cCmCiWvE++SP4cmHmSza5l4N6AN7yuxY1frUWKTFwMN7mAptzkteUIkEAxJA/c0yZeq09NU3gz
tLvXd/nA6R1AkdjbUK/4OFHZJ7ipZYyJa2RH0gwSq9tFmKcjcugkMx+i5tm3nzaiaEIB7vKwqYq0
BmKquOgC7Vpxr2nLOoxoXOpCLAyhDTFt7RbB3nodQzzcsgrKnxzk6AZcaH8mRMflAq/EBrQ5MFbi
Ikc/CMm+8mB6l4BK4IrafZxWyj6sm+wArt+MjOyZuDb1qSHZGwYfEbuUYzY8W9+BZSs9bOPUjImW
b0i1ItCQHvfd0DWm+Ph09PsF2yaoTxcsPL9NZ1AUtU2VHksGJyS9wE5pGjUWtf8sm8lGHlF2Y9gH
xQYdKcwyxZkaNh/fKN+P+KWojxSXjivdz3QjuSKJrj/S+8qTNNvP8yXWJqM+lNwNZurgbPFN3gae
4Bcb8V4S++/9cff6WtxIePbvAF6wDDN4ahAtxqVsiDIVDw9HpoJ7x/hn7iG27BRIr2sVk5BeD3si
6Uo718IYhtOM1BF3H/ybXIkO2haVv9sZlaO6E2FWDegOk+VGE8mv5MKvCSD8WRIgtKNDZpXbah58
87zMfZXULM2mvQGqUSRRtrNQ/LcoAeCXUo8Bo7DZhOQ5nBJWVhgymGYYz4O1Md6cfKuSnltoZe5x
4WizDFXeOxxYcsAPCsHtytkRYrQPe6d8Mh5+b8CTwkrLyxNPtB4Idrv7MkPVUFOqxHQ3BFCvdYJu
2WOt4zY/ULGuQvS6MSOunEncCdLhBAI+V/jc74ksCdNoCYS1pItompwJuYAtC0coiI5uyZhHUsOk
+pV/f4/kQvXsmhNqUPgbD8u+f41HgTeBWNqQVwC8G9/xzxdmmu34lwjfRGfFmQISN3fCyqXfi0tg
np6Ug2nWJq0=