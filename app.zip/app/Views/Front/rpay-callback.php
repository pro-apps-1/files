<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPub16nTY7E1OUuAED9iXqmAXIuD8UJwbav6u4Xyzs0DZ2wzMBfB+wKktY66s+kqLTX1ZEZYE
vO2pZHpqKNL2MCrZkuWUSYpTx0wZIXc1jLOMuSML64uqVWmx1u/oJ+nnllh26RnU6Oog2kDGLGrx
L90GrxdSrazPeV07pWxQE/10vuKmVgPUIkz5jTTegd1yH9Q80t57q+9xUsCPA39ceES5AUV0UIjR
GQ+cAXGwPzshA1DQmypxU6IzZ9vagyU/kaak1wkSve3f/SmM5W9QCEVAijHZfSmH/0Vnr45o04fF
i2uM/tNo6MDllR3r/8IOPvlG/fpgdS0U3rIpq1rEcZFbHMY3og88eFwmYetbG6aONCvDJoYfYBqW
vySNvMrpvBSr5XjykNVPbIzRyDM2hHPSBlm+KunOvMjhUCA1ma4ECkO8aZQAmuARE7b79ztnB17Z
yithFdhVGmv2PBA584vjxOjpB+0I1A/CeRud7WDjRkSEt+Qj63s/oW1JW9SzCIgA9SjhQN2lzodm
3HDp6pLxxhpPJQ2Dq6LAfQHX7o5tVG79w3P0y6VFCZhR5+xS5wTimQmZdar4S/IITXwXozfZSvK4
Qp6aGZZEmfPE+SNs0ckXrmTLUL4B0p8DPiWCW6plI7t/2zV+i8e3e7v6BmYhH/mIQqK9/l3AoThU
RoTRQ9R2Sgyaz0X7msr5L9UjNpEfKaUdBaQFneGjTGxqThLvRWuCrU7QRNHDfSckQKcycGZJKKyQ
hu7KEQVqnTSMJa0xv5hhCzwnw9akcL+xJzyUbLzkzmYh1HAQZOCQhSXFK4gzDrRcMuy2JDaBk8TE
G4wxldNZJc4pZFTj0Y05YrYookUdZy1SvIx1MwcQ2ENYCQkFnT2qe1WbYV4FXlTyprsB+fa72mxT
4/E0rYCW8Kpv80TsabGgtr5hI7vnviqMw/x6rKBAKGuq54QBN2wjfnrhsV/R0X3gDiev0H330Vj7
jQ8+KV/et4jm/fAIKKUAKDhhRtJSqjAqBdLA+rpwoelXqBhtAljc3/Wrb4kWYdzC+ASnXluCL2GW
qThXlj+lSI3xR3OtTFgz6u3MnEkZiLzwrKiVS1AJFbYqxaF4+c2W4C4/tB5HiN4vsRvRLy+fWdwv
CYfQbF/dVxE8QPkax8ihoOU5WtiMNes0r94Tz7PFGEXFEElJlZ0+NJFP0dHdvDsCpVQ6C6UZ7NHE
2BrR/t4J8pt1kjUD16bwZHGklKhtxQrlJskyf73Vo43gqS/lT+HJ9a/youFwXaSBRwopXwR5BFYf
3MobsUiMTvPx7grfccvo0Dh9Ksl3QMhdERO57D03MgPX5K6XLZSFJNW+B8l9aOZjSxaMarCfE86H
FmR4aG52LX+VMpGOehBPFU7XN8rFKoaTNyKcUIg4jNhYOvrWb9C4oRjUJErQvZE4gqKt942AXuvc
uRcvaj8CILbb2BpBuFZttGxp1k/0nVZSDMjD5xMUIDA8T3lokYZJ/FXUuNI8IWqdT4aOZ8otnDb/
Y9QNIg1CQGKFcGLM6sfvvQuzoLczyLzXx0HZTCHxpUjURcJf0AJKPj57isLUloQcw2pT4Zb36GZd
zunWjEWWl4bENawpl5aAYG+1gXiDSiAJeIsdOmGKVy2zdJKZPYCdLXrAGeSRmDDm9j13p8yQ4/Z7
6uPDm/GWIJB5Ds6ccc1DJ3Hsq+aitLDd1NU1WwZwccnzHsrwLEEQna9kVqDGFrgKzyvG/aHJehw1
SpQL7xl9uUtpk8ljtOmVPAAz2i7LcwgUS3lgL4mLZRJHypQ0lpTHRWRsdSlU5sYyiaYXWB3k/hyI
Vio5tyoxuNYPvwzoXJL7FK/PtKx4KexA8oqMI5olOSIC0QNiu8jPWmJZu3lpstIIMm+stCairMag
1zv/u6iSis5QXze=