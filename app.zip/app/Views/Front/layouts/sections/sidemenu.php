<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuunIpP8f4yw5UhU5Kr8VSLR0Y72YxAkCPIuVvY/k9p28Aq2QUts7dEGiu47A6GLqrbleSwu
krmMGIcbhG58Oba7u9h3pqYN32n0S4Uzd2M7MxxLxu8atFQ2Be1JTE5ImEY25jkX4IMaio6kmRqc
ejKOBK+pp5bw7akByQlee1cvzGe2okpFk8gtAoNPsQDocQtvkIELNiRjOvijxvadi04GDMlkdvgZ
Fl8BRkXahBZ9SdWWcC3aTFKGaAUuzKjtLYSnyh6F55dCubCN2OI5/+0cykDfAWI4vLjUKLCYsaNt
c7iC/+gMwTqCFQfgCB46BSPIsD0Lr21wCzjUyusB56XCsN6vZxi8rqlAXl/1aIFTIWQDzUTxUdlK
YzA1A0l842GVHk56fXxTuVtc5py4wLZgAlOo9fwvH7Kn5u/3jue010e7G9QscFTlEWhDmHOvod4I
fPb2KKmdAWZ8OPKKjhmPUMaNCDfVcE4Xuml1Iag5ruoerRJEBRClI1Bpu9gnuXMd0AJmgyJscqUs
bzMfgAuCY1id3I/aBhyAPwI8nHAzymjHysXzvOmNsoaaET0z6vdmte2WfxWqnve621gvj2pdaqmN
klYu4T4ZaWEKZjCDT9ZhAKe+PV7IcpufUBCO+TqRdMt/tIglsjeEWRmMrWXgTyrGWWGTGHAEJhk7
cBs7i+WiqCTmwG3LvMDC26PxaBE6RtM41iQA3AdpW+TB4uKMtcLHLuGohzxa/ULHmbqBWBy8TI3G
tVDUEUlA2lLBkKwCyUFM+VzLVqzAXUH/c4OGQ72H9BxL0JUOuAcUI7xqCbkCP6Y0UsdsW7WX+kjc
MhDbJjAnvCF3yVLb/XBO/tEqhnpAxrvLkMZWTaVe2h2D7XbxrWvMvn2Uobl6ykMXUtVwRuLuLd9o
gQ7tk71968v+p/o4iSK/GsPTXyOq1reKbs2zWt2FloKMOHrar1VxXd7IoqIf3S7XFOFPUzaXY6GH
HVO2DVzeFN555a37Pvc6YytEhIyi5FpkaBPdSeoKA4oTe72fHgjNYpsk9kRPidfKiVpIDE5yJkHz
ejxnpTLX08CMwJHk4jLX9xRfFoBX0cLBU6GlgNE1iyC/EN11CZto4f3XWRcr8WporbZjroukroQR
lstmHpN6nzy/yW+Y3ECRVpDPgxhzze1byufsAJYv4VeUQiOJU+fbtg0JO5XFp6gI5jLsjHZ6lHIX
3aMRPwVY8FvalC+TUfJFYPaKHNvSdHTmaHAU8VlGN9YZg+pzccMz3tEo+UQf1mXAVQLRPdtgfTL1
bPsnUNuiLvFkLRnxOMjXQYc5yU3K29FHkuwZKlEcJhqN/mO3H4W0wkTmlZ9wmTn9dNfCXWQ9HLOY
RzxZIGOuxmbImvkavLQKzUaW7REuLDQxe++AoVtctKshLd+9OklE/rHeijk3MlSEfLIxEPTXIt3r
7Dfnh3bczIKPImCjMfGrWBDdShEnrI1lI51Vs/h0l3eTl9ANrjSLmg3Mic75X3TkIij1WToRa6By
rDyDzpcC28Q+joj9vqiKMAEgl9rcCakvnWVdbv1eimmDZC4stxXZ7XdYUBPY8p+pryG1PraxvXTo
3RxiLR+/RvEmQd25VE3yJIko3t7ocuAlrgsqe3wVRayLqs8KEaWodtY8KMPNyNzo4f287c5EsbZk
K7+2LpZ/YF1THhpuSTufFPTUcgyOfocnWZhIXMuuhyWIAJlmj8LPSUCrCldCNcbcAv2NTWT0fYsE
blGLKJYdL0Pf5nC1W0om6wJJhFfKlc7ebP+tbO3HewTyS9mgGdfqCC5bquT5z8fKBuSSl5IdjSgI
/aDOm8di2dHEkVOtkPPcP44ZUzoBa9TFNGcbzUriPSKQZ7HRmoAIftNKcK8rfZzypVV4zPfMigu9
a9PahZ5jy4ZonLtypgX3ydQkcsW5C+zMI1Nx0MvEbZ/H8h5zOzkde4tFseXlNAYzXH0GzWvXx8zJ
wJuGcB5wznFXwE7nxhYAptESwjAQBvoM+2fcj78kZA6bS+E6mBwTYMQtguq6EklPviOcUH2+NeJg
UEW5iANH7SVQ81SjVxbm2W3AMIy/FM7YvTS/DEYJHL0HJhemGqQb+PXk76HigG1gmqNP0oK8t3vM
nnAzaIgLnXvS1UL2R5Cj5w5IGLJMLtvLSATLAd4RPjRwl4eSgkHfzko/0T2aSG0vZg3+43CO5meC
k8Eg2BfIqg/zbv6NwWM3YrMG8FbrShlKXShFz85iJgTSJqCkoiKmmfK2wt/DBn6z7Q6MTHJXp7fs
DflrysTLAIkohTwJT6AzoIqi8ATpNty/EymcnhyYOw9s4vDZRniUu4CnFgtfVxb/A58zk5coDSTb
SVO1fZ8HyHT4ouZAPAVDwvYt7XHY5HNtP9NnbolWzYhOlxp5iCgkiGmrrZFxt6XkDR59vjisoNAi
ka5/BhgoMfoqYW5A99dHiJcjBx0/88rBvt4qhPBV792eZAg2SGrRUhJaIca+9kE2yDWJ1caJcKUi
TIDi0lvbEya4PzTNIt5IN//s5Kyo79glKQhaL4+lwBDnqst0ZRa50UwzPwLgw++okSs8nWrol7a3
gTD5+DOkfzgoohv+BkHRsnAzLNOzpDioC4IGjIMyhCdiUPgBpSKdmTUYX1XkCrhgSkwyRnwUKT27
AkVgMfQ4DTRVZIEAfNNdOtkMTZ4lRknwLFE7adXwrjRf9GZQnrkM/np7WuvD8/NDh1XQBp4VYr4j
JVapS0l9LduXQcSZL5k8SG4ny3shHmMLUkaxxwSPJqg0B23mOpz+JszB324pUlOd4sXAcHKQqePN
7dpbWXT5DNtLWDrgS8slOYhrONo9qcWiCxGWeo9aROpGG+YYOc5IZA0zS+A33vV2hwTZ/+rLPhJF
hwxh/wUH5OOCNor6WqZHUNbqwNS6NOZxvwga7aPlZNd0zQWODbXP6krgmoojw0hMcsNRIwRkmV38
ZpNYJshbqkuvL2850vmI9JVyELzGWa7sLyz1jKBnw/v4Z40OKpv9ZB0dibQAI0+D/dNTT9n7HI/J
MJFbYNYkAJ5e5BWEcG/u0VzSJthKK8I8TavD5crvLTsZZQ3MeSvmyCVm5+zHrsJGaYJW3sFafy4q
GwNnb7jrODUe+XS2+Y4Y1OIV0cDvxPD2nfo8BSZ4rs2q+xQhrnAhmcARV9yxB8xFeQ1Cqz/WjmGL
XHaFlhu48bAeNsgxT6tShVXboBDFmiYi6413Y3wcZI+OMijwnbsBwxLXb3C8szaVlZqbNXytudw7
+KEmov3zdvtuPGAg7ZGqcW4vo9fPyRE+el1iLhshpiOB7daPXjvkzk0Q6Dawyy1g51hSv3K2WU1e
pQiG/fgopCVN+vm8+kOQccaodL/RG5oP8yfy1nn79VHtmwRUo8DGcOw8xZ0i/uX5HJhuBVG4y41J
jD4J4owcoXivoqOj8rUyrB3dghKeZzBuwdvpECuKLGoB2Io+JKVkK10eG7I1eJ8YwOlqK8F4JdfI
+1doreYY23s0MXdPOPkdEd4xRdQQo1CPoT+nD39a1eksjtEU4+SPyWLMdGyKfMtgb3CXmqS1HtjC
oS+HqDp+fzRqZadNMHJ1dMmI5Wg5c7AvUwEhLVhdXf1KH2JAVUo0h2OJNSWdhHZ5iZYIkocVD14M
gUNMwE/7WQmmY5uvnZBUkdjOt4AAbn7t468VUO9FiyBkZszdPCiMVOxmpgKqSOKBfNERYOuuf4Ai
mui3ODezD1t+8itEP61kPXKNAzyWIsSHIqoFZTEgnerao+EAzCVkpe2Ldcwi5LSJCOuSk27o+80z
eTAUHPx3V/RfNI3/OlVxviMnKou0vmgaXEfwd5jEydSiA6gUki8B2sULtTIaK5n/q+GRn5ltGkSx
V7bAydcMVVXGe3Vr2tEt/2PfnZDiPqlqvUy18s6LWh4bOvuQlJAakeQdt0KgCesMY8SsHNZ4hCQs
YabMtdMRzoH9ld2BF+027OH9e7sibSQ9LELhASWUh+yQyXEvRG3eXlgDLUqquuwM0JgXHkZphuPW
cRXrIx469SSzKDtRVtqrZbEiGcwEXy/PvKHKrI7gNUHJ2sgHFqt6AD23ALc04Qh4153JPl+tFTZ5
2d3wEE2H3KrwQAAi+kr06BSz8Eh9LRS8ZPqQ8t6A2hp321XJTss/n3jTC1519SHFk+0DMfCYpXPt
4fXnGc1FZdUakJhshvzZ/dEU1ds/jlrsh5cJmEbS9jnhg/C0WXIDsyS3zjY58AKDjJx+cQHymiLg
3pS5b8p4oP6PvWnD8xoO0AVq3akpyle9axpJiFjTScAszZlwE2Ih/56nyLfhk1+xm9SqVHsjyYlv
aUMsse2ZMVTq2U2vHy3oQDsG0rjAaXRlytSi1QcjyS/ciVdTWDOssWcbH7cP4muH/FurHTswdDU9
SNsDP0k0JmONSis+H72aC8SePAI0LTLeUGtL8EZUTpqef9tvLYF5RvZ8Xm3KRoGMJ4k2DBbz32LV
YEN6IbwEGljTgOeAkD5/+Mwnt82jPLwXy6U2DE1iwRuQKSbByChu8Uo5cy499WzrFMcAiKvDedVR
TPpqzHylO/UEQudxjG1SmRgUOlyJNGQW2a4XTR/SFKg8vK0m1NTOFmIrqjB6AQhNwU2MNK63zmfq
mvxF51jNYR3oM/KeL4j+8Lx+rEVt+JSNrR+ok5TuAJ4=