<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnUN3S6cJlRslrIOuX6rkYLzK6xRC7C85R+u7yDlE/LMs64uGAaEE3EuPowZUW9A0/qZgrhY
TcxQQH5tpkseXJAHR9kOmhTm/57vZZ2bVtjXzXO8D2gse7Lkw6yKIRSHsW8TYd2gU9KPvnLIEDkg
ECQtKj9q1KUkZ76eWY9vT+ZFRvUMRXhLewoo68VTjCp7aXjekkn8XhGuQLcEKwgAMrR+jFEOolDv
qDjZqJRLTIfq97zwEb/XWMMnkw9BhaMYIBJXlg30UZr/oXUPysMTD8bFf4rg67J3yIe5fgGSBeMY
3JbuDuRe+gc2OONrhm5kS0a2vI+FQ0K+pWHixaA4zS9u0g+XdO9Wm4l4fuv7ZF5r3H+w8loTKmGq
hVQO9IN7wCSCP5mJXOGNi724auRLYhm1aQv/EV7slEOdia0MLp2j82SJz0v2z8hJ8XlaO0AEsFjm
uwnXe5WSwzsap6290Vh29WP4rZP9cUy39DeGWAB6YWsOQ/QGOc5rQiOO+uIVoi0x+T0eVGRA4JcE
lYsWn6qMprcZH5SrJZ9q4U5HIc0E+7o9mbw8oNfChBy1xBPZlJtAKXwr/IiqmDKcYRxKHVWUrMu2
DdhLkjIfT9uvFSRahu6VhGq665nux5Jm2ka+mrRUgIAJQNJ/3KjGvro57l3fjJLUPjcKFtvishdq
rbQByxdCKWuKO6G6l8ZYosFv60uKqefJhM/LeNJZ7AmUhRfrR8heiKmtX13w5Kj7ncJlvpwTTNes
rTyDnIAsIIwvn5PKSst+EX0DfTiDJ+BQoZQ4gkC0vORRzl9NJF3mdfRs8v/Ceo54IjASmXV/VXfF
3XOU1gUptAf9RLYHg6GhYTzoWnsmElB4vw+Oj3h2r6lBQ3/QWRhUqZLXlN+iBtcUuO0MVXx+JVRo
EE52EfIt6Dhbxr+T+JOX+xvuRP81jQher4UVfQx6Hk0Er5KD87HhWas0R+Mfm1qbjZY9aeuVbkFW
s0BKz21zE3lWi8+I3bkYhRcxLG3VT+1cNrbsdx0mtMwvxRij0S8NkneiBMip3c1agV8FAbNyQgMX
KQ77RfQ9zlZ+9vXF6yDNPCkxGRDR1zPziFO5EdaIxne0uqh4Enf6A6T5m9mm4d6mHeEFS7YcZtRK
zBmFwtX0r6SCHhQkJNX5ZX481S8uJGG35NfuT/+J6IipyrtgWbuBdR3wzFmg0Ee/lA5D/ch7cs8H
JzJ++aZH0446L230HIgL7Be6jxVL7RTN34RYaEBO2MhjIe607dSUTTnbiUHJcRsfO2jBCVdJfuds
aTZjlG/sPYYNq8iDRQEL1rtRK+IKT6xbwMOekk6CoKU1Yes+pgi4T6ZCzeW13Ml68bghFe4m0N4J
YNPAdE/p3+Owq+InsSbppZZURw/GI53Js6JQOmT58n1xl97SH98onHcLgDHrYEJSn+Jh+gAu/Svn
rFJ39UgbgWtj4orRXX1l95mibCgMkEm8yw9q2KeHtXEbfcBRVzlss8PpX74FYbK3vmXC1Ds93+Th
096UpRH1QHt3CnX0bSmIvUUVU1FbQDiSYc0TPCOUom+hVWl5Z5yP+W11wM/pIXZBSqlMUofFrgKh
sTMdPc1+zRZe1D33hclxLK2YalUDU7qfrM+UQAIQ+nfKJ9Rk60MI5h65fF1DjnAdRkyW7qnBhpLW
bJ+NVQT/br3dZr+eYYNik6+qp6uHVU5xn6stvbeB6c9mfXHdGfKJfyMGCnXlMfkbVtUGBs5H2wg9
+kbJ68XLP4ZXxIM8i0jWytgbEPXTxIOFQh6hGQmXGrbbe5sfH9rt5l7aNIm+GHqqOPY0xE1MBpsa
6DcGs2csC71gpnePB+rx/6xFRWkRacXsDTSHfRbNbopeLKJwcTKxJdtMpvC9T8jVc/UTupvYqjN9
hYSL03cjemPN8c19QJzgPeXxvVoYtQDUiyq6j74qNOhR+bF8yjipE9cjWXsiRmhWWxPhQJGoCZPy
h8YKN+WZCDLlG8Yvh6NYcyHfthsiUQ6xp83zmW==