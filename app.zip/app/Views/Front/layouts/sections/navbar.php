<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpSuG4nhbRXZSldLRnMnjj9BXEtyPV7Rmk62u3F6Vg2GTX6UQ7wWAGadhjZ6EeJXIpSLfqBP
0vsGKN7rmaiaTOo69v3T9T/ltHpgOo7qU0XMBLbyWYkY08lWwz8FmztHxxr2QuIcYDKNnFuU2iC+
x3OE2YyDylvZDaAbfZMmrSfJ/gci42qN7Sbj/JVE3acYXYZ3t+s1CP/jQze99l0QzwcD3n96foeR
6DWk3swsOt+sdAYBIdXJVuwh6ZBng98NvSFSD86Eb7DkMzWmxFyeSatQ+elVnck12JCYKNgV4UZx
p6gnq51qif3NPqQmXKCPDzkRCVfvbrwkZUnUqWRFxn3q20Fni1okkPvra/wK3HO0OjFhSnQrOwr9
CiaNuo+td087TfoxLE+P9up9hD6ZjPeoOXdwv5kzJM5S0PIzLOk3LO6yQA2gCqIgJIobDNieqJ3a
VmF+o5cN4IQGVIoAbheDrQXPk9ZIFGuUrk1ozZjQKI5FqcipHsYkJM/R3VgwZqus7T5lFqkRcRXG
f13ZdssfX3GeRyXe7Dk4JoydfcC5VyhVVrmKFOd7i7IhZJg1e00NZRlAqzVJHwiX3LvjPcVYBRkH
+O7WhOKXSbe6iANCyhlzeW6rsNc2yZ9yylegKZhdWqfj4Vs32/ymA5o/St76dWv84GTVLkNmLdc7
cbw6ivoiuGmX4gaOIkamNYEHUj9kthv5EqNcLUS8j1stbOhHqQ6AqHDgUk/0GPf1KQrRwgUZVzXU
Z8dSt1WQA9ApMJWdiR/fdLMh/R8Ubye0DN9kRT1biL3y528u+uq8t+jvrYwvpt1eIz3zub/cmWCe
qjCEFbVVEIg1mughd4/xcfnLBKjRPSPGqhFC9e7FTRC4w2aBKlMnhFV82nz2+dFnAp+5ts3Z16+a
rAMgR95jJo5RFhpMfkRwH2v54u152aGQBOEiuxZO/Fic6QGAGJdPumsLerc1Y/Q9CpGWcCSF+4eQ
DjTHv7AYY+yZ/vClk+2bllbWu4HWUrtBk5qnSajxlXDe40yQnBKxLjUD6k4BNqi+6vTElRvwKZYd
XGV7jVFo2KNtOsZnxjyY0JfaEpPmkp5nXmvYANv6dTZ8W2tch8ZcYaUnZ02ZIl1mn2SglDtjCRBK
10B7Aqm7wQlkvpG/AAPP1GZtIQ1GFgJOCA4rCAz0LE+7ZI7t53cIcN/cOqkPHzPfedr7aVGMNT11
3sO6uGTtx0BPXcmr65pSD4+MAdOUy/XgdjLRWOgz991hqKO/12NGAKKIivNFnDL0Ro7mDc7sLGCq
6i5F5+XnLAjWljB2e3RNdvglNvD5EDQbwFf/aBSK2zcqcZILAY4MuaLiGdZy4XLC4emVJBRbcWBv
JdMZtRPTXpgz