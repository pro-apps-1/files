<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPugUP4mBCLraqbtnRqjeG/2RA5q9mmetfeQuj9TVtj22zO445Yl01Ry/KLFw3qCYXeSn0DwF
EVGzCMpevnNKkFljIbIjGC+7o8/YW0aIEOBH2UMAl7L8lFk/C9KC+upDKn4rZ4W2WaPndui0Vbyi
WQOAW2JCsy6cImZTiiI6NWQkxeTsbZa+XprnDncHrLBM4hR1fr2JvExQQG91a8AmrYW2srIhsGjQ
duwrs9d5X1p7SVIhSuW9kC3UOyp8O/eflQf7BFA8EKV1kGqKsfbxMrk61Vrc47uduLQhFTH31nxt
ywLZ/nvdLJi4oAbx2AEj3SjbaG5Rvqs0+0YS9L8EPxcSf0Nz6PVoLzZ5aluFXn7xwc+eYq9VWLGO
y6KXht2Y8+O5T1z+pizhmdNor7KGzUcu5oRbEhvk+psbMwgmbFCc/lKWUOWdywnBdbcoGSeodRYO
yCV1Zq61WbRRQu/heliAvUuYDxsCBRPaYwUkPUM9IZTEtIQhj+d74jh08e//eHd9rcf5gQDkGqQG
EG5LwHAHDSPTTX1QNhv8O6GqM7N0Rsi+uXoE0LlJBMq/Ts9C7J6afzwyOP79jFj8U/PihVjeCmhN
nveQbeoFPDMCTugfdzx0q9wmsSAoDMB/l4ApW1iT0mN/LplVbIy+xop9p+3UGDApX9R+mycBgNPf
EdY1W4Pnz8gwU/Kmpg5aC+/haAtmc9Bn1uYRzMbooKVeGzsME3HJxNvW7VRcr5YPTzXAWUv5tJ+p
0JA+0++KB/KHsmFKlKB0Tilkskwz1XVJK8NchNNLc903XJyQoOJZHoNn0SLUJyfEtIJyhJAwo2wr
DlhF+7bvKg3GN99n1sBVaucBczG69t8QHOdApifFmOAVTseRdEzmiRQAWfPZhCXQjRl6Kur4H3qM
T/q3wDo8ChfADwd2Mh1rP2wAKNrjEi4o7yNQ6gjCfPQ1eNju38pp1801d8DlC/F5LTv2JOcsP1Mi
nVdKL1CR6lChjvNVxp/gvJ24n2BJshikb30HBtxcEkBzE/hTh02TQJAxA5b5Tf1CD/w3g/kZSSdY
5gnf8oyUUoV7exst5tjH31+/aRzJ6cL1EjwzwzeXqAqG8KB0PUb0KEkj0Hj5nridapife76Dj0tS
XTu2hAjLWddkjGGQPgKREMfhBMXu3k9mzO6FLYrOUP83yiplXWryMqCE+sKn/jChjnsiJmbSePC/
g6avHgfdwTkYoosVRlh0VnUy/AaSEyDUArElWWYA/o9RW4y6fOfpiT9oIoYp0X1SxPKNKnuxWWsl
Cb4b8PkKi0cOySoCiXeEIw16LnluZU0VldYlI8CdGu4OC2VzGs845qCESa9IcsTybDDcXMsMBemi
htAui+2XSYpNHiHwoxt5vndu9gOnobKKwcIJion0XvmxA+0LK1Ri7rh812MiJL6N3yC7eGKrjF8B
TiBQfecf4Gy4mloBXfo/dfmQNYfOFGv9OJlYsKCsqOKmOBC2KUOOizcRLeuLNZlqXrYtUr6pG92y
/E+WzLR+V/yQ4nMaWkkgp+nEQR/xp4yXOQTf/2nGwlromwxLDlrhAqDslFhbGsFD39xP953YILgG
EbVf1OvYjch5paQgBa/Nmq2g4/vDN7Jp3bP1YTxFFJwC/czU1deaV1prPPoTmGLltI3skdnWhnoR
VaP7z+HG353PvP/ViNf++Lsss3+thIUdj1c/iDeJ/q52/nzryigDvhYP2sPziRD/j5Saze0JGpOJ
l5MY3A/KaddtGSmQDAY+UBqzWYiIYNIhUjPeyOaIDXC8/WzEkF+1ip0UcGnox2kbgjaG82p2UYW3
wcc7dEVL3Gx936iRO1PShsRMK6d9vfJZWGnH35e0kLpw2fAt+VB4I7q8cgKf+UlisufeVCADxZQN
hrRAZfmP6N1C6lXXNtLaFqXlh1Htp+2sxzbnyKMOULdndqWEEumOrdp4xSQrQ3af1UVy3ctOCquK
u67Ibls3KayV6X/7GVg6h35zEtj0SZTGJ0dxAu4W0FjuUaWxest+e965918=