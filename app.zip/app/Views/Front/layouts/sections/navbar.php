<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuH3RyiT4bJjs83ww7M5UpH5ahflByxyICP0bfkT7vadr9INthNj8vc6kU5SXaOcMA04/HHN
FmazShSFNlcQkvgIEhISdEdU4YQCvnd9L+rKzUx2BShWsidu8/4Gp68hsvhHEy01sC0PtW40QhXc
qowirerfRgKgB41qEvaitRD6K28lmMe4jscWbuV5A2J7TRZD9nWLph0p9cBbvPtfLM1LZKv8Gw7y
iBTLoNP24WwtrwEZVaL/lb6mrTl7BeOorly+m7KXlaL3Uh/9X1QHvBbCUHysysjrS5JPz5D7OO6v
mGaBnbsf2SCnDqcTpFMKlhSi5iZ46qxppfus+z2YwzKoLEz4/qe98sLXd6lZAnSbzz4mMEAzmhjD
x94Cy8zCRRi2AapSsbAS74h9P8VwKoMoqpbsTSzKOuOsDf6esJjY0AGhKKOLoNi0DrfUD4Sn3933
nL8WMObY6V75octgcy1qTbVDUDBg5FQavM4YxtyNimJoABcGIfzgesdcZi3jrnhHpEo09aPjDA/R
+cL8hfqH95NI7usZJKRz4Z6RROmjWAx0YkhG89sSKR2TCuxxPczGS8zFhwHmGdwCHm870PUyoou3
PTcjUDQhJD64Mc9nKdhVGohtBJIVm18F2/BKAKYfl6rFMzd04lyRQHW2CouHsfEC7XGHfLhWEke3
xsRGX+7HIUpN/0tuK8+B3W7zUFqaY3CXnLvK2Qwd3DUHtcOxDuyEW+ljrV22BG32df3GFsmWT4bW
LA3tG4uxnVibrVxe5JgdO+zlGd5SkdDPz/j+NaJzZRiNQ6yFnsVQdW1BfT3dSsvqzEsuKuxok57a
SRNW4KmtUlH0nQvdBQONiQUZYrBefYqUnuRZCuYMu1vYgTr8/jFWrQ4UkNfMovBBUyrHHjQPY3QW
TX7HOtm7vuPFedc3QqsNurPNE4IjrdRtycKLDeuWx9a0uidSd+cuHngyyJ1K2VofHIMTjxXa8Z0J
dPgS4gnzqb1Yo6qjyqeocoAaBKuErERpfoVSvKOYjkaNQ6b0uKnA0oCC6r5A0O1pit4QlHQis11b
DuWqpaDfGC1L1yMKlCFXYu2nh+2IXfgPkq96v+Sw0FEQIey4hQg23XTtBEOCAo2eQWV1u6Pa27i1
dGB3+LyNM44U32cPDHWbvcIcSGfNBsnXgJymb40r/HbM6gFnz8MfRXFAtCm9AWCb/cEcpRYouOWa
qmzpYVrJPJECOm4mClkhefKT6vU30dv8tzp1IRGTY7FLczrvf0LOWd0RDXXMKSGSHmWTBQoMOEXE
6PGbUsHVbQKYaeaHSE8UXcEi0ukHn7Q/ceYJJiNhw0ntSVfyeaSml4N/2OL7L1yR5VaO7AGo4UZQ
lPSD+7nRnrhmkoFhiSrMo4Z6ILgETBKOdMUfxZ/OdFlmLaLhsMg7tEMTuqA/dxof6lJTm8/9oclx
BNoaG/bDG5hPPtcQbdGnnhvdPG/Yuhsw4xRpxNcFH8qeU2w5CtKk3snXmavxikkUSOFOO/letUAE
gHrl1HsWq4HQa+Ubd+W9Ok6mwXYV4YaFBx/5b6LJM+SJS70mx+gBuk7lRvPZnMkPWcyH6l8OmXKj
MVBHweC00z0JjNtjb1jKzPIIJof/u0Td/NIdRaLsccXLzaYJ/5A6k/QtwHew4K655APyYvuYz6Jm
0nzZqh1JxrEqGMEQ3tck56FLa5qfhhrSEXNLWXFTL2ocqGZfwEHhEBT7tJDzK1WSN6MfHh0FQIez
LQVy99ucpe2n2gy/pVF5jqihqB952iXbleYwzx98rnkRJwE31DP5bOtjZzxvpt6CPyY+sPGqg3xl
Gur/JSd0FL8V7MRPoykxLkyeGMIVZoarVClqDmvZACptilsqCqb30uKkpMUzXhaxlKP74nqkBZzN
qvuHvjsQm9e1PuYFzFQkFttzl5UOZUhGkl8+R6M/faWlAChhHdPPfOWxVsumRe/qPbB8iiT1pypI
SfiPGqI2gHgJ5aqi+2C7JrGqh0fn40E8+7W5vd5LDV5ZQD6zYtkcsm==