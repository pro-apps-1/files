<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoasW9nkgNZJT/KLly6QVJS4Ou2Mk3515z5hmgNQKNNpTF9DUXr/G7S34VT9mhky3XkUGmIv
z5ZUpLzoTpRyIVHdIVtWV50HDdjnAFtpYrx7Lk51OZbPwM0MbnkqPIMU6ZOm/cYzuxgcjtGQDutC
QXAIaZA3fkmVL6ri3F6+Y0KjxeiwEBYiJ3cll7TNjeHzrorr3B0LkiqPVxTwGBA+UlMT7N7L9FSI
GafS8REQPSzhOhdvxbfCpOza+dc2/n+CxM04v/HX9+XPhbv11mcj6MAwaFieQ0F2U7FKh37k8oYo
WOkP93fYWfKwwMpbeN2I4rQhIugUvtUMgoNKW0P0jPe4b3Pae4ARyRr3Cshe1sh/H0wuzl3H9yab
G6vzjGohX2G6n38vEsJysijWG7FHXe/UdNOXElC3JCVJpxVT4I+UGUn4i74dJMb5vX49Zw8Cuuoc
FgBzOIFkorzWRES4bD8Z4ThCM5VcltRM6cdUk+PbBIOHzBmJVf33x1scxkSMiRcQrUiX/0O9yqPY
PiUhPCbnhamLLSIpSWuOgnbZL5xKSkuFbkGsotkA5+AWlTxuRaAI7HRV2OV6GwSrxHu2QUKeHTmf
jkbSHshv8RoQc8XvMahFb4lGdWCxVQhDPpWMiEh7WqeL0bbo/sfduTKAfGxXPLpQj67+SH6RoR8x
wb6/5ohRhrrIpHMsJ1lmMhf6MrR4utGCernUTPONwbGmVjqplKrbNmGD+FlD2mgplFcTwydAXWNL
4vlw/K26IGweILYmTYw2p6jJjytDOYYSkrXGrQ05TNyGLTJ73Nljlx1+D8GoYAAZcPcMcpPU8IQD
OYhc7M9MRuGwwSMA2+jT/IXB9Cbu2Ef9+bMcENeFLovmbOht+VrhGqnJVGGSmx7uaiob0oB1T9eP
dUfSg7v8dBDzPlfQ+HN1zTk6ZWeaSmsr/zyX5EyV7RUB+lz2Avw1f5Co8xA3gInPUjpiGQitWh+c
6IoG28JTuZCYQqcJEO4XYdSwRvQtplHk0nsrdYzid6Oxof79gbF87fa1/9FGAqSlNSf5d/KYhium
Q3UybrBvlZ2ustPc/6AeQMqHiYni1SfVIlG80pt9GRmDXhX6Fux9JfHbwX3o5XDZBCl4sZj8YXEQ
7Xeu68jG6fH71E/Q/xsyCFWQqOv58xYYzTCcZGSZy7kAsZtVLFdGs+AJUz10QVvaeK82ctZn/ovN
6jjxiQmiHZl/VKGWNTgOH2kSOAlkVIzhjqKotrrg8rej4pUvcHilOMDnUW2W4mrTd4x9DKnJN5fs
rceATDQHvmd0M2H+VPVGfQOQUaiIE0Gudm7ZztxvLvETyzR26fPk+Yj46XW/jM9qGt3vaixKq+zo
QsxDMinkTx/zG/QQvIwJ0+y6hFTrjiZGRl5wO/LLgRMEAFf69+NVuzrSCN4Go0TM/hLNsyGffg4T
TyyVKeuG3RAVUQGceVR6NWIvaX5JQXkPh6VRGAEaWAopfjRx0XNjos93ju8zmH3k+5T2n4O3CWB3
FlLElghZ7ExLpu7P2it52dx6lRFSvbsffd/xlu5uFXrGBANe9q66tFDGy0VKZhLTZZG5KdtXh9RX
mx0Re60V2oOFEbpFAGfBt+b/CdJ3+Z70stA94JabPupqNM6TdAa2qG7VxQvj48JoDTDI/s4rhD3D
WaDjukltDrkKAsKoRwmhwI2ClvGvxySPDFmWzDPcecIZWQn+rawsyxkdEII1CEqYo5OsGHQnTZkD
6UXnvYA7NHcNnyaZgGO7w6RSWvGSQ39bSG9jC6202yxU/Vbq0NZAxw8OJHhDYHpEsdwPA406TWjj
4cauUgkeGvpv2xtHG6oXZkVrwWRKEYaqDkE/mV3do+e34LLL4BC+kT9mPV0tfBMPha0WszcczeKG
XfT6HEb0poaHwzn9pWwpb1WkHAmuvFVPQ/eK4UbhXlI2vD+1iRsz8zvaf/JsAqJNqPepzlVE4yEc
eu5a8VPsj3tjiJaJ1lzxAlf5jW+SqeTE8oxGt5nEIrRElVo1O6S=