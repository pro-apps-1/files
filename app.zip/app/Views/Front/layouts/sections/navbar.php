<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyEWrcRxFIj9Wc53HH0SsXLY6adhvBqIvvkuq5KvUOMV1Deli4MJdIMOp23uR2jOPX9NBYyD
HHAh6KF7S6xjoynVz4XyTWfZ+v1NfCXVhQtXV2/wS/kK/SlRtb2DZ3/XUJLOA0faGCfpxI37gKMR
soiBcCDPcPlBGWikHKTL5e0el5On1FySXSu1/xCSka9OxjRCmLcITKa90VPAzj+P4EHug7yjNJZU
nrwGD2kKT1b3Tw6YBrCwyZ5WMrY8dBXl0DAt1wkSve3f/SmM5W9QCEVAiXbb/tzf2l+V45RCeKfF
hYuk/trIsgOjO+py2GMQtvERXzFSKcrM5kkhP6K3ghNorRzaQSN991mRz2ykKuSb3nw0wtBQvx5p
XFKV7+82zIrRrFcsQi2YFKKfxaSDt/mMEfxnuieUmxU3uQYpuXRGBmzk51bZmYn3nPi8MRjkNBb9
adZe/70Kp3hwzZMZuLJw2NF7f+FhYI/KFs9UBTfMVs86SSXW3wsUasypIIH6r30az4ejh50rAMdF
KrgD08fl0d8T3YlOkW2pChAQ9XIoFViQAO26xdk5IJsKMFomGVBdQ4JOHgWY1ui2DbpzTJZlhswj
BaSUBPSFitBp0ks0OUVZjwJP2p37O1tk8IZS5rn19mhVCz/1iBZ+7r2ZOLhKn+GXtMjmUS7PeJVF
EkSYnnsO137DFII+R5omYntkhCNJ2USJvd6zHYShGD3Etd1I6LYTu/47wJFyXtUB8UP5J6Dlfy7Q
uVcr+wwTr2s5YqdvmuQuPlJuJ5qKphHwKmyVcIHQIL3pUjw4qrB9pThhizk8OeXBytkwexqf4HJt
WNxSw9+GUzfzXm6pnJVdAu105z8b0+s7avaGngV6oOX2AdpZOeUlSWfKTigbc3IiY30xibMxch3g
+W818DCNpXqceR1GXGvvAE7B5eEtu/CorqqXc8g7I1+byfB96E9v4KUpC+ff4rPEXA/A2tetHmsf
9UjNgAdvU//eSfqYGPsaDl6tmERQc5UFOv7hvULNswlFuYMTCOQxrZMCE+qqw1qgYaKrbAYhf3lg
Cu4K+jAx9MYCqrAeS9GSYoidHfwWVjpbdmetzKqWnzhFM3Q4fPg0q/ZrLMVI+KmuuuEXfzrGpgXE
AU5BJQYTot3yvzgJcNFDV+M9joyp/A/SIcWCxq4IvU2rcN7jPVhvB5pMMHRGRh1/805RHctipFvA
iT8WYO9P0ynqlSwCjLUYivpLZfnIh+M+xuX/E01/RQkFQyMIxGvkYEt9rrPZWSiEETnauOiINF6r
eXvojPAkiG1ytpEtPnzknbZZdeAB5QpdWGAgpOHd3n4p5tLE1WNh2YNU5exfKnA2EkeEgUXvwCsV
3LClrQ7TAu+X8frOb0==