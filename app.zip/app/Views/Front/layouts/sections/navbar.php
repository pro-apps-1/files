<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzSv8j5fb9RcTFgtyYNW+E3fd3dewTwdQwMu77RDzhAWb0viwFKLxHODSQ2OIMX2orvj4NEH
GD3aFizGjgZPLzkXNwi6JAqIA2027koey6LODd6dGH9gyuhAV3jMx0wq6uQvXnjfpLlVSbng6WE6
UrJxoBBsJs3C+UIBQXgD51M3oS0M1uU0Xn/zoKaiqRKvtsfxD8zK5boF6DjE8xrVFVDGRNlBz+XP
Bs0EC9+vjaZSwnfCHC9DmgKF1ebwdn9y6bHytLI+K6eOota74/8WrF47Ja1euLjHro+/b/lD/A6A
YcLj68yMBk5lwJqdlv9NvZ1U2nZxmRV3TyruQ8rfTuttxirOeQBtSs2VBIsW1f/s7uQmhvF1ozr3
PYpxc58P0ccdnU4UZkjc8Uo+bKkF/ZUGDGK423w3MoxIpcMJi1DHh9lQvpXwoY8MnjfuGXwqdltM
2fgRcLjvYmT0v4xoW9mXg0C4U1qvgTbhCW5BQMJAkq9WiRBfdtofRqGY1EZmrjn+XwxqkMDJOHNI
z2cNob1OsdcZxEy6TlkbZMgj270N+hivsV5EH/YnxnvLSHxLZLUGuUh77ajYsf9hf3w5V20OW9kW
FvtlkUT6IeXkBVSjulVNZM46k/Jdekd0aMe52siPk27wXzN55LjgmrU3/oGnWvYwSfjhJniMcR6s
0pU2x7co5ddxodFUY/NXRSdfE+d43s7Y+5sr/ehPjo6sMoe4QPTiSDCoHd9cD4O0lHoTbgQy1cKi
AwQhc7LkRx5wyiHtmZcLp08w/W3vWQQzQuaIED1nnfk939HM9y5yVLs524sQ54VMcRvmgIqt/vs4
km+oEa87pKqR28goffpNFPsLZsDF//r9bVOwAcdJfIG4VEZvoYl59+sXbz2TuY7x9QMsD7DHxLYj
bjoLwgd0qB9ONcXrZrjxqZd/DF5I3OwHiKPuc1Zyb0wY0u+FCKQi0/qcCZLxA6ek8CF1ybG4D98N
UTozxHfFB6kwMqWL7F+27wv2BhpgSeRyYR31gHN70NnsGsEGVNRAE4ooLskYarT4l+xViymtrAP9
uikSMg5iRfPlGvLfCYRh5LH+b5QqFjZVGzWm2OnGGyskSnhrfSWEyKByaUzNdtpjMU+kR2A5RWVD
ghbJzMeD29qvRx2O8HL2114vTgZcY2d161qgDWCgSf9y8tjTrfM01i1jAz+y0Q2iwhj68jsldEpO
DGOwmA3z2vD0wLvp9ZQfj0pAydWax6WCelYHrXaCcSIuYNjKegeDGmYp0oDTbR6i1i4M3brwxOSL
Cdm3vHdubeXWSbl2lUu1ewCx9Z0YkafYjIBLzx9QqHfXtp8RLOK/YLnS/urfELWkmXfzxt9ZfxvZ
Grkrr/XKss4U9/rdxxSGUr3jOidWj3fjK6qh+KeHMsIW16+xSobOP0LtxPc3rUcoRBEwkbgsNRkb
7HOHiqiOODrGQzMVSiuO273fzgymm2Oflr+hXF5TpCNu6p0vW0/icwojA6Ccac0L2razWzdlQYNe
fLWUp8Abko3mPyU3hth45aXkX1kYhn6jRWnBCkc7xkmsMa8KeFS3qFj6BId41R5g0+/qUoa+PYa0
DJgt9SCb56k9ZUTdfRDwrx50ER9v/eVApvgl1+PzXToP/lfBJeiRcPjgqjcQc9l+0YLbhDSuAtDS
DDmB9Y/4w60q0khZT43pTR1Rqo5yGz+HS3Xi2OcEWYPC/9VVd/9lHWo83wHOrAwsa8yVZ2boNnLX
IF2Ch8ui8ToV6lKS2gAeU4CaTTGu8iAxpb1MDpcy+l6ucRpDPDgbaOPogDc8/VnouEJxQLjxb0Ae
Bc2OSKMaqdozAIU9Ipc1YOe2AjWDKh0dJi9nicLdPGitKSuip5QU2DS+WJfALCHx1QUzSe6ud7ut
MAH1/hJJ1BRkdGwuA64sgHBUKItox3FDEC53e1u6jSm+rBntSRf0yCamBNnQs2IJJe4K1cOWMn12
rWW1pYGHui/SYkjQWj+UJePeddIwwHD/j7CcN/XWjKTv8/8=