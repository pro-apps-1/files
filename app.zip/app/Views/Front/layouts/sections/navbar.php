<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnqNP76Zpbn7kjJnKf2xYQ24woo1ZrYfGiT1elu0K4ahuHYE81MRl2tDxSo3A7m50WkIKYW+
AqnisOr/abYOFmoYZnQphNB/JJjrTwadjS4/jNPGH3WXllYmdM+OTazUhqiQSSzA9PqTyyYMIcGp
mrX/5VHbPVZ7YVA7rFudyi+2+/5QpHL8R1/QoXXJVL3WCoqm3Lg9/HC7mwpoKgHbfloNel56CMxo
8Je+SuTmd9iFxiOq/4DnrY76n3PI7Ap+cy+DAQSJRT5A8qsaufIGbchEIKHEPnFlTZy+o+xZrfLn
BQov4/ygcz0qaeY1Hcwt5FWfisH/d1gQSlgpm7jwrNQtLbH68IWKbuWDiN4GzlQX+7YSNtvCntDT
PfAKYVRkxyRKWAQ/dJ6NrmYqPrMAoq+XDdq1luXoGHe3rZDHB/6rX3CD4vKX5RsJ/epS8rfyGstY
AjZqtuiN+1T5khzV6PwL4WdosUr/yK5ySmme1Y7/UJlK80yM54KbUohmGbkPYpiWhncLAb5REh1X
zfuYrQjiR564rsRsDSti01XfCXH9V6Y2D3WVOVNvDrwv3HPvfFlrpofSBGsFue+x4CBiriFzzkZb
6+YecFN3cYtANic7en4gPUR/l2aLjlTlN0w3N1gg8LeaBNq6t83BI6brNt0LNKkbDwGiggAfOWcE
nFk4hq8Z1JesOwcF4HGoC8mnHXnf7OG10D4J3jl7hzq/ZnGOIZdzwxU2+WZ7g+3GA9ZagJ2cMJSk
BIOtLVnKiP1obvy1iM3o+PmrD2WMcPW4E3Ub7AoslgP7Y4GRla1UMOmIK3h5Ujpsmo6wgVOq9zGs
3+OwzcM/I65sOuVeq6ISSUpbHRAkvYQ4OCl5QRUAwE42yGBQNedLWc9/YzVHrcnU1doOyjQEHT2c
Ie3GgLyodNx6H5EomhA0KKl3qaRnUKX0Dg30utCDALL0LGY9OhaNueOpARKYBkJ3T3gx353g1dF2
yb7bNtGnQsjsHntoB+jBYWWqaEzZmYGexInH7GTCHsKYzbvSm+JcQ+2Xpm/oENp7JZxMEhwzFq82
BZjU9O5VPtMNc0OLCev7hYpCA87AnfXyIAHW8F589PwvOG6nTuPAaIzMr75z5vDqgUv3cWk7PZVj
xNxNqQZnRPyvIJ5EiulNNeWIIZuC00sW+1sm/W2qn86yLDUK2wEvJ3sFsD0lrajd1xhL2q+Zh9SO
5wksJ8+hEI+/NPm/pFOU3jxnEzecTg1EqjOQGIFdJKY08OmOYH1PaRL1E9p2B0BeZfOlr4jski2V
7RqpCcO3XUA8l7/TYen4u+3kdPQid/E9YfyG8QpyXwPRLLEA5mEuU//LA3Bt9hP2gFwCUGtAOC3i
jOTPg67Bhcck14VgShjR9unjhcxn8QDLxTPUrg63oM4ZNHtIuR7tSQ3PMw0Xhn4JGRt0EGqXaCjZ
EaXKylpPUj5L1ag9A3+BNW6C+C7mhg03bTsgNjLVASBb2Y0I+9ToIZsRQT3gbawcDkRb/jxagNWX
ZvzLLt4FHTviV2bLrDio97wwGbgWlI/SoqSJIUWI936GtLGbSrv9QQDFz/Q8XAJ+Pt6wq9fQz4sb
GB1UoSmTbhlq1VABuvRapxw4uNl/VLpnuHUZ+Hwde0SC3RrqqycVyddSZzOdU1H2tkSPsA5bHd3J
p4sfQtZndypFdbj3wo1/Bd6qDVTkHYVRMkh6fvGpsuxi7Q4cuEr5p0CooYWaZDJ2oyW8SIwBS7+F
UB5ccRi6VuZ5NVTbnUfjdwXSu7qG4diDku/2mLfC96qG9Qn/GRaj4bCkhX8YfJ+8lcDdI1VsC0p5
dkeGFl6KggYQlwDXDzQ2cYgSwNKgWh81FsudqAUNXU3CnMn/7u2Raj9ECzbxC4gBr1lk0rjpFxbx
UNGsEnd5atDz9KmIcptO2h2aaeRcFh3/6PHKCdAMl6jR7zqdR0p8lrM+qHO7pQUnp05HmpBW1A0F
jbP7JFbny1YpSGhmDRzM6J1gZzw3o0C21/+b9tBekW==