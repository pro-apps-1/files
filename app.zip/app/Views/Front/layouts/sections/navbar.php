<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpi3YcI+tmvBHy8VHyEyIJ+rVHLFOz7WNPouakIxz8NUC+EgZtxtgMGXK+q/ptAKDH0VR07t
IH8Lbct5EuVhtNIFYGdYAwbHbAg4u3/kLaIdRiXEmNojLG7pjZb3S3bmO0zy2azII/rLoC0/FJ2a
LFP+fBPN4+KshcvAxsjmME5zI/z2OSAAMEp/o3BiTun0kcObkdmf8zyqhQ+acJQzw/q5YwDob6Zj
eyzKpRr2GqZriANXBXQXfVsvwXlLtwHM/8pCcGvBj2YX+IbYrpdhsNBPbLbj/5pZaZTcyWV/ZlbZ
J70T9zHVPtzTLD73h/wjRY10mT5DxgvARuNGF+Qimu8i3+uWZrlctSwwo9st8DS2fVgFDcPQwRPR
GXduo476BQTZt5+b1TnwAizsTw2ioURXqoK3L7ejtPYQ2p0bvmAhOv85CuuNQysWbG94aM5DE1D8
rXlLhyw6RQHZU9QFMOPYfQeJ7IbpDIV6z6qrPDsXU8u9rSIukQxqjnNoyMmDZTnLx2ysrC3E/XAT
wTVSpT22x6nebSCMWQPZfIwOCY8eGeCfTVyIzZw7LdPFMZRCGsgkKYREakybraRWLiTeCSbzSAPg
oyIdRmmUjmRG7+fvs7fpddGaQvf7ew5tVz+26EckshQa/pBuOFtUE6fR/Pa+FrEurwGzs2bNaW3L
QcyQGZ9sup0u7Ys2amkeUxZfAss/Hakaw8IQgqmiPS953Usvwo/F82/GA3EQpHN18RjS6Cv/7MKx
UL7uwoNjl3JLccaU4hObcDw49m0qDjuvSUG8R4TFDbdkazJC41RLaKW5Aah0ifMGlB5qGKQtV3SJ
jWZtKF1RtviqnBpn4FD01BZFp1mFyMp4dDUB55mFyJ1hRTuuqbvVelbvaMAc7wJ+xeXQN98j+hmN
W6Ygxj0S4kENIS/V4DwjbJX33eg+EYSwy2NUl2dvkLan/kM0T1Uo1JWPcF9e41UJzy9QHDyt8rsI
raW6jbYBLYUlL2yL4E5unf2eNAPFtSl04QzknfJuZ9EXW4bwI0FWwj5i1McZpO8sMqZNLBgayifj
P9H66vgoiS0xl6ahaRtib5MrSSOdXWCzwAplNO9xtlKBSwOmAJTEL+RNL8LfnpR4dbJJjVIrisHx
dgLMhffN/eiqDuR2/+azSiHcU+FhC/Gfsmq2DQf0WujySon7rCqe+D5d6Jlmt2piYfyWfUJHYkZG
Ro6FLEW5d7Vbuu0mvjS6FVLlFsYq2UaFzASJnIxIkjLADE81xO4OriwBfLSvc+bKD25CRAezguCF
SGFajUKYbH/ftmANdYYzv03Rgvbg+kQpbd4KlgSH/VBiG1/KXs46FwYUX5Sv5dMhXycsJjix7oAG
/lLV8aee9p7ArbQmq9XLZW==