<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsBl+sWdPi1FFYnkIoKqneRSnZOJqDTbdUX0fMNunH2WzQ/Lr+Gt4I7gTWhyooCYxgf8xG8v
dD62xWSPn/lTIn4xENsnwJhmV+yi68EyMK1JUarCtaH8VnqTdCTKsreJ5SCHFVA5r/drA56fzGwI
Z6RYLbS7Qn+hhinugoc/Y4qRrC5PWmU/tI+m8iYizncVsUzFrQCPO9EftPX1rHHAnL8Kwt3obsMx
cJQ7eXt/Ue1Aa28Vslipj3vKD32ogo1HsFKZ4TWV61l89llOWL6IwKXuL1ehK6dXauavgrt0MU+H
mZqDUJB/ZK5VfAfb4TYxU6f3Jb0wtLJkdPoogRPv/qGLa9MB5O/JSXZmU32ReXKUNZ2i33ua5BPQ
LVKGA3d8wFBQjeNjCqFcxT3bsgBfcrpFnfYlTU35dmZ2mfWRWZbpgFtxkFSkfExGOlmUdXQC2blV
XjxqOEnruDvY+AqU0C5YdojmlQ0v/RO7sJd6JZOiPHZlgPUm+xEceNJnspu6CkZ92IdLY5lv8PWQ
aJUliJt+fAn1yxzRhj0BxfeFRC8nRuwNqQpK9sVWCPlGNESuNGG9DFAYyNz/iuY3Ex2P5wR1eK7u
M+IKOUQvpozKT1VlU0bgL7I2/Y/4NX0G89kWgO7Eew7gAyKJUfG5udCujGnpS7RwHxzwpxhwHyK+
2J7GxY7kAky2KZ6RHxNi7YhWzFyDq13QWE3WkwVscjdJpq7+3sG4o5555noKiFFbNdc3FzqfbFjo
FOA+0Nk6c+nN9rEmNAUq2dj0gsZk1ciQSH8stJbesKFnbRkCt0M1cMMCqNTOLLnDEnF/imEMpzcW
oFbJQUkC8sZLW+OA9Wk2BxNlon6Uf5E5Dtffo0kqDBrNa3b/h5WasWKzeL9/WyBMZDIicK4okPpQ
xS3SY8iK6Jd1FURCtU5YCMYBt89LDxYXo43btpigJ8OQxu0SKZLR98fIvKDU5MZwSnVu0lS5zqRj
UW1ake5xBy0QEHN7NgQ72i8sh5VjT+2mB8g739APDVR4LxrZc4QmNBLe5CP0DIkghv1CoxsXeWGP
Kqp+qJSBrET8jPf+OIGWhnkfucju6UeX35sIM/iTZniWgr+OVIdKqdPFCA8D8fYDVNY1j5zHfM1A
ZD16CCgD1Fh8/Fj4BK+rUZJglRQMsIk/s5S3Tu933eApHIM/d4gVeOvr7qI1UISAk5XSHDNwC3D6
MXzhZMrAAQgULTnl03WbPf2PNtl0dzn/989JiKYrGrqO83EEfqGH7r/GBgoxMD2jQsfCDQj8bZ8P
ax894Pyf8Ydf2kMmvCfofF7V/oPd1BBpfk7hCMVhH4BcbstJETWCgmiwQFp96bkHKYJ/dnIaD8eS
lB6aKf9Mncm2KB2wIKQFP29LqpgBkQx46Kx2XkLWmfQ3/n5LFsAEAwj0+DfIY3MvwKxUkONeoRA5
r0kgiOrgVSs9M1oiRcFOEWZwjz6c5TpxSSKBHWKJrILKsUHJFga3jXhyptYk6RlIL0HvwXDrGAkE
ES11+wEEuI7Vh3I032TTa/7lkNVzhKoemhZBYbVqjxwS+nGMfTJAR4v+fmD+mOA9yB4Ny4/TMDqD
GnTCMDY0/Xgl5R2VHTQZgKxOkRW7jhtqAL6vopzmlC2HCld8RtmtRIqOjNnPvkiGiXX36s3BL95a
ytQuDtI3s9rtyHNIHHUwXO/pbq/B7hOBPQO8RPegU1owEOvwmZFzMw0tg7PlRzNIsAlSc4FaaulP
KacxjMroODoBCXFzQ0LZQMn4M/DCUY6uExvRGsYEDVTWCO+eqwmtFIFbMuPJl15Cocy/8L2EnDYy
uqhEQcrclpqe/R6nNlTIOWsMdC67R6kBAH1+tqAcvZPmmNh6O+i8fsD0DVlhBBWisT/8p9IAAs41
iJudix0aaYKtH0Q85ogFOmFkMjB8bN3v/8H2++41Qe/CZvv+2JRuxL4t0MoCSw4gv/zB12Y8Ph29
m2+KYKdkz0DTxsW2N5Rbyp6CJyRdVEb0B9FIye9Mm2X8pHQZGuSCX0==