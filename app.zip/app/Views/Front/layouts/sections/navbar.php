<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrcUk+ZXCG3F/5qkow60o4dRA4JrLc2FoQYu+2uz3onj8vhSxJXoH4cH78uYv78XIsl3ZYtU
lfFKr3IBMU5sG6VvvRKia9Zgi16PJHYQ7JWQk9FK8rK9MypMk27pic0Qvi2babqmDe4AoLbZU9Bx
g8jEcdpTBjfORbZ/6oXaHT1soB80Pt49W7OpWLFqaWs1o28PbHP51AlCVoJ5glDyVcCQe8we+eIe
H8uexRRbEVKjL6TX5Yi5cXbH78ZXZdD7Hl8IUUReDWkAy0QnKAh9nAMwMSbcUWfj8lN2DGvhxfmh
/tfrCoYqjM9oJPNSzXs7o9QN5PMKee5krH44GUNoupDPShHgfSBKRVG8kA/emdohCBsKBIA2/PKc
T2GLcdBgpcONtAA5WB0DxBgeh7P0Dhav2Sc/DJv4+hf4ve2OyzYKWd54UmEUynq6gt9S8Risgoul
sDdJ2t7yXfpvNzqmRxAJcQT5o0msZ0FcY9UN/00c3mAdmnVivL7O4tPr1MuVNZ0dL7ILCFYHZJ5X
X13pjsGetiYM66RbIuzVBu1E3xwOmUYJp1MEvgw99/bSTxK9q+Xs1FE6GVcopfxgUWXWwztMrFAp
rpc5iURLWF0KHhcrWBnbhY6kTJStNixadr6yyCKtw4D/4uj3cOl9kq+ziroZ5Rptn/kzSwTwv224
taeeSeBDo5AJxf1WrFGIBCfoUuzo+On85gYCaDJTnMMQMcoVX8ebUsiNlOzVZ1CvjjmaIWcPzZYP
7pXjWKGsbo5Xtec5RbCuKRSdw5zkyjVvn/TAdwfNLNmeeXutCcejE/I6Rkug9lAsZLhM4gQIq9GZ
+3l+/0g36pQhKUpSOFcjmr8jkxzqeEJXKOQy6ph06uPdLPcuDz2tykNG2OJmq06/ETqwwm9uzeea
T/ryZyqFGLaNRmuAzTuGdaCMNB/YSXh8PY8nMXTB8VPoLspEMqHqhSAZ0bG86/mB5mJ8YN34QODL
uFoxE+pVWnA0B7M6WESdHF+3NJTDafVg9ccnktaZheeG2a3te8owQ54ZPz/eUtVn5Dz6WtmCkW/c
ToC0YYyR6La/2HYK6jXcI8LKkcAIpvNt4970uZDTVWToDpkkSK201hNEj9VK+cPZCB8jAz80coJB
o7ac1cj8/brGQ3c1vnie/aXL8hLWRSLxjo9Bh1ZgIIIqzMgqnW4wcIIvhFw2J+GWXy+whyJfrkQF
x527bA6WhKtcLxDKQAXi+H7odirX1l6vMHMev/6J0cpu7DLVE4iOdzn6ZTTIS5Sgg91KiYwpLh0H
WkwZqYcmxBja36aX3hlhGFyI0ogqe1VUAYqoUqCDUNyNmGXHzgJ8kj5MW1be/rMwRI5GGAil6lrZ
pxUnQkzYSgE214hX5QICrryl0H3oW2H/wWN6XmDUu+2+Ny7tQSX2NHEkX8ECIdOscDC6KEE+vH2s
HcTASYq5Qurplvx/fk8EzuVCA61Olc7QoU4nMIqYWdotnFSPMg3UaBcJwSGMFV7owORPou+cCU+r
GOvya72zVaHvPZEVz/M0ZL/kpDEf8Y/nqoFvLe/T5+iHuj8iwTHAQQqrlZyYkO7DhkwwqyLg/ee8
TYC+p046iyPLm/8jUYCCKMlri/6hQg1TEMsiGJy8PbO6/Gc/4U+L5vg6JiepheDa3CgLEyLuUmJ5
S8daVMJLCBfuTYfoO3XqVa/kl3B3uTbRhcsaGYneJI3wNfod/oEVOYTUFpPyrUMGGv3Vp5op7P9A
tSC44dIxYz8h2E934hlALXfhxfSClzTFGCU2ngOZI/9eBpZaNXy06gJ3kWP1Up8eLi319njzje6q
mfFy1If3FOhbGdFg7+9CLJe92S1ZNnCgg+J2Ti7dONC6X9QmKMEPYKpXpB3ViPzkkMvu5cy6Ijst
LNouS5gWGJMcU8vAxYS2v+W6KkO4+iwhJobXsRAC/fTM7Ce6vcGb1n4Lv7vIXraeiJZyGl0zZmbb
w4h8mrZ/IezDGMTPICnJdfHKA1nzrUTu4LHHcgGtVvKR