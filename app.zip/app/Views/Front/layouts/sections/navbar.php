<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwYbURLrE4Ax06Ribb8iduxXEL3U8nw5L9+uOjQurY+Ef0DcoaZRBZHwgpK3i2KJsfXqDb2j
721copRLrNkgB/FuBkyZxSYXf0kMJ5Jjvg1KnKOBSlcjXiSDtdbC1kdI6o3NYyXMqMw+LRt9k5Fb
HyDCtgC0O6EP8CwpbjeKAd0l6QJoA1PPyrArMHAC+NFv3tdoNtduIuYaMezaS0trIweRFMxv1IZf
YYWiVSFMUDaUmwkNfmiXyFX/511vQK2x0WF4RjHLK0sFFSqLpROcz/6WCdHdIU7tKWZl12efJOA2
+aKKbky8/1+zO3Df5w38dgJST0Wt9NbbpofAc/KJW57WEMYactL8L1mEMnPB+ZqlBVzwzei43z3b
lOuacFz8QuzG2w1+HE16IOnB0WzOid/tOtMzie5CAKrAFQV/tiU3v0kKqb9HDIEo3GbvKzFpEAUa
IAcVQKvwmAxkr+NEJ93yBNtwvUycrs1BiZ2F7Es3HXiplB25H5k+DfGGFMXNwdno9gUaLlmp1yr9
r7Cxg3riaX+kTdRZBCoSzfyGD8RY87COaSbUCSCYQuPGsXK0CH55i5/UPekKSbTSRBPAetsmPoED
ZNamSeVP12ir7wiZJWikbF4fjxbJwfRrDFJkhW1SynFSZ3t/imhIN/btkc5Rs1ggaHF78kcKlVKe
spBQGuTjyhLWFGx38CNiKYcmxnIBclocM9h9UUqTsRlJrLxAgAqiXGMGCn/nCk+8G3vG4YOOUihL
R6ljuvkc9PvwRVHppUgL3hP6vpWODQq2JQzoL7+XsR48PZVaH40FnVfX9c5zQW9xaju/t5QkFJcX
x7TqocvA1F0gI1USa6iDi1nTuuaWr5YFX9vXKYx2XSc3c1OCCUCozeBOhEf2wkL8Y+4k+RZzafp2
DXFs4tVriC8q4Pr0QMDKiTBBr+9jqffFtQ6s4H9vyjaBtIa8IghokPb2a9aEbsO+Ap1Hnz6cjfCx
vqQozCnVMAoxSLv/1QjiVk+5oSqCQmjhBV/Vf6T58W8PuzZpSXww1h+0n1YXc/a+Sfm8ygcRyoPW
FVO7fPPZXOAGeJC33wYcK+/W3WDyNmtBLDg3ElcJQTih6pCYicpvdyPwe2V6QOR5FlPFKXE2/Lxa
ROhbuVkCO2+eFdbQD4bJRD/qzLQhFhebHUjpjlQlZMY7DWljsD2yFqyiKqfr1S4KoXQNuQvizJ4h
f0qMDfrL90s5cCHsKYJKhbk7VIG6krWV/W7/nJeWEM6V7SP3M5ZfODfQ/OAiAxZVSRHmRlCvtpj4
4DVawBC3KsQJzFuT2xLgQNf1DIwDmhjPypcDBWmT7qcMAQ3nr7vp/xZ3DVNZ6UUKXFTXpM48EiiG
xLsK9/JiuUY7Jix2F+oHlqLLYs1ZW9UmD5kdMGAtqQEWa15rPl3OSzNkDCcZbdNfFeV+RS82b80G
Zc57Prn9RTdV0uGU0+/Sc7WwsuWbf20MyEE7wt+sOLv6wViW9PxcEr5CKI019LbWHM6Du8dAk7ng
IINCal22QQB+Ironk7HnNzslsokx/XmcpECWvOLnWAc4SeGRKrTssWMV2kPNCAjj81IMekaZ3UwG
u05v8CpJJUFkLABvow2OnMEQ6ip8arfUBSsK6GB0c87e5B/I0v77aUz9BUnc7lgNLLLpoHPTm5Mq
yJ14dk3KXPlsC1e6R9Z/21o+cjnf6ZTcgstQ7qe6I1x55YfD7bTZHSAtCJh+aq3oYSK4nzm5WC/W
1fycYPkNHaOBsUjD4XMQTLeJcvjmxDLxP/h3+O4vTQ5K2daL/POg/o9q8VhJHGOsGic/OgTMA8JJ
T1sg5Vh39BqzhCx5YG26hg5q9p9mT/4Dhn0tkVsvtvhvrb26CZVRJW79oaE7EUJ9QePvKEv4VT8c
eWwMdtLnDNKxFZ6UDGOhqb7NbnA2bWA+ogFSR+8I5NQAGwHPO70cw0F232U98gczKzTqu2hJLQjQ
oiMWxOZWSMrtqCNQft1dpEcXGCavqEM/cNbDj0==