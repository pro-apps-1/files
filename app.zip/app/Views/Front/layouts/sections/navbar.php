<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw6+aaO64sTftty7PLJ9qp0UALdZ7jBaswUund5GtNwxrvWTP/HNJoAOoAK7yMqbC/Fz6Ld3
AfhNSw+V9gElHzG2PL4uz23rSsoOrhvQeb/A1YQ0Fig0uRd0QXGkFoN5oz3UkN6d1G/w2PgkJBKu
hUYDTW0c5GQLrnvfbxiWj2GPTNM7mRlzdg8N+IiOGA9qqgzbOPEvPR9Oh5dQQEEZCNowE8Kqn+si
V3uqPrU4DpEkYxPSGxRrUQmuxA2TBm+LHQKrscOEfIpv+5PatZdjxX50ax1eTXcrMJqtT9mhhAIH
M6TT/UcaC4PTJoreZN9hsRWpfnhi0nNk5KtlRdpP+RihJJOXd1pjzh4xoPEYPmlmCheCuuUWSGK6
wHess+UHT1+zyRnt2PCWmXVFAd5AjSPXPAZ7nc3joGnDGkMWeH9q+621Fs4sQUrGmyUfE3QKg9u+
Wc4L7CeD/5C6wFmQqwt97mDrBqemG5UA55o7Ty06McXShkti0uBaQLr6EuV4v5A9YBRZnnRPXGa2
ziip2g9Es9rtq9Qz3Bkp2tY/LYt3qNMB9VJMnawh7eVmMUHZD5PzxiRDr9/ny3x0Bow2OAjTa+/S
bkIpvdgSJDAYAzELTeQra1hxqjBS9Mmg/pq6456T6181oNIy5tj5ZtPMLFYzIP9Jg7i2xYAUX0hO
H/VfaWaPKPhQnMZIp8WfRCiuCdu+5dZgezR+fe9rFlHholUzKjv6aqIQ1S4dhk9R/aCz6iGZSXBd
1vpJnhcTsiZrbBrlX37X9qsHZZKzDTvrGLKUyyFGFMGzIT2h+mpm4Wtl3qVtSH2yeTMrP//1b2BC
Kgr1HOjOzpX6n0ou3VT0xLPAi7fojCMl8nE8ZiXFAxjenbgmhqIbHyuh3zw6+SRb+fq1ii2KHY52
WLsGAbgsQd24YuM/0rNk/x7xwoJnE0swVoJZQsHG+u719udPuCtvEWWCxqh0O9PusJ+JdmgGLp/R
oOeh+Cs+ZYU+9/0ijDLPWtAXhkUHOH3r15tGnZK1vlqL1JxbXtuZNcQDTZ74pb4VdWmRs8BjOOIG
fHFi3ZMxT+cNdC2vBQwkQ7T4xMrqnPGoIAF05jEpWldu24Hzzi3ouyyAxf0FnPHIRmyLVRt6jZAu
sTm+AZL72Mjmmx1Cv99jsxEXMgJkBJ9qJ73Gkwbc2td5QWuQpQfatRQClvEeJP0KWYHIOXYNFeo2
CSkDr2MODP/aa1LEuB6fbkW/VR84WzhvHXPlJYCi6/cILQaR1bSU9yP+SGkNsE6BE1sLu+Z9GUqU
rlsKtyejPhrv6sFltNPbQvX7fo8S+qE70qmERQgRXjjFAyzzkcD2tn4w5xCN2oW6xr0AexrtJ/E6
mUp9oIcDyEu8gAYNPia=