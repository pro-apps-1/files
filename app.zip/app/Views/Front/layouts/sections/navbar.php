<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzRrt4/ERYLWbpH9RAunQGKsvDcUwMOBYhQutrBPaonfYkChFISTIVA2gVa6Bx05z4pqiDg2
dF4DaGfEJVuoaQKzV7Mm09WvG+Kw2dak6AZ5Hc1MlRWV0Oflw2fsaqc9wAu1SY/zzXDJO2yIOh6/
pOg73w+IMVzIKH8MVTd0YdPTLYDVuMivnJ87Z98kTTzk06ytCd8mmIFijBmvWXprbQO1aN7cgrgI
nR5tmdDGGxXVgbz2EK5qiE/RPrJj9jXQsO1+XGmX8x4qZZJMw1YKFlZa7ILaWN7aW3vbj2P1F4Nh
CerD/sz4IIQReNdwVghsWYJ/MaWhYjhvU39jrZSflo7bGzNke9TFcTYJ2yfv7SmoqK3+GWjsXjkN
BU2lZ0pSgncNicQI/FyquE8gyYDVpQ6AgEjwwFFpvuf12pRm1vuH7FupeMwhuJDXih4spsyYRwvB
9iYEQEF3T1oA+BYx8gTHiBgypjucMA8TY+toX+1dNs/kc+liYfaBRXbrbAfzJdCpnIaTqCAd5/e3
73VZYu/Rc4E6K+DmJMIvxvwGZbNEP+ykaAuURLAs0TOoyoiOPqQ6KRNDYbF0QJuQhiG8NrHSBgnG
a+BTkiZ8sAns387gmcwKEIYiaAqFabaoPvyKL0A9lYxw4YHZJ80G5KUDwg8kDYx0mJh0WZBBZTau
oTaz++u/QdisXWjzdLkSIwID8FsV5YB/hj6KB4CWuPqJIyMWd6IMkNhInPj7hFk0LbeLSufkWinO
2gXv7FxGc86oyLIT/xFmzvGMCafkJiUtMcUz0EWxv9nYpIg+kVUBBA/WTQ/zhvIGXTGrXHUPJw1X
ytGKtS3thXtTmSMxHDzFqqFqIqj2a893c5GEHKWrLjFaFxMZgcBOldNaLr2t1vzlA++bD84U7jub
yIm0W4Pt4+4+7r7JE3rynvRAjqG2Aklu4MbhD2AMIZGWVXlXrTUP8fyBs7Bclo6s7oEYeSIAAewc
9mG6ceiMBaWvfQbwTuCD7Go9hfbJw+K32KZbEeNnH7NmgbWGNMcEjWPb70HE+YJmaGCrII/NIpLj
hvLAIduATjIoZ55o0A2d6a6HSy+piV2EdsQSWtDteCGl8Tv3MzYDm2Tm4DIiTz8RendcfnWaZ0KT
kC+GiP2NfwgjmDYeipEk4VtoCmlSsoPHoVSqD4fUHvlyC2ERGywqVciUTBnW0GF0rp5C0nMd4Nx4
JRNUbfjQZtJCTYc4Va5pEehoN0Ef0EZDbM5M/G6WWE43Pxe0Y33jkPcpN9sVjRuEoX6oE5Kxa3Ft
s+d4i9ea9WcjUQU9Xj4S6PNcIth3YAh9JcBNJOTJB5KQ/GDBKwf7nyC+5etiwYmfeHXNWKuG4bdI
Dzg2vrY0YeUbkOwGNm==