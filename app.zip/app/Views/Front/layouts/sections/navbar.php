<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzpQOQF+TLgLXndqW79WhFAWejoxOibasgEuCUfUXI50l405hw7RqrlGg/Qs0HjfEe19PDGP
g+63FzN0VAfJmzZsK8dxwmHGXPjG2Z/1ueLb3mu78kBeJmLJ1xaXtCB3pKMDob3QIWvMe/s2OzUF
IhWIVP+r8gTMRmfaTciu8raZoSIguWrHEEwUcm3HnuniOJHWYCPiqFVb0BhxLkDmyXgkuPcajjNs
JM6mSQ8PvVIXQ9L7CQvByYqGgooYQLOkFjP6Gv2yD9MuVnh1EjhBxNnaxEPjozMfGC7991l+u8es
nxm+3H9xJCMR8+sjxN/QnpYUQGKD7Zi4wHgoAROD3LnGQeLaHzVZg6/Kgi4fR7xLy0BYNyfc2YC/
KjCMP9Pbp5vE4643ofY9iSvnvMAjZHLQy6dtAq82mT0ngRYPoMy/iGUGxQRoxPLb+IdgSM5FmvSO
zx9PoD4IUWOL9yG99UVle8KUZMWFDVPO2uQrfT/J6BNr9mNhCOJmkZVrn+VGzp4b4PAWcaej0Ymn
zh69crUyEo/CGqOtuNsbs4opyvRFDv86bL+kn4GmqMsrYaF9jCZwRHBxHzGab+UL3srJbcXak7Kd
oCF6DeiFObJfuzQCESb9+QpuBvC1tAhwWuV9BGlsemEopEU5FYht2bDOs0Em70l/AlmAExnuw9fC
YNgPLXqjWcbrxMCZMVXi/VNRkxzCvVJ3/cTgP4mXPg0Ftotjv1VXpDJ13+8vp7l/qpZlOOUJnImD
dmil2M+284F5XUIOLa1LgPFCFQQQpPEG8id+f1CQlDlenCWv9FnpS1NV7Gk67heDz5S08xfAvqQR
rnO+KlBhWBwuvS+yHVqT7Cyw1bia0BNnuhLl7CuFXqAV/AVbozh9rw+EMoHRrEfI5TVd/WLeCO81
fy8ap8paDeAYQ5+apKdftqcCDphXP7z2tWiD+5QxavWlBSWbL8mf/ogxZOHOM8M7NMCQfSMrnSUl
Y2qfeOGPu2vXrFFNAeSq0lzkgAL7d+mX+RCb/8DmInY83WP6TOIiQe9iMGbZw9hP674BJ4mrZSRf
muwH+9y6UgKMgqPlYo/o6IuuIfSdlwSJ0sHP9LsavYK2/DQIyZgrhnSheGbYaz+Tr9G8/TKv4xRY
clT3C3Nb/QtQgN+8PP4K7VMuuN5Ml35ijHTEc9b90/+K6uzHy92/MTaMAoJHB5G2YMsF1lmSUywi
9mWg12JvM/YsNGrDCxUzDmjiu5RAlDwUv6Oq9iAKhZsYZAZEhPdngNf8iNqj8431OL/3InjY8bZ7
J+yvUzhTps0ZExyvxcY+D5Gr4B35L5trjpUcjuSJLcByIZSkSH+SUXKOaGfp/mrmrMKBHqdUiW+8
g7gDpYR4PdWVUHoGfTpjxx+0KXXstHd/fgV3kNkzl5bSnjnSyng0TUn8tua+K5SwrNFIJq/xlMJI
sxUGThdR/2K05kpDCuWvEgHI3zOVMqt6E+1T3g5V67gW5QVUWMYzE/abA02EHEWgIvILJZfB93bU
yAyQWMIpG3+0MKwKqY3CPML32OvptzkoZDwNaFmaOA+pI3D4RoQqMypZCEWf4qMDJsRfvDBo9WLW
9a/3RNAxdW/KCO6Ob+gkwFec04zpbE7XcSR+1WGM+93PVHnR5ZOt8YuPmzNIzVMoKVmWr9G7R0FS
N2i/4w6w0+XoHCkkJ4NjrNJu1y5a1A3GtCec4lzzalhroJ1VywFmMnbcOyfw2qs/35kG2MsqcItk
SvFQY/FTsmgG6xiKHVkd51s+Y1Hxyep6Ks3lN/EUTs9mb5JCj2S82GPPA/N2ZxRrN7QDbcVz5l+G
Q7SF6K1oPfmqc9W4b3zln2XjXQIORwnqCIDbcF3VZ2VhFMxFraIwfrPjoarV8vKQwNAOAp+NNdj5
uMluZEQYC8+/vCA29Y3G9qPYhNtNT3OpVlVFwwjnsxSuAht1TvKNDa3T5UII/54oQw3Q7XqWjc7e
mr7YLgHVvqdMLe82O4U7f91ROjrwPnpBSVynCOpsxCP9HXppGf2g7eEhqG==