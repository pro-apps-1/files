<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv1nwh0Bukw7qh1/aq+J3ElYsaC2+qtZ9UKB4vVdZdHf12aVzLECh8lCYX1ztIcpRSFYAGcf
qQSh02BncmbYYznWxXPm9eGzxukwL8BkW1iNuBMo2MatBXruAk8+u+qG2tWbg8l9DE2W8cm3/Kct
quoAWE24/D2WkQ84cwpabLkklGMhXPGcTp2UlxJHKbULP6W3ju/YXoI/0rptHxqL6jR3ALBtnPWi
tqewhYWfIHM+OBIFlhRe9EzLdRdP2D7r4N+lNYVXb4oTzhmv2BwKJROdXxxjQa525VZvYQXmsCkE
yyheO4+OBhqDXmp6goLZQ9TT2rTUzLLUJcnF0xgtcD3QFZ8jpCsy32ra6rkTazq4tZ7zQTvwKkFq
lGnOSiw3TPNf6FVECsmlN9d6kTSsDHlRBXaaW5X6h/A4MZrUzoBU+HBR+RdfTt3ViR+1XctCA66B
mwV4IyM475fTNzH2xM8Mt9xzYJvz93lF7QHo72HRqETuGWZjB8ijPt7Ws8+fdCehozC2BZgCn09m
GGEg3qqju2/wt459CNMMFITjoJ4sDAFQql78b687kpS3eMjbNNiPE8hDfoORTVfK6L8DQ7+G5hLd
+ANjVGlL63I4ba3vat5mRt2kFfjaYdwDvMiPWgVjZ1I5tt56s6OzHCAZAUKMeTjlk6ltDyLliReu
0+u5RJ8cZA/gC5tahjfgB7v38jzoSer2CyQihCvBqn6WAM9cVf7nvZeKysfRXHomzLFiTAsF4P8w
ur+m7egg9WnWQxTlJljznXBSTctfJjIs1ro3wPL0SNZjdQp2XEaQidWtkLejQfR7hgV8kI6rMT5B
XYZ07VfL3FjFo2J3RpPH6E3shMUrVi37dztp26UqM4L8dTPXUJDsxQi2Aa6fypDqf1mt9W/cgTkH
+36p0Ndjy/S/J+xmHf2050ck0I4tgKLYpuQcRIQPmCZm9lvsNDcIUdbF3PIKDfHZ0HJNVFp2U9/U
9CBxlPFxO8OJCIx/LaiC0lkQlzORtR/gwVPr6+htsxezl5MzySyRzIM0bQGKfKmhyNaQNe0cECbo
8hCKtfm9vuiDBTUGQzx+sjECvFmY3ExTUseX3ABerh4wtKWajDcV57mxMZeNHgkFj13fOjXb1NwX
eaymZBBNTwMxuTZI+vVw8ewnlwyQCxXYDtUVm8QIors4MMJN2nUuveJRgF22YliTo5nLjQaBfC1/
00Le9q9NAUR+Oklzi9Ksn/SGQ2B4ULyEZ5zjEuUT7i3aYGcYZXo8YjqdtLF6bRmvj5R6Hl6Dd2aO
WbW2SfNrOm2p0BLai4qkg8qDLanVjrilwbIL8pu+0PXJWZxpIe3p5XN9eHP6e8xpRB/Q6qTuJ62J
lfCn2W+m68v/e0==