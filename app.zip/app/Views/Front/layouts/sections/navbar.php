<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwjTVSJXy4Ni/9xevqvyze4Y6JTlwxtuPiXx5OVWy2KFo6f0xAuJnnVEqbKz4er7PMlQi7NS
mvKY/5okwH2WFycZhUn7tyvyOwWqY1S+pyZnzSWGEAMM/VSre0zsOE1k15/9aj8012wTVofrIsh/
qYH1HTvOf9biw4QmZZjppj2qblx5aKRlGJuIBgC+teV2R2NV9CAWh3iTBuopO2jh7DJzMoGaC0NG
9yB17bAU4cgcdnQcpUKApSfMr3UDcdgrSb4kc48UlJdPArgD9XhjxmGtTgS1VGbiPB1pBkAVW/w5
sW+WLhaB1Omo5zPFYrKrHt4MEK+5o81nyYmzSRVLsTGvuKndaoex3TzuE0FsvU5o2/wtfDJ9Kf5n
z+rdqQUi38dkpND+qRH/iH09XFBJGxVc/3E+OSrDbTX7EuI6/yPNm/mIPf4xz3GivR0DG/wtKvae
OEr9dmU5+7HG5w+zlLIYFYlPpysizEubkTfMS5EV1g7F+5REXqj4TUg4iZXg5kKwoWUVlCeG8QXq
ZZUHxKd6K/inI/6BgdnmpMNA0XBbndX7rAv+02ONU9Z0Mml9WTGfh07wIE4BmM5IYDKB+gUaPdwU
PNcXzP3ebI9XIwFYJ+3P4nicVtDeYGLZeW7M/CfUZjjhvbu/UqZ2WKcrDJsEAmNJDgHTvnJYs9Ne
qnLlIq99orCSW+bpfOmwuifSPMcx8F1bKw/8dZEz9RqN/ZD/sKoSY3CR0iKvDOQEpzNjJ6TlfSyS
SmUbIskNxbKfIcntiUaz6iL47+du7Zs+MvbDvzFIUs3Wf6SgmuUz37d1kz52TqKvk83mNUCkZw5o
sGOAE4/M3MjmfKAbX2ij6fr5LZk2Jv/KDsw60kORCLCoH6g0LyrI5YYcVfyG7Y6zjl6n7cQfG5ol
pP9FQGmtXWfz1TL7UGb1L0cQ7e7fh1G1UvJqCJCqN7kzilWzeddueoujgPL5DriePjEcfz0JnDg4
Ik662OAWMr+lUpT0V/BwRgcVoAebkEeJ//xeghzGqFByCoqE5t4rr3XRu8TuzbDT4MtTHJ8j86nF
RryIObgcf8pLFtsBbKee0cPs4y2ZYWUJFhlmFNCSr6JJBVKq/Psnhw11j0gzkeTG/Sk0XitPM9J1
o2ixKIC/vMZOsLbQk1C3psr7/g4QIZ2ycyCs5hwyUsowwCHhVa8xOb3801olXhEHPBwBcc9UXRfO
CAq1INF2lltI49XlhpNnG8lWJwyPU0ia/Xj+In7No1DO1iGQEdfNGdoWrFR4gp97GQ5YMthsYo1F
g/S914E654gKIBln9s7aGY6mq2ZXpQ0p3d/qSzpYoXnlGG7TUX56PeEMpSWl+yQLf2LTw6d/CNBs
4rysnxAoM04TG0dIeG03wY+19BRBusdVR6FN3fZE0RaLFR4rN5566BVk1PcgRtQErQEPYKyUpGSG
S9W2aTlyGA2mByD2uNKJ7zQQqXe86Uv40aAgsHpUFzQV5CivI9STkjzBK+tAwjv0p50BJVPX6mYu
r/nNIHSIubdt8+3XTn6U/QC/raQqrmxN6lAN9azcJ3wVum7/gVZv6FNKgxoqgCUpEcPoR/lrSrCM
jwu0S7otzngKLo2tP3R8gjXpJe3PDACqeLC9owaZtjZPDXyP/tlKO+1JAz2pr1wagt+5aEf/ILRp
xc3Em4UUM0M+5CoiHnZqCHom5g7Nrae4TFGldWIpxRvKSkN71e2XivCzhUrroVE7GpVSgpA4uefD
o52Nd+aBiQXyWsogSwiupJZJysAGP9ixGEv/8MYzV9nhQ9XKaSrHAJYDiXF0awqmB1awktaxpuqk
6oXpYk9JKwxBGBU/IU61MZt07PJSGGDOwtUCsV/9bL6Ijnx6fOcJn+kI82Hw+O3bsXL7J00P74AE
QqBYf4AITa9vB+NlhbMHrK5Pc5aVK3NehGnPuZ6rrD2LTblM53SrwRK/v0WYCOmhtml/GP+MFruQ
REaa2nIlKo3uHHd6f60+xGDBBgGV4Awv1Yg8N1ZuecFp7GWKX3LQI6R+gqjwb2G=