<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz506+lB7U3Cae6Eo3ZTMFi0vNfDeyR0TUze6j17YsLEchn7yz9le8iAE+pAygkrKAJU0Upg
6k18D7Ocnuv82RRawaBsHBXKzjIwq5vGzUwPsw0gulCaGpNQsRY4rvX5KfRtSqqPpPAKN9Hpb1fq
GnH8ncrb7uz9N6P6qDVn3OkebRsOJtzF1gCitnxp67e6C9EKWaIHNLajuoORjel6yqn3byTUE0NH
Uule+B8eYhamPdaTsR1Q0UA0hrqS7ZL1I1uBf+7UZjZMzb/+NHsfPTbDxu7fRRGASqQRHsPixSZv
sEJkSlwWML2tK/dedlvOwO1HcP5rnfH8sx88+LyNJ8ooIhje0J8f/oO82Ilp09Vnl+pRgzFDljSa
uszB3Dh5naYi45hvd1tIEbD05WxncEHp/o7f9mS8yEar29xPz64TFjQj2g7eupKns1h2TcPuB/ES
wVH6NdKY3Wiz2eoALOa7qyPeYucAH9IYV0zjT7UG4urTBEv6SljG1Rjdfsb5G/mM95Yay2kdqRuY
pPiR2KMZe9TWmEPuxk/iyGviaQc4440QgXLqp6TuqR2h2MSzY12qxAJJiElAa9FoYJazYHRvmaXt
GGuUgPUJUjhLcEKsFRh7VduFH3lzogpkyBFvu2GLCf8ASmTk4GOO9Yiuao1JzorIKUp+OQ1qj0KN
fyxA2Fw2Y5VSLwuvbG6d0MaluoT1k4IgMirJs7ZiYb7N0ohNhlAXXOnbQc+AadHhUc5yS50bDaVS
n2F/SfENH947c3Qoe9U3hZCKdRT0XyVGDy20V2J9ENHSek+OHFipcGwSExvBMp8Btm07DFfcDU/s
fHO1/u32rbRsiS48ii6mlU9PsjYuMVOnqF4NWP3m6nA5I4l1OArOh7x7NZs+YFozmRphzdg3U/mK
2nIqqzSqzkJoVpuF2DUhFVJp1OdM3Nq/FVCEpGlgCi3Nr5zMw5cWEXa/WpgTK9SzAh2A0s9Beagf
2yYEqTvWli0k/+z/4aC9JswuI4uo2BUq+I9R8kPHIeI1+vu2RZannnZqdtLZq9xdNgaGhCTaxLsr
MH5p9p14Vhq0ASoKHpAM4ATq0ZwI28zyCEjeKzA8zN8cDFrWT/FM2o8wFWqr6JdM3wkbXMULeh0L
opGw8fFZHzZz9LdVCa7/Tfqv22L53jwyz1OwYC7jSIPoldm7o+Iz1k9IbW/cmFCeRh/AXOdk/Lv7
QsZCcqdVOvBUypAR3sxxB3MKFcFRs0vkkBdmXOSIvvVN9j6nenern1T4XNgmOWKQSID8Rb/qXAsu
ZegKD8jQsE/IHRdGtQwhBNkizwQBplgbU1SpxIoodel3wi3eO1q3tmCLdLyt4Txyhbe2Y5kcSc2s
bb0xbPIMjM2F2N4=