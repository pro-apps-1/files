<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt7XFtjnSeHy322gM6nThIEtCsP9HahgpT5ZvkLUHsOVSLn8koH/3o+8fs7yp7kSlVr2eBbH
2H+GHQKx62LwdVr/27uDIi5FTMGNcGZhokJsPszW3VT6t7jVNOJCnzwXTGAF6hy3YR7dxh7/9Y2a
hrVAPFRQ8TgFHUkTsA7ZbLJFckIFgyWJwy5/zBc9vVUyy6qAmvnmpvGmpMCW+PSG2D33lGozwUqP
/4hFaExBS7uImBCmGKVR/MyJOVquKG6n6Kbk31+w5Id7ys/xh1blMYJasqKHRGCAf/sxFSV1vXhi
e+TcHA524DR7jx/5EzRQHVGpDMoXpzrRLDoV/fJcUj1NWLS4SpXrkVsec2pF3e63jivSm8TOjlIh
4ifUVPHszNS2RG7z+GT1BViNFbso/Qff06Zh4MQqb7G3zeAVr2f4SxsH9co/CnptouSbdMCtRMmd
7nZrOWJ9FZSf3xsMPpDwFtvPKkfUZCvgSMffcfFXqYKN+cTxoHivazsFWlkPcub2n80TguJRS5tP
/wOsEwl3wN0QaxCvaqOzNx9C0Ga+PehDkKKwBC46Gdc8BfSTLc2lZQDQuceEB8wshVADI8iCq/Nr
zoAYa5DOe2iI/eIGHW5sxmzg3vinxKLhHrYMp+IniWztNOLbXXfrWplBgz8uNYbjtA0LNEKcxooV
Z5stubit5w3I7FLB57KoAqyuSlgBJ6pHSEVoRc3FXwIKDRUmSci5hHgk4jS/FfZekhPTPXidLLRM
qTRYyfwiLwoWYEux5O8TwKFi8ZZWqr6m9TYAbROgRTsqRYGCxs3BuLVEG6Asb2Fg7Ym55C9nNyRD
XL40UAEIv8hr6XkNd1BPnDG5m4NBG9AUg3WzDZEDmjL5UmZ/eao8xYD6ACnkIqh1qyGbD3276TkC
bOmVwUnF5sRklcX+GuxZU5xksJxaMUt50D57sulbOdZezxESr3T2nFQBi1ZpiD13SItsi+jj0aw/
e/qTd343B0eICce2cokA4dyQPjU8PcZwieAkKbpuBxCiOxvym/DAuLxy0hMVKb8YnF3BBj+CjYMh
fZcmOw6y5+RVvWW5G9XiXp2p+lEUj0AJnfABCBxbOv+i/tYx1/4oCZktyZgvB8FseLUVi/xW/7Mt
fsdn0sJPiCjWC/eHPwmcSmhQ8VPpBWCHHpysp5F0YOtq8Dwc+rCWOTDSK7BDR7Cl3kXR6JyS93W4
wWvw0YQ3zgtNvP1/4tDDgDmhm5hXnNqMWo5zOzyvGlTgjDvbH7yC6KU5Wq8VEopvZYHY+C6G9aLf
e0HmiNOVUczFytzRcZRsisJ8qL/V7vdqbV4JdWlUHMbjMGq4OJqOWYg9lYPJXDAf41E4l8uO94A6
WmTPMcI/z/zZh1LcknwE5zS=