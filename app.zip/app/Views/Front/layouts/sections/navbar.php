<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmeZIlsClqxpIUBVtdaEzuBnmLc53nJePyjr6/yGdVNiY/68uWkWGwPTUjOa2UhMOz4Qy1tb
NNuOoIFgTdc5LRLmgP0uF/AocMwhCwSZVF4hV4LV61iMjL96eohnEtD8CHWkaZZ78G+BpDr6xqhB
VVNj/0LdNNYkNfOjvQPnnu/reifXiQRjWFWRhCp+Z9nOo2/d7IDGglZl0Z0cMVKrydE+G/5NtQIb
c/dKZAzI0sgNPPVESg6ZvoznGG7QYfYBRQGISSXMzerGqLEo0pXlNniYmpAgh6sf0oslcx2AD8IT
GHaGI7mixTlVAKZ6YDFD8iu7EQccK4mmYCaOyx0YSGH3dombjgGnlmB8eMY6o1g2CKwS91RIbjKD
mO7LME5hGVGPViRVdhAL9EQR/eQ1ksz6ahK9D5iAQDcpk1m3AT201HRy6kSntwF5QWkDSqqnuOEP
+uhWuRg/x224IOsZY8fviPOUkh1qEWBr2p2C7X5x9OVyqfiaSbouoeHn3r/qHhAl6B7b5HPdG6zE
wIWvkwXokOV+oVE5FoY9GFv/wdg4LqBHhrd04lzhYph1XgXmMp4eerKha9dGvJbB7Yx0QTpiBHXg
e43YOx0OvBSsLj2T07nFLZyaiKffI9/TMVp1IFHVewKKWJSlUV+vwuLq8C5/Exp8OTWu2vzfgWrk
j+y+b3QDxAumVO7MAyMTjnJqxh4L5b0eK5t8Zn7sWnGNnFJm+nERz0cm9kXodY1pY3lc4XvjzGRw
vKnVv3Asfp3lLjTmO1LW7xxDvOMkyrtnCsX6wxLJCB7Bq5elhJtXztgRPl7Lv8dRyYNu1YVqz2jV
dlT7se4DvZws12JJf1x/6kHz9Vh7gJKtWbEknoDjWiLCeJJzmGJmYPcbsJrCmALXbevcLyPNkOvE
6Xy6yaEVLHXdiXYJI5ZjSF5Mc9v7S5QXu16n44mVMvCTo/taTkt4a21ThvPNTLMzXfMm1PM1FKQF
o1idpd0DryizynPtV3BHFoKCIlMbCvXHn32sZ3PrcCiwfxBUHNPOjnalf3u/4UHZRCFKmP755/rY
8VdDzcfWA2z1Wy7j7KBDKMeNo621wpgkt6ScqvvTazW/GtbqvnDQ8wfb3ukGypgZGK2ZU9uNOzWB
DyoVwpZ7NMab4ieYryyf9PJt0skx983uq89gLTcr38wuv8/ZNkbjKi0x01Am4uGsycZZ++ZcT4Za
VZSiK9zUlkeLUrL3vU0UU30wzvH4ZKrzLObGDPhsqU5unmw7tYA1Zxxdelvrk4VJSA/durDBe1+E
rAbFfkp9hSqYSglrR8ttlr1p+xg98v/c99s7VGi9PfACpd9noqZ1WqyLKb0GbIbIVpES1ks55BWW
6o8LtwHAfrwHCUG=