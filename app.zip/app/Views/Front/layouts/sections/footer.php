<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwmc9jXTkveV6EUp++RHEUKw5rFs4Q/DLF5DD+NhuB7jWPRBTOsmN/2Fgx5gsqDxDU7UjrAE
efyi6tUzw4jYjYIlIOFJ4wudAVxBJHIff2ZktLV+02uSxywemiyMGd1AWyb8afjm916AQW4DMKmW
DTJPhmBjBXs4ZbLKKdSVbwI3gGFIz/5Sc0Xp2QCH6RK+fuYzq+uzMuMaL0wkY9sGd//7oYvlQ5Vi
YF2HKl7d9PZgUE8Lx1H+BuAcMpO38IA9utl24eMbi2AXEY+NIVLnj/1LIwhtQWPmNihDHnycBHTS
J4LvDIogXec3Dv4YXOw+wVRxq6IQaLU7mTpYNGwf/0ol8oix7lHsOk+1grPMUAoFePMhBjAm0RDk
1e2LbVMXUwunz3+6FiGMILQyCDXp5TJFI3k5zecZtZTrgoQ2+OrpvA3IZukrIW0USPR+hgq0JEMe
Apwwo4/JNxqW72uq9ByIi8TsvtW2tuorhSHqQmdL70EJ6/Gv9ZwR5yhcVMvaSRASc70z+pFBgAp9
2OvT9LUgq+aP+1TH7QLsXwEYx0Vr2AcRLaza1k+JxPKSBBDrGWtULrjb490WQ/tDfRcuPl+j91pN
ZiSDQTxAMmJYqHTBonjHdWtJZKXBrkSfip1kodnVj3IVBrzuf2sbh8AcyFAR/BJ7UD4zoKECptnM
kL5KnYtxnXUOA7azuiQmzdx90xRWIRIJJqj9Kw19NeoOvrWvsH8Tt1XrNe5sHKN5Qf1e1seIdCuo
Qq9dufl5GU7FbvEcRhV2DU1Kgju9pmm/OfkLPDcRmikm8piBZ5SOUe49FiNfdwgxZKnlzBqerCYd
ygD00mzCKZ3MiyY+xjM9gS+vCsbrKUetG4YWyVMucCO21N2EPtFjWaqfLFQBvwgZbsON/B4fZjvs
0B2YtbDVOBdf/VXcxtoktx6aTnogegrCrlIZhB1SvSRlR6l5Gi2E7b/Ii9yO8O2Xt2Vk7R0SFwO7
FVTl5KL35RosXCKNV0BXRRibss+YnvGvrhEo3ca6wWxLFVVi1JIYQEOdKz2DisYsWgEbMTh8ii7b
QFXfu74vWeew7W05jMaEiH9yDXFR1rqxv3CJGP1B1ncpwvDUj3bGJpdmG+lbjEmOAlOMacNo1eFb
jfqols1goAd2aTFBZNlVz8bMnJEqyM/1OJc98DieCKTs8nL4mi0L9J0dD6QY6wsRVo1UpEntSZ+b
yU5rRCTQk8bYjy8I2N5tJgDMDpIkTKulA0EoJCLJN+fvv+PgF/TxzXP3cGPt0+Y4t1Bad8Z7FzuU
/z8a/BI9k3boinEHkx9yqNe=