<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxbZQCfw/53k0wBzwLH+773U1YORHotQZzDb4hh6t06LC7V8U3+c687V1SWTn5wlDEVCLwaV
ArPup5DGboPxP7vjCKeRZ06syvMMqrRJywhDdV7kLb7zyRGM2CUxnNuZFiUCil6NpG/aZwFJqSNF
eWIL+oJphc3vnd3ItArz3d6oKcvn5MF7Mr675gLFWBl7tW7llN0LxWqLD202lu/b0rjR7QvLyexz
C1yWqGkd1cm8ovk6TQbHvcCzljinK7+/9i2TYF5UV3HNAgEvKMn0WDbY3c90QdhPkoyV8i7/6C/j
0z4uEoC3yQ9dsgp2kWOGNsglq0ntSmoSO83HTtK4Jf9xxa5rc7mn79lI79JKnk++sD76Ry+Ey34S
rMdwa0PdGwMIpdWoPBNLBsokGS18erTiBurcfmeGSQu61uAgi+CMk/lri7gXgf4x2u8Bd0AODpVP
ht5b+aMx3QwFWlOJqEDT6sj6EAi/O/15JrlZEp/ZzsSd7smNkXCM0R5s2+BI4HczWe2DnLrtsL7H
tDv6hxyQKHBFrgOHT6jrbtWpgrMrd6v0HafQH21395Q5PIFKiBGJdVh/UiMIwgO+ig3RdQKs4u0o
PbrM9Zwo2lRJ3iufAacLcoZVtbnwP93RwVsZI7JLmEhRqMHSjobc/rKMwr2+INlmfk5c6bplmzKT
yRSmfrm6Zy+6FXd7LXsfdJC2xxQSosbcGs9xXP9+pDwUqs06NPWDog3SdRU+ZWp/cOEQ9UXqucdG
qWSu0o2y/7gYfzR8HfR7rWVTfZ8czkWzfLA1ZFgiy3789urfdCoDhjDx10TB5EV4JZyxr+p/GzGi
YX6Fy9l2QA2G6TXF3A/AHXLdphXJcgpaUdNaK21b40eR2EBDqCbL2Q5CPHtSSHL4vkZU5/jz5uPQ
qCrMhEGI960w3XA0aLJqHVESWEELpHn4KehO6pw7O2vSfYAHaQynBHMsn+1IV6OG7RMk5v6+dKvJ
dkdjPzVVigka1t/U6jBVh4P72M/EAzPUlTpf2EsLRyYyJZKiQSPhP9FQLcXZtO/mDaNFPWLPEAzT
adfZidZi0+XMSyOSlgy08HbfSLtbv5cC7zJDJDGT+PVRm3X3wjTpbZAeUeMyJm3AzRI9hXaLL2mX
GQ3oXWjLM7sBRAgJ0mVp6D0DdvIBwcr6nlV9Ykiwnex7n7wIFiSIfrd4/YRbHVJmmFtB6Xh/ofdT
spJqpb2Or8jE1ikWuA5D7EwCLGB/B+HDNyFG7xMdGZ5bDJX6rt3XJa6PQRl9TDQbaLByRQXEQDX1
UTMCjgE6hbzwVdO=