<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyHOyYLczSOAVvbd1WEjps26LEFtS6ZJYv+uhQ+lHYFJA3sy2Sf9ZQP8SWPnqjwPoapRLa2T
dGvv+66hDY5V3CFsI+7HznX4RqaGupGLz2iUWIYmgaoqX0CkxeKjBYK4+z+wpFX3wZQXUDvi5waH
qwIfnEYLgj5wpEhFGzXLunHP9vWbYgYslf6VKkd8SX2OZ1n8XW43ZHnhKAPcL90gyQnKQK64Pj0q
Han+2WNH1M15zmdFDEMA9cNpOoJ+liC/vm7btLI+K6eOota74/8WrF47JWLdcqxjwcR+ikXb2A6A
Y6LQwQFEtNByPmbZZntU4VhPGozcxzBMu6WSFQ6qHrzJr+b59viFWGPTzzXW+8b66FA+p77gt0E7
XGiJDpzXGc92jyPzjo+ScZenRy1DywNbppylFyRVa1jNE43X86Ps+C4pUEv7/hSQeMbWV6DVpP7W
Akt8eySbsVdb5wF76+agxTX3LtoTVNzlP9k2Xh3UkJuDkMSgm5aOmChh94+gp1mtK/DUGujP20rL
3kc45GyVMHBN81bFK0XyUPu2EPdI/tGpifpHRrMWkCql0aop4W6hA3c0uuAgYhWfwd3Q96UFPGyk
CoocjJuOab0McWHP5MOKKshU+K6Ag2cZCHYj6dyBy6aqxNkQLvno6Hl4o3flmMM+uh0XcrafALja
wIdAtBMS4OWZiCLagmUUBlISZHLi5QnOnv+6CNC/DW9tiq94XP7HEH8gfTEetHr6/DKejJsafkGZ
KYo1iLOvj1b76HBX2XwVO5Pl2nigW2dUsxW1RrRsY93WDb/UvcS+vemn1OeJ4Xfq/N8XwNEnNVkH
hLCkdLVoLnylJ8xo6zJIf4hWfvkJS6HcdTUt2inj9EFKPoubXnGxurNDqKhUuEu0Deq0Zxod3bn9
sZTL1WYFUwx3uELkUuGTmjzpnMD6nCXQmEs3bPSvUrzndUzyZp+NSC7whjTJJe1GENFPfRLt3IHm
ibP4yaU2DoTu6U0m2GFG/Yu3p/0xid/WRy5153XINTl465UThQ+NBqIZjT6ollHkOY0wSOUdXIDu
7gzrE3DCE9n826L+Rk3jg5xAGGb7qZ8O1ePNZ7XKEhw3efo5/Nnfy2n70qYcklL2sE00w/TLJnih
QhzfZIl1Cg4dHS4U6WZW7MFK1vpFajWEKnzUeI5YtHfrw4Bc11V5PwXsIqTY8LOPZ31+FQhuN5op
X81dh8GTdTFGq3rtwdqbKy2hazKbFXgWB+lU5WnVZ6snNReYnkCpLOiP7EMkxZ/tmrRGILY7orY1
xlzgx42Q7RdrOa1v