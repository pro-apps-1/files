<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPu1z1SrMrltYBxoGxeaTj1G+bLlFtDmbghsu1jwt7u+ew8r1qKA0wxnjj3Qz/dqSQJ96M3G4
03ctd2bO7ys5ky5M2sFHHT7YkCwst2C3fyMOiw+q7uqi8B3FR6eudkbkd79SOXgoLuKEA9tZuhPE
n4G95aJIoxZmmNVcmR3egQG2+gNAYXi/zzg9Wq29TVWQ7M+TKoyUpPVT2Ima16qmA8b3B3UNFL4F
03U5WB6dhNdoXOmOJbI3xxv7hvBTzm98D5PMnc82gkQCyqV2yCGmDldWeA9fGYAjI/CnV+S3L91S
oZPOWrqSYLoGVUcrE/RCE4muDCd+sTVsteHceeohXqifBiovxXHRqaKY98920CcBdSh//gqWycDB
7xPRT9liDokMtRbGC7zHixuZcgtGJzuLjgUZ9OkSWIkOe/hWGFRUU7gHGJkSWQVEeUEMlrHO26L7
5KexSSPpEgQyTlRef1z453RnKAPRcEjvUmET4Kugrvdun50vDhtr1kJnJFIS3hiTdosSUbEBaIfi
HTrIkpgEZqmG2QjgLHwXwXQUZJqXz8sx3Thseo0oRE5U6x2D9INI3UEgy+6KnjV7RqIoGejm8LI4
NQDEVVPPIVbnXMxnPsczl4KTGvhYqUUtswv08ZS4sc9HAWfHWyht4wAbdGB7xd+CHb9Fu0SN7gPj
fygvScsk0hIV5sUUM6ViZEptk5kx21LPIOGC9FRjfP6ue7zXSZrDAiE2U5wwVt613z/Fq62rMDPu
PgwMYgORhVAvib/i6tzo8w6bGQHP51M6gqH5mBJgxk4396MgYfHQWNoXEzBme8x+n6JM453MbTuv
ASu7UVbcNeWdz+7fMXJa6oY/SsaBgIMTTiGQeEFkjzH8d5jQAQoVhTyWx3j5WUjjguZbhFDuNI61
0XUN3SfzJ5aBA7Glwz+jNAAXdZP4Dv8vJ599plsqScpJCJbxRiW03ZMUql7Ebt459n2wRCffhi3g
W61b+0ciul47FnwcaBqYa/SxcXN965jtka5ooAPOMeg2903Rkce7zccVd3RA0QdK+2IgtGF9kUNk
BV+xN67kxP8EBBo3n/5z/SltbITyAdNeKjCThYuUeCNDGVEglEw5uOunjQfc8yQaW+8E2H+wsJ29
tmV3fJ5Nj/VdtAtcrqemEfLDjtN6FroxsHvLkpROZMVwilKfS8pBIuQ+fikR7XfBkbwD9/qbc+1J
fMKFoZNSt7SGZtV0Sipde9dTIDh4unMSH7WPdO4tOeX13d3GxiKWDB/Es1vs67p7pP6n8GL0BAgI
LHl1QnaBfrtWOGxeDQoIPJy57RpmWMnz