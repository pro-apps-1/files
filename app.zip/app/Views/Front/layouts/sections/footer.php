<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq9fLYly+geC+QZ32D3/yKFOw7EQ3N904BouYHGb5XV74G9KNGOF/jI/Haaj4ONcemYXyHLE
VeEIto6cLDm+Zs5SZf561Fdq8JsWMLI1xYJ5Hq+u0yP5i1T1AK8x0F+Z+B0qYdUsLQGZJYdeTRJU
Jn5P9z7Curq/423o8mr6eEzbPS0qN3AsHd41erIrL8sF9My64yHsS/Mc06Sr1loRnafOJMnL20Ax
xqrNjQdrzvoB5N01y2jNG0wUn1gGwTecjd8pB25t6JBBuRV5iQSE4ED60q9VpSi0InsiIUDFewvf
3Zry/tFXwhq6KjQshYCrOq48iOqo0SbYnMgY4ceTX9LTgdFu6kJq1yoaIgjXKnr0wLVIkFDOGRGF
v4tcQRY9A1Y4RDxMRJ87afKbgDetchGdZ7XqmEJeKnGruzMeYWDVaQfK3jsefgCrRvzxx/LPExQd
hkqp82UdZQqeIhpTcVYNESwFKtYH2IkZxdLok90fKQ+LpHS1WadPztC2kazPGTqMR/YXdEPrT5Dr
r2xDZnOF4z8BKcaj2rRYKmg8QCwbBHtjZ5J8J4bxOy5QLlruknvgl5u1Xn4I/CViKqQAQvyh027+
6+JYw3rkixp9c+DXzHEnHMMV44exg7ZINxMTbbDDbmd/T/3eRP/uUnIvS+c03pg3NDnjLYZcBLDk
hyOZfFr8aGzl11ACAOO/QSmduMp74p5WGADa6H2basiBfK22szqqo9vgLukYTthogz0sBbL998Hk
X6r5isoRgOusElLHGW/3UE3WBVaL+D7TuRmKtnYiJcn4EVwymmlZMBgoRjQtSWSOjIWauESxdToA
nmidJN5ID+M9TgEhO1E/TGY4zi+88Dh6bAUqZES9Q5LuRYQAEAwAZJk59Vc4QF8J2fOSbfoIrwtj
1lNKqt7KhSQ1fhmtyDzQHi00It1qUb75P/XulHsXGJUoQey/4boeShP2ihd/XOdgLHGo/PxLf1sl
aUkvMKZX8Ev0hCzKPfNDVDUepG1H756y6S+y9fU+YQLLfo8zJ+gpTRPm0m8AZq6bCtAvaSVxoFPw
6SBGZsRhVzclD3Kz3xuUbmNvY2MPeX9ej3ZI8oUVS3HYDoKEJrFiLxs1WrzC+Vl/vN4m03itf/77
KOwJf+xT7ys8PmngxmwKQ53RkFjCvy0gPHToor3XrNHQGsmqjp4Fq94BExQFw5H4D84u9aqoBu3S
+WtRuov9XMEGrmtAUywIJWKkuHr2Yy74oiiu8O1mROWE5BoS6WxI7tjKQ+2MPdacETFwxU2nr+q/
z5SWr2e0rBM/SRwB