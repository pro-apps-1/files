<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtYPQVapIbB/3CfO/Dg1ZKWbL8qm/mqc98QuwuYxiTBNwereRp2wxeYpbnltud7NiQYKqPKq
Eue8zNjF009gneHVUZ5MLzdFmXVALki/YNesoU3kiR30z+tpAFN2QKvIo2MzX41hOrGrwhv13iFn
nlDu/qE2l1Dbd9rIgOjyVR65Y6gUnNzNI7lw7n8OVi86YKDsNwWOVIo5xGVLMIZPv1bovxr+yoGl
pJeotUdUHq1xiae4+D29uQ/spLo6kBuNua5zq6Wd/76Lpb7MaO8rknKwRrrlGK9geikMy02xfz3Q
Y3ejGO6WFLIlBmP5sy+2DNh9DFQjs6XIi7MhhCbGRka5McCgZk5N7pCTLdhYAe8GaGABFcdNJ7tg
GFLkL6qPWulp8sW5ZI1glJr2xMTGSaVDlKSTXL3OFGr/gs74w+AaQ7oibPyMqha/5bdtcW1AGGQz
lROmpU/39RdLvutbD+nTQbjqxegtR2BGH2r7cLPvIJAHuP/clHzXraDLlMT02Sn/NTluwnLoarHO
T1TTqYTfqWeTYvRhbZIM5/jgNnJQRj/dR+j3NID/FzemBvi86xmTI9NexCqUccW9DDAMSYs0GPHL
u1TnwFcZm79jK4lewGTtqtcn7OrTxTWsEqtzPRG5tEjX2aGK1NJSPVjuOGy/P4u12mIl3bhEXCo4
hL/ZRFjdsu50n7IwOJAFi+WdnYQo76+PrKkqlnPkIAIYluLBDicX7Kt4A/2/YZdzGz1HTW/KSGSG
OgO/anZ0vt+PDwbzdVcV8owGOVroqat7E9VUTdTe+RLfUri7gpUifpWSnJgJDZ8l+9zVptW5cIDj
IKWEkFntbV4VuyyUA4VU4s8m3hF8gEzm78KT1+xClEaDY7VokbGCepwztljjtjcmyYWczJtMU1S5
jhT01yEkijEbEI2G/YLvex47qAI7lg/KTaUkpNBNp3+ELLU0IyU1kZvps9xrIsqN9DVASfUzyz97
DRMVlqy6stlsTHyg3ybJ451L2h80N4wkbN1GI4oazkXxEkQhRxdBKfu1ODpYYEHYyA08uhKEo8I4
plSNtm+BtzZGSxbFu8Me4KUGsaY7ju09M+Qo6ufO5R72evB6mTSK9qkGyZAcVGDXUqiXdZxpO6ZV
I+4ITUH4IOw5Pq0DdrlVLDguG6xYbHdIBvJUC+odY0pPj3AgK9hK9uJzsYD/HSzHuqXASlF1Dj53
DT6nTiUFCA2wmQiOpo+1XcLS4HZxG0kCsjKBfChgZ7CYcJAaKk5VAtUjcKoF1cuNvDtq8XemngLB
p4fXb1cgOYH1RL/PUAc/utH1UW==