<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvEgvsuz9zn1E6joJTmJ3Vd7YAcFET8LYFO0cBTt7vsYJ9fNzk7o1fD8bbGXCKIZMRCk5xbT
Hl85gzQYZL2FZIvNjINY89LUsNI8nozd8njyyQdmUQ6gxzOlqOiQzsPkEnpv/uKF6FVYmazOcRSY
bgCriGDvc3PfXtLxIABgvjmJpy6/hUb7FUdSN36i2cRlwjzIsP18L+EGPUiez3W4mpOsJRF2rOOq
6CGS87+dmXsyOJTGiKx2yJcnhghAn59SnOwIYFHX9+XPhbv11mcj6MAwaFjRQotyKAp4o32XWnAo
WSQNH0Kmva6uO8H0Dk5eyAhHSTAjIruPUwrlMv1rSW+vOHW0QUMstesInSscsBwj4erAv3PEXvoT
BGoxvfXRjnqPbc21SZ9KybKIFGhKo4PS+J2KheqoBQI88nFs0rznNtuC05uIvtO/Mt3WxS+ix5pR
RhwHk45BQT67tsv/o7EMM+fLE3I+iYXsALNCCnFk3t7HODFpl31Zzolz0M5S+xJIu40w3UEUmYn6
AU1rnkNdGhFnhDwTeYRwbDCln7vbaPpDMOo1maDR0wOclhFSJcIdxWzisqIvsAg3pdE3EUd2M9ZR
yIwcN2FF8pUSOngMTmCNE1bMnhy6+4zPm/YhiUBRsFJiE5SwDE51CwY4+ubBUHZKyw7hvKxiEW5B
NMjLdwJe5qv7uMpj/gggQADaBv8QanYC43HPqzc3bMAGYe7p60Br4vYG0HBer10QTqjGCvs0zF4U
QGKreeY1TuDt2BGjzNFMEdnv4Q8MfW+1D5O7yMBXAYpryhmRfaEevI6k/iwlIQgPh/HwfnmbbJAK
ASYEg9D9ulrxVCLWHnmIxXIHX1a6vJRaJONUObEMTmamaXhwH5OtClgWhLJdxJsHndG8KKwpCL27
68hN1zR5+L88WsKQHavlQ4tF4U5W7GPqOm4Lrx5VT5QvW597ZGQDRiTOpHPTc9kv0VuoBXHOjrJZ
peAt1MR7yKar6gFUlP5HQYucj2T9RG70j6IaP0ZsIrO155Lnh5KxMVG0dUabnbkHboYJ+LYLeBXl
UH2/jXnqZzV53ltb2jWm5k5E61IqSeJmYaJPlPZfH3S5D0kqKfM8VgdJ6C43fOGQusRIxhbnIuQW
5npbEZLZrnytptuArs4dVrE9PcCtly+0Hsk96bHmdDDKIMl50U7TbBBVjBUPN9Zf6ASfS/6yDhix
HEkpgAsHe7iEXUf7XkaJ3vqdweFMBZdrVF3C/9TAV10lslFk+o9srYU7ob+URC67Jdxp7mO0Z0Q6
AG0KJuznUjLGTrZwusF8uIIVkoBKt2AnJ7KEpW==