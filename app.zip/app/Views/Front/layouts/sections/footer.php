<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPw2iIr5L8R1c86tUSkK3rxJAzOOV8XOwY9EuUqmReIlcKZVHI1WlBTctBssRcTa0Yb4eyatV
FYgg5cmjE9IvMXAaQOadENK5KjEA85TaYAMT1oTMgw/PZWrwPOeKHsRgIxpDR3SRcuamln2SknJt
dVsKLwwTfBDagDm3e0VbtbwlJ5M7O2aIWErkZjwminB0kS6hKPxXocD/1VFwQCFxQeCHmEeoBYl7
9GxeZp5KHW07uf5f48L048EXP/4urSgkmGG6CEF1x2Mp38X0OBGOBrINoNHYlESXQ0V0//eklV71
Fejw/wjuImLT4KpKQanibOt4vu6+tJixN2ryT48S2LgpX+9PKIlC/GrFOEzNW2FJgXomE/uuXXzI
ws6hADNAdtvUXC/tCAtcMAyQVtN6VQ7UB9Z+2ABa6Z0SxJxYzBr8bj60TI749E2inG3/LPL+S5h5
T29CXHrCoNsHhuH5Ttb98iUek+/m7jD9tLimtH/yShviIVTd7NYHaaN33GOQ0rK3rqKhJwEoLtBg
ycb6HP8YHDnbvNAL7DXO4OmWB/1XRokMjl1HmjhKFc/rixUawoQWnUAs20+WaY1uu0CKOy9Ws5DH
1A73FeWm4vZj1fxgpc2qHKhNh+SbjIjXpw9HAGm87cB/yoLGsBDk+uksi9pGAajdhxCgdRAOjc7U
SWbi/XJxWtvrLodC/nN3BY8CszMl1qOqj7unTbtF9vEqH1e/x3CdLom09camDGXcCn4X5bQxpEyM
clPLk9w/EVQmK5dLgqbV8QK7hEGX7KKmZDp+tfPVgj380bINKh4QB36SmRzV26U8QA/T1FB/AZq3
mPiaLFvaNgFW5oUnReOKZLirDiQtcub2ML7c118Bx11JHyFG2Y2u0HBe5O62bpwo4O9HjWfMz5ew
am1EOqD+Od5fJ7AKsbvBa47MXkyJSVOlFKipHGD5Osn/c8os3DYIoAa0UEFJWhlt1oWWzKEixLUN
Ij4OGYMOrHavQc4etpLl69Hc/ruSw8bt0hVYtV5ozvszEDBANEjp9XBlWaLsjZJ4Xr2d6k+/rZNa
J1YTs52lycYw9O8NkCTjndobI+fBferiXVLeJZRcwXSLC/aoTkklHRLUcw8F1dgPPuk/dLPmKidY
Z15Hpqpik3vLYfN7Ad+YEQQm1h4XBmZzEYGDdQKS1zhbvOnrde6DinedDnqc2VE1ZxyWgBe8KSdj
ACGsvMzg6AODPTu0wOKi2DPpRNgCz3RvfXPz79f3eCKRybxdEFwpfSSg6WAY+1JwYQTPRBso30mF
jJvY8zq=