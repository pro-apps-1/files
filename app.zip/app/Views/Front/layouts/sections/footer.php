<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuGgKtyhfwTmCkl6NE4XT3wkNqpCTFRiwD5nGUVM7McBgp5QwdbD6jFTIa+12rGPmLqHWdzA
ZF8WeMf/qKvR6tfCWDo0iuC1wPMnhvXf9LOOcIx9wZAnptqO3cpfmnr8pKLjKVdXdrOtMwP4m/FV
rm03bAQKxk9B616E1p1485ns91q9FXC8Zo5qTCs3Hf9dxlgU4wCOwRDRyGu7qxt8im8772aWRFlN
H32lrnYeDDE0SHNo1QE7abN20df4d0PpVHyB+IVXb4oTzhmv2BwKJROdXxxPOd/DmormjDqk2w6E
SyheDC34BzFwpMal2kuHSWE1CU87oTPOpGXIHGQ8KdEm8R5OBqjgJAPDFGY/e2swQjR6QcxBL1Lt
wciFxPUxwuOgE63cqqh26pgPJVyB7dJmupsdJTxOX4RHtgWFicONM1z33S83l9q6mvzLUCkP8nK9
rx6XHlAfRLf+vBtgdpIKthzYjBS/RYOcFX4ERxS1OgjIoKsNLoG5dr6WBCpp/0OVHcQSntdO2d+3
+AKEM3P++16FfXr3pwVIi7KddcN2ln2qsWEKz1y+fLiAKQDUgyz+YBFcxHFGbz5GBUvCNaL27vKq
b2TM17KtZdnsUxT1JEF8PDmFkM2Gx58YEG2uHOR+XGpwrg4a8ky0uoEu06oLySNsQEoskggvdqSW
XLD9b5RxVuq2IfPJsrw4B7xSdNOhsEO60wg/J4jtykQFX5m3nDuP2ssFJv+dOrBTTENeO0PrVN4t
owPwSb+rVj6yDJd98q5/uJjccaELhf+b5e3OIfEwg0NgcX6i9q5b/xInK/pZrka1cn+BT40j8rd6
7M9YudER18NzNyKIoamJRa1o85OZmuJy4doegBLnd1arpCyVepGQVRhgT/l+ZdRMMQYsM+1o400P
ddUYrHxuVjJt/EqOg90dy1fUSBoESdhfBR9dD91FhtZ/byUL3n0R2YZOql6tJGxSDMikJUaNmOcb
oAC7kxtNuPMygrpYwGGK19ZT05Hav10+EzTULFO1dT98XyJtsv/RRiBrt6ulWrOIyC7xUpbJxgng
Lqnyq2mLveSdqXekMPLlpZaXJVDcT8oMkAtfnWOMEshMvYKDMlB5v5wztngh3HY/ok8A5CoZ4Hu7
9dGpss4a9FdoaENf0G7bgPFeqw2j9rwYdYGQgCO06xb6mKhvHc89YZYXWu08BWz8/9mbqbX/XGmZ
gqAg4UJtmWnArvPG3J3ler0KxSzHWj76vOYRsEmbhagJyzqdfutmI1I6qqkWs/eDkpPmWdklejEX
oJV79eGTVxK4RwDESPqd