<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxVaZfrSUNFI6IKRlhl1O/IzRuIzvhDX5SyNk5TTjJI5jJfOUjMUrAuDmCBEK6dIDoQQe5CD
HXF+sgZgIOC+7bQn0StPnlDFIvbz0GPz/e5ANDXncpJN8foB7NPpSOoibLW+T+cYCSUc+Zl8/2CR
7FIOIyHQ/H1vjOhONNhCcBpHpH9/JXnOyVBjdNWER+fZdWHTd0/+BBZ7FxlLPXTRvJk4vUyrVAyn
pNGIqFonuCS8qQVI7s+D5+SiRdcph1p7EGaN8NOKAnTu21puFx0CpmxcZikmQZWxb6os9h3E6eBy
OPbOUaSI3kU3y5+iROsTGWOl4Zl/w9Q/CNnu3flnIf+4z2P6pKgP1qUmbSBC+r/9tStQaHjciHal
0Ep6jOwNp1OCqWdNmMi7/dxqKvhgJwS4LNarLRDAUhotU6OdF+M92+8SH37hBj4i2Ud2Rpelmadr
ATIQlutq9buHfQp5DMqr0NGZHvCItx1vMccO7++HjF53HGhFF/kVJpkUOI28bV33psLwg5m+/rp6
bP7XN3NCqO1qEVApKUHPVcIMLv1+i9fh4Zh5pwrPKoViMSbCatPpOGt4QqUCAsB+f6cMwNSjSA5V
MvCzhfUlQn8O26buvCMeZ10Ihu+6U0yV0CykAGiotEca83NDVBbb/o/gpXNyticWOujnUgVvIXwq
5MQxrxARtc1huesO9bqruKDNe72jfrwpYvCQZJIUbtExnp8TmQSo69pV3Lm6C6zNxboqT5D4/7V6
zwKV8nS73IcnXrhaj6bu7xcON73wPoZnX8avR6+1XAwpmYMLQx1ad2CYxHagrK8GPZw78tNffgSf
4+BsAw/38CkVsaC+ULDRlRpr9B/i4vS+KF31tLlu4l86brfnK8mNoXpVU21CxnE+bQIJENzxORm+
VITNgs9iYFfQW+ti178dMZ2Y2hcWyRJxG+kKG4tVsNr4T2YU2WyFYGIXBwbVLtvwDZGumtiUPktg
NjLWRv9iJ5DIv28+X2wxX2Nc6hgBc/ilfxJw+T4O4U7GCCB7PuIT4XsSAExypftv2/j0Wvy+zWI5
Ixhf4A3jPqinpeCPf+OAXKo2qXUeKfCLr1T9+6Cjk428yL1MTlsPCzvetx9E5fp9Ykn+b3CJxJYb
PTWlPPmamseqTi6uH8MGTcPacGC88L4REaGIWBtfQ00RhinaN8tERvSwVZwT/BAk9N9WA4DhuAKs
w+lNnqXG+3NQhaPuE5h4v97zlja2lLhp4tGSQ7BP7UHUYHSkRMlV1kwJ/gA0zPiAI1nLppcJ8yAw
LIT7cX516fg0H4xX0/0vl4EFffvndwG=