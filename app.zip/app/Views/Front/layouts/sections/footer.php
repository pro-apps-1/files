<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqAsxw/iAzI0wNTwZDwUyJENSO53SoJM2ukuQ/bPOAEb6d/oicFCzM1x+75vizAXuEmJVhtJ
shjLowHqH+IHlzpbEFNPBuCTN10MJceijXZZqu/jM1X3mYLpQasNmLS1BUEvuawy7E00Xdzw4AQe
VYGN2sGBf7dNJSh0+Pfu1vn1yP/qBLACA+6KPTNlHk70KqOz4CA2z81fwCuLt3E/1SN6nXMCpA41
FJAfs2F1HFFNnRrd4THcTfdDRMnLX5zg0geJIdpduDuQEICruOA6s+HRjQPkuyQMG7/4GU1Ugi4j
+xeaa5RUw+BdmWOD7S9xHvzY6lDxK9rvMhKaFSN+om8xHrgOUD7wqo9Q9UPeYktf0wjG5/J2MWYW
Qap9dIbXuxm/zxrrUdi/rB/yzy33OI84w/c/qL/MfTxsADXQhTK9QvJSlLLAczNkRX8Ge5o59MY1
sdfirNl1xNgTvJ84FIMdRIZvAtjYVXBLr0LR8FLx0fievOGODcxP5ikrgsg6CdxzwHAXri4L54sp
fZFdRDzZxHrqN75BrQnAMh44PkzcrvkzvE5+EtxHecS1BvW0gmdZK8cnbFna8G0LJfHEKzjINZU5
Ydk0HSDANrGhLj1i1wA1ROM1eClbSIpYWd1ryjZtSenf4o05I/azbRQ0WOg1030D2qltYvxlxdaT
43CMAjgJW2NTtoim6sSiqJ69+OLU0EvfBfq3ITrxA8Rb/Gy1wo60NWX6jE0s58DI3yeIVv/44kBM
uLWcJFfhMz87cyiURoqdAy9NWuv+P79EXveBTR3j3BZhBr+H0Sqg5SKnQ+WU7QzZXyphs2D3ZuYK
LbuTQBhbduatVWr5nV77nX8iAjobCaMVcKcrc+NISrgpOHo3j7iPwc/cK4VPOaFxI+fFchQZiz/q
BVsaaLfWb0SNwUBmzy1t3j6VD2pftbdbf5XTTOpmQUiCdYlbGC6rbaLC8SYtOBRHjE+o7dYXYTn0
Pq3LCAzx7sHSm7aXOHykkLd9+7dcawM1hKppBjMrsANqei+/pcNgByiTJLOfrDJBSRcs9WQz/D7X
64jNiEGvv63QXZ0A0oWc2HdXGiVH9sb3/QVQ+EUCNEZmXDZarNhxHhbwESfZQarZmf1j2B7LSw/O
48ONS2qEjaPBWJbdDjNNxcrHQ0K22KY6o+pct9Wb3yvi1xswlU74yfaV+U3QjlUPG1jcVf252EON
UfRPUIs+KTOkWoUAtOYnmWXtMVAOqkFuWlQ7L09SiFM+mqCZyeyYOQIZ6jXwKWaOky9ph43f0b4P
obAv2gprvTjczw4bOYM097u9Np5bp0+Zee52u0==