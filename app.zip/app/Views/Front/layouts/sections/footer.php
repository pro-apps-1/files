<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoJ4+y7EcS3sbmLkuf+b16V6DGDzJznbMv6ux9FjqiYU54zJrWQ2pVUCkGUgV5akMXTG5FE1
8m87rm3H2jmGl/NMRbIcL6rfmdMRKoK0de7Ie57B7rfiD1NAKNflyePYJF/MbVCSHXei4/2yJ4GY
wsxC8QNSN4teKeIrK0bg65lH+zhE37c23MvWhGhJy0hUHec2L/DTKBC0EfrvVGa8IvUFpeKWgyyn
I/mIa3hPoEjYtPSdip+4NuBttfTXDz0YXX2slg30UZr/oXUPysMTD8bFf7Pdp+cnluOWi99/OeMY
I3Sv/y+8AedH5V6OnqcCytILPIZcO2EZGrhLQfCFy5coplHCf2U5pHXoQYKoKhjR857qXSz7hr8X
17ofJPxXcvsBRlanZ/n55EcklzscY20X4Y2MWvw9cyvow0vLlpychUi1q3wdYuUKe0qcEqu6wY+J
HgPtK6yl+gwSyZvRw6PNIXyYarYkkrZeVGyW1/pg74TwNGdwnDO7vvVtA/8LMW2k5DzPivmojOHQ
tx4YuYQYSZVQ+weXb7mTNuhGMDEMBuVEICE41uOTHAbJIhnIHCuXQZ+Uvk9OBKq+2kl9Q8c9yJ6z
we4ejFrwkc8tOsZKC+JjtLS4lG64MUuDBJSbb5OL44TZAhwYC48RRssA9fAiLjdb+/5XAQzNGXBi
JAg1zrjE8Gb3rZ8Fh4torLU77a4CXSbhfGTFmjFZISdGDTpHheqVXm+UDObWr6ispjK6b4wQKLVL
uHJk3KECqiz0TPMxSgFLt3KLXrabc/UJZD1NpYoreKZoQve0zYwXDoMByhr66mpVqus8itJSyzY+
WrfaODXenq5Xu0VfUucbbC3Vz6I0xhF3ohJbzvjS7fKt9xbqcHlb952tz5oGRUWKKVpxWVGAIw0p
1mTatx8otxUPifLr3QG143tghSaNnGW3MlEbAwB8vaU3Cll/jpvL6yZWlSIjyWZ8hII7VbGM9Pc1
M5Ap+mc2U8B9+VXoWcBn6rL8sAMTeq4+5iUaM5W0inbzFJVJJJxIKtjQ8FjM+RpLUg687odR4VQo
tfdkx0pu1gkB3YOvc3T/bGmboZBeqxkFXPDssJqSlsU6IgnBgnU+yqQND8beGy/t0E8+t3AZsSzH
xNdDivSgPumWkjB4DAkMVGu6D+y/lHeTc4yIPLqQiVOeq52xp9lPGcLrXtoqfWUh9mkcBRYCaWrK
gQQDOm8rBuCofLEgQl2C05SBisRzR71OAlLkLNcilY1ptrwYC8GR2gve2b8NYmslHiZxCnxrgk9w
Jj62g73Ogfydtch4tMJ7epDsRgu=