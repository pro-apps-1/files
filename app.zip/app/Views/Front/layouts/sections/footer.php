<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtz8ODas1LaVpudr+cfQ2lERYarO9TKRwTA2/0RYzGRfTbCptgyMzcWr50f9nxnIHq3kTr52
4WX3JPcM6FbkjZL5N42cH3aQDYScZrzwglNme8MbzIopW3N5obWUnepd2OG4LV0ano6kdhtPeIXR
NTmKHUBcLgrZeRrsmzlP0S2GusIVfJSkH1O4hlH2Wc/1fDYx5MSBaUmrMTmt9uqr5tvCLILfzi/v
P+n/983I1w4UxJSo4PGaOwZUTApXM1Yo5eNT9Ndcw3OBYl06iL2goSIbkbb6PfJAOmO1PwhIG/US
A/jwGF+oWv8asih61rnNX2wGbDqO/+LIej55/X3leibWAGAjb+36wE5Tz8xRiPuUsNi3MCMSKvMg
8+qYHtkNytF/CrPUNZwyU5Kruhhe9qZFlomLLD418bfZTnjCl0Z2hVhjDJQVuN7QjMhCLDrN9STp
2zgyfLzui3cO5l3tFQFJkiLUXh2eKNskpNSvRnC+AkF1bc/j7UkVAQ7kGYn7yjF90yhM46YzwyNX
4tDMUf7i1pieHLNlElrXpREZqKMbHydICTi3ZXEhUg3j65pLbJL2glMqV1LEPhiMh5z64FX3Xg+e
cuDFpxGU48bAn13RTHYxGRR75QZc5+hODro22HMd0T5usNkXhr0ZWE2Bnh6+wTqllQDyQBiKNoaM
9XxpEPmvRiV3BRxUZeWerPfYiWnkwwHJiDRPBFUw8OuESVkEnB1me5zOGsyAf8+IzV6O/4tMXd2K
WFN9LvVdCb+sIpltLzozNO5PsX6EA0QfbhLPKa4o0Ip0ewRjQ586ziwcUxsS07Wj2T0Knc0cwhTC
JLXYZS5oQbzQgSX1Vb7fFHYx7d7BBzMhDcMSJrXf3TtPlrDHXcSe2Dk65X3p/+zvdVM2MLQgever
g0uZr67J6jBWt3IC7XFK9bOPs0EZGQEOhZGbU3fKqUEitfgmcoI6sxjGPQfhzJyzqO3squf3o0c5
nc/fjthQi5QOPGRM43RbMc3rPyMSR5am8Yv2jKcN8ri3GxN0dB7vhxo0bQrmxuZOza/p3VQO+r3H
NcUryMWTzuMw1qMgpMxzpArj1ZyOkX7d2t7JWwb3vXSaQ3Pfhsg500XLC9nGzRBPunUzAxuUZtbG
uS/ClvzMrCzLYY09XWU+mqxjD2nxoZsCdOzuUqIHloYDLmhH8lmrAB6inYcPvcIMtb4CM3GLtkTR
zue4gy+daVvYFpTo1G++GKFqnqvJZFns7B/jkiF0eM0FfPxBQ2jOqxzArk5VYlkA68uQVB6pAmSp
9FwvM8qpJoHqVeTgntxlhQxDWB29