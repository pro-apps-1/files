<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnW3qrMlt2UQji96ThMeLG/mOmdDuHBYkeQuUx6YGnRyxmCnLQPaAieNUy5bgIMCIpwwWsCt
UCdAxTqjOpFi1/zs085ugF+6GC6VvIBltjDVoloNprKho2BrUqNbeylfk+l8wkkChJq24FVok1EN
APr0X2meEFzDKIdh65ptdJASQ8mOSMDaTQBHyFnmYG1TnnI0YfnbMgAMT5HJLvr8TV9PpoiPR0lA
qjfAkZx/y8CDo/WqAvsOYi/Mp3abXn2ZL+8G1wkSve3f/SmM5W9QCEVAiWvjD1gQICx+zFk9IqhF
hIu9VtU8Y0rccaKW+ttQL42M0KQkE8JUhvHHiIKVCoUyd6Xfq2xHqNFFEmlIffFwzG0hb/IkWTJg
92WW7qWDQ6qQdzdDg/04IskNy8dstAIiitG0SuTpCq6XUX2aQR/bRRh8EpXWRvD6V1NmR+b6Ewor
lOr0FjQJ/heFzcIRhMHvBuA9crT/4taVqcRoeC0xa1neJlqXdqmTLey505HQ7xZi8OL1dVUwo5HW
SlakE8n48+AKhD12zcqY5Woie+AkJArsdRZKSK3CVdpXH2knFlSdSSnG8O9b5DCAnm3v6g69qmmt
XjaF25cgO+3szTr4BaRxzrz9vYkHGX1G2OLdCtq+fVLEILu2fqMUINPRVDCKRHTnKArznatYsZJh
0VtP5EpTWyAvUZuvKy7zdD1i+HGZak/FDFhhMk7UNDcD4wVeJ78PFra4P6R6lIf0q8/38mrx+NBI
hyl0gnNmTEwnKdca6vERJ5WPFPQZNMSoicVbo1YzlHWsXEaFANJZIgbDjn7R9oYHbTog5IblJ+7/
OydF2iOHWNDuJNzDv+ETioXCb4gHSmoo5068kidLOPRqnCQ8mPuPMvXMLxQBbPh3ejFlSxKFEa6T
3VxBRdjYudEGucjVdVv9E94FxCbNZPxGmJsC+i79Zasi4Ne4WufVZZJhBgQ4YwwVIc7d7XCmETP5
cQFzQN3cJxeGQKeTsVv9IkNfNDAmbj3xvtqOyABW/Ah+qNWD+rGKIgjIg+DbS3BVAxUme7DS8t1B
+KPVNbAFxoShSxslnMg30Wsa/acfemW1eZXC+TthAO0YDIHPJ5DcoN9pDab/mrn7L9Ws5ZduDVhQ
WiD74hWoqd8CgRRao9NFs30MZ2E28aXR7jYoN6tQPlctK2jQjQuIHdiqRacbR1v5HHkoUz9/2aKU
Fq4iCcau/QMNcpSobaE3MaqHVwchPHuE+UHcRaU+i23UvIjnCGQ8Fr2U1L7hqxZcuXFg07bWV5IH
8RQBuGxZwh1Kc8yfjubflGlyjb9rCLO=