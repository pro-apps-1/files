<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrZ1hN8KaXP5uG0uKGcuI83vHjfIcBZj/QMuyoYN+iYamW3zQCoUv1b4C6MIAMSrZAEvPteL
Vu4MZwlwafmPxd6lfzRtK/14pYMngl4pcq9rVTjGhM9OOjSdyQCXh2eQQiqSckRSLp38agBQHNmg
t6z7C9QY1FrD16zdgM8ZWdOeElSAJsOYqZKLHSbQOmSzBqzM8lzP+h0mDa1mQxbx9eaK2MTwfJvN
QmPi2kRQOgNh1lIkmnylu2Z6oz2oUo3Soy+lUqoPPhjLP//toGYqjdKiFXTdY26ya5upJsG4LM3a
K+zKp0u9h3yZoQhZ5OelBdqBekOlyvdGdRLSW7D/60logPR42JF24X8RQwgV1A979VQroxtgpnF0
WuaFrh5XbSGNQI5hgvJKSNsW4uREqghb7sDTCXaWmxx1QC2X4zTTBiiJPodPDYEXjGZgmPHrLNDV
qoZmqDUgjE1vzfkj/KQeuy8dFTWJRyZNky77+u2fRzetW4OQPmHKSnC/5Yret4JT7Iej7d1vlAUO
5n7HvmFC86bcrrsCFV75b49mkJ2vVUZ2diSJBoD+msBy5L6RMvJe5Z8B3G6wltaZauTT8QoOEJh/
D/b5jAPRB1nneA+6jERhiD6IKNRQ4vKIJQA6ECwUZjxgfo+OCRFkR6Xr3Xjc6ySKGPj+JPQXOxjx
xgG4jcDfEumCU0Nul71PddJsEJ5zVdOY5lvTSXLcJpWF2EHFjMIdprZdxD0WhvyD5ROtBiv6wFtb
y4UNXbREBG+Vs9qcAgDe6Smd1epxG/MsrOYiDqE4pBV7JG73smSTLYZTQGKWhrBDWB85XTB/+Gpz
o0lsRaXZxdUv9mII7/yzlK+FkYrcGgWGjd52KMkxelYun8HyX5pje8TrSYIR60EByVgNiJTEr1kE
rX0pUDW7QRXgvcKaka1BX1aAQXq7yovDfeKJ4WT20lVwkaowCQTfJMqv9wlh7151+mDHd9qNtP2c
GVUGTXsO7vVM3D05tyBsmMH7W6ngM4yoIEfy8z6jfykWP6y/Ut2zZq9ldej/jxFcENxYDDxc01Ah
ddTddYmQePOCb1ceSnUZrcvYrXSADVFOxRj/+R6q3gkwFbeg6qOCIDn4EFwnKkscHN9l+UwuY8Wv
CQpVBmp9pQ8+lKXAx0uerX5E/w5ErhBVaX430DQr/wAEVEIOojsob0vj3wZH+eYyKFSe9ZCUT9Z4
dB1Fo8F9EB2TUhbkiGm5h3NlPmzs1ZYKKl6b505goq22H8v4e58kKHTYfJF48vy4Z6j/3lrYaOxj
hTkBAYzAXyODhfrgXd0=