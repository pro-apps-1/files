<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPssE5CqHG+tYx4+1xkGZNsy5E46ZHopOjg6uNi6T0ez7/bdE8yDId/1fOnzqu24xwomTleEI
3WcX763fojaLNikaelqpOnf5H7u7dnHM58/zDtMOOyqcoxytHdzDVvTd5zmg+NDaCIdTlaFQoCmj
VkpHoMbzTXgd7hQqisQ7ZPeBYNx5FH4ccb5EukgmE3AFMtIfAobt7jYVgGM2vVfaxXSrpTLMDkxX
okVGDpzQP/YQos2Wlztp3Yxf5eZqHMKq5Cgw7nWRo2Rxs85Hakb8U5GQA/Dc7XVNUqEGAw9NJSAz
2NaP/zLkm0w/OGA/jvM6krY9fxIkj124b0LdCCLJTWSkumI6EiOuU+n6CdQvN3f7ODULMDZAGRX0
eanKrlHpqi6jtj7Qnwq0s17lGpTZLqDaip3NoeRK7nmRQeikW7lcRkLGncZPfReRqyxFo+OoUI5n
fO6jpK5E5DyZWXdKsiYLfOYaTgXMSVo7MxVbdmjo+YkyHS2j8vQ1ic5beuaTV2JFOiDkiS04gffq
wlDcPw4s1O+NGR57+r5FXhnqPpSK0rmHRNFfaAjFdvp6kg/rPEj102NL/y6QwciD4G1vTwbBDQ+H
gqjmuNadvKfwU2pRHpJnoVvwkpxw3oekQ21jsA9FVb//7jCmbalyjQF1B5dhzUjwaz8d1+AHE/Tl
kZhALaORs0rZunI0XmtBRAb232pR+1jAa56aTQRoAB3+uYtOYjDzwRqVNR/3+t1R0EQcyhQES7ex
gZBNTkZ2AqjaWpINhC20B71s0y9OjQPfFVrXTk0ZD+vsphHIatbz+nn8MaRT1A6ihPy8JDpycs81
8NurupSwMMunbyTE0HLP0otgQMWNePu4N5OR/vgDJxX/3TUtvzAkWCxsR449Y08kQo0ZLhyiXHN7
y6kZoe1xl1kD1DgrNRAU6/FzU3hHZPk1THGJlQeI6bJ2TxJFyHKPIArARU+emfjfgh4LCjVoVI7A
iq8nA9XGe5co410KYIi45hp9xasB7n7OkFvBJqstTGEdyMy+i3IuK3jHsbwzw0byoCIhvBJQ7l5R
U9qOZaueLIAEqvtPsbTBWE7BxX76WcEPNbzZYog3uh+bpKUgSpsGwuKbv2kbTmuLzwMAa5V/O4y+
bJZP/tAMKH95lQOw8nVOm8t992x1z8fCwtkmhVRSw/UuXdVYN7eET26jqeZ/CqJD7xzwIoofkf/T
YzuU3SpLdisSTudXeV3k3PUxSPGJoKAECyRNHwD9sDQvEkYF+SdWxRB5YAll5whznJ/LKDiHmGRB
exqUV0w8