<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtLU3Fqxy/Jomf+PteNYBJSZlx9mSLSl/D0csZGLQqX+Qwuxg4zAk1B0AFD3ZHg/k7Ng1D58
Ejx9k8kMvYpnKeEKaL//Y7+1QL7G0PYgEr/zb5bXdaHgam4GJXgMyr7IpLYXOclfphNbK4+tzpYW
wT4q+1tz78L3obIlBD3MnBB4NY0PeY8QYTj7l0HbFWzaQWaeMgWMvmlsgTJfjJdDDJTONTR56/Ov
mjOJ95N8yMfuxsFtGX71HJ1UiB1P6t0V0RRq3zn2WgoPKlaAU/XlrUmuabRMQexcApIEtCy1k6jR
28mwE/+8ojZp9olozyx0PGTfRmiCb7u4JpkdZn012KUFtpdnOLBvnCPnQmmxGiVt4ANHvzyYckPK
1ma8btPMdLGJbq5jUWsMMHlbbDGcqjbqSKdC4zO53fJVUIMU+KV/lw76LiouJo4n/s8Y+i3R60QJ
cXSJG3LOP5e8S3tRY6Z+j3+aLYXKgEzNNtUVSo18hVRVMrCwbNzFQCIFq1NiWt65g5lDoI2SzTaP
g5E8A/3IM+hZDAlZrjYa3WX8/v0laz+75TW6wAaigiSXN38CNOdNVpcEFnzt6OLhSjT+0DrSa6LA
91qAzb5WS5sTDPQKHnGqByU8jFo05depGMY6M5MLX1zp642O7J6uxc1e7cZ+YN1BvNC5CBupSsxC
NvEB6DwKLL8uFhk8YfI5eYMi4kSS8sYzJcyLONvPa/IrghpyMBLZJXRxz0huS7LffJHzPQGREdxb
1EntVzOggmCdVw66Ezz4jF0IeNhiXw1s3ClheJZuD4kJ1MuJAucjtJ+wwvu6AgDFhvVTAJ4QaT90
kWLVKixpsPCBwILkR2490cl2si0p6TjFsOvmxVFpLtBhh1tLlXrppMmmL5Ml+s6NCz2V2DBmuQPu
xiNFJ8HQhPeaMjPJCsCSdvq4NiYdyZXNVF4llb/o6Fze2J1z4tuYWHfbOEpBuQRgE6rKa8oTIvMO
gIK7mTdNNIiKY1vtvYggtmYRL2PmnTJAk6xQceZH4RQQ/2vRc4hcablZDLnRY0aR5yi/nBDNLYQE
tLTwE1eesvOP2XnqgjsWBxGxEKw2yF5WQBSg4c8qRrl3d4aS04wg0Pk8rPnMLwlf62oKk99/CIIo
Ub8ahAi4RoeZIM0NU6Nnow6UeJfeYOHRjg3l1hLZCf6xRyb9HtIzFia9lAzD9DucbaH7iWyoHsVQ
t5o0IVyd3yDUjP2Q+B4bjgasv+/Tfeil3jNeTimIhK99KroBZgNRy6CaW7O1Qd7rvkQVWlsOVe4U
ztSBYSfhPs0ooN2u/MY3XG==