<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmB/katXfv6rrhxzsCAgQTIshWWU1ByWjvUuQ4j+qOAtcGsxFlJx++liXlOD8u6eOifBqCJ7
iXyky63ZQZ3xMZIWMRDQZxaHiQhmJOX2dL3KETosau4aixOHqUHcBg+C1qCAHfJcxWrwR5I/pQ9y
tNnmcwKouzHaXtEO+nwbpzgmxNUwwWCEVCYpQ204cnrzwh3TsQ9HWw+seC8f1+ORuIf+Bas7m9iR
5CDOzJ3Vl5EsxhrICc7wjJXwpOQAgZGtjnxJZfHpRblOCEp/A79DslgBtm5pIXeaPQOOw8rLiing
ij1yMszzPAr88nEEDKtNXIYTYkXCZLgiTzxsZGpPweHk5HEC1gck9+th8FTJW/vIu2Gp5mUFqsJN
DFwaRzhbKBwGMrDfmi1iLaywdVCHMEMbDj0Jg2pm/oG2xuCB8v2SXrsZgpOYlnVYnFkErmVzbLSL
QGivq0IfcP7nrVJuBJC9h/Fj5l4LW1brfk8joygbTQSGGgbmVMEJEKAMq+kKUCh+Xno2pKyLf9y6
zl/lRz5I7D1AKGhvtaVlgL5WkRY0mI/E2aHe76KzPUJrKQs2K4ET1637zeNfTtVff3FM9k2Bbzho
5EgwaJYRd2kHpwVJ4luQxJETtN9T0eedoS1OUl4tVaep/Ix/icho0ACPureK0cna0bE/sVZvqvnI
EgGllC70z/g/rjjVXZX69k4SmXDZh7XH3JNjAmgFqOklSAzHnARRKutp+iEc++SJcKpe7aX3XPgk
1z2Os19953gx406t+Y3kd+Pgafv6CPmTCXatSmiWimpEgaF+9gOM/XY7KyKHcOhOEtqfZg5P6Gwg
bEl2YxXt5qnoAR7G7pfQHIYCvp0jfuL80r+9bisZ+6WQ9a+BWYd6141oDd8REkJbpOFNpNmbJ/oe
sFSJR1FjKPO6YwDyw7seSpKGduUYlCSavkjo5ioLiRoIRVqXEk7FWFLaPsz6ce04Dp1wO1Y6jtR5
SBn7lL2m3LAuO1qYjbl9yjAatrNM/S0lOp0Z33iKgUfdyCL+MXLeicARbR2aWXJL9hgLTfuRPlkd
ldAknHJ7htTh/yUbexQuefuO6aAgW2vHtbhpjFow0zPxZR8IYYUFWA9kjGSx1Z5VvsRBTs/ofTsk
83uSFu0aP7YmxzKonigA1POxC2pb+llcuYB9TRtEXtW5/0KCmXuesUe3j5PD70SOjMMfcebzvnUx
od5Tui2DfqOfNEXCK74adMwZeqKOy4DlgfG1o7b8WHQ3I5kYuWFlfAr131GG1+5OjljCfvNr6+0Z
B4PDrhLwTE72