<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr/GctSGZM1uxH4ELAzq7WrN65SKgT3KQlTLoCuHBx1lLtJjosuv62ZfzW52UTG3qskpL9ee
Kw6bqh33Y25kc/M6u4z1QQHRquKkquKea3NOpkCPrXJCoDYKoeaCFVadnGjUqJY6lvlF0DTirG5C
f9rYRDo0MX0qgEZldc3yYdM+XJRFnuPUtFRtLzjb/EU8QwPJJlSa4pRFcXEtISCRgmmwPt7v4HZf
xK82lH5XrL8jChRkRZh72RbyTtisIqJ/ULhUmAdLjW9MoV94lq2LcN4zhW9YQgcb+ybOaaPaOsLU
Fg6STHv/qjvIc3f+7fjQKLj6iuXdUtFTnl1Fjm6Mon9SsmILOcRW/WJQNSFk/OMF47puSnHpn57P
bO6QceurosDMhYyVVUCqJvofVTp1jDmDVDWuAZdp/VMRaNqKml76GHMNX6+m/z1hBeWgFcNPa1pR
o5BXyVAQoQedV1XMohuDp11V9gJmgRLsk08/OUr5uiXzvuz/Xm3Jqa1WzJUd95dpA3M0HmEAXGA2
DYDPJ7amcbUN+A2GiYvrYq2dsSM3vWC2oChZ4IPX5NcLm+UdJN8/FjVx//hFV0M0ExiD4jj8WPWI
fBFahOONajsnlit0SGGICcYtZ7RErKVkkikDjL/uQIfifKDmPTNwT3255ihua9mkKa+WcunYYIx1
yi7f+9Bn3P5xa+Qfnv3l0qjddQbrlty2Q/7H+tNG1mpPBImPqtTn3vSl/RUQnVIy9J5R9AxCjzK3
ZSdUWdapwbFjwGoNE6pD1t1ISPCPJS3ka0jFX7H7EhLsD0KpBQ2W+QHKOUCO8tzuGrncHtvS/szz
2dQQKZJClzX4VvEsI+I0+KDNp5DUHQiASjpgPSxIvgNcvvhvJDy8H4Mq0I7qbRntZyY90yO0S2zJ
yAS9KL3Iy/Ts+z3PfO3OmE2+mu9fsmEC5GS/YvshOIu1NzEo5whmW5xl5KEHy8+tM1Gwr5492ce2
u8ohmA3xre5QmEMaaYZZI+32m7cV2ZEcLHgXBKDAQcxVsrs0sQqiEBom7ulAssBZAnbx9Tx8YVtb
+ypTiWoInZB9vHKnSjf7djfLYGfZVFWRH2U5X40kGLe++ESTZk8icO86Xqsp39tPIWk1SngEIkww
tiOWyd8PZOEil1sQCCL6iLXUmDP47ubMa3VUOUh034xsrx9c8267QNdWNZqEN8UIaRFpkV0PcA6m
I5emqZqdP3lSlm61XiG4G5Pdqy+Jt9GZsRfV4Mu3i32WpZRPcPMmCLVfP2rIesW6RlNf+Y53v1Cn
ZplF0Rp8Cn9UKa8GR6MjR7xvvW==