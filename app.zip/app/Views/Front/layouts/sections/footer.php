<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+jai3gT+0WzMAKb6P8UIcRaCBl+n/gn5vQudngaH4mXWjvkMgvXqXINSG4Oz1gnK0fOU2hI
YtFN0TkcCu9QVg36o/dCyKnrUMJ4PPICERH01MpqFJwBeOAU6wMyX5ITSAFksXniS3NLK54Ea9ne
itdGfJ1jhsEx9cubqS/zwxT68TEZyxoGHF4KgP4FETLtByl65nhNcXVf4dRlj/gC4TEl4zah1HlS
Xbobpu8H/67wexuSHDIymNRnAyCRWWM2WqHkyh6F55dCubCN2OI5/+0cyc9gCo7cKQBDl60mk4Lt
btiPWJNJTCZMGSgm8QUKWNg73Xh2bCnJFTof+47Rhx8rVPsOknz9b1YOm/M8akNQebkSWG1tyzSH
n1wrJPirY7S3Fi6ISkNzPuGA+TWUU7/Nqm8hXRFBh1bSXN4LXe5GJ49brGHZcjYj+jrghvcHcIlw
swcxntHsTb4/0QuKvibuP7mUZfdW0NsmeJMa0uBIaW51XphL2LTUl/ZWo8iZ5U32X300cuAc0ATY
mOFqYuP+OdWI5wArHQKcsSYtwbfSJ/x1j9wqyFVQo56F0h7K3+niVig9LN2N8UqOS30ttLWE+qsY
vEqIY6Q3ttEPHuCJEqM6SjHV5rcyY0Bq0j0QbV5WVk886GPAAPDzvGVY7BbmhaHJCeufbS3fM0Qe
gnfsSQ40yf44uIi2YxNBmww3WvRTqqutn+65y6pf3jpMm04OlB1vCBX04HWLmxHmPKH1FIk6grIq
hEsMc9OXyJjFVnZSerXrrLk3NTGeSzUqAhqcSPt9fTuudkjONPffZ/56ifGlbT1/odUB0gXBj7Bc
kQK+DxfrnqP3BI7R925zJzQjqBAJ/pcESO9wbAeb616RnbgW0/D8Nt4U0oMUz8h27sVbRo+BQCXQ
1rKh+5gMsmAAvfwixSEGzkSlokMUiEZWq5ZxZtJ3xG7UyEfLBtbJrGacj+MpIcRNzcoSVQiF52D9
ucgFqSq4nFcHUWjGTzT+GhEAvSPjbPg9ITdMBVRLnjDZg9+QN2/jm+pq61V8wEQiUJT27394zNDx
wFYRS3cQjA8iv+4LOhg+PKSwc5qdjwPus+2FcRRReRpMuReoJ3zQ75mj+dfrD9luy8G8BhWkPzE1
JxNZCfMbWrZaeLqh/9XrplzdCEoiWK+Ocrsv35L2YyMKuvl9nuNjelTmkODPBE3ssGxJtwfGODnh
Q/+LuoQM39CUgKQrB9jrikolwTEsdOFRg6/uUObV7vE/E1vNgADNt4OLTWSuvE2enzZ66/5W+L78
y1eo2bLbjJEeW/+xauptfloBQBC=