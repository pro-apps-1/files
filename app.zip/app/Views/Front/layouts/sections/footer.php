<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnEwfhZO5nk/fNipc/HH4xDmwWgdulYk7CjJZpxKVoSCDgbwgyehYXWN/W/SOTvnYCtg1+dK
X6Ezjpt4LmjL0A8gpwORRQ2hT+qvsNb/8C6LK+NDTbm1kxIhLTiPRyishdn6HggsCq+wHAwf25M0
P2wTqSHKycSi2/siqIsjRTBxHdhPqTm/53wmUHGfLSOIhfi43ts6fAm5dwOL65leOTo8t5zHsxAA
qb+YEkAu645MNyM+v7b3XKFNX6w/WOrpZ1XiHX5yXavASODAXtEDfJjwW1IwPs7Gv2rSveOyJV3D
PClkUsW+KK7k0gG5zLZ+PnbYrBqspzRrcgs5fIXCcPw7+MMcq7E5lHlUMzYVnfngzUVHoniWOx7V
7mtZ4Yp1KVYtSzeQ36LcuOx+uojAg3w/GgQMgyCf6drKootmQjH2jfIrJYtyOGOTuf/eNfjIVe2i
K3x4RwZukcOcyw7HyeKNmq02xybreyWd1ROT4th7E3cJdwvS9cL+UjEtZk8Z6dBf2/DNEawplxtL
1+78gWPpJUI7FH3/jqQMgOYxWwCVSFiE54XH9sA6/PVEmNLmByZ3SOfA1qIhs/gnO3HmwwU8AOaH
v2+wz4t5vFxUOHFW2vuKSnKETW0goff0hcrxHzXYFPR486HhsHOA0RIAwKNlMyQvlzocpTzZN0bb
KQ6w+6m8ZlzFFja/BwaOmBGZmiD2RIWAPAFD9O2nD7udws28cufde0ASYRJXpf2C7allstcAMPOd
6bAFgha7hTF5VuBvGAUp2OYeRe495XineYr8IjmcmrXZvg9NO5tbRbg7QLnGJdoY3R3K+WeUkCQ8
NvPmCHZ7I9sVAyt87oVT1DrVaeYR20lscnrgrCrEMaMx03IvZxpKoGVSEY4UMQsnk9v8oZ5XyVVl
9gmpOEFlQQc489GAl3DC0iYwl3+M+MuOK4SgfnwLQ3yYxCH9BQ2jt5+9Pyw2v7m8WlHy98p6zmc5
rYaDzQ6E7bKjre+iEMnQcrRS9sIPQXvbNKUIB3EluFGAGSxyCBJjVhstz50pj2GehgHTXcVMNUcr
eMo00MGtnqMrSTxtS/EBdRtsdI37cLomlLdiMrZITPColt/7mGy6G+f/HeIZ7tU5x8EGT/lVnZOM
M2P0NykTrYhPnn9Xv7/pm2xPjkwAZtO8xgKK2nx2eobIJE6a+noFJUJi4DgiraHdriSwHWGc8eof
BKwvYXpanF547L8LKXJVLJNFssXauxvbqhBsb41SLRWS8vcH6c39IapLTj33R2b4qm3RZQNngBG/
ZVSQiKGwy6artROKUImE