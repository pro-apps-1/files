<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyoq243YA/5t+tUTOxxJ4s2YlrpgEpxZoSqxCgPYjNJ8mXu36r/fVUemejepLEg0QYLMYU7P
dXT9qvJY2MNn6vPM4yirBnyFNI3SmnSnJeYgpN9PI+QGVB3jKFr8PodFbLrlJtD6ENU+xjLFmgf3
c+A/yYEmJ+SXb7R0uMj5MNfjnoInK6tgEPI0PDBXwntSYv5DmiMN+UHch05BgfmRYerxPqqsWnzw
DVEPrZfDAhBpnWPO//UlfjTCuObGQBGZaJ6Fgafyv+3U6ZaZDU62XjlaMxMkRRBilXqhHBSyXnV1
BVowP/+SD5s6cBAbqMRZVwPbhc9STwOoRLa+jnCoU6KYDSJYyoNe2kds1JdiBK/zXovY30qzQRqV
pGjVjgS/BJPp8JvNtRIvS2NlTRLvk8rbV67xP5jgkkJXEW2T2EFuCuAJQBI/l7LYEDeJBPitIO+X
6EI4LBc/9YhVHDadYIenGePqAXKJJAvV9mZJISDjhO5J3WBbW1bbE6ARdRfM7ALCeHEUFK9CxAba
HXMGAJcQkDut6VfLA0f2jbmWq1HpXIEDZLK78zEiRKIFZVk1Q5J6FulkPLeskp6nEsiNqtxej6FV
cd8a0JvsxV4p7p7UWJQI/JZeGxEPNwSNFu9V/MGSQEGsxSQglcr1OcdqW69WWCJIL60kqsKwO9tp
ERyRtPlBcV50tSilTPr/96tBIFVH3Jt64dty4+Nf2QpdustpytMT6as1rZZEA1JuWYok0CtJGTKn
HBYa+NHcX8kxJmVqb6WUZwyxs2TZD3gxA8yQGY1erYX55UDjvoz63/lgn5spqB9TZs7yHXeoyH2w
eWjuumnoMGBNcrTclLjb8QCaaPW81cWZlAJiwxWeHL+3fETO/qTxXJQB7QpPfK3W2TU9gnws9DJu
q3vV78lSwLaee7rcbuuMv5RN0Q0MgyTDalMmYwArkM05q2/cDp4LNpMbvvP5UH4APsjacIImRheP
0537bnn6ZcuLZiw0MYbrx6MxXMEqDKRzgAb6FiRXZZD42IKdXTLX0ABKxOIT1z+Otz4KxUXtZRBp
D3kWsZBGjUDCB2Riwyb+sc0XopVyJyrLXN/EEsVaMrLUe4vMMD8nHSCXITs2A4Kqup4lRra7EBf1
grpG584XC80CrkDdLKFBJjMtCPQ/lYumLxGmBlgwK1H4WQxzB3zvyIZRQiFBPYHZkANfYQOXH0Qa
XB6GTXXa/wu7pKVwa/NhRINXdWZbmoHRR6C1g7qKCUcGCtAny3ahdKlwJJkrfYqgthwlog427jIE
+bAW52HPdzEjvfU9hxTSjYBsOKXMZ1SJA+OXBriA713nQID6K19G5fqR2bQdc8AOAHnUT3xjaqg2
1zse4t+JrfgBxuudgq9f56Cdv9uEauk7NmXzPVfkU66vEAblH/Vp06+OQifIjLdy0QZLyCU3FS6G
9lTjTD0LOzvrSvNrXy4S/OenNwWMFxHLcZJM4aAvu+OD6pWEqHERUw4gqMh9WApgvZikpR4EbAKn
sndAgRksoB5H6bNThlbl8z4fwmA5nuvkVb2NSKRUApj7/jDccNcrpJYlPzP8NeU1Uq/AJJbX4Pjx
mZ2laQIEml90V552j2P3j65UN5YqIZO6id7ZHTHyT2/7djLQMYDoy6ZXKGZVQ7YTrKaQ0981VpAV
anYO0Mz6hY0i+A+Kidd1ZbKV/oB9eKblOaIhl4OJzFJvOGg40QY0JY2MXcAQHERs3uTBw0bABqOb
Xgh4oX2yabnGY39dLPImSxqaz+kh0cjXd+YimKXade/V7+9TGWPZ5mrori35bntGyikYkT5gDkz5
UNSIlKyPwDrxqo57b8fb00dLAnfT2THK0n5Y93tQyapP+iGqT8xcekOrCXFDfY/wwNHNZnweyuoB
a5heL22F0NvXsnRN0Vh5MzERejh6+taDvr8g51PnoVFuCEf2efzR05Fu+GLr+8OrN1ZKmralx0CC
0Ce0RdWIDN0lwrsjhpEm3pl0utm7LPoC0mzaFr7klmKiom7dP6/J13P9cmlN2L0ZTkYWdiou15Gz
CDOCVSTTjzmSSUAWrW4fNfW07HmGO5ojtoQGB5iptn5Hz6xIUfdRpqCEbCGbzSFpj3d2Y14rg6PL
ZQapP45pbYC8uCGU6iQkG0ac+GyWWucYfWYOqNW=