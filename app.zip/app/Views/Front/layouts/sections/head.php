<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwGRLt2Rsgj7OiV2KthuYg5+Lp1+J7xHgTe5R/7Mp2N0DMSNIP5lvjqXSpjFfVwfCyBYsLNi
Kf5FH9NMfqVlPFNofY1bvDmTMLohsm+dwUE7xIxRubnhcNo7eXqX0aCugzIeJ5ZBaTkxYpqid8qU
Yb0Cn/RFtd7U+Ow1WArltuHFe7USs6NTs2z5W1gOulUpGW2S6JZlelMm4gI/4mCdDXaNi5ULtBU1
zaxcnjxim4GD5pzb0ItDkd8jseLjz/aveOp5nIqmuy7i9RCCY41Wj1WlL9V9Z6yj9vAY6F3+YrYx
yK50Yq2UJ4/9laFu53DIEeLv49Z437GUni/U1ZOUQ/GEJuUQQ0XJjw+IOV7YM7GeA+UCUdv9bZL8
RLe+RVzZmDFVcFVNd0dWI4DIfqDnYd5G5CyQOS4ptU1fHTGqabbbzfdW/abez4cbPtNZq37l1lNc
UbgoCo/D7nR2hnVA3u1l4WnfkmHI2XBTmgzJZWqen5s2NkKC6wRt5ESn1e78Q1IK0qo0ncvWs2GR
mWxfvi3hL5X8xHCRUjhclb4hPMr3dWy6UGESgRiZ/5wP5zRVrxIsu2AoXKFJFepBpBxaCp8ioqpe
b/nNZ2X52hK1y9CBb05whe7QXNDt1zb9EUAyIQAvk+9KYo4AIbUvPpMlGnbJygdLnDrcXlYysQ0J
8S+erm6AGKZ7Tedsfmt+L6Gcr25brT6Wvjr9W8LPxWgiJo5AXdV+YZJvZgE+7gXkG9mz4e5H37XN
5cqVTOLKHvzVaeQA57gd60r7naZsI3/mtWh8cdmXa13m1bORtgGoFifc090gCvQMXiB9h1Jc9dsl
spQWPdTB8GprnvWM/7+YqZVrGY65VLLmJdICOcGgnCQSvaaU6yXwvxR9aBI7Z5rKTfOSp03hexf7
ioMPwhqqzl0UI9RcAqfTXW8Ic6PwWns8o8K1cTG3iDvXrOKdnYxCmsbILCbBQpa5tfg54ff4L2PK
HNWck2aTnFvxMku+c2HEPL4sv5o6Gc3y1YwS5Or8JFwp/LikO3e3a5SbY0onL9ArNSLgdY95QuI6
lD4Y6EwpaINnVgJUc6JaA+NZWu/QT2Co9D/oIL1VO0RO67aYG2zk44Yq2/9am+nJvOvzIVtOfmni
JMIRDsgaboLgehxooysb3ZJUSbYTzUAp/tYTMShGArjCQUoNgKRiEtcWq8CNa3qkM0rtdemU7YUl
vcenTYmj58RlM1PhqjlVvIqKA5U/CyP8kFmojPuuSaV0RLv+aRG/lZ+S36osP76Eo4Diaev5T4WD
LtIEJ8KgTYjZ3itjJKJGbryq/oivN+wuCNaqjgdC7w18g7huWHw4ynnbbx/+e0mkRqnwfot8m+t8
s4DN+Z/9IZiU6EM5ZYqbFhtTQlv3LMsfXn0M2fbIovLkGSkZdunULHm5cjuE8ygz9n8edWyX9vzp
3yBkTQjUnmq/0bsobTTJiyIFz4Kqp0udmvHA1vZrkHEhyKKGfjA5XCcxmtXae0WXQVWVJkEJXaSG
Hu6u4/MiXhpkHfAb2jfGviDYutNSj8Ki+yru9sjK1WtUHIrmM+RK4gejBgUf+lYAQ44nrN+OEv/w
ckGk1SLeuw+crIe6WhvHzh6xLWzbrE1yQK6De9Xclg7VVhELqmCf+OIRMca3rCbhMD1HYrFjiqSc
NzHgCUzFEBBKa5/QsYoei1A0U+6LOblxUjrs6WiOZPtTChv024f5dqttl2Q16yeDPhcR8cw4FQAZ
zpZn1VOHUWY+wx4hDGyilWpULrXlkJALgUgEabtny77XP36eD4tElN/34L9y77ol8Tx+tdP+XBgl
54A/KeveMjwTkkZkaTE9UqxbvlXmVALX7BYKvMxtQliktkl9gqYM49LTNRXgOhaqqvZ8Dz5d8pDD
+mSNYIOikWfVS9GhtwmG33BIsItQ6AE2nsNHBggjL+VcJ2dHjv3V9B7yBRy0E2cco7NE0mIbUymd
fWAmP0AbPd0Auq1EPDogSnuETvhnTo6rB3V5fgpG0u2LBZgrFTYUWWg9IGQuAUXhMduKMTRa8gbZ
VojhWOdc9Mw2qdbHK8CVQMzJOdf+jSQxH876YXoPUmukwF1G8/O5YnJsz3/XnV85MaahxXvTCYB9
QyV0gOMiStr6f/AAK8OpXZUFvPmR20PRsl1HOyQr3bVcnu8CAfcpmY7iPGKwJ10q5ixoVdEx9Q/o
i4fRBUguZEuDpR2ifFgl8BiTWW==