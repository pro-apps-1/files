<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnVpOO03OrgesY/qenJHwgCaZvNxK1x50V0GkolbI9hAYcjthiLJrk9D2+LNRzxhhoNYJS34
4ttFu5RVi4vY1hzic+tWuIqUiwjWE7vuBXaTLbS+0tLd98o2mmAKuuTIyQY/ZjOK+pJIYOnYAstF
jT/nW3ALYfCHdFn4un4K3kZnTX4slKytcwxwo+mmnFg4378mPpCP3Wra5vyAhAe51/hihVfbyOJT
1B0MVDDaLi8Qlv5WaWiLlzfr74MEsh/5wlVBCqkrEFPCywQ+/z1G38IBgI9bHspK4QOZM7O50lGj
hcKiEMgUK7uT/swqrNvOc+62i/wmdyjpkW81HaZnFaQ31mZUaEYL3CjRNcHwTj9Gk/Jq8q2ALehz
gSvtXgH0g+7VxARhVVQ7UykOBfn9t6F6NNg2qOcL3NcGL5YK3cDb2cIKVjw8xIY2sFUzqNzGUx9p
CQO5MjV1q2OOQ723LbGQ2q9NtAnaMc3amkcCA+68rf+xGneOXVkdYLWnbuiVeD6FLcUAPNDW3x+m
DJCCx4ZrS4JDczjdFg4f0qMx+o/4qbbafFzwQK/JWzrNtWAttG2S/bWc5V6W1enXmBTZ01ziPuiw
4Ys3J/X4z8XC1O1chnR0SMW0nYmhWCDfsoWhWlAdg6DWsG3QF/ylcl6L/3r/NlVgifCELBtKXNjB
F/q+okOYJ+n4jJvC+X/CtcIxukT5QE3iyG5kVeTZQCv14WByxPxb9GtSrMGAG3zcU1ghvlmDPZjK
PGoNlRp2BeoqVs90OSpbI+rHVxUkSqsUCVdA27kdAOaKKwz8+cgi2Vbb+tJsSJU3CmuimL8VhacB
AQH0iWp8mouDaujNA+GpUz8xxdEgzeCMML0NIqzzHk1BGksMKrIo0KNYHbsl0d/22LQZFLl4GxL3
emxeuVSf2YY9Pcg9jagSR7a4NSsucS03H5+4Uag2iODni/Q9WP2rLCQ9HrVQQ+fWQ26QBGQtuvfA
2vcR+3VBq44TlqcHQ3c+6JD22EP4P+DdrJjfRB5WOyCfs2Wq/x/Qt4MIwvlff9jhyK50W2QSX+9R
ozbSfjGfd8LtHFxKsF8bn2cvA0dutxwH1wAlg4zO5vZ4kyHmDuhlWGYn2+FqX0aciTXDdnfNNDXy
xYERPiUzsVILntWXKVVeR9eZYrTqrTnEidxgSXHgYPBJMcyzr7AND4SWTlKFkeFaKj/kjBO4DoFO
r0qSeICOc8Xh5dEMQErt9MefNmytjIjmdPz1BbDadTyC8X6z2r8vw09pU6Oc5+ZN76qT1c/ykk70
Z8vKlUjQfiHsGckCpG4S5jUGyDTdlGKcr9/Z8IAT6BgmpuYtsFoZiIxGb1L+w5F119PhV/gA2Fue
WZG2ZYGxjr+HcxYYf+TI1K0gVqcDjlmfZdY4vh7tbIYDpqLpqxUEspi7Bpjy8ejbSd8MoEtIUZw6
3Q2M4eZlXOFAQ6t0EsxKAZc4KRVtMOV3tpYzleMbf7HGolrVyjoLCrCRCnlmCQ4o+4KZ6arIXF04
bRvR3V3EH7IHVJ2Gp5xB//UR8IToLy7NrH4OxOmRW7z3a4NmrEw3q2xpWpJj8hQ2YB4bdd4VN9Cq
CRTeuWjoFjFLkQCxKNmKpkBweP6lK7Uzp0eBl3+dSiE2Y20o+upgwNUyx0Kju6mlcSrGS82ONzuT
zjlUgiyCn/g5g/RJvSPNIkstf4GTTVUMorZQDzwJvkaXwyndzWj4wJOe1mMBqY/12aahc6jCwUyl
sLeuL4sRMIXah0eLdTz036AfA47H+9UCC15UJdAzKHhsyNHe0HSiozWb6+GpJcbuSvy7CCNJZkxQ
/K9cuhbD6cW/9b7XfnpTkywEbw4JUpIxiq+eXIyj91xMNldOAgzaMTVvljUUvGiJPAUyZ1ZMFvMV
Xucr8Xw56ZOfQVA3nZG8jzTO800u8C7DddrsykqZeoVPm+TN4JKdGqxB0YzzLnBRVzq8z+lNMwDf
bc6NASvVYz2QiiSAdLpu5a7Avzn9OoG4FQHuhpuutslL1oR/pERUmv5vbNzo1yT4dzkJeWTsVUOF
K5tBVXxxXllfiFSlNLytD+1iczrY4I0CG9armSp1bssw6Va04ua/RVN+iTFkdLU/uCd3mHelchZl
Q339Wx40+AuYW1LNHoKbekGmTRbxE7VpMi3LQr1jNrWuJpOLhi4FGFNL7gHSVoU+xPsovdKi8Xw1
TOEqk13H3GCqk0VCpzm=