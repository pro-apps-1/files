<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtfvnIkg+JqCiwLG29fa9WFl9nQcbUn9ARAuSD3io+gPehE7dbBDPBCbaV57ie6XNb+2zD7f
JarIkg7FW4hQBHi11Cnc7DyPR4QRbiHI8KDYq0kHElvMhzJ/RjFaG6c1SL5x2K7ha80mo9AUka5b
V++ZB/MxMSi5jqfba+zlk4hdOoVoOE5PAKXcUJjG2RkoyYqW0eXb7IZHg3Qx62XTrB9vkH7CUDIc
ApQcqiSakncWUHm28KZde0+ZNbjaCl5RoT9VgTMs0bR9yaI/G9MPSJsk0dvd4NBlSg8DpLWfgru+
evmq7V7LeEJ6kl45PIuiX6K3rEGYLOuC/TnqlJaM8uY7b5amfmhnbhCajPrt064LmbJuTDb/NkIg
rVB0jZqOAbsTcqJM/7bYJMbF0g6UxzqoFV1znT3DzVK6hrBQcPzU1jfssT1cDhZxSs5eyXtY9K0R
90HVtatjd6BZD0libplnUjkoH35u0wtqdOX4+324zNDDj59feenb6Bw9favGgdnQgfh1BBslpSe6
PteKOOkrPpO+jCX6Lo3RmJJyy84VQn/QNvPuZTgYD/tsa6vnEGmBL6Fona2ps22jQxQIhUalV3GH
2TIwViqvQEcI12C7bxN7u938GG9nMefjRa3SZCsjfLQrikAFy5J/C0AdQIAuDETnMFV9+YGS8REa
XkOfT62HQmnZ3KejKGvkuRK33R2AErPhwAHf/yTclVOQRPtzEcp20q0U4Jg/DQ6Xgymt0i8moWOE
yiTEopCLjiAFGQUCYCqHurRfJBRhmnKPyGsTVYk5Ly9NjnagAv/1Qq4gJJvhhEm5D+NefSYnYmfF
gukAj52mO5mcEarTqhFhwj3u28gftAGFXQTH7JbkIAV88G+uTruZf0UHSmqem5PSTrL44oD8Dtaj
2KRjNqMkvvRpgwedcF2f7pvKDZNtyXSiGsZQE7CM2c+Z0JT3IhoKZxaWtPywpWiZGe1FnrK33/92
ViRehKweN1G5Ogye4+NqIPSlAqaMaAZysIRAZriG2x33jTq13nKxd8GBD8Z6jspfweNhbB8YB3ww
54EMmK807zmxfj+rHsb4AvHUSx7sb6mej8lSibySeL+aNWtlEIxXtQI4Hw+tIZcWKTXUT61ET9KR
bUWdudEA5f+Wa3yLNhNTQGHb/nYv/7E5shljFw81/FmiQ822f5rUpFkPT7bzB0GKFphPaMhXIx+k
3e2yLcJ6kEQElDfCGIPPWeCG2/nhOgOVDE69qGhZa9LoGwXzAN278FLFnEwr0li2pJq4TNKuyztN
HtQfo6ITWl3X6b6vD9aSbrrKs3jTAtCC+wn/HVtV/CjdTD+9lNmWHeq0z7m0HhH4UbGJ5uL4pZdi
ukr+TUSLGFcl54qjjVAPsGvviITSt44dtQOggCa0nyQBmCRc1vDReaAJdI/y+RocpH72Pa9PLg4F
UX20/I+ucDZ1yli+jlPka3SQupky5TJ0rX/Mp18m7b64NBG6v7w5PGCPHpU0zZGt7hP4R0mcpFN5
QuimQkSG9Q1e44+U1BbLdmuf+fNiZ0WH8or4x57o1r7chsUOhiaTKiLVJmWZSzW7gSsvzdgaLjkm
XrU8G3FT8TxcalohO5ZWa4Y8EuP+qozBBf/g4I/hAnBQlzbuYzfTFohjjmivDYAez6BBdBkMNdnL
JnN+XIvMDbL/yKRM6tVH2h5XtbGWG4F5ESZDBauunCNQIKfCTgAiaPXjNqytBLGI+uhqyFMKXtMo
7KxG5k6Er7DZFiJJUA4s24gvMeWz7TJdY6nmD/p/onFD0kv76iDs06Rfy9AV1vOgtdZTYqycVWEf
bCAorm4n5O54xz3NMsKMeZKmVg0tlF7Gb0yeKTH0cyO/oVaR7sFloAJ8Au9pkqx0nAQVtbVPDYOI
DvPOy5QarNpXL9EYWU7Sft6eAS+rGNfM+aIhhzrIpuGAD56yv6Z3eYgSB/cJLQw8u75wEHcD40PI
VBCX/lVbJvMQG1fIgB6O2j+CVJ6LNZS8JKji3ql7DuJXq3NpLe3HM13IJWtpCZX5uLHOtlYW8L3O
84dzxGj2b7iTPwUXcQDk8HNCcgmpMM9jsHG6JnYm3GjLcLkLOPCvPnmMQoMfcw/8/GyFIZ8vE4hN
YAQyifyxYnPgNyVNrewCUebtW29mC60n+jRMN6xS4z1K4/LvL4zFY4/6C3QN6Ics4L9ww8XP+6Ft
e9944Qd1Kp4JhYePHAmWkiOF